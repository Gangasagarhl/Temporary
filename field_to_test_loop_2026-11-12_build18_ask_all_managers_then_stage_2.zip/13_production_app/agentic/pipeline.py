"""The flow: ONE run from the input folder to the test case. Family 1, then Family 2, then Family 3, in that order.

Steps of a run (kind "flow"):

  Family 1 · Data experts
    director                    the CSVs of the folder and what each one is
    f1_last                     REVIEW when dictionaries were approved before for these same files (same headers):
                                "used last time; proceed?" - approve reuses them and skips their Explorer, Grounder and Manager
    explore:/ground:/manager:<csv>   one sub-family per CSV; the Manager's dictionary is a REVIEW (see family1)
    f1_gate                     REVIEW (see admin_ask): the admin asks whether a kind of data is present (the Admin Agent
                                puts the question to every file's Manager); "read the new files" gives the CSVs added to
                                the folder their sub-family, placed before this step, and asks again; approve = go to
                                stage 2. The flow does not reach Family 2 until the admin approves here
  Family 2 · Hierarchy
    last_strategy, rea, collect, coder, build_ask, build, slice_test, breaker, independent   (see family2)
  Family 3 · Rules
    f3_plan                     REVIEW: the items to use on this data, Section 1 (analytics) and Section 2 (errors).
                                Approved rules proceed as they are; drafts, new items and items to edit go to the
                                Rule writer first. Approving it adds the steps below, for each chosen item
                                (f3:<section>/<level>/<id>[#round]:<step>):
      write                     the Rule writer drafts the rule from the admin's words - REVIEW (approve = new version)
      code, run, test, export   the code generated from the approved rule, run on the tree, checked, exported
      result                    REVIEW. Change = say what to change in the rule: a new round (write ... result) is added
      for a Section 2 item, stage 1 and stage 2 on one defect the rule found (the admin picks it in the result review):
      isolate                   stage 1, the isolation tab's own evidence loop: the reason, the rows cited, the shortest
                                command sequence that leads to the defect - REVIEW with the four signals:
                                correct (+1) / correct with your edits (+1) / wrong (-1, runs again with your comment as
                                a hint) / wrong with your edits (-1 for the proposal, your edited sequence is kept)
      outcomes                  stage 2: what a correct drive must answer from the defect onward - REVIEW (approve = verified)
      testcase                  the test file from the verified outcomes; compiled and run once with pytest (on a machine
                                without the drive it must skip cleanly)
      summary                   the summary (who, what, when, where, why, how; at most 100 words), stored with the defect's signature
  report                        the Admin Agent's report of the whole flow (HTML and JSON), with links

Stage 1 and stage 2 call the same endpoints as the isolation tab (/api/isolate/...), through the application itself,
so the flow and the tab can never disagree.
"""
import hashlib
import html
import json
import os
import py_compile
import subprocess
import sys
import time
from collections import Counter

from . import admin_ask, core, family1, family2, family3, source_tools
from nvme_hier.defect_graph import SIDES  # noqa: E402  (the sides a cause can be on)

KIND = "flow"
FAMILY_LABEL = {"1": "Family 1 · Data experts", "2": "Family 2 · Hierarchy", "3": "Family 3 · Rules", "R": "Report"}
LOWER = ["nvme_transaction", "split", "link", "packets"]
SIGNAL_WORDS = {"correct": "Correct (+1)", "correct_with_edits": "Correct with the admin's edits (+1)",
                "wrong": "Wrong (-1)", "wrong_with_edits": "Wrong, replaced by the admin's edited sequence (-1 for the proposal)"}


# ---------------------------------------------------------------------------------------------- the plan of a run
def steps(params, project):
    f1 = family1.steps(params, project)
    out = [f1[0], {"key": "f1_last", "title": "Director: data dictionaries approved before for these same files", "family": "1",
                   "agent": "Director", "review": True}] + f1[1:]
    out.append(admin_ask.gate_step())      # the admin's questions to all the Managers; Family 2 starts only on the admin's word
    out += family2.steps(params, project)
    out.append({"key": "f3_plan", "title": "Family 3 Manager: the rules to use on this data (Section 1 and Section 2)", "family": "3",
                "agent": "Manager", "review": True})
    out.append({"key": "report", "title": "Admin Agent: the report of the whole flow", "family": "R", "agent": "Admin Agent"})
    return out


def item_key(sec, lvl, rid, rnd=1):
    return "%s/%s/%s%s" % (sec, lvl, rid, "" if rnd <= 1 else "#%d" % rnd)


def split_item(item):
    """'errors/nvme_command/cmd_incomplete#2' -> (section, level, id, round). An error's own steps carry '@<finding>' after the item."""
    base, _, rnd = item.split("@")[0].partition("#")
    sec, lvl, rid = base.split("/")
    return sec, lvl, rid, int(rnd) if rnd else 1


def base_item(item):
    """The pattern's item of an error's own steps ('errors/nvme_command/cmd_timeout@10' -> 'errors/nvme_command/cmd_timeout')."""
    return item.split("@")[0]


def error_of(item):
    """The error (the detector's finding) an item's steps are about, or None for the pattern's own steps."""
    e = item.partition("@")[2]
    return int(e) if e.isdigit() else None


def parse_key(key):
    """'f3:<item>:<step>' -> (item, step)."""
    body = key[3:]
    item, _, sub = body.rpartition(":")
    return item, sub


def item_steps(sec, lvl, rid, name, write, message="", rnd=1):
    item = item_key(sec, lvl, rid, rnd)
    k = lambda s: "f3:%s:%s" % (item, s)       # noqa: E731
    tag = "%s%s · " % (name, "" if rnd <= 1 else " (round %d)" % rnd)
    out = []
    if write:
        out.append({"key": k("write"), "title": tag + "Rule writer: the rule from your words", "family": "3", "agent": "Rule writer",
                    "review": True, "input": {"message": message}})
    out += [{"key": k("code"), "title": tag + "Coder: the Python code of the procedure (verified, or written for your review)", "family": "3",
             "agent": "Coder", "review": True},
            {"key": k("run"), "title": tag + "run on the tree", "family": "3", "agent": "Runner"},
            {"key": k("test"), "title": tag + "Tester: the result checked independently", "family": "3", "agent": "Tester"},
            {"key": k("export"), "title": tag + "export (CSV and HTML)", "family": "3", "agent": "Runner"},
            {"key": k("result"), "title": tag + "the result, for your review", "family": "3", "agent": "Manager", "review": True}]
    if family3.goes_to_stages(sec):
        # (owner, 2026-11-11) the errors a pattern finds are listed on their own page; each error is taken through the stages on its own page
        out.append({"key": k("errors"), "title": tag + "the errors this pattern found (each is taken through stage 1 and stage 2 on its own page)", "family": "3", "agent": "Manager"})
    return out


ERRORS_DONE = {"key": "errors_done", "title": "Stage 1 and stage 2 of the errors: on the errors page; then the report", "family": "3", "agent": "Manager", "review": True}


def graph_steps(k, tag):
    """Stage 2 (owner, 2026-11-11): the procedural graph after the isolation: defect -> cause -> solution."""
    return [{"key": k("cause"), "title": tag + "stage 2: the procedural graph: what is stored for this defect, and its cause this time", "family": "3",
             "agent": "Procedural graph", "review": True},
            {"key": k("solution"), "title": tag + "stage 2: the solution: the stored ones ranked by your judgements, or the first one", "family": "3",
             "agent": "Procedural graph", "review": True}]


class ItemCtx:
    """A step context for one Family 3 item inside the flow: the family3 functions see the item's section, level and id
    as their run parameters, and their own step names ("code", "run", ...) in output_of."""

    def __init__(self, ctx, item, sub):
        sec, lvl, rid, rnd = split_item(item)
        self._c = ctx
        self.engine, self.run = ctx.engine, ctx.run
        self.step = dict(ctx.step, key=sub)
        self.input = ctx.input
        self.item, self.round = item, rnd
        self.params = dict(ctx.params, _kind="rule_run", section=sec, level=lvl, id=rid,
                           message=ctx.input.get("message") or "", upload_id=None)
        self.prefix = "f3:%s:" % item

    @property
    def project(self):
        return self._c.project

    def progress(self, text):
        self._c.progress(text)

    def evidence(self, claims):
        self._c.evidence(claims)

    def admin_comments(self):
        return self._c.admin_comments()

    def output_of(self, key):
        if "@" in self.item and key in ("write", "code", "run", "test", "export", "result", "errors"):
            return self._c.output_of("f3:%s:%s" % (base_item(self.item), key))      # an error's steps read their pattern's results
        return self._c.output_of(self.prefix + key)


def _admin(project):
    return (project or {}).get("admin") or "admin"


def _standin(engine):
    return engine.runner.runtime == "standin"


def needs_hierarchy(project):
    """Does this analysis join the exports of its recording into one hierarchy (Family 2)? It depends on the tool that exported
    the recording, asked on the start page (project.source_tool) and on what the reference library says of that tool
    ("hierarchy" in reference_library/index.json): Teledyne LeCroy's five exports of one recording are joined; a tool whose
    export is one table has nothing to join. True when no tool was asked or the library says nothing: the flow as it was.
    Not used by run_step yet: Family 3's rules read the hierarchy, so for a tool without one they have nothing to read; when
    such a tool becomes ready, the Family 2 steps are skipped with source_tools.no_hierarchy_reason(project)."""
    return source_tools.needs_hierarchy(project)


def call_app(engine, method, path, body=None):
    """One request to the application's own endpoints (the isolation tab's), from the engine's thread."""
    app = getattr(engine.services, "app", None)
    if app is None:
        raise RuntimeError("the application object is not available to the flow (services.app)")
    with app.test_client() as c:
        r = c.open(path, method=method, json=body)
    j = r.get_json(silent=True)
    if r.status_code >= 400:
        raise RuntimeError("%s %s answered %s: %s" % (method, path, r.status_code, (j or {}).get("error") if isinstance(j, dict) else r.data[:200]))
    return j or {}


# ---------------------------------------------------------------------------------------------- the steps
def ahead_chains(steps):
    """What may work before its turn: each file's Data Explorer and then its Data Grounder. They read only their own file and need no decision; only the Manager's
    dictionary does. Nothing works ahead until everything before the files is finished, because "use the dictionaries approved last time?" can skip the reading."""
    first = next((i for i, s in enumerate(steps) if s["key"].startswith(("explore:", "ground:", "manager:"))), None)
    if first is None or any(s["state"] not in ("done", "approved", "skipped") for s in steps[:first]):
        return []
    by_file = {}
    for s in steps[first:]:
        if s["key"].startswith(("explore:", "ground:")):
            by_file.setdefault(s["key"].split(":", 1)[1], []).append(s)
    chains = []
    for ss in by_file.values():
        todo = [s["id"] for s in ss if s["state"] == "waiting"]
        if todo and all(s["state"] in ("waiting", "done", "skipped") for s in ss):
            chains.append(todo)
    return chains


def run_step(ctx):
    key = ctx.step["key"]
    if key == "f1_last":
        return _f1_last(ctx)
    if key == admin_ask.GATE:
        return admin_ask.run_gate(ctx)
    if key == "f3_plan":
        return _f3_plan(ctx)
    if key == "report":
        return _report(ctx)
    if key == "errors_done":
        return _errors_done(ctx)
    if key.startswith("f3:"):
        item, sub = parse_key(key)
        ic = ItemCtx(ctx, item, sub)
        if sub in ("write", "code", "run", "test", "export"):
            return getattr(family3, "_" + sub)(ic)
        return {"result": _result, "errors": _errors, "isolate": _isolate, "cause": _cause, "solution": _solution, "outcomes": _outcomes, "testcase": _testcase,
                "summary": _summary}[sub](ic)
    fam = ctx.step.get("family")
    if fam == "1":
        return family1.run_step(ctx)
    if fam == "2":
        return family2.run_step(ctx)
    raise RuntimeError("unknown step %s" % key)


# ---- Family 1: dictionaries approved before
def _f1_last(ctx):
    files = family1.inventory(ctx.project.get("folder"))      # every CSV: a file that is not of the five levels has a dictionary too
    if ctx.input.get("comments"):
        return core.Result({}, skip="the admin asked for the files to be read again (%s)" % ctx.input["comments"][-1])
    known = []
    for f in files:
        d = family1.approved_dictionary(f["format_key"], f["name"])
        if d:
            known.append({"file": f["name"], "level": f["level_label"], "version": d.get("version"), "approved_by": d.get("approved_by"),
                          "approved_at": d.get("approved_at"), "columns": len(d.get("columns") or []), "rows": d.get("rows"),
                          "columns_in_file": f.get("columns"), "format_key": f["format_key"],
                          "with_meaning": sum(1 for c in d.get("columns") or [] if c.get("meaning"))})
    if not known:
        return core.Result({"files": len(files)}, skip="no data dictionary was approved before for these files (same name and same headers)")
    body = ["**Admin %s, need review.** Data dictionaries were approved before for %d of the %d files, with these same headers:" % (
        _admin(ctx.project), len(known), len(files)), "",
        "| file | level | rows | columns in the file | columns holding a value | with a meaning | version | approved by | on |", "|---|---|---|---|---|---|---|---|---|"]
    body += ["| %s | %s | %s | %s | %s | %s | %s | %s | %s |" % (k["file"], k["level"], "{:,}".format(k["rows"]) if isinstance(k.get("rows"), int) else "not recorded",
                                                                 "{:,}".format(k["columns_in_file"]) if isinstance(k.get("columns_in_file"), int) else "?", k["columns"], k["with_meaning"],
                                                                 k["version"], k["approved_by"], time.strftime("%Y-%m-%d %H:%M", time.localtime(k["approved_at"] or 0))) for k in known]
    unread = [f["name"] for f in files if f["name"] not in {k["file"] for k in known}]
    if unread:
        body += ["", "**No dictionary was approved before for %s: %s.** %s read now by the three agents (Data Explorer, Data Grounder, Manager), whatever you decide here." % (
            "this file" if len(unread) == 1 else "these %d files" % len(unread), ", ".join(unread), "It is" if len(unread) == 1 else "They are")]
    body += ["", "A dictionary describes the columns that hold a value in this recording. The analyzer also exports columns that are always empty (listed apart as empty) and blank spacer columns between groups (no header, never a value).",
             "Approve to use them as they are: the Explorer, the Grounder and the Manager of these files are skipped.",
             "Ask for changes to have the files read again."]
    return core.Result({"known": known}, review={"title": "Proceed with the dictionaries used last time?", "body": "\n".join(body),
                                                 "data": {"reuse": [k["file"] for k in known]}})


# ---- Family 3: the plan
def _f3_plan(ctx):
    up = ctx.project.get("upload_id")
    items = []
    for sec in family3.tree():
        for lv in sec["levels"]:
            for it in lv["items"]:
                r = family3.load_rule(sec["section"], lv["level"], it["id"]) or {}
                approved = it["status"] == "approved"
                # approved items, the owner's default choice (family3.DEFAULT_CHOSEN) and the demo error are ticked
                selected = approved or bool(it.get("default")) or (sec["section"] != "analytics" and bool(it.get("demo")))
                items.append({"key": item_key(sec["section"], lv["level"], it["id"]), "section": sec["section"], "section_label": sec["label"],
                              "level": lv["level"], "level_label": lv["label"], "name": it["name"], "status": it["status"],
                              "version": it.get("version", 0), "demo": it.get("demo", False), "selected": selected,
                              "last_run": (r.get("last_run") or {}).get("at")})
    chosen = [i for i in items if i["selected"]]
    from . import rule_evidence
    rec = rule_evidence.recording(up) or {}
    rows = rec.get("rows") or {}
    body = ["**Admin %s, need review.** Choose what to look for in the recording **%s**%s. Every item you tick runs on it." % (
        _admin(ctx.project), rec.get("name") or ctx.project.get("name") or "of this analysis",
        " (%s NVMe commands)" % "{:,}".format(rows["nvme_command"]) if rows.get("nvme_command") is not None else ""), ""]
    for sec, label in family3.SECTIONS.items():
        rows = [i for i in chosen if i["section"] == sec]
        body += ["**%s** (%d chosen of %d)" % (label, len(rows), sum(1 for i in items if i["section"] == sec)), ""]
        if rows:
            body += ["| item | level | rules | what happens |", "|---|---|---|---|"]
            body += ["| %s | %s | %s | %s |" % (i["name"], i["level_label"], ("version %d, approved" % i["version"]) if i["status"] == "approved" else "draft",
                                               "proceeds with the current rules" if i["status"] == "approved" else "the Rule writer drafts it and asks you first")
                     for i in rows]
        body.append("")
    body += ["Tick or untick items in the list below, add a new item if you need one, then approve.",
             "Every item of a section that finds defects (%s) goes on to stage 1 (isolation of one defect) and stage 2 (the test case)." % ", ".join(
                 family3.SECTION_INFO[x]["label"] for x in family3.SECTIONS if family3.goes_to_stages(x))]
    return core.Result({"upload_id": up, "proposed": [i["key"] for i in chosen]},
                       review={"title": "What to look for in this recording", "body": "\n".join(body),
                               "data": {"items": items, "sections": dict(family3.SECTIONS), "levels": family3.LEVEL_LABEL, "upload_id": up, "recording": rec}})


def _plan_steps(engine, data, admin):
    edits = data.get("edits") or {}
    family3.sync_sections()
    sel = edits.get("selected")
    if sel is None:
        sel = [i["key"] for i in data.get("items") or [] if i.get("selected")]
    sel = list(dict.fromkeys(sel))
    messages = dict(edits.get("edit") or {})
    for n in edits.get("new") or []:
        sec, lvl, name = n.get("section"), n.get("level"), (n.get("name") or "").strip()
        if not name:
            continue
        if sec not in family3.SECTIONS or lvl not in family3.LEVELS:
            raise ValueError("a new item needs a section and one of the five levels")
        r = family3.add_item(sec, lvl, name, n.get("description") or "", admin)
        k = item_key(sec, lvl, r["id"])
        sel.append(k)
        messages[k] = (n.get("description") or name).strip()
    if not sel:
        raise ValueError("choose at least one item (or add one)")
    gone = {item_key(x["section"], x["level"], x["id"]) for x in family3.deleted_items()}
    sel = [k for k in sel if k not in gone]           # deleted while the plan waited: not run
    if not sel:
        raise ValueError("every chosen item was deleted: choose at least one item (or add one)")
    order = {s: i for i, s in enumerate(family3.SECTIONS)}
    plan = []
    for k in sorted(sel, key=lambda x: order.get(x.split("/")[0], 9)):
        sec, lvl, rid, _ = split_item(k)
        r = family3.load_rule(sec, lvl, rid)
        if r is None:
            raise ValueError("no such item: %s" % k)
        # the Rule writer drafts the procedure only when the item has none, or the admin asked for a change in words
        write = family3.procedures_of(r) is None or k in messages
        plan += item_steps(sec, lvl, rid, r["name"], write, messages.get(k) or r.get("description") or r["name"])
    if any(family3.goes_to_stages(k.split("/")[0]) for k in sel):
        plan.append(dict(ERRORS_DONE))     # (owner, 2026-11-11) after every pattern ran: the errors, then the report
    return plan, sel


# ---- Family 3: the result of one item
def _result(ic):
    if ic.input.get("superseded"):
        return core.Result({}, skip="the admin asked to change the rule: a new round follows")
    res = family3._result(ic)
    r = family3._rule(ic)
    body = res.review["body"].replace("Approve to accept the result. To change what is computed, edit the rule (the code follows the rule).", "")
    if family3.goes_to_stages(r["section"]):
        n = (ic.output_of("run") or {}).get("rows") or 0
        page = ic.engine.store.one("SELECT id FROM step WHERE run=? AND key=?", (ic.run["id"], ic.prefix + "errors"))
        if page:
            res.review["data"]["errors_page"] = True
        body += ("\n\nApprove to accept it%s. **Change**: say what to change in the rule; the Rule writer drafts a new version for you, "
                 "and the code runs again." % ((" and open its errors: each error goes through stage 1 and stage 2 on its own page" if page else
                                                " and take the error you pick below to stage 1 and stage 2") if n else
                                               " (the rule found no error in this data, so stage 1 and stage 2 have nothing to isolate)"))
    else:
        body += "\n\nApprove to accept it. **Change**: say what to change in the rule; the Rule writer drafts a new version for you, and the code runs again."
    res.review["body"] = body
    return res


# ---- stage 1 and stage 2
def _defect(ic):
    """The defect the admin chose. Nothing is chosen for the admin (owner, 2026-11-11: "you are showing the defect number by default.
    Who gave you that ... Don't do that"): no choice, no stage 1."""
    res = ic.output_of("run")
    if error_of(ic.item) is not None:
        return res.get("upload_id"), error_of(ic.item)          # an error's own steps: the error is in the step's name
    fid = ic.input.get("defect")
    return res.get("upload_id"), (None if fid in (None, "", "none") else int(fid))


def defect_choices(res):
    """[[finding id, "where · what"], ...] for the defects a rule found, in the words of the result table (no defect number)."""
    head = res.get("head") or []
    plain = family3.plain_defects(res.get("columns"), head) or {"rows": []}
    return [[x[0], "%s · %s" % (p[1], p[0])] for x, p in zip(head, plain["rows"])]


def defect_words(res, fid):
    return next((w for i, w in defect_choices(res) if str(i) == str(fid)), "the defect the rule filed in this recording")


def _isolate(ic):
    """Stage 1, the isolation of the defect (owner, 2026-11-11): the window of 15 NVMe commands above the error's command and 15 below,
    with every lower level, goes to the model; the error found by the admin's pattern is written at the end of the prompt; the model
    answers what, why, when, where, who, which and how, and proposes a standard name and the cause in one line. The admin confirms the
    name. Nothing is judged here: the procedural graph comes after the isolation (stage 2)."""
    up, fid = _defect(ic)
    if fid is None:
        if not (ic.output_of("run").get("head") or []):
            return core.Result({}, skip="the rule found no defect in this data: stage 1 and stage 2 need one")
        return core.Result({}, skip="you chose no defect to take to stage 1" if ic.input.get("defect") == "none" else
                           "no defect was chosen on the result card: stage 1 and stage 2 take only the defect you choose")
    if (family3._rule(ic).get("kind") or "detection_rule") != "detection_rule":
        # stage 1 isolates a defect the detector filed (a finding id); a rule that only lists rows gives row numbers
        return core.Result({}, skip="this rule lists rows, not defects the detector filed: stage 1 needs a detector rule "
                                    "(edit the rule to name one of the detector's rules)")
    hint = "; ".join(c for c in ic.input.get("comments") or [] if c and not c.startswith(LOOK_AGAIN))     # "look again: n above, m below" is a window, not a hint
    ic.progress("stage 1: the isolation of the defect from the window (15 commands above, 15 below, every level under them)")
    r = call_app(ic.engine, "POST", "/api/isolate/%s/%d/isolate" % (up, int(fid)),
                 {"n": ic.input.get("n"), "m": ic.input.get("m"), "remember": bool(ic.input.get("window_set")), "history": True,
                  "levels": LOWER, "hint": hint, "anyway": True, "name": _admin(ic.project), "standin": _standin(ic.engine), "isolation": True})
    iso = r.get("isolation") or {}
    rule = family3._rule(ic)
    words = defect_words(ic.output_of("run"), fid)
    labels = iso.get("labels") or {}
    body = ["**Admin %s, need review.** Stage 1, the isolation of the defect you chose: **%s**, found by the rule *%s*." % (_admin(ic.project), words, rule["name"]), ""]
    if hint:
        body += ["**Your hint for this round:** " + hint, ""]
    body += _window_lines(r.get("window") or {})
    body += ["**The isolation** (the model read the window first and the error last, as you set it; %s):" % (
        "answered by the model" if not str(iso.get("producer") or "").startswith("stand-in") else "no model answered: built from the rule's own facts"), "",
        "| | |", "|---|---|"]
    body += ["| **%s** | %s |" % (labels.get(k, k), (iso.get(k) or "").replace("|", "/")) for k in ("what", "why", "when", "where", "who", "which", "how")]
    body += ["", "**Proposed standard name:** %s" % (iso.get("standard_name") or "none"),
             "", "**Proposed cause (one line):** %s: %s" % (iso.get("cause_side") or "other", iso.get("cause_header") or "not named"), ""]
    if iso.get("cited_rows"):
        body += ["**The rows it rests on:** " + ", ".join("%s row %s" % (c.get("level"), c.get("rowid")) for c in iso["cited_rows"][:30]), ""]
    probs = list(iso.get("problems") or [])
    body += ["**Checks by the code:** " + ("every cited row is in the window; every question is answered" if not probs else "; ".join(probs)), "",
             "Choose the defect's standard name below (an existing one when it is the same defect, or a new one), then approve. "
             "**Nothing is judged here:** stage 2 then shows what the procedural graph already holds for this defect, its causes and their solutions."]
    out = {"upload_id": up, "finding": int(fid), "sequence": r.get("sequence") or [], "reason": r.get("reason"), "scenario_name": iso.get("standard_name") or r.get("scenario_name"),
           "isolation": iso, "checks": r.get("checks"), "rounds": len(r.get("rounds") or []), "cited": len(iso.get("cited_rows") or []),
           "expected_outcome": r.get("expected_outcome"), "observed_outcome": r.get("observed_outcome"), "window": r.get("window"),
           "rule": iso.get("rule"), "rule_name": rule.get("name"), "level": iso.get("level")}
    known = iso.get("known") or []
    return core.Result(out, producer=iso.get("producer") or r.get("producer"),
                       review={"title": "Stage 1 · isolation of the defect: " + words.split(" · ")[0], "body": "\n".join(body),
                               "data": {"isolation": iso, "upload_id": up, "finding": int(fid), "proposed_name": iso.get("standard_name") or "",
                                        "known_defects": [{"id": d["id"], "name": d["name"], "seen": d["seen"], "causes": d["causes"]} for d in known[:100]],
                                        "defects": [] if error_of(ic.item) is not None else defect_choices(ic.output_of("run"))[:200], "chosen_by_admin": True,
                                        "window": {k: (r.get("window") or {}).get(k) for k in ("n", "m", "source", "counts")}}})


def _errors(ic):
    """The errors a pattern found, for the errors page (owner, 2026-11-11: each error is taken through stage 1 and stage 2 on its own page,
    then back to the list; page 3 shows only where each stands)."""
    res = ic.output_of("run")
    head = res.get("head") or []
    if not head:
        return core.Result({"errors": []}, skip="the pattern found no error in this recording")
    r = family3._rule(ic)
    plain = family3.plain_defects(res.get("columns"), head) or {"rows": [[x[3], "row %s" % x[5], "", ""] for x in head]}
    errors = [{"finding": x[0], "what": p_[0], "where": p_[1], "when": p_[2], "serious": p_[3], "level": x[1],
               "row": (x[8] if len(x) > 8 and x[8] is not None else x[5])} for x, p_ in zip(head, plain["rows"])]
    return core.Result({"errors": errors, "item": base_item(ic.item), "upload_id": res.get("upload_id"), "total": res.get("rows") or len(head), "pattern": r["name"]},
                       producer="the code")


def _errors_done(ctx):
    """The gate before the report: the admin works through the errors on the errors page and says when it is done."""
    v = ctx.engine.view(ctx.run["id"])
    lists = [s_ for s_ in v["steps"] if s_["key"].endswith(":errors") and (s_.get("output") or {}).get("errors")]
    n = sum(len(s_["output"]["errors"]) for s_ in lists)
    body = ["**Admin %s, the errors.** %d pattern%s found %d error%s in this recording. Each error is taken through **stage 1** (the isolation of the defect), "
            "**stage 2** (the procedural graph: its cause and its solution) and its **test case** on its own page: open the errors page." % (
                _admin(ctx.project), len(lists), "" if len(lists) == 1 else "s", n, "" if n == 1 else "s"), "",
            "Page 3 shows where each error stands. Press **Done: write the report** when you have finished the ones you want; the report says which are done."]
    return core.Result({"patterns": len(lists), "errors": n}, review={"title": "The errors: stage 1 and stage 2 on the errors page", "body": "\n".join(body),
                                                                      "data": {"errors_overview": True}})


def _graph_view_lines(view):
    """What the procedural graph holds for a defect, in words (the card draws it as an outline you can open)."""
    if not view or not view.get("causes"):
        return ["**First finding of this defect in the procedural graph:** nothing is stored for it yet.", ""]
    cs = view["causes"]
    nsol = sum(len(c["solutions"]) for c in cs)
    return ["**Already in the procedural graph for this defect:** %d cause%s, %d solution%s; seen %d time%s (first %s, last %s) on %s." % (
        len(cs), "" if len(cs) == 1 else "s", nsol, "" if nsol == 1 else "s", view.get("seen", 0), "" if view.get("seen") == 1 else "s",
        view.get("first_seen") or "-", view.get("last_seen") or "-", ", ".join(view.get("devices") or []) or "no device named"), "",
        "Open a cause below to see its solutions: the error sequence (it becomes the test), the optimized sequence (it solves the problem), "
        "their versions, test files and your earlier judgements. " + (view.get("order") or ""), ""]


def _cause(ic):
    """Stage 2, the procedural graph: is this defect stored, with which causes? The admin names the cause of this occurrence."""
    iso = ic.output_of("isolate")
    did = ic.input.get("defect_id")
    if not iso.get("isolation") or did is None:
        return core.Result({}, skip="no isolated defect with a confirmed name (stage 1 was skipped or made before 2026-11-11)")
    view = call_app(ic.engine, "GET", "/api/dg/defects/%d" % int(did))
    i = iso["isolation"]
    body = ["**Admin %s, need review.** Stage 2, the procedural graph. The defect: **%s**%s." % (
        _admin(ic.project), view["name"], " (new: stored just now under the name you confirmed)" if not view.get("causes") and not view.get("seen") else ""), ""]
    body += _graph_view_lines(view)
    body += ["**The isolation proposes this cause:** %s: %s" % (i.get("cause_side") or "other", i.get("cause_header") or "not named"), "",
             "Choose the cause of this occurrence below: one of the stored causes, or a new one (its side and its one line). Nothing is chosen for you. "
             "Approving stores this occurrence under that cause (one count for it, with this device and firmware); then the cause's solutions follow."]
    return core.Result({"defect_id": int(did), "defect_name": view["name"], "causes": len(view.get("causes") or [])}, producer="the procedural graph",
                       review={"title": "Stage 2 · procedural graph: " + view["name"], "body": "\n".join(body),
                               "data": {"graph": view, "proposed_cause": {"side": i.get("cause_side") or "other", "header": i.get("cause_header") or ""},
                                        "sides": SIDES}})


def _solution(ic):
    """Stage 2, the solution of the cause: the stored ones ranked by the admin's judgements (the signals change only this ranking), or,
    for a cause with none, the first one: the error sequence from this recording and the optimized sequence (the model proposes it, the
    admin edits it)."""
    iso = ic.output_of("isolate")
    cid, did = ic.input.get("cause_id"), ic.input.get("defect_id")
    if cid is None or did is None:
        return core.Result({}, skip="no cause was named (stage 2 was skipped)")
    view = call_app(ic.engine, "GET", "/api/dg/defects/%d" % int(did))
    cause = next((c for c in view.get("causes") or [] if c["id"] == int(cid)), None)
    if cause is None:
        raise RuntimeError("the cause %s is not under the defect %s" % (cid, did))
    own = iso.get("sequence") or []
    did_lines = ic.input.get("did") or []
    body = ["**Admin %s, need review.** Stage 2, the solution. Defect **%s** · cause **%s** (%s), %s." % (
        _admin(ic.project), view["name"], cause["header"], cause["side_words"], cause["chosen_words"]), ""]
    if did_lines:
        body += ["**What your last signal did:** " + "; ".join(did_lines) + ".", ""]
    data = {"cause": {k: cause[k] for k in ("id", "side", "side_words", "header", "chosen_words")}, "defect": {"id": view["id"], "name": view["name"]},
            "sequence": own, "upload_id": iso.get("upload_id"), "finding": iso.get("finding")}
    if cause["solutions"]:
        body += ["**Stored solutions for this cause, best judged first** (%d). Open one to see its error sequence, its optimized sequence, its versions, "
                 "test file and earlier judgements. Choose the one you judge and give your signal: it changes only how the solutions are ranked "
                 "the next time this defect and cause come back. Or store this recording's sequence as a new solution." % len(cause["solutions"]), ""]
        data.update(solutions=cause["solutions"], judge=True)
    else:
        ic.progress("stage 2: the model proposes the optimized sequence for this cause")
        prop = call_app(ic.engine, "POST", "/api/dg/optimized", {"upload_id": iso.get("upload_id"), "finding_id": iso.get("finding"), "isolation": iso.get("isolation"),
                                                                   "cause": {"side": cause["side"], "header": cause["header"]}, "error_seq": own,
                                                                   "standin": _standin(ic.engine)})
        body += ["**First solution for this cause.** It is stored as you leave it below:", "",
                 "- **the error sequence**: the commands of this recording that recreate the error (untick a step it does not need; the error's own step stays). It becomes the test case.",
                 "- **the optimized sequence**: the solution to the problem for this cause. %s Edit it; one action per line." % (
                     "The model proposed it (%s): %s" % (prop.get("producer"), prop.get("note")) if not prop.get("standin") else prop.get("note")), ""]
        data.update(first=True, optimized=prop.get("lines") or [], optimized_note=prop.get("note"), optimized_by=prop.get("producer"))
    return core.Result({"cause_id": int(cid), "defect_id": int(did), "solutions": len(cause["solutions"])}, producer="the procedural graph",
                       review={"title": "Stage 2 · the solution for: " + cause["header"], "body": "\n".join(body), "data": data})


LOOK_AGAIN = "look again:"
LEVEL_WORDS = {"nvme_transaction": "NVMe transactions", "split": "split transactions", "link": "link transactions", "packets": "packets"}


def _window_lines(w):
    """The isolation window in words: the numbers and where they come from, what it holds per level, and the commands from earlier in
    the recording that the failing command depends on (with their reasons)."""
    if not w:
        return []
    c = w.get("counts") or {}
    out = ["**The window:** %d command%s above the defect and %d below (%s). It holds %s command%s%s." % (
        w.get("n", 0), "" if w.get("n") == 1 else "s", w.get("m", 0), w.get("source") or "", "{:,}".format(c.get("commands", 0)), "" if c.get("commands") == 1 else "s",
        "".join(", %s %s under them" % ("{:,}".format(c[lv]), LEVEL_WORDS[lv]) for lv in LEVEL_WORDS if c.get(lv))), ""]
    h = w.get("history") or {}
    rows = h.get("rows") or []
    if rows:
        out += ["**From earlier in the recording** (%d command%s the failing command depends on, found by shared blocks, features and queues, not by time):" % (len(rows), "" if len(rows) == 1 else "s"), "",
                "| row | command | why it is kept |", "|---|---|---|"]
        out += ["| %s | %s | %s |" % (x.get("n") or x.get("rowid"), (x.get("summary") or "").replace("|", "/")[:120], "; ".join(x.get("why") or []).replace("|", "/")[:300]) for x in rows[:40]]
        out.append("")
    elif h.get("note"):
        out += ["**From earlier in the recording:** %s." % h["note"], ""]
    else:
        out += ["**From earlier in the recording:** nothing the failing command depends on was found before the window.", ""]
    if h.get("uncovered"):
        out += ["Blocks of the failing command's range with no earlier write in the recording (their content at the time is unknown; the test writes a known pattern there): %s." % (
            "; ".join("namespace %s blocks %s to %s" % (u["nsid"], u["first"], u["last"]) for u in h["uncovered"][:6])), ""]
    if h.get("cutoff"):
        out += ["The latest %s (row %s) is where the data history starts: blocks written before it cannot matter." % (h["cutoff"]["command"], h["cutoff"]["rowid"]), ""]
    return out


def _graph_lines(r, choice, fresh, rejected, change, came_from=lambda st: ""):
    """What the procedural graph says about this failure, for the admin's review. Every weight is shown as the judgements behind it
    ("not yet judged", "judged correct 3 of 4 times"), never as a bare number (owner, 2026-11-10: "do not start with a default value of 67")."""
    paths = (r.get("graph") or {}).get("paths") or []
    out = []
    if change:
        out += ["**Your last signal changed the graph:** " + "; ".join(change) + ".", ""]
    if choice and choice.get("from_family"):
        out += ["**Procedural graph: known from %s.** The graph proposes that failure's procedure version %s (%s). Regression test: %s. A signal here stores it for this failure too." % (
            choice["from_family"], choice["version"], choice["weight_text"], os.path.basename(choice["test_path"]) if choice.get("test_path") else "none yet"), ""]
    elif choice:
        out += ["**Procedural graph: this failure is known.** The graph chose stored procedure version %s (%s; %s). "
                "This recording's own new proposal has %d steps and is used only if you reject the stored ones." % (
                    choice["version"], choice["weight_text"], choice["ordered_by"], len(fresh)), ""]
    elif paths:
        out += ["**Procedural graph: this failure is known, but no stored procedure is left to try** (%s). This is a new proposal from this recording." % (
            "you rejected the best-weighted ones" if rejected else "each one is judged wrong more often than right"), ""]
    else:
        out += ["**Procedural graph: first time for this failure.** Nothing is stored for it yet; this is a new proposal from this recording.", ""]
    if paths:
        out += ["| procedure | where it came from | your judgements | regression test on file |", "|---|---|---|---|"]
        for p in paths:
            out.append("| version %s%s | %s | %s | %s |" % (
                p["version"], " (chosen)" if choice and p["procedure_id"] == choice["procedure_id"] else "", (came_from(p.get("stored")) or "").replace("|", "/"),
                p["weight_text"], ("%s (%s)" % (os.path.basename(p["test_path"]), p.get("test_state"))) if p.get("test_path") else "not yet"))
        out.append("")
    return out


def _outcomes(ic):
    iso = ic.output_of("isolate")
    seq = ic.input.get("sequence") or iso.get("sequence")
    up, fid = iso.get("upload_id"), iso.get("finding")
    if not seq or fid is None:
        return core.Result({}, skip="no isolated sequence (stage 1 was skipped)")
    ic.progress("stage 2: the expected outcomes from the defect onward")
    r = call_app(ic.engine, "POST", "/api/isolate/%s/%d/testcase" % (up, int(fid)), {"sequence": seq, "name": _admin(ic.project), "standin": _standin(ic.engine)})
    outs = r.get("expected_outcomes") or []
    lim = r.get("limit") or {}
    change = ic.input.get("graph_change")
    body = ([("**Your signal changed the graph:** " + "; ".join(change) + "."), ""] if change else []) + [
            "**Admin %s, need review.** Stage 2: what a correct drive must answer, from the defect (step %s) onward. "
            "Check every line; approving means you verified them, and the test file is written from them." % (_admin(ic.project), r.get("fault_step")), "",
            "| step | command | expected status | time limit | the check | basis |", "|---|---|---|---|---|---|"]
    body += ["| %s | %s | %s | %s | %s | %s |" % (o["step"], o["command"], o.get("status"), o.get("timing_text"), (o.get("check") or "").replace("|", "/"),
                                                 (o.get("basis") or "").replace("|", "/")[:160]) for o in outs]
    body += ["", "Time limit used: %s (%s)." % (lim.get("text"), lim.get("source"))]
    return core.Result({"outcomes": outs, "sequence": r.get("sequence"), "fault_step": r.get("fault_step"), "upload_id": up, "finding": fid,
                        "procedure_id": ic.input.get("procedure_id"), "signal": ic.input.get("signal")},
                       producer=r.get("producer"),
                       review={"title": "Stage 2: expected outcomes of defect %s" % fid, "body": "\n".join(body),
                               "data": {"outcomes": outs, "fault_step": r.get("fault_step")}})


def _testcase(ic):
    """Stage 2's test file (owner, 2026-11-10): the model writes the plan from the multi-level window of the defect, the code checks it (every
    step against the recording, the plan's checks, the four runs on the simulated drive), renders it beside the fixed replay library, and the
    admin approves it. Compiled and run once here, where there is no drive: it must skip cleanly."""
    oc = ic.output_of("outcomes")
    outs = ic.input.get("outcomes")
    if not outs:
        return core.Result({}, skip="no verified outcomes (stage 2 was skipped)")
    iso = ic.output_of("isolate")
    hint = "; ".join(c for c in ic.input.get("comments") or [] if c)
    ic.progress("the model writes the test plan from the window; the code checks it and runs it on the simulated drive")
    body = {"sequence": oc["sequence"], "expected_outcomes": outs, "verified": True, "procedure_id": oc.get("procedure_id"),
            "scenario_name": iso.get("scenario_name"), "name": ic.input.get("verified_by") or _admin(ic.project), "author": "model", "hint": hint}
    if _standin(ic.engine):
        body["standin"] = True
    for k in ("deallocate_range", "known_rate"):
        if ic.input.get(k):
            body[k] = ic.input[k]
    r = call_app(ic.engine, "POST", "/api/isolate/%s/%d/testcase" % (oc["upload_id"], int(oc["finding"])), body)
    path = r["path"]
    py_compile.compile(path, doraise=True)
    check = {"compiled": True}
    # run once here, where the drive is absent: a correct test file skips cleanly (it never fails or errors without a drive)
    env = {k: v for k, v in os.environ.items() if not k.startswith("NVME_")}
    env["NVME_DEV"] = "/dev/nvme-flow-check-absent"
    env["PYTHONUTF8"] = "1"                  # the test and what it prints are UTF-8 on every system (Windows would use cp1252)
    p = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", path], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180, cwd=os.path.dirname(path), env=env)
    last = [x for x in (p.stdout or "").strip().splitlines() if x.strip()]
    if "No module named pytest" in (p.stderr or ""):
        check["pytest"] = "pytest is not installed for %s: the file was only compiled" % sys.executable
    else:
        check.update({"pytest_exit": p.returncode, "pytest": last[-1] if last else (p.stderr or "")[-200:]})
        if p.returncode not in (0, 5) or not last or "error" in last[-1].lower() or "failed" in last[-1].lower():
            detail = [x for x in last if x.startswith("E ") or "Error" in x][:12]
            raise RuntimeError("the generated test file %s does not run cleanly without the drive: %s\n%s" % (
                path, last[-1] if last else (p.stderr or "")[-300:], "\n".join(detail)))
    out = {"path": path, "name": r.get("name"), "version": r.get("version"), "steps": len(r.get("steps") or []), **check,
           "two_sided": r.get("two_sided"), "model": r.get("model"), "plan_checks": r.get("checks"), "library": r.get("library")}
    plan = r.get("plan") or {}
    return core.Result(out, producer=(r.get("model") or {}).get("producer"),
                       review={"title": "Stage 2: the test file for defect %s" % oc["finding"], "body": "\n".join(_testfile_lines(r, plan, check)),
                               "data": {"testfile": {"path": path, "name": r.get("name"), "version": r.get("version"), "text": r.get("text") or "",
                                                     "two_sided": r.get("two_sided"), "model": r.get("model"), "checks": r.get("checks"),
                                                     "deallocate_range": plan.get("deallocate_range"), "known_rate": (plan.get("repeat") or {}).get("known"),
                                                     "oracle": plan.get("oracle_fault"), "library": r.get("library")}}})


def _testfile_lines(r, plan, check):
    m = r.get("model") or {}
    two = r.get("two_sided") or {}
    lines = ["**Admin, need review.** The test file `%s` (version %s) for this defect." % (r.get("name"), r.get("version")), ""]
    if m.get("used") == "model":
        lines += ["**Written by the model** (%s) from the window of %s commands (%s above, %s below, and the earlier commands the defect depends on), with every lower level under them. "
                  "Every parameter is copied from the recording by the code; the model only chose the rows and said why." % (
                      m.get("producer"), (m.get("window") or {}).get("commands"), (m.get("window") or {}).get("n"), (m.get("window") or {}).get("m")), "",
                  "**The model's analysis:** " + (m.get("analysis") or ""), ""]
        if m.get("setup_note"):
            lines += ["**The drive's state before the replay (the model):** " + m["setup_note"], ""]
        for n in m.get("notes") or []:
            lines.append("- " + n)
        if m.get("notes"):
            lines.append("")
        if len(m.get("rounds") or []) > 1:
            lines += ["The model needed %d tries: %s." % (len(m["rounds"]), "; ".join("try %d: %s" % (x["round"], "; ".join(x.get("problems") or []) or "passed") for x in m["rounds"])), ""]
    else:
        lines += ["**Written by the code from stage 1's sequence:** %s" % (m.get("analysis") or "no model was asked."), ""]
    o = plan.get("oracle_fault") or {}
    lines += ["**What shows the defect again:** %s." % o.get("words", ""), ""]
    lines += ["**The code's checks:** every step matches its own row of the recording; the plan's checks passed; compiled; run here without a drive: %s." % (check.get("pytest") or "compiled only"), ""]
    if two.get("runs"):
        lines += ["**On the simulated drive** (the test's mechanics only, never the real drive): %s" % ("passed" if two.get("ok") else "FAILED"), "",
                  "| simulated drive | EXPECT | wanted | got |", "|---|---|---|---|"] + ["| %s | %s | %s | %s |" % (x["drive"], x["expect"], x["wanted"], x["got"]) for x in two["runs"]] + [""]
    elif two.get("words"):
        lines += ["**On the simulated drive:** %s" % two["words"], ""]
    if plan.get("deallocate_range"):
        d = plan["deallocate_range"]
        lines += ["**Deallocate check:** blocks %s to %s with %s guard blocks on each side (%s)." % (d["slba"], d["slba"] + d["blocks"] - 1, d.get("guard"), d.get("why") or ""), ""]
    known = (plan.get("repeat") or {}).get("known")
    lines += ["**Runs:** %s" % ("EXPECT=fixed needs the clean runs the old firmware's rate requires: it reproduced %s of %s times." % (known["k"], known["n"]) if known else
                                 "the old firmware's reproduction rate is not measured yet."), "",
              "Approving makes this file the regression test of this kind of defect (it is recorded with your name and the file's fingerprint). "
              "**Write it again** sends your comment to the model as a hint."]
    return lines


def _graph_of(engine, iso):
    """The defect's part of the procedural graph as it stands now (for the report)."""
    if iso.get("finding") is None:
        return None
    try:
        g = call_app(engine, "GET", "/api/isolate/%s/%d/graph" % (iso["upload_id"], int(iso["finding"]))).get("graph") or {}
    except RuntimeError:
        return None
    return {"nodes": [{k: n[k] for k in ("kind", "label", "weight_text", "n", "status")} for n in g.get("nodes") or []],
            "edges": [{k: e[k] for k in ("kind", "from", "to", "weight_text", "n", "status")} for e in g.get("edges") or []]}


def _summary(ic):
    iso, oc = ic.output_of("isolate"), ic.output_of("outcomes")
    if iso.get("finding") is None:
        return core.Result({}, skip="no isolated defect")
    tc = ic.engine.store.one("SELECT input FROM step WHERE run=? AND key=?", (ic.run["id"], ic.prefix + "testcase")) or {}
    verified = (core.jload(tc.get("input"), {}) or {}).get("outcomes") or oc.get("outcomes") or []
    fault = next((o for o in verified if o.get("step") == oc.get("fault_step")), None)
    expected = {"status": (fault or {}).get("status"), "description": (iso.get("expected_outcome") or {}).get("description"),
                "check": (fault or {}).get("check")} if fault else iso.get("expected_outcome")
    r = call_app(ic.engine, "POST", "/api/isolate/%s/%d/summary" % (iso["upload_id"], int(iso["finding"])),
                 {"reason": iso.get("reason"), "sequence": oc.get("sequence") or iso.get("sequence"), "expected_outcome": expected,
                  "name": _admin(ic.project), "standin": _standin(ic.engine)})
    return core.Result({"lines": r.get("lines"), "text": r.get("text")}, producer=r.get("producer"))


# ---------------------------------------------------------------------------------------------- the admin's decisions
def on_reject(engine, run, step, data, admin):
    """A rejected review. A data dictionary of Family 1 takes back what its run kept for later runs (family1.on_reject,
    when Family 1 has one); every other review has nothing to take back. Returns what Family 1 returns, else 0."""
    fn = getattr(family1, "on_reject", None)
    if fn and step.get("family") == "1" and step["key"] not in ("f1_last", admin_ask.GATE):
        return fn(engine, run, step, data, admin)
    return 0


def on_approve(engine, run, step, data, admin):
    key = step["key"]
    edits = data.get("edits") or {}
    if key == admin_ask.GATE:
        return admin_ask.before_stage_2(engine, run, step, admin)      # "go to stage 2": refused while an analyzer file of the folder is unread
    if step.get("family") == "1" and key != "f1_last":
        return family1.on_approve(engine, run, step, data, admin)      # a data dictionary is stored
    if step.get("family") == "2":
        return family2.on_approve(engine, run, step, data, admin)      # a strategy is stored, or the one used last time reused
    if key == "f1_last":
        reuse = set(data.get("reuse") or [])
        for name in reuse:
            for k in ("explore", "ground", "manager"):
                engine.store.exec("UPDATE step SET state='skipped', note=? WHERE run=? AND key=?",
                                  ("the dictionary approved before was reused (approved again by %s)" % admin, run["id"], "%s:%s" % (k, name)))
        return
    if key == "f3_plan":
        plan, sel = _plan_steps(engine, data, admin)
        engine.insert_steps(run["id"], step["idx"], plan)
        engine.store.exec("UPDATE step SET output=? WHERE id=?", (json.dumps(dict(core.jload(step["output"], {}) or {}, chosen=sel, steps_added=len(plan))), step["id"]))
        return
    if key.startswith("f3:"):
        item, sub = parse_key(key)
        sec, lvl, rid, _rnd = split_item(item)
        prefix = "f3:%s:" % item
        if sub in ("write", "code"):
            run2 = dict(run, params=json.dumps({"_kind": "rule_draft" if sub == "write" else "rule_code", "section": sec, "level": lvl, "id": rid}))
            family3.on_approve(engine, run2, dict(step, key=sub), data, admin)
        elif sub == "result":
            out = core.jload(step["output"], {}) or {}
            run_out = core.jload((engine.store.one("SELECT output FROM step WHERE run=? AND key=?", (run["id"], prefix + "run")) or {}).get("output"), {}) or {}
            r = family3.load_rule(sec, lvl, rid)
            if r is not None:
                r["last_run"] = {"run": run["id"], "at": time.time(), "upload_id": run_out.get("upload_id"), "rows": out.get("rows")}
                family3.save_rule(r)
            if family3.goes_to_stages(sec) and not engine.store.one("SELECT id FROM step WHERE run=? AND key=?", (run["id"], prefix + "errors")):
                head = run_out.get("head") or []
                ids = [x[0] for x in head]
                chosen = edits.get("defect") if isinstance(edits, dict) else None
                if ids and chosen in (None, ""):
                    # nothing is chosen for the admin (owner, 2026-11-11)
                    raise ValueError("choose the defect to take to stage 1 and stage 2, or choose “none”: no defect is chosen for you")
                if chosen == "none":
                    engine.set_input(run["id"], prefix + "isolate", defect="none")
                elif chosen not in (None, ""):
                    try:
                        chosen = int(chosen)
                    except (TypeError, ValueError, OverflowError):
                        raise ValueError("the defect must be one of the list")
                    if chosen not in ids:
                        raise ValueError("that defect is not one of the defects this rule found")
                    engine.set_input(run["id"], prefix + "isolate", defect=chosen)
        elif sub == "isolate":
            if (core.jload(step["output"], {}) or {}).get("isolation"):
                _approve_isolation(engine, run, step, edits, admin, prefix)
            else:                               # a stage 1 card made before 2026-11-11 (signals on the sequence)
                _apply_signal(engine, run, step, data, admin, edits.get("signal") or "correct", edits)
        elif sub == "cause":
            _approve_cause(engine, run, step, edits, admin, prefix)
        elif sub == "solution":
            _approve_solution(engine, run, step, edits, admin, prefix)
        elif sub == "outcomes":
            out = core.jload(step["output"], {}) or {}
            outs = [dict(o) for o in out.get("outcomes") or []]
            changed = edits.get("outcomes") or {}
            for o in outs:
                ch = changed.get(str(o["step"])) or changed.get(o["step"]) or {}
                for f in ("status", "check"):
                    if (ch.get(f) or "").strip():
                        o[f] = ch[f].strip()
                o["verified"] = True
            engine.set_input(run["id"], prefix + "testcase", outcomes=outs, verified_by=admin)
            # the test file is a decision too (owner, 2026-11-10: "verified by the admin"), also for runs whose steps were made before it was
            engine.store.exec("UPDATE step SET needs_review=1 WHERE run=? AND key=?", (run["id"], prefix + "testcase"))
        elif sub == "testcase":
            out = core.jload(step["output"], {}) or {}
            if out.get("path") and os.path.exists(out["path"]):
                with open(out["path"], "rb") as fh:
                    sha = hashlib.sha256(fh.read()).hexdigest()
                rec = {"approved_by": admin, "at": time.time(), "test": out.get("name"), "version": out.get("version"), "sha256": sha, "status": "approved",
                       "comment": (data.get("comment") or "").strip(), "two_sided": (out.get("two_sided") or {}).get("ok"), "written_by": (out.get("model") or {}).get("used")}
                family1.L.write_json_atomic(out["path"] + ".approved.json", rec, indent=1)
                rev = (core.jload((engine.store.one("SELECT input FROM step WHERE run=? AND key=?", (run["id"], prefix + "outcomes")) or {}).get("input"), {}) or {}).get("dg_revision")
                if rev:                          # the approved test belongs to that version of the solution in the procedural graph
                    call_app(engine, "POST", "/api/dg/revisions/%d/test" % int(rev), {"path": out["path"], "admin": admin})


def _ensure_graph_steps(engine, run, step, prefix):
    """A run made before 2026-11-11 has no stage 2 graph steps: they are added right after stage 1."""
    have = engine.store.one("SELECT id FROM step WHERE run=? AND key=?", (run["id"], prefix + "cause"))
    if have:
        return
    item = prefix[3:-1]
    sec, lvl, rid, rnd = split_item(item)
    r = family3.load_rule(sec, lvl, rid) or {"name": rid}
    tag = "%s%s · " % (r["name"], "" if rnd <= 1 else " (round %d)" % rnd)
    engine.insert_steps(run["id"], step["idx"], graph_steps(lambda x: prefix + x, tag))


def _approve_isolation(engine, run, step, edits, admin, prefix):
    """The admin confirms the isolation and the defect's standard name: an existing defect of the graph, or a new one stored now."""
    out = core.jload(step["output"], {}) or {}
    iso = out.get("isolation") or {}
    choice = edits.get("defect_name")
    if choice in (None, ""):
        raise ValueError("choose the defect's standard name: one already stored, or a new name (nothing is chosen for you)")
    if str(choice) == "new":
        name = " ".join(str(edits.get("name") or "").split())
        if not name:
            raise ValueError("write the new standard name of the defect")
        r = call_app(engine, "POST", "/api/dg/defects", {"name": name, "rule": iso.get("rule"), "level": iso.get("level"), "what": iso.get("what"), "admin": admin})
        did = r["id"]
    else:
        try:
            did = int(choice)
        except (TypeError, ValueError, OverflowError):
            raise ValueError("the defect must be one of the list, or a new name")
        call_app(engine, "GET", "/api/dg/defects/%d" % did)        # it must exist
    _ensure_graph_steps(engine, run, step, prefix)
    engine.set_input(run["id"], prefix + "cause", defect_id=did)
    engine.set_input(run["id"], prefix + "solution", defect_id=did)


def _approve_cause(engine, run, step, edits, admin, prefix):
    """The admin names the cause of this occurrence: a stored one, or a new one (side and one line). The occurrence is stored under it."""
    out = core.jload(step["output"], {}) or {}
    did = out.get("defect_id")
    iso = core.jload((engine.store.one("SELECT output FROM step WHERE run=? AND key=?", (run["id"], prefix + "isolate")) or {}).get("output"), {}) or {}
    choice = edits.get("cause")
    if choice in (None, ""):
        raise ValueError("choose the cause of this occurrence: one already stored, or a new one (nothing is chosen for you)")
    if str(choice) == "new":
        side, header = str(edits.get("side") or "").strip(), " ".join(str(edits.get("header") or "").split())
        if side not in SIDES:
            raise ValueError("choose the side of the new cause")
        if not header:
            raise ValueError("write the new cause in one line")
        cid = call_app(engine, "POST", "/api/dg/causes", {"defect_id": did, "side": side, "header": header, "admin": admin})["id"]
    else:
        try:
            cid = int(choice)
        except (TypeError, ValueError, OverflowError):
            raise ValueError("the cause must be one of the list, or a new one")
        view = call_app(engine, "GET", "/api/dg/defects/%d" % int(did))
        if cid not in [c["id"] for c in view.get("causes") or []]:
            raise ValueError("that cause is not one of this defect's causes")
    i = iso.get("isolation") or {}
    oid = call_app(engine, "POST", "/api/dg/occurrences", {"defect_id": did, "cause_id": cid, "upload_id": iso.get("upload_id"), "finding_id": iso.get("finding"),
                                                            "device": i.get("device"), "firmware": i.get("firmware"), "isolation": {k: i.get(k) for k in (
                                                                "what", "why", "when", "where", "who", "which", "how", "standard_name", "cited_rows")},
                                                            "admin": admin})["id"]
    engine.set_input(run["id"], prefix + "solution", defect_id=did, cause_id=cid, occurrence_id=oid, did=[])


def _edited(seq, drop):
    drop = {int(x) for x in drop or []}
    kept = [dict(s_) for s_ in seq if s_.get("step") not in drop or s_.get("position") == "fault"]
    for i, s_ in enumerate(kept):
        s_["step"] = i + 1
    return kept


def _approve_solution(engine, run, step, edits, admin, prefix):
    """Store the first solution of a cause, store this recording's sequence as a new one, or judge a stored one with a signal. The error
    sequence then goes to stage 3, where the test file is written from it."""
    sinp = core.jload(step["input"], {}) or {}
    out = core.jload(step["output"], {}) or {}
    iso = core.jload((engine.store.one("SELECT output FROM step WHERE run=? AND key=?", (run["id"], prefix + "isolate")) or {}).get("output"), {}) or {}
    own = iso.get("sequence") or []
    i = iso.get("isolation") or {}
    choice = edits.get("solution")
    optimized = edits.get("optimized")
    if choice in (None, ""):
        raise ValueError("choose the stored solution you judge, or store this recording's sequence as a new solution (nothing is chosen for you)")
    if str(choice) == "new":
        seq = _edited(own, edits.get("drop"))
        lines = [x for x in str(optimized or "").splitlines() if x.strip()]
        if not lines:
            raise ValueError("write the optimized sequence (the solution), one action per line")
        r = call_app(engine, "POST", "/api/dg/solutions", {"cause_id": out.get("cause_id"), "error_seq": seq, "optimized": lines, "admin": admin,
                                                            "producer": "model, edited by %s" % admin, "upload_id": iso.get("upload_id"), "finding_id": iso.get("finding")})
        sid, rid, test_seq = r["id"], r["revision_id"], seq
    else:
        sig = edits.get("signal")
        if sig not in SIGNAL_WORDS:
            raise ValueError("give one of the four signals for the solution you chose")
        try:
            sid = int(choice)
        except (TypeError, ValueError, OverflowError):
            raise ValueError("the solution must be one of the list")
        view = call_app(engine, "GET", "/api/dg/defects/%d" % int(out.get("defect_id")))
        sol = next((x for c in view.get("causes") or [] for x in c["solutions"] if x["id"] == sid and c["id"] == out.get("cause_id")), None)
        if sol is None:
            raise ValueError("that solution is not one of this cause's solutions")
        body = {"signal": sig, "admin": admin, "occurrence_id": sinp.get("occurrence_id"), "device": i.get("device"), "firmware": i.get("firmware")}
        if sig.endswith("_with_edits"):
            body["error_seq"] = _edited(sol["error_seq"], edits.get("drop"))
            if optimized is not None:
                body["optimized"] = [x for x in str(optimized).splitlines() if x.strip()]
        r = call_app(engine, "POST", "/api/dg/solutions/%d/verdict" % sid, body)
        sol = r.get("solution") or sol
        if r.get("new_solution_id"):
            sid = r["new_solution_id"]
        rid = r.get("new_revision_id") or sol.get("revision_id")
        test_seq = body.get("error_seq") or sol["error_seq"]
        if (sol.get("origin_upload") and sol["origin_upload"] != iso.get("upload_id")) and not body.get("error_seq"):
            test_seq = own              # a solution stored from another recording: the test is written from this recording's rows of the same error
        engine.set_input(run["id"], step["key"], did=r.get("did") or [])
    engine.set_input(run["id"], prefix + "outcomes", sequence=test_seq, dg_solution=sid, dg_revision=rid)


def _apply_signal(engine, run, step, data, admin, sig, edits):
    if sig not in SIGNAL_WORDS:
        raise ValueError("the signal must be one of: %s" % ", ".join(SIGNAL_WORDS))
    if (core.jload(step["input"], {}) or {}).get("defect") in (None, "", "none"):
        # a stage 1 made on a defect nobody chose (the first one in the list, before 2026-11-11) gives no signal and stores nothing
        raise ValueError("this defect was not chosen by you: choose the defect on this card and press Look again; no signal is stored until then")
    item, _sub = parse_key(step["key"])
    prefix = "f3:%s:" % item
    out = core.jload(step["output"], {}) or {}
    seq = out.get("sequence") or []
    drop = {int(x) for x in (edits.get("drop") or [])}
    edited = [dict(s) for s in seq if s.get("step") not in drop or s.get("position") == "fault"]
    for i, s in enumerate(edited):
        s["step"] = i + 1
    advice = (data.get("comment") or "").strip()
    advice = "" if advice == "the proposal was judged wrong" else advice            # the page's default words are not advice
    if sig.endswith("_with_edits") and len(edited) == len(seq):
        if not advice:
            raise ValueError("untick at least one step or write your advice (or choose the signal without edits)")
        sig = sig[:-len("_with_edits")]          # advice without changed steps: the signal, and the advice stays on the graph
    body = {"advice": advice, "signal": sig, "proposal_steps": seq, "proposal_text": out.get("reason") or "", "scenario_name": out.get("scenario_name"),
            "reason": out.get("reason") or "", "name": admin}
    chosen = out.get("from_procedure")              # the signal is about the stored procedure the graph proposed: its weights change
    if chosen:
        body["procedure_id"] = chosen
    if sig.endswith("_with_edits"):
        body.update(edited_steps=edited, edited_text=out.get("reason") or "")
    r = call_app(engine, "POST", "/api/isolate/%s/%d/signal" % (out["upload_id"], int(out["finding"])), body)
    change = r.get("graph_change") or []
    if sig == "wrong":
        inp = core.jload(step["input"], {}) or {}
        engine.set_input(run["id"], step["key"], graph_change=change,
                         rejected_procedures=(inp.get("rejected_procedures") or []) + ([chosen] if chosen else []))
        return
    res = r.get("result") or {}
    final = edited if sig.endswith("_with_edits") else seq
    engine.set_input(run["id"], prefix + "outcomes", sequence=final, signal=sig, graph_change=change,
                     procedure_id=res.get("new_procedure_id") or res.get("procedure_id"))


def on_change(engine, run, step, data, admin, comment):
    key = step["key"]
    if key == admin_ask.GATE:
        if (data.get("edits") or {}).get("read_new"):
            admin_ask.read_new(engine, run, step, admin)               # the new CSVs of the folder get their three agents; then this step asks again
        return
    if not key.startswith("f3:"):
        return
    item, sub = parse_key(key)
    edits = data.get("edits") or {}
    if sub == "isolate" and edits.get("defect") not in (None, ""):
        # the admin chooses (or changes) the defect on the stage 1 card; the weights of the old one are not touched
        run_out = core.jload((engine.store.one("SELECT output FROM step WHERE run=? AND key=?", (run["id"], "f3:%s:run" % item)) or {}).get("output"), {}) or {}
        ids = [x[0] for x in run_out.get("head") or []]
        try:
            fid = int(edits["defect"])
        except (TypeError, ValueError, OverflowError):
            raise ValueError("the defect must be one of the list")
        if fid not in ids:
            raise ValueError("that defect is not one of the defects this rule found")
        inp = core.jload(step["input"], {}) or {}
        if fid != inp.get("defect"):
            engine.set_input(run["id"], key, defect=fid, rejected_procedures=[], graph_change=None)
    elif sub == "isolate" and error_of(item) is None and core.jload(step["input"], {}).get("defect") in (None, "", "none"):
        raise ValueError("choose the defect first: no defect is chosen for you")
    if sub == "solution" and edits.get("signal") == "wrong":
        out = core.jload(step["output"], {}) or {}
        try:
            sid = int(edits.get("solution"))
        except (TypeError, ValueError, OverflowError):
            raise ValueError("choose the stored solution you judge wrong")
        iso = core.jload((engine.store.one("SELECT output FROM step WHERE run=? AND key=?", (run["id"], "f3:%s:isolate" % item)) or {}).get("output"), {}) or {}
        i = iso.get("isolation") or {}
        view = call_app(engine, "GET", "/api/dg/defects/%d" % int(out.get("defect_id")))
        if sid not in [x["id"] for c in view.get("causes") or [] if c["id"] == out.get("cause_id") for x in c["solutions"]]:
            raise ValueError("that solution is not one of this cause's solutions")
        r = call_app(engine, "POST", "/api/dg/solutions/%d/verdict" % sid, {"signal": "wrong", "admin": admin, "device": i.get("device"), "firmware": i.get("firmware"),
                                                                             "occurrence_id": (core.jload(step["input"], {}) or {}).get("occurrence_id")})
        engine.set_input(run["id"], key, did=r.get("did") or [])
        return
    if sub == "isolate" and isinstance(edits.get("window"), dict):
        # "Look again with these numbers": the same defect with the admin's n above and m below; no signal, the graph is not touched
        win = edits["window"]
        try:
            n, m = int(win.get("n")), int(win.get("m"))
        except (TypeError, ValueError, OverflowError):
            raise ValueError("the numbers above and below must be whole numbers")
        if not (0 <= n <= 100 and 0 <= m <= 100):
            raise ValueError("commands above and below: from 0 to 100 each")
        engine.set_input(run["id"], key, n=n, m=m, window_set=True)
        return
    if sub == "testcase":
        # "write it again": the comment goes to the model as a hint; a deallocate range or a measured rate given on the card goes into the plan
        keep = {}
        if isinstance(edits.get("deallocate_range"), dict):
            keep["deallocate_range"] = edits["deallocate_range"]
        if isinstance(edits.get("known_rate"), dict):
            keep["known_rate"] = edits["known_rate"]
        if keep:
            engine.set_input(run["id"], key, **keep)
        return
    if sub == "isolate" and edits.get("signal") == "wrong":
        _apply_signal(engine, run, step, data, admin, "wrong", edits)
    elif sub == "result":
        # a change of the rule: a new round of the item (the Rule writer with the admin's words, then the code again)
        sec, lvl, rid, rnd = split_item(item)
        r = family3.load_rule(sec, lvl, rid)
        last = engine.store.one("SELECT MAX(idx) AS i FROM step WHERE run=? AND key LIKE ?", (run["id"], "f3:%s:%%" % item))["i"]
        engine.insert_steps(run["id"], last, item_steps(sec, lvl, rid, r["name"], True, comment or "", rnd + 1))
        engine.set_input(run["id"], key, superseded=True)
        for k in ("errors", "isolate", "cause", "solution", "outcomes", "testcase", "summary"):
            engine.store.exec("UPDATE step SET state='skipped', note=? WHERE run=? AND key=? AND state='waiting'",
                              ("the rule is being changed: see round %d" % (rnd + 1), run["id"], "f3:%s:%s" % (item, k)))


def on_finish(engine, rid):
    v = engine.view(rid)
    rep = next((s for s in v["steps"] if s["key"] == "report"), None)
    files = ((rep or {}).get("output") or {}).get("files") or {}
    engine.store.exec("UPDATE run SET summary=? WHERE id=?", ("flow finished: Family 1 -> 2 -> 3; report %s" % (files.get("html") or "not written"), rid))


# ---------------------------------------------------------------------------------------------- the report
def _report(ctx):
    v = ctx.engine.view(ctx.run["id"])
    p = ctx.project
    steps_ = v["steps"]
    files = family1.inventory(p.get("folder"))
    dicts = []
    for f in files:
        if not f["level"]:
            continue
        d = family1.approved_dictionary(f["format_key"], f["name"]) or {}
        cols = d.get("columns") or []
        dicts.append({"file": f["name"], "level": f["level_label"], "rows_estimate": d.get("rows_estimate"), "version": d.get("version"),
                      "approved_by": d.get("approved_by"), "columns": len(cols), "status": dict(Counter(c.get("status") for c in cols))})
    fmt, _ = family2.project_format(p)
    st = family2.last_strategy(fmt) or {}
    out = {s["key"]: s.get("output") or {} for s in steps_}
    slice_, breaker, indep = out.get("slice_test", {}), out.get("breaker", {}), out.get("independent", {})
    items = {}
    for s in steps_:
        if not s["key"].startswith("f3:"):
            continue
        item, sub = parse_key(s["key"])
        it = items.setdefault(item, {"item": item, "steps": {}})
        it["steps"][sub] = {"state": s["state"], "output": s.get("output") or {}, "producer": s.get("producer"), "note": s.get("note")}
    reviews = {r["step"]: r for r in v["reviews"]}
    fam = Counter((s.get("family"), s["state"]) for s in steps_)
    rep = {"run": ctx.run["id"], "made": time.time(), "admin": _admin(p), "project": {k: p.get(k) for k in ("name", "folder", "upload_id")},
           "files": [{k: f[k] for k in ("name", "level_label", "bytes", "columns")} for f in files],
           "family1": dicts, "family2": {"format": fmt, "strategy_version": st.get("version"), "strategy_approved_by": st.get("approved_by"),
                                          "upload_id": p.get("upload_id"), "random_windows": [slice_.get("passed"), slice_.get("of")],
                                          "hard_windows": [breaker.get("passed"), breaker.get("of")], "invariants": indep.get("invariants")},
           "family3": [], "steps": [{"title": s["title"], "family": s.get("family"), "state": s["state"], "producer": s.get("producer"),
                                     "decided_by": (reviews.get(s["id"]) or {}).get("decided_by"),
                                     "seconds": round((s.get("finished") or 0) - (s.get("started") or 0), 1) if s.get("started") and s.get("finished") else None}
                                    for s in steps_ if s["key"] != "report"],
           "state_counts": {"%s %s" % (FAMILY_LABEL.get(k[0], k[0]), k[1]): n for k, n in fam.items()}}
    for item, it in items.items():
        sec, lvl, rid, rnd = split_item(item)
        r = family3.load_rule(sec, lvl, rid) or {}
        S = it["steps"]
        o = lambda k: (S.get(k) or {}).get("output") or {}     # noqa: E731
        rep["family3"].append({"item": item, "name": r.get("name"), "section": family3.SECTIONS.get(sec), "level": family3.LEVEL_LABEL.get(lvl), "round": rnd,
                               "rule_version": o("code").get("procedure_version") or o("code").get("version") or ("built-in detector" if o("code").get("kind") == "detector" else None), "rows": o("run").get("rows"), "tester_passed": o("test").get("passed"),
                               "checks": o("test").get("checks"), "exports": o("export").get("files"),
                               "defect": o("isolate").get("finding"), "reason": o("isolate").get("reason"), "scenario_name": o("isolate").get("scenario_name"),
                               "signal": (S.get("outcomes") or {}).get("output", {}).get("signal"), "test_file": o("testcase").get("path"),
                               "test_run": o("testcase").get("pytest"), "summary": o("summary").get("lines"),
                               "from_version": o("isolate").get("from_version"), "known_failure": o("isolate").get("known_failure"),
                               "graph": _graph_of(ctx.engine, o("isolate")),
                               "error": error_of(item), "defect_name": o("cause").get("defect_name"),
                               "states": {k: x["state"] for k, x in S.items()}})
    # where each error ended (owner, 2026-11-11: stage 1 done, stage 2 done, test files created), from the procedural graph
    rep["errors"] = []
    for s_ in steps_:
        o_ = s_.get("output") or {}
        if not (s_["key"].endswith(":errors") and o_.get("errors")):
            continue
        try:
            st_ = call_app(ctx.engine, "GET", "/api/dg/status?upload=%s&findings=%s" % (o_.get("upload_id"), ",".join(str(x["finding"]) for x in o_["errors"]))).get("status") or {}
        except RuntimeError:
            st_ = {}
        for x in o_["errors"]:
            y = st_.get(str(x["finding"])) or {}
            rep["errors"].append({"pattern": o_.get("pattern"), "where": x["where"], "what": x["what"], "state": y.get("state") or "new",
                                  "status": y.get("words") or "not isolated yet", "test_file": y.get("test_path")})
    d = os.path.join(family1.knowledge_dir(), "exports", "flow", "run_%d" % ctx.run["id"])
    os.makedirs(d, exist_ok=True)
    jp, hp = os.path.join(d, "flow_report.json"), os.path.join(d, "flow_report.html")
    family1.L.write_json_atomic(jp, rep, indent=1, default=str)
    family1.L.write_text_atomic(hp, _report_html(rep))
    return core.Result({"files": {"html": hp, "json": jp}, "items": len(rep["family3"]),
                        "dictionaries": sum(1 for x in dicts if x["version"]), "strategy_version": st.get("version")})


def _report_html(rep):
    e = lambda x: html.escape("" if x is None else str(x))     # noqa: E731

    def table(head, rows):
        return "<table><tr>%s</tr>%s</table>" % ("".join("<th>%s</th>" % e(h) for h in head),
                                                 "".join("<tr>%s</tr>" % "".join("<td>%s</td>" % c for c in r) for r in rows))
    f2 = rep["family2"]
    parts = ["<h1>The flow, run %s</h1>" % e(rep["run"]),
             "<p>Project <b>%s</b> · admin %s · input folder <code>%s</code> · tree: upload %s · made %s</p>" % (
                 e(rep["project"]["name"]), e(rep["admin"]), e(rep["project"]["folder"]), e(rep["project"]["upload_id"]),
                 e(time.strftime("%Y-%m-%d %H:%M", time.localtime(rep["made"])))),
             "<h2>Family 1 · Data experts: one approved data dictionary per file</h2>",
             table(["file", "level", "about how many rows", "dictionary version", "approved by", "columns", "meanings by status"],
                   [[e(x["file"]), e(x["level"]), e("{:,}".format(x["rows_estimate"]) if x["rows_estimate"] else ""), e(x["version"] or "not approved"),
                     e(x["approved_by"]), e(x["columns"]), e(", ".join("%s: %s" % kv for kv in x["status"].items()))] for x in rep["family1"]]),
             "<h2>Family 2 · Hierarchy: the strategy, the tree and its tests</h2>",
             "<p>Strategy version %s (approved by %s) for this file format (%s). Tree: upload %s.</p>" % (
                 e(f2["strategy_version"]), e(f2["strategy_approved_by"]), e(f2["format"]), e(f2["upload_id"])),
             "<p>Code tester: %s of %s random windows rebuilt alone matched the full tree and the analyzer's counts. Breaker: %s of %s hard windows.</p>" % (
                 e(f2["random_windows"][0]), e(f2["random_windows"][1]), e(f2["hard_windows"][0]), e(f2["hard_windows"][1])),
             table(["independent check (column meanings only)", "rows checked", "violations"],
                   [[e(i.get("check")), e("{:,}".format(i.get("rows_checked") or 0)), e(i.get("violations", i.get("error")))] for i in f2["invariants"] or []]),
             "<h2>Family 3 · Rules: every item used on this data</h2>"]
    for it in rep["family3"]:
        checks = "".join("<li>%s %s: %s</li>" % ("✔" if c.get("ok") else "✘", e(c.get("check")), e(c.get("detail"))) for c in it.get("checks") or [])
        ex = " ".join('<a href="/api/agents/file?path=%s">%s</a>' % (html.escape(p, quote=True), e(k.upper())) for k, p in (it.get("exports") or {}).items())
        parts.append("<h3>%s <small>(%s · %s%s)</small></h3>" % (e(it["name"]), e(it["section"]), e(it["level"]), "" if it["round"] <= 1 else " · round %d" % it["round"]))
        parts.append("<p>Rule version %s · %s rows · tester: %s · exports: %s</p><ul>%s</ul>" % (
            e(it["rule_version"]), e(it["rows"]), "all checks passed" if it["tester_passed"] else "NOT all checks passed" if it["tester_passed"] is False else "-", ex or "-", checks))
        if it.get("defect") is not None:
            parts.append("<p><b>Stage 1</b>, defect %s: %s<br>Scenario: %s<br>Signal: %s</p>" % (
                e(it["defect"]), e(it.get("reason")), e(it.get("scenario_name")), e(SIGNAL_WORDS.get(it.get("signal"), it.get("signal")))))
            parts.append("<p><b>Stage 2</b>: test file <code>%s</code> (run here without the drive: %s)</p>" % (e(it.get("test_file")), e(it.get("test_run"))))
            g = it.get("graph") or {}
            if g.get("edges"):
                link = {"CAUSED_BY": "is caused by", "REPRODUCED_BY": "is reproduced by", "TESTED_BY": "is tested by", "SUPERSEDES": "replaces", "LESSON_ABOUT": "is a lesson about"}
                parts.append("<p><b>Procedural graph</b> of this failure: %s. Weights after the admin's signals:</p>" % (
                    "known before this flow, procedure version %s came from the graph" % e(it["from_version"]) if it.get("from_version") else
                    "known before this flow, a new proposal was used" if it.get("known_failure") else "first time"))
                parts.append(table(["from", "link", "to", "weight", "signals", "state"],
                                   [[e(x["from"]), e(link.get(x["kind"], x["kind"])), e(x["to"]), e(x["weight_text"]), e(x["n"]), e(x["status"])] for x in g["edges"]]))
            if it.get("summary"):
                parts.append("<p><b>Summary</b><br>%s</p>" % "<br>".join(e(x) for x in it["summary"]))
        parts.append("<p class=s>steps: %s</p>" % e(", ".join("%s %s" % kv for kv in it["states"].items())))
    if rep.get("errors"):
        done = sum(1 for x in rep["errors"] if x["state"] == "tested")
        parts += ["<h2>The errors: stage 1, stage 2 and their tests</h2>",
                  "<p>%d error%s; %d isolated (stage 1); %d with a cause and a solution (stage 2); %d with an approved test.</p>" % (
                      len(rep["errors"]), "" if len(rep["errors"]) == 1 else "s", sum(1 for x in rep["errors"] if x["state"] != "new"),
                      sum(1 for x in rep["errors"] if x["state"] in ("solved", "tested")), done),
                  table(["pattern", "where", "what was found", "where it stands", "test file"],
                        [[e(x["pattern"]), e(x["where"]), e(x["what"]), e(x["status"]), e(os.path.basename(x["test_file"])) if x["test_file"] else ""] for x in rep["errors"]])]
    parts += ["<h2>Every step, in order</h2>",
              table(["family", "step", "state", "answered by", "decided by", "seconds"],
                    [[e(FAMILY_LABEL.get(s["family"], s["family"])), e(s["title"]), e(s["state"]), e(s["producer"]), e(s["decided_by"]), e(s["seconds"])] for s in rep["steps"]])]
    css = ("body{font-family:system-ui,sans-serif;margin:24px;max-width:1100px;color:#1d2128}table{border-collapse:collapse;margin:8px 0}"
           "td,th{border:1px solid #ccc;padding:3px 8px;font-size:13px;text-align:left;vertical-align:top}th{background:#f2f2f2}"
           "h2{margin-top:28px;border-bottom:1px solid #ddd}code{font-size:12px}.s{color:#666;font-size:12px}")
    return "<!doctype html><meta charset=utf-8><title>Flow report, run %s</title><style>%s</style>%s" % (e(rep["run"]), css, "\n".join(parts))
