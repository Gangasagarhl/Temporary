"""After Family 1 (owner, 2026-11-12): the admin's questions to all the Managers, the new files, and "go to stage 2".

What must hold:
  1. the flow has one step between Family 1 and Family 2, and it holds the flow until the admin says "go to stage 2";
  2. "is this kind of data present?" goes to the Manager of every file; the answer says YES only when a Manager named
     something that IS in the data, NO only when every file was read and every Manager said no, CANNOT TELL otherwise;
     the counts and lines in the answer are the dictionary's, never the model's;
  3. "read the new files" gives ONLY the CSV files added to the folder their three agents, before the question, and
     touches no file that was read; with nothing new, or with a second file of a kind, nothing changes;
  4. "go to stage 2" is refused while an analyzer file of the folder is unread.

No server and no model: an engine on its own store in a temporary folder; the Managers' answers are written here, the
way a model could answer (right, wrong, invented, or not at all)."""
import json
import os
import sys
import time
import types

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from agentic import admin_ask, core, family1, pipeline  # noqa: E402

LEVELS = {"packets": "packets", "nvme_command": "nvme_command", "link": "link"}      # a test file's level, from the start of its name
LABEL = {"packets": "packets", "nvme_command": "NVMe commands", "link": "link transactions"}


def _level(name):
    return next((lv for start, lv in LEVELS.items() if name.startswith(start)), None)


def _inventory(folder):
    out = []
    for fn in sorted(os.listdir(folder)):
        if fn.lower().endswith(".csv"):
            lv = _level(fn)
            out.append({"name": fn, "path": os.path.join(folder, fn), "bytes": os.path.getsize(os.path.join(folder, fn)), "level": lv,
                        "level_label": LABEL[lv] if lv else "not one of the five analyzer levels", "columns": 3, "format_key": "fk_" + (lv or "other")})
    return out


COMMANDS = [{"column": "Command", "rows_with_value": 100, "distinct": 3, "meaning": "the NVMe command the host sent",
             "keywords": [{"value": "Read", "count": 60, "rows": [1, 2, 3], "meaning": "the host reads blocks"},
                          {"value": "Write", "count": 38, "rows": [4, 5, 9], "meaning": "the host writes blocks"},
                          {"value": "Abort", "count": 2, "rows": [41, 77], "meaning": "the host gave up waiting for a command"}]},
            {"column": "Latency", "rows_with_value": 100, "distinct": 97, "meaning": "time from the command to its completion", "keywords": []}]
PACKETS = [{"column": "TLP Type", "rows_with_value": 500, "distinct": 2, "meaning": "the kind of transaction packet",
            "keywords": [{"value": "MWr", "count": 300, "rows": [1, 2, 8], "meaning": "memory write"}, {"value": "CplD", "count": 200, "rows": [3, 4, 5], "meaning": "completion with data"}]},
           {"column": "Speed", "rows_with_value": 500, "distinct": 2, "meaning": "the link speed", "keywords": []}]


class Flow:
    """A flow whose Family 1 has finished for the files of its folder; the step after it has opened its review."""

    def __init__(self, tmp_path, monkeypatch, files=None, reused=()):
        self.root = str(tmp_path)
        self.folder = os.path.join(self.root, "recording")
        os.makedirs(self.folder)
        self.know = os.path.join(self.root, "knowledge")
        monkeypatch.setattr(family1, "inventory", _inventory)
        monkeypatch.setattr(family1, "knowledge_dir", lambda: self.know)
        monkeypatch.setattr(core.Engine, "kick", lambda eng, rid: None)       # no background thread: steps are run here
        self.dicts = files if files is not None else {"nvme_command.csv": COMMANDS, "packets.csv": PACKETS}
        for name in self.dicts:
            self.put(name)
        self.store = core.Store(os.path.join(self.root, "db", "agentic.sqlite"))
        self.runner = core.AgentRunner(os.path.join(self.root, "runs"), runtime="http", web=False)
        self.eng = core.Engine(self.store, {"flow": pipeline}, self.runner)
        self.pid = self.store.exec("INSERT INTO project (name, folder, created) VALUES (?,?,?)", ("p", self.folder, time.time()))
        self.rid = self.eng.start(self.pid, "flow")
        for s in self.steps():
            if s["key"] == admin_ask.GATE:
                break
            name = s["key"].partition(":")[2]
            if s["key"].startswith("manager:") and name not in reused:
                self.store.exec("UPDATE step SET state='approved', output=? WHERE id=?", (json.dumps({"dictionary_file": self.write_dictionary(name)}), s["id"]))
            elif name in reused or s["key"] == "f1_last":
                self.store.exec("UPDATE step SET state='skipped' WHERE id=?", (s["id"],))
            else:
                self.store.exec("UPDATE step SET state='done', output=? WHERE id=?", (json.dumps({"files": _inventory(self.folder)} if s["key"] == "director" else {}), s["id"]))
        for name in reused:
            self.approve_before(name)
        self.asked = []
        self.open_gate()

    def put(self, name):
        with open(os.path.join(self.folder, name), "w", encoding="utf-8") as fh:
            fh.write("A,B,C\n1,2,3\n")

    def dictionary(self, name, made=1000.0):
        path = os.path.join(self.folder, name)
        mem = os.path.join(self.root, "memory_%s.json" % name)
        with open(mem, "w", encoding="utf-8") as fh:        # the Data Explorer's memory: the most frequent values of a column without keywords
            json.dump({"columns": [{"column": "Speed", "top_values": [{"value": "8.0 GT/s", "count": 450, "rows": [1, 2, 3]}, {"value": "2.5 GT/s", "count": 50, "rows": [7, 8]}]}]}, fh)
        cols = [dict(c, type="text", observed="text", status="grounded", where=family1.where(path, [1, 2, 3])) for c in self.dicts[name]]
        return {"file": name, "path": path, "made": made, "rows": 100, "columns": cols, "explorer_memory": mem}

    def write_dictionary(self, name):
        p = os.path.join(self.root, "dict_%s.json" % name)
        with open(p, "w", encoding="utf-8") as fh:
            json.dump(self.dictionary(name), fh)
        return p

    def approve_before(self, name, **changes):
        d = dict(self.dictionary(name), approved_by="Sagar", approved_at=1794000000.0, version=2, **changes)
        folder = os.path.join(self.know, "dictionaries", "fk_" + (_level(name) or "other"))
        os.makedirs(folder, exist_ok=True)
        with open(os.path.join(folder, os.path.splitext(name)[0] + ".current.json"), "w", encoding="utf-8") as fh:
            json.dump(d, fh)

    def steps(self):
        return self.store.all("SELECT * FROM step WHERE run=? ORDER BY idx", (self.rid,))

    def keys(self):
        return [s["key"] for s in self.steps()]

    def step(self, key=admin_ask.GATE):
        return self.store.one("SELECT * FROM step WHERE run=? AND key=?", (self.rid, key))

    def open_gate(self):
        self.eng._run_step(self.store.one("SELECT * FROM run WHERE id=?", (self.rid,)), self.step())
        self.review = self.store.one("SELECT * FROM review WHERE run=? AND state='open' ORDER BY id DESC", (self.rid,))
        assert self.review and self.step()["state"] == "needs_review", "the step after Family 1 did not ask the admin: %s" % (self.step().get("error"),)

    def next_step(self):
        return next((s["key"] for s in self.steps() if s["state"] not in ("done", "approved", "skipped")), None)

    def managers(self, answer):
        """The Managers answer as `answer(file, columns of this call) -> dict` says (or raise)."""
        def ask(run_id, agent, instruction, context, schema_text, must_have, standin, **more):
            c = json.loads(context)
            self.asked.append((c["file"], [x["column"] for x in c["columns"]], agent))
            a = answer(c["file"], c["columns"])
            return (standin(), "stand-in (no model connected)", "") if a == "standin" else (a, "claude-sonnet-5-5", "")
        self.runner.ask = ask

    def ask(self, question):
        text, who = admin_ask.ask_all(self.eng, self.review, self.step(), question, [])
        assert who == "Admin Agent"
        return text


@pytest.fixture
def flow(tmp_path, monkeypatch):
    return Flow(tmp_path, monkeypatch)


NO = {"present": "no", "matches": [], "could_not_check": ""}


# ---------------------------------------------------------------------------------------------- 1. the step holds the flow
def test_one_step_stands_between_family_1_and_family_2(flow):
    keys = flow.keys()
    g = keys.index(admin_ask.GATE)
    assert keys[g - 1].startswith("manager:") and keys[g + 1] == "last_strategy", keys
    assert keys.count(admin_ask.GATE) == 1 and flow.step()["family"] == "1" and flow.step()["needs_review"] == 1


def test_the_flow_stays_until_the_admin_says_go_to_stage_2(flow):
    assert flow.next_step() == admin_ask.GATE                       # Family 2 has not started
    assert all(s["state"] == "waiting" for s in flow.steps() if s["family"] == "2")
    body = flow.review["body"]
    assert "nvme_command.csv" in body and "packets.csv" in body and "Go to stage 2" in body and "Read the new files" in body
    flow.eng.decide(flow.review["id"], "approve", "Sagar")
    assert flow.step()["state"] == "approved" and flow.next_step() == "last_strategy"


def test_stop_at_this_step_stops_the_flow(flow):
    flow.eng.decide(flow.review["id"], "reject", "Sagar", "the recording is not the right one")
    assert flow.step()["state"] == "rejected"
    assert flow.store.one("SELECT state FROM run WHERE id=?", (flow.rid,))["state"] == "stopped"
    assert all(s["state"] == "waiting" for s in flow.steps() if s["family"] == "2")


# ---------------------------------------------------------------------------------------------- 2. yes, no, cannot tell
def test_yes_rests_on_a_name_that_is_in_the_data_and_on_the_dictionarys_counts(flow):
    # the Manager of the commands names a real keyword, and tries to give a count of its own
    flow.managers(lambda f, cols: {"present": "yes", "matches": [{"column": "command", "keyword": "ABORT", "rows": 98765}], "could_not_check": ""} if f == "nvme_command.csv" else NO)
    text = flow.ask("is there any command the host gave up on?")
    assert text.startswith("**Yes, present.**") and "nvme_command.csv" in text.split("\n")[0]
    row = next(l for l in text.split("\n") if "Command = Abort" in l)
    assert "2 rows" in row and "lines 42, 78" in row and "the host gave up waiting for a command" in row      # row n is line n + 1 of the file
    assert "98765" not in text and "98,765" not in text
    assert "| packets.csv | no | nothing |" in text
    assert sorted(a[0] for a in flow.asked) == ["nvme_command.csv", "packets.csv"]            # every Manager was asked
    assert len({a[2] for a in flow.asked}) == 2                                                  # each call in a folder of its own


def test_a_whole_column_and_a_value_the_explorer_kept_can_be_the_match(flow):
    flow.managers(lambda f, cols: {"present": "yes", "matches": [{"column": "Speed", "keyword": "2.5 GT/s"}, {"column": "TLP Type", "keyword": ""}]} if f == "packets.csv" else NO)
    text = flow.ask("did the link run at the lowest speed?")
    assert text.startswith("**Yes, present.**")
    assert any("Speed = 2.5 GT/s" in l and "50 rows" in l and "lines 8, 9" in l for l in text.split("\n"))
    assert any("TLP Type (the whole column)" in l and "500 rows" in l for l in text.split("\n"))


def test_a_name_that_is_not_in_the_data_is_dropped_and_never_makes_a_yes(flow):
    flow.managers(lambda f, cols: {"present": "yes", "matches": [{"column": "Completion Timeout", "keyword": ""}, {"column": "Command", "keyword": "Timeout"}]} if f == "nvme_command.csv" else NO)
    text = flow.ask("is there a completion timeout?")
    assert text.startswith("**Cannot tell.**"), text[:200]
    assert "Yes, present" not in text
    assert "2 names a Manager gave were not in its file and were dropped" in text
    assert "Completion Timeout (nvme_command.csv)" in text and "Command = Timeout (nvme_command.csv)" in text
    assert "its Manager said yes but named nothing that is in the file" in text
    assert "| nvme_command.csv | cannot tell | nothing |" in text


def test_no_needs_every_file_read_and_every_manager_saying_no(flow):
    flow.managers(lambda f, cols: NO)
    text = flow.ask("is there any thermal throttling event?")
    assert text.startswith("**No, not found.**") and "Read the new files" in text
    # a CSV put into the folder that no agent has read: the same answers are no longer a "no" for the folder
    flow.put("thermal_log.csv")
    text = flow.ask("is there any thermal throttling event?")
    assert text.startswith("**Cannot tell for the whole folder.**") and "thermal_log.csv" in text.split("\n")[0]
    assert "| thermal_log.csv | not asked | new in the folder: not read yet |" in text
    assert "No, not found" not in text


def test_a_manager_without_an_answer_is_cannot_tell_and_the_others_still_answer(flow):
    def answer(f, cols):
        if f == "packets.csv":
            raise RuntimeError("the model did not answer in 420 s")
        return NO
    flow.managers(answer)
    text = flow.ask("is there any thermal throttling event?")
    assert text.startswith("**Cannot tell.**") and "No, not found" not in text
    assert "packets.csv: its Manager gave no answer" in text and "| nvme_command.csv | no | nothing |" in text
    # ... and a yes of another Manager is still a yes
    flow.managers(lambda f, cols: (_ for _ in ()).throw(RuntimeError("no answer")) if f == "packets.csv" else {"present": "yes", "matches": [{"column": "Command", "keyword": "Read"}]})
    assert flow.ask("any read command?").startswith("**Yes, present.**")


def test_an_answer_of_the_wrong_shape_is_cannot_tell(flow):
    for bad in ({"present": "maybe"}, {"present": "yes", "matches": "Command"}, {"present": ["yes"]}, {}, {"present": "yes", "matches": [None, 7, {"column": None}]}):
        flow.managers(lambda f, cols, bad=bad: bad)
        text = flow.ask("is there any read?")
        assert text.startswith("**Cannot tell.**"), (bad, text[:120])


def test_a_free_sentence_with_a_number_in_it_is_not_shown(flow):
    flow.managers(lambda f, cols: {"present": "no", "matches": [], "could_not_check": "there are 4096 timeouts in the hidden rows" if f == "packets.csv" else "the exact latency values are not listed"})
    text = flow.ask("is there a latency above the limit?")
    assert "4096" not in text and "the exact latency values are not listed" in text
    # ... and the admin is told that a sentence was left out, and of which file
    assert "packets.csv: its Manager also gave a reason in a sentence with a number in it" in text
    assert "nvme_command.csv: its Manager also gave a reason" not in text
    # a number of the admin's own question is not a new number: that sentence stays; with one more number it does not
    flow.managers(lambda f, cols: {"present": "cannot_tell", "matches": [], "could_not_check": "the block addresses are not listed one by one, so 4096 cannot be looked up"
                                   if f == "nvme_command.csv" else "address 4096 (0x1000) is not among the listed values"})
    text = flow.ask("is there a write to block address 4096?")
    assert "nvme_command.csv, in its Manager's words: the block addresses are not listed one by one, so 4096 cannot be looked up" in text
    assert "0x1000" not in text and "packets.csv: its Manager also gave a reason in a sentence with a number in it" in text


def test_no_yes_and_not_every_no_names_who_says_no_and_who_cannot_rule_it_out(flow):
    flow.managers(lambda f, cols: NO if f == "nvme_command.csv" else {"present": "cannot_tell", "matches": [{"column": "Speed", "keyword": ""}], "could_not_check": "the values are not listed one by one"})
    head = flow.ask("is there any firmware update?").split("\n")[0]
    assert head.startswith("**Cannot tell.** No Manager found it. 1 of the 2 files that were asked says no (nvme_command.csv); 1 file cannot rule it out: packets.csv."), head
    flow.managers(lambda f, cols: {"present": "cannot_tell", "matches": []})
    head = flow.ask("is there any firmware update?").split("\n")[0]
    assert head.startswith("**Cannot tell.** No Manager found it. None of the 2 files that were asked says no; 2 files cannot rule it out: nvme_command.csv, packets.csv."), head


def test_without_a_model_only_the_questions_own_words_are_looked_up(flow):
    flow.managers(lambda f, cols: "standin")
    text = flow.ask("is there an Abort in the data?")
    assert text.startswith("**Yes, present.**") and "Command = Abort" in text and "No model is connected" in text
    text = flow.ask("did the drive overheat?")
    assert text.startswith("**Cannot tell.**") and "No, not found" not in text          # words that are not there prove nothing without a model


def test_a_large_dictionary_is_asked_in_parts_and_no_column_is_left_out(tmp_path, monkeypatch):
    many = [{"column": "Column %03d" % i, "rows_with_value": 10 + i, "distinct": 4, "meaning": "meaning %03d " % i + "x" * 200,
             "keywords": [{"value": "kw%03d_%d" % (i, k), "count": k + 1, "rows": [k + 1], "meaning": "m" * 60} for k in range(4)]} for i in range(260)]
    flow = Flow(tmp_path, monkeypatch, files={"nvme_command.csv": many})
    flow.managers(lambda f, cols: {"present": "yes", "matches": [{"column": "Column 259", "keyword": "kw259_3"}]} if any(c["column"] == "Column 259" for c in cols) else NO)
    text = flow.ask("is kw259_3 there?")
    seen = [c for a in flow.asked for c in a[1]]
    assert len(flow.asked) >= 2, "one call took a dictionary larger than a call may hold"
    assert sorted(seen) == sorted(c["column"] for c in many)                 # every column in exactly one call
    assert all(len(json.dumps([admin_ask._for_model(c) for c in admin_ask._index(flow.dictionary("nvme_command.csv")).values() if c["column"] in a[1]])) <= admin_ask.PART_CHARS + 2000 for a in flow.asked)
    assert text.startswith("**Yes, present.**") and "Column 259 = kw259_3" in text and "4 rows" in text
    assert "(%d calls)" % len(flow.asked) in text


def test_the_meaning_shown_is_the_one_the_admin_approved(tmp_path, monkeypatch):
    flow = Flow(tmp_path, monkeypatch)
    corrected = [dict(c) for c in COMMANDS]
    corrected[0] = dict(corrected[0], keywords=[dict(k, meaning="CORRECTED BY THE ADMIN") if k["value"] == "Abort" else k for k in corrected[0]["keywords"]])
    flow.dicts = {"nvme_command.csv": corrected, "packets.csv": PACKETS}
    flow.approve_before("nvme_command.csv")                                  # the approved copy of the same dictionary (same "made")
    flow.managers(lambda f, cols: {"present": "yes", "matches": [{"column": "Command", "keyword": "Abort"}]} if f == "nvme_command.csv" else NO)
    assert "CORRECTED BY THE ADMIN" in flow.ask("any abort?")


def test_a_dictionary_used_again_answers_and_the_answer_says_it_was_not_read_again(tmp_path, monkeypatch):
    flow = Flow(tmp_path, monkeypatch, reused=("packets.csv",))
    assert "approved before: used again, not read again" in flow.review["body"]
    flow.managers(lambda f, cols: {"present": "yes", "matches": [{"column": "TLP Type", "keyword": "MWr"}]} if f == "packets.csv" else NO)
    text = flow.ask("are there memory writes?")
    assert text.startswith("**Yes, present.**") and "TLP Type = MWr" in text
    assert "packets.csv was not read again in this flow" in text and "version 2" in text


# ---------------------------------------------------------------------------------------------- 3. read the new files
def test_read_the_new_files_gives_only_the_new_file_its_three_agents(flow):
    before = {s["id"]: (s["key"], s["state"], s["output"]) for s in flow.steps() if s["key"] not in (admin_ask.GATE, "director")}
    flow.put("link_events.csv")
    flow.eng.decide(flow.review["id"], "change", "Sagar", "new CSV files were added to the folder", {"read_new": True})
    keys = flow.keys()
    g = keys.index(admin_ask.GATE)
    assert keys[g - 3:g] == ["explore:link_events.csv", "ground:link_events.csv", "manager:link_events.csv"], keys
    assert keys[g + 1] == "last_strategy" and len(keys) == len(before) + 2 + 3
    after = {s["id"]: (s["key"], s["state"], s["output"]) for s in flow.steps()}
    assert all(after[i] == v for i, v in before.items()), "a step of a file that was read, or of a later family, was touched"
    assert [s["idx"] for s in flow.steps()] == list(range(len(keys)))                      # one order, no gap, no two steps on one place
    assert flow.step()["state"] == "waiting" and flow.next_step() == "explore:link_events.csv"
    new = flow.step("manager:link_events.csv")
    assert new["needs_review"] == 1 and json.loads(new["input"])["file"]["name"] == "link_events.csv" and "state" not in json.loads(new["input"])["file"]
    assert [f["name"] for f in json.loads(flow.step("director")["output"])["files"]] == ["link_events.csv", "nvme_command.csv", "packets.csv"]
    assert pipeline.ahead_chains(flow.steps()) == [[flow.step("explore:link_events.csv")["id"], flow.step("ground:link_events.csv")["id"]]]   # they may work ahead
    # the new file's agents finish; the question is asked again, now with three files
    for k in ("explore", "ground"):
        flow.store.exec("UPDATE step SET state='done' WHERE id=?", (flow.step(k + ":link_events.csv")["id"],))
    flow.dicts["link_events.csv"] = PACKETS
    flow.store.exec("UPDATE step SET state='approved', output=? WHERE id=?", (json.dumps({"dictionary_file": flow.write_dictionary("link_events.csv")}), new["id"]))
    assert flow.next_step() == admin_ask.GATE
    flow.open_gate()
    assert "3 of the 3 CSV files" in flow.review["body"] and "link_events.csv" in flow.review["body"]
    flow.managers(lambda f, cols: NO)
    assert flow.ask("anything?").startswith("**No, not found.**") and len({a[0] for a in flow.asked}) == 3
    # pressed again with nothing new: nothing is added
    with pytest.raises(ValueError, match="no new CSV file in the folder"):
        flow.eng.decide(flow.review["id"], "change", "Sagar", "again", {"read_new": True})
    assert flow.keys() == keys


def test_with_nothing_new_in_the_folder_nothing_changes_and_the_card_stays_open(flow):
    keys = flow.keys()
    with pytest.raises(ValueError, match="no new CSV file in the folder") as e:
        flow.eng.decide(flow.review["id"], "change", "Sagar", "new CSV files were added to the folder", {"read_new": True})
    assert "nvme_command.csv" in str(e.value) and flow.folder in str(e.value)
    assert flow.keys() == keys and flow.step()["state"] == "needs_review"
    assert flow.store.one("SELECT state FROM review WHERE id=?", (flow.review["id"],))["state"] == "open"


def test_a_second_file_of_a_kind_is_refused_and_nothing_is_read(flow):
    keys = flow.keys()
    flow.put("packets_second_recording.csv")
    with pytest.raises(ValueError, match="nothing was read.*more than one file of the same kind"):
        flow.eng.decide(flow.review["id"], "change", "Sagar", "new CSV files were added to the folder", {"read_new": True})
    assert flow.keys() == keys and flow.store.one("SELECT state FROM review WHERE id=?", (flow.review["id"],))["state"] == "open"


def test_a_change_without_read_the_new_files_adds_nothing(flow):
    keys = flow.keys()
    flow.put("link_events.csv")
    flow.eng.decide(flow.review["id"], "change", "Sagar", "show me the list again")
    assert flow.keys() == keys and flow.step()["state"] == "waiting"


# ---------------------------------------------------------------------------------------------- 4. go to stage 2
def test_go_to_stage_2_is_refused_while_an_analyzer_file_is_unread(flow):
    flow.put("link_events.csv")                                              # an analyzer level: Family 2 would join it
    with pytest.raises(ValueError, match="link_events.csv.*Press Read the new files first"):
        flow.eng.decide(flow.review["id"], "approve", "Sagar")
    assert flow.step()["state"] == "needs_review" and flow.next_step() == admin_ask.GATE
    assert flow.store.one("SELECT state FROM review WHERE id=?", (flow.review["id"],))["state"] == "open"
    os.remove(os.path.join(flow.folder, "link_events.csv"))
    flow.put("lab_notes.csv")                                                # not one of the five levels: no part of the tree
    flow.eng.decide(flow.review["id"], "approve", "Sagar")
    assert flow.step()["state"] == "approved" and flow.next_step() == "last_strategy"


# ---------------------------------------------------------------------------------------------- 5. the flow run again
def test_run_again_offers_the_dictionaries_approved_before_and_names_the_file_to_read(tmp_path, monkeypatch):
    flow = Flow(tmp_path, monkeypatch, files={"nvme_command.csv": COMMANDS, "lab_notes.csv": PACKETS, "packets.csv": PACKETS})
    for name in ("nvme_command.csv", "lab_notes.csv"):                      # also a file that is not of the five levels
        flow.approve_before(name)
    rid = flow.eng.start(flow.pid, "flow")
    run = flow.store.one("SELECT * FROM run WHERE id=?", (rid,))
    step = flow.store.one("SELECT * FROM step WHERE run=? AND key='f1_last'", (rid,))
    flow.eng._run_step(run, step)
    rv = flow.store.one("SELECT * FROM review WHERE run=? AND state='open'", (rid,))
    assert sorted(json.loads(rv["data"])["reuse"]) == ["lab_notes.csv", "nvme_command.csv"]
    assert "No dictionary was approved before for this file: packets.csv" in rv["body"]
    flow.eng.decide(rv["id"], "approve", "Sagar")
    states = {s["key"]: s["state"] for s in flow.store.all("SELECT key, state FROM step WHERE run=?", (rid,))}
    assert all(states["%s:%s" % (k, n)] == "skipped" for k in ("explore", "ground", "manager") for n in ("nvme_command.csv", "lab_notes.csv"))
    assert all(states["%s:packets.csv" % k] == "waiting" for k in ("explore", "ground", "manager"))        # only the file without one is read


# ---------------------------------------------------------------------------------------------- 6. the page's request
def test_the_question_and_the_answer_are_kept_with_the_step(flow, monkeypatch):
    from flask import Flask
    from api import agentic_api as A
    monkeypatch.setattr(A, "engine", lambda: flow.eng)
    app = Flask(__name__)
    app.config["services"] = types.SimpleNamespace(cfg={}, root=flow.root)
    app.register_blueprint(A.bp)
    flow.managers(lambda f, cols: {"present": "yes", "matches": [{"column": "Command", "keyword": "Abort"}]} if f == "nvme_command.csv" else NO)
    r = app.test_client().post("/api/agents/reviews/%d/ask" % flow.review["id"], json={"message": "any command the host gave up on?", "admin": "Sagar"})
    assert r.status_code == 200, r.get_data(as_text=True)[:300]
    j = r.get_json()
    assert j["producer"] == "Admin Agent" and j["answer"].startswith("**Yes, present.**")
    assert [(c["role"], c["text"][:16]) for c in j["chat"]] == [("admin:Sagar", "any command the "), ("Admin Agent", "**Yes, present.*")]
    assert flow.step()["state"] == "needs_review"                           # asking decides nothing
    view = flow.eng.view(flow.rid)
    assert [c["role"] for rv in view["reviews"] if rv["step"] == flow.step()["id"] for c in rv["chat"]] == ["admin:Sagar", "Admin Agent"]
