"""The NVMe command errors page (owner, 2026-11-12): every completion status an NVMe command can end with, from the two
public specifications, and how many commands of one loaded recording ended with each. No time limit lives here: those
come from the values the owner gives.

  GET /api/hier/nvme_command_errors            the catalogue (status code types, every entry, the documents)
  GET /api/hier/nvme_command_errors/<upload>   the same question asked of one loaded recording: commands per status
"""
import os
import sqlite3

from flask import Blueprint, jsonify

from . import svc
from . import hier_api as H
from nvme_hier import nvme_command_errors as NE

bp = Blueprint("nvme_errors", __name__)


@bp.get("/api/hier/nvme_command_errors")
def nvme_command_errors():
    return jsonify({"summary": NE.summary(), "types": NE.types(), "entries": NE.catalogue(),
                    "keys": {NE.key(e): i for i, e in enumerate(NE.catalogue()) if e["scope"] == "pcie"}})


@bp.get("/api/hier/nvme_command_errors/<uid>")
def nvme_command_errors_of(uid):
    s = svc()
    d = H.upload_dir(s, uid)
    if not d:
        return jsonify({"error": "no such upload: this recording is not among the loaded ones"}), 404
    db = H.db_of(d)
    meta = H.read_meta(d) or {}
    if not os.path.exists(db):
        return jsonify({"error": "this recording has not been loaded yet, so its NVMe commands cannot be counted"}), 409
    try:
        got = NE.count(db)
    except sqlite3.Error as e:
        return jsonify({"error": "the NVMe commands of this recording cannot be read (%s): load the recording again" % e}), 409
    got.update({"upload_id": uid, "trace_name": meta.get("trace_name"), "device": meta.get("device"),
                "recording_date": meta.get("recording_date"), "status": meta.get("status")})
    return jsonify(got)
