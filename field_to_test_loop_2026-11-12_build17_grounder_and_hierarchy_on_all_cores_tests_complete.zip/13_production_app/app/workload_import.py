"""Input kind "workload": a stage-1 artifact from an external workload tool - the boot_etl ADK pipeline's stage1.json
(Fast-Startup), or any JSON in the generic shape below (PCMark 10 or another runner needs a 20-line exporter) - is
imported as a run whose incidents are the artifact's abnormalities. The architecture's input box lists "PCIe traces,
Windows ADK, PCMark"; this is the path for the last two. Stage 2 then looks the signature up, lets the LLM write the
baseline scenario, and files it as a proposed test for the hardware bench (the synthetic bench cannot run a Windows
boot).

Generic shape (everything optional except abnormalities):
{"workload": "PCMark 10 Storage", "device": "...", "firmware": "...", "verdict": {"outcome": "FAIL", "measured": 1234, "limit": 1000, "unit": "ms"},
 "abnormalities": [{"id": "ABN-001", "title": "...", "statement": "...", "metric": "...", "observed": 1512, "baseline": 41, "spread": 3.2,
                    "delta": 1471, "robust_z": 37.1, "unit": "ms", "phase": "...", "component": "...", "symptom": "...", "confidence": 0.9,
                    "evidence": [{...}]}],
 "hypothesis": "...", "change_points": ["..."]}
"""
import json
import os
import time


def _num(x):
    try:
        return float(x)
    except (TypeError, ValueError, OverflowError):
        return None


def normalise(artifact):
    """boot_etl stage1.json or the generic shape -> (meta, list of abnormality dicts with uniform keys)."""
    a = artifact
    meta = {"workload": a.get("workload") or (a.get("run") or {}).get("assessment") or "workload",
            "run_id": (a.get("run") or {}).get("run_id") or a.get("run_id"), "device": a.get("device"), "firmware": a.get("firmware"),
            "verdict": a.get("verdict") or {}, "hypothesis": a.get("primary_hypothesis") or a.get("hypothesis"),
            "change_points": a.get("change_points") or [], "summary": a.get("summary"), "schema": a.get("schema_version")}
    out = []
    for ab in a.get("abnormalities") or []:
        obs, base, delta = ab.get("observed"), ab.get("baseline"), ab.get("delta")
        gk = ab.get("graph_keys") or {}
        comp = ab.get("component")
        out.append({"id": ab.get("id"), "title": ab.get("title") or ab.get("statement") or "abnormality",
                    "statement": ab.get("statement") or ab.get("title"),
                    "metric_id": (obs.get("metric_id") if isinstance(obs, dict) else ab.get("metric")) or gk.get("metric_family"),
                    "observed": (obs.get("value") if isinstance(obs, dict) else _num(obs)),
                    "unit": (obs.get("unit") if isinstance(obs, dict) else ab.get("unit")),
                    "baseline": (base.get("center") if isinstance(base, dict) else _num(base)),
                    "spread": (base.get("spread") if isinstance(base, dict) else ab.get("spread")),
                    "baseline_n": (base.get("n") if isinstance(base, dict) else ab.get("baseline_n")),
                    "delta": (delta.get("abs") if isinstance(delta, dict) else _num(delta)),
                    "robust_z": (delta.get("robust_z") if isinstance(delta, dict) else ab.get("robust_z")),
                    "impact": (delta.get("impact_ms") if isinstance(delta, dict) else ab.get("impact")),
                    "phase": ab.get("phase") or gk.get("phase"), "symptom": ab.get("symptom") or gk.get("symptom"),
                    "component": (comp.get("name") if isinstance(comp, dict) else comp), "component_class": gk.get("component_class") or ab.get("component_class") or ab.get("component_type"),
                    "severity": ab.get("severity"), "confidence": _num(ab.get("confidence")) if ab.get("confidence") is not None else None,
                    "evidence": ab.get("evidence") or [], "assessment": meta["workload"], "workload": meta["workload"],
                    "hypothesis": meta["hypothesis"], "change_points": meta["change_points"]})
    return meta, out


def card_of(ab):
    """A workload card id: WL-<symptom or metric family>, so the knowledge base keys recurrences the same way."""
    key = (ab.get("symptom") or ab.get("metric_id") or ab.get("component_class") or "unknown")
    key = "".join(ch if ch.isalnum() or ch in ".-_" else "_" for ch in str(key))[:48]
    return "WL-" + key


def to_incidents(meta, abnormalities):
    incs, rows = [], []
    for n, ab in enumerate(abnormalities, 1):
        card = card_of(ab)
        conf = ab.get("confidence") if ab.get("confidence") is not None else 0.6
        verdict = "CONFIRMED" if conf >= 0.8 else "SUSPECT"
        rule = "WL." + (ab.get("symptom") or ab.get("metric_id") or "abnormality")
        origin = "device" if str(ab.get("component_class") or "").lower() in ("device", "disk", "storage", "driver") else "host"
        detail = "%s (observed %s %s vs baseline %s)" % (ab.get("statement") or ab.get("title"), ab.get("observed"), ab.get("unit") or "", ab.get("baseline"))
        inc = {"id": "INC-%04d" % n, "verdict": verdict, "layer": "workload", "start_pkt": None, "end_pkt": None,
               "first_abnormal": {"pkt": None, "rule": rule, "detail": detail[:300], "verdict": verdict},
               "rules": {rule: {"role": "root", "detail": detail[:200]}},
               "explanation": {"pattern": "WL-" + str(ab.get("component_class") or "workload"), "title": ab.get("title"), "why": ab.get("statement"),
                               "mechanism": meta.get("hypothesis") or ab.get("statement")},
               "attribution": {"origin": origin, "basis": "workload artifact: component %s (%s)" % (ab.get("component"), ab.get("component_class"))},
               "atlas_candidates": [{"card_id": card, "title": ab.get("title"), "score": round(float(conf), 2)}],
               "task": "%s %s" % (meta.get("workload"), ab.get("phase") or ""), "nvme_commands": [],
               "workload": ab, "artifact_meta": {k: meta.get(k) for k in ("workload", "run_id", "device", "firmware", "verdict", "summary")}}
        incs.append(inc)
        ev_rows = ["Evidence=%s" % json.dumps(e)[:200] for e in (ab.get("evidence") or [])[:8]]
        rows.append({"id": inc["id"], "blocks": [{"range": [0, len(ev_rows)], "rows": ev_rows}] if ev_rows else []})
    return incs, rows


def run_workload_import(job_id, params, mgr):
    """Job body for the 'workload' input kind: artifact JSON -> run folder in the same layout stage 1 writes."""
    path, run_dir = params["artifact_path"], params["run_dir"]
    os.makedirs(run_dir, exist_ok=True)
    t0 = time.time()
    with mgr.span(job_id, "stage1.import", {"artifact": path}):
        mgr.progress(job_id, "import", "reading the workload artifact", 10, {"rows_read": 0})
        artifact = json.load(open(path, encoding="utf-8"))
        meta, abn = normalise(artifact)
        incs, rows = to_incidents(meta, abn)
        json.dump(incs, open(os.path.join(run_dir, "incidents.json"), "w", encoding="utf-8"), indent=1)
        with open(os.path.join(run_dir, "incident_rows.jsonl"), "w", encoding="utf-8") as f:
            for r in rows:
                f.write(json.dumps(r) + "\n")
        iso = [{"id": i["id"], "status": "ISOLATED" if i["verdict"] == "CONFIRMED" else "SUSPECT",
                "where": {"workload": meta.get("workload"), "phase": i["workload"].get("phase"), "component": i["workload"].get("component")},
                "why": {"mechanism": i["explanation"].get("mechanism")}, "fix": {"corrective_action": "reproduce on the hardware bench with the baseline scenario, then fix the firmware path named by the change points"}}
               for i in incs]
        json.dump(iso, open(os.path.join(run_dir, "isolation.json"), "w", encoding="utf-8"), indent=1)
        with open(os.path.join(run_dir, "llm_reviews.jsonl"), "w", encoding="utf-8") as f:
            for i in incs:
                f.write(json.dumps({"id": i["id"], "verdict": i["verdict"], "confidence": (i["atlas_candidates"][0]["score"]), "card_id": i["atlas_candidates"][0]["card_id"],
                                    "backend": "artifact", "summary": "verdict carried by the workload artifact (%s); stage-1 narrative: %s" % (meta.get("workload"), (artifact.get("summary") or "")[:300])}) + "\n")
        mgr.event(job_id, "workload artifact imported: %s, verdict %s, %d abnormalities -> %d defects" % (meta.get("workload"), (meta.get("verdict") or {}).get("outcome"), len(abn), len(incs)))
    with open(os.path.join(run_dir, "report.md"), "w", encoding="utf-8") as f:
        f.write("# Workload artifact run\n\nartifact: %s\nworkload: %s\nverdict: %s\nabnormalities: %d\n" % (path, meta.get("workload"), json.dumps(meta.get("verdict")), len(incs)))
    summary = {"csv": path, "kind": "workload", "run_dir": run_dir, "incidents": len(incs), "llm_reviewed": len(incs), "llm_called": 0, "llm_cached": 0,
               "llm_confirmed": sum(1 for i in incs if i["verdict"] == "CONFIRMED"), "steps": {"import": {"seconds": round(time.time() - t0, 2), "rc": 0}},
               "artifact_meta": meta}
    json.dump(summary, open(os.path.join(run_dir, "stage1_summary.json"), "w", encoding="utf-8"), indent=1)
    mgr.progress(job_id, "done", "%d defects from the workload artifact" % len(incs), 100, {"rows_read": len(incs), "incidents": len(incs), "findings": len(incs)})
    mgr.event(job_id, "stage 1 complete (workload artifact): %d defects" % len(incs))
    return summary
