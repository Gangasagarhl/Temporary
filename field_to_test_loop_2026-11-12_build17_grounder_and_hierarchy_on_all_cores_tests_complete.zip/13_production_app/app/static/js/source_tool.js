// The first question of the start page (owner, 2026-11-12): which tool exported the recording you want to analyse.
// A file of its own, loaded after agents.js. It adds the question to the "New analysis" card, keeps "Start the flow" off until
// an available tool is chosen, sends the choice with the new analysis, and shows the tool's name with every analysis.
// The tools come from the server (GET /api/agents/source_tools: the reference library's list, in its order). A server from
// before the question answers 404: then nothing is added, nothing is sent, and the page works as it did.
"use strict";
(function () {
  const main = document.getElementById("main");
  if (!main || typeof fetch !== "function") return;
  // tools: null = the server does not have the question; pending: the server has not answered yet; chosen: the key of the chosen tool
  const T = { tools: null, pending: true, question: "", why: "", chosen: "" };
  const REASON = "Start the flow is off until you choose the tool that exported the recording (the first question of this card).";
  const NONE = "No tool can be chosen in this copy of the application, so the flow starts without one: the Data Grounder works out the tool from the column names.";
  const h = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const sentence = s => { s = String(s || "").trim(); return s ? s.charAt(0).toUpperCase() + s.slice(1) + (/[.!?]$/.test(s) ? "" : ".") : ""; };
  const tool = key => (T.tools || []).find(t => t.key === key);
  const anyAvailable = () => (T.tools || []).some(t => t.available);
  // may the flow start: yes without the question (older server), yes when no tool can be chosen at all, else only with an available tool chosen
  const ok = () => { if (!T.tools || !anyAvailable()) return true; const t = tool(T.chosen); return !!(t && t.available); };

  const css = document.createElement("style");
  css.textContent = `
#st-q { margin: 14px 0 4px; }
#st-q .st-l { font-weight: 600; font-size: 13px; margin: 0 0 6px; }
#st-q .st-l .req { font-weight: 600; font-size: 11px; letter-spacing: .03em; color: var(--accent-strong); background: var(--accent-soft); border-radius: 999px; padding: 1px 8px; margin-left: 6px; }
#st-q .st-opt { display: flex; gap: 10px; align-items: flex-start; border: 1px solid var(--line); border-radius: 10px; padding: 9px 11px; margin: 6px 0 0; cursor: pointer; background: var(--bg); }
#st-q .st-opt:hover { border-color: var(--faint); }
#st-q .st-opt.on { border-color: var(--accent); box-shadow: 0 0 0 3px var(--accent-soft); }
#st-q .st-opt.off { cursor: default; background: var(--surface-2); }
#st-q .st-opt.off:hover { border-color: var(--line); }
#st-q .st-opt input { margin: 4px 0 0; flex: none; accent-color: var(--accent); }
#st-q .st-t { display: flex; flex-direction: column; gap: 2px; min-width: 0; font-size: 14px; overflow-wrap: anywhere; }
#st-q .st-opt.off b { color: var(--muted); }
#st-q .st-x { font-size: 12.5px; line-height: 1.5; color: var(--muted); }
#st-q .st-na { font-size: 12.5px; line-height: 1.5; color: var(--warn); font-weight: 600; }
#st-why { flex: 0 0 100%; font-size: 13px; color: var(--warn); }`;
  document.head.appendChild(css);

  function questionHtml() {
    return `<div class="st-l" id="st-q-l">${h(T.question)} <span class="req">required</span></div>
      ${T.why ? `<div class="why">${h(T.why)}</div>` : ""}
      ${T.tools.map(t => `<label class="st-opt${t.available ? "" : " off"}${T.chosen === t.key ? " on" : ""}">
        <input type="radio" name="st-tool" value="${h(t.key)}"${t.available ? "" : " disabled"}${T.chosen === t.key ? " checked" : ""}>
        <span class="st-t"><b>${h(t.name)}</b>
          ${t.exports ? `<span class="st-x">What it exports: ${h(t.exports)}.</span>` : ""}
          ${t.hierarchy_words ? `<span class="st-x">${h(sentence(t.hierarchy_words))}</span>` : ""}
          ${t.available ? "" : `<span class="st-na">${h(sentence(t.sentence || "not available yet"))}</span>`}</span></label>`).join("")}`;
  }

  // the question, as the first thing of the "New analysis" card (the page redraws the card: it is put back with the choice kept)
  function question(make) {
    if (document.getElementById("st-q")) return;
    const actions = make.parentElement, card = make.closest(".card") || actions.parentElement;
    const q = document.createElement("div");
    q.id = "st-q"; q.setAttribute("role", "radiogroup"); q.setAttribute("aria-labelledby", "st-q-l");
    q.innerHTML = questionHtml();
    const first = card.querySelector('label[for="adm"]');
    if (first && first.parentElement === card) card.insertBefore(q, first);
    else if (actions.parentElement === card) card.insertBefore(q, actions);
    else card.appendChild(q);
    const intro = card.querySelector("h2 + p");
    if (intro && /^Three fields\./.test(intro.textContent.trim())) intro.textContent = "One question and three fields. Everything else is asked when it is needed.";
  }

  // "Start the flow" is off until an available tool is chosen, and the card says why
  function gate(make) {
    const off = T.pending || !ok();
    if (make.disabled !== off) make.disabled = off;
    const want = !T.tools ? "" : !anyAvailable() ? NONE : off ? REASON : "";
    let why = document.getElementById("st-why");
    if (!want) { if (why) why.remove(); if (make.title) make.title = ""; return; }
    if (!why) { why = document.createElement("div"); why.id = "st-why"; why.setAttribute("aria-live", "polite"); make.parentElement.insertBefore(why, make.parentElement.firstChild); }
    if (why.textContent !== want) why.textContent = want;
    const tip = off ? want : "";
    if (make.title !== tip) make.title = tip;
  }

  // the tool's name with an analysis: in the list of analyses and under the name of an open one (the name, never the key)
  function names() {
    const projects = typeof S !== "undefined" && S && S.state && Array.isArray(S.state.projects) ? S.state.projects : null;
    if (!projects) return;
    main.querySelectorAll(".proj").forEach(row => {
      const a = row.querySelector("a[data-open]"), meta = row.querySelector(".meta");
      const p = a && projects.find(x => String(x.id) === String(a.dataset.open));
      if (!meta || !p || !p.source_tool_name || meta.querySelector(".st-of")) return;
      meta.insertAdjacentHTML("beforeend", `<span class="st-of"> · recording exported by ${h(p.source_tool_name)}</span>`);
    });
    const m = /^#\/p\/(\d+)(?:\/(?!errors)[^/]*)?\/?$/.exec(location.hash);
    const meta = m && main.querySelector(".phead .meta"), p = m && projects.find(x => String(x.id) === m[1]);
    if (!meta || !p || meta.querySelector(".st-of")) return;
    meta.insertAdjacentHTML("beforeend", p.source_tool_name
      ? `<span class="st-of"> · recording exported by <b>${h(p.source_tool_name)}</b></span>`
      : `<span class="st-of"> · the tool that exported the recording was not asked for this analysis (the Data Grounder works it out from the column names)</span>`);
  }

  function place() {
    const make = document.getElementById("np-make");
    if (make) { if (T.tools) question(make); gate(make); }
    if (T.tools) names();
  }

  main.addEventListener("change", e => {
    const x = e.target;
    if (!x || x.name !== "st-tool" || !x.checked) return;
    const t = tool(x.value);
    T.chosen = t && t.available ? t.key : "";
    main.querySelectorAll("#st-q .st-opt").forEach(l => l.classList.toggle("on", !!l.querySelector("input:checked")));
    const make = document.getElementById("np-make");
    if (make) gate(make);
  });

  // the choice goes with the new analysis: the page's own request gets one more field (and nothing else of it changes)
  const send = window.api;
  if (typeof send === "function") {
    window.api = function (method, url, body) {
      const mine = !!T.tools && method === "POST" && url === "/api/agents/projects" && !!body && typeof body === "object";
      const t = mine ? tool(T.chosen) : null;
      if (t && t.available && !("source_tool" in body)) body = Object.assign({}, body, { source_tool: t.key });
      const answer = send.call(this, method, url, body);
      if (mine && answer && typeof answer.then === "function") answer.then(() => { T.chosen = ""; }, () => {});   // the next analysis is asked again: nothing stays chosen
      return answer;
    };
  }

  function settle(j) {
    T.pending = false;
    const tools = j && Array.isArray(j.tools) ? j.tools.filter(t => t && typeof t.key === "string" && t.key && t.name) : [];
    if (tools.length) { T.tools = tools; T.question = j.question || "Which tool exported the recording you want to analyse?"; T.why = j.why || ""; }
    place();
  }
  new MutationObserver(place).observe(main, { childList: true, subtree: true });
  place();
  const stop = typeof AbortController === "function" ? new AbortController() : null;
  const timer = setTimeout(() => { if (stop) stop.abort(); }, 8000);
  fetch("/api/agents/source_tools", stop ? { signal: stop.signal } : undefined)
    .then(r => (r.ok ? r.json() : null)).catch(() => null).then(j => { clearTimeout(timer); settle(j); });
})();
