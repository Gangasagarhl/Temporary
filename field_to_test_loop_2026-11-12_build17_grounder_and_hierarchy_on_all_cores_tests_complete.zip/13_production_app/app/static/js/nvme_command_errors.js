/* The NVMe command errors page (owner, 2026-11-12). The list comes from /api/hier/nvme_command_errors (names and values
   of the two NVMe specifications); the counts of one recording from /api/hier/nvme_command_errors/<upload>. Nothing is
   chosen until the user chooses a recording; no time limit is shown here. */
(function () {
  "use strict";
  const $ = id => document.getElementById(id);
  const esc = s => String(s === null || s === undefined ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const nf = n => Number(n || 0).toLocaleString("en-US");
  const cmds = n => `${nf(n)} command${Number(n) === 1 ? "" : "s"}`;
  const state = { cat: null, counts: null, upload: "" };

  async function get(url) {
    const r = await fetch(url, { headers: { Accept: "application/json" } });
    let body = null;
    try { body = await r.json(); } catch (e) { body = null; }
    if (!r.ok) {
      const e = new Error((body && (body.error || body.description)) || (r.status === 404
        ? "this part of the application is not running yet: it starts with the next start of the application"
        : `the application answered with a problem (HTTP ${r.status})`));
      e.status = r.status; throw e;
    }
    return body;
  }
  const status = (text, bad) => { const s = $("status"); s.textContent = text; s.className = "status" + (bad ? " bad" : ""); };
  const keyOf = e => `${e.type}:${e.code}:${e.code_to}`;

  function row(e) {
    const seen = state.counts && e.scope === "pcie" ? state.counts.seen[keyOf(e)] : null;
    const fine = e.kind === "success";
    const quiet = e.kind === "reserved" || e.scope === "fabrics";
    let count = "";
    if (state.counts) {
      if (e.scope === "fabrics") count = `<span class="muted">not counted: not possible on a PCIe link</span>`;
      else if (seen) {
        const parts = e.code !== e.code_to ? `<div class="src">${seen.codes.map(c => `status code ${esc(c.code_hex)}: ${cmds(c.commands)}`).join(" · ")}</div>` : "";
        const first = seen.first_command !== null && seen.first_command !== undefined ? `<div class="src">first: NVMe command number ${nf(seen.first_command)} of the recording</div>` : "";
        count = `<b>seen in this recording: ${cmds(seen.commands)}</b>${parts}${first}`;
      } else count = `<span class="muted">seen in this recording: 0 commands</span>`;
    }
    const who = e.commands ? `<div class="src">commands the specification names for it: ${esc(e.commands)}</div>` : "";
    const set = e.command_set ? `<div class="src">I/O command set named beside it in the specification: ${esc(e.command_set)} (NVM = NVM Command Set, ZNS = Zoned Namespace Command Set, KV = Key Value Command Set)</div>` : "";
    return `<tr class="${seen ? "seen" + (fine ? " fine" : "") : ""}${quiet ? " quiet" : ""}">
      <td class="code">${esc(e.code_hex)}</td>
      <td><b>${esc(e.name)}</b><div class="src">${esc(e.kind_words)}</div></td>
      <td>${esc(e.meaning)}${who}${set}</td>
      <td><span class="src">${esc(e.where)}</span></td>
      ${state.counts ? `<td class="n">${count}</td>` : ""}</tr>`;
  }

  function render() {
    const c = state.cat; if (!c) return;
    const q = $("find").value.trim().toLowerCase(), only = $("only-seen").checked && !!state.counts;
    const match = e => (!q || `${e.name} ${e.code_hex} ${e.meaning} ${e.type_name} ${e.commands || ""}`.toLowerCase().includes(q))
      && (!only || (e.scope === "pcie" && state.counts.seen[keyOf(e)]));
    const seenN = e => (state.counts && e.scope === "pcie" && state.counts.seen[keyOf(e)] ? state.counts.seen[keyOf(e)].commands : 0);
    const head = `<tr><th>Status code (hexadecimal)</th><th>Name in the specification</th><th>What it means, in plain words</th><th>Where the specification states it</th>${state.counts ? "<th>Commands of this recording</th>" : ""}</tr>`;
    let html = "";
    const groups = c.types.map(t => ({ t, rows: c.entries.filter(e => e.scope === "pcie" && e.type >= t.type && e.type <= t.type_to) }));
    groups.push({ t: { type_hex: "1h", name: "Command Specific Status, only for NVMe over Fabrics commands", fabrics: true,
      meaning: "The same status code type 1h, when the command is an NVMe over Fabrics command (a connection over a network). A recording of a PCIe link holds no such command, so these are listed for completeness and are not counted.",
      where: (c.entries.find(e => e.scope === "fabrics") || {}).where || "" }, rows: c.entries.filter(e => e.scope === "fabrics") });
    for (const g of groups) {
      let rows = g.rows.filter(match);
      if (!rows.length) continue;
      if (state.counts) rows = rows.slice().sort((a, b) => (seenN(b) > 0) - (seenN(a) > 0));      // what was seen comes first; the table's own order otherwise
      const total = state.counts && !g.t.fabrics ? rows.reduce((s, e) => s + seenN(e), 0) : null;
      html += `<section><h2>Status code type ${esc(g.t.type_hex)}: ${esc(g.t.name)}</h2>
        <p>${esc(g.t.meaning)} <span class="src">${esc(g.t.where)}</span>${total !== null ? ` · <b>${cmds(total)}</b> of this recording ended with a status of this type (rows shown here)` : ""}</p>
        <div class="tablewrap"><table>${head}${rows.map(row).join("")}</table></div></section>`;
    }
    $("sections").innerHTML = html || `<div class="empty">Nothing in the list matches.</div>`;
    renderTotals();
  }

  function renderTotals() {
    const k = state.counts, box = $("totals"), un = $("unknown");
    if (!k) { box.hidden = true; un.innerHTML = ""; return; }
    box.hidden = false;
    box.innerHTML = `<div><b>${nf(k.commands)}</b><span>NVMe commands in this recording</span></div>
      <div><b>${nf(k.successful)}</b><span>ended with Successful Completion (status code type 0h, status code 00h)</span></div>
      <div><b>${nf(k.with_another_status)}</b><span>ended with any other status</span></div>
      <div><b>${nf(k.no_status)}</b><span>${esc(k.no_status_words)}</span></div>`;
    un.innerHTML = (k.not_in_catalogue || []).length ? `<section><h2>Seen in this recording and not in the specifications' tables</h2>
      <p>These are never dropped: the recording holds them, and no row of the tables names them.</p>
      <div class="tablewrap"><table><tr><th>Status code type</th><th>Status code</th><th>Commands of this recording</th><th>First NVMe command number</th><th>Why it is listed here</th></tr>
      ${k.not_in_catalogue.map(u => `<tr class="seen"><td class="code">${esc(u.type_hex !== undefined ? u.type_hex : (u.type === null ? "empty" : u.type))}${u.type_name ? " (" + esc(u.type_name) + ")" : ""}</td><td class="code">${esc(u.code_hex !== undefined ? u.code_hex : (u.code === null ? "empty" : u.code))}</td><td class="n">${cmds(u.commands)}</td><td class="n">${u.first_command === null || u.first_command === undefined ? "not numbered" : nf(u.first_command)}</td><td>${esc(u.why)}</td></tr>`).join("")}</table></div></section>` : "";
  }

  async function choose() {
    state.upload = $("rec").value; state.counts = null;
    if (!state.upload) { status(`${nf(state.cat.summary.entries)} entries in the list; ${nf(state.cat.summary.named_errors)} of them are named errors. No recording is chosen.`); render(); return; }
    status("Counting the NVMe commands of the recording…");
    try {
      state.counts = await get(`/api/hier/nvme_command_errors/${encodeURIComponent(state.upload)}`);
      status(`Counted ${cmds(state.counts.commands)}: ${state.counts.source}.`);
    } catch (e) { status(`The recording could not be counted: ${e.message}`, true); }
    render();
  }

  async function start() {
    try { state.cat = await get("/api/hier/nvme_command_errors"); }
    catch (e) { status(`The list could not be read: ${e.message}`, true); return; }
    const s = state.cat.summary;
    $("not-here").textContent = s.not_here;
    $("sources").innerHTML = `Source of every name and value: ${s.documents.map(d => `${esc(d.document)}, ${esc(d.revision)}`).join("; ")} (public, at <a href="${esc(s.documents[0].address)}" target="_blank" rel="noopener">${esc(s.documents[0].address)}</a>). ${esc(s.how_checked)}.`;
    try {
      const ups = await get("/api/hier/uploads");
      for (const u of ups) {
        if (u.status !== "loaded") continue;
        const o = document.createElement("option"); o.value = u.upload_id;
        o.textContent = [u.trace_name || "recording without a name", u.device ? `device ${u.device}` : "", u.recording_date ? `recorded ${u.recording_date}` : "", `loaded as ${u.upload_id}`].filter(Boolean).join(" · ");
        $("rec").appendChild(o);
      }
    } catch (e) { /* the list alone is still shown */ }
    const want = new URLSearchParams(location.search).get("upload");       // a link from an errors page may name the recording
    if (want && [...$("rec").options].some(o => o.value === want)) $("rec").value = want;
    $("rec").addEventListener("change", choose);
    $("find").addEventListener("input", render);
    $("only-seen").addEventListener("change", render);
    choose();
  }
  start();
})();
