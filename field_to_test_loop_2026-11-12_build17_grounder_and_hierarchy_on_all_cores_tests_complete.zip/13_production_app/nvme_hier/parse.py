"""Value parsers for the export's cell formats. Every function returns None for a blank or unreadable cell and
never raises, so one odd cell cannot stop a load; the loader counts unreadable cells per column in its report.

Formats (from the customer's 113-column export and the generator that imitates it):
  Time Stamp   "0000.161897042000s"  seconds . twelve fractional digits (picoseconds) and a trailing s
  Time Delta   "150.398 us" / "1.2 ms" / "500 ns" / "0.5 s" / "12 ps"
  Address      "0x00000000FCE01008"  (also plain hex without 0x, or decimal)
  Tag, PSN, QID, CID, Length, Byte Cnt   decimal ("26"), hex ("0x1A"), or "26 (Read)" style text with a leading number
  DATA / Data  "256 B" / "4 KB" / "1 KB" summary, or hex bytes "00 1F 2A ..." when the export expanded the data
"""
import re

PS = 1
NS = 1000
US = 1000 * NS
MS = 1000 * US
SEC = 1000 * MS
UNIT_PS = {"ps": PS, "ns": NS, "us": US, "µs": US, "μs": US, "ms": MS, "s": SEC, "sec": SEC}

_TS = re.compile(r"^\s*(\d+)\.(\d{1,12})\s*s?\s*$")
_DELTA = re.compile(r"^\s*(-?\d+(?:\.\d+)?)\s*(ps|ns|us|µs|μs|ms|s|sec)\s*$", re.I)
_INT = re.compile(r"^\s*(0[xX][0-9A-Fa-f]+|-?\d+)")
_HEX_ONLY = re.compile(r"^\s*[0-9A-Fa-f]+\s*$")
_SIZE = re.compile(r"^\s*(\d+(?:\.\d+)?)\s*(B|KB|MB|GB|KiB|MiB|GiB)\s*$", re.I)
_HEXBYTES = re.compile(r"^\s*(?:[0-9A-Fa-f]{2}\s+){1,}[0-9A-Fa-f]{2}\s*$")
_SIZE_MULT = {"b": 1, "kb": 1024, "mb": 1024 ** 2, "gb": 1024 ** 3, "kib": 1024, "mib": 1024 ** 2, "gib": 1024 ** 3}


def time_stamp_ps(s):
    """'0000.161897042000s' -> 161897042000 (picoseconds)."""
    if not s:
        return None
    # the usual cell, digits "." digits and one "s", is read without the pattern (about a third of the time per cell);
    # every other spelling takes the pattern below, and both give the same number (tests/test_hierarchy_parallel.py)
    if type(s) is str:          # anything else goes to the pattern, which refuses it as it always did
        sec, _, frac = s.partition(".")
        if frac[-1:] == "s":
            frac = frac[:-1]
        if len(frac) <= 12 and s.isascii() and sec.isdigit() and frac.isdigit():
            return int(sec) * SEC + int(frac.ljust(12, "0"))
    m = _TS.match(s)
    if not m:
        return None
    sec, frac = m.group(1), m.group(2)
    return int(sec) * SEC + int(frac.ljust(12, "0")[:12])


def delta_ps(s):
    """'150.398 us' -> 150398000. Negative values are kept (the export can show them around replays)."""
    if not s:
        return None
    m = _DELTA.match(s)
    if not m:
        return None
    try:
        return int(round(float(m.group(1)) * UNIT_PS[m.group(2).lower()]))
    except (OverflowError, ValueError):       # a number too long to be a time
        return None


def fmt_ps(ps):
    """Picoseconds -> the shortest readable unit, e.g. 43000000000 -> '43 ms'."""
    if ps is None:
        return ""
    a = abs(ps)
    for unit, size in (("s", SEC), ("ms", MS), ("us", US), ("ns", NS)):
        if a >= size:
            v = ps / size
            return ("%.3f %s" % (v, unit)).replace(".000 ", " ")
    return "%d ps" % ps


def int_value(s, hex_default=False):
    """Leading decimal or 0x-hex number of a cell. hex_default: a bare hex string (no 0x) is read as hex, which
    is how the export prints addresses and most identifiers."""
    if s is None:
        return None
    if not hex_default and type(s) is str and s.isdigit() and s.isascii():      # the usual cell: decimal digits only
        return int(s) if len(s) <= 20 else None
    s = str(s).strip()
    if not s:
        return None
    m = _INT.match(s)
    if m:
        tok = m.group(1)
        if len(tok.lstrip("-")) > 20:           # longer than any 64-bit number: a data dump or a serial, not a field value
            return None
        if tok.lower().startswith("0x"):
            return int(tok, 16)
        if hex_default and _HEX_ONLY.match(s) and not s.isdigit():
            return int(s, 16) if len(s) <= 16 else None
        if hex_default and _HEX_ONLY.match(s) and len(s) >= 8:
            return int(s, 16) if len(s) <= 16 else None
        return int(tok)
    if hex_default and _HEX_ONLY.match(s):
        return int(s, 16) if len(s) <= 16 else None
    return None


_ADDR64 = re.compile(r"^\s*(?:0[xX])?([0-9A-Fa-f]{1,8}):([0-9A-Fa-f]{8})\s*$")
_HEX_DIGITS = "0123456789abcdefABCDEF"


def address(s):
    """'0x00000000FCE01008', 'FCE01008' or the analyzer's split form '00000004:800A0000' (high:low)."""
    if not s:
        return None
    if type(s) is str:
        # the two usual cells, "0x" and hex digits or hex digits alone, are read without the patterns; every other
        # spelling (high:low, spaces, a sign, text after the number) takes the patterns below, with the same result
        body = s[2:] if s[:2] in ("0x", "0X") else None
        if body is not None:
            if body and not body.strip(_HEX_DIGITS):
                v = int(body, 16) if len(body) <= 18 else None
                return v if v is None or v < 2 ** 63 else None
        elif not s.strip(_HEX_DIGITS):
            if len(s) < 8 and s.isdigit():
                return int(s)                   # a short number without a letter is decimal, as int_value reads it
            v = int(s, 16) if len(s) <= 16 else None
            return v if v is None or v < 2 ** 63 else None
    m = _ADDR64.match(s)
    if m:
        return (int(m.group(1), 16) << 32) | int(m.group(2), 16)
    v = int_value(s, hex_default=True)
    return v if v is None or 0 <= v < 2 ** 63 else None


def data_bytes(s):
    """'256 B' -> 256, '4 KB' -> 4096, hex bytes -> their count; None when blank."""
    if not s:
        return None
    m = _SIZE.match(s)
    if m:
        return int(float(m.group(1)) * _SIZE_MULT[m.group(2).lower()])
    if _HEXBYTES.match(s):
        return len(s.split())
    return None


def data_is_expanded(s):
    """True when the cell holds the bytes themselves (export made with 'expand data')."""
    return bool(s) and bool(_HEXBYTES.match(s))


def text(s):
    return s.strip() if s else None


def direction(s):
    """'Upstream' / 'Downstream' normalised; anything else is kept as written."""
    if not s:
        return None
    t = s.strip().lower()
    if t.startswith("up"):
        return "Upstream"
    if t.startswith("down"):
        return "Downstream"
    return s.strip()
