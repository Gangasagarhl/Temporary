"""f2t_nvme: the fixed replay library every generated regression test uses (field-to-test loop, 2026-11-10).

A generated test file holds only its PLAN (data: the recorded environment, the setup, the steps, the oracles) and calls run_case(PLAN)
or deallocate_check(PLAN). Everything that touches a drive is here, in code the tool owns and the admin can read once:

  safety gate     runs only on a drive and namespace the operator listed by serial number; never on a mounted, held, swap or boot
                  device; destructive commands need NVME_DESTRUCTIVE=1 and NVME_CONFIRM=ERASE-<serial>
  identity        Identify Controller / Namespace: model, firmware, LBA size, deallocate read behaviour (DLFEAT) against the recording
  environment     the recording's feature settings (not the ones the Linux driver owns), the data the replayed commands read written first
                  with a pattern tagged by block and generation, the blocks the recording shows deallocated deallocated again
  replay          every command through the kernel's NVMe passthrough ioctl: opcode, namespace and command dwords 10-15 as the recording
                  decodes them. The kernel chooses the command id, the queue and the data pointers; PCIe link events cannot be sent
                  from a host (use the analyzer's exerciser for those).
  oracles         EXPECT=fault: the recorded signature appears again (same status, a timeout, the time limit, the deallocate read-back);
                  EXPECT=fixed: every outcome a correct drive must give, for as many clean runs as the old firmware's rate requires
  snapshots       Identify, SMART and error log before and after every run, with SHA-256, into a JSON file beside the JUnit report
  simulated drive NVME_BACKEND=sim with NVME_SIM=<json>: an in-memory drive, with or without the recorded fault, so a test can be checked
                  both ways where there is no drive ("mechanics checked on a simulated drive", never "fault reproduced")

Specification facts used (official NVM Express documents): NVM Command Set 1.1 sections 3.3.3 (Dataset Management: deallocate is
advisory; deallocated blocks read as DLFEAT says, deterministically until written), 3.3.8 (Write Zeroes: reads shall return zeros);
Identify Namespace byte 33 (DLFEAT), byte 24 (NSFEAT), byte 26 (FLBAS), LBA formats from byte 128; Identify Controller (CNS 06h, NVM
command set) bytes 3, 7:4, 15:8 (DMRL, DMRSL, DMSL); Base 2.1 Set Features. Linux: include/uapi/linux/nvme_ioctl.h (the 72-byte
passthrough structure, NVME_IOCTL_ADMIN_CMD 0xC0484E41, NVME_IOCTL_IO_CMD 0xC0484E43).
"""
import ctypes
import errno
try:
    import fcntl
except ImportError:          # Windows: no Linux passthrough ioctl. The simulated drive runs; a test on a real drive is skipped (safety_gate)
    fcntl = None
import hashlib
import json
import math
import os
import random
import re
import stat
import struct
import time

LIB_VERSION = "2026.11.12-1"
ADMIN_IOCTL, IO_IOCTL = 0xC0484E41, 0xC0484E43
HOST_ABORTED = 0x371                               # Linux: the host gave up on the command (timeout, abort, reset)
DRIVER_OWNED_FEATURES = {0x07, 0x0C, 0x0D, 0x0F, 0x16}   # Number of Queues, APST, Host Memory Buffer, Keep Alive, Host Behavior: the driver sets them; Linux 7.3+ refuses them by passthrough
DESTRUCTIVE_OPCODES = {("io", 0x01), ("io", 0x04), ("io", 0x08), ("io", 0x09), ("admin", 0x80), ("admin", 0x84), ("admin", 0x09), ("admin", 0x0D), ("admin", 0x15), ("admin", 0x10), ("admin", 0x11)}
NEVER_REPLAYED = {0x00: "Delete I/O Submission Queue", 0x01: "Create I/O Submission Queue", 0x04: "Delete I/O Completion Queue", 0x05: "Create I/O Completion Queue",
                  0x0C: "Asynchronous Event Request", 0x10: "Firmware Commit", 0x11: "Firmware Image Download", 0x80: "Format NVM", 0x84: "Sanitize",
                  0x0D: "Namespace Management", 0x15: "Namespace Attachment"}   # queues are the driver's; the rest change the drive for good: the test reports them, never sends them


def env(name, default=None):
    v = os.environ.get(name)
    return default if v in (None, "") else v


# ------------------------------------------------------------------------------------------------ results
class Result:
    """One command's outcome: status word (SCT, SC, DNR), completion dword 0, data read, time taken, whether the host gave up."""

    def __init__(self, status=0, dw0=0, data=b"", seconds=0.0, timed_out=False, error=None):
        self.status, self.dw0, self.data, self.seconds, self.timed_out, self.error = status, dw0, data, seconds, timed_out, error
        st = status if isinstance(status, int) and status >= 0 else None
        self.sct = (st >> 8) & 0x7 if st is not None else None
        self.sc = st & 0xFF if st is not None else None
        self.dnr = bool(st & 0x4000) if st is not None else None
        if st == HOST_ABORTED:
            self.timed_out = True

    @property
    def ok(self):
        return self.status == 0 and not self.timed_out and self.error is None

    def words(self):
        if self.timed_out:
            return "no completion within the time limit (the host gave up after %.1f s)" % self.seconds
        if self.error:
            return "refused by the host: %s" % self.error
        if self.status == 0:
            return "successful completion"
        return "status type %s code 0x%02X%s" % (self.sct, self.sc or 0, " (do not retry)" if self.dnr else "")


# ------------------------------------------------------------------------------------------------ the real drive: kernel passthrough
class _Cmd(ctypes.Structure):
    _fields_ = [("opcode", ctypes.c_uint8), ("flags", ctypes.c_uint8), ("rsvd1", ctypes.c_uint16), ("nsid", ctypes.c_uint32),
                ("cdw2", ctypes.c_uint32), ("cdw3", ctypes.c_uint32), ("metadata", ctypes.c_uint64), ("addr", ctypes.c_uint64),
                ("metadata_len", ctypes.c_uint32), ("data_len", ctypes.c_uint32), ("cdw10", ctypes.c_uint32), ("cdw11", ctypes.c_uint32),
                ("cdw12", ctypes.c_uint32), ("cdw13", ctypes.c_uint32), ("cdw14", ctypes.c_uint32), ("cdw15", ctypes.c_uint32),
                ("timeout_ms", ctypes.c_uint32), ("result", ctypes.c_uint32)]


assert ctypes.sizeof(_Cmd) == 72


class Drive:
    """A real NVMe drive through the Linux passthrough ioctls: admin commands on the controller (/dev/nvmeX), I/O on the namespace
    (/dev/ngXnY, or /dev/nvmeXnY)."""
    kind = "real"

    def __init__(self, ctrl, ns_dev, nsid):
        self.ctrl, self.ns_dev, self.nsid = ctrl, ns_dev, nsid
        self.fd_admin = os.open(ctrl, os.O_RDONLY)
        self.fd_io = os.open(ns_dev, os.O_RDONLY)

    def close(self):
        for fd in (self.fd_admin, self.fd_io):
            try:
                os.close(fd)
            except OSError:
                pass

    def _send(self, fd, req, opcode, nsid, cdw, data_len=0, write=None, timeout_ms=30000):
        buf = None
        if data_len:
            buf = ctypes.create_string_buffer(data_len)
            if write is not None:
                ctypes.memmove(buf, bytes(write)[:data_len], min(len(write), data_len))
        c = _Cmd(opcode=opcode, flags=0, nsid=nsid & 0xFFFFFFFF, addr=ctypes.addressof(buf) if buf is not None else 0, data_len=data_len, timeout_ms=timeout_ms)
        for i in range(10, 16):
            setattr(c, "cdw%d" % i, (cdw.get(i, 0) or 0) & 0xFFFFFFFF)
        t0 = time.monotonic()
        try:
            st = fcntl.ioctl(fd, req, c)
        except OSError as e:
            took = time.monotonic() - t0
            timed = e.errno in (errno.EINTR, errno.ETIMEDOUT) or took * 1000 >= timeout_ms
            return Result(status=None, seconds=took, timed_out=timed, error=None if timed else os.strerror(e.errno))
        return Result(status=st, dw0=c.result, data=buf.raw if (buf is not None and write is None) else b"", seconds=time.monotonic() - t0)

    def admin(self, opcode, nsid=0, cdw=None, data_len=0, write=None, timeout_ms=60000):
        return self._send(self.fd_admin, ADMIN_IOCTL, opcode, nsid, cdw or {}, data_len, write, timeout_ms)

    def io(self, opcode, nsid, cdw=None, data_len=0, write=None, timeout_ms=30000):
        return self._send(self.fd_io, IO_IOCTL, opcode, nsid, cdw or {}, data_len, write, timeout_ms)


# ------------------------------------------------------------------------------------------------ the simulated drive
class SimDrive:
    """An in-memory NVMe namespace for checking a generated test where there is no drive. It follows the specification for the
    commands the tests send (Read, Write, Flush, Write Zeroes, Write Uncorrectable, Dataset Management, Identify, Get/Set Features,
    Get Log Page). Faults are injected from NVME_SIM (JSON):
      {"model": "...", "firmware": "...", "serial": "SIM0001", "lba_bytes": 512, "nsze": 1048576, "drb": 1, "thinp": true, "dae": true,
       "faults": [{"kind": "status", "opc": 2, "slba": 100, "nlb": 7, "sct": 2, "sc": 129, "p": 1.0},
                  {"kind": "timeout", "opc": 2, "slba": 100},
                  {"kind": "latency", "opc": 1, "us": 900000},
                  {"kind": "stale_deallocate"} | {"kind": "ignore_deallocate"} | {"kind": "wrong_value"} | {"kind": "spill"} | {"kind": "unstable"}]}
    A status/timeout fault applies to commands of that opcode whose range overlaps the given one (all of that opcode when none is given)."""
    kind = "sim"

    def __init__(self, cfg):
        self.cfg = cfg
        self.nsid = int(cfg.get("nsid", 1))
        self.lba = int(cfg.get("lba_bytes", 512))
        self.nsze = int(cfg.get("nsze", 1 << 20))
        self.drb = int(cfg.get("drb", 1))
        self.blocks, self.dealloc, self.features = {}, set(), {0x05: 0, 0x06: 1}
        self.faults = cfg.get("faults") or []
        self.rnd = random.Random(int(cfg.get("seed", 7)))
        self.reads = {}

    def close(self):
        pass

    def _fault(self, kind, opc, slba=None, nlb=0):
        for f in self.faults:
            if f.get("kind") != kind or (f.get("opc") is not None and f["opc"] != opc):
                continue
            if f.get("slba") is not None and slba is not None:
                a0, a1 = int(f["slba"]), int(f["slba"]) + int(f.get("nlb", 0))
                if a1 < slba or a0 > slba + nlb:
                    continue
            if self.rnd.random() < float(f.get("p", 1.0)):
                return f
        return None

    def _has(self, kind):
        return any(f.get("kind") == kind for f in self.faults)

    def _identify(self, cns, nsid):
        b = bytearray(4096)
        if cns == 1:
            struct.pack_into("<H", b, 0, 0x1E0F)
            b[4:24] = str(self.cfg.get("serial", "SIM0001")).encode().ljust(20)[:20]
            b[24:64] = str(self.cfg.get("model", "Simulated NVMe drive")).encode().ljust(40)[:40]
            b[64:72] = str(self.cfg.get("firmware", "SIMFW001")).encode().ljust(8)[:8]
            b[77] = 5
            struct.pack_into("<H", b, 520, 0x000C)          # ONCS: Dataset Management and Write Zeroes supported
        elif cns == 0:
            struct.pack_into("<QQQ", b, 0, self.nsze, self.nsze, len(self.blocks) - len(self.dealloc & set(self.blocks)) if self.cfg.get("thinp") else self.nsze)
            b[24] = (1 if self.cfg.get("thinp") else 0) | (4 if self.cfg.get("dae") else 0)
            b[26] = 0
            b[33] = (self.drb & 7) | 8
            b[128 + 2] = int(math.log2(self.lba))
        elif cns == 6:
            b[3] = int(self.cfg.get("dmrl", 256)) & 0xFF
            struct.pack_into("<I", b, 4, int(self.cfg.get("dmrsl", 0)))
            struct.pack_into("<Q", b, 8, int(self.cfg.get("dmsl", 0)))
        return bytes(b)

    def admin(self, opcode, nsid=0, cdw=None, data_len=0, write=None, timeout_ms=60000):
        cdw = cdw or {}
        if opcode == 0x06:
            return Result(0, data=self._identify(cdw.get(10, 0) & 0xFF, nsid)[:data_len or 4096])
        if opcode == 0x0A:
            return Result(0, dw0=self.features.get(cdw.get(10, 0) & 0xFF, 0))
        if opcode == 0x09:
            self.features[cdw.get(10, 0) & 0xFF] = cdw.get(11, 0)
            return Result(0)
        if opcode == 0x02:
            data = bytearray(data_len or 512)
            if (cdw.get(10, 0) & 0xFF) == 0x02 and len(data) >= 3:
                struct.pack_into("<H", data, 1, 310)        # 37 C
            return Result(0, data=bytes(data))
        return Result(0)

    def _fill(self, slba, nlb):
        if slba + nlb >= self.nsze:
            return None
        return [slba + i for i in range(nlb + 1)]

    def _read_block(self, b):
        if b in self.dealloc:
            if self._has("stale_deallocate") and b in self.blocks:
                return self.blocks.get(("old", b), self.blocks[b])
            if self._has("wrong_value"):
                return b"\xff" * self.lba if self.drb == 1 else b"\x00" * self.lba
            if self._has("unstable"):
                k = self.reads.get(b, 0)
                self.reads[b] = k + 1
                return (b"\x00" if k % 2 == 0 else b"\xff") * self.lba
            return (b"\xff" if self.drb == 2 else b"\x00") * self.lba
        return self.blocks.get(b, b"\x00" * self.lba)

    def io(self, opcode, nsid, cdw=None, data_len=0, write=None, timeout_ms=30000):
        cdw = cdw or {}
        slba = (cdw.get(11, 0) << 32) | cdw.get(10, 0)
        nlb = cdw.get(12, 0) & 0xFFFF
        f = self._fault("timeout", opcode, slba, nlb)
        if f:
            return Result(HOST_ABORTED, seconds=timeout_ms / 1000.0, timed_out=True)
        f = self._fault("status", opcode, slba, nlb)
        if f:
            return Result((int(f.get("sct", 0)) << 8) | int(f.get("sc", 6)), seconds=0.0002)
        lat = self._fault("latency", opcode, slba, nlb)
        took = (float(lat.get("us", 0)) / 1e6) if lat else 0.0001
        if opcode in (0x02, 0x01, 0x08, 0x04, 0x05, 0x0C):
            blocks = self._fill(slba, nlb)
            if blocks is None:
                return Result(0x0080, seconds=took)            # LBA Out of Range
        if opcode == 0x02:
            data = b"".join(self._read_block(b) for b in blocks)
            if self._has("short_read"):
                data = data[: len(data) // 2] + b"\x00" * (len(data) - len(data) // 2)
            return Result(0, data=data, seconds=took)
        if opcode == 0x01:
            for i, b in enumerate(blocks):
                if b in self.blocks:
                    self.blocks[("old", b)] = self.blocks[b]
                self.blocks[b] = bytes(write[i * self.lba:(i + 1) * self.lba])
                self.dealloc.discard(b)
            return Result(0, seconds=took)
        if opcode == 0x08:
            for b in blocks:
                self.blocks[b] = b"\x00" * self.lba
                if cdw.get(12, 0) & (1 << 25) and self.drb == 1 and not self._has("ignore_deallocate"):
                    self.dealloc.add(b)
            return Result(0, seconds=took)
        if opcode == 0x04:
            return Result(0, seconds=took)
        if opcode == 0x09:
            nr = (cdw.get(10, 0) & 0xFF) + 1
            ad = bool(cdw.get(11, 0) & 4)
            for i in range(nr):
                _ca, length, s = struct.unpack_from("<IIQ", write, i * 16)
                if length == 0:
                    continue
                if s + length > self.nsze:
                    return Result(0x0080, seconds=took)
                if ad and not self._has("ignore_deallocate"):
                    extra = 1 if self._has("spill") else 0
                    for b in range(s, s + length + extra):
                        self.dealloc.add(b)
            return Result(0, seconds=took)
        return Result(0, seconds=took)


# ------------------------------------------------------------------------------------------------ choosing the drive, the safety gate
class Skip(Exception):
    """The test cannot run meaningfully here (no drive, not allowed, not the recorded kind of drive): a pytest skip, never a pass."""


def _controller_of(ns_dev):
    m = re.match(r"^/dev/(?:nvme|ng)(\d+)n(\d+)$", ns_dev)
    if not m:
        raise Skip("NVME_NS must name a namespace device such as /dev/ng0n1 or /dev/nvme0n1, not %s" % ns_dev)
    return "/dev/nvme%s" % m.group(1), "nvme%sn%s" % (m.group(1), m.group(2)), int(m.group(2))


def safety_gate(plan, destructive):
    """Every check must pass or the test is skipped. Returns (Drive, facts). Operator-written: the allow-list (NVME_ALLOW: lines
    '<serial> <nsid>'), NVME_DESTRUCTIVE=1 and NVME_CONFIRM=ERASE-<serial> for commands that change data."""
    ns_dev = env("NVME_NS")
    if not ns_dev:
        raise Skip("no drive given: set NVME_NS=/dev/ngXnY (and NVME_ALLOW, see the header); NVME_BACKEND=sim runs on the simulated drive")
    if fcntl is None:
        raise Skip("a real drive is reached through the Linux NVMe passthrough, which this system does not have: run the test on a Linux machine, or with NVME_BACKEND=sim on the simulated drive")
    if not os.path.exists(ns_dev):
        raise Skip("%s does not exist on this machine" % ns_dev)
    ctrl, blk, nsid = _controller_of(ns_dev)
    nsid = int(env("NVME_NSID", nsid))
    allow = env("NVME_ALLOW")
    if not allow or not os.path.isfile(allow):
        raise Skip("no allow-list: write the drive's serial number and namespace (one '<serial> <nsid>' per line) in a file and give it as NVME_ALLOW")
    d = Drive(ctrl, ns_dev, nsid)
    try:
        ident = identify_controller(d)
    except Exception:
        d.close()
        raise
    listed = set()
    with open(allow, encoding="utf-8") as fh:
        for line in fh:
            p = line.split()
            if len(p) >= 2 and not line.lstrip().startswith("#"):
                listed.add((p[0], p[1]))
    if (ident["serial"], str(nsid)) not in listed:
        d.close()
        raise Skip("drive %s namespace %d is not in the allow-list %s" % (ident["serial"], nsid, allow))
    block = "/dev/%s" % blk
    if os.path.exists(block):
        try:
            fd = os.open(block, os.O_RDONLY | os.O_EXCL)       # EBUSY when mounted, in a volume or otherwise held
            os.close(fd)
        except OSError as e:
            d.close()
            raise Skip("%s is in use (%s): it is mounted, held by a volume, or open elsewhere" % (block, os.strerror(e.errno)))
        holders = "/sys/block/%s/holders" % blk
        if os.path.isdir(holders) and os.listdir(holders):
            d.close()
            raise Skip("%s is held by %s" % (block, ", ".join(os.listdir(holders))))
        try:
            with open("/proc/swaps", encoding="utf-8") as fh:
                if any(line.split()[0].startswith(block) for line in fh.readlines()[1:]):
                    d.close()
                    raise Skip("%s is used as swap" % block)
        except OSError:
            pass
        root_dev = os.stat("/").st_dev
        for name in [blk] + [x for x in os.listdir("/sys/block/%s" % blk) if x.startswith(blk)] if os.path.isdir("/sys/block/%s" % blk) else []:
            try:
                with open("/sys/class/block/%s/dev" % name, encoding="utf-8") as fh:
                    mj, mn = (int(x) for x in fh.read().split(":"))
                if os.makedev(mj, mn) == root_dev:
                    d.close()
                    raise Skip("%s holds the root file system" % block)
            except (OSError, ValueError):
                continue
    if destructive:
        if env("NVME_DESTRUCTIVE") != "1" or env("NVME_CONFIRM") != "ERASE-%s" % ident["serial"]:
            d.close()
            raise Skip("this test writes to the drive: set NVME_DESTRUCTIVE=1 and NVME_CONFIRM=ERASE-%s to allow it (the data in its LBA window is overwritten)" % ident["serial"])
    return d, ident


def open_drive(plan, destructive):
    """The drive the test runs on: the simulated one (NVME_BACKEND=sim), or a real one through the safety gate."""
    if env("NVME_BACKEND") == "sim":
        cfg = {}
        if env("NVME_SIM"):
            with open(env("NVME_SIM"), encoding="utf-8") as fh:
                cfg = json.load(fh)
        d = SimDrive(cfg)
        return d, identify_controller(d)
    return safety_gate(plan, destructive)


# ------------------------------------------------------------------------------------------------ identify
def _text(b):
    return b.decode("ascii", errors="replace").strip().strip("\x00").strip()


def identify_controller(d):
    r = d.admin(0x06, 0, {10: 1}, 4096)
    if not r.ok:
        raise Skip("Identify Controller failed: %s" % r.words())
    b = r.data
    return {"vid": struct.unpack_from("<H", b, 0)[0], "serial": _text(b[4:24]), "model": _text(b[24:64]), "firmware": _text(b[64:72]),
            "mdts": b[77], "oncs": struct.unpack_from("<H", b, 520)[0], "sha256": hashlib.sha256(b).hexdigest()}


def identify_namespace(d, nsid):
    r = d.admin(0x06, nsid, {10: 0}, 4096)
    if not r.ok:
        raise Skip("Identify Namespace %d failed: %s" % (nsid, r.words()))
    b = r.data
    nsze, ncap, nuse = struct.unpack_from("<QQQ", b, 0)
    flbas = b[26]
    fmt = (flbas & 0x0F) | ((flbas >> 1) & 0x30)
    lbads = b[128 + 4 * fmt + 2]
    dlfeat = b[33]
    return {"nsze": nsze, "ncap": ncap, "nuse": nuse, "nsfeat": b[24], "thinp": bool(b[24] & 1), "dae": bool(b[24] & 4), "flbas": flbas,
            "lba_bytes": 1 << lbads if lbads else 512, "metadata_bytes": struct.unpack_from("<H", b, 128 + 4 * fmt)[0], "dlfeat": dlfeat,
            "drb": dlfeat & 7, "wzds": bool(dlfeat & 8), "gds": bool(dlfeat & 16), "sha256": hashlib.sha256(b).hexdigest()}


def identify_nvm_limits(d):
    """Identify Controller for the NVM command set (CNS 06h): the Dataset Management limits (0 = no limit reported)."""
    r = d.admin(0x06, 0, {10: 6}, 4096)
    if not r.ok:
        return {"dmrl": 0, "dmrsl": 0, "dmsl": 0, "note": "CNS 06h not supported: %s" % r.words()}
    b = r.data
    return {"dmrl": b[3], "dmrsl": struct.unpack_from("<I", b, 4)[0], "dmsl": struct.unpack_from("<Q", b, 8)[0]}


# ------------------------------------------------------------------------------------------------ data patterns and block classes
MAGIC = b"F2T1"


def pattern(lba, gen, nonce, size):
    """A block that says which block and which generation it is, and is never all 00h or all FFh."""
    head = MAGIC + struct.pack("<QHH", lba, gen, nonce)
    body = bytes(((lba * 131 + gen * 17 + nonce + i) % 251) + 1 for i in range(size - len(head)))
    return head + body


def classify(block, lba, gens, nonce):
    """'latest' | 'stale' | 'zeros' | 'ones' | 'other_lba' | 'mixed' for one block read back after writes of generations gens (newest last)."""
    if block == pattern(lba, gens[-1], nonce, len(block)):
        return "latest"
    if any(block == pattern(lba, g, nonce, len(block)) for g in gens[:-1]):
        return "stale"
    if block.count(0) == len(block):
        return "zeros"
    if block.count(0xFF) == len(block):
        return "ones"
    if block[:4] == MAGIC:
        return "other_lba"
    return "mixed"


# ------------------------------------------------------------------------------------------------ commands from the plan's steps
def lba(plan, x):
    return int(x) + int(env("NVME_LBA_OFFSET", plan.get("lba_offset", 0)))


def _rw_cdw(slba, nlb, p=None):
    p = p or {}
    c12 = (nlb & 0xFFFF) | ((int(p.get("prinfo") or 0) & 0xF) << 26) | ((1 if p.get("fua") else 0) << 30) | ((1 if p.get("lr") else 0) << 31)
    if p.get("deac"):
        c12 |= 1 << 25
    return {10: slba & 0xFFFFFFFF, 11: (slba >> 32) & 0xFFFFFFFF, 12: c12}


def dsm_payload(ranges, pad_to=0):
    """The Dataset Management range list: 16 bytes per range (context attributes, length in blocks (1-based), starting LBA)."""
    out = b"".join(struct.pack("<IIQ", 0, int(n), int(s)) for s, n in ranges)
    return out.ljust(max(len(out), pad_to), b"\x00")


def send_step(d, plan, step, lba_bytes, nonce, gen):
    """One recorded command. -> (Result or None when it is not sent, words)."""
    p = step.get("parameters") or {}
    opc, nsid = step.get("opc"), int(p.get("nsid") or plan["recorded"].get("nsid") or d.nsid)
    tmo = int(plan.get("limits", {}).get("admin_ms" if step.get("admin") else "io_ms", 60000 if step.get("admin") else 30000))
    if step.get("admin"):
        if opc in NEVER_REPLAYED:
            return None, "%s is not sent: %s" % (NEVER_REPLAYED[opc], "it is the driver's" if opc in (0x00, 0x01, 0x04, 0x05, 0x0C) else "it changes the drive for good")
        if opc == 0x06:
            return d.admin(0x06, nsid if (p.get("cns") or 0) in (0, 3) else 0, {10: int(p.get("cns") or 0)}, 4096, timeout_ms=tmo), "Identify"
        if opc == 0x02:
            lid = int(p.get("lid") or 2)
            return d.admin(0x02, 0xFFFFFFFF, {10: lid | (127 << 16)}, 512, timeout_ms=tmo), "Get Log Page 0x%02X" % lid
        if opc == 0x0A:
            return d.admin(0x0A, 0, {10: int(p.get("fid") or 0)}, 0, timeout_ms=tmo), "Get Features"
        if opc == 0x09:
            fid = int(p.get("fid") or 0)
            if fid in DRIVER_OWNED_FEATURES:
                return None, "Set Features 0x%02X is the Linux driver's (refused by passthrough on Linux 7.3 and later): compared, not sent" % fid
            if p.get("value") is None:
                return None, "Set Features 0x%02X: the export does not carry the value, so it is not sent" % fid
            return d.admin(0x09, 0, {10: fid | ((1 if p.get("sv") else 0) << 31), 11: int(p["value"])}, 0, timeout_ms=tmo), "Set Features 0x%02X" % fid
        if opc == 0x18:
            return d.admin(0x18, 0, {}, 0, timeout_ms=tmo), "Keep Alive"
        if opc == 0x08:
            return None, "Abort names a command id the kernel chose in the field: not sent (the kernel's own timeout handling replays this behaviour)"
        return None, "admin opcode 0x%02X is not replayed by this library" % (opc or 0)
    slba, nlb = lba(plan, p.get("slba") or 0), int(p.get("nlb") or 0)
    if opc == 0x02:
        return d.io(0x02, nsid, _rw_cdw(slba, nlb, p), (nlb + 1) * lba_bytes, timeout_ms=tmo), "Read"
    if opc == 0x01:
        data = b"".join(pattern(slba + i, gen, nonce, lba_bytes) for i in range(nlb + 1))
        return d.io(0x01, nsid, _rw_cdw(slba, nlb, p), len(data), data, timeout_ms=tmo), "Write"
    if opc == 0x00:
        return d.io(0x00, nsid, {}, 0, timeout_ms=tmo), "Flush"
    if opc == 0x08:
        return d.io(0x08, nsid, _rw_cdw(slba, nlb, p), 0, timeout_ms=tmo), "Write Zeroes"
    if opc == 0x04:
        return d.io(0x04, nsid, {10: slba & 0xFFFFFFFF, 11: slba >> 32, 12: nlb & 0xFFFF}, 0, timeout_ms=tmo), "Write Uncorrectable"
    if opc == 0x0C:
        return d.io(0x0C, nsid, _rw_cdw(slba, nlb, p), 0, timeout_ms=tmo), "Verify"
    if opc == 0x09:
        ranges = [[lba(plan, s), n] for s, n in (p.get("ranges") or [[p.get("slba") or 0, nlb + 1]])]
        data = dsm_payload(ranges, 4096 if env("NVME_DSM_FULL_BUFFER") == "1" else 0)
        return d.io(0x09, nsid, {10: (len(ranges) - 1) & 0xFF, 11: 4 if p.get("deallocate", True) else 0}, len(data), data, timeout_ms=tmo), "Dataset Management"
    return None, "I/O opcode 0x%02X is not replayed by this library" % (opc or 0)


# ------------------------------------------------------------------------------------------------ how many runs
def _binom_cdf(k, n, p):
    return sum(math.comb(n, i) * p ** i * (1 - p) ** (n - i) for i in range(k + 1))


def lower_bound(k, n, conf=0.95):
    """One-sided lower confidence bound on a rate from k hits in n runs (exact binomial, Clopper-Pearson)."""
    if k <= 0:
        return 0.0
    lo, hi = 0.0, k / n
    for _ in range(60):
        mid = (lo + hi) / 2
        if 1 - _binom_cdf(k - 1, n, mid) < 1 - conf:
            lo = mid
        else:
            hi = mid
    return lo


def clean_runs_needed(k, n, conf=0.95):
    """Clean runs on new firmware for 'fixed' at this confidence, from the old firmware's k reproductions in n runs (its lower bound,
    the safe reading). None when k is 0: the fault was never reproduced, so no number of clean runs shows a fix."""
    if not n or not k:
        return None
    p = lower_bound(k, n, conf)
    return max(1, math.ceil(math.log(1 - conf) / math.log(1 - p))) if 0 < p < 1 else 1


# ------------------------------------------------------------------------------------------------ the oracles
def fault_seen(plan, res, lba_bytes, drb, nonce, gen):
    """Whether the recorded defect shows in this outcome of the fault step (the detector's rule, as the plan states it)."""
    o = plan["oracle_fault"]
    kind = o.get("kind")
    if res is None:
        return False, "the fault step was not sent"
    if kind == "status":
        want = (o.get("sct"), o.get("sc"))
        if want == (None, None):
            return (not res.ok and not res.timed_out), res.words()
        return (res.sct, res.sc) == tuple(want), res.words()
    if kind == "timeout":
        return res.timed_out or (o.get("limit_us") and res.seconds * 1e6 >= o["limit_us"]), res.words()
    if kind == "latency":
        return res.timed_out or res.seconds * 1e6 >= o["limit_us"], "%s after %.0f us (limit %s us)" % (res.words(), res.seconds * 1e6, o["limit_us"])
    if kind == "deallocate_readback":
        if not res.ok:
            return True, res.words()
        bad = _deallocated_read_bad(res.data, lba_bytes, drb)
        return bool(bad), bad or "every block reads as the drive declares for deallocated blocks"
    if kind == "bytes_short":
        want = (int((plan["steps"][plan["fault_step"] - 1].get("parameters") or {}).get("nlb") or 0) + 1) * lba_bytes
        return (not res.ok) or len(res.data) < want, "%d of %d bytes" % (len(res.data), want)
    return (not res.ok), res.words()


def _deallocated_read_bad(data, lba_bytes, drb):
    """What is wrong with a read of blocks the recording deallocated, by the drive's own DLFEAT (DRB): 001b all 00h, 010b all FFh, 000b either."""
    for i in range(0, len(data), lba_bytes):
        b = data[i:i + lba_bytes]
        zeros, ones = b.count(0) == len(b), b.count(0xFF) == len(b)
        if drb == 1 and not zeros:
            return "block %d reads %s, but the drive declares deallocated blocks read as 00h" % (i // lba_bytes, "FFh" if ones else "other data")
        if drb == 2 and not ones:
            return "block %d reads %s, but the drive declares deallocated blocks read as FFh" % (i // lba_bytes, "00h" if zeros else "other data")
        if drb == 0 and not (zeros or ones) and b[:4] == MAGIC:
            return "block %d still holds written data after the deallocate (the recorded symptom)" % (i // lba_bytes)
    return ""


def outcome_ok(exp, res):
    """A correct drive's outcome for one step (verified by the admin): its status and its time."""
    if res is None:
        return True, "not sent"
    if exp.get("status_code") is not None:
        want = tuple(exp["status_code"])
        good = (res.sct, res.sc) == want and not res.timed_out
    else:
        good = res.ok if exp.get("success", True) else (not res.ok)
    if good and exp.get("timing_us"):
        good = res.seconds * 1e6 <= exp["timing_us"]
    return good, "%s after %.0f us" % (res.words(), res.seconds * 1e6)


# ------------------------------------------------------------------------------------------------ snapshots and the result file
def snapshot(d, nsid):
    out = {"at": time.time()}
    try:
        out["controller"] = identify_controller(d)
        out["namespace"] = {k: v for k, v in identify_namespace(d, nsid).items()}
    except Skip as e:
        out["error"] = str(e)
    for lid, name in ((0x02, "smart"), (0x01, "error")):
        r = d.admin(0x02, 0xFFFFFFFF, {10: lid | (127 << 16)}, 512)
        out[name] = {"status": r.words(), "sha256": hashlib.sha256(r.data or b"").hexdigest()}
        if lid == 0x02 and r.ok and len(r.data) >= 3:
            out[name].update(critical_warning=r.data[0], temperature_c=struct.unpack_from("<H", r.data, 1)[0] - 273)
    return out


def write_result(plan, record, rec):
    folder = env("NVME_RESULTS", os.path.join(os.getcwd(), "results"))
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, "%s_%s_%d.json" % (plan["id"], rec.get("expect", "run"), int(time.time())))
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(rec, fh, indent=1, default=str)
    if record is not None:
        for k in ("test_id", "test_version", "library", "drive_model", "drive_firmware", "drive_serial", "backend", "expect", "verdict"):
            if rec.get(k) is not None:
                record(k, str(rec[k]))
    return path


# ------------------------------------------------------------------------------------------------ the case
def _destructive(plan):
    return any(("admin" if s.get("admin") else "io", s.get("opc")) in DESTRUCTIVE_OPCODES for s in plan["steps"]) or bool(plan["setup"].get("prewrite"))


def check_environment(d, plan, ident, ns):
    """The recording's environment against this drive: (problems that make the test meaningless here -> skip, warnings)."""
    rec, skip, warn = plan["recorded"], [], []
    if rec.get("model") and ident["model"] and rec["model"].strip().upper() != ident["model"].strip().upper():
        skip.append("this drive is a %s; the recording is of a %s" % (ident["model"], rec["model"]))
    if rec.get("firmware") and ident["firmware"] != rec["firmware"]:
        warn.append("firmware %s here, %s in the recording" % (ident["firmware"], rec["firmware"]))
    if rec.get("lba_bytes") and ns["lba_bytes"] != rec["lba_bytes"]:
        skip.append("blocks of %d bytes here, %d in the recording: format the namespace with the recorded LBA format first" % (ns["lba_bytes"], rec["lba_bytes"]))
    if plan["oracle_fault"].get("kind") == "deallocate_readback" and rec.get("drb") is not None and ns["drb"] != rec["drb"]:
        skip.append("this namespace declares deallocated blocks read as %s; the recording's drive declared %s" % (ns["drb"], rec["drb"]))
    top = max([lba(plan, (s.get("parameters") or {}).get("slba") or 0) + int((s.get("parameters") or {}).get("nlb") or 0) for s in plan["steps"]] + [0])
    if top >= ns["nsze"]:
        skip.append("the recorded blocks go up to %d; this namespace has %d (set NVME_LBA_OFFSET or use a larger namespace)" % (top, ns["nsze"]))
    return skip, warn


def apply_features(d, plan):
    """The recording's Set Features (except the driver's own) applied and read back; returns what to restore."""
    restore, notes = [], []
    for f in plan["setup"].get("features") or []:
        fid = int(f["fid"])
        if fid in DRIVER_OWNED_FEATURES:
            notes.append("feature 0x%02X is the Linux driver's: compared only" % fid)
            continue
        if f.get("value") is None:
            notes.append("feature 0x%02X: the value is not in the export, so the drive's own value stays" % fid)
            continue
        was = d.admin(0x0A, 0, {10: fid}, 0)
        r = d.admin(0x09, 0, {10: fid, 11: int(f["value"])}, 0)
        if not r.ok:
            raise AssertionError("PRECONDITION NOT MET: Set Features 0x%02X = 0x%X failed: %s" % (fid, int(f["value"]), r.words()))
        now = d.admin(0x0A, 0, {10: fid}, 0)
        if now.dw0 != int(f["value"]):
            raise AssertionError("PRECONDITION NOT MET: feature 0x%02X reads back 0x%X, not 0x%X" % (fid, now.dw0, int(f["value"])))
        restore.append((fid, was.dw0))
    return restore, notes


def prepare_data(d, plan, ns, nonce, gen):
    """The data state before the replay: blocks the replay reads written first, blocks the recording shows deallocated deallocated."""
    lb = ns["lba_bytes"]
    for w in plan["setup"].get("prewrite") or []:
        s, n = lba(plan, w["slba"]), int(w["nlb"])
        for off in range(0, n + 1, 64):
            k = min(64, n + 1 - off)
            data = b"".join(pattern(s + off + i, gen, nonce, lb) for i in range(k))
            r = d.io(0x01, int(w.get("nsid") or d.nsid), _rw_cdw(s + off, k - 1), len(data), data)
            if not r.ok:
                raise AssertionError("PRECONDITION NOT MET: writing blocks %d..%d before the replay failed: %s" % (s + off, s + off + k - 1, r.words()))
    for x in plan["setup"].get("deallocated") or []:
        ranges = [[lba(plan, x["slba"]), int(x["nlb"]) + 1]]
        r = d.io(0x09, int(x.get("nsid") or d.nsid), {10: 0, 11: 4}, 16, dsm_payload(ranges))
        if not r.ok:
            raise AssertionError("PRECONDITION NOT MET: deallocating blocks %s before the replay failed: %s" % (ranges, r.words()))


def run_case(plan, record=None):
    """Replay the plan. EXPECT=fault (default): passes when the recorded fault appears again; EXPECT=fixed: passes only after the
    required number of clean runs. NVME_MEASURE=1 runs every attempt and reports k of n (feed it back to the tool)."""
    import pytest
    expect = env("EXPECT", "fault")
    if expect not in ("fault", "fixed"):
        raise AssertionError("EXPECT must be fault or fixed")
    try:
        d, ident = open_drive(plan, _destructive(plan))
    except Skip as e:
        pytest.skip(str(e))
    rec = {"test_id": plan["id"], "test_version": plan["version"], "library": LIB_VERSION, "expect": expect, "backend": d.kind,
           "drive_model": ident["model"], "drive_firmware": ident["firmware"], "drive_serial": ident["serial"], "attempts": []}
    restore = []
    try:
        ns = identify_namespace(d, d.nsid)
        skip, warn = check_environment(d, plan, ident, ns)
        rec.update(namespace={k: ns[k] for k in ("nsze", "nuse", "lba_bytes", "drb", "thinp", "dae")}, warnings=warn)
        if skip:
            rec["verdict"] = "skipped: " + "; ".join(skip)
            write_result(plan, record, rec)
            pytest.skip("; ".join(skip))
        rec["before"] = snapshot(d, d.nsid)
        restore, notes = apply_features(d, plan)
        rec["setup_notes"] = notes
        known = (plan.get("repeat") or {}).get("known") or {}
        if expect == "fault":
            runs = int(env("NVME_REPEAT", (plan.get("repeat") or {}).get("fault_runs", 10)))
        else:
            need = clean_runs_needed(int(known.get("k") or 0), int(known.get("n") or 0))
            runs = int(env("NVME_REPEAT", need or (plan.get("repeat") or {}).get("fixed_runs_unmeasured", 30)))
            rec["clean_runs_basis"] = ("%d clean runs: the old firmware reproduced the fault %s of %s times (95%% lower bound %.4f)" % (runs, known.get("k"), known.get("n"), lower_bound(int(known["k"]), int(known["n"]))))\
                if need else "%d clean runs: the old firmware's reproduction rate is not measured yet (run EXPECT=fault NVME_MEASURE=1 on it)" % runs
        measure = env("NVME_MEASURE") == "1"
        nonce = random.randrange(1, 60000)
        hits = 0
        for attempt in range(runs):
            gen = attempt + 1
            prepare_data(d, plan, ns, nonce, gen)          # every attempt starts from the same data state
            got, results, fault_res = [], {}, None
            for step in plan["steps"]:
                gap = min(step.get("gap_us", 10) / 1e6, float(env("NVME_MAX_GAP_S", 5)))
                if gap > 0 and d.kind == "real":
                    time.sleep(gap)
                res, what = send_step(d, plan, step, ns["lba_bytes"], nonce, gen)
                results[step["step"]] = res
                got.append({"step": step["step"], "command": what, "result": res.words() if res else "not sent", "seconds": round(res.seconds, 6) if res else None})
                if step["step"] == plan["fault_step"]:
                    fault_res = res
                elif step["step"] < plan["fault_step"] and res is not None and not res.ok and step.get("must_succeed", True):
                    raise AssertionError("PRECONDITION NOT MET: set-up step %d (%s) did not complete normally: %s" % (step["step"], what, res.words()))
            seen, why = fault_seen(plan, fault_res, ns["lba_bytes"], ns["drb"], nonce, gen)
            att = {"attempt": gen, "fault_seen": bool(seen), "why": why, "steps": got}
            if expect == "fixed" and not seen:
                # a correct drive must also give every outcome the admin verified (status and time), from the fault onward
                for exp in plan.get("expected") or []:
                    ok, what = outcome_ok(exp, results.get(exp["step"]))
                    if not ok:
                        seen, att["fault_seen"] = True, True
                        att["expected_failed"] = "step %d: expected %s; got %s" % (exp["step"], exp.get("status") or "success", what)
                        break
            hits += 1 if seen else 0
            rec["attempts"].append(att)
            if seen and (expect == "fixed" or not measure):
                break
        rec["hits"], rec["runs"] = hits, len(rec["attempts"])
        rec["after"] = snapshot(d, d.nsid)
        if rec["before"].get("controller", {}).get("firmware") != rec["after"].get("controller", {}).get("firmware"):
            rec["verdict"] = "invalid: the firmware revision changed during the run"
            write_result(plan, record, rec)
            raise AssertionError(rec["verdict"])
        if expect == "fault":
            rec["verdict"] = ("reproduced %d of %d" % (hits, rec["runs"])) if hits else "not reproduced in %d runs" % rec["runs"]
        else:
            rec["verdict"] = "fault seen again" if hits else "fixed: %d clean runs" % rec["runs"]
        path = write_result(plan, record, rec)
        if expect == "fault":
            assert hits > 0, "FAILED: the recorded fault (%s) did not appear in %d runs; results in %s" % (plan["oracle_fault"].get("words"), rec["runs"], path)
        else:
            last = rec["attempts"][-1] if rec["attempts"] else {}
            assert hits == 0, "FAILED: the fault appears again on run %d (%s); results in %s" % (len(rec["attempts"]), last.get("expected_failed") or last.get("why"), path)
    finally:
        for fid, value in restore:
            d.admin(0x09, 0, {10: fid, 11: value}, 0)
        d.close()


# ------------------------------------------------------------------------------------------------ deallocate check of one base range
def deallocate_check(plan, record=None, base=None, count=None, command="dsm"):
    """The procedure for one range [S, S+N) (NVM Command Set 1.1 sections 3.3.3 and 3.3.8; research report 'Defect replay tests and
    deallocate checks'): probe, guard bands, two pattern generations, deallocate, classify every block twice, guard bands unchanged,
    cross-checks. FAIL only for what the specification forbids; a block the drive kept is 'not deallocated' (allowed: deallocate is advisory)."""
    import pytest
    spec = plan.get("deallocate_range") or {}
    S = int(env("NVME_DEALLOC_SLBA", base if base is not None else spec.get("slba", 0)))
    N = int(env("NVME_DEALLOC_BLOCKS", count if count is not None else spec.get("blocks", 64)))
    G = int(env("NVME_GUARD_BLOCKS", spec.get("guard", 8)))
    command = env("NVME_DEALLOC_COMMAND", spec.get("command", command))
    try:
        d, ident = open_drive(plan, True)
    except Skip as e:
        pytest.skip(str(e))
    rec = {"test_id": plan["id"] + "_deallocate", "test_version": plan["version"], "library": LIB_VERSION, "backend": d.kind, "expect": "spec",
           "drive_model": ident["model"], "drive_firmware": ident["firmware"], "drive_serial": ident["serial"], "range": [S, N], "guard": G, "command": command}
    try:
        ns = identify_namespace(d, d.nsid)
        lim = identify_nvm_limits(d)
        rec["probe"] = {"oncs": ident["oncs"], **lim, **{k: ns[k] for k in ("nsze", "nuse", "lba_bytes", "drb", "wzds", "thinp", "dae")}}
        if command == "dsm" and not ident["oncs"] & 4:
            pytest.skip("this controller does not support Dataset Management (ONCS bit 2 is 0)")
        if command == "write_zeroes" and not ident["oncs"] & 8:
            pytest.skip("this controller does not support Write Zeroes (ONCS bit 3 is 0)")
        if S - G < 0 or S + N + G > ns["nsze"]:
            pytest.skip("the range with its guard bands does not fit in the namespace (%d blocks)" % ns["nsze"])
        if (lim["dmrl"] == 0) != (lim["dmrsl"] == 0):
            rec.setdefault("warnings", []).append("the Dataset Management limits are partly zero (DMRL %s, DMRSL %s): the specification wants all or none" % (lim["dmrl"], lim["dmrsl"]))
        lb, nonce = ns["lba_bytes"], random.randrange(1, 60000)
        lo, hi = S - G, S + N + G

        def write_gen(gen):
            for off in range(lo, hi, 64):
                k = min(64, hi - off)
                data = b"".join(pattern(off + i, gen, nonce, lb) for i in range(k))
                r = d.io(0x01, d.nsid, _rw_cdw(off, k - 1), len(data), data)
                assert r.ok, "PRECONDITION NOT MET: writing blocks %d..%d failed: %s" % (off, off + k - 1, r.words())

        def read_all():
            out = {}
            for off in range(lo, hi, 64):
                k = min(64, hi - off)
                r = d.io(0x02, d.nsid, _rw_cdw(off, k - 1), k * lb)
                assert r.ok, "FAILED: reading blocks %d..%d failed: %s" % (off, off + k - 1, r.words())
                for i in range(k):
                    out[off + i] = r.data[i * lb:(i + 1) * lb]
            return out
        write_gen(1)
        write_gen(2)
        nuse_before = identify_namespace(d, d.nsid)["nuse"]
        if command == "dsm":
            r = d.io(0x09, d.nsid, {10: 0, 11: 4}, 16, dsm_payload([[S, N]]))
        else:
            r = d.io(0x08, d.nsid, _rw_cdw(S, N - 1, {"deac": True}), 0)
        rec["command_status"] = r.words()
        assert r.ok, "FAILED: the %s of blocks %d..%d did not complete: %s" % ("deallocate" if command == "dsm" else "Write Zeroes", S, S + N - 1, r.words())
        first, second = read_all(), None
        d.io(0x02, d.nsid, _rw_cdw(max(0, lo - 64), 0), lb)          # unrelated I/O between the two reads
        second = read_all()
        fails, warns, counts = [], [], {}
        for b in range(lo, hi):
            c1, c2 = classify(first[b], b, [1, 2], nonce), classify(second[b], b, [1, 2], nonce)
            inside = S <= b < S + N
            counts[(inside, c1)] = counts.get((inside, c1), 0) + 1
            if not inside:
                if c1 != "latest" or c2 != "latest":
                    fails.append("guard block %d changed (%s): data outside the listed range must not change" % (b, c1))
                continue
            if c1 == "stale" or c2 == "stale":
                fails.append("block %d returned the OLDER generation: neither the latest data nor the deallocated value" % b)
            elif c1 in ("mixed", "other_lba") or c2 in ("mixed", "other_lba"):
                fails.append("block %d returned %s data" % (b, c1 if c1 in ("mixed", "other_lba") else c2))
            elif command == "write_zeroes" and (c1 != "zeros" or c2 != "zeros"):
                fails.append("block %d is not all zeros after Write Zeroes (%s): a read after Write Zeroes shall return 00h" % (b, c1))
            elif c1 in ("zeros", "ones") and c1 != c2:
                fails.append("block %d changed between two reads with no write (%s, then %s): the deallocated value shall be deterministic" % (b, c1, c2))
            elif c1 == "ones" and ns["drb"] == 1 or c1 == "zeros" and ns["drb"] == 2:
                fails.append("block %d reads %s, but the drive declares deallocated blocks read as %s" % (b, "FFh" if c1 == "ones" else "00h", "00h" if ns["drb"] == 1 else "FFh"))
            elif c1 == "latest" and c2 == "latest":
                if command == "dsm":
                    warns.append(b)                # deallocate is advisory: the drive may keep the data
            elif c1 == "latest" and c2 in ("zeros", "ones"):
                warns.append(b)                    # deallocated in the background between the reads
        nuse_after = identify_namespace(d, d.nsid)["nuse"]
        rec["nuse"] = {"before": nuse_before, "after": nuse_after, "meaningful": ns["thinp"]}
        if ns["thinp"] and not warns and nuse_after > nuse_before:
            fails.append("Namespace Utilization grew (%d -> %d) after a deallocate on a thin-provisioned namespace" % (nuse_before, nuse_after))
        rec["counts"] = {("inside " if k[0] else "guard ") + k[1]: v for k, v in counts.items()}
        rec["not_deallocated"] = len(warns)
        rec["fails"] = fails[:50]
        rec["verdict"] = ("FAIL: " + fails[0]) if fails else ("PASS with warning: %d of %d blocks kept their data (allowed: deallocate is advisory)" % (len(warns), N) if warns else "PASS")
        path = write_result(plan, record, rec)
        assert not fails, "FAILED (%d problems): %s; results in %s" % (len(fails), "; ".join(fails[:5]), path)
    finally:
        d.close()
