"""Replacing and deleting a file that somebody is still reading.

Windows refuses to replace or delete a file while any program has it open: a page that reads a state file at the moment the
load writes its next progress line, a virus scanner or the search indexer looking at a file that was written a moment ago.
The refusal is short-lived, so replace() and remove() try again for a few seconds before they pass the error on.

Linux and macOS never refuse for that reason: there the first try is the only one and nothing changes (RETRY is False).
F2T_FILE_RETRY=1 turns the waiting on elsewhere (tests/windows_like.py does, to run this code on Linux).
"""
import os
import time

RETRY = os.name == "nt" or os.environ.get("F2T_FILE_RETRY") == "1"
WAIT_S = 5.0          # how long to keep trying before the error is passed on


def _again(fn, args, wait):
    if not RETRY:
        return fn(*args)
    end = time.monotonic() + (WAIT_S if wait is None else wait)
    pause = 0.02
    while True:
        try:
            return fn(*args)
        except PermissionError:
            if time.monotonic() >= end:
                raise
            time.sleep(pause)
            pause = min(pause * 2, 0.25)


def replace(src, dst, wait=None):
    """os.replace(src, dst); on Windows it waits (up to WAIT_S seconds) for a reader of either file to close it."""
    return _again(os.replace, (src, dst), wait)


def remove(path, wait=None):
    """os.remove(path); on Windows it waits (up to WAIT_S seconds) for a reader of the file to close it."""
    return _again(os.remove, (path,), wait)


def remove_tree(folder, wait=None):
    """Deletes a folder with everything in it and says whether it is gone. On Windows a file that is still open keeps the folder: tried again
    for a few seconds, then False (the caller says so instead of reporting a delete that did not happen)."""
    import shutil
    shutil.rmtree(folder, ignore_errors=True)
    end = time.monotonic() + (WAIT_S if wait is None else wait)
    while os.path.exists(folder) and time.monotonic() < end:
        time.sleep(0.2)
        shutil.rmtree(folder, ignore_errors=True)
    return not os.path.exists(folder)
