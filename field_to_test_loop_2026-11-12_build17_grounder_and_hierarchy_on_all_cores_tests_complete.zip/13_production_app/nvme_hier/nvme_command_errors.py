"""Every completion status an NVMe command can end with, and how often each one is seen in a loaded recording (2026-11-12).

The owner's request: "what are the different NVMe commands errors that is possible, all those needs to be tracked, except
the timings". So this module holds no time limit at all: a command that is slow, or that never completes, is a matter of
the limits the owner gives, and is only COUNTED here as "no completion status in the recording".

Where the names and values come from: the status tables of the two public specifications, read from the specification
text itself (not from memory) on 12 November 2026:
  - NVM Express Base Specification, Revision 2.1 (ratified 5 August 2024): Figure 101 (status code types), Figure 102
    (generic command status), Figure 103 and Figure 104 (command specific status), Figure 105 (command specific status
    of the NVMe over Fabrics commands), Figure 106 (media and data integrity errors), Figure 107 (path related status);
  - NVM Express NVM Command Set Specification, Revision 1.1 (ratified 5 August 2024): Figure 17, Figure 18, Figure 19
    (the meaning of the values the base specification leaves to the command set, and the commands they belong to).
Only the name, the value and the place in the document are taken from the specification; the short meaning beside each
name is written for this application in plain words. tests/test_nvme_command_errors.py checks every name and value
against the specification text when that text is on the computer (the text itself is not shipped: it is copyrighted).

A status is identified by the pair (status code type, status code): the two fields ST.SCT and ST.SC of the NVMe command
export, kept by the loader in the columns `sct` and `sc` of the table `cmd`. Nothing here is joined by time stamp.
"""
import sqlite3

ADDRESS = "https://nvmexpress.org/specifications/"
BASE = {"document": "NVM Express Base Specification", "revision": "Revision 2.1, ratified 5 August 2024", "address": ADDRESS}
NVM = {"document": "NVM Express NVM Command Set Specification", "revision": "Revision 1.1, ratified 5 August 2024", "address": ADDRESS}

# status code type -> (name as the specification writes it, section of the base specification, figure, plain meaning)
TYPES = [
    (0, 0, "Generic Command Status", "section 4.2.3.1", 102, "Results that many different kinds of command can end with."),
    (1, 1, "Command Specific Status", "section 4.2.3.2", 103, "Results that belong to one particular command or a few commands."),
    (2, 2, "Media and Data Integrity Errors", "section 4.2.3.3", 106, "The storage media or the protection of the data failed."),
    (3, 3, "Path Related Status", "section 4.2.3.4", 107, "The path between the host and the drive's namespace failed, not the command itself."),
    (4, 6, "Reserved", "Figure 101", None, "Status code types the specification keeps for later use: a drive must not send them."),
    (7, 7, "Vendor Specific", "Figure 101", None, "Results the drive's maker defines; their meaning is in the maker's documents, not in the specification."),
]

# The rows: (status code type, first code, last code, name, figure of the base specification, kind, plain meaning, more)
#   kind: "success" = not an error · "error" = one named error · "status" = named, not a failure of the command
#         "range" = a block of values named as a whole (vendor specific, directive specific, ...) · "reserved"
#   more: {"commands": the commands the specification names for it, "set": the I/O command set it belongs to,
#          "also": (figure of the NVM Command Set Specification 1.1 that carries the same value)}
R, G, E, S, OK = "reserved", "range", "error", "status", "success"
_ROWS = [
    # ---- Figure 102: generic command status
    (0, 0x00, 0x00, "Successful Completion", 102, OK, "The command completed without an error.", {}),
    (0, 0x01, 0x01, "Invalid Command Opcode", 102, E, "The command code is reserved or the drive does not support it.", {}),
    (0, 0x02, 0x02, "Invalid Field in Command", 102, E, "A field of the command, other than the command code, holds a reserved or unsupported value.", {}),
    (0, 0x03, 0x03, "Command ID Conflict", 102, E, "The command identifier is already in use by another command.", {}),
    (0, 0x04, 0x04, "Data Transfer Error", 102, E, "Moving the command's data or metadata between the host and the drive failed.", {}),
    (0, 0x05, 0x05, "Commands Aborted due to Power Loss Notification", 102, E, "The drive gave the command up because it was told that power is about to be lost.", {}),
    (0, 0x06, 0x06, "Internal Error", 102, E, "The drive could not complete the command because of an error inside the drive.", {}),
    (0, 0x07, 0x07, "Command Abort Requested", 102, E, "The command was given up because the host sent an Abort or a Cancel command that named it.", {}),
    (0, 0x08, 0x08, "Command Aborted due to SQ Deletion", 102, E, "The command was given up because the host deleted the submission queue it was sent on.", {}),
    (0, 0x09, 0x09, "Command Aborted due to Failed Fused Command", 102, E, "The command was given up because the other command of its fused pair failed.", {}),
    (0, 0x0A, 0x0A, "Command Aborted due to Missing Fused Command", 102, E, "The command was given up because the next queue entry did not hold the other command of its fused pair.", {}),
    (0, 0x0B, 0x0B, "Invalid Namespace or Format", 102, E, "The namespace named in the command, or the format of that namespace, is not valid.", {}),
    (0, 0x0C, 0x0C, "Command Sequence Error", 102, E, "The command broke a rule for a sequence of several commands, for example the order of security send and receive.", {}),
    (0, 0x0D, 0x0D, "Invalid SGL Segment Descriptor", 102, E, "A segment descriptor of the command's scatter gather list (its list of data areas) is not valid.", {}),
    (0, 0x0E, 0x0E, "Invalid Number of SGL Descriptors", 102, E, "A segment descriptor of the scatter gather list is not in the last place of its segment.", {}),
    (0, 0x0F, 0x0F, "Data SGL Length Invalid", 102, E, "The scatter gather list for the data is too short, or longer than the drive accepts.", {}),
    (0, 0x10, 0x10, "Metadata SGL Length Invalid", 102, E, "The scatter gather list for the metadata is too short, or longer than the drive accepts.", {}),
    (0, 0x11, 0x11, "SGL Descriptor Type Invalid", 102, E, "The drive does not support that type of scatter gather list descriptor.", {}),
    (0, 0x12, 0x12, "Invalid Use of Controller Memory Buffer", 102, E, "The command uses the drive's own memory buffer in a way the drive does not support.", {}),
    (0, 0x13, 0x13, "PRP Offset Invalid", 102, E, "The offset inside a physical region page entry (a pointer to the data) is not valid.", {}),
    (0, 0x14, 0x14, "Atomic Write Unit Exceeded", 102, E, "The write is longer than the size the drive can write as one indivisible unit.", {"set": "NVM, ZNS", "also": 17}),
    (0, 0x15, 0x15, "Operation Denied", 102, E, "The command was refused because the sender lacks the access rights.", {}),
    (0, 0x16, 0x16, "SGL Offset Invalid", 102, E, "The offset given in a scatter gather list descriptor is not valid.", {}),
    (0, 0x17, 0x17, "Reserved", 102, R, "Kept by the specification for later use.", {}),
    (0, 0x18, 0x18, "Host Identifier Inconsistent Format", 102, E, "64-bit and 128-bit host identifiers were in use at the same time on different controllers.", {}),
    (0, 0x19, 0x19, "Keep Alive Timer Expired", 102, E, "The keep alive timer between the host and the drive ran out.", {}),
    (0, 0x1A, 0x1A, "Keep Alive Timeout Invalid", 102, E, "The keep alive timeout value the host gave is not valid.", {}),
    (0, 0x1B, 0x1B, "Command Aborted due to Preempt and Abort", 102, E, "The command was given up because of a Reservation Acquire command with the action Preempt and Abort.", {}),
    (0, 0x1C, 0x1C, "Sanitize Failed", 102, E, "The most recent sanitize operation failed and no recovery has succeeded since.", {}),
    (0, 0x1D, 0x1D, "Sanitize In Progress", 102, E, "The command is not allowed while a sanitize operation is running.", {}),
    (0, 0x1E, 0x1E, "SGL Data Block Granularity Invalid", 102, E, "The address alignment or the length of a scatter gather list data block is not one the drive accepts.", {"set": "NVM, ZNS", "also": 17}),
    (0, 0x1F, 0x1F, "Command Not Supported for Queue in CMB", 102, E, "The drive does not support this command on a queue kept in its own memory buffer.", {}),
    (0, 0x20, 0x20, "Namespace is Write Protected", 102, E, "The command would change a namespace that is write protected.", {}),
    (0, 0x21, 0x21, "Command Interrupted", 102, E, "The drive stopped working on the command and could not finish it; the host is expected to send it again.", {}),
    (0, 0x22, 0x22, "Transient Transport Error", 102, E, "A passing error of the transport made the command fail; sending it again may succeed.", {}),
    (0, 0x23, 0x23, "Command Prohibited by Command and Feature Lockdown", 102, E, "The command is blocked by the lockdown setting of the drive.", {}),
    (0, 0x24, 0x24, "Admin Command Media Not Ready", 102, E, "The admin command needs the storage media, and the media is not ready yet.", {}),
    (0, 0x25, 0x25, "Invalid Key Tag", 102, E, "The command was refused because its key tag is not valid.", {"also": 17}),
    (0, 0x26, 0x26, "Host Dispersed Namespace Support Not Enabled", 102, E, "The namespace is a dispersed one and the host has not turned on support for dispersed namespaces.", {}),
    (0, 0x27, 0x27, "Host Identifier Not Initialized", 102, E, "The host identifier has not been set.", {}),
    (0, 0x28, 0x28, "Incorrect Key", 102, E, "The key given with the command is wrong.", {}),
    (0, 0x29, 0x29, "FDP Disabled", 102, E, "The command needs flexible data placement, which is turned off.", {}),
    (0, 0x2A, 0x2A, "Invalid Placement Handle List", 102, E, "The list of placement handles given with the command is not valid.", {}),
    (0, 0x2B, 0x7F, "Reserved", 102, R, "Kept by the specification for later use.", {}),
    (0, 0x80, 0x80, "LBA Out of Range", 102, E, "The command names a logical block address beyond the size of the namespace.", {"set": "NVM, ZNS", "also": 17}),
    (0, 0x81, 0x81, "Capacity Exceeded", 102, E, "The operation would go past the capacity of the namespace.", {"also": 17}),
    (0, 0x82, 0x82, "Namespace Not Ready", 102, E, "The namespace is not ready to be used.", {}),
    (0, 0x83, 0x83, "Reservation Conflict", 102, E, "The command was refused because of a reservation on the namespace.", {}),
    (0, 0x84, 0x84, "Format In Progress", 102, E, "A format operation is running on the namespace.", {}),
    (0, 0x85, 0x85, "Invalid Value Size", 102, E, "Key Value command set: the size of the value is not valid.", {"set": "KV"}),
    (0, 0x86, 0x86, "Invalid Key Size", 102, E, "Key Value command set: the size of the key is not valid.", {"set": "KV"}),
    (0, 0x87, 0x87, "KV Key Does Not Exist", 102, E, "Key Value command set: the key named in the command does not exist.", {"set": "KV"}),
    (0, 0x88, 0x88, "Unrecovered Error", 102, E, "Key Value command set: an error the drive could not recover from.", {"set": "KV"}),
    (0, 0x89, 0x89, "Key Exists", 102, E, "Key Value command set: the key already exists.", {"set": "KV"}),
    (0, 0x90, 0xBF, "Reserved", 102, R, "Kept by the specification for later use.", {}),
    (0, 0xC0, 0xFF, "Vendor Specific", 102, G, "Defined by the drive's maker; the meaning is in the maker's documents.", {}),
    # ---- Figure 103: command specific status (with the commands the specification names)
    (1, 0x00, 0x00, "Completion Queue Invalid", 103, E, "The completion queue named for the new submission queue does not exist.", {"commands": "Create I/O Submission Queue"}),
    (1, 0x01, 0x01, "Invalid Queue Identifier", 103, E, "The queue identifier in the command is not valid.", {"commands": "Create I/O Submission Queue, Create I/O Completion Queue, Delete I/O Completion Queue, Delete I/O Submission Queue"}),
    (1, 0x02, 0x02, "Invalid Queue Size", 103, E, "The queue size asked for is not valid.", {"commands": "Create I/O Submission Queue, Create I/O Completion Queue"}),
    (1, 0x03, 0x03, "Abort Command Limit Exceeded", 103, E, "More Abort commands are waiting than the drive supports.", {"commands": "Abort"}),
    (1, 0x04, 0x04, "Reserved", 103, R, "Kept by the specification for later use.", {}),
    (1, 0x05, 0x05, "Asynchronous Event Request Limit Exceeded", 103, E, "More Asynchronous Event Request commands are waiting than the drive supports.", {"commands": "Asynchronous Event Request"}),
    (1, 0x06, 0x06, "Invalid Firmware Slot", 103, E, "The firmware slot named in the command is not valid.", {"commands": "Firmware Commit"}),
    (1, 0x07, 0x07, "Invalid Firmware Image", 103, E, "The firmware image to be activated is not valid.", {"commands": "Firmware Commit"}),
    (1, 0x08, 0x08, "Invalid Interrupt Vector", 103, E, "The interrupt vector asked for the new completion queue is not valid.", {"commands": "Create I/O Completion Queue"}),
    (1, 0x09, 0x09, "Invalid Log Page", 103, E, "The log page asked for is not valid.", {"commands": "Get Log Page"}),
    (1, 0x0A, 0x0A, "Invalid Format", 103, E, "The format asked for is not valid.", {"commands": "Format NVM, Namespace Management"}),
    (1, 0x0B, 0x0B, "Firmware Activation Requires Conventional Reset", 103, S, "The new firmware starts only after a conventional reset.", {"commands": "Firmware Commit, Sanitize"}),
    (1, 0x0C, 0x0C, "Invalid Queue Deletion", 103, E, "The completion queue cannot be deleted in its present state.", {"commands": "Delete I/O Completion Queue"}),
    (1, 0x0D, 0x0D, "Feature Identifier Not Saveable", 103, E, "The drive cannot save that feature.", {"commands": "Set Features"}),
    (1, 0x0E, 0x0E, "Feature Not Changeable", 103, E, "That feature cannot be changed.", {"commands": "Set Features"}),
    (1, 0x0F, 0x0F, "Feature Not Namespace Specific", 103, E, "That feature is not kept per namespace.", {"commands": "Set Features"}),
    (1, 0x10, 0x10, "Firmware Activation Requires NVM Subsystem Reset", 103, S, "The new firmware starts only after a reset of the whole NVM subsystem.", {"commands": "Firmware Commit, Sanitize"}),
    (1, 0x11, 0x11, "Firmware Activation Requires Controller Level Reset", 103, S, "The new firmware starts only after a reset of the controller.", {"commands": "Firmware Commit, Sanitize"}),
    (1, 0x12, 0x12, "Firmware Activation Requires Maximum Time Violation", 103, E, "Activating the firmware without a reset would take longer than the longest time the drive allows for it.", {"commands": "Firmware Commit"}),
    (1, 0x13, 0x13, "Firmware Activation Prohibited", 103, E, "The drive does not allow that firmware image to be activated.", {"commands": "Firmware Commit"}),
    (1, 0x14, 0x14, "Overlapping Range", 103, E, "Ranges given in the command overlap.", {"commands": "Firmware Commit, Firmware Image Download, Set Features"}),
    (1, 0x15, 0x15, "Namespace Insufficient Capacity", 103, E, "There is not enough free capacity to create the namespace.", {"commands": "Namespace Management"}),
    (1, 0x16, 0x16, "Namespace Identifier Unavailable", 103, E, "No namespace identifier is free for a new namespace.", {"commands": "Namespace Management"}),
    (1, 0x17, 0x17, "Reserved", 103, R, "Kept by the specification for later use.", {}),
    (1, 0x18, 0x18, "Namespace Already Attached", 103, E, "The namespace is already attached to that controller.", {"commands": "Namespace Attachment"}),
    (1, 0x19, 0x19, "Namespace Is Private", 103, E, "The namespace is private and cannot be attached to more than one controller.", {"commands": "Namespace Attachment"}),
    (1, 0x1A, 0x1A, "Namespace Not Attached", 103, E, "The namespace is not attached to that controller.", {"commands": "Namespace Attachment"}),
    (1, 0x1B, 0x1B, "Thin Provisioning Not Supported", 103, E, "The drive does not support thin provisioning.", {"commands": "Namespace Management"}),
    (1, 0x1C, 0x1C, "Controller List Invalid", 103, E, "The list of controllers given with the command is not valid.", {"commands": "Namespace Attachment"}),
    (1, 0x1D, 0x1D, "Device Self-test In Progress", 103, E, "A device self-test is already running.", {"commands": "Device Self-test"}),
    (1, 0x1E, 0x1E, "Boot Partition Write Prohibited", 103, E, "Writing to the boot partition is not allowed.", {"commands": "Firmware Commit"}),
    (1, 0x1F, 0x1F, "Invalid Controller Identifier", 103, E, "The controller identifier in the command is not valid.", {"commands": "Virtualization Management, Track Send, Track Receive, Migration Send, Migration Receive, Controller Data Queue"}),
    (1, 0x20, 0x20, "Invalid Secondary Controller State", 103, E, "The secondary controller is not in a state that allows the action.", {"commands": "Virtualization Management"}),
    (1, 0x21, 0x21, "Invalid Number of Controller Resources", 103, E, "The number of controller resources asked for is not valid.", {"commands": "Virtualization Management"}),
    (1, 0x22, 0x22, "Invalid Resource Identifier", 103, E, "The resource identifier in the command is not valid.", {"commands": "Virtualization Management"}),
    (1, 0x23, 0x23, "Sanitize Prohibited While Persistent Memory Region is Enabled", 103, E, "A sanitize is not allowed while the persistent memory region is turned on.", {"commands": "Sanitize"}),
    (1, 0x24, 0x24, "ANA Group Identifier Invalid", 103, E, "The asymmetric namespace access group identifier is not valid.", {"commands": "Namespace Management"}),
    (1, 0x25, 0x25, "ANA Attach Failed", 103, E, "The namespace could not be attached because of its asymmetric namespace access group.", {"commands": "Namespace Attachment"}),
    (1, 0x26, 0x26, "Insufficient Capacity", 103, E, "There is not enough capacity for the action.", {"commands": "Capacity Management"}),
    (1, 0x27, 0x27, "Namespace Attachment Limit Exceeded", 103, E, "Attaching the namespace would go past the number of attachments allowed.", {"commands": "Namespace Attachment"}),
    (1, 0x28, 0x28, "Prohibition of Command Execution Not Supported", 103, E, "The drive cannot block that command or feature.", {"commands": "Lockdown"}),
    (1, 0x29, 0x29, "I/O Command Set Not Supported", 103, E, "The drive does not support that I/O command set.", {"commands": "Namespace Attachment, Namespace Management"}),
    (1, 0x2A, 0x2A, "I/O Command Set Not Enabled", 103, E, "That I/O command set is not turned on.", {"commands": "Namespace Attachment"}),
    (1, 0x2B, 0x2B, "I/O Command Set Combination Rejected", 103, E, "The drive refused that combination of I/O command sets.", {"commands": "Set Features"}),
    (1, 0x2C, 0x2C, "Invalid I/O Command Set", 103, E, "The I/O command set named in the command is not valid.", {"commands": "Identify"}),
    (1, 0x2D, 0x2D, "Identifier Unavailable", 103, E, "No identifier is free for the action.", {"commands": "Capacity Management"}),
    (1, 0x2E, 0x2E, "Namespace Is Dispersed", 103, E, "Reservations are not allowed on a dispersed namespace.", {"commands": "Reservation Acquire, Reservation Register, Reservation Release, Reservation Report"}),
    (1, 0x2F, 0x2F, "Invalid Discovery Information", 103, E, "The discovery information given is not valid.", {"commands": "Discovery Information Management"}),
    (1, 0x30, 0x30, "Zoning Data Structure Locked", 103, E, "The fabric zoning data structure is locked.", {"commands": "Fabric Zoning Lookup, Fabric Zoning Send, Fabric Zoning Receive"}),
    (1, 0x31, 0x31, "Zoning Data Structure Not Found", 103, E, "The fabric zoning data structure was not found.", {"commands": "Fabric Zoning Lookup, Fabric Zoning Send, Fabric Zoning Receive"}),
    (1, 0x32, 0x32, "Insufficient Discovery Resources", 103, E, "There are not enough resources to keep the discovery information.", {"commands": "Discovery Information Management"}),
    (1, 0x33, 0x33, "Requested Function Disabled", 103, E, "The function asked for is turned off.", {"commands": "Fabric Zoning Lookup, Fabric Zoning Send, Fabric Zoning Receive"}),
    (1, 0x34, 0x34, "ZoneGroup Originator Invalid", 103, E, "The originator of the zone group is not valid.", {"commands": "Fabric Zoning Send"}),
    (1, 0x35, 0x35, "Invalid Host", 103, E, "The host named in the command is not valid.", {"commands": "Manage Exported NVM Subsystem"}),
    (1, 0x36, 0x36, "Invalid NVM Subsystem", 103, E, "The NVM subsystem named in the command is not valid.", {"commands": "Manage Exported NVM Subsystem"}),
    (1, 0x37, 0x37, "Invalid Controller Data Queue", 103, E, "The controller data queue named in the command is not valid.", {"commands": "Set Features, Get Features, Track Send, Controller Data Queue"}),
    (1, 0x38, 0x38, "Not Enough Resources", 103, E, "The drive does not have enough resources for the action.", {"commands": "Track Send, Controller Data Queue"}),
    (1, 0x39, 0x39, "Controller Suspended", 103, E, "The controller is suspended.", {"commands": "Track Send, Sanitize"}),
    (1, 0x3A, 0x3A, "Controller Not Suspended", 103, E, "The controller is not suspended, and the action needs it to be.", {"commands": "Track Send"}),
    (1, 0x3B, 0x3B, "Controller Data Queue Full", 103, E, "The controller data queue is full.", {"commands": "Track Send"}),
    (1, 0x3C, 0x6F, "Reserved", 103, R, "Kept by the specification for later use.", {}),
    (1, 0x70, 0x7F, "Directive Specific", 103, G, "Values that belong to directives (the specification points to its section 8.1.8).", {}),
    # ---- Figure 104: command specific status of the I/O commands (commands taken from NVM Command Set 1.1 Figure 18)
    (1, 0x80, 0x80, "Conflicting Attributes", 104, E, "The attributes given in the command contradict each other.", {"commands": "Dataset Management, Read, Write", "also": 18}),
    (1, 0x81, 0x81, "Invalid Protection Information", 104, E, "The protection information settings of the command do not fit the namespace.", {"commands": "Compare, Copy, Read, Verify, Write, Write Zeroes", "also": 18}),
    (1, 0x82, 0x82, "Attempted Write to Read Only Range", 104, E, "The command tried to write to a range of blocks that is read only.", {"commands": "Copy, Dataset Management, Flush, Format NVM, Write, Write Uncorrectable, Write Zeroes", "also": 18}),
    (1, 0x83, 0x83, "Command Size Limit Exceeded", 104, E, "The command is larger than the size limit of the drive.", {"commands": "Copy, Dataset Management", "also": 18}),
    (1, 0x84, 0x84, "Invalid Command ID", 104, E, "The command identifier given inside the command is not valid (the specification describes it for the Cancel command).", {}),
    (1, 0x85, 0x85, "Incompatible Namespace or Format", 104, E, "The namespaces of the copy, or their formats, do not fit each other.", {"commands": "Copy", "also": 18}),
    (1, 0x86, 0x86, "Fast Copy Not Possible", 104, E, "A fast copy was asked for and the drive cannot do it.", {"commands": "Copy", "also": 18}),
    (1, 0x87, 0x87, "Overlapping I/O Range", 104, E, "The ranges of blocks in the command overlap.", {"commands": "Copy", "also": 18}),
    (1, 0x88, 0x88, "Namespace Not Reachable", 104, E, "A namespace the command needs cannot be reached.", {}),
    (1, 0x89, 0x89, "Insufficient Resources", 104, E, "The drive does not have the resources to do the command now.", {"commands": "Copy", "also": 18}),
    (1, 0x8A, 0x8A, "Insufficient Program Resources", 104, E, "There are not enough resources for the program.", {}),
    (1, 0x8B, 0x8B, "Invalid Memory Namespace", 104, E, "The memory namespace named in the command is not valid.", {}),
    (1, 0x8C, 0x8C, "Invalid Memory Range Set", 104, E, "The set of memory ranges given is not valid.", {}),
    (1, 0x8D, 0x8D, "Invalid Memory Range Set Identifier", 104, E, "The identifier of the set of memory ranges is not valid.", {}),
    (1, 0x8E, 0x8E, "Invalid Program Data", 104, E, "The data of the program is not valid.", {}),
    (1, 0x8F, 0x8F, "Invalid Program Index", 104, E, "The index of the program is not valid.", {}),
    (1, 0x90, 0x90, "Invalid Program Type", 104, E, "The type of the program is not valid.", {}),
    (1, 0x91, 0x91, "Maximum Memory Ranges Exceeded", 104, E, "More memory ranges were given than the drive allows.", {}),
    (1, 0x92, 0x92, "Maximum Memory Range Sets Exceeded", 104, E, "More sets of memory ranges exist than the drive allows.", {}),
    (1, 0x93, 0x93, "Maximum Programs Activated", 104, E, "The largest allowed number of programs is already activated.", {}),
    (1, 0x94, 0x94, "Maximum Program Bytes Exceeded", 104, E, "The program is larger than the number of bytes the drive allows.", {}),
    (1, 0x95, 0x95, "Memory Range Set In Use", 104, E, "The set of memory ranges is in use.", {}),
    (1, 0x96, 0x96, "No Program", 104, E, "There is no program at the place named in the command.", {}),
    (1, 0x97, 0x97, "Overlapping Memory Ranges", 104, E, "The memory ranges given overlap.", {}),
    (1, 0x98, 0x98, "Program Not Activated", 104, E, "The program is not activated.", {}),
    (1, 0x99, 0x99, "Program In Use", 104, E, "The program is in use.", {}),
    (1, 0x9A, 0x9A, "Program Index Not Downloadable", 104, E, "A program cannot be downloaded to that program index.", {}),
    (1, 0x9B, 0x9B, "Program Too Big", 104, E, "The program is too big.", {}),
    (1, 0x9C, 0x9C, "Successful Media Verification Read", 104, S, "A read that was done while the media is being verified; by its name not a failure of the read.", {}),
    (1, 0x9D, 0xB7, "Reserved", 104, R, "Kept by the specification for later use.", {}),
    (1, 0xB8, 0xB8, "Zoned Boundary Error", 104, E, "Zoned namespace: the command crosses the boundary of a zone.", {}),
    (1, 0xB9, 0xB9, "Zone Is Full", 104, E, "Zoned namespace: the zone is full.", {}),
    (1, 0xBA, 0xBA, "Zone Is Read Only", 104, E, "Zoned namespace: the zone is read only.", {}),
    (1, 0xBB, 0xBB, "Zone Is Offline", 104, E, "Zoned namespace: the zone is offline.", {}),
    (1, 0xBC, 0xBC, "Zone Invalid Write", 104, E, "Zoned namespace: the write does not start where the zone must be written next.", {}),
    (1, 0xBD, 0xBD, "Too Many Active Zones", 104, E, "Zoned namespace: the command would make more zones active than allowed.", {}),
    (1, 0xBE, 0xBE, "Too Many Open Zones", 104, E, "Zoned namespace: the command would open more zones than allowed.", {}),
    (1, 0xBF, 0xBF, "Invalid Zone State Transition", 104, E, "Zoned namespace: the zone cannot go from its present state to the state asked for.", {}),
    (1, 0xC0, 0xFF, "Vendor Specific", 103, G, "Defined by the drive's maker; the meaning is in the maker's documents.", {}),
    # ---- Figure 106: media and data integrity errors
    (2, 0x00, 0x7F, "Reserved", 106, R, "Kept by the specification for later use.", {}),
    (2, 0x80, 0x80, "Write Fault", 106, E, "The write to the storage media failed.", {}),
    (2, 0x81, 0x81, "Unrecovered Read Error", 106, E, "The drive could not read the data back from the media, even after its own correction.", {}),
    (2, 0x82, 0x82, "End-to-end Guard Check Error", 106, E, "The guard (checksum) part of the data protection did not match.", {}),
    (2, 0x83, 0x83, "End-to-end Application Tag Check Error", 106, E, "The application tag part of the data protection did not match.", {}),
    (2, 0x84, 0x84, "End-to-end Reference Tag Check Error", 106, E, "The reference tag part of the data protection did not match.", {}),
    (2, 0x85, 0x85, "Compare Failure", 106, E, "A Compare command found that the data on the drive differs from the data sent.", {"set": "NVM", "also": 19}),
    (2, 0x86, 0x86, "Access Denied", 106, E, "Access to the data was refused for lack of access rights.", {}),
    (2, 0x87, 0x87, "Deallocated or Unwritten Logical Block", 106, E, "The command tried to copy, read or verify a block that is deallocated or was never written.", {"set": "NVM", "also": 19}),
    (2, 0x88, 0x88, "End-to-End Storage Tag Check Error", 106, E, "The storage tag part of the data protection did not match.", {}),
    (2, 0x89, 0xBF, "Reserved", 106, R, "Kept by the specification for later use.", {}),
    (2, 0xC0, 0xFF, "Vendor Specific", 106, G, "Defined by the drive's maker; the meaning is in the maker's documents.", {}),
    # ---- Figure 107: path related status
    (3, 0x00, 0x00, "Internal Path Error", 107, E, "An error inside the drive, specific to the controller the command was sent to, kept the command from completing.", {}),
    (3, 0x01, 0x01, "Asymmetric Access Persistent Loss", 107, E, "The path to the namespace through this controller is lost for good.", {}),
    (3, 0x02, 0x02, "Asymmetric Access Inaccessible", 107, E, "The namespace cannot be reached through this controller now.", {}),
    (3, 0x03, 0x03, "Asymmetric Access Transition", 107, E, "The access state of the path to the namespace is changing.", {}),
    (3, 0x04, 0x5F, "Reserved", 107, R, "Kept by the specification for later use.", {}),
    (3, 0x60, 0x60, "Controller Pathing Error", 107, E, "The controller found an error of the path between itself and the host.", {}),
    (3, 0x61, 0x6F, "Reserved", 107, R, "Kept by the specification for later use.", {}),
    (3, 0x70, 0x70, "Host Pathing Error", 107, E, "The host found an error of the path between itself and the controller.", {}),
    (3, 0x71, 0x71, "Command Aborted By Host", 107, E, "The host gave the command up itself (a status the host writes, not the drive).", {}),
    (3, 0x72, 0x7F, "Reserved", 107, R, "Kept by the specification for later use.", {}),
    (3, 0x80, 0xBF, "I/O Command Set Specific", 107, G, "Values left to the I/O command set.", {}),
    (3, 0xC0, 0xFF, "Vendor Specific", 107, G, "Defined by the drive's maker; the meaning is in the maker's documents.", {}),
    # ---- Figure 101: the status code types that have no table of their own (every code of the type is one entry)
    (4, 0x00, 0xFF, "Reserved", 101, R, "A status code type kept by the specification for later use: a drive must not send it.", {}),
    (5, 0x00, 0xFF, "Reserved", 101, R, "A status code type kept by the specification for later use: a drive must not send it.", {}),
    (6, 0x00, 0xFF, "Reserved", 101, R, "A status code type kept by the specification for later use: a drive must not send it.", {}),
    (7, 0x00, 0xFF, "Vendor Specific", 101, G, "Every code of this type is defined by the drive's maker; the meaning is in the maker's documents.", {}),
]
# Generic command status 8Ah to 8Fh: Figure 102 of the specification text names 89h and then "90h to BFh Reserved", so
# these six values are in no row of the table; a command that ends with one of them is shown as "not in the catalogue".

# Figure 105: the same status code type 1h, values 80h and above, when the command is an NVMe over Fabrics command. A
# recording of a PCIe link holds no such command, so these are listed for completeness and never counted.
_FABRICS = [
    (1, 0x80, 0x80, "Incompatible Format", 105, E, "The drive does not support the format of the NVMe over Fabrics command.", {}),
    (1, 0x81, 0x81, "Controller Busy", 105, E, "The controller is busy and cannot take the connection now.", {}),
    (1, 0x82, 0x82, "Connect Invalid Parameters", 105, E, "The parameters of the Connect command are not valid.", {"commands": "Connect"}),
    (1, 0x83, 0x83, "Connect Restart Discovery", 105, E, "The NVM subsystem asked for is not available; the host should start discovery again.", {"commands": "Connect"}),
    (1, 0x84, 0x84, "Connect Invalid Host", 105, E, "The host is not allowed to connect.", {"commands": "Connect"}),
    (1, 0x85, 0x85, "Invalid Queue Type", 105, E, "The command was sent on the wrong type of queue.", {"commands": "Disconnect"}),
    (1, 0x86, 0x8F, "Reserved", 105, R, "Kept by the specification for later use.", {}),
    (1, 0x90, 0x90, "Discover Restart", 105, E, "The discovery records are out of date; the log page must be read again.", {"commands": "Get Log Page"}),
    (1, 0x91, 0x91, "Authentication Required", 105, E, "The queue has not been authenticated yet.", {}),
    (1, 0x92, 0xAF, "Reserved", 105, R, "Kept by the specification for later use.", {}),
    (1, 0xB0, 0xBF, "Transport Specific", 105, G, "Values left to the transport.", {}),
]

KIND_WORDS = {OK: "not an error", E: "an error", S: "a named result that is not a failure of the command",
              G: "a block of values named as a whole", R: "kept for later use: a drive must not send it"}
NOT_HERE = ("Time limits are not on this page: a command that is slow, or that never completes, is judged with the "
            "limits the owner gives. They are typed on the hierarchy page of a recording, under \"Time limits per level\" "
            "(row \"NVMe command\"), and the rule \"NVMe command timeout\" uses them on its next run.")


def hexa(v, width=2):
    return ("%0" + str(width) + "X") % v + "h"


def _where(fig, more):
    w = "%s, %s, Figure %d" % (BASE["document"], BASE["revision"], fig)
    if more.get("also"):
        w += "; %s, %s, Figure %d" % (NVM["document"], NVM["revision"], more["also"])
    return w


def _entry(row, scope):
    sct, lo, hi, name, fig, kind, meaning, more = row
    t = type_of(sct)
    return {"type": sct, "type_hex": hexa(sct, 1), "type_name": t["name"], "code": lo, "code_to": hi,
            "code_hex": hexa(lo) if lo == hi else "%s to %s" % (hexa(lo), hexa(hi)), "name": name, "kind": kind,
            "kind_words": KIND_WORDS[kind], "meaning": meaning, "figure": fig, "nvm_figure": more.get("also"),
            "commands": more.get("commands"), "command_set": more.get("set"), "where": _where(fig, more),
            "address": ADDRESS, "scope": scope, "confirmed": True}


def types():
    out = []
    for lo, hi, name, section, fig, meaning in TYPES:
        out.append({"type": lo, "type_to": hi, "type_hex": hexa(lo, 1) if lo == hi else "%s to %s" % (hexa(lo, 1), hexa(hi, 1)),
                    "name": name, "meaning": meaning, "figure": fig,
                    "where": "%s, %s, Figure 101%s" % (BASE["document"], BASE["revision"], "" if section.startswith("Figure") else " and " + section),
                    "address": ADDRESS})
    return out


def type_of(sct):
    for lo, hi, name, section, fig, meaning in TYPES:
        if lo <= sct <= hi:
            return {"type": lo, "name": name, "meaning": meaning}
    return {"type": sct, "name": None, "meaning": None}


def catalogue(fabrics=True):
    """Every entry, in the order of the specification's tables. `scope` "pcie" = can be met in a PCIe recording and is
    counted; "fabrics" = only for NVMe over Fabrics commands, listed and never counted."""
    out = [_entry(r, "pcie") for r in _ROWS]
    if fabrics:
        out += [_entry(r, "fabrics") for r in _FABRICS]
    return out


_EXACT, _RANGES = {}, []
for _r in _ROWS:
    if _r[1] == _r[2]:
        _EXACT[(_r[0], _r[1])] = _r
    else:
        _RANGES.append(_r)


def lookup(sct, sc):
    """The catalogue entry of one status (type, code), or None when the specification's tables do not hold it."""
    try:
        sct, sc = int(sct), int(sc)
    except (TypeError, ValueError):
        return None
    r = _EXACT.get((sct, sc))
    if r is None:
        for x in _RANGES:
            if x[0] == sct and x[1] <= sc <= x[2]:
                r = x
                break
    return _entry(r, "pcie") if r is not None else None


def key(e):
    return "%d:%d:%d" % (e["type"], e["code"], e["code_to"])


COUNT_SQL = "SELECT sct, sc, COUNT(*), MIN(n), MIN(rowid_file) FROM cmd GROUP BY sct, sc"


def count(db):
    """How many commands of one loaded recording completed with each status. `db` is the path of the recording's staging
    database (uploads/<upload>/hier.sqlite) or an open connection to it. One grouped pass over the command table, done
    by the database (the rows never come into memory); the status is read from the command's own row (ST.SCT, ST.SC):
    no join, no time stamp. A status the catalogue does not hold is never dropped: it comes back in `not_in_catalogue`.
    """
    own = isinstance(db, str)
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True) if own else db
    try:
        rows = list(con.execute(COUNT_SQL))      # one row per different status: at most a few hundred
    finally:
        if own:
            con.close()
    seen, unknown, total, no_status, success, errors = {}, [], 0, 0, 0, 0
    for sct, sc, n, first_n, first_row in rows:
        total += n
        if sct is None or sc is None:
            if sct is None and sc is None:
                no_status += n
            else:
                unknown.append({"type": sct, "code": sc, "commands": n, "first_command": first_n,
                                "why": "only one of the two status fields is filled in the recording"})
            continue
        e = lookup(sct, sc)
        if e is None:
            unknown.append({"type": sct, "code": sc, "type_hex": hexa(sct, 1) if isinstance(sct, int) and sct >= 0 else str(sct),
                            "code_hex": hexa(sc) if isinstance(sc, int) and sc >= 0 else str(sc), "commands": n, "first_command": first_n,
                            "type_name": type_of(sct)["name"] if isinstance(sct, int) else None,
                            "why": "this pair of status code type and status code is not in the specification's tables"})
            errors += n
            continue
        k = key(e)
        got = seen.setdefault(k, {"key": k, "commands": 0, "first_command": first_n, "codes": []})
        got["commands"] += n
        got["codes"].append({"code_hex": hexa(sc), "commands": n, "first_command": first_n})
        if first_n is not None and (got["first_command"] is None or first_n < got["first_command"]):
            got["first_command"] = first_n
        if e["kind"] == OK:
            success += n
        else:
            errors += n
    return {"commands": total, "successful": success, "with_another_status": errors, "no_status": no_status,
            "seen": seen, "not_in_catalogue": sorted(unknown, key=lambda u: -u["commands"]),
            "source": "counted from the columns ST.SCT (status code type) and ST.SC (status code) of the NVMe command export of this recording",
            "no_status_words": "commands with no completion status in the recording (the recording ended first, or the command was never answered); "
                               "whether that is a timeout depends on the time limit the owner gives"}


def summary():
    c = catalogue()
    kinds = {}
    for e in c:
        kinds[e["kind"]] = kinds.get(e["kind"], 0) + 1
    return {"entries": len(c), "named_errors": sum(1 for e in c if e["kind"] == E), "kinds": kinds,
            "documents": [BASE, NVM], "not_here": NOT_HERE,
            "how_checked": "names and values read from the text of the two specifications on 12 November 2026; the short meanings are written for this application"}
