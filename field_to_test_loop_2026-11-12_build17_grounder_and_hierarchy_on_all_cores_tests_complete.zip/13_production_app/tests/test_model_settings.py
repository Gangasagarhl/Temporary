"""The model connection is set on the Settings page and used by every part (owner, 2026-11-11: "it should not depend solely on my API
key ... I open the settings from run_app.py and change the model name, the URL and the API key, so that everything works properly").

* the key saved on the page wins at start over a key the computer's environment already holds (run_app.py -> model_env.load);
* a key under another variable name (llm.api_key_env) is what every caller reads (ANTHROPIC_API_KEY);
* the page is told only the key's last 4 characters and where it came from, never the key;
* the agents follow the connection's model name and URL at once, without a restart.
Every test here works on its own key file in a temporary folder; the real one is never read or written."""
import os
import shutil
import sys
import tempfile

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

NAMES = ("ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", "COMPANY_KEY")


@pytest.fixture
def env():
    was = {k: os.environ.get(k) for k in NAMES}
    d = tempfile.mkdtemp(prefix="model_env_%d_" % os.getpid())
    try:
        yield d
    finally:
        for k, v in was.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        shutil.rmtree(d, ignore_errors=True)


def test_the_saved_key_wins_over_the_environment_and_junk_lines_are_ignored(env):
    import model_env as ME
    f = os.path.join(env, "env")
    open(f, "w").write("# saved by the Settings page\nnot a setting at all\nexport ANTHROPIC_API_KEY='theirs-key-0000000000ABCD'\nBAD NAME=1\n=x\n")
    assert ME.read_env_file(f) == {"ANTHROPIC_API_KEY": "theirs-key-0000000000ABCD"}
    os.environ["ANTHROPIC_API_KEY"] = "mine-key-11111111111WXYZ"                 # the developer's key, inherited
    src = ME.load({"llm": {"base_url": "https://gateway.example.test", "model": "m"}}, f)
    assert os.environ["ANTHROPIC_API_KEY"] == "theirs-key-0000000000ABCD"
    assert os.environ["ANTHROPIC_BASE_URL"] == "https://gateway.example.test"
    assert src == {"present": True, "end": "ABCD", "source": "saved on the Settings page"}


def test_a_key_under_its_own_variable_is_what_every_caller_reads(env):
    import model_env as ME
    f = os.path.join(env, "env")
    open(f, "w").write("COMPANY_KEY=company-key-22222222222QRST\n")
    os.environ["ANTHROPIC_API_KEY"] = "mine-key-11111111111WXYZ"
    ME.load({"llm": {"api_key_env": "COMPANY_KEY"}}, f)
    assert os.environ["COMPANY_KEY"] == os.environ["ANTHROPIC_API_KEY"] == "company-key-22222222222QRST"
    os.environ["COMPANY_KEY"] = "company-key-33333333333LMNO"                    # set by a service's environment file instead
    ME.apply({"llm": {"api_key_env": "COMPANY_KEY"}})
    assert os.environ["ANTHROPIC_API_KEY"] == "company-key-33333333333LMNO"
    assert ME.source({"llm": {"api_key_env": "COMPANY_KEY"}}, f)["source"].startswith("from this computer's environment")


def test_no_key_says_so(env):
    import model_env as ME
    for k in NAMES:
        os.environ.pop(k, None)
    assert ME.source({"llm": {}}, os.path.join(env, "missing"))["present"] is False


def test_the_settings_page_sets_url_model_and_key_for_every_part_at_once(env):
    import fuzz_app as F
    from api import agentic_api as A
    from api import hier_api as H
    if not os.path.isdir(F.BASE):
        pytest.skip("the S08 sample recording is not on this machine (the code-only zip carries no samples)")
    root = os.path.join(env, "app")
    os.makedirs(root)
    app, c, _k, _r = F.setup(root)
    s = app.config["services"]
    s.cfg.setdefault("llm", {})["backend"] = "http"
    s.cfg.setdefault("agentic", {})["model"] = ""                               # the agents follow the connection's model
    assert H.ENV_FILE.startswith(root)                                           # never the real key file
    with app.app_context():
        A.engine()                                                               # the agents' engine exists before the change
    r = c.put("/api/hier/model", json={"base_url": "http://127.0.0.1:9", "model": "company-model-1", "key": "sk-test-key-abcdefgh1234"})
    assert r.status_code == 200, r.get_json()
    m = r.get_json()
    assert (m["base_url"], m["model"], m["key_present"], m["key_end"], m["key_source"]) == (
        "http://127.0.0.1:9", "company-model-1", True, "1234", "saved on the Settings page")
    assert "sk-test-key-abcdefgh1234" not in r.get_data(as_text=True)              # the key is never sent back
    assert os.environ["ANTHROPIC_API_KEY"] == "sk-test-key-abcdefgh1234" and os.environ["ANTHROPIC_BASE_URL"] == "http://127.0.0.1:9"
    assert "sk-test-key-abcdefgh1234" in open(H.ENV_FILE).read() and "sk-test-key" not in open(os.path.join(root, "config", "app_config.json")).read()
    eng = s.agentic_engine
    assert eng.runner.http_model == "company-model-1" and eng.runner.model == "company-model-1"
    assert c.get("/api/hier/model").get_json()["agents_model"] == "company-model-1"


class _FakeModel:
    """A stand-in Messages API on this computer: it records the address, the key and the model of every call it gets."""

    def __init__(self, status=200, reject_tools=False, brotli=None):
        import json as _json
        import threading
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
        seen = self.seen = []
        offered = self.offered = []                # per call: the compression the caller offered and the one the answer went out in

        class H(BaseHTTPRequestHandler):
            def do_POST(self):
                n = int(self.headers.get("content-length") or 0)
                body = _json.loads(self.rfile.read(n) or b"{}")
                offers = self.headers.get("accept-encoding") or ""
                seen.append({"path": self.path, "key": self.headers.get("x-api-key"), "model": body.get("model")})
                offered.append({"model": body.get("model"), "offers": offers, "sent": "plain"})
                if status != 200 or (reject_tools and body.get("tools")):
                    code = status if status != 200 else 400
                    data = _json.dumps({"type": "error", "error": {"type": "x", "message": "payment required" if code == 402 else "tools are not offered here"}}).encode()
                    self.send_response(code)
                    self.send_header("content-type", "application/json")
                    self.send_header("content-length", str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                    return
                data = _json.dumps({"id": "msg_test", "type": "message", "role": "assistant", "model": body.get("model"),
                                    "content": [{"type": "text", "text": '{"ok": "yes"}'}], "stop_reason": "end_turn",
                                    "usage": {"input_tokens": 1, "output_tokens": 1}}).encode()
                self.send_response(200)
                self.send_header("content-type", "application/json")
                if brotli is not None and "br" in [x.strip() for x in offers.split(",")]:    # as the real service does
                    data = brotli.compress(data)
                    self.send_header("content-encoding", "br")
                    offered[-1]["sent"] = "br"
                self.send_header("content-length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def log_message(self, *a):
                pass

        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = "http://127.0.0.1:%d" % self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def close(self):
        self.srv.shutdown()


def test_a_change_in_settings_reaches_every_part_without_a_restart(env, monkeypatch):
    """Owner, 2026-11-11: "every time the API and the model change ... properly test that everything works". Two stand-in model
    servers: the Settings page points at the first, then at the second; every part must follow at once, and a restart keeps it."""
    import json as _json
    import types
    import fuzz_app as F
    import model_env as ME
    from agentic import core
    from api import agentic_api as A
    from api import hier_api as H
    from api import isolate_api as I
    import stage1_runner
    if not os.path.isdir(F.BASE):
        pytest.skip("the S08 sample recording is not on this machine (the code-only zip carries no samples)")
    root = os.path.join(env, "app")
    os.makedirs(root)
    app, c, _k, _r = F.setup(root)
    s = app.config["services"]
    s.cfg.setdefault("llm", {})["backend"] = "http"
    s.cfg.setdefault("agentic", {}).update(model="", runtime="http")
    one, two = _FakeModel(), _FakeModel()
    try:
        with app.app_context():
            eng = A.engine()
        eng.runner.runtime = "http"
        after_one = None
        for fake, model, key in ((one, "company-model-1", "sk-test-key-one-00001111"), (two, "company-model-2", "sk-test-key-two-22223333")):
            r = c.put("/api/hier/model", json={"base_url": fake.url, "model": model, "key": key})
            assert r.status_code == 200, r.get_json()
            t = c.post("/api/hier/model/test").get_json()
            # the button's two checks: the model connection (stage 1 and 2, the error pages) and the agents
            assert t["ok"] is True and t["agents"]["ok"] is True, t
            assert len(fake.seen) >= 2 and all(x == {"path": "/v1/messages", "key": key, "model": model} for x in fake.seen), fake.seen
            # the error pages use the same model object
            with app.test_request_context("/"):
                assert I._llm(s, {}).model == model
            # Claude Code, when it runs the agents, is started with this model and inherits this key and address
            got = {}

            def fake_run(cmd, **kw):
                got.update(cmd=cmd, key=os.environ.get("ANTHROPIC_API_KEY"), url=os.environ.get("ANTHROPIC_BASE_URL"))
                return types.SimpleNamespace(returncode=0, stdout=_json.dumps({"result": '{"ok": "yes"}'}), stderr="")
            monkeypatch.setattr(core.AgentRunner, "_run_cli", lambda self, cmd, prompt, cwd, timeout, env, _f=fake_run: _f(cmd, input=prompt, cwd=cwd, timeout=timeout, env=env))   # Claude Code is started through _run_cli (Stop can end it)
            monkeypatch.setattr(core.AgentRunner, "find_claude", staticmethod(lambda configured=None: "/usr/bin/claude"))
            assert eng.runner._claude_code("x", env) == {"ok": "yes"}
            assert got["cmd"][got["cmd"].index("--model") + 1] == model and got["key"] == key and got["url"] == fake.url
            monkeypatch.undo()
            # stage 1 (the analyser's review) uses the same connection through the Anthropic package
            pytest.importorskip("anthropic")
            assert stage1_runner.llm_backend(s.cfg["llm"]) == "sdk"
            if fake is one:
                after_one = len(one.seen)
        assert after_one >= 2 and len(one.seen) == after_one          # after the switch nothing more went to the first server
        # a restart: the key saved on the page is loaded and wins over a key someone else left in the environment
        os.environ["ANTHROPIC_API_KEY"] = "someone-elses-key-99999999"
        ME.load(s.cfg, H.ENV_FILE)
        assert os.environ["ANTHROPIC_API_KEY"] == "sk-test-key-two-22223333" and os.environ["ANTHROPIC_BASE_URL"] == two.url
    finally:
        one.close()
        two.close()


def test_a_url_is_kept_in_one_form():
    import model_env as ME
    for typed, kept in (("", ""), ("  ", ""), ("gateway.company.com", "https://gateway.company.com"), ("https://gateway.company.com/", "https://gateway.company.com"),
                        ("https://gateway.company.com/v1", "https://gateway.company.com"), ("https://gateway.company.com/v1/messages/", "https://gateway.company.com"),
                        ("http://10.0.0.5:8080/llm/v1", "http://10.0.0.5:8080/llm"), ("HTTPS://GW.example/anthropic", "HTTPS://GW.example/anthropic")):
        assert ME.normal_url(typed) == kept, (typed, ME.normal_url(typed))


def test_with_a_company_url_every_call_goes_there_and_never_to_claude_code(env, monkeypatch):
    """Owner, 2026-11-11: "why is it logging into Anthropic again and again? It has to go to the URL I gave". With a URL of its own the
    agents use the Model connection (Claude Code, with its own Anthropic login, is not started); a web-search call the address refuses
    is made again without web search; the test names the address it called and what an error means."""
    import fuzz_app as F
    from agentic import core
    from api import agentic_api as A
    if not os.path.isdir(F.BASE):
        pytest.skip("the S08 sample recording is not on this machine (the code-only zip carries no samples)")
    root = os.path.join(env, "app")
    os.makedirs(root)
    app, c, _k, _r = F.setup(root)
    s = app.config["services"]
    s.cfg.setdefault("llm", {})["backend"] = "http"
    s.cfg.setdefault("agentic", {}).update(model="", runtime="claude-code")
    gw, broke = _FakeModel(reject_tools=True), _FakeModel(status=402)
    try:
        with app.app_context():
            eng = A.engine()
        eng.runner.runtime = "claude-code"
        eng.runner.web_enabled = True                                              # the admin allows web search
        r = c.put("/api/hier/model", json={"base_url": gw.url + "/v1/", "model": "company-model-1", "key": "sk-company-key-abcd5678"})
        assert r.get_json()["base_url"] == gw.url                                  # kept without /v1
        def no_claude(*a, **k):
            raise AssertionError("Claude Code must not be started with a company URL")
        monkeypatch.setattr(core.AgentRunner, "_run_cli", lambda self, cmd, prompt, cwd, timeout, env, _f=no_claude: _f(cmd, input=prompt, cwd=cwd, timeout=timeout, env=env))   # Claude Code is started through _run_cli (Stop can end it)
        ans, producer, _box = eng.runner.ask(1, "Grounder", "say ok", {}, '{"ok": "yes"}', "ok", lambda: {"ok": "stand-in"})
        assert ans == {"ok": "yes"} and "stand-in" not in producer
        ans, producer, _box = eng.runner.ask(1, "Grounder", "say ok", {}, '{"ok": "yes"}', "ok", lambda: {"ok": "stand-in"}, web=True)
        assert ans == {"ok": "yes"} and "did not take web search" in producer
        assert gw.seen and all(x["path"] == "/v1/messages" and x["key"] == "sk-company-key-abcd5678" and x["model"] == "company-model-1" for x in gw.seen)
        t = c.post("/api/hier/model/test").get_json()
        assert t["ok"] and t["agents"]["ok"] and t["address"] == gw.url + "/v1/messages", t
        assert "with your URL the agents use the Model connection" in t["agents"]["words"]
        monkeypatch.undo()
        c.put("/api/hier/model", json={"base_url": broke.url})                      # an account without credit
        t = c.post("/api/hier/model/test").get_json()
        assert t["ok"] is False and "HTTP 402" in t["error"] and t["hint"].startswith("payment required"), t
        assert t["agents"]["ok"] is False and t["agents"]["hint"].startswith("payment required"), t["agents"]
    finally:
        gw.close()
        broke.close()


def test_claude_code_is_started_without_its_background_traffic(env, monkeypatch):
    import json as _json
    import types
    from agentic import core
    got = {}

    def fake_run(cmd, **kw):
        got.update(kw)
        return types.SimpleNamespace(returncode=0, stdout=_json.dumps({"result": '{"ok": "yes"}'}), stderr="")
    monkeypatch.setattr(core.AgentRunner, "_run_cli", lambda self, cmd, prompt, cwd, timeout, env, _f=fake_run: _f(cmd, input=prompt, cwd=cwd, timeout=timeout, env=env))   # Claude Code is started through _run_cli (Stop can end it)
    monkeypatch.setattr(core.AgentRunner, "find_claude", staticmethod(lambda configured=None: "/usr/bin/claude"))
    r = core.AgentRunner(env, runtime="claude-code", model="m")
    assert r._claude_code("x", env) == {"ok": "yes"}
    assert got["env"]["CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC"] == "1"


def test_nothing_goes_anywhere_but_the_settings_url_and_the_key_stays_in_its_file(env, monkeypatch):
    """Owner, 2026-11-11: "if I change the URL, the API key, the model, it has to be applied in the whole application ... make sure
    nothing is leaking the data". Every network connection the application opens is recorded while every part is used with a
    company URL: stage 2, the error page's isolation, the agents (with web search allowed), stage 1's client and the Settings test.
    Every connection must go to that URL, and the key must not be written anywhere but the private key file."""
    import socket
    import fuzz_app as F
    from api import agentic_api as A
    from api import hier_api as H
    import test_isolation_window as W
    if not os.path.isdir(F.BASE):
        pytest.skip("the S08 sample recording is not on this machine (the code-only zip carries no samples)")
    root = os.path.join(env, "app")
    os.makedirs(root)
    app, c, _k, _r = F.setup(root)
    s = app.config["services"]
    s.cfg.setdefault("llm", {})["backend"] = "http"
    s.cfg.setdefault("agentic", {}).update(model="", runtime="claude-code")
    gw = _FakeModel(reject_tools=True)
    key = "sk-company-secret-key-LEAKCHECK-7788"
    went = []
    real_connect = socket.socket.connect

    def watch(self, address):
        if isinstance(address, tuple):
            went.append((address[0], address[1]))
        return real_connect(self, address)
    try:
        with app.app_context():
            eng = A.engine()
        eng.runner.runtime, eng.runner.web_enabled = "claude-code", True
        assert c.put("/api/hier/model", json={"base_url": gw.url, "model": "company-model-1", "key": key}).status_code == 200
        monkeypatch.setattr(socket.socket, "connect", watch)
        assert c.post("/api/hier/model/test").get_json()["ok"] is True                       # the Settings test, both parts
        s.s2.llm.generate_json("say ok (leak check)", {"type": "object", "properties": {"ok": {"type": "string"}}, "required": ["ok"]})   # stage 2
        eng.runner.ask(1, "Grounder", "say ok", {}, '{"ok": "yes"}', "ok", lambda: {"ok": "stand-in"}, web=True)                       # the agents
        fid = W._first_finding(app)
        c.post("/api/isolate/up-fuzz/%d/isolate" % fid, json={"anyway": True, "isolation": True, "name": "t"})                          # an error page
        try:
            import anthropic                                                                  # stage 1's client takes the same address
            anthropic.Anthropic(max_retries=0).messages.create(model="company-model-1", max_tokens=16, messages=[{"role": "user", "content": "ok"}])
        except ImportError:
            pass
        monkeypatch.undo()
        port = int(gw.url.rsplit(":", 1)[1])
        assert went and all(p == port and h in ("127.0.0.1", "localhost", "::1") for h, p in went), sorted(set(went))
        assert len(gw.seen) >= 4 and all(x["key"] == key and x["model"] == "company-model-1" for x in gw.seen), gw.seen
        # the key is in its private file only: not in the configuration, the answer cache, the runs or anything else the app wrote
        found = []
        for d, _ds, fs in os.walk(root):
            for f in fs:
                p = os.path.join(d, f)
                if os.path.abspath(p) == os.path.abspath(H.ENV_FILE):
                    continue
                try:
                    if key.encode() in open(p, "rb").read():
                        found.append(os.path.relpath(p, root))
                except OSError:
                    pass
        assert found == [], found
    finally:
        gw.close()


def test_the_packaged_client_offers_only_the_compression_python_reads_by_itself(env):
    """2026-11-12: the service answers in the compression the client offers. Beside an older brotli package the Anthropic package
    could not read the brotli answers, and every stage-1 call ended as "Connection error." although the network was fine. Stage 1
    and stage 2 offer gzip and deflate only (Python reads both by itself), and a failure's text carries its cause. The stand-in
    service here answers in brotli whenever brotli is offered, as the real one does."""
    anthropic = pytest.importorskip("anthropic")
    for p in (os.path.join(APP, "stage1"), os.path.join(APP, "stage2")):
        if p not in sys.path:
            sys.path.insert(0, p)
    from pcie_isolate import llm as S1
    import llm_adapter as S2
    try:
        import brotli
    except ImportError:
        brotli = None                                                            # then the stand-in can only answer plainly
    gw = _FakeModel(brotli=brotli)
    schema = {"type": "object", "properties": {"ok": {"type": "string"}}, "required": ["ok"], "additionalProperties": False}
    try:
        os.environ["ANTHROPIC_API_KEY"], os.environ["ANTHROPIC_BASE_URL"] = "sk-test-key-abcdefgh1234", gw.url
        r = S1.sdk_client(max_retries=0).messages.create(model="m1", max_tokens=16, messages=[{"role": "user", "content": "ok"}])
        assert r.content[0].text == '{"ok": "yes"}'                             # stage 1: read in full
        assert S2.AnthropicLLM(model="m2", backend="sdk")._sdk("say ok", schema, False) == {"ok": "yes"}     # stage 2: read in full
        assert [(x["model"], x["offers"], x["sent"]) for x in gw.offered] == [("m1", "gzip, deflate", "plain"), ("m2", "gzip, deflate", "plain")], gw.offered
        if brotli is not None:                                                   # the stand-in really does what the fault needs:
            try:                                                                 # a client left as the package makes it is answered in brotli
                anthropic.Anthropic(max_retries=0).messages.create(model="m3", max_tokens=16, messages=[{"role": "user", "content": "ok"}])
            except anthropic.APIConnectionError as e:                            # on a machine with the older brotli this is the fault itself
                assert "cause: " in S1.failure_text(e), S1.failure_text(e)
            assert gw.offered[-1]["model"] == "m3" and gw.offered[-1]["sent"] == "br", gw.offered[-1]
    finally:
        gw.close()

    class Outer(Exception):
        pass
    try:
        try:
            raise TypeError("process() takes no keyword arguments")
        except TypeError as c:
            raise Outer("Connection error.") from c
    except Outer as e:
        assert S1.failure_text(e) == "Connection error. (cause: TypeError: process() takes no keyword arguments)"
    assert S1.failure_text(ValueError("plain")) == "plain"
