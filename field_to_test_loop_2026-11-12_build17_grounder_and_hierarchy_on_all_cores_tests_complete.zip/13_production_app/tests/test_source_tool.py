"""The first question of the start page: which tool exported the recording (owner, 2026-11-12: "at the starting page ask
whether the analysis is going on for Windows ADK or Teledyne LeCroy or PCMark 10 ... there might not be need of building the
hierarchy by combining many different CSVs together, only it is needed for LeCroy Teledyne").

1. the list: the tools of the reference library in its order; only a ready one can be chosen, the others say why not.
2. the analysis keeps the chosen tool (project.source_tool), shows its name, and a step reads it as ctx.project["source_tool"];
   without the field nothing is stored; an unknown tool or one that is not ready is refused in plain words.
3. a database made by an earlier build gets the new column when the application starts, and keeps its rows.
4. the hierarchy: built unless the library says the chosen tool's export is one table; nothing changes for Teledyne LeCroy.
No server and no model: Flask's test client on a database of its own."""
import json
import os
import sqlite3
import sys
import types

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(HERE)
for p in (APP_DIR, os.path.join(APP_DIR, "app")):
    if p not in sys.path:
        sys.path.insert(0, p)
from agentic import core, pipeline, source_tools as ST   # noqa: E402

LECROY, LECROY_NAME = "teledyne_lecroy_pcie", "Teledyne LeCroy PCIe Protocol Analysis"
WPA_NAME = "Windows Performance Analyzer (Windows Assessment and Deployment Kit)"
NOT_YET = "not available yet: only the notes on its export are in the application"


class QuietEngine(core.Engine):
    def kick(self, rid):            # runs are recorded, their steps are not executed
        pass


@pytest.fixture
def api(tmp_path, monkeypatch):
    from flask import Flask
    from api import agentic_api as A
    store = core.Store(str(tmp_path / "db" / "agentic.sqlite"))
    eng = QuietEngine(store, {"flow": pipeline}, runner=None)
    monkeypatch.setattr(A, "engine", lambda: eng)
    # what a folder must hold is not what is tested here: every folder passes as one with a packet-level file
    monkeypatch.setattr(A.family1, "inventory", lambda folder: [{"name": "packets.csv", "level": "packets", "bytes": 1}])
    monkeypatch.setattr(A.family1, "folder_problem", lambda found: None)
    app = Flask(__name__)
    app.config["services"] = types.SimpleNamespace(cfg={}, root=str(tmp_path))
    app.register_blueprint(A.bp)
    folder = tmp_path / "recording"
    folder.mkdir()
    yield app.test_client(), eng, str(folder)


def new(c, folder, name="analysis one", **more):
    return c.post("/api/agents/projects", json=dict({"admin": "Sagar", "name": name, "folder": folder}, **more))


def in_a_step(eng, pid):
    """The project as a step of a run sees it (ctx.project)."""
    return core.StepContext(eng, {"id": 0, "project": pid, "params": "{}"}, {"id": 0, "input": "{}"}).project


def own_library(tmp_path, tools):
    """A reference library of this test's own: every tool with "columns" gets a column list of one column."""
    root = tmp_path / "library"
    root.mkdir()
    for t in tools:
        if t.get("columns"):
            (root / t["key"]).mkdir()
            (root / t["columns"]).write_text(json.dumps({"entries": [{"name": "Time", "kind": "column", "meaning": "when the row happened"}], "sources": {}}))
    (root / "index.json").write_text(json.dumps({"tools": tools}))
    return str(root)


# ---------------------------------------------------------------------------------------------- 1. the list
def test_the_question_lists_the_library_tools_in_order_and_only_a_ready_one_can_be_chosen(api):
    c, _eng, _folder = api
    j = c.get("/api/agents/source_tools").get_json()
    assert j["question"] == "Which tool exported the recording you want to analyse?"
    assert [t["name"] for t in j["tools"]] == [LECROY_NAME, WPA_NAME, "PCMark 10 (UL Benchmarks)"]
    assert [t["available"] for t in j["tools"]] == [True, False, False]
    assert [t["sentence"] for t in j["tools"]] == ["", NOT_YET, NOT_YET]
    assert all(t["exports"] for t in j["tools"])
    # the hierarchy, in plain words under each tool
    assert [t["hierarchy"] for t in j["tools"]] == [True, False, False]
    assert j["tools"][0]["hierarchy_words"] == "its five exports of one recording are joined into one hierarchy"
    assert j["tools"][1]["hierarchy_words"] == j["tools"][2]["hierarchy_words"] == "one table per export: no hierarchy is built"
    # the list is the library's: nothing here is a list of the program's own
    index = json.load(open(os.path.join(APP_DIR, "reference_library", "index.json"), encoding="utf-8"))
    assert [t["key"] for t in j["tools"]] == [t["key"] for t in index["tools"]]


def test_why_a_tool_cannot_be_chosen_is_worded_from_the_library_status(tmp_path):
    root = own_library(tmp_path, [
        {"key": "ready_tool", "name": "Ready Tool", "exports": "one table", "columns": "ready_tool/columns.json", "status": "ready", "hierarchy": False},
        {"key": "notes_tool", "name": "Notes Tool", "status": "notes only: no column list yet"},
        {"key": "draft_tool", "name": "Draft Tool", "columns": "draft_tool/columns.json", "status": "draft: its column list is being checked"},
        {"key": "lost_tool", "name": "Lost Tool", "status": "ready"},                      # says ready, has no column list
        {"key": "bare_tool", "name": "Bare Tool"}])
    got = {t["key"]: t for t in ST.tools(root)}
    assert list(got) == ["ready_tool", "notes_tool", "draft_tool", "lost_tool", "bare_tool"]
    assert got["ready_tool"]["available"] and got["ready_tool"]["sentence"] == ""
    assert got["notes_tool"]["sentence"] == NOT_YET
    assert got["draft_tool"]["sentence"] == "not available yet: draft: its column list is being checked"
    assert got["lost_tool"]["sentence"] == "not available: its column list could not be read in this copy of the application"
    assert got["bare_tool"]["sentence"] == "not available yet: the reference library has no column list for it"
    assert [t["available"] for t in got.values()] == [True, False, False, False, False]
    # the hierarchy fact: the library's own words when it gives them, plain words otherwise, nothing when it says nothing
    assert got["ready_tool"]["hierarchy"] is False and got["ready_tool"]["hierarchy_words"] == "one table per export: no hierarchy is built"
    assert got["notes_tool"]["hierarchy"] is None and got["notes_tool"]["hierarchy_words"] == ""
    assert ST.check("ready_tool", root) == ("ready_tool", None)
    assert ST.check("lost_tool", root)[0] is None and "Lost Tool is not available" in ST.check("lost_tool", root)[1]


# ---------------------------------------------------------------------------------------------- 2. kept with the analysis
def test_a_new_analysis_keeps_the_chosen_tool_and_shows_its_name(api):
    c, eng, folder = api
    r = new(c, folder, source_tool=LECROY)
    assert r.status_code == 200, r.get_json()
    p = r.get_json()
    assert p["source_tool"] == LECROY and p["source_tool_name"] == LECROY_NAME
    assert eng.store.one("SELECT source_tool FROM project WHERE id=?", (p["id"],))["source_tool"] == LECROY
    assert in_a_step(eng, p["id"]).get("source_tool") == LECROY                 # what family1.exported_by reads
    listed = c.get("/api/agents/state").get_json()["projects"]
    assert [(x["source_tool"], x["source_tool_name"]) for x in listed] == [(LECROY, LECROY_NAME)]
    assert c.get("/api/agents/projects/%d" % p["id"]).get_json()["source_tool_name"] == LECROY_NAME


@pytest.mark.parametrize("more", [{}, {"source_tool": None}, {"source_tool": ""}])
def test_without_the_field_the_analysis_is_made_and_nothing_is_stored(api, more):
    c, eng, folder = api
    r = new(c, folder, **more)
    assert r.status_code == 200, r.get_json()
    p = r.get_json()
    assert p["source_tool"] is None and p["source_tool_name"] == ""
    assert in_a_step(eng, p["id"]).get("source_tool") is None
    assert pipeline.needs_hierarchy(in_a_step(eng, p["id"])) is True


@pytest.mark.parametrize("value, words", [
    ("no_such_tool", "\"no_such_tool\" is not a tool the application knows"),
    ("windows_wpa", WPA_NAME + " is " + NOT_YET),
    ("pcmark10", "PCMark 10 (UL Benchmarks) is " + NOT_YET),
    (" Teledyne LeCroy ", "is not a tool the application knows"),
    (7, "must be given as text"), (["teledyne_lecroy_pcie"], "must be given as text"), ({"key": LECROY}, "must be given as text"), (True, "must be given as text")])
def test_an_unknown_tool_and_a_tool_that_is_not_ready_are_refused_in_plain_words(api, value, words):
    c, eng, folder = api
    r = new(c, folder, source_tool=value)
    assert r.status_code == 400
    err = r.get_json()["error"]
    assert words in err and err.endswith("The tools that can be chosen: " + LECROY_NAME)
    assert eng.store.one("SELECT COUNT(*) AS n FROM project")["n"] == 0             # nothing was made


def test_a_refused_tool_is_refused_before_the_folder_is_looked_at(api):
    c, _eng, _folder = api
    r = c.post("/api/agents/projects", json={"admin": "Sagar", "name": "x", "folder": "/no/such/folder", "source_tool": "windows_wpa"})
    assert r.status_code == 400 and NOT_YET in r.get_json()["error"]


def test_opening_the_same_analysis_again_keeps_or_takes_the_tool(api):
    c, eng, folder = api
    first = new(c, folder).get_json()
    assert first["source_tool"] is None
    again = new(c, folder, source_tool=LECROY).get_json()                         # made before the question, opened with an answer
    assert again["reused"] is True and again["id"] == first["id"] and again["source_tool"] == LECROY
    third = new(c, folder).get_json()                                             # an older page sends nothing: what was said stays
    assert third["reused"] is True and third["source_tool"] == LECROY and third["source_tool_name"] == LECROY_NAME
    assert new(c, folder, source_tool="pcmark10").status_code == 400
    assert eng.store.one("SELECT COUNT(*) AS n FROM project")["n"] == 1


def test_the_tool_can_be_set_and_removed_later_and_a_refused_one_changes_nothing(api):
    c, eng, folder = api
    pid = new(c, folder).get_json()["id"]
    url = "/api/agents/projects/%d" % pid
    r = c.put(url, json={"name": "another name", "source_tool": "windows_wpa"})
    assert r.status_code == 400 and NOT_YET in r.get_json()["error"]
    assert eng.store.one("SELECT name, source_tool FROM project WHERE id=?", (pid,)) == {"name": "analysis one", "source_tool": None}
    assert c.put(url, json={"source_tool": LECROY}).get_json()["source_tool_name"] == LECROY_NAME
    assert c.put(url, json={"notes": "a note"}).get_json()["source_tool"] == LECROY     # another field leaves it alone
    assert c.put(url, json={"source_tool": None}).get_json()["source_tool"] is None


# ---------------------------------------------------------------------------------------------- 3. an earlier database
def test_a_database_of_an_earlier_build_gets_the_column_and_keeps_its_rows(tmp_path):
    path = str(tmp_path / "agentic.sqlite")
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE project (id INTEGER PRIMARY KEY, admin TEXT, name TEXT, folder TEXT, refs TEXT, rea TEXT, "
                "upload_id TEXT, notes TEXT, created REAL, updated REAL)")
    con.execute("INSERT INTO project (admin, name, folder, refs, created, updated) VALUES ('Sagar', 'made before', '/data/rec', '[]', 1, 1)")
    con.commit()
    con.close()
    store = core.Store(path)
    row = store.one("SELECT * FROM project")
    assert "source_tool" in row and row["source_tool"] is None and row["name"] == "made before" and row["folder"] == "/data/rec"
    store.exec("UPDATE project SET source_tool=? WHERE id=?", (LECROY, row["id"]))
    again = core.Store(path)                                                     # the next start: nothing to add, nothing lost
    assert again.one("SELECT source_tool FROM project")["source_tool"] == LECROY
    con = sqlite3.connect(path)
    assert [r[1] for r in con.execute("PRAGMA table_info(project)")].count("source_tool") == 1
    con.close()


def test_a_new_database_has_the_column(tmp_path):
    store = core.Store(str(tmp_path / "new.sqlite"))
    con = store.con()
    assert "source_tool" in [r[1] for r in con.execute("PRAGMA table_info(project)")]
    con.close()


# ---------------------------------------------------------------------------------------------- 4. the hierarchy
def test_the_hierarchy_is_built_unless_the_library_says_the_tool_exports_one_table(tmp_path):
    # the shipped library: nothing changes for Teledyne LeCroy, nor for an analysis that was not asked
    for project in (None, {}, {"source_tool": None}, {"source_tool": ""}, {"source_tool": LECROY}, {"source_tool": "a tool the library dropped"}):
        assert pipeline.needs_hierarchy(project) is True
        assert ST.no_hierarchy_reason(project) == ""
    assert ST.needs_hierarchy({"source_tool": "pcmark10"}) is False
    assert ST.no_hierarchy_reason({"source_tool": "pcmark10"}) == "not needed for PCMark 10 (UL Benchmarks): its export is one table"
    # a library of this test's own: a ready tool whose export is one table, one whose exports are joined, one that says nothing
    root = own_library(tmp_path, [
        {"key": "one_table", "name": "One Table Tool", "columns": "one_table/columns.json", "status": "ready", "hierarchy": False},
        {"key": "joined", "name": "Joined Tool", "columns": "joined/columns.json", "status": "ready", "hierarchy": True},
        {"key": "silent", "name": "Silent Tool", "columns": "silent/columns.json", "status": "ready"},
        {"key": "odd", "name": "Odd Tool", "columns": "odd/columns.json", "status": "ready", "hierarchy": "no"}])
    assert ST.needs_hierarchy({"source_tool": "one_table"}, root) is False
    assert ST.no_hierarchy_reason({"source_tool": "one_table"}, root) == "not needed for One Table Tool: its export is one table"
    for key in ("joined", "silent", "odd"):                  # only a plain false switches the hierarchy off
        assert ST.needs_hierarchy({"source_tool": key}, root) is True and ST.no_hierarchy_reason({"source_tool": key}, root) == ""
