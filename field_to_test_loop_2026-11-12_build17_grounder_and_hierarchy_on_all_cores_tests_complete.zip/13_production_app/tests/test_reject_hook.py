"""A rejected review tells the run's kind (2026-11-12): what a step kept for later runs can be taken back.

The engine calls on_reject(engine, run, step, data, admin) of the run's kind once, after the rejection is written, with the
step that was rejected. Whatever goes wrong inside on_reject, the rejection stands: the review is rejected, the step is
rejected, the run is stopped, and one line goes to the log. Approve and Change never call it, and a kind without an on_reject
is rejected as before. The flow (pipeline.on_reject) hands a rejected data dictionary of Family 1 to family1.on_reject when
Family 1 has one, and nothing else.

No server and no model: an engine on its own store in a temporary folder, its steps run here one at a time."""
import os
import shutil
import sys
import tempfile
import time
import types

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from agentic import core  # noqa: E402


class _Flow:
    """One run of a kind with a step that asks for a review ("dict") and a step after it, on its own engine."""

    def __init__(self, **hooks):
        self.root = tempfile.mkdtemp(prefix="reject_%d_" % os.getpid())
        self.kick = core.Engine.kick
        core.Engine.kick = lambda eng, rid: None        # no background thread: the steps are run here, in order
        self.store = core.Store(os.path.join(self.root, "agentic.sqlite"))
        self.runner = core.AgentRunner(os.path.join(self.root, "runs"), runtime="http", web=False)

        def steps(params, project):
            return [{"key": "manager:a.csv", "title": "dictionary of a.csv", "family": "1", "agent": "Manager", "review": True},
                    {"key": "after", "title": "after it", "agent": "After"}]

        def run_step(ctx):
            if ctx.step["key"] == "after":
                return core.Result({"after": True})
            return core.Result({"columns": 3}, review={"title": "Dictionary of a.csv", "data": {"path": "/f/a.csv", "kept": ["k1", "k2"]}})
        self.eng = core.Engine(self.store, {"k": types.SimpleNamespace(steps=steps, run_step=run_step, **hooks)}, self.runner)
        pid = self.store.exec("INSERT INTO project (name, folder, created) VALUES (?,?,?)", ("p", self.root, time.time()))
        self.rid = self.eng.start(pid, "k")
        self.step = self.store.one("SELECT * FROM step WHERE run=? AND key='manager:a.csv'", (self.rid,))
        self.eng._run_step(self.store.one("SELECT * FROM run WHERE id=?", (self.rid,)), self.step)
        self.review = self.store.one("SELECT * FROM review WHERE run=?", (self.rid,))
        assert self.review and self.review["state"] == "open", "the step did not open its review"

    def states(self):
        one = self.store.one
        return (one("SELECT state FROM review WHERE id=?", (self.review["id"],))["state"],
                one("SELECT state FROM step WHERE id=?", (self.step["id"],))["state"],
                one("SELECT state FROM run WHERE id=?", (self.rid,))["state"])

    def close(self):
        core.Engine.kick = self.kick
        shutil.rmtree(self.root, ignore_errors=True)


def test_a_rejected_review_calls_on_reject_once_with_the_rejected_step():
    calls = []

    def on_reject(engine, run, step, data, admin):
        calls.append({"engine": engine, "run": run["id"], "step": step["id"], "key": step["key"], "family": step["family"], "step_state": step["state"],
                      "run_state_in_the_store": engine.store.one("SELECT state FROM run WHERE id=?", (run["id"],))["state"],
                      "data": dict(data), "admin": admin})
    f = _Flow(on_reject=on_reject)
    try:
        f.eng.decide(f.review["id"], "reject", "ADMIN", "the wrong file")
        assert len(calls) == 1, calls
        c = calls[0]
        assert c["engine"] is f.eng and c["run"] == f.rid and c["admin"] == "ADMIN"
        assert (c["step"], c["key"], c["family"]) == (f.step["id"], "manager:a.csv", "1")
        # the rejection is written before the kind hears of it: the step it gets reads "rejected", the run is stopped
        assert c["step_state"] == "rejected" and c["run_state_in_the_store"] == "stopped"
        # the review's own data, with what the admin wrote
        assert c["data"] == {"path": "/f/a.csv", "kept": ["k1", "k2"], "comment": "the wrong file"}
        assert f.states() == ("rejected", "rejected", "stopped")
        assert f.store.one("SELECT summary FROM run WHERE id=?", (f.rid,))["summary"] == "rejected by ADMIN at 'Dictionary of a.csv': the wrong file"
        assert f.rid in f.runner.cancelled                                    # the run's model calls are ended, as before
        # a review decided once is not open: a second press is refused and calls nothing
        try:
            f.eng.decide(f.review["id"], "reject", "ADMIN")
            raise AssertionError("a decided review was decided again")
        except ValueError:
            pass
        assert len(calls) == 1
    finally:
        f.close()


def test_a_failure_inside_on_reject_does_not_stop_the_rejection(capsys):
    calls = []

    def on_reject(engine, run, step, data, admin):
        calls.append(step["key"])
        raise RuntimeError("could not take it back\nsecond line of the error")
    f = _Flow(on_reject=on_reject)
    try:
        capsys.readouterr()
        f.eng.decide(f.review["id"], "reject", "ADMIN")                       # must not raise
        assert calls == ["manager:a.csv"]
        assert f.states() == ("rejected", "rejected", "stopped")              # not put back to "open"
        assert f.store.one("SELECT decided_by FROM review WHERE id=?", (f.review["id"],))["decided_by"] == "ADMIN"
        assert f.rid in f.runner.cancelled
        assert f.store.one("SELECT state FROM step WHERE run=? AND key='after'", (f.rid,))["state"] == "waiting"
        err = capsys.readouterr().err
        lines = err.splitlines()                                              # one line, even for an error of several lines
        assert len(lines) == 1 and err.endswith("\n"), err
        assert lines[0] == "on_reject failed for review %s (run %s): RuntimeError: could not take it back second line of the error" % (f.review["id"], f.rid), err
    finally:
        f.close()


def test_approve_and_change_never_call_on_reject():
    for decision in ("approve", "change"):
        calls = []
        f = _Flow(on_reject=lambda *a: calls.append(a))
        try:
            f.eng.decide(f.review["id"], decision, "ADMIN", "a comment")
            assert calls == [], decision
            assert f.states() == ({"approve": "approved", "change": "changes"}[decision], {"approve": "approved", "change": "waiting"}[decision], "running")
        finally:
            f.close()


def test_a_kind_without_on_reject_is_rejected_as_before():
    f = _Flow()
    try:
        f.eng.decide(f.review["id"], "reject", "ADMIN")
        assert f.states() == ("rejected", "rejected", "stopped")
        assert f.store.one("SELECT summary FROM run WHERE id=?", (f.rid,))["summary"] == "rejected by ADMIN at 'Dictionary of a.csv'"
    finally:
        f.close()


def test_the_flow_hands_a_rejected_dictionary_to_family_1_and_nothing_else(monkeypatch):
    from agentic import family1, pipeline
    calls = []

    def fake(engine, run, step, data, admin):
        calls.append((engine, run, step["key"], data, admin))
        return 7
    monkeypatch.setattr(family1, "on_reject", fake, raising=False)
    run, data = {"id": 3}, {"path": "/f/a.csv"}
    assert pipeline.on_reject("ENG", run, {"key": "manager:a.csv", "family": "1"}, data, "ADMIN") == 7
    assert calls == [("ENG", run, "manager:a.csv", data, "ADMIN")]
    # the last review of Family 1 is not one file's dictionary; Families 2 and 3 and steps of no family keep nothing to take back
    for step in ({"key": "f1_last", "family": "1"}, {"key": "strategy", "family": "2"}, {"key": "proc:x", "family": "3"}, {"key": "report", "family": ""}, {"key": "report"}):
        assert pipeline.on_reject("ENG", run, step, data, "ADMIN") == 0, step
    assert len(calls) == 1
    # a Family 1 that has no on_reject: nothing is called and nothing fails
    monkeypatch.delattr(family1, "on_reject", raising=False)
    assert pipeline.on_reject("ENG", run, {"key": "manager:a.csv", "family": "1"}, data, "ADMIN") == 0
