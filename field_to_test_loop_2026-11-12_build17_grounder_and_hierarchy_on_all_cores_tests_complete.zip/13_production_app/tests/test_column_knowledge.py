"""What the application already knows about columns: the reference library and the store of earlier runs (2026-11-12).

agentic/column_knowledge.py answers a column from the reference library shipped with the application (reference_library/) or from
what an earlier run understood (knowledge/column_meanings/), so that the model is asked only for what is new. A wrong answer here
is worse than a slow one: it is shown as a document's or the admin's word. These checks try to break it:

  the library   the five real headers (data/lecroy_real_headers.json) are recognised as Teledyne LeCroy exports and every named
                column is answered, except the four the document does not state; headers of other tools, invented names, an empty
                header and a header with too few known names are not recognised; a name the export has several times is told
                apart by the column before it, never guessed; every document quote (all of them) is on the line it cites; a quote
                that was changed is not confirmed; names that are not names (nothing, a number, 100,000 letters) and a damaged
                library do not stop a run;
  the store     what is remembered is read back by a new run; a column is the same column only by name, kind of values and
                keywords; what the admin approved is never replaced by what was not approved, also when another run saves an
                older view of the file afterwards; two columns whose names differ only in the case of their letters are two
                columns; a rejected run's meanings are taken out and nothing else is; odd names and odd tool names write nothing
                outside the store's folder; a damaged or hand-edited store file does not stop a run; runs that save one after
                the other, or at the same moment, keep each other's meanings.

No server, no model. Its files go to a folder of its own under F2T_TEST_TMP (or the system's temporary folder) and are deleted.
Run: python3 tests/test_column_knowledge.py   (exit code 1 when a check fails)."""
import json
import os
import shutil
import sys
import tempfile
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from agentic import column_knowledge as CK, core      # noqa: E402

TOOL = "teledyne_lecroy_pcie"
LEVEL_OF = {"packets.csv": "packets", "link.csv": "link", "split.csv": "split", "NVME_Transactions.csv": "nvme_transaction",
            "nvme_command.csv": "nvme_command"}
NOT_STATED = {"PMUX Metadata", "Jammer Phase", "CXL Pkt Type", "CXL Pkt Subtype"}     # in the list, with no meaning: left to the Data Grounder
ANSWER_KEYS = {"column", "meaning", "source", "keywords", "library"}
LIBRARY_KEYS = {"tool", "tool_name", "entry", "kind", "found_by", "prepared"}
FAILED, COUNT = [], [0]


def check(name, ok, detail=""):
    COUNT[0] += 1
    print("%s  %s%s" % ("PASS" if ok else "FAIL", name, " :: " + str(detail)[:400] if detail not in ("", None) else ""), flush=True)
    if not ok:
        FAILED.append(name)
    return bool(ok)


def no_crash(name, fn):
    """Run fn; a check fails when it raises. -> (it ran, what it gave)."""
    try:
        return True, fn()
    except Exception as e:      # the point of the check: nothing may come out as an exception
        check(name, False, "%s: %s" % (type(e).__name__, e))
        return False, None


def real_headers():
    """{file name: (level, [the readers' name of every column, in file order])} from the real headers kept with the application.
    A cell without a name is a separator: the readers call it 'column N'."""
    with open(os.path.join(APP, "data", "lecroy_real_headers.json"), encoding="utf-8") as fh:
        real = json.load(fh)
    out = {}
    for fname, versions in real["files"].items():
        d = versions[0]
        named = d["columns"]
        out[fname] = (LEVEL_OF[fname], [named.get(str(i)) or "column %d" % (i + 1) for i in range(len(d["header"]))], d["header"])
    return out


def all_files_under(folder):
    return sorted(os.path.relpath(os.path.join(b, f), folder) for b, _d, fs in os.walk(folder) for f in fs)


# ------------------------------------------------------------------------------------------------------------ the library
def library_real_headers(tmp):
    lib = CK.library()
    check("the shipped reference library is read without a problem", not lib.problems and TOOL in lib.tools, lib.problems)
    heads = real_headers()
    check("the five real headers are there", sorted(heads) == sorted(LEVEL_OF), sorted(heads))
    how_all, t0, looked = {}, time.time(), 0
    for fname, (level, names, header) in sorted(heads.items()):
        named = [n for n in names if not CK.is_separator(n)]
        key, facts = lib.recognise(names)
        check("%s is recognised as a Teledyne LeCroy export, every name in the list" % fname,
              key == TOOL and facts == {"names": len(named), "found": len(named), "share": 1.0}, (key, facts))
        key2, _f = lib.recognise(list(reversed(names)))
        check("%s is recognised whatever the order of its columns" % fname, key2 == TOOL)
        before = CK.previous_names([{"column": n, "position": i} for i, n in enumerate(names)])
        check("%s: the column before each named column steps over the separators" % fname,
              set(before) == set(named) and not any(CK.is_separator(b) for b in before.values()) and before[named[0]] == "")
        left, kinds, hows, shapes = {}, {}, {}, []
        for n in names:
            e, how = lib.lookup(TOOL, level, n, before.get(n))
            looked += 1
            if CK.is_separator(n):
                if e is not None:
                    left[n] = "a separator was answered"
                continue
            if e is None:
                left[n] = how
                continue
            kinds[e["kind"]] = kinds.get(e["kind"], 0) + 1
            hows[how] = hows.get(how, 0) + 1
            a = lib.answer(TOOL, e, n, how)
            if not (set(a) == ANSWER_KEYS and a["column"] == n and a["meaning"] and a["keywords"] == [] and LIBRARY_KEYS <= set(a["library"])
                    and set(a["source"]) == {"kind", "ref", "quote"} and a["source"]["kind"] == e["kind"] == a["library"]["kind"]
                    and a["library"]["found_by"] == how and a["library"]["tool"] == TOOL):
                shapes.append(n)
        how_all[fname] = hows
        check("%s: every named column is answered from the library, except the ones the document does not state" % fname,
              set(left) == (NOT_STATED & set(named)) and all(w == "the reference document has no meaning for it" for w in left.values()),
              "%d answered (%s), not answered: %s" % (sum(kinds.values()), kinds, dict(list(left.items())[:6])))
        check("%s: every answer has the shape the Data Grounder reads" % fname, not shapes, shapes[:5])
    secs = time.time() - t0
    check("the look-ups of all five headers take seconds, not minutes", secs < 20, "%d look-ups in %.2f s" % (looked, secs))
    check("the widest file needs all four ways of finding a name (name, the column before, repeated name, numbered family)",
          set(how_all.get("nvme_command.csv") or {}) == {"name", "sibling", "repeated", "family"}, how_all.get("nvme_command.csv"))
    try:                                    # the Data Grounder takes the names from its own reader: they must be these names
        from agentic import family1
        from nvme_hier import loader as L
        same = []
        for fname, (level, names, header) in sorted(heads.items()):
            lv = L.guess_level(header)
            got = sorted(family1._named_columns(lv, header)[1], key=lambda x: x[1])         # (name, place in the file)
            same.append((fname, lv == level and [n for n, _i in got] == names and [i for _n, i in got] == list(range(len(names)))))
        check("the Data Grounder's own reader gives the names the library was checked with", all(ok for _f, ok in same), same)
    except Exception as e:
        check("the Data Grounder's own reader gives the names the library was checked with", False,
              "agentic/family1.py could not be used: %s: %s" % (type(e).__name__, e))


def library_not_recognised(tmp):
    lib = CK.library()
    real = [n for n in real_headers()["packets.csv"][1]][:40]
    invented = ["Zz Invented %d" % i for i in range(40)]
    cases = [
        ("a header of invented names", invented),
        ("an empty header", []),
        ("a header of separators and empty cells only", ["column 1", "", None, "column 4"]),
        ("four known names and nothing else (fewer than %d)" % CK.RECOGNISE_LEAST, real[:4]),
        ("five known names among seventeen (under %d%%)" % int(CK.RECOGNISE_SHARE * 100), real[:5] + invented[:12]),
        ("three known names among ten (30%, but fewer than five)", real[:3] + invented[:7]),
        ("the real names in small letters (names are matched as written: Timestamp and TIMESTAMP are two columns)", [n.lower() for n in real]),
        ("a Windows Performance Analyzer CPU table", ["Line #", "Process", "Thread ID", "Stack", "Count", "Weight (in view) (ms)", "% Weight", "CPU",
                                                       "Priority", "Module", "Function", "Address", "TimeStamp (s)", "Type", "Flags", "Size (B)", "Data"]),
        ("a Windows Performance Analyzer disk table", ["Process", "Path Name", "IO Type", "Priority", "Size (B)", "Disk Service Time (µs)", "IO Time (µs)",
                                                        "Init Time (s)", "Complete Time (s)", "Disk", "Min Offset", "Flags", "Thread ID", "Count", "Type",
                                                        "Data", "Address", "Length", "Status"]),
        ("a PCMark 10 result table", ["Test", "Score", "Result", "Unit", "Essentials", "Productivity", "Digital Content Creation", "App Start-up Score",
                                      "Video Conferencing Score", "Web Browsing Score", "Date", "Time", "Type", "Status", "Data", "Length", "Address"]),
    ]
    for what, names in cases:
        ok, got = no_crash("not recognised: " + what, lambda names=names: lib.recognise(names))
        if ok:
            check("not recognised: " + what, got[0] is None and got[1]["names"] == len([n for n in names if n and not CK.is_separator(n)]), got)
    # the two limits themselves, from both sides
    check("five known names and nothing else are enough", lib.recognise(real[:5])[0] == TOOL, lib.recognise(real[:5]))
    check("five known names among sixteen (31%) are enough", lib.recognise(real[:5] + invented[:11])[0] == TOOL)
    check("six known names among twenty (exactly 30%) are enough", lib.recognise(real[:6] + invented[:14])[0] == TOOL)
    check("six known names among twenty-one (under 30%) are not", lib.recognise(real[:6] + invented[:15])[0] is None)
    for what, names in (("nothing in place of a name", [None, None]), ("numbers in place of names", [5, 7.5, 0, True]),
                        ("a name of 100,000 letters", ["a" * 100000] + real[:5]), ("names with signs of a search pattern", ["RNG (.*", "[", "\\", "#", "#2", "a#0"])):
        no_crash("recognise does not stop on " + what, lambda names=names: lib.recognise(names))
    check("a tool that is not in the library is described as nothing", lib.describe("no_such_tool") is None)
    check("a look-up for a tool that is not in the library gives no entry", lib.lookup("no_such_tool", "packets", "Marker") == (None, "not in a reference document"))


def library_lookup(tmp):
    lib = CK.library()

    def entry(level, name, before=None):
        e, how = lib.lookup(TOOL, level, name, before)
        return (e["name"] if e else None), how

    check("a plain name at its level", entry("packets", "Marker") == ("Marker", "name"), entry("packets", "Marker"))
    check("a plain name at a level it is not in is not answered", entry("link", "Marker")[0] is None and "another level" in entry("link", "Marker")[1])
    check("a plain name with no level known is answered when it is one field in the whole export", entry(None, "Marker") == ("Marker", "name"))
    check("a name that is two fields is not answered when the level is not known", entry(None, "Address")[0] is None and "level of this file is not known" in entry(None, "Address")[1])
    a_p, _h = lib.lookup(TOOL, "packets", "Address")
    a_n, _h = lib.lookup(TOOL, "nvme_transaction", "Address")
    check("Address is one field in the packets file and another in the NVMe transactions file",
          a_p and a_n and a_p is not a_n and a_p["kind"] == "document" and a_n["kind"] == "model" and a_p["meaning"] != a_n["meaning"])
    check("Address at a level that has no Address is not answered", entry("nvme_command", "Address")[0] is None)
    d_p, _h = lib.lookup(TOOL, "packets", "Device ID")
    d_c, _h = lib.lookup(TOOL, "nvme_command", "Device ID")
    check("Device ID of a packet is not Device ID of an NVMe command", d_p and d_c and d_p["meaning"] != d_c["meaning"])
    # a numbered family: any member, one meaning
    check("a member of a numbered family", entry("nvme_command", "RNG 12.SLBA") == ("RNG #.SLBA", "family"), entry("nvme_command", "RNG 12.SLBA"))
    check("a member the prepared export did not have (a higher number)", entry("nvme_command", "RNG 999.SLBA") == ("RNG #.SLBA", "family"))
    check("a family member at a level without that family is not answered", entry("packets", "RNG 12.SLBA")[0] is None)
    check("the family's own name with the # sign is not a column", entry("nvme_command", "RNG #.SLBA") == (None, "not in the reference document"))
    check("a known name with a number added is not taken for the known name", entry("packets", "Marker 2")[0] is None and entry("packets", "Marker2")[0] is None)
    # a name the export repeats: one entry for all of them
    check("the second column of a repeated name", entry("nvme_command", "Log Page Identifier Supported.IOS#2") == ("Log Page Identifier Supported.IOS", "repeated"))
    check("#2 of a name the export does not repeat is not answered from the bare name", entry("packets", "Marker#2") == (None, "not in the reference document"))
    # the same header word several times, each another field: the column before it decides
    check("AL after AF in the NVMe transactions file", entry("nvme_transaction", "AL", "AF") == ("AL", "sibling"), entry("nvme_transaction", "AL", "AF"))
    check("AL#2 after SECP", entry("nvme_transaction", "AL#2", "SECP") == ("AL#2", "sibling"))
    check("AL#3 after AF#2", entry("nvme_transaction", "AL#3", "AF#2") == ("AL#3", "sibling"))
    check("when the first AL is not exported, the reader calls the second one AL: its place still tells which field it is",
          entry("nvme_transaction", "AL", "SECP") == ("AL#2", "sibling"), entry("nvme_transaction", "AL", "SECP"))
    for before in (None, "", "Marker", "column 3"):
        got = entry("nvme_transaction", "AL#2", before)
        check("AL#2 is not guessed when the column before it is %r" % (before,), got[0] is None and "several columns of this name" in got[1], got)
    check("AL in the NVMe commands file, after SECP", entry("nvme_command", "AL", "SECP") == ("AL", "sibling"))
    check("AL with no level known is not answered", entry(None, "AL", "AF")[0] is None)
    # separators, the four the document does not state, a model entry
    for name, sep in (("column 7", True), ("column 1727", True), ("Column 7", False), ("column 7 ", False), ("column", False), ("column 7#2", False),
                      ("", False), (None, False), ("column seven", False)):
        check("is_separator(%r) is %s" % (name, sep), CK.is_separator(name) is sep)
    check("a separator is never answered", lib.lookup(TOOL, "packets", "column 7") == (None, "not in a reference document"))
    for n in sorted(NOT_STATED):
        check("%s is in the list but has no meaning: left to the model" % n, lib.lookup(TOOL, "packets", n) == (None, "the reference document has no meaning for it"))
    e, how = lib.lookup(TOOL, "link", "Link Tra Error")
    a = lib.answer(TOOL, e, "Link Tra Error", how) if e else {}
    check("an entry written from the model's knowledge says so: no document, no quote, no original",
          bool(e) and e["kind"] == "model" and a["source"] == {"kind": "model", "ref": "model knowledge", "quote": ""} and "original" not in a["library"], a)
    # names that are not names
    for name in (None, 5, 7.5, "", " ", "a" * 100000, "RNG (.*", "[", "AL#2#3", "#", "#2", "AL#", "a#0", "Größe µs 列", "two\nlines", "\x00"):
        ok, got = no_crash("a look-up does not stop on the name %s" % repr(name)[:30], lambda name=name: lib.lookup(TOOL, "packets", name, name))
        if ok:
            check("a look-up does not stop on the name %s" % repr(name)[:30], got[0] is None and isinstance(got[1], str) and got[1], got)
    check("the columns before: taken by place, not by the order of the list; a column without a place comes last",
          CK.previous_names([{"column": "C", "position": 5}, {"column": "column 4", "position": 3}, {"column": "A", "position": 0}, {"column": "B", "position": 2},
                             {"column": "Z"}, {"column": ""}, {"position": 1}]) == {"A": "", "B": "A", "C": "B", "Z": "C"})
    check("the columns before, when no column has a place (a test memory): the order of the list",
          CK.previous_names([{"column": "A"}, {"column": "column 2"}, {"column": "B"}]) == {"A": "", "B": "A"})


def library_quotes(tmp):
    lib = CK.library()
    t = lib.tools[TOOL]
    entries = [e for es in list(t["by_name"].values()) + list(t["patterns"].values()) for e in es]
    docs = [e for e in entries if e["kind"] == "document"]
    models = [e for e in entries if e["kind"] == "model"]
    check("the library has entries of the three kinds", len(entries) == t["entries"] and len(docs) > 500 and models and len(entries) - len(docs) - len(models) == len(NOT_STATED),
          "%d entries: %d from a document, %d from the model's knowledge, %d without a meaning" % (len(entries), len(docs), len(models), len(entries) - len(docs) - len(models)))
    check("the reference document is where the library says", os.path.isfile(t["document"]) and os.path.basename(t["document"]) == CK.DOCUMENT
          and lib.documents() == [os.path.dirname(t["document"])], t["document"])
    refs = core.References(lib.documents(), os.path.join(tmp, "cache"))
    lines = refs.docs().get(t["document"]) or []
    confirmed, on_line, claimed, shape, original = 0, 0, 0, [], []
    for e in docs:
        a = lib.answer(TOOL, e, e["name"])
        src = a["source"]
        if not (set(a) == ANSWER_KEYS and LIBRARY_KEYS | {"original"} <= set(a["library"]) and src["kind"] == "document"
                and src["ref"] == "%s:%d" % (t["document"], e["doc_line"]) and src["quote"] == e["quote"] and a["meaning"]):
            shape.append(e["name"])
        confirmed += 1 if refs.has_quote(src["ref"], src["quote"]) else 0
        i = int(e["doc_line"]) - 1
        on_line += 1 if 0 <= i < len(lines) and lines[i].startswith("> ") and core.norm(src["quote"]) in core.norm(lines[i]) else 0
        claimed += 1 if core.check_claims([{"text": e["name"], "source": src}], refs=refs)[0]["verified"] else 0
        o = lib.original_of(src["ref"])
        if not (o and o == dict(a["library"]["original"], tool_name=t["name"]) and o["title"] and o["address"].startswith("https://") and o["where"]):
            original.append(e["name"])
    check("every document entry gives an answer of the right shape", not shape, shape[:5])
    check("every document quote is confirmed by the check the Data Grounder uses (References.has_quote)", confirmed == len(docs), "%d of %d" % (confirmed, len(docs)))
    check("every document quote stands on the very line its entry cites, as a quoted line", on_line == len(docs), "%d of %d" % (on_line, len(docs)))
    check("every document quote passes check_claims", claimed == len(docs), "%d of %d" % (claimed, len(docs)))
    check("no two entries cite the same line", len({e["doc_line"] for e in docs}) == len(docs))
    check("every document entry names its original document: title, public address, place in it", not original, original[:5])
    # a quote that was changed, a line that is not the entry's, a file that is not the document
    a = lib.answer(TOOL, docs[0], docs[0]["name"])
    src = a["source"]
    check("a quote with other words is not confirmed", not refs.has_quote(src["ref"], "these words are in no reference document of this application")
          and not core.check_claims([{"text": "x", "source": dict(src, quote="these words are in no reference document of this application")}], refs=refs)[0]["verified"])
    check("a quote cited from a file that is not a reference document is not confirmed",
          not core.check_claims([{"text": "x", "source": dict(src, ref=os.path.join(APP, "run_app.py") + ":1")}], refs=refs)[0]["verified"])
    check("an empty quote is not confirmed", not core.check_claims([{"text": "x", "source": dict(src, quote="")}], refs=refs)[0]["verified"])
    check("without the reference folder nothing is confirmed", not core.check_claims([{"text": "x", "source": src}], refs=None)[0]["verified"])
    # original_of
    check("a line of the document that is no entry's quote: the tool, and no original", lib.original_of(t["document"] + ":1") == {"tool_name": t["name"]})
    check("a reference into another file has no original", lib.original_of(os.path.join(APP, "run_app.py") + ":3") is None and lib.original_of("no_such_file:3") is None)
    for ref in (None, "", t["document"], t["document"] + ":", t["document"] + ":abc", ":5", "model knowledge", 5):
        ok, got = no_crash("original_of does not stop on %r" % (ref if not isinstance(ref, str) else ref[-30:],), lambda ref=ref: lib.original_of(ref))
        if ok:
            check("original_of(%r) is nothing" % (ref if not isinstance(ref, str) else ref[-30:],), got is None, got)
    roundabout = os.path.join(os.path.dirname(t["document"]), "..", "document", CK.DOCUMENT) + ":%d" % docs[0]["doc_line"]
    check("the same document reached by another path is the same document", (lib.original_of(roundabout) or {}).get("title") == a["library"]["original"]["title"])
    with open(os.path.join(APP, "reference_library", "index.json"), encoding="utf-8") as fh:
        listed = {x["key"]: x for x in json.load(fh)["tools"]}
    check("describe gives the tool in the index's own words", lib.describe(TOOL) == {k: listed[TOOL][k] for k in ("key", "name", "domain", "web_hint", "exports")}, lib.describe(TOOL))
    check("a tool with notes only (no column list yet) is not a tool files are recognised as", set(lib.tools) == {k for k, x in listed.items() if x.get("columns")}, sorted(lib.tools))
    check("the library is read once", CK.library() is lib and CK.library(os.path.join(APP, "reference_library")) is lib)


def _small_library(root, entries_a, entries_b=None, index=None):
    """A library of two invented tools in a folder of the test's own, with the quotes of tool A on the lines its entries cite."""
    os.makedirs(os.path.join(root, "toolA", "document"), exist_ok=True)
    os.makedirs(os.path.join(root, "toolB"), exist_ok=True)
    doc = ["# Tool A export"] + ["text"] * 60
    for e in entries_a if isinstance(entries_a, list) else []:
        if isinstance(e, dict) and e.get("doc_line") and e.get("quote"):
            doc[e["doc_line"] - 1] = "> " + e["quote"]
    with open(os.path.join(root, "toolA", "document", CK.DOCUMENT), "w", encoding="utf-8") as fh:
        fh.write("\n".join(doc) + "\n")
    with open(os.path.join(root, "toolA", "columns.json"), "w", encoding="utf-8") as fh:
        json.dump({"tool": "toolA", "prepared": "2026-11-12", "sources": {"man": {"title": "Manual A", "version": "1", "publisher": "P", "address": "https://example.org/a"}},
                   "entries": entries_a}, fh)
    with open(os.path.join(root, "toolB", "columns.json"), "w", encoding="utf-8") as fh:
        json.dump({"tool": "toolB", "prepared": "2026-11-12", "sources": {}, "entries": entries_b if entries_b is not None else []}, fh)
    with open(os.path.join(root, "index.json"), "w", encoding="utf-8") as fh:
        json.dump(index if index is not None else {"tools": [
            {"key": "toolA", "name": "Tool A", "domain": "things", "web_hint": "tool a export", "exports": "a table", "columns": "toolA/columns.json", "document": "toolA/document"},
            {"key": "toolB", "name": "Tool B", "columns": "toolB/columns.json"},
            {"key": "notes_only", "name": "Notes only", "notes": "x/NOTES.md"}]}, fh)
    return root


def _doc(name, line, level="one", before="", **more):
    return dict({"name": name, "seen": [{"level": level, "before": before}], "kind": "document", "meaning": "%s means something." % name, "source": "man",
                 "where": "1.%d" % line, "quote": "%s is stated on line %d" % (name, line), "source_line": 100 + line, "doc_line": line}, **more)


def library_rules_on_a_small_one(tmp):
    """The rules one by one, on a library small enough to say what every answer must be."""
    a = [_doc("Alpha", 3),
         _doc("Beta", 5, before="Alpha", only_for=["one"]),
         {"name": "Beta", "only_for": ["two"], "seen": [{"level": "two", "before": ""}], "kind": "model", "meaning": "Beta at level two."},
         _doc("Twin", 7, before="Beta"), _doc("Twin#2", 9, before="Gamma"),
         {"name": "Gamma", "seen": [{"level": "one", "before": "Twin"}], "kind": "model", "meaning": "Gamma, from knowledge."},
         _doc("Rep", 11, before="Twin#2", repeated_columns=4),
         _doc("Fam #.X", 13, pattern=True, same_for_all_members=True),
         _doc("Mix #", 15, pattern=True, same_for_all_members=False),
         {"name": "NoQuote", "seen": [{"level": "one", "before": ""}], "kind": "document", "meaning": "Has a meaning and no quote."},
         dict(_doc("Blank", 17), meaning="   "),
         {"name": "Unstated", "seen": [{"level": "one", "before": ""}], "kind": "unknown"},
         _doc("Both", 19), dict(_doc("Both", 21), meaning="Both, said twice."),
         "not an entry", {"name": "", "kind": "document"}, {"name": "NoKind"}, {"name": 5, "kind": "model", "meaning": "a name that is a number"}, None]
    b = [{"name": n, "seen": [{"level": "one", "before": ""}], "kind": "model", "meaning": "%s of tool B." % n} for n in ("Alpha", "B1", "B2", "B3", "B4", "B5", "B6")]
    ok, lib = no_crash("a library with entries that are not entries is read", lambda: CK.Library(_small_library(os.path.join(tmp, "lib_small"), a, b)))
    if not ok:
        return
    check("only whole entries are taken (a name and a kind)", set(lib.tools) == {"toolA", "toolB"} and lib.tools["toolA"]["entries"] <= 14 and not lib.problems,
          (sorted(lib.tools), lib.tools.get("toolA", {}).get("entries"), lib.problems))

    def entry(level, name, before=None, tool="toolA"):
        e, how = lib.lookup(tool, level, name, before)
        return (e["name"] if e else None), how

    check("small: a plain name", entry("one", "Alpha") == ("Alpha", "name"))
    check("small: a name limited to one level, at that level and at the other", entry("one", "Beta")[0] == "Beta" and lib.lookup("toolA", "one", "Beta")[0]["kind"] == "document"
          and lib.lookup("toolA", "two", "Beta")[0]["kind"] == "model" and entry("three", "Beta")[0] is None and entry(None, "Beta")[0] is None)
    check("small: twins are told apart by the column before", entry("one", "Twin", "Beta") == ("Twin", "sibling") and entry("one", "Twin#2", "Gamma") == ("Twin#2", "sibling")
          and entry("one", "Twin", "Gamma") == ("Twin#2", "sibling"))
    check("small: a twin after an unknown column is not guessed", entry("one", "Twin", "Alpha")[0] is None and entry("one", "Twin#2")[0] is None and entry("one", "Twin#7", "Zz")[0] is None)
    check("small: a repeated name stands for every repeat", entry("one", "Rep") == ("Rep", "name") and entry("one", "Rep#3") == ("Rep", "repeated"))
    check("small: a family with one meaning for all its members", entry("one", "Fam 12.X") == ("Fam #.X", "family"))
    check("small: a family whose members differ is not answered", entry("one", "Mix 3")[0] is None and "family" in entry("one", "Mix 3")[1])
    check("small: a document entry without a quote is not answered", entry("one", "NoQuote") == (None, "the reference document's entry has no quote"))
    check("small: an entry with an empty meaning is not answered", entry("one", "Blank") == (None, "the reference document has no meaning for it"))
    check("small: an entry of kind unknown is not answered", entry("one", "Unstated") == (None, "the reference document has no meaning for it"))
    check("small: two entries for one name at one level: neither is taken", entry("one", "Both") == (None, "the reference document has more than one entry for this name"))
    check("small: a model entry", entry("one", "Gamma") == ("Gamma", "name") and lib.answer("toolA", lib.lookup("toolA", "one", "Gamma")[0], "Gamma")["source"]["kind"] == "model")
    refs = core.References(lib.documents(), os.path.join(tmp, "cache_small"))
    e, how = lib.lookup("toolA", "one", "Fam 12.X")
    ans = lib.answer("toolA", e, "Fam 12.X", how)
    check("small: the answer for a family member carries the member's name, the family's entry and a quote that is confirmed",
          ans["column"] == "Fam 12.X" and ans["library"]["entry"] == "Fam #.X" and ans["library"]["found_by"] == "family" and refs.has_quote(ans["source"]["ref"], ans["source"]["quote"])
          and ans["library"]["original"] == {"title": "Manual A", "version": "1", "publisher": "P", "address": "https://example.org/a", "where": "1.13", "line": 113}, ans)
    # which tool: the larger share of names; nothing when neither has enough
    a_names = ["Alpha", "Beta", "Twin", "Twin#2", "Gamma", "Rep", "Rep#2", "Fam 1.X", "Mix 4", "Unstated"]
    check("small: a header of tool A is tool A's", lib.recognise(a_names) == ("toolA", {"names": 10, "found": 10, "share": 1.0}), lib.recognise(a_names))
    check("small: a header of tool B is tool B's, though one name is in both lists", lib.recognise(["Alpha", "B1", "B2", "B3", "B4", "B5"])[0] == "toolB")
    check("small: a header with five names of each tool goes to the tool that has more of it",
          lib.recognise(["Alpha", "Beta", "Twin", "Gamma", "Rep", "B1", "B2", "B3", "B4", "B5", "B6"])[0] == "toolB")
    check("small: names that only look like members are not counted", lib.recognise(["Alpha 1", "Beta#2", "Twin 3", "Gamma#2", "Fam .X", "Mix"])[0] is None)
    check("small: the folders of the documents that exist", lib.documents() == [os.path.join(tmp, "lib_small", "toolA", "document")], lib.documents())
    # a library that cannot be read: no tool, a problem in words, and nothing is recognised (every column is then asked)
    damaged = {
        "no folder": None,
        "an index that is not JSON": "{not json",
        "an index that is a list": "[1, 2]",
        "an index whose tools are a number": '{"tools": 5}',
        "an index whose tools are text": '{"tools": "toolA"}',
        "an index of tools that are not tools": '{"tools": [5, "x", null, {"name": "no key"}, {"key": ["a"], "columns": "toolA/columns.json"}, {"key": "k", "columns": 5}]}',
        "a tool whose column list is missing": '{"tools": [{"key": "gone", "columns": "gone/columns.json"}]}',
    }
    for what, text in damaged.items():
        root = os.path.join(tmp, "lib_damaged_%d" % (abs(hash(what)) % 10 ** 8))
        if text is not None:
            os.makedirs(root, exist_ok=True)
            with open(os.path.join(root, "index.json"), "w", encoding="utf-8") as fh:
                fh.write(text)
        ok, lib2 = no_crash("a damaged library does not stop a run: " + what, lambda root=root: CK.Library(root))
        if ok:
            check("a damaged library does not stop a run: " + what, lib2.tools == {} and lib2.recognise(a_names)[0] is None and lib2.documents() == []
                  and (bool(lib2.problems) or "not tools" in what), (lib2.tools, lib2.problems))
    for what, entries in (("a column list that is a list", None), ("entries that are a number", 5), ("entries that are text", "Alpha"), ("entries that are an object", {"Alpha": {}})):
        root = _small_library(os.path.join(tmp, "lib_odd_%d" % (abs(hash(what)) % 10 ** 8)), entries if entries is not None else [], b)
        if entries is None:
            with open(os.path.join(root, "toolA", "columns.json"), "w", encoding="utf-8") as fh:
                fh.write("[1, 2, 3]")
        ok, lib2 = no_crash("a damaged column list does not stop a run: " + what, lambda root=root: CK.Library(root))
        if ok:
            check("a damaged column list does not stop a run: " + what, lib2.recognise(a_names)[0] is None and "toolB" in lib2.tools
                  and lib2.recognise(["Alpha", "B1", "B2", "B3", "B4", "B5"])[0] == "toolB", (sorted(lib2.tools), lib2.problems))


# ------------------------------------------------------------------------------------------------------------ the store
LF = {"run": 7, "file": "packets.csv", "at": 1000.0}
ADMIN = {"by": "the admin", "at": 2000.0}


def _m(text, kind="model", checked=False, keywords=None, **more):
    """A Data Grounder entry as a run remembers it."""
    src = {"kind": kind, "ref": "model knowledge" if kind in ("model", "data", "admin") else "/ref/doc.md:5", "quote": "" if kind == "model" else "the quote"}
    return dict({"meaning": text, "source": src, "checked": checked, "why": "", "keywords": keywords or {}}, **more)


def _meaning(store, scope, name, typ=None, values=None):
    e = store.match(scope, name, typ, values)
    return e.get("meaning") if e else None


def store_round_trip(tmp):
    folder = os.path.join(tmp, "store_rt", "column_meanings")
    s = CK.Store(folder, TOOL)
    check("opening a store writes nothing", not os.path.exists(folder) and s.columns == {} and s.path == os.path.join(folder, TOOL + ".json"))
    check("saving when nothing was remembered writes nothing", s.save() == 0 and not os.path.exists(folder))
    kws = {"Yes": _m("The mark is set."), "No": _m("The mark is not set.", asked_once_for=["Yes", "No"])}
    check("a meaning is remembered", s.remember("packets", "Marker", _m("A mark the user set on the packet.", keywords=kws), typ="word", values=["Yes", "No"],
                                                learned_from=LF, level="packets") is True)
    check("the same meaning again is nothing new", s.remember("packets", "Marker", _m("A mark the user set on the packet.", keywords=kws), typ="word", values=["Yes", "No"],
                                                               learned_from=LF, level="packets") is False)
    check("it is found before it is saved", _meaning(s, "packets", "Marker", "word", ["Yes"]) == "A mark the user set on the packet.")
    check("saving says how many columns were written", s.save() == 1 and s.save() == 0)
    check("one file, in the store's folder, and no temporary file beside it", all_files_under(os.path.join(tmp, "store_rt")) == [os.path.join("column_meanings", TOOL + ".json")],
          all_files_under(os.path.join(tmp, "store_rt")))
    with open(s.path, encoding="utf-8") as fh:
        d = json.load(fh)
    check("the file says what it is, for which tool and when", set(d) == {"what", "tool", "saved", "columns"} and d["tool"] == TOOL and isinstance(d["saved"], float)
          and list(d["columns"]) == [CK.Store.key("packets", "Marker")], (sorted(d), list(d.get("columns") or {})))
    s2 = CK.Store(folder, TOOL)
    e = s2.match("packets", "Marker", "word", ["No", "Maybe"]) or {}
    want = {"column": "Marker", "meaning": "A mark the user set on the packet.", "source": {"kind": "model", "ref": "model knowledge", "quote": ""}, "checked": False,
            "why": "", "learned_from": LF, "type": "word", "values": ["Yes", "No"], "level": "packets", "scope": "packets"}
    check("a new run reads it back: meaning, source, where it was learned, kind of values, keywords seen", {k: e.get(k) for k in want} == want, e)
    k2 = s2.keywords("packets", "Marker")
    check("a new run reads the keywords' meanings back, each with where it was learned",
          set(k2) == {"Yes", "No"} and k2["Yes"]["meaning"] == "The mark is set." and k2["Yes"]["learned_from"] == LF and k2["No"]["asked_once_for"] == ["Yes", "No"]
          and k2["Yes"]["source"]["kind"] == "model", k2)
    try:
        from agentic import family1
        read = getattr(family1, "_stored_answer", None)
        if read:
            a = read(e)
            check("the Data Grounder's reader of a stored entry takes it", a.get("meaning") == want["meaning"] and a.get("source") == want["source"]
                  and (a.get("stored") or {}).get("file") == "packets.csv", a)
    except Exception as ex:
        check("the Data Grounder's reader of a stored entry takes it", False, "agentic/family1.py could not be used: %s: %s" % (type(ex).__name__, ex))
    # a file of no known tool
    u = CK.Store(folder)
    check("a file of no known tool has a store of its own", os.path.basename(u.path) == "unknown_source.json" and u.tool is None and CK.Store(folder, "").path == u.path
          and u.match("packets", "Marker") is None)
    # an answer of the library is remembered with the library's name; a later answer that is not the library's drops it
    lib = CK.library()
    en, how = lib.lookup(TOOL, "packets", "Packet")
    ans = lib.answer(TOOL, en, "Packet", how)
    s2.remember("packets", "Packet", dict(ans, checked=True, keywords={}), typ="integer", learned_from=LF, library=ans["library"], level="packets")
    s2.save()
    e3 = CK.Store(folder, TOOL).match("packets", "Packet", "hex") or {}
    check("a library answer is remembered with the library's entry and its document quote", e3.get("library") == ans["library"] and e3.get("checked") is True
          and e3.get("source") == ans["source"], e3)
    s4 = CK.Store(folder, TOOL)
    s4.remember("packets", "Packet", _m("Another reading, from the model."), learned_from=dict(LF, run=8))
    check("a later meaning that is not the library's no longer carries the library's name", "library" not in (s4.match("packets", "Packet") or {"library": 1}))
    # the keywords seen with a meaning: the newest first, the earlier ones kept, never more than the most
    s5 = CK.Store(folder, "values_tool")
    s5.remember("f", "C", _m("one"), values=["v%d" % i for i in range(30)])
    first = list((s5.match("f", "C") or {}).get("values") or [])
    s5.remember("f", "C", _m("two"), values=["w%d" % i for i in range(30)] + ["v0"])
    second = list((s5.match("f", "C") or {}).get("values") or [])
    for i in range(5):
        s5.remember("f", "C", _m("more %d" % i), values=["x%d_%d" % (i, j) for j in range(30)])
    third = list((s5.match("f", "C") or {}).get("values") or [])
    check("the keywords kept beside a meaning: the first %d of a file, the newest file first, none twice, never more than %d" % (CK.VALUES_KEPT, CK.VALUES_KEPT_MOST),
          first == ["v%d" % i for i in range(CK.VALUES_KEPT)] and second[:CK.VALUES_KEPT] == ["w%d" % i for i in range(CK.VALUES_KEPT)] and len(second) == len(set(second)) == 2 * CK.VALUES_KEPT
          and len(third) == CK.VALUES_KEPT_MOST and third[0] == "x4_0", (len(first), len(second), len(third)))
    ok, _g = no_crash("keywords that are numbers or nothing are kept as text", lambda: s5.remember("f", "D", _m("d"), values=[1, 2.5, None, True, "", "a"]))
    if ok:
        check("keywords that are numbers or nothing are kept as text", all(isinstance(v, str) for v in s5.match("f", "D")["values"]), s5.match("f", "D")["values"])


def store_match(tmp):
    folder = os.path.join(tmp, "store_match")
    s = CK.Store(folder, TOOL)
    s.remember("packets", "Marker", _m("A mark."), typ="word", values=["Yes", "No"], learned_from=LF)
    s.remember("packets", "Length", _m("The length."), typ="integer", values=["4", "8"], learned_from=LF)
    s.remember("packets", "Bare", _m("Learned with no keyword and no kind of values."), learned_from=LF)
    s.save()
    s = CK.Store(folder, TOOL)
    check("the same column: name, kind of values and one keyword in common", _meaning(s, "packets", "Marker", "word", ["Other", "No"]) == "A mark.")
    check("keywords are compared without their letter case and outer spaces", _meaning(s, "packets", "Marker", "word", ["  yes "]) == "A mark.")
    check("no keyword in common: the name now stands for something else, the column is asked again", s.match("packets", "Marker", "word", ["Maybe", "Perhaps"]) is None)
    check("another kind of values: not the same column", s.match("packets", "Marker", "integer", ["Yes"]) is None and s.match("packets", "Marker", "time", None) is None)
    check("a file whose column holds no keyword: name and kind of values decide", _meaning(s, "packets", "Marker", "word", []) == "A mark."
          and _meaning(s, "packets", "Marker", "word") == "A mark.")
    check("no kind of values given: name and keywords decide", _meaning(s, "packets", "Marker", None, ["Yes"]) == "A mark." and s.match("packets", "Marker", None, ["Zz"]) is None)
    check("whole numbers and hexadecimal numbers are one kind", _meaning(s, "packets", "Length", "hex", ["8"]) == "The length." and s.match("packets", "Length", "word", ["8"]) is None
          and s.match("packets", "Length", "float", ["8"]) is None)
    table = [(None, "word", True), ("word", None, True), ("", "", True), ("word", "word", True), ("integer", "hex", True), ("hex", "integer", True),
             ("integer", "float", False), ("word", "hex", False), ("float", "integer", False), ("time", "word", False)]
    wrong = [(a, b) for a, b, fit in table if CK.types_fit(a, b) is not fit]
    check("which kinds of values fit each other", not wrong, wrong)
    check("an entry learned with no keyword and no kind fits any file's column of that name", _meaning(s, "packets", "Bare", "time", ["anything"]) == "Learned with no keyword and no kind of values.")
    check("another name, another level, another tool: nothing", s.match("packets", "Marker 2") is None and s.match("link", "Marker") is None and s.match("", "Marker") is None
          and s.match(None, "Marker") is None and CK.Store(folder, "other_tool").match("packets", "Marker") is None)
    check("a name is the same name with more or fewer spaces around and inside it", _meaning(s, "packets", "  Marker ") == "A mark.")
    # keywords without a meaning for the column
    s.remember("packets", "Flags", {"meaning": "", "keywords": {"A": _m("The A flag."), "B": _m(""), "C": _m("From a document, not found there.", kind="document")}}, typ="word", learned_from=LF)
    s.remember("packets", "Doc", _m("A document quote that was not found.", kind="document", keywords={"K": _m("A keyword from the model.")}), typ="word", learned_from=LF)
    s.save()
    s = CK.Store(folder, TOOL)
    check("a column with keyword meanings and no meaning of its own is not a match, and its keywords are still given",
          s.match("packets", "Flags") is None and set(s.keywords("packets", "Flags")) == {"A"} and s.match("packets", "Doc") is None and set(s.keywords("packets", "Doc")) == {"K"},
          (s.keywords("packets", "Flags"), s.keywords("packets", "Doc")))
    check("a keyword without a meaning, or with a quote that was not found, is not remembered",
          set((s.columns.get(CK.Store.key("packets", "Flags")) or {}).get("keywords") or {}) == {"A"})
    check("the keywords of a column are given whatever kind of values the file now holds", set(s.keywords("packets", "Marker")) == set() and set(s.keywords("packets", "Flags")) == {"A"}
          and s.keywords("packets", "No such column") == {} and s.keywords("link", "Flags") == {})
    check("nothing to remember is said so, and nothing is written for it", s.remember("packets", "Empty", {"meaning": " ", "keywords": {}}) is False
          and s.remember("packets", "Empty", _m("Not found in its document.", kind="web")) is False and s.save() == 0 and CK.Store.key("packets", "Empty") not in s.columns)


def trusted_rules(tmp):
    table = [(None, False), ("text", False), ({}, False), ({"meaning": "  "}, False), ({"meaning": "x"}, False), ({"meaning": "x", "checked": True}, True),
             (_m("x", "model"), True), (_m("x", "data"), True), (_m("x", "admin"), True), (_m("x", "document"), False), (_m("x", "web"), False),
             (_m("x", "document", True), True), (_m("x", "web", True), True), (_m("x", "something else"), False), (_m("", "model"), False), (_m("", "document", True), False),
             ({"meaning": "x", "source": None}, False), ({"meaning": 5, "checked": True}, True)]
    wrong = [(m, want) for m, want in table if CK.trusted(m) is not want]
    check("worth remembering: checked against its source, or the model's own reading; never an empty meaning or a quote that was not found", not wrong, wrong)
    for what, m in (("a source that is text", {"meaning": "x", "source": "model"}), ("a source that is a list", {"meaning": "x", "source": ["model"]}),
                    ("a source that is a number", {"meaning": "x", "source": 5})):
        ok, got = no_crash("an entry with %s is not trusted, and does not stop a run" % what, lambda m=m: CK.trusted(m))
        if ok:
            check("an entry with %s is not trusted, and does not stop a run" % what, got is False, got)
    s = CK.Store(os.path.join(tmp, "store_trusted"), TOOL)
    s.remember("p", "A", _m("The model's reading."), learned_from=LF)
    check("a quote that was not found does not replace what is remembered", s.remember("p", "A", _m("From a page, not found.", kind="web"), learned_from=LF) is False
          and _meaning(s, "p", "A") == "The model's reading.")
    check("a checked quote replaces the model's reading", s.remember("p", "A", _m("From the document.", kind="document", checked=True), learned_from=LF) is True
          and _meaning(s, "p", "A") == "From the document." and s.match("p", "A")["checked"] is True)
    odd = [("nothing in place of an entry", None), ("text in place of an entry", "a meaning"), ("a list in place of an entry", [1, 2]),
           ("keywords that are a list", dict(_m("m1"), keywords=["a", "b"])), ("keywords that are text", dict(_m("m2"), keywords="a")),
           ("keyword meanings that are not entries", dict(_m("m3"), keywords={"a": "text", "b": None, "c": 5, "d": ["x"]})),
           ("a source that is text", {"meaning": "m4", "source": "model", "keywords": {"k": {"meaning": "kk", "source": "model"}}}),
           ("a meaning that is a number", {"meaning": 5, "source": {"kind": "model"}})]
    for i, (what, m) in enumerate(odd):
        ok, got = no_crash("remembering %s does not stop a run" % what, lambda m=m, i=i: s.remember("p", "Odd %d" % i, m, typ="word", values=["v"], learned_from=LF))
        if ok:
            check("remembering %s does not stop a run" % what, isinstance(got, bool), got)
    ok, n = no_crash("what was remembered from odd entries can be saved and read", lambda: s.save())
    if ok:
        s2 = CK.Store(os.path.join(tmp, "store_trusted"), TOOL)
        check("what was remembered from odd entries can be saved and read", s2.match("p", "Odd 0") is None and s2.match("p", "Odd 1") is None
              and _meaning(s2, "p", "Odd 3") == "m1" and s2.keywords("p", "Odd 5") == {} and _meaning(s2, "p", "A") == "From the document.", sorted(s2.columns))


def store_approved_rules(tmp):
    folder = os.path.join(tmp, "store_approved")
    s = CK.Store(folder, TOOL)
    s.remember("p", "A", _m("First reading.", keywords={"K": _m("K, first.")}), typ="word", values=["x", "y"], learned_from=LF)
    check("approving what was remembered keeps where it was learned", s.remember("p", "A", _m("First reading.", keywords={"K": _m("K, the admin's.")}), approved=ADMIN) is True
          and s.match("p", "A")["approved"] == ADMIN and s.match("p", "A")["learned_from"] == LF and s.keywords("p", "A")["K"]["approved"] == ADMIN)
    check("an approved meaning holds whatever keywords the next file has", _meaning(s, "p", "A", "word", ["never seen", "before"]) == "First reading.")
    check("an approved meaning still needs the kind of values to fit", s.match("p", "A", "time", ["x"]) is None)
    check("a later run's reading does not replace what the admin approved",
          s.remember("p", "A", _m("A later run's reading.", kind="document", checked=True, keywords={"K": _m("K, later."), "N": _m("N, new.")}), typ="integer", values=["z"],
                     learned_from=dict(LF, run=9), library={"tool": TOOL}) is True
          and _meaning(s, "p", "A", "word") == "First reading." and s.match("p", "A", "word")["approved"] == ADMIN and s.match("p", "A", "word")["learned_from"] == LF
          and "library" not in s.match("p", "A", "word") and s.match("p", "A", "word")["values"] == ["x", "y"], s.match("p", "A", "word"))
    k = s.keywords("p", "A")
    check("a later run adds its new keywords to an approved column, and does not replace an approved keyword",
          k["K"]["meaning"] == "K, the admin's." and k["K"].get("approved") == ADMIN and k["N"]["meaning"] == "N, new." and "approved" not in k["N"], k)
    later = {"by": "the admin", "at": 3000.0}
    check("another approval replaces an approved meaning and an approved keyword",
          s.remember("p", "A", _m("The admin's second word.", keywords={"K": _m("K, second word.")}), approved=later) is True and _meaning(s, "p", "A", "word") == "The admin's second word."
          and s.match("p", "A")["approved"] == later and s.keywords("p", "A")["K"]["meaning"] == "K, second word.")
    check("what the admin approved is kept whatever its source, and is not shown as checked",
          s.remember("p", "B", _m("From a page whose quote was not found.", kind="web", keywords={"W": _m("Also not found.", kind="web")}), approved=ADMIN) is True
          and _meaning(s, "p", "B") == "From a page whose quote was not found." and s.match("p", "B")["checked"] is False and s.keywords("p", "B")["W"]["checked"] is False)
    check("an approval of nothing is nothing", s.remember("p", "C", {"meaning": "", "keywords": {"E": _m("")}}, approved=ADMIN) is False and s.match("p", "C") is None)
    s.remember("p", "D", _m("Not approved."), learned_from=LF)
    s.remember("p", "D", _m("Not approved, replaced."), learned_from=dict(LF, run=9))
    check("a meaning that was not approved is replaced by the next run's", _meaning(s, "p", "D") == "Not approved, replaced." and s.match("p", "D")["learned_from"]["run"] == 9)
    s.save()
    s2 = CK.Store(folder, TOOL)
    check("approvals are read back by a new run", s2.match("p", "A", None, ["zz"])["approved"] == later and s2.keywords("p", "A")["K"]["approved"] == later
          and s2.match("p", "B", None, ["zz"])["approved"] == ADMIN and "approved" not in s2.match("p", "D"))
    try:
        from agentic import family1
        part = getattr(family1, "_stored_part", None)
        if part:
            got = part(s2.match("p", "A"))
            check("the Data Grounder's reader shows who approved a stored meaning", got.get("approved_by") == "the admin" and got.get("file") == "packets.csv", got)
    except Exception as ex:
        check("the Data Grounder's reader shows who approved a stored meaning", False, "agentic/family1.py could not be used: %s: %s" % (type(ex).__name__, ex))


def store_scopes(tmp):
    folder = os.path.join(tmp, "store_scopes")
    a, b, u = CK.Store(folder, TOOL), CK.Store(folder, "other_tool"), CK.Store(folder)
    a.remember("packets", "Address", _m("Where a packet goes."), learned_from=LF)
    a.remember("nvme_transaction", "Address", _m("Where a transaction reads or writes."), learned_from=LF)
    b.remember("packets", "Address", _m("Tool B's address."), learned_from=LF)
    u.remember("format_1f3a", "Address", _m("An address in a file of no known tool."), learned_from=LF)
    u.remember("format_77c0", "Address", _m("An address in another file of no known tool."), learned_from=LF)
    check("each store saved its own", (a.save(), b.save(), u.save()) == (2, 1, 2) and sorted(os.listdir(folder)) == ["other_tool.json", TOOL + ".json", "unknown_source.json"],
          sorted(os.listdir(folder)))
    a, b, u = CK.Store(folder, TOOL), CK.Store(folder, "other_tool"), CK.Store(folder)
    check("one name at two levels of one tool: two meanings", _meaning(a, "packets", "Address") == "Where a packet goes."
          and _meaning(a, "nvme_transaction", "Address") == "Where a transaction reads or writes." and a.match("link", "Address") is None)
    check("one name in two tools: two meanings", _meaning(b, "packets", "Address") == "Tool B's address." and b.match("nvme_transaction", "Address") is None)
    check("one name in two files of no known tool: two meanings, and none for a third file", _meaning(u, "format_1f3a", "Address") == "An address in a file of no known tool."
          and _meaning(u, "format_77c0", "Address") == "An address in another file of no known tool." and u.match("format_0000", "Address") is None and u.match("packets", "Address") is None)
    check("no scope and an empty scope are the same scope", CK.Store.key(None, "A") == CK.Store.key("", "A"))
    # the real headers: every column remembered with the library's answer must come back as that column's own answer
    lib, heads, mixed, pairs = CK.library(), real_headers(), [], []
    st = CK.Store(os.path.join(tmp, "store_real"), TOOL)
    given = {}
    for fname, (level, names, _h) in sorted(heads.items()):
        before = CK.previous_names([{"column": n, "position": i} for i, n in enumerate(names)])
        low = {}
        for n in names:
            if CK.is_separator(n):
                continue
            low.setdefault(n.lower(), []).append(n)
            e, how = lib.lookup(TOOL, level, n, before.get(n))
            if e:
                ans = lib.answer(TOOL, e, n, how)
                st.remember(level, n, dict(ans, checked=e["kind"] == "document", keywords={}), learned_from={"run": 1, "file": fname, "at": 1.0}, library=ans["library"], level=level)
                given[(level, n)] = ans["meaning"]
        pairs += [(fname, v) for v in low.values() if len(v) > 1]
    st.save()
    st = CK.Store(os.path.join(tmp, "store_real"), TOOL)
    for (level, n), meaning in given.items():
        if _meaning(st, level, n) != meaning:
            mixed.append((level, n))
    check("the real headers have names that differ only in the case of their letters", bool(pairs), pairs)
    check("every column of the five real headers, remembered and read back, has its own meaning (not that of a column whose name differs only in letter case)",
          not mixed and len(st.columns) == len(given), "%d of %d columns came back with another column's meaning: %s; %d entries for %d columns" % (
              len(mixed), len(given), mixed[:6], len(st.columns), len(given)))
    s = CK.Store(os.path.join(tmp, "store_case"), TOOL)
    s.remember("nvme_transaction", "Timestamp", _m("The time the transaction was seen."), learned_from=LF)
    s.remember("nvme_transaction", "TIMESTAMP", _m("The Timestamp feature of NVMe."), approved=ADMIN)
    s.save()
    s = CK.Store(os.path.join(tmp, "store_case"), TOOL)
    check("two columns whose names differ only in letter case are two columns", _meaning(s, "nvme_transaction", "Timestamp") == "The time the transaction was seen."
          and _meaning(s, "nvme_transaction", "TIMESTAMP") == "The Timestamp feature of NVMe." and "approved" not in (s.match("nvme_transaction", "Timestamp") or {"approved": 1})
          and s.match("nvme_transaction", "timestamp") is None, sorted(s.columns))


def _forget_folder(folder):
    """A store folder with what three runs learned: run 7 from two files, run 8, an earlier run that also had the number 7."""
    a, u = CK.Store(folder, TOOL), CK.Store(folder)
    p7 = {"run": 7, "file": "packets.csv", "at": 1000.0}
    l7 = {"run": 7, "file": "link.csv", "at": 1000.0}
    r8 = {"run": 8, "file": "packets.csv", "at": 1500.0}
    a.remember("packets", "A", _m("A by run 7, packets file.", keywords={"a1": _m("a1 by run 7.")}), typ="word", values=["a1"], learned_from=p7)
    a.remember("link", "B", _m("B by run 7, link file."), learned_from=l7)
    a.remember("packets", "C", _m("C by run 8."), learned_from=r8)
    a.remember("packets", "D", _m("D by run 7, approved."), learned_from=p7)
    a.remember("packets", "D", _m("D by run 7, approved."), approved=ADMIN)
    a.remember("packets", "E", _m("E by run 7.", keywords={"e1": _m("e1 by run 7."), "e3": _m("e3 by run 7, approved.")}), learned_from=p7)
    a.remember("packets", "E", {"meaning": "", "keywords": {"e2": _m("e2 by run 8.")}}, learned_from=r8)
    a.remember("packets", "F", _m("F by an earlier run that had the number 7."), learned_from={"run": 7, "file": "packets.csv", "at": 500.0})
    a.remember("packets", "G", _m("G by run 8.", keywords={"g8": _m("g8 by run 8.")}), learned_from=r8)
    a.remember("packets", "G", {"meaning": "", "keywords": {"g7": _m("g7 by run 7.")}}, learned_from=p7)
    a.remember("packets", "H", _m("H with no time."), learned_from={"run": 7, "file": "packets.csv"})
    a.remember("packets", "I", _m("I with no origin."))
    u.remember("format_x", "U", _m("U by run 7, in a file of no known tool."), learned_from=p7)
    a.save()
    u.save()
    # the admin approves one keyword of E (as the approval of a data dictionary does): only that keyword
    b = CK.Store(folder, TOOL)
    b.remember("packets", "E", {"meaning": "", "keywords": {"e3": _m("e3 by run 7, approved.")}}, approved=ADMIN)
    b.save()
    return CK.Store(folder, TOOL)


def store_forget_run(tmp):
    check("forgetting in a folder that does not exist takes nothing and makes nothing", CK.forget_run(os.path.join(tmp, "no_such_store"), 7) == 0
          and not os.path.exists(os.path.join(tmp, "no_such_store")))
    # one file of the run
    folder = os.path.join(tmp, "forget_file")
    _forget_folder(folder)
    n = CK.forget_run(folder, 7, file="link.csv")
    s, u = CK.Store(folder, TOOL), CK.Store(folder)
    check("forgetting one file of a run takes that file's meanings and no other", n == 1 and s.match("link", "B") is None and _meaning(s, "packets", "A") == "A by run 7, packets file."
          and _meaning(u, "format_x", "U") and len(s.columns) == 8, (n, sorted(s.columns)))
    # the whole run, with the time the run was created
    folder = os.path.join(tmp, "forget_run")
    _forget_folder(folder)
    with open(os.path.join(folder, TOOL + ".json"), "rb") as fh:
        before = fh.read()
    check("forgetting a run that learned nothing takes nothing and leaves the files as they are", CK.forget_run(folder, 99) == 0 and CK.forget_run(folder, 7, file="no_such.csv") == 0
          and open(os.path.join(folder, TOOL + ".json"), "rb").read() == before)
    n = CK.forget_run(folder, 7, since=900.0)
    s, u = CK.Store(folder, TOOL), CK.Store(folder)
    gone = [x for x in (("packets", "A"), ("link", "B"), ("packets", "E"), ("packets", "H")) if s.match(*x) is not None] + ([("format_x", "U")] if u.match("format_x", "U") else [])
    check("forgetting a run takes its meanings out of every store file", not gone and n == 8, "%d taken; still there: %s" % (n, gone))
    check("what another run learned stays", _meaning(s, "packets", "C") == "C by run 8." and _meaning(s, "packets", "G") == "G by run 8." and _meaning(s, "packets", "I") == "I with no origin.")
    check("what the admin approved stays, the meaning and the keyword", _meaning(s, "packets", "D") == "D by run 7, approved." and set(s.keywords("packets", "E")) == {"e2", "e3"}
          and s.keywords("packets", "E")["e3"]["approved"] == ADMIN, s.keywords("packets", "E"))
    check("a keyword the run added to another run's column is taken, the column's meaning and its other keywords stay", set(s.keywords("packets", "G")) == {"g8"})
    check("what an earlier run with the same number learned stays (it is older than the run)", _meaning(s, "packets", "F") == "F by an earlier run that had the number 7.")
    check("a column with nothing left is taken out whole; one with keywords left stays without a meaning",
          CK.Store.key("packets", "A") not in s.columns and CK.Store.key("link", "B") not in s.columns and CK.Store.key("packets", "E") in s.columns
          and "meaning" not in s.columns[CK.Store.key("packets", "E")] and "source" not in s.columns[CK.Store.key("packets", "E")], sorted(s.columns))
    check("forgetting the same run again takes nothing", CK.forget_run(folder, 7, since=900.0) == 0)
    check("without the run's time, the earlier run of the same number is taken too", CK.forget_run(folder, 7) == 1 and CK.Store(folder, TOOL).match("packets", "F") is None)
    # the edge of the time
    folder = os.path.join(tmp, "forget_edge")
    s = CK.Store(folder, TOOL)
    for name, at in (("just before", 998.4), ("a second before", 999.0), ("at", 1000.0), ("after", 5000.0)):
        s.remember("p", name, _m(name), learned_from={"run": 3, "file": "f.csv", "at": at})
    s.save()
    n = CK.forget_run(folder, 3, since=1000.0)
    s = CK.Store(folder, TOOL)
    check("a meaning learned from one second before the run was created on is the run's; an older one is not",
          n == 3 and _meaning(s, "p", "just before") == "just before" and len(s.columns) == 1, (n, sorted(s.columns)))
    # a run without a number is not a run: nothing may be taken for it
    folder = os.path.join(tmp, "forget_none")
    s = CK.Store(folder, TOOL)
    s.remember("p", "No origin", _m("Learned with no origin."))
    s.remember("p", "No run", _m("Learned with a file and no run."), learned_from={"file": "f.csv", "at": 5.0})
    s.save()
    ok, n = no_crash("forgetting a run that has no number takes nothing", lambda: CK.forget_run(folder, None) + CK.forget_run(folder, ""))
    if ok:
        check("forgetting a run that has no number takes nothing", n == 0 and len(CK.Store(folder, TOOL).columns) == 2, (n, sorted(CK.Store(folder, TOOL).columns)))
    # damaged and hand-edited files beside a good one
    folder = os.path.join(tmp, "forget_damaged")
    s = CK.Store(folder, TOOL)
    s.remember("p", "Good", _m("Good, by run 7."), learned_from=LF)
    s.save()
    odd = {"a_not_json.json": "{not json", "b_empty.json": "", "c_list.json": "[1, 2]", "d_number.json": "5", "e_columns_list.json": '{"columns": [1]}',
           "f_entries.json": json.dumps({"columns": {"p|x": 5, "p|y": "text", "p|z": None, "p|k": {"meaning": "k", "keywords": ["a"], "learned_from": "run 7"},
                                                     "p|at": {"meaning": "time as text", "learned_from": {"run": 7, "at": "yesterday"}},
                                                     "p|kw": {"meaning": "m", "learned_from": {"run": 8}, "keywords": {"a": "text", "b": {"meaning": "b", "learned_from": {"run": 7, "at": None}}}}}}),
           "g_not_utf8.json": None, "notes.txt": "not a store file"}
    for fname, text in odd.items():
        with open(os.path.join(folder, fname), "wb") as fh:
            fh.write(b"\xff\xfe\x00{" if text is None else text.encode("utf-8"))
    ok, n = no_crash("damaged and hand-edited store files do not stop the forgetting", lambda: CK.forget_run(folder, 7, since=900.0))
    if ok:
        with open(os.path.join(folder, "f_entries.json"), encoding="utf-8") as fh:
            left = json.load(fh)["columns"]
        check("damaged and hand-edited store files do not stop the forgetting", CK.Store(folder, TOOL).match("p", "Good") is None and n >= 2
              and "b" not in (left.get("p|kw") or {}).get("keywords", {}) and (left.get("p|kw") or {}).get("meaning") == "m" and left.get("p|k", {}).get("meaning") == "k"
              and open(os.path.join(folder, "notes.txt")).read() == "not a store file" and open(os.path.join(folder, "a_not_json.json")).read() == "{not json", (n, left))


def store_odd_names(tmp):
    parent = os.path.join(tmp, "odd")
    folder = os.path.join(parent, "inner", "column_meanings")
    names = ["", " ", None, "a" * 100000, "Größe µs 列 🙂", "../../../outside", "/etc/passwd", "a/b\\c", "C:\\Windows\\x", "..", ".", "name\nwith\tlines", "nul\x00byte", "a|b", "|", "#2",
             "%s", "{0}", "__proto__", "Marker", "MARKER", "marker"]
    s = CK.Store(folder, TOOL)
    for i, n in enumerate(names):
        no_crash("remembering a column named %s" % repr(n)[:30], lambda n=n, i=i: s.remember("../scope/%d" % (i % 3), n, _m("meaning %d" % i), learned_from=LF))
    ok, _n = no_crash("saving columns with odd names", s.save)
    files = all_files_under(parent)
    check("columns with odd names and scopes are written into the store's one file and nowhere else", files == [os.path.join("inner", "column_meanings", TOOL + ".json")], files)
    s2 = CK.Store(folder, TOOL)
    back = [repr(n)[:30] for i, n in enumerate(names) if n and n.strip() and _meaning(s2, "../scope/%d" % (i % 3), n) != "meaning %d" % i]
    check("each odd name is read back with its own meaning", not back, back)
    # tool names
    tools = ["../../outside", "/etc/passwd", "a/b", "a\\b", "..", ".", "...", "~", "con", "tool name", "тест", "列", "x.json", ".hidden", "a\x00b", "a\nb", "$(touch x)", "%2e%2e%2f", "x" * 300, 5]
    inside, wrote = [], 0
    for t in tools:
        ok, st = no_crash("a store for a tool named %s" % repr(t)[:30], lambda t=t: CK.Store(folder, t))
        if not ok:
            continue
        if os.path.dirname(os.path.abspath(st.path)) != os.path.abspath(folder) or not st.path.endswith(".json") or os.path.basename(st.path).startswith("."):
            inside.append((t, st.path[-60:]))
        st.remember("p", "A", _m("A of %r" % (t,)), learned_from=LF)
        try:
            wrote += st.save()
        except OSError:                 # a name the file system does not take (too long): nothing is written, and that is said by the error
            pass
    files = all_files_under(parent)
    check("a store's file is in the store's folder whatever the tool is called, and is not a hidden file (forgetting a run looks through *.json)", not inside, inside)
    check("stores of tools with odd names write into the store's folder and nowhere else",
          wrote >= 10 and all(f.startswith(os.path.join("inner", "column_meanings") + os.sep) and f.endswith(".json") and os.sep not in f[len(os.path.join("inner", "column_meanings")) + 1:]
                              for f in files) and not os.path.exists(os.path.join(tmp, "outside.json")) and not os.path.exists(os.path.join(parent, "outside.json")),
          "%d saved; files: %s" % (wrote, [f[-40:] for f in files][:25]))
    check("nothing was written beside the test's own folder", not [f for f in os.listdir(os.path.dirname(tmp)) if "outside" in f], os.path.dirname(tmp))
    ok, n = no_crash("forgetting with an odd file name", lambda: CK.forget_run(folder, 7, file="../../x"))
    if ok:
        check("forgetting with an odd file name takes nothing", n == 0)


def store_damaged_file(tmp):
    deep = "[" * 100000 + "]" * 100000
    entries = {"p|n": 5, "p|t": "text", "p|none": None,
               CK.Store.key("p", "KwList"): {"meaning": "keywords are a list", "keywords": ["a", "b"]},
               CK.Store.key("p", "KwText"): {"meaning": "keyword meanings are text", "keywords": {"a": "text", "b": 5, "c": None, "ok": {"meaning": "a real one"}}},
               CK.Store.key("p", "Values"): {"meaning": "values are a number", "values": 5, "type": "word"},
               CK.Store.key("p", "ValuesText"): {"meaning": "values are text", "values": "Yes"},
               CK.Store.key("p", "Source"): {"meaning": "the source is text", "source": "a manual", "learned_from": "run 7", "approved": "yes"},
               CK.Store.key("p", "Meaning"): {"meaning": 5},
               CK.Store.key("p", "Type"): {"meaning": "the type is a list", "type": ["word"]},
               CK.Store.key("p", "Fine"): {"meaning": "an entry that is in order", "source": {"kind": "model"}, "values": ["Yes"], "keywords": {"Yes": {"meaning": "yes"}}}}
    cases = [("text that is not JSON", b"{not json"), ("an empty file", b""), ("a list", b"[1, 2]"), ("a number", b"5"), ("nothing (null)", b"null"),
             ("columns that are a list", b'{"columns": [1, 2]}'), ("columns that are text", b'{"columns": "x"}'), ("no columns", b'{"tool": "x"}'),
             ("bytes that are not text", b"\xff\xfe\x00{\x80"), ("half a file (cut while it was written)", b'{"what": "x", "columns": {"p|a": {"meaning": "cut'),
             ("brackets nested 100,000 deep", deep.encode()), ("hand-edited entries of odd shapes", json.dumps({"columns": entries}).encode())]
    for i, (what, raw) in enumerate(cases):
        folder = os.path.join(tmp, "damaged_%d" % i)
        os.makedirs(folder)
        with open(os.path.join(folder, TOOL + ".json"), "wb") as fh:
            fh.write(raw)

        def run(folder=folder, hand="hand-edited" in what):
            s = CK.Store(folder, TOOL)
            out = []
            for name in ("KwList", "KwText", "Values", "ValuesText", "Source", "Meaning", "Type", "Fine", "No such"):
                e = s.match("p", name, "word", ["Yes", "x"])
                k = s.keywords("p", name)
                out.append((name, bool(e), sorted(k)))
                if e:                               # what the Data Grounder reads of a stored entry must be of the right kind
                    assert isinstance(e.get("source") or {}, dict) and isinstance(e.get("keywords") or {}, dict) and isinstance(e.get("values") or [], list), (name, e)
                s.remember("p", name, _m("understood anew: %s" % name, keywords={"a": _m("a anew"), "Yes": _m("yes anew")}), typ="word", values=["Yes"], learned_from=LF)
            n = s.save()
            s2 = CK.Store(folder, TOOL)
            assert n == 9 and all(_meaning(s2, "p", name, "word", ["Yes"]) for name in ("KwList", "Fine", "No such")), (n, sorted(s2.columns))
            assert CK.forget_run(folder, 7) >= 9
            if hand:
                assert out[-2] == ("Fine", True, ["Yes"]), out
                assert dict((a, c) for a, _b, c in out)["KwText"] == ["ok"], out
            return out
        ok, got = no_crash("a store file that is %s does not stop a run: its columns are understood anew and saved" % what, run)
        if ok:
            check("a store file that is %s does not stop a run: its columns are understood anew and saved" % what, True, got if "hand" in what else "")
    # a store whose folder cannot be made: the error is the file system's own, and what was remembered is not lost for a later save
    blocker = os.path.join(tmp, "a_file_in_the_way")
    with open(blocker, "w") as fh:
        fh.write("x")
    s = CK.Store(os.path.join(blocker, "column_meanings"), TOOL)
    s.remember("p", "A", _m("kept in memory"), learned_from=LF)
    try:
        s.save()
        raised = None
    except OSError as e:
        raised = e
    except Exception as e:      # any other kind of error would be a surprise to the caller
        raised = "unexpected %s: %s" % (type(e).__name__, e)
    check("when the store's folder cannot be written, saving fails with the file system's error and the run still has its meanings",
          isinstance(raised, OSError) and _meaning(s, "p", "A") == "kept in memory" and open(blocker).read() == "x", raised)
    s.folder, s.path = os.path.join(tmp, "moved"), os.path.join(tmp, "moved", TOOL + ".json")
    check("and a later save to a folder that can be written writes them", s.save() == 1 and _meaning(CK.Store(os.path.join(tmp, "moved"), TOOL), "p", "A") == "kept in memory")


def store_two_saves(tmp):
    # two runs, each with its own view of the file, save one after the other
    folder = os.path.join(tmp, "two_saves")
    one, two = CK.Store(folder, TOOL), CK.Store(folder, TOOL)
    one.remember("p", "A", _m("A, by the first run."), learned_from=dict(LF, run=1))
    two.remember("p", "B", _m("B, by the second run."), learned_from=dict(LF, run=2))
    one.save()
    two.save()
    s = CK.Store(folder, TOOL)
    check("two runs that save one after the other keep each other's columns", _meaning(s, "p", "A") == "A, by the first run." and _meaning(s, "p", "B") == "B, by the second run.", sorted(s.columns))
    check("after its save a run sees what the other one wrote", _meaning(two, "p", "A") == "A, by the first run." and one.match("p", "B") is None)
    # the same column, another keyword from each
    one, two = CK.Store(folder, TOOL), CK.Store(folder, TOOL)
    one.remember("p", "A", {"meaning": "", "keywords": {"k1": _m("k1, by the first run.")}}, learned_from=dict(LF, run=1))
    two.remember("p", "A", {"meaning": "", "keywords": {"k2": _m("k2, by the second run.")}}, learned_from=dict(LF, run=2))
    one.save()
    two.save()
    s = CK.Store(folder, TOOL)
    check("two runs that each add a keyword to the same column keep each other's keyword", set(s.keywords("p", "A")) == {"k1", "k2"} and _meaning(s, "p", "A") == "A, by the first run.",
          sorted(s.keywords("p", "A")))
    # the admin approves while a run that opened the store earlier is still working
    slow = CK.Store(folder, TOOL)
    admin = CK.Store(folder, TOOL)
    admin.remember("p", "B", _m("B, as the admin approved it.", keywords={"kb": _m("kb, approved.")}), approved=ADMIN)
    admin.save()
    slow.remember("p", "B", _m("B, by a run that did not see the approval.", keywords={"kb": _m("kb, not approved."), "kn": _m("kn, new.")}), learned_from=dict(LF, run=3))
    slow.save()
    s = CK.Store(folder, TOOL)
    check("a run that opened the store before an approval does not write over the approved meaning",
          _meaning(s, "p", "B") == "B, as the admin approved it." and (s.match("p", "B") or {}).get("approved") == ADMIN, s.match("p", "B"))
    check("nor over the approved keyword, and its own new keyword is kept", s.keywords("p", "B").get("kb", {}).get("meaning") == "kb, approved."
          and s.keywords("p", "B").get("kn", {}).get("meaning") == "kn, new.", s.keywords("p", "B"))
    # a later approval does replace an earlier one, also from an older view
    slow = CK.Store(folder, TOOL)
    admin = CK.Store(folder, TOOL)
    admin.remember("p", "B", _m("B, approved first."), approved=ADMIN)
    admin.save()
    slow.remember("p", "B", _m("B, approved second."), approved={"by": "the admin", "at": 3000.0})
    slow.save()
    check("the approval that is saved last stands", _meaning(CK.Store(folder, TOOL), "p", "B") == "B, approved second.")
    # a run is rejected while another run that opened the store earlier is still working
    folder = os.path.join(tmp, "two_forget")
    first = CK.Store(folder, TOOL)
    first.remember("p", "X", _m("X, by run 7.", keywords={"x7": _m("x7, by run 7.")}), learned_from=LF)
    first.remember("p", "Y", _m("Y, by run 7."), learned_from=LF)
    first.save()
    slow = CK.Store(folder, TOOL)                   # sees run 7's meanings
    taken = CK.forget_run(folder, 7)                # the admin rejects run 7
    slow.remember("p", "X", {"meaning": "", "keywords": {"x9": _m("x9, by run 9.")}}, learned_from=dict(LF, run=9))
    slow.remember("p", "Z", _m("Z, by run 9."), learned_from=dict(LF, run=9))
    slow.save()
    s = CK.Store(folder, TOOL)
    check("a rejected run's meanings do not come back with the save of a run that had read them before",
          taken == 3 and s.match("p", "X") is None and s.match("p", "Y") is None and set(s.keywords("p", "X")) == {"x9"} and _meaning(s, "p", "Z") == "Z, by run 9.",
          (taken, sorted(s.columns), s.columns.get(CK.Store.key("p", "X"))))
    # an entry the admin deleted from the file by hand stays deleted
    folder = os.path.join(tmp, "two_deleted")
    first = CK.Store(folder, TOOL)
    first.remember("p", "Keep", _m("kept"), learned_from=LF)
    first.remember("p", "Deleted", _m("deleted by hand"), learned_from=LF)
    first.save()
    slow = CK.Store(folder, TOOL)
    with open(first.path, encoding="utf-8") as fh:
        d = json.load(fh)
    del d["columns"][CK.Store.key("p", "Deleted")]
    with open(first.path, "w", encoding="utf-8") as fh:
        json.dump(d, fh)
    slow.remember("p", "New", _m("new"), learned_from=LF)
    slow.save()
    s = CK.Store(folder, TOOL)
    check("an entry deleted from the file by hand does not come back with another run's save", s.match("p", "Deleted") is None and _meaning(s, "p", "Keep") == "kept"
          and _meaning(s, "p", "New") == "new" and slow.match("p", "Deleted") is None)
    # many runs at the same moment
    folder = os.path.join(tmp, "two_threads")
    gate, errors = threading.Barrier(8), []

    def worker(i):
        try:
            st = CK.Store(folder, TOOL)
            for j in range(50):
                st.remember("p", "T%d C%d" % (i, j), _m("meaning %d %d" % (i, j)), learned_from=dict(LF, run=i))
            st.remember("p", "Shared", {"meaning": "", "keywords": {"k%d" % i: _m("keyword of run %d" % i)}}, learned_from=dict(LF, run=i))
            gate.wait(timeout=30)
            st.save()
        except Exception as e:
            errors.append("%s: %s" % (type(e).__name__, e))
    threads = [threading.Thread(target=worker, args=(i,)) for i in range(8)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(60)
    s = CK.Store(folder, TOOL)
    check("eight runs saving at the same moment lose nothing: 400 columns and the eight keywords of the column they share",
          not errors and len(s.columns) == 401 and set(s.keywords("p", "Shared")) == {"k%d" % i for i in range(8)} and os.listdir(folder) == [TOOL + ".json"],
          (errors[:2], len(s.columns), sorted(s.keywords("p", "Shared")), os.listdir(folder)))


CASES = (library_real_headers, library_not_recognised, library_lookup, library_quotes, library_rules_on_a_small_one,
         store_round_trip, store_match, trusted_rules, store_approved_rules, store_scopes, store_forget_run, store_odd_names, store_damaged_file, store_two_saves)


def main():
    del FAILED[:]
    COUNT[0] = 0
    base = os.environ.get("F2T_TEST_TMP") or None
    if base:
        os.makedirs(base, exist_ok=True)
    tmp = tempfile.mkdtemp(prefix="column_knowledge_", dir=base)
    try:
        for case in CASES:
            try:
                case(tmp)
            except Exception as e:          # a case that breaks is a failed check, and the other cases still run
                check("%s ran to its end" % case.__name__, False, "%s: %s" % (type(e).__name__, e))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("%d checks: %s" % (COUNT[0], "%d failed: %s" % (len(FAILED), "; ".join(FAILED)) if FAILED else "all checks passed"), flush=True)
    return 1 if FAILED else 0


def test_column_knowledge():
    """The same checks under pytest."""
    assert main() == 0, FAILED


if __name__ == "__main__":
    sys.exit(main())
