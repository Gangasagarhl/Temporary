#!/usr/bin/env python3
"""Build hierarchy read in parts by all cores, against the one-core path (2026-11-12).

Offline: no server, no model, no network, its own temporary folders. What is proven:
  1. the cell readers and the row parser give exactly what the code before the speed-up gave (that code is kept below as the reference);
  2. a five-file set read in parts gives the staging tables, the tree and the findings of the same set read on one core: the columns, the row counts and a hash of every
     table that does not depend on the order of the rows, the indexes, and the reports without their timings;
  3. the cases that could break reading in parts: a file smaller than one part, line breaks inside quoted cells, a part cut inside a quoted cell, both header layouts,
     an empty file, a file of the five not given, a worker that fails (the file is then read on one core), a worker that is killed (the load stops with its plain reason),
     lines that end with a carriage return alone;
  4. the tree still links by identity as the generator's truth file says, read in parts or not; the rules read the command of a packet only where a rule fires, with the
     same findings; the parent index is there after the build.

Run: python3 tests/test_hierarchy_parallel.py
"""
import concurrent.futures
import contextlib
import csv
import hashlib
import json
import operator
import os
import random
import re
import sqlite3
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)
from nvme_hier import builder as B, columns as C, loader as L, parse as P, rules as R   # noqa: E402
import test_nvme_hier as T                                                              # noqa: E402  (make_files, _generated_set)

TABLES = ("pkt", "lnk", "spl", "ntx", "cmd")
ONE_CORE = {"WORKERS": 1}
# three workers and parts of 64 kB on every file, however small: many part boundaries on a set of a few megabytes
IN_PARTS = {"WORKERS": 3, "PARALLEL_MIN_BYTES": 0, "CHUNK_BYTES": 64 * 1024, "MIN_CHUNK_BYTES": 16 * 1024}


@contextlib.contextmanager
def loader(**settings):
    """The loader's module settings for the length of one block, put back afterwards whatever happens."""
    before = {k: getattr(L, k) for k in settings}
    for k, v in settings.items():
        setattr(L, k, v)
    try:
        yield
    finally:
        for k, v in before.items():
            setattr(L, k, v)


# what may differ between two ways of reading the same files: how long it took, how it was read, where the files lie
NOT_COMPARED = {"seconds", "parallel", "path", "read_on_one_core_because"}


def _clean(v):
    if isinstance(v, dict):
        return {k: _clean(x) for k, x in sorted(v.items()) if k not in NOT_COMPARED}
    return [_clean(x) for x in v] if isinstance(v, list) else v


def signature(db, meta=True):
    """Per table: its columns, its number of rows and a hash that does not depend on row order (the sum of one hash per row); every index; the stored reports."""
    con = sqlite3.connect(db)
    out = {"tables": {}, "indexes": {}, "meta": {}}
    for (t,) in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall():
        if t == "meta":
            for k, v in con.execute("SELECT k, v FROM meta ORDER BY k") if meta else ():
                try:
                    out["meta"][k] = _clean(json.loads(v))
                except ValueError:
                    out["meta"][k] = v
            continue
        total = n = 0
        for row in con.execute("SELECT * FROM %s" % t):
            total = (total + int.from_bytes(hashlib.blake2b(repr(row).encode(), digest_size=16).digest(), "big")) % (1 << 128)
            n += 1
        out["tables"][t] = {"columns": [r[1] for r in con.execute("PRAGMA table_info(%s)" % t)], "rows": n, "hash": "%032x" % total}
    for name, sql in con.execute("SELECT name, sql FROM sqlite_master WHERE type='index' AND sql IS NOT NULL ORDER BY name"):
        out["indexes"][name] = " ".join(sql.split())
    con.close()
    return out


def differences(a, b, path=""):
    if isinstance(a, dict) and isinstance(b, dict):
        out = []
        for k in sorted(set(a) | set(b)):
            out += ["%s/%s is in one only" % (path, k)] if k not in a or k not in b else differences(a[k], b[k], "%s/%s" % (path, k))
        return out
    return [] if a == b else ["%s: %s | %s" % (path, str(a)[:80], str(b)[:80])]


def whole_step(files, db, settings, progress=None):
    """What the Build hierarchy job does to one upload: load the files, build the tree, apply the rules. Returns (load reports, build report, rules report)."""
    for f in (db, db + "-wal", db + "-shm"):
        if os.path.exists(f):
            os.remove(f)
    with loader(**settings):
        rep = L.load_upload(db, files, progress=progress)
    return rep, B.build(db), R.apply(db, {})


def table_only(path, key, settings, progress=None):
    """One file into its table. Returns (load report, row count, order-independent signature of the table)."""
    db = path + (".parts" if settings is not ONE_CORE else ".one") + ".sqlite"
    with loader(**settings):
        rep = L.load_upload(db, {key: path}, progress=progress)[key]
    return rep, signature(db, meta=False)["tables"].get(L.TABLE[key])


@pytest.fixture(scope="module")
def generated(tmp_path_factory):
    """One small recording made by the application's generator, exported at the five levels, with the generator's own truth file (which packet belongs to which
    link transaction, split transaction, NVMe transaction and command)."""
    files, truth = T._generated_set(str(tmp_path_factory.mktemp("generated")))
    return files, truth


@pytest.fixture(scope="module")
def one_core(generated, tmp_path_factory):
    db = str(tmp_path_factory.mktemp("one_core") / "hier.sqlite")
    return (db,) + whole_step(generated[0], db, ONE_CORE)


# ------------------------------------------------------------------ 1. the reference: the code as it was before 2026-11-12
_TS = re.compile(r"^\s*(\d+)\.(\d{1,12})\s*s?\s*$")
_INT = re.compile(r"^\s*(0[xX][0-9A-Fa-f]+|-?\d+)")
_HEX_ONLY = re.compile(r"^\s*[0-9A-Fa-f]+\s*$")
_ADDR64 = re.compile(r"^\s*(?:0[xX])?([0-9A-Fa-f]{1,8}):([0-9A-Fa-f]{8})\s*$")


def ref_time_stamp_ps(s):
    if not s:
        return None
    m = _TS.match(s)
    if not m:
        return None
    sec, frac = m.group(1), m.group(2)
    return int(sec) * P.SEC + int(frac.ljust(12, "0")[:12])


def ref_int_value(s, hex_default=False):
    if s is None:
        return None
    s = str(s).strip()
    if not s:
        return None
    m = _INT.match(s)
    if m:
        tok = m.group(1)
        if len(tok.lstrip("-")) > 20:
            return None
        if tok.lower().startswith("0x"):
            return int(tok, 16)
        if hex_default and _HEX_ONLY.match(s) and not s.isdigit():
            return int(s, 16) if len(s) <= 16 else None
        if hex_default and _HEX_ONLY.match(s) and len(s) >= 8:
            return int(s, 16) if len(s) <= 16 else None
        return int(tok)
    if hex_default and _HEX_ONLY.match(s):
        return int(s, 16) if len(s) <= 16 else None
    return None


def ref_address(s):
    if not s:
        return None
    m = _ADDR64.match(s)
    if m:
        return (int(m.group(1), 16) << 32) | int(m.group(2), 16)
    v = ref_int_value(s, hex_default=True)
    return v if v is None or 0 <= v < 2 ** 63 else None


def ref_parse_rows(rows, typed, named, sql_cols, unread, blanks):
    out = []
    names = [c for c, _ in named]
    picks = [i for _, i in named]
    fetch = operator.itemgetter(*picks) if len(picks) > 1 else (lambda r: (r[picks[0]],)) if picks else (lambda r: ())
    width = 1 + max(picks + [t[0] for t in typed] + [-1])
    memo = {t[0]: {} for t in typed}
    for row in rows:
        if not any(c.strip() for c in row):
            continue
        if len(row) < width:
            row = row + [""] * (width - len(row))
        vals = {}
        for idx, sql, fn, cname in typed:
            cell = row[idx]
            if cell == "":
                if sql not in vals:
                    vals[sql] = None
                continue
            known = memo[idx]
            if cell in known:
                v = known[cell]
                if v is None:
                    L._note_unread(cell, cname, unread)
            else:
                v = L._value(fn, cell, cname, unread)
                if len(known) < L.MEMO_PER_COLUMN:
                    known[cell] = v
            if sql in vals and vals[sql] is not None:
                continue
            vals[sql] = v
        typed_vals = [vals.get(s_) for s_ in sql_cols]
        for sql, v in zip(sql_cols, typed_vals):
            if v is None:
                blanks[sql] += 1
        out.append(typed_vals + [L._COMPACT({n: c for n, c in zip(names, fetch(row)) if c != ""})])
    return out


CELLS = ["0000.162047440000s", "12.5", "12.5 s", " 7.000000000001s ", "1.0000000000001s", "0.s", ".5s", "5.", "5.5ss", "5.5S", "١.٥s", "0x00000000FCE00000", "FCE00000", "0XFCE0",
         "0x", "0xg", "00000004:800A0000", "0x00000004:800A0000", "1234567", "12345678", "00000010", "0000010", "12AB", "-5", "+5", "0x1A (Read)", "26 (Read)", "²", "１２", "٣",
         "FFFFFFFFFFFFFFFF", "7FFFFFFFFFFFFFFF", "8000000000000000", "0x7FFFFFFFFFFFFFFF", "0x8000000000000000", "0x" + "F" * 18, "0x" + "0" * 19, "1" * 20, "1" * 21, "9" * 16,
         "9" * 17, "A" * 17, "", " ", "\n", "5\n", "5.5s\n", "0x5\n", "abc", "0b11", "1_000", "1e5", "0o7", "5.5\x00s", "﻿5"]


def _fuzzed_cells(n, seed=20261112):
    rnd = random.Random(seed)
    alphabet = "0123456789abcdefABCDEFxX.:s -+\t\n\r gGzZ()µ٣²０"
    yield from CELLS
    for _ in range(n):
        base, k = rnd.choice(CELLS), rnd.random()
        if k < 0.35:                                    # a real spelling with one character put in
            cut = rnd.randrange(len(base) + 1)
            yield base[:cut] + rnd.choice(alphabet) + base[cut:]
        elif k < 0.6:                                   # anything
            yield "".join(rnd.choice(alphabet) for _ in range(rnd.randrange(1, 24)))
        elif k < 0.8:                                   # hex digits of every length, with and without 0x
            yield ("0x" if rnd.random() < 0.5 else "") + "".join(rnd.choice("0123456789ABCDEFabcdef") for _ in range(rnd.randrange(1, 23)))
        else:                                           # digits of every length, with the endings of a time stamp
            yield "".join(rnd.choice("0123456789") for _ in range(rnd.randrange(1, 24))) + rnd.choice(["", ".", ".5s", "s", ".123456789012s", ".1234567890123s", " "])


def test_cell_readers_give_what_they_gave_before():
    """The three readers that got a short way for the usual cell (time stamp, whole number, address) against the code before: the same value for every cell,
    usual or not, 120,000 of them made from real spellings with characters put in, taken out and replaced."""
    def outcome(fn, cell):
        try:
            return fn(cell)
        except (ValueError, OverflowError) as e:        # digits too many for a number: both must refuse alike (the loader counts the cell as unreadable)
            return type(e).__name__
    cells = list(_fuzzed_cells(120000)) + [None]
    for name, ref, new in (("time stamp", ref_time_stamp_ps, P.time_stamp_ps), ("whole number", ref_int_value, P.int_value),
                           ("whole number, hex", lambda s: ref_int_value(s, True), lambda s: P.int_value(s, True)), ("address", ref_address, P.address)):
        bad = [(c, outcome(ref, c), outcome(new, c)) for c in cells if outcome(ref, c) != outcome(new, c)]
        assert not bad, (name, len(bad), bad[:5])
    # the usual cells give the documented values
    assert P.time_stamp_ps("0000.162047440000s") == 162047440000 and P.time_stamp_ps("0001.5") == 10 ** 12 + 5 * 10 ** 11
    assert P.address("0x00000000FCE00000") == 0xFCE00000 == P.address("FCE00000") and P.address("1234567") == 1234567 and P.address("12345678") == 0x12345678
    assert P.int_value("495440") == 495440 and P.int_value("1" * 21) is None


def _plan(key, path, limit=3000):
    """The loader's plan for one file (typed columns, named columns, table columns) and the file's first rows."""
    with open(path, "r", encoding="utf-8-sig", errors="replace", newline="") as fh:
        rd = L.read_csv(fh, path)
        header = next(rd)
        al = L.align_header(key, header, L.prescan_values(path, L.ambiguous_columns(key, header)))
        typed, sql_cols = [], []
        for cname, sql, fn in L.KEYS[key]:
            if cname in al.positions and sql not in sql_cols:
                sql_cols.append(sql)
            if cname in al.positions:
                typed.append((al.positions[cname], sql, fn, cname))
        named = sorted(al.positions.items(), key=lambda kv: kv[1]) + [(h, i) for i, h in al.unknown] + [("column %d" % (i + 1), i) for i in al.separators]
        rows = [r for _, r in zip(range(limit), rd)]
    return typed, named, sql_cols, rows, len(header)


def _awkward_rows(rows, width, seed):
    """Rows that go for the raw text and the counts: blank rows, short and long rows, quotes, backslashes, control and non-ASCII characters, cells no reader can read."""
    rnd = random.Random(seed)
    odd = ["", " ", "\t", "\"", "\\", "a\"b\\c", "line1\nline2", "\r", "\x00", "\x1f", "\x7f", "é", "日本", "\U0001f600", "\ud800", "</script>", "0x", "12 (Read)", "-1", "1" * 30,
           "nope", "  5  ", "0000.5s", "1.5 us", " ", "{}", "null", "[1,2]", "a,b", "'"]
    out = [[], [""], [" "] * width, ["\t"], [""] * (width + 3), ["x"], ["", "", "x"]]
    for r in rows[:300]:
        r = list(r)
        for _ in range(rnd.randrange(1, 8)):
            r[rnd.randrange(len(r))] = rnd.choice(odd)
        k = rnd.random()
        out.append(r[:rnd.randrange(len(r))] if k < 0.15 else r + [rnd.choice(odd)] * rnd.randrange(1, 4) if k < 0.25 else r)
    return out


def test_row_parser_gives_what_it_gave_before(generated):
    """parse_rows against the code before: the same typed values, the same raw text, the same unreadable cells and the same counts of empty key cells, on the rows
    of all five levels as exported, on awkward rows, and when two columns carry one name (the later one's cell is the one kept in the raw text)."""
    for seed, key in enumerate(C.LEVEL_ORDER):
        typed, named, sql_cols, rows, width = _plan(key, generated[0][key])
        awkward = _awkward_rows(rows, width, seed)
        same_name = [(n if i % 7 else "one name", j) for i, (n, j) in enumerate(named)]
        for label, rr, nm in (("as exported", rows, named), ("awkward rows", awkward, named), ("two columns of one name", rows[:200] + awkward, same_name)):
            got = {}
            for who, fn in (("before", ref_parse_rows), ("now", L.parse_rows)):
                unread, blanks = {}, {s: 0 for s in sql_cols}
                out = []
                for i in range(0, len(rr), 500):                # several calls, as the loader makes them: the counts add up across calls
                    out += fn(iter(rr[i:i + 500]), typed, nm, sql_cols, unread, blanks)
                got[who] = ([list(x) for x in out], unread, blanks)
            assert len(got["now"][0]) > 0, (key, label)
            assert got["before"][0] == got["now"][0], (key, label, "rows")
            assert got["before"][1] == got["now"][1], (key, label, "unreadable cells")
            assert got["before"][2] == got["now"][2], (key, label, "empty key cells")
            for r in got["now"][0][:50]:                         # the raw text is JSON that reads back as the row's filled cells
                assert isinstance(json.loads(r[-1]), dict)


def test_part_size_follows_the_workers():
    """A part is the file's size over the workers, at most CHUNK_BYTES (the memory one worker takes is set by it) and at least MIN_CHUNK_BYTES."""
    mb = 1024 * 1024
    assert L.part_bytes(326 * mb, 7) == L.CHUNK_BYTES == 16 * mb
    assert L.part_bytes(40 * mb, 7) == 40 * mb // 7 + 1
    assert L.part_bytes(3 * mb, 7) == L.MIN_CHUNK_BYTES == mb
    assert L.part_bytes(0, 0) == L.MIN_CHUNK_BYTES
    assert L.PARTS_MIN_BYTES <= L.PARALLEL_MIN_BYTES == 64 * mb       # the file size from which a file was read in parts before; other code reads it


# ------------------------------------------------------------------ 2. in parts = on one core
def _truth_tally(db, truth_path):
    """Links of the tree against the generator's truth file: right, wrong, missing (truth has a parent, the tree none), extra (the tree has a parent, truth none)."""
    con = sqlite3.connect(db)
    n_of = {t: dict(con.execute("SELECT rowid_file, n FROM %s" % t)) for t in ("lnk", "spl", "ntx", "cmd")}
    t_link, l_split, l_ntx, x_cmd = {}, {}, {}, {}
    for r in csv.DictReader(open(truth_path)):
        lk = int(r["link"]) if r["link"] else None
        if r["packet"]:
            t_link[int(r["packet"])] = lk
        if lk is not None:
            l_split.setdefault(lk, int(r["split"]) if r["split"] else None)
            l_ntx.setdefault(lk, int(r["ntx"]) if r["ntx"] else None)
        if r["ntx"]:
            x_cmd.setdefault(int(r["ntx"]), int(r["cmd"]) if r["cmd"] else None)
    spl_par = {rid: (lvl, par) for rid, lvl, par in con.execute("SELECT rowid_file, parent_level, parent FROM spl")}

    def tally(pairs):
        out = {"right": 0, "wrong": 0, "missing": 0, "extra": 0}
        for tree, truth in pairs:
            if tree is not None or truth is not None:
                out["right" if tree == truth else "missing" if tree is None else "extra" if truth is None else "wrong"] += 1
        return out

    def ntx_of(lvl, par):
        if lvl == "split" and par:
            lvl, par = spl_par.get(par, (None, None))
        return n_of["ntx"].get(par) if lvl == "nvme_transaction" and par else None
    links = con.execute("SELECT n, parent_level, parent FROM lnk").fetchall()
    res = {"packet to link": tally((n_of["lnk"].get(par) if lvl == "link" and par else None, t_link[n])
                                   for n, lvl, par in con.execute("SELECT n, parent_level, parent FROM pkt") if n in t_link),
           "link to split": tally((n_of["spl"].get(par) if lvl == "split" and par else None, l_split[n]) for n, lvl, par in links if n in l_split),
           "link to NVMe transaction": tally((ntx_of(lvl, par), l_ntx[n]) for n, lvl, par in links if n in l_ntx),
           "NVMe transaction to command": tally((n_of["cmd"].get(par) if lvl == "nvme_command" and par else None, x_cmd[n])
                                                for n, lvl, par in con.execute("SELECT n, parent_level, parent FROM ntx") if n in x_cmd)}
    con.close()
    return res


def test_parts_give_the_one_core_tables_tree_and_findings(generated, one_core, tmp_path):
    """The whole step on one core and in parts (three workers, 64 kB parts, so that every file is cut many times): the same rows in every table, the same parents,
    the same findings, the same indexes, the same reports. And the links are the generator's: no packet, link or split under a wrong parent, read either way."""
    files, truth = generated
    db1, rep1, build1, rules1 = one_core
    db3 = str(tmp_path / "parts.sqlite")
    rep3, build3, rules3 = whole_step(files, db3, IN_PARTS)
    for key in C.LEVEL_ORDER:
        assert rep1[key]["parallel"] is None and "read_on_one_core_because" not in rep1[key], (key, rep1[key].get("parallel"))
        assert rep3[key]["parallel"]["workers"] >= 1 and "read_on_one_core_because" not in rep3[key], (key, rep3[key])
        assert rep3[key]["rows"] == rep1[key]["rows"] > 0, key
    assert rep3["packets"]["parallel"]["chunks"] >= 8 and rep3["link"]["parallel"]["chunks"] >= 3, rep3["packets"]["parallel"]      # the boundaries are really there
    s1, s3 = signature(db1), signature(db3)
    assert set(TABLES) | {"finding"} <= set(s1["tables"]), sorted(s1["tables"])
    assert not differences(s1, s3), differences(s1, s3)[:10]
    assert _clean(build1) == _clean(build3) and _clean(rules1) == _clean(rules3)
    assert rules1["findings"] > 0
    t1, t3 = _truth_tally(db1, truth), _truth_tally(db3, truth)
    assert t1 == t3, (t1, t3)
    for join in ("packet to link", "link to split", "link to NVMe transaction"):
        assert t1[join]["right"] > 0 and t1[join]["wrong"] == t1[join]["missing"] == t1[join]["extra"] == 0, (join, t1[join])
    # NVMe transaction to command: the only differences test_nvme_hier allows are completion-queue head doorbells that share a head value (a modelling choice)
    assert t1["NVMe transaction to command"]["missing"] == t1["NVMe transaction to command"]["extra"] == 0, t1
    # rows without a parent are counted in the build report and marked in the table, not dropped: every row of the file is still there
    con = sqlite3.connect(db3)
    for key, level in (("link", "link"), ("split", "split"), ("nvme_transaction", "nvme_transaction")):
        t = L.TABLE[key]
        outside = con.execute("SELECT COUNT(*) FROM %s WHERE relation='orphan'" % t).fetchone()[0]
        assert outside == build3["checks"]["%s_outside_any_parent" % level], (key, outside, build3["checks"])
        assert con.execute("SELECT COUNT(*) FROM %s WHERE parent IS NULL AND relation IS NULL" % t).fetchone()[0] == 0, key
    con.close()


def test_a_file_smaller_than_one_part(tmp_path):
    """Three rows per file: one part, one worker, and the tables of the one-core pass."""
    paths, _ = T.make_files(str(tmp_path))
    for key in C.LEVEL_ORDER:
        rep1, tab1 = table_only(paths[key], key, ONE_CORE)
        rep3, tab3 = table_only(paths[key], key, IN_PARTS)
        assert rep3["parallel"] == {"workers": 1, "chunks": 1} and "read_on_one_core_because" not in rep3, (key, rep3.get("parallel"))
        assert tab1 == tab3 and tab1["rows"] == rep1["rows"] == rep3["rows"] == 3, (key, tab1, tab3)
        assert _clean(rep1) == _clean(rep3), key


# ------------------------------------------------------------------ 3. what could break reading in parts
NOTE_CELLS = ["first line\nsecond line, with a comma and a \"quoted\" word", "one\r\ntwo\r\nthree", "", "plain", "\"", "ends with a line break\n", "\n\n", "comma, only"]


def _with_notes(src, dst, note_of, line_end="\r\n", stray_quote_at=None):
    """A copy of a level file with one more column, Notes, whose cells hold line breaks, commas and quotes, written the way a CSV writer writes them (quoted, quotes doubled).
    stray_quote_at: that row's Notes cell is written without quoting although it holds a quote: 5" drive. Returns the number of data rows."""
    with open(src, newline="") as fh:
        rows = list(csv.reader(fh))
    with open(dst, "w", newline="") as fh:
        w = csv.writer(fh, lineterminator=line_end)
        w.writerow(rows[0] + ["Notes"])
        for i, r in enumerate(rows[1:]):
            if i == stray_quote_at:
                assert not any(c for c in r if set(c) & set(',"\r\n')), r
                fh.write(",".join(r + ['5" drive']) + line_end)
            else:
                w.writerow(r + [note_of(i)])
    return len(rows) - 1


def _notes_in_table(db, table="lnk"):
    con = sqlite3.connect(db)
    out = [json.loads(raw).get("Notes", "") for (raw,) in con.execute("SELECT raw FROM %s ORDER BY rowid_file" % table)]
    con.close()
    return out


def test_line_breaks_inside_quoted_cells(generated, tmp_path):
    """Cells with line breaks, commas and doubled quotes, rows ending in CR LF, and parts so small that many are cut next to such cells: read in parts (no fall-back),
    every row once, every cell whole."""
    path = str(tmp_path / "link.csv")
    n = _with_notes(generated[0]["link"], path, lambda i: NOTE_CELLS[i % len(NOTE_CELLS)])
    rep1, tab1 = table_only(path, "link", ONE_CORE)
    rep3, tab3 = table_only(path, "link", IN_PARTS)
    assert rep3["parallel"]["chunks"] >= 3 and "read_on_one_core_because" not in rep3, rep3["parallel"]
    assert rep1["rows"] == rep3["rows"] == n == tab3["rows"] and tab1 == tab3, (n, rep1["rows"], rep3["rows"])
    assert _notes_in_table(path + ".parts.sqlite") == [NOTE_CELLS[i % len(NOTE_CELLS)] for i in range(n)]
    assert "Notes" in rep3["extra_columns_kept"] + [u["header"] for u in rep3["unknown_columns"]]      # the column the level does not know is kept and named


def test_a_part_cut_inside_a_quoted_cell_is_read_on_one_core(generated, tmp_path):
    """One unquoted cell holds a quote (5" drive) and every later row holds a cell with a line break. Counting quotes, the only "safe" places to cut are then inside
    those cells, so every part ends in the middle of a row. Before 2026-11-12 the two halves of such a row were stored as two rows (seen on a file read in parts:
    one row more per cut, the cell torn). Now a worker proves where its part ended, the file is read on one core instead, and the report and the progress line say why."""
    path = str(tmp_path / "link.csv")
    n = _with_notes(generated[0]["link"], path, lambda i: "top\nbottom %d" % i, stray_quote_at=5)
    with loader(**IN_PARTS):
        size = os.path.getsize(path)
        cuts = L.plan_chunks(path, 0, L.part_bytes(size, 3))
    assert len(cuts) >= 3
    with open(path, "rb") as fb:                    # the planned cuts do fall inside cells: the byte before the cut ends "top\n", not a row
        blob = fb.read()
    assert all(blob[b - 5:b] == b'"top\n' for _a, b in cuts[:-1]), [blob[b - 8:b] for _a, b in cuts[:3]]
    said = []
    rep1, tab1 = table_only(path, "link", ONE_CORE)
    rep3, tab3 = table_only(path, "link", IN_PARTS, progress=lambda *a: said.append(a))
    assert rep3["parallel"] is None and "did not end where a row ends" in rep3["read_on_one_core_because"], rep3.get("read_on_one_core_because")
    assert any(len(a) > 3 and "reading this file on one core instead" in str(a[3]) for a in said), said[:5]
    assert rep1["rows"] == rep3["rows"] == n == tab3["rows"], (n, rep1["rows"], rep3["rows"])
    assert tab1 == tab3 and _clean(rep1) == _clean(rep3)
    notes = _notes_in_table(path + ".parts.sqlite")
    assert notes[5] == '5" drive' and notes[6] == "top\nbottom 6" and notes[-1] == "top\nbottom %d" % (n - 1)
    assert not [f for f in os.listdir(str(tmp_path)) if f.startswith("chunk_")]


def test_lines_that_end_with_a_carriage_return_alone(generated, tmp_path):
    """Parts are cut at line feeds. A file without any (old Mac line ends) was read in parts as a header and nothing else: no rows, no word about it.
    It is read on one core now, with every row."""
    path = str(tmp_path / "link.csv")
    n = _with_notes(generated[0]["link"], path, lambda i: "plain %d" % i, line_end="\r")
    rep1, tab1 = table_only(path, "link", ONE_CORE)
    rep3, tab3 = table_only(path, "link", IN_PARTS)
    assert "carriage return" in rep3["read_on_one_core_because"] and rep3["parallel"] is None
    assert rep1["rows"] == rep3["rows"] == n > 0 and tab1 == tab3


def as_real_export(files, out_dir):
    """The same rows under the header of the customer's analyzer export of 2026-11-03: sub-columns bare after their group cell, no "#2" on the second column of a name,
    AckNak_Seq_Num with underscores, the label-less cells holding text of the first row ("16.0", "1 warning(s)"), and no blank separator columns."""
    os.makedirs(out_dir, exist_ok=True)
    out = {}
    for key, path in files.items():
        with open(path, newline="") as fh:
            rows = list(csv.reader(fh))
        al = L.align_header(key, rows[0], L.prescan_values(path, L.ambiguous_columns(key, rows[0])))
        known, orig, label_less = C.canonical_names(key), C.original_names(key), set(C.label_less_positions(key))
        cells, picks = [], []
        for i, name in enumerate(known):
            if name not in al.positions:
                continue
            if i in label_less:
                cell = orig[i]
            elif "." in name and name.partition(".")[0] in set(known):
                cell = name.partition(".")[2]
            else:
                cell = name.replace(" ", "_") if name == "AckNak Seq Num" else name
            cells.append(re.sub(r"#\d+$", "", cell))
            picks.append(al.positions[name])
        out[key] = os.path.join(out_dir, os.path.basename(path))
        with open(out[key], "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(cells)
            for r in rows[1:]:
                r = r + [""] * (len(rows[0]) - len(r))
                w.writerow([r[p] for p in picks])
    return out


def test_both_header_layouts(generated, one_core, tmp_path):
    """The generator's layout (blank label-less cells, dotted sub-column names, blank separator columns) and the real export's layout go through the same code:
    the same tables, tree and findings from both, and for the real layout in parts as on one core."""
    files, _ = generated
    real = as_real_export(files, str(tmp_path / "real"))
    with open(real["link"], newline="") as fh:
        header = next(csv.reader(fh))
    assert "" not in header and "16.0" in header and not any("." in h and h.partition(".")[0] in header for h in header if h != "16.0"), header[:12]
    db1, db3 = str(tmp_path / "real_one.sqlite"), str(tmp_path / "real_parts.sqlite")
    rep1, _b1, _r1 = whole_step(real, db1, ONE_CORE)
    rep3, _b3, _r3 = whole_step(real, db3, IN_PARTS)
    for key in C.LEVEL_ORDER:
        assert not rep1[key]["missing_columns"] and not rep1[key]["unknown_columns"], (key, rep1[key]["missing_columns"][:5], rep1[key]["unknown_columns"][:5])
        assert rep3[key]["parallel"] and "read_on_one_core_because" not in rep3[key], key
    s1, s3 = signature(db1), signature(db3)
    assert not differences(s1, s3), differences(s1, s3)[:10]
    synthetic = signature(one_core[0])
    assert not differences(synthetic["tables"], s1["tables"]), differences(synthetic["tables"], s1["tables"])[:10]
    assert synthetic["indexes"] == s1["indexes"]


def test_an_empty_file_and_a_file_with_a_header_only(generated, tmp_path):
    """A file of no bytes is reported as empty and is no level; a file with its header and no row is a level with no rows. The same in parts and on one core,
    and the tree is still built from the other files."""
    files = dict(generated[0])
    empty, header_only = str(tmp_path / "split.csv"), str(tmp_path / "nvme_command.csv")
    open(empty, "w").close()
    with open(files["nvme_command"], newline="") as src, open(header_only, "w", newline="") as dst:
        dst.write(src.readline())
    files["split"], files["nvme_command"] = empty, header_only
    seen = {}
    for name, settings in (("one core", ONE_CORE), ("parts", IN_PARTS)):
        db = str(tmp_path / (name.replace(" ", "_") + ".sqlite"))
        rep, build, _rules = whole_step(files, db, settings)
        assert rep["split"]["rows"] == 0 and rep["split"]["error"] == "empty file", rep["split"]
        assert rep["nvme_command"]["rows"] == 0 and not rep["nvme_command"].get("error"), rep["nvme_command"]
        assert build["levels"] == [k for k in C.LEVEL_ORDER if k != "split"], build["levels"]
        seen[name] = signature(db)
    assert seen["one core"]["tables"]["cmd"]["rows"] == 0 and "spl" not in seen["one core"]["tables"]
    assert not differences(seen["one core"], seen["parts"]), differences(seen["one core"], seen["parts"])[:10]


def test_a_file_of_the_five_not_given(generated, tmp_path):
    """Four files, no split transactions: the level is absent, the tree is built from what is there (links hang under NVMe transactions directly), in parts as on
    one core. A path that leads to no file stops both ways with the same error, before anything is read."""
    files = {k: v for k, v in generated[0].items() if k != "split"}
    seen = {}
    for name, settings in (("one core", ONE_CORE), ("parts", IN_PARTS)):
        db = str(tmp_path / (name.replace(" ", "_") + ".sqlite"))
        rep, build, _rules = whole_step(files, db, settings)
        assert sorted(rep) == sorted(files) and build["levels"] == [k for k in C.LEVEL_ORDER if k != "split"]
        assert "split_rows_whose_link_count_differs" not in build["checks"] or build["checks"]["split_rows_whose_link_count_differs"] == 0
        seen[name] = signature(db)
    assert "spl" not in seen["parts"]["tables"] and seen["parts"]["tables"]["lnk"]["rows"] > 0
    assert not differences(seen["one core"], seen["parts"]), differences(seen["one core"], seen["parts"])[:10]
    gone = {"link": str(tmp_path / "no such file.csv")}
    for i, settings in enumerate((ONE_CORE, IN_PARTS)):
        with pytest.raises(FileNotFoundError):
            whole_step(gone, str(tmp_path / ("gone_%d.sqlite" % i)), settings)


def test_a_worker_that_fails_falls_back_to_one_core(generated, one_core, tmp_path, monkeypatch):
    """Every worker fails (the folder for its rows is not there): each file is read on one core, the old path, and the whole step gives the one-core result.
    The report of each file says why; nothing of the failed parts is left in the table or on the disk."""
    lost = str(tmp_path / "no such folder")
    monkeypatch.setattr(L, "chunk_folder", lambda beside: (lost, False))
    db = str(tmp_path / "fallback.sqlite")
    said = []
    rep, _build, _rules = whole_step(generated[0], db, IN_PARTS, progress=lambda *a: said.append(a))
    for key in C.LEVEL_ORDER:
        assert rep[key]["parallel"] is None and "a worker process could not read its part" in rep[key]["read_on_one_core_because"], (key, rep[key].get("read_on_one_core_because"))
    assert sum(1 for a in said if len(a) > 3 and "reading this file on one core instead" in str(a[3])) == len(C.LEVEL_ORDER)
    assert not differences(signature(one_core[0]), signature(db))
    assert not os.path.exists(lost)


def test_workers_that_cannot_be_started_fall_back_to_one_core(generated, tmp_path, monkeypatch):
    """The operating system gives no more processes: the file is read on one core."""
    def no_processes(*a, **kw):
        raise OSError("no more processes")
    monkeypatch.setattr(concurrent.futures, "ProcessPoolExecutor", no_processes)
    path = generated[0]["nvme_transaction"]
    rep3, tab3 = table_only(path, "nvme_transaction", IN_PARTS)
    monkeypatch.undo()
    rep1, tab1 = table_only(path, "nvme_transaction", ONE_CORE)
    assert "could not be started" in rep3["read_on_one_core_because"] and rep3["parallel"] is None
    assert tab1 == tab3 and tab3["rows"] == rep1["rows"] > 0 and _clean(rep1) == _clean(rep3)


def _worker_dies():
    os._exit(9)


def test_a_killed_worker_still_stops_the_load(generated, tmp_path, monkeypatch):
    """A worker the operating system kills (no memory left) is not a reason to read on: one core would take the same memory away from the other programs.
    The load stops with the plain reason, as before."""
    monkeypatch.setattr(L, "worker_starts", _worker_dies)
    with loader(**IN_PARTS):
        con = L.open_db(str(tmp_path / "killed.sqlite"))
        with pytest.raises(L.NoRoom) as stopped:
            L.load_file(con, "link", generated[0]["link"])
        con.close()
    assert "a worker process reading link.csv was killed" in str(stopped.value)


# ------------------------------------------------------------------ 4. the rules and the parent index
def test_rules_read_the_command_of_a_packet_only_where_a_rule_fires(one_core, monkeypatch):
    """Before, the command above a packet was read (up to three look-ups) for every packet with an LCRC value, which is every TLP. It is read now for the packets
    a rule fires on. The findings must carry the command a full walk up the tree gives, and the walks must be no more than the packets with a finding."""
    db = one_core[0]
    before = signature(db)["tables"]["finding"]
    walks = {"n": 0, "in_packets": False}
    real_chain, real_packets = R.Rules.chain, R.Rules.packets

    def chain(self, level, rowid):
        walks["n"] += walks["in_packets"]
        return real_chain(self, level, rowid)

    def packets(self):
        walks["in_packets"] = True
        try:
            return real_packets(self)
        finally:
            walks["in_packets"] = False
    monkeypatch.setattr(R.Rules, "chain", chain)
    monkeypatch.setattr(R.Rules, "packets", packets)
    R.apply(db, {})
    monkeypatch.undo()
    assert signature(db)["tables"]["finding"] == before                 # applying the rules again gives the same findings
    con = sqlite3.connect(db)
    tlps = con.execute("SELECT COUNT(*) FROM pkt WHERE lcrc IS NOT NULL AND lcrc != ''").fetchone()[0]
    with_finding = con.execute("SELECT COUNT(DISTINCT rowid) FROM finding WHERE level='packets'").fetchone()[0]
    assert 0 < with_finding and walks["n"] <= with_finding < tlps, (walks, with_finding, tlps)
    wrong = con.execute("""
        SELECT COUNT(*) FROM finding f JOIN pkt p ON p.rowid_file = f.rowid
        LEFT JOIN lnk l ON p.parent_level = 'link' AND l.rowid_file = p.parent
        LEFT JOIN spl s ON l.parent_level = 'split' AND s.rowid_file = l.parent
        LEFT JOIN ntx x ON x.rowid_file = CASE WHEN l.parent_level = 'split' THEN s.parent WHEN l.parent_level = 'nvme_transaction' THEN l.parent END
        WHERE f.level = 'packets' AND f.cmd_rowid IS NOT CASE WHEN p.parent_level = 'nvme_command' THEN p.parent ELSE x.parent END""").fetchone()[0]
    assert wrong == 0, wrong
    con.close()


def test_the_parent_index_is_made_by_the_build(generated, tmp_path):
    """ix_<table>_parent (parent_level, parent), which the pages, the rules and the tree's checks use, is no longer kept up to date row by row while the file is loaded
    and while the parents are written: the build makes it once the parents are there. Same name, same columns. A second build leaves the same tables and the index;
    a database whose build never ran still gets it when it is opened for browsing."""
    sys.path.insert(0, os.path.join(ROOT, "app"))
    from api import hier_api as H
    db = str(tmp_path / "hier.sqlite")
    with loader(**ONE_CORE):
        L.load_upload(db, generated[0])

    def parent_indexes():
        con = sqlite3.connect(db)
        out = {name: " ".join(sql.split()) for name, sql in con.execute("SELECT name, sql FROM sqlite_master WHERE type='index' AND name LIKE 'ix_%_parent'")}
        con.close()
        return out
    assert parent_indexes() == {}
    steps = []
    B.build(db, progress=lambda step, detail, pct: steps.append((step, pct)))
    want = {"ix_%s_parent" % t: "CREATE INDEX ix_%s_parent ON %s (parent_level, parent)" % (t, t) for t in TABLES}
    assert parent_indexes() == want
    names = [s for s, _ in steps]
    assert "tree: indexing the links" in names and names.index("tree: indexing the links") < names.index("tree: checking the analyzer's counts"), names
    assert [p for _, p in steps] == sorted(p for _, p in steps) and steps[-1][1] <= 100, steps[-5:]       # the percentage never goes back
    con = sqlite3.connect(db)
    plan = " ".join(r[3] for r in con.execute("EXPLAIN QUERY PLAN SELECT COUNT(*) FROM pkt WHERE parent_level='link' AND parent=1"))
    con.close()
    assert "ix_pkt_parent" in plan, plan
    first = signature(db)
    B.build(db)
    assert parent_indexes() == want and not differences(first["tables"], signature(db)["tables"])
    con = L.open_db(db)                      # a build that stopped between dropping the index and making it again: opening the upload puts it back
    for t in TABLES:
        L.parent_index(con, t, present=False)
    con.commit()
    H.ensure_indexes(con)
    con.close()
    assert parent_indexes() == want


def _doorbell_files(folder, batches, qsize):
    """nvme_command.csv and NVME_Transactions.csv of one I/O queue with `qsize` slots: one command per completion entry, and one completion queue head doorbell for
    every batch of entries (`batches` = how many entries each doorbell acknowledges). Returns the files and {doorbell's transaction number: the command number whose
    entry sits in slot head - 1}."""
    base = 0x100000

    def stamp(us):
        return "0000.%012ds" % (us * 1000000)
    cmds = [["NVMe Cmd", "Link Dir", "OPC", "SQID", "CQID", "CID", "PRP1", "Metrics.# NVME Trans", "Time Stamp", "QID", "QSIZE"],
            ["1", "Downstream", "0x05 (Create I/O CQ)", "0", "0", "1", "0x%016X" % base, "2", stamp(10), "1", str(qsize)]]
    tx = [["NVMe", "Link Dir", "QID", "Address", "Type", "Doorbell index", "SQID", "CID", "Time Stamp"],
          ["1", "Downstream", "", "", "Admin Submission Queue Entry", "", "0", "1", stamp(10)],
          ["2", "Upstream", "", "0x%016X" % 0x200000, "Admin Completion Queue Entry", "", "0", "1", stamp(11)]]
    want = {}
    t, c, slot = 100, 0, 0
    for size in batches:
        first = c + 1
        for i in range(size):
            c += 1
            t += 10
            cmds.append([str(c + 1), "Downstream", "0x02 (Read)", "1", "1", str(c), "", "3" if i == size - 1 else "2", stamp(t), "", ""])
            tx.append([str(len(tx)), "Downstream", "", "", "I/O Submission Queue Entry", "", "1", str(c), stamp(t)])
        for k in range(first, c + 1):
            t += 10
            tx.append([str(len(tx)), "Upstream", "", "0x%016X" % (base + 16 * slot), "I/O Completion Queue Entry", "", "1", str(k), stamp(t)])
            slot = (slot + 1) % qsize
        t += 10
        tx.append([str(len(tx)), "Downstream", "1", "", "Completion Queue Head Doorbell", str(slot), "", "", stamp(t)])
        want[len(tx) - 1] = c + 1
    os.makedirs(folder, exist_ok=True)
    files = {"nvme_command": os.path.join(folder, "nvme_command.csv"), "nvme_transaction": os.path.join(folder, "NVME_Transactions.csv")}
    for key, rows in (("nvme_command", cmds), ("nvme_transaction", tx)):
        with open(files[key], "w", newline="") as fh:
            csv.writer(fh).writerows(rows)
    return files, want


@pytest.mark.parametrize("batches", [[1] * 9, [2, 1, 1, 1, 1], [3, 1, 2, 1, 1, 3, 2, 1, 1, 2, 3, 1]])
def test_one_doorbell_for_several_completion_entries(batches, tmp_path):
    """A host may acknowledge several completion entries with one head doorbell. The doorbell hangs under the command whose entry sits in slot head - 1, the last one
    it acknowledged, also after the queue has wrapped. Found 2026-11-12: the commands a doorbell had passed stayed in the waiting list, so after a wrap a doorbell
    found the passed command of the lap before in its slot (batches 2, 1, 1, 1, 1 on a queue of 4 slots: the fifth doorbell hung under the first command instead
    of the sixth)."""
    files, want = _doorbell_files(str(tmp_path / "in"), batches, qsize=4)
    db = str(tmp_path / "hier.sqlite")
    with loader(**ONE_CORE):
        L.load_upload(db, files)
    rep = B.build(db)
    con = sqlite3.connect(db)
    got = dict(con.execute("SELECT x.n, c.n FROM ntx x LEFT JOIN cmd c ON c.rowid_file = x.parent AND x.parent_level = 'nvme_command' WHERE x.type = 'Completion Queue Head Doorbell'"))
    outside = con.execute("SELECT COUNT(*) FROM ntx WHERE relation = 'orphan'").fetchone()[0]
    con.close()
    assert got == want, {n: (got.get(n), w) for n, w in want.items() if got.get(n) != w}
    assert outside == 0 and rep["checks"]["command_rows_whose_transaction_count_differs"] == 0, (outside, rep["checks"])


if __name__ == "__main__":
    sys.exit(pytest.main(["-q", "-p", "no:cacheprovider", os.path.abspath(__file__)]))
