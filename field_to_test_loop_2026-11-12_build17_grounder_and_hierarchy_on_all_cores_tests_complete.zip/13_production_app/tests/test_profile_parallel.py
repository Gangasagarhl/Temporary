"""The Data Explorer's reading on all the cores gives what the reading on one core gives (2026-11-12).

A real export is 4 to 6 GB with up to 1,598 columns: family1.full_profile reads it on one core, agentic/profile_parallel.py reads
it in parts, in worker processes. The two must give the same profile, key for key and value for value ("seconds" aside). Here
every file goes through both, with small parts (64 KB) and three workers so that a small file is cut into many parts:

  - generated files built to break the putting together: a sequence number that wraps at 4096, a column that reaches 2,000
    different values late with early values coming back after many new ones (the parts must be read once more: checked), columns
    with fewer than 2,000, exactly 2,000 and 2,001 different values, more than 60 kinds of row under a real header;
  - damaged and odd CSV text: quoted cells with line breaks and commas, \\r\\n, \\n and \\r line ends, a byte order mark, short and
    long rows, empty lines, spaces around values, bytes that are not UTF-8, a quote inside a plain cell, a file that ends inside a
    quoted cell, a part that ends inside a quoted cell (the one-core reading takes over: checked);
  - the five sample exports themselves; a small file with the defaults; a stop asked through the progress line (no worker is left);
  - one timing on a file of about 150 MB with the defaults.

No server, no model. Its files go to a folder of its own under F2T_TEST_TMP (or the system's temporary folder) and are deleted.
Run: python3 tests/test_profile_parallel.py   (exit code 1 when a check fails)."""
import csv
import multiprocessing
import os
import shutil
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from agentic import family1, profile_parallel as PP      # noqa: E402
from nvme_hier import loader as L                         # noqa: E402

S17 = os.path.join(APP, "samples", "clean_five_files", "S17_io_timeout_abort_reset")
FIVE = (("nvme_command.csv", "nvme_command"), ("split.csv", "split"), ("NVME_Transactions.csv", "nvme_transaction"),
        ("link.csv", "link"), ("packets.csv", "packets"))
SMALL = dict(workers=3, min_bytes=0, chunk_bytes=64 * 1024)      # a small file in many parts
FAILED = []


def check(name, ok, detail=""):
    print("%s  %s%s" % ("PASS" if ok else "FAIL", name, " :: " + detail if detail else ""), flush=True)
    if not ok:
        FAILED.append(name)
    return ok


def _short(x):
    s = repr(x)
    return s if len(s) <= 300 else s[:300] + " ..."


def difference(a, b):
    """Where two profiles differ first, in words: the key, or the column and its key. "" when they are the same ("seconds" aside)."""
    for k in sorted(set(a) | set(b)):
        if k not in ("seconds", "columns") and a.get(k) != b.get(k):
            return "key %r: one core %s, parts %s" % (k, _short(a.get(k)), _short(b.get(k)))
    ca, cb = a.get("columns") or [], b.get("columns") or []
    if len(ca) != len(cb):
        return "one core has %d columns, parts %d" % (len(ca), len(cb))
    for x, y in zip(ca, cb):
        for k in sorted(set(x) | set(y)):
            if x.get(k) != y.get(k):
                return "column %r, key %r: one core %s, parts %s" % (x.get("column"), k, _short(x.get(k)), _short(y.get(k)))
    return ""


def outcome(fn, *args, **kw):
    """("profile", the profile) or ("error", its kind and text): an unreadable file must fail the same way on both readings."""
    try:
        return "profile", fn(*args, **kw)
    except Exception as e:
        return "error", "%s: %s" % (type(e).__name__, e)


def same(name, path, level, parallel=True, assemble=True, **how):
    """One file through both readings. parallel: whether the parts are expected to be used (True), not used (False), or either (None).
    -> (the one-core profile or None, what the call did)."""
    kind_a, a = outcome(family1.full_profile, path, level)
    kind_b, b = outcome(PP.full_profile_parallel, path, level, **dict(SMALL, **how))
    did = dict(PP.LAST)
    if kind_a != kind_b or kind_a == "error":
        ok, diff = (kind_a, a) == (kind_b, b), "one core %s %s, parts %s %s" % (kind_a, _short(a), kind_b, _short(b))
    else:
        diff = difference(a, b)
        ok = not diff
    if ok and parallel is not None and bool(did.get("parallel")) != parallel:
        ok, diff = False, "expected %s, but: %s" % ("the parts to be used" if parallel else "the one-core reading", did)
    note = "%s parts, %s workers" % (did.get("parts"), did.get("workers")) if did.get("parallel") else "read on one core (%s)" % did.get("why")
    if did.get("recount_parts"):
        note += ", %d parts read once more for %d columns" % (did["recount_parts"], did["recount_columns"])
    check("%s: the same profile" % name, ok, diff if not ok else "%s rows, %s" % (a.get("rows") if kind_a == "profile" else "no", note))
    if assemble and kind_a == "profile":
        d = difference(a, PP.assemble(**PP.sequential_state(path, level)))
        check("%s: assemble(sequential_state) is full_profile" % name, not d, d)
    return (a if kind_a == "profile" else None), did


# ---------------------------------------------------------------------------------------------- generated files
def write_narrow(path, rows=60000):
    """Short rows: the sequence number, which wraps at 4096, holds 2,000 different values within the first part already."""
    with open(path, "w", newline="") as fh:
        fh.write("seq,dir,len\n")
        for i in range(rows):
            fh.write("%d,%s,%d\n" % (i % 4096, "UD"[i % 2], i % 7))


def write_late(path):
    """The column "late" reaches 2,000 different values late, and values met early come back after many new ones:
      rows      0-11,999  1,200 values, over and over (the start of the file holds them all)
      rows 12,000-12,999  300 other values (5000-5299), first met after the start; 5000-5099 once each
      rows 13,000-19,999  the first 1,200 again
      rows 20,000-43,999  four times: 4,500 values never met before (more than a part has room for), then 1,500 rows holding three of
                          the 300 (other ones each time). The 2,000 are complete with the first 500 of the 4,500; a part that had no
                          room left has not counted the three, and they are among the most frequent values of the column
      rows 44,000-59,999  a mix of counted values and of values that are not counted"""
    with open(path, "w", newline="") as fh:
        fh.write("late,hot\n")
        new = 20000
        for i in range(60000):
            if i < 12000 or 13000 <= i < 20000:
                v = 1000 + i % 1200
            elif i < 13000:
                v = 5000 + i % 300 if i < 12300 else 5100 + i % 200
            elif i < 44000:
                block, r = divmod(i - 20000, 6000)
                if r < 4500:
                    v, new = new, new + 1
                else:
                    v = 5000 + 10 * block + (0, 0, 0, 1, 1, 2)[r % 6]
            else:
                v = (1000 + i % 1200, 5000 + i % 300, 20000 + i % 500, 20500 + i % 4000, 90000 + i)[i % 5]
            fh.write("%d,%s\n" % (v, ("ab", "cd", " ef ", "")[i % 4]))


def write_counts(path, rows=60000):
    """Columns whose number of different values sits on the limit of 2,000, and one whose type depends on the order of its values:
      few     1,500 different values, spread over the whole file and not in order
      exact   exactly 2,000, the last one first met in the last rows
      more    2,001: the same, and one more value in the very last row
      mid     exactly 2,000, complete in the middle of the file; only the last one after that
      mixed   600 hex values first, then words, then 3,000 hex values: "hex" only if the first 500 values are kept in file order"""
    with open(path, "w", newline="") as fh:
        fh.write("n,few,exact,more,mid,mixed,word\n")
        for i in range(rows):
            if i < 20000:
                mixed = "%xf" % (i % 250 if i < 10000 else i % 600)
            elif i < 30000:
                mixed = "word %d" % (i % 50)
            else:
                mixed = "%xf" % (i % 3000)
            fh.write(",".join((str(i), "f%d" % (i // 40 if i % 7 else i * 37 % 1500), "x%d" % (i // 30),
                               "y%d" % (i // 30) if i < rows - 1 else "one more", "m%d" % min(i // 15, 1999), mixed,
                               ("Read", "Write", "Flush", "")[i % 4])) + "\n")


def column(profile, name):
    """One column of a profile, by its name."""
    return next(c for c in profile["columns"] if c["column"] == name)


def sample(name):
    """-> (the header row, the other rows) of one of the five sample files, as lists of cells."""
    with open(os.path.join(S17, name), "r", encoding="utf-8-sig", errors="replace", newline="") as fh:
        rows = list(csv.reader(fh))
    return rows[0], rows[1:]


def write_kinds(path, name, level, repeat, take=None, flood=False):
    """The rows of a sample file under its own header, with more than 60 kinds of row. The Explorer looks for the kind column in the
    first 3,000 rows and in 500 rows at 30, 50, 70 and 90 % of the file, so the made-up kinds sit between those places:
      20-21 %  (one kind column only) the kind cell is empty: "no kind", met before the limit of 60
      36-47 %  100 made-up kinds, a new one every few rows: the limit of 60 is passed in the middle of a part
      55-66 %  the same 100, the last ones first: a part meets first the kinds that are counted as "other"
      76-77 %  (several kind columns) two of them hold a value on the same row, first met after the limit
      78-79 %  no kind cell holds a value
    flood: instead, 36-48 % a kind of its own on every row (more than 1,000 kinds in one large part)."""
    header, rows = sample(name)
    rows = rows[:take] * repeat
    places = [p for _nm, p in family1.kind_columns(os.path.join(S17, name), level)["columns"]]
    total = len(rows)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        out = csv.writer(fh, lineterminator="\n")
        out.writerow(header)
        for i, row in enumerate(rows):
            at = 100.0 * i / total
            held = [p for p in places if p < len(row) and row[p].strip()]
            row = list(row)
            if flood:
                if 36 <= at < 48 and held:
                    row[held[0]] = "Kind of row %d" % i
            elif (20 <= at < 21 and len(places) == 1) or 78 <= at < 79:
                for p in held:
                    row[p] = ""
            elif 36 <= at < 47 and held:
                row[held[0]] = "Made-up kind %02d" % int((at - 36) * 100 / 11)
            elif 55 <= at < 66 and held:
                row[held[0]] = "Made-up kind %02d" % (99 - i % 100)
            elif 76 <= at < 77 and len(places) > 1 and len(row) > max(places):
                row[places[0]] = row[places[1]] = "Both"
            out.writerow(row)


def write_odd(path, rows=24000):
    """CSV text as a damaged or unusual export holds it, written byte by byte; sixteen kinds of line, one after the other."""
    mark = PP._END.encode("utf-8")              # the module's own end mark as a line of the data: it must stay a row like any other
    with open(path, "wb") as fh:
        fh.write(b"\xef\xbb\xbfid,name,note,value,extra\r\n")
        for i in range(rows):
            n, v = b"%d" % i, b"%d" % (i * 7 % 1000)
            fh.write((
                (b"\xef\xbb\xbf" if i % 160 == 0 else b"") + n + b",alpha,plain note," + v + b",x\r\n",
                n + b",beta,unix line end," + v + b",y\n",
                n + b',"two\r\nlines, and a comma",quoted,' + v + b",z\r\n",
                n + b',"says ""hi"", then goes on",quoted,' + v + b",z\n",
                n + b",short\r\n",
                n + b",long,row," + v + b",e,more,and more\r\n",
                b"\r\n" + n + b",after an empty line,," + v + b",\n   \n",
                n + b",  spaced  ,\t tab around\t," + v + b" , q\r\n",
                n + b",caf\xe9,\xff\xfe not utf-8," + v + b",\xe2\x82\n",
                n + b",mac,old line end," + v + b",c\r",
                n + b',5" disk,a quote in a plain cell,' + v + b",w\n",
                n + b',3" disk,the second one,' + v + b",w\r\n",
                n + b",nul\x00inside,\xc2\xb5s and \xe2\x80\x94," + v + b",\xe2\x80\xa8\n",
                n + b', ,"\t",' + v + b',"  "\n',
                n + b',"\n\nstarts with breaks","ends with one\n",' + v + b",m\n",
                mark + b"\n" + n + b",\x1f,\x1c\x1d," + v + b",\x0b\x0c\x85\n",
            )[i % 16])


def write_open_end(path):
    """Plain rows, then a quoted cell that is never closed: the rest of the file is that one cell."""
    with open(path, "wb") as fh:
        fh.write(b"id,name,value\n")
        for i in range(9000):
            fh.write(b"%d,name %d,%d\n" % (i, i % 40, i % 9))
        fh.write(b'9000,"never closed,1\n')
        for i in range(300):
            fh.write(b"%d,inside the cell,%d\n" % (i, i))


def write_cut_in_cell(path):
    """A quote inside a plain cell, then a quoted cell of 5,000 lines: by the count of quotes the cell looks closed where it is open,
    so a part ends inside it. The parts cannot give the rows of the one-core reading, and the one-core reading must take over."""
    with open(path, "wb") as fh:
        fh.write(b"id,name,value\n")
        for i in range(8000):
            fh.write(b"%d,name %d,%d\n" % (i, i % 40, i % 9))
        fh.write(b'8000,5" disk,1\n8001,"a cell of many lines\n')
        for i in range(5000):
            fh.write(b"line %d of the cell, with a comma\n" % i)
        fh.write(b'the end of the cell",2\n')
        for i in range(8002, 12000):
            fh.write(b"%d,name %d,%d\n" % (i, i % 40, i % 9))


def write_number_then_word(path):
    """A column of 700 numbers and then a word (the type is taken from the first 500 values): whatever the one-core reading does with
    it, a profile or an error, the reading in parts must do the same."""
    with open(path, "w", newline="") as fh:
        fh.write("a,b,c\n")
        for i in range(9000):
            fh.write("%s,x%d,y\n" % (i % 700 if i < 8000 else "N/A", i % 3))


# ---------------------------------------------------------------------------------------------- the cases
def generated(tmp):
    """Files built to break the putting together of the parts: the limit of 2,000 different values per column."""
    path = os.path.join(tmp, "narrow.csv")
    write_narrow(path)
    a, _did = same("a sequence number that wraps at 4096", path, None)
    c = column(a, "seq")
    check("... that file is what it is meant to be", (c["distinct"], c["distinct_more_than_counted"], c["min"], c["max"]) == (2000, True, 0, 1999),
          "seq: %s" % _short({k: c[k] for k in ("distinct", "distinct_more_than_counted", "min", "max")}))

    path = os.path.join(tmp, "late.csv")
    write_late(path)
    for kb in (64, 16):
        a, did = same("a column full late, early values back after many new ones, parts of %d KB" % kb, path, None, assemble=kb == 64,
                      chunk_bytes=kb * 1024)
        check("... parts were read once more for it (parts of %d KB)" % kb, did.get("recount_parts", 0) > 0, str(did))
    c = column(a, "late")
    top = [t["value"] for t in c["top_values"]]
    check("... that file is what it is meant to be",
          (c["distinct"], c["distinct_more_than_counted"], c["min"], c["max"]) == (2000, True, 1000, 20499)
          and set(top[:4]) == {"5000", "5010", "5020", "5030"} and set(top[4:]) == {"5001", "5011", "5021", "5031"}, _short(c["top_values"]))
    keep = PP._add_recount
    PP._add_recount = lambda *args, **kw: None          # the second reading thrown away: the counts must then be wrong
    try:
        b = PP.full_profile_parallel(path, None, **SMALL)
    finally:
        PP._add_recount = keep
    d = difference(a, b)
    check("... without the second reading that file gives other counts (so the case is a real one)", bool(d), d or "the counts were right all the same")

    path = os.path.join(tmp, "counts.csv")
    write_counts(path)
    a, _did = same("columns of 1,500, of exactly 2,000 and of 2,001 different values", path, None)
    got = {name: (column(a, name)["distinct"], column(a, name)["distinct_more_than_counted"]) for name in ("few", "exact", "more", "mid")}
    want = {"few": (1500, False), "exact": (2000, False), "more": (2000, True), "mid": (2000, False)}
    check("... that file is what it is meant to be", got == want and column(a, "mixed")["type"] == "hex", "%s, mixed is %s" % (got, column(a, "mixed")["type"]))


def kinds(tmp):
    """More than 60 kinds of row under a real header (the sample files themselves have few kinds: see five_samples)."""
    for label, name, level, repeat, take in (("one kind column", "split.csv", "split", 6, None),
                                             ("several kind columns", "link.csv", "link", 1, 20000)):
        path = os.path.join(tmp, "kinds_" + name)
        write_kinds(path, name, level, repeat, take)
        a, _did = same("more than 60 kinds of row, %s" % label, path, level)
        values = [k["value"] for k in ((a or {}).get("kind_of_row") or {}).get("kinds", [])]
        check("... that file is what it is meant to be (%s)" % label, len(values) > 50 and any("less common" in v for v in values),
              "%d kinds, the last ones %s" % (len(values), _short(values[-3:])))
    path = os.path.join(tmp, "kinds_flood.csv")
    write_kinds(path, "split.csv", "split", 4, flood=True)
    same("a kind of its own on 2,600 rows, in small parts", path, "split", assemble=False)
    _a, did = same("the same file in large parts: read on one core", path, "split", parallel=False, assemble=False, chunk_bytes=512 * 1024)
    check("... because one part holds too many kinds", "kinds of row" in did.get("why", ""), str(did))


def odd_text(tmp):
    """Damaged and unusual CSV text."""
    path = os.path.join(tmp, "odd.csv")
    write_odd(path)
    same("quoted line breaks and commas, three line ends, byte order marks, short and long rows, empty lines, spaces, bytes that are not UTF-8",
         path, None)
    same("the same file read as a split export (its header does not fit)", path, "split", parallel=None, assemble=False)
    path = os.path.join(tmp, "open_end.csv")
    write_open_end(path)
    same("a file that ends inside a quoted cell", path, None)
    path = os.path.join(tmp, "cut_in_cell.csv")
    write_cut_in_cell(path)
    _a, did = same("a part that ends inside a quoted cell: read on one core", path, None, parallel=False)
    check("... and the reason is said", "quoted cell" in did.get("why", ""), str(did))
    path = os.path.join(tmp, "number_then_word.csv")
    write_number_then_word(path)
    same("a column of numbers with a word after its first 500 values: the same outcome", path, None, parallel=None, assemble=False)


def five_samples(tmp):
    """The five sample exports themselves, cut into small parts."""
    for name, level in FIVE:
        same("%s as %s" % (name, level), os.path.join(S17, name), level, assemble=name != "packets.csv")
    for name in ("nvme_command.csv", "split.csv"):
        same("%s with no level given" % name, os.path.join(S17, name), None, assemble=False)


def defaults(tmp):
    """With the defaults a small file is not cut into parts; neither is any file when one worker only is allowed."""
    path = os.path.join(S17, "split.csv")
    a = family1.full_profile(path, "split")
    b = PP.full_profile_parallel(path, "split")
    did = dict(PP.LAST)
    check("a small file with the defaults: read on one core, the same profile", not difference(a, b) and did.get("why") == "a small file", str(did))
    b = PP.full_profile_parallel(path, "split", workers=1, min_bytes=0, chunk_bytes=64 * 1024)
    did = dict(PP.LAST)
    check("one worker only: read on one core, the same profile", not difference(a, b) and did.get("why") == "one worker only", str(did))


class Stop(Exception):
    """What the progress line raises when the owner stops the job."""


def workers_left(seconds=30):
    """The worker processes still alive, after waiting up to `seconds` for them to end."""
    until = time.time() + seconds
    while multiprocessing.active_children() and time.time() < until:
        time.sleep(0.1)
    return multiprocessing.active_children()


def large(tmp):
    """A file of about 150 MB (the rows of the largest sample file, three times) with the defaults: the same profile, the seconds of
    both readings, the progress lines, and a stop on the way."""
    with open(os.path.join(S17, "packets.csv"), "rb") as fh:
        head, _nl, body = fh.read().partition(b"\n")
    path = os.path.join(tmp, "large.csv")
    with open(path, "wb") as fh:
        fh.write(head + b"\n")
        for _ in range(3):
            fh.write(body if body.endswith(b"\n") else body + b"\n")
    del body
    mb = os.path.getsize(path) / 1024.0 ** 2
    try:
        t = time.time()
        a = family1.full_profile(path, "packets")
        one = time.time() - t
        lines = []
        t = time.time()
        b = PP.full_profile_parallel(path, "packets", progress=lines.append)
        many = time.time() - t
        did = dict(PP.LAST)
        d = difference(a, b)
        check("a file of %d MB with the defaults: the same profile, read in parts" % mb, not d and bool(did.get("parallel")), d or str(did))
        t = time.time()
        L.plan_chunks(path, 0)
        plan = time.time() - t
        busy = "; the machine's load was %.1f on %d cores" % (os.getloadavg()[0], os.cpu_count() or 1) if hasattr(os, "getloadavg") else ""
        print("TIME  %d MB, %s rows: one core %.1f s; %s workers %.1f s (%d parts; %.1f s of it to find where the parts end); %.1f times faster%s"
              % (mb, "{:,}".format(a["rows"]), one, did.get("workers"), many, did.get("parts", 0), plan, one / max(many, 0.01), busy), flush=True)
        check("progress lines are written on the way", bool(lines) and all("% · reading large.csv" in x for x in lines),
              "%d lines, the last one: %s" % (len(lines), _short(lines[-1:])))

        workers_left()              # the workers of the run above have ended before the stop is tried
        calls = []

        def progress(text):
            calls.append(text)
            if len(calls) == 2:
                raise Stop("the job was stopped")
        try:
            PP.full_profile_parallel(path, "packets", progress=progress, workers=3)
            stopped = False
        except Stop:
            stopped = True
        check("a stop raised by the second progress line comes out of the call", stopped, "%d progress lines" % len(calls))
        left = workers_left()
        check("no worker process is left running after the stop", not left, "still alive: %s" % left if left else "")
    finally:
        os.remove(path)


def main():
    base = os.environ.get("F2T_TEST_TMP") or None
    if base:
        os.makedirs(base, exist_ok=True)
    tmp = tempfile.mkdtemp(prefix="profile_parallel_", dir=base)
    try:
        for case in (generated, kinds, odd_text, five_samples, defaults, large):
            try:
                case(tmp)
            except Exception as e:          # a case that breaks is a failed check, and the other cases still run
                check("%s ran to its end" % case.__name__, False, "%s: %s" % (type(e).__name__, e))
    finally:
        workers_left()
        shutil.rmtree(tmp, ignore_errors=True)
    print("%d check(s) failed: %s" % (len(FAILED), "; ".join(FAILED)) if FAILED else "all checks passed", flush=True)
    return 1 if FAILED else 0


def test_profile_parallel():
    """The same checks under pytest."""
    assert main() == 0, FAILED


if __name__ == "__main__":      # the worker processes are started fresh and read this file again: nothing may run then
    sys.exit(main())
