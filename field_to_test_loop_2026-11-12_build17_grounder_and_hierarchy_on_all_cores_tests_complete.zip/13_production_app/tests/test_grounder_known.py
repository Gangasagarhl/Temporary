"""What the Data Grounder already knows, and what it asks the model only once (owner, 2026-11-12: "keep that document ... ground
from it before moving ... if once the column name has been done, it's done ... match the already stored content ... not every
time by web search", and about 2,000 columns in some exports).

A meaning is looked for in this order and the first place that has it wins: a data dictionary that the admin approved (or a
remembered meaning that the admin approved), the reference document of the tool that exported the file, what an earlier run
understood, what the model knew when the reference document was prepared, and only then the model. These tests run the Grounder
against the stand-in model server of tests/test_grounder_batches.py (no real model is called), each with a knowledge folder of
its own, and look at what reached the model, what did not, and what was kept for the next run.

The files go to a folder of this test's own under F2T_TEST_TMP (or the system's temporary folder) and are deleted."""
import csv
import json
import os
import shutil
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from test_grounder_batches import _Ctx, _Model, _for_keywords, _for_meaning, _tmp      # noqa: E402  (the same stand-in model and step context)

TOOL = "teledyne_lecroy_pcie"
TOOL_NAME = "Teledyne LeCroy PCIe Protocol Analysis"
FROM_DOCUMENT = "from the reference document of " + TOOL_NAME
FROM_PREPARED = "from the model's knowledge when the reference document was prepared (no source to check)"
FROM_MODEL = "from the model's knowledge (no source to check)"
KEPT = "kept from an earlier run: "
MODEL_SOURCE = {"kind": "model", "ref": "model knowledge", "quote": ""}
# a file of an unknown tool is remembered under its own header (the format key); a recognised tool's file under its level
PACKETS = {"name": "packets.csv", "level": "packets", "level_label": "packets", "format_key": "fmtA"}
LINK = {"name": "link.csv", "level": "link", "level_label": "link transactions", "format_key": "fmtL"}


class _World:
    """One test's own knowledge folder and runs folder; the application's knowledge folder is never read or written."""

    def __init__(self, name):
        self.name, self.n = name, 0

    def __enter__(self):
        from agentic import family1
        self.root = _tmp("grounder_known_%s_%d_" % (self.name, os.getpid()))
        self.knowledge = os.path.join(self.root, "knowledge")
        self.folder = os.path.join(self.knowledge, "column_meanings")      # where the Grounder keeps what it understood
        self._env = {k: os.environ.get(k) for k in ("ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", "ANTHROPIC_AUTH_TOKEN")}
        self._kd = family1.knowledge_dir
        family1.knowledge_dir = lambda: self.knowledge
        return self

    def __exit__(self, *_a):
        from agentic import family1
        family1.knowledge_dir = self._kd
        for k, v in self._env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        shutil.rmtree(self.root, ignore_errors=True)

    def dictionary(self, d, fmt="fmtD"):
        """An approved data dictionary, where the application keeps them."""
        folder = os.path.join(self.knowledge, "dictionaries", fmt)
        os.makedirs(folder, exist_ok=True)
        with open(os.path.join(folder, "%s.current.json" % os.path.splitext(d["file"])[0]), "w") as fh:
            json.dump(d, fh)

    def store(self, tool=None):
        from agentic import column_knowledge as CK
        return CK.Store(self.folder, tool)

    def _runner(self, model, web, at_once):
        from agentic import core
        os.environ.update(ANTHROPIC_API_KEY="sk-test-grounder-0000", ANTHROPIC_BASE_URL=model.url)
        os.environ.pop("ANTHROPIC_AUTH_TOKEN", None)
        return core.AgentRunner(os.path.join(self.root, "runs"), runtime="http", http_model="company-model-1", web=web, calls_at_once=at_once)

    def ground(self, cols, f, run_id=1, web=True, at_once=4, expect_error=False, mem_more=None, pause=0.05, per_second=None, prepare=None,
               **model_args):
        """One Data Grounder step on a file whose Explorer memory holds these columns, against a stand-in model of its own ->
        (the model, the step's result, the Grounder's memory, the context); with expect_error the error's text and no memory.
        per_second: the calls this test's own runner may start in one second (a test that is not about the rate may raise it;
        the application's own number, core.Slots.PER_SECOND, is not touched). prepare(runner, model): called before the step."""
        from agentic import family1
        self.n += 1
        mem = os.path.join(self.root, "explorer_%d.json" % self.n)
        with open(mem, "w") as fh:
            json.dump(dict({"columns": cols}, **(mem_more or {})), fh)
        model = _Model(pause=pause, **model_args)
        try:
            runner = self._runner(model, web, at_once)
            if per_second:
                runner.slots.per_second = per_second
            if prepare:
                prepare(runner, model)
            ctx = _Ctx(runner, mem, run_id)
            if expect_error:
                try:
                    family1._ground(ctx, f)
                except RuntimeError as e:
                    return model, str(e), None, ctx
                raise AssertionError("the step did not stop")
            res = family1._ground(ctx, f)
            with open(res.output["memory_file"]) as fh:
                return model, res, json.load(fh), ctx
        finally:
            model.srv.shutdown()
            model.srv.server_close()

    def explore(self, f, run_id=1, at_once=4, pause=0.05, **model_args):
        """One Data Explorer step on a real CSV file -> (the model, the step's result, the Explorer's memory, the context)."""
        from agentic import family1
        model = _Model(pause=pause, **model_args)
        try:
            ctx = _Ctx(self._runner(model, False, at_once), None, run_id)
            res = family1._explore(ctx, f)
            with open(res.output["memory_file"]) as fh:
                return model, res, json.load(fh), ctx
        finally:
            model.srv.shutdown()
            model.srv.server_close()


class _ReviewCtx(_Ctx):
    """The context of the Manager's step of the same run: the Explorer's memory and the Grounder's result."""

    def __init__(self, ctx, ground_output, admin):
        _Ctx.__init__(self, ctx.engine.runner, ctx._mem, ctx.run["id"])
        self.input, self._ground = {}, ground_output
        self.project = {"refs": "[]", "admin": admin}

    def output_of(self, key):
        return self._ground if key.startswith("ground:") else {"memory_file": self._mem}


def _cols(n, kws=5, start=0):
    """Columns of an unknown tool: Field 000 ..., each with keywords K<i>_<j> that no other column holds."""
    return [{"column": "Field %03d" % i, "position": i, "header_cell": "Field %03d" % i, "type": "text", "rows_with_value": 50, "observed": "holds a code",
             "top_values": [{"value": "V%d_%d" % (i, j), "count": 10 - j} for j in range(3)],
             "keywords": [{"value": "K%d_%d" % (i, j), "count": 5} for j in range(kws)]} for i in range(start, start + n)]


def _real_header(file="link.csv"):
    """The column names of one of the five real exports, in the order of the file (data/lecroy_real_headers.json)."""
    with open(os.path.join(APP, "data", "lecroy_real_headers.json")) as fh:
        rec = json.load(fh)["files"][file][0]["columns"]
    return [rec[k] for k in sorted(rec, key=int)]


def _lecroy(kws=3, more=()):
    """The Explorer's columns of a file with the real link.csv header, each holding a value and kws keywords LK<i>_<j>; more:
    (name, [keywords]) of further columns after them."""
    names = _real_header()
    out = [{"column": n, "position": i, "header_cell": n, "type": "text", "rows_with_value": 40, "observed": "holds a value",
            "top_values": [{"value": "LV%d" % i, "count": 9}], "keywords": [{"value": "LK%d_%d" % (i, j), "count": 4} for j in range(kws)]}
           for i, n in enumerate(names)]
    for name, words in more:
        out.append({"column": name, "position": len(out), "header_cell": name, "type": "text", "rows_with_value": 40, "observed": "holds a value",
                    "top_values": [{"value": "XV%d" % len(out), "count": 9}], "keywords": [{"value": w, "count": 4} for w in words]})
    return out


def _library_kinds(names, level="link"):
    """(the names whose meaning the reference document states with a quote, the names it has only from the model's knowledge),
    by the reference library's own look-up."""
    from agentic import column_knowledge as CK
    lib = CK.library()
    before = CK.previous_names([{"column": n, "position": i} for i, n in enumerate(names)])
    doc, model = [], []
    for n in names:
        e, _how = lib.lookup(TOOL, level, n, before.get(n))
        if e:
            (doc if e["kind"] == "document" else model).append(n)
    return doc, model


def _seed(store, scope, name, meaning, values=(), keywords=None, approved=None, file="old.csv", run=90, at=1794390000):
    """What an earlier run understood of one column, as the Grounder keeps it (from the model's knowledge, not approved unless said)."""
    store.remember(scope, name, {"meaning": meaning, "source": dict(MODEL_SOURCE), "checked": False, "why": "",
                                 "keywords": {k: {"meaning": v, "source": dict(MODEL_SOURCE), "checked": False, "why": ""} for k, v in (keywords or {}).items()}},
                   typ="text", values=list(values), learned_from={"file": file, "run": run, "at": at}, approved=approved)


def _entries(model):
    return [c for a in model.asked for c in a["columns"]]


def _said(out):
    return {n: (m["meaning"], {k: v["meaning"] for k, v in m["keywords"].items()}) for n, m in out["columns"].items()}


def _known(a):
    """A call that asks only for keywords: every entry has its meaning already."""
    return bool(a) and all("meaning_known" in c for c in a)


# ------------------------------------------------------------------------------------------ small parts, without a run
def test_the_status_of_a_meaning_says_which_of_the_known_places_it_comes_from():
    from agentic import family1
    doc = {"meaning": "m", "checked": True, "source": {"kind": "document", "ref": "x.md:3", "quote": "q"}}
    model = {"meaning": "m", "checked": False, "source": dict(MODEL_SOURCE)}
    assert family1._status(dict(doc, library={"tool_name": TOOL_NAME})) == FROM_DOCUMENT
    assert family1._status(doc) == "from a reference document"                         # a document of the project's own folders
    assert family1._status(dict(doc, checked=False, library={"tool_name": TOOL_NAME})) == "document quote not found: not trusted"
    assert family1._status(model) == FROM_MODEL
    assert family1._status(dict(model, library={"tool_name": TOOL_NAME, "kind": "model"})) == FROM_PREPARED
    assert family1._status(dict(model, stored={"file": "a.csv", "on": "2026-11-12"})) == KEPT + FROM_MODEL
    assert family1._status(dict(doc, stored={"file": "", "on": ""})) == KEPT + "from a reference document"
    assert family1._status(dict(model, stored={"file": "a.csv", "on": "2026-11-12", "approved_by": "Sagar", "approved_on": "2026-11-12"})) == \
        "from the approved dictionary of a.csv (approved by Sagar, 2026-11-12)"
    assert family1._status(dict(model, stored={"file": "", "on": "", "approved_by": "the admin", "approved_on": ""})) == \
        "from the approved dictionary of an earlier file (approved by the admin, earlier)"
    assert family1._status({"meaning": "m", "checked": True, "source": {"kind": "admin", "ref": "Sagar", "quote": ""}}) == "given by the admin"
    assert family1._status(dict(model, meaning="", stored={"file": "a.csv", "on": ""})) == "no meaning found"


def test_an_entry_goes_to_the_model_with_only_what_it_holds():
    from agentic import family1
    shared = {"column": "words that many columns hold (1)", "shared": True, "type": "", "keywords": ["Reserved"], "snippets": [], "contents": {}, "filled_on": "",
              "group": "~shared", "meaning_known": "not a column: each keyword below is a word that many columns of this file hold",
              "held_by": {"Reserved": "10 columns, such as A, B, C"}}
    assert family1._for_model(3, shared) == {"n": 3, "column": "words that many columns hold (1)", "keywords": ["Reserved"],
                                             "meaning_known": "not a column: each keyword below is a word that many columns of this file hold",
                                             "held_by": {"Reserved": "10 columns, such as A, B, C"}}       # no type, no contents: it is not a column
    known = {"column": "Tag", "header_cell": "Tag", "type": "hex", "keywords": ["0x1F"], "snippets": [], "contents": {"observed": "o"}, "filled_on": "",
             "group": "", "meaning_known": "the tag of the request"}
    assert family1._for_model(1, known) == {"n": 1, "column": "Tag", "type": "hex", "keywords": ["0x1F"], "contents": {"observed": "o"},
                                            "meaning_known": "the tag of the request"}
    new = dict(known, header_cell="TAG (hex)", filled_on="filled only on rows where OPC is Read", snippets=[{"ref": "a.md:1", "quote": "q"}])
    del new["meaning_known"]
    assert family1._for_model(2, new) == {"n": 2, "column": "Tag", "type": "hex", "keywords": ["0x1F"], "contents": {"observed": "o"}, "header_cell": "TAG (hex)",
                                          "filled_on": "filled only on rows where OPC is Read", "snippets": [{"ref": "a.md:1", "quote": "q"}]}


def test_only_the_keywords_are_read_for_an_entry_whose_meaning_is_known():
    from agentic import family1
    words = "words that many columns hold (1)"
    batch = [{"column": "Tag", "keywords": ["A", "B"], "meaning_known": "the tag"}, {"column": "Len", "keywords": ["X"], "meaning_known": "the length"},
             {"column": "New", "keywords": ["Y"]}, {"column": words, "shared": True, "keywords": ["Reserved"], "meaning_known": "not a column"}]
    ans = {"columns": [
        {"n": 1, "meaning": "another meaning, which was not asked for", "kind": "web", "ref": "https://example.org/x", "quote": "q",
         "keywords": [["A", "the value A", "model"], ["B", "", "model"]]},
        {"n": 2, "meaning": "written although it is known", "kind": "model", "keywords": []},
        {"n": 3, "meaning": "a new column", "kind": "model", "keywords": [["Y", "the value Y", "data"]]},
        {"n": 4, "keywords": [["reserved", "not used", "model"]]}]}
    got = family1._read_answers(ans, batch)
    assert set(got) == {"Tag", "New", words}                                           # a known entry without a keyword meaning says nothing
    assert got["Tag"] == {"column": "Tag", "meaning": "", "source": {}, "keywords_only": True,
                          "keywords": [{"keyword": "A", "meaning": "the value A", "source": dict(MODEL_SOURCE)}]}
    assert "keywords_only" not in got["New"] and got["New"]["meaning"] == "a new column"
    assert got["New"]["keywords"] == [{"keyword": "Y", "meaning": "the value Y", "source": {"kind": "data", "ref": "New", "quote": "Y"}}]
    assert got[words]["keywords_only"] is True and [k["keyword"] for k in got[words]["keywords"]] == ["Reserved"]


def test_a_known_column_counts_only_its_keywords_and_more_of_them_fit_in_one_call():
    from agentic import family1
    assert family1._weight({"column": "a", "keywords": ["x", "y"]}) == 3
    assert family1._weight({"column": "a", "keywords": ["x", "y"], "meaning_known": "m"}) == 2
    assert family1._weight({"column": "a", "keywords": [], "meaning_known": "m"}) == 1                    # never nothing
    known = [{"column": "c%d" % i, "keywords": ["k"], "meaning_known": "m", "group": ""} for i in range(100)]
    parts, per = family1.ground_parts(known, 1, most=family1.GROUND_MEANINGS, columns=family1.GROUND_BATCH_KNOWN)
    assert per == 100 and [len(p) for p in parts] == [60, 40]                          # 60 known columns in one call at most
    parts, per = family1.ground_parts(known, 1)
    assert [len(p) for p in parts] == [40, 40, 20]                                     # no number given: GROUND_BATCH (40) entries at most
    new = [{"column": "c%d" % i, "keywords": ["k"] * 9, "group": ""} for i in range(40)]    # 400 meanings
    parts, per = family1.ground_parts(new, 2, most=90)
    assert per == 90 and max(len(p) for p in parts) == 9                               # a smaller number given by the caller holds
    parts, per = family1.ground_parts(new, 2)
    assert per == 150 and max(len(p) for p in parts) == 15
    # the number that no call used any more (90 meanings in a call that may search the web) is gone: the calls that may search
    # the web ask for column meanings only (column_parts), the keyword calls hold up to GROUND_MEANINGS and never search
    assert not hasattr(family1, "GROUND_MEANINGS_WEB") and family1.GROUND_MEANINGS == 150
    # an entry is never cut in two: 361 columns of 20 keywords are 52 calls of 7 columns (140 meanings), the last of 4
    wide = [{"column": "c%d" % i, "keywords": ["k%d" % j for j in range(20)], "meaning_known": "m", "group": ""} for i in range(361)]
    parts, per = family1.ground_parts(wide, 16, most=family1.GROUND_MEANINGS, columns=family1.GROUND_BATCH_KNOWN)
    assert per == 150 and [len(p) for p in parts] == [7] * 51 + [4]
    assert [c["column"] for p in parts for c in p] == [c["column"] for c in wide]      # every column once, in the file's order


def test_the_five_real_headers_are_recognised_as_one_tool_and_unknown_names_as_none():
    from agentic import family1
    with open(os.path.join(APP, "data", "lecroy_real_headers.json")) as fh:
        files = json.load(fh)["files"]
    assert len(files) == 5
    tool = None
    for name, recs in files.items():
        tool = family1.exported_by([{"column": n} for n in recs[0]["columns"].values()])
        assert (tool["tool"], tool["name"], tool["how"]) == (TOOL, TOOL_NAME, "recognised"), name
        assert tool["found"] >= 5 and tool["share"] >= 0.3, name
    exported, knowledge = family1._prompt_words(tool)
    assert exported.startswith("exported by " + TOOL_NAME) and knowledge.startswith("your knowledge of ")
    assert TOOL_NAME in family1._web_note(tool)
    none = family1.exported_by([{"column": "Field %03d" % i} for i in range(40)])        # no tool is assumed
    assert none["tool"] is None and none["how"] == "unknown" and none["found"] == 0 and none["name"] == ""
    assert family1._prompt_words(none) == ("whose exporting tool is not known", "your general knowledge of what such names and values point to")
    assert "The tool that exported this file is not known" in family1._web_note(none)


# ------------------------------------------------------------------------------------------ the reference document first
def test_a_recognised_export_takes_its_columns_from_the_reference_document_and_asks_only_for_keywords():
    """Owner, 2026-11-12: "keep that document ... ground from it before moving": the columns of a Teledyne LeCroy export get their
    meaning from the reference document with no model call; only their keywords reach the model, without the web."""
    from agentic import family1
    names = _real_header()
    doc, prepared = _library_kinds(names)
    assert len(doc) >= 25 and prepared and len(doc) + len(prepared) == len(names)       # the document has every name of the real link export
    with _World("lecroy") as w:
        model, res, out, ctx = w.ground(_lecroy(kws=3), LINK)
        cols = out["columns"]
        assert set(cols) == set(names)
        for n in doc:
            m = cols[n]
            assert m["meaning"] and m["source"]["kind"] == "document" and m["checked"] is True, n
            assert m["source"]["ref"].rpartition(":")[0].endswith("CSV_EXPORT_REFERENCE.md") and m["source"]["quote"], n
            assert family1._status(m) == FROM_DOCUMENT, n
        for n in prepared:
            assert cols[n]["meaning"] and cols[n]["checked"] is False and family1._status(cols[n]) == FROM_PREPARED, n
        assert res.output["meanings"] == {FROM_DOCUMENT: len(doc), FROM_PREPARED: len(prepared)}
        # the model was asked for no column's meaning: every entry it got has its meaning already, and no call had the web
        asked = _entries(model)
        assert res.output["columns_asked"] == 0 and model.retries == 0 and ctx.evidence_calls == []
        assert sorted(c["column"] for c in asked) == sorted(names) and model.cols_seen == len(names)
        assert all(c["meaning_known"] == cols[c["column"]]["meaning"] and len(c["keywords"]) == 3 for c in asked)
        assert res.output["web_allowed"] is True and not any(a["tools"] for a in model.asked)
        assert all(len(m["keywords"]) == 3 for m in cols.values()) and cols[names[0]]["keywords"]["LK0_1"]["meaning"] == "the value LK0_1"
        t = res.output["timing"]
        assert (t["columns_from_the_reference_document"], t["columns_from_the_model_when_the_document_was_prepared"], t["columns_asked"],
                t["keyword_meanings_asked"]) == (len(doc), len(prepared), 0, 3 * len(names))
        last = ctx.notes[-1][1]
        assert last.startswith("100% · Data Grounder") and "%d of %d columns done, %d with a meaning" % (len(names), len(names), len(names)) in last
        assert "%d from the reference document of %s" % (len(doc), TOOL_NAME) in last
        assert "%d from the model's knowledge when that document was prepared" % len(prepared) in last
        assert "%d meanings taken from the reference document of %s" % (len(doc), TOOL_NAME) in res.producer
        assert res.output["exported_by"]["name"] == TOOL_NAME and out["exported_by"]["tool"] == TOOL
        assert out["store"] == {"tool": TOOL, "scopes": {n: "link" for n in names}}       # remembered for every link export of this tool
        assert os.path.exists(os.path.join(w.folder, TOOL + ".json"))
        # the next run of the same file: nothing is asked; the columns are read from the document again, the keywords are kept
        model2, res2, out2, ctx2 = w.ground(_lecroy(kws=3), LINK, run_id=2)
        assert model2.calls == 0 and res2.output["timing"]["model_calls"] == 0 and res2.output["timing"]["keyword_meanings_asked"] == 0
        assert _said(out2) == _said(out)
        assert all(family1._status(out2["columns"][n]) == FROM_DOCUMENT for n in doc)
        assert all(family1._status(out2["columns"][n]) == FROM_PREPARED for n in prepared)
        assert all(family1._status(k) == KEPT + FROM_MODEL and k["stored"]["file"] == "link.csv" for m in out2["columns"].values() for k in m["keywords"].values())


def test_the_first_place_that_has_a_meaning_wins_and_the_model_is_asked_only_for_the_rest():
    """The order: approved dictionary, approved remembered meaning, reference document, an earlier run, the model's knowledge
    when the document was prepared, the model."""
    from agentic import family1
    names = _real_header()
    doc, prepared = _library_kinds(names)
    d1, d2, d3 = doc[:3]
    m1, m2 = prepared[:2]
    asha = {"by": "Asha", "at": 1794390000}
    with _World("order") as w:
        w.dictionary({"level": "link", "file": "link_march.csv", "approved_by": "Sagar", "approved_at": 1794390000,
                      "columns": [{"column": d1, "meaning": "the dictionary's meaning", "source": {"kind": "admin", "ref": "Sagar", "quote": ""}, "keywords": []}]})
        st = w.store(TOOL)
        _seed(st, "link", d1, "an approved remembered meaning, which the dictionary beats", approved=asha, file="old_link.csv")
        _seed(st, "link", d2, "what Asha approved", approved=asha, file="old_link.csv")
        _seed(st, "link", d3, "an earlier run's reading, which the document beats")
        _seed(st, "link", m1, "an earlier run's reading of it")
        _seed(st, "link", "My Own Mode", "the mode, as an earlier run understood it", values=["Fast", "Idle"], keywords={"Fast": "quick", "Slow": "not quick"})
        _seed(st, "link", "My Own Flag", "what this name stood for in a file with other values", values=["OLD1", "OLD2"])
        assert st.save() == 6
        cols_in = _lecroy(kws=0, more=[("My Own Counter", []), ("My Own Flag", ["On", "Off"]), ("My Own Mode", ["Fast", "Slow"])])
        model, res, out, ctx = w.ground(cols_in, LINK)
        cols = out["columns"]
        assert cols[d1]["meaning"] == "the dictionary's meaning"                                       # 1. the approved dictionary, before the store
        assert family1._status(cols[d1]).startswith("from the approved dictionary of link_march.csv (approved by Sagar, ")
        assert cols[d2]["meaning"] == "what Asha approved"                                             # 1. an approved remembered meaning, before the document
        assert family1._status(cols[d2]).startswith("from the approved dictionary of old_link.csv (approved by Asha, ")
        assert family1._status(cols[d3]) == FROM_DOCUMENT and cols[d3]["source"]["kind"] == "document"   # 2. the document, before an earlier run
        assert cols[d3]["meaning"] != "an earlier run's reading, which the document beats"
        assert cols[m1]["meaning"] == "an earlier run's reading of it" and family1._status(cols[m1]) == KEPT + FROM_MODEL    # 3. an earlier run, before 4.
        assert family1._status(cols[m2]) == FROM_PREPARED                                              # 4. the model's knowledge when the document was prepared
        mode = cols["My Own Mode"]                                                                     # 3. not in the document: an earlier run, with its keywords
        assert mode["meaning"] == "the mode, as an earlier run understood it" and {k: v["meaning"] for k, v in mode["keywords"].items()} == {"Fast": "quick", "Slow": "not quick"}
        # 5. the model: only the column nothing knows and the one whose name now stands for other values
        # (one call for the meanings of the two; the two keywords of My Own Flag in a call of their own at the same time)
        wanted, words = _for_meaning(model), _for_keywords(model)
        assert model.calls == 2 and sorted(c["column"] for c in wanted) == ["My Own Counter", "My Own Flag"]
        assert {c["column"]: c.get("keywords_seen") for c in wanted} == {"My Own Counter": [], "My Own Flag": ["On", "Off"]} and not any("keywords" in c for c in wanted)
        assert [(c["column"], c["meaning_known"], c["keywords"]) for c in words] == [("My Own Flag", family1.KEYWORDS_APART, ["On", "Off"])]
        assert cols["My Own Flag"]["meaning"] == "what My Own Flag holds" and cols["My Own Counter"]["meaning"] == "what My Own Counter holds"
        assert {k: v["meaning"] for k, v in cols["My Own Flag"]["keywords"].items()} == {"On": "the value On", "Off": "the value Off"}
        t = res.output["timing"]
        assert (t["columns_from_the_approved_dictionary"], t["columns_from_the_reference_document"], t["columns_from_the_model_when_the_document_was_prepared"],
                t["columns_from_earlier_runs"], t["columns_asked"]) == (2, len(doc) - 2, len(prepared) - 1, 2, 2)
        assert res.output["columns_asked"] == 2
        last = ctx.notes[-1][1]
        for words in ("2 taken from the approved dictionary", "%d from the reference document of %s" % (len(doc) - 2, TOOL_NAME),
                      "%d from the model's knowledge when that document was prepared" % (len(prepared) - 1), "2 understood in an earlier run"):
            assert words in last, (words, last)
        assert "%d of %d columns done, %d with a meaning" % (len(cols_in), len(cols_in), len(cols_in)) in last


def test_a_name_that_the_level_does_not_tell_apart_is_remembered_for_this_header_only():
    """A recognised tool's column is remembered under its level (the same name is the same field in every link export). A column
    without a header cell and a name the file has twice are not: they are remembered under this file's own header, or not at all."""
    names = _real_header()
    odd = ["Snoop", "Snoop#2", "column 7"]
    assert "Snoop" in names
    cols_in = _lecroy(kws=0, more=[("Snoop#2", []), ("column 7", [])])
    with _World("scopes") as w:
        bare = {k: v for k, v in LINK.items() if k != "format_key"}
        model, res, out, ctx = w.ground(cols_in, bare)
        assert out["store"]["scopes"] == {n: "link" for n in names if n != "Snoop"}             # no header key: nothing to remember the three under
        assert sorted(c["column"] for c in _entries(model)) == ["Snoop#2", "column 7"]          # the document does not have them: asked
        model, res, out, ctx = w.ground(cols_in, bare, run_id=2)
        assert sorted(c["column"] for c in _entries(model)) == ["Snoop#2", "column 7"]          # ... and asked again: they were not kept
        model, res, out, ctx = w.ground(cols_in, LINK, run_id=3)
        assert {n: out["store"]["scopes"][n] for n in odd} == {n: "fmtL" for n in odd}
        assert all(out["store"]["scopes"][n] == "link" for n in names if n != "Snoop")
        assert sorted(c["column"] for c in _entries(model)) == ["Snoop#2", "column 7"]
        model, res, out, ctx = w.ground(cols_in, LINK, run_id=4)
        assert model.calls == 0 and out["columns"]["Snoop#2"]["meaning"] == "what Snoop#2 holds"   # the same header again: known


# ------------------------------------------------------------------------------------------ once understood, done
def test_what_one_run_understood_is_not_asked_again_in_the_next_run():
    """Owner, 2026-11-12: "if once the column name has been done, it's done" and "verify just by using the column names and along
    with the top 20 keywords present under the column"."""
    from agentic import family1
    with _World("again") as w:
        model, res, out, ctx = w.ground(_cols(12), PACKETS)
        assert model.cols_seen == 12 and res.output["columns_asked"] == 12
        assert model.entries_seen == 24 and len(_for_meaning(model)) == len(_for_keywords(model)) == 12     # each column once for its meaning, once for its keywords
        assert out["store"] == {"tool": None, "scopes": {"Field %03d" % i: "fmtA" for i in range(12)}}
        assert os.path.exists(os.path.join(w.folder, "unknown_source.json"))
        # the same file in another run: no call, the same meanings, and each says that it was kept
        model2, res2, out2, ctx2 = w.ground(_cols(12), PACKETS, run_id=2)
        assert model2.calls == 0 and _said(out2) == _said(out)
        assert all(family1._status(m) == KEPT + FROM_MODEL and m["stored"]["file"] == "packets.csv" for m in out2["columns"].values())
        assert all(len(m["keywords"]) == 5 and all(family1._status(k).startswith(KEPT) for k in m["keywords"].values()) for m in out2["columns"].values())
        t = res2.output["timing"]
        assert res2.output["columns_asked"] == 0 and (t["model_calls"], t["parts"], t["columns_from_earlier_runs"], t["keyword_meanings_asked"]) == (0, 0, 12, 0)
        assert res2.output["meanings"] == {KEPT + FROM_MODEL: 12}
        texts = [x for _w, x in ctx2.notes]
        assert texts[0].startswith("0% · Data Grounder") and texts[-1].startswith("100% · Data Grounder")
        assert "12 of 12 columns done, 12 with a meaning" in texts[-1] and "12 understood in an earlier run" in texts[-1]
        assert "12 meanings kept from an earlier run" in res2.producer and ctx2.evidence_calls == []
        # a file with another header is another thing: asked
        model3, res3, out3, ctx3 = w.ground(_cols(12), dict(PACKETS, name="other.csv", format_key="fmtB"), run_id=3)
        assert model3.cols_seen == 12 and res3.output["columns_asked"] == 12
        # the same name with none of the keywords it had, or with another kind of values, is not taken as the same column
        changed = _cols(12)
        changed[4]["keywords"] = [{"value": "Z%d" % j, "count": 5} for j in range(5)]
        changed[7]["type"] = "integer"
        model4, res4, out4, ctx4 = w.ground(changed, PACKETS, run_id=4)
        assert sorted(c["column"] for c in _for_meaning(model4)) == ["Field 004", "Field 007"] and res4.output["columns_asked"] == 2
        assert {c["column"] for c in _entries(model4)} == {"Field 004", "Field 007"}                      # nothing of the 10 other columns
        z = [c for c in _for_keywords(model4) if c["column"] == "Field 004"]
        assert len(z) == 1 and z[0]["keywords"] == ["Z%d" % j for j in range(5)] and z[0]["meaning_known"] == family1.KEYWORDS_APART


def test_a_keyword_that_got_no_meaning_is_asked_again_and_only_that():
    with _World("keyword") as w:
        model, res, out, ctx = w.ground(_cols(12), PACKETS, no_keyword=("K3_1",))
        assert "K3_1" not in out["columns"]["Field 003"]["keywords"] and len(out["columns"]["Field 003"]["keywords"]) == 4
        model2, res2, out2, ctx2 = w.ground(_cols(12), PACKETS, run_id=2)
        asked = _entries(model2)
        assert model2.calls == 1 and len(asked) == 1 and not model2.asked[0]["tools"]           # one call, one entry, without the web
        assert asked[0]["column"] == "Field 003" and asked[0]["meaning_known"] == "what Field 003 holds" and asked[0]["keywords"] == ["K3_1"]
        assert out2["columns"]["Field 003"]["keywords"]["K3_1"]["meaning"] == "the value K3_1" and res2.output["columns_asked"] == 0
        assert out2["columns"]["Field 003"]["meaning"] == "what Field 003 holds" and len(out2["columns"]["Field 003"]["keywords"]) == 5
        model3, res3, out3, ctx3 = w.ground(_cols(12), PACKETS, run_id=3)
        assert model3.calls == 0 and out3["columns"]["Field 003"]["keywords"]["K3_1"]["meaning"] == "the value K3_1"


def test_a_part_that_fails_does_not_lose_what_the_other_parts_answered():
    """No credit (HTTP 402) on two of seven calls: the step stops with the reason, but what the five calls that answered brought
    is kept, so "Run it again" asks only for what the two refused calls held: the meanings of the columns of the one and the
    keywords of the columns of the other, and nothing of the rest."""
    from agentic import family1

    def bad(cols):
        return any(c["column"] == "Field 020" for c in cols)
    names = ["Field %03d" % i for i in range(90)]
    with _World("partial") as w:
        # 90 columns of 5 keywords, 4 calls at once -> the columns' meanings in two calls of 45 (Field 000-044 and 045-089), the
        # 450 keyword meanings in calls of 22, 22, 22, 22 and 2 columns (113 meanings in a call at most). The two calls that
        # hold Field 020 are refused after the five others are back: at most 5 calls start in one second, so the last two
        # start a second after the first, and the refusals come 2.5 seconds after their calls
        model, err, _none, ctx = w.ground(_cols(90), PACKETS, expect_error=True, mode="402", only=bad, pause=lambda cols: 2.5 if bad(cols) else 0.05)
        assert "no credit" in err and "Settings -> Model connection" in err and model.retries == 0
        assert model.calls == 7 and sorted(len(a["columns"]) for a in model.asked) == [2, 22, 22, 22, 22, 45, 45]
        refused = [a["columns"] for a in model.asked if a["refused"]]
        assert len(refused) == 2 and all(bad(a) for a in refused)
        no_meaning = {c["column"] for a in refused for c in a if "meaning_known" not in c}
        no_keywords = {c["column"] for a in refused for c in a if "meaning_known" in c}
        assert no_meaning == set(names[:45]) and no_keywords == set(names[:22])
        answered = [a["columns"] for a in model.asked if not a["refused"]]
        assert {c["column"] for a in answered for c in a if "meaning_known" not in c} == set(names[45:])
        assert {c["column"] for a in answered for c in a if "meaning_known" in c} == set(names[22:])
        # kept: the meaning of every column of the call that answered, and the keyword meanings of every column whose keyword
        # call answered - also of Field 022-044, whose own meaning was refused: kept without a meaning, so not taken as known
        st = w.store()
        for i, n in enumerate(names):
            e = st.match("fmtA", n, "text", ["K%d_0" % i])
            assert (e is None) if i < 45 else (e["meaning"] == "what %s holds" % n), n
            assert len(st.keywords("fmtA", n)) == (0 if i < 22 else 5), n
        model2, res2, out2, ctx2 = w.ground(_cols(90), PACKETS, run_id=2)
        assert {c["column"] for c in _for_meaning(model2)} == no_meaning and {c["column"] for c in _for_keywords(model2)} == no_keywords
        assert model2.cols_seen == 45 and model2.entries_seen == 45 + 22            # each once: nothing that had answered is asked again
        assert len(out2["columns"]) == 90 and all(m["meaning"] and len(m["keywords"]) == 5 for m in out2["columns"].values())
        assert all(family1._status(out2["columns"][n]) == KEPT + FROM_MODEL for n in names[45:])
        assert all(family1._status(out2["columns"][n]) == FROM_MODEL for n in names[:45])
        assert all(family1._status(k).startswith(KEPT) for n in names[22:] for k in out2["columns"][n]["keywords"].values())
        assert all(family1._status(k) == FROM_MODEL for n in names[:22] for k in out2["columns"][n]["keywords"].values())
        assert res2.output["columns_asked"] == 45 and res2.output["timing"]["keyword_meanings_asked"] == 22 * 5


# ------------------------------------------------------------------------------------------ a word that many columns hold
def test_a_keyword_that_many_columns_hold_is_asked_once_for_all_of_them():
    from agentic import family1
    with _World("shared") as w:
        cols_in = _cols(10, kws=2)
        for i, c in enumerate(cols_in):
            c["keywords"].append({"value": "Reserved", "count": 3})            # in all 10 columns: asked once
            if i < 7:
                c["keywords"].append({"value": "Enabled", "count": 2})         # in 7 columns: fewer than 8, so asked with each column
        model, res, out, ctx = w.ground(cols_in, PACKETS)
        calls = [(a, c) for a in model.asked for c in a["columns"]]
        once = [(a, c) for a, c in calls if "held_by" in c]
        assert len(once) == 1
        a, c = once[0]
        assert c["column"] == "words that many columns hold (1)" and c["keywords"] == ["Reserved"] and set(c) == {"n", "column", "meaning_known", "keywords", "held_by"}
        assert c["held_by"] == {"Reserved": "10 columns, such as Field 000, Field 001, Field 002"} and c["meaning_known"].startswith("not a column")
        assert not a["tools"]
        # the 10 columns: each once for its meaning (its keywords shown, the word that many hold among them: it is in the column)
        # and once for its keywords, without the word that is asked once
        wanted = [c for _a, c in calls if "held_by" not in c and "meaning_known" not in c]
        assert len(wanted) == 10 and all("Reserved" in c["keywords_seen"] and "keywords" not in c for c in wanted)
        others = [c for _a, c in calls if "held_by" not in c and "meaning_known" in c]
        assert len(others) == 10 and all(c["meaning_known"] == family1.KEYWORDS_APART for c in others) and len(calls) == 21
        assert not any("Reserved" in c["keywords"] for c in others) and sum("Enabled" in c["keywords"] for c in others) == 7
        # its meaning is on every column that holds it, and says that it was asked once for 10 columns
        assert sorted(out["columns"]) == ["Field %03d" % i for i in range(10)]
        for i in range(10):
            kws = out["columns"]["Field %03d" % i]["keywords"]
            assert kws["Reserved"]["meaning"] == "the value Reserved" and kws["Reserved"]["asked_once_for"] == 10
            assert "asked_once_for" not in kws["K%d_0" % i] and ("Enabled" in kws) == (i < 7) and "asked_once_for" not in kws.get("Enabled", {})
        t = res.output["timing"]
        assert res.output["columns_asked"] == 10 and t["shared_keywords_asked_once"] == 1 and t["keyword_meanings_asked"] == 10 * 2 + 7 + 1
        assert any("1 keyword that many columns hold asked once" in x for _w, x in ctx.notes)
        assert "1 keyword that many columns hold asked once for all of them" in res.output["how_long"]
        model2, res2, out2, ctx2 = w.ground(cols_in, PACKETS, run_id=2)
        assert model2.calls == 0 and out2["columns"]["Field 009"]["keywords"]["Reserved"]["asked_once_for"] == 10


# ------------------------------------------------------------------------------------------ the two kinds of call
def _new_and_known():
    """24 columns: the approved dictionary has the meaning of Field 000-005 but of none of their 10 keywords (60 keyword meanings
    to ask); Field 006-023 are new, each with 9 keywords (180 meanings to ask)."""
    cols = _cols(6, kws=10) + _cols(18, kws=9, start=6)
    known = {"level": "packets", "file": "packets_old.csv", "approved_by": "Sagar", "approved_at": 1794390000,
             "columns": [{"column": "Field %03d" % i, "meaning": "approved meaning %d" % i, "source": {"kind": "admin", "ref": "Sagar", "quote": ""}, "keywords": []}
                         for i in range(6)]}
    return cols, known


def test_the_meanings_of_new_columns_and_the_keywords_are_asked_in_calls_of_their_own():
    """(Until 2026-11-12 this file was 4 calls: the 18 new columns with their keywords in 3 calls of 6, the keywords of the 6
    known columns in 1. Now the 18 columns are one call for their meanings and all the keywords go apart: 6 calls.)"""
    from agentic import family1
    cols_in, known = _new_and_known()
    with _World("split") as w:
        w.dictionary(known)
        model, res, out, ctx = w.ground(cols_in, PACKETS)
        new = [a for a in model.asked if not any("meaning_known" in c for c in a["columns"])]
        kw_only = sorted((a for a in model.asked if _known(a["columns"])), key=lambda a: a["columns"][0]["column"])
        assert len(new) + len(kw_only) == len(model.asked) == 6                          # no call mixes the two kinds
        # the 18 new columns: one call for their meanings (fewer than 80 open columns are one call), each with its 9 keywords shown
        assert [len(a["columns"]) for a in new] == [18]
        assert all(c["keywords_seen"] == ["K%d_%d" % (int(c["column"][-3:]), j) for j in range(9)] and "keywords" not in c for c in new[0]["columns"])
        # the 60 + 162 keyword meanings: 4 calls at once -> 56 meanings in a call at most: 5 known columns (50), then the sixth
        # with 5 new ones (55), 6 new ones (54), 6 (54) and the last (9)
        assert [len(a["columns"]) for a in kw_only] == [5, 6, 6, 6, 1]
        assert [c["column"] for a in kw_only for c in a["columns"]] == ["Field %03d" % i for i in range(24)]      # every column once, in the file's order
        assert all(c["meaning_known"] == ("approved meaning %d" % i if i < 6 else family1.KEYWORDS_APART) and len(c["keywords"]) == (10 if i < 6 else 9)
                   for i, c in enumerate(c for a in kw_only for c in a["columns"]))
        assert all(a["tools"] for a in new) and not any(a["tools"] for a in kw_only)     # the web only where a column's meaning is looked for
        t = res.output["timing"]
        assert (t["parts"], t["model_calls"], t["calls_at_once_allowed"], t["meanings_per_part_at_most"]) == (6, 6, 4, 56)
        assert (t["calls_for_column_meanings"], t["columns_per_such_call_at_least"], t["columns_per_such_call_most"]) == (1, 18, 18)
        assert (t["columns_asked"], t["keyword_meanings_asked"], t["columns_from_the_approved_dictionary"]) == (18, 18 * 9 + 60, 6)
        assert any("6 parts of at most 56 meanings" in x for _w, x in ctx.notes)
        assert len(out["columns"]) == 24 and all(len(out["columns"]["Field %03d" % i]["keywords"]) == (10 if i < 6 else 9) for i in range(24))
        assert out["columns"]["Field 000"]["meaning"] == "approved meaning 0" and out["columns"]["Field 006"]["meaning"] == "what Field 006 holds"


def test_a_keyword_call_whose_answer_was_cut_off_is_asked_in_two_halves():
    cols_in, known = _new_and_known()
    with _World("cut") as w:
        w.dictionary(known)
        # only a keyword call's answer may be too long: one for more than 3 entries. The keywords are asked in calls of 5, 6, 6, 6
        # and 1 entries (see the test above): four of them are cut off and each is asked again in two halves
        model, res, out, ctx = w.ground(cols_in, PACKETS, mode="cut", only=_known, cut_above=3)
        kw_only = [a for a in model.asked if _known(a["columns"])]
        assert model.cut == 4 and sorted(len(a["columns"]) for a in kw_only) == [1, 2] + [3] * 7 + [5, 6, 6, 6]
        assert not any(a["tools"] or a["again"] or a["retry"] for a in kw_only)
        times = {}
        for a in kw_only:
            for c in a["columns"]:
                times[c["column"]] = times.get(c["column"], 0) + 1
        assert times == dict({"Field %03d" % i: 2 for i in range(23)}, **{"Field 023": 1})      # once in the call that was cut off, once in a half
        assert len([a for a in model.asked if not _known(a["columns"])]) == 1 and model.calls == 14       # the call for the 18 meanings was not cut
        assert all(len(out["columns"]["Field %03d" % i]["keywords"]) == (10 if i < 6 else 9) for i in range(24))
        assert all(m["meaning"] for m in out["columns"].values())
        assert "asked in two halves: the first answer was cut off" in res.producer
        assert any("last problem: part" in x and "longer than one call may write" in x for _w, x in ctx.notes)


def test_keywords_that_got_no_answer_are_asked_again_once_without_the_web():
    cols_in, known = _new_and_known()
    with _World("asked_again") as w:
        w.dictionary(known)
        # a keyword call answers every second entry of its first try. The keywords are asked in calls of Field 000-004, 005-010,
        # 011-016, 017-022 and 023: four of them leave entries without an answer, and exactly those are asked again, once
        model, res, out, ctx = w.ground(cols_in, PACKETS, mode="half", only=_known)
        again = sorted(([c["column"] for c in a["columns"]] for a in model.asked if a["again"]))
        assert again == [["Field %03d" % i for i in g] for g in ((1, 3), (6, 8, 10), (12, 14, 16), (18, 20, 22))]
        assert not any(a["tools"] for a in model.asked if a["again"]) and model.retries == 0       # not the retry of new columns "without the web"
        assert all(_known(a["columns"]) for a in model.asked if a["again"]) and model.calls == 1 + 5 + 4
        assert all(len(out["columns"]["Field %03d" % i]["keywords"]) == (10 if i < 6 else 9) for i in range(24))
        assert " (asked again)" in res.producer and any("4 parts asked again" in x for _w, x in ctx.notes)
        assert not any("retried without the web" in x for _w, x in ctx.notes)


# ------------------------------------------------------------------------------------------ evidence
def test_the_evidence_is_written_once_and_holds_only_what_the_model_said_about_a_column_now():
    with _World("evidence") as w:
        w.dictionary({"level": "packets", "file": "packets_old.csv", "approved_by": "Sagar", "approved_at": 1794390000,
                      "columns": [{"column": "Field %03d" % i, "meaning": "approved meaning %d" % i, "source": {"kind": "admin", "ref": "Sagar", "quote": ""}, "keywords": []}
                                  for i in range(3)]})
        st = w.store()
        for i in (3, 4):
            _seed(st, "fmtA", "Field %03d" % i, "an earlier run's meaning %d" % i, values=["K%d_0" % i, "K%d_1" % i],
                  keywords={"K%d_0" % i: "kept", "K%d_1" % i: "kept"})
        assert st.save() == 2
        model, res, out, ctx = w.ground(_cols(12, kws=2), PACKETS, no_meaning=("Field 011",))
        assert len(ctx.evidence_calls) == 1                                              # one write for the whole file
        claims = ctx.evidence_calls[0]
        # not the 3 approved columns, not the 2 of an earlier run, not the column the model gave no meaning for, and no keyword
        assert sorted(c["text"] for c in claims) == ["Field %03d" % i for i in range(5, 11)]
        assert all(c["source"] == MODEL_SOURCE and c["verified"] is False for c in claims)
        assert "Field 011" not in out["columns"] and len(out["columns"]) == 11
        assert "1 column without a meaning after 3 tries" in res.producer


# ------------------------------------------------------------------------------------------ the admin approves, the admin rejects
def test_an_approved_dictionary_is_remembered_and_a_later_file_takes_it_without_a_call():
    from agentic import family1
    with _World("approve") as w:
        cols_in = _cols(6, kws=2)
        model, res, out, ctx = w.ground(cols_in, PACKETS, run_id=5)
        review = family1._manager(_ReviewCtx(ctx, res.output, "Sagar"), PACKETS)           # the dictionary the admin reviews
        step = {"key": "manager:packets.csv", "output": json.dumps(review.output)}
        family1.on_approve(None, {"id": 5}, step, {"edits": {"Field 000": "the admin's own words", "Field 001: K1_0": "the admin's keyword words"}}, "Sagar")
        st = w.store()
        e = st.match("fmtA", "Field 000", "text")
        assert e["meaning"] == "the admin's own words" and e["source"] == {"kind": "admin", "ref": "Sagar", "quote": ""} and e["checked"] is True
        assert e["approved"]["by"] == "Sagar" and e["approved"]["at"] and e["learned_from"]["file"] == "packets.csv" and e["learned_from"]["run"] == 5
        e = st.match("fmtA", "Field 002", "text")                                          # left as it was: it keeps the source it had
        assert e["meaning"] == "what Field 002 holds" and e["source"]["kind"] == "model" and e["checked"] is False and e["approved"]["by"] == "Sagar"
        k = st.keywords("fmtA", "Field 001")["K1_0"]
        assert k["meaning"] == "the admin's keyword words" and k["source"]["kind"] == "admin" and k["checked"] is True and k["approved"]["by"] == "Sagar"
        assert st.keywords("fmtA", "Field 001")["K1_1"]["approved"]["by"] == "Sagar" and st.keywords("fmtA", "Field 001")["K1_1"]["source"]["kind"] == "model"
        # a later file with the same header, the saved dictionary present: nothing is asked
        later = dict(PACKETS, name="packets_b.csv")
        model2, res2, out2, ctx2 = w.ground(cols_in, later, run_id=6)
        assert model2.calls == 0 and out2["columns"]["Field 000"]["meaning"] == "the admin's own words"
        assert all(family1._status(m).startswith("from the approved dictionary of packets.csv (approved by Sagar, ") for m in out2["columns"].values())
        # ... and without the dictionary file, from what was remembered column by column: the same
        shutil.rmtree(os.path.join(w.knowledge, "dictionaries"))
        model3, res3, out3, ctx3 = w.ground(cols_in, later, run_id=7)
        assert model3.calls == 0 and _said(out3) == _said(out2)
        assert out3["columns"]["Field 000"]["meaning"] == "the admin's own words" and out3["columns"]["Field 000"]["source"]["kind"] == "admin"
        assert out3["columns"]["Field 001"]["keywords"]["K1_0"]["meaning"] == "the admin's keyword words"
        assert all(family1._status(m).startswith("from the approved dictionary of packets.csv (approved by Sagar, ") for m in out3["columns"].values())
        assert all(family1._status(k).startswith("from the approved dictionary of packets.csv (approved by Sagar, ")
                   for m in out3["columns"].values() for k in m["keywords"].values())
        assert "6 meanings reused from the approved dictionary" in res3.producer and "6 taken from the approved dictionary" in ctx3.notes[-1][1]
        assert res3.output["timing"]["columns_from_the_approved_dictionary"] == 6


def test_a_rejected_dictionary_forgets_what_that_run_learned_of_that_file_and_nothing_else():
    from agentic import family1
    with _World("reject") as w:
        t_start = time.time()
        a, b, c = (dict(PACKETS, name="%s.csv" % x, format_key="fmt%s" % x.upper()) for x in "abc")
        cols_in = _cols(6, kws=2)
        w.ground(cols_in, a, run_id=7)
        w.ground(cols_in, b, run_id=7)
        w.ground(cols_in, c, run_id=8)
        st = w.store()                      # the admin approved one column of a.csv in the same run
        st.remember("fmtA", "Field 000", {"meaning": "what the admin approved", "source": {"kind": "admin", "ref": "Sagar", "quote": ""}, "checked": True,
                                          "why": "approved by Sagar", "keywords": {}},
                    typ="text", values=["K0_0", "K0_1"], learned_from={"file": "a.csv", "run": 7, "at": time.time()}, approved={"by": "Sagar", "at": time.time()})
        assert st.save() == 1
        run = {"id": 7, "created": t_start}
        assert family1.on_reject(None, run, {"key": "explore:b.csv"}, {}, "Sagar") == 0              # not a dictionary's review: nothing is forgotten
        assert family1.on_reject(None, {"id": 7, "created": time.time() + 3600}, {"key": "manager:b.csv"}, {}, "Sagar") == 0   # learned before that run began: an earlier run's
        assert all(w.store().match("fmt%s" % x, "Field %03d" % i, "text") for x in "ABC" for i in range(6))
        # the dictionary of a.csv is rejected: 5 column meanings and 12 keyword meanings of run 7 are taken out
        assert family1.on_reject(None, run, {"key": "manager:a.csv"}, {}, "Sagar") == 17
        st = w.store()
        assert st.match("fmtA", "Field 000", "text")["meaning"] == "what the admin approved" and not st.keywords("fmtA", "Field 000")
        assert all(st.match("fmtA", "Field %03d" % i, "text") is None and not st.keywords("fmtA", "Field %03d" % i) for i in range(1, 6))
        assert all(st.match(sc, "Field %03d" % i, "text") and len(st.keywords(sc, "Field %03d" % i)) == 2 for sc in ("fmtB", "fmtC") for i in range(6))
        # the next run of a.csv asks for what was forgotten; the approved meaning stays known
        model, res, out, ctx = w.ground(cols_in, a, run_id=9)
        assert sorted(c["column"] for c in _for_meaning(model)) == ["Field %03d" % i for i in range(1, 6)] and res.output["columns_asked"] == 5
        words = {c["column"]: c for c in _for_keywords(model)}
        assert sorted(words) == ["Field %03d" % i for i in range(6)] and len(_entries(model)) == 11          # the keywords of all six were forgotten
        assert words["Field 000"]["meaning_known"] == "what the admin approved"                              # the approved meaning is not asked
        assert all(words["Field %03d" % i]["meaning_known"] == family1.KEYWORDS_APART for i in range(1, 6))
        assert all(m["meaning"] and len(m["keywords"]) == 2 for m in out["columns"].values()) and out["columns"]["Field 000"]["meaning"] == "what the admin approved"


# ------------------------------------------------------------------------------------------ the Data Explorer on a very wide file
def _wide_csv(folder, name, columns, rows=30):
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, name)
    with open(path, "w", newline="") as fh:
        wr = csv.writer(fh)
        wr.writerow(["W%03d" % j for j in range(columns)])
        for r in range(rows):
            wr.writerow([("Idle", "Busy", "Error")[(r + j) % 3] if j % 2 else str(1000 + 7 * r + j) for j in range(columns)])
    return path


def test_above_120_filled_columns_the_explorer_says_each_column_from_the_counts_and_asks_once_for_the_summary():
    """Owner, 2026-11-12: about 2,000 columns in some exports: the model is not asked to repeat the counts of every column."""
    from agentic import family1
    with _World("wide") as w:
        folder = os.path.join(w.root, "wide")
        _wide_csv(folder, "wide.csv", family1.EXPLORE_BY_CODE_ABOVE + 10)
        f = family1.inventory(folder)[0]
        model, res, mem, ctx = w.explore(f)
        assert model.calls == 1 and len(model.summaries) == 1 and model.cols_seen == 0   # one call, for the summary; no column was asked
        asked = model.summaries[0]
        assert len(asked["column_names"]) == 130 and asked["file_facts"]["rows"] == 30 and "write_summary" not in asked
        assert len(asked["columns"]) <= family1.EXPLORE_SUMMARY_COLUMNS and not any("n" in c for c in asked["columns"])
        assert res.output["summary"] == "A file of 130 named columns that hold a value."
        assert (res.output["model_parts"], res.output["columns_with_values"], res.output["rows"]) == (1, 130, 30)
        assert "what each column holds: counted by code" in res.producer
        texts = [x for _w, x in ctx.notes]
        assert any("all 30 lines read" in x and "what each of the 130 columns that hold a value holds is said from the counts" in x for x in texts)
        assert not any("the model describes" in x for x in texts)
        assert len(mem["columns"]) == 130 and all(c["observed"] for c in mem["columns"])  # every column still says what it holds
        # at 120 filled columns the model still describes them, in as many parts as calls run at the same time
        _wide_csv(os.path.join(w.root, "at_limit"), "limit.csv", family1.EXPLORE_BY_CODE_ABOVE)
        f = family1.inventory(os.path.join(w.root, "at_limit"))[0]
        model, res, mem, ctx = w.explore(f, run_id=2)
        assert model.calls == 4 and not model.summaries and model.sizes == [30, 30, 30, 30] and res.output["model_parts"] == 4
        assert "counted by code" not in res.producer
        assert any("all 30 lines read" in x and "the model describes the 120 columns that hold a value" in x for _w, x in ctx.notes)
