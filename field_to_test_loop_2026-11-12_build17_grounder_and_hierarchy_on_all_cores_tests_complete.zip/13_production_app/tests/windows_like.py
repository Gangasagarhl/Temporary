#!/usr/bin/env python3
"""A Windows-like run of the application on this (Linux) machine.

    python3 tests/windows_like.py --out REPORT.json [--tmp FOLDER] [--only step,step]

Production runs on Windows; the code is written and tested on Linux. This program takes away from its own process, and from
every Python process it starts, what Windows does not have, and then runs the application's main parts in a temporary folder:

  taken away   os.nice, os.getuid, os.killpg, os.fork, os.statvfs ... and signal.SIGKILL, SIGHUP ... (the lists GONE_OS, GONE_SIGNAL);
               the modules fcntl, resource, pwd, grp, termios; everything under /proc, /sys, /dev/shm and /etc (FileNotFoundError)
  as Windows   a text file opened without encoding= is read and written as cp1252 (and so is a program's output read with
               text=True); "\\n" written in text mode becomes "\\r\\n"; a file that is open cannot be deleted or replaced
               (PermissionError); a file name with one of < > : " | ? * or a reserved name (con, nul, com1 ...) cannot be made;
               processes for parallel work start with "spawn"; output that is not a console is cp1252
  written down every place where one of these rules changed something (EVENTS in the report), also when the code went on.

os.name stays "posix" (the standard library breaks otherwise), so code under `if os.name == "nt":` is NOT run here: that,
real file locking by a virus scanner, drive letters and the 260-character limit need a real Windows machine.

NEVER import this file: it changes the process that loads it. tests/test_windows_like.py starts it as a program.
"""
import builtins
import io
import json
import os
import signal
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.environ.get("F2T_WIN_APP") or os.path.dirname(HERE)       # the code under test (a copy of it, when F2T_WIN_APP names one)

GONE_OS = ("nice getuid geteuid getgid getegid getpgid getpgrp killpg setsid setpgid fork forkpty sched_getaffinity sched_setaffinity "
           "getloadavg statvfs fstatvfs chown fchown lchown posix_fadvise POSIX_FADV_DONTNEED O_PATH O_CLOEXEC O_NOFOLLOW O_DIRECTORY "
           "getpriority setpriority mkfifo sync fdatasync getresuid getresgid getgroups ttyname openpty wait3 wait4 getsid "
           "pread pwrite setuid setgid chroot ctermid").split()
LIBRARIES_ONLY = ("uname", "sysconf")           # the Linux builds of numpy and the standard library call these when they load: kept for them, gone for the application's own lines
GONE_SIGNAL = "SIGKILL SIGHUP SIGUSR1 SIGUSR2 SIGQUIT SIGPIPE SIGALRM SIGSTOP SIGCONT SIGTSTP SIGWINCH alarm pause setitimer getitimer".split()
GONE_MODULES = ("fcntl", "resource", "pwd", "grp", "termios", "pty", "tty", "syslog", "crypt")
UNIX_ONLY = ("/proc", "/sys", "/dev/shm", "/etc")
BAD_CHARS = set('<>:"|?*')
RESERVED = {"CON", "PRN", "AUX", "NUL"} | {"COM%d" % i for i in range(1, 10)} | {"LPT%d" % i for i in range(1, 10)}

REAL = {}                    # the real functions, for this program's own reading of /proc and for the clean-up
_SEEN = set()
_LONGEST = [0]


def _text(p):
    """A path as text; None for a file descriptor."""
    if isinstance(p, int):
        return None
    try:
        p = os.fspath(p)
    except TypeError:
        return None
    return p.decode("utf-8", "surrogateescape") if isinstance(p, bytes) else p


def _site():
    """The line of the application that asked: 'agentic/family3.py:926 in write_code'. A line of the tests when no application line is involved."""
    f = sys._getframe(1)
    other = None
    while f is not None:
        name = f.f_code.co_filename
        if name != __file__ and name.startswith(APP + os.sep):
            rel = os.path.relpath(name, APP)
            where = "%s:%d in %s" % (rel, f.f_lineno, f.f_code.co_name)
            if not rel.startswith("tests" + os.sep):
                return where
            other = other or where
        f = f.f_back
    return other or "outside the application"


def event(kind, what, path="", site=None, once=False):
    rec = {"kind": kind, "what": what, "path": path, "site": site or _site(), "pid": os.getpid()}
    key = (kind, what, rec["site"]) + (() if once else (path,))
    if key in _SEEN:
        return
    _SEEN.add(key)
    target = os.environ.get("F2T_WL_EVENTS")
    if not target:
        return
    try:
        fd = REAL["os_open"](target, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o644)
        try:
            os.write(fd, (json.dumps(rec) + "\n").encode("utf-8"))
        finally:
            os.close(fd)
    except OSError:
        pass                     # a process that is confined to its own folder cannot write the list


def _unix_only(path, what):
    s = _text(path)
    if not s or not s.startswith("/"):
        return False
    a = os.path.normpath(s)
    for u in UNIX_ONLY:
        if a == u or a.startswith(u + "/"):
            event("unix-path", "%s of %s: Windows has no such path" % (what, u), a, once=True)
            return True
    return False


def _no_such(path):
    return FileNotFoundError(2, "No such file or directory (Windows-like run: Windows has no such path)", _text(path))


def _name_rule(path, what):
    s = _text(path)
    if not s:
        return
    a = os.path.abspath(s)
    for part in a.split("/"):
        stem = part.split(".")[0].upper()
        if any(c in BAD_CHARS or ord(c) < 32 for c in part) or stem in RESERVED or len(part) > 255:
            event("file-name", "%s: Windows cannot make a file or folder with this name" % what, a)
            raise OSError(22, "Invalid argument (Windows-like run: this name cannot exist on Windows)", s)
    root = os.environ.get("F2T_WL_ROOT")
    if root and a.startswith(root + "/") and len(a) - len(root) > _LONGEST[0]:
        _LONGEST[0] = len(a) - len(root)
        if _LONGEST[0] > 120:
            event("path-length", "%d characters below the temporary folder" % _LONGEST[0], a[len(root):])


def _family(pid, out):
    out.append(pid)
    try:
        for tid in REAL["listdir"]("/proc/%d/task" % pid):
            with REAL["open"]("/proc/%d/task/%s/children" % (pid, tid)) as fh:
                for c in fh.read().split():
                    _family(int(c), out)
    except (OSError, ValueError):
        pass
    return out


def _open_by(path):
    """The process (this one or one it started) that has the file open, or None."""
    try:
        target = os.path.realpath(path)
    except OSError:
        return None
    for pid in _family(os.getpid(), []):
        d = "/proc/%d/fd" % pid
        try:
            names = REAL["listdir"](d)
        except OSError:
            continue
        for n in names:
            try:
                if REAL["readlink"]("%s/%s" % (d, n)) == target:
                    return pid
            except OSError:
                pass
    return None


def _busy(path, what):
    s = _text(path)
    if s is None or sys._getframe(2).f_globals.get("__name__") == "tempfile":       # tempfile itself differs on Windows and does not do this there
        return
    pid = _open_by(s)
    if pid is not None:
        site = _site()
        waits = site.startswith("nvme_hier" + os.sep + "osfile.py")      # that helper tries again until the reader has closed the file: no fault unless it gives up
        event("open-file-waited" if waits else "open-file", "%s of a file that is still open in %s: Windows refuses it" % (what, "this process" if pid == os.getpid() else "a process it started"),
              os.path.abspath(s), site=site, once=waits)
        raise PermissionError(13, "The process cannot access the file because it is being used by another process (Windows-like run)", s)


class _Watch(io.TextIOWrapper):
    """A text file opened without encoding=: cp1252 as on Windows, and a note when text that is not plain ASCII is written through it."""
    _wl_path = ""
    _wl_site = ""

    def write(self, s):
        if isinstance(s, str) and not s.isascii():
            event("encoding", "text with other than ASCII characters written to a file opened without encoding= (Windows writes cp1252 there, not UTF-8)", self._wl_path, site=self._wl_site)
        return super().write(s)


def make_windows_like():
    """Change this process. Called once, at the start of the program and of every Python process it starts."""
    if REAL:
        return
    import importlib.abc
    import multiprocessing
    import multiprocessing.popen_fork
    import multiprocessing.spawn
    import shutil
    import sqlite3
    import subprocess
    import tempfile                                   # noqa: F401  (loaded before the flags it reads at import are taken away)
    R = REAL
    R.update(open=builtins.open, os_open=os.open, stat=os.stat, lstat=os.lstat, listdir=os.listdir, scandir=os.scandir, readlink=os.readlink,
             access=os.access, remove=os.remove, unlink=os.unlink, replace=os.replace, rename=os.rename, mkdir=os.mkdir, statvfs=os.statvfs,
             connect=sqlite3.connect, executable=sys.executable, disk_usage=shutil.disk_usage, popen_init=subprocess.Popen.__init__,
             translate=subprocess.Popen._translate_newlines, kill=subprocess.Popen.kill, mp_kill=multiprocessing.popen_fork.Popen.kill,
             rmtree_fd=shutil._use_fd_functions)
    utf8 = bool(sys.flags.utf8_mode)                  # python -X utf8: UTF-8 is the default on Windows too

    # ---- processes: spawn as on Windows; the standard library's own use of SIGKILL keeps working
    multiprocessing.set_executable(sys.executable)
    try:
        multiprocessing.set_start_method("spawn")
    except RuntimeError:
        pass
    subprocess.Popen.kill = lambda self: self.send_signal(9)
    multiprocessing.popen_fork.Popen.kill = lambda self: self._send_signal(9)

    # ---- what Windows does not have
    for name in GONE_OS:
        if hasattr(os, name):
            delattr(os, name)
    for name in GONE_SIGNAL:
        if hasattr(signal, name):
            delattr(signal, name)

    def libraries_only(name, real):
        def call(*a, **k):
            caller = sys._getframe(1).f_code.co_filename
            if caller.startswith(APP + os.sep) and caller != __file__:
                event("missing", "os.%s is called: Windows does not have it" % name)
                raise AttributeError("module 'os' has no attribute %r (Windows-like run)" % name)
            return real(*a, **k)
        return call
    for name in LIBRARIES_ONLY:
        setattr(os, name, libraries_only(name, getattr(os, name)))

    class NoUnixModules(importlib.abc.MetaPathFinder):
        def find_spec(self, name, path=None, target=None):
            if name in GONE_MODULES:
                raise ModuleNotFoundError("No module named %r" % name, name=name)
            return None
    for name in GONE_MODULES:
        sys.modules.pop(name, None)
    sys.meta_path.insert(0, NoUnixModules())

    # ---- paths that exist only on Linux
    def stat(path, *a, **k):
        if _unix_only(path, "stat"):
            raise _no_such(path)
        return R["stat"](path, *a, **k)

    def lstat(path, *a, **k):
        if _unix_only(path, "stat"):
            raise _no_such(path)
        return R["lstat"](path, *a, **k)

    def listdir(path="."):
        if _unix_only(path, "listing"):
            raise _no_such(path)
        return R["listdir"](path)

    def scandir(path="."):
        if _unix_only(path, "listing"):
            raise _no_such(path)
        return R["scandir"](path)

    def readlink(path, *a, **k):
        if _unix_only(path, "reading the link"):
            raise _no_such(path)
        return R["readlink"](path, *a, **k)

    def access(path, mode, *a, **k):
        if _unix_only(path, "access check"):
            return False
        return R["access"](path, mode, *a, **k)

    def disk_usage(path):
        if _unix_only(path, "disk usage"):
            raise _no_such(path)
        st = R["statvfs"](path)
        return shutil._ntuple_diskusage(st.f_blocks * st.f_frsize, (st.f_blocks - st.f_bfree) * st.f_frsize, st.f_bavail * st.f_frsize)

    # ---- files
    def os_open(path, flags, mode=0o777, **k):
        if _unix_only(path, "open"):
            raise _no_such(path)
        if flags & (os.O_CREAT | os.O_WRONLY | os.O_RDWR) and "dir_fd" not in k:
            _name_rule(path, "open for writing")
        return R["os_open"](path, flags, mode, **k)

    def wl_open(file, mode="r", buffering=-1, encoding=None, errors=None, newline=None, closefd=True, opener=None):
        s = _text(file)
        writes = any(c in mode for c in "wax+")
        if s is not None:
            if _unix_only(s, "open"):
                raise _no_such(s)
            if writes:
                _name_rule(s, "open for writing")
        if "b" in mode:
            return R["open"](file, mode, buffering, encoding, errors, newline, closefd, opener)
        if newline is None and writes and "+" not in mode:
            newline = "\r\n"                           # text mode on Windows: "\n" goes to the disk as "\r\n"
        if encoding not in (None, "locale") or utf8:
            return R["open"](file, mode, buffering, encoding, errors, newline, closefd, opener)
        site = _site()
        if s is not None and not writes:
            try:
                with R["open"](s, "rb") as fh:
                    if not fh.read(4 * 1024 * 1024).isascii():
                        event("encoding", "a file with other than ASCII characters read without encoding= (Windows reads it as cp1252: the characters come out wrong, without an error)", os.path.abspath(s), site=site)
            except OSError:
                pass
        raw = R["open"](file, mode.replace("t", "") + "b", -1 if buffering == 1 else buffering, None, None, None, closefd, opener)
        try:
            fh = _Watch(raw, encoding="cp1252", errors=errors, newline=newline, line_buffering=buffering == 1)
        except Exception:
            raw.close()
            raise
        fh.mode = mode
        fh._wl_path, fh._wl_site = (os.path.abspath(s) if s is not None else "a file descriptor"), site
        return fh

    def remove(path, *a, **k):
        if "dir_fd" not in k:
            _busy(path, "deletion")
        return R["remove"](path, *a, **k)

    def replace(src, dst, *a, **k):
        if not k:
            _name_rule(dst, "rename")
            _busy(src, "renaming")
            if R["access"](dst, os.F_OK):
                _busy(dst, "replacement")
        return R["replace"](src, dst, *a, **k)

    def rename(src, dst, *a, **k):
        if not k:
            _name_rule(dst, "rename")
            _busy(src, "renaming")
            if os.path.isfile(dst):
                event("rename", "os.rename onto a file that exists: Windows refuses it (os.replace does it)", os.path.abspath(_text(dst)))
                raise FileExistsError(17, "Cannot create a file when that file already exists (Windows-like run)", _text(dst))
        return R["rename"](src, dst, *a, **k)

    def mkdir(path, *a, **k):
        if "dir_fd" not in k:
            _name_rule(path, "new folder")
        return R["mkdir"](path, *a, **k)

    def connect(database, *a, **k):
        s = _text(database)
        if s and not k.get("uri") and s != ":memory:" and not s.startswith("file:"):
            if _unix_only(s, "open"):
                raise sqlite3.OperationalError("unable to open database file")
            _name_rule(s, "database file")
        return R["connect"](database, *a, **k)

    builtins.open = io.open = wl_open
    os.open, os.stat, os.lstat, os.listdir, os.scandir, os.readlink, os.access = os_open, stat, lstat, listdir, scandir, readlink, access
    os.remove = os.unlink = remove
    os.replace, os.rename, os.mkdir = replace, rename, mkdir
    sqlite3.connect = sqlite3.dbapi2.connect = connect
    shutil.disk_usage = disk_usage
    shutil._use_fd_functions = False                  # as on Windows: a folder is removed path by path, through os.unlink above

    # ---- a program's output read as text without encoding=: cp1252
    def popen_init(self, *a, **k):
        if (k.get("text") or k.get("universal_newlines")) and not k.get("encoding") and not k.get("errors") and not utf8:
            k["encoding"] = "cp1252"
            self._wl_site = _site()
        return R["popen_init"](self, *a, **k)

    def translate(self, data, encoding, errors):
        if getattr(self, "_wl_site", None) and not data.isascii():
            event("encoding", "a program's output with other than ASCII characters read through text=True without encoding= (Windows reads it as cp1252)", site=self._wl_site)
        return R["translate"](self, data, encoding, errors)
    subprocess.Popen.__init__ = popen_init
    subprocess.Popen._translate_newlines = translate

    # ---- output that is not a console (a service, a log file, a pipe) is cp1252 on Windows
    if not utf8:
        for stream, err in ((sys.stdout, "strict"), (sys.stderr, "backslashreplace")):
            try:
                stream.reconfigure(encoding="cp1252", errors=err)
            except (AttributeError, ValueError):
                pass

    # ---- every Python program started through sys.executable is made Windows-like too
    if os.environ.get("F2T_WL_WRAPPER"):
        sys.executable = os.environ["F2T_WL_WRAPPER"]


def back_to_linux():
    """The real functions again (for the clean-up of the temporary folder)."""
    import shutil
    import sqlite3
    builtins.open = io.open = REAL["open"]
    os.open, os.stat, os.lstat, os.listdir, os.scandir, os.readlink, os.access = (REAL[k] for k in ("os_open", "stat", "lstat", "listdir", "scandir", "readlink", "access"))
    os.remove = os.unlink = REAL["remove"]
    os.replace, os.rename, os.mkdir = REAL["replace"], REAL["rename"], REAL["mkdir"]
    sqlite3.connect = sqlite3.dbapi2.connect = REAL["connect"]
    shutil.disk_usage = REAL["disk_usage"]


WRAPPER = """#!/bin/sh
# stands for sys.executable in a Windows-like run: the Python program that is started is made Windows-like before its first line
flags=""
while [ $# -gt 0 ]; do
  case "$1" in
    -I|-E|-s|-S|-u|-B|-q|-O|-OO|-P) flags="$flags $1"; shift;;
    -X|-W) flags="$flags $1 $2"; shift 2;;
    *) break;;
  esac
done
exec %(python)s $flags %(me)s --boot "$@"
"""


def boot(argv):
    """python [flags] windows_like.py --boot (-c code | -m module | script) [arguments]: the program runs as if started directly."""
    import runpy
    isolated = bool(sys.flags.isolated)
    if not isolated and sys.path and os.path.abspath(sys.path[0] or ".") == HERE:
        sys.path.pop(0)                               # this file's folder; the program's own folder goes there instead
    if not argv:
        raise SystemExit("windows_like --boot: nothing to run")
    if argv[0] == "-c":
        sys.argv = ["-c"] + argv[2:]
        if not isolated:
            sys.path.insert(0, "")
        exec(compile(argv[1], "<string>", "exec"), {"__name__": "__main__", "__builtins__": builtins})
    elif argv[0] == "-m":
        sys.argv = [argv[1]] + argv[2:]
        if not isolated:
            sys.path.insert(0, os.getcwd())
        runpy.run_module(argv[1], run_name="__main__", alter_sys=True)
    else:
        sys.argv = list(argv)
        if not isolated:
            sys.path.insert(0, os.path.dirname(os.path.abspath(argv[0])))
        runpy.run_path(argv[0], run_name="__main__")


if os.environ.get("F2T_WL") == "1":                   # a process started by a Windows-like run (a worker of a pool loads this file again as its main program)
    make_windows_like()


# =============================================================================================== the steps
class StepFailed(Exception):
    pass


def _need(cond, words):
    if not cond:
        raise StepFailed(words)


def step_imports(root, state):
    """Every module of the application loads."""
    import importlib
    import importlib.util
    for p in (os.path.join(APP, "stage2"), os.path.join(APP, "stage1"), os.path.join(APP, "app"), APP):
        if p not in sys.path:
            sys.path.insert(0, p)
    names = ["run_app"]
    names += sorted(f[:-3] for f in os.listdir(os.path.join(APP, "app")) if f.endswith(".py"))
    names += sorted("api." + f[:-3] for f in os.listdir(os.path.join(APP, "app", "api")) if f.endswith(".py") and f != "__init__.py")
    for pkg, folder in (("agentic", "agentic"), ("nvme_hier", "nvme_hier"), ("pcie_isolate", os.path.join("stage1", "pcie_isolate"))):
        names += sorted("%s.%s" % (pkg, f[:-3]) for f in os.listdir(os.path.join(APP, folder)) if f.endswith(".py") and f != "__init__.py")
    names += sorted(f[:-3] for f in os.listdir(os.path.join(APP, "stage2")) if f.endswith(".py") and not f.startswith(("tests_", "bench_")))     # bench_optimizers.py is a program, not a module
    failed = []
    for n in names:
        try:
            importlib.import_module(n)
        except BaseException as e:                    # noqa: BLE001
            failed.append("%s: %s: %s" % (n, type(e).__name__, str(e)[:200]))
    for label, path in (("f2t_nvme", os.path.join(APP, "nvme_hier", "regress", "f2t_nvme.py")), ("preflight", os.path.join(APP, "deploy", "preflight.py"))):
        if not os.path.exists(path):
            continue
        names.append(label)
        try:
            spec = importlib.util.spec_from_file_location("wl_" + label, path)
            spec.loader.exec_module(importlib.util.module_from_spec(spec))
        except BaseException as e:                    # noqa: BLE001
            failed.append("%s: %s: %s" % (os.path.relpath(path, APP), type(e).__name__, str(e)[:200]))
    _need(not failed, "%d of %d modules do not load: %s" % (len(failed), len(names), " | ".join(failed)))
    return "%d modules loaded" % len(names)


def step_generate(root, state):
    """The five example files, written by the application's own generator (two Python programs started through sys.executable)."""
    import subprocess
    tmp = os.path.join(root, "set")
    os.makedirs(tmp)
    gen = os.path.join(APP, "data", "generator", "generate_synthetic_pcie_trace.py")
    exp = os.path.join(APP, "data", "generator", "export_levels.py")
    out = os.path.join(tmp, "t.csv")
    problem = None
    for cmd in ([sys.executable, gen, "--only", "T-42,S-01,C-16,L-21", "--output", out, "--seed", "11", "--data-format", "hex",
                 "--cards", os.path.join(APP, "data", "atlas_cards_raw.json"), "--target-bytes", "0"],
                [sys.executable, exp, "--csv", out, "--out", os.path.join(tmp, "levels")]):
        p = subprocess.run(cmd, capture_output=True, timeout=900)
        if p.returncode != 0:                         # the later steps still get their files: written once more by the same program on the unchanged Python
            problem = problem or "%s stopped: %s" % (os.path.basename(cmd[1]), p.stderr.decode("utf-8", "replace")[-1500:])
            q = subprocess.run([REAL["executable"]] + cmd[1:], capture_output=True, timeout=900, env={k: v for k, v in os.environ.items() if not k.startswith("F2T_WL")})
            _need(q.returncode == 0, "%s stopped on the unchanged Python too: %s" % (os.path.basename(cmd[1]), q.stderr.decode("utf-8", "replace")[-1500:]))
    lv = os.path.join(tmp, "levels")
    state["files"] = {"packets": os.path.join(lv, "packets.csv"), "link": os.path.join(lv, "link.csv"), "split": os.path.join(lv, "split.csv"),
                      "nvme_transaction": os.path.join(lv, "NVME_Transactions.csv"), "nvme_command": os.path.join(lv, "nvme_command.csv")}
    _need(not problem, problem)
    for k, p in state["files"].items():
        _need(os.path.getsize(p) > 0, "the generator wrote no %s file" % k)
    return "five files, %.1f MB" % (sum(os.path.getsize(p) for p in state["files"].values()) / 1048576)


def step_load_in_parts(root, state):
    """The five files are loaded in parts by worker processes (spawn), the priority step of a job and of a worker included."""
    from nvme_hier import loader as L
    _need(state.get("files"), "no files (the step before failed)")
    d = os.path.join(root, "uploads", "up-parts")
    os.makedirs(d)
    db = os.path.join(d, "hier.sqlite")
    L.give_way()
    settings = {"WORKERS": 3, "PARALLEL_MIN_BYTES": 0, "CHUNK_BYTES": 64 * 1024, "MIN_CHUNK_BYTES": 16 * 1024}
    before = {k: getattr(L, k) for k in settings}
    for k, v in settings.items():
        setattr(L, k, v)
    try:
        rep = L.load_upload(db, state["files"])
    finally:
        for k, v in before.items():
            setattr(L, k, v)
    bad = {k: r.get("error") for k, r in rep.items() if r.get("error")}
    _need(not bad, "files not loaded: %s" % bad)
    one_core = {k: r.get("read_on_one_core_because") for k, r in rep.items() if not r.get("parallel")}
    _need(not one_core, "not read in parts: %s" % one_core)
    left = [f for f in os.listdir(d) if f != "hier.sqlite" and not f.startswith("hier.sqlite-")]
    _need(not left, "files left beside the database after the load: %s" % left)
    state["db"] = db
    return "parts per file: %s; memory readings: available %s, machine %s" % ({k: r["parallel"]["chunks"] for k, r in rep.items()}, L.memory_available(), L.total_memory())


def step_tree_and_rules(root, state):
    """The tree build and the rules on the loaded database."""
    import sqlite3
    from nvme_hier import builder as B, rules as RL
    _need(state.get("db"), "no database (the load failed)")
    B.build(state["db"])
    RL.apply(state["db"], {})
    d = os.path.dirname(state["db"])
    left = [f for f in os.listdir(d) if ".work" in f]
    _need(not left, "scratch files left after the build: %s" % left)
    con = sqlite3.connect(state["db"])
    try:
        n = con.execute("SELECT COUNT(*) FROM finding").fetchone()[0]
    finally:
        con.close()
    return "tree built, %d findings" % n


def step_explorer_all_cores(root, state):
    """The Data Explorer's profile of one file by worker processes."""
    from agentic import profile_parallel as PP
    _need(state.get("files"), "no files")
    prof = PP.full_profile_parallel(state["files"]["nvme_transaction"], "nvme_transaction", workers=2, min_bytes=0, chunk_bytes=64 * 1024)
    _need(isinstance(prof, dict) and prof.get("columns"), "no profile came back")
    return "%d columns profiled" % len(prof["columns"])


def step_grounder_over_http(root, state):
    """One Data Grounder pass against a stand-in model server (the Model connection over http, calls at the same time)."""
    if HERE not in sys.path:
        sys.path.insert(0, HERE)
    import test_grounder_batches as G
    model, res, mem, ctx = G._run("all", n=45, pause=0.05)
    cols = mem.get("columns") or []
    _need(len(cols) == 45, "the Grounder returned %d of 45 columns" % len(cols))
    calls = getattr(model, "calls", None)
    return "45 columns, %s calls to the stand-in model" % (calls if isinstance(calls, int) else len(calls or []))


def step_procedure_run(root, state):
    """A procedure's code runs in its own Python process (the runner of agentic/procedures.py)."""
    from agentic import procedures as PR
    box = os.path.join(root, "proc")
    os.makedirs(box)
    src = os.path.join(box, "x.csv")
    with open(src, "w", encoding="utf-8", newline="") as fh:
        fh.write("a,b\n" + "1,2\n" * 5000)
    code = os.path.join(box, "code.py")
    with open(code, "w", encoding="utf-8") as fh:
        fh.write("import csv\n\n\ndef run(sources, out_csv):\n    n = 0\n    with open(sources['x.csv'], newline='', encoding='utf-8') as fh:\n        for row in csv.reader(fh):\n            n += 1\n"
                 "    with open(out_csv, 'w', newline='', encoding='utf-8') as fh:\n        csv.writer(fh).writerows([['n', 'note'], [n, 'caf\\u00e9 \\u2192 done']])\n"
                 "    print('progress \\u2192 done')\n    return {'rows_read': n}\n")
    out = os.path.join(box, "out", "out.csv")
    os.makedirs(os.path.dirname(out))
    res = PR.run_code(code, {"x.csv": src}, out, os.path.join(box, "run"))
    _need(res.get("ok"), "the run failed: %s" % str(res.get("error"))[-900:])
    _need(res["summary"] == {"rows_read": 5001}, "wrong result: %r" % (res,))
    with open(out, "rb") as fh:
        data = fh.read()
    _need(data == "n,note\r\n5001,caf\u00e9 \u2192 done\r\n".encode("utf-8"), "the output CSV is not what the code wrote: %r" % data[:80])
    return "ran, result read back"


def step_test_file(root, state):
    """The regression test library: a test file skips cleanly without a drive and runs on the simulated drive (pytest through sys.executable)."""
    import shutil
    import subprocess
    from nvme_hier import testplan as TP
    d = os.path.join(root, "suite")
    os.makedirs(d)
    shutil.copyfile(TP.LIBRARY, os.path.join(d, "f2t_nvme.py"))
    path = os.path.join(d, "test_windows_like_probe.py")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("import os\nimport sys\n\nimport pytest\n\nsys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))\nimport f2t_nvme as T  # noqa: E402\n\n\n"
                 "def test_gate():\n    if os.environ.get('NVME_BACKEND') == 'sim':\n"
                 "        T.deallocate_check({'id': 'dealloc_probe', 'version': 1, 'deallocate_range': {'slba': 1000, 'blocks': 32, 'guard': 4, 'command': 'dsm'}})\n        return\n"
                 "    try:\n        T.safety_gate({}, False)\n    except T.Skip as e:\n        pytest.skip(str(e))\n")
    cfg = os.path.join(d, "sim.json")
    with open(cfg, "w", encoding="utf-8") as fh:
        json.dump({"lba_bytes": 512, "nsze": 100000, "drb": 1, "thinp": True, "faults": []}, fh)
    said = []
    for name, extra, want in (("without a drive", {}, "1 skipped"), ("simulated drive", {"NVME_BACKEND": "sim", "NVME_SIM": cfg, "NVME_RESULTS": os.path.join(d, "results")}, "1 passed")):
        env = {k: v for k, v in os.environ.items() if not k.startswith("NVME_")}
        env.update(extra, PYTHONDONTWRITEBYTECODE="1")
        p = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", path], capture_output=True, timeout=300, cwd=d, env=env)
        text = (p.stdout + p.stderr).decode("utf-8", "replace")
        _need(p.returncode == 0 and want in text, "%s: wanted '%s', pytest said: %s" % (name, want, text[-1200:]))
        said.append("%s: %s" % (name, want))
    return "; ".join(said)


def step_command_line_agent(root, state):
    """The Claude Code runtime's way of talking to a program: a prompt with other than ASCII characters goes in and comes back unchanged."""
    from agentic import core
    runner = core.AgentRunner(os.path.join(root, "cli_runs"), runtime="http", http_model="company-model-1", web=False)
    prompt = "rule \u2192 \u201cquoted\u201d caf\u00e9 \u2260 x"
    echo = "import sys; sys.stdout.buffer.write(sys.stdin.buffer.read())"
    res = runner._run_cli([sys.executable, "-c", echo], prompt, root, 120, dict(os.environ))
    _need(res.returncode == 0 and res.stdout == prompt, "the text came back changed: %r (exit %s, %s)" % (res.stdout, res.returncode, (res.stderr or "")[-300:]))
    return "prompt and answer unchanged"


def step_files_in_use(root, state):
    """A file is replaced or deleted while a reader still has it open (a page that reads a state file while the load writes its next progress line,
    a virus scanner): Windows refuses until the reader closes it. The application has to wait for the reader, not stop."""
    import threading
    from nvme_hier import loader as L, osfile
    d = os.path.join(root, "in_use")
    os.makedirs(d)

    def held(path, seconds=0.5):
        fh = REAL["open"](path, "rb")
        threading.Timer(seconds, fh.close).start()

    def check(name, fn):
        try:
            fn()
        except PermissionError as e:
            raise StepFailed("%s does not wait for a reader that still has the file open: %s" % (name, e))

    a, b = os.path.join(d, "a.json"), os.path.join(d, "b.json")
    for x in (a, b):
        with open(x, "w", encoding="utf-8") as fh:
            fh.write("{}")
    held(a)
    check("nvme_hier.osfile.replace", lambda: osfile.replace(b, a))
    held(a)
    check("nvme_hier.osfile.remove", lambda: osfile.remove(a))
    _need(not os.path.exists(a), "the file was not deleted")
    meta = os.path.join(d, "meta.json")
    L.write_json_atomic(meta, {"n": 0})
    held(meta)
    check("nvme_hier.loader.write_json_atomic (every state file: an upload's meta.json with the load's progress, the key file, the rules)", lambda: L.write_json_atomic(meta, {"n": 1}))
    with open(meta, encoding="utf-8") as fh:
        _need(json.load(fh) == {"n": 1}, "the state file does not hold what was written last")
    _need(os.listdir(d) == ["meta.json"] or sorted(os.listdir(d)) == ["meta.json"], "files were left behind: %s" % sorted(os.listdir(d)))
    return "replace, delete and the state files of a load wait for the reader"


def step_application(root, state):
    """The web application on a throw-away folder: start page, file picker, Model connection, a load through the upload route, delete."""
    import copy
    from agentic import core, family1
    from api import config_api, hier_api
    from server import create_app
    home = os.path.join(root, "apphome")
    os.makedirs(os.path.join(home, "knowledge"))
    os.makedirs(os.path.join(home, "config"))
    with open(os.path.join(APP, "config", "app_config.json"), encoding="utf-8") as fh:
        cfg = copy.deepcopy(json.load(fh))
    cfg["_path"] = os.path.join(home, "config", "app_config.json")
    with open(cfg["_path"], "w", encoding="utf-8") as fh:
        json.dump({k: v for k, v in cfg.items() if k != "_path"}, fh)
    cfg["llm"].update(base_url="http://127.0.0.1:9", api_key_env="WL_NO_SUCH_KEY", backend="http")
    cfg["agentic"].update(runtime="standin", web=False)
    config_api.save_config = lambda c: None
    hier_api.ENV_FILE = os.path.join(home, "env")     # a test never reaches the real key file
    family1.knowledge_dir = lambda: os.path.join(home, "knowledge")
    core.Engine.kick = lambda self, rid: None
    app = create_app(cfg, home)
    c = app.test_client()
    said = []
    for url in ("/", "/hier", "/api/hier/version", "/api/hier/model", "/api/hier/browse", "/api/hier/browse?path=" + os.path.join(root, "set", "levels"), "/api/config"):
        r = c.get(url)
        _need(r.status_code == 200, "GET %s answered %d: %s" % (url, r.status_code, r.get_data(as_text=True)[:300]))
    said.append("7 pages and routes answer")
    r = c.put("/api/hier/model", json={"model": "company-model-1", "base_url": "http://127.0.0.1:9", "key": "sk-windows-like-0000"})
    _need(r.status_code == 200, "saving the Model connection answered %d: %s" % (r.status_code, r.get_data(as_text=True)[:300]))
    with open(hier_api.ENV_FILE, encoding="utf-8") as fh:
        _need("sk-windows-like-0000" in fh.read(), "the key was not written to the key file")
    said.append("Model connection saved")
    _need(state.get("files"), "no files for the load")
    r = c.post("/api/hier/uploads", json={"files": state["files"], "device": "Windows-like drive", "operator": "admin", "trace_name": "windows-like"})
    _need(r.status_code == 200, "the upload route answered %d: %s" % (r.status_code, r.get_data(as_text=True)[:300]))
    uid = r.get_json()["upload_id"]
    t0 = time.time()
    status = None
    while time.time() - t0 < 900:
        m = c.get("/api/hier/uploads/" + uid).get_json() or {}
        status = (m.get("meta") or m).get("status") if isinstance(m, dict) else None
        if status and status != "loading":
            break
        time.sleep(1)
    _need(status in ("loaded", "ready", "built"), "the load through the application ended as %r, reason %r: %s" % (status, ((m.get("meta") or m).get("error") if isinstance(m, dict) else None), json.dumps(m, default=str)[:600]))
    said.append("load through the upload route: %s in %.0f s" % (status, time.time() - t0))
    answered = 0
    reads = ("/columns?level=packets", "/rows?level=packets&limit=5", "/rows?level=nvme_command&limit=5", "/summary", "/summary.csv", "/thresholds", "/timing_limits",
             "/defect_table", "/findings", "/export.csv?level=nvme_command")
    for tail in reads:                   # what the pages read from a loaded upload: afterwards no file of it may still be open
        r = c.get("/api/hier/uploads/%s%s" % (uid, tail))
        r.get_data()
        r.close()
        _need(r.status_code < 500, "GET %s answered %d" % (tail, r.status_code))
        answered += r.status_code == 200
    said.append("%d of %d reads of the loaded upload answered" % (answered, len(reads)))
    r = c.delete("/api/hier/uploads/" + uid)
    _need(r.status_code == 200, "delete answered %d: %s" % (r.status_code, r.get_data(as_text=True)[:300]))
    left = os.path.join(home, "uploads", uid)
    _need(not os.path.exists(left), "the upload was reported deleted but its folder is still there: %s" % (os.listdir(left) if os.path.isdir(left) else ""))
    said.append("upload deleted")
    return "; ".join(said)


STEPS = [("imports", step_imports), ("generate", step_generate), ("load_in_parts", step_load_in_parts), ("tree_and_rules", step_tree_and_rules),
         ("explorer_all_cores", step_explorer_all_cores), ("grounder_over_http", step_grounder_over_http), ("procedure_run", step_procedure_run),
         ("test_file", step_test_file), ("command_line_agent", step_command_line_agent), ("files_in_use", step_files_in_use), ("application", step_application)]


def _where(tb):
    """The last line of the application in a traceback."""
    import traceback
    hit = ""
    for fr in traceback.extract_tb(tb):
        if fr.filename.startswith(APP + os.sep) and fr.filename != __file__:
            hit = "%s:%d in %s" % (os.path.relpath(fr.filename, APP), fr.lineno, fr.name)
    return hit


def main():
    import argparse
    import shutil
    import tempfile
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True, help="the report (JSON)")
    ap.add_argument("--tmp", default=os.environ.get("F2T_TEST_TMP") or None, help="folder for the temporary folder")
    ap.add_argument("--only", default="", help="steps to run, comma separated (default: all)")
    a = ap.parse_args()
    out = os.path.abspath(a.out)
    root = tempfile.mkdtemp(prefix="wl_", dir=a.tmp)
    os.makedirs(os.path.join(root, "tmp"))
    wrapper = os.path.join(root, "python-windows-like")
    with open(wrapper, "w", encoding="utf-8") as fh:
        fh.write(WRAPPER % {"python": sys.executable, "me": os.path.abspath(__file__)})
    os.chmod(wrapper, 0o755)
    events = os.path.join(root, "events.jsonl")
    os.environ.update(F2T_WL="1", F2T_WL_EVENTS=events, F2T_WL_WRAPPER=wrapper, F2T_WL_ROOT=root, F2T_TEST_TMP=os.path.join(root, "tmp"), TMPDIR=os.path.join(root, "tmp"),
                      F2T_FILE_RETRY="1")         # nvme_hier/osfile.py: wait for a reader as on Windows
    os.environ.setdefault("F2T_WIN_APP", APP)
    tempfile.tempdir = os.path.join(root, "tmp")
    make_windows_like()
    only = {x.strip() for x in a.only.split(",") if x.strip()}
    report = {"app": APP, "python": sys.version.split()[0], "utf8_mode": bool(sys.flags.utf8_mode), "steps": [], "events": [], "finished": False}

    def save():
        with REAL["open"](out + ".tmp", "w", encoding="utf-8") as fh:
            json.dump(report, fh, indent=1)
        REAL["replace"](out + ".tmp", out)
    state = {}
    for name, fn in STEPS:
        if only and name not in only:
            continue
        t0 = time.time()
        rec = {"step": name, "what": (fn.__doc__ or "").strip()}
        try:
            rec.update(ok=True, said=fn(root, state))
        except BaseException as e:                    # noqa: BLE001 - one step that fails must not hide the others
            rec.update(ok=False, error="%s: %s" % (type(e).__name__, str(e)[:3000]), where=_where(e.__traceback__))
            if isinstance(e, KeyboardInterrupt):
                raise
        rec["seconds"] = round(time.time() - t0, 1)
        report["steps"].append(rec)
        save()
    if os.path.exists(events):
        with REAL["open"](events, encoding="utf-8") as fh:
            report["events"] = [json.loads(x) for x in fh if x.strip()]
    report["finished"] = True
    save()
    back_to_linux()
    shutil.rmtree(root, ignore_errors=True)
    bad = [s["step"] for s in report["steps"] if not s["ok"]]
    print("Windows-like run: %d of %d steps passed%s; %d events; report %s" % (len(report["steps"]) - len(bad), len(report["steps"]), (" (failed: %s)" % ", ".join(bad)) if bad else "", len(report["events"]), out))
    return 1 if bad else 0


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--boot":
        boot(sys.argv[2:])
    else:
        sys.exit(main())
