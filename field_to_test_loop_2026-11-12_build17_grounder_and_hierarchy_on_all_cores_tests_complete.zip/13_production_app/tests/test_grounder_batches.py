"""The Data Grounder on a real-size export (owner, 2026-11-11: "Data Grounder has stuck ... meanings of columns 1 to 120 of 361 ... 0%").

A file of 361 columns, each with keywords, against a stand-in model server that takes a second per call. Since 2026-11-12 (owner:
"each and every LLM call must have at least 40 column names, along with the 30 different highest keywords ... for 1 second 5
different requests") the Grounder asks in two kinds of call: a call for the MEANING of the columns that have none (at least 40
columns in one call whenever that many are open, each with its 30 most frequent keywords under "keywords_seen"), and calls for the
meanings of the KEYWORDS (the top 20 of each column, at most 150 meanings in one call; such an entry says "meaning_known"). All
calls are asked at the same time, as many as the runner allows and at most 5 started in one second; every column is finished and
the progress line moves while the model works. No real model is called; the stand-in server answers what it is asked, in the short
form the Grounder asks for (a column by its number, a keyword as a short list) or in the long one (by name, with a "source"
object): both are read.

The calls of that shape themselves (how the columns are cut, what a call holds, both orders of the answers, the 5 starts in a
second) are tested in tests/test_grounder_forty.py.

What is already known without a call (approved dictionaries, the reference document of the exporting tool, earlier runs) is
tested in tests/test_grounder_known.py, which uses the stand-in model and the context of this file.

Its files go to a folder of its own under F2T_TEST_TMP (or the system's temporary folder) and are deleted."""
import json
import os
import shutil
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

N_COLUMNS = 361


def _tmp(prefix):
    """A folder of this test's own: under F2T_TEST_TMP when that is set, else in the system's temporary folder."""
    base = os.environ.get("F2T_TEST_TMP") or None
    if base:
        os.makedirs(base, exist_ok=True)
    return tempfile.mkdtemp(prefix=prefix, dir=base)


class _Model:
    """Answers each Grounder call after a pause, as it was asked: an entry without "meaning_known" gets its meaning (and the
    meanings of the keywords under "keywords", when it has any: "keywords_seen" are only shown, no meaning is written for them);
    an entry with "meaning_known" gets only the meanings of its keywords. Records how many calls ran at once.

    mode: "all" answers everything; "half" answers every second entry of a first try (not of a retry without the web, not of an
    "asked again"); "cut" cuts an answer for more than cut_above entries off; "fail" refuses with HTTP 400 and "402" with HTTP 402.
    only: when given, the mode holds only for the calls whose entries make only(entries) true; the other calls are answered in full.
    pause: seconds, or a function of the call's entries. no_meaning: columns the model never answers (neither their meaning nor
    their keywords); meaning_never: columns whose MEANING the model never gives (their keywords are answered where they are asked
    apart); no_keyword: keywords it never gives a meaning for. asked: one record per call, in the order the calls were answered
    (its entries, whether it carried the web tools, whether it was the retry without the web or an "asked again", whether it was
    refused). summaries: the Data Explorer's calls for the summary of a wide file (answered with a summary; not counted among
    the Grounder's entries).

    Two counts of what was answered: cols_seen is the number of DIFFERENT column names (a column that is asked once for its
    meaning and once for its keywords is one column; the entry of words that many columns hold is not a column), entries_seen
    the number of entries over all calls (so a column that was asked twice for the same thing shows there)."""

    def __init__(self, pause=1.0, mode="all", shape="short", only=None, no_meaning=(), no_keyword=(), cut_above=2, meaning_never=()):
        self.calls, self.now, self.most, self.retries, self.retry_tools, self.contents_seen, self.entries_seen = 0, 0, 0, 0, 0, 0, 0
        self.cut, self.sizes, self.prompts, self.asked, self.summaries, self.names = 0, [], [], [], [], set()
        self.arrived = []               # when each call reached this server
        lock = threading.Lock()
        me = self

        class H(BaseHTTPRequestHandler):
            def send(self, code, data):
                self.send_response(code)
                self.send_header("content-type", "application/json")
                self.send_header("content-length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def text(self, body, text, stop="end_turn"):
                self.send(200, json.dumps({"id": "m", "type": "message", "role": "assistant", "model": body.get("model"),
                                           "content": [{"type": "text", "text": text}], "stop_reason": stop,
                                           "usage": {"input_tokens": 1, "output_tokens": 1}}).encode())

            def do_POST(self):
                n = int(self.headers.get("content-length") or 0)
                body = json.loads(self.rfile.read(n) or b"{}")
                with lock:
                    me.arrived.append(time.time())
                    me.calls += 1
                    me.now += 1
                    me.most = max(me.most, me.now)
                try:
                    prompt = body["messages"][0]["content"]
                    try:
                        context = json.loads(prompt.split("CONTEXT:\n", 1)[1])
                    except (IndexError, ValueError):
                        context = {}
                    cols = context.get("columns") if isinstance(context, dict) and isinstance(context.get("columns"), list) else []
                    time.sleep(pause(cols) if callable(pause) else pause)
                    retry, again = "THE WEB COULD NOT BE USED" in prompt, "ASKED AGAIN:" in prompt
                    summary = isinstance(context, dict) and "column_names" in context
                    on = mode if only is None or only(cols) else "all"
                    with lock:
                        me.retries += retry
                        me.retry_tools += bool(retry and body.get("tools"))
                        me.contents_seen += '"most_common"' in prompt
                        me.asked.append({"columns": cols, "tools": bool(body.get("tools")), "retry": retry, "again": again,
                                         "refused": on in ("fail", "402"), "summary": summary})
                    if on in ("fail", "402"):               # the address refuses the call (400, or 402: no credit on the account)
                        self.send(402 if on == "402" else 400, b'{"type": "error", "error": {"type": "invalid_request_error", "message": "refused"}}')
                        return
                    if summary:                             # the Data Explorer asks only for the summary of a file with very many columns
                        with lock:
                            me.summaries.append(context)
                        self.text(body, json.dumps({"summary": "A file of %d named columns that hold a value." % len(context["column_names"])}))
                        return
                    with lock:
                        me.entries_seen += len(cols)
                        me.names.update(c["column"] for c in cols if isinstance(c, dict) and c.get("column") and "held_by" not in c)
                        me.sizes.append(len(cols))
                        me.prompts.append(prompt)
                    stop = "end_turn"
                    if on == "cut" and len(cols) > cut_above:    # an answer for more than cut_above entries is longer than one call may write
                        stop = "max_tokens"
                        with lock:
                            me.cut += 1
                    if on == "half" and not retry and not again:    # the first try answers only every second column
                        cols = cols[::2]
                    cols = [c for c in cols if c["column"] not in no_meaning and ("meaning_known" in c or c["column"] not in meaning_never)]
                    model_source = {"kind": "model", "ref": "model knowledge", "quote": ""}
                    rows = []
                    for c in cols:
                        words = [k for k in c.get("keywords") or [] if k not in no_keyword]     # never the "keywords_seen": they are only shown
                        if shape == "long":                 # by name, each meaning with a "source" object
                            row = {"column": c["column"], "keywords": [{"keyword": k, "meaning": "the value %s" % k, "source": dict(model_source)} for k in words]}
                            if "meaning_known" not in c:
                                row.update(meaning="what %s holds" % c["column"], source=dict(model_source))
                        else:                               # the form asked for: a column by its number, a keyword as a short list
                            row = {"n": c["n"], "keywords": [[k, "the value %s" % k, "model"] for k in words]}
                            if "meaning_known" not in c:
                                row.update(meaning="what %s holds" % c["column"], kind="model")
                        rows.append(row)
                    ans = {"columns": rows}
                    self.text(body, json.dumps(ans)[:40] if stop == "max_tokens" else json.dumps(ans), stop)
                finally:
                    with lock:
                        me.now -= 1

            def log_message(self, *a):
                pass

        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = "http://127.0.0.1:%d" % self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    @property
    def cols_seen(self):
        return len(self.names)


def _for_meaning(model):
    """The entries that asked for a column's meaning, over all the calls that were answered or refused."""
    return [c for a in model.asked for c in a["columns"] if "meaning_known" not in c]


def _for_keywords(model):
    """The entries that asked only for keywords (the column's meaning is known, or asked in another call at the same time)."""
    return [c for a in model.asked for c in a["columns"] if "meaning_known" in c]


class _Ctx:
    def __init__(self, runner, mem_file, run_id=1):
        self.engine = type("E", (), {"runner": runner})()
        self.project = {"refs": "[]"}
        self.run = {"id": run_id}
        self.notes, self._mem, self.evidence_calls = [], mem_file, []

    def output_of(self, key):
        return {"memory_file": self._mem}

    def progress(self, text):
        self.notes.append((time.time(), text))

    def evidence(self, claims):
        self.evidence_calls.append(list(claims or []))


def test_the_grounder_finishes_a_361_column_export_in_calls_at_once_and_its_progress_moves():
    from agentic import core, family1
    root = _tmp("grounder_%d_" % os.getpid())
    was = {k: os.environ.get(k) for k in ("ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", "ANTHROPIC_AUTH_TOKEN")}
    was_kd = family1.knowledge_dir
    family1.knowledge_dir = lambda: os.path.join(root, "knowledge")          # its own knowledge folder: never the application's
    model = _Model(pause=1.0)
    try:
        os.environ.update(ANTHROPIC_API_KEY="sk-test-grounder-0000", ANTHROPIC_BASE_URL=model.url)
        os.environ.pop("ANTHROPIC_AUTH_TOKEN", None)
        cols = [{"column": "Field %03d" % i, "header_cell": "Field %03d" % i, "type": "text", "rows_with_value": 50,
                 "keywords": [{"value": "K%d_%d" % (i, j), "count": 5} for j in range(25)]} for i in range(N_COLUMNS)]
        mem = os.path.join(root, "explorer.json")
        json.dump({"columns": cols}, open(mem, "w"))
        runner = core.AgentRunner(os.path.join(root, "runs"), runtime="http", http_model="company-model-1", web=False)
        ctx = _Ctx(runner, mem)
        t0 = time.time()
        # no level, no format key and names that no tool's column list holds: nothing is known beforehand and nothing is kept,
        # so every column is asked, without the web (the runner may not use it)
        res = family1._ground(ctx, {"name": "packets.csv", "level_label": "packets"})
        took = time.time() - t0
        out = json.load(open(res.output["memory_file"]))
        at_once = runner.slots.ceiling                                               # automatic: from this computer's processor cores
        # the meanings of the 361 columns: 9 calls of 40 or 41 columns (never fewer than 40 in a call). The meanings of their
        # keywords: 20 per column, 7 columns fit in the 150 meanings of one call -> 52 calls. (Before 2026-11-12 the same file was
        # 52 calls, each with 7 columns and their keywords together.)
        col_calls = N_COLUMNS // family1.GROUND_BATCH
        kw_per_call = family1.GROUND_MEANINGS // family1.GROUND_KEYWORDS
        kw_calls = -(-N_COLUMNS // kw_per_call)
        parts = col_calls + kw_calls
        assert (col_calls, kw_per_call, kw_calls, parts) == (9, 7, 52, 61)
        assert model.calls == parts
        mixed = [a for a in model.asked if len({"meaning_known" in c for c in a["columns"]}) != 1]
        assert not mixed                                                              # no call asks for both kinds
        wanted = [a["columns"] for a in model.asked if "meaning_known" not in a["columns"][0]]
        assert sorted(len(a) for a in wanted) == [40] * 8 + [41]
        for c in (c for a in wanted for c in a):          # a column whose meaning is asked comes with its most frequent keywords (here all 25), no meaning asked for them
            i = int(c["column"][-3:])
            assert c["keywords_seen"] == ["K%d_%d" % (i, j) for j in range(25)] and "keywords" not in c, c
        words = [a["columns"] for a in model.asked if "meaning_known" in a["columns"][0]]
        assert len(words) == kw_calls and max(len(a) for a in words) == kw_per_call
        for c in (c for a in words for c in a):
            i = int(c["column"][-3:])
            assert c["meaning_known"] == family1.KEYWORDS_APART and c["keywords"] == ["K%d_%d" % (i, j) for j in range(family1.GROUND_KEYWORDS)], c
        # every column once for its meaning and once for its keywords: nothing was asked twice
        assert model.cols_seen == N_COLUMNS and model.entries_seen == 2 * N_COLUMNS
        assert 1 < model.most <= at_once                                              # several at once, never more than the limit
        t = res.output["timing"]
        assert at_once >= 4 and t["calls_at_once_allowed"] == at_once and 1 < t["calls_at_once_most"] <= at_once
        assert (t["parts"], t["model_calls"], t["calls_for_column_meanings"], t["columns_per_such_call_at_least"], t["columns_per_such_call_most"]) == (parts, parts, 9, 40, 41)
        assert (t["frequent_keywords_given_per_column_at_most"], t["calls_started_per_second_at_most"], runner.slots.per_second) == (30, 5, 5)
        assert len(out["columns"]) == N_COLUMNS and all(m["meaning"] for m in out["columns"].values())
        assert all(len(m["keywords"]) == family1.GROUND_KEYWORDS for m in out["columns"].values())   # at most 20 keywords asked per column
        assert took < parts * 1.0 / 2                                                 # at least twice as fast as one call after the other
        # ... and not faster than the 5 starts in one second allow: the 61st call starts 12 s after the first at the earliest.
        # At the model itself: any six calls in a row arrived over a second or more (0.1 s is allowed for the way to the server)
        arrived = sorted(model.arrived)
        assert took >= (parts - 1) // 5 and len(arrived) == parts
        assert min(arrived[i + 5] - arrived[i] for i in range(parts - 5)) >= 0.9, min(arrived[i + 5] - arrived[i] for i in range(parts - 5))
        assert "model calls in %d parts" % parts in res.output["how_long"] and "at the same time" in res.output["how_long"]
        texts = [t for _w, t in ctx.notes]
        assert texts[0].startswith("0% · Data Grounder") and texts[-1].startswith("100% · Data Grounder")
        assert len({t.split(" · ")[0] for t in texts}) >= 3                           # the percentage moved on the way
        assert "%d of %d columns done" % (N_COLUMNS, N_COLUMNS) in texts[-1]
        assert not os.path.exists(os.path.join(root, "knowledge", "column_meanings", "unknown_source.json"))     # no format key: nothing is remembered
    finally:
        family1.knowledge_dir = was_kd
        model.srv.shutdown()
        for k, v in was.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        shutil.rmtree(root, ignore_errors=True)


def _cols(n):
    return [{"column": "Field %03d" % i, "header_cell": "Field %03d" % i, "type": "text", "rows_with_value": 50, "observed": "holds a code",
             "top_values": [{"value": "V%d_%d" % (i, j), "count": 10 - j} for j in range(6)], "min": "V%d_0" % i, "max": "V%d_5" % i,
             "keywords": [{"value": "K%d_%d" % (i, j), "count": 5} for j in range(5)]} for i in range(n)]


def _run(mode, n=45, pause=0.2, dictionary=None, expect_error=False, shape="short", cols=None, mem_more=None, **model_args):
    from agentic import core, family1
    root = _tmp("grounder_%s_%d_" % (mode, os.getpid()))
    was = {k: os.environ.get(k) for k in ("ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", "ANTHROPIC_AUTH_TOKEN")}
    was_kd = family1.knowledge_dir
    family1.knowledge_dir = lambda: os.path.join(root, "knowledge")          # its own knowledge folder: approved dictionaries of this test only
    if dictionary:
        d = os.path.join(root, "knowledge", "dictionaries", "fmt1")
        os.makedirs(d)
        json.dump(dictionary, open(os.path.join(d, "packets.current.json"), "w"))
    model = _Model(pause=pause, mode=mode, shape=shape, **model_args)
    try:
        os.environ.update(ANTHROPIC_API_KEY="sk-test-grounder-0000", ANTHROPIC_BASE_URL=model.url)
        os.environ.pop("ANTHROPIC_AUTH_TOKEN", None)
        mem = os.path.join(root, "explorer.json")
        json.dump(dict({"columns": cols or _cols(n)}, **(mem_more or {})), open(mem, "w"))
        runner = core.AgentRunner(os.path.join(root, "runs"), runtime="http", http_model="company-model-1", web=True)
        ctx = _Ctx(runner, mem)
        if expect_error:
            t0 = time.time()
            try:
                family1._ground(ctx, {"name": "packets.csv", "level": "packets", "level_label": "packets"})
            except RuntimeError as e:
                return model, str(e), time.time() - t0, ctx
            raise AssertionError("the step did not stop")
        res = family1._ground(ctx, {"name": "packets.csv", "level": "packets", "level_label": "packets"})
        return model, res, json.load(open(res.output["memory_file"])), ctx
    finally:
        family1.knowledge_dir = was_kd
        model.srv.shutdown()
        for k, v in was.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        shutil.rmtree(root, ignore_errors=True)


def test_columns_left_without_a_meaning_are_asked_again_without_the_web_from_their_name_and_contents():
    """Owner, 2026-11-11: "add a retry if the Data Grounder fails, and if the web cannot give it, use the column names and contents"."""
    model, res, out, ctx = _run("half")
    assert model.contents_seen >= 1                                       # the contents went with the columns
    assert model.retries >= 1 and model.retry_tools == 0                  # retried, and the retry did not use the web
    assert len(out["columns"]) == 45 and all(m["meaning"] and not m["meaning"].startswith("Described from") for m in out["columns"].values())
    assert "retry without the web" in res.producer
    assert any("retried without the web" in t for _w, t in ctx.notes)


def test_when_the_model_gives_nothing_no_meaning_is_written_by_code():
    """Owner, 2026-11-11: "it should not be written": after the three tries, a column without a source keeps no meaning (the admin
    fills it in the review); nothing is made up by code."""
    from agentic import family1
    model, res, out, ctx = _run("fail", n=12)
    assert model.retries >= 2                                             # retried without the web, then in halves
    assert len(out["columns"]) == 0                                       # no meaning was written for any column
    assert family1._status(None) == "no meaning found"
    assert "12 columns without a meaning after 3 tries" in res.producer
    assert res.output["meanings"] == {}


def test_a_meaning_from_the_web_keeps_its_page_and_words():
    """Owner, 2026-11-11: "if it is taken from the web, mention that it is from the web and store the meaning ... save from which
    place it came": the stored meaning keeps kind web, the page and the quoted words, and says so in words."""
    from agentic import family1
    m = {"meaning": "the transaction's sequence number", "checked": True,
         "source": {"kind": "web", "ref": "https://example.org/pcie/dllp", "quote": "a 12-bit sequence number"}}
    assert family1._status(m) == "from a web page (checked)"
    m["checked"] = False
    assert family1._status(m) == "web quote not found on the page: not trusted"


def test_columns_already_in_an_approved_dictionary_are_taken_from_it_and_only_the_others_are_asked():
    """Owner, 2026-11-11: "if it already has the column names, just use the description of the column, else go for finding"."""
    from agentic import family1
    known = {"level": "packets", "file": "packets.csv", "approved_by": "Sagar", "approved_at": 1794390000,
             "columns": [{"column": "Field %03d" % i, "meaning": "approved meaning %d" % i, "source": {"kind": "document", "ref": "manual.pdf:12", "quote": "q"},
                          "keywords": [{"value": "K%d_0" % i, "meaning": "approved keyword", "source": {"kind": "model", "ref": "model knowledge", "quote": ""}}]}
                         for i in range(5)] + [{"column": "Field 011", "meaning": "", "source": {}}]}       # an empty meaning is not reused
    model, res, out, ctx = _run("all", n=12, dictionary=known)
    # the 7 columns without an approved meaning are asked for their meaning (one call, each with its keywords under "keywords_seen")
    # and, in another call, for their keywords; the 5 approved ones are asked only for the 4 keywords each that the approved
    # dictionary has no meaning for (owner, 2026-11-12: the top keywords of every column), with the approved meaning as "meaning_known"
    assert model.cols_seen == 12 and model.entries_seen == 7 + 7 + 5          # 12 different columns, none asked twice for the same thing
    wanted, words = _for_meaning(model), _for_keywords(model)
    assert sorted(c["column"] for c in wanted) == ["Field %03d" % i for i in range(5, 12)]
    assert all("keywords" not in c and c["keywords_seen"] == ["K%d_%d" % (int(c["column"][-3:]), j) for j in range(5)] for c in wanted)
    approved = {c["column"]: c for c in words if c["meaning_known"] != family1.KEYWORDS_APART}
    assert sorted(approved) == ["Field %03d" % i for i in range(5)]
    assert approved["Field 000"]["meaning_known"] == "approved meaning 0" and approved["Field 000"]["keywords"] == ["K0_%d" % j for j in range(1, 5)]
    apart = [c for c in words if c["meaning_known"] == family1.KEYWORDS_APART]
    assert sorted(c["column"] for c in apart) == ["Field %03d" % i for i in range(5, 12)] and len(approved) + len(apart) == len(words)
    assert all(c["keywords"] == ["K%d_%d" % (int(c["column"][-3:]), j) for j in range(5)] for c in apart)
    assert not any(len({"meaning_known" in c for c in a["columns"]}) != 1 for a in model.asked)             # no call asks for both kinds
    assert not any(a["tools"] for a in model.asked if "meaning_known" in a["columns"][0])                   # keywords: without the web
    assert all(a["tools"] for a in model.asked if "meaning_known" not in a["columns"][0])                   # the web only where a column's meaning is looked for
    assert len(out["columns"]) == 12 and all(m["meaning"] and len(m["keywords"]) == 5 for m in out["columns"].values())
    first = out["columns"]["Field 000"]
    assert first["meaning"] == "approved meaning 0" and first["source"]["ref"] == "manual.pdf:12" and first["keywords"]["K0_0"]["meaning"] == "approved keyword"
    assert len(first["keywords"]) == 5 and first["keywords"]["K0_1"]["meaning"] == "the value K0_1"         # the approved meaning stays, the new keywords are added
    assert family1._status(first).startswith("from the approved dictionary of packets.csv (approved by Sagar, ")
    assert "5 meanings reused from the approved dictionary" in res.producer
    assert any("5 taken from the approved dictionary" in t for _w, t in ctx.notes)


def test_a_refused_connection_stops_the_step_at_once_with_the_reason():
    """No credit (HTTP 402): the Grounder stops asking at once (no retries for every part) and the step fails with the reason in words."""
    model, err, took, ctx = _run("402", n=45, expect_error=True)
    assert "no credit" in err and "Settings -> Model connection" in err
    assert model.retries == 0 and model.calls <= 9                         # the first try of each of the 9 parts at most: no retries after a refusal
    assert took < 20
    assert any("last problem: part" in t and "no credit" in t for _w, t in ctx.notes)


def test_the_status_says_which_part_waits_how_long_and_why():
    from agentic import family1
    was = family1.GROUND_SLOW_AFTER
    family1.GROUND_SLOW_AFTER = 0.5
    try:
        model, res, out, ctx = _run("all", n=20, pause=12.5)               # four parts asked together, and the model takes 12.5 s
    finally:
        family1.GROUND_SLOW_AFTER = was
    texts = [t for _w, t in ctx.notes]
    slow = [t for t in texts if "has waited" in t]
    assert slow and "part 1 has waited" in slow[0] and "first try" in slow[0] and "a call gives up after" in slow[0], texts
    assert all(" · Data Grounder · packets.csv: " in t for t in texts)


def test_an_answer_in_the_long_form_by_column_name_is_read_too():
    """A model (or a gateway's model) that answers by name with "source" objects, as before the short form, is understood as well."""
    model, res, out, ctx = _run("all", n=12, shape="long")
    assert len(out["columns"]) == 12 and all(m["meaning"] and len(m["keywords"]) == 5 for m in out["columns"].values())
    assert out["columns"]["Field 003"]["keywords"]["K3_2"]["meaning"] == "the value K3_2"


def test_the_short_form_is_read_and_what_the_code_knows_is_filled_in_by_the_code():
    from agentic import family1
    batch = [{"column": "Mem.Address", "keywords": ["MWr(64)", "MRd(32)"]}, {"column": "OPC", "keywords": ["Read", "Write"]}, {"column": "PSN", "keywords": []}]
    ans = {"columns": [
        {"n": 2, "meaning": "the command's opcode", "kind": "data", "quote": "Read",
         "keywords": [["read", "a Read command", "data"], ["Write", "a Write command", "web", "https://nvmexpress.org/x", "Write command"],
                      ["Flush", "not one of this column's keywords", "model"], ["Write", "a second answer for the same keyword", "model"]]},
        {"n": 1, "meaning": "the address of the memory request", "kind": "document", "ref": "spec.md:12", "quote": "Address"},
        {"n": 2, "meaning": "a second answer for the same column", "kind": "model"},
        {"n": 3, "meaning": "", "kind": "model"},                                   # an empty meaning is no meaning
        {"n": 9, "meaning": "a column that was not asked", "kind": "model"},
        {"column": " psn ", "meaning": "the packet's sequence number", "kind": "something else"},      # by name, without regard to capitals and spaces
        "not an object"]}
    got = family1._read_answers(ans, batch)
    assert set(got) == {"Mem.Address", "OPC", "PSN"}
    assert got["OPC"]["meaning"] == "the command's opcode" and got["OPC"]["source"] == {"kind": "data", "ref": "OPC", "quote": "Read"}
    kws = {k["keyword"]: k for k in got["OPC"]["keywords"]}
    assert set(kws) == {"Read", "Write"}                                            # the keyword as the file writes it; unknown ones dropped
    assert kws["Read"]["source"] == {"kind": "data", "ref": "OPC", "quote": "Read"}  # data: the column itself, the keyword is its own value
    assert kws["Write"]["meaning"] == "a Write command" and kws["Write"]["source"] == {"kind": "web", "ref": "https://nvmexpress.org/x", "quote": "Write command"}
    assert got["Mem.Address"]["source"] == {"kind": "document", "ref": "spec.md:12", "quote": "Address"}
    assert got["PSN"]["source"] == {"kind": "model", "ref": "model knowledge", "quote": ""}     # an unknown kind is model knowledge
    assert family1._read_answers({"columns": "no list"}, batch) == {} and family1._read_answers("no object", batch) == {}


def test_the_parts_follow_the_calls_at_once_and_never_hold_more_than_150_meanings():
    from agentic import family1
    def items(n, k, group=""):
        return [{"column": "c%d" % i, "keywords": ["k"] * k, "group": group} for i in range(n)]
    # a small file: one round of calls finishes it (as many parts as calls at once), but a part is not made smaller than 30 meanings
    parts, per = family1.ground_parts(items(40, 5), 4)             # 240 meanings, 4 calls at once -> 60 each
    assert per == 60 and [len(p) for p in parts] == [10, 10, 10, 10]
    parts, per = family1.ground_parts(items(40, 5), 16)            # 16 calls at once -> 15 each would be too small: 30
    assert per == 30 and [len(p) for p in parts] == [5] * 8
    # a big file: never more than 150 meanings in one answer, never more than GROUND_BATCH (40) entries in one call when no other number is given
    parts, per = family1.ground_parts(items(361, 15), 16)          # a column with 15 keywords is 16 meanings: 9 fit in 150
    assert per == 150 and max(len(p) for p in parts) == 9 and sum(len(p) for p in parts) == 361
    parts, per = family1.ground_parts(items(100, 0), 1)
    assert max(len(p) for p in parts) == family1.GROUND_BATCH and sum(len(p) for p in parts) == 100
    # one column with more keywords than a part holds is still asked, alone
    parts, per = family1.ground_parts(items(1, 15) + items(2, 15), 16)
    assert [len(p) for p in parts] == [1, 1, 1] or [len(p) for p in parts] == [1, 2]
    # columns that the same kinds of row fill stay together: a new part where the kind changes, once the part is half full
    mixed = items(6, 4, "Read, Write") + items(6, 4, "Identify")
    parts, per = family1.ground_parts(mixed, 2)                    # 60 meanings, 2 calls at once -> 30 each
    assert [[it["group"] for it in p] for p in parts] == [["Read, Write"] * 6, ["Identify"] * 6]
    assert family1.ground_parts([], 8) == ([], 30)


def test_an_answer_that_was_cut_off_is_asked_again_in_two_halves_and_not_the_same_way():
    """Before: an answer longer than one call may write came back as "not JSON" and the same question was asked again."""
    from collections import Counter
    # the model may write an answer for 4 entries at most. The call for the meanings of the 8 columns is cut off, and so is the
    # call for the keywords of 6 of them (8 columns of 5 keywords are asked in calls of 6 and 2: 30 meanings in a call at least)
    model, res, out, ctx = _run("cut", n=8, cut_above=4)
    assert model.cut == 2                                                  # both first answers were too long
    kinds = ["keywords" if "meaning_known" in a["columns"][0] else "meaning" for a in model.asked]
    assert [len(a["columns"]) for a, k in zip(model.asked, kinds) if k == "meaning"] == [8, 4, 4]           # the call, then its two halves
    assert sorted(len(a["columns"]) for a, k in zip(model.asked, kinds) if k == "keywords") == [2, 3, 3, 6]
    # not the same question again: no retry and no "asked again", and an entry of a call that was cut off was asked exactly once more
    assert model.calls == 7 and not any(a["retry"] or a["again"] for a in model.asked)
    times = Counter((k, c["column"]) for a, k in zip(model.asked, kinds) for c in a["columns"])
    assert all(times[("meaning", "Field %03d" % i)] == 2 for i in range(8))
    assert [times[("keywords", "Field %03d" % i)] for i in range(8)] == [2] * 6 + [1] * 2
    assert len(out["columns"]) == 8 and all(m["meaning"] and len(m["keywords"]) == 5 for m in out["columns"].values())
    assert "asked in two halves: the first answer was cut off" in res.producer
    assert any("last problem: part" in t and "longer than one call may write" in t for _w, t in ctx.notes)


def test_which_rows_fill_a_column_goes_to_the_model_and_the_columns_of_one_kind_are_asked_together():
    """Owner, 2026-11-11: "a Read command fills only the columns it needs ... that special status is also needed when extracting"."""
    cols = _cols(12)
    for i, c in enumerate(cols):
        if i % 2:           # every second column is a field of Read and Write commands only
            c["filled_for"] = {"text": "filled only on rows where OPC is Read (360 of 360 rows), Write (179 of 179 rows); never on the other 69 rows", "rows": "OPC: Read, Write"}
        elif i % 4 == 0:
            c["filled_for"] = {"text": "filled only on rows where OPC is Identify (15 of 15 rows); never on the other 593 rows", "rows": "OPC: Identify"}
    model, res, out, ctx = _run("all", cols=cols, mem_more={"kind_of_row": {"text": "The kind of each row is named by OPC: Read (360 rows), Write (179 rows)."}})
    assert len(out["columns"]) == 12
    asked = [json.loads(p.split("CONTEXT:\n", 1)[1]) for p in model.prompts]
    assert all(a["kind_of_row"].startswith("The kind of each row is named by OPC") for a in asked)
    seen = {c["column"]: c for a in asked for c in a["columns"]}
    assert seen["Field 001"]["filled_on"].startswith("filled only on rows where OPC is Read (360 of 360 rows)")
    assert "filled_on" not in seen["Field 002"] and "group" not in seen["Field 001"]      # nothing empty is sent, and no key of the program's own
    assert all(c["n"] == i + 1 for a in asked for i, c in enumerate(a["columns"]))        # numbered from 1 inside each call
    kinds = [[("Read" if "Read" in c.get("filled_on", "") else "Identify" if "Identify" in c.get("filled_on", "") else "") for c in a["columns"]] for a in asked]
    # the call for the columns' meanings holds all 12 (fewer than 80 open columns are one call), the columns of one kind next to
    # each other in the order the kinds first appear in the file: Identify (Field 000), Read and Write (Field 001), the others
    meaning_calls = [k for a, k in zip(asked, kinds) if "meaning_known" not in a["columns"][0]]
    assert meaning_calls == [["Identify"] * 3 + ["Read"] * 6 + [""] * 3], meaning_calls
    # ... and their keywords are asked kind by kind: a whole call of the columns that Read and Write fill
    keyword_calls = [k for a, k in zip(asked, kinds) if "meaning_known" in a["columns"][0]]
    assert sorted(keyword_calls) == sorted([["Identify"] * 3, ["Read"] * 6, [""] * 3]), keyword_calls
