"""The application on a Windows-like Python (production runs on Windows, the code is written on Linux).

tests/windows_like.py is started once as a program of its own: it takes away what Windows does not have (os.nice, os.getuid,
SIGKILL, the modules fcntl and resource, /proc and /dev/shm ...), reads and writes text files without encoding= as cp1252,
refuses to delete or replace a file that is still open, and then loads every module, loads five files in parts with worker
processes, builds the tree, runs the rules, the Data Explorer on several cores, one Data Grounder pass over http, a procedure
in its own process, a test file with pytest, a replace and a delete while a reader holds the file, and the web application's start
page, file picker, Model connection, load, reads and delete.

    F2T_TEST_TMP=<folder> python3 -m pytest -q -p no:cacheprovider tests/test_windows_like.py

No server, no model, no network; about two to four minutes. What only a real Windows machine can show is listed in
docs/CHANGES_2026-11-12.md ("Windows").  F2T_WIN_APP=<folder> runs the same on a copy of the code.
"""
import json
import os
import subprocess
import sys
import tempfile

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
STEPS = ["imports", "generate", "load_in_parts", "tree_and_rules", "explorer_all_cores", "grounder_over_http", "procedure_run", "test_file",
         "command_line_agent", "files_in_use", "application"]
INSTALL_FOLDER = 60          # characters of a usual install folder on Windows, e.g. C:\Users\<name>\Desktop\13_production_app
WINDOWS_PATH_LIMIT = 260


@pytest.fixture(scope="module")
def report():
    base = os.environ.get("F2T_TEST_TMP") or None
    if base:
        os.makedirs(base, exist_ok=True)
    work = tempfile.mkdtemp(prefix="windows_like_", dir=base)
    out = os.path.join(work, "report.json")
    env = {k: v for k, v in os.environ.items() if not k.startswith("F2T_WL")}
    env.update(F2T_TEST_TMP=work, TMPDIR=work, PYTHONDONTWRITEBYTECODE="1")
    env.pop("PYTHONUTF8", None)
    p = subprocess.run([sys.executable, os.path.join(HERE, "windows_like.py"), "--out", out, "--tmp", work], capture_output=True, timeout=3000, env=env,
                       cwd=os.environ.get("F2T_WIN_APP") or APP)
    try:
        assert os.path.exists(out), "the Windows-like run wrote no report: %s" % (p.stdout + p.stderr).decode("utf-8", "replace")[-3000:]
        with open(out, encoding="utf-8") as fh:
            rep = json.load(fh)
        rep["output"] = (p.stdout + p.stderr).decode("utf-8", "replace")[-3000:]
        keep = os.environ.get("F2T_WIN_REPORT")
        if keep:
            with open(keep, "w", encoding="utf-8") as fh:
                json.dump(rep, fh, indent=1)
        yield rep
    finally:
        import shutil
        shutil.rmtree(work, ignore_errors=True)


def test_the_run_went_through_every_step(report):
    assert report["finished"], report["output"]
    assert [s["step"] for s in report["steps"]] == STEPS, [s["step"] for s in report["steps"]]


@pytest.mark.parametrize("name", STEPS)
def test_step(report, name):
    step = next((s for s in report["steps"] if s["step"] == name), None)
    assert step is not None, "the step did not run: %s" % report["output"]
    assert step["ok"], "%s (%s)\nat %s\n%s" % (step["what"], name, step.get("where") or "?", step.get("error"))


def _events(report, kind):
    """Events of the application's own lines; what a test helper did is not the application's fault."""
    return sorted({"%s  %s  [%s]" % (e["site"], e["what"], os.path.basename(e.get("path") or "")) for e in report["events"]
                   if e["kind"] == kind and not e["site"].startswith(("tests" + os.sep, "outside the application"))})


def test_no_text_file_depends_on_the_windows_code_page(report):
    """A file opened without encoding= is cp1252 on Windows: text that is not plain ASCII is stored or read wrongly, without an error."""
    found = _events(report, "encoding")
    assert not found, "\n".join(found)


def test_no_file_is_deleted_or_replaced_while_it_is_open(report):
    """Windows refuses both. Also counted when the code caught the error and went on (a half-deleted folder, a scratch file left behind)."""
    found = _events(report, "open-file") + _events(report, "rename")
    assert not found, "\n".join(found)


def test_no_file_name_that_windows_cannot_make(report):
    found = _events(report, "file-name")
    assert not found, "\n".join(found)


def test_paths_stay_under_the_windows_limit(report):
    longest = max([int(e["what"].split()[0]) for e in report["events"] if e["kind"] == "path-length"] or [0])
    assert INSTALL_FOLDER + longest < WINDOWS_PATH_LIMIT, "a path %d characters below the application's folder: with the folder name it passes 260 characters" % longest
