"""The Data Grounder's calls as the owner asked for them on 2026-11-12: "each and every LLM call must have like at least 40 ...
column names, along with the 30 different highest keywords that is present within the column", the calls "simultaneously,
parallelly", and "for 1 second 5 different requests can be made from the API".

What is tested here:
  * how the open columns are cut into calls (family1.column_parts): at least 40 in a call whenever 40 are open, never 80;
  * what such a call holds: every column with its 30 most frequent keywords (counted by the Data Explorer, the most frequent
    first), and no keyword meaning asked in it; the keyword meanings (20 per column) are asked in other calls at the same time,
    and the result is the same whichever kind of call answers first;
  * a column whose meaning the model never gives keeps the keyword meanings that were answered, stays without a meaning
    (no text is written for it by code) and is asked again in the next run, for its meaning only;
  * the start rate of the model calls (core.Slots): no more than 5 starts within any one second.

No real model is called: the stand-in model server of tests/test_grounder_batches.py answers, and every run has a knowledge
folder of its own (tests/test_grounder_known.py, _World). Where a test is not about the rate, its own runner may start 1,000
calls in a second, so that the suite stays fast; the application's number (core.Slots.PER_SECOND = 5) is never changed.

The files go to a folder of this test's own under F2T_TEST_TMP (or the system's temporary folder) and are deleted."""
import csv
import os
import sys
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from test_grounder_batches import _for_keywords, _for_meaning      # noqa: E402
from test_grounder_known import FROM_MODEL, KEPT, PACKETS, _World, _cols, _said      # noqa: E402


# ------------------------------------------------------------------------------------------ how the open columns are cut
def test_open_columns_are_cut_into_calls_of_at_least_40_and_fewer_than_80_in_the_order_they_have():
    from agentic import family1
    assert family1.GROUND_BATCH == 40 and family1.GROUND_KEYWORDS_SHOWN == 30 and family1.GROUND_KEYWORDS == 20
    assert family1.column_parts([]) == []
    for n in range(1, 80):                                      # fewer than 80 open columns: one call (40 cannot be reached twice)
        assert [len(p) for p in family1.column_parts(list(range(n)))] == [n], n
    assert [len(p) for p in family1.column_parts(list(range(80)))] == [40, 40]
    assert [len(p) for p in family1.column_parts(list(range(100)))] == [50, 50]
    assert [len(p) for p in family1.column_parts(list(range(361)))] == [41] + [40] * 8
    assert [len(p) for p in family1.column_parts(list(range(2000)))] == [40] * 50
    big = family1.column_parts(list(range(2039)))
    assert len(big) == 50 and all(40 <= len(p) < 80 for p in big) and sorted({len(p) for p in big}) == [40, 41]
    for n in list(range(0, 400)) + [1999, 2000, 2001, 2039, 5000]:
        items = ["column %d" % i for i in range(n)]
        parts = family1.column_parts(items)
        assert [x for p in parts for x in p] == items, n         # the order kept, every column exactly once
        assert len(parts) == (max(1, n // 40) if n else 0), n
        if n >= 40:
            assert all(40 <= len(p) < 80 for p in parts), n      # at least 40 in every call; never 80 (that would be two calls)
            assert max(len(p) for p in parts) - min(len(p) for p in parts) <= 1, n
    # another number than the owner's 40 may be given; nothing is lost with it either
    assert [len(p) for p in family1.column_parts(list(range(10)), least=3)] == [4, 3, 3]


# ------------------------------------------------------------------------------------------ what a call holds
def _busy_cols(n=100, kws=45):
    """Columns of an unknown tool, each with kws keywords as the Data Explorer writes them: the most frequent first. The names
    of the keywords are not in the order of the alphabet, so a list that was sorted by name would show."""
    out = []
    for i in range(n):
        words = ["W%02d_%d" % ((j * 7) % kws, i) for j in range(kws)]                 # W00, W07, W14, ... W38: every name once
        out.append({"column": "Field %03d" % i, "position": i, "header_cell": "Field %03d" % i, "type": "text", "rows_with_value": 5000,
                    "observed": "holds a code", "top_values": [{"value": "V%d_%d" % (i, j), "count": 10 - j} for j in range(3)],
                    "keywords": [{"value": w, "count": 900 - 10 * j} for j, w in enumerate(words)]})
    return out


def _one_kind_first(first, calls_of_it):
    """For _World.ground(prepare=...): the calls of the other kind are sent only when all `calls_of_it` calls of the `first`
    kind ("meaning" or "keywords") are back. A call that waits holds no place among the calls at once."""
    def prepare(runner, model):
        real, lock, back, n = runner.ask, threading.Lock(), threading.Event(), [0]

        def ask(run_id, name, instruction, context, *a, **k):
            kind = "keywords" if "meaning_known" in context["columns"][0] else "meaning"
            if kind != first:
                assert back.wait(60), "the calls that were to answer first did not come back"
            try:
                return real(run_id, name, instruction, context, *a, **k)
            finally:
                if kind == first:
                    with lock:
                        n[0] += 1
                        if n[0] >= calls_of_it:
                            back.set()
        runner.ask = ask
    return prepare


def test_100_open_columns_are_two_calls_of_50_each_with_its_30_most_frequent_keywords_whichever_call_answers_first():
    from agentic import family1
    cols_in = _busy_cols()
    seen = {c["column"]: [k["value"] for k in c["keywords"]] for c in cols_in}
    assert all(len(v) == 45 and v != sorted(v) for v in seen.values())
    results = {}
    for first, calls_of_it in (("meaning", 2), ("keywords", 15)):
        with _World("forty_%s" % first) as w:
            model, res, out, ctx = w.ground(cols_in, PACKETS, per_second=1000, pause=0.02, prepare=_one_kind_first(first, calls_of_it))
            kinds = ["keywords" if "meaning_known" in a["columns"][0] else "meaning" for a in model.asked]     # in the order they were answered
            assert kinds == (["meaning"] * 2 + ["keywords"] * 15 if first == "meaning" else ["keywords"] * 15 + ["meaning"] * 2), (first, kinds)
            assert not any(len({"meaning_known" in c for c in a["columns"]}) != 1 for a in model.asked)        # no call asks for both kinds
            # the columns' meanings: exactly 2 calls of 50, in the file's order, every column with its 30 most frequent keywords
            # (the most frequent first) and without a keyword to write a meaning for
            wanted = sorted((a for a, k in zip(model.asked, kinds) if k == "meaning"), key=lambda a: a["columns"][0]["column"])
            assert [[c["column"] for c in a["columns"]] for a in wanted] == [["Field %03d" % i for i in range(50)], ["Field %03d" % i for i in range(50, 100)]]
            for c in (c for a in wanted for c in a["columns"]):
                assert c["keywords_seen"] == seen[c["column"]][:30] and len(c["keywords_seen"]) == 30, c["column"]
                assert "keywords" not in c and "meaning_known" not in c, c["column"]
            assert all(a["tools"] and not a["retry"] and not a["again"] for a in wanted)                       # the web only where a column's meaning is looked for
            # the keywords: the 20 most frequent of every column, in other calls, where the entry says that the meaning is asked apart
            words = [a for a, k in zip(model.asked, kinds) if k == "keywords"]
            assert sorted(len(a["columns"]) for a in words) == [2] + [7] * 14                                  # 7 columns of 20 keywords: 140 of the 150 meanings a call may hold
            assert not any(a["tools"] or a["retry"] or a["again"] for a in words)
            entries = [c for a in words for c in a["columns"]]
            assert sorted(c["column"] for c in entries) == sorted(seen)                                        # every column once
            for c in entries:
                assert c["meaning_known"] == family1.KEYWORDS_APART and c["keywords"] == seen[c["column"]][:20] and "keywords_seen" not in c, c["column"]
            assert model.calls == 17 and model.cols_seen == 100 and model.entries_seen == 200                  # nothing asked twice
            # the result: every column with the meaning the model gave and the meanings of its 20 keywords
            assert sorted(out["columns"]) == sorted(seen)
            for name, m in out["columns"].items():
                assert m["meaning"] == "what %s holds" % name and family1._status(m) == FROM_MODEL, name
                assert {k: v["meaning"] for k, v in m["keywords"].items()} == {k: "the value %s" % k for k in seen[name][:20]}, name
            t = res.output["timing"]
            # ("at least" is the promise - 40, or all the open columns when fewer are open - not the smallest call of this run, which held 50)
            assert (t["parts"], t["model_calls"], t["calls_for_column_meanings"], t["columns_per_such_call_at_least"], t["columns_per_such_call_most"]) == (17, 17, 2, 40, 50)
            assert (t["columns_asked"], t["keyword_meanings_asked"], t["frequent_keywords_given_per_column_at_most"]) == (100, 2000, 30)
            assert res.output["columns_asked"] == 100
            # ... and all of it is kept: the same file again asks nothing
            model2, res2, out2, ctx2 = w.ground(cols_in, PACKETS, run_id=2, per_second=1000)
            assert model2.calls == 0 and _said(out2) == _said(out)
            results[first] = _said(out)
    assert results["meaning"] == results["keywords"]                                                           # the same, whichever answered first


def test_the_frequent_keywords_are_the_ones_the_explorer_counted_most_often_on_the_rows_of_the_file():
    """From a CSV file to the call: the Data Explorer counts every row, and the Grounder's call for the column's meaning gives
    the 30 words that are in the most rows, the most frequent first - not the first 30 of the file, not the first 30 by name."""
    from agentic import family1
    words = ["Tango", "Alpha", "Mike", "Zulu", "Echo", "Kilo", "Bravo", "Yankee", "Delta", "Oscar", "Hotel", "Sierra", "Golf", "Victor", "Lima",
             "Papa", "Juliet", "Romeo", "Quebec", "India", "Xray", "Foxtrot", "Uniform", "November", "Whiskey", "Charlie", "Nadir", "Orbit",
             "Pulse", "Quartz", "Ripple", "Summit", "Timber", "Umbra", "Vortex"]
    assert len(set(words)) == 35 and all(family1.is_keyword(x, "State") for x in words)
    often = {x: 40 - j for j, x in enumerate(words)}            # Tango in 40 rows, Alpha in 39, ... Vortex in 6: no two the same
    cells = [x for x in reversed(words) for _ in range(often[x])]       # in the file the rarest word comes first
    with _World("forty_rows") as w:
        folder = os.path.join(w.root, "rows")
        os.makedirs(folder)
        with open(os.path.join(folder, "states.csv"), "w", newline="") as fh:
            wr = csv.writer(fh)
            wr.writerow(["Packet", "State"])
            for r, x in enumerate(cells):
                wr.writerow([str(1000 + r), x])
        f = family1.inventory(folder)[0]
        _m, _res, mem, _ctx = w.explore(f)
        state = [c for c in mem["columns"] if c["column"] == "State"][0]
        assert [(k["value"], k["count"]) for k in state["keywords"]] == [(x, often[x]) for x in words]       # all 35, counted on every row, most frequent first
        model, res, out, ctx = w.ground(mem["columns"], f)
        entry = [c for c in _for_meaning(model) if c["column"] == "State"]
        assert len(entry) == 1 and entry[0]["keywords_seen"] == words[:30] and "keywords" not in entry[0]
        apart = [c for c in _for_keywords(model) if c["column"] == "State"]
        assert len(apart) == 1 and apart[0]["keywords"] == words[:20] and apart[0]["meaning_known"] == family1.KEYWORDS_APART
        assert out["columns"]["State"]["meaning"] == "what State holds" and sorted(out["columns"]["State"]["keywords"]) == sorted(words[:20])


# ------------------------------------------------------------------------------------------ a meaning the model never gives
def test_a_column_whose_meaning_the_model_never_gives_keeps_its_keyword_meanings_and_gets_no_meaning_from_code():
    from agentic import family1
    kws3 = {"K3_%d" % j: "the value K3_%d" % j for j in range(5)}
    with _World("forty_never") as w:
        # 12 columns of 5 keywords: one call for the 12 meanings, two calls for the keywords of 6 columns each. The model
        # answers everything but the meaning of Field 003: not in the call, not in the retry without the web
        model, res, out, ctx = w.ground(_cols(12), PACKETS, meaning_never=("Field 003",))
        tries = [[c["column"] for c in a["columns"]] for a in model.asked if "meaning_known" not in a["columns"][0]]
        assert sorted(tries, key=len) == [["Field 003"], ["Field %03d" % i for i in range(12)]] and model.retries == 1
        assert model.calls == 4 and len(_for_keywords(model)) == 12                    # the keywords were asked once each, also Field 003's
        m = out["columns"]["Field 003"]
        assert m["meaning"] == "" and m["source"] == {} and m["checked"] is False      # no meaning: nothing was written in its place
        assert {k: v["meaning"] for k, v in m["keywords"].items()} == kws3             # ... and the keyword meanings that were answered are there
        assert all(v["source"]["kind"] == "model" for v in m["keywords"].values())
        assert len(out["columns"]) == 12 and all(out["columns"]["Field %03d" % i]["meaning"] == "what Field %03d holds" % i for i in range(12) if i != 3)
        assert all(len(x["keywords"]) == 5 for x in out["columns"].values())
        assert "1 column without a meaning after 3 tries" in res.producer
        assert "12 of 12 columns done, 11 with a meaning" in ctx.notes[-1][1], ctx.notes[-1][1]
        assert sorted(c["text"] for c in ctx.evidence_calls[0]) == ["Field %03d" % i for i in range(12) if i != 3]     # no claim for it
        assert not any("Field 003" in str(v.get("meaning")) for v in [m])
        # kept for the next run: the keywords, and no meaning - so the column is not taken as known
        st = w.store()
        assert st.match("fmtA", "Field 003", "text", ["K3_0"]) is None
        assert {k: v["meaning"] for k, v in st.keywords("fmtA", "Field 003").items()} == kws3
        # the next run, the model still without a meaning for it: asked for the meaning only (and retried), the keywords stay
        model2, res2, out2, ctx2 = w.ground(_cols(12), PACKETS, run_id=2, meaning_never=("Field 003",))
        asked2 = [c for a in model2.asked for c in a["columns"]]
        assert model2.calls == 2 and [c["column"] for c in asked2] == ["Field 003"] * 2 and not any("meaning_known" in c or "keywords" in c for c in asked2)
        assert all(c["keywords_seen"] == list(kws3) for c in asked2)
        m2 = out2["columns"]["Field 003"]
        assert m2["meaning"] == "" and {k: v["meaning"] for k, v in m2["keywords"].items()} == kws3
        assert all(family1._status(v).startswith(KEPT) for v in m2["keywords"].values())
        assert (res2.output["columns_asked"], res2.output["timing"]["keyword_meanings_asked"]) == (1, 0)
        # a run in which the model does give it: one call, one entry, and the column is whole
        model3, res3, out3, ctx3 = w.ground(_cols(12), PACKETS, run_id=3)
        asked3 = [c for a in model3.asked for c in a["columns"]]
        assert model3.calls == 1 and [c["column"] for c in asked3] == ["Field 003"] and "meaning_known" not in asked3[0] and "keywords" not in asked3[0]
        m3 = out3["columns"]["Field 003"]
        assert m3["meaning"] == "what Field 003 holds" and family1._status(m3) == FROM_MODEL
        assert {k: v["meaning"] for k, v in m3["keywords"].items()} == kws3 and all(family1._status(v).startswith(KEPT) for v in m3["keywords"].values())
        model4, res4, out4, ctx4 = w.ground(_cols(12), PACKETS, run_id=4)
        assert model4.calls == 0 and out4["columns"]["Field 003"]["meaning"] == "what Field 003 holds"


# ------------------------------------------------------------------------------------------ 5 starts in one second
class _Told:
    """A core.Slots that also keeps the instant at which each place was given (the limiter's own clock reading)."""

    def __new__(cls, *a, **k):
        from agentic import core

        class Told(core.Slots):
            def __init__(self, *a2, **k2):
                core.Slots.__init__(self, *a2, **k2)
                self.given = []

            def take(self, check=None):
                with self._cv:                  # the limiter's own lock (it may be taken again by its holder): no other call starts in between
                    core.Slots.take(self, check)
                    self.given.append(self._starts[-1])
        return Told(*a, **k)


def _most_in_a_second(times, slack=0.0):
    """The most starts that any one second holds: for every start, the starts from it to less than (1 - slack) seconds later."""
    times = sorted(times)
    return max(sum(1 for u in times if t <= u < t + 1.0 - slack) for t in times)


def test_no_more_than_5_calls_start_within_any_one_second_however_many_places_are_free():
    from agentic import core
    assert core.Slots.PER_SECOND == 5 and core.Slots(32).per_second == 5 and core.Slots(32, per_second=3).per_second == 3
    slots = _Told(32)                                           # 32 places: only the second holds a call back
    seen, lock, go = [], threading.Lock(), threading.Event()

    def call():
        go.wait()
        slots.take()
        t = time.time()                                         # as the caller sees it: right after it has its place
        with lock:
            seen.append(t)
    threads = [threading.Thread(target=call) for _ in range(12)]
    for th in threads:
        th.start()
    t0 = time.time()
    go.set()
    for th in threads:
        th.join(20)
    assert len(seen) == len(slots.given) == 12 and slots.active == 12 and slots.most == 12       # every call got its place, none was lost
    given = sorted(slots.given)
    # by the limiter's own clock: the sixth start after any start is a full second later, so no one second holds more than 5
    assert all(given[i + 5] - given[i] >= 1.0 for i in range(7)), [round(x - given[0], 3) for x in given]
    assert _most_in_a_second(given) == 5
    # as the 12 callers saw it (a caller reads the clock a moment after its place was given: 0.05 s is allowed for that)
    assert _most_in_a_second(seen, slack=0.05) <= 5, [round(x - t0, 3) for x in sorted(seen)]
    # 5 at once, 5 a second later, 2 a second after that: all 12 within about 3 seconds, and not sooner than the rate allows
    assert 2.0 <= given[-1] - given[0] < 3.0 and max(seen) - t0 < 3.0, (given[-1] - given[0], max(seen) - t0)
    assert [sum(1 for x in given if s <= x - given[0] < s + 1.0) for s in (0.0, 1.0, 2.0)] == [5, 5, 2]
    for _ in range(12):
        slots.give()
    assert slots.active == 0


def test_a_rate_of_1000_in_a_second_makes_no_call_wait():
    from agentic import core
    slots = core.Slots(64, per_second=1000)
    t0 = time.time()
    for _ in range(60):
        slots.take()
    assert time.time() - t0 < 0.5 and slots.active == 60
    # ... and with the application's own 5 the sixth of the same loop waits for the second to pass
    slots = core.Slots(64)
    t0 = time.time()
    for _ in range(5):
        slots.take()
    quick = time.time() - t0
    slots.take()
    assert quick < 0.5 and 1.0 <= time.time() - t0 < 1.5 and slots.active == 6


def test_a_call_that_is_stopped_while_it_waits_takes_no_place_and_giving_back_keeps_the_count_right():
    from agentic import core

    class Stopped(Exception):
        pass

    def check():
        raise Stopped()
    # it waits for a place (1 place, taken)
    slots = core.Slots(1, per_second=1000)
    slots.take(check)                                           # a free place and room in the second: no waiting, check is not asked
    assert slots.active == 1
    try:
        slots.take(check)
        raise AssertionError("the stopped call got a place")
    except Stopped:
        pass
    assert slots.active == 1 and slots.most == 1 and len(slots._starts) == 1          # no place taken, no start counted
    slots.give()
    assert slots.active == 0
    slots.take(check)                                           # the place is free again: taken without waiting
    assert slots.active == 1
    slots.give()
    # it waits for the second (4 places, 1 start in a second)
    slots = core.Slots(4, per_second=1)
    slots.take(check)
    t0 = time.time()
    try:
        slots.take(check)
        raise AssertionError("the stopped call started within the same second")
    except Stopped:
        pass
    assert slots.active == 1 and len(slots._starts) == 1 and time.time() - t0 < 1.0
    slots.take()                                                # not stopped: it waits for the second and then has its place
    assert slots.active == 2 and 1.0 <= time.time() - t0 < 1.6
    # giving back: one place per give, never below nothing, and the most seen together stays
    slots = core.Slots(8, per_second=1000)
    for n in (1, 2, 3):
        slots.take()
        assert slots.active == n
    for n in (2, 1, 0, 0):
        slots.give()
        assert slots.active == n
    assert slots.most == 3
    with slots:
        assert slots.active == 1
    assert slots.active == 0
    # a place that is given back lets a waiting call in, but not before the second has room
    slots = core.Slots(1, per_second=2)
    slots.take()
    got = []
    th = threading.Thread(target=lambda: (slots.take(), got.append(time.time())))
    t0 = time.time()
    th.start()
    time.sleep(0.2)
    assert not got and slots.active == 1                        # no place free: it waits
    slots.give()
    th.join(5)
    assert len(got) == 1 and got[0] - t0 < 0.6 and slots.active == 1                  # the second had room (2 in a second): in at once


# ------------------------------------------------------------------------------------------ the effort level said to Claude Code
# Measured with the real model on 2026-11-12 (claude-sonnet-5-5, one call of 140 keywords, 60 of them made-up words): at "xhigh"
# the 60 were left empty, at "medium" and "low" each got a filler sentence. Without a level Claude Code takes the one of the
# personal settings of the user who runs the server, so the Grounder says its own with every call.
def _claude_code_stand_in(runner, seen):
    """Claude Code replaced by a function on this runner: it records the command line and the time a call may take, and answers
    as the stand-in model server does (the meaning of a column that is asked, the meaning of every keyword under "keywords")."""
    import json
    import types
    lock = threading.Lock()

    def run_cli(cmd, prompt, cwd, timeout, env):
        cols = json.loads(prompt.split("CONTEXT:\n", 1)[1])["columns"]
        rows = []
        for c in cols:
            row = {"n": c["n"], "keywords": [[k, "the value %s" % k, "model"] for k in c.get("keywords") or []]}
            if "meaning_known" not in c:
                row.update(meaning="what %s holds" % c["column"], kind="model")
            rows.append(row)
        with lock:
            seen.append({"effort": cmd[cmd.index("--effort") + 1] if "--effort" in cmd else None, "timeout": timeout,
                         "web": "WebSearch" in " ".join(cmd), "for_meaning": any("meaning_known" not in c for c in cols),
                         "for_keywords": any(c.get("keywords") for c in cols)})
        return types.SimpleNamespace(returncode=0, stdout=json.dumps({"result": json.dumps({"columns": rows})}), stderr="")
    runner._run_cli = run_cli


def _ground_over_claude_code(w, cols_in, run_id, level):
    """One Grounder step whose calls go to Claude Code (the stand-in above), with this effort level set in family1 ->
    (the calls as Claude Code was started, the step's result, the Grounder's memory, the context)."""
    import json
    from agentic import core, family1
    from test_grounder_batches import _Ctx
    seen = []
    mem = os.path.join(w.root, "explorer_cc_%d.json" % run_id)
    with open(mem, "w") as fh:
        json.dump({"columns": cols_in}, fh)
    was_find, was_level = core.AgentRunner.find_claude, family1.GROUND_EFFORT
    was_env = {k: os.environ.pop(k, None) for k in ("ANTHROPIC_BASE_URL", "ANTHROPIC_AUTH_TOKEN")}     # no address of our own: Claude Code is used
    core.AgentRunner.find_claude = staticmethod(lambda configured=None: "/no/such/folder/claude")
    family1.GROUND_EFFORT = level
    try:
        runner = core.AgentRunner(os.path.join(w.root, "runs_cc"), runtime="claude-code", model="model-1", http_model="model-1", web=True, calls_at_once=4)
        runner.slots.per_second = 1000
        assert runner.path_now() == "claude-code"
        _claude_code_stand_in(runner, seen)
        ctx = _Ctx(runner, mem, run_id)
        res = family1._ground(ctx, dict(PACKETS, format_key="fmtCC%d" % run_id))
        with open(res.output["memory_file"]) as fh:
            return seen, res, json.load(fh), ctx, runner
    finally:
        core.AgentRunner.find_claude, family1.GROUND_EFFORT = was_find, was_level
        for k, v in was_env.items():
            if v is not None:
                os.environ[k] = v


def test_the_effort_level_is_one_of_claude_codes_levels_or_nothing_is_said():
    from agentic import family1
    assert family1.GROUND_EFFORT == "xhigh" and family1.ground_effort() == "xhigh"        # as shipped: the level that left unknown words empty
    was = family1.GROUND_EFFORT
    try:
        for level in family1.EFFORT_LEVELS:
            family1.GROUND_EFFORT = level
            assert family1.ground_effort() == level
        for not_a_level in (None, "", "fastest", "XHIGH", 3, "low; rm"):                    # never passed on to the command line
            family1.GROUND_EFFORT = not_a_level
            assert family1.ground_effort() is None, not_a_level
    finally:
        family1.GROUND_EFFORT = was


def test_every_grounder_call_to_claude_code_says_the_effort_level_and_the_meanings_do_not_depend_on_it():
    from agentic import family1
    cols_in = _busy_cols(n=50, kws=25)
    said = {}
    with _World("effort") as w:
        for run_id, level in ((1, "xhigh"), (2, None), (3, "not a level")):
            seen, res, out, ctx, runner = _ground_over_claude_code(w, cols_in, run_id, level)
            meaning = [c for c in seen if c["for_meaning"]]
            words = [c for c in seen if not c["for_meaning"]]
            assert len(meaning) == 1 and len(words) == 8 and all(c["for_keywords"] for c in words), (level, len(meaning), len(words))
            assert all(c["web"] for c in meaning) and not any(c["web"] for c in words)       # the web only where a column's meaning is looked for
            if level == "xhigh":
                # both kinds of call say the level; a call with a level may take twice the runner's time, as one with the web
                assert [c["effort"] for c in seen] == ["xhigh"] * 9
                assert {c["timeout"] for c in seen} == {2 * runner.timeout}
                assert "effort xhigh" in res.producer, res.producer
            else:
                # nothing said: Claude Code's own settings decide, and only the calls with the web get twice the time
                assert [c["effort"] for c in seen] == [None] * 9
                assert {c["timeout"] for c in meaning} == {2 * runner.timeout} and {c["timeout"] for c in words} == {runner.timeout}
                assert "effort" not in res.producer, res.producer
            assert len(out["columns"]) == 50
            for name, m in out["columns"].items():
                assert m["meaning"] == "what %s holds" % name and family1._status(m) == FROM_MODEL, name
                assert len(m["keywords"]) == 20 and all(v["meaning"] == "the value %s" % k for k, v in m["keywords"].items()), name
            said[level] = {n: (m["meaning"], m["source"], {k: (v["meaning"], v["source"]) for k, v in m["keywords"].items()}) for n, m in out["columns"].items()}
    assert said["xhigh"] == said[None] == said["not a level"]                               # the program keeps what the model gave, whatever the level


def test_over_the_model_connection_no_effort_level_is_passed():
    from agentic import family1
    assert family1.ground_effort() == "xhigh"
    passed = []

    def watch(runner, model):
        ask0 = runner.ask

        def ask(*a, **kw):
            passed.append(kw.get("effort", "not given"))
            return ask0(*a, **kw)
        runner.ask = ask
        assert runner.path_now() == "http"
    with _World("effort_http") as w:
        model, res, out, ctx = w.ground(_busy_cols(n=50, kws=25), PACKETS, per_second=1000, pause=0.01, prepare=watch)
        assert model.calls == 9 and passed == [None] * 9                                    # the Model connection has no such level
        assert "effort" not in res.producer and len(out["columns"]) == 50
