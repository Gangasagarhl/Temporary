#!/usr/bin/env python3
"""The four independent joins of Build hierarchy in processes of their own, against the build on one core (2026-11-12).

Offline: no server, no model, no network, its own temporary folders. What is proven:
  1. the joins run at the same time (2, 3 or 4 processes) leave the tree of the build on one core: every table's columns, row count and a hash that does not depend on
     row order, the indexes, and the build report without its timings;
  2. a small recording stays on one core;
  3. what can go wrong with a process: it is killed, it is killed after writing part of its result, it raises, it says it finished without a result, its result file is
     not a database, no process can be started, only the first can be started. Each time the build runs that join itself and the tree is the same;
  4. a stop while the joins run (the progress report raises, or memory or disk runs out) ends the processes, leaves no scratch file and does not touch the recording;
  5. scratch files left by a build that was killed are removed by the next build;
  6. a join process cannot write the recording (it may only write its own scratch file);
  7. a rebuild keeps nothing of the build before it: every link and every duration is what this build decided;
  8. the progress while the joins run: one percentage for all of them that never goes back, and a detail the page can take its rows-per-second from;
 10. while the build waits for the other programs on the machine (memory is tight) the join processes wait as well, and go on when the build goes on;
  9. stepping back for processor time never fails: where the operating system has no 'nice' (Windows), where it has, with the levels from the environment.
     The Windows calls are made against a stand-in here: this was NOT run on a real Windows machine.

Run: python3 tests/test_joins_at_once.py
"""
import functools
import glob
import multiprocessing
import os
import re
import shutil
import sqlite3
import sys
import time
import types

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)
from nvme_hier import builder as B, loader as L          # noqa: E402
import test_hierarchy_parallel as HP                      # noqa: E402  (signature, differences, loader)
import test_nvme_hier as T                                # noqa: E402  (_generated_set)

NAMES = [name for name, _step in B.JOINS]
STEPS = [step for _name, step in B.JOINS]


@pytest.fixture(scope="module")
def loaded(tmp_path_factory):
    """One small recording of the application's generator, its five files loaded (on one core) and not built yet. Every test builds a copy of it."""
    files, _truth = T._generated_set(str(tmp_path_factory.mktemp("generated")))
    db = str(tmp_path_factory.mktemp("loaded") / "hier.sqlite")
    with HP.loader(WORKERS=1):
        L.load_upload(db, files)
    con = sqlite3.connect(db)
    con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    con.close()
    return db


def copy_of(loaded, tmp_path, name):
    folder = tmp_path / name
    folder.mkdir()
    db = str(folder / "hier.sqlite")
    shutil.copy(loaded, db)
    return db


def build(db, workers, **kw):
    with HP.loader(WORKERS=workers):
        return B.build(db, **kw)


def scratch_files(db):
    return sorted(os.path.basename(f) for f in glob.glob(glob.escape(os.path.splitext(db)[0]) + ".work*"))


@pytest.fixture(scope="module")
def one_core(loaded, tmp_path_factory):
    """The tree of the build on one core: (database, report, signature)."""
    db = copy_of(loaded, tmp_path_factory.mktemp("one_core"), "db")
    rep = build(db, 1)
    assert "parallel" not in rep
    return db, rep, HP.signature(db)


@pytest.fixture
def at_once(monkeypatch):
    """The recording of these tests is small: without this the build would leave it on one core."""
    monkeypatch.setattr(B, "JOINS_AT_ONCE_MIN_US", 0)


def same_tree(db, one_core):
    assert HP.differences(one_core[2], HP.signature(db)) == []
    assert scratch_files(db) == []
    assert multiprocessing.active_children() == []


# ------------------------------------------------------------------ 1, 2. the same tree
@pytest.mark.parametrize("processes", [2, 3, 4])
def test_joins_in_processes_give_the_tree_of_one_core(loaded, one_core, at_once, tmp_path, processes):
    db = copy_of(loaded, tmp_path, "db")
    rep = build(db, processes)
    assert rep["parallel"]["joins_at_the_same_time"] == NAMES and rep["parallel"]["processes"] == processes
    assert rep["parallel"]["run_on_one_core_instead"] == {}
    assert sorted(rep["steps"]) == sorted(one_core[1]["steps"])
    same_tree(db, one_core)


def test_a_small_recording_stays_on_one_core(loaded, one_core, tmp_path):
    db = copy_of(loaded, tmp_path, "db")
    rep = build(db, 4)                                      # four workers allowed, but the planned work is below JOINS_AT_ONCE_MIN_US
    assert "parallel" not in rep
    same_tree(db, one_core)


def test_one_worker_allowed_means_one_core(loaded, one_core, at_once, tmp_path, monkeypatch):
    db = copy_of(loaded, tmp_path, "db")
    monkeypatch.setattr(B, "joins_at_once", lambda *a, **k: pytest.fail("no process may be started when one worker is allowed"))
    assert "parallel" not in build(db, 1)
    same_tree(db, one_core)


def test_the_joins_that_are_due_follow_the_levels():
    assert [n for n, _s in B.joins_due(["packets", "link", "split", "nvme_transaction", "nvme_command"])] == NAMES
    assert [n for n, _s in B.joins_due(["packets", "link"])] == ["packets_to_links"]
    assert [n for n, _s in B.joins_due(["link", "nvme_transaction"])] == ["units_to_ntx"]
    assert [n for n, _s in B.joins_due(["split", "nvme_transaction", "nvme_command"])] == ["units_to_ntx", "ntx_to_cmds"]
    assert B.joins_due(["packets"]) == [] and B.joins_due([]) == []


# ------------------------------------------------------------------ 3. what can go wrong with a process
def _spoiled(how, db_path, name, step, settings, part, out, go=None):
    """Runs in the join's process in place of builder._join_process (the test puts it there): one join goes wrong in the way `how`, the others run as they are."""
    if how == "killed" and name == "links_to_splits":
        os._exit(9)
    if how == "killed after writing" and name == "packets_to_links":
        con = L.open_db(db_path)
        L.attach_work(con, db_path, part=part)
        B.Build(con, None, settings)                        # makes the scratch tables
        con.executemany("INSERT INTO w.pkt_parent (rowid, lvl, par, rel, t) VALUES (?, 'link', 1, 'nonsense', 0)", [(i,) for i in range(1, 400)])
        con.commit()
        con.close()
        os._exit(7)
    if how == "raises" and name == "units_to_ntx":
        def broken(_self):
            raise ValueError("no such thing")
        B.Build.units_to_ntx = broken
    if how == "no result" and name == "ntx_to_cmds":
        out.send(("done", {"ntx_to_cmds": {"seconds": 0.0, "made up": 1}}))
        out.close()
        return
    if how == "not a database" and name == "links_to_splits":
        with open(L.work_path(db_path, part), "wb") as fh:
            fh.write(os.urandom(8192))
        out.send(("done", {"links_to_splits": {"seconds": 0.0, "made up": 1}}))
        out.close()
        return
    if how == "other tables" and name == "packets_to_links":
        con = sqlite3.connect(L.work_path(db_path, part))
        for t in B.SCRATCH_TABLES:
            con.execute("CREATE TABLE %s (rowid INTEGER PRIMARY KEY, something TEXT)" % t)
        con.execute("INSERT INTO pkt_parent VALUES (1, 'nonsense')")
        con.commit()
        con.close()
        out.send(("done", {"packets_to_links": {"seconds": 0.0, "made up": 1}}))
        out.close()
        return
    B._join_process(db_path, name, step, settings, part, out, go)


@pytest.mark.parametrize("how, join, why", [
    ("killed", "links_to_splits", r"^its process ended without a result \(exit code 9\)$"),
    ("killed after writing", "packets_to_links", r"^its process ended without a result \(exit code 7\)$"),
    ("raises", "units_to_ntx", r"^ValueError: no such thing$"),
    ("no result", "ntx_to_cmds", r"^its result could not be read \(its table pkt_parent is missing\)$"),
    ("not a database", "links_to_splits", r"^its result could not be read \(DatabaseError: "),
    ("other tables", "packets_to_links", r"^its result could not be read \(its table pkt_parent is not the build's\)$"),
])
def test_a_join_whose_process_goes_wrong_is_run_on_one_core(loaded, one_core, at_once, tmp_path, monkeypatch, how, join, why):
    db = copy_of(loaded, tmp_path, "db")
    monkeypatch.setattr(B, "_join_process", functools.partial(_spoiled, how))
    rep = build(db, 4)
    instead = rep["parallel"]["run_on_one_core_instead"]
    assert list(instead) == [join] and re.search(why, instead[join]), instead
    assert rep["steps"][join] == {k: v for k, v in rep["steps"][join].items() if k != "made up"}       # the report is the build's own, not what the process said
    assert {k: v for k, v in rep["steps"][join].items() if k != "seconds"} == {k: v for k, v in one_core[1]["steps"][join].items() if k != "seconds"}
    same_tree(db, one_core)


class _FewProcesses:
    """A spawn context that can start `allowed` processes and no more."""

    def __init__(self, real, allowed):
        self.real, self.allowed = real, allowed

    def Pipe(self, duplex=False):
        return self.real.Pipe(duplex=duplex)

    def Event(self):
        return self.real.Event()

    def Process(self, **kw):
        if self.allowed > 0:
            self.allowed -= 1
            return self.real.Process(**kw)

        class Cannot:
            def start(self):
                raise OSError("no more processes")
        return Cannot()


@pytest.mark.parametrize("allowed", [0, 1])
def test_processes_that_cannot_be_started_leave_their_joins_to_one_core(loaded, one_core, at_once, tmp_path, monkeypatch, allowed):
    db = copy_of(loaded, tmp_path, "db")
    real = multiprocessing.get_context("spawn")
    monkeypatch.setattr(multiprocessing, "get_context", lambda _kind=None: _FewProcesses(real, allowed))
    rep = build(db, 4)
    instead = rep["parallel"]["run_on_one_core_instead"]
    assert list(instead) == NAMES[allowed:], instead
    assert all(w == "a process for it could not be started (OSError: no more processes)" for w in instead.values())
    same_tree(db, one_core)


# ------------------------------------------------------------------ 4. a stop while the joins run
def test_a_stop_from_the_progress_report_ends_the_processes(loaded, one_core, at_once, tmp_path, monkeypatch):
    db = copy_of(loaded, tmp_path, "db")
    before = HP.signature(db, meta=False)
    monkeypatch.setattr(L, "REPORT_SECONDS", 0.0)
    said = []

    def stop(step, detail, pct):
        said.append((step, detail, pct))
        raise L.NoRoom("stopped for the test")
    with pytest.raises(L.NoRoom, match="stopped for the test"):
        build(db, 3, progress=stop)
    assert len(said) == 1 and said[0][0] == STEPS[0]         # the first report came while the joins ran
    assert multiprocessing.active_children() == [] and scratch_files(db) == []
    assert HP.differences(before, HP.signature(db, meta=False)) == []      # the recording is as it was loaded
    build(db, 3)                                             # and the build can simply be run again
    same_tree(db, one_core)


def test_no_memory_or_disk_left_ends_the_processes(loaded, at_once, tmp_path, monkeypatch):
    db = copy_of(loaded, tmp_path, "db")
    before = HP.signature(db, meta=False)
    monkeypatch.setattr(L, "REPORT_SECONDS", 0.0)

    class Guard:
        why = None
    guard = Guard()
    L._GUARDS.add(guard)

    def progress(_step, _detail, _pct):
        guard.why = "the disk is nearly full (test)"
    try:
        with pytest.raises(L.NoRoom, match="the disk is nearly full"):
            build(db, 3, progress=progress)
    finally:
        L._GUARDS.discard(guard)
    assert multiprocessing.active_children() == [] and scratch_files(db) == []
    assert HP.differences(before, HP.signature(db, meta=False)) == []


# ------------------------------------------------------------------ 10. the build waits for the other programs: the joins wait with it
class _WatchedContext:
    """The spawn context, keeping the 'go' word the build makes for its join processes so the test can look at it."""

    def __init__(self, real):
        self.real, self.words = real, []

    def Pipe(self, duplex=False):
        return self.real.Pipe(duplex=duplex)

    def Process(self, **kw):
        return self.real.Process(**kw)

    def Event(self):
        self.words.append(self.real.Event())
        return self.words[-1]


class _TightGuard:
    """What builder and loader look at in a RoomGuard: memory is tight (the load waits), and no reason to stop."""
    why = None
    tight = True


def test_waiting_for_room_is_what_the_guards_say():
    assert L.waiting_for_room() is False
    guard = _TightGuard()
    L._GUARDS.add(guard)
    try:
        assert L.waiting_for_room() is True
        guard.tight = False
        assert L.waiting_for_room() is False
        guard.tight, guard.why = True, "the machine was running out of memory (test)"       # stopped, not waiting
        assert L.waiting_for_room() is False
    finally:
        L._GUARDS.discard(guard)
    assert L.waiting_for_room() is False


def test_while_the_build_waits_for_room_the_joins_are_told_to_wait(loaded, one_core, at_once, tmp_path, monkeypatch):
    db = copy_of(loaded, tmp_path, "db")
    monkeypatch.setattr(L, "REPORT_SECONDS", 0.0)
    watched = _WatchedContext(multiprocessing.get_context("spawn"))
    monkeypatch.setattr(multiprocessing, "get_context", lambda _kind=None: watched)
    guard = _TightGuard()
    L._GUARDS.add(guard)
    during, after = [], []

    def progress(step, _detail, _pct):
        """The application's report: RoomGuard.check() waits in here while memory is tight, and returns when there is room again."""
        if step not in STEPS or not watched.words:
            return
        if guard.tight:
            during.append(watched.words[0].is_set())
            guard.tight = False                              # the other programs have room again
        else:
            after.append(watched.words[0].is_set())
    try:
        rep = build(db, 3, progress=progress)
    finally:
        L._GUARDS.discard(guard)
    assert len(watched.words) == 1                           # one word for all the join processes of this build
    assert during == [False]                                 # while the build waited, the joins were told to wait
    assert after and all(after)                              # every later report: they work
    assert watched.words[0].is_set()                         # and nothing is left waiting at the end
    assert rep["parallel"]["run_on_one_core_instead"] == {}
    same_tree(db, one_core)


def test_a_join_process_waits_until_the_build_says_go(loaded, tmp_path):
    """The join's side, in a real process: with the word cleared it says nothing and writes no row; with the word given it runs to its end."""
    db = copy_of(loaded, tmp_path, "db")
    ctx = multiprocessing.get_context("spawn")
    go = ctx.Event()                                         # not set: the build is waiting for room
    here, there = ctx.Pipe(duplex=False)
    name, step = B.JOINS[0]
    part = "%s.%d" % (name, os.getpid())
    p = ctx.Process(target=B._join_process, args=(db, name, step, {}, part, there, go), daemon=True)
    p.start()
    there.close()
    try:
        scratch = L.work_path(db, part)
        deadline = time.time() + 120
        while not os.path.exists(scratch) and time.time() < deadline and p.is_alive():
            time.sleep(0.05)
        assert os.path.exists(scratch), "the join process did not start"
        assert here.poll(3.0) is False                       # it has its scratch file and waits at its first report: nothing said, alive
        assert p.is_alive()
        go.set()
        said = []
        while True:
            assert here.poll(120), "nothing from the join after the word was given"
            said.append(here.recv())
            if said[-1][0] != "progress":
                break
        assert said[0][0] == "progress" and said[-1][0] == "done", [k for k, _w in said]
        assert name in said[-1][1]
    finally:
        if p.is_alive():
            p.terminate()
        p.join(20)
        here.close()
        L.drop_work_parts(db)
    assert multiprocessing.active_children() == [] and scratch_files(db) == []


def test_no_word_to_wait_can_be_made_means_one_core(loaded, one_core, at_once, tmp_path, monkeypatch):
    """A system at its limit gives no object for the word 'go': no process is started, the build runs every join itself and says why."""
    db = copy_of(loaded, tmp_path, "db")
    real = multiprocessing.get_context("spawn")

    class NoWord:
        def Event(self):
            raise OSError("no room for it")

        def Pipe(self, duplex=False):
            pytest.fail("no pipe may be made")

        def Process(self, **kw):
            pytest.fail("no process may be started")
    assert real is not None
    monkeypatch.setattr(multiprocessing, "get_context", lambda _kind=None: NoWord())
    rep = build(db, 4)
    instead = rep["parallel"]["run_on_one_core_instead"]
    assert list(instead) == NAMES and all(w == "a process for it could not be started (OSError: no room for it)" for w in instead.values())
    same_tree(db, one_core)


# ------------------------------------------------------------------ 5. what a killed build left behind
def test_scratch_files_of_a_killed_build_are_removed(loaded, one_core, tmp_path):
    db = copy_of(loaded, tmp_path, "db")
    stem = os.path.splitext(db)[0]
    left = [stem + ".work.packets_to_links.4242.sqlite", stem + ".work.packets_to_links.4242.sqlite-journal", stem + ".work.ntx_to_cmds.4242.sqlite", stem + ".work.sqlite"]
    for f in left:
        with open(f, "wb") as fh:
            fh.write(b"left by a build that was killed")
    build(db, 1)
    same_tree(db, one_core)


def test_a_join_s_scratch_file_goes_as_soon_as_it_is_taken(loaded, one_core, at_once, tmp_path, monkeypatch):
    """The disk does not hold what the joins found twice while the links are written back (the longest step of the build)."""
    db = copy_of(loaded, tmp_path, "db")
    monkeypatch.setattr(L, "REPORT_SECONDS", 0.0)
    seen = []
    build(db, 4, progress=lambda step, _detail, _pct: seen.append((step, scratch_files(db))))
    own = "hier.work.sqlite"
    parts = sorted("hier.work.%s.%d.sqlite" % (name, os.getpid()) for name in NAMES)
    collecting = [files for step, files in seen if step == B.COLLECTING]
    assert collecting and collecting[0] == sorted(parts + [own])        # all four are there when the build starts to take them
    after = [(step, files) for step, files in seen if step not in STEPS and step != B.COLLECTING]
    assert {step for step, _f in after} >= {"tree: context rows to command windows", "tree: writing the packet links", "tree: finished"}
    assert [(step, files) for step, files in after if files != [own]] == []
    same_tree(db, one_core)


def test_the_names_of_the_scratch_files(tmp_path):
    db = str(tmp_path / "hi[er].sqlite")                    # a name with characters that mean something in a file pattern
    assert L.work_path(db) == str(tmp_path / "hi[er].work.sqlite")
    assert L.work_path(db, "units_to_ntx.77") == str(tmp_path / "hi[er].work.units_to_ntx.77.sqlite")
    for f in (L.work_path(db), L.work_path(db, "a.1"), L.work_path(db, "a.1") + "-journal", L.work_path(db, "b.2"), db):
        open(f, "w").close()
    assert L.drop_work_parts(db) == 3
    assert sorted(os.listdir(tmp_path)) == ["hi[er].sqlite", "hi[er].work.sqlite"]      # the build's own scratch file and the recording are not its business
    assert L.drop_work_parts(db) == 0


# ------------------------------------------------------------------ 6. a join process cannot write the recording
def test_a_join_process_cannot_write_the_recording(loaded, tmp_path):
    db = copy_of(loaded, tmp_path, "db")
    before = HP.signature(db)
    con = L.open_db(db)
    L.attach_work(con, db, part="test.1")
    con.set_authorizer(B._scratch_only)
    try:
        for sql in ("UPDATE pkt SET parent = 1", "DELETE FROM lnk", "INSERT INTO meta (k, v) VALUES ('x', 'y')", "DROP TABLE cmd", "CREATE TABLE more (a)",
                    "CREATE INDEX ix_more ON pkt (parent)", "ALTER TABLE pkt ADD COLUMN more TEXT", "ALTER TABLE spl RENAME TO other",
                    "CREATE TRIGGER tr AFTER INSERT ON pkt BEGIN SELECT 1; END", "CREATE VIEW vw AS SELECT 1", "INSERT OR REPLACE INTO main.ntx (rowid_file) VALUES (1)"):
            with pytest.raises(sqlite3.DatabaseError, match="not authorized|prohibited"):
                con.execute(sql)
        b = B.Build(con, None, None)                        # its own scratch file is its own: tables, rows, an index, all of it
        b.sink["pkt"].add((1, "link", 2, "member", 3))
        b._flush()
        con.execute("CREATE INDEX w.ix_test ON pkt_parent (par)")
        con.execute("UPDATE w.pkt_parent SET par = 5")
        con.execute("DELETE FROM w.pkt_parent")
        con.execute("CREATE TEMP TABLE mine (a)")
        assert con.execute("SELECT count(*) FROM pkt").fetchone()[0] > 0       # and it reads the recording
        con.commit()
    finally:
        con.close()
        L.drop_work_parts(db)
    assert HP.differences(before, HP.signature(db)) == []


# ------------------------------------------------------------------ 7. a rebuild keeps nothing of the build before it
def _spoil_every_link(db):
    """What a build before could have left: a parent, a relation and a duration in every row, and none of them right."""
    con = sqlite3.connect(db)
    for t in ("pkt", "lnk", "spl", "ntx"):
        con.execute("UPDATE %s SET parent = 7, parent_level = 'stale', relation = 'stale'" % t)
    for t in ("lnk", "spl", "ntx", "cmd"):
        con.execute("UPDATE %s SET dur_ps = 7" % t)
    con.commit()
    con.close()


@pytest.mark.parametrize("workers", [1, 3])
def test_a_rebuild_keeps_nothing_of_the_build_before(loaded, one_core, at_once, tmp_path, workers):
    db = copy_of(loaded, tmp_path, "db")
    build(db, workers)
    same_tree(db, one_core)
    _spoil_every_link(db)
    assert HP.differences(one_core[2]["tables"], HP.signature(db)["tables"]) != []
    build(db, workers)
    same_tree(db, one_core)


def _rows(db, sql):
    con = sqlite3.connect(db)
    try:
        return con.execute(sql).fetchone()[0]
    finally:
        con.close()


NOTHING = "parent IS NULL AND parent_level IS NULL AND relation IS NULL"


@pytest.fixture(scope="module")
def holed(loaded, tmp_path_factory):
    """The recording with rows missing from two of its files (every seventh link transaction, every fifth NVMe transaction), as a capture that was cut
    or filtered gives them: now the joins decide nothing for some packets and find no duration for some commands. Returns (the loaded database, the
    database of its tree built once on one core, that tree's signature). In the recording as generated every packet gets a link and every command a
    duration, so the test above never reaches the rows a build must clear without having anything to write."""
    folder = tmp_path_factory.mktemp("holed")
    db = copy_of(loaded, folder, "loaded")
    con = sqlite3.connect(db)
    con.execute("DELETE FROM lnk WHERE rowid_file % 7 = 3")
    con.execute("DELETE FROM ntx WHERE rowid_file % 5 = 2")
    con.commit()
    con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    con.close()
    once = copy_of(db, folder, "once")
    build(once, 1)
    assert _rows(once, "SELECT COUNT(*) FROM pkt WHERE " + NOTHING) > 1000          # packets no join decided
    assert _rows(once, "SELECT COUNT(*) FROM cmd WHERE dur_ps IS NULL") > 10         # commands without a duration
    for t in ("spl", "ntx"):
        assert _rows(once, "SELECT COUNT(*) FROM %s WHERE dur_ps IS NULL" % t) > 10
        assert _rows(once, "SELECT COUNT(*) FROM %s WHERE relation = 'orphan' AND parent IS NULL" % t) > 10
    return db, once, HP.signature(once)


@pytest.mark.parametrize("workers", [1, 3])
def test_a_rebuild_clears_the_rows_the_joins_decide_nothing_for(holed, at_once, tmp_path, workers):
    """A packet that held a link and gets none now ends with none; the same for a duration. (Found by a deliberate fault: the write-back with its
    "held something before" part taken out passed every other test, because the generated recording leaves no such row.)"""
    loaded_with_holes, _once, sig = holed
    db = copy_of(loaded_with_holes, tmp_path, "db")
    build(db, workers)
    assert HP.differences(sig, HP.signature(db)) == []
    _spoil_every_link(db)
    assert _rows(db, "SELECT COUNT(*) FROM pkt WHERE " + NOTHING) == 0 and _rows(db, "SELECT COUNT(*) FROM cmd WHERE dur_ps IS NULL") == 0
    build(db, workers)
    assert HP.differences(sig, HP.signature(db)) == []
    for t in ("pkt", "lnk", "spl", "ntx"):
        assert _rows(db, "SELECT COUNT(*) FROM %s WHERE parent_level = 'stale' OR relation = 'stale'" % t) == 0
    assert scratch_files(db) == [] and multiprocessing.active_children() == []


@pytest.mark.parametrize("workers", [1, 3])
def test_a_rebuild_with_other_settings_is_a_fresh_build_with_them(loaded, at_once, tmp_path, workers):
    other = {"look_links": 1, "look_splits": 1, "look_cmds": 1}
    fresh = copy_of(loaded, tmp_path, "fresh")
    build(fresh, 1, settings=other)
    again = copy_of(loaded, tmp_path, "again")
    build(again, workers)                                   # first with the usual settings ...
    rep = build(again, workers, settings=other)             # ... then again with the others
    assert rep["settings"] == other
    assert HP.differences(HP.signature(fresh), HP.signature(again)) == []
    back = build(again, workers)                            # and back
    assert back["settings"] == B.settings_of(None)
    usual = copy_of(loaded, tmp_path, "usual")
    build(usual, 1)
    assert HP.differences(HP.signature(usual), HP.signature(again)) == []


# ------------------------------------------------------------------ 8. the progress while the joins run
def test_progress_while_the_joins_run(loaded, one_core, at_once, tmp_path, monkeypatch):
    db = copy_of(loaded, tmp_path, "db")
    monkeypatch.setattr(L, "REPORT_SECONDS", 0.0)
    said = []
    build(db, 3, progress=lambda step, detail, pct: said.append((step, detail, pct)))
    steps = [s for s, _d, _p in said]
    pcts = [p for _s, _d, p in said]
    assert pcts == sorted(pcts) and pcts[-1] == 100.0 and steps[-1] == "tree: finished"
    collecting = steps.index(B.COLLECTING)
    assert collecting > 0 and set(steps[:collecting]) <= set(STEPS)                    # while they run: the step is one of the joins
    after = steps[collecting:]
    assert not set(after) & set(STEPS)                                                  # none had to be run again
    for wanted in (B.COLLECTING, "tree: context rows to command windows", "tree: writing the packet links", "tree: indexing the links", "tree: checking the analyzer's counts"):
        assert wanted in after, wanted
    for _step, detail, _pct in said[:collecting]:
        # the page takes its rows-per-second from the first number of the detail: it must be the row count, or the detail must start with 'still working'
        assert detail.startswith("still working") or re.match(r"[\d,]+ \D+$", detail), detail
    assert any("(at the same time: " in d for _s, d, _p in said[:collecting])
    same_tree(db, one_core)


def test_the_progress_names_the_first_join_still_running():
    class Stand:
        plan = {s: (1000, 1000) for s in STEPS}
        work = 8000
        pct = 0.0

        def __init__(self):
            self.said = []

        def report_to(self, step, detail, pct):
            self.said.append((step, detail, pct))
    b = Stand()
    due = list(B.JOINS)
    import time
    now = time.time()
    running = {"links_to_splits": None, "ntx_to_cmds": None}
    done = {"packets_to_links": {}, "units_to_ntx": {}}
    latest = {"links_to_splits": "500 rows", "ntx_to_cmds": "250 rows"}
    B._say_joins(b, due, running, done, latest, {n: now for n in running}, {n: now - 10 for n in running})
    assert b.said == [("tree: link to split transactions", "500 rows (at the same time: NVMe transactions to commands)", 34.4)]     # (1000 + 500 + 1000 + 250) of 8000
    # nothing heard from it for more than 3 seconds: the detail says so, and the percentage does not go back
    latest["links_to_splits"] = "100 rows"
    B._say_joins(b, due, running, done, latest, {n: now - 5 for n in running}, {n: now - 10 for n in running})
    step, detail, pct = b.said[-1]
    assert step == "tree: link to split transactions" and re.match(r"still working on this step, 1\d s so far \(at the same time: NVMe transactions to commands\)$", detail) and pct == 34.4
    # the last one alone
    del running["links_to_splits"]
    done["links_to_splits"] = {}
    B._say_joins(b, due, running, done, latest, {n: now for n in running}, {n: now - 10 for n in running})
    assert b.said[-1] == ("tree: NVMe transactions to commands", "250 rows", 40.6)


# ------------------------------------------------------------------ 9. stepping back for processor time
def _fake_nice(monkeypatch, now):
    calls = []

    def nice(by):
        calls.append(by)
        return now + by
    monkeypatch.setattr(os, "nice", nice, raising=False)
    return calls


def test_stepping_back_goes_to_a_level_not_by_a_level(monkeypatch):
    monkeypatch.setattr(L, "WINDOWS", False)
    calls = _fake_nice(monkeypatch, 0)
    assert L.step_back(10, whole_process=True) == "nice" and calls == [0, 10]
    calls = _fake_nice(monkeypatch, 5)                      # started by a job that had already stepped back to 5
    assert L.step_back(10, whole_process=True) == "nice" and calls == [0, 5]
    for already in (10, 15):                                # already there or further: nothing more
        calls = _fake_nice(monkeypatch, already)
        assert L.step_back(10, whole_process=True) == "nice" and calls == [0]
    calls = _fake_nice(monkeypatch, 0)
    assert L.step_back(0, whole_process=True) is None and calls == []


def test_stepping_back_never_fails(monkeypatch):
    monkeypatch.setattr(L, "WINDOWS", False)

    def refused(_by):
        raise PermissionError("not allowed")
    monkeypatch.setattr(os, "nice", refused, raising=False)
    assert L.step_back(10, whole_process=True) is None
    monkeypatch.delattr(os, "nice")                         # an operating system without it
    assert L.step_back(10, whole_process=True) is None and L.step_back(5, whole_process=False) is None
    assert L.give_way() is None
    monkeypatch.setattr(L, "open", lambda *a, **k: (_ for _ in ()).throw(FileNotFoundError("no /proc here")), raising=False)
    L.worker_starts()
    L.job_process_starts()


def _fake_windows(monkeypatch, answer=1, broken=False):
    """os.nice gone, and a stand-in for ctypes.windll.kernel32 that notes what it is asked."""
    calls = []

    class Function:
        def __init__(self, name):
            self.name = name

        def __call__(self, *args):
            if broken:
                raise OSError("the call failed")
            calls.append((self.name,) + args)
            return {"GetCurrentProcess": "process", "GetCurrentThread": "thread"}.get(self.name, answer)

    class Kernel:
        def __init__(self):
            self.made = {}

        def __getattr__(self, name):
            return self.made.setdefault(name, Function(name))
    fake = types.SimpleNamespace(windll=types.SimpleNamespace(kernel32=Kernel()), c_void_p="void*", c_uint32="uint32", c_int="int")
    monkeypatch.delattr(os, "nice", raising=False)
    monkeypatch.setattr(L, "WINDOWS", True)
    monkeypatch.setitem(sys.modules, "ctypes", fake)
    return calls


def test_stepping_back_on_windows_uses_the_priority_calls(monkeypatch):
    calls = _fake_windows(monkeypatch)
    assert L.step_back(10, whole_process=True) == "windows"
    assert calls == [("GetCurrentProcess",), ("SetPriorityClass", "process", 0x00004000)]          # BELOW_NORMAL_PRIORITY_CLASS for the whole worker process
    del calls[:]
    assert L.give_way() == "windows"
    assert calls == [("GetCurrentThread",), ("SetThreadPriority", "thread", -1)]                   # THREAD_PRIORITY_BELOW_NORMAL for the job's thread only, never the server
    del calls[:]
    monkeypatch.setattr(L, "open", lambda *a, **k: (_ for _ in ()).throw(FileNotFoundError("no /proc here")), raising=False)
    L.worker_starts()
    assert calls == [("GetCurrentProcess",), ("SetPriorityClass", "process", 0x00004000)]
    assert L.step_back(0, whole_process=True) is None


def test_stepping_back_on_windows_never_fails(monkeypatch):
    _fake_windows(monkeypatch, answer=0)                    # Windows refuses
    assert L.step_back(10, whole_process=True) is None and L.give_way() is None
    _fake_windows(monkeypatch, broken=True)                 # the call itself fails
    assert L.step_back(10, whole_process=True) is None and L.give_way() is None
    monkeypatch.setitem(sys.modules, "ctypes", types.SimpleNamespace())       # no windll at all
    assert L.step_back(10, whole_process=True) is None and L.give_way() is None


def test_the_levels_come_from_the_environment(monkeypatch):
    for given, level in (("0", 0), ("3", 3), ("19", 19), ("99", 19), ("-4", 0), ("", 10), ("ten", 10), (" 7 ", 7), ("2.5", 10)):
        monkeypatch.setenv("F2T_WORKER_NICE", given)
        assert L.niceness("F2T_WORKER_NICE", 10) == level, given
    monkeypatch.delenv("F2T_WORKER_NICE")
    assert L.niceness("F2T_WORKER_NICE", 10) == 10
    monkeypatch.setattr(L, "WINDOWS", False)
    monkeypatch.setattr(L, "open", lambda *a, **k: (_ for _ in ()).throw(FileNotFoundError("not in a test")), raising=False)
    monkeypatch.setenv("F2T_WORKER_NICE", "4")
    monkeypatch.setenv("F2T_JOB_NICE", "2")
    calls = _fake_nice(monkeypatch, 0)
    L.worker_starts()
    assert calls == [0, 4]
    calls = _fake_nice(monkeypatch, 0)
    L.job_process_starts()
    assert calls == [0, 2]
    calls = _fake_nice(monkeypatch, 0)
    assert L.give_way() == "nice" and calls == [0, 2]
    monkeypatch.setenv("F2T_JOB_NICE", "0")                 # 0: not at all
    calls = _fake_nice(monkeypatch, 0)
    assert L.give_way() is None and calls == []


if __name__ == "__main__":
    sys.exit(pytest.main(["-q", "-p", "no:cacheprovider", __file__]))
