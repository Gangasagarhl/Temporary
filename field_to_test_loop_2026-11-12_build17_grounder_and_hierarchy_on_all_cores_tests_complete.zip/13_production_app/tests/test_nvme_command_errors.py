"""The NVMe command errors page (2026-11-12): the catalogue of every completion status, the count per recording, the routes.

Offline: no server, its own temp folder (F2T_TEST_TMP when set). The check of every name and value against the text of
the two NVMe specifications runs when that text is on the computer: set F2T_NVME_SPEC_TEXT to the folder that holds
nvme_base_specification_2.1.txt and nvme_nvm_command_set_specification_1.1.txt (plain text of the public documents; the
text is not shipped with the application). Without it that one test is skipped, with the reason.

    python3 -m pytest -q -p no:cacheprovider tests/test_nvme_command_errors.py
"""
import os
import re
import shutil
import sqlite3
import sys
import tempfile
import types

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(HERE)
for p in (APP_DIR, os.path.join(APP_DIR, "app")):
    if p not in sys.path:
        sys.path.insert(0, p)
from nvme_hier import nvme_command_errors as NE   # noqa: E402

SPEC_DIR = os.environ.get("F2T_NVME_SPEC_TEXT") or ""
BASE_TXT = os.path.join(SPEC_DIR, "nvme_base_specification_2.1.txt")
NVM_TXT = os.path.join(SPEC_DIR, "nvme_nvm_command_set_specification_1.1.txt")


@pytest.fixture
def tmp():
    base = os.environ.get("F2T_TEST_TMP") or None
    if base:
        os.makedirs(base, exist_ok=True)
    d = tempfile.mkdtemp(prefix="nvme_errors_", dir=base)
    yield d
    shutil.rmtree(d, ignore_errors=True)


def _recording(folder, rows):
    """A staging database with the command table as the loader writes it (only the columns the count reads)."""
    os.makedirs(folder, exist_ok=True)
    db = os.path.join(folder, "hier.sqlite")
    con = sqlite3.connect(db)
    con.execute("CREATE TABLE cmd (rowid_file INTEGER, n INTEGER, opc INTEGER, sqid INTEGER, cid INTEGER, sct INTEGER, sc INTEGER, t_ps INTEGER)")
    con.executemany("INSERT INTO cmd (rowid_file, n, opc, sqid, cid, sct, sc) VALUES (?, ?, 2, 1, ?, ?, ?)",
                    [(i + 2, i + 1, i % 64, sct, sc) for i, (sct, sc) in enumerate(rows)])
    con.commit()
    con.close()
    return db


# ---- the catalogue itself

def test_no_status_is_listed_twice():
    seen = set()
    for e in NE.catalogue():
        k = (e["type"], e["code"], e["code_to"], e["scope"])
        assert k not in seen, "listed twice: %s" % (k,)
        seen.add(k)
    # and no value of a type is covered by two rows of the countable part
    for t in range(8):
        cover = {}
        for e in NE.catalogue(fabrics=False):
            if e["type"] == t:
                for v in range(e["code"], e["code_to"] + 1):
                    assert v not in cover, "type %Xh code %02Xh is in two rows: %s and %s" % (t, v, cover[v], e["name"])
                    cover[v] = e["name"]


def test_every_value_of_every_type_has_a_row_or_is_known_to_be_absent():
    absent = {(0, v) for v in range(0x8A, 0x90)}     # Figure 102 names 89h and then "90h to BFh Reserved"
    for t in range(8):
        for v in range(256):
            e = NE.lookup(t, v)
            assert (e is None) == ((t, v) in absent), "type %Xh code %02Xh" % (t, v)


def test_every_entry_is_complete_and_plain():
    c = NE.catalogue()
    assert len(c) > 150
    for e in c:
        assert e["name"] and e["meaning"] and e["where"] and e["address"].startswith("https://nvmexpress.org/")
        assert len(e["meaning"].split()) <= 25, "meaning longer than 25 words: %s" % e["name"]
        assert "Figure %d" % e["figure"] in e["where"] and "Revision 2.1" in e["where"]
        assert e["type_name"], "status code type without its name: %s" % e["name"]
        assert e["kind"] in NE.KIND_WORDS and e["confirmed"] is True
        assert re.fullmatch(r"[0-9A-F]{2}h( to [0-9A-F]{2}h)?", e["code_hex"])
    assert [t["name"] for t in NE.types()] == ["Generic Command Status", "Command Specific Status", "Media and Data Integrity Errors",
                                               "Path Related Status", "Reserved", "Vendor Specific"]


def test_no_time_limit_in_the_catalogue():
    """The owner gives the time limits: nothing here may carry one."""
    for e in NE.catalogue():
        assert not re.search(r"\b\d+(\.\d+)?\s*(ms|milliseconds?|seconds?|s|minutes?|µs|us|ns)\b", e["meaning"]), e["name"]
    assert "limits the owner gives" in NE.NOT_HERE


def test_known_values():
    assert NE.lookup(0, 0)["kind"] == "success" and NE.lookup(0, 0)["name"] == "Successful Completion"
    assert NE.lookup(2, 0x81)["name"] == "Unrecovered Read Error"
    assert NE.lookup(0, 0x07)["name"] == "Command Abort Requested"
    assert NE.lookup(3, 0x71)["name"] == "Command Aborted By Host"
    assert NE.lookup(1, 0x80)["name"] == "Conflicting Attributes"          # the PCIe meaning, not the Fabrics one
    assert NE.lookup(0, 0xC5)["name"] == "Vendor Specific" and NE.lookup(7, 0x12)["name"] == "Vendor Specific"
    assert NE.lookup(5, 0)["kind"] == "reserved"
    assert NE.lookup(None, 1) is None and NE.lookup("x", 1) is None and NE.lookup(0, 0x8B) is None


# ---- names and values against the specification text

def _figure_spans(lines):
    """Figure number -> (first line, line after the last) of the figure in the body of the document (the table of
    contents lines, which end with dot leaders and a page number, are left out)."""
    heads = [(i, int(m.group(1))) for i, l in enumerate(lines)
             for m in [re.match(r"^\s*Figure (\d+): ", l)] if m and "....." not in l]
    spans = {}
    for k, (i, fig) in enumerate(heads):
        end = next((j for j, f in heads[k + 1:] if f != fig), len(lines))
        a, b = spans.get(fig, (i, end))
        spans[fig] = (min(a, i), max(b, end))
    return spans


def _check_figure(lines, span, rows, problems, doc):
    """rows: [(value text as the table writes it, name)] in the table's order. For every row: a line of the figure starts
    with the value, the name starts on that line or at most 6 lines above it, and after the value line of the row before."""
    a, b = span
    floor = a
    for value, name in rows:
        words = name.split()
        lead = " ".join(words[:3])
        val = re.compile(r"^\s*%s\b(?!\s+to\s)" % re.escape(value)) if " to " not in value else re.compile(r"^\s*%s\b" % re.escape(value).replace(r"\ ", r"\s+"))
        iv = next((i for i in range(floor, b) if val.match(lines[i])), None)
        if iv is None:
            problems.append("%s: value %s (%s) not found in its figure after line %d" % (doc, value, name, floor + 1))
            continue
        norm = lambda s: re.sub(r"\s+", " ", s)
        at = [i for i in range(max(floor, iv - 6), iv + 1) if lead in norm(lines[i])]
        if not at:
            problems.append("%s: value %s is at line %d, the name %r is not on it or just above it" % (doc, value, iv + 1, name))
            continue
        found = False
        for start in at:                             # the name starts on one of these lines (its first words may also
            block, pos, found = norm(" ".join(lines[start:min(b, iv + 4)])), 0, True      # come again inside the description)
            for w in words:                          # every word of the name, in order (a name may wrap around the value)
                j = block.find(w, pos)
                if j < 0:
                    found = False
                    break
                pos = j + len(w)
            if found:
                break
        if not found:
            problems.append("%s: value %s, the name %r is not whole in the table row at line %d" % (doc, value, name, iv + 1))
        floor = iv + 1
    return problems


@pytest.mark.skipif(not (os.path.isfile(BASE_TXT) and os.path.isfile(NVM_TXT)),
                    reason="the text of the two NVMe specifications is not on this computer (set F2T_NVME_SPEC_TEXT to its folder)")
def test_every_name_and_value_is_in_the_specification_text():
    with open(BASE_TXT, encoding="utf-8", errors="replace") as f:
        base = f.read().split("\n")
    with open(NVM_TXT, encoding="utf-8", errors="replace") as f:
        nvm = f.read().split("\n")
    spans, nspans = _figure_spans(base), _figure_spans(nvm)
    problems, checked = [], 0
    c = NE.catalogue()
    for fig in (102, 103, 104, 105, 106, 107):
        rows = [(e["code_hex"], e["name"]) for e in c if e["figure"] == fig and not (fig == 103 and e["code"] >= 0xC0)]
        if fig == 103:                                # Figure 103 ends with the two blocks the catalogue takes from elsewhere
            rows += [("80h to BFh", "I/O Command Set Specific"), ("C0h to FFh", "Vendor Specific")]
        assert rows and fig in spans, "Figure %d not found in the base specification text" % fig
        _check_figure(base, spans[fig], rows, problems, "Base 2.1 Figure %d" % fig)
        checked += len(rows)
    # Figure 101: the status code types
    types_rows = [(t["type_hex"], t["name"]) for t in NE.types()]
    _check_figure(base, spans[101], types_rows, problems, "Base 2.1 Figure 101")
    checked += len(types_rows)
    # the NVM Command Set figures the entries point to
    for fig in (17, 18, 19):
        rows = [(e["code_hex"], e["name"]) for e in c if e["nvm_figure"] == fig]
        assert rows and fig in nspans
        # Figure 18 of revision 1.1 writes 89h as "Insufficient Resrouces" (the document's own spelling): compare the first word
        rows = [(v, "Insufficient" if (fig == 18 and v == "89h") else n) for v, n in rows]
        _check_figure(nvm, nspans[fig], rows, problems, "NVM Command Set 1.1 Figure %d" % fig)
        checked += len(rows)
    # the commands the catalogue names for a status are the ones the document writes in that row's neighbourhood
    assert not problems, "\n".join(problems)
    assert checked >= len(c)
    print("names and values found in the specification text: %d rows" % checked)


# ---- the count of one recording

def test_count_gives_the_injected_counts(tmp):
    rows = [(0, 0)] * 40 + [(2, 0x81)] * 3 + [(0, 0x07)] * 2 + [(1, 0x80)] + [(0, 0xC1), (0, 0xC2)] + [(None, None)] * 4 \
        + [(0, 0x8B)] * 2 + [(7, 0x33)] + [(9, 1)] + [(0, None)]
    db = _recording(os.path.join(tmp, "up-1"), rows)
    got = NE.count(db)
    assert got["commands"] == len(rows) == 57
    assert got["successful"] == 40 and got["no_status"] == 4
    seen = got["seen"]
    assert seen["0:0:0"]["commands"] == 40
    assert seen["2:129:129"]["commands"] == 3 and seen["2:129:129"]["first_command"] == 41
    assert seen["0:7:7"]["commands"] == 2 and seen["1:128:128"]["commands"] == 1
    assert seen["0:192:255"]["commands"] == 2 and sorted(x["code_hex"] for x in seen["0:192:255"]["codes"]) == ["C1h", "C2h"]
    assert seen["7:0:255"]["commands"] == 1
    # never dropped: a value no table names, a type that does not exist, a row with half a status
    un = {(u["type"], u["code"]): u for u in got["not_in_catalogue"]}
    assert un[(0, 0x8B)]["commands"] == 2 and un[(9, 1)]["commands"] == 1 and un[(0, None)]["commands"] == 1
    assert "not in the specification's tables" in un[(0, 0x8B)]["why"]
    # every command is in exactly one place
    assert sum(v["commands"] for v in seen.values()) + sum(u["commands"] for u in got["not_in_catalogue"]) + got["no_status"] == len(rows)
    assert got["with_another_status"] == len(rows) - 40 - 4 - 1          # the half status is neither success nor a status
    # the same through an open connection
    con = sqlite3.connect(db)
    try:
        assert NE.count(con)["seen"]["2:129:129"]["commands"] == 3
    finally:
        con.close()


def test_count_of_an_empty_recording(tmp):
    got = NE.count(_recording(os.path.join(tmp, "up-0"), []))
    assert got["commands"] == 0 and got["seen"] == {} and got["not_in_catalogue"] == []


# ---- the routes

@pytest.fixture
def client(tmp):
    from flask import Flask
    from api import nvme_errors_api as A
    app = Flask(__name__)
    app.config["services"] = types.SimpleNamespace(cfg={}, root=tmp)
    app.register_blueprint(A.bp)
    return app.test_client()


def test_route_catalogue(client):
    r = client.get("/api/hier/nvme_command_errors")
    assert r.status_code == 200
    j = r.get_json()
    assert len(j["entries"]) == len(NE.catalogue()) and len(j["types"]) == 6
    assert j["summary"]["not_here"] == NE.NOT_HERE and len(j["summary"]["documents"]) == 2


def test_route_counts_and_unknown_upload(client, tmp):
    _recording(os.path.join(tmp, "uploads", "up-7"), [(0, 0)] * 5 + [(2, 0x81)])
    r = client.get("/api/hier/nvme_command_errors/up-7")
    assert r.status_code == 200
    j = r.get_json()
    assert j["commands"] == 6 and j["seen"]["2:129:129"]["commands"] == 1 and j["upload_id"] == "up-7"
    r = client.get("/api/hier/nvme_command_errors/no-such")
    assert r.status_code == 404 and "no such upload" in r.get_json()["error"]
    os.makedirs(os.path.join(tmp, "uploads", "up-empty"))
    r = client.get("/api/hier/nvme_command_errors/up-empty")
    assert r.status_code == 409 and "not been loaded" in r.get_json()["error"]
    r = client.get("/api/hier/nvme_command_errors/..%2F..")
    assert r.status_code == 404


def test_page_and_script_are_there_and_say_what_is_not_on_the_page():
    page = open(os.path.join(APP_DIR, "app", "static", "nvme_command_errors.html"), encoding="utf-8").read()
    js = open(os.path.join(APP_DIR, "app", "static", "js", "nvme_command_errors.js"), encoding="utf-8").read()
    assert "/static/js/nvme_command_errors.js" in page and "status code type" in page
    assert "No recording chosen" in page and "selected" not in page                # nothing is chosen for the user
    assert "/api/hier/nvme_command_errors" in js and "seen in this recording" in js
    server = open(os.path.join(APP_DIR, "app", "server.py"), encoding="utf-8").read()
    assert '"/nvme-errors"' in server and "nvme_errors_api" in server
