"""Pull source rows back out of the CSV by Packet number (one sequential pass for many ranges)."""
import bisect
import csv

from .schema import Cols


def merge_ranges(ranges):
    out = []
    for lo, hi in sorted(ranges):
        if out and lo <= out[-1][1] + 1:
            out[-1][1] = max(out[-1][1], hi)
        else:
            out.append([lo, hi])
    return out


def extract(csv_path, ranges, payload_path=None):
    """ranges: iterable of (lo_pkt, hi_pkt). Returns header, {pkt: row}.
    Rows are located by Packet value; the export numbers packets consecutively from 0, so the scan stops
    as soon as the last range is passed."""
    rs = merge_ranges(ranges)
    if not rs:
        return None, {}
    starts = [r[0] for r in rs]
    out = {}
    end = rs[-1][1]
    with open(csv_path, newline="", encoding="utf-8-sig", errors="replace", buffering=1 << 22) as f:
        rd = csv.reader(f)
        header = next(rd)
        ip = header.index("Packet")
        # cheap pre-filter on the raw line: the Packet value is the 2nd field
        for row in rd:
            if len(row) <= ip or not row[ip].isdigit():
                continue                    # rows without a packet number carry nothing to show
            p = int(row[ip])
            if p > end:
                break
            i = bisect.bisect_right(starts, p) - 1
            if i >= 0 and p <= rs[i][1]:
                out[p] = row
    if payload_path:
        want = set(out)
        with open(payload_path, newline="", encoding="utf-8") as f:
            rd = csv.reader(f)
            next(rd)
            for r in rd:
                p = int(r[0])
                if p > end:
                    break
                if p in want:
                    out[p] = out[p] + ["PAYLOAD:" + r[2] + ("" if int(r[1]) <= 64 else "...(crc32 %s)" % r[3])]
    return header, out


def compact(header, row, keep_payload=True):
    """'col=value' for the non-empty columns of a row (what an LLM or a human needs to read)."""
    parts = []
    for i, v in enumerate(row):
        if not v:
            continue
        if i < len(header):
            if header[i] in ("Time Delta",):
                continue
            parts.append("%s=%s" % (header[i], v))
        elif keep_payload:
            parts.append(v)
    return " | ".join(parts)
