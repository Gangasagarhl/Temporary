"""The AI reviewer's narrative for the management view of the NVMe commands page, checked by code.

When it is called: once per kind of command that went wrong, after commands.build() has computed the facts
(counts, statuses, who is responsible by the specification, the parameter contrasts, the packets, the timing).
What it gets: only those facts.  What it must return: a headline, what happens, what to tell the team, in plain words,
inside a strict JSON schema.  What the code checks: every number in the answer must appear in the facts, and the
answer must not name a command, a status or a side that the facts do not name.  An answer that fails the check is
replaced by the sentences built from the facts (management_lines), and the page says so.  Nothing is trained.
"""
import json
import os
import re
import time

SYSTEM = ("You write for an engineering manager who must decide which team looks at a problem. You are given FACTS "
          "about one kind of NVMe command measured in one PCIe capture. Use ONLY those facts. Do not invent numbers, "
          "causes, commands or sides. Where the facts say an association is not a proven cause, say 'associated with', "
          "not 'caused by'. Plain words, no abbreviations without their meaning, at most 120 words in total.")
SCHEMA = {"type": "object", "additionalProperties": False,
          "properties": {"headline": {"type": "string", "description": "one sentence: which command, how often it went wrong, who the specification points at"},
                         "what_happens": {"type": "string", "description": "two or three sentences: the status, the parameters associated with the failures, the packets under them, the time against the usual and the limit"},
                         "tell_the_team": {"type": "string", "description": "one or two sentences: what to look at first and why, from the facts only"}},
          "required": ["headline", "what_happens", "tell_the_team"]}
NUM_RX = re.compile(r"\d[\d,]*(?:\.\d+)?")          # 2,108,560 · 19.4 · 08 (from 0x08)


def facts_for_model(m):
    keep = {k: m[k] for k in ("kind", "klass", "opcode", "called", "went_wrong", "failed_status", "never_completed",
                              "packet_errors_on_successful", "over_host_limit", "statuses", "responsible", "separating",
                              "lba", "packets", "defects", "timing", "lines")}
    keep["defects"] = ["Defect %d" % int(d.split("-")[1]) if str(d).startswith("INC-") else d for d in m.get("defects", [])]
    keep["rate_percent"] = round(100 * m["rate"])
    keep["rate_interval_percent"] = [round(100 * m["rate_ci"][0]), round(100 * m["rate_ci"][1])]
    return keep


def numbers_in(obj):
    out = set()
    if isinstance(obj, dict):
        for v in obj.values():
            out |= numbers_in(v)
    elif isinstance(obj, (list, tuple)):
        for v in obj:
            out |= numbers_in(v)
    elif isinstance(obj, bool):
        pass
    elif isinstance(obj, (int, float)):
        out.add(("%g" % obj).replace(".0", "") if isinstance(obj, float) else str(obj))
        if isinstance(obj, float):
            out.add("%.1f" % obj)
            out.add("%.3f" % obj)
    elif isinstance(obj, str):
        for n in NUM_RX.findall(obj):
            out.add(n.replace(",", "").rstrip(","))
    return out


def _num(s_):
    try:
        return float(s_.replace(",", ""))
    except ValueError:
        return None


def check(answer, facts):
    """True when every number in the answer appears in the facts (compared as values, so 08 = 8 and 5 = 5.0),
    no side is named that the facts never mention, no cause is asserted, and the text is short."""
    text = " ".join(str(answer.get(k, "")) for k in ("headline", "what_happens", "tell_the_team"))
    allowed = {_num(x) for x in numbers_in(facts)} - {None}
    for n in NUM_RX.findall(text):
        v = _num(n)
        if v is None or v not in allowed:
            return False, "number %s is not in the facts" % n
    facts_text = json.dumps(facts).lower()
    for side in ("host", "device", "link", "platform"):
        if re.search(r"\b%s\b" % side, text, re.I) and side not in facts_text:
            return False, "names a side the facts do not: %s" % side
    if len(text.split()) > 200:
        return False, "too long"
    # the facts only ever establish associations and the specification's assignment of a status code; an answer
    # that asserts a cause of its own is not grounded
    for phrase in ("caused by", "the cause is", "root cause", "because the firmware", "bug in", "is the cause",
                   "due to a bug", "faulty", "defective"):
        if phrase in text.lower():
            return False, "asserts a cause the facts do not establish (%r)" % phrase
    return True, "ok"


def ask_model(backend, model, facts, timeout=120):
    """One schema-constrained call through the stage-1 reviewer's transports. Returns (answer | None, info)."""
    from . import llm as L
    prompt = "FACTS (JSON):\n" + json.dumps(facts, indent=1) + "\n\nWrite the headline, what happens and what to tell the team."
    if backend == "cli":
        return L.cli_structured("claude", model, SYSTEM, SCHEMA, prompt, timeout=timeout)
    if backend == "sdk":
        client = L.sdk_client(max_retries=2)
        try:
            resp = client.messages.create(model=model, max_tokens=800, system=SYSTEM,
                                          messages=[{"role": "user", "content": prompt}],
                                          output_config={"effort": "low", "format": {"type": "json_schema", "schema": SCHEMA}})
            txt = "".join(getattr(b, "text", "") for b in resp.content)
            return json.loads(txt), {"input_tokens": resp.usage.input_tokens, "output_tokens": resp.usage.output_tokens}
        except Exception as e:                      # noqa: BLE001 - any transport failure falls back to the template
            return None, {"error": L.failure_text(e)[:300]}
    return None, {"error": "no model (backend %s)" % backend}


def narrate(run_dir, backend="dry-run", model="claude-haiku-5-5", limit=12):
    """Attach a narrative to every management entry of command_summary.json; write command_narratives.jsonl."""
    p = os.path.join(run_dir, "command_summary.json")
    if not os.path.exists(p):
        return 0
    summ = json.load(open(p, encoding="utf-8"))
    n_model = n_ok = 0
    log = open(os.path.join(run_dir, "command_narratives.jsonl"), "w", encoding="utf-8")
    for i, m in enumerate(summ.get("management", [])):
        facts = facts_for_model(m)
        answer, info, src = None, {}, "sentences built from the facts (no model: backend %s)" % backend
        if backend in ("cli", "sdk") and i < limit:
            t0 = time.time()
            answer, info = ask_model(backend, model, facts)
            info["seconds"] = round(time.time() - t0, 1)
            n_model += 1
            if answer:
                ok, why = check(answer, facts)
                info["check"] = why
                if ok:
                    src = "AI reviewer (%s), checked by code: every number and side is in the facts" % model
                    n_ok += 1
                else:
                    answer = None
                    src = "sentences built from the facts (the AI reviewer's answer was rejected: %s)" % why
            else:
                src = "sentences built from the facts (no answer from the AI reviewer: %s)" % info.get("error", "?")
        m["narrative"] = answer or {"headline": m["lines"][0], "what_happens": " ".join(m["lines"][1:-1]) if len(m["lines"]) > 2 else "",
                                    "tell_the_team": m["lines"][-1] if len(m["lines"]) > 1 else ""}
        m["narrative_source"] = src
        log.write(json.dumps({"kind": m["kind"], "source": src, "answer": answer, "info": info}) + "\n")
    log.close()
    summ["narrative"] = {"backend": backend, "model": model if backend in ("cli", "sdk") else None,
                         "model_calls": n_model, "accepted": n_ok}
    json.dump(summ, open(p, "w", encoding="utf-8"), indent=1)
    print("narratives: %d kinds, %d model calls, %d accepted by the check" % (len(summ.get("management", [])), n_model, n_ok), flush=True)
    return len(summ.get("management", []))
