"""The per-command view of a capture: every NVMe command that ended, its parameters, its timing and the
low-level PCIe packets that went wrong under it.

Input (written by the engine during the first read): <run>/commands.jsonl, one line per command, and the findings
(findings.pkl) plus the isolated defects (incidents.json) so that each packet-level error can be shown against the
command it belongs to.  Output: <run>/command_summary.json, read by the "NVMe commands" page.

What is a specification fact and what is a measurement:
  * the parameters of each command come from the submission entry as the NVMe Base Specification 2.0 (admin
    commands, chapter 5) and the NVM Command Set Specification 1.0 (I/O commands, section 3) define them;
  * the latency of each step is measured from the capture's own timestamps;
  * the NVMe specification sets no time limit for a command.  The limits used for the word "over the limit" are the
    host driver's (Linux nvme_core: io_timeout 30 s, admin_timeout 60 s).  The words "slowest 1 %" and "slowest
    10 %" rank the command inside this capture only (p99 and p90 of its own kind).  Readiness and resume budgets
    (CAP.TO, CRTO, RTD3R/RTD3E, ENLAT/EXLAT) are specification values and are applied by the engine's rules.
"""
import collections
import csv
import json
import math
import os
import pickle

from .engine import ADMIN_NAMES, IO_NAMES, MS, SEC, US, opc_name
from .rules import RULES

# ---------------------------------------------------------------------------------------------------------- limits
HOST_LIMIT = {"io": 30 * SEC, "admin": 60 * SEC}
HOST_LIMIT_SOURCE = ("Linux NVMe host driver, drivers/nvme/host/core.c: nvme_core.io_timeout = 30 s, "
                     "nvme_core.admin_timeout = 60 s (the NVMe specification sets no per-command limit)")
LONG_BY_NATURE = {0x80: "Format NVM", 0x84: "Sanitize", 0x14: "Device Self-test", 0x10: "Firmware Commit",
                  0x11: "Firmware Image Download"}
LONG_BY_NATURE_NOTE = ("works on the whole media or the firmware image (NVMe Base 2.0 chapter 5); hosts give these "
                       "commands longer timeouts than ordinary admin commands")

# ------------------------------------------------------------------------------------------ bucket edges (display)
# The bucket edges are the ones the driver team's Trace Vision screens use, so the two tools can be compared.
LAT_BUCKETS = [(0, 10), (10, 20), (20, 30), (30, 40), (40, 50), (50, 60), (60, 70), (70, 80), (80, 90), (90, 100),
               (100, None)]                                                              # microseconds
INTERVAL_BUCKETS = [(0, 0.01), (0.01, 0.1), (0.1, 1), (1, 2), (2, 10), (10, 100), (100, 1000), (1000, 10000),
                    (10000, 20000), (20000, None)]                                       # milliseconds
SIZE_BUCKETS = [("N < 4K", 0, 4096 - 1), ("4K", 4096, 4096), ("4K < N ≤ 8K", 4097, 8192), ("8K < N ≤ 16K", 8193, 16384),
                ("16K < N ≤ 32K", 16385, 32768), ("32K < N ≤ 64K", 32769, 65536), ("64K < N ≤ 128K", 65537, 131072),
                ("128K < N ≤ 256K", 131073, 262144), ("256K < N ≤ 512K", 262145, 524288),
                ("512K < N ≤ 1024K", 524289, 1048576), ("1024K < N", 1048577, None)]
QD_BUCKETS = [("1", 0, 1), ("2", 2, 2), ("3-4", 3, 4), ("5-8", 5, 8), ("9-16", 9, 16), ("17-32", 17, 32),
              ("33-64", 33, 64), ("65+", 65, None)]

# ----------------------------------------------------------------------------------------- status code meanings
# NVMe Base Specification 2.0, Completion Queue Entry, Status Field: SCT = Status Code Type, SC = Status Code
SCT_WORDS = {0: "generic command status", 1: "command specific status", 2: "media and data integrity error",
             3: "path related status", 7: "vendor specific"}
SC_GENERIC = {0x00: "Successful Completion", 0x01: "Invalid Command Opcode", 0x02: "Invalid Field in Command",
              0x03: "Command ID Conflict", 0x04: "Data Transfer Error",
              0x05: "Commands Aborted due to Power Loss Notification", 0x06: "Internal Error",
              0x07: "Command Abort Requested", 0x08: "Command Aborted due to SQ Deletion",
              0x09: "Command Aborted due to Failed Fused Command", 0x0A: "Command Aborted due to Missing Fused Command",
              0x0B: "Invalid Namespace or Format", 0x0C: "Command Sequence Error", 0x0D: "Invalid SGL Segment Descriptor",
              0x0E: "Invalid Number of SGL Descriptors", 0x0F: "Data SGL Length Invalid",
              0x10: "Metadata SGL Length Invalid", 0x11: "SGL Descriptor Type Invalid",
              0x12: "Invalid Use of Controller Memory Buffer", 0x13: "PRP Offset Invalid",
              0x14: "Atomic Write Unit Exceeded", 0x15: "Operation Denied", 0x16: "SGL Offset Invalid",
              0x18: "Host Identifier Inconsistent Format", 0x19: "Keep Alive Timer Expired",
              0x1A: "Keep Alive Timeout Invalid", 0x1B: "Command Aborted due to Preempt and Abort",
              0x1C: "Sanitize Failed", 0x1D: "Sanitize In Progress", 0x1E: "SGL Data Block Granularity Invalid",
              0x1F: "Command Not Supported for Queue in CMB", 0x20: "Namespace is Write Protected",
              0x21: "Command Interrupted", 0x22: "Transient Transport Error",
              0x23: "Command Prohibited by Command and Feature Lockdown", 0x24: "Admin Command Media Not Ready",
              0x80: "LBA Out of Range", 0x81: "Capacity Exceeded", 0x82: "Namespace Not Ready",
              0x83: "Reservation Conflict", 0x84: "Format In Progress", 0x85: "Invalid Value Size",
              0x86: "Invalid Key Size", 0x87: "KV Key Does Not Exist", 0x88: "Unrecovered Error", 0x89: "Key Exists"}
SC_SPECIFIC = {0x00: "Completion Queue Invalid", 0x01: "Invalid Queue Identifier", 0x02: "Invalid Queue Size",
               0x03: "Abort Command Limit Exceeded", 0x05: "Asynchronous Event Request Limit Exceeded",
               0x06: "Invalid Firmware Slot", 0x07: "Invalid Firmware Image", 0x08: "Invalid Interrupt Vector",
               0x09: "Invalid Log Page", 0x0A: "Invalid Format", 0x0B: "Firmware Activation Requires Conventional Reset",
               0x0C: "Invalid Queue Deletion", 0x0D: "Feature Identifier Not Saveable", 0x0E: "Feature Not Changeable",
               0x0F: "Feature Not Namespace Specific", 0x10: "Firmware Activation Requires NVM Subsystem Reset",
               0x11: "Firmware Activation Requires Controller Level Reset",
               0x12: "Firmware Activation Requires Maximum Time Violation", 0x13: "Firmware Activation Prohibited",
               0x14: "Overlapping Range", 0x15: "Namespace Insufficient Capacity",
               0x16: "Namespace Identifier Unavailable", 0x18: "Namespace Already Attached",
               0x19: "Namespace Is Private", 0x1A: "Namespace Not Attached", 0x1B: "Thin Provisioning Not Supported",
               0x1C: "Controller List Invalid", 0x1D: "Device Self-test In Progress",
               0x1E: "Boot Partition Write Prohibited", 0x1F: "Invalid Controller Identifier",
               0x20: "Invalid Secondary Controller State", 0x21: "Invalid Number of Controller Resources",
               0x22: "Invalid Resource Identifier", 0x23: "Sanitize Prohibited While Persistent Memory Region is Enabled",
               0x24: "ANA Group Identifier Invalid", 0x25: "ANA Attach Failed", 0x80: "Conflicting Attributes",
               0x81: "Invalid Protection Information", 0x82: "Attempted Write to Read Only Range",
               0x83: "Command Size Limit Exceeded"}
SC_MEDIA = {0x80: "Write Fault", 0x81: "Unrecovered Read Error", 0x82: "End-to-end Guard Check Error",
            0x83: "End-to-end Application Tag Check Error", 0x84: "End-to-end Reference Tag Check Error",
            0x85: "Compare Failure", 0x86: "Access Denied", 0x87: "Deallocated or Unwritten Logical Block"}
SC_PATH = {0x00: "Internal Path Error", 0x01: "Asymmetric Access Persistent Loss", 0x02: "Asymmetric Access Inaccessible",
           0x03: "Asymmetric Access Transition", 0x60: "Controller Pathing Error", 0x70: "Host Pathing Error",
           0x71: "Command Aborted By Host"}


# Who acted wrongly, by the status code definitions (NVMe Base 2.0 section 4.2): a generic status that names an
# invalid request points at the host; a media and data integrity error points at the device; path status at the
# fabric or platform.  Each entry: (side, what it means in plain words).
WHO_GENERIC = {0x01: ("host", "sent an opcode the controller does not support"), 0x02: ("host", "sent a field value the controller rejects"),
               0x03: ("host", "reused a command identifier that was still in use"), 0x04: ("link", "the data transfer itself failed"),
               0x05: ("platform", "power loss notification aborted it"), 0x06: ("device", "the controller reported an internal error"),
               0x07: ("host", "asked the controller to abort it"), 0x08: ("host", "deleted the queue it was on"),
               0x09: ("host", "the paired fused command failed"), 0x0A: ("host", "the paired fused command was missing"),
               0x0B: ("host", "named a namespace or format that is invalid"), 0x0C: ("host", "sent it out of the required sequence"),
               0x0D: ("host", "sent an invalid SGL descriptor"), 0x0E: ("host", "sent an invalid number of SGL descriptors"),
               0x0F: ("host", "sent an invalid data SGL length"), 0x10: ("host", "sent an invalid metadata SGL length"),
               0x11: ("host", "sent an invalid SGL descriptor type"), 0x12: ("host", "misused the controller memory buffer"),
               0x13: ("host", "sent an invalid PRP offset"), 0x14: ("host", "exceeded the atomic write unit"),
               0x15: ("device", "the controller denied the operation"), 0x16: ("host", "sent an invalid SGL offset"),
               0x19: ("host", "let the keep-alive timer expire"), 0x1B: ("host", "pre-empted and aborted it"),
               0x1C: ("device", "a sanitize operation failed"), 0x1D: ("host", "sent it while sanitize was in progress"),
               0x20: ("host", "wrote to a write-protected namespace"), 0x21: ("device", "the controller interrupted it"),
               0x22: ("link", "a transient transport error"), 0x24: ("device", "the media was not ready for the admin command"),
               0x80: ("host", "addressed a block beyond the namespace"), 0x81: ("host", "exceeded the capacity"),
               0x82: ("device", "the namespace was not ready"), 0x83: ("host", "conflicted with a reservation"),
               0x84: ("host", "sent it while a format was in progress")}
WHO_SPECIFIC = {k: ("host", "sent invalid queue or feature parameters") for k in range(0x00, 0x10)}
WHO_SPECIFIC.update({0x10: ("device", "the firmware activation needs a reset"), 0x11: ("device", "the firmware activation needs a reset"),
                     0x12: ("device", "the firmware activation exceeded its maximum time"), 0x13: ("device", "firmware activation is prohibited"),
                     0x1D: ("host", "sent it while a self-test was in progress"), 0x80: ("host", "sent conflicting attributes"),
                     0x81: ("host", "sent invalid protection information"), 0x82: ("host", "wrote to a read-only range"),
                     0x83: ("host", "exceeded the command size limit")})
WHO_MEDIA = {0x80: ("device", "the media could not be written"), 0x81: ("device", "the media could not be read"),
             0x82: ("data", "the end-to-end guard check failed"), 0x83: ("data", "the end-to-end application tag check failed"),
             0x84: ("data", "the end-to-end reference tag check failed"), 0x85: ("data", "the compare found different data"),
             0x86: ("device", "access to the data was denied"), 0x87: ("host", "read a block that was never written or was deallocated")}
WHO_BASIS = "NVMe Base 2.0 section 4.2 (status code definitions: generic invalid-request codes name the host, media and data integrity codes name the device)"


def who_by_status(status):
    """(side, plain reason) for a failed status, by the specification's definition of the code."""
    if not status:
        return None, None
    sct, sc, _ = status
    if sct == 0 and sc == 0:
        return None, None
    table = {0: WHO_GENERIC, 1: WHO_SPECIFIC, 2: WHO_MEDIA}.get(sct)
    if sct == 3:
        return "platform", "a path or fabric problem"
    if table and sc in table:
        return table[sc]
    return "undetermined", "a status code the page has no plain words for"


def wilson(k, n, z=1.96):
    """95 % confidence interval of a rate k/n (Wilson 1927); the same bound the lab check uses."""
    if not n:
        return (0.0, 0.0)
    p = k / n
    d = 1 + z * z / n
    c = p + z * z / (2 * n)
    s = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return (max(0.0, (c - s) / d), min(1.0, (c + s) / d))


def status_words(status):
    """(sct, sc, dnr) -> plain words with the specification name of the status code."""
    if not status:
        return "no completion"
    sct, sc, dnr = status
    if sct == 0 and sc == 0:
        return "Successful Completion"
    table = {0: SC_GENERIC, 1: SC_SPECIFIC, 2: SC_MEDIA, 3: SC_PATH}.get(sct, {})
    name = table.get(sc, "status code 0x%02X" % sc)
    return "%s (%s, SCT %d SC 0x%02X%s)" % (name, SCT_WORDS.get(sct, "type %d" % sct), sct, sc,
                                            ", do not retry" if dnr else "")


# -------------------------------------------------------------------------------------- parameters per command
FID_NAMES = {0x01: "Arbitration", 0x02: "Power Management", 0x03: "LBA Range Type", 0x04: "Temperature Threshold",
             0x05: "Error Recovery", 0x06: "Volatile Write Cache", 0x07: "Number of Queues",
             0x08: "Interrupt Coalescing", 0x09: "Interrupt Vector Configuration", 0x0A: "Write Atomicity Normal",
             0x0B: "Asynchronous Event Configuration", 0x0C: "Autonomous Power State Transition",
             0x0D: "Host Memory Buffer", 0x0E: "Timestamp", 0x0F: "Keep Alive Timer",
             0x10: "Host Controlled Thermal Management", 0x11: "Non-Operational Power State Config",
             0x12: "Read Recovery Level Config", 0x13: "Predictable Latency Mode Config",
             0x14: "Predictable Latency Mode Window", 0x15: "LBA Status Information Report Interval",
             0x16: "Host Behavior Support", 0x17: "Sanitize Config", 0x18: "Endurance Group Event Configuration",
             0x19: "I/O Command Set Profile", 0x1A: "Spinup Control", 0x7D: "Enhanced Controller Metadata",
             0x7E: "Controller Metadata", 0x7F: "Namespace Metadata", 0x80: "Software Progress Marker",
             0x81: "Host Identifier", 0x82: "Reservation Notification Mask", 0x83: "Reservation Persistence",
             0x84: "Namespace Write Protection Config"}
LID_NAMES = {0x01: "Error Information", 0x02: "SMART / Health Information", 0x03: "Firmware Slot Information",
             0x04: "Changed Namespace List", 0x05: "Commands Supported and Effects", 0x06: "Device Self-test",
             0x07: "Telemetry Host-Initiated", 0x08: "Telemetry Controller-Initiated", 0x09: "Endurance Group Information",
             0x0A: "Predictable Latency Per NVM Set", 0x0B: "Predictable Latency Event Aggregate",
             0x0C: "Asymmetric Namespace Access", 0x0D: "Persistent Event Log", 0x0E: "LBA Status Information",
             0x0F: "Endurance Group Event Aggregate", 0x10: "Media Unit Status",
             0x11: "Supported Capacity Configuration List", 0x12: "Feature Identifiers Supported and Effects",
             0x13: "NVMe-MI Commands Supported and Effects", 0x14: "Command and Feature Lockdown",
             0x15: "Boot Partition", 0x16: "Rotational Media Information", 0x70: "Discovery",
             0x80: "Reservation Notification", 0x81: "Sanitize Status"}
CNS_NAMES = {0x00: "Identify Namespace", 0x01: "Identify Controller", 0x02: "Active Namespace ID list",
             0x03: "Namespace Identification Descriptor list", 0x04: "NVM Set list",
             0x05: "I/O Command Set specific Identify Namespace", 0x06: "I/O Command Set specific Identify Controller",
             0x07: "Active Namespace ID list (I/O Command Set)", 0x08: "I/O Command Set independent Identify Namespace",
             0x10: "Allocated Namespace ID list", 0x11: "Identify Namespace (allocated)",
             0x12: "Controllers attached to the namespace", 0x13: "Controller list",
             0x14: "Primary Controller Capabilities", 0x15: "Secondary Controller list",
             0x16: "Namespace Granularity list", 0x17: "UUID list", 0x18: "Domain list", 0x19: "Endurance Group list",
             0x1A: "Allocated Namespace ID list (I/O Command Set)", 0x1B: "Identify Namespace (allocated, I/O Command Set)",
             0x1C: "I/O Command Set data structure"}
ACCESS_LATENCY = {0: "none", 1: "idle", 2: "normal", 3: "low"}
ACCESS_FREQ = {0: "no frequency information", 1: "typical", 2: "infrequent writes and reads",
               3: "infrequent writes, frequent reads", 4: "frequent writes, infrequent reads",
               5: "frequent writes and reads", 6: "one-time read", 7: "speculative read", 8: "will be overwritten"}
SES_WORDS = {0: "no secure erase", 1: "user data erase", 2: "cryptographic erase"}
SANACT_WORDS = {1: "exit failure mode", 2: "block erase", 3: "overwrite", 4: "crypto erase"}

NVME_BASE = "NVMe Base 2.0 chapter 5, "
NVM_CS = "NVM Command Set 1.0 section 3.2, "


def _bits(v, hi, lo):
    return (v >> lo) & ((1 << (hi - lo + 1)) - 1)


def param_rows(rec):
    """The parameters of one command as the specification names them: list of [name, value, plain words, source]."""
    sqid, opc, dw = rec["sqid"], rec["opc"], rec.get("dw") or [0] * 6
    dw = list(dw) + [0] * (6 - len(dw))
    d10, d11, d12, d13, d14, d15 = dw[:6]
    nsid = rec.get("nsid")
    lb = rec.get("lba_bytes") or 512
    rows = []

    def add(name, value, plain, src):
        rows.append([name, value, plain, src])
    if sqid != 0:
        src = NVM_CS + IO_NAMES.get(opc, "opcode 0x%02X" % opc)
        if opc in (0x00,):
            add("NSID", "all namespaces" if nsid == 0xFFFFFFFF else nsid, "which namespace is flushed", src)
        if opc in (0x01, 0x02, 0x04, 0x05, 0x08, 0x0C, 0x7D):
            add("NSID", nsid, "the namespace the blocks belong to", src)
            slba = rec.get("slba") or 0
            nlb = rec.get("nlb") or 0
            add("SLBA", slba, "starting logical block address", src)
            add("NLB", nlb, "number of logical blocks (0-based field + 1)", src)
            add("bytes", nlb * lb, "NLB x LBA data size (%d B from Identify Namespace LBADS)" % lb, src)
            add("FUA", bool(_bits(d12, 30, 30)), "Force Unit Access: write through to the media before completing", src)
            add("LR", bool(_bits(d12, 31, 31)), "Limited Retry: do not spend extra time on error recovery", src)
            if _bits(d12, 29, 26):
                add("PRINFO", "0x%X" % _bits(d12, 29, 26), "protection information check and pass-through bits", src)
            if opc == 0x08:
                add("DEAC", bool(_bits(d12, 25, 25)), "Deallocate: the zeroed blocks may be deallocated", src)
            if opc in (0x01, 0x02, 0x7D):
                dsm = d13 & 0xFF
                if dsm:
                    add("DSM access latency", ACCESS_LATENCY.get(_bits(dsm, 5, 4)),
                        "a hint from the host, not a limit (DSM bits 5:4)", src)
                    add("DSM access frequency", ACCESS_FREQ.get(dsm & 0xF, "value %d" % (dsm & 0xF)),
                        "a hint from the host (DSM bits 3:0)", src)
                    add("DSM sequential request", bool(_bits(dsm, 6, 6)), "part of a sequential run (bit 6)", src)
                    add("DSM incompressible", bool(_bits(dsm, 7, 7)), "data is not compressible (bit 7)", src)
                if opc == 0x01 and _bits(d13, 31, 16):
                    add("DSPEC", _bits(d13, 31, 16), "directive specific value (stream identifier)", src)
            add("data pointer", "PRP1 0x%X%s" % (rec.get("prp1") or 0,
                                                 (", PRP2 0x%X" % rec["prp2"]) if rec.get("prp2") else ""),
                "host memory the data moves to or from (PRP entries, NVMe Base 2.0 section 4.1)", src)
        elif opc == 0x09:
            add("NSID", nsid, "namespace of the ranges", src)
            add("NR", (d10 & 0xFF) + 1, "number of LBA ranges in the list (0-based field + 1)", src)
            add("AD", bool(_bits(d11, 2, 2)), "Deallocate: the ranges may be deallocated (trim)", src)
            add("IDW", bool(_bits(d11, 1, 1)), "Integral Dataset for Write hint", src)
            add("IDR", bool(_bits(d11, 0, 0)), "Integral Dataset for Read hint", src)
            for i, (slba, nlb) in enumerate(rec.get("ranges") or []):
                add("range %d" % (i + 1), "LBA %d, %d blocks (%d B)" % (slba, nlb, nlb * lb),
                    "one LBA range from the command's data (context attributes, length, starting LBA)", src)
        elif opc in (0x0D, 0x0E, 0x11, 0x15):
            add("NSID", nsid, "namespace of the reservation", src)
            if opc == 0x0D:
                add("RREGA", d10 & 7, "0 register, 1 unregister, 2 replace key", src)
            if opc == 0x11:
                add("RACQA", d10 & 7, "0 acquire, 1 preempt, 2 preempt and abort", src)
                add("RTYPE", _bits(d10, 15, 8), "reservation type", src)
            if opc == 0x15:
                add("RRELA", d10 & 7, "0 release, 1 clear", src)
                add("RTYPE", _bits(d10, 15, 8), "reservation type", src)
            if opc == 0x0E:
                add("NUMD", d10 + 1, "dwords of report data (0-based field + 1)", src)
        elif opc == 0x19:
            add("NSID", nsid, "namespace of the copy", src)
            add("SDLBA", d10 | d11 << 32, "starting destination LBA", src)
            add("NR", (d12 & 0xFF) + 1, "number of source ranges", src)
            add("DESC format", _bits(d12, 11, 8), "source range descriptor format", src)
        elif opc in (0x79, 0x7A):
            add("NSID", nsid, "zoned namespace", src)
            add("SLBA", d10 | d11 << 32, "lowest LBA of the zone", src)
            if opc == 0x79:
                add("ZSA", d13 & 0xFF, "zone send action (1 close, 2 finish, 3 open, 4 reset, 5 offline, 16 set descriptor extension)", src)
                add("Select All", bool(_bits(d13, 8, 8)), "apply to all zones", src)
            else:
                add("NUMD", d12 + 1, "dwords of zone report data", src)
                add("ZRA", d13 & 0xFF, "zone receive action", src)
        else:
            add("NSID", nsid, "namespace", src)
            add("CDW10..15", " ".join("0x%08X" % x for x in dw), "command dwords as sent (no decoder for this opcode)", src)
    else:
        src = NVME_BASE + ADMIN_NAMES.get(opc, "opcode 0x%02X" % opc)
        if opc in (0x00, 0x04):
            add("QID", d10 & 0xFFFF, "queue identifier to delete", src)
        elif opc in (0x01, 0x05):
            add("QID", d10 & 0xFFFF, "queue identifier", src)
            add("QSIZE", (d10 >> 16) + 1, "queue size in entries (0-based field + 1; the maximum is 65536)", src)
            add("PC", bool(d11 & 1), "physically contiguous", src)
            if opc == 0x01:
                add("QPRIO", _bits(d11, 2, 1), "queue priority (0 urgent, 1 high, 2 medium, 3 low)", src)
                add("CQID", d11 >> 16, "completion queue the submission queue reports to", src)
                if _bits(d12, 15, 0):
                    add("NVMSETID", _bits(d12, 15, 0), "NVM Set identifier", src)
            else:
                add("IEN", bool(_bits(d11, 1, 1)), "interrupts enabled", src)
                add("IV", d11 >> 16, "interrupt vector (MSI-X)", src)
            add("base", "0x%X" % (rec.get("prp1") or 0), "host memory base of the queue (PRP1)", src)
        elif opc == 0x02:
            lid = d10 & 0xFF
            add("LID", "0x%02X %s" % (lid, LID_NAMES.get(lid, "")), "log page identifier", src)
            numd = ((d11 & 0xFFFF) << 16 | d10 >> 16) + 1
            add("NUMD", numd, "dwords requested (%d B)" % (numd * 4), src)
            add("LSP", _bits(d10, 14, 8), "log specific field", src)
            add("RAE", bool(_bits(d10, 15, 15)), "retain asynchronous event", src)
            add("LPO", d12 | d13 << 32, "log page offset in bytes", src)
        elif opc == 0x06:
            cns = d10 & 0xFF
            add("CNS", "0x%02X %s" % (cns, CNS_NAMES.get(cns, "")), "what to identify", src)
            add("NSID", nsid, "namespace (for namespace structures)", src)
            if d10 >> 16:
                add("CNTID", d10 >> 16, "controller identifier", src)
            if d11 >> 24:
                add("CSI", d11 >> 24, "command set identifier", src)
        elif opc == 0x08:
            add("SQID", d10 & 0xFFFF, "submission queue of the command to abort", src)
            add("CID", d10 >> 16, "command identifier to abort", src)
        elif opc in (0x09, 0x0A):
            fid = d10 & 0xFF
            add("FID", "0x%02X %s" % (fid, FID_NAMES.get(fid, "")), "feature identifier", src)
            if opc == 0x09:
                add("SV", bool(_bits(d10, 31, 31)), "save across power cycles", src)
            else:
                add("SEL", _bits(d10, 10, 8), "0 current, 1 default, 2 saved, 3 supported capabilities", src)
            if opc == 0x09 or True:
                if fid == 0x01:
                    add("AB / LPW / MPW / HPW", "%d / %d / %d / %d" % (d11 & 7, _bits(d11, 15, 8), _bits(d11, 23, 16),
                                                                       _bits(d11, 31, 24)),
                        "arbitration burst (2^n) and low / medium / high priority weights", src)
                elif fid == 0x02:
                    add("PS / WH", "%d / %d" % (d11 & 0x1F, _bits(d11, 7, 5)), "power state and workload hint", src)
                elif fid == 0x06:
                    add("WCE", bool(d11 & 1), "volatile write cache enabled", src)
                elif fid == 0x07:
                    add("NSQR / NCQR", "%d / %d" % ((d11 & 0xFFFF) + 1, (d11 >> 16) + 1),
                        "I/O submission / completion queues requested (0-based fields + 1)", src)
                elif fid == 0x08:
                    add("THR / TIME", "%d / %d x 100 us" % (d11 & 0xFF, _bits(d11, 15, 8)),
                        "interrupt coalescing threshold (entries) and time", src)
                elif fid == 0x09:
                    add("IV / CD", "%d / %s" % (d11 & 0xFFFF, bool(_bits(d11, 16, 16))),
                        "interrupt vector and coalescing disabled", src)
                elif fid == 0x0C:
                    add("APSTE", bool(d11 & 1), "autonomous power state transitions enabled", src)
                elif fid == 0x0F:
                    add("KATO", "%d ms" % d11, "keep alive timeout", src)
                elif fid == 0x0B:
                    add("event mask", "0x%08X" % d11, "which asynchronous events are reported", src)
                elif fid == 0x04:
                    add("TMPTH / TMPSEL / THSEL", "%d K / %d / %d" % (d11 & 0xFFFF, _bits(d11, 19, 16), _bits(d11, 21, 20)),
                        "temperature threshold in kelvin, sensor, over or under", src)
                elif opc == 0x09 and d11:
                    add("CDW11", "0x%08X" % d11, "feature value", src)
        elif opc == 0x0D:
            add("SEL", d10 & 0xF, "0 create, 1 delete", src)
        elif opc == 0x10:
            add("FS / CA", "%d / %d" % (d10 & 7, _bits(d10, 5, 3)), "firmware slot and commit action", src)
        elif opc == 0x11:
            add("NUMD / OFST", "%d / %d" % (d10 + 1, d11), "dwords of image and offset in dwords", src)
        elif opc == 0x14:
            add("STC", d10 & 0xF, "self-test code (1 short, 2 extended, 0xF abort)", src)
        elif opc == 0x15:
            add("SEL", d10 & 0xF, "0 attach, 1 detach", src)
        elif opc in (0x19, 0x1A):
            add("DOPER / DTYPE / DSPEC", "%d / %d / %d" % (d11 & 0xFF, _bits(d11, 15, 8), _bits(d11, 31, 16)),
                "directive operation, type and specific value", src)
        elif opc == 0x80:
            add("LBAF", (d10 & 0xF) | (_bits(d10, 13, 12) << 4), "LBA format index", src)
            add("MSET / PI / PIL", "%d / %d / %d" % (_bits(d10, 4, 4), _bits(d10, 7, 5), _bits(d10, 8, 8)),
                "metadata setting, protection information type and location", src)
            add("SES", SES_WORDS.get(_bits(d10, 11, 9), str(_bits(d10, 11, 9))), "secure erase setting", src)
        elif opc in (0x81, 0x82):
            add("SECP / SPSP", "0x%02X / 0x%04X" % (_bits(d10, 31, 24), _bits(d10, 23, 8)),
                "security protocol and protocol specific field", src)
            add("TL", d11, "transfer length in bytes", src)
        elif opc == 0x84:
            add("SANACT", SANACT_WORDS.get(d10 & 7, str(d10 & 7)), "sanitize action", src)
            add("AUSE / OWPASS / OIPBP / NDAS", "%s / %d / %s / %s" % (bool(_bits(d10, 3, 3)), _bits(d10, 7, 4),
                                                                      bool(_bits(d10, 8, 8)), bool(_bits(d10, 9, 9))),
                "allow unrestricted sanitize exit, overwrite passes, invert pattern, no-deallocate after sanitize", src)
        elif opc in (0x0C, 0x18):
            add("(no parameters)", "", "the command carries no fields beyond its identity", src)
        else:
            add("CDW10..15", " ".join("0x%08X" % x for x in dw), "command dwords as sent (no decoder for this opcode)", src)
    return rows


def param_fields(sqid, opc):
    """The parameter names the specification defines for a command type (for the summary table)."""
    rec = {"sqid": sqid, "opc": opc, "dw": [0] * 6, "nsid": 1, "slba": 0, "nlb": 1, "prp1": 0, "prp2": 0,
           "lba_bytes": 512, "ranges": []}
    return [r[0] for r in param_rows(rec) if not r[0].startswith("range ")]


# ---------------------------------------------------------------------------------------------- measurements
def percentile(sorted_vals, p):
    if not sorted_vals:
        return None
    k = (len(sorted_vals) - 1) * p
    lo, hi = int(math.floor(k)), int(math.ceil(k))
    if lo == hi:
        return sorted_vals[lo]
    return sorted_vals[lo] + (sorted_vals[hi] - sorted_vals[lo]) * (k - lo)


def stats(vals):
    v = sorted(x for x in vals if x is not None)
    if not v:
        return None
    return {"n": len(v), "min": v[0], "p50": percentile(v, .5), "p90": percentile(v, .9), "p99": percentile(v, .99),
            "max": v[-1], "mean": sum(v) / len(v)}


def bucket_counts(values, edges, unit):
    """values in picoseconds -> counts per (lo, hi) bucket expressed in `unit` picoseconds."""
    out = []
    for lo, hi in edges:
        n = sum(1 for v in values if v is not None and v >= lo * unit and (hi is None or v < hi * unit))
        label = ("N < %g" % hi) if lo == 0 else ("%g ≤ N" % lo if hi is None else "%g ≤ N < %g" % (lo, hi))
        out.append({"bucket": label, "count": n})
    return out


def size_bucket_counts(sizes):
    out = []
    for label, lo, hi in SIZE_BUCKETS:
        n = sum(1 for s in sizes if s is not None and s >= lo and (hi is None or s <= hi))
        out.append({"bucket": label, "count": n})
    return out


def qd_bucket_counts(qds):
    out = []
    for label, lo, hi in QD_BUCKETS:
        n = sum(1 for q in qds if q is not None and q >= lo and (hi is None or q <= hi))
        out.append({"bucket": label, "count": n})
    return out


def steps_of(rec):
    """Per-step latency in picoseconds and which side owns the step (NVMe Base 2.0 section 3.3, queue model)."""
    t_db, t_f, t_fd, t_ld, t_c = rec.get("t_db"), rec.get("t_fetch"), rec.get("t_first_data"), rec.get("t_last_data"), rec.get("t_cqe")
    steps = []

    def st(name, a, b, owner, plain):
        steps.append({"step": name, "ps": (b - a) if (a is not None and b is not None and b >= a) else None,
                      "owner": owner, "plain": plain})
    st("doorbell to fetch", t_db, t_f, "device", "the controller reads the submission entry after the tail doorbell")
    st("fetch to first data", t_f, t_fd, "device", "the controller starts moving data (or reading the PRP list)")
    st("data phase", t_fd, t_ld, "link", "all data packets of the command, in both directions")
    st("last data to completion", t_ld if t_ld is not None else t_f, t_c, "device",
       "the controller posts the completion entry after the last data packet (or after the fetch when there is no data)")
    st("doorbell to completion", t_db if t_db is not None else t_f, t_c, "both",
       "what the host waits for: the whole command")
    return steps


def total_latency(rec):
    t0 = rec.get("t_db") if rec.get("t_db") is not None else rec.get("t_fetch")
    t1 = rec.get("t_cqe")
    if t0 is None or t1 is None or t1 < t0:
        if t0 is not None and rec.get("end_t") is not None and rec.get("end") != "cqe":
            return rec["end_t"] - t0          # lost: the time it was outstanding
        return None
    return t1 - t0


def fmt_ps(ps):
    if ps is None:
        return "-"
    if ps >= SEC:
        return "%.3f s" % (ps / SEC)
    if ps >= MS:
        return "%.3f ms" % (ps / MS)
    if ps >= US:
        return "%.1f µs" % (ps / US)
    return "%d ns" % (ps / 1000)


def pieces_of(rec):
    """The data packets remembered for the command as pieces of the transfer: packet, LBA sub-range, bytes, time
    since the fetch."""
    lb = rec.get("lba_bytes") or 512
    pages = rec.get("pages") or []
    out = []
    for item in rec.get("pkts") or []:
        pkt, addr, nbytes, t = item
        page = addr & ~0xFFF if addr is not None else None
        off = None
        if page is not None and page in pages:
            off = pages.index(page) * 4096 + (addr & 0xFFF) - ((rec.get("prp1") or 0) & 0xFFF if pages and pages[0] == ((rec.get("prp1") or 0) & ~0xFFF) else 0)
        lba = (rec.get("slba") or 0) + (off // lb if off is not None and off >= 0 else 0) if rec["sqid"] != 0 else None
        out.append({"pkt": pkt, "bytes": nbytes, "lba": lba if off is not None else None,
                    "blocks": max(1, nbytes // lb) if lb else None,
                    "since_fetch_ps": (t - rec["t_fetch"]) if (t is not None and rec.get("t_fetch") is not None) else None})
    return out


# ---------------------------------------------------------------------------------------------- the build
def _load_findings(run_dir):
    p = os.path.join(run_dir, "findings.pkl")
    if not os.path.exists(p):
        return []
    try:
        from .host_evidence import load_all
        return load_all(run_dir)
    except Exception:
        return pickle.load(open(p, "rb"))


def _defect_index(run_dir):
    """packet -> (defect id, rules of that defect)"""
    p = os.path.join(run_dir, "incidents.json")
    idx = {}
    if not os.path.exists(p):
        return idx
    for inc in json.load(open(p, encoding="utf-8")):
        rules = sorted(inc.get("rules", {}))
        for f in inc.get("findings", []):
            idx.setdefault(f["pkt"], (inc["id"], rules))
            for rp in f.get("related_pkts", []):
                idx.setdefault(rp, (inc["id"], rules))
    return idx


def errors_for(rec, by_pkt, by_cmd, defects):
    """Findings that belong to this command: the ones carrying its identity key, and the ones on its own packets."""
    inst = rec.get("inst")
    seen, out = set(), []
    cands = list(by_cmd.get((rec["sqid"], rec["cid"], inst), []))
    pk = [rec.get(k) for k in ("pkt_db", "pkt_fetch", "pkt_sqe", "pkt_cqe", "end_pkt")]
    pk += [x[0] for x in (rec.get("pkts") or [])]
    for p in pk:
        if p is not None:
            cands += by_pkt.get(p, [])
    for f in cands:
        key = (f[0], f[2])
        if key in seen:
            continue
        seen.add(key)
        rd = RULES.get(f[2], {})
        if rd.get("level") != "DEFECT" or rd.get("tier") == "S":
            continue                      # context rows (queue created, reset) and statistics are not errors
        d = defects.get(f[0])
        out.append({"pkt": f[0], "rule": f[2], "text": RULES.get(f[2], {}).get("text", f[2]),
                    "layer": RULES.get(f[2], {}).get("layer"), "detail": f[4][:200],
                    "defect": d[0] if d else None, "defect_rules": d[1] if d else None})
    out.sort(key=lambda e: e["pkt"])
    return out


def label_for(rec, lat, p90, p99):
    cls = "admin" if rec["sqid"] == 0 else "io"
    if rec.get("end") != "cqe":
        return "no completion (%s)" % (rec.get("lost") or rec.get("end"))
    if lat is None:
        return "not measurable (no doorbell or fetch time in the capture)"
    if lat > HOST_LIMIT[cls]:
        return "over the host's limit (%d s)" % (HOST_LIMIT[cls] // SEC)
    if rec["sqid"] == 0 and rec["opc"] in LONG_BY_NATURE:
        return "long by nature"
    if p99 is not None and lat >= p99 and p99 > 0:
        return "slowest 1 % of its kind in this capture"
    if p90 is not None and lat >= p90 and p90 > 0:
        return "slowest 10 % of its kind in this capture"
    return "typical for its kind in this capture"


def pct(x):
    return "%d %%" % round(100 * x)


def management_lines(f):
    """Plain sentences built only from the facts: what a team lead needs to read."""
    L = []
    lo, hi = f["rate_ci"]
    L.append("%s (%s command, opcode %s) was called %d times; %d went wrong (%s, 95 %% interval %s to %s): %d failed with an error status, %d never completed, %d completed but had a packet-level error under them." %
             (f["kind"], f["klass"], f["opcode"], f["called"], f["went_wrong"], pct(f["rate"]), pct(lo), pct(hi),
              f["failed_status"], f["never_completed"], f["packet_errors_on_successful"]))
    for st_ in f["statuses"]:
        reason = ("the host " + st_["reason"]) if st_["side"] == "host" else st_["reason"]
        who = (" The specification assigns this code to the %s: %s." % (st_["side"], reason)) if st_["side"] else ""
        L.append("%d returned %s.%s" % (st_["count"], st_["status"], who))
    for c in f["separating"]:
        L.append("%d of the %d problems carry %s = %s (%d of %d such commands went wrong, %s); the other values of %s: %d of %d went wrong." %
                 (c["failed"], f["went_wrong"], c["attribute"], c["value"], c["failed"], c["total"], pct(c["rate"]),
                  c["attribute"], c["others_failed"], c["others_total"]))
    if f.get("lba"):
        lb = f["lba"]
        L.append("The problems target LBAs %d to %d (all commands of this kind: %d to %d), in blocks of %s." %
                 (lb["lba_min"], lb["lba_max"], lb["all_lba_min"], lb["all_lba_max"], ", ".join(str(b) for b in lb["blocks"])))
    if f["packets"]:
        L.append("Under them: " + "; ".join("%d x %s (packet%s %s)" % (p["count"], p["text"], "s" if len(p["example_pkts"]) > 1 else "", ", ".join(str(x) for x in p["example_pkts"])) for p in f["packets"]) + ".")
    else:
        L.append("No packet-level error sits under them: the controller answered each one, with the status above.")
    t = f["timing"]
    if t["usual_successful"]:
        L.append("A successful %s in this capture usually takes %s (median of %d); the ones that went wrong took %s to %s; the host's limit is %d s; %s." %
                 (f["kind"], t["usual_successful"], t["successful_n"], t["failed_min"] or "-", t["failed_max"] or "-", t["host_limit_s"], t["spec_note"]))
    else:
        L.append("No successful %s in this capture to compare with; the host's limit is %d s; %s." % (f["kind"], t["host_limit_s"], t["spec_note"]))
    if f["over_host_limit"]:
        L.append("%d exceeded the host's limit." % f["over_host_limit"])
    if f["never_completed"]:
        L.append("%d never completed: the capture shows no completion entry before the end, a reset or a link loss; whether the controller was slow or stuck cannot be read from the packets." % f["never_completed"])
    if f["defects"]:
        L.append("Grouped into %s." % ", ".join("Defect %d" % int(d.split("-")[1]) if d.startswith("INC-") else d for d in f["defects"]))
    if f["responsible"]:
        parts = ", ".join("%d point at the %s" % (v, k) for k, v in sorted(f["responsible"].items(), key=lambda kv: -kv[1]))
        L.append("For the team: by the specification's definition of the status codes returned, %s; start with the side named most often." % parts)
    elif f["never_completed"] or f["packets"]:
        L.append("For the team: no error status was returned, so the status codes name no side; the packet-level findings above say where the packets stopped.")
    return L


def build(run_dir, max_examples=50):
    src = os.path.join(run_dir, "commands.jsonl")
    recs = []
    if os.path.exists(src):
        with open(src, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    recs.append(json.loads(line))
    findings = _load_findings(run_dir)
    by_pkt = collections.defaultdict(list)
    by_cmd = collections.defaultdict(list)
    for f in findings:
        by_pkt[f[0]].append(f)
        for k in f[5]:
            if k and k[0] == "cmd" and len(k) == 4:
                by_cmd[(k[1], k[2], k[3])].append(f)
    defects = _defect_index(run_dir)
    # ---- per command type
    groups = collections.defaultdict(list)
    for r in recs:
        groups[(0 if r["sqid"] == 0 else 1, r["opc"])].append(r)
    # submission intervals per queue (time between consecutive doorbells / fetches) and host gaps
    per_queue = collections.defaultdict(list)
    for r in recs:
        t = r.get("t_db") if r.get("t_db") is not None else r.get("t_fetch")
        if t is not None:
            per_queue[r["sqid"]].append((t, r))
    intervals = {"admin": [], "io": []}
    host_gaps = {"admin": [], "io": []}
    for q, lst in per_queue.items():
        lst.sort(key=lambda x: x[0])
        cls = "admin" if q == 0 else "io"
        for (t0, r0), (t1, r1) in zip(lst, lst[1:]):
            intervals[cls].append(t1 - t0)
            if r0.get("t_cqe") is not None and t1 >= r0["t_cqe"]:
                host_gaps[cls].append(t1 - r0["t_cqe"])
    types = []
    all_rows = []
    for (is_io, opc), lst in sorted(groups.items(), key=lambda kv: (kv[0][0], -len(kv[1]))):
        sqid0 = 1 if is_io else 0
        name = opc_name(sqid0, opc)
        lats = [total_latency(r) for r in lst]
        done = [r for r in lst if r.get("end") == "cqe"]
        st_total = stats([total_latency(r) for r in done])
        p90 = st_total["p90"] if st_total else None
        p99 = st_total["p99"] if st_total else None
        step_stats = {}
        for r in done:
            for s in steps_of(r):
                step_stats.setdefault(s["step"], {"owner": s["owner"], "plain": s["plain"], "vals": []})
                step_stats[s["step"]]["vals"].append(s["ps"])
        steps = [{"step": k, "owner": v["owner"], "plain": v["plain"], "stats": stats(v["vals"])}
                 for k, v in step_stats.items()]
        status = collections.Counter(status_words(tuple(r["status"])) if r.get("status") else
                                     ("no completion: " + str(r.get("lost") or r.get("end"))) for r in lst)
        over = sum(1 for r, l in zip(lst, lats) if r.get("end") == "cqe" and l is not None and
                   l > HOST_LIMIT["admin" if sqid0 == 0 else "io"])
        # observed parameter ranges
        obs = {}
        if is_io and opc in (0x01, 0x02, 0x04, 0x05, 0x08, 0x0C, 0x7D):
            sl = [r.get("slba") for r in lst if r.get("slba") is not None]
            nl = [r.get("nlb") for r in lst if r.get("nlb") is not None]
            lb = lst[0].get("lba_bytes") or 512
            obs = {"LBA range": "%d to %d" % (min(sl), max(sl + [s + n for s, n in zip(sl, nl)])) if sl else "-",
                   "blocks per command": "%d to %d" % (min(nl), max(nl)) if nl else "-",
                   "bytes per command": "%d to %d" % (min(nl) * lb, max(nl) * lb) if nl else "-",
                   "FUA set": sum(1 for r in lst if _bits((r.get("dw") or [0] * 6)[2], 30, 30)),
                   "namespaces": sorted({r.get("nsid") for r in lst})[:8]}
        elif is_io and opc == 0x09:
            obs = {"ranges per command": "%d to %d" % (min(((r.get("dw") or [0])[0] & 0xFF) + 1 for r in lst),
                                                        max(((r.get("dw") or [0])[0] & 0xFF) + 1 for r in lst)),
                   "deallocate (AD) set": sum(1 for r in lst if _bits((r.get("dw") or [0, 0])[1], 2, 2)),
                   "namespaces": sorted({r.get("nsid") for r in lst})[:8]}
        elif not is_io and opc in (0x09, 0x0A):
            fids = collections.Counter(FID_NAMES.get((r.get("dw") or [0])[0] & 0xFF, "0x%02X" % ((r.get("dw") or [0])[0] & 0xFF)) for r in lst)
            obs = {"features": dict(fids.most_common(12))}
        elif not is_io and opc == 0x02:
            lids = collections.Counter(LID_NAMES.get((r.get("dw") or [0])[0] & 0xFF, "0x%02X" % ((r.get("dw") or [0])[0] & 0xFF)) for r in lst)
            obs = {"log pages": dict(lids.most_common(12))}
        elif not is_io and opc == 0x06:
            cns = collections.Counter(CNS_NAMES.get((r.get("dw") or [0])[0] & 0xFF, "0x%02X" % ((r.get("dw") or [0])[0] & 0xFF)) for r in lst)
            obs = {"structures": dict(cns.most_common(12))}
        elif not is_io and opc in (0x01, 0x05):
            obs = {"queues": sorted({(r.get("dw") or [0])[0] & 0xFFFF for r in lst})[:16],
                   "queue sizes": sorted({((r.get("dw") or [0])[0] >> 16) + 1 for r in lst})[:8]}
        # errors
        err_counter = collections.Counter()
        err_examples = {}
        rows_with_err = []
        for r in lst:
            errs = errors_for(r, by_pkt, by_cmd, defects)
            r["_errs"] = errs
            for e in errs:
                err_counter[e["rule"]] += 1
                err_examples.setdefault(e["rule"], []).append({"pkt": e["pkt"], "cid": r["cid"], "sqid": r["sqid"],
                                                               "defect": e["defect"], "detail": e["detail"]})
            if errs:
                rows_with_err.append(r)
        errors = [{"rule": k, "count": n, "text": RULES.get(k, {}).get("text", k), "layer": RULES.get(k, {}).get("layer"),
                   "examples": err_examples[k][:3]} for k, n in err_counter.most_common()]
        # example rows: slowest and with errors
        def row_of(r):
            lat = total_latency(r)
            return {"sqid": r["sqid"], "cid": r["cid"], "opc": r["opc"], "name": name, "inst": r.get("inst"),
                    "pkt_db": r.get("pkt_db"), "pkt_fetch": r.get("pkt_fetch"), "pkt_cqe": r.get("pkt_cqe"),
                    "end": r.get("end"), "lost": r.get("lost"), "qd": r.get("qd"), "xfer": r.get("xfer"),
                    "moved": r.get("moved"), "n_data": r.get("n_data"), "status": status_words(tuple(r["status"])) if r.get("status") else None,
                    "latency_ps": lat, "latency": fmt_ps(lat), "label": label_for(r, lat, p90, p99),
                    "steps": [{"step": s["step"], "owner": s["owner"], "ps": s["ps"], "text": fmt_ps(s["ps"])} for s in steps_of(r)],
                    "params": param_rows(r), "pieces": pieces_of(r), "errors": r.get("_errs", [])}
        slowest = sorted((r for r in done if total_latency(r) is not None), key=lambda r: -total_latency(r))[:5]
        ex_rows = {}
        for r in rows_with_err[:max_examples] + slowest + [r for r in lst if r.get("end") != "cqe"][:max_examples]:
            ex_rows[(r["sqid"], r["cid"], r.get("inst"))] = row_of(r)
        for r in lst:
            all_rows.append({"sqid": r["sqid"], "cid": r["cid"], "opc": r["opc"], "name": name, "inst": r.get("inst"),
                             "latency_ps": total_latency(r), "end": r.get("end"), "status": r.get("status"),
                             "n_errors": len(r.get("_errs", [])), "xfer": r.get("xfer"), "qd": r.get("qd")})
        cls = "admin" if sqid0 == 0 else "io"
        types.append({
            "klass": "Admin command" if sqid0 == 0 else "I/O command", "opcode": "0x%02X" % opc, "name": name,
            "count": len(lst), "completed": len(done), "not_completed": len(lst) - len(done),
            "parameters": {"fields": param_fields(sqid0, opc), "observed": obs,
                           "source": (NVME_BASE if sqid0 == 0 else NVM_CS) + name},
            "latency": {"total": st_total, "total_text": {k: fmt_ps(v) for k, v in (st_total or {}).items() if k != "n"},
                        "steps": steps, "over_host_limit": over, "host_limit_s": HOST_LIMIT[cls] // SEC,
                        "long_by_nature": LONG_BY_NATURE.get(opc) if sqid0 == 0 else None,
                        "p90_text": fmt_ps(p90), "p99_text": fmt_ps(p99),
                        "buckets_us": bucket_counts([total_latency(r) for r in done], LAT_BUCKETS, US),
                        "qd": qd_bucket_counts([r.get("qd") for r in lst]),
                        "sizes": size_bucket_counts([r.get("xfer") for r in lst]) if (is_io and opc in (0x01, 0x02, 0x05, 0x7D)) else None},
            "status": dict(status.most_common()),
            "errors": errors, "commands_with_errors": len(rows_with_err),
            "examples": list(ex_rows.values())})
    # ---- the error-first view: one row per command that failed, never completed, or carries a packet-level error;
    #      each row ties the command, its parameters, the time it took and the packets that went wrong
    error_rows, error_kinds = [], collections.Counter()
    for (is_io, opc), lst in groups.items():
        sqid0 = 1 if is_io else 0
        name = opc_name(sqid0, opc)
        done = [r for r in lst if r.get("end") == "cqe"]
        st_total = stats([total_latency(r) for r in done])
        p90 = st_total["p90"] if st_total else None
        p99 = st_total["p99"] if st_total else None
        for r in lst:
            failed = bool(r.get("status")) and (r["status"][0] or r["status"][1])
            if not (r.get("_errs") or failed or r.get("end") != "cqe"):
                continue
            kinds = []
            if r.get("end") != "cqe":
                kinds.append("never completed: " + str(r.get("lost") or r.get("end")))
            if failed:
                kinds.append(status_words(tuple(r["status"])).split(" (")[0])
            for e in r.get("_errs") or []:
                if e["rule"] == "NVME.STATUS" and failed:
                    continue                          # the same fact as the status word above
                kinds.append(e["text"])
            for k in set(kinds):
                error_kinds[k] += 1
            lat = total_latency(r)
            error_rows.append({"sqid": r["sqid"], "cid": r["cid"], "opc": r["opc"], "name": name, "inst": r.get("inst"),
                               "klass": "admin" if sqid0 == 0 else "io", "kinds": sorted(set(kinds)),
                               "params": [p for p in param_rows(r) if p[0] not in ("data pointer", "LR")][:8],
                               "latency_ps": lat, "latency": fmt_ps(lat), "label": label_for(r, lat, p90, p99),
                               "steps": [{"step": s_["step"], "owner": s_["owner"], "text": fmt_ps(s_["ps"])} for s_ in steps_of(r)],
                               "status": status_words(tuple(r["status"])) if r.get("status") else None,
                               "end": r.get("end"), "lost": r.get("lost"), "n_pieces": r.get("n_data"),
                               "errors": r.get("_errs") or [], "pieces": pieces_of(r)})
    error_rows.sort(key=lambda x: x["inst"] or 0)
    # ---- the management view: per kind of command, how often it was called, how often it went wrong, which
    #      parameters separate the failures, which packets sit behind them, the usual time against the limit, and
    #      who is responsible by the specification's own status definitions
    management = []
    for (is_io, opc), lst in sorted(groups.items(), key=lambda kv: (kv[0][0], -len(kv[1]))):
        sqid0 = 1 if is_io else 0
        name = opc_name(sqid0, opc)
        cls = "admin" if sqid0 == 0 else "io"
        bad = [r for r in lst if (r.get("status") and (r["status"][0] or r["status"][1])) or r.get("end") != "cqe" or r.get("_errs")]
        if not bad:
            continue
        ok = [r for r in lst if r.get("end") == "cqe" and not (r["status"][0] or r["status"][1])]
        lat_ok = [total_latency(r) for r in ok]
        st_ok = stats(lat_ok)
        lat_bad = [total_latency(r) for r in bad if r.get("end") == "cqe"]
        failed = [r for r in lst if r.get("status") and (r["status"][0] or r["status"][1])]
        lost = [r for r in lst if r.get("end") != "cqe"]
        over = [r for r in lst if r.get("end") == "cqe" and total_latency(r) is not None and total_latency(r) > HOST_LIMIT[cls]]
        p99_ok = st_ok["p99"] if st_ok else None
        slow = [r for r in ok if p99_ok and total_latency(r) is not None and total_latency(r) >= p99_ok and len(ok) >= 20]
        # statuses with who is responsible
        st_counter = collections.Counter(tuple(r["status"]) for r in failed)
        statuses = []
        for stt, cnt in st_counter.most_common():
            side, reason = who_by_status(stt)
            statuses.append({"status": status_words(stt), "count": cnt, "side": side, "reason": reason})
        # parameter contrasts: which attribute values carry the failures
        def attrs(r):
            dw = (r.get("dw") or [0] * 6) + [0] * 6
            a = []
            if is_io and opc in (0x01, 0x02, 0x04, 0x05, 0x08, 0x0C, 0x7D):
                a.append(("FUA (Force Unit Access)", "set" if _bits(dw[2], 30, 30) else "not set"))
                sz = next((lab for lab, lo, hi in SIZE_BUCKETS if (r.get("xfer") or 0) >= lo and (hi is None or (r.get("xfer") or 0) <= hi)), "?")
                a.append(("transfer size", sz))
                a.append(("namespace", "NSID %s" % r.get("nsid")))
                dsm = dw[3] & 0xFF
                if dsm:
                    a.append(("DSM access latency hint", ACCESS_LATENCY.get(_bits(dsm, 5, 4))))
                if opc == 0x08:
                    a.append(("DEAC (deallocate)", "set" if _bits(dw[2], 25, 25) else "not set"))
            elif is_io and opc == 0x09:
                a.append(("deallocate (AD)", "set" if _bits(dw[1], 2, 2) else "not set"))
                a.append(("ranges per command", str((dw[0] & 0xFF) + 1)))
            elif not is_io and opc in (0x09, 0x0A):
                a.append(("feature", FID_NAMES.get(dw[0] & 0xFF, "0x%02X" % (dw[0] & 0xFF))))
            elif not is_io and opc == 0x02:
                a.append(("log page", LID_NAMES.get(dw[0] & 0xFF, "0x%02X" % (dw[0] & 0xFF))))
            elif not is_io and opc == 0x06:
                a.append(("structure", CNS_NAMES.get(dw[0] & 0xFF, "0x%02X" % (dw[0] & 0xFF))))
            elif not is_io and opc in (0x01, 0x05, 0x00, 0x04):
                a.append(("queue", "QID %d" % (dw[0] & 0xFFFF)))
            qd = r.get("qd")
            if qd is not None:
                a.append(("queue depth at submission", next((lab for lab, lo, hi in QD_BUCKETS if qd >= lo and (hi is None or qd <= hi)), "?")))
            return a
        tot = collections.Counter()
        fail = collections.Counter()
        badset = {(r["sqid"], r["cid"], r.get("inst")) for r in bad}
        for r in lst:
            for av in attrs(r):
                tot[av] += 1
                if (r["sqid"], r["cid"], r.get("inst")) in badset:
                    fail[av] += 1
        overall = len(bad) / len(lst)
        contrasts = []
        for av, n_tot in tot.items():
            n_f = fail.get(av, 0)
            if n_f == 0 or n_tot == 0:
                continue
            rate = n_f / n_tot
            # the complement: the same attribute with any other value
            others_tot = sum(v for k, v in tot.items() if k[0] == av[0] and k != av)
            others_f = sum(v for k, v in fail.items() if k[0] == av[0] and k != av)
            contrasts.append({"attribute": av[0], "value": av[1], "failed": n_f, "total": n_tot,
                              "rate": rate, "share_of_failures": n_f / len(bad),
                              "others_failed": others_f, "others_total": others_tot,
                              "lift": (rate / overall) if overall else None})
        contrasts.sort(key=lambda c: (-c["share_of_failures"], -(c["lift"] or 0)))
        separating = [c for c in contrasts if c["share_of_failures"] >= 0.5 and c["others_total"] >= 10 and
                      (c["others_failed"] / c["others_total"]) < c["rate"] and (c["lift"] or 0) >= 1.5]
        # LBA band and sizes of the failures
        lba_note = None
        if is_io and opc in (0x01, 0x02, 0x04, 0x05, 0x08, 0x0C, 0x7D):
            sl = [r["slba"] for r in bad if r.get("slba") is not None]
            if sl:
                nl = [r.get("nlb") or 0 for r in bad]
                lba_note = {"lba_min": min(sl), "lba_max": max(s_ + n_ for s_, n_ in zip(sl, nl)),
                            "blocks": sorted({r.get("nlb") for r in bad}),
                            "all_lba_min": min(r["slba"] for r in lst if r.get("slba") is not None),
                            "all_lba_max": max((r["slba"] or 0) + (r.get("nlb") or 0) for r in lst)}
        # packets behind the failures
        pk = collections.Counter()
        pk_ex = {}
        for r in bad:
            for e in r.get("_errs") or []:
                pk[e["rule"]] += 1
                pk_ex.setdefault(e["rule"], []).append(e["pkt"])
        packets = [{"rule": k, "text": RULES.get(k, {}).get("text", k), "layer": RULES.get(k, {}).get("layer"),
                    "count": n_, "example_pkts": sorted(pk_ex[k])[:4]} for k, n_ in pk.most_common()]
        defects = sorted({e["defect"] for r in bad for e in (r.get("_errs") or []) if e.get("defect")})
        sides = collections.Counter(st_["side"] for st_ in statuses for _ in range(st_["count"]) if st_["side"])
        ci = wilson(len(bad), len(lst))
        facts = {
            "kind": name, "klass": "admin" if sqid0 == 0 else "I/O", "opcode": "0x%02X" % opc,
            "called": len(lst), "went_wrong": len(bad), "rate": len(bad) / len(lst), "rate_ci": ci,
            "failed_status": len(failed), "never_completed": len(lost), "packet_errors_on_successful": len([r for r in bad if r not in failed and r not in lost]),
            "over_host_limit": len(over), "slowest_1pct_of_successful": len(slow),
            "statuses": statuses, "responsible": dict(sides.most_common()),
            "contrasts": contrasts[:8], "separating": separating[:3], "lba": lba_note,
            "packets": packets, "defects": defects,
            "timing": {"usual_successful": fmt_ps(st_ok["p50"]) if st_ok else None, "usual_successful_ps": st_ok["p50"] if st_ok else None,
                       "successful_n": len(ok), "failed_min": fmt_ps(min(lat_bad)) if lat_bad else None, "failed_max": fmt_ps(max(lat_bad)) if lat_bad else None,
                       "host_limit_s": HOST_LIMIT[cls] // SEC, "spec_note": ("the NVMe specification sets no completion time for %s" % name) if not (sqid0 == 0 and opc in LONG_BY_NATURE) else ("%s is long by nature: %s" % (name, LONG_BY_NATURE_NOTE))},
        }
        facts["lines"] = management_lines(facts)
        management.append(facts)
    management.sort(key=lambda m: (-m["went_wrong"], -m["rate"]))
    # ---- controller-level events that are not commands (budgets from the specification)
    reg = collections.Counter(f[2] for f in findings if f[2].startswith("REG.") or f[2] in ("PM.RESUME_SLOW",))
    controller = [{"rule": k, "count": n, "text": RULES.get(k, {}).get("text", k), "spec": RULES.get(k, {}).get("spec", "")}
                  for k, n in reg.most_common()]
    summary = {
        "n_commands": len(recs), "n_types": len(types),
        "n_admin": sum(1 for r in recs if r["sqid"] == 0), "n_io": sum(1 for r in recs if r["sqid"] != 0),
        "n_not_completed": sum(1 for r in recs if r.get("end") != "cqe"),
        "n_with_errors": sum(1 for r in recs if r.get("_errs")),
        "types": types,
        "error_rows": error_rows[:3000], "n_error_rows": len(error_rows),
        "management": management,
        "management_basis": {"rate": "went wrong = failed status, never completed, or a packet-level error under it; the interval is the Wilson 95 % interval of the rate",
                             "responsible": WHO_BASIS,
                             "contrast": "an attribute value 'separates' the failures when it carries at least half of them and its failure rate is above the rate of the other values of the same attribute; it is an association in this capture, not a proven cause",
                             "timing": "usual = median of the successful commands of the same kind in this capture; the limit is the host driver's; " + HOST_LIMIT_SOURCE},
        "error_kinds": [{"kind": k, "count": n} for k, n in error_kinds.most_common()],
        "intervals_ms": {k: bucket_counts(v, INTERVAL_BUCKETS, MS) for k, v in intervals.items()},
        "host_gaps": {k: stats(v) for k, v in host_gaps.items()},
        "host_gaps_text": {k: {kk: fmt_ps(vv) for kk, vv in (stats(v) or {}).items() if kk != "n"} for k, v in host_gaps.items()},
        "controller_events": controller,
        "basis": {
            "parameters": "decoded from the submission entry as NVMe Base 2.0 chapter 5 (admin) and NVM Command Set 1.0 "
                          "section 3.2 (I/O) define the fields; LBA data size from Identify Namespace LBADS",
            "latency": "measured from the capture timestamps: doorbell write, entry fetch, first and last data packet, "
                       "completion entry; step owners from the NVMe queue model (Base 2.0 section 3.3)",
            "labels": "over the limit: " + HOST_LIMIT_SOURCE + "; slowest 1 % / 10 %: the command is at or above the "
                      "99th / 90th percentile of its own kind in this capture; typical: below the 90th percentile; "
                      "long by nature: " + LONG_BY_NATURE_NOTE,
            "errors": "findings of the stage 1 rules that carry the command's identity (SQID, CID, submission packet) "
                      "or sit on one of the command's own packets (doorbell, fetch, entry, data packets, completion); "
                      "each names the defect it was grouped into",
            "buckets": "bucket edges as in the driver team's Trace Vision tables, for comparison",
            "no_payload": "when the DATA column holds only sizes, no command can be decoded and this page is empty"},
    }
    json.dump(summary, open(os.path.join(run_dir, "command_summary.json"), "w", encoding="utf-8"), indent=1)
    with open(os.path.join(run_dir, "command_rows.jsonl"), "w", encoding="utf-8") as f:
        for row in all_rows:
            f.write(json.dumps(row, separators=(",", ":")) + "\n")
    print("commands: %d commands, %d kinds, %d with errors, %d not completed -> %s" %
          (summary["n_commands"], summary["n_types"], summary["n_with_errors"], summary["n_not_completed"],
           os.path.join(run_dir, "command_summary.json")), flush=True)
    return summary


def rows(run_dir, kind=None, only_errors=False, sort="latency", offset=0, limit=200):
    """Rows for the page: all commands of one kind (opcode string) or all, sorted."""
    p = os.path.join(run_dir, "command_rows.jsonl")
    out = []
    if not os.path.exists(p):
        return {"total": 0, "rows": []}
    with open(p, encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            if kind and "%s/%s" % ("admin" if r["sqid"] == 0 else "io", "0x%02X" % r["opc"]) != kind:
                continue
            if only_errors and not (r["n_errors"] or r["end"] != "cqe" or (r["status"] and (r["status"][0] or r["status"][1]))):
                continue
            out.append(r)
    if sort == "latency":
        out.sort(key=lambda r: -(r["latency_ps"] or 0))
    elif sort == "packet":
        out.sort(key=lambda r: r["inst"] or 0)
    total = len(out)
    sel = out[offset:offset + limit]
    for r in sel:
        r["latency"] = fmt_ps(r["latency_ps"])
        r["status_text"] = status_words(tuple(r["status"])) if r["status"] else None
    return {"total": total, "rows": sel}


def detail(run_dir, sqid, cid, inst):
    """Everything about one command, rebuilt from the engine's log."""
    src = os.path.join(run_dir, "commands.jsonl")
    if not os.path.exists(src):
        return None
    with open(src, encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            if r["sqid"] == sqid and r["cid"] == cid and (inst is None or r.get("inst") == inst):
                findings = _load_findings(run_dir)
                by_pkt = collections.defaultdict(list)
                by_cmd = collections.defaultdict(list)
                for fd in findings:
                    by_pkt[fd[0]].append(fd)
                    for k in fd[5]:
                        if k and k[0] == "cmd" and len(k) == 4:
                            by_cmd[(k[1], k[2], k[3])].append(fd)
                lat = total_latency(r)
                return {"sqid": sqid, "cid": cid, "inst": r.get("inst"), "name": opc_name(sqid, r["opc"]),
                        "opcode": "0x%02X" % r["opc"], "end": r.get("end"), "lost": r.get("lost"),
                        "status": status_words(tuple(r["status"])) if r.get("status") else None,
                        "latency": fmt_ps(lat), "latency_ps": lat,
                        "steps": [{"step": s["step"], "owner": s["owner"], "text": fmt_ps(s["ps"]), "plain": s["plain"]} for s in steps_of(r)],
                        "params": param_rows(r), "pieces": pieces_of(r),
                        "packets": {k: r.get(k) for k in ("pkt_db", "pkt_fetch", "pkt_sqe", "pkt_first_data", "pkt_last_data", "pkt_cqe", "end_pkt")},
                        "errors": errors_for(r, by_pkt, by_cmd, _defect_index(run_dir))}
    return None


def to_csv(run_dir, path):
    """Every command as one CSV row (the driver team asked for a CSV export)."""
    src = os.path.join(run_dir, "commands.jsonl")
    n = 0
    with open(path, "w", newline="", encoding="utf-8") as fo:
        w = csv.writer(fo)
        w.writerow(["queue", "cid", "class", "opcode", "command", "nsid", "slba", "nlb", "bytes", "qd",
                    "doorbell_pkt", "fetch_pkt", "first_data_pkt", "last_data_pkt", "completion_pkt",
                    "latency_us", "doorbell_to_fetch_us", "fetch_to_first_data_us", "data_phase_us",
                    "last_data_to_completion_us", "status", "end", "parameters"])
        if os.path.exists(src):
            with open(src, encoding="utf-8") as f:
                for line in f:
                    r = json.loads(line)
                    st = {s["step"]: s["ps"] for s in steps_of(r)}
                    us = lambda v: ("%.3f" % (v / US)) if v is not None else ""
                    w.writerow([r["sqid"], r["cid"], "admin" if r["sqid"] == 0 else "io", "0x%02X" % r["opc"],
                                opc_name(r["sqid"], r["opc"]), r.get("nsid"), r.get("slba"), r.get("nlb"), r.get("xfer"),
                                r.get("qd"), r.get("pkt_db"), r.get("pkt_fetch"), r.get("pkt_first_data"),
                                r.get("pkt_last_data"), r.get("pkt_cqe"), us(total_latency(r)),
                                us(st.get("doorbell to fetch")), us(st.get("fetch to first data")), us(st.get("data phase")),
                                us(st.get("last data to completion")),
                                status_words(tuple(r["status"])) if r.get("status") else "", r.get("end"),
                                "; ".join("%s=%s" % (p[0], p[1]) for p in param_rows(r) if not p[0].startswith("data pointer"))])
                    n += 1
    return n
