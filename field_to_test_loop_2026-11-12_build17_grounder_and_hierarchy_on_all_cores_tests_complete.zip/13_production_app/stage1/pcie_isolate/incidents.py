"""Findings -> isolated incidents.

Grouping rests only on relations the specifications define; there is no packet-distance or time-distance
assumption anywhere in this module:
  SAME_KEY   two findings name the same transaction (RequesterID + Tag, PCIe 4.0 §2.2.6.2), the same TLP sequence
             number (PCIe 4.0 §3.5.1), the same NVMe command (SQID + CID, NVMe 2.0 §4.1), queue or LBA
  REFERS     a rule computed one finding while looking at the packet of another (the finding's related packets:
             a completion refers to its request, a lost command refers to the reset or link down that lost it,
             an early access refers to the D0 write it followed)
  SAME_ROW   two findings on the same packet
  SERIES     findings of one rule with the same qualifier that carry no identifier at all (symbol errors, bad
             codes, ordered-set faults) are reported as one series with a count, the way the analyzer's own
             Error Summary counts them; no cause is claimed between them
Everything else:
  first_abnormal        earliest wire finding of the group (the first abnormal event; catalogue rule R1)
  evidence graph        nodes = findings, edges = SAME_KEY / REFERS, CAUSES = a pair listed in CASCADE (published
                        error propagation, earlier -> later); root = first node with no cause
  attribution           R0..R10: each branch states the specification fact it rests on
  classification        ranked atlas cards by rule-signature similarity (atlas.Classifier)
  context               the NVMe commands involved and the command mix inside the span (counts, no guessed label)
  evidence rows         exactly the packets the findings name (their own packets and related packets) and the rows
                        between the first and last packet of each finding, nothing added around them
"""
import csv
import json
import os
import pickle
import struct
from collections import Counter, defaultdict

from .atlas import Classifier, enrich
from .engine import ADMIN_NAMES, IO_NAMES
from .evidence import compact, merge_ranges
from .rules import CONTEXT, DEFECT, RULES
from .schema import fmt_dt, fmt_t

# identity keys that name one event instance (a transaction while outstanding, one command, one TLP sequence number,
# one block address); queue ids ("sq", "cq") name long-lived objects and do not link findings
LINK_KEYS = ("tag", "cmd", "psn", "lba")
# no distance constants: see the module docstring
MAX_WINDOW_ROWS = 400    # a single finding's own span longer than this is shown as its first and last 200 rows
                         # (display bound only: the finding's packets themselves are always included)

# published / atlas cascades: earlier rule family -> later rule family
CASCADE = [
    ("PHY.", ("DLL.LCRC_BAD", "DLL.NAK", "DLL.REPLAY", "LINK.RECOVERY", "MSG.ERR", "LINK.DOWN", "PHY.SPEED_DOWN",
              "PHY.WIDTH_CHANGE")),
    ("DLL.LCRC_BAD", ("DLL.NAK", "DLL.REPLAY", "MSG.ERR")),
    ("DLL.CRC16_BAD", ("DLL.REPLAY", "DLL.ACK_LATE", "MSG.ERR")),
    ("DLL.NAK", ("DLL.REPLAY", "MSG.ERR")),
    ("DLL.REPLAY", ("DLL.REPLAY_ROLLOVER", "LINK.RECOVERY", "MSG.ERR")),
    ("DLL.REPLAY_ROLLOVER", ("LINK.RECOVERY", "LINK.DOWN", "MSG.ERR")),
    ("LINK.RECOVERY", ("LINK.RECOVERY_STORM", "PHY.SPEED_DOWN", "PHY.WIDTH_CHANGE", "LINK.DOWN")),
    ("LINK.DOWN", ("LINK.DOWN_INFLIGHT", "TXN.LOST_LINKDOWN", "NVME.CMD_LOST_RESET", "NVME.CMD_TIMEOUT",
                   "REG.ALL_ONES", "LINK.TRAIN_SLOW")),
    ("PHY.EIDLE_NO_EIOS", ("LINK.DOWN", "LINK.DOWN_INFLIGHT", "DATA.LOST_AFTER_POWER", "DATA.POWER_CUT")),
    ("FC.", ("TXN.CPL_TIMEOUT", "NVME.CMD_TIMEOUT", "S.")),
    ("TXN.CPL_TIMEOUT", ("NVME.STATUS", "NVME.CMD_TIMEOUT", "MSG.ERR", "TXN.CPL_LATE")),
    ("TLP.", ("MSG.ERR", "TXN.", "NVME.STATUS")),
    ("TXN.", ("MSG.ERR", "NVME.STATUS", "NVME.CMD_TIMEOUT")),
    ("CFG.", ("TLP.CPL_STATUS", "MSG.ERR", "NVME.CMD_TIMEOUT", "REG.")),
    ("REG.RDY_TIMEOUT", ("REG.CTRL_RESET",)),
    ("NVME.SQE_", ("NVME.STATUS",)),
    ("NVME.CMD_TIMEOUT", ("NVME.ABORT", "REG.CTRL_RESET", "NVME.CQE_UNKNOWN_CID")),
    ("NVME.NOT_FETCHED", ("REG.CTRL_RESET", "NVME.CMD_TIMEOUT")),
    ("DB.", ("NVME.AEN", "NVME.STATUS", "NVME.NOT_FETCHED", "NVME.CMD_TIMEOUT")),
    ("NVME.AEN", ("NVME.LOG_CRITICAL",)),
    ("PM.", ("S.", "LINK.", "NVME.CMD_TIMEOUT")),
]


def causes(a, b):
    for pre, posts in CASCADE:
        if a.startswith(pre) and any(b.startswith(p) for p in posts):
            return True
    return False


def interval(f):
    """The packets a finding is about: its own packet and the packets its rule related to it."""
    rel = [p for p in f[6] if isinstance(p, int)]
    return min([f[0]] + rel), max([f[0]] + rel)


def _pkts(f):
    return {f[0]} | {p for p in f[6] if isinstance(p, int)}


def cluster(findings):
    """Group findings by specification-defined relations only (SAME_KEY, REFERS, SAME_ROW), then fold
    identifier-less findings of one rule and qualifier into one SERIES group.  Context findings (host actions,
    resets) are kept only when a defect finding refers to them; an unrelated context finding is not a defect."""
    fs = sorted(findings, key=lambda f: (f[0], f[2]))
    n = len(fs)
    parent = list(range(n))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def union(i, j):
        ri, rj = find(i), find(j)
        if ri != rj:
            parent[max(ri, rj)] = min(ri, rj)
    by_key = defaultdict(list)
    by_pkt = defaultdict(list)
    for i, f in enumerate(fs):
        for k in f[5]:
            if k and k[0] in LINK_KEYS:
                by_key[tuple(k)].append(i)
        by_pkt[f[0]].append(i)
    for ids in by_key.values():                       # SAME_KEY
        for j in ids[1:]:
            union(ids[0], j)
    for ids in by_pkt.values():                       # SAME_ROW
        for j in ids[1:]:
            union(ids[0], j)
    for i, f in enumerate(fs):                        # REFERS
        for p in f[6]:
            if isinstance(p, int):
                for j in by_pkt.get(p, ()):
                    union(i, j)
    groups = defaultdict(list)
    for i, f in enumerate(fs):
        groups[find(i)].append(f)
    out = []
    series = {}
    for g in groups.values():
        defects = [f for f in g if RULES[f[2]]["level"] == DEFECT and RULES[f[2]]["tier"] != "S"]
        if not defects:
            continue                                  # context or statistics alone is not a defect
        if len(g) == 1 and not g[0][5] and not [p for p in g[0][6] if isinstance(p, int)]:
            # no identifier, no reference: one of a series (rule, qualifier)
            f = g[0]
            series.setdefault((f[2], f[3]), []).append(f)
            continue
        lo = min(interval(f)[0] for f in g)
        hi = max(interval(f)[1] for f in g)
        out.append({"lo": lo, "hi": hi, "f": sorted(g, key=lambda f: f[0]), "kind": "linked"})
    for (rule, qual), fl in series.items():
        fl.sort(key=lambda f: f[0])
        out.append({"lo": fl[0][0], "hi": fl[0][0], "f": fl, "kind": "series", "series_count": len(fl),
                    "series_pkts": [f[0] for f in fl]})
    out.sort(key=lambda g: (g["lo"], g["hi"]))
    return out


def evidence_graph(fs):
    nodes = []
    for i, f in enumerate(fs):
        nodes.append({"id": i, "pkt": f[0], "rule": f[2], "level": RULES[f[2]]["level"], "detail": f[4]})
    edges = []
    keyed = defaultdict(list)
    for i, f in enumerate(fs):
        for k in f[5]:
            keyed[tuple(k)].append(i)
    for k, ids in keyed.items():
        for a, b in zip(ids, ids[1:]):
            edges.append({"from": a, "to": b, "type": "SAME_KEY", "key": "/".join(str(x) for x in k)})
    at = defaultdict(list)
    for i, f in enumerate(fs):
        at[f[0]].append(i)
    for i, f in enumerate(fs):
        for p in f[6]:
            if isinstance(p, int):
                for j in at.get(p, ()):
                    if j != i:
                        edges.append({"from": j, "to": i, "type": "REFERS", "pkt": p})
    incoming = set()
    defect_ids = [i for i, f in enumerate(fs) if RULES[f[2]]["level"] == DEFECT]
    for x, a in enumerate(defect_ids):
        for b in defect_ids[x + 1:]:
            if fs[a][2] != fs[b][2] and causes(fs[a][2], fs[b][2]):
                edges.append({"from": a, "to": b, "type": "CAUSES"})
                incoming.add(b)
    spec_ids = [i for i in defect_ids if RULES[fs[i][2]]["tier"] != "S"] or defect_ids
    root = next((i for i in spec_ids if i not in incoming), spec_ids[0] if spec_ids else 0)
    if len(edges) > 400:
        edges = edges[:400]
    return nodes, edges, root


# ---------------------------------------------------------------------- one pass to pull rows back
class Extract:
    """Collects full rows for evidence ranges and slim rows for task-context ranges (one CSV pass),
    then attaches payload from the sidecar (one sidecar pass)."""

    def __init__(self, csv_path, payload_path):
        self.csv_path, self.payload_path = csv_path, payload_path
        self.full = []
        self.ctx = []

    def run(self):
        full = merge_ranges(self.full)
        ctxr = merge_ranges(self.ctx)
        import bisect
        fs, cs = [r[0] for r in full], [r[0] for r in ctxr]
        end = max([r[1] for r in full] + [r[1] for r in ctxr] + [0])
        rows, slim, lineno = {}, {}, {}
        with open(self.csv_path, newline="", encoding="utf-8-sig", errors="replace", buffering=1 << 22) as f:
            header = next(csv.reader([f.readline()]))
            self.header = header
            ix = {n: i for i, n in enumerate(header)}
            take = [ix.get(n, len(header)) for n in ("Link Dir", "TLP Type", "DLLP Type", "Ord.Set Type", "Link Event",
                                                     "Address", "Length", "Tag", "Message Code", "DATA", "Time Stamp",
                                                     "Cpl Status")]
            ipk = ix["Packet"]
            for n, line in enumerate(f, start=2):            # physical line: header is line 1
                if ipk == 1:
                    # fast path: the Packet value is the 2nd field (the Marker column before it never holds a comma)
                    a = line.find(",")
                    b = line.find(",", a + 1) if a >= 0 else -1
                    ps = line[a + 1:b] if b > 0 else ""
                else:
                    cells = next(csv.reader([line]))
                    ps = cells[ipk] if len(cells) > ipk else ""
                if not ps.isdigit():
                    continue                                 # a row without a packet number carries no evidence
                p = int(ps)
                if p > end:
                    break
                i = bisect.bisect_right(fs, p) - 1
                inf = i >= 0 and p <= full[i][1]
                j = bisect.bisect_right(cs, p) - 1
                inc = j >= 0 and p <= ctxr[j][1]
                if not (inf or inc):
                    continue
                row = next(csv.reader([line]))
                if len(row) < len(header) + 1:
                    row = row + [""] * (len(header) + 1 - len(row))   # short row: missing cells read as empty
                if inf:
                    rows[p] = row
                    lineno[p] = n
                if inc:
                    slim[p] = [row[k] for k in take]
        pay = {}
        if self.payload_path:
            want = set(rows) | set(slim)
            with open(self.payload_path, newline="", encoding="utf-8") as f:
                f.readline()
                for line in f:
                    a = line.index(",")
                    p = int(line[:a])
                    if p > end:
                        break
                    if p in want:
                        r = line.rstrip("\n").split(",")
                        pay[p] = (int(r[1]), r[2], r[3])
        self.rows, self.slim, self.pay, self.lineno = rows, slim, pay, lineno
        return self


# ---------------------------------------------------------------------- context: command and task
def decode_sqe(hexs):
    b = bytes.fromhex(hexs)
    if len(b) < 64:
        return None
    dw = struct.unpack("<16I", b[:64])
    opc, cid = dw[0] & 0xFF, dw[0] >> 16
    return {"opcode": opc, "cid": cid, "nsid": dw[1], "prp1": dw[6] | dw[7] << 32, "prp2": dw[8] | dw[9] << 32,
            "cdw10": dw[10], "cdw11": dw[11], "cdw12": dw[12], "slba": dw[10] | dw[11] << 32,
            "nlb": (dw[12] & 0xFFFF) + 1}


def describe_command(inc, ex, bar0):
    """The NVMe command(s) the incident is about, decoded from the SQE payload when available."""
    keys = []
    for f in inc["_f"]:
        for k in f[5]:
            if k and k[0] == "cmd" and (k[1], k[2]) not in keys:
                keys.append((k[1], k[2]))
    cands = set(p for f in inc["_f"] for p in [f[0]] + list(f[6]) if isinstance(p, int))
    cmds = []
    for p in sorted(cands):
        pl = ex.pay.get(p)
        row = ex.rows.get(p)
        if not pl or not row or pl[0] != 64:
            continue
        ix = ex.header.index("TLP Type")
        if row[ix] != "CplD":
            continue
        d = decode_sqe(pl[1])
        if not d:
            continue
        for sqid, cid in keys or [(None, d["cid"])]:
            if cid == d["cid"]:
                names = ADMIN_NAMES if sqid == 0 else IO_NAMES
                name = names.get(d["opcode"], "opcode 0x%02X" % d["opcode"])
                desc = {"sqid": sqid, "cid": cid, "opcode": "0x%02X" % d["opcode"], "name": name,
                        "nsid": d["nsid"], "sqe_packet": p}
                if sqid != 0:
                    desc.update({"slba": "0x%X" % d["slba"], "blocks": d["nlb"], "bytes": d["nlb"] * 512})
                else:
                    desc.update({"cdw10": "0x%08X" % d["cdw10"], "cdw11": "0x%08X" % d["cdw11"]})
                desc.update({"prp1": "0x%X" % d["prp1"], "prp2": "0x%X" % d["prp2"]})
                cmds.append(desc)
                break
    return cmds[:4], keys[:8]


def describe_task(lo, hi, ex, bar0):
    """The command mix inside the defect span, as counts.  No label is guessed: the specifications define the
    commands (NVMe 2.0 §5, NVM CS 1.0 §3), not what the user was doing."""
    rows = [(p, ex.slim[p]) for p in range(lo, hi + 1) if p in ex.slim]
    c = Counter()
    io = Counter()
    io_bytes = []
    admin = Counter()
    last_db_q = None
    for p, r in rows:
        d, tl, dl, os_, ev, addr, ln, tag, msg, data, ts, cst = r
        if os_:
            c["ordered sets"] += 1
        elif dl:
            c["link-layer packets"] += 1
        elif ev:
            c["link events"] += 1
        elif tl.startswith("Cfg"):
            c["configuration requests"] += 1
        elif tl.startswith("Msg"):
            c["messages"] += 1
        elif tl.startswith("MWr") and bar0 is not None and addr:
            try:
                off = int(addr, 16) - bar0
            except ValueError:
                off = -1
            if 0 <= off < 0x1000:
                c["controller register writes"] += 1
            elif off >= 0x1000:
                c["doorbell writes"] += 1
                last_db_q = (off - 0x1000) // 8
            else:
                c["memory writes"] += 1
        elif tl.startswith("MRd"):
            c["memory reads"] += 1
        elif tl.startswith("Cpl"):
            c["completions"] += 1
        if tl == "CplD" and d == "Downstream" and p in ex.pay and ex.pay[p][0] == 64:
            s_ = decode_sqe(ex.pay[p][1])
            if s_:
                if last_db_q == 0:
                    admin[ADMIN_NAMES.get(s_["opcode"], "0x%02X" % s_["opcode"])] += 1
                else:
                    io[IO_NAMES.get(s_["opcode"], "0x%02X" % s_["opcode"])] += 1
                    if s_["opcode"] in (1, 2):
                        io_bytes.append(s_["nlb"] * 512)
    parts = []
    if io:
        parts.append("I/O commands in the span: " + ", ".join("%s %d" % kv for kv in io.most_common()))
    if admin:
        parts.append("admin commands: " + ", ".join("%s %d" % kv for kv in admin.most_common()))
    other = ", ".join("%s %d" % kv for kv in c.most_common() if kv[1])
    if other:
        parts.append("traffic: " + other)
    label = "; ".join(parts) if parts else "no traffic decoded inside the span"
    detail = {"io_commands": dict(io), "admin_commands": dict(admin),
              "io_size_range": [min(io_bytes), max(io_bytes)] if io_bytes else None,
              "other": {k: v for k, v in c.items() if v}}
    return label, detail


# ---------------------------------------------------------------------- attribution (atlas XII.8)
def attribute(inc, ex, card):
    """Who acted wrongly first.  Every branch names the specification fact it rests on; where the wire does not
    decide, the answer is 'undetermined' rather than a guess."""
    rules = [f[2] for f in inc["_f"] if RULES[f[2]]["level"] == DEFECT]
    rs = set(rules)
    first = inc["_f"][inc["_first"]]
    row = ex.rows.get(first[0])
    d = row[ex.header.index("Link Dir")] if row else ""
    sender = "device" if d == "Upstream" else ("host" if d == "Downstream" else None)

    def has(prefix):
        return any(r.startswith(prefix) for r in rs)
    if has("CI."):
        return "test setup", "R0 the finding is a record of the capture itself (analyzer marker, gap, filter, " \
                             "resync, injected fault: Teledyne capture records), not of the link", ["re-export unfiltered"]
    if "NVME.STATUS" in rs:
        if has("NVME.SQE_") or "DB.PARTIAL" in rs:
            return "host", "R2 the submission entry broke an SQE field rule (NVMe 2.0 §4.1) or the doorbell write " \
                           "was not a full 32-bit write (§3.1.3); the controller rejected it as the specification " \
                           "requires (§4.2 status)", []
        aborted = any(f[2] == "NVME.STATUS" and f[3].endswith("/0x07") for f in inc["_f"]) and \
            any(f[2] in ("NVME.ABORT", "NVME.HOST_ABORT_EARLY") for f in inc["_f"])
        if aborted:
            return "host", "R2 status SC 0x07 (Command Abort Requested, NVMe 2.0 §4.2) answers the host's own Abort " \
                           "command (§5.1): the controller responded as specified; the reason for the abort is " \
                           "host-side", ["E05 host I/O trace: who issued the Abort and when"]
        return "device", "R2 the controller returned a non-zero status (NVMe 2.0 §4.2) for a command whose checked " \
                         "SQE fields are valid: the rejection is the controller's decision", \
            ["E03 nvme error-log with the same SQID+CID"]
    if has("NVME.NOT_FETCHED"):
        return "device", "R3 the tail doorbell was written (NVMe 2.0 §3.3.1) and the controller never fetched the " \
                         "entry: the first missing step is the controller's", ["E03 PEL"]
    if "TXN.CPL_TIMEOUT" in rs and first[2] == "TXN.CPL_TIMEOUT" and "Upstream" in first[4]:
        return "platform", "R3 a read from the device (Upstream MRd) got no completion (PCIe 4.0 §2.8): the " \
                           "completer is the root complex", ["E02 IOMMU/ACS, AER on root port"]
    if "NVME.CMD_TIMEOUT" in rs:
        return "device", "R3 the entry was fetched and no completion entry was posted (NVMe 2.0 §3.3, §4.2) until " \
                         "the host gave up: the device holds the command", ["E03 C1h/C3h logs", "reset ladder"]
    if has("DLL.") or has("PHY.SYMBOL") or "LINK.RECOVERY" in rs:
        naks = [f for f in inc["_f"] if f[2] == "DLL.NAK"]
        up = sum(1 for f in naks if f[3] == "Upstream")
        dn = sum(1 for f in naks if f[3] == "Downstream")
        if up and dn:
            return "link", "R5 Nak sent in both directions (PCIe 4.0 §3.5.2.2: the receiver that saw a bad TLP " \
                           "sends Nak): both receivers see corruption, so the channel", ["E07 margining", "slot/riser swap"]
        if up:
            return "platform", "R5 Nak sent Upstream (PCIe 4.0 §3.5.2.2): the device's receiver saw bad TLPs, so " \
                               "the host transmitter or the channel", ["swap slot", "E07 margining"]
        if dn:
            return "device", "R5 Nak sent Downstream (PCIe 4.0 §3.5.2.2): the root port's receiver saw bad TLPs, " \
                             "so the device transmitter or the channel", ["swap SSD", "E07 margining"]
        return "link", "R5 link-layer errors without a Nak that names the receiver (PCIe 4.0 §3.5)", \
            ["AER counters on both ends"]
    if has("LINK.DOWN") or has("PHY.EIDLE") or "LINK.TRAFFIC_WHILE_DOWN" in rs:
        host_act = any(f[2] in ("LINK.DOWN_HOST", "PHY.TS_HOTRESET", "PHY.TS_DISABLE", "REG.CTRL_RESET", "CFG.FLR")
                       for f in inc["_f"])
        if host_act:
            return "host", "R6 a host-initiated reset or disable (PCIe 4.0 §6.6.1 hot reset / §4.2.6.9 Disabled " \
                           "/ §6.6.2 FLR; NVMe 2.0 §3.7.2 CC.EN=0) is linked to this link loss", \
                ["E01 dmesg pciehp/DPC", "E07"]
        return (sender or "device"), "R6 link loss with no linked host action (PCIe 4.0 §2.9.2 surprise down)", \
            ["E01 dmesg pciehp/DPC", "E07"]
    if "FC.INSUFFICIENT_CREDITS" in rs:
        q = next((f[3] for f in inc["_f"] if f[2] == "FC.INSUFFICIENT_CREDITS"), "")
        side = "host" if q.startswith("Downstream") else ("device" if q.startswith("Upstream") else "undetermined")
        return side, "R4 a TLP was sent without the credits for it (PCIe 4.0 §2.6.1: the transmitter must not " \
                     "send beyond CREDIT_LIMIT); the transmitter is the %s" % side, ["InitFC/UpdateFC ledger"]
    if "FC.UPDATE_WITHHELD" in rs or "FC.STALL" in rs or "FC.INVALID_ADVERTISEMENT" in rs or "DLL.FC_INIT" in rs:
        q = next((f[3] for f in inc["_f"] if f[2].startswith("FC.") or f[2] == "DLL.FC_INIT"), "")
        side = "device" if q.startswith("Downstream") else ("host" if q.startswith("Upstream") else "undetermined")
        return side, "R4 credits were advertised or returned wrongly (PCIe 4.0 §2.6.1, §3.3: the receiver owns " \
                     "the credit advertisement); the receiver is the %s" % side, ["InitFC/UpdateFC ledger"]
    if has("PM."):
        return "platform" if "PM.LTR_LOW" not in rs else "device", \
            "R7 power-management handshake or latency rule (PCIe 4.0 §5.3, §5.4.1, §6.18 LTR) broken by the " \
            "side that owns the value", ["ASPM/APST A/B test"]
    if has("TLP.") or has("TXN.") or has("NVME.") or has("DB.") or has("CFG.") or has("REG."):
        if sender:
            return sender, "R4 the transmitter of the first bad TLP (%s; PCIe 4.0 §2.2 header rules)" % d, []
        return "undetermined", "R4 the first bad TLP's direction is not in the export", []
    if has("DATA."):
        return "device", "R8 data correct on the wire at write time and different at read time (NVM CS 1.0 §3.2: " \
                         "a read returns the last data written)", ["E04 fio verify"]
    if has("S."):
        rr = " ".join(f[3] for f in inc["_f"] if f[2].startswith("S."))
        if any(x in rr for x in ("cq_head_lag", "sq_batch", "config_to_driver")):
            return "host", "R9 the measured gap is on a host-owned step of the queue model (NVMe 2.0 §3.3: head " \
                           "doorbell, submission)", ["E05 host tracing"]
        return "device", "R9 the measured gap is on a controller-owned step (NVMe 2.0 §3.3: fetch, data, " \
                         "completion)", ["E03 C3h latency monitor"]
    if has("H."):                                   # proven only by outside evidence: the document names the side
        h = next(f for f in inc["_f"] if f[2].startswith("H."))
        side = {"H.OTHER_PATH": "other path", "H.HOST_TRACE": "host", "H.PLATFORM": "platform",
                "H.CAPTURE_SETUP": "test setup", "H.DATA_VERIFY": "device", "H.NVME_LOG": "device",
                "H.LAB_RESULT": "device", "H.KERNEL_ERROR": "undetermined"}[h[2]]
        return side, "R10 nothing on the wire; the outside document (%s) names the side" % h[4].split(":")[0], []
    return "undetermined", "R10 nothing on the wire decides who acted wrongly first", ["E01-E10"]


# ---------------------------------------------------------------------- main
def isolate(run_dir, library_path, csv_path, payload_path):
    from .host_evidence import load_all
    findings = load_all(run_dir)
    run = json.load(open(os.path.join(run_dir, "run.json"), encoding="utf-8"))
    bar0 = int(run["topology"]["bar0"], 16) if run["topology"].get("bar0") else None
    clf = Classifier(library_path)
    groups = cluster(findings)
    print("findings %d -> incidents %d" % (len(findings), len(groups)), flush=True)
    ex = Extract(csv_path, payload_path)
    incs = []
    for n, g in enumerate(groups, 1):
        fs = g["f"]
        nodes, edges, root = evidence_graph(fs)
        defect_idx = [i for i, f in enumerate(fs) if RULES[f[2]]["level"] == DEFECT]
        wire_idx = [i for i in defect_idx if RULES[fs[i][2]]["tier"] not in ("H", "S")] or \
            [i for i in defect_idx if RULES[fs[i][2]]["tier"] != "H"]
        first = wire_idx[0] if wire_idx else defect_idx[0]   # the wire row is the proof; host lines corroborate
        lo, hi = g["lo"], g["hi"]
        key_pkts = []
        for f in fs:
            for p in [f[0]] + [x for x in f[6] if isinstance(x, int)]:
                if p not in key_pkts:
                    key_pkts.append(p)
        key_pkts = sorted(key_pkts)[:40]
        # evidence = each finding's own span (its packet to the packets it relates to); a long span is bounded
        windows = []
        for f in fs:
            a, b = interval(f)
            if b - a + 1 <= MAX_WINDOW_ROWS:
                windows.append((a, b))
            else:
                windows.extend([(a, a + MAX_WINDOW_ROWS // 2), (b - MAX_WINDOW_ROWS // 2, b)])
        windows = [tuple(w) for w in merge_ranges(windows)]
        for w in windows:
            ex.full.append(w)
        for p in key_pkts:
            ex.full.append((p, p))
        ex.ctx.append((lo, hi))
        incs.append({"_f": fs, "_first": first, "_root": root, "id": "INC-%04d" % n, "start_pkt": lo, "end_pkt": hi,
                     "windows": windows, "key_pkts": key_pkts, "nodes": nodes, "edges": edges,
                     "kind": g.get("kind", "linked"), "series_count": g.get("series_count"),
                     "series_pkts": g.get("series_pkts")})
    print("extracting evidence rows ...", flush=True)
    ex.run()
    out = []
    for inc in incs:
        fs = inc["_f"]
        first = fs[inc["_first"]]
        root = fs[inc["_root"]]
        ranked = clf.rank(fs)
        top = ranked[0]["card_id"] if ranked else None
        card = clf.cards_db.get(top) if top else None
        origin, why_origin, need = attribute(inc, ex, card)
        task, task_detail = describe_task(inc["start_pkt"], inc["end_pkt"], ex, bar0)
        cmds, cmd_keys = describe_command(inc, ex, bar0)
        ts = lambda p: ex.rows[p][ex.header.index("Time Stamp")] if p in ex.rows else None
        defects = [f for f in fs if RULES[f[2]]["level"] == DEFECT]
        caused = {e["to"] for e in inc["edges"] if e["type"] == "CAUSES"}

        def role(i, f):
            """The earliest abnormal event is the root; a later finding is a cascade only when the CASCADE table (published error propagation) lists the pair, otherwise it is related but independent."""
            if RULES[f[2]]["level"] != DEFECT:
                return "context"
            if RULES[f[2]]["tier"] == "S":
                return "observation"
            if i == inc["_root"]:
                return "root"
            if inc["kind"] == "series":
                return "series"
            return "cascade" if i in caused else "independent"
        ln = ex.lineno
        rec = {
            "id": inc["id"],
            "start_pkt": inc["start_pkt"], "end_pkt": inc["end_pkt"],
            "start_time": ts(inc["start_pkt"]), "end_time": ts(inc["end_pkt"]),
            "span_rows": inc["end_pkt"] - inc["start_pkt"] + 1,
            "csv_lines": {"start": ln.get(inc["start_pkt"]), "end": ln.get(inc["end_pkt"]),
                          "first_abnormal": ln.get(first[0]), "root": ln.get(root[0]),
                          "note": "1-based physical lines of the CSV file; the header is line 1"},
            "first_abnormal": {"pkt": first[0], "rule": first[2], "verdict": RULES[first[2]]["verdict"],
                               "detail": first[4]},
            "root_cause_node": {"pkt": root[0], "rule": root[2], "detail": root[4]},
            "verdict": max((RULES[f[2]]["verdict"] for f in defects),
                           key=lambda v: ["UNKNOWN", "ARTEFACT", "SUSPECT", "CONFIRMED"].index(v)
                           if v in ("UNKNOWN", "ARTEFACT", "SUSPECT", "CONFIRMED") else 0),
            "layer": RULES[first[2]]["layer"],
            "rules": dict(Counter(f[2] for f in defects)),
            "context_rules": dict(Counter(f[2] for f in fs if RULES[f[2]]["level"] == CONTEXT)),
            "pattern_vote": clf.pattern_vote(fs)[:4],
            "atlas_candidates": ranked,
            "attribution": {"origin": origin, "rule": why_origin, "evidence_to_collect": need},
            "nvme_commands": cmds,
            "command_keys": [list(k) for k in cmd_keys],
            "task": task, "task_detail": task_detail,
            "explanation": enrich(card) if card else None,
            "findings": [{"pkt": f[0], "line": ln.get(f[0]), "rule": f[2], "level": RULES[f[2]]["level"],
                          "verdict": RULES[f[2]]["verdict"], "qual": f[3], "detail": f[4], "role": role(i, f),
                          "related_pkts": [p for p in f[6] if isinstance(p, int)]} for i, f in enumerate(fs[:200])],
            "n_findings": len(fs),
            "grouping": {"kind": inc["kind"], "series_count": inc["series_count"],
                         "series_pkts": (inc["series_pkts"] or [])[:20000],
                         "series_last_pkt": (inc["series_pkts"] or [None])[-1],
                         "basis": "SAME_KEY / REFERS / SAME_ROW relations only" if inc["kind"] == "linked" else
                                  "one rule, one qualifier, no identifiers: counted as a series, no cause claimed"},
            "evidence_graph": {"nodes": inc["nodes"][:200], "edges": inc["edges"], "root": inc["_root"]},
            "windows": inc["windows"], "key_pkts": inc["key_pkts"],
        }
        out.append(rec)
    json.dump(out, open(os.path.join(run_dir, "incidents.json"), "w", encoding="utf-8"), indent=1, default=str)
    # evidence rows for the reviewer: compact text, one block per window plus key rows
    with open(os.path.join(run_dir, "incident_rows.jsonl"), "w", encoding="utf-8") as fo:
        for inc, rec in zip(incs, out):
            blocks = []
            for lo, hi in inc["windows"]:
                blocks.append({"range": [lo, hi], "rows": [row_text(ex, p) for p in range(lo, hi + 1) if p in ex.rows]})
            keys = [row_text(ex, p) for p in inc["key_pkts"] if p in ex.rows and
                    not any(lo <= p <= hi for lo, hi in inc["windows"])]
            fpk = sorted({p for f in inc["_f"] for p in [f[0]] + [x for x in f[6] if isinstance(x, int)]})
            fo.write(json.dumps({"id": rec["id"], "blocks": blocks, "key_rows": keys, "finding_pkts": fpk}) + "\n")
    print("incidents -> %s" % os.path.join(run_dir, "incidents.json"))
    return out


def row_text(ex, p):
    row = ex.rows[p]
    s = compact(ex.header, row)
    if p in ex.lineno:
        s += " | Line=%d" % ex.lineno[p]
    pl = ex.pay.get(p)
    if pl:
        s += " | PAYLOAD=" + (pl[1] if pl[0] <= 64 else pl[1] + "...(%d B, crc32 %s)" % (pl[0], pl[2]))
    return s
