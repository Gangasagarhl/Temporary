#!/usr/bin/env python3
"""Derive the four upper-level exports (link, split, NVMe transaction, NVMe command) from a synthetic 113-column
packet CSV and its packet_owner sidecar, in the customer's exact column layout, plus a ground-truth file that says
which command, NVMe transaction, split and link transaction every packet belongs to.

SYNTHETIC DATA: imitates the layout of the Teledyne LeCroy per-level CSV exports; it is not an analyzer export.

Containment rules (identity first, as the analyzer does; time only orders):
  packet -> link transaction     a TLP opens one; the Ack/Nak DLLP from the other direction whose AckNak Seq Num
                                 covers its PSN closes it (same PSN = explicit, higher = implicit); a Nak also
                                 acknowledges every TLP up to its number and marks the later ones refused; their
                                 replayed copies join the same link transaction
  link -> split transaction      a non-posted request opens one keyed by (direction, RequesterID, Tag); completions
                                 from the other direction with that RequesterID + Tag join it until the byte count
                                 is served or a non-SC completion ends it; posted writes and messages have none
  split/link -> NVMe transaction the generator's owner tag (command, part, index) names the transaction a TLP was
                                 emitted for; untagged TLPs are classified by address (controller register,
                                 doorbell, interrupt) or left outside the NVMe level (configuration, messages)
  NVMe transaction -> command    the owner's command sequence number

Conventions that the real export may do differently are gathered in CONV (settled from the manuals by the export
research note 04_export_and_grouping.md; change them there, not in the code below).

Usage
  python3 export_levels.py --csv t.csv --sidecars t_sidecars --out t_levels/
Outputs in --out: link.csv, split.csv, NVME_Transactions.csv, nvme_command.csv, packets.csv (a copy of the input
with the customer's header), truth_packet.csv (packet, link, split, ntx, cmd), truth_units.json (per-unit facts),
levels_manifest.json.
Memory: one streaming pass; finished units go to <out>/_stage.sqlite on disk, so a 4 GB packet file needs well under 1 GB of RAM.
"""
import argparse
import csv
import json
import os
import re
import sqlite3
import struct
import sys
from array import array

HERE = os.path.dirname(os.path.abspath(__file__))
COLUMNS_JSON = os.path.join(os.path.dirname(HERE), "lecroy_export_columns.json")

CONV = {
    "time_delta": "next_start_minus_this_start",   # per level: gap from this row's first packet to the next row's
    "count_ack_in_packets": True,                   # Metrics.# Packets counts the explicit Ack/Nak DLLP
    "nak_acknowledges_up_to_seq": True,             # PCIe retry rules: a Nak acknowledges every TLP up to its number
    "nak_counted_with": "first_refused",            # the Nak DLLP is counted once, in the first refused link transaction (inferred)
    "count_replays_in_packets": True,
    "split_dir": "request",                         # Link Dir of a split = direction of the request TLP
    "ntx_count": "splits_plus_posted_links",        # Metrics.# Link & Split Trans
    "explicit_ack_values": ("Yes", "No"),
    "link_speed": "16.0",
    "incomplete_split_status": "Incomplete",
    "ntx_types": {
        "dbl": "Submission Queue Tail Doorbell", "cqdbl": "Completion Queue Head Doorbell",
        "entry_admin": "Admin Submission Queue Entry", "entry_io": "I/O Submission Queue Entry",
        "prp": "PRP List", "data": "Transferred Data", "cqe_admin": "Admin Completion Queue Entry",
        "cqe_io": "I/O Completion Queue Entry", "irq": "MSI-X Interrupt", "reg": "Controller Register",
        "stray": "Transferred Data",
    },
    "error_cell": "%d error(s)", "warning_cell": "%d warning(s)",
    "separators": {"link.csv": 18, "split.csv": 9, "nvme_command.csv": 129, "NVME_Transactions.csv": 63, "packets.csv": 0},
}
LABEL_LESS = {("link.csv", "16.0"), ("split.csv", "16.0"), ("nvme_command.csv", "1 warning(s)"),
              ("nvme_command.csv", "2 error(s)"), ("nvme_command.csv", "1 error(s)"),
              ("NVME_Transactions.csv", "1 error(s)"), ("NVME_Transactions.csv", "1 warning(s)")}
BAR0 = 0xFCE00000
BAR0_SIZE = 0x4000
DOORBELL_OFF = 0x1000
MSIX_MASK, MSIX_BASE = 0xFFF00000, 0xFEE00000
REG_NAMES = {0x00: "CAP", 0x08: "VS", 0x0C: "INTMS", 0x10: "INTMC", 0x14: "CC", 0x1C: "CSTS", 0x20: "NSSR",
             0x24: "AQA", 0x28: "ASQ", 0x30: "ACQ", 0x38: "CMBLOC", 0x3C: "CMBSZ", 0x40: "BPINFO", 0x44: "BPRSEL",
             0x48: "BPMBL", 0x50: "CMBMSC", 0x58: "CMBSTS", 0xE00: "PMRCAP", 0xE04: "PMRCTL", 0xE08: "PMRSTS"}
IO_OPC = {0: "Flush", 1: "Write", 2: "Read", 4: "Write Uncorrectable", 5: "Compare", 8: "Write Zeroes",
          9: "Dataset Management", 0xC: "Verify", 0xD: "Reservation Register", 0xE: "Reservation Report",
          0x11: "Reservation Acquire", 0x15: "Reservation Release", 0x19: "Copy"}
ADMIN_OPC = {0: "Delete I/O SQ", 1: "Create I/O SQ", 2: "Get Log Page", 4: "Delete I/O CQ", 5: "Create I/O CQ",
             6: "Identify", 8: "Abort", 9: "Set Features", 0xA: "Get Features", 0xC: "Asynchronous Event Request",
             0x10: "Firmware Commit", 0x11: "Firmware Image Download", 0x18: "Keep Alive", 0x80: "Format NVM",
             0x81: "Security Send", 0x82: "Security Receive", 0x84: "Sanitize"}
STATUS_NAMES = {(0, 0): "Successful Completion", (0, 1): "Invalid Command Opcode", (0, 2): "Invalid Field in Command",
                (0, 3): "Command ID Conflict", (0, 4): "Data Transfer Error", (0, 5): "Commands Aborted due to Power Loss Notification",
                (0, 6): "Internal Error", (0, 7): "Command Abort Requested", (0, 8): "Command Aborted due to SQ Deletion",
                (0, 0xB): "Invalid Namespace or Format", (0, 0xC): "Command Sequence Error", (0, 0x13): "PRP Offset Invalid",
                (0, 0x80): "LBA Out of Range", (0, 0x81): "Capacity Exceeded", (0, 0x82): "Namespace Not Ready",
                (0, 0x83): "Reservation Conflict", (0, 0x84): "Format In Progress", (1, 0): "Completion Queue Invalid",
                (1, 1): "Invalid Queue Identifier", (1, 2): "Invalid Queue Size", (1, 3): "Abort Command Limit Exceeded",
                (1, 5): "Asynchronous Event Request Limit Exceeded", (1, 6): "Invalid Firmware Slot", (1, 7): "Invalid Firmware Image",
                (1, 8): "Invalid Interrupt Vector", (1, 9): "Invalid Log Page", (1, 0xA): "Invalid Format",
                (2, 0x80): "Write Fault", (2, 0x81): "Unrecovered Read Error", (2, 0x82): "End-to-end Guard Check Error",
                (2, 0x83): "End-to-end Application Tag Check Error", (2, 0x84): "End-to-end Reference Tag Check Error",
                (2, 0x85): "Compare Failure", (2, 0x86): "Access Denied", (2, 0x87): "Deallocated or Unwritten Logical Block",
                (3, 0): "Internal Path Error", (3, 1): "Asymmetric Access Persistent Loss", (3, 2): "Asymmetric Access Inaccessible",
                (3, 3): "Asymmetric Access Transition", (3, 0x60): "Controller Pathing Error", (3, 0x70): "Host Pathing Error"}
NON_POSTED = ("MRd(32)", "MRd(64)", "MRdLk(32)", "MRdLk(64)", "IORd", "IOWr", "CfgRd0", "CfgRd1", "CfgWr0", "CfgWr1",
              "FetchAdd", "Swap", "CAS")
POSTED = ("MWr(32)", "MWr(64)", "Msg", "MsgD", "DMWr")
CPLS = ("Cpl", "CplD", "CplLk", "CplDLk")
PS_UNITS = (("s", 10 ** 12), ("ms", 10 ** 9), ("us", 10 ** 6), ("ns", 10 ** 3))


# --------------------------------------------------------------------------------------------- small helpers
def ts_ps(s):
    m = re.match(r"^(\d+)\.(\d+)s$", s or "")
    return int(m.group(1)) * 10 ** 12 + int(m.group(2).ljust(12, "0")[:12]) if m else None


def fmt_ts(ps):
    return "%04d.%012ds" % (ps // 10 ** 12, ps % 10 ** 12)


def fmt_delta(ps):
    """Same style as the packet export: 3 decimals and the largest unit that keeps the number >= 1."""
    if ps is None:
        return ""
    a = abs(ps)
    for u, size in PS_UNITS:
        if a >= size:
            return "%.3f %s" % (ps / size, u)
    return "%d ps" % ps


def fmt_size(n):
    if n is None or n == 0:
        return ""
    if n % 1024 == 0 and n >= 1024:
        return "%d KB" % (n // 1024)
    return "%d B" % n


def hexint(s):
    """Addresses in the export are hexadecimal, with or without 0x (the generator writes 0x and 16 digits)."""
    s = (s or "").strip()
    if not s:
        return None
    try:
        m = re.match(r"^([0-9A-Fa-f]{1,8}):([0-9A-Fa-f]{8})$", s)
        if m:
            return (int(m.group(1), 16) << 32) | int(m.group(2), 16)
        if s.lower().startswith("0x"):
            return int(s, 16)
        if re.match(r"^[0-9A-Fa-f]+$", s) and (len(s) >= 8 or re.search(r"[A-Fa-f]", s)):
            return int(s, 16)
        return int(s)
    except ValueError:
        return None


def hexbytes(s):
    s = (s or "").strip()
    if not s or not re.match(r"^([0-9A-Fa-f]{2}\s*)+$", s):
        return None
    return bytes.fromhex(s.replace(" ", ""))


def opcode_name(opc, qid):
    return (ADMIN_OPC if qid == 0 else IO_OPC).get(opc, "Vendor Specific 0x%02X" % opc)


def decode_sqe(b):
    dw = struct.unpack("<16I", b)
    f = {"OPC": dw[0] & 0xFF, "FUSE": (dw[0] >> 8) & 3, "PSDT": (dw[0] >> 14) & 3, "CID": dw[0] >> 16, "NSID": dw[1],
         "MPTR": dw[4] | (dw[5] << 32), "PRP1": dw[6] | (dw[7] << 32), "PRP2": dw[8] | (dw[9] << 32),
         "CDW10": dw[10], "CDW11": dw[11], "CDW12": dw[12], "CDW13": dw[13], "CDW14": dw[14], "CDW15": dw[15]}
    f["SLBA"] = dw[10] | (dw[11] << 32)
    f["NLB"] = dw[12] & 0xFFFF
    f["FUA"] = (dw[12] >> 30) & 1
    f["LR"] = (dw[12] >> 31) & 1
    f["PRINFO"] = (dw[12] >> 26) & 0xF
    return f


def decode_cqe(b):
    dw0, dw1, dw2, dw3 = struct.unpack("<4I", b)
    st = dw3 >> 17
    return {"DW0": dw0, "SQHD": dw2 & 0xFFFF, "SQID": dw2 >> 16, "CID": dw3 & 0xFFFF, "P": (dw3 >> 16) & 1,
            "SC": st & 0xFF, "SCT": (st >> 8) & 7, "CRD": (st >> 11) & 3, "M": (st >> 13) & 1, "DNR": (st >> 14) & 1}


# --------------------------------------------------------------------------------------------- writing
def customer_header(fname, columns):
    """Named columns in the customer's order with blank separator columns inserted at field-group boundaries
    (count from the customer's overview) and blank cells for the label-less columns. Returns (header, positions)."""
    names = columns[fname]
    nsep = CONV["separators"].get(fname, 0)
    boundaries = []
    for i in range(1, len(names)):
        a, b = names[i - 1], names[i]
        ga, gb = a.split(".")[0] if "." in a else None, b.split(".")[0] if "." in b else None
        if (ga or gb) and ga != gb:
            boundaries.append(i)
    chosen = set(boundaries[:nsep]) if len(boundaries) >= nsep else set(boundaries)
    extra = nsep - len(chosen)
    hdr, pos = [], []
    for i, n in enumerate(names):
        if i in chosen:
            hdr.append("")
        pos.append(len(hdr))
        hdr.append("" if (fname, n) in LABEL_LESS else n)
    hdr += [""] * max(0, extra)
    return hdr, pos


class Writer:
    def __init__(self, path, fname, columns):
        self.hdr, self.pos = customer_header(fname, columns)
        self.names = columns[fname]
        self.idx = {n: self.pos[i] for i, n in enumerate(self.names)}
        self.fh = open(path, "w", newline="", encoding="utf-8")
        self.w = csv.writer(self.fh, lineterminator="\r\n")
        self.w.writerow(self.hdr)
        self.n = 0

    def row(self, values):
        r = [""] * len(self.hdr)
        for k, v in values.items():
            if v is None or v == "":
                continue
            i = self.idx.get(k)
            if i is not None:
                r[i] = str(v)
        self.w.writerow(r)
        self.n += 1

    def close(self):
        self.fh.close()


def deltas(rows_t):
    """Time Delta per row from the row start times (CONV time_delta)."""
    out = []
    for i, t in enumerate(rows_t):
        nxt = rows_t[i + 1] if i + 1 < len(rows_t) else None
        out.append(fmt_delta(nxt - t) if (nxt is not None and t is not None) else "")
    return out


def errcell(lst, kind):
    if not lst:
        return ""
    return (CONV["error_cell"] if kind == "e" else CONV["warning_cell"]) % len(lst)


# --------------------------------------------------------------------------------------------- the streaming pass
# Everything below works in ONE pass over the packet CSV. Only the OPEN units (link transactions waiting for their
# Ack, split transactions waiting for completions, the NVMe-transaction ids seen so far) live in memory; every
# finished unit and every packet's membership go straight into a SQLite staging file on disk (<out>/_stage.sqlite),
# and the five CSVs are then written from that file. Memory stays flat whatever the capture size.

BATCH = 20000
FIRST_UNIT_RELATION = "member"


def classify_unowned(addr, tlp):
    """An untagged TLP: controller register, doorbell or interrupt by address; else outside the NVMe level."""
    if tlp in CPLS or addr is None:
        return None
    if BAR0 <= addr < BAR0 + BAR0_SIZE:
        off = addr - BAR0
        return ("dbl", off) if off >= DOORBELL_OFF else ("reg", off)
    if (addr & MSIX_MASK) == MSIX_BASE:
        return ("irq", 0)
    return None


def read_command_opcodes(event_log):
    """seq -> opcode from the generator's event log (only used when a command's entry was never fetched)."""
    opc = {}
    with open(event_log, encoding="utf-8") as fh:
        for line in fh:
            e = json.loads(line)
            if e.get("event") in ("nvme_cmd_done", "nvme_cqe_never_posted", "nvme_submit_not_fetched",
                                  "nvme_cmd_lost_in_controller") and e.get("seq") and e.get("opc") is not None:
                opc[e["seq"]] = e["opc"]
    return opc


def owner_stream(path):
    """Yields (packet number, (seq, qid, cid, part, index)) in packet order; the sidecar is written in that order."""
    with open(path, newline="", encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            if r["cmd_seq"]:
                yield int(r["packet"]), (int(r["cmd_seq"]), int(r["qid"]), int(r["cid"]), r["part"], r["index"])


class Stage:
    """The on-disk staging store: packets' membership and the finished units."""

    def __init__(self, path):
        if os.path.exists(path):
            os.remove(path)
        self.db = sqlite3.connect(path)
        self.db.executescript("""
            PRAGMA journal_mode=OFF; PRAGMA synchronous=OFF; PRAGMA cache_size=-200000; PRAGMA temp_store=FILE;
            CREATE TABLE pkt(n INTEGER PRIMARY KEY, t INTEGER, kind TEXT, tlp TEXT, length INTEGER, replay INTEGER,
                             link INTEGER, split INTEGER, ntx INTEGER);
            CREATE TABLE lnk(id INTEGER PRIMARY KEY, t INTEGER, dir TEXT, psn INTEGER, tlp TEXT, length INTEGER,
                             rid TEXT, tag TEXT, cplid TEXT, cstatus TEXT, bcm TEXT, bytecnt INTEGER, lwr TEXT,
                             routing TEXT, msgcode TEXT, attr TEXT, addr INTEGER, fbe TEXT, lbe TEXT,
                             npkts INTEGER, nak INTEGER, status TEXT, ntx INTEGER, ack_pkt INTEGER);
            CREATE TABLE spl(id INTEGER PRIMARY KEY, t INTEGER, dir TEXT, tlp TEXT, rid TEXT, tag TEXT, addr INTEGER,
                             cplid TEXT, status TEXT, got INTEGER, ncpl INTEGER, ntx INTEGER);
            CREATE TABLE ntx(id INTEGER PRIMARY KEY, seq INTEGER, part TEXT, idx TEXT, qid INTEGER, cid INTEGER,
                             t INTEGER, dir TEXT, addr INTEGER, tlp TEXT, type TEXT, fields TEXT, dsm BLOB,
                             nbytes INTEGER, cnt INTEGER, nerr INTEGER, nwarn INTEGER);
            CREATE TABLE cmdid(seq INTEGER PRIMARY KEY, id INTEGER);
        """)
        self.buf = {"pkt": [], "lnk": [], "spl": [], "ntx": []}
        self.sql = {"pkt": "INSERT INTO pkt VALUES (?,?,?,?,?,?,?,?,?)",
                    "lnk": "INSERT INTO lnk VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    "spl": "INSERT INTO spl VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                    "ntx": "INSERT INTO ntx(id,seq,part,idx,qid,cid,t,dir,addr,tlp,type,fields) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"}

    def add(self, table, row):
        b = self.buf[table]
        b.append(row)
        if len(b) >= BATCH:
            self.flush(table)

    def flush(self, table=None):
        for tname in ([table] if table else list(self.buf)):
            if self.buf[tname]:
                self.db.executemany(self.sql[tname], self.buf[tname])
                self.buf[tname] = []

    def done_inserting(self):
        self.flush()
        self.db.executescript("CREATE INDEX ntx_seq ON ntx(seq); CREATE INDEX pkt_ntx ON pkt(ntx);")
        self.db.commit()


class Pass:
    """State of the single pass over the packets."""

    def __init__(self, stage, owners, opc_of_seq):
        self.st, self.owners, self.opc_of_seq = stage, owners, opc_of_seq
        self.next_owner = next(owners, None)
        self.open_links = {"Upstream": {}, "Downstream": {}}     # dir -> psn -> link record (list)
        self.order = {"Upstream": [], "Downstream": []}          # open PSNs in emission order
        self.open_req = {}                                        # (dir, rid, tag) -> split record
        self.n_links = self.n_splits = self.n_ntx = 0
        self.ntx_id = {}                                          # key -> ntx id
        self.ntx_part, self.ntx_tlp = [None], [None]              # per ntx id (index 0 unused)
        self.cplbytes, self.postbytes = array("q", [0]), array("q", [0])
        self.nlinks, self.nposted, self.nsplits = array("q", [0]), array("q", [0]), array("q", [0])
        self.nerr, self.nwarn = array("q", [0]), array("q", [0])
        self.entry_acc = {}                                       # ntx id -> bytearray (submission entry being fetched)
        self.entry_fields = []                                    # (fields json, ntx id) to update
        self.dsm_first = {}                                       # seq -> ntx id of its first data transaction
        self.dsm_acc = {}                                         # ntx id -> bytearray (DSM range list)
        self.link_status, self.split_status, self.ntx_parts = {}, {}, {}

    # ---- link records: [id, t, dir, psn, tlp, length, rid, tag, cplid, cstatus, bcm, bytecnt, lwr, routing,
    #                     msgcode, attr, addr, fbe, lbe, npkts, nak, status, ntx, ack_pkt]
    def flush_link(self, lt):
        nid = lt[22]
        if nid is not None:
            if lt[21] == "Incomplete":
                self.nerr[nid] += 1
            if lt[20]:
                self.nwarn[nid] += 1
        self.link_status[lt[21]] = self.link_status.get(lt[21], 0) + 1
        self.st.add("lnk", lt)

    # ---- split records: [id, t, dir, tlp, rid, tag, addr, cplid, status, got, ncpl, ntx, need, ntxs(set)]
    def flush_split(self, sp):
        if sp[8] is None:
            sp[8] = CONV["incomplete_split_status"]
        for nid in sp[13]:
            if sp[8] == CONV["incomplete_split_status"] or sp[8] != "SC":
                self.nerr[nid] += 1
        self.split_status[sp[8]] = self.split_status.get(sp[8], 0) + 1
        self.st.add("spl", sp[:12])

    def new_ntx(self, key, seq, part, idx, qid, cid, t, dir_, addr, tlp, data):
        self.n_ntx += 1
        nid = self.n_ntx
        self.ntx_id[key] = nid
        for a in (self.cplbytes, self.postbytes, self.nlinks, self.nposted, self.nsplits, self.nerr, self.nwarn):
            a.append(0)
        self.ntx_part.append(part)
        self.ntx_tlp.append(tlp)
        fields = {}
        if part == "entry":
            typ = CONV["ntx_types"]["entry_admin" if qid == 0 else "entry_io"]
        elif part == "cqe":
            typ = CONV["ntx_types"]["cqe_admin" if qid == 0 else "cqe_io"]
            raw = hexbytes(data)
            if raw and len(raw) >= 16:
                fields = decode_cqe(raw[:16])
        elif part == "reg":
            typ = "%s (%s)" % (CONV["ntx_types"]["reg"], REG_NAMES.get(idx, "offset 0x%X" % idx))
        elif part == "dbl" and seq is None:
            off = idx - DOORBELL_OFF
            q, is_cq = divmod(off // 4, 2)
            typ = CONV["ntx_types"]["cqdbl" if is_cq else "dbl"]
            qid = q
        else:
            typ = CONV["ntx_types"].get(part, part)
        if part in ("dbl", "cqdbl"):
            raw = hexbytes(data)
            if raw:
                fields["Doorbell index"] = int.from_bytes(raw[:4], "little")
        self.ntx_parts[part] = self.ntx_parts.get(part, 0) + 1
        self.st.add("ntx", [nid, seq, part, str(idx) if idx is not None else None, qid, cid, t, dir_, addr, tlp, typ,
                            json.dumps(fields) if fields else None])
        return nid

    def packet(self, n, dir_, tlp, dllp, ordset, psn, ack, rid, tag, cplid, addr, length, cstatus, bytecnt, t, data,
               fbe, lbe, lwr, bcm, msgcode, routing, attr):
        kind = "TLP" if tlp else ("DLLP" if dllp else ("OS" if ordset else "EVENT"))
        # the owner tag of this packet, if any (the sidecar is in packet order)
        owner = None
        while self.next_owner is not None and self.next_owner[0] < n:
            self.next_owner = next(self.owners, None)
        if self.next_owner is not None and self.next_owner[0] == n:
            owner = self.next_owner[1]
            self.next_owner = next(self.owners, None)
        link_id = split_id = nid = None
        replay = 0
        if kind == "TLP":
            # ---- link transaction
            ob = self.open_links[dir_]
            lt = ob.get(psn)
            new_link = lt is None
            if lt is not None:
                lt[19] += 1
                replay = 1
            else:
                self.n_links += 1
                lt = [self.n_links, t, dir_, psn, tlp, length, rid, tag, cplid, cstatus, bcm, bytecnt, lwr, routing,
                      msgcode, attr, addr, fbe, lbe, 1, 0, "Incomplete", None, None]
                ob[psn] = lt
                self.order[dir_].append(psn)
            link_id = lt[0]
            # ---- split transaction (never for a replayed copy)
            sp = None
            if not replay:
                if tlp in NON_POSTED:
                    key = (dir_, rid, tag)
                    old = self.open_req.get(key)
                    if old is not None:                           # tag reused while open: the earlier one stays incomplete
                        self.flush_split(old)
                    self.n_splits += 1
                    need = length * 4 if tlp.startswith("MRd") else 4
                    if tlp in ("IOWr", "CfgWr0", "CfgWr1"):
                        need = 0
                    sp = [self.n_splits, t, dir_, tlp, rid, tag, addr, "", None, 0, 0, None, need, set()]
                    self.open_req[key] = sp
                    split_id = sp[0]
                elif tlp in CPLS:
                    cdir = "Upstream" if dir_ == "Downstream" else "Downstream"
                    sp = self.open_req.get((cdir, rid, tag))
                    if sp is not None:
                        sp[10] += 1
                        sp[7] = cplid
                        sp[9] += length * 4 if tlp in ("CplD", "CplDLk") else 0
                        sp[8] = cstatus or "SC"
                        split_id = sp[0]
            # ---- NVMe transaction
            key = None
            if owner:
                seq, qid, cid, part, idx = owner
                key = (seq, part, idx)
            elif replay:
                nid = lt[22]
            else:
                c = classify_unowned(addr, tlp)
                if c is None:
                    if tlp in CPLS and sp is not None:
                        nid = sp[11]
                else:
                    key = ("U", n, c[0])
                    seq, qid, cid, part, idx = None, None, None, c[0], c[1]
            if key is not None:
                nid = self.ntx_id.get(key)
                if nid is None:
                    nid = self.new_ntx(key, seq, part, idx, qid, cid, t, dir_, addr, tlp, data)
                    if part == "data" and seq is not None and self.opc_of_seq.get(seq) == 9 and qid != 0 and seq not in self.dsm_first:
                        self.dsm_first[seq] = nid
                        self.dsm_acc[nid] = bytearray()
            if nid is not None:
                if new_link:
                    lt[22] = nid
                    self.nlinks[nid] += 1
                    if tlp in POSTED:
                        self.nposted[nid] += 1
                if sp is not None and nid not in sp[13]:
                    sp[13].add(nid)
                    self.nsplits[nid] += 1
                    if sp[11] is None:
                        sp[11] = nid
                if not replay:
                    if tlp in ("CplD", "CplDLk"):
                        self.cplbytes[nid] += length * 4
                        part_ = self.ntx_part[nid]
                        if part_ == "entry" and len(self.entry_acc.get(nid, b"")) < 64 and nid not in self.entry_fields_done():
                            acc = self.entry_acc.setdefault(nid, bytearray())
                            acc += hexbytes(data) or b""
                            if len(acc) >= 64:
                                f = decode_sqe(bytes(acc[:64]))
                                self.entry_fields.append((json.dumps(f), nid))
                                seq_ = key[0] if key is not None and key[0] != "U" else None
                                if seq_ is not None:
                                    self.opc_of_seq[seq_] = f["OPC"]
                                del self.entry_acc[nid]
                                self._entry_done.add(nid)
                        elif part_ == "data" and nid in self.dsm_acc:
                            self.dsm_acc[nid] += hexbytes(data) or b""
                    elif tlp in POSTED:
                        self.postbytes[nid] += length * 4
            # ---- close the split if served
            if sp is not None and tlp in CPLS and (sp[8] != "SC" or sp[9] >= sp[12]):
                self.flush_split(sp)
                cdir = "Upstream" if dir_ == "Downstream" else "Downstream"
                self.open_req.pop((cdir, rid, tag), None)
        elif kind == "DLLP" and dllp in ("ACK", "NAK", "Ack", "Nak") and ack is not None:
            tdir = "Upstream" if dir_ == "Downstream" else "Downstream"   # acknowledges TLPs of the other direction
            seq = ack
            if dllp.upper() == "ACK":
                done = []
                for psn_ in self.order[tdir]:
                    if ((seq - psn_) & 0xFFF) < 2048:          # psn <= seq (mod 4096)
                        lt = self.open_links[tdir][psn_]
                        lt[21] = "Explicitly Acknowledged" if psn_ == seq else "Implicitly Acknowledged"
                        if psn_ == seq:
                            lt[23] = n
                            lt[19] += 1
                            link_id = lt[0]
                        done.append(psn_)
                        self.flush_link(lt)
                if done:
                    for psn_ in done:
                        self.open_links[tdir].pop(psn_, None)
                    ds = set(done)
                    self.order[tdir] = [x for x in self.order[tdir] if x not in ds]
            else:
                # a Nak names the last TLP received correctly: every open TLP up to that number is acknowledged by it
                # (closed, "Implicitly Acknowledged": it got no Ack of its own); the later ones are refused and will be replayed
                done, refused = [], []
                for psn_ in self.order[tdir]:
                    lt = self.open_links[tdir][psn_]
                    if ((seq - psn_) & 0xFFF) < 2048:                    # psn <= seq: acknowledged by the Nak
                        lt[21] = "Implicitly Acknowledged"
                        done.append(psn_)
                        self.flush_link(lt)
                    else:                                              # psn > seq: refused, will be replayed
                        lt[20] += 1
                        refused.append(lt)
                if refused:
                    # one packet has one parent: the Nak is counted once, with the first refused TLP (the one it reports)
                    first = min(refused, key=lambda x: (x[3] - seq) & 0xFFF)
                    first[19] += 1
                    link_id = first[0]
                if done:
                    for psn_ in done:
                        self.open_links[tdir].pop(psn_, None)
                    ds = set(done)
                    self.order[tdir] = [x for x in self.order[tdir] if x not in ds]
        self.st.add("pkt", (n, t, kind, tlp, length, replay, link_id, split_id, nid))

    _entry_done = set()

    def entry_fields_done(self):
        return self._entry_done

    def finish(self):
        """End of the capture: what is still open stays incomplete."""
        for d in ("Upstream", "Downstream"):
            for psn_ in self.order[d]:
                self.flush_link(self.open_links[d][psn_])
            self.open_links[d], self.order[d] = {}, []
        for sp in list(self.open_req.values()):
            self.flush_split(sp)
        self.open_req = {}
        self.st.flush()
        db = self.st.db
        if self.entry_fields:
            db.executemany("UPDATE ntx SET fields=? WHERE id=?", self.entry_fields)
            self.entry_fields = []
        dsm = [(bytes(b), nid) for nid, b in self.dsm_acc.items() if b]
        if dsm:
            db.executemany("UPDATE ntx SET dsm=? WHERE id=?", dsm)
        rows = []
        for nid in range(1, self.n_ntx + 1):
            part, tlp = self.ntx_part[nid], self.ntx_tlp[nid] or ""
            if part in ("entry", "prp") or (part == "data" and tlp.startswith("MRd")):
                nbytes = self.cplbytes[nid]
            else:
                nbytes = self.postbytes[nid]
            if CONV["ntx_count"] == "splits_plus_posted_links":
                cnt = self.nsplits[nid] + self.nposted[nid]
            else:
                cnt = self.nlinks[nid] + self.nsplits[nid]
            rows.append((nbytes, cnt, self.nerr[nid], self.nwarn[nid], nid))
            if len(rows) >= BATCH:
                db.executemany("UPDATE ntx SET nbytes=?, cnt=?, nerr=?, nwarn=? WHERE id=?", rows)
                rows = []
        if rows:
            db.executemany("UPDATE ntx SET nbytes=?, cnt=?, nerr=?, nwarn=? WHERE id=?", rows)
        db.commit()


def run_pass(csv_path, sidecars, stage, progress):
    opc_of_seq = read_command_opcodes(os.path.join(sidecars, "scenario_event_log.jsonl"))
    owners = owner_stream(os.path.join(sidecars, "packet_owner.csv"))
    ps = Pass(stage, owners, opc_of_seq)
    ps._entry_done = set()
    with open(csv_path, newline="", encoding="utf-8") as fh:
        rd = csv.reader(fh)
        header = next(rd)
        col = {h: i for i, h in enumerate(header)}
        need = ["Packet", "Link Dir", "TLP Type", "DLLP Type", "Ord.Set Type", "PSN", "AckNak Seq Num", "RequesterID", "Tag",
                "CompleterID", "Address", "Length", "Cpl Status", "Byte Cnt", "Time Stamp", "DATA", "st BE", "1st BE",
                "Last BE", "Lwr Addr", "BCM", "Message Code", "Msg Routing", "Attributes"]
        ix = {k: col.get(k) for k in need}
        nrow = 0
        for row in rd:
            L = len(row)
            g = lambda k: (row[ix[k]] if ix[k] is not None and ix[k] < L else "")   # noqa: E731
            n_s = g("Packet")
            ps.packet(int(n_s) if n_s else None, g("Link Dir"), g("TLP Type") or None, g("DLLP Type") or None,
                      g("Ord.Set Type"), int(g("PSN")) if g("PSN") else None, int(g("AckNak Seq Num")) if g("AckNak Seq Num") else None,
                      g("RequesterID"), g("Tag"), g("CompleterID"), hexint(g("Address")), int(g("Length")) if g("Length") else 0,
                      g("Cpl Status"), int(g("Byte Cnt")) if g("Byte Cnt") else None, ts_ps(g("Time Stamp")), g("DATA"),
                      g("st BE") or g("1st BE"), g("Last BE"), g("Lwr Addr"), g("BCM"), g("Message Code"), g("Msg Routing"), g("Attributes"))
            nrow += 1
            if nrow % 500000 == 0:
                progress("pass: %d packets, %d link, %d split, %d NVMe transactions so far" % (nrow, ps.n_links, ps.n_splits, ps.n_ntx))
    ps.finish()
    stage.done_inserting()
    progress("pass done: %d packets, %d link, %d split, %d NVMe transactions" % (nrow, ps.n_links, ps.n_splits, ps.n_ntx))
    return ps, nrow


def with_next(cur):
    """Yields (row, next_row_or_None) from a cursor, one row of lookahead (for Time Delta = gap to the next row)."""
    prev = None
    for r in cur:
        if prev is not None:
            yield prev, r
        prev = r
    if prev is not None:
        yield prev, None


def delta_cell(t, nxt):
    return fmt_delta(nxt - t) if (nxt is not None and t is not None) else ""


def export(csv_path, sidecars, out_dir, mn="Synthetic NVMe SSD 1TB", device_id="002:00:0", keep_stage=False, progress=None):
    progress = progress or (lambda m: print(m, flush=True))
    columns = json.load(open(COLUMNS_JSON, encoding="utf-8"))["columns"]
    os.makedirs(out_dir, exist_ok=True)
    stage_path = os.path.join(out_dir, "_stage.sqlite")
    stage = Stage(stage_path)
    ps, n_packets = run_pass(csv_path, sidecars, stage, progress)
    db = stage.db
    # ---- link.csv
    w = Writer(os.path.join(out_dir, "link.csv"), "link.csv", columns)
    cur = db.execute("SELECT id,t,dir,psn,tlp,length,rid,tag,cplid,cstatus,bcm,bytecnt,lwr,routing,msgcode,attr,addr,fbe,lbe,npkts,nak,status,ntx,ack_pkt FROM lnk ORDER BY id")
    for r, nx in with_next(cur):
        (lid, t, dir_, psn, tlp, length, rid, tag, cplid, cstatus, bcm, bytecnt, lwr, routing, msgcode, attr, addr, fbe, lbe,
         npkts, nak, status, _nid, _ack) = r
        v = {"Link Tra": lid, "Link Dir": dir_, "16.0": CONV["link_speed"], "PSN": psn, "VC ID": 0,
             "Metrics": "", "Metrics.# Packets": npkts if CONV["count_ack_in_packets"] else 1 + nak,
             "Time Delta": delta_cell(t, nx[1] if nx else None), "Time Stamp": fmt_ts(t), "RequesterID": rid, "Tag": tag,
             "Explicit ACK": CONV["explicit_ack_values"][0] if status == "Explicitly Acknowledged" else CONV["explicit_ack_values"][1]}
        if status == "Incomplete":
            v["Link Tra Error"] = "Incomplete (no Ack)"
        elif nak:
            v["Link Tra Error"] = "Nak received, replayed %d time%s" % (nak, "" if nak == 1 else "s")
        if tlp in CPLS:
            v.update({"Cpl": "", "Cpl.TLP Type": tlp, "Cpl.Length": length, "CompleterID": cplid, "Cpl Status": cstatus,
                      "BCM": bcm, "Byte Cnt": bytecnt, "Lwr Addr": lwr, "Data": fmt_size(length * 4 if tlp.endswith("D") or tlp == "CplDLk" else 0)})
        elif tlp in ("Msg", "MsgD"):
            v.update({"Msg": "", "Msg.TLP Type": tlp, "Msg.Msg Routing": routing, "Msg.Length": length, "Message Code": msgcode})
        else:
            v.update({"Mem": "", "Mem.TLP Type": tlp, "Mem.Attributes": attr, "Mem.Length": length,
                      "Address": ("0x%016X" % addr) if addr is not None else "", "1st BE": fbe, "Last BE": lbe,
                      "Data": fmt_size(length * 4 if tlp in POSTED or tlp in ("IOWr", "CfgWr0", "CfgWr1") else 0)})
        w.row(v)
    w.close()
    progress("link.csv written: %d rows" % w.n)
    # ---- split.csv
    w = Writer(os.path.join(out_dir, "split.csv"), "split.csv", columns)
    cur = db.execute("SELECT id,t,dir,tlp,rid,tag,addr,cplid,status,got,ncpl FROM spl ORDER BY id")
    for r, nx in with_next(cur):
        sid, t, dir_, tlp, rid, tag, addr, cplid, status, got, ncpl = r
        w.row({"Split Tra": sid, "Link Dir": dir_, "16.0": CONV["link_speed"], "Mem": "", "Mem.TLP Type": tlp,
               "RequesterID": rid, "CompleterID": cplid or "", "Tag": tag, "TC": 0, "VC ID": 0,
               "Address": ("0x%016X" % addr) if addr is not None else "", "Cpl Status": status,
               "Data": fmt_size(got), "Metrics": "", "Metrics.# LinkTrans": 1 + ncpl,
               "Time Delta": delta_cell(t, nx[1] if nx else None), "Time Stamp": fmt_ts(t)})
    w.close()
    progress("split.csv written: %d rows" % w.n)
    # ---- NVME_Transactions.csv
    w = Writer(os.path.join(out_dir, "NVME_Transactions.csv"), "NVME_Transactions.csv", columns)
    cur = db.execute("SELECT id,seq,part,qid,cid,t,dir,addr,type,fields,nbytes,cnt,nerr,nwarn FROM ntx ORDER BY id")
    for r, nx in with_next(cur):
        nid, seq, part, qid, cid, t, dir_, addr, typ, fields, nbytes, cnt, nerr, nwarn = r
        f = json.loads(fields) if fields else {}
        v = {"NVMe": nid, "Link Dir": dir_, "Device ID": device_id, "Type": typ, "MN": mn,
             "Address": ("0x%016X" % addr) if addr is not None else "", "Metrics": "",
             "Metrics.# Link & Split Trans": cnt, "Time Delta": delta_cell(t, nx[5] if nx else None), "Time Stamp": fmt_ts(t),
             "Data": fmt_size(nbytes), "1 error(s)": errcell_n(nerr, "e"), "1 warning(s)": errcell_n(nwarn, "w")}
        if part in ("dbl", "cqdbl"):
            v.update({"QID": qid, "Doorbell index": f.get("Doorbell index")})
        if part in ("entry", "cqe", "prp", "data", "irq", "stray"):
            v.update({"SQID": qid, "CID": cid})
        if part == "entry" and f:
            v.update({"MPTR": "", "MPTR.Address": "0x%016X" % f["MPTR"] if f["MPTR"] else "", "PRP1": "", "PRP1.Address": "0x%016X" % f["PRP1"] if f["PRP1"] else "",
                      "PRP2": "", "PRP2.Address": "0x%016X" % f["PRP2"] if f["PRP2"] else ""})
            if qid != 0 and f["OPC"] in (1, 2, 4, 5, 8, 0xC):
                v.update({"SLBA": f["SLBA"], "NLB": f["NLB"], "FUA": f["FUA"], "LR": f["LR"], "PRINFO": f["PRINFO"]})
            if qid == 0 and f["OPC"] == 6:
                v.update({"CNS": f["CDW10"] & 0xFF, "CNTID": f["CDW10"] >> 16})
            if qid == 0 and f["OPC"] in (1, 5):
                v.update({"QID": f["CDW10"] & 0xFFFF, "QSIZE": (f["CDW10"] >> 16) + 1})
            if qid == 0 and f["OPC"] in (9, 0xA):
                v.update({"FID": f["CDW10"] & 0xFF})
        if part == "cqe" and f:
            v.update({"P": f["P"], "DW0": "0x%08X" % f["DW0"], "ST": "0x%04X" % ((f["SCT"] << 8) | f["SC"]),
                      "SCT": f["SCT"], "SC": f["SC"], "CRD": f["CRD"], "M": f["M"], "DNR": f["DNR"]})
        w.row(v)
    w.close()
    progress("NVME_Transactions.csv written: %d rows" % w.n)
    # ---- nvme_command.csv: commands in the order of their first NVMe transaction; each command's transactions by one
    #      indexed query (memory flat)
    w = Writer(os.path.join(out_dir, "nvme_command.csv"), "nvme_command.csv", columns)
    cmd_order = db.execute("SELECT seq, MIN(id), MIN(t) FROM ntx WHERE seq IS NOT NULL GROUP BY seq ORDER BY 2")
    q = db.cursor()
    cmd_errors = 0
    cmd_rows = []
    for (seq, _first, t), nx in with_next(cmd_order):
        cid_ = w.n + 1
        cmd_rows.append((seq, cid_))
        if len(cmd_rows) >= BATCH:
            db.executemany("INSERT INTO cmdid VALUES (?,?)", cmd_rows)
            cmd_rows = []
        parts = q.execute("SELECT id,part,qid,cid,dir,fields,dsm,nbytes,nerr,nwarn FROM ntx WHERE seq=? ORDER BY id", (seq,)).fetchall()
        qid, cmd_cid, dir_ = parts[0][2], parts[0][3], parts[0][4]
        sqe, cqe, dsm, nbytes, nerr, nwarn, seen = {}, {}, None, 0, 0, 0, set()
        for (_nid, part, _q, _c, _d, fields, dsm_, nb, ne, nw) in parts:
            seen.add(part)
            if part == "entry" and fields:
                sqe = json.loads(fields)
            if part == "cqe" and fields and not cqe:
                cqe = json.loads(fields)
            if part == "data":
                nbytes += nb or 0
                if dsm is None and dsm_:
                    dsm = dsm_
            nerr += ne or 0
            nwarn += nw or 0
        if "cqe" not in seen:
            nerr += 1
        if "entry" not in seen:
            nerr += 1
        if nerr:
            cmd_errors += 1
        f = sqe
        opc = f.get("OPC", ps.opc_of_seq.get(seq))
        v = {"NVMe Cmd": cid_, "Link Dir": dir_, "OPC": "0x%02X (%s)" % (opc, opcode_name(opc, qid)) if opc is not None else "",
             "SQID": qid, "CQID": qid, "CID": cmd_cid, "Device ID": device_id, "MN": mn, "NSID": f.get("NSID"),
             "Data": fmt_size(nbytes), "Metrics": "", "Metrics.# NVME Trans": len(parts), "Time Delta": delta_cell(t, nx[2] if nx else None),
             "Time Stamp": fmt_ts(t), "2 error(s)": errcell_n(nerr, "e"), "1 warning(s)": errcell_n(nwarn, "w")}
        if f:
            v.update({"MPTR": "0x%016X" % f["MPTR"] if f["MPTR"] else "", "PRP1": "0x%016X" % f["PRP1"] if f["PRP1"] else "",
                      "PRP2": "0x%016X" % f["PRP2"] if f["PRP2"] else ""})
            if qid != 0 and opc in (1, 2, 4, 5, 8, 0xC):
                v.update({"SLBA": f["SLBA"], "NLB": f["NLB"], "FUA": f["FUA"], "LR": f["LR"], "PRINFO": f["PRINFO"]})
            if qid == 0 and opc == 6:
                v.update({"CNS": f["CDW10"] & 0xFF, "CNTID": f["CDW10"] >> 16, "CSI": f["CDW11"] >> 24})
            if qid == 0 and opc in (1, 5):
                v.update({"QID": f["CDW10"] & 0xFFFF, "QSIZE": (f["CDW10"] >> 16) + 1, "PC": f["CDW11"] & 1,
                          "IV": (f["CDW11"] >> 16) if opc == 5 else None})
            if qid == 0 and opc in (9, 0xA):
                v.update({"FID": f["CDW10"] & 0xFF, "SV": (f["CDW10"] >> 31) & 1})
            if qid == 0 and opc == 2:
                v.update({"LID": f["CDW10"] & 0xFF, "LSP": (f["CDW10"] >> 8) & 0xF, "RAE": (f["CDW10"] >> 15) & 1,
                          "NUMDL": f["CDW10"] >> 16, "NUMDU": f["CDW11"] & 0xFFFF})
            if qid != 0 and opc == 9:
                v.update({"NR": f["CDW10"] & 0xFF, "IDR": f["CDW11"] & 1, "IDW": (f["CDW11"] >> 1) & 1, "AD": (f["CDW11"] >> 2) & 1})
                if dsm:
                    for r in range(min(64, (f["CDW10"] & 0xFF) + 1, len(dsm) // 16)):
                        ca, nlb, slba = struct.unpack_from("<IIQ", dsm, r * 16)
                        v["RNG %d" % r] = ""
                        v["RNG %d.Length LB" % r] = nlb
                        v["RNG %d.SLBA" % r] = slba
                        v["RNG %d.AF" % r] = ca & 0xF
                        v["RNG %d.AL" % r] = (ca >> 4) & 3
                        v["RNG %d.SR" % r] = (ca >> 6) & 1
                        v["RNG %d.SW" % r] = (ca >> 7) & 1
                        v["RNG %d.WP" % r] = (ca >> 8) & 1
                        v["RNG %d.CAS" % r] = (ca >> 10) & 1
        if cqe:
            v.update({"ST": "0x%04X (%s)" % ((cqe["SCT"] << 8) | cqe["SC"], STATUS_NAMES.get((cqe["SCT"], cqe["SC"]), "status")),
                      "ST.SCT": cqe["SCT"], "ST.SC": cqe["SC"]})
        w.row(v)
    w.close()
    if cmd_rows:
        db.executemany("INSERT INTO cmdid VALUES (?,?)", cmd_rows)
    db.commit()
    n_cmds = w.n
    progress("nvme_command.csv written: %d rows" % n_cmds)
    # ---- packets.csv: the input with the customer's packet header, copied in blocks (never held in memory)
    with open(csv_path, "rb") as src, open(os.path.join(out_dir, "packets.csv"), "wb") as dst:
        hdr = src.readline()
        text = hdr.decode("utf-8").rstrip("\r\n")
        cells = next(csv.reader([text]))
        dst.write((",".join('"%s"' % c.replace('"', '""') if ("," in c or '"' in c) else c
                            for c in [("1st BE" if h == "st BE" else h) for h in cells]) + "\r\n").encode("utf-8"))
        crlf = b"\r\n" in src.read(1 << 20)
        src.seek(len(hdr))
        while True:
            block = src.read(1 << 24)
            if not block:
                break
            dst.write(block if crlf else block.replace(b"\n", b"\r\n"))
    progress("packets.csv written")
    # ---- truth: every packet's link, split, NVMe transaction and command (ids as in the four files)
    with open(os.path.join(out_dir, "truth_packet.csv"), "w", newline="", encoding="utf-8") as fh:
        wr = csv.writer(fh)
        wr.writerow(["packet", "link", "split", "ntx", "cmd", "relation"])
        cur = db.execute("SELECT p.n, p.kind, p.link, p.split, p.ntx, c.id FROM pkt p LEFT JOIN ntx x ON x.id = p.ntx "
                         "LEFT JOIN cmdid c ON c.seq = x.seq ORDER BY p.n")
        for n, kind, link, split, ntx, cmd in cur:
            rel = FIRST_UNIT_RELATION if link is not None or kind == "DLLP" else "context"
            wr.writerow([n if n is not None else "", link or "", split or "", ntx or "", cmd or "", rel])
    progress("truth_packet.csv written")
    units = {"links": ps.n_links, "splits": ps.n_splits, "ntx": ps.n_ntx, "cmds": n_cmds, "packets": n_packets,
             "link_status": ps.link_status, "split_status": ps.split_status, "ntx_parts": ps.ntx_parts, "cmd_errors": cmd_errors}
    json.dump({"source_csv": csv_path, "conventions": CONV, "units": units, "staging": "SQLite on disk, one streaming pass",
               "provenance": "SYNTHETIC five-level set derived from the synthetic packet trace; not an analyzer export"},
              open(os.path.join(out_dir, "levels_manifest.json"), "w", encoding="utf-8"), indent=1)
    db.close()
    if not keep_stage:
        os.remove(stage_path)
    return units


def errcell_n(n, kind):
    if not n:
        return ""
    return (CONV["error_cell"] if kind == "e" else CONV["warning_cell"]) % n


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--csv", required=True)
    ap.add_argument("--sidecars", default=None)
    ap.add_argument("--out", required=True)
    ap.add_argument("--mn", default="Synthetic NVMe SSD 1TB")
    ap.add_argument("--keep-stage", action="store_true", help="keep <out>/_stage.sqlite (the on-disk staging file)")
    a = ap.parse_args()
    side = a.sidecars or (os.path.splitext(a.csv)[0] + "_sidecars")
    units = export(a.csv, side, a.out, mn=a.mn, keep_stage=a.keep_stage)
    print(json.dumps(units, indent=1))


if __name__ == "__main__":
    main()
