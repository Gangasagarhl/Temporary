# Field-to-Test Loop — code-only package

The whole pipeline as code, plus everything needed to install, deploy and operate it. Nothing from the test
environment is inside: no trace CSV files, no database contents, no run outputs, no generated test suites, no samples.
The database (`db/`), the run folders (`runs/`) and the regression suite (`suite/`) are created empty on first start.

**Start with `README_FIRST.md`.** An engineer or AI coding agent who installs this follows
`deploy/AGENT_INSTRUCTIONS.md` from top to bottom.

## What is inside

| Path | What | Why it is needed |
|---|---|---|
| `README_FIRST.md` | one page: what this is, what to read, the quick start | entry point |
| `README.md` | design and background | reference |
| `deploy/AGENT_INSTRUCTIONS.md` | the master runbook: ordered checklist from zip to production, hard rules, troubleshooting | installer / agent |
| `deploy/INSTALL.md`, `deploy/requirements.txt`, `deploy/preflight.py` | install on a fresh Linux server, the Python packages, an automatic environment check | installation |
| `deploy/DEPLOY.md`, `deploy/field-to-test-loop.service`, `deploy/nginx-field-to-test-loop.conf`, `deploy/config.production.example.json`, `deploy/backup.sh`, `deploy/restore.sh` | production service, authenticating reverse proxy, production settings, backup and restore | deployment |
| `deploy/OPERATIONS.md` | day-to-day running: start, stop, logs, backups, upgrades, key rotation, incidents | operations |
| `deploy/BENCH_INTEGRATION.md`, `deploy/bench_hook_template.py` | connecting a real lab bench (drive + analyzer) | lab |
| `docs/OPERATOR_AND_BACKEND_GUIDE.html` (+ `docs/guide_images/`) | every screen, word and button, the code behind it, why, and how to check it | operators, managers |
| `docs/CHANGES_2026-11-12.md`, `docs/CHANGES_2026-11-11.md`, `docs/CHANGES_2026-10-27.md` | the change logs, the latest first | reference |
| `docs/PROVENANCE_AUDIT.md`, `docs/VERIFICATION_FROM_SCRATCH.md` | where every formula, threshold and constant comes from; the full package run end to end from an empty folder | reference |
| `app/` | Flask web server, API and web screens | the application |
| `app/bench_hook.py` | the interface to your hardware bench (`run`, `detect`, optional `inject` / `clear_faults`) | lab |
| `stage1/pcie_isolate/` | the defect-isolation analyser (227 rules, 72 of the analyzer's own error kinds, trackers, defects, attribution, catalogue matching, AI review) | stage 1 |
| `stage1/runs/signature_library.json`, `stage1/reference/` | the catalogue signature library and the 113-column header contract | stage 1 assets |
| `stage1/vendor/` | a bundled copy of the Anthropic software development kit (SDK), used by both stages when the `anthropic` package is not installed; it loads only on CPython 3.13 x86-64 Linux (its compiled part was built for that), so for `llm.backend = sdk` install `anthropic` from `deploy/requirements.txt` | stage 1, stage 2 |
| `stage2/` | knowledge base, search, admin actions, optimiser, composition, sweep, test generation, AI adapter | stage 2 |
| `data/DEFECT_DETECTION_SPEC_485.jsonl` | the rule definition of every catalogue entry, given to the AI prompts | stage 2 |
| `data/atlas_cards_raw.json`, `data/final_113_columns.csv`, `data/generator/` | catalogue cards and the synthetic trace generator, used by the simulated lab bench and the tests | simulated bench, tests |
| `config/app_config.json` | the settings (see below) | configuration |
| `tests/`, `run_tests.sh`, `stage2/tests_v3.py`, `stage2/tests_v4.py` | functional tests through the API with a deterministic AI stand-in and the simulated bench; stage-2 unit tests | verification |

## The settings as shipped

`config/app_config.json` is shipped ready for a **first run on a laptop**, not for production:

| Key | Shipped value | Meaning | Production |
|---|---|---|---|
| `llm.backend` | `cli` | the AI reviewer is reached through the `claude` command-line login on this machine. Only `auto`, `sdk` and `cli` give stage 1 a model; with `standin`, `ollama` and `openai-compat` stage 1 runs its review without one | `sdk` with `base_url`, `model`, `api_key_env` (see `deploy/config.production.example.json`) |
| `stage2.bench` | `synthetic` | lab runs go to a **simulated** drive | `hook` once `app/bench_hook.py` is implemented (`deploy/BENCH_INTEGRATION.md`) |
| `stage2.search_on` | `model` | the search runs on the fast device model, the bench verifies | `bench` only after the hook is proven |
| `server.host` / `port` | `127.0.0.1` / `8077` | local only | keep `127.0.0.1`; put an authenticating reverse proxy in front (`deploy/DEPLOY.md`) |
| `server.lock_endpoint` | `false` | `true` makes the Settings page refuse (HTTP 403) changes to `llm.backend`, `llm.base_url`, `llm.api_key_env` and `llm.tools`; they are then changed only in the file, followed by a restart | `true` (as in `deploy/config.production.example.json`), so nobody who reaches the page can send the key to another server |
| `paths.allowed_csv_roots` | `/` | starting folders offered by the file picker; **no path is refused**, any readable file may be loaded | the folder where analyzer exports land, as the picker's first stop; limit reading with file permissions |

The application has **no login of its own**: the operator name is typed, not checked. Keep it on `127.0.0.1` behind
authentication. Never run two server processes on the same `db/` folder.

## Quick start

```
unzip field_to_test_loop_code_only.zip && cd 13_production_app
python3 restore_names.py                 # ONLY for the *_MAIL_SAFE.zip variant
python3 -m venv .venv && . .venv/bin/activate
python3 -m pip install -r deploy/requirements.txt
python3 deploy/preflight.py              # PASS / WARN / FAIL per check; fix every FAIL (shipped config: 25 PASS, 2 WARN)
./run_tests.sh                           # about 90-110 seconds; 1 test is skipped on purpose (fixture traces not shipped)
python3 run_app.py                       # http://127.0.0.1:8077   (--port N for another port)
```

Python 3.10 or newer (3.9 minimum). Required: `flask`, `numpy`. `anthropic` is required for `llm.backend = sdk`:
without it, stage 2 falls back to the bundled copy in `stage1/vendor/`, which loads only on CPython 3.13 x86-64
Linux, and otherwise silently to the stand-in (no model). `pytest` and `websocket-client` are needed only for tests.
The tests write about 166 MB of simulated lab traces into `runs/_bench/` (it may be deleted afterwards). Details:
`deploy/INSTALL.md`; a first end-to-end run through the API: `deploy/AGENT_INSTRUCTIONS.md` step 2.6 A.

## Inputs

Step 1 of the screens takes an analyzer CSV path (LeCroy 113-column export; VIAVI after a one-time column map). A
workload-result artifact (JSON: the ADK pipeline's `stage1.json`, or the generic shape in `app/workload_import.py`) is
accepted through the API only: `POST /api/runs` with `kind: "workload"` and `artifact_path`.

The full documentation, research and evidence are in the separate `field_to_test_loop_production_package_v1.zip`.
