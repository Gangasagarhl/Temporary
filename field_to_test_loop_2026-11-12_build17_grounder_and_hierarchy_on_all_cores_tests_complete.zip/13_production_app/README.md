# Field-to-Test Loop - production application (stage 1 + stage 2)

One local full-stack application: give it the path of a 113-column PCIe/NVMe analyzer CSV and it
1. **isolates every defect** in the trace (stage 1: streaming analysis, host-evidence fusion for the silent ones,
   isolation to packets, atlas card, evidence rows) and asks the LLM to **confirm** each isolated defect
   (verdicts of already-seen patterns come from a cache, no model call),
2. for every confirmed defect runs **stage 2**: looks the defect up in the procedural knowledge database and shows the
   admin the **stored procedure (what was saved earlier, with its feedback metadata) next to the LLM-generated
   proposal** - or only the generated one when nothing is stored - then takes the admin's action (accept / revise /
   reject / rerank / promote / ... 26 actions), updates the weights and the graph, searches for the reproducing
   command sequence + timing under the first-level-triage limits, verifies it in the **closed loop** (procedure ->
   capture -> the same stage-1 detector -> same card isolated; fixed firmware must stay silent) and files the
   **regression test**,
3. shows **how long every step took** (per stage-1 step, per incident: retrieval+LLM, search, verification) in the
   report, and lets the admin browse the database (events, causes, procedures, tests, lessons, LLM verdict cache,
   undo).

No LLM is trained or fine-tuned anywhere; learning = counts and events in SQLite (the optional PPO optimiser fits a small
policy inside one search and discards it).

## The five-level NVMe hierarchy (2026-11-02): the tree pages `/hier` (opened from the flow); the earlier single-CSV workflow at `/packets`

Page 3 is the defect table (2026-11-03): one row per command with a defect, its NVMe transactions with their Time Delta and duration, every transaction- and command-level error with its evidence, and the link transactions slower than the admin's link limit (the only input on that page, default 43 ms) under their transaction and command. A row opens the error's own page `/isolate?upload=<id>&finding=<id>` (2026-11-11): 1 the error; 2 the commands around it, n above and m below (15 and 15 by default), as an expandable tree like the hierarchy page; 3 **Isolate the defect**: code computes the error's evidence card from its own command (the steps, times, longest wait, host Abort, link problems, what ran meanwhile), fixed rules in a fixed order decide the cause keyword from it, code states what/when/where/which/who and the model writes only why/how; the isolation is kept per error, so it never changes with the window or on "isolate again"; a progress bar with percent, a step log and a sound when done; the defect's name comes from the dictionary (made by code from the recording, the same for everyone) and the procedural graph is checked for it automatically; 4 the procedural graph: defect -> causes (fixed keywords, grouped by side) -> solutions; 5 the solution: error sequence (makes the error happen again; the test is written from it) + optimized sequence (solves the problem; a full-width box that grows to fit its steps), stored ones ranked by the admin's judgements ("judged correct s of n times"; four signals: correct, correct with edits, wrong, wrong with edits), or the first one, stored "not yet judged"; 6 the test case: the answers a correct drive must give, proposed and checked line by line by the admin, the file written and tried on a simulated drive, approved by the admin. An error is called a defect only after its isolation. Weights start neutral; nothing is pre-selected. A box on that page asks the model about the error (it only answers). The summary (who, what, when, where, why, how; at most 100 words) is stored with the signature by `POST /api/isolate/<id>/<finding>/summary`; the flow's run cards made before 2026-11-11 still use it (statement: research note 09; retrieval: note 10). Page 1 asks only for the drive under test.

Interactive guide to the whole application: `docs/HOW_THE_APP_WORKS.html` (served at `/how` by the running server): the path from the five files to the test case, with hands-on parts for the joins, the limits, the four signals and the window.

Give it the five per-level CSV exports of one recording (packets, link transactions, split transactions, NVMe
transactions, NVMe commands) and it 1. checks every header against the known column lists (113 / 34 / 17 / 402 /
1598 named columns; blank separator columns dropped, the four unnamed value cells named), 2. builds the containment
tree by identity (PSN, requester + tag, address, queue + command id; never by time stamp alone) and checks itself
against the analyzer's own `Metrics.#` counts, 3. applies the deterministic rules with the admin's time limit per
level (defaults with their sources), 4. shows the tree with a filter on every column, the five level error filters
and the c1..c4 summary, 5. lists the errors with their chain, catalogue entry and signature; each error is taken to its
own page (isolation of the defect, procedural graph, solution, test case; see the flow below).

Code: `nvme_hier/` (loader, builder, rules, signature, store, optimise, chat, testcase), API `app/api/hier_api.py`,
page `app/static/hier.html` + `js/hier.js`. Synthetic five-level sets: `data/generator/export_levels.py` and
`make_five_level_sets.py` (one set per corpus scenario into `samples/five_level/`); the full-atlas 4.3 GB set with all 485 error cards is `samples/five_level_full/` (see its README; not in the zip). Everything works from disk: the exporter is one streaming pass with SQLite staging (0.65 GB RAM for 8.25 M packets), load/build/rules stream through the per-upload SQLite file (about 300 MB RAM whatever the size), and the pages fetch rows from the database as you scroll (200 at a time, filters in SQL). Research notes:
`../09_defect_isolation_research/research_notes/nvme_app/` (00 statement, 01–08 notes with JSON twins copied to
`data/catalogue/`). Tests: `python3 tests/test_nvme_hier.py` (loader, builder vs ground truth, rules, store,
optimiser) and `python3 tests/ui_smoke_hier.py` against a running server. FAQ 55–60 explain the pages.

## THE FLOW (2026-11-08, owner: "it is finally single flow"): the main page `/`

One run takes a folder of CSVs to a test case: **Family 1 -> Family 2 -> Family 3 -> report**, in that order, in one
page, with every step's state on the screen (`agentic/pipeline.py`, run kind `flow`; `POST /api/agents/projects/<id>/flow`).

The page (redesigned 2026-11-08 on the owner's request: separate pages, information only where it is needed) has a
home page (your name, the folder, **Start the flow**; reference documents under "More options"; your analyses). REA
findings are asked for on page 2, at the REA step ("give the folder, or continue without"). A tree built before from the
same files (the same files on disk: device and inode, same size, unchanged since) is found and used again by itself, and
starting the same analysis again (same folder, same or no name) opens it instead of making a second one and, for each analysis, a stepper with four pages: **1 Understand the data, 2 One tree,
3 Rules, defects, test cases, 4 Report**. Each page shows the decision that waits for you ("Your decision" card), what
is working now, then its own steps; details fold away. The rules library opens from page 3; History and Settings from
the top bar.

1. **Home**: your name (always asked: the one who starts the analysis; filled in with the last name used on this
   computer, and "Start the flow" / "Run the flow again" on an analysis's page ask "Who is starting this flow?"; the
   flow's reviews are addressed to that person, and the run records it), the **name of the analysis (required and unique: the same name on the same folder later opens
   this analysis, so its dictionaries, strategy and tree are used again and nothing is computed twice; a name already used
   for another folder is refused)**, the input folder ("Check" lists the files and their levels), then "Start the flow".
   Every field says under its label why it exists.
2. **Family 1 · Data experts**: "dictionaries used last time; proceed?" when the same files were approved before
   (approve = skip reading them again); otherwise Explorer, Grounder and Manager per CSV, one dictionary review per file.
3. **Family 2 · Hierarchy**: "strategy used last time; proceed?", or REA + collector + the Coder's strategy (review);
   "shall I build?"; the build (or the same tree reused); Code tester, Breaker, Independent tester (review).
4. **Family 3 · Rules**: one review lists every Section 1 and Section 2 item: tick the ones to use, add a new one.
   Approved rules proceed as they are; drafts and new items go to the Rule writer first (review). Each item: code from
   the rule, run on the tree, tester, export (CSV + HTML), result (review; **Change** = a new round of the rule).
   **Section 2 (errors) since 2026-11-11:** the admin writes a pattern (rule); the Coder writes its code, it is checked
   and the admin verifies it; it runs on the tree and finds **errors** (an error is called a defect only after its
   isolation). The result card asks for no choice of one error: each pattern's list is recorded, and page 3 shows per
   pattern "N errors found · stage 1 done · stage 2 done · test files approved" with **Open the errors page**.
   - **The errors page** (`#/p/<analysis>/errors`) lists every errors pattern as a section with all its errors and where
     each stands. Each error opens its own page `/isolate?upload=<id>&finding=<id>` (2026-11-11): 1 the error; 2 the commands around it, n above and m below (15 and 15 by default), as an expandable tree like the hierarchy page; 3 **Isolate the defect**: code computes the error's evidence card from its own command (the steps, times, longest wait, host Abort, link problems, what ran meanwhile), fixed rules in a fixed order decide the cause keyword from it, code states what/when/where/which/who and the model writes only why/how; the isolation is kept per error, so it never changes with the window or on "isolate again"; a progress bar with percent, a step log and a sound when done; the defect's name comes from the dictionary (made by code from the recording, the same for everyone) and the procedural graph is checked for it automatically; 4 the procedural graph: defect -> causes (fixed keywords, grouped by side) -> solutions; 5 the solution: error sequence (makes the error happen again; the test is written from it) + optimized sequence (solves the problem; a full-width box that grows to fit its steps), stored ones ranked by the admin's judgements ("judged correct s of n times"; four signals: correct, correct with edits, wrong, wrong with edits), or the first one, stored "not yet judged"; 6 the test case: the answers a correct drive must give, proposed and checked line by line by the admin, the file written and tried on a simulated drive, approved by the admin. Weights start neutral; nothing is pre-selected.
   - Then back to the errors page: the next error, other patterns. After all, **Done: write the report** (on the errors
     page or page 3).
   - Runs made before 2026-11-11 keep their old inline stage cards (one picked error: its isolation with the four
     signals on the sequence, the expected outcomes, the test file, the summary).
5. **Report** (page 4): tiles "errors found", "isolated (stage 1 done)", "stage 2 done", "test files approved or
   written", an **Open the errors page** button, and `knowledge/exports/flow/run_<n>/flow_report.html` (+ JSON): what
   every family produced, with links, and each error's status.

The tree pages (`/hier`, `/hier?upload=<id>`) open from the flow's steps; each error's page (`/isolate?upload=..&finding=..`)
opens from the errors page and calls `/api/isolate/...` and `/api/dg/...` (the procedural graph, `nvme_hier/defect_graph.py`;
the evidence card and cause rules, `nvme_hier/evidence.py`; the dictionary, `nvme_hier/terms.py`). The old inline stage
cards of runs made before 2026-11-11 call the same isolation endpoints through the application.
Tests: `tests/test_flow.py` (the whole flow twice: first time and "next time"; `--real` for Claude Code + the model
connection), `tests/ui_smoke_flow.py` (clicked through in headless Chrome, including the errors page and one error's page),
`tests/test_defect_graph.py`, `tests/test_isolation_window.py`, `tests/test_summary_and_choice.py` (offline: the dictionary, the
evidence card, the same isolation whatever the window, the procedural graph, progress jobs, test approval).


**How a defect is named and classified (2026-11-11).** Both are fixed by code, so they do not depend on who looks, when,
or how much of the recording is on the screen.
- **The name** is made by code from codes in the recording, never by the model and never typed by an admin
  (`nvme_hier/terms.py` `defect_term`, `VERSION = 3`). Its key: the rule that found the error | the command's class and
  opcode | what happened (aborted by the host, never completed, completed late, slower than usual, error status) | the
  detector's stage code or the official NVMe status code. Example: `cmd.timeout|io.read|aborted_by_the_host|nvme.sc.0.07`
  = "Read aborted by the host, status Command Abort Requested". No measured value is in a key: on the S17 sample, the 746
  findings of its two latency rules (link limit and split limit) give 12 keys, and the whole recording's 775 findings
  give 23 (counted 2026-11-11 with the current code). The key is the defect's identity in the procedural graph
  (`nvme_hier/defect_graph.py`, `dg_defect.key` = `term:<key>`): the same kind of defect from any admin, drive or day
  lands on the same stored defect. "Not the same kind of defect?" writes a note, with the admin's name, to
  `knowledge/dictionary/term_requests.jsonl`.
- **The cause** is one of 20 fixed keywords (`terms.CAUSES`: host 3, driver 3, device 6, interrupt path 2, link 3, PCIe
  2, and `unknown_cause`), decided by fixed rules in a fixed order (`nvme_hier/evidence.py` `decide_cause`) from an
  evidence card computed from the error's own command (`evidence.card`), never from the window shown, so the window size
  or "Isolate again" cannot change it. It is kept per error (`dg_isolation`). The rules can decide 11 of the keywords; the
  other 9 can only be chosen by an admin. The admin may pick another keyword from the same list: the error page has no
  box for a written cause; it offers only the 20 keywords, and the server refuses a keyword outside the list (an older
  API path, `POST /api/dg/causes` without a keyword, used by flows made before 2026-11-11, can still store a written
  line). Every change of an error's defect or cause is kept (`dg_occurrence_log`).
- **The model** writes only why and how, in words, around the facts code states (`evidence.facts`: what, when, where,
  which, who); proposes the optimized sequence (`POST /api/dg/optimized`; the admin edits it before it is stored); and
  gives the Data Grounder's meanings. It never names a defect and never picks the cause.
- **Many admins:** every action on the error page is recorded with the admin's name; one judgement per error and admin
  counts (the latest; every row is kept); the four judgements at the top of each stored solution (positive, positive
  with feedback, negative, negative with feedback) only re-rank the stored solutions.
- **Still open:** the cause rules for a never-completed command do not yet look at the stall, the host's Abort or the
  reset (on S17 a stable but wrong "firmware stall" for 6 of its 7 timeout errors;
  `../reports/Stable isolation across windows.md`); a cause outside the 20 keywords can only be "unknown cause"; the judgements only re-rank, which is not
  yet reinforcement learning (`../reports/Procedural graph reinforcement and new causes.md`).

**Reference documents and the web (2026-11-08).** Reference documents are optional (2026-11-11). The agents read them first (the Grounder for
column meanings, the Coder for the strategy's evidence); when those do not say it, they also search the web (Claude
Code with WebSearch/WebFetch; the model connection with Anthropic's web search and web fetch tools). Every web page an
agent quotes is fetched by the application itself (`agentic/core.py` WebSources: http(s) internet pages only, cached per
run) and the quoted words must be on it; otherwise the claim is shown as NOT verified with why. Settings: "The agents
may also search the web" (`agentic.web`, on by default).
\n\n## The agent families (2026-11-08): the parts of the flow (also at `/agents`)

The owner's approach (`../Approach_reframed_and_plan_2026-11-08.md`) as a page and a package (`agentic/`):

- **Start page.** The admin's name (every review is addressed to it: "Admin <name>, need review"), the name of the
  analysis, its input folder (the CSVs exported from one .pex file), and one button, **Start the flow**. Reference
  documents (LeCroy manuals, notes) are optional, under "More options": an empty box never stops the flow (the
  configured folders that exist are used, if any; the project's research notes are a default only when that folder is
  next to the application); only a folder typed into the box is checked, and a missing one is refused by name
  (`app/api/agentic_api.py` `settings`, `create_project`). REA findings are asked for on page 2.
- **Stop and Delete** (2026-11-11). **Stop** is one click with no dialog: the run, its open reviews and every step still
  working, its own and those working ahead of their turn, are stopped at once; a Claude Code call is ended with every
  program it started, the run's next calls are refused, and a result that still comes back is not written
  (`agentic/core.py` `Engine.stop`, `_halt`, `AgentRunner.cancel`). After a Stop the page offers **Run the flow again**,
  which starts a new flow (what was already approved is reused). **Delete** asks once, in one line; an analysis whose
  flow is running is stopped first, then deleted (`DELETE /api/agents/projects/<id>`).
- **Family 1 · Data experts** (`agentic/family1.py`), redesigned 2026-11-08 on the owner's request: one sub-family per
  CSV, three agents with SEPARATE memories. The **Data Explorer** knows only the data: code reads every row (no sample)
  and counts every column and every special keyword (a text column with few different values), with the first lines
  where each appears; the model only writes the summary of that profile (`runs/agentic/run_<n>/explorer_<csv>/memory.json`).
  The data is the truth: it is counted, not "verified". The **Data Grounder** finds what each column and keyword means
  (`_ground`, 2026-11-11). Each column goes to it with a summary of its contents that code computed from every row (the 8
  most common values with their counts, the smallest and largest value, up to 15 keywords, the Explorer's observation;
  never the rows). It looks in the reference documents first, then on the web (when allowed), then at the column's name
  and contents with the model's knowledge of PCIe and NVMe. It asks in parts that are all sent at once (`ground_parts`: at
  most 20 columns and 60 meanings per call, a column counting 1 and each keyword 1), and as many calls run at the same
  time as the computer allows (`core.Slots`: automatic from the processor cores, or the number in Settings, halved when
  the model service answers "too many calls"). The answer is a short form (a column by its number, a keyword as a short
  list). Code also counts on every row which kinds of row fill each column (`kind_columns`, `_filled_for`: for example
  "filled only on rows where OPC is Read or Write") and gives that to the model and to the review table. Its progress
  line moves with every part and every 10 s. Columns left without a
  meaning are asked again without the web, then in two halves; then a reference document's own words if one was found;
  otherwise the column stays without a meaning for the admin: **no meaning is ever written by code**. Document and web
  quotes, and values quoted from the contents, are checked by code; the dictionary shows and saves where each meaning
  came from ("From the web: <page>" with the page's words, "From its contents", the document with its quote, or "From
  the model's knowledge") (`grounder_<csv>/memory.json`). The **Manager** puts both together
  for the admin: the review opens with what the file is, then the meanings by source, "Ask the Manager" (a data question
  goes to the Explorer and comes back with counts and file lines; a meaning question goes to the Grounder and comes back
  with its source), and the columns and keywords tables with where to see each one.
- **Family 2 · Hierarchy** (`agentic/family2.py`). "Used last time; proceed?" when a strategy was approved for the same
  file format; otherwise REA findings, references, Family 1's dictionaries and the web are collected (IMS and JIRA are
  reported as not connected until configured), the Coder's strategy with evidence goes to review, the Builder asks
  before building, then the Code tester rebuilds 5 to 10 random windows of the real data on their own, the Breaker the
  hardest windows, and the Independent tester checks the tree with the column meanings only.
- **Family 3 · Rules and sections** (`agentic/family3.py`). A sidebar of Section 1 (data analytics) and Section 2 (error
  roots), five levels each, items with Add. One JSON rule file per item (`knowledge/rules/...`), versioned. Opening an
  item: **Edit the rules** (the Rule writer drafts from your words, you review) or **Proceed with the current rules**
  (code generated from the rule by a fixed translator, run on the project's data, checked by a tester, exported as
  CSV and HTML, shown for review). Change the rule, not the code. Section 2 items list their errors on the errors
  page; each error goes through stage 1 (isolation of the defect), stage 2 (procedural graph) and its test case on its own page. Seeds: command type percentages, Read vs RndRead vs sequential read, and the
  detector's rules as drafts; the demo error is "a command that never completed (host timeout)".
- **Step engine** (`agentic/core.py`). Every run is a list of named steps with a state shown on the page (waiting,
  running, needs review, approved, done, skipped, failed); a failed step can be run again; a run interrupted by a
  server stop continues by itself from its first unfinished step. Records live in `db/agentic.sqlite`; each agent call
  keeps its instruction, context and answer in its own sandbox folder (`runs/agentic/run_<n>/<agent>/`).
- **Where the agents run.** Settings: Claude Code headless (default), the application's model connection, or the
  stand-in (no model). Claude Code gets the key and URL of Settings -> Model connection and its model name (unless "A
  different model for the agents" is filled in), with its background traffic to Anthropic switched off. With a URL of
  your own, Claude Code is not started: the agents use the model connection, so every call goes to that URL
  (`agentic/core.py` `custom_url`). When the chosen one fails the next is used, and every step records who answered.
  No model is trained.
- **Tests.** `tests/test_agentic.py` (every family, every review decision, retry, resume after a restart, exports,
  independent recounts; `--real` adds real Claude Code calls) and `tests/ui_smoke_agents.py` (the page in Chrome).

## Read first

`docs/FINAL_WORKFLOW_AND_ALGORITHMS.html` - the final workflow as block diagrams, how an error is recognised from the
packets, how the 485 errors come about (with the real CSV rows of every card next to how it should look), the
knowledge database as the RAG store, retrieval and weight-update formulas, the reproduction search, the test contract,
and three worked examples (visible / partly visible / not visible). `docs/HOW_DEFECTS_ARE_DETECTED.html` is stage 1's own account.

## Run it on your laptop

```bash
cd 13_production_app
python3 run_app.py                 # open http://127.0.0.1:8077 (five-file upload); /packets = earlier single-CSV workflow
python3 run_app.py --standin       # no LLM at all (deterministic stand-in): demo / tests
python3 tests/test_app.py          # end-to-end + component tests (4 tests, ~90 s, stand-in LLM, no network)
```

Requirements (`deploy/requirements.txt`): Python >= 3.10, `flask`, `numpy` (stage 1), `anthropic` (for `llm.backend = sdk`;
without it stage 2 falls back to the stand-in), `pytest` (only to run the generated regression tests). Install and
deployment: `README_FIRST.md` and `deploy/AGENT_INSTRUCTIONS.md`.
The shipped `config/app_config.json` has `llm.backend = "http"`, which needs an API key: set it on the main page under
Settings -> Model connection (below). The agents run on Claude Code by default; with `llm.backend = "cli"` the `claude`
login is enough and no API key is needed.

## Configure the LLM (used at five points, all read-and-propose, all verified by code; never trains)

**Settings -> Model connection (2026-11-11), on the main page's top bar**, is the one place for the URL, the model name
and the API key, for every part (the agents, stage 1 and 2, the error pages):
- **URL**: empty = Anthropic (https://api.anthropic.com); otherwise the gateway's base address only. It is kept in one
  form (`app/model_env.py` `normal_url`): `https://` is added when missing and a typed `/v1` or `/v1/messages` is
  removed, because every caller adds `/v1/messages` itself.
- **Model name**: for example `claude-sonnet-5-5` (the shipped setting since 2026-11-12; `claude-haiku-5-5` before). The agents use it unless "A different model for
  the agents" (More settings) is filled in.
- **API key**: written to `~/.config/f2t/env` (file mode 600, outside the project), never into the configuration, so
  never into a zip. `run_app.py` loads it at every start (`model_env.load`), and it wins over a key the computer's
  environment already holds. The page never shows the key: only its last 4 characters (for a key of 12 characters or
  more) and where it came from.
- **Save and test the connection** (`POST /api/hier/model/test`) saves, then makes one real call through the model
  connection and one through what runs the agents (never from the answer cache). It shows the address it called and, for
  each, who answered and in how many seconds, or what the error means in words (`_hint`: for example HTTP 402 = the
  account behind the key has no credit left or its budget is used up; HTTP 404 = give the base address only).
- **With a URL of your own, every call goes there**: the agents use the model connection, not Claude Code (which has its
  own Anthropic login). With the URL empty, Claude Code gets the same key and URL.

`config/app_config.json` (or the **Settings** tab; with `server.lock_endpoint: true`, the production setting, `backend`,
`base_url`, `api_key_env` and `tools` can only be changed in the file: stop the service, edit, start):

| field | meaning |
|---|---|
| `llm.backend` | `http` = the Anthropic Messages API over plain HTTPS, key from `api_key_env` (the shipped setting; the `/packets` stage-1 confirmation then uses the `anthropic` package when it is installed) · `cli` = local `claude` login (no key) · `sdk` = Anthropic API or a gateway (`base_url`, key from `api_key_env`) · `openai-compat` = any `/v1/chat/completions` endpoint (`base_url`, `model`; stage-1 confirmation then runs without a model) · `standin` = no model · `auto` |
| `llm.model`, `llm.effort` | e.g. `claude-haiku-5-5`, `low` |
| `llm.batch` | stage-1 confirmation through the Message Batches API (sdk only; half price, results within minutes to hours) |
| `llm.capture_check` | one extra call per run: "can this capture show what we are looking for?" |

The five call sites: the stage-1 confirmation per defect (cached by pattern), the stage-1 capture check (optional,
`llm.capture_check`), the stage-2 digest / presentation, the stage-2 proposal (the seed of the search) and the test
composition (*Generate test case*).

1. **Stage 1** - after the engine isolates a defect, the evidence rows and findings go to the model, which answers
   through a JSON schema (verdict, error type, responsible party, cited packets; no self-rated confidence number is used). The `claude` CLI backend runs
   with `--effort low` and a cached static prompt prefix; the SDK backend uses `output_config.effort = low`, prompt
   caching and optionally batches. **Pattern cache:** the verdict is stored under (card, first-abnormal rule,
   pattern, layer, rule set, evidence-row kind sequence, model, prompt version); a later incident with the same key
   gets the stored verdict without a call.
2. **Stage 2** - the admin card's digest (headline, mechanism, decisive packets, recommended sequence, differences
   vs the stored procedure, risks) and, when a search is needed, the proposal (commands, timing, parameter ranges).
   Everything the model emits is checked by code (cited packets exist, commands allowed, ranges). The model never
   changes a ledger status.

In your environment: set the URL, the model name and the key in Settings -> Model connection and press **Save and test
the connection**; or, with `server.lock_endpoint: true`, put the URL, model name and key variable in the config file
(start from `deploy/config.production.example.json`) and the key in `~/.config/f2t/env`, then restart - nothing else
changes.

## The flow (your architecture diagram -> this app)

| Diagram | Here |
|---|---|
| Input trace -> Trace Normaliser -> LLM (abnormalities) | **Run** tab: `analyze` -> `fuse` (dmesg / tool records) -> `isolate` -> pattern cache -> `review` (LLM confirms) -> `report` |
| Procedural Graph Lookup -> return stored data (procedure, params) | **Incident** tab, *Look up database + LLM proposal*: hybrid retrieval over the knowledge graph, "seen before" verdict, stored procedure with timing, feedback posterior, tests, test preview |
| LLM generates the baseline (create params) | the generated column on the same card |
| LLM guidance (RL phase): score > 0.9 three times consecutively = optimal; > 10 min = fail | `stage2.optimal_consecutive` (default 3) and `stage2.time_budget_s` (default 600). The search confirms a reproduction with a Wilson 95 % lower bound >= 0.5 over 8 confirm runs on the device model; the 0.9 x 3 rule is applied on the bench in the closed loop (each verification run gets a signature score; optimal = 3 consecutive runs above 0.9; the result shows the score series). At the 600 s limit only the search stops; verification completes and the result is flagged *triage_timeout* (first-level triage time exceeded). Not evaluated for workload (ADK/PCMark) defects, which the synthetic bench cannot run |
| RL agent (PPO) + hardware test bench | `stage2.optimizer`: the training-free bandit (default; benchmark winner: hill-climb + archive restarts + bandit over mutations, Wilson confirmation, ddmin) or PPO (selectable; neither trains an LLM) + bench (`synthetic` or your hardware through `app/bench_hook.py`) |
| Admin dashboard: +1 -> regression test script, enrich graph, weight up; -1 -> restart, record failed trials, weight down | the action buttons: `accept` credits the path and continues to search / tests; `reject` blames only that item; `revise`, `rerank`, `not_reproducible`, `promote` / `deprecate` / `delete_approve` (second admin), `undo`, ...; `restart_failed` (-1) records the failed trial (b+1 and tb+1 on the cause edge, or r = 0 on the procedure edge, plus a lesson) and restarts the search |

## Phases (what the admin sees, in order)

1. **Run stage 1** - CSV path (+ optional host evidence). While it runs, an animated progress ring fills with the
   percentage, the current step is named in plain words, live counters show rows read of the CSV (with an estimate of
   the total), findings so far, defects isolated and LLM confirmations, and an activity stream lists every event.
   Nothing about stage 2 is shown yet; the other steps in the sidebar are locked (the sidebar shows the stage-1
   percentage, later the stage-2 progress). At 100 % the same page shows **Isolation of defects**: one row per
   defect (card, title, status, LLM verdict); expanding it gives the summary - which of the 485 errors, first
   abnormal packet, the rules that prove it, who caused it, whether outside evidence was needed and from which
   source, what the LLM returned - and *Open the full record* opens a dedicated page (`/defect`) with eight
   sections: which error, where, how it is proven (rules with their rows and the acceptance checks), outside
   evidence (needed? source, why that source), what the LLM returned, why it happens and the fix, stage 2 for this
   defect, and the admin's earlier decisions on this error.
2. **Isolated defects** - unlocked when stage 1 completes: every defect with the engine verdict and the LLM
   confirmation. A *Continue to stage 2* button appears.
3. **Stage 2 review** - opens with a gate that explains what stage 2 does; **Start stage 2** (the admin's explicit
   decision) prepares every defect (database lookup + LLM proposal, cached) and then shows the review queue. Each
   defect is one **manager decision view** (`app/static/js/decision.js`, spec in
   `research_notes_v3/manager_decision_view.md`): a three-line *bottom line* (what the packets showed, what is
   proposed, your decisions so far); *what the packets showed* as a host <-> device flow graph (time top to bottom,
   delta-t per row, first abnormal packet shaded, gaps drawn, "show the full exchange" as the only disclosure);
   *proposed reproductions* as ranked cards - plain-language title, command chips with the spacing, tunable timing
   chips, one provenance line (saved by whom, reproduced in at least X % of lab runs with a likelihood word, judged
   +p/-n, tests on file; or "proposed now by the AI reviewer, fresh model call") and three outcome buttons: **Correct** (runs
   it in the lab, writes the test script), **Needs changes** (Stored vs Your version in place, changes highlighted,
   "Save corrected version" validates it by execution before it is stored under the manager's name), **Not
   correct** (collapses to a stub with Undo and reason chips; optionally retire from the database with a second
   admin). Cards are ranked by drag handle or by the "..." menu (move to top / up / down / bottom - the no-drag
   alternative), which records a ranking signal only. "Save decisions" records removals and ranking together.
   **Generate test case from the stored knowledge**: when the database holds correct / optimised sequences for the
   error, one button asks the LLM to compose up to three test variants from them (robust recreation, timing boundary,
   different path); code validates each, each runs in the lab, only the ones that reproduce go through the closed loop
   and are filed with their sources and rationale (`manifest.json` → `composition`); nothing is auto-approved.
   Everything engineer-level (LLM digest, all 26 actions, candidates, raw rows, history, the JSON editor) is behind
   **All details**. The gate is enforced by the API (409 before stage 1 is done or stage 2 is started);
   `GET /api/runs/<run>/incidents/<inc>/solutions` is the endpoint behind the cards.
4. **Report & tests** - per-stage timings, per-defect results, the generated suite.

## Design rationale (research-backed)

Two notes drive the screens: `claude_research_report/.../research_notes_v3/ux_for_non_technical_admins.md` (progress
indicators and the labour illusion, progressive disclosure, how Sentry / GitHub code scanning / Wireshark present an
alert, review workflows and history panels, confirmation vs undo, steppers) and `visual_design_system.md` (Primer light
palette with every text/background pair measured >= 4.5:1, Carbon type scale 14/20 body - 12/16 caption - 16/24
section - 24/32 title - 32/40 counters with tabular figures, 8 px spacing grid, 256 px sidebar, 320 px list pane,
40 px rows, Material-3 ring proportions, WCAG 2.4.13 focus rings, Carbon motion durations, reduced-motion fallbacks).
What that produced:
- a linear five-step tracker with the live state under each step, later steps locked until the previous phase ends;
- one hero ring with the whole-run percentage (capped at 99 % until the report exists), the step named in plain
  words, a step list with real live counts, an ETA only after 10 % and padded, a staleness guard, cancel with a
  specific confirmation;
- a fixed three-word status vocabulary - Confirmed / Suspect / Needs evidence - always colour + icon + word;
- results as summary tiles + expandable rows + a full-record page in reading order: what this means, where, why it
  was flagged (rule checklist with values), evidence rows on the page, what usually fixes it, related errors,
  stage 2, history;
- the review screen as list-detail with the manager decision view (`manager_decision_view.md`: answer-first
  bottom line, two disclosure levels, Wireshark-style flow graph, outcome-labelled verdict buttons with printed
  shortcuts, WCAG 2.5.7 no-drag ranking alternative, in-place Stored vs Your version editing, removal as an undoable
  stub instead of a dialog, likelihood words next to their numbers), a callout when an earlier decision on the same
  error was negative, nothing pre-selected, a "what happens next" receipt and an undo in the toast.

## What you see in the report

Stage 1: seconds per step (analyze, fuse, isolate, pattern cache, review, report, capture check) and the LLM stats
(reviewed, model calls, from cache, confirmed, cost). Stage 2 per incident: seen-before verdict, stored / generated
present, action, mode (reuse / adapt / generate), status, trials, reproduction bound, closed-loop hits (known-bad vs
fixed), admitted test, optimal flag, and the seconds for retrieval+LLM, search and verification. Totals per stage and
overall. `runs/<run>/report.md` and `report.json`; the engine's own `isolation_report.md` is next to them.

## Layout (modular)

```
run_app.py                 start the server          config/app_config.json   settings (editable in the UI)
app/server.py              Flask app factory, pages / and /db
app/services.py            shared services: jobs, caches, stage-2 service, path safety, run/queue helpers
app/api/config_api.py      /api/config                 app/api/runs_api.py      /api/runs (stage 1, run cache, files)
app/api/stage2_api.py      incidents, review queue, prepare-all, present (cached), act, state
app/api/db_api.py          /api/db/* overview, tables, signature tree, verdict cache, undo
app/api/misc_api.py        jobs, report, test suite, synthetic samples
app/jobs.py                background jobs + timing spans     app/stage1_runner.py  stage 1 as a job
app/pattern_cache.py       LLM verdict cache                  app/stage2_service.py stage 2 service
app/report.py              report builder                     app/bench_hook.py     hardware bench template
app/static/index.html      the workflow (sidebar: Run -> Isolated defects -> Stage 2 review -> Report -> Settings)
app/static/db.html         the database interface (signatures & procedures tree, tables, event log + undo, caches)
app/static/js/             one module per page: main, run, incidents, review, decision, defect, report, settings, db; api.js shared
stage1/                    the defect-isolation engine        stage2/               the stage-2 package
data/                      atlas cards, detection spec, trace generator
db/ runs/ suite/ samples/  runtime data (created on first use)
tests/test_app.py          end-to-end API test + component tests
```

## Caches (nothing already processed is computed twice)

| Cache | Key | Effect |
|---|---|---|
| Run cache | CSV path + size + mtime, host-evidence files, nsze, model/backend/effort | the same capture opens the finished run instead of re-running stage 1 ("re-run even if cached" overrides) |
| Pattern cache | card, first-abnormal rule, pattern, layer, rule set, evidence-row kinds, model, prompt version | stage-1 verdict reused without a model call (shown as *cached* in the tables) |
| Presentation cache | run + incident | the stage-2 card (lookup + LLM digest) is served from disk until the admin acts; *Prepare stage 2 for all* builds them in the background |
| LLM prompt cache | prompt hash | identical prompts never hit the model twice |

## Attaching your hardware bench

Implement `run(scenario)` and `detect(capture) -> findings` in `app/bench_hook.py` and set `stage2.bench = "hook"`
(restart the app after changing it). `run()` returns a dict (trace path, isolated findings, stage, closeness,
reproduced, cost_s), not a path: see the docstring of `app/bench_hook.py`, the template `deploy/bench_hook_template.py`
and the guide `deploy/BENCH_INTEGRATION.md`. With `stage2.search_on = "bench"` every search trial runs on the hardware;
with `"model"` the search runs on the device model and only the verification runs on the bench. Generated scripts are download-only: the app never executes
shell/fio text it produced.

## Safety and limits

- Binds to 127.0.0.1, no authentication of its own (put an authenticating reverse proxy in front, `deploy/DEPLOY.md`).
  Trace paths are typed or picked with the file picker; since 2026-11-03 **no path is refused** (the owner's rule): any file the service user can read may be loaded. `paths.allowed_csv_roots` only lists the folders the picker starts in; limit a shared server with file permissions (deploy/DEPLOY.md).
- Two-person actions (`promote`, `deprecate`, `delete_approve`) are checked server-side as a comparison of the typed
  names (approver != requester). The app has no login, so the rule is only as strong as access control: run it behind
  an authenticating reverse proxy (`deploy/DEPLOY.md`). Set `server.lock_endpoint: true` in production so the Settings
  page cannot redirect the API key or widen the readable folders.
- The synthetic bench measures the pipeline (hidden trigger model + generator + the real engine), not device physics.
- `stage1/` is a copy of `10_defect_isolation_engine` (unchanged); `stage2/` is a copy of
  `Database_Implmentation/final_implementation` (v3). Research and measured results: `Database_Implmentation/claude_research_report/`.

## Inputs, rules and the admin's acknowledgements (architecture diagram)

- **Input**: the Run step takes a PCIe analyzer CSV. A workload-result artifact (the `boot_etl` ADK pipeline's
  `stage1.json`, or any JSON in the shape documented in `app/workload_import.py` for PCMark) is accepted through the API
  only (`POST /api/runs` with `kind: "workload"`); its abnormalities become defects with a failure signature, stage 2
  looks them up, writes the baseline and files a proposed test for the hardware bench.
- **Failure signature** (`stage1_adapter.signature_of`) on every defect, in the review panel and in every test manifest.
- **The two rules** (`stage2/loop_rules.py`): the search itself confirms a reproduction with a Wilson 95 % lower bound >= 0.5
  over 8 confirm runs on the device model; the diagram's "test score > 0.9 three times consecutively" is applied on the bench
  in the closed loop (each verification run gets a signature score; optimal = 3 consecutive runs above 0.9; the result shows
  the score series). The 10-minute rule bounds each stage-2 search (status `triage_timeout`: the search stops, verification
  completes) and is reported per stage-1 run in the KPI. Neither rule is evaluated for workload (ADK/PCMark) defects because
  the synthetic bench cannot run a workload; they apply once the hardware bench runs it.
- **Negative Ack (−1)**: "Record failed trial (−1) and restart" after a search that found nothing (`restart_failed`). On a
  cause target: b+1 on the cause edge (the ranking weight goes down) and tb+1 (technical count) plus a lesson; on a procedure
  target: r = 0 on the procedure edge; then the search restarts on another random stream.
- **Stress ascent** (every confirmed reproduction): each timing value is pushed in its stressful direction while the
  defect still appears in 2 of 3 lab runs (`Optimizer.stress_ascent`, budget `stage2.stress_trials` = 30); the hardest
  version that still triggers it is checked on known-bad / fixed firmware and filed as a second regression test
  (manifest key `stress`). This is the statement's "most stressful trigger conditions → executable test scripts".
- **Vulnerability sweep**: "Sweep the neighbourhood" around a reproducing procedure (`sweep`): up to 15 variants (10 timing,
  4 power states, 1 burst; an "idle 500 ms" variant when the base has no idle). `app/bench_hook.py` declares optional
  `inject(spec)` and `clear_faults()`: when `inject` exists, jammer variants run through the closed loop (fault armed on the
  known-bad runs, cleared after) and are filed like the other variants; on the synthetic bench they are reported "hardware
  bench only".
- **KPI report**: `/api/kpi` and the Report page (triage rule, automatic isolation, known-signature leakage = 0, tests
  authored automatically, saving against `kpi.manual_triage_minutes_per_run` when you set it).
- **Optimiser**: `stage2.optimizer = "bandit"` (default) or `"ppo"`; **web search for the baseline**: `llm.tools = ["web_search"]`.

## Tests

`bash run_tests.sh` runs EVERY suite, one after the other (a failing suite does not stop the others), and ends with a
table. `--real` adds the agent suites with real model calls (Claude Code with `~/.claude/settings.json`, and the
application's model connection; they cost money); `--no-browser` leaves out the browser suites. The admin's own state
(databases, logs, `knowledge/`) is saved first and put back at the end (`tests/protect_state.py`): do not use the
application while it runs. Logs: `runs/suite_logs/<suite>.log`.

| Suite | Needs | What it checks |
|---|---|---|
| `unit_app` (`tests/test_app.py`) | - | the packet workflow end to end with the stand-in, stage 2 unit tests (`stage2/tests_v3.py`, `tests_v4.py`), the stage 1 engine fixtures and analyzer cases |
| `unit_hier` (`tests/test_nvme_hier.py`) | - | the five-level loader (real header layout, stored headers, every column kept, huge values, parallel = serial), the builder against the ground truth, rules, store, optimiser, the generated test file imports |
| `unit_errors` (`tests/test_defect_graph.py`, `test_isolation_window.py`, `test_summary_and_choice.py`, `test_optional_references.py`, `test_model_settings.py`) | - | the errors page and one error's page: the fixed dictionary, the evidence card, the same isolation whatever the window, the procedural graph, progress jobs, test approval, the 5W1H summary; optional reference documents; the model connection set in Settings (the saved key wins, every part follows a change, every call goes to a URL of your own); tests that need the S17 sample skip without it. Not in `run_tests.sh` yet, offline: `python3 -m pytest -q tests/test_grounder_batches.py tests/test_stop_and_delete.py` (the Data Grounder's parts and retries; Stop and Delete) |
| `e2e_hier` (`tests/test_hier_e2e.py`) | server | five files through the HTTP API: load, tree, summary, rules, limits, defects, signals, test case |
| `isolate` (`tests/test_isolate.py`) | server | the isolation routes behind each error's own page (`/isolate`): window, stateful chat, memory, evidence loop, test case (it must import and skip without a drive), summary (who, what, when, where, why, how) |
| `agents` (`tests/test_agentic.py`) | server | the agent families one by one: dictionaries, strategy, build, Code tester, Breaker, Independent tester, rules, retry, resume |
| `flow` (`tests/test_flow.py`) | server | THE FLOW twice: Family 1 -> 2 -> 3; the pattern lists its errors; one error worked on its own page through the routes (stage 1: isolate and name the defect; stage 2: the cause and the first or stored solution, judged; the test proposed, checked, written, approved); "Done: write the report"; the second run reuses what was approved |
| `packet_loop` (`tests/exercise_loop.py`) | server | the earlier packet workflow on the running app: stage 1, stage 2, every admin signal, composition, sweep, recurrence, cache, undo, KPI |
| `ui_packets`, `ui_tree`, `ui_pages`, `ui_flow` | server, Chrome | the /packets decision view; the tree pages /hier; the flow pages (home, top bar, settings, history, rules library); a whole flow clicked through the four pages |
| `agents_real`, `flow_real` (`--real`) | server, key | the agent families and the whole flow with real model calls |

`README_FIRST.md` is the reading guide (installers and agents: `deploy/AGENT_INSTRUCTIONS.md`; operators and managers:
`docs/OPERATOR_AND_BACKEND_GUIDE.html`). The full documentation package adds `docs/START_HERE.md`, the reading guide
for the whole project.

## Metadata kept with every run and decision

The screen requires the operator's name to analyse a trace (the API accepts an empty name) and records it with the run; each stage-2 decision records the
name in "Your name". Every knowledge-base event carries a timestamp and the run, defect, device and firmware it
belongs to. The device is read from the trace (NVMe Identify Controller: model, serial, firmware revision; PCIe
configuration header: vendor/device id) or typed by the operator. Procedures and regression tests are filed per
device model; the test id carries the device. See docs/CHANGES_2026-10-27.md.
