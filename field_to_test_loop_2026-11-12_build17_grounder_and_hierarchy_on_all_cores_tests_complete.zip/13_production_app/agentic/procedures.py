"""Procedures and their verified code (owner, 2026-11-09).

Every Family 3 item is shown as:
    Source data:          the file(s), with the full path in the open recording, and the columns used
    Rules or procedure:   numbered steps that say exactly what is done: which column, how its cell is parsed (format,
                          letter case), which hash map (key and value), which formula, what is output
    Buttons:              Edit rule/procedure (the JSON, edited by the admin) · Code it / Verified code · Run · Export CSV

The procedure is a JSON object kept in the item's rule file ("procedure"), versioned, editable by the admin:
    {"source_data": [{"file": "nvme_command.csv", "columns": ["OPC", "SQID"]}],
     "steps": ["...", "..."],
     "output": {"columns": ["command type", "count", "percent"], "order": "count, largest first"},
     "open_questions": ["..."]}

Code it: the Coder (an agent, Haiku at high effort) writes Python from the procedure, given what Family 1 knows of the
columns (meanings, the real cell formats from the file) -> the program checks it (it compiles, it imports only the
standard library, it runs on the recording, its output has the procedure's columns, the counts and percentages add up,
and where the item had an earlier plan, an independent count from the tree database agrees) -> the admin reviews it
(the chime sounds) -> approved, it is the VERIFIED code of that procedure version. A changed procedure needs new code.
The detector's items (Section 2) run the detector's own code (nvme_hier/rules.py), which is part of the application.
"""
import ast
import csv
import hashlib
import json
import os
import re
import sqlite3
import subprocess
import sys
import time

from . import family1, rule_evidence as E

APP = family1.APP
FILE_NAME = E.FILE_NAME
LEVEL_OF_FILE = {v: k for k, v in FILE_NAME.items()}
TREE = "the tree"           # the tree Family 2 built (owner, 2026-11-10): a procedure's source like a file; its code gets run(tree, out_csv) and nvme_hier.tree_api


def uses_tree(proc):
    return any(isinstance(s, dict) and s.get("file") == TREE for s in (proc or {}).get("source_data") or [])


def tree_column(c):
    """'link: Link Tra Error' -> ('link', 'Link Tra Error'); a column of the tree is named with its level."""
    lv, _, col = str(c).partition(":")
    return (lv.strip(), col.strip()) if col and lv.strip() in FILE_NAME else (None, str(c).strip())
FORBIDDEN_CALLS = {"eval", "exec", "compile", "__import__", "getattr", "setattr", "delattr", "globals", "locals", "vars", "breakpoint", "input", "memoryview"}
ALLOWED_IMPORTS = {"csv", "re", "math", "collections", "decimal", "datetime", "statistics", "itertools", "json", "functools", "operator",
                   "nvme_hier", "nvme_hier.names"}
RUN_TIMEOUT_S = 4 * 3600         # a full run on a large recording (6 GB files are normal) may take long: it runs in the background
TRY_TIMEOUT_S = 120              # Try on a sample: the first records only, seconds at most
TRY_RECORDS = 1000
# the columns of a detector item's result (the SQL of family3.compile_rule, detection_rule)
DETECTOR_OUTPUT = ("defect", "level", "rule", "what was found", "severity", "number in its file", "time stamp (ps)", "command's file row", "data row in its file")
SAMPLE_ROWS = 20000          # rows read to show the Coder the real formats of a column (distinct values, at most 12 each)

# The procedures of the two analytics items, written from the real export's formats (S17: OPC "0x02 (Read)", SQID "3",
# NSID "1", SLBA "2097152", NLB "15" (0-based), Time Stamp "0000.400098983870s"; the header has 1,727 cells, empty and
# repeated names among them). They are drafts until the admin approves code made from them.
SEED_MARK = "seed"              # edited_by of a seeded procedure nobody has changed (it may be reworded by a later seed)
SEEDS = {
    "command_type_share": {
        "source_data": [{"file": "nvme_command.csv", "columns": ["OPC", "SQID"]}],
        "steps": [
            "Read nvme_command.csv row by row. Find each column by its exact header name (first match).",
            "OPC: take the hex number before the space (\"0x02 (Read)\" gives 2). Ignore the text in brackets. Nothing is lower-cased.",
            "SQID: a whole number. 0 is the admin queue; any other number is an I/O queue.",
            "Name the command from the NVMe opcode list: the admin list when SQID is 0, else the I/O list (2 on an I/O queue is \"Read\"). "
            "An unknown opcode is \"opcode 0xNN\"; an empty OPC is \"(blank)\".",
            "Count each name in a hash map: name -> number of rows.",
            "Total = the sum of all counts.",
            "Percent = count / total x 100, rounded to 3 decimals.",
        ],
        "output": {"columns": ["command type", "count", "percent"], "order": "largest count first"},
        "open_questions": [],
    },
    "read_pattern": {
        "source_data": [{"file": "nvme_command.csv", "columns": ["OPC", "SQID", "NSID", "SLBA", "NLB", "Time Stamp"]}],
        "steps": [
            "Read nvme_command.csv row by row. Find each column by its exact header name (first match).",
            "Keep only reads: OPC is 0x02 (the hex number before the space) and SQID is not 0. Skip rows with an empty SLBA or NLB.",
            "NSID, SLBA and NLB are whole numbers. NLB counts from 0, so a read covers NLB + 1 blocks.",
            "Time Stamp \"0000.400098983870s\" becomes picoseconds: seconds x 10^12 + the 12 digits.",
            "Group the reads by NSID in a hash map: NSID -> its reads in time order (same time: file order).",
            "In each group: the first read is \"first read of its namespace\"; a read whose SLBA = previous SLBA + previous NLB + 1 is "
            "\"sequential read\"; any other read is \"random read (RndRead)\".",
            "Count each kind. Percent = count / total reads x 100, rounded to 3 decimals.",
        ],
        "output": {"columns": ["kind of read", "count", "percent"], "order": "largest count first"},
        "open_questions": ["Reads on different queues of one namespace count as one stream. Is that right?",
                           "A read must start at exactly the next block to be sequential. Is a small gap allowed?"],
    },
}


# ------------------------------------------------------------------------------------------------ the procedure
def sha(proc):
    core = {k: proc.get(k) for k in ("source_data", "steps", "output")}
    return hashlib.sha256(json.dumps(core, sort_keys=True).encode()).hexdigest()[:16]


def detector_rule(r):
    """The detector's rule id of an item that still runs the detector's own code (its procedure was not changed)."""
    if r.get("kind") != "detection_rule":
        return None
    p = r.get("procedure")
    if p and not p.get("from_detector"):
        return None
    return (r.get("plan") or {}).get("rule")


def detector_procedure(r):
    """The procedure of a detector item, written from what the detector does (rule_evidence.READS) and why (BASIS)."""
    from nvme_hier import rules as RL
    rule = (r.get("plan") or {}).get("rule")
    reads, test = E.READS.get(rule, ([], ""))
    kind, text, ref = RL.BASIS.get(rule, ("", "", ""))
    files = {}
    for lv, sql in reads:
        cols = E.file_columns(lv, sql)
        f = files.setdefault(FILE_NAME[lv], [])
        for c in cols:                                   # a column the tree build makes is said in the first step instead
            if c not in f:
                f.append(c)
    own = FILE_NAME.get(r.get("level"), "")
    steps = []
    if any(sql in ("parent", "relation") for _lv, sql in reads):
        steps.append("Join the five files into one tree: each row is linked to its parent by IDs (queue + command ID, requester + tag, PSN), not by time.")
    head, *more = [x.strip() for x in test.split("\n") if x.strip()]     # a test written as lines gives one step per line
    first = head.split(" ", 1)[0]
    lead = head[0].lower() + head[1:] if first in ("The", "A", "An", "One", "For", "Only", "Each", "Every") else head   # column names keep their case
    steps.append("For each row of %s: %s" % (own, lead))
    steps += more
    steps.append("Each match is a defect, saved with its row number and its command.")
    if ref:
        steps.append("Why: %s. Source: %s" % (text.rstrip("."), RL.source_words(kind, ref).split(": ", 1)[-1]))
    return {"source_data": [{"file": f, "columns": c} for f, c in files.items()], "steps": steps,
            "output": {"columns": list(DETECTOR_OUTPUT), "order": "in the order the detector filed them"},
            "open_questions": [], "from_detector": True}


def procedure_of(r):
    """The item's procedure: the stored one, else the detector's (for its items), else None (no procedure yet)."""
    if r.get("procedure"):
        return r["procedure"]
    if r.get("kind") == "detection_rule" and (r.get("plan") or {}).get("rule"):
        return detector_procedure(r)
    return None


def validate(proc):
    """The procedure as the admin may write it, checked: -> the clean dict, or ValueError naming every problem."""
    if not isinstance(proc, dict):
        raise ValueError("the procedure must be a JSON object { ... }")
    probs = []
    src = proc.get("source_data")
    if not isinstance(src, list) or not src:
        probs.append('"source_data" must be a list of {"file": ..., "columns": [...]} with at least one file')
        src = []
    clean_src = []
    for i, s in enumerate(src, 1):
        if not isinstance(s, dict) or (s.get("file") not in LEVEL_OF_FILE and s.get("file") != TREE):
            probs.append('source_data %d: "file" must be "%s" or one of %s' % (i, TREE, ", ".join(FILE_NAME.values())))
            continue
        cols = s.get("columns") or []
        if not isinstance(cols, list) or not all(isinstance(c, str) and c.strip() for c in cols):
            probs.append('source_data %d: "columns" must be a list of column names' % i)
            continue
        if s["file"] == TREE and any(tree_column(c)[0] is None for c in cols):
            probs.append('source_data %d: a column of the tree is named with its level, for example "link: Link Tra Error" (levels: %s)' % (i, ", ".join(FILE_NAME)))
            continue
        clean_src.append({"file": s["file"], "columns": [c.strip() for c in cols]})
    steps = proc.get("steps")
    if not isinstance(steps, list) or not steps or not all(isinstance(x, str) and x.strip() for x in steps):
        probs.append('"steps" must be a list of sentences, at least one')
        steps = []
    out = proc.get("output") or {}
    ocols = out.get("columns") if isinstance(out, dict) else None
    if not isinstance(ocols, list) or not ocols or not all(isinstance(c, str) and c.strip() for c in ocols):
        probs.append('"output" must be {"columns": ["...", ...], "order": "..."}')
        ocols = []
    oq = proc.get("open_questions") or []
    if not isinstance(oq, list):
        probs.append('"open_questions" must be a list of sentences (it may be empty)')
        oq = []
    extra = set(proc) - {"source_data", "steps", "output", "open_questions", "version", "edited_by", "edited_at", "from_detector", "note"}
    if extra:
        probs.append("unknown field%s: %s" % ("s" if len(extra) > 1 else "", ", ".join(sorted(extra))))
    if probs:
        raise ValueError("; ".join(probs))
    return {"source_data": clean_src, "steps": [x.strip() for x in steps],
            "output": {"columns": [c.strip() for c in ocols], "order": (out.get("order") or "").strip()}, "open_questions": [str(x) for x in oq]}


def store(r, proc, admin, note=""):
    """A new version of the item's procedure (the earlier one goes to the history). A changed procedure needs new code."""
    clean = validate(proc)
    old = r.get("procedure") or procedure_of(r)
    if old and sha(old) == sha(clean) and r.get("procedure"):
        return r, False
    if old and sha(old) == sha(clean) and old.get("from_detector"):
        return r, False                                   # the detector's own procedure, saved unchanged: nothing to store
    v = int((r.get("procedure") or {}).get("version") or 0) + 1
    if r.get("procedure"):
        r.setdefault("history", []).append({"procedure": r["procedure"], "code": r.get("code")})
    clean.update(version=v, edited_by=admin, edited_at=time.time(), note=note)
    r["procedure"] = clean
    r["definition"] = " ".join("%d. %s" % (i, s) for i, s in enumerate(clean["steps"], 1))
    # a changed procedure is a rule of its own: its Python code is made from it (the detector's code, or an earlier SQL plan
    # used as the independent cross-check, described the procedure before the change; the plan stays in the history)
    r["kind"] = "python"
    r["status"], r["version"], r["approved_by"], r["approved_at"] = "approved", v, admin, time.time()
    return r, True


def code_state(r):
    """{"kind": detector|python|none, "verified": bool, ...} for the item's current procedure."""
    rule = detector_rule(r)
    if rule:
        c = E.code_of(rule) or {}
        return {"kind": "detector", "verified": True, "rule": rule, "path": c.get("path"),
                "lines": [(s["from"], s["to"]) for s in c.get("snippets", [])], "snippets": c.get("snippets", [])}
    proc = procedure_of(r)
    if not proc:
        return {"kind": "none", "verified": False, "why": "no procedure yet"}
    c = r.get("code") or {}
    ok = bool(c.get("verified_by") and c.get("procedure_sha") == sha(proc) and c.get("path") and os.path.exists(c["path"]))
    out = {"kind": "python", "verified": ok, "procedure_version": proc.get("version", 0)}
    if c:
        out.update({k: c.get(k) for k in ("path", "verified_by", "verified_at", "by")})
        out["code_for_version"] = c.get("procedure_version")         # the procedure version the stored code was made for
        out["for_this_version"] = c.get("procedure_sha") == sha(proc)
    return out


# ------------------------------------------------------------------------------------------------ the recording's files
_UPLOADS = [os.path.join(APP, "uploads")]         # the application's own uploads folder (create_app sets it)


def use_uploads_folder(path):
    _UPLOADS[0] = path


def upload_folder(upload_id):
    """The folder of one recording, or None for an id that is not a plain name (an id comes from a request)."""
    if not upload_id or not isinstance(upload_id, str) or not re.match(r"^[A-Za-z0-9_-][A-Za-z0-9_.-]*$", upload_id):
        return None
    return os.path.join(_UPLOADS[0], upload_id)


def source_paths(upload_id):
    """{file name: full path} of the recording's files (the upload's meta)."""
    d = upload_folder(upload_id)
    if not d:
        return {}
    try:
        with open(os.path.join(d, "meta.json"), encoding="utf-8") as fh:
            meta = json.load(fh)
    except (OSError, ValueError):
        return {}
    out = {FILE_NAME[k]: v for k, v in (meta.get("files") or {}).items() if v and k in FILE_NAME}
    db = os.path.join(d, "hier.sqlite")
    if meta.get("status") == "loaded" and os.path.exists(db):
        out[TREE] = db                          # the tree Family 2 built from these files
    return out


def columns_info(path, names, rows=SAMPLE_ROWS):
    """For each column name: its first position in the header and up to 12 distinct values seen in the first rows
    (the real cell formats the Coder must parse)."""
    out = {n: {"position": None, "samples": [], "rows_with_value": 0} for n in names}
    try:
        with open(path, newline="", encoding="utf-8-sig", errors="replace") as fh:
            rd = family1.L.read_csv(fh, path)
            head = next(rd, [])
            for n in names:
                if n in head:
                    out[n]["position"] = head.index(n)
            out["_header_cells"] = len(head)
            k = 0
            for row in rd:
                k += 1
                for n in names:
                    i = out[n]["position"]
                    if i is not None and i < len(row) and row[i] != "":
                        out[n]["rows_with_value"] += 1
                        if len(out[n]["samples"]) < 12 and row[i] not in out[n]["samples"]:
                            out[n]["samples"].append(row[i])
                if k >= rows:
                    break
            out["_rows_scanned"] = k
    except OSError as e:
        out["_error"] = str(e)
    return out


SAMPLE_MAX_SHOW = 200          # records shown on the page at once
SAMPLE_MAX_EXPORT = 100000     # records in one sample export


def sample_rows(path, columns=None, from_line=2, count=20):
    """Records of a source file as they are in the file, from a line number on (the file's own numbering: line 1 is the
    header, the first record is line 2; a record that spans lines is counted by the line it starts on).
    columns: the column names to keep (first match in the header), or None for every column.
    -> {"header": [...], "rows": [[line, cell, ...], ...], "next_line": the line after the last record given, or None at the end}"""
    from_line, count = max(2, int(from_line or 2)), max(1, int(count or 1))
    with open(path, newline="", encoding="utf-8-sig", errors="replace") as fh:
        rd = family1.L.read_csv(fh, path)
        head = next(rd, [])
        if columns:
            missing = [c for c in columns if c not in head]
            if missing:
                raise ValueError("the file has no column %s" % ", ".join(missing))
            pos = [head.index(c) for c in columns]
            out_head = list(columns)
        else:
            pos, out_head = None, list(head)
        rows, start = [], rd.line_num + 1
        for row in rd:
            if start >= from_line:
                cells = [row[i] if i < len(row) else "" for i in pos] if pos is not None else row
                rows.append([start] + cells)
                if len(rows) >= count:
                    nxt = rd.line_num + 1
                    return {"header": ["line"] + out_head, "rows": rows, "next_line": nxt}
            start = rd.line_num + 1
    return {"header": ["line"] + out_head, "rows": rows, "next_line": None}


# ------------------------------------------------------------------------------------------------ the code
def check_code(code, tree=False):
    """Problems of a code text before it runs: it must compile, import only the allowed modules, and define run(). With tree=True (a procedure on
    the tree): run(tree, out_csv), and no file is opened but the output (the raw CSV files are not there to read)."""
    probs = []
    try:
        parsed = ast.parse(code)
    except SyntaxError as e:
        return ["it does not compile: %s (line %s)" % (e.msg, e.lineno)]
    tree_ = parsed.body
    for node in ast.walk(parsed):
        if isinstance(node, ast.Import):
            for a in node.names:
                if a.name not in ALLOWED_IMPORTS:
                    probs.append("imports %s (allowed: %s)" % (a.name, ", ".join(sorted(ALLOWED_IMPORTS))))
        elif isinstance(node, ast.ImportFrom):
            if (node.module or "") not in ALLOWED_IMPORTS:
                probs.append("imports from %s (allowed: %s)" % (node.module, ", ".join(sorted(ALLOWED_IMPORTS))))
            elif node.module == "nvme_hier" and any(a.name != "names" for a in node.names):
                probs.append("imports from nvme_hier something other than names")
        elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in FORBIDDEN_CALLS:
            probs.append("calls %s()" % node.func.id)
        elif isinstance(node, ast.Attribute) and node.attr.startswith("_"):
            probs.append("reaches the hidden attribute %s" % node.attr)
        elif isinstance(node, ast.Name) and node.id.startswith("__"):
            probs.append("reaches %s" % node.id)
    calls = {id(n.func) for n in ast.walk(parsed) if isinstance(n, ast.Call)}
    for node in ast.walk(parsed):
        if isinstance(node, ast.Name) and node.id == "open" and id(node) not in calls:
            probs.append("uses open other than by calling it")
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "open":
            mode = node.args[1] if len(node.args) > 1 else next((k.value for k in node.keywords if k.arg == "mode"), None)
            writing = not (mode is None or (isinstance(mode, ast.Constant) and isinstance(mode.value, str) and not set(mode.value) & set("wax+")))
            target = node.args[0] if node.args else None
            if writing and not (isinstance(target, ast.Name) and target.id == "out_csv"):
                probs.append("opens a file for writing other than out_csv")
            if tree and not (isinstance(target, ast.Name) and target.id == "out_csv"):
                probs.append("opens a file other than out_csv: a procedure on the tree reads the tree only (tree.rows, tree.children ...), never the CSV files")
    runs = [n for n in tree_ if isinstance(n, ast.FunctionDef) and n.name == "run"]
    want = ["tree", "out_csv"] if tree else ["sources", "out_csv"]
    if not runs:
        probs.append("it has no function run(%s)" % ", ".join(want))
    elif len(runs[0].args.args) != 2:
        probs.append("its run() must take two values (%s), not (%s)" % (", ".join(want), ", ".join(a.arg for a in runs[0].args.args)))
    return probs


RUN_MEMORY_BYTES = 8 * 1024 ** 3            # a recording is read line by line: more memory than this means the code loads it whole
RUN_PRINT_BYTES = 20 * 1024 ** 2            # the result goes to the output CSV; this much printing is a mistake
RUN_TAIL_BYTES = 1024 ** 2                  # the end of what it printed, which holds its result line
RUN_MIN_FILE_BYTES = 2 * 1024 ** 3          # the output CSV may be this big, or twice the source files if that is more

RUNNER = r'''
import importlib.util, json, sys, time
try:
    import resource
except ImportError:          # Windows has no resource module: the memory limit is set by hold_memory() below, the size of the output file is watched by the program that started this one
    resource = None
sys.path.insert(0, %(app)r)
with open(sys.argv[1], encoding="utf-8") as _fh:
    args = json.load(_fh)


def hold_memory(limit):
    """Windows only: a job object holds this process to the memory limit, as RLIMIT_AS does on Linux (an allocation past it fails with MemoryError). False where Windows refuses it."""
    try:
        import ctypes
        from ctypes import wintypes
        k = ctypes.WinDLL("kernel32", use_last_error=True)

        class Basic(ctypes.Structure):
            _fields_ = [("PerProcessUserTimeLimit", ctypes.c_int64), ("PerJobUserTimeLimit", ctypes.c_int64), ("LimitFlags", wintypes.DWORD),
                        ("MinimumWorkingSetSize", ctypes.c_size_t), ("MaximumWorkingSetSize", ctypes.c_size_t), ("ActiveProcessLimit", wintypes.DWORD),
                        ("Affinity", ctypes.c_size_t), ("PriorityClass", wintypes.DWORD), ("SchedulingClass", wintypes.DWORD)]

        class Extended(ctypes.Structure):
            _fields_ = [("BasicLimitInformation", Basic), ("IoInfo", ctypes.c_uint64 * 6), ("ProcessMemoryLimit", ctypes.c_size_t),
                        ("JobMemoryLimit", ctypes.c_size_t), ("PeakProcessMemoryUsed", ctypes.c_size_t), ("PeakJobMemoryUsed", ctypes.c_size_t)]
        k.CreateJobObjectW.restype = wintypes.HANDLE
        k.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
        k.GetCurrentProcess.restype = wintypes.HANDLE
        k.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
        k.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
        job = k.CreateJobObjectW(None, None)
        if not job:
            return False
        info = Extended()
        info.BasicLimitInformation.LimitFlags = 0x100                                          # JOB_OBJECT_LIMIT_PROCESS_MEMORY
        info.ProcessMemoryLimit = int(limit)
        if not k.SetInformationJobObject(job, 9, ctypes.byref(info), ctypes.sizeof(info)):     # 9 = JobObjectExtendedLimitInformation
            return False
        return bool(k.AssignProcessToJobObject(job, k.GetCurrentProcess()))
    except Exception:
        return False


if resource is not None:
    resource.setrlimit(resource.RLIMIT_AS, (args["memory"], args["memory"]))
    resource.setrlimit(resource.RLIMIT_FSIZE, (args["file_size"], args["file_size"]))
elif sys.platform == "win32":
    hold_memory(args["memory"])


def confine():
    """The operating system itself holds this process to the recording's files, its own folder and the Python it needs, and blocks the network (Linux Landlock). The checks on
    the code's text cannot do this: a chain of ordinary attributes (a module that imports another) reaches anything. Where the kernel has no Landlock, False, and the check on open() below is what is left."""
    import ctypes, os
    if not sys.platform.startswith("linux") or not hasattr(os, "O_PATH"):
        return False                     # Landlock is Linux only: on Windows the check on open() below and the checks on the code's text are what holds the code
    libc = ctypes.CDLL(None, use_errno=True)
    create, add, restrict = 444, 445, 446
    version = libc.syscall(create, None, 0, 1)
    if version < 1:
        return False

    class Attr(ctypes.Structure):
        _fields_ = [("fs", ctypes.c_uint64), ("net", ctypes.c_uint64)]

    class Beneath(ctypes.Structure):
        _pack_ = 1
        _fields_ = [("allowed", ctypes.c_uint64), ("fd", ctypes.c_int32)]
    every_fs = (1 << 13) - 1
    read_tree = 1 | (1 << 2) | (1 << 3)
    read_file = 1 | (1 << 2)
    attr = Attr(every_fs, 3 if version >= 4 else 0)
    rules = libc.syscall(create, ctypes.byref(attr), ctypes.sizeof(Attr) if version >= 4 else 8, 0)
    if rules < 0:
        return False

    def allow(path, rights):
        try:
            fd = os.open(path, os.O_PATH | os.O_CLOEXEC)
        except OSError:
            return
        rule = Beneath(rights, fd)
        libc.syscall(add, rules, 1, ctypes.byref(rule), 0)
        os.close(fd)
    for tree in {sys.prefix, sys.base_prefix, "/usr", "/lib", "/lib64", "/etc", APP_DIR + "/nvme_hier"}:
        allow(tree, read_tree)
    for one in list(args["sources"].values()) + [args["code"]]:
        allow(one, read_file)
        for side in (one + "-wal", one + "-shm"):          # the tree is read in its write-ahead-log mode: its two side files are read too
            if args.get("tree") == one and os.path.exists(side):
                allow(side, read_file)
    for tree in {os.getcwd(), os.path.dirname(os.path.abspath(args["out_csv"]))}:
        allow(tree, every_fs)
    libc.prctl(38, 1, 0, 0, 0)
    done = libc.syscall(restrict, rules, 0) == 0
    os.close(rules)
    return done


APP_DIR = sys.path[0]
confined = confine()


def only_its_own_files():
    """The second line, and the only one on a kernel without Landlock: open() refuses everything but the recording's files and the code's own folders."""
    import builtins, os
    real_open = builtins.open
    may = {os.path.realpath(x) for x in args["sources"].values()} | {os.path.realpath(args["code"])}
    if args.get("tree"):
        may = {os.path.realpath(args["code"])}             # a procedure on the tree opens no file itself: the tree library reads the database
    here = os.path.realpath(".") + os.sep
    out = os.path.dirname(os.path.realpath(args["out_csv"])) + os.sep

    def open_checked(file, *a, **k):
        if isinstance(file, (str, bytes, os.PathLike)):
            path = os.path.realpath(file)
            if isinstance(path, bytes):
                path = path.decode(errors="replace")
            if path not in may and not path.startswith(here) and not path.startswith(out):
                raise PermissionError("this code may open only the recording's files and its own output, not " + path)
        return real_open(file, *a, **k)
    builtins.open = open_checked


only_its_own_files()
spec = importlib.util.spec_from_file_location("item_code", args["code"])
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
t0 = time.time()
if args.get("tree"):
    from nvme_hier import tree_api
    tree = tree_api.Tree(args["tree"], args.get("meanings") or {}, immutable=bool(args.get("tree_immutable")))
    summary = m.run(tree, args["out_csv"])
    print(json.dumps({"summary": summary, "seconds": round(time.time() - t0, 2), "tree_calls": dict(tree.calls)}, default=str))
else:
    summary = m.run(args["sources"], args["out_csv"])
    print(json.dumps({"summary": summary, "seconds": round(time.time() - t0, 2)}, default=str))
'''


def _tail(path, size=RUN_TAIL_BYTES):
    """The end of a file, however large it grew."""
    with open(path, "rb") as fh:
        fh.seek(0, os.SEEK_END)
        fh.seek(max(0, fh.tell() - size))
        return fh.read().decode("utf-8", errors="replace")


def read_positions(pid, paths):
    """{path: bytes read so far} for the files a process has open, from /proc/<pid>/fdinfo (Linux): how far the code has
    read into each source file, without any change to the code itself."""
    out = {}
    want = {os.path.realpath(x): x for x in paths}
    try:
        fds = os.listdir("/proc/%d/fd" % pid)
    except OSError:
        return out
    for fd in fds:
        try:
            target = os.path.realpath(os.readlink("/proc/%d/fd/%s" % (pid, fd)))
            if target in want:
                with open("/proc/%d/fdinfo/%s" % (pid, fd), encoding="utf-8") as fh:
                    for line in fh:
                        if line.startswith("pos:"):
                            out[want[target]] = max(out.get(want[target], 0), int(line.split()[1]))
        except (OSError, ValueError):
            continue
    return out


from .core import fmt_bytes as _fmt_b, fmt_secs as _fmt_s, progress_text   # noqa: E402  (one progress format for every step)


def _memory_for_code():
    """What one run of an agent's code may use: the usual limit, or less when the machine has less to spare, so that the other programs keep theirs."""
    room = family1.L.memory_available()
    if room is None:
        return RUN_MEMORY_BYTES
    return max(1024 ** 3, min(RUN_MEMORY_BYTES, room - family1.L.keep_for_others()))


def run_code(code_path, sources, out_csv, box, timeout=RUN_TIMEOUT_S, progress=None):
    """Runs the code's run(sources, out_csv) in its own Python process (isolated mode, the sandbox as folder). While it
    runs, progress(info) is called every second with how far it has read into the source files:
    {"percent", "read", "total", "file", "elapsed", "left", "text"}."""
    os.makedirs(box, exist_ok=True)
    runner = os.path.join(box, "runner.py")
    with open(runner, "w", encoding="utf-8") as fh:
        fh.write(RUNNER % {"app": APP})
    args = os.path.join(box, "args.json")
    sizes = {p: os.path.getsize(p) for p in sources.values() if os.path.exists(p)}
    total = sum(sizes.values()) or 1
    file_limit = max(RUN_MIN_FILE_BYTES, 2 * total)
    memory_limit = _memory_for_code()
    with open(args, "w", encoding="utf-8") as fh:
        json.dump({"code": code_path, "sources": sources, "out_csv": out_csv, "memory": memory_limit, "file_size": file_limit,
                   "tree": sources.get(TREE), "meanings": tree_meanings() if sources.get(TREE) else None,
                   "tree_immutable": _fold_wal(sources.get(TREE)) if sources.get(TREE) else False}, fh)
    out_p, err_p = os.path.join(box, "stdout.txt"), os.path.join(box, "stderr.txt")
    t0 = time.time()
    seen = set()                                 # source files the code has opened; one opened before and closed now is read to the end
    with open(out_p, "w", encoding="utf-8") as fo, open(err_p, "w", encoding="utf-8") as fe:
        # -X utf8: files the code opens without an encoding, and what it prints, are UTF-8 on every system (on Windows they would be cp1252)
        proc = subprocess.Popen([sys.executable, "-I", "-X", "utf8", runner, args], cwd=box, stdout=fo, stderr=fe)
        last = -1
        while proc.poll() is None:
            if time.time() - t0 > timeout:
                proc.kill()
                proc.wait()
                return {"ok": False, "error": "it ran longer than %s and was stopped" % _fmt_s(timeout)}
            time.sleep(1)
            if os.path.getsize(out_p) + os.path.getsize(err_p) > RUN_PRINT_BYTES:
                proc.kill()
                proc.wait()
                return {"ok": False, "error": "it printed more than %d MB and was stopped: the result goes to the output CSV, not to the screen" % (RUN_PRINT_BYTES // 1024 ** 2)}
            try:                                 # Windows has no file-size limit for a process; on Linux the kernel stops the write at the limit, so this never comes true there
                too_big = os.path.getsize(out_csv) > file_limit
            except OSError:
                too_big = False
            if too_big:
                proc.kill()
                proc.wait()
                return {"ok": False, "error": "it wrote more than %d GB to one file and was stopped" % (file_limit // 1024 ** 3)}
            if progress is None:
                continue
            pos = read_positions(proc.pid, list(sizes))
            seen.update(pos)
            read = sum(min(pos[p], sizes[p]) if p in pos else (sizes[p] if p in seen else 0) for p in sizes)
            pct = min(99.9, 100.0 * read / total)
            el = time.time() - t0
            cur = next((p for p in sizes if p in pos), None)
            left = el * (100 - pct) / pct if pct >= 1 else None
            text = progress_text(pct, t0, what=os.path.basename(cur) if cur and len(sizes) > 1 else "", done=read, total=total)
            if int(pct * 10) != last:
                last = int(pct * 10)
                progress({"percent": round(pct, 1), "read": read, "total": total, "file": os.path.basename(cur) if cur else None,
                          "elapsed": round(el), "left": round(left) if left is not None else None, "text": text})
    out, err = _tail(out_p), _tail(err_p)
    if proc.returncode != 0:
        if "MemoryError" in err:
            return {"ok": False, "error": "it needed more than %d GB of memory and was stopped: the code must read the files line by line" % (memory_limit // 1024 ** 3)}
        if "File too large" in err:
            return {"ok": False, "error": "it wrote more than %d GB to one file and was stopped" % (file_limit // 1024 ** 3)}
        return {"ok": False, "error": (err or out or "exit %d" % proc.returncode).strip()[-1500:]}
    try:
        res = json.loads(out.strip().splitlines()[-1])
    except (ValueError, IndexError):
        return {"ok": False, "error": "it printed no result: %s" % (out or err)[-500:]}
    return dict(res, ok=True, seconds_total=round(time.time() - t0, 1))



def sample_sources(sources, box, records=TRY_RECORDS):
    """Copies of the source files with the header and the first records only (for Try on a sample): instant on any size."""
    os.makedirs(box, exist_ok=True)
    out = {TREE: sources[TREE]} if TREE in sources else {}
    for name, path in sources.items():
        if name == TREE:
            continue
        dst = os.path.join(box, "sample_" + name)
        with open(path, newline="", encoding="utf-8-sig", errors="replace") as fi, open(dst, "w", newline="", encoding="utf-8") as fo:
            rd, w = family1.L.read_csv(fi, path), csv.writer(fo)
            for i, row in enumerate(rd):
                w.writerow(row)
                if i >= records:
                    break
        out[name] = dst
    return out


def read_output(path, head=200):
    """(columns, the first rows, the number of rows) of an output CSV."""
    with open(path, newline="", encoding="utf-8") as fh:
        rd = csv.reader(fh)
        cols = next(rd, [])
        rows, n = [], 0
        for row in rd:
            n += 1
            if len(rows) < head:
                rows.append(row)
    return cols, rows, n


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError, OverflowError):
        return None


def output_checks(proc, cols, rows, n, summary):
    """What the program checks on any output: the procedure's columns, rows written, counts and percentages that add up."""
    want = proc["output"]["columns"]
    checks = [{"check": "the output has the procedure's columns, in its order", "ok": cols == want, "detail": ", ".join(cols)}]
    checks.append({"check": "the code wrote rows", "ok": n > 0, "detail": "%s rows" % "{:,}".format(n)})
    low = [c.lower() for c in cols]
    if "percent" in low and n <= len(rows):
        pct = sum(_num(r[low.index("percent")]) or 0 for r in rows)
        checks.append({"check": "the percentages add up to 100", "ok": abs(pct - 100) < 0.002 * max(1, n) + 0.01, "detail": "%.3f" % pct})
    if "count" in low and n <= len(rows) and isinstance(summary, dict) and summary.get("total") is not None:
        tot = sum(_num(r[low.index("count")]) or 0 for r in rows)
        checks.append({"check": "the counts add up to the total the code reports", "ok": abs(tot - float(summary["total"])) < 1e-9,
                       "detail": "%s counted, total %s" % ("{:,.0f}".format(tot), summary["total"])})
    return checks


def output_checks_file(proc, path, summary):
    """output_checks on the whole result file, read line by line (any size): the columns, the lines written, and that the
    counts and the percentages add up."""
    want = proc["output"]["columns"]
    with open(path, newline="", encoding="utf-8") as fh:
        rd = csv.reader(fh)
        cols = next(rd, [])
        low = [c.lower() for c in cols]
        ip = low.index("percent") if "percent" in low else None
        ic = low.index("count") if "count" in low else None
        n, pct, cnt = 0, 0.0, 0.0
        for row in rd:
            n += 1
            if ip is not None and ip < len(row):
                pct += _num(row[ip]) or 0
            if ic is not None and ic < len(row):
                cnt += _num(row[ic]) or 0
    checks = [{"check": "the output has the procedure's columns, in its order", "ok": cols == want, "detail": ", ".join(cols)},
              {"check": "the code wrote rows", "ok": n > 0, "detail": "%s rows" % "{:,}".format(n)}]
    if ip is not None:
        checks.append({"check": "the percentages add up to 100", "ok": abs(pct - 100) < 0.002 * max(1, n) + 0.01, "detail": "%.3f" % pct})
    if ic is not None and isinstance(summary, dict) and summary.get("total") is not None:
        checks.append({"check": "the counts add up to the total the code reports", "ok": abs(cnt - float(summary["total"])) < 1e-9,
                       "detail": "%s counted, total %s" % ("{:,.0f}".format(cnt), summary["total"])})
    return checks


def cross_check(r, upload_id, cols, rows):
    """An independent count: where the item had an earlier plan (the SQL made by the fixed translator, on the tree
    database), its counts per label must equal the Python code's (two different programs, one answer)."""
    from . import family3
    if r.get("kind") not in ("distribution", "read_pattern") or not r.get("plan"):
        return None
    folder = upload_folder(upload_id)
    db = os.path.join(folder, "hier.sqlite") if folder else ""
    if not db or not os.path.exists(db):
        return None
    try:
        import sqlite3
        sql, params, _ps, _pp = family3.compile_rule(r)
        con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
        try:
            ref = {str(a): int(b) for a, b, _c in con.execute(sql, params).fetchall()}
        finally:
            con.close()
    except Exception as e:      # noqa: BLE001 - reported as not checked
        return {"check": "an independent count from the tree database agrees", "ok": True, "detail": "not checked: %s" % e}
    got = {}
    for row in rows:
        if len(row) >= 2 and _num(row[1]) is not None:
            got[row[0]] = int(_num(row[1]))
    diff = sorted(set(ref) ^ set(got)) + sorted(k for k in set(ref) & set(got) if ref[k] != got[k])
    return {"check": "an independent count from the tree database (a different program) agrees", "ok": not diff,
            "detail": "the same %d lines" % len(ref) if not diff else "differs on: %s" % ", ".join(diff[:8])}


# ------------------------------------------------------------------------------------------------ the Coder
CODER_INSTRUCTION = """You are the Coder of Family 3. Write the Python code that does EXACTLY the PROCEDURE below, step by step,
on the analyzer's CSV files. The admin wrote or approved the procedure; on your own, do not add, drop or change any step. If a
step is not clear enough to code, write the most literal reading and put your question in "questions".

THE ADMIN'S COMMENTS (ADMIN_ASKS, when present) come first. When a comment asks for something the procedure says differently or
does not say (for example other names in the output, a kind left out or merged, a step added or removed, another order), CHANGE
THE PROCEDURE as asked: return the whole changed procedure in "procedure" (the same shape: source_data, steps, output,
open_questions; keep every step the admin did not ask to change, word for word) and code that follows the changed procedure.
Say each change in "changes". When a comment asks a question (for example "what is this?"), answer it in "answers", plainly.
Without such a comment, "procedure" is null.

THE CODE MUST:
- define  def run(sources, out_csv):  sources = {file name: full path} of the procedure's source files; out_csv = the path of the
  output CSV to write (UTF-8; first row = the procedure's output columns, exactly, in that order)
- return a dict: {"rows_read": <data rows read>, "rows_written": <output rows>, "total": <the total used for percentages, or null>}
- read each CSV with csv.reader (NOT DictReader: the header repeats some names and has empty ones); find each column by its exact
  header text, first match (COLUMNS gives the position found in the real file); open files with newline="" and encoding "utf-8-sig"
- stream the rows: never load a whole file into memory (the files can hold millions of rows)
- parse each cell exactly as the procedure says; COLUMNS shows real values from the file, so handle every format seen there and
  empty cells; say in the step's comment how the cell is parsed (for example whether letter case is changed)
- import only: csv, re, math, collections, decimal, datetime, statistics, itertools, json, functools, operator, and
  "from nvme_hier import names" (names.opcode_name(opc: int, sqid: int) -> the NVMe specification's command name, "(admin)" added for queue 0)
- put a comment line "# step N: <the step's words, short>" right before the code of each step of the procedure
- no other files, no network, no os, no subprocess, no printing"""
CODER_INSTRUCTION_TREE = """You are the Coder of Family 3. Write the Python code that does EXACTLY the PROCEDURE below, step by step, on THE TREE that
Family 2 built from the recording's five files (with the joining rules the admin approved), using the meanings Family 1's data experts wrote.
The admin wrote or approved the procedure; on your own, do not add, drop or change any step. If a step is not clear enough to code, write the
most literal reading and put your question in "questions".

THE ADMIN'S COMMENTS (ADMIN_ASKS, when present) come first: when a comment asks for something the procedure says differently or does not say,
CHANGE THE PROCEDURE as asked: return the whole changed procedure in "procedure" (same shape; keep every step the admin did not ask to change, word
for word) and code that follows it; say each change in "changes". Answer questions in "answers". Without such a comment, "procedure" is null.

THE CODE MUST:
- define  def run(tree, out_csv):  tree = the recording's tree (THE_TREE below says every call); out_csv = the path of the output CSV to write
  (UTF-8; first row = the procedure's output columns, exactly, in that order)
- return a dict: {"rows_read": <rows read>, "rows_written": <output rows>, "total": <the total used for percentages, or null>}
- read the data ONLY through tree: tree.rows, tree.children, tree.parent, tree.ancestor, tree.descendants, tree.unlinked, tree.findings,
  tree.meaning. Never open a CSV file, never join two levels again by Tag, Address, CID, RequesterID or time stamp: the tree already joined
  them by identity, and a row the joins could not place has no parent (report it, do not guess one)
- stream: iterate tree.rows(...); never build a list of a whole level (a level can hold millions of rows)
- parse each cell exactly as the procedure says; COLUMNS shows real values from this tree, so handle every format seen there and empty cells
- write the output with csv.writer; import only: csv, re, math, collections, decimal, datetime, statistics, itertools, json, functools,
  operator, and "from nvme_hier import names" (names.opcode_name(opc: int, sqid: int))
- put a comment line "# step N: <the step's words, short>" right before the code of each step of the procedure
- no other files, no network, no os, no subprocess, no printing"""
CODER_SHAPE = """{"code": "<the whole Python file>", "how": ["step 1: how the code does it", "..."], "questions": ["..."],
 "procedure": null or {"source_data": [...], "steps": ["..."], "output": {"columns": ["..."], "order": "..."}, "open_questions": ["..."]},
 "changes": ["step 6: the kinds are now named sqread and RndRead, as the admin asked", "..."], "answers": ["..."]}"""

# the stand-in Coder (no model): the code of the two seeded procedures, written by hand, so the flow can be tested
STANDIN_CODE = {
    "command_type_share": '''import csv
from nvme_hier import names


def run(sources, out_csv):
    # step 1: read nvme_command.csv row by row; columns found by their exact header text, first match
    with open(sources["nvme_command.csv"], newline="", encoding="utf-8-sig") as fh:
        rd = csv.reader(fh)
        head = next(rd)
        i_opc, i_sqid = head.index("OPC"), head.index("SQID")
        counts = {}
        n = 0
        for row in rd:
            n += 1
            opc_cell = row[i_opc].strip() if i_opc < len(row) else ""
            sqid_cell = row[i_sqid].strip() if i_sqid < len(row) else ""
            if not opc_cell:
                name = "(blank)"
            else:
                # step 2: OPC "0x02 (Read)" -> the text before the first space, read as hexadecimal (case does not matter)
                opc = int(opc_cell.split(" ")[0], 16)
                # step 3: SQID as a whole number (0 = admin queue)
                sqid = int(sqid_cell) if sqid_cell else None
                # step 4: the NVMe specification's name
                name = names.opcode_name(opc, sqid)
            # step 5: hash map: command type -> rows
            counts[name] = counts.get(name, 0) + 1
    # step 6: total = the sum of the counts
    total = sum(counts.values())
    # step 7 and the output: percent, one line per type, largest count first
    with open(out_csv, "w", newline="", encoding="utf-8") as out:
        w = csv.writer(out)
        w.writerow(["command type", "count", "percent"])
        for name, k in sorted(counts.items(), key=lambda x: (-x[1], x[0])):
            w.writerow([name, k, round(100.0 * k / total, 3) if total else 0])
    return {"rows_read": n, "rows_written": len(counts), "total": total}
''',
    "read_pattern": '''import csv


def _ps(t):
    # step 4: "0000.400098983870s" -> picoseconds
    t = t.strip().rstrip("s")
    whole, _, frac = t.partition(".")
    return int(whole or 0) * 10 ** 12 + int((frac + "0" * 12)[:12] or 0)


def run(sources, out_csv):
    # step 1: read nvme_command.csv row by row; columns by exact header text, first match
    with open(sources["nvme_command.csv"], newline="", encoding="utf-8-sig") as fh:
        rd = csv.reader(fh)
        head = next(rd)
        ix = {c: head.index(c) for c in ("OPC", "SQID", "NSID", "SLBA", "NLB", "Time Stamp")}
        by_ns = {}
        n = 0
        for k, row in enumerate(rd):
            n += 1
            cell = lambda c: row[ix[c]].strip() if ix[c] < len(row) else ""
            # step 2: reads only: OPC 2 (hexadecimal before the first space) on an I/O queue, SLBA and NLB present
            if not cell("OPC") or int(cell("OPC").split(" ")[0], 16) != 2:
                continue
            if not cell("SQID") or int(cell("SQID")) == 0 or not cell("SLBA") or not cell("NLB"):
                continue
            # step 3: whole numbers; NLB is 0-based
            ns, slba, nlb = int(cell("NSID") or 0), int(cell("SLBA")), int(cell("NLB"))
            # step 5: hash map NSID -> reads (time, file order, SLBA, NLB)
            by_ns.setdefault(ns, []).append((_ps(cell("Time Stamp")), k, slba, nlb))
    counts = {}
    for ns, reads in by_ns.items():
        reads.sort()
        prev = None
        # step 6: first / sequential / random
        for _t, _k, slba, nlb in reads:
            if prev is None:
                kind = "first read of its namespace"
            elif slba == prev[0] + prev[1] + 1:
                kind = "sequential read"
            else:
                kind = "random read (RndRead)"
            counts[kind] = counts.get(kind, 0) + 1
            prev = (slba, nlb)
    # step 7 and the output: total, percent, largest first
    total = sum(counts.values())
    with open(out_csv, "w", newline="", encoding="utf-8") as out:
        w = csv.writer(out)
        w.writerow(["kind of read", "count", "percent"])
        for kind, k in sorted(counts.items(), key=lambda x: (-x[1], x[0])):
            w.writerow([kind, k, round(100.0 * k / total, 3) if total else 0])
    return {"rows_read": n, "rows_written": len(counts), "total": total}
''',
}


def standin_share_code(proc):
    """The stand-in Coder's code for the one procedure shape the stand-in Rule writer makes: the share of each value of one
    column of one file (output: the column, count, percent). None for any other procedure."""
    src = proc.get("source_data") or []
    if len(src) != 1 or len(src[0].get("columns") or []) != 1:
        return None
    col = src[0]["columns"][0]
    if proc.get("output", {}).get("columns") != [col, "count", "percent"]:
        return None
    return '''import csv


def run(sources, out_csv):
    # step 1: read %(file)s row by row; the column found by its exact header text, first match
    with open(sources[%(file)r], newline="", encoding="utf-8-sig") as fh:
        rd = csv.reader(fh)
        head = next(rd)
        i = head.index(%(col)r)
        counts, n = {}, 0
        for row in rd:
            n += 1
            # step 2: the cell as it is, spaces at both ends removed, letter case unchanged; empty -> "(blank)"
            v = row[i].strip() if i < len(row) else ""
            v = v or "(blank)"
            # step 3: hash map value -> rows
            counts[v] = counts.get(v, 0) + 1
    # step 4: total and percent
    total = sum(counts.values())
    # step 5: one line per value, largest count first
    with open(out_csv, "w", newline="", encoding="utf-8") as out:
        w = csv.writer(out)
        w.writerow([%(col)r, "count", "percent"])
        for v, k in sorted(counts.items(), key=lambda x: (-x[1], x[0])):
            w.writerow([v, k, round(100.0 * k / total, 3) if total else 0])
    return {"rows_read": n, "rows_written": len(counts), "total": total}
''' % {"file": src[0]["file"], "col": col}


def coder_context(r, proc, upload_id):
    """What the Coder is given: the procedure, and for each source file its path, the named columns' positions and real
    values (from the file itself), and Family 1's meaning of each column (with where the meaning comes from)."""
    paths = source_paths(upload_id)
    files = []
    for s in proc["source_data"]:
        lv = LEVEL_OF_FILE.get(s["file"])
        info = columns_info(paths[s["file"]], s["columns"]) if s["file"] in paths else {}
        meanings = E._meanings(lv) if lv else {}
        files.append({"file": s["file"], "path_in_this_recording": paths.get(s["file"]), "header_cells": info.get("_header_cells"),
                      "rows_scanned_for_samples": info.get("_rows_scanned"),
                      "COLUMNS": [{"name": c, "position": (info.get(c) or {}).get("position"), "real_values_seen": (info.get(c) or {}).get("samples"),
                                   "rows_with_value_in_scan": (info.get(c) or {}).get("rows_with_value"),
                                   "meaning_from_family_1": (meanings.get(c) or ("", ""))[0], "meaning_source": (meanings.get(c) or ("", "not in Family 1's dictionary"))[1]}
                                  for c in s["columns"]]})
    return {"item": r.get("name"), "PROCEDURE": {"version": proc.get("version", 0), "source_data": proc["source_data"], "steps": proc["steps"],
                                                  "output": proc["output"]}, "FILES": files}


def tree_meanings():
    """{level: {column: meaning}} from Family 1's approved dictionaries: what tree.meaning(level, column) answers inside the code."""
    return {lv: {c: (m or ("",))[0] for c, m in E._meanings(lv).items()} for lv in FILE_NAME}


def tree_facts(db):
    """What THE_TREE context says about one built tree: the guide, rows per level, rows the joins left without a parent."""
    from nvme_hier import tree_api as T
    t = T.Tree(db)
    try:
        levels = t.levels()
        no_parent = {lv: t.con.execute("SELECT COUNT(*) FROM %s WHERE parent IS NULL AND (relation IS NULL OR relation != 'context')" % T.TABLE[lv]).fetchone()[0]
                     for lv in levels if lv != "nvme_command"}
        context = {lv: t.con.execute("SELECT COUNT(*) FROM %s WHERE relation = 'context'" % T.TABLE[lv]).fetchone()[0] for lv in levels if lv == "packets"}
    finally:
        t.close()
    return {"guide": T.GUIDE, "rows_per_level": levels, "rows_without_a_parent": no_parent, "context_rows": context}


def tree_samples(db, level, column, n=12):
    from nvme_hier import tree_api as T
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    try:
        key = '$."%s"' % column.replace('"', '')
        vals = [r[0] for r in con.execute("SELECT DISTINCT json_extract(raw, ?) FROM (SELECT raw FROM %s LIMIT 5000) WHERE json_extract(raw, ?) IS NOT NULL LIMIT ?"
                                          % T.TABLE[level], (key, key, n))]
        filled = con.execute("SELECT COUNT(*) FROM (SELECT raw FROM %s LIMIT 5000) WHERE COALESCE(json_extract(raw, ?), '') != ''" % T.TABLE[level], (key,)).fetchone()[0]
    finally:
        con.close()
    return vals, filled


def coder_context_tree(r, proc, upload_id):
    """What the Coder is given for a procedure on the tree: the procedure, THE_TREE (guide, rows per level, rows without a parent) and each
    column used, with real values from this tree and Family 1's approved meaning and its source. No raw file path is given."""
    db = source_paths(upload_id).get(TREE)
    facts = tree_facts(db) if db else {"guide": "no tree is built for this recording"}
    cols = []
    for s in proc["source_data"]:
        if s["file"] != TREE:
            continue
        for c in s["columns"]:
            lv, col = tree_column(c)
            vals, filled = tree_samples(db, lv, col) if db and lv else ([], 0)
            m = E._meanings(lv).get(col) if lv else None
            cols.append({"level": lv, "file": FILE_NAME.get(lv), "name": col, "real_values_seen": vals, "rows_with_value_in_first_5000": filled,
                         "meaning_from_family_1": (m or ("", ""))[0], "meaning_source": (m or ("", "not in Family 1's dictionary"))[1]})
    return {"item": r.get("name"), "PROCEDURE": {"version": proc.get("version", 0), "source_data": proc["source_data"], "steps": proc["steps"],
                                                  "output": proc["output"]}, "THE_TREE": dict(facts, COLUMNS=cols)}


def _fold_wal(db):
    """Fold the tree's write-ahead log into its main file, so a process that may only read can open the file alone (immutable). True when the
    log is empty afterwards; False (the reader then opens it read-only in the usual way) when a writer is busy with it."""
    try:
        con = sqlite3.connect(db, timeout=5)
        try:
            con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        finally:
            con.close()
    except sqlite3.Error:
        pass
    wal = db + "-wal"
    return not os.path.exists(wal) or os.path.getsize(wal) == 0
