"""The Data Explorer's reading of a whole CSV file, on all the cores.

family1.full_profile reads every row of the file once, on one core. A real export is 4 to 6 GB with up to 1,598 columns, and
that takes too long. full_profile_parallel gives EXACTLY the same result (only "seconds" differs) and reads the file in
parts, in worker processes:

  1. the start of the file (the header and about one part of rows) is read here, one row after the other: it gives the
     header, and per column the values counted so far (at most DISTINCT_CAP, in the order they appear);
  2. every other part is read by a worker. It is told the values already counted per column, counts those, and counts the
     first new values it meets, in the order it meets them, up to the room that was left; it says so when it met a value
     that it did not count;
  3. the parts are put together here in the order of the file, with the rule the one-core reading applies row by row: a
     new value is counted while fewer than DISTINCT_CAP are, after that the column is only marked "more than counted";
  4. (seldom) a value that was first counted in a later part than the start may have gone uncounted in a part that had
     no room left for it: those parts are read once more, for those columns and those values only. This stays small:
     as soon as a column holds DISTINCT_CAP values, the parts handed out from then on are told its values and count
     exactly those, so only the few parts already handed out at that moment (WAVE per worker) can need the second reading;
  5. the kinds of row are counted per part without a limit and put together in file order with the one-core rule
     (KIND_MAX kinds one by one, the rest as "other").

Whenever the parts cannot be shown to give the same rows as the one-core reading (a part ends inside a quoted cell, a line
the CSV reader refuses, a very long line, a worker killed for memory), the file is simply read by family1.full_profile.

The work is in two halves so that family1 can use the second one too: reading gives the counts (sequential_state reads on
one core, the parts give the same counts), assemble() turns the counts into the profile.
"""
import concurrent.futures
import concurrent.futures.process
import csv
import io
import itertools
import multiprocessing
import os
import pickle
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
if APP not in sys.path:
    sys.path.insert(0, APP)
from nvme_hier import columns as C, loader as L   # noqa: E402
from . import family1 as F                        # noqa: E402  (its names are only used inside the functions)

KIND_STOP = 1000               # more different kinds of row than this in one part: the kind column is not one, the file is read on one core
WAVE = 2                       # parts handed out per worker and not yet put together (bounds the memory the results take)
PARTS_PER_WORKER = 8           # with no part size asked for, a file gives every worker at least this many parts ...
PART_MIN_BYTES = 1024 * 1024   # ... but a part is never smaller than this
TICK_SECONDS = 0.25            # how long the wait for a part lasts before the progress line is looked at again
_END = "\x1f end of this part \x1f"     # a line no analyzer writes: put after a part, it comes back as a row of its own only when the part ended outside a quoted cell
_NOTHING = frozenset()

# What the last call did, for the tests and for a log line (not for decisions: two calls at the same time share it):
# {"parallel": True/False, "why": why not, "workers", "parts", "recount_columns", "recount_parts"}
LAST = {}


class _GiveUp(Exception):
    """The parts cannot be shown to give what the one-core reading gives; the text says why. quiet = nothing worth a log line."""

    def __init__(self, why, quiet=False):
        Exception.__init__(self, why)
        self.quiet = quiet


# ---------------------------------------------------------------------------------------------- the counts -> the profile
def assemble(path, level, header, al, named, kind, rows, filled, counts, first, over, by_kind, t0):
    """The profile of a file from the counts taken over every row. This is the part of family1.full_profile after its loop, unchanged.

    path, level   as given to full_profile
    header        the first row of the file (list of cells)
    al, named     what family1._named_columns(level, header) gives: the alignment (or None) and [(column name, position)]
    kind          what family1.kind_columns(path, level) gives, or None
    rows          how many rows follow the header (a blank line counts: it has a row number)
    filled[j]     rows in which column j holds a value
    counts[j]     {value: rows holding it} for the first DISTINCT_CAP different values of column j, in the order they first appear
    first[j]      {value: the first ROWS_PER_VALUE row numbers where it appears}, the same values as counts[j]
    over[j]       True when column j holds a value that was not counted (more than DISTINCT_CAP different values)
    by_kind       {kind of row: [rows of that kind filling column 0, 1, ... , then how many rows the kind has]}; {} without a kind column
    t0            when the reading started (for "seconds")"""
    width, n = len(named), rows
    _n = F._n
    # the kinds of row, by name: "0x02 (Read)" and "Read" are the same kind
    kinds, members, kind_fact = [], [], None
    if kind and len(by_kind) > 1:
        name_at = {p: nm for nm, p in kind["columns"]}
        members = [nm for nm, _p in kind["columns"]]
        merged = {}
        for key, cnt in by_kind.items():
            if key == F._NO_KIND:
                col, value = "", "none of %s holds a value" % ", ".join(members) if len(members) > 1 else "%s holds no value" % members[0]
            elif key == F._TWO_KINDS:
                col, value = "", "more than one of %s holds a value" % ", ".join(members)
            elif key == F._OTHER_KINDS:
                col, value = "", "%s holds one of the less common values" % " or ".join(members)
            else:
                col = name_at[key[0]]
                value = (F.keyword_names(key[1], col) or [key[1]])[0][:60]
            have = merged.get((col, value))
            if have is None:
                merged[(col, value)] = {"column": col, "value": value, "rows": cnt[width], "counts": list(cnt[:width])}
            else:
                have["rows"] += cnt[width]
                have["counts"] = [a + b for a, b in zip(have["counts"], cnt[:width])]
        kinds = sorted(merged.values(), key=lambda k: (-k["rows"], k["column"], k["value"]))
        shown = ", ".join("%s (%s rows)" % (k["value"] if len(members) == 1 or not k["column"] else "%s %s" % (k["column"], k["value"]), _n(k["rows"])) for k in kinds[:8])
        kind_fact = {"columns": members, "kinds": [{"column": k["column"], "value": k["value"], "rows": k["rows"]} for k in kinds],
                     "decides": kind["decides"], "of": kind["of"], "rows_looked_at": kind["rows_looked_at"],
                     "text": "The kind of each row is named by %s: %s%s. Found by code, from which columns hold a value on which rows: in the %s rows "
                             "looked at it decides %d of the %d columns that are filled on some rows only. The counts are from every row." % (
                                 members[0] if len(members) == 1 else "one of %s (never two on the same row)" % ", ".join(members), shown,
                                 " and %d more" % (len(kinds) - 8) if len(kinds) > 8 else "", _n(kind["rows_looked_at"]), kind["decides"], kind["of"])}
    cols = []
    for j, (name, idx) in enumerate(named):
        cols.append(_column(j, name, idx, header, n, filled[j], counts[j], first[j], over[j], kinds, members))
    return {"path": path, "level": level, "level_label": C.LEVEL_LABEL.get(level) if level else "", "rows": n, "kind_of_row": kind_fact,
            "columns_with_special_status": sum(1 for x in cols if x.get("filled_for")),
            "columns_in_file": len(header), "columns_with_values": sum(1 for x in cols if x["rows_with_value"]),
            "columns_empty": [x["column"] for x in cols if not x["rows_with_value"]],
            "keyword_columns": sum(1 for x in cols if x.get("keywords")), "keywords": sum(len(x.get("keywords") or []) for x in cols),
            "header_format": al.header_format if al else "unknown", "seconds": round(time.time() - t0, 1), "columns": cols}


def _column(j, name, idx, header, n, filled_j, c, first_j, over_j, kinds, members):
    """One column of the profile, from its counts (the body of full_profile's loop over the columns, unchanged)."""
    typ = F._type_of(list(c.keys()))
    distinct = len(c)
    top = sorted(c.items(), key=lambda kv: (-kv[1], kv[0]))
    agg = {}
    for v, k in top:
        for nm in F.keyword_names(v, name):
            a = agg.setdefault(nm, {"count": 0, "rows": [], "as_written": []})
            a["count"] += k
            a["rows"] = sorted(set(a["rows"] + first_j[v]))[:F.ROWS_PER_VALUE]
            if v != nm and len(a["as_written"]) < 3:
                a["as_written"].append(v[:120])
    words = sorted(agg.items(), key=lambda kv: (-kv[1]["count"], kv[0]))
    keyword_col = 0 < len(words) <= F.KEYWORD_MAX_DISTINCT and not over_j
    col = {"column": name, "position": idx, "header_cell": header[idx] if idx < len(header) else "", "type": typ,
           "rows_with_value": filled_j, "filled_pct": round(100.0 * filled_j / max(1, n), 2),
           "distinct": distinct, "distinct_more_than_counted": over_j,
           "top_values": [{"value": v[:120], "count": k, "rows": first_j[v]} for v, k in top[:F.TOP_VALUES]]}
    if keyword_col:
        # the keywords are the words only; their counts and first rows stay in the Explorer's memory for questions
        col["keywords"] = [{"value": nm[:120], "count": a["count"], "rows": a["rows"], "as_written": a["as_written"]} for nm, a in words]
    if typ == "integer" and c:
        nums = []
        for v in c:                 # as in full_profile: a value that is not a whole number is left out
            try:
                nums.append(int(v))
            except ValueError:
                pass
        if nums:
            col["min"], col["max"] = min(nums), max(nums)
    if kinds and name not in members and 0 < filled_j < n:
        ff = F._filled_for(j, kinds, members, n)
        if ff:
            col["filled_for"] = ff
    return col


# ---------------------------------------------------------------------------------------------- the counts, on one core
def sequential_state(path, level, progress=None, share=(0.0, 100.0)):
    """The counts of every row, taken on one core: the loop of family1.full_profile, unchanged. -> the inputs of assemble(), as a dict.
    assemble(**sequential_state(path, level)) is full_profile(path, level); the tests check it."""
    size = os.path.getsize(path)
    try:
        kind = F.kind_columns(path, level)
    except (OSError, ValueError, L.BadFile):
        kind = None
    with open(path, "r", encoding="utf-8-sig", errors="replace", newline="") as fh:
        rd = L.read_csv(fh, path)
        header = next(rd, [])
        al, named = F._named_columns(level, header)
        pairs = [(j, idx) for j, (_n1, idx) in enumerate(named)]
        filled = [0] * len(named)
        counts = [dict() for _ in named]
        first = [dict() for _ in named]
        over = [False] * len(named)
        width = len(named)
        places = [p for _nm, p in kind["columns"]] if kind else []
        by_kind = {}                    # kind of row -> how many of its rows fill each column, and (last) how many rows it has
        bk = [0] * (width + 1)          # no kind column: one list that is never read
        n, t0, bytes_seen, last_report = 0, time.time(), 0, 0.0
        for row in rd:
            n += 1
            m = len(row)
            if places:
                key = None
                for p in places:
                    if p < m:
                        v = row[p]
                        if v and not v.isspace():
                            if key is not None:
                                key = F._TWO_KINDS
                                break
                            key = (p, v.strip())
                if key is None:
                    key = F._NO_KIND
                bk = by_kind.get(key)
                if bk is None:
                    if len(by_kind) >= F.KIND_MAX:
                        key = F._OTHER_KINDS
                    bk = by_kind.get(key)
                    if bk is None:
                        bk = by_kind[key] = [0] * (width + 1)
                bk[width] += 1
            for j, idx in pairs:
                if idx >= m:
                    continue
                v = row[idx]
                if not v or v.isspace():
                    continue
                v = v.strip()
                filled[j] += 1
                bk[j] += 1
                c = counts[j]
                if v in c:
                    c[v] += 1
                    f = first[j][v]
                    if len(f) < F.ROWS_PER_VALUE:
                        f.append(n)
                elif len(c) < F.DISTINCT_CAP:
                    c[v] = 1
                    first[j][v] = [n]
                else:
                    over[j] = True
            if n % 100000 == 0 and hasattr(fh, "buffer"):
                L.drop_file_cache(fh.buffer, 0, fh.buffer.tell())         # every row is read once: the file cache is left to the other programs
            if progress and n % 2000 == 0 and time.time() - last_report >= 1:      # about once a second, in one line
                last_report = time.time()
                bytes_seen = fh.buffer.tell() if hasattr(fh, "buffer") else 0
                progress(F.reading_line(os.path.basename(path), n, bytes_seen, size, t0, share, columns=len(header)))
    return {"path": path, "level": level, "header": header, "al": al, "named": named, "kind": kind, "rows": n, "filled": filled,
            "counts": counts, "first": first, "over": over, "by_kind": by_kind, "t0": t0}


# ---------------------------------------------------------------------------------------------- the counts of one part of the file
def _part_rows(path, start, end, last):
    """The rows of the bytes [start, end) of the file, as csv.reader gives them. A part starts at a line start (L.plan_chunks), and it is
    read like the one-core reading reads the file: utf-8 with unreadable bytes replaced, a byte order mark taken off only at the very
    start of the file, and lines ending in \\n, \\r or \\r\\n. After a part that is not the last one, the end mark follows as one more
    line (see _hold_last). The bytes of the part are given back to the machine's file cache as soon as they are read."""
    with open(path, "rb") as fb:
        fb.seek(start)
        data = fb.read(end - start)
        L.drop_file_cache(fb, start, end - start)
    if not last and not data.endswith(b"\n"):       # plan_chunks may cut a line of MAX_LINE_CHARS bytes after a \r: a \r\n would be split in two
        raise _GiveUp("the part of the file in bytes %d to %d does not end at a line end" % (start, end))
    text = data.decode("utf-8-sig" if start == 0 else "utf-8", errors="replace")
    del data
    if len(text) >= L.MAX_LINE_CHARS and any(len(line) >= L.MAX_LINE_CHARS for line in io.StringIO(text, newline="")):
        raise _GiveUp("a line is %d MB long or longer, which the one-core reading refuses" % (L.MAX_LINE_CHARS // 1024 ** 2))
    lines = io.StringIO(text, newline="")
    return csv.reader(lines if last else itertools.chain(lines, [_END + "\n"]))


def _hold_last(rd, last):
    """The rows of rd except the last one, which is put into the list `last`. A part that ends outside a quoted cell gives the end mark
    as a last row of its own. A part that ends inside a quoted cell takes the mark into that cell: the next part then does not start
    at the start of a row, and the parts do not give the rows of the one-core reading."""
    it = iter(rd)
    try:
        prev = next(it)
    except StopIteration:
        return
    for row in it:
        yield prev
        prev = row
    last.append(prev)


def _count(rows, at, width, places, known, room):
    """The counts over the rows of one part, numbered 1, 2, ... within the part. -> (rows, filled, counts, over, by_kind)

    at[position]   the columns (their numbers j) that read the cell at that position of a row
    places         the positions of the columns that name the kind of a row ([] = none)
    known[j]       the values of column j that were counted before this part: counted here too, always
    room[j]        how many other values of column j may still be counted: the first ones met, in the order they are met
    counts[j]      {value: [rows holding it, then its first row numbers (at most ROWS_PER_VALUE)]}, in the order the values are met
    over[j]        True when a value of column j was met that is not counted (not known, and no room left)
    by_kind        {kind of row: [rows of that kind filling column 0, 1, ..., then its rows]}, in the order the kinds are met, without the
                   KIND_MAX limit (it is applied when the parts are put together); more than KIND_STOP kinds: _GiveUp
    Per row this does what full_profile's loop does: a cell that is empty or only spaces holds no value, a value is counted without
    the spaces around it, a short row has no cell for the columns beyond its end, cells beyond the last column are not read."""
    keep = F.ROWS_PER_VALUE
    no_kind, two_kinds = F._NO_KIND, F._TWO_KINDS
    filled, over, used = [0] * width, [False] * width, [0] * width
    counts = [dict() for _ in range(width)]
    by_kind = {}
    bk = [0] * (width + 1)          # no kind column: one list that is never read
    compress = itertools.compress
    n = 0
    for row in rows:
        n += 1
        if places:
            m, key = len(row), None
            for p in places:
                if p < m:
                    v = row[p]
                    if v and not v.isspace():
                        if key is not None:
                            key = two_kinds
                            break
                        key = (p, v.strip())
            if key is None:
                key = no_kind
            bk = by_kind.get(key)
            if bk is None:
                if len(by_kind) >= KIND_STOP:
                    raise _GiveUp("one part of the file holds more than %d kinds of row" % KIND_STOP)
                bk = by_kind[key] = [0] * (width + 1)
            bk[width] += 1
        for js, v in compress(zip(at, row), row):       # only the cells that are not empty, picked without a Python step per empty cell
            if v.isspace():
                continue
            v = v.strip()
            for j in js:
                filled[j] += 1
                bk[j] += 1
                c = counts[j]
                e = c.get(v)
                if e is not None:
                    e[0] += 1
                    if len(e) <= keep:
                        e.append(n)
                elif v in known[j]:
                    c[v] = [1, n]
                elif used[j] < room[j]:
                    used[j] += 1
                    c[v] = [1, n]
                else:
                    over[j] = True
    return n, filled, counts, over, by_kind


def _positions(where):
    """where[j] = the position column j reads -> at[position] = the numbers of the columns that read it (one, as a rule; none for a
    position no column reads)."""
    at = [()] * (1 + max(list(where) + [-1]))
    for j, idx in enumerate(where):
        at[idx] += (j,)
    return at


def _scan(path, start, end, last, at, width, places, known, room):
    """The counts of the part [start, end) of the file, small enough to be sent to the main process: only the columns that hold a value.
    -> {"rows", "cols": [(j, rows with a value, met a value it did not count, counts[j])], "kinds": by_kind}. _GiveUp when the part
    (not the last one) ends inside a quoted cell."""
    tail = []
    rd = _part_rows(path, start, end, last)
    n, filled, counts, over, by_kind = _count(rd if last else _hold_last(rd, tail), at, width, places, known, room)
    if not last and tail != [[_END]]:
        raise _GiveUp("the part of the file in bytes %d to %d ends inside a quoted cell" % (start, end))
    return {"rows": n, "cols": [(j, filled[j], over[j], counts[j]) for j in range(width) if filled[j]], "kinds": by_kind}


# ---------------------------------------------------------------------------------------------- the worker processes
_W = {}         # in a worker process: what is the same for every part of the file (kept once, when the worker starts)


def _worker_starts(path, where, places, known_lists):
    """A worker process starts: it gives way to the other programs (L.worker_starts), and it keeps what every part of this file needs,
    so that the values counted at the start of the file are sent once per worker and not once per part.
    where[j] = the position column j reads; known_lists[j] = the values of column j counted at the start of the file (None = none)."""
    try:
        L.worker_starts()
    except Exception:           # giving way is a courtesy: where the system has no such call (os.nice does not exist on Windows) the worker still works
        pass
    cap = F.DISTINCT_CAP
    _W.clear()
    _W.update(path=path, where=list(where), at=_positions(where), width=len(where), places=list(places),
              known0=[frozenset(k) if k else _NOTHING for k in known_lists],
              room0=[cap - len(k) if k else cap for k in known_lists], version=None)


def _why(e):
    return str(e) if isinstance(e, _GiveUp) else "the CSV reader refuses a line (%s)" % e if isinstance(e, csv.Error) else "%s: %s" % (type(e).__name__, e)


def _told(version, later):
    """The values a worker counts per column, as of `version`: those of the start of the file and, for the columns that reached
    DISTINCT_CAP in a later part (`later`: pickled [(j, [the values first counted after the start])]), those too, with no room for
    any other. Built once per worker and version: the main process sends the same bytes with every part until a column is added."""
    if _W["version"] != version:
        known, room = list(_W["known0"]), list(_W["room0"])
        for j, values in (pickle.loads(later) if later else ()):
            known[j] = known[j] | frozenset(values)
            room[j] = 0
        _W.update(version=version, known=known, room=room)
    return _W["known"], _W["room"]


def _scan_part(args):
    """Worker: the counts of one part, args = (start, end, is it the last part, version, later: see _told). -> what _scan gives, or
    {"give_up": why}: whatever goes wrong in a worker (a line the CSV reader refuses, no memory, the file gone), the one-core reading
    then gives the result or the proper error."""
    start, end, last, version, later = args
    try:
        known, room = _told(version, later)
        return _scan(_W["path"], start, end, last, _W["at"], _W["width"], _W["places"], known, room)
    except Exception as e:
        return {"give_up": _why(e)}


def _recount_part(args):
    """Worker: one part read once more, for some columns and some values only (the module text, 4). args = (start, end, [(j, [values])]).
    -> {"cols": [(j, {value: [rows holding it, then its first row numbers]})]} with the values the part holds, or {"give_up": why}.
    The part was read before and ended at the end of a row, so no end mark is needed."""
    start, end, wanted = args
    try:
        keep = F.ROWS_PER_VALUE
        targets = [(_W["where"][j], {v: [0] for v in values}) for j, values in wanted]
        n = 0
        for row in _part_rows(_W["path"], start, end, True):
            n += 1
            m = len(row)
            for idx, got in targets:
                if idx < m:
                    v = row[idx]
                    if v and not v.isspace():
                        e = got.get(v.strip())
                        if e is not None:
                            e[0] += 1
                            if len(e) <= keep:
                                e.append(n)
        return {"cols": [(j, {v: e for v, e in got.items() if e[0]}) for (j, _values), (_idx, got) in zip(wanted, targets)]}
    except Exception as e:
        return {"give_up": _why(e)}


# ---------------------------------------------------------------------------------------------- the parts put together, in file order
def _add_kinds(total, part):
    """The kinds of row of one more part into the kinds so far, with full_profile's own rule for a kind met for the first time: it is
    counted on its own while fewer than KIND_MAX kinds are counted (the special ones included), and with the "other" kinds after that.
    The parts come in file order and a part lists its kinds in the order it met them, so every kind arrives here in the order of the file."""
    for key, cnt in part.items():
        have = total.get(key)
        if have is None:
            if len(total) >= F.KIND_MAX:
                key = F._OTHER_KINDS
            have = total.get(key)
            if have is None:
                total[key] = list(cnt)
                continue
        total[key] = [a + b for a, b in zip(have, cnt)]


def _add_part(res, m, base, counts, first, filled, over, gained, again, told):
    """The counts of part m into the counts so far; the rows of the part are rows base + 1, base + 2, ... of the file.
    -> the columns that reached DISTINCT_CAP values with this part (their values are final from here on).

    A value already counted: its rows are added, and its first rows filled up. A new value (the part lists them in the order it met
    them): counted while fewer than DISTINCT_CAP are, else the column is marked `over`, as the one-core reading does at that row.
    A part that met a value it did not count (it had counted all it had room for) also marks the column: the part alone then holds
    more new values than there was room for at the start, so the file holds more than DISTINCT_CAP. After such a part the column's
    values are DISTINCT_CAP and final. Those among them that were first counted after the start of the file (gained[j]) and are not
    in the part's list may be in the part all the same, uncounted: again[m] notes (column, those values) for the second reading.
    Not so for the columns in `told`: their worker was given the final values and counted every one of them."""
    cap, keep = F.DISTINCT_CAP, F.ROWS_PER_VALUE
    full = []
    for j, rows_with_value, dropped, c in res["cols"]:
        filled[j] += rows_with_value
        gc, gf = counts[j], first[j]
        for v, e in c.items():
            if v in gc:
                gc[v] += e[0]
                f = gf[v]
                if len(f) < keep:
                    f.extend([r + base for r in e[1:1 + keep - len(f)]])
            elif len(gc) < cap:
                gc[v] = e[0]
                gf[v] = [r + base for r in e[1:]]
                gained.setdefault(j, []).append(v)
                if len(gc) == cap:
                    full.append(j)
            else:
                over[j] = True
        if dropped:
            over[j] = True
            if j not in told:
                missed = [v for v in gained.get(j, ()) if v not in c]
                if missed:
                    again.setdefault(m, []).append((j, missed))
    return full


def _add_recount(res, base, counts, first):
    """What the second reading of a part found: the rows are added, and the first rows of a value are the earliest of those known and
    those of this part (the parts read twice arrive after the others, so the rows are put in order, not appended)."""
    keep = F.ROWS_PER_VALUE
    for j, got in res["cols"]:
        gc, gf = counts[j], first[j]
        for v, e in got.items():
            gc[v] += e[0]
            gf[v] = sorted(gf[v] + [r + base for r in e[1:]])[:keep]


def _in_order(pool, fn, how_many, task, wave, tick):
    """Gives the tasks 0 .. how_many - 1 to the pool and yields (task number, result) in that order. task(i) makes the arguments of task i
    at the moment it is given out. At most `wave` tasks are with the workers or wait to be put together, so the results never pile up
    in memory. tick({task number: its future} of those not yet put together) is called a few times a second while waiting: the progress
    line moves, and a stop asked by the admin (tick raises) is not kept waiting."""
    futs, nxt = {}, 0
    for i in range(how_many):
        res = None
        while res is None:
            while nxt < how_many and nxt - i < wave:
                futs[nxt] = pool.submit(fn, task(nxt))
                nxt += 1
            try:
                res = futs[i].result(timeout=TICK_SECONDS)
            except concurrent.futures.TimeoutError:
                pass
            tick(futs)
        del futs[i]
        if "give_up" in res:
            raise _GiveUp(res["give_up"])
        yield i, res


# ---------------------------------------------------------------------------------------------- the whole file
def _parallel(path, level, progress, share, n_workers, chunk_bytes, size, note):
    """The profile of the file, read in parts by worker processes. _GiveUp when the parts cannot be shown to give the one-core result."""
    try:
        kind = F.kind_columns(path, level)
    except (OSError, ValueError, L.BadFile):
        kind = None
    t0 = time.time()
    if progress:        # said at once: finding where the parts end reads the whole file once, and no other line is written during that
        progress(F.reading_line(os.path.basename(path), 0, 0, size, t0, share))
    try:
        parts = L.plan_chunks(path, 0, chunk_bytes)         # the first part starts at the first byte: the header is its first row
    except L.BadFile as e:
        raise _GiveUp(str(e))
    if len(parts) < 2:
        raise _GiveUp("the file is one part only", quiet=True)
    # 1. the start of the file, read here: the header, and the values counted so far
    tail = []
    try:
        rows = _hold_last(_part_rows(path, parts[0][0], parts[0][1], False), tail)
        header = next(rows, None)
        if header is None:
            raise _GiveUp("the header does not end within the first part of the file")
        al, named = F._named_columns(level, header)
        where = [idx for _name, idx in named]
        width = len(named)
        places = [p for _nm, p in kind["columns"]] if kind else []
        n, filled, c0, over, k0 = _count(rows, _positions(where), width, places, [_NOTHING] * width, [F.DISTINCT_CAP] * width)
    except csv.Error as e:
        raise _GiveUp(_why(e))
    if tail != [[_END]]:
        raise _GiveUp("the first part of the file ends inside a quoted cell")
    counts = [{v: e[0] for v, e in c.items()} for c in c0]
    first = [{v: e[1:] for v, e in c.items()} for c in c0]
    del c0
    by_kind = {}
    _add_kinds(by_kind, k0)
    rest = parts[1:]
    bases, gained, again = [], {}, {}       # rows before each part; values first counted after the start; what to read once more
    seen, said = [parts[0][1], n], [0.0]    # bytes and rows put together so far; when the progress line was last written

    def tick(waiting):
        """The progress line, about once a second: the parts put together and the parts the workers have finished."""
        if not progress or time.time() - said[0] < 1:
            return
        said[0] = time.time()
        done_bytes, lines = seen
        for i, f in waiting.items():
            if f.done() and not f.cancelled() and f.exception() is None and "rows" in f.result():
                done_bytes += rest[i][1] - rest[i][0]
                lines += f.result()["rows"]
        progress(F.reading_line(os.path.basename(path), lines, done_bytes, size, t0, share, columns=len(header)))

    # 2. the other parts, read by worker processes. A pool that notices a dead worker (see loader.load_file); spawn: the same on every system
    n_proc = min(n_workers, len(rest))
    ctx = multiprocessing.get_context("spawn")
    pool = concurrent.futures.ProcessPoolExecutor(max_workers=n_proc, mp_context=ctx, initializer=_worker_starts,
                                                  initargs=(path, where, places, [list(c) if c else None for c in counts]))
    killed = False
    final, told = {"columns": frozenset(), "version": 0, "later": b""}, {}

    def scan_task(i):
        """Part i, with the columns whose values are final by now: a worker told so counts exactly those values (nothing to read twice)."""
        told[i] = final["columns"]
        return (rest[i][0], rest[i][1], i == len(rest) - 1, final["version"], final["later"])

    try:
        for i, res in _in_order(pool, _scan_part, len(rest), scan_task, WAVE * n_proc, tick):
            # 3. put together in file order
            bases.append(n)
            full = _add_part(res, i, n, counts, first, filled, over, gained, again, told.pop(i))
            _add_kinds(by_kind, res["kinds"])
            n += res["rows"]
            seen[0], seen[1] = rest[i][1], n
            if full:        # a column reached DISTINCT_CAP after the start of the file: the parts given out from now on are told its values
                cols = final["columns"] | frozenset(full)
                final.update(columns=cols, version=final["version"] + 1,
                             later=pickle.dumps([(j, gained[j]) for j in sorted(cols)], pickle.HIGHEST_PROTOCOL))
        # 4. the parts that had no room for a value first counted after the start: read once more, for those columns and values only.
        #    Only parts given out before the column was final can be among them: at most WAVE per worker after the part that filled it
        order = sorted(again)
        for k, res in _in_order(pool, _recount_part, len(order), lambda k: (rest[order[k]][0], rest[order[k]][1], again[order[k]]), WAVE * n_proc, tick):
            _add_recount(res, bases[order[k]], counts, first)
    except concurrent.futures.process.BrokenProcessPool:
        killed = True
    finally:
        pool.shutdown(wait=False, cancel_futures=True)
    if killed:
        raise _GiveUp("a worker process was killed, usually because the machine ran out of memory")
    note.update(parallel=True, workers=n_proc, parts=len(parts), recount_parts=len(again),
                recount_columns=len({j for cols in again.values() for j, _values in cols}))
    return assemble(path, level, header, al, named, kind, n, filled, counts, first, over, by_kind, t0)


def full_profile_parallel(path, level, progress=None, share=(0.0, 100.0), workers=None, min_bytes=None, chunk_bytes=None):
    """family1.full_profile(path, level) read on all the cores: the same result, key for key and value for value ("seconds" aside).

    workers       worker processes at most (None = L.worker_count(): by the cores and the free memory)
    min_bytes     a file smaller than this is read by full_profile itself (None = L.PARALLEL_MIN_BYTES)
    chunk_bytes   the size of a part (None = L.CHUNK_BYTES; less, down to PART_MIN_BYTES, when a worker would get fewer than PARTS_PER_WORKER parts)
    progress      called with one line of text about once a second; it may raise to stop the job (the workers are then let go)
    Read by family1.full_profile itself, with the same progress and share: a small file, one worker only, a file of one part, and
    every case in which the parts cannot be shown to give the same rows (see the module text). LAST says what the call did."""
    note = {"parallel": False, "why": "", "workers": 1, "parts": 0, "recount_columns": 0, "recount_parts": 0}
    prof = None
    try:
        size = os.path.getsize(path)
        n_workers = L.worker_count() if workers is None else max(1, int(workers))
        if n_workers < 2:
            note["why"] = "one worker only"
        elif size < (L.PARALLEL_MIN_BYTES if min_bytes is None else min_bytes):
            note["why"] = "a small file"
        else:
            try:
                # no size asked for: L.CHUNK_BYTES, and less for a file that is not large, so that every worker gets several parts (the
                # last parts do not run alone while the other workers wait, and the start of the file, read on one core, stays short)
                part = int(chunk_bytes) if chunk_bytes else max(PART_MIN_BYTES, min(L.CHUNK_BYTES, size // (PARTS_PER_WORKER * n_workers)))
                prof = _parallel(path, level, progress, share, n_workers, max(1, part), size, note)
            except _GiveUp as e:
                note["why"] = str(e)
                if not e.quiet:
                    print("profile_parallel: %s is read on one core: %s" % (os.path.basename(path), e), file=sys.stderr)
    finally:
        LAST.clear()
        LAST.update(note)
    if prof is None:
        prof = F.full_profile(path, level, progress=progress, share=share)
    return prof
