"""What the application already knows about the columns of a CSV export, so that the model is asked only for what is new
(owner, 2026-11-12: "keep that document ... ground from it before moving ... if once the column name has been done, it's done").

  Library   the reference library shipped with the application (reference_library/): for each tool whose export is known, one
            entry per column name with its meaning and, for most, the line of a public document that states it. A file is
            recognised as a tool's export by its header; its columns are then answered from the library with no model call.
  Store     what earlier runs understood (knowledge/column_meanings/<tool or unknown_source>.json): the meaning of each
            column and of each of its keywords, with its source, the file it was learned from and the admin's approval.

Neither writes a meaning. The library's meanings were written, with their quotes, when the reference document was prepared;
the store's are the Data Grounder's own earlier answers. What code does here is only finding the right entry for a name.
"""
import glob
import json
import os
import re
import threading
import time

from . import core

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
DOCUMENT = "CSV_EXPORT_REFERENCE.md"
RECOGNISE_SHARE = 0.3          # a file is a tool's export when at least this share of its column names is in the tool's list ...
RECOGNISE_LEAST = 5            # ... and at least this many names (three names such as Address, Data, Time are in any tool's list)
VALUES_KEPT = 20               # the keywords of a column kept beside its stored meaning (owner: "the top 20 keywords present under the column") ...
VALUES_KEPT_MOST = 60          # ... and the most kept when later files of the same column hold other keywords
_SEPARATOR = re.compile(r"column \d+")
_NUMBERED = re.compile(r"^(.+?)#(\d+)$")
_LOCK = threading.Lock()


def is_separator(name):
    """A column without a header cell: the readers name it 'column N'. It has no name to look up."""
    return bool(_SEPARATOR.fullmatch(str(name or "")))


def _load(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def _levels(entry):
    return set(entry.get("only_for") or [s["level"] for s in entry.get("seen") or []])


def previous_names(columns):
    """{column name: the named column before it in the file} from a profile's columns (each with "column" and "position", the
    index of its header cell). Separators are stepped over: the library tells two columns of one name apart by the named
    column that stands before each."""
    out, before = {}, ""
    for c in sorted(columns, key=lambda c: (c.get("position") if isinstance(c.get("position"), int) else 1 << 30)):
        name = c.get("column")
        if not name or is_separator(name):
            continue
        out[name] = before
        before = name
    return out


class Library:
    """The reference library: reference_library/index.json and each ready tool's columns.json."""

    def __init__(self, root=None):
        self.root = root or os.path.join(APP, "reference_library")
        self.tools, self.listed, self.problems = {}, [], []
        try:
            index = _load(os.path.join(self.root, "index.json"))
            tools = index.get("tools") if isinstance(index, dict) else None
            if not isinstance(tools, list):
                raise ValueError("index.json has no list of tools")
            self.listed = [t for t in tools if isinstance(t, dict) and isinstance(t.get("key"), str) and t["key"]]
        except (OSError, ValueError, RecursionError) as e:
            self.problems.append("the reference library could not be read (%s): every column is asked from the model" % e)
        for t in self.listed:
            if not t.get("columns"):
                continue
            try:
                cols = _load(os.path.join(self.root, t["columns"]))
                entries = [e for e in cols["entries"] if isinstance(e, dict) and isinstance(e.get("name"), str) and e["name"] and isinstance(e.get("kind"), str)]
                os.path.join(self.root, t.get("document") or os.path.dirname(t["columns"]))
            except (OSError, ValueError, KeyError, TypeError, AttributeError, RecursionError) as e:
                self.problems.append("the column list of %s could not be read (%s)" % (t.get("name") or t["key"], e))
                continue
            by_name, patterns = {}, {}
            for e in entries:
                (patterns if e.get("pattern") else by_name).setdefault(e["name"], []).append(e)
            # a name the export has more than once, each time another field (AL, AL#2, AL#3): all of them, under the bare name
            siblings = {}
            for n in by_name:
                m = _NUMBERED.match(n)
                if m and m.group(1) in by_name:
                    siblings.setdefault(m.group(1), list(by_name[m.group(1)]))
                    siblings[m.group(1)] += by_name[n]
            doc = os.path.join(self.root, t.get("document") or os.path.dirname(t["columns"]), DOCUMENT)
            self.tools[t["key"]] = {"key": t["key"], "name": t.get("name") or t["key"], "domain": t.get("domain") or "", "web_hint": t.get("web_hint") or "",
                                    "exports": t.get("exports") or "", "document": doc, "sources": cols.get("sources") or {}, "prepared": cols.get("prepared") or "",
                                    "by_name": by_name, "patterns": patterns, "siblings": siblings, "entries": len(entries)}

    # ---- which entries could a name be
    def _candidates(self, key, name):
        """-> (the entries this name could be, how it was found: "name" | "repeated" | "family" | "sibling" | "")."""
        t = self.tools[key]
        name = name if isinstance(name, str) else str(name or "")       # a header cell that is not text is a name the library does not have
        m = _NUMBERED.match(name)
        base = m.group(1) if m else name
        if base in t["siblings"]:
            return t["siblings"][base], "sibling"
        if name in t["by_name"]:
            return t["by_name"][name], "name"
        if m:                           # the export repeats the name: one entry stands for all of them
            got = [e for e in t["by_name"].get(base) or [] if e.get("repeated_columns")]
            if got:
                return got, "repeated"
        fam = re.sub(r"\d+", "#", name)     # RNG 12.SLBA -> RNG #.SLBA
        if fam != name and fam in t["patterns"]:
            return t["patterns"][fam], "family"
        return [], ""

    def recognise(self, names):
        """Which tool exported a file with these column names -> (tool key or None, {"names", "found", "share"}). The names
        are the readers' names of ALL columns of the file; separators do not count."""
        named = [n for n in names if n and not is_separator(n)]
        best, facts = None, {"names": len(named), "found": 0, "share": 0.0}
        for key in self.tools:
            found = sum(1 for n in named if self._candidates(key, n)[0])
            share = found / float(len(named)) if named else 0.0
            if found >= RECOGNISE_LEAST and share >= RECOGNISE_SHARE and share > facts["share"]:
                best, facts = key, {"names": len(named), "found": found, "share": round(share, 4)}
        return best, facts

    def names_found(self, key, names):
        """How many of a file's column names are in ONE tool's list -> {"names", "found", "share"} (separators do not count).
        For a tool that was named for the file (the start page's choice), where nothing has to be recognised."""
        named = [n for n in names if n and not is_separator(n)]
        found = sum(1 for n in named if self._candidates(key, n)[0]) if key in self.tools else 0
        return {"names": len(named), "found": found, "share": round(found / float(len(named)), 4) if named else 0.0}

    def lookup(self, key, level, name, before=None):
        """The entry that states this column's meaning for a file of this level -> (entry, how), or (None, why not, in words)
        when the library does not decide it: then the column goes to the model."""
        if key not in self.tools or is_separator(name):
            return None, "not in a reference document"
        cands, how = self._candidates(key, name)
        if not cands:
            return None, "not in the reference document"
        if how == "family" and not all(e.get("same_for_all_members") for e in cands):
            return None, "the reference document has the family of this name, not one meaning for all its members"
        if level:
            cands = [e for e in cands if level in _levels(e)]
            if not cands:
                return None, "the reference document has this name at another level of the export only"
        elif len(cands) > 1 or cands[0].get("only_for"):
            return None, "this name is more than one field in the export, and the level of this file is not known"
        if how == "sibling":            # the same header word several times: the named column before it tells which one this is
            cands = [e for e in cands if any(s.get("level") == level and (s.get("before") or "") == (before or "") for s in e.get("seen") or [])]
            if len(cands) != 1:
                return None, "the export has several columns of this name; the place of this one in the file does not tell which it is"
        if len(cands) != 1:
            return None, "the reference document has more than one entry for this name"
        e = cands[0]
        if e["kind"] not in ("document", "model") or not str(e.get("meaning") or "").strip():
            return None, "the reference document has no meaning for it"
        if e["kind"] == "document" and not (e.get("doc_line") and e.get("quote")):
            return None, "the reference document's entry has no quote"
        return e, how

    def answer(self, key, entry, column, how="name"):
        """One library entry as a Data Grounder answer. A document entry cites the line of the reference document that holds
        the quote (checked like any document quote); 'library' keeps what the page shows: the tool and the original document."""
        t = self.tools[key]
        lib = {"tool": key, "tool_name": t["name"], "entry": entry["name"], "kind": entry["kind"], "found_by": how, "prepared": t["prepared"]}
        if entry["kind"] == "document":
            src = {"kind": "document", "ref": "%s:%d" % (t["document"], int(entry["doc_line"])), "quote": entry["quote"]}
            s = t["sources"].get(entry.get("source")) or {}
            lib["original"] = {"title": s.get("title") or "", "version": s.get("version") or "", "publisher": s.get("publisher") or "", "address": s.get("address") or "",
                               "where": entry.get("where") or "", "line": entry.get("source_line")}
        else:
            src = {"kind": "model", "ref": "model knowledge", "quote": ""}
        return {"column": column, "meaning": str(entry["meaning"]).strip(), "source": src, "keywords": [], "library": lib}

    def original_of(self, ref):
        """For a reference into a tool's reference document ("<path>:<line>"): the original document the quote on that line
        was taken from -> {"title", "version", "publisher", "address", "where", "line", "tool_name"} or None."""
        path, _, line = str(ref or "").rpartition(":")
        if not line.isdigit():
            return None
        for t in self.tools.values():
            try:
                same = os.path.samefile(path, t["document"])
            except OSError:
                same = os.path.normcase(os.path.abspath(path)) == os.path.normcase(os.path.abspath(t["document"]))
            if not same:
                continue
            if "by_line" not in t:
                t["by_line"] = {e["doc_line"]: e for es in list(t["by_name"].values()) + list(t["patterns"].values()) for e in es if e.get("doc_line")}
            e = t["by_line"].get(int(line))
            if not e:
                return {"tool_name": t["name"]}
            s = t["sources"].get(e.get("source")) or {}
            return {"tool_name": t["name"], "title": s.get("title") or "", "version": s.get("version") or "", "publisher": s.get("publisher") or "",
                    "address": s.get("address") or "", "where": e.get("where") or "", "line": e.get("source_line")}
        return None

    def documents(self):
        """The folders of the ready tools' reference documents (searched and cited like the project's own reference folders)."""
        return [os.path.dirname(t["document"]) for t in self.tools.values() if os.path.isfile(t["document"])]

    def describe(self, key):
        """A tool in the words the prompts use -> {"key", "name", "domain", "web_hint", "exports"} or None."""
        t = self.tools.get(key)
        return {k: t[k] for k in ("key", "name", "domain", "web_hint", "exports")} if t else None


_LIBRARY = {}


def library(root=None):
    """The shipped library, read once (it changes only with a new build of the application)."""
    root = root or os.path.join(APP, "reference_library")
    with _LOCK:
        if root not in _LIBRARY:
            _LIBRARY[root] = Library(root)
        return _LIBRARY[root]


# ---------------------------------------------------------------------------------------------- what earlier runs understood
def types_fit(a, b):
    """Is a column of type b the column that was stored with type a? Whole numbers and hexadecimal numbers are told apart
    only by the values a file happens to hold, and a column without a stored type fits any."""
    if not a or not b or a == b:
        return True
    return {a, b} <= {"integer", "hex"}


def trusted(m):
    """A meaning worth remembering: one that was checked against its source, or one from the model's reading of the name and the
    data (shown as such). A document or web quote that was NOT found is not remembered: the column is asked again."""
    if not isinstance(m, dict) or not str(m.get("meaning") or "").strip():
        return False
    src = m.get("source") if isinstance(m.get("source"), dict) else {}
    return bool(m.get("checked")) or src.get("kind") in ("model", "data", "admin")


_MEANING_FIELDS = ("meaning", "source", "checked", "why", "learned_from", "type", "values", "library", "approved")


def _whole(e):
    """A stored entry with each part a run reads in the kind it is read as (a file edited by hand may hold anything): what
    is of another kind is left out, and the column or keyword is then simply understood anew."""
    out = dict(e)
    kws = out.pop("keywords", None)
    kws = {k: (m if isinstance(m.get("source") or {}, dict) else dict(m, source={})) for k, m in kws.items() if isinstance(m, dict)} if isinstance(kws, dict) else {}
    if kws:
        out["keywords"] = kws
    if not isinstance(out.get("source") or {}, dict):
        out["source"] = {}
    for field, kind in (("values", list), ("type", str), ("learned_from", dict)):
        if field in out and not isinstance(out[field], kind):
            del out[field]
    return out


def _on_top(base, ours, theirs):
    """One column as this run leaves it (ours), written on what the file holds now (theirs), given what this run had read
    of it (base): only what this run changed is written. What it merely carried along stays as the file has it now, also
    when it was taken out meanwhile (a rejected run, an entry deleted by hand), and what the admin approved meanwhile is not
    replaced by what was not approved. -> the entry to write, or None when nothing is left of it."""
    out = dict(ours)
    approved_now = bool(theirs.get("approved")) and bool(str(theirs.get("meaning") or "").strip())
    if all(ours.get(f) == base.get(f) for f in _MEANING_FIELDS) or (approved_now and not ours.get("approved")):
        for f in _MEANING_FIELDS:
            out.pop(f, None)
            if f in theirs:
                out[f] = theirs[f]
    had, there = base.get("keywords") or {}, theirs.get("keywords") or {}
    kws = dict(there)
    for kw, m in (ours.get("keywords") or {}).items():
        if m == had.get(kw) or ((there.get(kw) or {}).get("approved") and not m.get("approved")):
            continue                    # carried along, or approved meanwhile: the file's own stands
        kws[kw] = m
    out.pop("keywords", None)
    if kws:
        out["keywords"] = kws
    return out if kws or str(out.get("meaning") or "").strip() else None


class Store:
    """knowledge/column_meanings/<tool or unknown_source>.json: {"columns": {"<scope>|<name>": entry}}.

    scope is the level of the export for a recognised tool (the same name is the same field in every recording of that
    level) and the file's format key for an unknown tool (only a file with the same header is taken as the same thing)."""

    def __init__(self, folder, tool=None):
        self.folder, self.tool = folder, tool or None
        name = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(tool or "unknown_source"))
        self.path = os.path.join(folder, "%s%s.json" % ("_" if name.startswith(".") else "", name))    # never a hidden file: forget_run looks through *.json
        self.columns = self._read()
        self._changed, self._base = {}, {}      # what this run changed, and what it had read of each before its first change

    def _read(self):
        try:
            d = _load(self.path)
            cols = d.get("columns") if isinstance(d, dict) else None
            return {k: _whole(v) for k, v in cols.items() if isinstance(v, dict)} if isinstance(cols, dict) else {}
        except (OSError, ValueError, RecursionError):       # none yet, or damaged: nothing is remembered and the columns are simply asked
            return {}

    @staticmethod
    def key(scope, name):
        """The name as it is written, apart from its spaces: an export may hold two columns whose names differ only in the
        case of their letters (Timestamp and TIMESTAMP in the NVMe transactions file), and they are two fields."""
        return "%s|%s" % (scope or "", re.sub(r"\s+", " ", str(name or "")).strip())

    def match(self, scope, name, typ=None, values=None):
        """The stored entry for this column when it is the same column by its name, the kind of values it holds and its keywords,
        else None (owner: "verify just by using the column names and along with the top 20 keywords present under the column ...
        match the already stored content ... not every time by web search"). values: the keywords this file holds in the
        column; when the stored entry was learned with keywords too, at least one must be the same, or the name now stands for
        something else and the column is asked again. An approved entry holds whatever the keywords are: the admin said so."""
        e = self.columns.get(self.key(scope, name))
        if not e or not str(e.get("meaning") or "").strip() or not types_fit(e.get("type"), typ):
            return None
        if values and e.get("values") and not e.get("approved"):
            had = {core.norm(v) for v in e["values"]}
            if not any(core.norm(v) in had for v in values):
                return None
        return e

    def keywords(self, scope, name):
        """{keyword: its stored meaning entry} of a column, whether or not its type still fits."""
        e = self.columns.get(self.key(scope, name)) or {}
        return {k: v for k, v in (e.get("keywords") or {}).items() if isinstance(v, dict) and str(v.get("meaning") or "").strip()}

    def remember(self, scope, name, meaning, typ=None, values=None, learned_from=None, approved=None, library=None, level=None):
        """Keep one column's meaning and its keywords' meanings (a Data Grounder entry: meaning, source, checked, why, keywords).
        An approved entry is replaced only by another approved one; keywords are added to what is already known. What the admin
        approved is kept whatever its source (the admin read it and said yes); `checked` stays what the check of its source gave."""
        if not isinstance(meaning, dict):
            return False

        def source_of(m):
            return m["source"] if isinstance(m.get("source"), dict) else {}
        k = self.key(scope, name)
        old = self.columns.get(k) or {}
        new = dict(old)
        has_meaning = bool(str(meaning.get("meaning") or "").strip())
        if (trusted(meaning) or (approved and has_meaning)) and (approved or not old.get("approved") or not str(old.get("meaning") or "").strip()):
            new.update({"column": name, "meaning": str(meaning["meaning"]).strip(), "source": source_of(meaning), "checked": bool(meaning.get("checked")),
                        "why": meaning.get("why") or "", "learned_from": learned_from or old.get("learned_from") or {}})
            if typ:
                new["type"] = typ
            if values:                  # the keywords seen with this meaning: the newest first, the earlier ones kept after them
                new["values"] = list(dict.fromkeys([str(v) for v in values][:VALUES_KEPT] + [str(v) for v in old.get("values") or []]))[:VALUES_KEPT_MOST]
            if library:
                new["library"] = library
            elif "library" in new:
                del new["library"]
            if approved:
                new["approved"] = approved
            elif "approved" in new:
                del new["approved"]
        kws = dict(new.get("keywords") or {})
        given = meaning.get("keywords") if isinstance(meaning.get("keywords"), dict) else {}
        for kw, m in given.items():
            if not (trusted(m) or (approved and isinstance(m, dict) and str(m.get("meaning") or "").strip())):
                continue
            was = kws.get(kw) if isinstance(kws.get(kw), dict) else {}
            if was.get("approved") and not approved:
                continue
            kws[kw] = {"meaning": str(m["meaning"]).strip(), "source": source_of(m), "checked": bool(m.get("checked")), "why": m.get("why") or ""}
            if m.get("asked_once_for"):
                kws[kw]["asked_once_for"] = m["asked_once_for"]
            if learned_from:
                kws[kw]["learned_from"] = learned_from
            if approved:
                kws[kw]["approved"] = approved
        if kws:
            new["keywords"] = kws
        if not new.get("meaning") and not kws:
            return False
        new.setdefault("column", name)
        if level:
            new["level"] = level
        new["scope"] = scope or ""
        if new != old:
            self._base.setdefault(k, old)
            self.columns[k] = new
            self._changed[k] = new
        return new != old

    def save(self):
        """Write what this run added, on top of what is in the file now (another run may have written meanwhile: its columns
        and keywords are kept, an approval given meanwhile stands, and what was taken out meanwhile does not come back)."""
        if not self._changed:
            return 0
        from nvme_hier import loader as L
        with _LOCK:
            now = self._read()
            for k, ours in self._changed.items():
                e = _on_top(self._base.get(k) or {}, ours, now.get(k) or {})
                if e is None:
                    now.pop(k, None)
                else:
                    now[k] = e
            os.makedirs(self.folder, exist_ok=True)
            L.write_json_atomic(self.path, {
                "what": "What the Data Grounder understood in earlier runs: the meaning of each column and of each of its keywords, with the source it "
                        "was taken from, the file it was learned from and the admin's approval when there is one. A column found here is not asked "
                        "from the model again. Delete an entry (or this file) to have it understood anew.",
                "tool": self.tool, "saved": time.time(), "columns": now}, indent=1)
            n, self.columns, self._changed, self._base = len(self._changed), now, {}, {}
        return n


def forget_run(folder, run, file=None, since=None):
    """Take out of every store file what one run learned and the admin did not approve (the admin rejected that run's data
    dictionary: its meanings are not kept for the next file). Approved meanings stay. -> how many meanings were taken out.
    since: the time the run was created; an entry learned before it belongs to an earlier run that had the same number."""
    def mine(x):
        lf = x.get("learned_from") if isinstance(x.get("learned_from"), dict) else {}
        if x.get("approved") or lf.get("run") != run or (file is not None and lf.get("file") != file):
            return False
        at = lf.get("at")               # a time that is not a number is no time: the entry is the run's, like one without a time
        return since is None or isinstance(at, bool) or not isinstance(at, (int, float)) or not at or at >= since - 1

    if run is None or run == "":        # not a run: every meaning stored without a run would match it
        return 0
    from nvme_hier import loader as L
    n = 0
    with _LOCK:
        for p in sorted(glob.glob(os.path.join(folder, "*.json"))):
            try:
                d = _load(p)
            except (OSError, ValueError, RecursionError):
                continue
            cols = d.get("columns") if isinstance(d, dict) else None
            if not isinstance(cols, dict):
                continue
            took = 0
            for k in list(cols):
                e = cols[k]
                if not isinstance(e, dict):
                    continue
                kws = e.get("keywords") if isinstance(e.get("keywords"), dict) else {}
                for kw in [kw for kw, m in kws.items() if isinstance(m, dict) and mine(m)]:
                    del kws[kw]
                    took += 1
                if str(e.get("meaning") or "").strip() and mine(e):
                    for field in ("meaning", "source", "checked", "why", "learned_from", "library", "values", "type"):
                        e.pop(field, None)
                    took += 1
                if not kws:
                    e.pop("keywords", None)
                if not str(e.get("meaning") or "").strip() and not e.get("keywords"):
                    del cols[k]
            if took:
                d["saved"] = time.time()
                L.write_json_atomic(p, d, indent=1)
                n += took
    return n
