"""Which tool exported the recording (owner, 2026-11-12: "at the starting page ask whether the analysis is going on for Windows
ADK or Teledyne LeCroy or PCMark 10" and "there might not be need of building the hierarchy by combining many different CSVs
together, only it is needed for LeCroy Teledyne").

The tools are the ones the reference library lists (reference_library/index.json), in its order. The start page asks which one
exported the recording; the answer is kept with the analysis (project.source_tool: the library's key, or nothing when it was
not asked) and every step reads it as ctx.project.get("source_tool").

  tools()                       every listed tool, in the words the start page shows
  check(value)                  a value from a request -> (key, None), nothing given -> (None, None), refused -> (None, why)
  name_of(key)                  the tool's name for a screen (a screen never shows the key)
  needs_hierarchy(project)      does the flow join the exports of this recording into one hierarchy
  no_hierarchy_reason(project)  the words a hierarchy step shows when it is not needed ("" when it is needed)

Only what index.json says is used: "status" ("ready" = its column list is in the application) and "hierarchy" (true: several
exports of one recording are joined into one hierarchy; false: each export is one table, nothing to join)."""
import re

from . import column_knowledge

QUESTION = "Which tool exported the recording you want to analyse?"
WHY = ("The application keeps a column list and a reference document for every tool it can analyse. Your answer is kept with "
       "the analysis, and the agents use that tool's reference for the meaning of the columns. Nothing is chosen for you.")
NOTES_ONLY = "not available yet: only the notes on its export are in the application"
HIERARCHY_WORDS = {True: "the exports of one recording are joined into one hierarchy",
                   False: "one table per export: no hierarchy is built"}


def _why_not(t, lib):
    """One plain sentence when a tool cannot be chosen, worded from the library's own status; "" when it can."""
    status = re.sub(r"\s+", " ", str(t.get("status") or "")).strip()
    if status.lower() == "ready":
        return "" if t["key"] in lib.tools else "not available: its column list could not be read in this copy of the application"
    if status.lower().startswith("notes only"):
        return NOTES_ONLY
    return "not available yet: %s" % (status or "the reference library has no column list for it")


def tools(root=None):
    """Every tool the reference library lists, in the library's order ->
    [{"key", "name", "exports", "available", "sentence", "hierarchy", "hierarchy_words"}].
    available: it can be chosen on the start page; sentence: why not, when it cannot; hierarchy: True, False, or None when
    the library does not say (the flow then does what it did before the question existed: it builds the hierarchy)."""
    lib = column_knowledge.library(root)
    out = []
    for t in lib.listed:
        if not isinstance(t.get("key"), str) or not t["key"].strip():
            continue
        why = _why_not(t, lib)
        h = t.get("hierarchy") if isinstance(t.get("hierarchy"), bool) else None
        words = t.get("hierarchy_words") if isinstance(t.get("hierarchy_words"), str) and t["hierarchy_words"].strip() else ""
        out.append({"key": t["key"], "name": str(t.get("name") or t["key"]), "exports": str(t.get("exports") or ""),
                    "available": not why, "sentence": why, "hierarchy": h,
                    "hierarchy_words": "" if h is None else (words.strip() or HIERARCHY_WORDS[h])})
    return out


def check(value, root=None):
    """The tool a request names. Nothing named (absent, null or empty) -> (None, None): the analysis keeps no tool and the Data
    Grounder recognises it from the column names. A listed tool that is ready -> (key, None). Anything else -> (None, why)."""
    if value is None or value == "":
        return None, None
    all_ = tools(root)
    can = ", ".join(t["name"] for t in all_ if t["available"]) or "none in this copy of the application"
    if not isinstance(value, str):
        return None, "the tool that exported the recording must be given as text. The tools that can be chosen: %s" % can
    key = value.strip()
    t = next((t for t in all_ if t["key"] == key), None)
    if t is None:
        return None, "\"%s\" is not a tool the application knows. The tools that can be chosen: %s" % (key[:80], can)
    if not t["available"]:
        return None, "%s is %s. The tools that can be chosen: %s" % (t["name"], t["sentence"], can)
    return t["key"], None


def name_of(key, root=None):
    """The name a screen shows for a stored key; "" when nothing is stored or the library no longer lists the tool."""
    if not key:
        return ""
    return next((t["name"] for t in tools(root) if t["key"] == key), "")


def needs_hierarchy(project, root=None):
    """Does the flow join the exports of this recording into one hierarchy? False only when the analysis names a tool and the
    library says that tool's export is one table ("hierarchy": false). True when no tool was asked, when the library does
    not list it, or when the library says nothing about it: what the flow did before the question existed."""
    key = (project or {}).get("source_tool")
    t = next((t for t in tools(root) if t["key"] == key), None) if key else None
    return not (t is not None and t["hierarchy"] is False)


def no_hierarchy_reason(project, root=None):
    """The words a hierarchy step shows when it is not needed (the step is skipped, never failed); "" when it is needed."""
    if needs_hierarchy(project, root):
        return ""
    return "not needed for %s: its export is one table" % name_of((project or {}).get("source_tool"), root)
