"""Stage 2 v3 - orchestration. Starts where stage 1 stops (an isolated incident) and ends with an admitted
closed-loop regression test. No training anywhere; every learning step is an event in the database.

  present   stage1_adapter.Incident -> retrieval query -> HybridIndex top-5 + "seen before" -> presenter card:
            the stored procedure (most optimised sequence + timing + test preview) AND the LLM-generated one side by
            side when a stored one exists, only the generated one otherwise; impression logged
  execute   the admin's action (admin_actions vocabulary) -> events -> Beta counts / Plackett-Luce / CRUD;
            accept / add_cause continue:
              stored procedure of the same card -> executed FIRST on the bench (regression guard); still reproduces
              -> reuse at zero search cost; regressed -> lesson + adapt
              otherwise LLM proposal (+ the digest's sequence as a seed) -> optimizer under a trial budget AND a
              wall-clock budget (first-level triage limit) -> ddmin
            closed loop on the bench: run -> capture -> stage-1 detector -> same card isolated; "optimal" when the
            reproduction is seen N times consecutively; fixed firmware with a decoy must stay silent
            ledger: solution_propose -> solution_validate (execution) -> solution_approve (second admin) -> script_gate;
            manifest + pytest + conftest filed under the suite directory; the index re-syncs
  handle    present + a (simulated) admin's decision + execute, for unattended evaluation runs
"""
import json
import os
import time

from admin_actions import apply as apply_action, _solution as ledger_solution
from compose import COMPOSE_MAX_TOKENS, COMPOSE_SCHEMA, build_compose_prompt, clean_variants, sources_for, standin_variants
from llm_adapter import StandInLLM, check_output, family_template_scenario
from loop_rules import FIRST_LEVEL_TRIAGE_S, OPTIMAL_CONSECUTIVE, SCORE_THRESHOLD, rules_summary
from stage1_adapter import signature_of
from sweep import neighbourhood, stress_of
from optimizer import Optimizer, seed_scenario, wilson_lower
from oracle import SyntheticDeviceOracle
from presenter import build_card, render_markdown
from procgraph import ProcGraph
from prompts import build_prompt, exemplars_for
from retrieval_v3 import HybridIndex, query_from_incident
from stage1_adapter import evidence_text
from stage2_pipeline import context_hash, vhash
from testgen import GeneratorBench, emit_closed_loop_test, emit_workload_test, test_manifest, verify_closed_loop

SEARCH_ACTIONS = ("accept", "accept_with_note", "add_cause", "add_procedure", "compose_tests", "sweep", "restart_failed")


def strip(sc):
    return {"commands": [{"op": c["op"] if isinstance(c, dict) else c} for c in sc["commands"]],
            "timing": dict(sc["timing"]), "power_state": sc.get("power_state", "none")}


class SimAdmin:
    """Unattended admin for evaluation runs. 'optimist' accepts the recommendation / top candidate, approves with a
    second identity; 'strict' rejects procedures whose stored repro bound is < 0.5 and asks for a fresh search."""

    def __init__(self, mode="optimist", name="admin", approver="second_admin"):
        self.mode, self.name, self.approver = mode, name, approver

    def decide(self, card, inc):
        rec, alts = card["recommended"], card["alternatives"]
        if rec and card["seen_before"]["verdict"] in ("match", "ambiguous"):
            if self.mode == "strict" and (rec["repro_lower95"] or 0) < 0.5:
                return {"action": "reject", "sig": inc.card, "requester": self.name, "targets": [rec["doc_id"]],
                        "note": "stored bound too low; search again"}
            return {"action": "accept", "sig": inc.card, "requester": self.name, "approver": self.approver,
                    "targets": [rec["doc_id"]], "note": "sim admin accepts the stored procedure"}
        cause = next((a for a in alts if a["kind"] == "cause" and a["sig"] == inc.card), None)
        if cause:
            return {"action": "accept", "sig": inc.card, "requester": self.name, "approver": self.approver,
                    "targets": [cause["doc_id"]], "note": "sim admin confirms the cause; search for a procedure"}
        return {"action": "add_cause", "sig": inc.card, "requester": self.name, "approver": self.approver,
                "content": {"variant": 0, "text": (inc.explanation or {}).get("why", "")[:200]},
                "note": "no cause stored for this card yet"}


class Stage2V3:
    def __init__(self, db, llm=None, suite_dir=None, opt_budget=300, opt_seed=0, rule_defs=None, search_on="model",
                 bench_factory=None, log_path=None, llm_rerank=True, use_llm=True, closed_loop=True, n_bad=6, n_fixed=3,
                 dense_fn=None, max_rows=25, time_budget_s=FIRST_LEVEL_TRIAGE_S, optimal_consecutive=OPTIMAL_CONSECUTIVE, optimizer="bandit",
                 stress_trials=30):
        self.db = db
        self.graph = ProcGraph(db) if not db.hooks else db.hooks[0]
        self.index = HybridIndex(db, self.graph, dense_fn=dense_fn, k=5, seed=opt_seed)
        self.llm = llm or StandInLLM()
        self.use_llm, self.llm_rerank = use_llm, llm_rerank
        self.suite_dir, self.opt_budget, self.opt_seed = suite_dir, opt_budget, opt_seed
        self.rule_defs = rule_defs or {}
        self.search_on, self.closed_loop, self.n_bad, self.n_fixed = search_on, closed_loop, n_bad, n_fixed
        self.max_rows = max_rows
        self.time_budget_s, self.optimal_consecutive = time_budget_s, optimal_consecutive
        self.optimizer_kind = optimizer                     # "bandit" (Thompson over operators + Go-Explore) | "ppo"
        self.stress_trials = stress_trials                  # lab runs allowed for the "most stressful conditions" step (0 = off)
        self.bench_factory = bench_factory or (lambda sig, family, expected, fixed, decoy, seed: GeneratorBench(
            sig, 0, family, seed=seed, fixed=fixed, expected_cards=expected, decoy=decoy))
        self.log = open(log_path, "a", encoding="utf-8") if log_path else None
        self.counters = {"incidents": 0, "match": 0, "ambiguous": 0, "new": 0, "reuse": 0, "adapt": 0, "generate": 0,
                         "stored_still_reproduces": 0, "stored_regressed": 0, "zero_trial_repro": 0, "confirmed": 0,
                         "closed_loop_passed": 0, "closed_loop_runs": 0, "optimal": 0, "triage_timeout": 0,
                         "trials_total": 0, "llm_calls": 0, "llm_invalid": 0, "citation_violations": 0, "rerank_invalid": 0,
                         "actions": {}, "llm_agrees": 0, "llm_assessed": 0}
        self._detectability = {}

    # ------------------------------------------------------------------ 1. present (no search)
    def present(self, inc, firmware=None, device=None):
        """device: {"name", "model_number", "serial_number", "firmware_revision", "pci", "source"} or None. The context
        of a procedure is the device model + firmware (the pair the Linux NVMe driver keys its quirks on); a procedure
        saved on another device or firmware is shown as "seen on another device or firmware" and is re-validated here."""
        t0 = time.time()
        self.counters["incidents"] += 1
        fw = firmware or inc.firmware
        dev_name = (device or {}).get("name") or ""
        ctx_hash = context_hash(fw, dev_name)       # unchanged hash when no device is known (backwards compatible)
        sig, family = inc.card, inc.pattern or "?"
        self.db.apply_event("incident_seen", {"sig": sig, "pattern": family, "feats": inc.tokens}, "detector")
        q = query_from_incident(inc, ctx_hash)
        shown, all_c = self.index.query(q)
        seen, best, score = self.index.seen_before(q, shown)
        self.counters[seen] += 1
        self.db.apply_event("impression", {"sig": sig, "incident": inc.id, "policy": "hybrid_v3",
                                           "shown": [{"doc_id": c["doc_id"], "pos": i + 1, "score": c["score"],
                                                      "explore": bool(c.get("explore"))} for i, c in enumerate(shown)]}, "presenter")
        allowed = set(inc.evidence_packets) | {int(x) for blk in inc.rows for r in blk["rows"]
                                              for x in [r.split("|")[0].replace("Packet=", "").strip()] if x.isdigit()}
        ev_text = evidence_text(inc, max_rows=self.max_rows)
        t_llm = time.time()
        card = build_card(inc, q, shown, seen, best, self.graph, ev_text, allowed, self.rule_defs.get(sig, ""),
                          self.db.lessons(sig), llm=self.llm if self.use_llm else None, llm_rerank=self.llm_rerank,
                          counters=self.counters)
        llm_s = time.time() - t_llm
        if card.get("llm"):
            self.counters["llm_assessed"] += 1
            self.counters["llm_agrees"] += int(card["llm"]["agrees_with_matcher"])
        return {"sig": sig, "family": family, "fw": fw, "device": device, "ctx_hash": ctx_hash, "q": q, "shown": shown, "seen": seen,
                "best": best, "score": score, "allowed": allowed, "ev_text": ev_text, "card": card,
                "present_s": round(time.time() - t0, 1), "llm_s": round(llm_s, 1)}

    def _stress(self, oracle, sc, deadline):
        """Most stressful trigger conditions: push the confirmed procedure's timing until the defect stops reproducing."""
        if not self.stress_trials or not sc or not sc.get("commands"):
            return None
        opt = Optimizer(oracle, sc, budget=self.stress_trials, rng_seed=self.opt_seed)
        res = opt.stress_ascent(sc, max_trials=self.stress_trials, deadline=deadline)
        self.counters["trials_total"] += res["trials"]
        res["scenario"] = strip(res["scenario"])
        res["differs"] = bool(res["pushed"])
        return res

    @staticmethod
    def _search_stats(r):
        """How the search went, in plain words: trials, the operators that produced improvements, cells visited."""
        from optimizer import OPERATOR_WORDS
        helped = sorted(((max(0, int(ab[0] - 1)), o) for o, ab in (r.get("operator_stats") or {}).items()), reverse=True)
        return {"trials": r.get("trials", 0), "best_reward": r.get("best_reward"), "archive_cells": r.get("archive_cells"),
                "llm_proposals_used": r.get("llm_proposals_used", 0),
                "operators_that_helped": [{"operator": OPERATOR_WORDS.get(o, o), "improvements": n} for n, o in helped if n > 0][:5]}

    def _optimizer(self, oracle, seed, budget, rng_seed, ranges, extra, remaining):
        if self.optimizer_kind == "ppo":
            from ppo_optimizer import PPOOptimizer
            return PPOOptimizer(oracle, seed, budget=budget, rng_seed=rng_seed, ranges=ranges, extra_seeds=extra, time_budget_s=remaining)
        return Optimizer(oracle, seed, budget=budget, rng_seed=rng_seed, ranges=ranges, extra_seeds=extra, time_budget_s=remaining)

    # ------------------------------------------------------------------ 2. execute the admin's action
    def execute(self, inc, ctx, action, second_admin="second_admin"):
        t0 = time.time()
        sig, family, fw, ctx_hash = ctx["sig"], ctx["family"], ctx["fw"], ctx["ctx_hash"]
        shown, seen, card = ctx["shown"], ctx["seen"], ctx["card"]
        res = apply_action(self.db, self.graph, action, [c["doc_id"] for c in shown], inc.tokens, fw)
        self.counters["actions"][action["action"]] = self.counters["actions"].get(action["action"], 0) + 1
        out = {"incident": inc.id, "sig": sig, "pattern": family, "firmware": fw, "device": ctx.get("device"), "seen": seen, "seen_score": round(ctx["score"], 3),
               "seen_label": card["seen_before"].get("label"), "recommended": (card["recommended"] or {}).get("vhash"),
               "action": action["action"], "action_targets": action.get("targets"), "action_effects": res["effects"],
               "action_error": res["error"], "action_events": res.get("events", []),
               "llm": {k: card["llm"].get(k) for k in ("seen_before_assessment", "agrees_with_matcher", "key_packets", "cached")}
               if card.get("llm") else None, "llm_problems": card["llm_problems"], "present_s": ctx["present_s"],
               "llm_present_s": ctx["llm_s"], "search_s": 0.0, "verify_s": 0.0,
               "mode": None, "trials": 0, "status": "no_search", "repro_lower95": None, "closed_loop": None, "vhash": None,
               "optimal": False, "triage_timeout": False}
        out["rules"] = rules_summary()
        if res["error"] or action["action"] not in SEARCH_ACTIONS:
            return self._emit(out, t0)
        seed_off = int(action.get("attempt") or 0)        # restart_failed: the n-th attempt searches on another random stream
        out["attempt"] = seed_off
        if inc.layer == "workload":                        # ADK / PCMark artifact: no packets to replay on the synthetic bench
            if action["action"] in ("sweep", "compose_tests"):
                out.update(mode="workload", status="not_applicable_workload", trials=0, admitted=False, test_files=[],
                           note="sweep and composition need lab runs of the workload: available once the hardware bench runs it")
                return self._emit(out, t0)
            return self._workload(out, inc, ctx, action, fw, ctx_hash, t0)
        # ---------------- which cause, which stored procedure
        tgt = (action.get("targets") or [None])[0]
        stored, cause = None, None
        if tgt and tgt.startswith("sol::"):
            stored = next((c["payload"] for c in shown if c["doc_id"] == tgt), None)
            if stored is None:                                   # a newer version, or a same-family procedure of another card: the ledger has it
                stored = ledger_solution(self.db, tgt[5:])
            cause = stored["cause"] if stored else None
        elif tgt and tgt.startswith("cause::"):
            cause = tgt.split("::")[2]
        cause = cause or res.get("node_id") or (self.db.causes(sig) or ["c0"])[0]
        if cause not in self.db.causes(sig):
            self.db.apply_event("node_create", {"sig": sig, "node_id": cause, "content": {"variant": 0}}, action.get("requester", "admin"))
        if action["action"] == "add_procedure" and res.get("vhash"):     # the admin's own (edited) procedure: run it first
            stored = next((x for x in self.db.solutions(sig) if x["vhash"] == res["vhash"]), None)
            if stored:
                cause = stored["cause"]
        # regression guard (execute the stored procedure first) whenever the admin accepted a procedure of the SAME card -
        # "match" or "different manifestation / other context"; a related card's procedure only seeds the search
        mode = "reuse" if (stored and stored.get("sig") == sig) else ("adapt" if stored else "generate")
        # ---------------- bench (closed loop) and device model
        expected, decoy = self._expected(sig, family, inc)
        bench = self.bench_factory(sig, family, expected, False, None, self.opt_seed)
        bench_fixed = self.bench_factory(sig, family, expected, True, decoy, self.opt_seed)
        model = SyntheticDeviceOracle(sig, 0, seed=self.opt_seed, family=family)
        oracle = bench if self.search_on == "bench" else model
        t_search = time.time()
        deadline = t_search + self.time_budget_s if self.time_budget_s else None
        if action["action"] == "compose_tests":                        # tests composed by the LLM from the stored knowledge
            return self._compose(out, inc, ctx, action, bench, bench_fixed, oracle, fw, ctx_hash, t0, deadline)
        if action["action"] == "sweep":                                # vulnerability analysis around the reproducing procedure
            return self._sweep(out, inc, ctx, action, bench, bench_fixed, oracle, fw, ctx_hash, t0, deadline)
        if mode == "reuse" and action["action"] == "add_procedure":    # admin-authored: validate by execution, then approve
            k = sum(int(oracle.run(stored["scenario"])["reproduced"]) for _ in range(6))
            out.update(mode="admin_procedure", status="confirmed" if k >= 3 else "admin_procedure_failed", trials=6, repro_k=k, repro_n=6,
                       best=strip(stored["scenario"]), search_s=round(time.time() - t_search, 1))
            if k >= 3:
                out["stress"] = self._stress(oracle, out["best"], deadline)
                out["search_s"] = round(time.time() - t_search, 1)
                return self._finish(out, inc, cause, None, bench, bench_fixed, fw, ctx_hash, action, second_admin, t0, reused=False, deadline=deadline,
                                    validate_vhash=stored["vhash"])
            self.db.apply_event("solution_validate", {"vhash": stored["vhash"], "repro_lower95": 0.0}, "bench")   # -> failed-validation
            self.db.apply_event("lesson", {"sig": sig, "cause": cause, "vhash": stored["vhash"], "producer": "bench",
                                           "text": "your procedure showed the error in %d of 6 runs - not enough; the search starts from it" % k}, "bench")
            out.update(admin_procedure_k=k, admin_procedure_n=6)
            mode = "adapt"
        if mode == "reuse":
            k = sum(int(oracle.run(stored["scenario"])["reproduced"]) for _ in range(6))
            if k >= 3:
                self.counters["stored_still_reproduces"] += 1
                self.counters["zero_trial_repro"] += 1
                self.counters["reuse"] += 1
                out.update(mode="reuse", status="reused_validated", trials=6, repro_k=k, repro_n=6, best=strip(stored["scenario"]))
                out["stress"] = self._stress(oracle, out["best"], deadline)
                out["search_s"] = round(time.time() - t_search, 1)
                return self._finish(out, inc, cause, stored, bench, bench_fixed, fw, ctx_hash, action, second_admin, t0,
                                    reused=True, deadline=deadline)
            self.counters["stored_regressed"] += 1
            self.db.apply_event("lesson", {"sig": sig, "cause": cause, "vhash": stored["vhash"], "producer": "bench",
                                           "text": "the saved procedure no longer shows the error on %s" % ((("device %s, " % out["device"]["name"]) if (out.get("device") or {}).get("name") else "") + "firmware " + fw)}, "bench")
            mode = "adapt"
        self.counters[mode] += 1
        # ---------------- proposal (LLM or stand-in) + search under trial AND wall-clock budgets
        exemplars = exemplars_for(self.db, sig, family)
        prop, problems = self._propose(ctx["ev_text"], sig, family, mode, stored, exemplars, ctx["allowed"])
        seed = {"commands": prop["commands"], "timing": prop["timing"], "power_state": prop["power_state"]}
        ranges = {k: v for k, v in (prop.get("parameter_ranges") or {}).items() if isinstance(v, (list, tuple)) and len(v) == 2}
        extra = ([stored["scenario"]] if stored else []) + [c["scenario"] for c in exemplars[:2]]
        if card.get("llm") and card["llm"]["recommended_sequence"]["commands"]:
            rs = card["llm"]["recommended_sequence"]
            ok, _, cleaned = check_output({"commands": rs["commands"], "timing": rs["timing"], "power_state": rs["power_state"],
                                           "evidence_packets": [], "cause": ""}, ctx["allowed"])
            if cleaned:
                extra.append(strip(cleaned))
        extra.append(family_template_scenario(family))        # the card family's known trigger shape, always a seed
        remaining = max(1.0, deadline - time.time()) if deadline else None
        opt = self._optimizer(oracle, seed, self.opt_budget, self.opt_seed + 10 * seed_off, ranges, extra, remaining)
        r = opt.search()
        self.counters["trials_total"] += r["trials"]
        if not r["repro_k"] and r["status"] != "triage_timeout" and (not deadline or time.time() < deadline - 30):
            # nothing reproduced from the LLM seed: one retry seeded by the family template (other random stream)
            remaining = max(1.0, deadline - time.time()) if deadline else None
            opt2 = self._optimizer(oracle, family_template_scenario(family), self.opt_budget, self.opt_seed + 10 * seed_off + 1,
                                   ranges, [seed] + extra[:-1], remaining)
            r2 = opt2.search()
            self.counters["trials_total"] += r2["trials"]
            trials_both = r["trials"] + r2["trials"]
            problems = list(problems) + ["nothing reproduced from the model's proposal; a second search started from the known trigger shape of this error type"]
            if r2["repro_k"] or r2["best_reward"] >= r["best_reward"]:
                r, opt = r2, opt2
            r["trials"] = trials_both
        best_sc = opt.minimize(r["best_scenario"]) if r["repro_k"] else r["best_scenario"]
        stress = self._stress(oracle, strip(best_sc), deadline) if r["repro_k"] else None
        out.update(mode=mode, status=r["status"], trials=r["trials"], repro_k=r["repro_k"], repro_n=r["repro_n"],
                   best=strip(best_sc), proposal_problems=problems, stress=stress, search=self._search_stats(r),
                   search_s=round(time.time() - t_search, 1), triage_timeout=r["status"] == "triage_timeout")
        if out["triage_timeout"]:
            self.counters["triage_timeout"] += 1
        return self._finish(out, inc, cause, stored, bench, bench_fixed, fw, ctx_hash, action, second_admin, t0,
                            reused=False, deadline=deadline)

    def _compose(self, out, inc, ctx, action, bench, bench_fixed, oracle, fw, ctx_hash, t0, deadline):
        """'Generate test case' from the stored knowledge: LLM composes variants -> code validates -> each variant runs on the
        bench -> kept only if it reproduces -> closed loop -> filed as a test naming its sources. Never auto-approved."""
        sig, family = inc.card, inc.pattern or "?"
        sources, n_same = sources_for(self.db, self.graph, sig, family)
        out.update(mode="compose", n_sources=len(sources), n_sources_same=n_same, variants=[], admitted=False, test_files=[],
                   sources=[{k: s[k] for k in ("vhash", "origin", "status", "approved_by", "repro_lower95", "commands", "timing", "power_state")}
                            for s in sources])
        if not sources:
            out.update(status="no_sources", trials=0)
            return self._emit(out, t0)
        llm = ctx["card"].get("llm") or {}
        prompt = build_compose_prompt(ctx["ev_text"], sig, family, self.rule_defs.get(sig, ""), sources, self.db.lessons(sig),
                                      llm.get("headline"), llm.get("mechanism"))
        t_llm = time.time()
        if not self.use_llm or isinstance(self.llm, StandInLLM):
            raw, cached = standin_variants(sources), True
        else:
            raw, cached = self.llm.generate_json(prompt, COMPOSE_SCHEMA, allow_tools=True, max_tokens=COMPOSE_MAX_TOKENS)
            self.counters["llm_calls"] += (0 if cached else 1)
        out["llm_s"] = round(time.time() - t_llm, 1)
        variants, problems = clean_variants(raw, sources)
        out["proposal_problems"] = problems
        out["llm_summary"] = str(raw.get("summary", ""))[:400] if isinstance(raw, dict) else ""
        if not variants:
            out.update(status="no_valid_variants", trials=0)
            return self._emit(out, t0)
        cause = next((s["cause"] for s in sources if s["sig"] == sig), None) or (self.db.causes(sig) or ["c0"])[0]
        if cause not in self.db.causes(sig):
            self.db.apply_event("node_create", {"sig": sig, "node_id": cause, "content": {"variant": 0}}, action.get("requester", "admin"))
        # ---------------- every variant runs on the bench; kept only if it reproduces
        t_search, trials = time.time(), 0
        for v in variants:
            k = sum(int(oracle.run(v["scenario"])["reproduced"]) for _ in range(6))
            trials += 6
            low = wilson_lower(k, 6)
            v.update(repro_k=k, repro_n=6, repro_lower95=round(low, 3), confirmed=low >= 0.5, adapted=False)
        if not any(v["confirmed"] for v in variants) and (not deadline or time.time() < deadline):
            best = max(variants, key=lambda v: v["repro_k"])
            remaining = max(1.0, deadline - time.time()) if deadline else None
            opt = self._optimizer(oracle, best["scenario"], min(self.opt_budget, 120), self.opt_seed, None,
                                  [{"commands": [{"op": c} for c in s["commands"]], "timing": s["timing"], "power_state": s["power_state"]} for s in sources], remaining)
            r = opt.search()
            trials += r["trials"]
            if r["repro_k"]:
                sc = strip(opt.minimize(r["best_scenario"]))
                low = wilson_lower(r["repro_k"], r["repro_n"])
                variants.append({"name": "changed by the search, starting from '%s'" % best["name"],
                                 "rationale": "no variant showed the error reliably; the search changed the best one (%d of 6)" % best["repro_k"],
                                 "scenario": sc, "vhash": vhash(sc), "expected_packets": best["expected_packets"], "sources_used": best["sources_used"],
                                 "risks": [], "repro_k": r["repro_k"], "repro_n": r["repro_n"], "repro_lower95": round(low, 3),
                                 "confirmed": low >= 0.5, "adapted": True})
        self.counters["trials_total"] += trials
        out.update(search_s=round(time.time() - t_search, 1), trials=trials)
        # ---------------- file every confirmed variant (validated-by-execution; approval stays a two-person decision)
        fp = {"card": sig, "family": family, "rule": (inc.first_abnormal or {}).get("rule"), "layer": inc.layer,
              "origin": inc.origin, "verdict": inc.verdict, "context_hash": ctx_hash,
              "row_kinds": __import__("matcher").row_kinds([r for b in inc.rows for r in b["rows"]])}
        src_by_vh = {s["vhash"]: s for s in sources}
        t_v, files_all, test_dir = time.time(), [], None
        for v in variants:
            v.update(admitted=False, test_files=[], closed_loop=None, status="not_reproduced")
            if not v["confirmed"]:
                continue
            scen = dict(v["scenario"], _fingerprint=fp, _composed_from=v["sources_used"],
                        _composition={"name": v["name"], "rationale": v["rationale"], "expected_packets": v["expected_packets"]})
            vh = vhash(scen)
            v["vhash"] = vh
            self.db.apply_event("solution_propose", {"vhash": vh, "sig": sig, "cause": cause, "scenario": scen, "context_hash": ctx_hash,
                                                     "producer": "llm:composed" if self.use_llm else "composed"}, "composer")
            self.db.apply_event("solution_validate", {"vhash": vh, "repro_lower95": v["repro_lower95"]}, "bench")
            cl, files, d = None, [], None
            if self.closed_loop:
                cl = verify_closed_loop(bench, bench_fixed, v["scenario"], n_bad=self.n_bad, n_fixed=self.n_fixed,
                                        optimal_consecutive=self.optimal_consecutive, field_rule=(inc.first_abnormal or {}).get("rule"))
                cl["detectability"] = self._detectability.get(sig, {}).get("detectable")
                self.counters["closed_loop_runs"] += 1
                if cl["passed"]:
                    self.counters["closed_loop_passed"] += 1
                if self.suite_dir:
                    comp = {"name": v["name"], "rationale": v["rationale"], "expected_packets": v["expected_packets"], "risks": v["risks"],
                            "adapted_by_search": v["adapted"], "composed_by": getattr(self.llm, "name", "stand-in") if self.use_llm else "stand-in",
                            "summary": out["llm_summary"],
                            "sources": [{"vhash": s, "origin": src_by_vh[s]["origin"], "status": src_by_vh[s]["status"], "approved_by": src_by_vh[s]["approved_by"],
                                         "repro_lower95": src_by_vh[s]["repro_lower95"], "commands": src_by_vh[s]["commands"]} for s in v["sources_used"] if s in src_by_vh]}
                    man = test_manifest(inc.id, sig, family, v["scenario"], bench.expected, fw, fw + "+fix", v["repro_lower95"], ctx_hash, vh,
                                        ambiguity_note="error types the detector cannot tell apart from this one: %s" % self._detectability.get(sig, {}).get("engine_candidates"),
                                        composition=comp, signature=signature_of(inc), device=out.get("device"))
                    man["closed_loop_at_generation"] = cl
                    d, files = emit_closed_loop_test(self.suite_dir, man)
                    test_dir = test_dir or d
            self.db.apply_event("script_gate", {"sig": sig, "cause": cause, "vhash": vh, "gate": cl, "files": files,
                                                "admitted": bool(cl and cl["passed"])}, "integration")
            v.update(closed_loop=cl, admitted=bool(cl and cl["passed"]), test_files=files, test_dir=d,
                     status="admitted" if (cl and cl["passed"]) else "confirmed")
            files_all += files
        self.db.commit()
        out["verify_s"] = round(time.time() - t_v, 1)
        best = max(variants, key=lambda v: (v["admitted"], v["confirmed"], v["repro_k"]))
        out.update(status="composed" if any(v["confirmed"] for v in variants) else "not_reproduced", variants=variants,
                   best=best["scenario"], repro_k=best["repro_k"], repro_n=best["repro_n"], repro_lower95=best["repro_lower95"],
                   vhash=best.get("vhash"), closed_loop=best.get("closed_loop"), admitted=any(v["admitted"] for v in variants),
                   test_files=sorted(set(files_all)), test_dir=test_dir, triage_timeout=bool(deadline and time.time() > deadline))
        if out["triage_timeout"]:
            self.counters["triage_timeout"] += 1
        return self._emit(out, t0)

    def _sweep(self, out, inc, ctx, action, bench, bench_fixed, oracle, fw, ctx_hash, t0, deadline):
        """Vulnerability analysis (checklist H8): sweep the neighbourhood of the reproducing procedure - each timing
        parameter x0.5 and x2, every other power state, a doubled burst, and jammer faults when the bench can inject
        them - run each variant, keep the failure-prone ones, file the most stressful as tests. Never auto-approved."""
        sig, family = inc.card, inc.pattern or "?"
        base, base_vh, base_src = None, None, None
        content = action.get("content") or {}
        if content.get("commands"):
            from compose import clean_scenario
            cleaned, problems, fatal = clean_scenario(content)
            if fatal:
                out.update(mode="sweep", status="rejected", note="; ".join(problems), variants=[], admitted=False, test_files=[], trials=0)
                return self._emit(out, t0)
            base, base_src = cleaned, "given"
        else:
            for st in ("admin-approved", "validated-by-execution"):
                sols = self.db.solutions(sig, None, st)
                if sols:
                    base, base_vh, base_src = strip(sols[0]["scenario"]), sols[0]["vhash"], st
                    break
        out.update(mode="sweep", base_vhash=base_vh, base_source=base_src, variants=[], failure_prone=[], most_stressful=[],
                   admitted=False, test_files=[], trials=0)
        if not base:
            out.update(status="no_base")
            return self._emit(out, t0)
        variants = neighbourhood(base)
        inject = getattr(bench, "inject", None)
        if callable(inject):
            for spec in ({"kind": "tlp_corrupt", "rate": 1e-4}, {"kind": "delay_completion", "us": 500}, {"kind": "force_recovery", "every_ms": 50}):
                variants.append({"name": "link fault injected: %s" % spec["kind"].replace("_", " "), "variation": "jammer", "scenario": base, "jammer": spec, "stress": 2.0})
            out["jammer"] = "faults injected through the bench's inject()"
        else:
            out["jammer"] = "needs a hardware bench with fault injection (app/bench_hook.py inject)"
        t_s, trials = time.time(), 0
        for v in variants:
            if deadline and time.time() > deadline:
                v.update(hits=0, n=0, score_max=0.0, failure_prone=False, skipped="time budget")
                continue
            if v.get("jammer"):
                try:
                    inject(v["jammer"])
                except Exception as e:                      # noqa: BLE001
                    v.update(hits=0, n=0, score_max=0.0, failure_prone=False, skipped="inject failed: %s" % str(e)[:80])
                    continue
            k, smax = 0, 0.0
            for _ in range(3):
                res = oracle.run(v["scenario"])
                trials += 1
                k += int(res["reproduced"])
                smax = max(smax, min(1.0, (res["stage"] + res["closeness"]) / 5.0))
            v.update(hits=k, n=3, score_max=round(smax, 3), failure_prone=k >= 2, stress=stress_of(base, v))
        out["trials"] = trials
        out["search_s"] = round(time.time() - t_s, 1)
        prone = [v for v in variants if v.get("failure_prone")]
        stressful = sorted(prone, key=lambda v: (v["hits"], v["stress"], v["score_max"]), reverse=True)[:3]
        cause = next((s_["cause"] for st in ("admin-approved", "validated-by-execution") for s_ in self.db.solutions(sig, None, st)), None) \
            or (self.db.causes(sig) or ["c0"])[0]
        if cause not in self.db.causes(sig):
            self.db.apply_event("node_create", {"sig": sig, "node_id": cause, "content": {"variant": 0}}, action.get("requester", "admin"))
        fp = {"card": sig, "family": family, "rule": (inc.first_abnormal or {}).get("rule"), "layer": inc.layer, "origin": inc.origin,
              "verdict": inc.verdict, "context_hash": ctx_hash, "row_kinds": __import__("matcher").row_kinds([r for b in inc.rows for r in b["rows"]])}
        t_v, files_all, test_dir = time.time(), [], None
        for v in stressful:
            scen = dict(v["scenario"], _fingerprint=fp, _sweep={"base": base_vh, "variation": v["variation"], "jammer": v.get("jammer")})
            if v.get("jammer"):
                scen["preconditions"] = {"jammer": v["jammer"]}
            vh = vhash(scen)
            v["vhash"] = vh
            low = wilson_lower(v["hits"], v["n"])
            self.db.apply_event("solution_propose", {"vhash": vh, "sig": sig, "cause": cause, "scenario": scen, "context_hash": ctx_hash,
                                                     "producer": "sweep"}, "sweep")
            self.db.apply_event("solution_validate", {"vhash": vh, "repro_lower95": round(low, 3)}, "bench")
            cl, files, d = None, [], None
            clear = getattr(bench, "clear_faults", None)
            if self.closed_loop and (not v.get("jammer") or callable(inject)):
                if v.get("jammer"):
                    inject(v["jammer"])                              # the fault is active on the known-bad runs
                elif callable(clear):
                    clear()
                cl = verify_closed_loop(bench, bench_fixed, v["scenario"], n_bad=self.n_bad, n_fixed=self.n_fixed,
                                        optimal_consecutive=self.optimal_consecutive, field_rule=(inc.first_abnormal or {}).get("rule"))
                if v.get("jammer") and callable(clear):
                    clear()
                self.counters["closed_loop_runs"] += 1
                if cl["passed"]:
                    self.counters["closed_loop_passed"] += 1
                if self.suite_dir:
                    comp = {"name": "sweep: %s" % v["name"], "rationale": "variant '%s' also showed the error (%d of %d runs)" % (v["name"], v["hits"], v["n"]),
                            "expected_packets": [], "risks": [], "adapted_by_search": False, "composed_by": "neighbourhood sweep",
                            "producer_text": "found by trying the procedure with changed timing / power state, starting from %s" % (base_vh or "the given procedure"),
                            "summary": "", "sources": ([{"vhash": base_vh, "origin": "this error", "status": base_src, "approved_by": None, "repro_lower95": None,
                                                         "commands": [c["op"] for c in base["commands"]]}] if base_vh else [])}
                    man = test_manifest(inc.id, sig, family, v["scenario"], bench.expected, fw, fw + "+fix", round(low, 3), ctx_hash, vh,
                                        ambiguity_note="error types the detector cannot tell apart from this one: %s" % self._detectability.get(sig, {}).get("engine_candidates"),
                                        composition=comp, signature=signature_of(inc), device=out.get("device"))
                    man["closed_loop_at_generation"] = cl
                    d, files = emit_closed_loop_test(self.suite_dir, man)
                    test_dir = test_dir or d
            self.db.apply_event("script_gate", {"sig": sig, "cause": cause, "vhash": vh, "gate": cl, "files": files, "admitted": bool(cl and cl["passed"])}, "integration")
            v.update(closed_loop=cl, admitted=bool(cl and cl["passed"]), test_files=files, test_dir=d)
            files_all += files
        self.db.commit()
        out.update(status="swept" if variants else "no_variants", verify_s=round(time.time() - t_v, 1),
                   variants=[{k: v.get(k) for k in ("name", "variation", "scenario", "hits", "n", "score_max", "failure_prone", "stress", "jammer", "skipped", "vhash", "admitted", "test_files", "test_dir", "closed_loop")} for v in variants],
                   failure_prone=[v["name"] for v in prone], most_stressful=[v["name"] for v in stressful],
                   admitted=any(v.get("admitted") for v in stressful), test_files=sorted(set(files_all)), test_dir=test_dir,
                   best=(stressful[0]["scenario"] if stressful else base), repro_k=(stressful[0]["hits"] if stressful else 0), repro_n=(3 if stressful else 0),
                   repro_lower95=round(wilson_lower(stressful[0]["hits"], 3), 3) if stressful else 0.0,
                   closed_loop=(stressful[0].get("closed_loop") if stressful else None), triage_timeout=bool(deadline and time.time() > deadline))
        return self._emit(out, t0)

    def _workload(self, out, inc, ctx, action, fw, ctx_hash, t0):
        """An ADK / PCMark abnormality (no packets): the knowledge-base lookup and the LLM baseline already happened in
        present(); the lab step needs the hardware bench that runs the workload. The baseline scenario is filed as a
        PROPOSED test with the workload contract so the bench can run it; nothing is validated here."""
        sig, family = inc.card, inc.pattern or "?"
        card = ctx["card"]
        llm = card.get("llm") or {}
        rs = (llm.get("recommended_sequence") or {})
        wl = (inc.raw or {}).get("workload") or {}
        if rs.get("commands"):
            sc = {"commands": [{"op": c} for c in rs["commands"]], "timing": rs["timing"], "power_state": rs.get("power_state", "none")}
        else:                                                # no digest (stand-in, or the model gave none): the proposal path writes the baseline
            prop, problems = self._propose(ctx["ev_text"], sig, family, "generate", None, [], ctx["allowed"])
            out["proposal_problems"] = problems
            sc = {"commands": prop["commands"], "timing": prop["timing"], "power_state": prop["power_state"]}
        cause = (self.db.causes(sig) or ["c0"])[0]
        if cause not in self.db.causes(sig):
            self.db.apply_event("node_create", {"sig": sig, "node_id": cause, "content": {"text": wl.get("title") or sig}}, action.get("requester", "admin"))
        scen = dict(sc, _fingerprint={"card": sig, "family": family, "rule": (inc.first_abnormal or {}).get("rule"), "layer": "workload",
                                      "origin": inc.origin, "verdict": inc.verdict, "context_hash": ctx_hash, "row_kinds": []}, _workload=wl)
        vh = vhash(scen)
        self.db.apply_event("solution_propose", {"vhash": vh, "sig": sig, "cause": cause, "scenario": scen, "context_hash": ctx_hash,
                                                 "producer": "llm:workload-baseline"}, "composer")
        files, d = [], None
        if self.suite_dir:
            man = test_manifest(inc.id, sig, family, sc, [sig], fw, fw + "+fix", 0.0, ctx_hash, vh,
                                ambiguity_note="workload artifact: the bench must run the workload (%s) and compare the metric" % (wl.get("assessment") or wl.get("workload")),
                                signature=signature_of(inc), device=out.get("device"))
            man["bench"] = "hardware"
            meta = (inc.raw or {}).get("artifact_meta") or {}
            man["workload"] = {"assessment": wl.get("assessment") or wl.get("workload"), "phase": wl.get("phase"), "metric_id": wl.get("metric_id"),
                               "observed": wl.get("observed"), "baseline": wl.get("baseline"), "spread": wl.get("spread"), "unit": wl.get("unit"),
                               "pass_if": "metric within baseline + 3 x spread", "fail_if": "metric reproduces the observed deviation",
                               "change_points": wl.get("change_points") or []}
            man["preconditions"].update({"nuse_gb": meta.get("nuse_gb") or wl.get("nuse_gb"), "device": meta.get("device"), "firmware": meta.get("firmware") or fw,
                                         "note": "fill level (NUSE), trim alignment and flush gap are workload preconditions the bench must set; calibrate on the bench"})
            man["verdict_rules"] = {"known_bad": {"repeats": 3, "min_hits": 1, "report": "metric per run", "derivation": "the statement's 'three consecutive' rule; proposed, calibrate on the bench"},
                                    "fixed": {"repeats": 3, "max_hits": 0}}
            man["expected"]["fixed_firmware_rule"] = "the workload metric stays within the baseline band on fixed firmware"
            man["status"] = "proposed - awaiting the hardware bench"
            d, files = emit_workload_test(self.suite_dir, man)
        self.db.apply_event("script_gate", {"sig": sig, "cause": cause, "vhash": vh, "gate": None, "files": files, "admitted": False}, "integration")
        self.db.commit()
        out.update(mode="workload", status="awaiting_hardware_bench", trials=0, repro_k=0, repro_n=0, repro_lower95=0.0, best=sc, vhash=vh,
                   admitted=False, test_files=files, test_dir=d, closed_loop=None,
                   note="ADK / PCMark abnormality: the baseline scenario is filed as a proposed test; validation needs the hardware bench (app/bench_hook.py run_workload)")
        return self._emit(out, t0)

    def handle(self, inc, admin, firmware=None, second_admin="second_admin"):
        """Unattended: present, let the (simulated) admin decide, execute."""
        ctx = self.present(inc, firmware)
        action = admin.decide(ctx["card"], inc)
        out = self.execute(inc, ctx, action, second_admin)
        out["card_md"] = render_markdown(ctx["card"])
        return out

    # ------------------------------------------------------------------ pieces
    def _expected(self, sig, family, inc):
        """Ambiguity group = the card plus what the stage-1 engine itself proposes for this card on a synthetic
        capture (measured once per card); decoy = a neighbour card of the same family for the negative control."""
        if sig not in self._detectability:
            b = GeneratorBench(sig, 0, family, seed=self.opt_seed)
            try:
                d = b.detectability(n=1)
            except Exception as e:                 # noqa: BLE001
                d = {"detectable": False, "engine_candidates": [], "error": str(e)[:200]}
            self._detectability[sig] = d
        d = self._detectability[sig]
        exp = {sig} | {c for c, s in d.get("engine_candidates", [])[:3] if s >= 0.25}
        others = [c for c in self.db.all_signatures() if c != sig and c.split("-")[0] == sig.split("-")[0]]
        decoy = others[0] if others else None
        return sorted(exp), decoy

    def _propose(self, inc_text, card, family, mode, stored, exemplars, allowed):
        rule_def = self.rule_defs.get(card, "")
        p1 = build_prompt(inc_text, card, rule_def, stored, exemplars, self.db.lessons(card), family, mode, 1)
        if not self.use_llm or isinstance(self.llm, StandInLLM):
            out, cached = StandInLLM().generate_json(p1)
        elif getattr(self.llm, "name", "").startswith("anthropic"):
            # Claude reasons internally (adaptive thinking); one schema-constrained pass is enough
            p2 = build_prompt(inc_text, card, rule_def, stored, exemplars, self.db.lessons(card), family, mode, 2,
                              "(reason internally from the evidence, the rule and the exemplars before answering)")
            out, cached = self.llm.generate_json(p2, allow_tools=True)      # baseline generation may use web search when enabled
            self.counters["llm_calls"] += (0 if cached else 1)
        else:                                              # small local models: reason in text first, then flat JSON
            text_schema = {"type": "object", "properties": {"reasoning": {"type": "string"}}, "required": ["reasoning"]}
            r1, c1 = self.llm.generate_json(p1, text_schema)
            self.counters["llm_calls"] += (0 if c1 else 1)
            p2 = build_prompt(inc_text, card, rule_def, stored, exemplars, self.db.lessons(card), family, mode, 2,
                              (r1 or {}).get("reasoning", ""))
            out, cached = self.llm.generate_json(p2)
            self.counters["llm_calls"] += (0 if cached else 1)
        ok, problems, cleaned = check_output(out, allowed)
        if cleaned is None:
            self.counters["llm_invalid"] += 1
            fb, _ = StandInLLM().generate_json(p1)
            ok, problems, cleaned = check_output(fb, allowed)
            problems = ["fallback to stand-in"] + problems
        elif not ok:
            self.counters["citation_violations"] += 1
        return cleaned, problems

    def _finish(self, out, inc, cause, stored, bench, bench_fixed, fw, ctx_hash, action, second_admin, t0, reused, deadline=None, validate_vhash=None):
        sig, family = inc.card, inc.pattern or "?"
        sc = out["best"]
        lower = wilson_lower(out["repro_k"], out["repro_n"])
        out["repro_lower95"] = round(lower, 3)
        confirmed = lower >= 0.5 or reused
        fp = {"card": sig, "family": family, "rule": (inc.first_abnormal or {}).get("rule"), "layer": inc.layer,
              "origin": inc.origin, "verdict": inc.verdict, "context_hash": ctx_hash,
              "row_kinds": __import__("matcher").row_kinds([r for b in inc.rows for r in b["rows"]])}
        same_sig = bool(stored) and stored.get("sig") == sig
        scen = dict(sc, _fingerprint=fp)
        if stored and not same_sig:
            scen["_derived_from"] = stored["vhash"]          # adapted from another card's procedure, not a new version of it
        vh = stored["vhash"] if reused else (validate_vhash or vhash(scen))
        if validate_vhash:                                   # the admin's own procedure: validated under its hash, author kept
            self.db.apply_event("solution_validate", {"vhash": vh, "repro_lower95": lower}, "bench")
        elif not reused:
            self.db.apply_event("solution_propose", {"vhash": vh, "sig": sig, "cause": cause, "scenario": scen,
                                                     "context_hash": ctx_hash, "producer": "llm+optimizer" if self.use_llm else "optimizer",
                                                     "supersedes": stored["vhash"] if same_sig else None}, "optimizer")
            self.db.apply_event("solution_validate", {"vhash": vh, "repro_lower95": lower}, "bench")
        if confirmed:
            self.counters["confirmed"] += 1
        # ---------------- closed loop: the test that mimics the isolation
        cl, files = None, []
        if confirmed and self.closed_loop:
            t_v = time.time()
            cl = verify_closed_loop(bench, bench_fixed, sc, n_bad=self.n_bad, n_fixed=self.n_fixed,
                                    optimal_consecutive=self.optimal_consecutive, field_rule=(inc.first_abnormal or {}).get("rule"))
            cl["detectability"] = self._detectability.get(sig, {}).get("detectable")
            cl["bench_seconds"] = round(bench.seconds + bench_fixed.seconds, 1)
            out["verify_s"] = round(time.time() - t_v, 1)
            out["optimal"] = bool(cl.get("optimal"))
            if deadline and time.time() > deadline:
                out["triage_timeout"] = True
                cl["note"] = "the 10-minute limit passed while the result was being verified"
            self.counters["closed_loop_runs"] += 1
            if cl["passed"]:
                self.counters["closed_loop_passed"] += 1
            if out["optimal"]:
                self.counters["optimal"] += 1
            if self.suite_dir:
                man = test_manifest(inc.id, sig, family, sc, bench.expected, fw, fw + "+fix", round(lower, 3), ctx_hash, vh,
                                    ambiguity_note="error types the detector cannot tell apart from this one: %s" % self._detectability.get(sig, {}).get("engine_candidates"),
                                    signature=signature_of(inc), device=out.get("device"))
                man["closed_loop_at_generation"] = cl
                d, files = emit_closed_loop_test(self.suite_dir, man)
                out["test_dir"] = d
        # ---------------- the most stressful conditions that still trigger the defect: a second test guards the margin
        st = out.get("stress")
        if confirmed and st and st.get("differs") and self.closed_loop and cl is not None:
            t_s = time.time()
            ssc = st["scenario"]
            sscen = dict(ssc, _fingerprint=fp, _stress={"base": vh, "pushed": st["pushed"], "stress": st["stress"]})
            svh = vhash(sscen)
            self.db.apply_event("solution_propose", {"vhash": svh, "sig": sig, "cause": cause, "scenario": sscen, "context_hash": ctx_hash,
                                                     "producer": "optimizer:stress", "supersedes": None}, "optimizer")
            self.db.apply_event("solution_validate", {"vhash": svh, "repro_lower95": round(wilson_lower(2, 3), 3)}, "bench")
            scl = verify_closed_loop(bench, bench_fixed, ssc, n_bad=self.n_bad, n_fixed=self.n_fixed,
                                     optimal_consecutive=self.optimal_consecutive, field_rule=(inc.first_abnormal or {}).get("rule"))
            self.counters["closed_loop_runs"] += 1
            if scl["passed"]:
                self.counters["closed_loop_passed"] += 1
            sfiles, sd = [], None
            if self.suite_dir and scl["passed"]:
                words = ", ".join("%s x%s" % (k.replace("_", " "), v) for k, v in st["pushed"].items())
                comp = {"name": "most stressful conditions that still trigger the defect", "composed_by": "optimizer (stress ascent)",
                        "rationale": "the confirmed procedure was pushed step by step (%s) and the defect still appeared in 2 of 3 runs at each step; "
                                     "this test guards the margin around the trigger, not only the point" % words,
                        "expected_packets": [], "risks": [], "adapted_by_search": True, "summary": "",
                        "producer_text": "found by the stress ascent after the reproduction search", "sources": [
                            {"vhash": vh, "origin": "this error", "status": "confirmed", "approved_by": None, "repro_lower95": round(lower, 3),
                             "commands": [c["op"] if isinstance(c, dict) else c for c in sc["commands"]]}]}
                man = test_manifest(inc.id, sig, family, ssc, bench.expected, fw, fw + "+fix", round(wilson_lower(2, 3), 3), ctx_hash, svh,
                                    ambiguity_note="error types the detector cannot tell apart from this one: %s" % self._detectability.get(sig, {}).get("engine_candidates"),
                                    composition=comp, signature=signature_of(inc), device=out.get("device"))
                man["closed_loop_at_generation"] = scl
                man["stress"] = {"base_vhash": vh, "pushed": st["pushed"], "stress": st["stress"], "steps": st["steps"]}
                sd, sfiles = emit_closed_loop_test(self.suite_dir, man)
            self.db.apply_event("script_gate", {"sig": sig, "cause": cause, "vhash": svh, "gate": scl, "files": sfiles,
                                                "admitted": bool(scl["passed"])}, "integration")
            st.update(vhash=svh, closed_loop=scl, admitted=bool(scl["passed"]), test_files=sfiles, test_dir=sd, verify_s=round(time.time() - t_s, 1))
            out["verify_s"] = round((out.get("verify_s") or 0) + st["verify_s"], 1)
        # ---------------- four-eyes approval when the admin said yes and execution agreed
        if confirmed and not reused and action.get("approver") and action.get("approver") != action.get("requester"):
            self.db.apply_event("solution_approve", {"vhash": vh, "sig": sig, "cause": cause, "approved_by": action["approver"]},
                                action["approver"])
        self.db.apply_event("script_gate", {"sig": sig, "cause": cause, "vhash": vh, "gate": cl, "files": files,
                                            "admitted": bool(cl and cl["passed"])}, "integration")
        self.db.commit()
        extra = [f for f in ((out.get("stress") or {}).get("test_files") or []) if f.endswith(".py")]   # the margin test, in its own folder
        out.update(vhash=vh, closed_loop=cl, admitted=bool(cl and cl["passed"]), test_files=files + extra)
        return self._emit(out, t0)

    def _emit(self, out, t0):
        out["seconds"] = round(time.time() - t0, 1)
        if self.log:
            rec = {k: v for k, v in out.items() if k != "card_md"}
            self.log.write(json.dumps(rec) + "\n")
            self.log.flush()
        return out
