"""Inference-only LLM access with a deterministic fallback. No training, no fine-tuning.

Backends
  OllamaLLM     local model through Ollama's HTTP API (JSON-schema constrained output, temperature 0)
  OpenAICompat  any OpenAI-compatible endpoint (vLLM, llama.cpp server) - optional
  StandInLLM    deterministic, rule-based stand-in used when no model is reachable and for repeatable
                offline tests; produces the same JSON shape from the retrieved knowledge

Every call is cached by (model, prompt-hash) so repeated incidents cost nothing, and every answer passes
`check_citations` (only packet numbers that exist in the evidence) and the JSON schema before use.
"""
import hashlib
import json
import os
import sys
import re
import shutil
import subprocess
import threading
import time
import urllib.request

SCENARIO_SCHEMA = {
    "type": "object",
    "properties": {
        "cause": {"type": "string"},
        "reasoning": {"type": "string"},
        "commands": {"type": "array", "items": {"type": "string"}},
        "timing": {"type": "object",
                   "properties": {"inter_cmd_us": {"type": "integer"}, "burst_len": {"type": "integer"},
                                  "idle_gap_ms": {"type": "integer"}, "qd": {"type": "integer"},
                                  "bs_kb": {"type": "integer"}},
                   "required": ["inter_cmd_us", "qd"]},
        "power_state": {"type": "string"},
        "parameter_ranges": {"type": "object"},
        "evidence_packets": {"type": "array", "items": {"type": "integer"}},
        "reuses_stored_solution": {"type": "boolean"},
    },
    "required": ["cause", "commands", "timing", "evidence_packets"],
}
ALLOWED_OPS = {"read", "write", "flush", "trim", "write_zeroes", "reset", "power_cycle", "aspm_idle", "identify",
               "get_log", "set_feature", "abort"}


class LLM:
    name = "base"

    def __init__(self, cache_path=None):
        self.cache_path = cache_path
        self.cache = {}
        if cache_path and os.path.exists(cache_path):
            for line in open(cache_path, encoding="utf-8"):
                d = json.loads(line)
                self.cache[d["k"]] = d["v"]
        self.calls = 0
        self.seconds = 0.0
        self._tl = threading.local()       # the answer budget of the call in progress (per thread: the workers share one client)

    def _key(self, prompt, schema):
        return hashlib.sha256((self.name + "|" + prompt + "|" + json.dumps(schema, sort_keys=True)).encode()).hexdigest()

    tools = ()                                      # e.g. ("web_search",): used only when a call passes allow_tools=True

    def answer_limit(self):
        """The most output tokens the call in progress may use: what the caller asked for, else the client's default."""
        tl = getattr(self, "_tl", None)
        return (getattr(tl, "n", None) if tl is not None else None) or getattr(self, "max_tokens", 2000)

    def generate_json(self, prompt, schema=SCENARIO_SCHEMA, allow_tools=False, max_tokens=None):
        """max_tokens: a larger answer budget for long answers (the composition of test variants). An answer cut off at
        the budget is retried once with twice the budget, instead of failing as unreadable JSON."""
        use_tools = bool(allow_tools and self.tools)
        k = self._key(prompt + ("\n[tools:%s]" % ",".join(self.tools) if use_tools else ""), schema)
        if k in self.cache:
            return self.cache[k], True
        t = time.time()
        if not hasattr(self, "_tl"):
            self._tl = threading.local()
        self._tl.n = max_tokens
        try:
            out = self._generate(prompt, schema, use_tools)
            if isinstance(out, dict) and "_error" in out:          # one retry on a transport / backend failure
                if str(out["_error"]).startswith("cut off"):
                    self._tl.n = 2 * self.answer_limit()           # ... with twice the room when the answer did not fit
                out = self._generate(prompt, schema, use_tools)
        finally:
            self._tl.n = None
        self.seconds += time.time() - t
        self.calls += 1
        if not (isinstance(out, dict) and "_error" in out):   # errors are never cached
            self.cache[k] = out
            if self.cache_path:
                with open(self.cache_path, "a", encoding="utf-8") as f:
                    f.write(json.dumps({"k": k, "v": out}) + "\n")
        return out, False

    def _generate(self, prompt, schema, use_tools=False):
        raise NotImplementedError

    def available(self):
        return True


class OllamaLLM(LLM):
    def __init__(self, model="llama3.2:latest", host="http://localhost:11434", cache_path=None, num_predict=400):
        super().__init__(cache_path)
        self.model, self.host, self.num_predict = model, host, num_predict
        self.name = "ollama:" + model

    def available(self):
        try:
            urllib.request.urlopen(self.host + "/api/tags", timeout=3).read()
            return True
        except Exception:
            return False

    def _generate(self, prompt, schema, use_tools=False):
        body = {"model": self.model, "prompt": prompt, "stream": False, "format": schema,
                "options": {"temperature": 0, "num_predict": self.num_predict}}
        req = urllib.request.Request(self.host + "/api/generate", data=json.dumps(body).encode(),
                                     headers={"Content-Type": "application/json"})
        r = json.loads(urllib.request.urlopen(req, timeout=900).read())
        try:
            return json.loads(r["response"])
        except Exception:
            return {"_error": "non-json", "raw": r.get("response", "")[:500]}


def _import_anthropic():
    """The anthropic package, or the copy vendored in stage1/vendor (shipped with the app) when it is not installed."""
    try:
        import anthropic
        return anthropic
    except ImportError:
        vendor = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "stage1", "vendor")
        if os.path.isdir(vendor) and vendor not in sys.path:
            sys.path.append(vendor)
        import anthropic
        return anthropic


class OpenAICompat(LLM):
    def __init__(self, model, base_url, api_key="", cache_path=None):
        super().__init__(cache_path)
        self.model, self.base_url, self.api_key = model, base_url.rstrip("/"), api_key
        self.name = "openai-compat:" + model

    def _generate(self, prompt, schema, use_tools=False):
        body = {"model": self.model, "temperature": 0,
                "messages": [{"role": "system", "content": "Answer only with JSON matching the schema."},
                             {"role": "user", "content": prompt + "\n\nJSON schema:\n" + json.dumps(schema)}],
                "response_format": {"type": "json_object"}}
        req = urllib.request.Request(self.base_url + "/chat/completions", data=json.dumps(body).encode(),
                                     headers={"Content-Type": "application/json",
                                              "Authorization": "Bearer " + self.api_key})
        try:
            r = json.loads(urllib.request.urlopen(req, timeout=900).read())
        except Exception as e:                       # unreachable endpoint, HTTP error, bad answer: reported, never raised
            return {"_error": "endpoint error: %s" % str(e)[:200]}
        try:
            return json.loads(r["choices"][0]["message"]["content"])
        except Exception:
            return {"_error": "non-json"}


# The atlas families' known trigger shapes (atlas XII.4 wire patterns): the stand-in's answer, and always one of the
# search seeds so a first search never depends on the LLM proposal alone.
FAMILY_TEMPLATES = {"P01": ["write", "read"], "P02": ["write", "flush", "read"], "P06": ["write", "write", "write"],
                    "P08": ["aspm_idle", "read"], "P12": ["write", "power_cycle", "read"], "P13": ["reset", "identify"],
                    "P16": ["write", "read", "read"], "P19": ["aspm_idle", "identify"], "P22": ["write", "write", "read"],
                    "P23": ["write", "trim", "read"], "P24": ["write", "flush", "power_cycle", "read"]}


def family_template_scenario(family):
    return {"commands": [{"op": o} for o in FAMILY_TEMPLATES.get(family or "", ["write", "read"])],
            "timing": {"inter_cmd_us": 50, "burst_len": 16, "idle_gap_ms": 0, "qd": 8, "bs_kb": 4}, "power_state": "none"}


class StandInLLM(LLM):
    """Deterministic stand-in: reuses the stored solution if one is given, else builds the family template
    and cites the incident's key packets. Lets the whole pipeline run and be tested with no model."""
    name = "stand-in"

    def _generate(self, prompt, schema, use_tools=False):
        m = re.search(r"STORED_SOLUTION_JSON=(\{.*?\})\s*$", prompt, re.S | re.M)
        pk = [int(x) for x in re.findall(r"#(\d+)", prompt)][:6]
        if m:
            try:
                sol = json.loads(m.group(1))
                return {"cause": sol.get("cause", "stored"), "reasoning": "stored solution reused",
                        "commands": [c["op"] if isinstance(c, dict) else c for c in sol["commands"]],
                        "timing": sol["timing"], "power_state": sol.get("power_state", "none"),
                        "parameter_ranges": {}, "evidence_packets": pk, "reuses_stored_solution": True}
            except Exception:
                pass
        fam = re.search(r"pattern (P\d\d|E)", prompt)
        ops = FAMILY_TEMPLATES.get(fam.group(1) if fam else "", ["write", "read"])
        return {"cause": "template for family %s" % (fam.group(1) if fam else "?"), "reasoning": "no stored solution",
                "commands": ops, "timing": {"inter_cmd_us": 50, "burst_len": 16, "idle_gap_ms": 0, "qd": 8, "bs_kb": 4},
                "power_state": "none", "parameter_ranges": {"qd": [1, 64], "inter_cmd_us": [1, 1000]},
                "evidence_packets": pk, "reuses_stored_solution": False}


SYSTEM_EXTRACT = (
    "You are a senior SSD/PCIe validation engineer assisting an admin who decides how a field defect is reproduced "
    "and tested. You are given stage-1 isolation evidence (packet rows from a protocol-analyzer CSV) and retrieved "
    "knowledge (stored solutions, exemplars, lessons). Extract only what the admin needs to decide: be exact, cite "
    "packet numbers only from the evidence, never invent commands, timings or packets, and answer only through the "
    "JSON schema. Allowed commands: read, write, flush, trim, write_zeroes, reset, power_cycle, aspm_idle, identify, "
    "get_log, set_feature, abort. Never propose format, sanitize or firmware commands.")


def _strict(schema):
    """Structured output needs additionalProperties:false on every object (deep copy, never mutates the caller's)."""
    sc = json.loads(json.dumps(schema))

    def walk(o):
        if isinstance(o, dict):
            if o.get("type") == "object":
                o.setdefault("additionalProperties", False)
                if "properties" in o and "required" not in o:
                    o["required"] = list(o["properties"].keys())
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    walk(sc)
    return sc


HTTP_TRIES = 4            # attempts per call on the plain-HTTPS path (transient failures only)
HTTP_BACKOFF_S = 2.0      # pause before the 2nd try; doubles each time (2, 4, 8 s), capped at 30 s


class AnthropicLLM(LLM):
    """Claude through the Anthropic SDK (ANTHROPIC_API_KEY / ANTHROPIC_AUTH_TOKEN) or, without a key, through the
    local `claude` CLI login. Inference only: effort 'low', JSON-schema output, stable system prompt cached for 1 h.
    Default model claude-haiku-5-5 as requested (cheap extraction / reranking)."""

    def __init__(self, model="claude-haiku-5-5", effort="low", system=SYSTEM_EXTRACT, cache_path=None,
                 backend="auto", max_tokens=2000, timeout=240, cli="claude", tools=()):
        super().__init__(cache_path)
        self.model, self.effort, self.system, self.max_tokens, self.timeout, self.cli = model, effort, system, max_tokens, timeout, cli
        self.tools = tuple(t for t in (tools or ()) if t in ("web_search",))   # "LLM generates the baseline ... using tools (web search)"
        self.name = "anthropic:%s:%s" % (model, effort)
        self.usage = {"input_tokens": 0, "output_tokens": 0, "cache_read": 0, "cache_write": 0, "cost_usd": 0.0,
                      "errors": 0}
        if backend == "auto":
            if os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"):
                backend = "sdk"
            elif shutil.which(cli):
                backend = "cli"
            else:
                backend = None
        self.backend = backend
        self._client = None

    def available(self):
        if self.backend == "cli":
            return bool(shutil.which(self.cli))
        if self.backend == "sdk":
            try:
                _import_anthropic()
            except ImportError:
                return bool(os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"))   # plain HTTPS then
            return True
        if self.backend == "http":
            return bool(os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"))
        return False

    def _generate(self, prompt, schema, use_tools=False):
        schema = _strict(schema)
        if self.backend == "sdk":
            out = self._sdk(prompt, schema, use_tools)
            if isinstance(out, dict) and str(out.get("_error", "")).startswith(("connection:", "anthropic SDK not installed")):
                out = self._http(prompt, schema, use_tools)      # the installed SDK cannot talk: plain HTTPS does
            return out
        if self.backend == "http":
            return self._http(prompt, schema, use_tools)
        if self.backend == "cli":
            return self._cli(prompt, schema, use_tools)
        return {"_error": "no Anthropic backend"}

    def _http(self, prompt, schema, use_tools=False):
        """The Messages API over plain HTTPS (urllib), no SDK: the same request the sdk path makes. Key from
        ANTHROPIC_API_KEY (or ANTHROPIC_AUTH_TOKEN as a bearer token), endpoint from ANTHROPIC_BASE_URL."""
        import urllib.request
        import urllib.error
        key, tok = os.environ.get("ANTHROPIC_API_KEY"), os.environ.get("ANTHROPIC_AUTH_TOKEN")
        if not key and not tok:
            self.usage["errors"] += 1
            return {"_error": "no API key in the environment (ANTHROPIC_API_KEY)"}
        base = (os.environ.get("ANTHROPIC_BASE_URL") or "https://api.anthropic.com").rstrip("/")
        limit = self.answer_limit() if not use_tools else max(self.answer_limit(), 4000)
        body = {"model": self.model, "max_tokens": limit,
                "system": [{"type": "text", "text": self.system, "cache_control": {"type": "ephemeral", "ttl": "1h"}}],
                "messages": [{"role": "user", "content": prompt}],
                "output_config": {"effort": self.effort, "format": {"type": "json_schema", "schema": schema}}}
        if use_tools and "web_search" in self.tools:
            body["tools"] = [{"type": "web_search_20250305", "name": "web_search", "max_uses": 3}]
        headers = {"content-type": "application/json", "anthropic-version": "2023-06-01"}
        if key:
            headers["x-api-key"] = key
        else:
            headers["authorization"] = "Bearer " + tok
        req = urllib.request.Request(base + "/v1/messages", data=json.dumps(body).encode("utf-8"), headers=headers, method="POST")
        # one failed call never stops the work: transient failures (no connection, 408/429/5xx/529) are retried with a
        # growing pause (2, 4, 8 s; a Retry-After header wins); a bad key or a bad request (401/403/400/404) is not retried
        resp, last = None, ""
        for attempt in range(1, HTTP_TRIES + 1):
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as r:
                    resp = json.loads(r.read().decode("utf-8"))
                break
            except urllib.error.HTTPError as e:
                try:
                    msg = json.loads(e.read().decode("utf-8")).get("error", {}).get("message", "")
                except Exception:      # noqa: BLE001
                    msg = ""
                last = ("rate limited: %s" % msg) if e.code == 429 else ("HTTP %s: %s" % (e.code, msg))
                if e.code not in (408, 409, 425, 429, 500, 502, 503, 504, 529):
                    self.usage["errors"] += 1
                    return {"_error": last + " (not retried)"}
                wait = e.headers.get("Retry-After") if e.headers else None
            except (urllib.error.URLError, OSError) as e:
                last, wait = "connection: %s" % e, None
            self.usage["retries"] = self.usage.get("retries", 0) + 1
            if attempt < HTTP_TRIES:
                try:
                    pause = float(wait) if wait else HTTP_BACKOFF_S * (2 ** (attempt - 1))
                except ValueError:
                    pause = HTTP_BACKOFF_S * (2 ** (attempt - 1))
                time.sleep(min(pause, 30))
        if resp is None:
            self.usage["errors"] += 1
            return {"_error": "%s (after %d tries)" % (last, HTTP_TRIES)}
        u = resp.get("usage") or {}
        self.usage["input_tokens"] += u.get("input_tokens", 0)
        self.usage["output_tokens"] += u.get("output_tokens", 0)
        self.usage["cache_read"] += u.get("cache_read_input_tokens") or 0
        self.usage["cache_write"] += u.get("cache_creation_input_tokens") or 0
        if resp.get("stop_reason") == "refusal":
            self.usage["errors"] += 1
            return {"_error": "refusal"}
        if resp.get("stop_reason") == "max_tokens":
            self.usage["errors"] += 1
            return {"_error": "cut off at %d output tokens: the answer did not fit (max_tokens)" % limit}
        blocks = resp.get("content") or []
        texts = [b.get("text", "") for b in blocks if b.get("type") == "text"]
        text = texts[-1] if texts else ""
        self.usage["web_searches"] = self.usage.get("web_searches", 0) + sum(1 for b in blocks if b.get("type") == "server_tool_use")
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return {"_error": "non-json", "raw": text[:500]}

    def _sdk(self, prompt, schema, use_tools=False):
        try:
            anthropic = _import_anthropic()
        except ImportError as e:
            self.usage["errors"] += 1
            return {"_error": "anthropic SDK not installed: %s" % e}
        if self._client is None:
            # only the compression Python reads by itself: a machine's brotli can be older than the package expects, and
            # then every answer fails as "Connection error." although the network is fine (seen 2026-11-12)
            self._client = anthropic.Anthropic(timeout=self.timeout, default_headers={"Accept-Encoding": "gzip, deflate"})
        kw = {}
        if use_tools and "web_search" in self.tools:           # Anthropic server-side web search tool (no local code runs)
            kw["tools"] = [{"type": "web_search_20250305", "name": "web_search", "max_uses": 3}]
        try:
            limit = self.answer_limit() if not kw else max(self.answer_limit(), 4000)
            resp = self._client.messages.create(
                model=self.model, max_tokens=limit,
                system=[{"type": "text", "text": self.system, "cache_control": {"type": "ephemeral", "ttl": "1h"}}],
                messages=[{"role": "user", "content": prompt}],
                output_config={"effort": self.effort, "format": {"type": "json_schema", "schema": schema}}, **kw)
        except anthropic.RateLimitError as e:
            self.usage["errors"] += 1
            return {"_error": "rate limited: %s" % e.message}
        except anthropic.APIStatusError as e:
            self.usage["errors"] += 1
            return {"_error": "HTTP %s: %s" % (e.status_code, e.message)}
        except anthropic.APIConnectionError as e:
            self.usage["errors"] += 1
            c = e.__cause__                              # "Connection error." alone hides the reason
            return {"_error": "connection: %s%s" % (e, "" if c is None else " (cause: %s: %s)" % (type(c).__name__, str(c)[:160]))}
        u = resp.usage
        self.usage["input_tokens"] += u.input_tokens
        self.usage["output_tokens"] += u.output_tokens
        self.usage["cache_read"] += u.cache_read_input_tokens or 0
        self.usage["cache_write"] += u.cache_creation_input_tokens or 0
        if resp.stop_reason == "refusal":
            self.usage["errors"] += 1
            return {"_error": "refusal"}
        if resp.stop_reason == "max_tokens":
            self.usage["errors"] += 1
            return {"_error": "cut off at %d output tokens: the answer did not fit (max_tokens)" % limit}
        texts = [b.text for b in resp.content if b.type == "text"]
        text = texts[-1] if texts else ""                        # with tools the JSON answer is the last text block
        self.usage["web_searches"] = self.usage.get("web_searches", 0) + sum(1 for b in resp.content if getattr(b, "type", "") == "server_tool_use")
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return {"_error": "non-json", "raw": text[:500]}

    def _cli(self, prompt, schema, use_tools=False):
        tools = "WebSearch" if (use_tools and "web_search" in self.tools) else ""
        cmd = [self.cli, "-p", "--model", self.model, "--effort", self.effort, "--tools", tools, "--max-turns", "8" if tools else "3",
               "--output-format", "json", "--system-prompt", self.system, "--json-schema", json.dumps(schema)]
        if tools:
            cmd.append("--allowedTools=" + tools)             # non-interactive runs must allow-list the tool (single token: the flag is variadic)
        cmd.append(prompt)
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=self.timeout)
        except subprocess.TimeoutExpired:
            self.usage["errors"] += 1
            return {"_error": "cli timeout"}
        except OSError as e:
            self.usage["errors"] += 1
            return {"_error": "cli: %s" % e}
        if r.returncode != 0:
            self.usage["errors"] += 1
            return {"_error": "cli exit %d: stderr=%s stdout=%s" % (r.returncode, (r.stderr or "")[-200:], (r.stdout or "")[-300:])}
        try:
            d = json.loads(r.stdout)
        except json.JSONDecodeError:
            self.usage["errors"] += 1
            return {"_error": "cli non-json", "raw": r.stdout[-300:]}
        u = d.get("usage", {})
        self.usage["input_tokens"] += u.get("input_tokens", 0)
        self.usage["output_tokens"] += u.get("output_tokens", 0)
        self.usage["cache_read"] += u.get("cache_read_input_tokens", 0)
        self.usage["cache_write"] += u.get("cache_creation_input_tokens", 0)
        self.usage["cost_usd"] += d.get("total_cost_usd") or 0.0
        out = d.get("structured_output")
        if out is None:
            try:
                out = json.loads(d.get("result") or "")
            except (json.JSONDecodeError, TypeError):
                out = None
        if not isinstance(out, dict):
            self.usage["errors"] += 1
            return {"_error": "no structured output", "raw": str(d.get("result"))[:300]}
        return out


def pick_backend(prefer="ollama", model="llama3.2:latest", cache_path=None):
    """prefer: 'anthropic' (Haiku via SDK or claude CLI) | 'ollama' | 'standin'; falls back down the list."""
    if prefer == "anthropic":
        b = AnthropicLLM(model if model.startswith("claude") else "claude-haiku-5-5", cache_path=cache_path)
        if b.available():
            return b
        prefer = "ollama"
        model = "llama3.2:latest"
    if prefer == "ollama":
        b = OllamaLLM(model, cache_path=cache_path)
        if b.available():
            return b
    return StandInLLM(cache_path)


# ---------------------------------------------------------------- validation of LLM output
def check_output(out, allowed_packets):
    """Return (ok, problems, cleaned). Cleans ops/timing; rejects uncited or invented packets."""
    problems = []
    if not isinstance(out, dict) or "_error" in out:
        return False, ["not JSON"], None
    cmds = [str(c).lower().strip() for c in out.get("commands", [])]
    bad = [c for c in cmds if c not in ALLOWED_OPS]
    if bad:
        problems.append("unknown ops %s" % bad)
    cmds = [c for c in cmds if c in ALLOWED_OPS] or ["write", "read"]
    t = out.get("timing") or {}
    timing = {"inter_cmd_us": int(t.get("inter_cmd_us", 50) or 50), "burst_len": int(t.get("burst_len", 16) or 16),
              "idle_gap_ms": int(t.get("idle_gap_ms", 0) or 0), "qd": int(t.get("qd", 8) or 8), "bs_kb": int(t.get("bs_kb", 4) or 4)}
    for k, (lo, hi) in {"inter_cmd_us": (1, 5000), "burst_len": (1, 128), "idle_gap_ms": (0, 2000), "qd": (1, 256),
                        "bs_kb": (4, 1024)}.items():
        if not lo <= timing[k] <= hi:
            problems.append("timing %s out of range" % k)
            timing[k] = min(hi, max(lo, timing[k]))
    cited = [int(p) for p in out.get("evidence_packets", []) if str(p).lstrip("-").isdigit()]
    invented = [p for p in cited if allowed_packets and p not in allowed_packets]
    if invented:
        problems.append("cited packets not in evidence: %s" % invented[:5])
    cleaned = {"commands": [{"op": c} for c in cmds], "timing": timing,
               "power_state": str(out.get("power_state", "none")) if str(out.get("power_state", "none")) in
               ("none", "L1", "L1.2", "D3hot", "APST") else "none",
               "cause": str(out.get("cause", ""))[:200], "reasoning": str(out.get("reasoning", ""))[:600],
               "evidence_packets": [p for p in cited if p not in invented],
               "reuses_stored_solution": bool(out.get("reuses_stored_solution", False))}
    return (not invented), problems, cleaned
