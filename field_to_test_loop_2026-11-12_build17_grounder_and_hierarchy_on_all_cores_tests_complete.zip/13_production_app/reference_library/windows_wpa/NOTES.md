# Windows Performance Analyzer: what is known about its CSV export

State: **notes only**. There is no column list for this tool yet, so the application handles its files as files of an
unknown tool. This file says what the public pages give, what they do not give, and what must be brought from the
laptop that runs the tool so a column list can be built.

Prepared on 2026-11-12 from pages read on that day. Every statement below carries the address of the page it comes from
and one of these labels:

- **official**: Microsoft's documentation on learn.microsoft.com.
- **official (archived page)**: a Microsoft page under `previous-versions`, written for an older version of the tool.
- **Microsoft blog**: on a Microsoft address, but a blog post and not product documentation.
- **not official**: anybody else (blogs, forums, GitHub). Used only to show what a real file looks like.

Short form used below: `W/` stands for `https://learn.microsoft.com/en-us/windows-hardware/test/wpt/`.

## 1. The tool

- Windows Performance Analyzer (WPA) is part of the Windows Assessment and Deployment Kit (Windows ADK). It "creates
  graphs and data tables of Event Tracing for Windows (ETW) events that are recorded by Windows Performance Recorder
  (WPR), Xperf, or an assessment that is run in the Assessment Platform." (`W/windows-performance-analyzer`, official)
- What it reads is a trace file (`.etl`). The older command-line tool is still there: "In addition, support is
  maintained for the previous command-line tool, Xperf." (`W/`, official)
- Which version the owner's laptop has is not known. The layout of an exported file may differ between versions.

## 2. Three ways a table leaves the tool

### a) `wpaexporter.exe` with a profile: the only documented CSV export

Page: `W/exporter` (official).

- "You can use the WPA Exporter to export tables from a single trace and profile, optionally filtered to a specific
  time range, to a .csv (comma-separated values) file."
- The command, as the page gives it:
  `wpaexporter.exe [-i] traceFile.etl -profile profile.wpaProfile [-delimiter <char>] [-prefix <prefix>] [-outputfolder <folder>] [-range <start> <end>] [-marks <M1> <M2>] [-regionsxml <manifest> ...] [-region <region_name>] [-symbols] [-tti] [-h | /?]`
- The separator: "The character to use as the separator between values in the CSV. The default separator is a comma."
- The file names: "The output file names are automatically generated based on the table and preset names. The user may
  optionally specify a prefix (-prefix) and directory (-outputfolder)."
- The profile (the saved choice of tables and columns) is made in the WPA window: "In the menu, choose Profiles,
  Export…" and "View profiles are stored in .wpaprofile files and saved, by default, to the WPA Files folder under the
  user's Documents folder." (`W/view-profiles`, official)
- **The page does not show the file.** It says nothing about the header row, the units, the number format, quoting or
  the encoding.

### b) Copying from the WPA window

- The official list of keyboard shortcuts has "CTRL+C" as "Copy cell from data table". (`W/wpa-keyboard-shortcuts`,
  official). No current official page describes a CSV export of a table from the window.
- A Microsoft blog post (Raymond Chen, 2020-12-09) describes selecting everything with Ctrl+A and copying with Ctrl+C,
  and warns: "the format of the copied text is almost-but-not-quite CSV: If the text in a column contains a comma, the
  Ctrl+C command does not protect the comma with quotation marks.", "WPA inserts thousands separators into large
  numbers" and "Ctrl+C uses a comma followed by a space to separate columns."
  (`https://devblogs.microsoft.com/oldnewthing/20201209-00/?p=104530`, Microsoft blog)
- The older Xperf viewer had a menu for it: "The summary table provides a context menu with options for how to copy the
  current cell, the selected rows, or the full table to the clipboard and to export the selected rows, the displayed
  rows or the whole table to a text file that has comma-separated values."
  (`https://learn.microsoft.com/en-us/previous-versions/windows/desktop/xperf/summary-tables`, official (archived page))

### c) Text reports of the older `xperf` command

All official:

- "xperf -i input.etl -o output.txt -a <action_name> [action_parameters]" and "Xperf actions are trace processing
  components that collate event information to produce text reports." (`W/xperf-actions`)
- The dumper action: "This action produces an ANSI text file of the ETL trace log." (`W/dumper`)
- The disk action: "This action produces a text report that summarizes the metrics for disk I/O." (`W/diskio`)
- The boot action: "This action produces an XML report that summarizes the various metrics in boot." (`W/boot`)
- No official page shows the layout of the dumper or the disk report.

## 3. What a header looks like

### The one real exported file that was read (not official)

File: `https://raw.githubusercontent.com/bgeneto/windows-disk-trace-vis/main/Disk_Usage_Counts_by_IO_Type_Priority.csv.bz2`,
made by its author with `wpaexporter.exe -i boottrace.etl -profile DiskIO.wpaProfile -delimiter ;` from a Windows 11
boot trace. Its first line:

    IO Type;Priority;Process (Name);Init Time (s);Complete Time (s);IO Time (µs);Disk Service Time (µs);Size (B);Min Offset;Max Offset;QD/I - Queue Depth at Init Time;QD/C - Queue Depth at Complete Time;Disk;Count

Two of its rows:

    Read;Normal;System;1,079943800;1,080031000;87,200;87,200;512;0x0000000000000000;0x00000000000001FF;0;0;1;1
    Flush;Normal;System;1,718822100;1,720618000;1.795,900;1.205,600;0;0xFFFFFFFFFFFFFFFF;0xFFFFFFFFFFFFFFFF;1;1;1;1

What that one file shows (true for that file only):

- 14 columns and 172,630 data rows, one row per disk request.
- The separator is `;` because the author asked for it; the documented default is a comma.
- The unit stands in the header: `(s)` seconds, `(µs)` microseconds, `(B)` bytes. The micro sign is the character
  U+00B5.
- Numbers follow the regional settings of the laptop that exported: here a comma for decimals and a dot between
  thousands ("1.360,300" is 1360.3). Another source, from a laptop with other settings, shows the reverse with
  quotation marks: `Idle (0),23871651,"20,726,984.943082"`
  (`https://raw.githubusercontent.com/google/UIforETW/master/bin/CPUByCommandLine.py`, not official).
- Positions on the disk are written as `0x` and 16 hexadecimal digits.
- Lines end with carriage return and line feed; the text is UTF-8 without a byte-order mark; no cell is quoted.
- The file name is the table name and the preset name joined with underscores:
  `Disk_Usage_Counts_by_IO_Type_Priority.csv`.
- The header says `Process (Name)` where the WPA window calls the column `Process`. A name seen in the window is
  therefore not always the name in the exported header.

### Text reports of `xperf` (examples printed on web pages)

- Dumper, from a Microsoft blog of 2008: "The resulting file is an ANSI text file where each line is one record. Each
  record consists of a comma delimited set of fields. The first field of each line is the name (or type) of the
  record." and "The header lines are delimited by the 'BeginHeader' and 'EndHeader' lines." Example header line:
  `P-Start, TimeStamp, Process Name ( PID), ParentPID, SessionID, UniqueKey, UserSid, Command Line`
  (`https://learn.microsoft.com/en-us/archive/blogs/pigscanfly/so-just-what-is-in-a-trace-using-the-xperf-trace-dumper`,
  Microsoft blog)
- Disk report with `-summary -detail`, pasted into a blog of 2020:
  `IO Type, Start Time,   End Time,    IO Time,  Disk SrvT,    IO Size,  Byte Offset,  Pri, QD/I, QD/C, IBCB, IBCA, IACB,     Process Name ( PID), Disk, Filename`
  (`https://code4fun.me/2020/06/16/xperf/`, not official)

### Tables for which no exported header was seen

CPU Usage (Sampled), CPU Usage (Precise), File I/O, Generic Events, Regions of Interest and the boot phases. For these
only names from the WPA window or from saved profiles are known, and the case of `Process (Name)` above shows why such a
name cannot be taken as the exported header.

## 4. Which columns a Microsoft page defines

- **Disk Usage**, on `W/optimizing-performance-and-responsiveness-exercise-2` (official), for seven columns. Examples:
  "IO Type: Type of the I/O. The three possible I/O types are: read, write, and flush.", "Size: Size (in bytes) of the
  I/O.", "Disk Service time: Amount of time that it takes for the disk to service the I/O.", "IO Time: Amount of time
  that the I/O spent in the Windows I/O queue.", "Pri: Priority of the disk I/O. The three possible priority levels
  are: normal, low, and very low." The page also defines Process and Path Tree.
- **CPU Usage (Precise)**, on `W/optimizing-performance-and-responsiveness-exercise-3` (official): a table of columns
  with one sentence each, for example Count: "The number of context switches that are represented by the row. This is
  always 1 for individual rows." The page writes the names without spaces (`NewThreadId`, `Ready(s)`), which is not how
  saved profiles write them.
- **CPU Usage (Sampled)**, on the exercise-2 page (official): only "Thread ID: Identifier of the thread causing CPU
  usage" and "Stack: Call stack that highlights the code paths and functions that are causing CPU usage".
- **No official definition was found** for these columns of Disk Usage: `Init Time` and `Complete Time` (an archived
  page names "Initialization time" and "Completion time" only as items of a tooltip,
  `https://learn.microsoft.com/en-us/previous-versions/windows/desktop/xperf/disk-i-o-detail`), `Min Offset`,
  `Max Offset`, the two queue depth columns, `Disk` and `Count`. Nor for `Weight` of CPU Usage (Sampled), which the
  official page names without defining, nor for any column of File I/O, Generic Events, Regions of Interest and the
  boot phases. Community pages explain some of them, for example
  "QD/I – Queue Depth at Init Time – this measures how many I/Os were queued when the current I/O was requested"
  (`https://randomascii.wordpress.com/2012/11/21/the-lost-xperf-documentationdisk-usage/`, not official).

Two places where the sources disagree, to be settled with a real file:

- `IO Time`: the official page says time "in the Windows I/O queue"; the community page says "the elapsed time to
  perform the read or write as seen by the thread initiating the access." In the real file above it equals
  `Disk Service Time` in most rows.
- `Priority`: the official page names three levels; the real file above also has rows with `High`.

## 5. The assessments of the Windows ADK (boot, standby, hibernate)

- The Windows Assessment Console runs the assessments: "A GUI that you can use to group the assessments, create a job,
  run the job, and view and manage the job results."
  (`https://learn.microsoft.com/en-us/windows-hardware/test/assessments/`, official)
- Its results are XML, not CSV: "Assessments produce one or more XML files that contain individual results. AXE
  aggregates all of the assessment result files into the final job results file."
  (`https://learn.microsoft.com/en-us/previous-versions/windows/desktop/axe/axejobresults`, official (archived page))
- Where they are kept: "By default, the results from each job that you run are saved in the results library at
  %UserProfile%\Documents\Assessment Results."
  (`https://learn.microsoft.com/en-us/windows-hardware/test/assessments/compare-results`, official)
- No export of a results table to CSV or Excel is described on the official pages that were searched.
- The measurements have official definitions with their unit, for example Main Path Boot Duration: "For the Boot
  Performance assessment, this is the time, in seconds, to resume from the end of BIOS initialization until Windows is
  initialized. This does not include the Post On/Off Duration metric time." and Post On/Off Duration: "The time, in
  milliseconds, that Windows took to complete all startup tasks after the desktop appeared."
  (`https://learn.microsoft.com/en-us/windows-hardware/test/assessments/onoff-transition-performance`, official)
- An assessment also leaves trace files that WPA opens ("click the WPA in-depth analysis link in the Issues pane on the
  View Results page.", `W/wpa-step-by-step-guide`, official). Those can be exported by the routes of section 2.
- No real result file was seen, so the names inside the XML are not known.

## 6. What is not known

- The separator on the owner's laptop (comma by default; the one real file used `;` on request).
- The number format, which depends on the regional settings: decimal sign, sign between thousands, quotation marks.
- The exact header text, with units, of every table other than the one Disk Usage file above.
- Whether a profile with several tables writes several files. One user reports that only one file appeared
  (`https://learn.microsoft.com/en-us/answers/questions/1457753/wpaexporter-exe-only-exports-cpu-usages-by-process`,
  not official).
- Whether a header can hold the same name twice. Saved profiles found on GitHub hold some columns twice, for example
  `Time Since Last` once as a sum and once as a largest value (not official); whether both then stand under one name
  in the exported header has not been seen.
- What `IO Time` measures and why `Priority` can be `High` (section 4).
- The meaning of every column of File I/O, Generic Events, Regions of Interest and the boot phases.
- Whether the Windows Assessment Console can export or copy a results table at all.

## 7. What to bring from the laptop that runs the tool

Bring the files as the tool wrote them, not opened and saved again in another program: the first line, the separator
and the number format are exactly what has to be learned.

1. **The version.** In WPA: Help, About. Also the build of the installed Windows ADK. And which way the tables were
   exported: `wpaexporter.exe`, copy from the window, or `xperf -a`.
2. **One exported CSV file for each table that will be used**, complete with its first line: Disk Usage, File I/O,
   CPU Usage (Sampled), CPU Usage (Precise), Generic Events, Regions of Interest, and the boot phase table if one is
   used. A file of a short trace is enough; the header and a few hundred rows are what matters.
3. **The profile file** (`.wpaProfile`) that was given to `wpaexporter.exe`, or the name of the built-in profile.
4. **The file names exactly as written** by the export (a listing of the output folder).
5. **The regional format of that laptop**: the decimal sign and the sign between thousands that Windows is set to.
6. If `xperf` is used: one text file of `xperf -a dumper` and one of `xperf -a diskio -detail`, with the command line
   that made them.
7. If the Windows ADK assessments are used: the results folder of one boot run and one standby or hibernate run (by
   default `Documents\Assessment Results`), with the XML files inside it.
8. Where WPA shows a tooltip for a column of File I/O, Generic Events, Regions of Interest or the boot phases: a
   screenshot of it. These descriptions are not on the web.

With items 1 to 5 a `columns.json` for this tool can be written as `../README.md` describes: the header names from the
files, the meanings from the Microsoft pages of section 4 where they exist, and the rest marked as not documented.

## 8. What the application does with such a file today

It is read as a CSV file of an unknown tool: the Data Grounder searches the web first and then reads each column's name
and contents. The later stages of the application expect the five files of a Teledyne LeCroy export, so a WPA file does
not go further than that.
