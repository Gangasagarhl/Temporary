# Teledyne LeCroy PCIe Protocol Analysis: the CSV export and its columns

Prepared on 2026-11-12 for the Data Grounder of the Field-to-Test Loop application. This file is made by reference_library/build_reference.py from columns.json and export_notes.json: change those two files, not this one.

## The documents this was prepared from

| document | version | publisher | public address |
|---|---|---|---|
| Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual | PCIe Protocol Analysis version 13.42 | Teledyne LeCroy | https://cdn.teledynelecroy.com/files/manuals/pciegen5_summitz5_usermanual.pdf |
| PCI Express Protocol Analysis, Summit M64 Analyzer User Manual | PCIe Protocol Analysis software version 13.42 | Teledyne LeCroy | https://cdn.teledynelecroy.com/files/manuals/pciesummitm64analyzer_usermanual.pdf |
| Summit Exerciser Scripting Language Reference Manual | PCIe Protocol Analysis version 13.20 | Teledyne LeCroy | https://cdn.teledynelecroy.com/files/manuals/petrainerscriptmanual.pdf |
| Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual | PCIe Protocol Analysis version 13.20 | Teledyne LeCroy | https://cdn.teledynelecroy.com/files/manuals/petracervsemanual.pdf |
| Automation API for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual | PCIe Protocol Analysis version 13.42 | Teledyne LeCroy | https://cdn.teledynelecroy.com/files/manuals/pcieautomationmanual.pdf |
| NVM Express Base Specification | Revision 2.1, August 5th, 2024 | NVM Express, Inc. | https://nvmexpress.org/wp-content/uploads/NVM-Express-Base-Specification-Revision-2.1-2024.08.05-Ratified.pdf |
| NVM Express NVM Command Set Specification | Revision 1.1, August 5th, 2024 | NVM Express, Inc. | https://nvmexpress.org/wp-content/uploads/NVM-Express-NVM-Command-Set-Specification-Revision-1.1-2024.08.05-Ratified.pdf |
| NVM Express NVM Command Set Specification | Revision 1.3, July 31st, 2026 | NVM Express, Inc. | https://nvmexpress.org/wp-content/uploads/NVM-Express-NVM-Command-Set-Specification-Revision-1.3-Ratified-2026.07.31.pdf |

All of them are public. Teledyne LeCroy lists its manuals at https://www.teledynelecroy.com/protocolanalyzer/pci-express/resources/product-manuals and NVM Express its specifications at https://nvmexpress.org/specifications/ .

## What this document is, and why it was written

The Data Grounder of this application has to say what every column of an uploaded CSV file means, and where that meaning comes from. Asking a model about every column of every upload, with a web search each time, took hours for a file of a few hundred columns; the NVMe command file of a real export has 1,598 columns.

The export of Teledyne LeCroy's PCIe Protocol Analysis software uses a fixed set of column names. So their meanings were looked up once, from Teledyne LeCroy's own manuals and from the NVM Express specifications that the NVMe columns are taken from, and written down here. The Data Grounder reads this document first. It asks the model, and searches the web, only for names that are not in it.

This is not a copy of the manuals. Every entry gives a short meaning in plain words, then one line quoted from the source, with the document, its version, the section and the line, so that anyone can open the original and check. The documents themselves are not shipped with the application; their public addresses are in the table below.

## What the CSV export is and how it is made

A recording made with the analyzer is saved in Teledyne LeCroy's own format (a .pex file). The CSV file is an export of that recording, made in the PCIe Protocol Analysis software from the File menu.

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.1.15 Exporting a CATC Trace File, line 7636 of its text:

> By default, PCIe Protocol Analysis saves CATC Trace files in the .pex format. However, you can

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.1.15 Exporting a CATC Trace File, line 7637 of its text:

> export a CATC Trace to a file in any of the following other formats:

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.1.15 Exporting a CATC Trace File, line 7642 of its text:

> PCI Express packets will be exported to a script. All transaction levels, including supported SSD

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.1.15 Exporting a CATC Trace File, line 7643 of its text:

> decodes, can be exported to Text or CSV Text.

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.1.15 Exporting a CATC Trace File, line 7644 of its text:

> To export a CATC Trace file, select File > Export.

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), File menu, Export, Packets to CSV Text, line 6706 of its text:

> Saves the CATC Trace to a text file in Comma Separated Value (CSV)

## Only a part of the recording can be exported

The person exporting can choose a range, so a CSV file may hold only a part of the recording. Row numbers and times then start in the middle of the recording.

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.1.16 Export: To Text, line 7672 of its text:

> You can also select to Export only a portion of the Trace by setting the “From” and “To” menu

## Two export formats: legacy and new

The export window offers the older (legacy) format and the newer default format. The files this application reads are in the newer format: the time stamp is one number in seconds, a Time Delta column is present, the Data column shows an amount such as 4 B, and queue and command identifiers are decimal numbers.

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.1.16 Export: To Text, line 7659 of its text:

> Select Export => To Text, a window pops up that has a button to select legacy format, which would

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.1.16 Export: To Text, line 7688 of its text:

> Removes spaces from time stamp format, i.e. "0002 . 742 651 908"

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.1.16 Export: To Text, line 7690 of its text:

> Adds time delta value to the export

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.1.16 Export: To Text, line 7691 of its text:

> Modifies 'Data' field to show '4 B' or 1 KB instead of '1 dword’

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.1.16 Export: To Text, line 7692 of its text:

> QID / CID fields will be in decimal format rather than hexadecimal,

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.1.17 Export: Packets to CSV Text, line 7738 of its text:

> Or we can export Packets to CSV text using the new format, see Figure 6.31.

## The five levels of the export

The software decodes a recording at several levels, each built on the one below it. Each level is exported to its own CSV file, so one recording gives five files: packets, link transactions, split transactions, NVMe transactions and NVMe commands. A row of a higher level stands for several rows of the level below.

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.3.12 Decoding Traffic, line 9317 of its text:

> The PCIe Protocol Analysis has several decode levels:

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.3.12.1 Packet, line 9321 of its text:

> includes all TLP packets, DLLP packets, and all ordered sets.

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.3.12.2 Link, line 9383 of its text:

> is composed of TLP packets matched with a corresponding ACK or NAK

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.3.12.2 Link, line 9384 of its text:

> coming from the opposite direction.

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.3.12.3 Split, line 9391 of its text:

> Split level decode is composed of two Link transactions

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.3.12.5 NVMe Decoding, line 9469 of its text:

> To decode the NVMe protocol there are two levels available: NVMe Transaction level, which

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.3.12.5 NVMe Decoding, line 9470 of its text:

> decodes the individual NVMe transactions from the PCI Express protocol and NVMe Command

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.3.12.5 NVMe Decoding, line 9471 of its text:

> level, which gathers NVMe transactions into a single command.

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.3.12.5 NVMe Decoding, line 9475 of its text:

> NVMe, it will decode first the Packet Level, then the Link Transaction level, then the Split

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.3.12.5 NVMe Decoding, line 9476 of its text:

> Transaction Level and finally the NVMe Transaction decode level.

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.3.12.5 NVMe Decoding, line 9487 of its text:

> The NVMe Command level option displays NVMe Commands. The NVME commands decode all

## Columns can be added in the software

In the software's Spreadsheet View a person can add a field as a column. The manuals do not say whether the CSV export follows the columns of that view; the real exports received so far have the same header at each level. A file with a column that is not in this document is therefore possible, and the Data Grounder handles it: the new name goes to the model and the web.

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.3.11 Detail View and Spreadsheet View, line 9302 of its text:

> To put a Detail View header as a column in the Spreadsheet View, drag the header to a column

## Other CSV files the same software can write

The software writes two more kinds of CSV file that are not the five-level export: the Data Flow CSV file and the Link Tracker CSV file. Their columns are not in this document.

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.1.17.4 Data Flow CSV File: New Format, line 7861 of its text:

> Next we’ll chose the New Data format for the CSV file. See Figure 6.37.

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), Link Tracker, Exporting to CSV File, line 14197 of its text:

> To export trace file information to a CSV file, select the variables you want in the file and select the

From Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), Link Tracker, Exporting to CSV File, line 14213 of its text:

> The generated CSV file can be viewed in Excel.

## What the header row of a real export looks like

Measured from the customer's header index of 2026-11-03 (data/lecroy_real_headers.json in this application); these are counts made by this application's loader, not statements of a manual.

Columns per level in that export: packets 113, link transactions 39, split transactions 22, NVMe transactions 402, NVMe commands 1,598. Together they have 1,762 different column names, covered by the entries below.

A group of fields has one header cell for the group, and the header cells of its parts carry only the part's own name. The loader names such a part Group.Part (for example Mem.TLP Type), and this document uses those names.

The same name can occur several times in one header. The loader marks the second and later ones with #2, #3 and so on (for example AL#2). Which field such a column is depends on its place, so each of these entries names the column that comes before it.

Some header cells have no label; where the loader can name them from the first row (for example Errors and Warnings, whose cells read like '1 error(s)'), the entry says so.

Numbered families (for example RNG 0 to RNG 61 with their parts) have one entry, written with # in place of the number. A name that the export repeats many times (for example the 256 cells of Log Page Identifier Supported) also has one entry.

## How to read an entry

Each entry has the column name as the loader writes it, the meaning in plain words, where the name sits in the real export, and its source. There are three kinds of source.

document: the quoted line is in the named document, at the named line of its text (made with pdftotext -layout from the PDF as downloaded in November 2026). The Data Grounder uses these without asking the model.

model: no manual or specification states this field. The meaning was written from knowledge of PCI Express and NVMe when this document was prepared. The Data Grounder shows it as such: no source to check.

unknown: not found in any of the documents. The Data Grounder asks the model, and the web, for these.

Where the same name is a different field at another level, there are two entries, each marked with the levels it holds for.

## Things found while preparing this document

The export lists some NVMe fields under the header of a neighbouring group, because the group cell before them is the last one the software printed. Examples from the Identify Controller data: MDTS, CNTLID, VER, RTD3R and RTD3E appear as parts of CMIC; RRLS, CNTRLTYPE, FGUID and CRDT1 to CRDT3 as parts of CTRATT; ACL and AERL as parts of OACS. The entries explain the field itself and say so in their note.

Columns named Bit N or Bits N:M are matched to the specification's named bits by their position.

Some of the software's abbreviations differ from the specification's: HIS, NVMS, RRL, EG and UUIDL are the specification's HIDS, NSETS, RRLVLS, EGS and ULIST; SMBUSME is the bit the current specification calls TWPME; Optional Copy Formats Supported is the specification's Copy Descriptor Formats Supported; NVMe-Mi Data is the software's own name for a group.

The meaning of the same abbreviation can change with its place: AL is Access Latency after AF and Allocation Length after SECP.

Four packet-level columns are not described in any of the manuals: PMUX Metadata, Jammer Phase, CXL Pkt Type and CXL Pkt Subtype.

The manuals do not state the unit of Time Delta, or which earlier row it is measured from.

## Columns first seen at the packet level (packets.csv)

### `Marker`

Marker: the label, if any, that the engineer attached to this packet with Set Marker, so the packet can be found again; it also serves as a comment on that packet. Empty for packets without a marker.

- In the export: packets.csv, column 1.
- Source: Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.3.8.10 Set Marker, line 9075 of its text. Its words:

> A marker is a unique label for a packet that allows you to go to that packet and also serves as a

- Note: That an unmarked packet leaves the cell empty is inferred, not stated.

### `Packet`

Packet number: the position of this packet in the recording, counted in capture order. Other levels of the export refer to packets by this number.

- In the export: packets.csv, column 2, after `Marker`.
- Source: Automation API for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.42), ITrace::ExportToText (snippet of an exported text file), line 15197 of its text. Its words:

> Packet(1880) Downstream DLLP ACK AckNak_Seq_Num(3388) CRC 16(0xBB63)

- Note: The manual shows the number in the text export as Packet(n); it does not say whether the first packet is numbered 0 or 1.

### `Link Dir`

Link Direction: which way the packet travelled on the link, upstream (from the drive toward the host) or downstream (from the host toward the drive).

- In the export: packets.csv, column 3, after `Packet`; link.csv, column 2, after `Link Tra`; split.csv, column 2, after `Split Tra`; NVME_Transactions.csv, column 2, after `NVMe`; nvme_command.csv, column 2, after `NVMe Cmd`.
- Source: Automation API for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.42), IPEPacket::GetDirection, line 31150 of its text. Its words:

> Returns direction (upstream/downstream) of this packet.

- Note: The automation interface returns 0 for an upstream packet and 1 for a downstream packet; how the CSV spells the value is not documented. Side-band events (PERST#, WAKE#, CLKREQ#) appear once in each direction, and the viewer can swap upstream and downstream. Same idea in the other export files, where the name sits next to other unit columns.

### `Ord.Set Type`

Ordered Set Type: the kind of ordered set this row is (a short fixed group of link symbols), such as a training sequence TS1 or TS2, FTS, EIOS, SKIP, EIEOS or SDS. Empty for rows that are not ordered sets.

- In the export: packets.csv, column 4, after `Link Dir`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.7 Ordered Set specific set of members, line 1393 of its text. Its words:

> in.OrderedSetType: Contains the numeric encoding of the Ordered Set type.

- Note: The manual lists TS0, TS1, TS2, FTS, EIOS, SKIP, PATN, EIEOS, SDS and modified TS1/TS2 as the values.

### `DLLP Type`

Data Link Layer Packet Type: the kind of data link packet this row is, for example Ack, Nak, flow-control InitFC or UpdateFC (for posted, non-posted or completion traffic), power-management, vendor-specific or Data Link Feature. Empty for other rows.

- In the export: packets.csv, column 5, after `Ord.Set Type`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.2 DLLP-specific set of members, line 706 of its text. Its words:

> in.DLLPType: Contains the numeric encoding of the DLLP type.


### `TLP Type`

Transaction Layer Packet Type: the kind of transaction packet this row is, for example memory read or write (32-bit or 64-bit address), I/O, configuration read or write, message, completion with or without data, or an atomic operation.

- In the export: packets.csv, column 6, after `DLLP Type`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.3 TLP-specific set of members, line 827 of its text. Its words:

> in.TLPType: Contains the numeric encoding of the TLP type.


### `Link Event`

Link Event: a row that is not a packet but a change on the link or a side-band signal, for example Link Up, Link Down, or PERST#, WAKE# and CLKREQ# being asserted or released.

- In the export: packets.csv, column 7, after `TLP Type`.
- Source: Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), Decoding Side Band Signals, line 10589 of its text. Its words:

> These signals are displayed as Link Events.

- Note: The side-band list is quoted from the Z5 manual; the Link Up and Link Down events come from its Search, Go to, Link Event example and from the link conditions in the scripting-engine manual.

### `PSN`

Packet Sequence Number: the sequence number the data link layer gave this TLP. It counts up and wraps around, and Ack and Nak packets refer to it. A resent TLP keeps its number.

- In the export: packets.csv, column 8, after `Link Event`; link.csv, column 5, after `Link Tra Error`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Field values for all TLP types, line 918 of its text. Its words:

> in.PSN: Packet Sequence Number for this TLP as set by the Data Link Layer

- Note: Same meaning in link.csv. The scripting manual gives the range 0 - 4095 (twelve bits); a resent TLP keeping its number is from the PCI Express replay rules.

### `AckNak Seq Num`

Acknowledgement or Negative-acknowledgement Sequence Number: in an Ack or Nak data link packet, the TLP sequence number it refers to. An Ack confirms TLPs up to that number; a Nak asks for the TLPs after it to be sent again. Empty for other rows.

- In the export: packets.csv, column 9, after `PSN`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.2 DLLP-specific set of members, line 735 of its text. Its words:

> in.AckNak_SeqNum: Field value (valid only for Ack and Nak DLLPs), indicating which TLPs are affected by

- Note: The Ack versus Nak effect is from the PCI Express data link protocol, not from the manual line.

### `VC ID`

Virtual Channel ID: the virtual channel that a flow-control data link packet (InitFC or UpdateFC) refers to. Empty for other packets.

- In the export: packets.csv, column 10, after `AckNak Seq Num`; link.csv, column 16, after `Data`; split.csv, column 10, after `TC`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.2 DLLP-specific set of members, line 738 of its text. Its words:

> in.VC_ID: Virtual Channel ID (valid only for InitFC and UpdateFC DLLPs)

- Note: In link.csv and split.csv the same name sits next to TLP columns and holds the virtual channel of the transaction.

### `HdrScale`

Header Scale: the scaling factor for the header credit value (HdrFC) of an InitFC or UpdateFC flow-control packet. Used with scaled flow control; empty for other packets.

- In the export: packets.csv, column 11, after `VC ID`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.2 DLLP-specific set of members, line 743 of its text. Its words:

> in.HdrScale: Contains the scaling factor for headers of the indicated

- Note: From the PCI Express flow-control rules (not in the manual): 0 means scaling is not used, and 1, 2, 3 mean the credit count is multiplied by 1, 4, 16.

### `HdrFC`

Header Flow Control credits: the number of header credits a flow-control packet (InitFC or UpdateFC) gives for the traffic type named in the DLLP Type column (posted, non-posted or completion).

- In the export: packets.csv, column 12, after `HdrScale`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.2 DLLP-specific set of members, line 740 of its text. Its words:

> in.HdrFC: Credit value for headers of the type indicated by the DLLP type (valid only for InitFC and UpdateFC


### `DataScale`

Data Scale: the scaling factor for the data credit value (DataFC) of an InitFC or UpdateFC flow-control packet. Used with scaled flow control; empty for other packets.

- In the export: packets.csv, column 13, after `HdrFC`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.2 DLLP-specific set of members, line 748 of its text. Its words:

> in.DataScale: Contains the scaling factor for data payload of the indicated type

- Note: From the PCI Express flow-control rules (not in the manual): 0 means scaling is not used, and 1, 2, 3 mean the credit count is multiplied by 1, 4, 16.

### `DataFC`

Data Flow Control credits: the number of payload-data credits a flow-control packet (InitFC or UpdateFC) gives for the traffic type named in the DLLP Type column. One credit covers 16 bytes of payload.

- In the export: packets.csv, column 14, after `DataScale`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.2 DLLP-specific set of members, line 745 of its text. Its words:

> in.DataFC: Credit value for payload data of the type indicated by the DLLP type (valid only for InitFC and

- Note: The 16 bytes per credit comes from the PCI Express flow-control rules, not from the manual line.

### `Feature Ack`

Feature Acknowledge: flag in a Data Link Feature packet; set when the sender confirms it has received the feature list of the other end. Empty for other rows.

- In the export: packets.csv, column 15, after `DataFC`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.2 DLLP-specific set of members, line 752 of its text. Its words:

> in.FeatureAck: Data Link Feature DLLP related, Feature Ack flag

- Note: What the set flag confirms is from the PCI Express data link feature exchange, not from the manual line.

### `Feature Support`

Feature Supported: bit field in a Data Link Feature packet listing the data link features the sending port supports, and/or their attribute values. Bit 0 stands for Scaled Flow Control; other bits are reserved.

- In the export: packets.csv, column 16, after `Feature Ack`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.2 DLLP-specific set of members, line 754 of its text. Its words:

> in.FeatureSupport: Data Link Feature DLLP related, indicates the Data Link Features supported and/or attribute

- Note: Bit 0 = Scaled Flow Control comes from the Summit M64 manual, Table 7.2: Data Link Feature Supported Bit Definition.

### `TC`

Traffic Class: the 3-bit priority class (0 to 7) of the TLP, set by the sender. The link maps each class to a virtual channel.

- In the export: packets.csv, column 17, after `Feature Support`; split.csv, column 9, after `Tag`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), 2.1.1 Packet = TLP, line 502 of its text. Its words:

> Traffic Class: bits 6:4 of byte 1 in the

- Note: In split.csv the same name holds the traffic class of the request. The class-to-channel mapping is from the PCI Express rules, not from the manual line.

### `LN`

Lightweight Notification: bit in a memory request header (non-flit mode only); 1 means the request uses the Lightweight Notification protocol, 0 means it does not.

- In the export: packets.csv, column 18, after `TC`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), 2.1.1 Packet = TLP, line 504 of its text. Its words:

> Lightweight Notification

- Note: The table gives Enable = 1 and Disable = 0 and marks the field as present only in non-flit mode.

### `TH`

TLP Processing Hints: bit in a request header; 1 means the TLP carries processing hints for the receiver. Empty for packets without such a header bit.

- In the export: packets.csv, column 19, after `LN`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Field values for all TLP types, line 936 of its text. Its words:

> in.TH: TLP Processing Hints bit value

- Note: The meaning of 1 is from the PCI Express header definition, not from the manual line.

### `NW`

No Write: flag in an address-translation request (non-flit mode; carried in an extra header word in flit mode). 1 means the requester asks only for read permission, not write.

- In the export: packets.csv, column 20, after `TH`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Field values dependent upon TLP type: For Memory TLPs only, line 1011 of its text. Its words:

> in.NW: No Write flag in Translation Requests (Non-Flit mode), in OHC-A1 (Flit mode)

- Note: The meaning of 1 (read-only translation) is from the PCI Express address translation rules, not from the manual line.

### `TD`

TLP Digest: header bit; 1 means a digest (a single extra word, the end-to-end CRC) is present at the end of the TLP.

- In the export: packets.csv, column 21, after `NW`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), 2.1.1 Packet = TLP, line 509 of its text. Its words:

> 1 indicates presence of TLP digest in

- Note: Documented as present only in non-flit mode. Pairs with the ECRC column.

### `EP`

Poisoned: the EP bit of the TLP header (byte 2, bit 6); 1 means the TLP is marked poisoned, its data is known to be bad.

- In the export: packets.csv, column 22, after `TD`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), 2.1.1 Packet = TLP, line 512 of its text. Its words:

> Bit 6 of byte 2 in the TLP header:


### `Attributes`

Attributes: the TLP attribute bits taken together, Snoop (no-snoop), Ordering (relaxed ordering) and ID-based ordering.

- In the export: packets.csv, column 23, after `EP`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Field values for all TLP types, line 933 of its text. Its words:

> in.Attributes: Attributes field value [all three bits (Snoop, Ordering, and IDBasedOrdering)]

- Note: Scripting manual: Snoop 1 means hardware enforced cache coherency is not expected; Ordering 1 means the relaxed ordering model.

### `AT`

Address Type: 2-bit field of a memory request telling whether the address is untranslated, a translation request or already translated (address translation services).

- In the export: packets.csv, column 24, after `Attributes`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), 2.1.1 Packet = TLP, line 524 of its text. Its words:

> Address Type: Bits 2-3 of Byte 2 in the

- Note: Values 0 to 3; the table names untranslated, translation request and translated.

### `Length`

Length: size of the data payload of the TLP, in doublewords (4 bytes each). For a read request it is the amount asked for.

- In the export: packets.csv, column 25, after `AT`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), 2.1.1 Packet = TLP, line 535 of its text. Its words:

> Length of data payload in DWORDs.

- Note: In the TLP header a length field of 0 stands for 1024 doublewords (stated in the table).

### `RequesterID`

Requester ID: bus, device and function number of the function that sent the request, shown as one value. A completion carries the requester ID of the request it answers.

- In the export: packets.csv, column 26, after `Length`; link.csv, column 10, after `Mem.Length`; split.csv, column 6, after `Mem.TLP Type`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Field values for all TLP types, line 920 of its text. Its words:

> in. RequesterId: Requester ID value (Bus, Device and Function Number fields combined)

- Note: Same meaning in link.csv and split.csv. The completion remark is from the PCI Express rules.

### `Tag`

Tag: number the requester gives a request so its completion can be matched; the completion repeats it. Together with the requester ID it identifies the outstanding request.

- In the export: packets.csv, column 27, after `RequesterID`; link.csv, column 11, after `RequesterID`; split.csv, column 8, after `CompleterID`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), 2.1.1 Packet = TLP, line 552 of its text. Its words:

> Byte 10 for Completion TLP

- Note: Scripting manual: byte 6 of the header for memory, I/O and configuration requests, byte 10 for completions (up to 10 bits). Same meaning in link.csv and split.csv.

### `CompleterID`

Completer ID: bus, device and function number of the function that sent the completion, shown as one value. Only in completion TLPs.

- In the export: packets.csv, column 28, after `Tag`; link.csv, column 22, after `Cpl`; split.csv, column 7, after `RequesterID`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), For Completion TLPs only, line 984 of its text. Its words:

> in.CompleterId: Completer ID value (Bus, Device and Function Number fields combined)

- Note: Same meaning in link.csv and split.csv.

### `Address`

Address: the address a memory or I/O request TLP is aimed at (32-bit, or 64-bit for 64-bit requests). Empty for packets that carry no address, such as completions.

- In the export: packets.csv, column 29, after `CompleterID`; link.csv, column 12, after `Tag`; split.csv, column 11, after `VC ID`.
- Holds for the packet level and the link transaction level and the split transaction level only: the same name is another field at the other levels.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Field values dependent upon TLP type, line 967 of its text. Its words:

> in.Address: 32-bit Address value for IO, Configuration, and Mem-32 requests

- Note: The manual line also lists Configuration requests, but the export shows those with the DeviceID and Register columns instead. The manual splits 64-bit addresses into AddressLo and AddressHi; whether the CSV joins them is not documented. In NVME_Transactions.csv the same name is the address of the NVMe transaction.

### `DeviceID`

Device ID: bus, device and function number of the function a configuration request (or a message routed by ID) is aimed at, shown as one value. Not the vendor's device identifier.

- In the export: packets.csv, column 30, after `Address`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Field values dependent upon TLP type, line 975 of its text. Its words:

> in.DeviceId: Requester ID value (Bus, Device and Function Number fields combined) for Configuration

- Note: The manual line calls it a Requester ID value, but the scripting manual says it is used only when a message is routed by ID, and the export example shows it next to RequesterID as a separate target field.

### `Register`

Register: the address of the configuration-space register that a configuration read or write aims at (register number and extended register number combined); doubleword aligned.

- In the export: packets.csv, column 31, after `DeviceID`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Field values dependent upon TLP type, line 978 of its text. Its words:

> in.Register: Register address (Register Number and Extended Register Number combined) for Configuration


### `1st BE`

First doubleword Byte Enables: four bits telling which bytes of the first 4-byte word of the payload are used (1 = byte used). Not present in completions and messages.

- In the export: packets.csv, column 32, after `Register`; link.csv, column 13, after `Address`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Field values dependent upon TLP type, line 961 of its text. Its words:

> in.FirstDwBe: Byte Enable bits for the first DW of the payload (all TLPs except Completions and

- Note: Same meaning in link.csv. The meaning of 1 is from the PCI Express byte-enable rules.

### `Last BE`

Last doubleword Byte Enables: four bits telling which bytes of the last 4-byte word of the payload are used (1 = byte used). Not present in completions and messages.

- In the export: packets.csv, column 33, after `1st BE`; link.csv, column 14, after `1st BE`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Field values dependent upon TLP type, line 964 of its text. Its words:

> in.LastDwBe: Byte Enable bits for the last DW of the payload (all TLPs except Completions and

- Note: Same meaning in link.csv. The meaning of 1 is from the PCI Express byte-enable rules.

### `Cpl Status`

Completion Status: the outcome of the request, carried in the completion: successful, unsupported request, configuration retry or completer abort. Empty for non-completion packets.

- In the export: packets.csv, column 34, after `Last BE`; link.csv, column 23, after `CompleterID`; split.csv, column 12, after `Address`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), For Completion TLPs only, line 987 of its text. Its words:

> in.ComplStatus: Completion Status field value

- Note: The four outcome names are from the PCI Express completion status codes (the export example shows Status(UR)); the manual line gives only the field name. Same meaning in link.csv and split.csv.

### `Byte Cnt`

Byte Count: the remaining number of bytes of the request still to be delivered, counted from the start of this completion's data. Only in completion TLPs.

- In the export: packets.csv, column 35, after `Cpl Status`; link.csv, column 25, after `BCM`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), For Completion TLPs only, line 991 of its text. Its words:

> in.ByteCount: Remaining Byte Count field value

- Note: Same meaning in link.csv. A later column in packets.csv named Byte Count (SMBus section) is a different field.

### `BCM`

Byte Count Modified: bit in a completion header; 1 means a PCI-X bridge changed the byte count. Always 0 on native PCI Express links.

- In the export: packets.csv, column 36, after `Byte Cnt`; link.csv, column 24, after `Cpl Status`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), For Completion TLPs only, line 989 of its text. Its words:

> in.BCM: Byte Count Modified bit value

- Note: The PCI-X remark is from the PCI Express definition, not from the manual line.

### `Lwr Addr`

Lower Address: the low bits of the address of the first byte of data in this completion, so the requester can place the data. Only in completion TLPs.

- In the export: packets.csv, column 37, after `BCM`; link.csv, column 26, after `Byte Cnt`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), For Completion TLPs only, line 993 of its text. Its words:

> in.LowerAddr: Lower Address for starting byte of completion field value

- Note: Same meaning in link.csv.

### `Msg Routing`

Message Routing: how a message TLP is routed: to the Root Complex, by address, by ID, broadcast from the Root Complex, local to the link, or gathered to the Root Complex.

- In the export: packets.csv, column 38, after `Lwr Addr`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), For Message TLPs only, line 1004 of its text. Its words:

> in.MessageRoute: Message Routing field value (from the TLP Type field)

- Note: The six routing names are from the scripting manual's message TLP type list (MsgRtoRC, MsgRbyAddr, MsgRbyID, MsgBfromRC, MsgLocal, MsgGRtoRC) expanded in plain words.

### `Message Code`

Message Code: the code that names the kind of message in a message TLP, for example power-management, interrupt, error or vendor-defined messages. Empty for other packets.

- In the export: packets.csv, column 39, after `Msg Routing`; link.csv, column 30, after `Msg.Msg Routing`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), For Message TLPs only, line 998 of its text. Its words:

> in.MessageCode: Message Code field value

- Note: Same meaning in link.csv.

### `TS Link`

Training Sequence Link Number: the link number advertised in a training sequence (TS1 or TS2), 0 to 255 or PAD; the analyzer gives one value per lane.

- In the export: packets.csv, column 40, after `Message Code`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.7 Ordered Set specific set of members, line 1419 of its text. Its words:

> in.TS_LinkNumberList: Contains the Link Number parameter values for all lanes

- Note: Scripting manual: Link Number within component, 0 - 255 or PAD. Whether the CSV cell shows one value or the per-lane list is not documented.

### `TS Lane`

Training Sequence Lane Number: the lane number advertised in a training sequence (TS1 or TS2), 0 to 31 or PAD; the analyzer gives one value per lane.

- In the export: packets.csv, column 41, after `TS Link`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.7 Ordered Set specific set of members, line 1421 of its text. Its words:

> in.TS_LaneNumberList: Contains the Lane Number parameter values for all lanes

- Note: Scripting manual: Lane Number within Port, 0 - 31 or PAD. Whether the CSV cell shows one value or the per-lane list is not documented.

### `N_FTS`

Number of Fast Training Sequences: how many fast training ordered sets the receiver needs to get reliable bit and symbol lock when leaving the low-power L0s state. Value in a training sequence, 0 to 255.

- In the export: packets.csv, column 42, after `TS Lane`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), 2.1.7.1 SetType = TS1, TS2, line 3948 of its text. Its words:

> The number of fast training ordered sets

- Note: The L0s remark is from the PCI Express definition of N_FTS, not from the manual line.

### `Training Control`

Training Control: bit flags in a training sequence that ask the other end for hot reset, disable link, loopback or disable scrambling.

- In the export: packets.csv, column 43, after `N_FTS`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.7 Ordered Set specific set of members, line 1429 of its text. Its words:

> in.TS_TrainingControlList: Contains the Training Control bitmap parameter values for all lanes

- Note: The bit order (HotReset, DisableLink, Loopback, DisableScrambling) is from the scripting manual, 2.1.7.1 SetType = TS1, TS2.

### `TS Data Rate`

Training Sequence Data Rate: the data-rate field of a training sequence; its bits advertise the supported link speeds (2.5, 5.0, 8.0, 16 GT/s and higher) plus a speed-change request bit.

- In the export: packets.csv, column 44, after `Training Control`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.7 Ordered Set specific set of members, line 1433 of its text. Its words:

> in.TS_DataRateList: Contains the Data Rate parameter values for all lanes

- Note: Scripting manual: a value of 0x9E sets all the speed bits (2.5G, 5.0G, 8.0G and 16G) as well as the Speed Change bit.

### `TS Gen3 Eq Control`

Training Sequence Equalization Control: the equalization-control value in a TS1 or TS2 at 8 GT/s and faster (Gen 3 and later), used while the two ends tune their transmitters.

- In the export: packets.csv, column 45, after `TS Data Rate`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.7 Ordered Set specific set of members, line 1443 of its text. Its words:

> in.TS_EqControlList: Contains the Equalizer Control parameter values for all lanes

- Note: Manual: valid only for Gen 3, 4 and 5 TS1 and TS2.

### `TS Gen3 Pre-Cursor`

Training Sequence Pre-Cursor: the pre-cursor transmitter-equalization value in a TS1 or TS2 at 8 GT/s and faster (Gen 3 and later), used during link equalization.

- In the export: packets.csv, column 46, after `TS Gen3 Eq Control`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.7 Ordered Set specific set of members, line 1437 of its text. Its words:

> in.TS_PreCursorList: Contains the Pre-Cursor parameter values for all lanes

- Note: Manual: valid only for Gen 3, 4 and 5 TS1 and TS2.

### `TS Gen3 Cursor`

Training Sequence Cursor: the cursor transmitter-equalization value in a TS1 or TS2 at 8 GT/s and faster (Gen 3 and later), used during link equalization.

- In the export: packets.csv, column 47, after `TS Gen3 Pre-Cursor`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.7 Ordered Set specific set of members, line 1439 of its text. Its words:

> in.TS_CursorList: Contains the Cursor parameter values for all lanes

- Note: Manual: valid only for Gen 3, 4 and 5 TS1 and TS2.

### `TS Gen3 Post-Cursor`

Training Sequence Post-Cursor: the post-cursor transmitter-equalization value in a TS1 or TS2 at 8 GT/s and faster (Gen 3 and later), used during link equalization.

- In the export: packets.csv, column 48, after `TS Gen3 Cursor`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.7 Ordered Set specific set of members, line 1441 of its text. Its words:

> in.TS_PostCursorList: Contains the Post-Cursor parameter values for all lanes

- Note: Manual: valid only for Gen 3, 4 and 5 TS1 and TS2.

### `PMUX Channel ID`

Protocol Multiplexing Channel ID: number of the channel of a multiplexed protocol that a Protocol Multiplexing (PMUX) packet belongs to. Empty for ordinary packets.

- In the export: packets.csv, column 49, after `TS Gen3 Post-Cursor`.
- Source: none. No document that was read states this field; the meaning was written from knowledge of the protocol when this document was prepared.
- Note: The Z5 manual shows 'PMUX Channel ID (3)' as an item that can be searched for in a trace, but gives no definition. Not used by an NVMe drive on plain PCI Express.

### `PMUX Metadata`

Not found in the documents that were read. The Data Grounder asks the model and the web for this column.

- In the export: packets.csv, column 50, after `PMUX Channel ID`.
- Source: none.
- Note: The manuals only mention PMUX packets and their Channel ID (Z5 manual 6.3.12.20, 6.5.5.2; automation interface packet type PMUX); no line describes a Metadata field and I could not tell what it holds.

### `Snoop`

Snoop Latency: the snoop part of a Latency Tolerance Reporting message, which tells the host how long the device can wait for snooped memory accesses. The next three columns hold its requirement bit, scale and value.

- In the export: packets.csv, column 51, after `PMUX Metadata`; link.csv, column 36, after `No-Snoop Value`.
- Source: none. No document that was read states this field; the meaning was written from knowledge of the protocol when this document was prepared.
- Note: Not in the manuals. Read from the column neighbours (Requirement, Scale, Value) and the PCI Express Latency Tolerance Reporting message. The cell of this column itself may be empty. Not the TLP No-Snoop attribute bit (that is inside Attributes).

### `Requirement (Snoop)`

Requirement bit of the Snoop Latency in a Latency Tolerance Reporting message: 1 means the device has a snoop latency requirement, 0 means it has none.

- In the export: packets.csv, column 52, after `Snoop`.
- Source: none. No document that was read states this field; the meaning was written from knowledge of the protocol when this document was prepared.
- Note: Not in the manuals; from the PCI Express Latency Tolerance Reporting message format.

### `Scale (Snoop)`

Scale of the Snoop Latency in a Latency Tolerance Reporting message: the unit (1 ns, 32 ns, 1,024 ns, 32,768 ns, 1,048,576 ns or 33,554,432 ns) that the value is multiplied by.

- In the export: packets.csv, column 53, after `Requirement (Snoop)`.
- Source: none. No document that was read states this field; the meaning was written from knowledge of the protocol when this document was prepared.
- Note: Not in the manuals; from the PCI Express Latency Tolerance Reporting message format. Codes 0 to 5 select the units in the order listed.

### `Value (Snoop)`

Value of the Snoop Latency in a Latency Tolerance Reporting message: a number from 0 to 1023 that, multiplied by the scale, gives the longest snoop delay the device accepts.

- In the export: packets.csv, column 54, after `Scale (Snoop)`.
- Source: none. No document that was read states this field; the meaning was written from knowledge of the protocol when this document was prepared.
- Note: Not in the manuals; from the PCI Express Latency Tolerance Reporting message format.

### `No-Snoop`

No-Snoop Latency: the no-snoop part of a Latency Tolerance Reporting message, which tells the host how long the device can wait for memory accesses that need no snooping. The next three columns hold its requirement bit, scale and value.

- In the export: packets.csv, column 55, after `Value (Snoop)`; link.csv, column 32, after `Implicit ACK`.
- Source: none. No document that was read states this field; the meaning was written from knowledge of the protocol when this document was prepared.
- Note: Not in the manuals. Read from the column neighbours and the PCI Express Latency Tolerance Reporting message. The cell of this column itself may be empty.

### `Requirement (No-Snoop)`

Requirement bit of the No-Snoop Latency in a Latency Tolerance Reporting message: 1 means the device has a no-snoop latency requirement, 0 means it has none.

- In the export: packets.csv, column 56, after `No-Snoop`.
- Source: none. No document that was read states this field; the meaning was written from knowledge of the protocol when this document was prepared.
- Note: Not in the manuals; from the PCI Express Latency Tolerance Reporting message format.

### `Scale (No-Snoop)`

Scale of the No-Snoop Latency in a Latency Tolerance Reporting message: the unit (1 ns up to 33,554,432 ns, in steps of 32 times) that the value is multiplied by.

- In the export: packets.csv, column 57, after `Requirement (No-Snoop)`.
- Source: none. No document that was read states this field; the meaning was written from knowledge of the protocol when this document was prepared.
- Note: Not in the manuals; from the PCI Express Latency Tolerance Reporting message format.

### `Value (No-Snoop)`

Value of the No-Snoop Latency in a Latency Tolerance Reporting message: a number from 0 to 1023 that, multiplied by the scale, gives the longest delay the device accepts.

- In the export: packets.csv, column 58, after `Scale (No-Snoop)`.
- Source: none. No document that was read states this field; the meaning was written from knowledge of the protocol when this document was prepared.
- Note: Not in the manuals; from the PCI Express Latency Tolerance Reporting message format.

### `PTM Master Time[63:32]`

Precision Time Measurement Master Time, upper half: bits 63 to 32 of the 64-bit master clock value that a PTM Response message carries. Empty for other packets.

- In the export: packets.csv, column 59, after `Value (No-Snoop)`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), 2.1.1.6.1 For PTM Response message, line 1324 of its text. Its words:

> Bits 63:32 of the PTM Master

- Note: Together with the lower half it forms the master time. The unit is nanoseconds in the PCI Express definition (the Z5 exerciser keeps master time in 4 ns steps); the manual line does not state it.

### `PTM Master Time[31:0]`

Precision Time Measurement Master Time, lower half: bits 31 to 0 of the 64-bit master clock value that a PTM Response message carries. Empty for other packets.

- In the export: packets.csv, column 60, after `PTM Master Time[63:32]`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), 2.1.1.6.1 For PTM Response message, line 1326 of its text. Its words:

> Bits 31:0 of the PTM Master Time

- Note: Together with the upper half it forms the master time. The unit is nanoseconds in the PCI Express definition; the manual line does not state it.

### `PTM Propagation Delay`

Precision Time Measurement Propagation Delay: the delay value of a PTM ResponseD message; the requester combines it with the master time to align its own clock.

- In the export: packets.csv, column 61, after `PTM Master Time[31:0]`.
- Source: Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 4.6.7.5 Enable Precision Time Management (PTM), line 4611 of its text. Its words:

> The Z5 maintains the Master Time in 4ns increments, and will generate the Propagation Delay and

- Note: The unit is nanoseconds in the PCI Express definition; neither manual line states it. The scripting manual lists PTM_PropagationDelay as a field of the PTM Response message.

### `ARP Command`

ARP Command: the SMBus Address Resolution Protocol command in this row, for example Prepare to ARP, Reset Device, Get UDID, Assign Address or Notify ARP Master. UDID is the device's unique identifier. Empty for other rows.

- In the export: packets.csv, column 62, after `PTM Propagation Delay`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), SMBus ARP Commands, line 1292 of its text. Its words:

> in.ARPCommandCode: Current SMBus ARP command code :

- Note: General and directed forms exist for Reset Device and Get UDID. Rows come from the SMBus side channel, not from the PCI Express link.

### `Slave Address`

Slave Address: the 7-bit SMBus address of the device that the bus master wants to talk to. Only in SMBus rows.

- In the export: packets.csv, column 63, after `ARP Command`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.5 SMBus-specific set of members, line 1263 of its text. Its words:

> in.SlaveAddress: The 7-bit slave address that master wants to address on the bus.


### `Target Address`

Target Address: the slave address named inside a directed SMBus ARP command (Get UDID directed or Reset Device directed), the device the command is aimed at.

- In the export: packets.csv, column 64, after `Slave Address`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), SMBus ARP Commands, line 1356 of its text. Its words:

> in.TargetedSlaveAddress : Targeted Slave Address field from Get UDID (directed) or Reset device ARP


### `Device Slave Address`

Device Slave Address: the slave address field carried in a directed Get UDID SMBus ARP command.

- In the export: packets.csv, column 65, after `Target Address`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), SMBus ARP Commands, line 1359 of its text. Its words:

> in.DeviceSlaveAddress : Device Slave Address field from Get UDID (directed) ARP command.


### `Assign Address`

Assign Address: the new SMBus address that an Assign Address ARP command gives to a device.

- In the export: packets.csv, column 66, after `Device Slave Address`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), SMBus ARP Commands, line 1355 of its text. Its words:

> Assigned address field form Assign Address ARP command.

- Note: The source line has the typing mistake 'form' for 'from'.

### `Read`

Read: marks an SMBus transfer whose R/W bit is read, where the master asks for data. Paired with the Write column.

- In the export: packets.csv, column 67, after `Assign Address`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.5 SMBus-specific set of members, line 1265 of its text. Its words:

> in.Wr: The direction of the data transfer (R/W#); a ZERO indicates a transmission (WRITE) while a ONE

- Note: The manual describes one direction bit (0 write, 1 read); how the CSV fills the two columns Read and Write is not documented.

### `Write`

Write: marks an SMBus transfer whose R/W bit is write, where the master sends data. Paired with the Read column.

- In the export: packets.csv, column 68, after `Read`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.5 SMBus-specific set of members, line 1265 of its text. Its words:

> in.Wr: The direction of the data transfer (R/W#); a ZERO indicates a transmission (WRITE) while a ONE

- Note: The manual describes one direction bit (0 write, 1 read); how the CSV fills the two columns Read and Write is not documented.

### `Byte Count`

Byte Count: the length field of an SMBus message, used by MCTP messages and by the Get UDID and Assign Address ARP commands. Not the completion Byte Cnt.

- In the export: packets.csv, column 69, after `Write`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.5 SMBus-specific set of members, line 1270 of its text. Its words:

> in.ByteCount : Byte Count field for MCTP and "Get UDID", "Assign Address" SMBus ARP commands.

- Note: Different field from Byte Cnt (remaining byte count of a PCI Express completion).

### `Address Type`

Address Type: field of an SMBus device's UDID telling how its address is assigned: fixed, dynamic and persistent, dynamic and volatile, or random number device.

- In the export: packets.csv, column 70, after `Byte Count`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), SMBus ARP Commands, line 1314 of its text. Its words:

> in.UDID_AddressType : Device Capabilities's Address Type field from UDID :


### `PEC Support`

PEC Support: field of an SMBus device's UDID telling whether the device supports Packet Error Code, the error-check byte at the end of an SMBus packet.

- In the export: packets.csv, column 71, after `Address Type`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), SMBus ARP Commands, line 1325 of its text. Its words:

> in.UDID_PECSupported : Device Capabilitites's PEC Supported field.

- Note: The source line has the typing mistake 'Capabilitites'.

### `UDID Version`

UDID Version: the version of the UDID layout, from the Version/Revision field of an SMBus device's unique device identifier (value 001b is version 1).

- In the export: packets.csv, column 72, after `PEC Support`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), SMBus ARP Commands, line 1335 of its text. Its words:

> in.UDID_UDIDVersion : Version/Revision's UDID Version field from UDID :


### `Silicon Revision ID`

Silicon Revision ID: the chip revision number stored in the Version/Revision field of an SMBus device's unique device identifier (UDID).

- In the export: packets.csv, column 73, after `UDID Version`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), SMBus ARP Commands, line 1340 of its text. Its words:

> in.UDID_SiliconRevisionID : Version/Revision's Silicon Revision ID field from UDID.


### `Vendor ID`

Vendor ID: the vendor identifier stored in an SMBus device's unique device identifier (UDID), shown in SMBus ARP rows that carry the UDID.

- In the export: packets.csv, column 74, after `Silicon Revision ID`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), SMBus ARP Commands, line 1341 of its text. Its words:

> in.UDID_VendorID : Vendor ID field from UDID.


### `Device ID`

Device ID: in packets.csv, the device identifier stored in an SMBus device's unique device identifier (UDID), shown in SMBus ARP rows that carry the UDID.

- In the export: packets.csv, column 75, after `Vendor ID`.
- Holds for the packet level only: the same name is another field at the other levels.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), SMBus ARP Commands, line 1342 of its text. Its words:

> in.UDID_DeviceID : Device ID field from UDID.

- Note: In NVME_Transactions.csv and nvme_command.csv the same name appears next to other columns and is a different field (the scripting-engine manual has in.nvmcDeviceId: Returns command device id); not explained here.

### `ZONE`

ZONE: one of the interface flags in the Interface field of an SMBus device's unique device identifier (UDID), alongside IPMI, ASF and OEM.

- In the export: packets.csv, column 76, after `Device ID`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), SMBus ARP Commands, line 1344 of its text. Its words:

> in.UDID_ZONE : Interface's ZONE field from UDID.

- Note: The manual names the field only; what the ZONE interface is was not found in the sources.

### `IPMI`

IPMI: interface flag in an SMBus device's unique device identifier (UDID); set when the device supports the Intelligent Platform Management Interface.

- In the export: packets.csv, column 77, after `ZONE`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), SMBus ARP Commands, line 1345 of its text. Its words:

> in.UDID_IPMI : Interface's IPMI field from UDID.

- Note: The expansion of IPMI is from general knowledge; the manual names the field only.

### `ASF`

ASF: interface flag in an SMBus device's unique device identifier (UDID); set when the device supports the Alert Standard Format.

- In the export: packets.csv, column 78, after `IPMI`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), SMBus ARP Commands, line 1346 of its text. Its words:

> in.UDID_ASF : Interface's ASF field from UDID.

- Note: The expansion of ASF is from general knowledge; the manual names the field only.

### `OEM`

OEM: interface flag in an SMBus device's unique device identifier (UDID); set when the device has a manufacturer-defined (OEM) interface.

- In the export: packets.csv, column 79, after `ASF`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), SMBus ARP Commands, line 1347 of its text. Its words:

> in.UDID_OEM : Interface's OEM field from UDID.

- Note: The manual names the field only; the manufacturer-defined reading is from general knowledge.

### `SMBus Version`

SMBus Version: the System Management Bus version the device reports in its unique device identifier (UDID): 1.0, 1.1, 2.0 or 3.0.

- In the export: packets.csv, column 80, after `OEM`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), SMBus ARP Commands, line 1327 of its text. Its words:

> in.UDID_SMBusVer : SMBus Version field from UDID. All values that are not listed below are reserved :


### `Sub Vendor ID`

Subsystem Vendor ID: the subsystem vendor identifier stored in an SMBus device's unique device identifier (UDID).

- In the export: packets.csv, column 81, after `SMBus Version`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), SMBus ARP Commands, line 1348 of its text. Its words:

> in.UDID_SubsystemVendorID : Subsystem Vendor ID field from UDID.


### `Sub Device ID`

Subsystem Device ID: the subsystem device identifier stored in an SMBus device's unique device identifier (UDID).

- In the export: packets.csv, column 82, after `Sub Vendor ID`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), SMBus ARP Commands, line 1353 of its text. Its words:

> in.UDID_SubsystemDeviceID : Subsystem Device ID field from UDID.


### `Vendor Specific ID`

Vendor Specific ID: the vendor-defined identifier stored in an SMBus device's unique device identifier (UDID).

- In the export: packets.csv, column 83, after `Sub Device ID`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), SMBus ARP Commands, line 1354 of its text. Its words:

> in.UDID_VendorSpecificID : Vendor Specific ID field from UDID.


### `PEC`

Packet Error Code: the error-check byte sent at the end of an SMBus packet. The analyzer also calculates its own value to compare against.

- In the export: packets.csv, column 84, after `Vendor Specific ID`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.5 SMBus-specific set of members, line 1277 of its text. Its words:

> in.PEC : transmitted Packet Error Code.

- Note: The manual also lists in.CalculatedPEC: calculated Packet Error Code.

### `LCRC`

Link CRC: the 32-bit checksum the data link layer adds to each TLP. The receiver checks it; a mismatch is a bad link CRC error.

- In the export: packets.csv, column 85, after `PEC`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Field values for all TLP types, line 950 of its text. Its words:

> in.LCRC: LCRC value as set by the Data Link Layer

- Note: Bad LCRC is a flagged packet error (in.BadLCRC in the manual). 32 bits per the scripting manual range 0x00000000 - 0xFFFFFFFF.

### `ECRC`

End-to-end CRC: the optional 32-bit checksum at the end of a TLP (present when the TLP Digest bit is set), checked by the final receiver.

- In the export: packets.csv, column 86, after `LCRC`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Field values for all TLP types, line 952 of its text. Its words:

> in.ECRC: ECRC value (optional)

- Note: The link to the TD bit comes from the scripting manual (TD: presence of the TLP digest).

### `CRC 16`

CRC 16: the 16-bit checksum at the end of a data link layer packet, checked by the receiver.

- In the export: packets.csv, column 87, after `ECRC`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), DLLP Error related Variables, line 775 of its text. Its words:

> in.BadCRC: Set to 1 if the DLLP has bad 16-bit CRC and to 0 otherwise

- Note: The automation interface text export shows it as CRC 16(0x...) on DLLP lines.

### `DATA`

Data: the data payload of the packet. The newer export format shows it as an amount, such as 4 B or 1 KB, instead of listing doublewords.

- In the export: packets.csv, column 88, after `CRC 16`.
- Source: Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.1.16 Export: To Text, line 7691 of its text. Its words:

> Modifies 'Data' field to show '4 B' or 1 KB instead of

- Note: Not confirmed whether DATA in packets.csv holds this size text or the payload bytes; the manual speaks of the Data field of the export.

### `Time Delta`

Time Delta: the time difference added to the export by the newer format, the time that passed since the previous row. The manuals do not state the unit.

- In the export: packets.csv, column 89, after `DATA`; link.csv, column 19, after `Metrics.# Packets`; split.csv, column 16, after `Metrics.# LinkTrans`; NVME_Transactions.csv, column 23, after `Metrics.# Link & Split Trans`; nvme_command.csv, column 28, after `Metrics.# NVME Trans`.
- Source: Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.1.16 Export: To Text, line 7690 of its text. Its words:

> Adds time delta value to the export

- Note: Which earlier row it is measured from, and the unit, are not stated; it is probably the previous row of the same file. Same name at every level of the export.

### `Time Stamp`

Time Stamp: when the packet was captured, in seconds with nine decimals (for example 2.742651908), so down to the nanosecond.

- In the export: packets.csv, column 90, after `Time Delta`; link.csv, column 20, after `Time Delta`; split.csv, column 17, after `Time Delta`; NVME_Transactions.csv, column 24, after `Time Delta`; nvme_command.csv, column 29, after `Time Delta`.
- Source: Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.1.16 Export: To Text, line 7688 of its text. Its words:

> Removes spaces from time stamp format, i.e. "0002 . 742 651 908"

- Note: Older text format: 0002 . 069 437 652 s (seconds, then nanoseconds). Which instant the time counts from (start of recording) is not stated. Same name at every level of the export.

### `Jammer Phase`

Not found in the documents that were read. The Data Grounder asks the model and the web for this column.

- In the export: packets.csv, column 91, after `Time Stamp`.
- Source: none.
- Note: Searched all five manuals for the jammer fields. The scripting-engine manual (5.9) lists the jammer action type, original packet type and result packet type only; no line names or describes a phase. Could not tell what the column holds.

### `Action`

Jammer Action: what the jammer did to the packet shown in this row: delete, replace, modify, insert packet X after, insert error or side-band. Empty for packets the jammer did not touch.

- In the export: packets.csv, column 92, after `Jammer Phase`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.9 Verification Script Engine Input Context Members, line 9468 of its text. Its words:

> in. JamActionType: Contains the numeric encoding of the Jammer Action type.

- Note: Read as the jammer action because the neighbouring columns are all Jammer columns; the plain name Action is not defined in the manuals. The jammer is the Summit hardware that alters traffic on the link; an NVMe recording without a jammer leaves these columns empty.

### `Jammer Target Packet`

Jammer Target Packet: the type of the original packet that a jammer action was applied to, as it was before the jammer changed it.

- In the export: packets.csv, column 93, after `Action`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.9 Verification Script Engine Input Context Members, line 9479 of its text. Its words:

> in. JamOriginalPacketType: String representation of event type

- Note: The manual calls it the original packet type; matching it to the column name Target Packet is inferred from the neighbouring Result Packet column.

### `Jammer Result Packet`

Jammer Result Packet: the type of the packet that came out of the jammer action, for actions that make a packet (replace, insert packet X after, insert error).

- In the export: packets.csv, column 94, after `Jammer Target Packet`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.9 Verification Script Engine Input Context Members, line 9480 of its text. Its words:

> in. JamResultPacketType: String representation of result packet type (valid for jammer Replace, Insert Pkt X after,

- Note: The line continues on the next line with: insert error ).

### `CXL Pkt Type`

Not found in the documents that were read. The Data Grounder asks the model and the web for this column.

- In the export: packets.csv, column 95, after `Jammer Result Packet`.
- Source: none.
- Note: Searched all five manuals. The Compute Express Link fields they describe are control-flit type, cache and memory packet opcode, slot type and ALMP type, and the M64 trigger tables name D2H, H2D, M2S and S2M classes, but no line names this column or lists its values. Could not tell which of these it holds.

### `CXL Pkt Subtype`

Not found in the documents that were read. The Data Grounder asks the model and the web for this column.

- In the export: packets.csv, column 96, after `CXL Pkt Type`.
- Source: none.
- Note: Searched all five manuals. Nothing names this column; the closest are in.CXL_CacheMemControlFlitSubType (control flits only) and the cache and memory packet slot type. Could not tell which of these, if any, it holds.

### `OpCode`

OpCode: the operation code of a CXL.cache or CXL.mem protocol packet, naming the kind of request or response (for example a cache read or a memory read). Empty for packets that are not CXL protocol packets.

- In the export: packets.csv, column 97, after `CXL Pkt Subtype`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.10.4 CXL Cache/Mem Protocol Packet's Fields, line 9584 of its text. Its words:

> in.CXL_CacheMemPacketOpCode: CXL.cache/mem protocol packet OpCode field.

- Note: Not the NVMe command opcode (OPC in nvme_command.csv). The scripting manual lists opcode names such as H2DReqOpcode, D2HReqOpcode and MemReqOpcode.

### `CQID`

Command Queue ID: number of the device's tracking entry for a CXL.cache request; the host's answer repeats it so the device knows which entry it is for. Empty for other packets.

- In the export: packets.csv, column 98, after `OpCode`.
- Holds for the packet level only: the same name is another field at the other levels.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.10.4 CXL Cache/Mem Protocol Packet's Fields, line 9632 of its text. Its words:

> in.CXL_CachePacketCQID: CXL.cache protocol packet CQID field.

- Note: In NVME_Transactions.csv and nvme_command.csv the same name is the NVMe Completion Queue Identifier, a different field. Scripting manual: CQID is a reflection of the CQID sent with the D2H Request and indicates which device entry is the target of the response.

### `UQID`

Unique Queue ID: number of the host's tracking entry for a CXL.cache request or response; for example a host request names the host entry it comes from. Empty for other packets.

- In the export: packets.csv, column 99, after `CQID`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.10.4 CXL Cache/Mem Protocol Packet's Fields, line 9636 of its text. Its words:

> in.CXL_CachePacketUQID: CXL.cache protocol packet UQID field.

- Note: Scripting manual: Unique Queue ID: indicates which Host entry is the source of the request.

### `Address [51:6]`

Address bits 51 down to 6 of a CXL.cache request: the address of the 64-byte cache line the request targets (the low 6 bits are not sent).

- In the export: packets.csv, column 100, after `UQID`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), 2.1.3.1 CXLCacheType = H2D_CacheReq, line 2248 of its text. Its words:

> the [51:6] bits of the address.

- Note: The 64-byte line size follows from dropping the low 6 bits. The sentence reads: Note that according to the CXL specification the parameter specifies the [51:6] bits of the address.

### `NT`

Non-Temporal: hint bit in a cacheable read request from a CXL device telling the host how it should cache the line.

- In the export: packets.csv, column 101, after `Address [51:6]`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), 2.1.3.4 CXLCacheType = D2H_CacheReq, line 2441 of its text. Its words:

> NonTemporal field is used as a hint

- Note: The column name NT is read as NonTemporal because it sits between CQID and the address in a device-to-host request; the manual spells it NonTemporal.

### `RSP_PRE`

RSP_PRE: field of a host-to-device CXL.cache response that carries performance-monitoring information for requests that get no data: miss local, hit or miss remote.

- In the export: packets.csv, column 102, after `NT`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), 2.1.3.2 CXLCacheType = H2D_CacheResp, line 2316 of its text. Its words:

> RSP_PRE MissLocal MissLocal Carries the performance monitoring

- Note: The spelled-out words of RSP_PRE are not given in the manuals.

### `MESI`

MESI: the cache state (Modified, Exclusive, Shared or Invalid) that the host grants for a cache line in a CXL.cache GO response; carried in the response data field.

- In the export: packets.csv, column 103, after `RSP_PRE`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), 2.1.3.2 CXLCacheType = H2D_CacheResp, line 2310 of its text. Its words:

> CacheState Shared 0 It is relevant for H2DRespOpcode = GO. It is

- Note: The scripting manual calls it CacheState and says it is stored in the RspData field as MESI information; it also lists an Error state.

### `ChunkValid`

Chunk Valid: for a 32-byte CXL.cache data transfer, which half of the 64-byte cache line (lower or upper 32 bytes) the data carries. Ignored for 64-byte transfers.

- In the export: packets.csv, column 104, after `MESI`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), 2.1.3.3 CXLCacheType = H2D_CacheData, line 2355 of its text. Its words:

> In case of a 32B transfer on CXL.cache, this indicates


### `Bogus`

Bogus: bit in the data header of a CXL.cache evict message from the device; 1 means the data went out to a snoop after the request, so it is no longer current and the host should drop it.

- In the export: packets.csv, column 105, after `ChunkValid`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), 2.1.3.6 CXLCacheType = D2H_CacheData, line 2531 of its text. Its words:

> Indicates that the data associated with this

- Note: The sentence continues over the next lines: evict message was returned to a snoop after the D2H request was sent from the device but before a WritePull was received for the evict.

### `Poison`

Poison: bit in a CXL data header; 1 means the data is corrupted and must not be used. Not the poisoned bit of a PCI Express TLP (EP).

- In the export: packets.csv, column 106, after `Bogus`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.10.4 CXL Cache/Mem Protocol Packet's Fields, line 9588 of its text. Its words:

> in.CXL_CacheMemPacketPoison: CXL.cache/mem protocol packet Poison field.

- Note: Scripting manual: Indicates to the device that this data is corrupted and as such should not be used.

### `Go-Err`

GO-ERR: bit in the data header of a host-to-device CXL.cache message; 1 means the data is the result of an error condition and should not be cached or given as a response to snoops.

- In the export: packets.csv, column 107, after `Poison`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), 2.1.3.3 CXLCacheType = H2D_CacheData, line 2363 of its text. Its words:

> The GO-ERR field indicates to the agent that this


### `MetaField`

Meta Field: in a CXL.mem request, which meta data field of the memory line is to be updated, if any (Meta0State, or none).

- In the export: packets.csv, column 108, after `Go-Err`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), 2.1.4.1 CXLMemType = M2S_MemReq, line 2660 of its text. Its words:

> Specifies which, if any, Meta

- Note: Also in.CXL_MemPacketMetaField in the scripting-engine manual. The sentence continues on the next line: Data Field needs to be updated.

### `MetaValue`

Meta Value: the value the meta data field named in the Meta Field column is to be updated to, such as Invalid, Any or Shared.

- In the export: packets.csv, column 109, after `MetaField`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), 2.1.4.1 CXLMemType = M2S_MemReq, line 2666 of its text. Its words:

> MetaValue For MetaField = Invalid Specifies the value of the

- Note: Also in.CXL_MemPacketMetaValue in the scripting-engine manual. The sentence continues on the next line: field needs to be updated to.

### `SnpType`

Snoop Type: in a CXL.mem request, which snoop, if any, the device's coherence engine must issue to the host, and the lowest coherency state the host must hold: no-op, SnpData, SnpCur or SnpInv.

- In the export: packets.csv, column 110, after `MetaValue`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), 2.1.4.1 CXLMemType = M2S_MemReq, line 2654 of its text. Its words:

> SnpType NoOp NoOp Snoop Type: specifies which

- Note: Also in.CXL_MemPacketSnpType in the scripting-engine manual. Not the TLP No Snoop attribute.

### `LLCTRL Pkt Subtype`

Link Layer Control packet sub type: the sub type of a CXL.cache/CXL.mem link-layer control flit, such as Retry.Idle, Retry.Req or LLCRD.Ack. Empty for other packets.

- In the export: packets.csv, column 111, after `SnpType`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.10.5 CXL Cache/Mem Control Packet's Fields, line 9695 of its text. Its words:

> in.CXL_CacheMemControlFlitSubType: CXL.cache/mem control flit sub type (RETRY.Idle, RETRY.Req,

- Note: LLCTRL is read as the link layer control flit; the scripting manual's Packet = CXL_LLCTRL command sets LLCTRLType InitParam, LLCRDAck, RetryAck or RetryReq.

### `ALMP VLSM State`

ARB/MUX Link Management Packet virtual link state machine State: the state (for example Reset, Active, a low-power state, Retrain or Disable) that a CXL link management packet requests or reports.

- In the export: packets.csv, column 112, after `LLCTRL Pkt Subtype`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.10.2 CXL ALMP Packet's Flit Fields, line 9531 of its text. Its words:

> in.CXL_ALMPVLSMState: ALMP packet VLSM State field.

- Note: The state names are from the scripting manual's Config = CXL_VLSM table (Reset, Active, Idle_L1_1 to L1_4, L2, LinkReset, LinkError, Retrain, Disable).

### `ALMP VLSM Target`

ARB/MUX Link Management Packet virtual link state machine Target: which virtual link state machine the packet is about, the one for CXL.io or the one for CXL.cache and CXL.mem.

- In the export: packets.csv, column 113, after `ALMP VLSM State`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.10.2 CXL ALMP Packet's Flit Fields, line 9535 of its text. Its words:

> in.CXL_ALMPTarget: ALMP packet VLSM Target field.

- Note: The two targets (IO and CacheMem) are from the scripting manual's Config = CXL_VLSM, VLSMTarget.

## Columns first seen at the link transaction level (link.csv)

### `Link Tra`

Link Transaction: the number of this row at the Link decoding level. A link transaction is a TLP packet matched with its Ack or Nak packet coming back from the opposite direction.

- In the export: link.csv, column 1.
- Source: Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.3.12.2 Link (Reading CATC Traces), line 9383 of its text. Its words:

> Link level decode is composed of TLP packets matched with a corresponding ACK or NAK

- Note: The manual shows numbered units ('Link Transaction 0', Summit Z5 manual line 10364) but not the cell contents; reading the cell as the transaction number is an inference.

### `Link Speed`

Link Speed: the speed the link was running at when this transaction was captured, in gigatransfers per second (2.5, 5.0, 8.0, 16.0, 32 or 64). For example 16.0 means PCI Express generation 4.

- In the export: link.csv, column 3, after `Link Dir`; split.csv, column 3, after `Link Dir`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.1 All packet/transaction-specific set of members, line 581 of its text. Its words:

> in.Speed: Speed of this packet or link transaction: 0 = 2.5GT/s, 1 = 5.0 GT/s, 2 = 8.0 GT/s, 3 = 16.0 GT/s, 4 =

- Note: In the real export this header cell has no label and the first row's value (for example 16.0) stands in for the name. The manual lists the speed member for packet and link transaction levels only, yet split.csv has the same column.

### `Link Tra Error`

Link Transaction Error: the error the analyzer flagged for this link transaction, for example a damaged packet or an acknowledgement that never arrived.

- In the export: link.csv, column 4, after `Link Speed`.
- Source: none. No document that was read states this field; the meaning was written from knowledge of the protocol when this document was prepared.
- Note: No manual line describes this column. The Verification Script Engine manual only says a link transaction can end as 'Incomplete (Link Layer error)' (line 1519 of that manual). Meaning written from the column name and general PCI Express knowledge.

### `Mem`

Memory: group header for memory request transactions, memory reads and memory writes. The Mem.TLP Type, Mem.Attributes and Mem.Length columns give the details of that memory request.

- In the export: link.csv, column 6, after `PSN`; split.csv, column 4, after `Link Speed`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 7.2 Link Transaction Level Events, line 10084 of its text. Its words:

> Memory transactions _LINK_MEMORY

- Note: In split.csv only Mem.TLP Type follows; the split level has the matching event _SPLIT_MEMORY (line 10107).

### `Mem.TLP Type`

TLP Type of the memory request: the kind of Transaction Layer Packet, for example memory read (MRd), locked memory read (MRdLk) or memory write (MWr), each with a 32-bit or 64-bit address format.

- In the export: link.csv, column 7, after `Mem`; split.csv, column 5, after `Mem`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.3 TLP-specific set of members, line 827 of its text. Its words:

> in.TLPType: Contains the numeric encoding of the TLP type.


### `Mem.Attributes`

Attributes of the memory request TLP: the three attribute bits of its header, Snoop, Ordering and ID-based ordering. Snoop 1 means hardware cache coherency is not expected; Ordering 1 means relaxed ordering.

- In the export: link.csv, column 8, after `Mem.TLP Type`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.3 TLP-specific set of members, Field values for all TLP types, line 933 of its text. Its words:

> in.Attributes: Attributes field value [all three bits (Snoop, Ordering, and IDBasedOrdering)] (PCIe Flit/Non-Flit

- Note: The meaning of the Snoop and Ordering bit values comes from the Summit Exerciser Scripting manual (lines 515-523): Snoop 1 = hardware enforced cache coherency not expected; Ordering 1 = relaxed ordering model.

### `Mem.Length`

Length of the memory request TLP, counted in doublewords (4 bytes): the payload size of a write, or the amount of data a read asks for.

- In the export: link.csv, column 9, after `Mem.Attributes`.
- Source: Summit Exerciser Scripting Language Reference Manual (PCIe Protocol Analysis version 13.20), TLP parameter table (Packet=TLP command): Length, line 535 of its text. Its words:

> Length of data payload in DWORDs.

- Note: Source is the exerciser command table for generating TLPs; the VSE manual names the field (in.Length, line 948) without its unit.

### `Data`

Data: the payload bytes of the unit at this decoding level. A link transaction shows the data of its TLP, a split transaction the combined data of request and completions, an NVMe transaction or command the data it transferred.

- In the export: link.csv, column 15, after `Last BE`; split.csv, column 13, after `Cpl Status`; NVME_Transactions.csv, column 47, after `I`; nvme_command.csv, column 7, after `CID`.
- Source: Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), NVMe: Data Field on Packets, line 9537 of its text. Its words:

> The content for this field changes depending on the decode level selected and the particular

- Note: Combined payload of a split transaction: VSE manual line 1555; of an NVM command: line 1924. How the export prints the cell (hex bytes, shortened) is not described in the manuals.

### `Metrics`

Metrics: group header for the measurements the analyzer calculates for each link transaction, split transaction, NVMe transaction and NVMe command. In the export its sub-columns hold the number of lower-level parts that make up the unit.

- In the export: link.csv, column 17, after `VC ID`; split.csv, column 14, after `Data`; NVME_Transactions.csv, column 21, after `MN`; nvme_command.csv, column 26, after `NSID`.
- Source: Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.9.3 Show Metrics in the CATC Trace Display, line 14831 of its text. Its words:

> information applicable to a specific protocol unit is displayed in a Metrics header.

- Note: The exported sub-columns are Metrics.# Packets, # LinkTrans, # Link & Split Trans and # NVME Trans. Response time, latency and throughput metrics of the GUI are not columns of these files.

### `Metrics.# Packets`

Number of Packets: the total number of packets that make up this link transaction. Usually two (the TLP and its Ack) or one when acknowledged implicitly; more when Naks or link-level retries happened.

- In the export: link.csv, column 18, after `Metrics`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.10 Link transaction-specific set of members, Metric values, line 1526 of its text. Its words:

> in.Metric_NumOfPackets: Metric presenting the total number of packets that compose this Link Transaction, an

- Note: Two-or-one rule: Summit M64 manual line 14489.

### `Cpl`

Completion: group header for completion TLPs, the answers to requests such as memory reads. The neighbouring columns give details such as the completer and the completion status.

- In the export: link.csv, column 21, after `Time Stamp`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 7.2 Link Transaction Level Events, line 10088 of its text. Its words:

> Completion transactions _LINK_COMPLETION


### `Explicit ACK`

Acknowledgement status of the link transaction. 'Explicit ACK' means explicitly acknowledged: the TLP was matched with its own Ack packet, normally two packets. Other values are Implicitly Acknowledged and Incomplete (link layer error).

- In the export: link.csv, column 27, after `Lwr Addr`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.10 Link transaction-specific set of members, line 1518 of its text. Its words:

> in.TransactionStatus: Status for this Link transaction. Can be one of three values: Implicitly Acknowledged,

- Note: The header text is a status value (that of the first row) because the real header cell has no label; the column holds the status of every row. Explicit = two packets, implicit = one packet: Summit M64 manual line 14489.

### `Msg`

Message: group header for message TLPs, the in-band messages such as interrupt, power management or error signalling messages. The Msg.* columns and Message Code describe the message.

- In the export: link.csv, column 28, after `Explicit ACK`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 7.2 Link Transaction Level Events, line 10087 of its text. Its words:

> Message transactions _LINK_MESSAGE


### `Msg.Msg Routing`

Message Routing: how the message is routed, taken from the TLP Type field: to the Root Complex, by address, by ID, broadcast from the Root Complex, local (ends at the receiver) or gathered to the Root Complex.

- In the export: link.csv, column 29, after `Msg`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.3 TLP-specific set of members, For Message TLPs only, line 1004 of its text. Its words:

> in.MessageRoute: Message Routing field value (from the TLP Type field) (PCIe Flit/Non-Flit modes)

- Note: The six routing kinds follow the message names MsgRtoRC, MsgRbyAddr, MsgRbyID, MsgBfromRC, MsgLocal, MsgGRtoRC in the Summit Exerciser Scripting manual (lines 459-464).

### `Implicit ACK`

Acknowledgement status of a link transaction, shown here as 'Implicit ACK': implicitly acknowledged, so the TLP counts as acknowledged but the transaction is normally one packet. Other values are Explicitly Acknowledged and Incomplete.

- In the export: link.csv, column 31, after `Message Code`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.10 Link transaction-specific set of members, line 1518 of its text. Its words:

> in.TransactionStatus: Status for this Link transaction. Can be one of three values: Implicitly Acknowledged,

- Note: Same column type as Explicit ACK; the header text is the status of the first row of that group because the header cell has no label.

### `No-Snoop Requirement`

No-Snoop Latency Requirement, from a Latency Tolerance Reporting message: 1 means the sender has a latency requirement for traffic that is not snooped (see Value and Scale); 0 means it has none.

- In the export: link.csv, column 33, after `No-Snoop`.
- Source: none. No document that was read states this field; the meaning was written from knowledge of the protocol when this document was prepared.
- Note: No manual in the sources describes this column. It is read as a field of a Latency Tolerance Reporting message from its name and its place after the message columns; confirm against a row of a Latency Tolerance Reporting message.

### `No-Snoop Scale`

No-Snoop Latency Scale, from a Latency Tolerance Reporting message: the unit of the No-Snoop Value. 0 = 1 ns, 1 = 32 ns, 2 = 1,024 ns, 3 = 32,768 ns, 4 = 1,048,576 ns, 5 = 33,554,432 ns.

- In the export: link.csv, column 34, after `No-Snoop Requirement`.
- Source: none. No document that was read states this field; the meaning was written from knowledge of the protocol when this document was prepared.
- Note: No manual in the sources describes this column. It is read as a field of a Latency Tolerance Reporting message from its name and its place after the message columns; confirm against a row of a Latency Tolerance Reporting message.

### `No-Snoop Value`

No-Snoop Latency Value, from a Latency Tolerance Reporting message: a 10-bit number that, times the No-Snoop Scale unit, gives the latency the device can tolerate for traffic that is not snooped.

- In the export: link.csv, column 35, after `No-Snoop Scale`.
- Source: none. No document that was read states this field; the meaning was written from knowledge of the protocol when this document was prepared.
- Note: No manual in the sources describes this column. It is read as a field of a Latency Tolerance Reporting message from its name and its place after the message columns; confirm against a row of a Latency Tolerance Reporting message.

### `Cfg`

Configuration: group header for configuration request transactions, reads and writes of a device's configuration space. The Cfg.* columns give the packet type, the addressed device and the register.

- In the export: link.csv, column 37, after `Snoop`; split.csv, column 19, after `Split Tra Error`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 7.2 Link Transaction Level Events, line 10086 of its text. Its words:

> Configuration transactions _LINK_CONFIG


### `Cfg.DeviceID`

Device ID: the bus, device and function number, combined, of the device a configuration request is addressed to.

- In the export: link.csv, column 38, after `Cfg`; split.csv, column 21, after `Cfg.TLP Type`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.3 TLP-specific set of members, Field values dependent upon TLP type, line 975 of its text. Its words:

> in.DeviceId: Requester ID value (Bus, Device and Function Number fields combined) for Configuration requests

- Note: The manual words this as a 'Requester ID value'; in a configuration request this field names the addressed device, while the requester has its own column (RequesterID).

### `Cfg.Register`

Register: the address of the configuration-space register the request reads or writes (register number and extended register number combined).

- In the export: link.csv, column 39, after `Cfg.DeviceID`; split.csv, column 22, after `Cfg.DeviceID`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.3 TLP-specific set of members, Field values dependent upon TLP type, line 978 of its text. Its words:

> in.Register: Register address (Register Number and Extended Register Number combined) for Configuration


## Columns first seen at the split transaction level (split.csv)

### `Split Tra`

Split Transaction: the number of this row at the Split decoding level. A split transaction is a request link transaction together with the completion link transactions that answer it from the other direction.

- In the export: split.csv, column 1.
- Source: Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.3.12.3 Split (Reading CATC Traces), line 9391 of its text. Its words:

> Split level decode is composed of two Link transactions, the Request TLP and the Completion

- Note: Decode level name 'Split Tra': Automation API manual line 14650. A memory read can have more than two link transactions (Summit Z5 manual line 14825). Reading the cell as the number is an inference, as for Link Tra.

### `Metrics.# LinkTrans`

Number of Link Transactions: the total number of link transactions that make up this split transaction, the request plus its completions. Usually two for a configuration or I/O request, more for a memory read.

- In the export: split.csv, column 15, after `Metrics`.
- Source: Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.9.2.1 Metrics Defined for Split Transactions, line 14806 of its text. Its words:

> Number of Link Transactions: The total number of Link transactions that compose this Split

- Note: Two-or-more rule: Summit Z5 manual line 14825.

### `Split Tra Error`

Split Transaction Error: the errors the analyzer decoded for the split transaction. The manual names Completer Data Inconsistency, Attributes Mismatch and Error in sub-transaction.

- In the export: split.csv, column 18, after `Time Stamp`.
- Source: Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.3.12.26 Warning Messages in Split Traces, line 11210 of its text. Its words:

> The PCIe Protocol Analysis software can decode errors in Split transactions as shown in

- Note: The three error types are listed on lines 11213-11215 of the Summit Z5 manual.

### `Cfg.TLP Type`

TLP Type of the configuration request: configuration read or write, either Type 0 (CfgRd0, CfgWr0: to a device on the local bus) or Type 1 (CfgRd1, CfgWr1: forwarded on through a bridge).

- In the export: split.csv, column 20, after `Cfg`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.3 TLP-specific set of members, line 827 of its text. Its words:

> in.TLPType: Contains the numeric encoding of the TLP type.

- Note: Type 0 and Type 1 explanation is general PCI Express knowledge; the manual lists the four type names (TLP_TYPE_ID_CFGRD_0 to CFGWR_1).

## Columns first seen at the NVMe transaction level (NVME_Transactions.csv)

### `NVMe`

NVMe: the number of this row at the NVMe transaction decoding level. An NVMe transaction is one step of a command: a register access, doorbell write, queue-entry fetch, data transfer, completion entry or interrupt.

- In the export: NVME_Transactions.csv, column 1.
- Source: Automation API for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.42), Decoding Levels (EPETraceDecodeLevels), line 14652 of its text. Its words:

> DECODE_LEVEL_NVMHCI 3 NVMe

- Note: Numbered NVMe transactions appear in Summit Z5 manual line 9939 ('NVMe Transaction #311815'); the cell contents themselves are not shown in the manuals. Types of NVMe transaction: Verification Script Engine manual section 5.2.12.

### `Device ID`

Device ID: the identifier of the device that the NVMe transaction or command belongs to, as the analyzer shows it with each decoded command.

- In the export: NVME_Transactions.csv, column 3, after `Link Dir`; nvme_command.csv, column 23, after `ST.SC`.
- Holds for the NVMe transaction level and the NVMe command level only: the same name is another field at the other levels.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.13 NVM command-specific set of members, line 1927 of its text. Its words:

> in.nvmcDeviceId: Returns command device id.

- Note: Summit Z5 user manual, 'NVMe: Device ID and Model Name Decoded': the Device ID and Device Model Name field is displayed in the decoded command. The manuals do not say how the identifier is formed. In packets.csv the same name is an SMBus field, a different field with its own entry.

### `QID`

Queue Identifier: the number of the NVMe queue the row refers to; 0 is the Admin queue. In the command file it sits with the Create I/O Queue fields and is the number given to the queue being created.

- In the export: NVME_Transactions.csv, column 4, after `Device ID`; nvme_command.csv, column 338, after `NCQA`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.12 NVM transaction-specific set of members, line 1690 of its text. Its words:

> in. nvmeQID: Defined for _NVME_DOORBELL_REG transaction event. Returns zero for Admin doorbells, or

- Note: Create I/O Queue QID: NVMe Base Specification 2.1 line 26018. In NVME_Transactions.csv the column sits next to QSIZE, before Address; which transactions fill it is not described in the sources.

### `QSIZE`

Queue Size: the number of entries of an NVMe queue. In a Create I/O Queue command it is the size of the queue to create, a 0's based value (the number of entries minus 1).

- In the export: NVME_Transactions.csv, column 5, after `QID`; nvme_command.csv, column 339, after `QID`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 474: Create I/O Completion Queue - Command Dword 10, line 26015 of its text. Its words:

> Queue Size (QSIZE): This field indicates the size of the Completion Queue to be created. If the size is

- Note: Same field for the Submission Queue in Figure 478 (line 26100). In NVME_Transactions.csv it follows QID before Address; the sources do not say which transactions fill it.

### `Address`

Address: the memory address this NVMe transaction was seen at, for example the address of the controller register, the doorbell or the queue entry that was read or written.

- In the export: NVME_Transactions.csv, column 6, after `QSIZE`.
- Holds for the NVMe transaction level only: the same name is another field at the other levels.
- Source: none. No document that was read states this field; the meaning was written from knowledge of the protocol when this document was prepared.
- Note: Not described in the manuals for this level; read from the name and its place after QID and QSIZE. In packets.csv, link.csv and split.csv the same name is the address of a memory or I/O request, with its own entry.

### `Type`

Type: what kind of NVMe transaction the row is: a controller register access, doorbell write, admin or I/O submission queue entry, completion queue entry, PRP entry or list, SGL descriptor, data transfer, index/data register or interrupt.

- In the export: NVME_Transactions.csv, column 7, after `Address`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.12 NVM transaction-specific set of members, line 1598 of its text. Its words:

> in.nvmeType: Returns NVMe register type.

- Note: The manual lists the values in tables from line 1600 (for example _NVME_ADMIN_SQTDBL, _NVME_IO_SUBMISSION_Q_ENTRY, _NVME_IO_COMPLETION_Q_ENTRY). The exact words shown in the export cell are not given.

### `Doorbell index`

Doorbell index: for a doorbell write, the value written: the new Submission Queue Tail (SQT) for a submission queue doorbell, or the new Completion Queue Head (CQH) for a completion queue doorbell.

- In the export: NVME_Transactions.csv, column 8, after `Type`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.12 NVM transaction-specific set of members, line 1693 of its text. Its words:

> in. nvmeIndex: Defined for _NVME_DOORBELL_REG transaction event. Returns SQT for submission doorbells,


### `SQID`

Submission Queue Identifier: the number of the submission queue the command was issued to (0 is the Admin queue). In a completion queue entry it names the queue the completed command came from.

- In the export: NVME_Transactions.csv, column 9, after `Doorbell index`; nvme_command.csv, column 4, after `OPC`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 97: Completion Queue Entry: DW 2, line 8790 of its text. Its words:

> SQ Identifier (SQID): Indicates the Submission Queue to which the associated command was issued.


### `CID`

Command Identifier: the number the host gives a command when it submits it. Together with the submission queue identifier it uniquely identifies the command, and the completion queue entry repeats it.

- In the export: NVME_Transactions.csv, column 10, after `SQID`; nvme_command.csv, column 6, after `CQID`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 91: Command Dword 0, line 8488 of its text. Its words:

> Command Identifier (CID): This field specifies a unique identifier for the command when combined with the


### `P`

Phase Tag: a bit of the completion queue entry that tells the host whether the entry is new. The controller inverts it each time it writes entries around the queue again.

- In the export: NVME_Transactions.csv, column 11, after `CID`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 98: Completion Queue Entry: DW 3, line 8817 of its text. Its words:

> Phase Tag (P): Identifies whether a completion queue entry is new. Refer to section 4.2.4.

- Note: Inversion on each pass through the queue: NVMe Base Specification 2.1 line 6003.

### `DW0`

DW0: Dword 0 of the completion queue entry. Its meaning is specific to the command that completed; for example it can carry a result such as the number of queues allocated.

- In the export: NVME_Transactions.csv, column 12, after `P`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), 4.2 Completion Queue Entry, Figure 96, line 8773 of its text. Its words:

> Queue Entry Layout. The contents of Dword 0 and Dword 1 are command specific. If a command uses

- Note: Example of a command result in Dword 0: Set Features, Number of Queues (Verification Script Engine manual lines 2734-2735).

### `DW0.RSVD`

Reserved bits of Dword 0 of the completion queue entry: the part of Dword 0 that the completed command does not use. Reserved bits are normally zero.

- In the export: NVME_Transactions.csv, column 13, after `DW0`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), 4.2 Completion Queue Entry, Figure 96, line 8775 of its text. Its words:

> If a command does not use Dword 0 or Dword 1, then the unused field(s) are reserved.

- Note: The Verification Script Engine manual lists a RSVD field in Dword 0 for several commands (completion queue entry data tables from line 2719). Reading DW0.RSVD as that reserved part is an inference from the name.

### `ST`

Status: the status field of the completion queue entry (bits 31:17 of its last dword). 0 means the command completed successfully. The status code type, status code, retry delay, more and do-not-retry parts follow it.

- In the export: NVME_Transactions.csv, column 14, after `DW0.RSVD`; nvme_command.csv, column 20, after `ELBATM`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 98: Completion Queue Entry: DW 3, line 8816 of its text. Its words:

> Status (STATUS): Indicates the status for the command that is being completed.

- Note: Zero = successful completion: NVMe Base Specification 2.1 line 8848. In NVME_Transactions.csv the parts SCT, SC, CRD, M, DNR follow; in nvme_command.csv ST.SCT and ST.SC follow.

### `SCT`

Status Code Type: the category of the status in the completion entry: 0 generic command status, 1 command specific status, 2 media and data integrity errors, 3 path related status, 7 vendor specific.

- In the export: NVME_Transactions.csv, column 15, after `ST`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 100: Completion Queue Entry: Status Field; values in Figure 101, line 8888 of its text. Its words:

> Status Code Type (SCT): Indicates the status code type of the completion queue entry. This indicates the


### `SC`

Status Code: the detailed status of the command, read together with the Status Code Type. 00h with type 0 means success; the same number means different things under different types.

- In the export: NVME_Transactions.csv, column 16, after `SCT`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 100: Completion Queue Entry: Status Field, line 8891 of its text. Its words:

> Status Code (SC): Indicates a status code identifying any error or status information for the command

- Note: Status code ranges: 00h-7Fh Admin or shared, 80h-BFh I/O command set specific, C0h-FFh vendor specific (Base Specification lines 8938-8940).

### `CRD`

Command Retry Delay: a 2-bit value in the completion status. 0 means the host may retry at once; 1, 2 or 3 selects one of three retry delay times the drive reports in its Identify Controller data.

- In the export: NVME_Transactions.csv, column 17, after `SC`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 100: Completion Queue Entry: Status Field, line 8872 of its text. Its words:

> Command Retry Delay (CRD): If the DNR bit is cleared to ‘0’ and the host has set the Advanced

- Note: Only meaningful when Do Not Retry is 0 and the host enabled advanced command retry; otherwise reserved.

### `M`

More: a status bit. 1 means there is more status information for this command in the Error Information log page, which the host can read with Get Log Page; 0 means there is none.

- In the export: NVME_Transactions.csv, column 18, after `CRD`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 100: Completion Queue Entry: Status Field, line 8869 of its text. Its words:

> More (M): If this bit is set to ‘1’, then there is more status information for this command as part of the Error


### `DNR`

Do Not Retry: a status bit. 1 means that sending the same command again is expected to fail; 0 means the same command may succeed if retried.

- In the export: NVME_Transactions.csv, column 19, after `M`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 100: Completion Queue Entry: Status Field, line 8862 of its text. Its words:

> Do Not Retry (DNR): If this bit is set to ‘1’, then this bit indicates that if the same command is re-submitted


### `MN`

Model Number: the model name of the drive (the MN field of the Identify Controller data). The analyzer shows the device ID with the device model name next to a decoded command.

- In the export: NVME_Transactions.csv, column 20, after `DNR`; nvme_command.csv, column 24, after `Device ID`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Identify Controller data structure table (NVM Express Admin Command Set), line 3351 of its text. Its words:

> MN 19 319:0 Model Number

- Note: Summit Z5 manual line 9508: 'the Device ID and Device Model Name field is displayed in the decoded command'. Reading this column as that cell is an inference from the abbreviation and its place after Device ID.

### `Metrics.# Link & Split Trans`

Number of Link and Split Transactions: the total number of link and split transactions that make up this NVMe transaction.

- In the export: NVME_Transactions.csv, column 22, after `Metrics`.
- Source: Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), TABLE 6.1: NVMe Queue Time Metrics (Commands/Transactions), line 13657 of its text. Its words:

> # Link & Split Trans Number of Link & Split Transactions - the total number of Link & Split


### `MPTR`

Metadata Pointer: the host memory address of a buffer holding the command's metadata, or of an SGL segment that describes it. Used only when metadata is kept apart from the data.

- In the export: NVME_Transactions.csv, column 25, after `Time Stamp`; nvme_command.csv, column 8, after `Data`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.12.1 NVM transaction members specific to submission command events, line 1798 of its text. Its words:

> in.nvme MPTR: Returns the address of a contiguous physical buffer of metadata or the address of an SGL

- Note: Metadata kept separate from user data: NVMe Base Specification 2.1 line 8510.

### `MPTR.Address`

Address: the host memory address held in the Metadata Pointer (the metadata buffer, or the SGL segment describing it).

- In the export: NVME_Transactions.csv, column 26, after `MPTR`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.12.1 NVM transaction members specific to submission command events, line 1798 of its text. Its words:

> in.nvme MPTR: Returns the address of a contiguous physical buffer of metadata or the address of an SGL

- Note: The manuals define the pointer, not this sub-cell; reading it as the address value held in the pointer is an inference from the name.

### `PRP1`

PRP Entry 1: the first Physical Region Page entry of the command. It holds the host memory address of the first data page, or a pointer to a PRP list.

- In the export: NVME_Transactions.csv, column 27, after `MPTR.Address`; nvme_command.csv, column 9, after `MPTR`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Physical Region Page Entry and List, line 9661 of its text. Its words:

> A physical region page (PRP) entry is a pointer to a physical memory page.

- Note: Field definition: Base Specification line 8642 (PRP Entry 1: first PRP entry for the command or a PRP List pointer).

### `PRP1.Address`

Address: the 64-bit physical memory address held in PRP Entry 1, a page base address plus the offset inside the page.

- In the export: NVME_Transactions.csv, column 28, after `PRP1`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 110: PRP Entry - Page Base Address and Offset, line 9684 of its text. Its words:

> Page Base Address and Offset (PBAO): This field indicates the 64-bit physical memory page

- Note: The manuals define the PRP entry layout, not this sub-cell; reading it as the address held in PRP1 is an inference from the name.

### `PRP2`

PRP Entry 2: the second Physical Region Page entry. It holds the address of the second data page, or a pointer to a PRP list when the transfer crosses more than one page boundary; unused when the data fits one page.

- In the export: NVME_Transactions.csv, column 29, after `PRP1.Address`; nvme_command.csv, column 10, after `PRP1`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 92: Common Command Format (Data Pointer), line 8622 of its text. Its words:

> PRP Entry 2 (PRP2): This field:


### `PRP2.Address`

Address: the 64-bit physical memory address held in PRP Entry 2: the second data page, or the PRP list.

- In the export: NVME_Transactions.csv, column 30, after `PRP2`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 110: PRP Entry - Page Base Address and Offset, line 9684 of its text. Its words:

> Page Base Address and Offset (PBAO): This field indicates the 64-bit physical memory page

- Note: Inference from the name, as for PRP1.Address.

### `ELBST`

Expected Logical Block Storage Tag: the storage tag value the drive should find in the end-to-end protection information of the blocks read. Ignored when the namespace has no end-to-end protection.

- In the export: NVME_Transactions.csv, column 31, after `PRP2.Address`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 51: Read - Command Dword 2 and Dword 3, line 2614 of its text. Its words:

> sized Expected Logical Block Storage Tag (ELBST) and Expected Initial Logical Block Reference Tag

- Note: In the command specification it is split between Command Dword 2/3 (upper part) and Command Dword 14 (lower part); the file shows it between PRP2.Address and SLBA, matching the Read layout.

### `SLBA`

Starting LBA: the 64-bit address of the first logical block the command reads or writes.

- In the export: NVME_Transactions.csv, column 32, after `ELBST`; nvme_command.csv, column 11, after `PRP2`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 52: Read - Command Dword 10 and Command Dword 11, line 2622 of its text. Its words:

> Starting LBA (SLBA): This field indicates the 64-bit address of the first logical block to be read as part


### `NLB`

Number of Logical Blocks: how many logical blocks the command covers. It is a 0's based value, so 0 means one block.

- In the export: NVME_Transactions.csv, column 33, after `SLBA`; nvme_command.csv, column 12, after `SLBA`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 53: Read - Command Dword 12, line 2648 of its text. Its words:

> Number of Logical Blocks (NLB): This field indicates the number of logical blocks to be read. This is a


### `STC`

Storage Tag Check: a bit of a Read or Write command. 1 means the drive checks the Storage Tag field as part of end-to-end data protection; 0 means it does not.

- In the export: NVME_Transactions.csv, column 34, after `NLB`; nvme_command.csv, column 13, after `NLB`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 53: Read - Command Dword 12, line 2641 of its text. Its words:

> Storage Tag Check (STC): This bit specifies the Storage Tag field shall be checked as part of end-to-


### `PRINFO`

Protection Information field: four bits of a Read or Write command that set the action and the checks for end-to-end data protection. In the transaction file its parts follow as PRINFO.PRCHK and PRINFO.PRACT.

- In the export: NVME_Transactions.csv, column 35, after `STC`; nvme_command.csv, column 14, after `STC`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 53: Read - Command Dword 12, line 2637 of its text. Its words:

> Protection Information (PRINFO): Specifies the protection information action and check field, as


### `PRINFO.PRCHK`

Protection Information Check: three bits that choose what the drive checks: Guard (bit 2), Application Tag (bit 1) and Reference Tag (bit 0). A bit set to 1 enables that check.

- In the export: NVME_Transactions.csv, column 36, after `PRINFO`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 11: Protection Information Field Definition, line 1017 of its text. Its words:

> Protection Information Check (PRCHK): The protection information check field specifies the fields that


### `PRINFO.PRACT`

Protection Information Action: 1 means the drive strips (on read) or inserts (on write) the protection information when the metadata holds only protection information; 0 means it is passed through.

- In the export: NVME_Transactions.csv, column 37, after `PRINFO.PRCHK`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 11: Protection Information Field Definition, line 989 of its text. Its words:

> Protection Information Action (PRACT): This bit specifies the action to take for the protection

- Note: With 1 and larger metadata the protection information is passed (read) or replaces the protection information in the metadata (write).

### `FUA`

Force Unit Access: 1 means the drive must use the non-volatile medium, not a cache: a read returns data read from it, a write is stored there before completion is reported. 0 means no effect.

- In the export: NVME_Transactions.csv, column 38, after `PRINFO.PRACT`; nvme_command.csv, column 15, after `PRINFO`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 53: Read - Command Dword 12, line 2632 of its text. Its words:

> Force Unit Access (FUA): If this bit is set to ‘1’, then for data and metadata, if any, associated with


### `LR`

Limited Retry: 1 means the drive should apply limited retry effort when recovering from errors; 0 means it should use all available error recovery means.

- In the export: NVME_Transactions.csv, column 39, after `FUA`; nvme_command.csv, column 16, after `FUA`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 53: Read - Command Dword 12, line 2629 of its text. Its words:

> Limited Retry (LR): If this bit is set to ‘1’, then the controller should apply limited retry efforts. If this bit


### `EILBRT`

Expected Initial Logical Block Reference Tag: the reference tag the drive should find in the protection information of the first block read. The analyzer shows command dword 14 under this name. Ignored without end-to-end protection.

- In the export: NVME_Transactions.csv, column 40, after `LR`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 51: Read - Command Dword 2 and Dword 3, line 2616 of its text. Its words:

> (EILBRT) fields, which are defined in section 5.3.1.4.1. If the namespace is not formatted to use end-to-

- Note: In nvme_command.csv the same command dword is shown as ELBTL. Verification Script Engine manual: 'EILBRT 14 31:0 Expected Initial Logical Block Reference Tag'.

### `ELBAT`

Expected Logical Block Application Tag: the application tag value the drive should find in the protection information of the blocks read. Ignored when the namespace has no end-to-end protection.

- In the export: NVME_Transactions.csv, column 41, after `EILBRT`; nvme_command.csv, column 18, after `ELBTL`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 57: Read - Command Dword 15, line 2726 of its text. Its words:

> Expected Logical Block Application Tag (ELBAT): This field specifies the Application Tag expected


### `ELBATM`

Expected Logical Block Application Tag Mask: which bits of the application tag are compared. A bit of the tag is masked, not compared, when the matching mask bit is 0. Ignored without end-to-end protection.

- In the export: NVME_Transactions.csv, column 42, after `ELBAT`; nvme_command.csv, column 19, after `ELBAT`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 57: Read - Command Dword 15, line 2723 of its text. Its words:

> Expected Logical Block Application Tag Mask (ELBATM): This field specifies the Application Tag

- Note: Masking rule: NVM Command Set Specification line 7903-7906.

### `AF`

Access Frequency: 4-bit Dataset Management hint of a Read command on how often the blocks are read and written: 0 no information, 1 typical, 2 to 5 mixes of infrequent and frequent writes and reads, 6 one-time read, 7 speculative read, 8 overwritten soon.

- In the export: NVME_Transactions.csv, column 43, after `ELBATM`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 54: Read - Command Dword 13 if CETYPE is cleared to 0h, line 2680 of its text. Its words:

> Access Frequency (AF): This field specifies the expected access frequency.

- Note: Positionally the Read group (AF, AL, SR, I follow EILBRT, ELBAT, ELBATM); the second group (AF#2 and following) belongs to Write.

### `AL`

Access Latency after AF in the NVMe transaction file: the Read hint (0 none, 1 idle, 2 normal, 3 low). Allocation Length after SECP in the command file: the amount of data a Security Receive command lets the drive return.

- In the export: NVME_Transactions.csv, column 44, after `AF`; nvme_command.csv, column 33, after `SECP`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 54: Read - Command Dword 13 if CETYPE is cleared to 0h, line 2674 of its text. Its words:

> Access Latency (AL): This field specifies the expected access latency.

- Note: Allocation Length (Security Receive, Command Dword 11): NVMe Base Specification 2.1 line 23046 and VSE manual SecurityReceive table (AL, line 2243). In NVME_Transactions.csv the same name AL also appears twice more as AL#2 (Allocation Length) and AL#3 (Access Latency of Write).

### `SR`

Sequential Request: 1 means this Read command is part of a sequential read made of several Read commands; 0 means no information on sequential access is given.

- In the export: NVME_Transactions.csv, column 45, after `AL`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 54: Read - Command Dword 13 if CETYPE is cleared to 0h, line 2671 of its text. Its words:

> Sequential Request (SEQREQ): If this bit is set to


### `I`

Incompressible: 1 means the data of the blocks read is not compressible; 0 means no information on compression is given.

- In the export: NVME_Transactions.csv, column 46, after `SR`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 54: Read - Command Dword 13 if CETYPE is cleared to 0h, line 2668 of its text. Its words:

> Incompressible (INCPRS): If this bit is set to


### `Address List`

Address List: a list of memory addresses carried by the transaction, shown after the Data cell. For a data transfer or PRP list transaction it is probably the page addresses of the data buffer.

- In the export: NVME_Transactions.csv, column 48, after `Data`.
- Source: none. No document that was read states this field; the meaning was written from knowledge of the protocol when this document was prepared.
- Note: No manual line names this column. The Verification Script Engine manual has 'in.nvmeDataAddress: Returns SGL segment or PRP entry address' (line 1879) for the transferred-data transaction. The reading is inferred from the name and position; check against a real row.

### `SPSP`

SP Specific: the Security Protocol Specific field of a Security Send or Security Receive command; its meaning depends on the security protocol (SECP) used.

- In the export: NVME_Transactions.csv, column 49, after `Address List`; nvme_command.csv, column 31, after `Warnings`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Submission Queue Entry Data table: Security Receive, line 2240 of its text. Its words:

> SPSP 10 23:8 SP Specific

- Note: Base Specification lines 23033-23037 split it into SPSP1 (bits 15:08) and SPSP0 (bits 07:00) 'as defined in SPC-5'.

### `SECP`

Security Protocol: the security protocol a Security Send or Security Receive command uses, as defined in the SCSI Primary Commands standard (SPC-5). The drive aborts the command if the value is not supported.

- In the export: NVME_Transactions.csv, column 50, after `SPSP`; nvme_command.csv, column 32, after `SPSP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 376: Security Receive - Command Dword 10, line 23030 of its text. Its words:

> Security Protocol (SECP): This field specifies the security protocol as defined in SPC-5. The controller


### `AL#2`

Allocation Length: in a Security Receive command, the amount of data the host allows the drive to return, as defined for the Security Protocol In command in the SCSI Primary Commands standard (SPC-5).

- In the export: NVME_Transactions.csv, column 51, after `SECP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 377: Security Receive - Command Dword 11, line 23046 of its text. Its words:

> Allocation Length (AL): The value of this field is specific to the Security Protocol In command with the

- Note: The matching field of Security Send is Transfer Length (TL, Figure 381).

### `LBTU`

Logical Block Tags Upper: the upper part (bits 47:00 of command dwords 2 and 3) of the Logical Block Storage Tag and Initial Logical Block Reference Tag a Write stores in protection information. Ignored without end-to-end protection.

- In the export: NVME_Transactions.csv, column 52, after `AL#2`; nvme_command.csv, column 34, after `AL`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 68: Write - Command Dword 2 and Dword 3, line 2912 of its text. Its words:

> Logical Block Tags Upper (LBTU): This field and Command Dword 14 specify the variable sized


### `ILBRT`

Initial Logical Block Reference Tag: the reference tag that goes into the protection information of the first logical block of a Write. The analyzer shows command dword 14 under this name. Ignored without end-to-end protection.

- In the export: NVME_Transactions.csv, column 53, after `LBTU`; nvme_command.csv, column 35, after `LBTU`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 68: Write - Command Dword 2 and Dword 3, line 2913 of its text. Its words:

> Logical Block Storage Tag (LBST) and Initial Logical Block Reference Tag (ILBRT) fields, which are

- Note: The specification builds the storage tag and this reference tag from command dwords 2, 3 and 14 (LBTU and LBTL); the Verification Script Engine manual lists ILBRT as Command Dword 14 of Write.

### `LBAT`

Logical Block Application Tag: the application tag value a Write puts in, and a check compares with, the protection information. Ignored when the namespace has no end-to-end protection.

- In the export: NVME_Transactions.csv, column 54, after `ILBRT`; nvme_command.csv, column 36, after `ILBRT`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 74: Write - Command Dword 15, line 3024 of its text. Its words:

> Logical Block Application Tag (LBAT): This field specifies the Application Tag value. If the namespace


### `LBATM`

Logical Block Application Tag Mask: which bits of the application tag are used. A bit of the tag is masked, not compared, when the matching mask bit is 0. Ignored without end-to-end protection.

- In the export: NVME_Transactions.csv, column 55, after `LBAT`; nvme_command.csv, column 37, after `LBAT`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 74: Write - Command Dword 15, line 3021 of its text. Its words:

> Logical Block Application Tag Mask (LBATM): This field specifies the Application Tag Mask value. If


### `AF#2`

Access Frequency: 4-bit Dataset Management hint of a Write command on how often the blocks are read and written: 0 no information, 1 typical, 2 to 5 mixes of infrequent and frequent writes and reads, 6 one-time write.

- In the export: NVME_Transactions.csv, column 56, after `LBATM`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 71: Write - Command Dword 13 if CETYPE is cleared to 0h, line 2986 of its text. Its words:

> Access Frequency (AF): This field specifies the expected access frequency.


### `AL#3`

Access Latency: 2-bit Dataset Management hint of a Write command on the expected access latency: 0 none given, 1 idle (longer latency acceptable), 2 normal, 3 low (smallest possible latency).

- In the export: NVME_Transactions.csv, column 57, after `AF#2`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 71: Write - Command Dword 13 if CETYPE is cleared to 0h, line 2980 of its text. Its words:

> Access Latency (AL): This field specifies the exected access latency.

- Note: The specification text itself reads 'exected' (typing mistake in the source).

### `SR#2`

Sequential Request: 1 means this Write command is part of a sequential write made of several Write commands; 0 means no information on sequential access is given.

- In the export: NVME_Transactions.csv, column 58, after `AL#3`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 71: Write - Command Dword 13 if CETYPE is cleared to 0h, line 2977 of its text. Its words:

> Sequential Request (SEQREQ): If this bit is set to


### `I#2`

Incompressible: 1 means the data of the blocks written is not compressible; 0 means no information on compression is given.

- In the export: NVME_Transactions.csv, column 59, after `SR#2`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 71: Write - Command Dword 13 if CETYPE is cleared to 0h, line 2974 of its text. Its words:

> Incompressible (INCPRS): If this bit is set to


### `DSPEC`

Directive Specific: the value that goes with the Directive Type of a Read or Write command (bits 31:16 of command dword 13); how it is read depends on the directive chosen.

- In the export: NVME_Transactions.csv, column 60, after `I#2`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 71: Write - Command Dword 13 if CETYPE is cleared to 0h, line 2959 of its text. Its words:

> Directive Specific (DSPEC): Specifies the Directive Specific value associated with the Directive Type


### `Errors`

Errors: the errors the analyzer found in this NVMe transaction or command, for example a reserved field that is not zero, a missing step, a logical error or a queue error. One cell per row.

- In the export: NVME_Transactions.csv, column 61, after `DSPEC`; nvme_command.csv, column 44, after `DSM.DSPEC`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), 5.2.12 NVM transaction-specific set of members, line 1699 of its text. Its words:

> in.nvmeTraHasError: If set to a non-zero value, indicates NVME transaction has errors.

- Note: Error kinds: Summit Z5 manual 'Types of NVMe Errors' (line 13480 on). The real header cell has no label; the application names it Errors (the real text is like '1 error(s)'). For commands the matching member is in.nvmcTraHasError (line 2033).

### `CNS`

Controller or Namespace Structure: the code in an Identify command that says which data structure the drive returns, for example the controller, one namespace or a list of namespaces.

- In the export: NVME_Transactions.csv, column 62, after `Errors`; nvme_command.csv, column 45, after `Errors`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 307: Identify - Command Dword 10, line 18465 of its text. Its words:

> Controller or Namespace Structure (CNS): This field specifies the information to be returned to the


### `CNTID`

Controller Identifier: in an Identify command, the controller that some Identify operations apply to. For operations that do not use it, it is 0.

- In the export: NVME_Transactions.csv, column 63, after `CNS`; nvme_command.csv, column 46, after `CNS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 307: Identify - Command Dword 10, line 18455 of its text. Its words:

> Controller Identifier (CNTID): This field specifies the controller identifier used as part of some Identify


### `CNS Specific Identifier`

CNS Specific Identifier: an Identify command field whose meaning depends on the CNS value, for example an NVM set or endurance group identifier. Reserved when the CNS value does not define it.

- In the export: NVME_Transactions.csv, column 64, after `CNTID`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 308: Identify - Command Dword 11, line 18478 of its text. Its words:

> CNS Specific Identifier (CNSSID): This field is dependent on the specified CNS value and if not defined


### `CSI`

Command Set Identifier: selects the I/O command set (for example the NVM command set) an Identify command refers to, for the CNS values that need it; 0 otherwise.

- In the export: NVME_Transactions.csv, column 65, after `CNS Specific Identifier`; nvme_command.csv, column 47, after `CNTID`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 308: Identify - Command Dword 11, line 18472 of its text. Its words:

> Command Set Identifier (CSI): This field is CNS value specific. This field specifies the I/O Command

- Note: In nvme_command.csv there is a second column of this kind, CSI#2, after UUID_IDX.

### `UUID_IDX`

UUID Index: a number from 1 to 127 that picks a UUID from the drive's UUID list, so the command uses that vendor's specific information. 0 means no UUID is specified.

- In the export: NVME_Transactions.csv, column 66, after `CSI`; nvme_command.csv, column 48, after `CSI`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 658: UUID Index Field, line 35616 of its text. Its words:

> UUID Index (UIDX): If this field is set to a non-zero value, then the value of this field is the index


### `CSID`

Probably a second Command Set Identifier, which selects the I/O command set (for example the NVM command set) the command refers to. It follows the UUID index in the Identify fields.

- In the export: NVME_Transactions.csv, column 67, after `UUID_IDX`.
- Source: none. No document that was read states this field; the meaning was written from knowledge of the protocol when this document was prepared.
- Note: The abbreviation CSID is not in any source. It is read as Command Set Identifier from CSI (NVMe Base Specification line 18472) and its position after UUID_IDX; in nvme_command.csv the matching position is named CSI#2. Not confirmed.

### `Controller Capabilities`

Controller Capabilities and Features: heading of the first group of fields in the Identify Controller data, the structure the drive returns about itself. The columns after it, VID to IEEE, give vendor identifiers, serial and model number, firmware revision, arbitration burst, company identifier.

- In the export: NVME_Transactions.csv, column 68, after `CSID`; nvme_command.csv, column 50, after `CSI#2`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, group heading, line 18672 of its text. Its words:

> Controller Capabilities and Features

- Note: Heading as printed in the specification figure. That the export puts VID to IEEE under it is read from the column order, not stated in a source.

### `Controller Capabilities.VID`

PCI Vendor ID: the company identifier, assigned by the PCI standards body, of the drive's vendor, in the Identify Controller data. It is the same value as the vendor ID in the drive's PCI configuration header.

- In the export: NVME_Transactions.csv, column 69, after `Controller Capabilities`; nvme_command.csv, column 51, after `Controller Capabilities`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, bytes 01:00, line 18673 of its text. Its words:

> PCI Vendor ID (VID): Contains the company vendor identifier


### `Controller Capabilities.SSVID`

PCI Subsystem Vendor ID: the company identifier, assigned by the PCI standards body, of the subsystem vendor, in the Identify Controller data. It is the same value as the subsystem vendor register in the drive's PCI header.

- In the export: NVME_Transactions.csv, column 70, after `Controller Capabilities.VID`; nvme_command.csv, column 52, after `Controller Capabilities.VID`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, bytes 03:02, line 18676 of its text. Its words:

> PCI Subsystem Vendor ID (SSVID): Contains the company vendor identifier


### `Controller Capabilities.SN`

Serial Number: the vendor-assigned serial number of the NVM subsystem (the drive), a 20-character text string in the Identify Controller data.

- In the export: NVME_Transactions.csv, column 71, after `Controller Capabilities.SSVID`; nvme_command.csv, column 53, after `Controller Capabilities.SSVID`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, bytes 23:04, line 18679 of its text. Its words:

> Serial Number (SN): Contains the serial number for the NVM subsystem


### `Controller Capabilities.MN`

Model Number: the vendor-assigned model number of the NVM subsystem (the drive), a 40-character text string in the Identify Controller data.

- In the export: NVME_Transactions.csv, column 72, after `Controller Capabilities.SN`; nvme_command.csv, column 54, after `Controller Capabilities.SN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, bytes 63:24, line 18685 of its text. Its words:

> Model Number (MN): Contains the model number for the NVM subsystem


### `Controller Capabilities.FR`

Firmware Revision: the revision of the firmware currently active on the drive, an 8-character text string in the Identify Controller data. The Get Log Page command can return the same revision.

- In the export: NVME_Transactions.csv, column 73, after `Controller Capabilities.MN`; nvme_command.csv, column 55, after `Controller Capabilities.MN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, bytes 71:64, line 18693 of its text. Its words:

> Firmware Revision (FR): Contains the currently active firmware revision


### `Controller Capabilities.RAB`

Recommended Arbitration Burst: how many commands the controller recommends taking from one queue per arbitration turn, stored as a power of two (value n means 2 to the power n commands). Identify Controller data.

- In the export: NVME_Transactions.csv, column 74, after `Controller Capabilities.FR`; nvme_command.csv, column 56, after `Controller Capabilities.FR`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, byte 72, line 18698 of its text. Its words:

> Recommended Arbitration Burst (RAB): This is the recommended Arbitration Burst


### `Controller Capabilities.IEEE`

IEEE OUI Identifier: the 3-byte Organizationally Unique Identifier, assigned by the IEEE registration authority, of the controller's vendor, in the Identify Controller data.

- In the export: NVME_Transactions.csv, column 75, after `Controller Capabilities.RAB`; nvme_command.csv, column 57, after `Controller Capabilities.RAB`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, bytes 75:73, line 18701 of its text. Its words:

> IEEE OUI Identifier (IEEE): Contains the Organization Unique Identifier (OUI) for the


### `CMIC`

Controller Multi-Path I/O and Namespace Sharing Capabilities: one-byte field of the Identify Controller data saying whether the drive's subsystem may have several ports or controllers and reports asymmetric namespace access. The next four columns are its bits.

- In the export: NVME_Transactions.csv, column 76, after `Controller Capabilities.IEEE`; nvme_command.csv, column 58, after `Controller Capabilities.IEEE`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, byte 76, line 18704 of its text. Its words:

> Controller Multi-Path I/O and Namespace Sharing Capabilities (CMIC): This field

- Note: The columns MDTS to RTD3E that follow are separate Identify Controller fields (bytes 77 to 91); the export lists them under this header.

### `CMIC.MPORTS`

Multiple Ports, bit 0 of Controller Multi-Path I/O and Namespace Sharing Capabilities: 1 means the NVM subsystem may contain more than one subsystem port; 0 means it has a single port.

- In the export: NVME_Transactions.csv, column 77, after `CMIC`; nvme_command.csv, column 59, after `CMIC`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, CMIC bit 0, line 18722 of its text. Its words:

> Multiple Ports (MPORTS): If this bit is set to


### `CMIC.MCTRS`

Multiple Controllers, bit 1 of Controller Multi-Path I/O and Namespace Sharing Capabilities: 1 means the NVM subsystem may contain two or more controllers; 0 means it contains a single controller.

- In the export: NVME_Transactions.csv, column 78, after `CMIC.MPORTS`; nvme_command.csv, column 60, after `CMIC.MPORTS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, CMIC bit 1, line 18717 of its text. Its words:

> Multiple Controllers (MCTRS): If this bit is set to


### `CMIC.FT`

Function Type, bit 2 of Controller Multi-Path I/O and Namespace Sharing Capabilities: 1 means the controller belongs to a virtual function of the PCI device (SR-IOV); 0 means a PCI function or a Fabrics connection.

- In the export: NVME_Transactions.csv, column 79, after `CMIC.MCTRS`; nvme_command.csv, column 61, after `CMIC.MCTRS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, CMIC bit 2, line 18714 of its text. Its words:

> Function Type (FT): If this bit is set to


### `CMIC.ANARS`

Asymmetric Namespace Access Reporting Support, bit 3 of Controller Multi-Path I/O and Namespace Sharing Capabilities: 1 means the NVM subsystem supports asymmetric namespace access reporting; 0 means it does not.

- In the export: NVME_Transactions.csv, column 80, after `CMIC.FT`; nvme_command.csv, column 62, after `CMIC.FT`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, CMIC bit 3, line 18709 of its text. Its words:

> Asymmetric Namespace Access Reporting Support (ANARS): If this bit is


### `CMIC.MDTS`

Maximum Data Transfer Size: the largest transfer one command may make between host memory and the drive, in units of the minimum memory page size, stored as a power of two. 0 means no limit. Larger commands are aborted.

- In the export: NVME_Transactions.csv, column 81, after `CMIC.ANARS`; nvme_command.csv, column 63, after `CMIC.ANARS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, byte 77, line 18738 of its text. Its words:

> Maximum Data Transfer Size (MDTS): This field indicates the maximum data transfer

- Note: A separate one-byte field of the Identify Controller data, not a bit of CMIC; the export lists it under the CMIC header.

### `CMIC.CNTLID`

Controller ID: the identifier, unique within the NVM subsystem, of the controller that answered, a 16-bit number in the Identify Controller data.

- In the export: NVME_Transactions.csv, column 82, after `CMIC.MDTS`; nvme_command.csv, column 64, after `CMIC.MDTS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, bytes 79:78, line 18757 of its text. Its words:

> Controller ID (CNTLID): Contains the NVM subsystem unique controller identifier

- Note: A separate field of the Identify Controller data, not a bit of CMIC; the export lists it under the CMIC header.

### `CMIC.VER`

Version: the NVMe specification version the controller reports, the same value as the controller's Version property. Controllers following specification 1.2 or later report a non-zero value.

- In the export: NVME_Transactions.csv, column 83, after `CMIC.CNTLID`; nvme_command.csv, column 65, after `CMIC.CNTLID`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, bytes 83:80, line 18760 of its text. Its words:

> Version (VER): This field contains the value reported in the Version property

- Note: A separate field of the Identify Controller data, not a bit of CMIC; the export lists it under the CMIC header.

### `CMIC.RTD3R`

Runtime D3 Resume Latency: the expected time, in microseconds, for the drive to resume from the PCI Express Runtime D3 power state. 0 means the latency is not reported.

- In the export: NVME_Transactions.csv, column 84, after `CMIC.VER`; nvme_command.csv, column 66, after `CMIC.VER`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, bytes 87:84, line 18763 of its text. Its words:

> RTD3 Resume Latency (RTD3R): This field indicates the expected latency in

- Note: A separate field of the Identify Controller data, not a bit of CMIC; the export lists it under the CMIC header.

### `CMIC.RTD3E`

Runtime D3 Entry Latency: the typical time, in microseconds, for the drive to enter the PCI Express Runtime D3 power state. 0 means the latency is not reported.

- In the export: NVME_Transactions.csv, column 85, after `CMIC.RTD3R`; nvme_command.csv, column 67, after `CMIC.RTD3R`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, bytes 91:88, line 18766 of its text. Its words:

> RTD3 Entry Latency (RTD3E): This field indicates the typical latency in microseconds

- Note: A separate field of the Identify Controller data, not a bit of CMIC; the export lists it under the CMIC header.

### `OAES`

Optional Asynchronous Events Supported: four-byte field of the Identify Controller data saying which optional asynchronous events the controller can send to the host. The next nine columns are its bits.

- In the export: NVME_Transactions.csv, column 86, after `CMIC.RTD3E`; nvme_command.csv, column 68, after `CMIC.RTD3E`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, bytes 95:92, line 18769 of its text. Its words:

> Optional Asynchronous Events Supported (OAES): This field indicates the optional


### `OAES.NSAN`

Attached Namespace Attribute Notices, bit 8 of Optional Asynchronous Events Supported: 1 means the controller supports that event and the Changed Attached Namespace List log page; 0 means not.

- In the export: NVME_Transactions.csv, column 87, after `OAES`; nvme_command.csv, column 69, after `OAES`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, OAES field, bit 8, line 18851 of its text. Its words:

> Attached Namespace Attribute Notices (NSAN): If this bit is set to


### `OAES.FAN`

Firmware Activation Notices, bit 9 of Optional Asynchronous Events Supported: 1 means the controller supports the Firmware Activation Notices event; 0 means it does not.

- In the export: NVME_Transactions.csv, column 88, after `OAES.NSAN`; nvme_command.csv, column 70, after `OAES.NSAN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, OAES field, bit 9, line 18846 of its text. Its words:

> Firmware Activation Notices (FAN): If this bit is set to


### `OAES.ANACN`

Asymmetric Namespace Access Change Notices, bit 11 of Optional Asynchronous Events Supported: 1 means the controller supports sending those notices; 0 means it does not.

- In the export: NVME_Transactions.csv, column 89, after `OAES.FAN`; nvme_command.csv, column 71, after `OAES.FAN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, OAES field, bit 11, line 18840 of its text. Its words:

> Asymmetric Namespace Access Change Notices (ANACN): If this bit


### `OAES.PLEAN`

Predictable Latency Event Aggregate Log Change Notices, bit 12 of Optional Asynchronous Events Supported: 1 means the controller supports that event; 0 means it does not.

- In the export: NVME_Transactions.csv, column 90, after `OAES.ANACN`; nvme_command.csv, column 72, after `OAES.ANACN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, OAES field, bit 12, line 18835 of its text. Its words:

> Predictable Latency Event Aggregate Log Change Notices (PLEAN):


### `OAES.LSIAN`

LBA Status Information Alert Notices, bit 13 of Optional Asynchronous Events Supported: 1 means the controller supports that event; 0 means it does not.

- In the export: NVME_Transactions.csv, column 91, after `OAES.PLEAN`; nvme_command.csv, column 73, after `OAES.PLEAN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, OAES field, bit 13, line 18830 of its text. Its words:

> LBA Status Information Alert Notices (LSIAN): If this bit is set to


### `OAES.EGEAN`

Endurance Group Event Aggregate Log Page Change Notices, bit 14 of Optional Asynchronous Events Supported: 1 means the controller supports that event; 0 means it does not.

- In the export: NVME_Transactions.csv, column 92, after `OAES.LSIAN`; nvme_command.csv, column 74, after `OAES.LSIAN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, OAES field, bit 14, line 18825 of its text. Its words:

> Endurance Group Event Aggregate Log Page Change Notices


### `OAES.NNSS`

Normal NVM Subsystem Shutdown, bit 15 of Optional Asynchronous Events Supported: 1 means the controller supports the Normal NVM Subsystem Shutdown event; 0 means it does not. No log page goes with it.

- In the export: NVME_Transactions.csv, column 93, after `OAES.EGEAN`; nvme_command.csv, column 75, after `OAES.EGEAN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, OAES field, bit 15, line 18820 of its text. Its words:

> Normal NVM Subsystem Shutdown (NNSS): If this bit is set to


### `OAES.ZDCN`

Zone Descriptor Changed Notices, bit 27 of Optional Asynchronous Events Supported: 1 means the controller supports that event and the Changed Zone List log page; 0 means not.

- In the export: NVME_Transactions.csv, column 94, after `OAES.NNSS`; nvme_command.csv, column 76, after `OAES.NNSS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, OAES field, bit 27, line 18779 of its text. Its words:

> Zone Descriptor Changed Notices (ZDCN): If this bit is set to


### `OAES.DLPCN`

Discovery Log Page Change Notification, bit 31 of Optional Asynchronous Events Supported: 1 means the controller supports sending Discovery Log Page Change Notifications; 0 means it does not.

- In the export: NVME_Transactions.csv, column 95, after `OAES.ZDCN`; nvme_command.csv, column 77, after `OAES.ZDCN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, OAES field, bit 31, line 18773 of its text. Its words:

> Discovery Log Page Change Notification (DLPCN): If this bit is set to


### `CTRATT`

Controller Attributes: four-byte field of the Identify Controller data listing attributes of the controller, one per bit (for example host identifier, NVM Sets, Endurance Groups). The next 16 columns are its bits, followed by separate fields.

- In the export: NVME_Transactions.csv, column 96, after `OAES.DLPCN`; nvme_command.csv, column 78, after `OAES.DLPCN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, bytes 99:96, line 18859 of its text. Its words:

> Controller Attributes (CTRATT): This field indicates attributes of the controller.

- Note: The columns RRLS to CRDT3 that follow are separate Identify Controller fields (bytes 101:100, 111, 127:112, 133:128); the export lists them under this header.

### `CTRATT.HIS`

Host Identifier Support, bit 0 of Controller Attributes: 1 means the controller supports a 128-bit Host Identifier; 0 means it does not.

- In the export: NVME_Transactions.csv, column 97, after `CTRATT`; nvme_command.csv, column 79, after `CTRATT`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, CTRATT field, bit 0, line 19018 of its text. Its words:

> Host Identifier Support (HIDS): If this bit is set to

- Note: The export shortens the specification's name HIDS to HIS; matched by meaning and bit order (first bit).

### `CTRATT.NOPSPM`

Non-Operational Power State Permissive Mode, bit 1 of Controller Attributes: 1 means the host can control whether the controller may briefly exceed a non-operational power state's power for background work; 0 means not supported.

- In the export: NVME_Transactions.csv, column 98, after `CTRATT.HIS`; nvme_command.csv, column 80, after `CTRATT.HIS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, CTRATT field, bit 1, line 19007 of its text. Its words:

> Non-Operational Power State Permissive Mode (NOPSPM): If this bit is


### `CTRATT.NVMS`

NVM Sets, bit 2 of Controller Attributes: 1 means the controller supports NVM Sets (collections of storage kept separate from other sets); 0 means it does not.

- In the export: NVME_Transactions.csv, column 99, after `CTRATT.NOPSPM`; nvme_command.csv, column 81, after `CTRATT.NOPSPM`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, CTRATT field, bit 2, line 18991 of its text. Its words:

> NVM Sets (NSETS): If this bit is set to

- Note: The export's name NVMS is the specification's NSETS (NVM Sets); matched by meaning and bit order.

### `CTRATT.RRL`

Read Recovery Levels, bit 3 of Controller Attributes: 1 means the controller supports Read Recovery Levels (16 levels of how much read error recovery it attempts); 0 means it does not.

- In the export: NVME_Transactions.csv, column 100, after `CTRATT.NVMS`; nvme_command.csv, column 82, after `CTRATT.NVMS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, CTRATT field, bit 3, line 18988 of its text. Its words:

> Read Recovery Levels (RRLVLS): If this bit is set to

- Note: The export's name RRL is the specification's RRLVLS; matched by meaning and bit order.

### `CTRATT.EG`

Endurance Groups, bit 4 of Controller Attributes: 1 means the controller supports Endurance Groups (groups of storage whose wear is managed together); 0 means it does not.

- In the export: NVME_Transactions.csv, column 101, after `CTRATT.RRL`; nvme_command.csv, column 83, after `CTRATT.RRL`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, CTRATT field, bit 4, line 18985 of its text. Its words:

> Endurance Groups (EGS): If this bit is set to

- Note: The export's name EG is the specification's EGS; matched by meaning and bit order.

### `CTRATT.PLM`

Predictable Latency Mode, bit 5 of Controller Attributes: 1 means the controller supports Predictable Latency Mode; 0 means it does not.

- In the export: NVME_Transactions.csv, column 102, after `CTRATT.EG`; nvme_command.csv, column 84, after `CTRATT.EG`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, CTRATT field, bit 5, line 18980 of its text. Its words:

> Predictable Latency Mode (PLM): If this bit is set to


### `CTRATT.TBKAS`

Traffic Based Keep Alive Support, bit 6 of Controller Attributes: 1 means the controller uses Traffic Based Keep Alive; 0 means it does not.

- In the export: NVME_Transactions.csv, column 103, after `CTRATT.PLM`; nvme_command.csv, column 85, after `CTRATT.PLM`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, CTRATT field, bit 6, line 18975 of its text. Its words:

> Traffic Based Keep Alive Support (TBKAS): If this bit is set to


### `CTRATT.NG`

Namespace Granularity, bit 7 of Controller Attributes: 1 means the controller supports reporting of Namespace Granularity; 0 means it does not. It is 0 when namespace management is unsupported.

- In the export: NVME_Transactions.csv, column 104, after `CTRATT.TBKAS`; nvme_command.csv, column 86, after `CTRATT.TBKAS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, CTRATT field, bit 7, line 18970 of its text. Its words:

> Namespace Granularity (NG): If this bit is set to


### `CTRATT.SQA`

SQ Associations, bit 8 of Controller Attributes: 1 means the controller supports submission queue associations; 0 means it does not.

- In the export: NVME_Transactions.csv, column 105, after `CTRATT.NG`; nvme_command.csv, column 87, after `CTRATT.NG`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, CTRATT field, bit 8, line 18967 of its text. Its words:

> SQ Associations (SQA): If this bit is set to


### `CTRATT.UUIDL`

UUID List, bit 9 of Controller Attributes: 1 means the controller supports reporting a list of UUIDs (universally unique identifiers); 0 means it does not.

- In the export: NVME_Transactions.csv, column 106, after `CTRATT.SQA`; nvme_command.csv, column 88, after `CTRATT.SQA`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, CTRATT field, bit 9, line 18962 of its text. Its words:

> UUID List (ULIST): If this bit is set to

- Note: The export's name UUIDL is the specification's ULIST (UUID List); matched by meaning and bit order.

### `CTRATT.MDS`

Multi-Domain Subsystem, bit 10 of Controller Attributes: 1 means the NVM subsystem supports multiple domains; 0 means it reports no multiple domains and is a single domain.

- In the export: NVME_Transactions.csv, column 107, after `CTRATT.UUIDL`; nvme_command.csv, column 89, after `CTRATT.UUIDL`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, CTRATT field, bit 10, line 18957 of its text. Its words:

> Multi-Domain Subsystem (MDS): If this bit is set to


### `CTRATT.FCM`

Fixed Capacity Management, bit 11 of Controller Attributes: 1 means the controller supports Fixed Capacity Management; 0 means it does not.

- In the export: NVME_Transactions.csv, column 108, after `CTRATT.MDS`; nvme_command.csv, column 90, after `CTRATT.MDS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, CTRATT field, bit 11, line 18951 of its text. Its words:

> Fixed Capacity Management (FCM): If this bit is set to


### `CTRATT.VCM`

Variable Capacity Management, bit 12 of Controller Attributes: 1 means the controller supports Variable Capacity Management; 0 means it does not.

- In the export: NVME_Transactions.csv, column 109, after `CTRATT.FCM`; nvme_command.csv, column 91, after `CTRATT.FCM`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, CTRATT field, bit 12, line 18946 of its text. Its words:

> Variable Capacity Management (VCM): If this bit is set to


### `CTRATT.DEG`

Delete Endurance Group, bit 13 of Controller Attributes: 1 means the controller supports the Delete Endurance Group operation; 0 means it does not.

- In the export: NVME_Transactions.csv, column 110, after `CTRATT.VCM`; nvme_command.csv, column 92, after `CTRATT.VCM`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, CTRATT field, bit 13, line 18941 of its text. Its words:

> Delete Endurance Group (DEG): If this bit is set to


### `CTRATT.DNVMS`

Delete NVM Set, bit 14 of Controller Attributes: 1 means the controller supports the Delete NVM Set operation; 0 means it does not.

- In the export: NVME_Transactions.csv, column 111, after `CTRATT.DEG`; nvme_command.csv, column 93, after `CTRATT.DEG`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, CTRATT field, bit 14, line 18923 of its text. Its words:

> Delete NVM Set (DNVMS): If this bit is set to


### `CTRATT.ELBAS`

Extended LBA Formats Supported, bit 15 of Controller Attributes: 1 means the controller supports the extended protection information formats of the I/O command set; 0 means it does not.

- In the export: NVME_Transactions.csv, column 112, after `CTRATT.DNVMS`; nvme_command.csv, column 94, after `CTRATT.DNVMS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, CTRATT field, bit 15, line 18909 of its text. Its words:

> Extended LBA Formats Supported (ELBAS): If this bit is set to


### `CTRATT.RRLS`

Read Recovery Levels Supported: 16-bit field of the Identify Controller data; each set bit means that read recovery level (0 to 15) is supported. Present only when Read Recovery Levels are supported.

- In the export: NVME_Transactions.csv, column 113, after `CTRATT.ELBAS`; nvme_command.csv, column 95, after `CTRATT.ELBAS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, bytes 101:100, line 19021 of its text. Its words:

> Read Recovery Levels Supported (RRLS): If Read Recovery Levels (RRL) are

- Note: A separate field, not a bit of CTRATT; the export lists it under the CTRATT header.

### `CTRATT.CNTRLTYPE`

Controller Type: what kind of controller answered, in the Identify Controller data. 1 means I/O controller, 2 Discovery controller, 3 Administrative controller; 0 means not reported.

- In the export: NVME_Transactions.csv, column 114, after `CTRATT.RRLS`; nvme_command.csv, column 96, after `CTRATT.RRLS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, byte 111, line 19125 of its text. Its words:

> Controller Type (CNTRLTYPE): This field specifies the controller type.

- Note: A separate field, not a bit of CTRATT; the export lists it under the CTRATT header.

### `CTRATT.FGUID`

FRU Globally Unique Identifier: a 128-bit value that identifies the field replaceable unit (FRU, a part swappable in the field) worldwide and stays fixed for its life. 0 when not implemented.

- In the export: NVME_Transactions.csv, column 115, after `CTRATT.CNTRLTYPE`; nvme_command.csv, column 97, after `CTRATT.CNTRLTYPE`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, bytes 127:112, line 19138 of its text. Its words:

> FRU Globally Unique Identifier (FGUID): This field contains a 128-bit value that is

- Note: A separate field, not a bit of CTRATT; the export lists it under the CTRATT header.

### `CTRATT.CRDT1`

Command Retry Delay Time 1: the retry delay, in units of 100 milliseconds, the host should wait when a command completes with Do Not Retry cleared and Command Retry Delay set to 01b.

- In the export: NVME_Transactions.csv, column 116, after `CTRATT.FGUID`; nvme_command.csv, column 98, after `CTRATT.FGUID`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, bytes 129:128, line 19151 of its text. Its words:

> Command Retry Delay Time 1 (CRDT1): If the Do Not Retry (DNR) bit is cleared to

- Note: A separate field, not a bit of CTRATT; the export lists it under the CTRATT header.

### `CTRATT.CRDT2`

Command Retry Delay Time 2: the retry delay, in units of 100 milliseconds, the host should wait when a command completes with Do Not Retry cleared and Command Retry Delay set to 10b.

- In the export: NVME_Transactions.csv, column 117, after `CTRATT.CRDT1`; nvme_command.csv, column 99, after `CTRATT.CRDT1`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, bytes 131:130, line 19154 of its text. Its words:

> Command Retry Delay Time 2 (CRDT2): If the DNR bit is cleared to

- Note: A separate field, not a bit of CTRATT; the export lists it under the CTRATT header.

### `CTRATT.CRDT3`

Command Retry Delay Time 3: the retry delay, in units of 100 milliseconds, the host should wait when a command completes with Do Not Retry cleared and Command Retry Delay set to 11b.

- In the export: NVME_Transactions.csv, column 118, after `CTRATT.CRDT2`; nvme_command.csv, column 100, after `CTRATT.CRDT2`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, bytes 133:132, line 19157 of its text. Its words:

> Command Retry Delay Time 3 (CRDT3): If the DNR bit is cleared to

- Note: A separate field, not a bit of CTRATT; the export lists it under the CTRATT header.

### `NVMe-Mi Data`

NVMe Management Interface data: group of three one-byte fields at the end of the Identify Controller data (NVM Subsystem Report, VPD Write Cycle Information, Management Endpoint Capabilities) used by the NVMe Management Interface. The next six columns are their parts.

- In the export: NVME_Transactions.csv, column 119, after `CTRATT.CRDT3`; nvme_command.csv, column 101, after `CTRATT.CRDT3`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, bytes 253 to 255, line 19192 of its text. Its words:

> NVM Subsystem Report (NVMSR): This field reports information associated with the

- Note: The group name NVMe-Mi Data is the software's; the specification names the three fields and refers to the NVM Express Management Interface Specification. Grouping inferred from the column order.

### `NVMe-Mi Data.NVMESD`

NVMe Storage Device, bit 0 of NVM Subsystem Report: 1 means the NVM subsystem is part of an NVMe Storage Device; 0 means it is not.

- In the export: NVME_Transactions.csv, column 120, after `NVMe-Mi Data`; nvme_command.csv, column 102, after `NVMe-Mi Data`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, NVMSR bit 0, byte 253, line 19204 of its text. Its words:

> NVMe Storage Device (NVMESD): If this bit is set to


### `NVMe-Mi Data.NVMEE`

NVMe Enclosure, bit 1 of NVM Subsystem Report: 1 means the NVM subsystem is part of an NVMe Enclosure; 0 means it is not.

- In the export: NVME_Transactions.csv, column 121, after `NVMe-Mi Data.NVMESD`; nvme_command.csv, column 103, after `NVMe-Mi Data.NVMESD`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, NVMSR bit 1, byte 253, line 19201 of its text. Its words:

> NVMe Enclosure (NVMEE): If this bit is set to


### `NVMe-Mi Data.VWCR`

VPD Write Cycles Remaining: how many more times the vital product data can be rewritten with the VPD Write command, in units of 256 bytes (7Fh means 7Fh or more). Valid only when the Remaining Valid bit is 1.

- In the export: NVME_Transactions.csv, column 122, after `NVMe-Mi Data.NVMEE`; nvme_command.csv, column 104, after `NVMe-Mi Data.NVMEE`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, VWCI bits 6:0, byte 254, line 19216 of its text. Its words:

> VPD Write Cycles Remaining (VWCR): If the VPD Write Cycle Remaining


### `NVMe-Mi Data.VWCRV`

VPD Write Cycles Remaining Valid, bit 7 of VPD Write Cycle Information: 1 means the VPD Write Cycles Remaining value is valid; 0 means it is invalid and cleared to 0.

- In the export: NVME_Transactions.csv, column 123, after `NVMe-Mi Data.VWCR`; nvme_command.csv, column 105, after `NVMe-Mi Data.VWCR`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, VWCI bit 7, byte 254, line 19213 of its text. Its words:

> VPD Write Cycles Remaining Valid (VWCRV): If this bit is set to


### `NVMe-Mi Data.PCIEME`

PCIe Port Management Endpoint, bit 1 of Management Endpoint Capabilities: 1 means the NVM subsystem has one or more management endpoints on PCI Express ports; 0 means none.

- In the export: NVME_Transactions.csv, column 124, after `NVMe-Mi Data.VWCRV`; nvme_command.csv, column 106, after `NVMe-Mi Data.VWCRV`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, MEC bit 1, byte 255, line 19232 of its text. Its words:

> PCIe Port Management Endpoint (PCIEME): If the NVM subsystem contains


### `NVMe-Mi Data.SMBUSME`

SMBus/I2C Port Management Endpoint, bit 0 of Management Endpoint Capabilities: 1 means the NVM subsystem has one or more management endpoints on the 2-wire (SMBus/I2C) port; 0 means none.

- In the export: NVME_Transactions.csv, column 125, after `NVMe-Mi Data.PCIEME`; nvme_command.csv, column 107, after `NVMe-Mi Data.PCIEME`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, MEC bit 0, byte 255, line 19238 of its text. Its words:

> This bit was formerly named SMBus/I2C Port Management Endpoint

- Note: In specification 2.1 this bit is renamed 2-Wire Port Management Endpoint (TWPME); the export keeps the old name.

### `Admin CS Attributes`

Admin Command Set Attributes and Optional Controller Capabilities: heading of the group of Identify Controller fields about optional Admin commands and limits. The next columns, starting with Optional Admin Command Support, belong to it.

- In the export: NVME_Transactions.csv, column 126, after `NVMe-Mi Data.SMBUSME`; nvme_command.csv, column 108, after `NVMe-Mi Data.SMBUSME`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, group heading, line 19240 of its text. Its words:

> Admin Command Set Attributes & Optional Controller Capabilities

- Note: Heading as printed in the specification figure (CS = Command Set). The specification group also covers firmware, log page and power fields that come after AERL; the export's exact extent is not stated in a source.

### `OACS`

Optional Admin Command Support: two-byte field of the Identify Controller data saying which optional Admin commands and features the controller supports. The next 11 columns, SSRS to CFLS, are its bits.

- In the export: NVME_Transactions.csv, column 127, after `Admin CS Attributes`; nvme_command.csv, column 109, after `Admin CS Attributes`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, bytes 257:256, line 19241 of its text. Its words:

> Optional Admin Command Support (OACS): This field indicates the optional Admin

- Note: ACL and AERL, listed after CFLS, are separate Identify Controller fields that the export lists under this header.

### `OACS.SSRS`

Security Send Receive Supported, bit 0 of Optional Admin Command Support: 1 means the controller supports the Security Send and Security Receive commands; 0 means it does not.

- In the export: NVME_Transactions.csv, column 128, after `OACS`; nvme_command.csv, column 110, after `OACS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, OACS field, bit 0, line 19312 of its text. Its words:

> Security Send Receive Supported (SSRS): If this bit is set to


### `OACS.FNVMS`

Format NVM Supported, bit 1 of Optional Admin Command Support: 1 means the controller supports the Format NVM command; 0 means it does not.

- In the export: NVME_Transactions.csv, column 129, after `OACS.SSRS`; nvme_command.csv, column 111, after `OACS.SSRS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, OACS field, bit 1, line 19309 of its text. Its words:

> Format NVM Supported (FNVMS): If this bit is set to


### `OACS.FWDS`

Firmware Download Supported, bit 2 of Optional Admin Command Support: 1 means the controller supports the Firmware Commit and Firmware Image Download commands; 0 means it does not.

- In the export: NVME_Transactions.csv, column 130, after `OACS.FNVMS`; nvme_command.csv, column 112, after `OACS.FNVMS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, OACS field, bit 2, line 19304 of its text. Its words:

> Firmware Download Supported (FWDS): If this bit is set to


### `OACS.NMS`

Namespace Management Supported, bit 3 of Optional Admin Command Support: 1 means the controller supports the Namespace Management capability (creating and deleting namespaces); 0 means it does not.

- In the export: NVME_Transactions.csv, column 131, after `OACS.FWDS`; nvme_command.csv, column 113, after `OACS.FWDS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, OACS field, bit 3, line 19299 of its text. Its words:

> Namespace Management Supported (NMS): If this bit is set to


### `OACS.DSTS`

Device Self-test Supported, bit 4 of Optional Admin Command Support: 1 means the controller supports the Device Self-test command; 0 means it does not.

- In the export: NVME_Transactions.csv, column 132, after `OACS.NMS`; nvme_command.csv, column 114, after `OACS.NMS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, OACS field, bit 4, line 19296 of its text. Its words:

> Device Self-test Supported (DSTS): If this bit is set to


### `OACS.DIRS`

Directives Supported, bit 5 of Optional Admin Command Support: 1 means the controller supports Directives, including the Directive Send and Directive Receive commands; 0 means it does not.

- In the export: NVME_Transactions.csv, column 133, after `OACS.DSTS`; nvme_command.csv, column 115, after `OACS.DSTS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, OACS field, bit 5, line 19291 of its text. Its words:

> Directives Supported (DIRS): If this bit is set to


### `OACS.NSRS`

NVMe-MI Send Receive Supported, bit 6 of Optional Admin Command Support: 1 means the controller supports the NVMe-MI Send and NVMe-MI Receive commands; 0 means it does not.

- In the export: NVME_Transactions.csv, column 134, after `OACS.DIRS`; nvme_command.csv, column 116, after `OACS.DIRS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, OACS field, bit 6, line 19286 of its text. Its words:

> NVMe-MI Send Receive Supported (NSRS): If this bit is set to


### `OACS.VMS`

Virtualization Management Supported, bit 7 of Optional Admin Command Support: 1 means the controller supports the Virtualization Management command; 0 means it does not.

- In the export: NVME_Transactions.csv, column 135, after `OACS.NSRS`; nvme_command.csv, column 117, after `OACS.NSRS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, OACS field, bit 7, line 19281 of its text. Its words:

> Virtualization Management Supported (VMS): If this bit is set to


### `OACS.DBCS`

Doorbell Buffer Config Supported, bit 8 of Optional Admin Command Support: 1 means the controller supports the Doorbell Buffer Config command; 0 means it does not.

- In the export: NVME_Transactions.csv, column 136, after `OACS.VMS`; nvme_command.csv, column 118, after `OACS.VMS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, OACS field, bit 8, line 19276 of its text. Its words:

> Doorbell Buffer Config Supported (DBCS): If this bit is set to


### `OACS.GLSS`

Get LBA Status Supported, bit 9 of Optional Admin Command Support: 1 means the controller supports the Get LBA Status capability with Action Type values 10h and 11h; 0 means it does not.

- In the export: NVME_Transactions.csv, column 137, after `OACS.DBCS`; nvme_command.csv, column 119, after `OACS.DBCS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, OACS field, bit 9, line 19271 of its text. Its words:

> Get LBA Status Supported (GLSS): If this bit is set to


### `OACS.CFLS`

Command and Feature Lockdown Supported, bit 10 of Optional Admin Command Support: 1 means the controller supports the Command and Feature Lockdown capability; 0 means it does not.

- In the export: NVME_Transactions.csv, column 138, after `OACS.GLSS`; nvme_command.csv, column 120, after `OACS.GLSS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, OACS field, bit 10, line 19266 of its text. Its words:

> Command and Feature Lockdown Supported (CFLS): If this bit is set to


### `OACS.ACL`

Abort Command Limit: the maximum number of Abort commands the controller can execute at the same time on the Admin Queue, as a 0's based value (0 means one). Identify Controller data.

- In the export: NVME_Transactions.csv, column 139, after `OACS.CFLS`; nvme_command.csv, column 121, after `OACS.CFLS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, byte 258, line 19317 of its text. Its words:

> Abort Command Limit (ACL): This field indicates the maximum number of concurrently

- Note: A separate one-byte field, not a bit of OACS; the export lists it under the OACS header.

### `OACS.AERL`

Asynchronous Event Request Limit: the maximum number of Asynchronous Event Request commands that may be outstanding at once, as a 0's based value (0 means one). Identify Controller data.

- In the export: NVME_Transactions.csv, column 140, after `OACS.ACL`; nvme_command.csv, column 122, after `OACS.ACL`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, byte 259, line 19335 of its text. Its words:

> Asynchronous Event Request Limit (AERL): This field is used to convey the maximum

- Note: A separate one-byte field, not a bit of OACS; the export lists it under the OACS header.

### `FRMW`

Firmware Updates: the drive's capabilities for firmware updates, in the Identify Controller data it returns. The sub-columns show its bits: first slot read only, number of firmware slots, activation without reset, and multiple-update detection.

- In the export: NVME_Transactions.csv, column 141, after `OACS.AERL`; nvme_command.csv, column 123, after `OACS.AERL`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field FRMW, line 19341 of its text. Its words:

> Firmware Updates (FRMW): This field indicates capabilities regarding firmware updates.


### `FRMW.Bit 0`

First Firmware Slot Read Only (FFSRO), bit 0 of Firmware Updates: 1 means the first firmware slot (slot 1) is read only; 0 means slot 1 can be read and written.

- In the export: NVME_Transactions.csv, column 142, after `FRMW`; nvme_command.csv, column 124, after `FRMW`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; FRMW bit table, bit 0, line 19358 of its text. Its words:

> First Firmware Slot Read Only (FFSRO): If this bit is set to

- Note: The software shows the bit as 'Bit N'; matched to the specification's named bit by bit position, so the name is the specification's, not the software's.

### `FRMW.Bits 3:1`

Number Of Firmware Slots (NOFS), bits 3 to 1 of Firmware Updates: how many firmware slots the drive supports, a value from 1 to 7 (slots 1 through 7).

- In the export: NVME_Transactions.csv, column 143, after `FRMW.Bit 0`; nvme_command.csv, column 125, after `FRMW.Bit 0`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; FRMW bit table, bits 3:1, line 19353 of its text. Its words:

> Number Of Firmware Slots (NOFS): This field indicates the number of

- Note: The software shows the bit as 'Bits 3:1'; matched to the specification's named bits by bit position, so the name is the specification's, not the software's.

### `FRMW.Bit 4`

Firmware Activation Without Reset (FAWR), bit 4 of Firmware Updates: 1 means the drive can activate new firmware without a reset; 0 means a reset is needed to activate it.

- In the export: NVME_Transactions.csv, column 144, after `FRMW.Bits 3:1`; nvme_command.csv, column 126, after `FRMW.Bits 3:1`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; FRMW bit table, bit 4, line 19350 of its text. Its words:

> Firmware Activation Without Reset (FAWR): If this bit is set to

- Note: The software shows the bit as 'Bit N'; matched to the specification's named bit by bit position, so the name is the specification's, not the software's.

### `FRMW.Bit 5`

Support Multiple Update Detection (SMUD), bit 5 of Firmware Updates: 1 means the drive can detect overlapping firmware or boot partition image update command sequences; 0 means it cannot.

- In the export: NVME_Transactions.csv, column 145, after `FRMW.Bit 4`; nvme_command.csv, column 127, after `FRMW.Bit 4`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; FRMW bit table, bit 5, line 19345 of its text. Its words:

> Support Multiple Update Detection (SMUD): If this bit is set to

- Note: The software shows the bit as 'Bit N'; matched to the specification's named bit by bit position, so the name is the specification's, not the software's. Older drives report this bit as reserved (0).

### `LPA`

Log Page Attributes: optional attributes of the log pages read with the Get Log Page command, in the Identify Controller data. Sub-columns Bit 0 to Bit 6 are one capability flag each, followed by two separate fields.

- In the export: NVME_Transactions.csv, column 146, after `FRMW.Bit 5`; nvme_command.csv, column 128, after `FRMW.Bit 5`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field LPA, line 19376 of its text. Its words:

> Log Page Attributes (LPA): This field indicates optional attributes for log pages that are


### `LPA.Bit 0`

SMART Support (SMARTS), bit 0 of Log Page Attributes: 1 means the drive supplies the SMART / Health Information log page for each namespace separately; 0 means it does not.

- In the export: NVME_Transactions.csv, column 147, after `LPA`; nvme_command.csv, column 129, after `LPA`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; LPA bit table, bit 0, line 19420 of its text. Its words:

> SMART Support (SMARTS): If this bit is set to

- Note: The software shows the bit as 'Bit N'; matched to the specification's named bit by bit position, so the name is the specification's, not the software's.

### `LPA.Bit 1`

Commands Supported and Effects Support (CSES), bit 1 of Log Page Attributes: 1 means the drive supports the Commands Supported and Effects log page; 0 means it does not.

- In the export: NVME_Transactions.csv, column 148, after `LPA.Bit 0`; nvme_command.csv, column 130, after `LPA.Bit 0`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; LPA bit table, bit 1, line 19415 of its text. Its words:

> Commands Supported and Effects Support (CSES): If this bit is set to

- Note: The software shows the bit as 'Bit N'; matched to the specification's named bit by bit position, so the name is the specification's, not the software's.

### `LPA.Bit 2`

Log Page Extended Data Support (LPEDS), bit 2 of Log Page Attributes: 1 means the Get Log Page command supports extended data (longer Number of Dwords and Log Page Offset fields); 0 means it does not.

- In the export: NVME_Transactions.csv, column 149, after `LPA.Bit 1`; nvme_command.csv, column 131, after `LPA.Bit 1`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; LPA bit table, bit 2, line 19410 of its text. Its words:

> Log Page Extended Data Support (LPEDS): If this bit is set to

- Note: The software shows the bit as 'Bit N'; matched to the specification's named bit by bit position, so the name is the specification's, not the software's.

### `LPA.Bit 3`

Telemetry Support (TS), bit 3 of Log Page Attributes: 1 means the drive supports the Telemetry Host-Initiated and Telemetry Controller-Initiated log pages and sends Telemetry Log Notices; 0 means it does not.

- In the export: NVME_Transactions.csv, column 150, after `LPA.Bit 2`; nvme_command.csv, column 132, after `LPA.Bit 2`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; LPA bit table, bit 3, line 19405 of its text. Its words:

> Telemetry Support (TS): If this bit is set to

- Note: The software shows the bit as 'Bit N'; matched to the specification's named bit by bit position, so the name is the specification's, not the software's.

### `LPA.Bit 4`

Persistent Event Support (PES), bit 4 of Log Page Attributes: 1 means the drive supports the Persistent Event log; 0 means it does not.

- In the export: NVME_Transactions.csv, column 151, after `LPA.Bit 3`; nvme_command.csv, column 133, after `LPA.Bit 3`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; LPA bit table, bit 4, line 19402 of its text. Its words:

> Persistent Event Support (PES): If this bit is set to

- Note: The software shows the bit as 'Bit N'; matched to the specification's named bit by bit position, so the name is the specification's, not the software's. Older drives report this bit as reserved (0).

### `LPA.Bit 5`

Miscellaneous Log Page Support (MLPS), bit 5 of Log Page Attributes: 1 means the drive supports the Supported Log Pages log page and reports each command's scope in the Commands Supported and Effects log page, plus two more such pages; 0 means optional.

- In the export: NVME_Transactions.csv, column 152, after `LPA.Bit 4`; nvme_command.csv, column 134, after `LPA.Bit 4`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; LPA bit table, bit 5, line 19385 of its text. Its words:

> Miscellaneous Log Page Support (MLPS): If this bit is set to

- Note: The software shows the bit as 'Bit N'; matched to the specification's named bit by bit position, so the name is the specification's, not the software's. Older drives report this bit as reserved (0).

### `LPA.Bit 6`

Data Area 4 Support (DA4S), bit 6 of Log Page Attributes: 1 means the drive supports Data Area 4 in the Telemetry Host-Initiated and Telemetry Controller-Initiated log pages; 0 means it does not.

- In the export: NVME_Transactions.csv, column 153, after `LPA.Bit 5`; nvme_command.csv, column 135, after `LPA.Bit 5`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; LPA bit table, bit 6, line 19380 of its text. Its words:

> Data Area 4 Support (DA4S): If this bit is set to

- Note: The software shows the bit as 'Bit N'; matched to the specification's named bit by bit position, so the name is the specification's, not the software's. Older drives report this bit as reserved (0).

### `LPA.ELPE`

Error Log Page Entries: the maximum number of Error Information log entries the drive stores. It is a 0's based value, so add 1 to get the count.

- In the export: NVME_Transactions.csv, column 154, after `LPA.Bit 6`; nvme_command.csv, column 136, after `LPA.Bit 6`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field ELPE (byte 262), line 19425 of its text. Its words:

> Error Log Page Entries (ELPE): This field indicates the maximum number of Error

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `LPA.NPSS`

Number of Power States Support: how many NVM Express power states the drive supports, as a 0's based value (0 means one state, up to 31 means 32 states). Power states are numbered from 0.

- In the export: NVME_Transactions.csv, column 155, after `LPA.ELPE`; nvme_command.csv, column 137, after `LPA.ELPE`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field NPSS (byte 263), line 19441 of its text. Its words:

> Number of Power States Support (NPSS): This field indicates the number of NVM

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `AVSCC`

Admin Vendor Specific Command Configuration: settings for how the drive handles vendor-specific Admin commands, in the Identify Controller data. Its only sub-column is bit 0.

- In the export: NVME_Transactions.csv, column 156, after `LPA.NPSS`; nvme_command.csv, column 138, after `LPA.NPSS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field AVSCC, line 19448 of its text. Its words:

> Admin Vendor Specific Command Configuration (AVSCC): This field indicates the


### `AVSCC.Bit 0`

Vendor Specific Command Format (VSCF), bit 0 of Admin Vendor Specific Command Configuration: 1 means all vendor-specific Admin commands use the format defined by the specification; 0 means their format is vendor specific.

- In the export: NVME_Transactions.csv, column 157, after `AVSCC`; nvme_command.csv, column 139, after `AVSCC`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; AVSCC bit table, bit 0, line 19453 of its text. Its words:

> Vendor Specific Command Format (VSCF): If this bit is set to

- Note: The software shows the bit as 'Bit N'; matched to the specification's named bit by bit position, so the name is the specification's, not the software's.

### `APSTA`

Autonomous Power State Transition Attributes: attributes of the feature that lets the drive move itself between power states, in the Identify Controller data. Sub-column bit 0 is the support flag; temperature, firmware activation, host memory and capacity fields follow it.

- In the export: NVME_Transactions.csv, column 158, after `AVSCC.Bit 0`; nvme_command.csv, column 140, after `AVSCC.Bit 0`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field APSTA, line 19458 of its text. Its words:

> Autonomous Power State Transition Attributes (APSTA): This field indicates the


### `APSTA.Bit 0`

Autonomous Power Transition Support (APTS), bit 0 of Autonomous Power State Transition Attributes: 1 means the drive supports autonomous power state transitions; 0 means it does not.

- In the export: NVME_Transactions.csv, column 159, after `APSTA`; nvme_command.csv, column 141, after `APSTA`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; APSTA bit table, bit 0, line 19462 of its text. Its words:

> Autonomous Power Transition Support (APTS): If this bit is set to

- Note: The software shows the bit as 'Bit N'; matched to the specification's named bit by bit position, so the name is the specification's, not the software's.

### `APSTA.WCTEMP`

Warning Composite Temperature Threshold: the composite temperature, in Kelvins, from which the drive reports an overheating condition while it keeps running; remediation is recommended. 0 means no warning threshold is reported.

- In the export: NVME_Transactions.csv, column 160, after `APSTA.Bit 0`; nvme_command.csv, column 142, after `APSTA.Bit 0`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field WCTEMP (bytes 267:266), line 19467 of its text. Its words:

> Warning Composite Temperature Threshold (WCTEMP): This field indicates the

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column. Unit Kelvins follows the Composite Temperature field of the SMART / Health Information log page.

### `APSTA.CCTEMP`

Critical Composite Temperature Threshold: the composite temperature, in Kelvins, from which the drive reports a critical overheating condition (possible data loss, shutdown, heavy throttling or damage). 0 means no critical threshold is reported.

- In the export: NVME_Transactions.csv, column 161, after `APSTA.WCTEMP`; nvme_command.csv, column 143, after `APSTA.WCTEMP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field CCTEMP (bytes 269:268), line 19477 of its text. Its words:

> Critical Composite Temperature Threshold (CCTEMP): This field indicates the

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column. Unit Kelvins follows the Composite Temperature field of the SMART / Health Information log page.

### `APSTA.MTFA`

Maximum Time for Firmware Activation: the longest time, in 100 millisecond units, that the drive stops processing commands to activate a firmware image. Valid when activation without reset is supported; 0 means undefined.

- In the export: NVME_Transactions.csv, column 162, after `APSTA.CCTEMP`; nvme_command.csv, column 144, after `APSTA.CCTEMP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field MTFA (bytes 271:270), line 19485 of its text. Its words:

> Maximum Time for Firmware Activation (MTFA): This field indicates the maximum time

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `APSTA.HMPRE`

Host Memory Buffer Preferred Size: the size, in 4 KiB units, that the drive asks the host to allocate for the Host Memory Buffer. Non-zero means the feature is supported; 0 means it is not.

- In the export: NVME_Transactions.csv, column 163, after `APSTA.MTFA`; nvme_command.csv, column 145, after `APSTA.MTFA`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field HMPRE (bytes 275:272), line 19506 of its text. Its words:

> Host Memory Buffer Preferred Size (HMPRE): This field indicates the preferred size

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `APSTA.HMMIN`

Host Memory Buffer Minimum Size: the smallest size, in 4 KiB units, that the drive asks the host to allocate for the Host Memory Buffer. 0 means any amount up to the preferred size is acceptable.

- In the export: NVME_Transactions.csv, column 164, after `APSTA.HMPRE`; nvme_command.csv, column 146, after `APSTA.HMPRE`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field HMMIN (bytes 279:276), line 19513 of its text. Its words:

> Host Memory Buffer Minimum Size (HMMIN): This field indicates the minimum size

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `APSTA.TNVMCAP`

Total NVM Capacity: the total non-volatile memory capacity the controller can access, in bytes. Required when Namespace Management or Capacity Management is supported.

- In the export: NVME_Transactions.csv, column 165, after `APSTA.HMMIN`; nvme_command.csv, column 147, after `APSTA.HMMIN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field TNVMCAP (bytes 295:280), line 19518 of its text. Its words:

> Total NVM Capacity (TNVMCAP): This field indicates the total NVM capacity that is

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `APSTA.UNVMCAP`

Unallocated NVM Capacity: the part of the non-volatile memory capacity accessible by the controller that is not yet allocated to namespaces, in bytes. Required when Namespace Management or Capacity Management is supported.

- In the export: NVME_Transactions.csv, column 166, after `APSTA.TNVMCAP`; nvme_command.csv, column 148, after `APSTA.TNVMCAP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field UNVMCAP (bytes 311:296), line 19523 of its text. Its words:

> Unallocated NVM Capacity (UNVMCAP): This field indicates the unallocated NVM

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `RPMBS`

Replay Protected Memory Block Support: whether the drive supports one or more Replay Protected Memory Blocks and their capabilities, in the Identify Controller data. Sub-columns: number of units, authentication method, total size, access size.

- In the export: NVME_Transactions.csv, column 167, after `APSTA.UNVMCAP`; nvme_command.csv, column 149, after `APSTA.UNVMCAP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field RPMBS (bytes 315:312), line 19528 of its text. Its words:

> Replay Protected Memory Block Support (RPMBS): This field indicates if the controller


### `RPMBS.Unit Number`

Number of RPMB Units (NRPMBU), bits 2:0 of Replay Protected Memory Block Support: how many replay protected memory block targets the drive supports. 0 means none; a non-zero value requires the Security Send and Security Receive commands.

- In the export: NVME_Transactions.csv, column 168, after `RPMBS`; nvme_command.csv, column 150, after `RPMBS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; RPMBS bit table, bits 02:00, line 19554 of its text. Its words:

> Number of RPMB Units (NRPMBU): This field indicates the number of

- Note: The software names it 'Unit Number'; the specification calls it Number of RPMB Units (bits 2:0), matched by meaning and bit position.

### `RPMBS.Auth Method`

Authentication Method (AUTHM), bits 5:3 of Replay Protected Memory Block Support: the method used to access all replay protected memory blocks. 000b means HMAC SHA-256; other values are reserved.

- In the export: NVME_Transactions.csv, column 169, after `RPMBS.Unit Number`; nvme_command.csv, column 151, after `RPMBS.Unit Number`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; RPMBS bit table, bits 05:03, line 19547 of its text. Its words:

> Authentication Method (AUTHM): This field indicates the authentication

- Note: The software names it 'Auth Method'; matched by meaning and bit position.

### `RPMBS.Total Size`

Total Size (TSZE), bits 23:16 of Replay Protected Memory Block Support: the size of each replay protected memory block in 128 KiB units, as a 0's based value (0 means one unit). Ignore it when the number of units is 0.

- In the export: NVME_Transactions.csv, column 170, after `RPMBS.Auth Method`; nvme_command.csv, column 152, after `RPMBS.Auth Method`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; RPMBS bit table, bits 23:16, line 19539 of its text. Its words:

> Total Size (TSZE): If the Number of RPMB Units field is non-zero, then this

- Note: The Teledyne LeCroy script manual lists these bits as 23:15, which looks like a typing mistake; the NVMe specification says 23:16.

### `RPMBS.Access Size`

Access Size (ASZE), bits 31:24 of Replay Protected Memory Block Support: the most 512-byte units one Security Send or Security Receive access may read or write, as a 0's based value (0 means 512 bytes). Ignore it when the number of units is 0.

- In the export: NVME_Transactions.csv, column 171, after `RPMBS.Total Size`; nvme_command.csv, column 153, after `RPMBS.Total Size`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; RPMBS bit table, bits 31:24, line 19532 of its text. Its words:

> Access Size (ASZE): If the Number of RPMB Units field is non-zero, then


### `RPMBS.EDSTT`

Extended Device Self-test Time: the nominal time, in one minute units, the drive takes to finish an extended device self-test in power state 0. Reserved if the Device Self-test command is not supported.

- In the export: NVME_Transactions.csv, column 172, after `RPMBS.Access Size`; nvme_command.csv, column 154, after `RPMBS.Access Size`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field EDSTT (bytes 317:316), line 19574 of its text. Its words:

> Extended Device Self-test Time (EDSTT): If the Device Self-test command is

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `DSTO`

Device Self-test Options: optional behaviours of the Device Self-test command or operation that the controller or drive subsystem supports, in the Identify Controller data. Sub-column SDSO is its bit 0; two separate fields follow.

- In the export: NVME_Transactions.csv, column 173, after `RPMBS.EDSTT`; nvme_command.csv, column 155, after `RPMBS.EDSTT`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field DSTO (byte 318), line 19579 of its text. Its words:

> Device Self-test Options (DSTO): This field indicates the optional Device Self-test


### `DSTO.SDSO`

Single Device Self-test Operation (SDSO), bit 0 of Device Self-test Options: 1 means the drive subsystem supports only one device self-test in progress at a time; 0 means one self-test per controller at a time.

- In the export: NVME_Transactions.csv, column 174, after `DSTO`; nvme_command.csv, column 156, after `DSTO`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; DSTO bit table, bit 0, line 19595 of its text. Its words:

> Single Device Self-test Operation (SDSO): If this bit is set to


### `DSTO.FWUG`

Firmware Update Granularity: the granularity and alignment the Firmware Image Download command needs, in 4 KiB units (1 is 4 KiB, 2 is 8 KiB). 0 means no information is given; FFh means no restriction.

- In the export: NVME_Transactions.csv, column 175, after `DSTO.SDSO`; nvme_command.csv, column 157, after `DSTO.SDSO`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field FWUG (byte 319), line 19600 of its text. Its words:

> Firmware Update Granularity (FWUG): This field indicates the granularity and

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `DSTO.KAS`

Keep Alive Support: the granularity of the keep alive timeout (the KATO field) in 100 millisecond units. 0 means the Keep Alive Timer feature is not supported.

- In the export: NVME_Transactions.csv, column 176, after `DSTO.FWUG`; nvme_command.csv, column 158, after `DSTO.FWUG`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field KAS (bytes 321:320), line 19611 of its text. Its words:

> Keep Alive Support (KAS): This field indicates the granularity of the KATO field in 100

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `HCTMA`

Host Controlled Thermal Management Attributes: attributes of the feature that lets the host set thermal management temperatures, in the Identify Controller data. Sub-column bit 0 is the support flag; two temperature limits follow.

- In the export: NVME_Transactions.csv, column 177, after `DSTO.KAS`; nvme_command.csv, column 159, after `DSTO.KAS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field HCTMA (bytes 323:322), line 19616 of its text. Its words:

> Host Controlled Thermal Management Attributes (HCTMA): This field indicates the


### `HCTMA.Bit 0`

Host Controlled Thermal Management Support (HCTMS), bit 0 of Host Controlled Thermal Management Attributes: 1 means the drive supports host controlled thermal management (Set and Get Features with Feature Identifier 10h); 0 means it does not.

- In the export: NVME_Transactions.csv, column 178, after `HCTMA`; nvme_command.csv, column 160, after `HCTMA`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; HCTMA bit table, bit 0, line 19620 of its text. Its words:

> Host Controlled Thermal Management Support (HCTMS):

- Note: The software shows the bit as 'Bit N'; matched to the specification's named bit by bit position, so the name is the specification's, not the software's.

### `HCTMA.MNTMT`

Minimum Thermal Management Temperature: the lowest temperature, in Kelvins, the host may request in a Set Features command with Feature Identifier 10h. 0 means not reported or host controlled thermal management is unsupported.

- In the export: NVME_Transactions.csv, column 179, after `HCTMA.Bit 0`; nvme_command.csv, column 161, after `HCTMA.Bit 0`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field MNTMT (bytes 325:324), line 19627 of its text. Its words:

> Minimum Thermal Management Temperature (MNTMT): This field indicates the

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `HCTMA.MXTMT`

Maximum Thermal Management Temperature: the highest temperature, in Kelvins, the host may request in a Set Features command with Feature Identifier 10h. 0 means not reported or host controlled thermal management is unsupported.

- In the export: NVME_Transactions.csv, column 180, after `HCTMA.MNTMT`; nvme_command.csv, column 162, after `HCTMA.MNTMT`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field MXTMT (bytes 327:326), line 19647 of its text. Its words:

> Maximum Thermal Management Temperature (MXTMT): This field indicates the

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `SANICAP`

Sanitize Capabilities: which sanitize operations the drive supports (crypto erase, block erase, overwrite) and related options, in the Identify Controller data. Non-zero if the Sanitize command is supported, 0 if not.

- In the export: NVME_Transactions.csv, column 181, after `HCTMA.MXTMT`; nvme_command.csv, column 163, after `HCTMA.MXTMT`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field SANICAP (bytes 331:328), line 19654 of its text. Its words:

> Sanitize Capabilities (SANICAP): This field indicates attributes for sanitize operations.


### `SANICAP.CES`

Crypto Erase Support (CES), bit 0 of Sanitize Capabilities: 1 means the drive supports the Crypto Erase sanitize operation; 0 means it does not.

- In the export: NVME_Transactions.csv, column 182, after `SANICAP`; nvme_command.csv, column 164, after `SANICAP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; SANICAP bit table, bit 00, line 19726 of its text. Its words:

> Crypto Erase Support (CES): If this bit is set to


### `SANICAP.BES`

Block Erase Support (BES), bit 1 of Sanitize Capabilities: 1 means the drive supports the Block Erase sanitize operation; 0 means it does not.

- In the export: NVME_Transactions.csv, column 183, after `SANICAP.CES`; nvme_command.csv, column 165, after `SANICAP.CES`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; SANICAP bit table, bit 01, line 19723 of its text. Its words:

> Block Erase Support (BES): If this bit is set to


### `SANICAP.OWS`

Overwrite Support (OWS), bit 2 of Sanitize Capabilities: 1 means the drive supports the Overwrite sanitize operation; 0 means it does not.

- In the export: NVME_Transactions.csv, column 184, after `SANICAP.BES`; nvme_command.csv, column 166, after `SANICAP.BES`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; SANICAP bit table, bit 02, line 19720 of its text. Its words:

> Overwrite Support (OWS): If this bit is set to


### `SANICAP.SANICAP_NDI`

No-Deallocate Inhibited (NDI), bit 29 of Sanitize Capabilities: 1 means the drive does not honour a Sanitize request to skip deallocation (it deallocates media anyway, or aborts the command). 0 means the No-Deallocate After Sanitize bit is supported.

- In the export: NVME_Transactions.csv, column 185, after `SANICAP.OWS`; nvme_command.csv, column 167, after `SANICAP.OWS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; SANICAP bit table, bit 29, line 19677 of its text. Its words:

> No-Deallocate Inhibited (NDI): If this bit is set to

- Note: The software prefixes the name with the parent (SANICAP_NDI); matched to NDI by name and bit position (the Teledyne LeCroy script manual also lists it at bit 29).

### `SANICAP.SANICAP_NODMMAS`

No-Deallocate Modifies Media After Sanitize (NODMMAS), bits 31:30 of Sanitize Capabilities: whether sanitize also modifies the media when No-Deallocate After Sanitize was requested. 00b not defined, 01b media not additionally modified, 10b media additionally modified, 11b reserved.

- In the export: NVME_Transactions.csv, column 186, after `SANICAP.SANICAP_NDI`; nvme_command.csv, column 168, after `SANICAP.SANICAP_NDI`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; SANICAP bit table, bits 31:30, line 19658 of its text. Its words:

> No-Deallocate Modifies Media After Sanitize (NODMMAS): This field

- Note: The software prefixes the name with the parent (SANICAP_NODMMAS); matched to NODMMAS by name and bit position (the Teledyne LeCroy script manual lists it at bits 31:30).

### `SANICAP.HMMINDS`

Host Memory Buffer Minimum Descriptor Entry Size: the minimum usable size of one Host Memory Buffer descriptor entry, in 4 KiB units. 0 means the drive states no limit.

- In the export: NVME_Transactions.csv, column 187, after `SANICAP.SANICAP_NODMMAS`; nvme_command.csv, column 169, after `SANICAP.SANICAP_NODMMAS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field HMMINDS (bytes 335:332), line 19729 of its text. Its words:

> Host Memory Buffer Minimum Descriptor Entry Size (HMMINDS): This field indicates

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `SANICAP.HMMAXD`

Host Memory Maximum Descriptors Entries: the number of usable Host Memory Buffer descriptor entries. 0 means the drive states no maximum number.

- In the export: NVME_Transactions.csv, column 188, after `SANICAP.HMMINDS`; nvme_command.csv, column 170, after `SANICAP.HMMINDS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field HMMAXD (bytes 337:336), line 19734 of its text. Its words:

> Host Memory Maximum Descriptors Entries (HMMAXD): This field indicates the

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `SANICAP.NSETIDMAX`

NVM Set Identifier Maximum: the largest valid NVM Set Identifier of any controller in the drive subsystem. The number of NVM Sets the subsystem supports is less than or equal to this value.

- In the export: NVME_Transactions.csv, column 189, after `SANICAP.HMMAXD`; nvme_command.csv, column 171, after `SANICAP.HMMAXD`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field NSETIDMAX (bytes 339:338), line 19739 of its text. Its words:

> NVM Set Identifier Maximum (NSETIDMAX): This field defines the maximum value of

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `SANICAP.ENDGIDMAX`

Endurance Group Identifier Maximum: the largest valid Endurance Group Identifier of any controller in the drive subsystem. The number of Endurance Groups supported is less than or equal to this value.

- In the export: NVME_Transactions.csv, column 190, after `SANICAP.NSETIDMAX`; nvme_command.csv, column 172, after `SANICAP.NSETIDMAX`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field ENDGIDMAX (bytes 341:340), line 19742 of its text. Its words:

> Endurance Group Identifier Maximum (ENDGIDMAX): This field defines the maximum

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `SANICAP.ANATT`

ANA Transition Time: the maximum time, in seconds, for a transition between Asymmetric Namespace Access (ANA) states, or for which the controller reports the ANA change state. Non-zero if ANA reporting is supported, otherwise 0.

- In the export: NVME_Transactions.csv, column 191, after `SANICAP.ENDGIDMAX`; nvme_command.csv, column 173, after `SANICAP.ENDGIDMAX`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field ANATT (byte 342), line 19747 of its text. Its words:

> ANA Transition Time (ANATT): This field indicates the maximum amount of time, in

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `ANACAP`

Asymmetric Namespace Access Capabilities: the capabilities of Asymmetric Namespace Access reporting, in the Identify Controller data. Sub-columns: one flag per ANA state the drive can report, two group identifier flags, then several separate fields.

- In the export: NVME_Transactions.csv, column 192, after `SANICAP.ANATT`; nvme_command.csv, column 174, after `SANICAP.ANATT`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field ANACAP (byte 343), line 19767 of its text. Its words:

> Asymmetric Namespace Access Capabilities (ANACAP): This field indicates the


### `ANACAP.RANAOS`

Report ANA Optimized State (RANAOS), bit 0 of Asymmetric Namespace Access Capabilities: 1 means the controller can report the ANA Optimized state; 0 means it does not.

- In the export: NVME_Transactions.csv, column 193, after `ANACAP`; nvme_command.csv, column 175, after `ANACAP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; ANACAP bit table, bit 0, line 19804 of its text. Its words:

> Report ANA Optimized State (RANAOS):

- Note: The specification text for this bit says 'Inaccessible' in its description, which looks like a copy mistake; the bit's name and the ANA state list give Optimized. Matched by name and bit position.

### `ANACAP.RANANOS`

Report ANA Non-Optimized State (RANANOS), bit 1 of Asymmetric Namespace Access Capabilities: 1 means the controller can report the ANA Non-Optimized state; 0 means it does not.

- In the export: NVME_Transactions.csv, column 194, after `ANACAP.RANAOS`; nvme_command.csv, column 176, after `ANACAP.RANAOS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; ANACAP bit table, bit 1, line 19799 of its text. Its words:

> Report ANA Non-Optimized State (RANANOS):


### `ANACAP.RANAIS`

Report ANA Inaccessible State (RANAIS), bit 2 of Asymmetric Namespace Access Capabilities: 1 means the controller can report the ANA Inaccessible state; 0 means it does not.

- In the export: NVME_Transactions.csv, column 195, after `ANACAP.RANANOS`; nvme_command.csv, column 177, after `ANACAP.RANANOS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; ANACAP bit table, bit 2, line 19794 of its text. Its words:

> Report ANA Inaccessible State (RANAIS):


### `ANACAP.RANAPLS`

Report ANA Persistent Loss State (RANAPLS), bit 3 of Asymmetric Namespace Access Capabilities: 1 means the controller can report the ANA Persistent Loss state; 0 means it does not.

- In the export: NVME_Transactions.csv, column 196, after `ANACAP.RANAIS`; nvme_command.csv, column 178, after `ANACAP.RANAIS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; ANACAP bit table, bit 3, line 19789 of its text. Its words:

> Report ANA Persistent Loss State (RANAPLS):


### `ANACAP.RANACS`

Report ANA Change State (RANACS), bit 4 of Asymmetric Namespace Access Capabilities: 1 means the controller can report the ANA Change state; 0 means it does not.

- In the export: NVME_Transactions.csv, column 197, after `ANACAP.RANAPLS`; nvme_command.csv, column 179, after `ANACAP.RANAPLS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; ANACAP bit table, bit 4, line 19786 of its text. Its words:

> Report ANA Change State (RANACS)


### `ANACAP.ANAGIDLWAS`

ANA Group ID Locked When Attached Support (ANAGIDLWAS), bit 6 of Asymmetric Namespace Access Capabilities: 1 means a namespace's ANA group identifier does not change while it is attached to any controller; 0 means it may change.

- In the export: NVME_Transactions.csv, column 198, after `ANACAP.RANACS`; nvme_command.csv, column 180, after `ANACAP.RANACS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; ANACAP bit table, bit 6, line 19778 of its text. Its words:

> ANA Group ID Locked When Attached Support (ANAGIDLWAS):


### `ANACAP.ANAGIDS`

ANA Group ID Support (ANAGIDS), bit 7 of Asymmetric Namespace Access Capabilities: 1 means the controller accepts a non-zero ANA group identifier in the Namespace Management command; 0 means it does not.

- In the export: NVME_Transactions.csv, column 199, after `ANACAP.ANAGIDLWAS`; nvme_command.csv, column 181, after `ANACAP.ANAGIDLWAS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; ANACAP bit table, bit 7, line 19771 of its text. Its words:

> ANA Group ID Support (ANAGIDS):


### `ANACAP.ANAGRPMAX`

ANA Group Identifier Maximum: the largest valid ANA group identifier of any controller in the drive subsystem. Non-zero if ANA reporting is supported, otherwise 0.

- In the export: NVME_Transactions.csv, column 200, after `ANACAP.ANAGIDS`; nvme_command.csv, column 182, after `ANACAP.ANAGIDS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field ANAGRPMAX (bytes 347:344), line 19809 of its text. Its words:

> ANA Group Identifier Maximum (ANAGRPMAX): This field indicates the maximum

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `ANACAP.NANAGRPID`

Number of ANA Group Identifiers: how many ANA groups the controller supports. Non-zero and not above the maximum group identifier if ANA reporting is supported, otherwise 0.

- In the export: NVME_Transactions.csv, column 201, after `ANACAP.ANAGRPMAX`; nvme_command.csv, column 183, after `ANACAP.ANAGRPMAX`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field NANAGRPID (bytes 351:348), line 19814 of its text. Its words:

> Number of ANA Group Identifiers (NANAGRPID): This field indicates the number of

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `ANACAP.PELS`

Persistent Event Log Size: the maximum reportable size of the Persistent Event Log, in 64 KiB units. Reserved if the Persistent Event Log is not supported.

- In the export: NVME_Transactions.csv, column 202, after `ANACAP.NANAGRPID`; nvme_command.csv, column 184, after `ANACAP.NANAGRPID`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field PELS (bytes 355:352), line 19821 of its text. Its words:

> Persistent Event Log Size (PELS): This field indicates the maximum reportable size for

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `ANACAP.DID`

Domain Identifier: the identifier of the domain that contains this controller. 0 means the drive subsystem consists of a single domain.

- In the export: NVME_Transactions.csv, column 203, after `ANACAP.PELS`; nvme_command.csv, column 185, after `ANACAP.PELS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field DID (bytes 357:356), line 19824 of its text. Its words:

> Domain Identifier (DID): This field indicates the identifier of the domain (refer to section

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `ANACAP.MEGCAP`

Max Endurance Group Capacity: the maximum capacity of a single Endurance Group. 0 means the drive subsystem does not report a maximum Endurance Group capacity.

- In the export: NVME_Transactions.csv, column 204, after `ANACAP.DID`; nvme_command.csv, column 186, after `ANACAP.DID`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent; field MEGCAP (bytes 383:368), line 19870 of its text. Its words:

> Max Endurance Group Capacity (MEGCAP): This field indicates the maximum capacity

- Note: In the specification this is a separate field of the Identify Controller data; the export lists it under the preceding parent column.

### `NVM CS Attributes`

NVM Command Set Attributes: heading of the group of Identify Controller fields that describe how the drive handles the NVM command set (queue entry sizes, optional commands, fused operations, format, write cache, atomic write sizes, scatter gather lists). The fields follow in the next columns.

- In the export: NVME_Transactions.csv, column 205, after `ANACAP.MEGCAP`; nvme_command.csv, column 187, after `ANACAP.MEGCAP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 19904 of its text. Its words:

> NVM Command Set Attributes

- Note: The software abbreviates 'Command Set' to 'CS'. In the specification's figure this is a group heading; the sources do not say whether this column holds a value of its own.

### `SQES`

Submission Queue Entry Size, in the Identify Controller data the drive returns: the required (lower four bits) and maximum (upper four bits) size of an I/O Submission Queue entry. Each is a power of two in bytes; 6 means 64 bytes.

- In the export: NVME_Transactions.csv, column 206, after `NVM CS Attributes`; nvme_command.csv, column 188, after `NVM CS Attributes`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 19905 of its text. Its words:

> Submission Queue Entry Size (SQES): This field defines the required and maximum


### `SQES.Bits 3:0`

Minimum I/O Submission Queue Entry Size, bits 3:0 of Submission Queue Entry Size: the smallest entry size that may be used, as a power of two in bytes. The required value is 6, meaning 64 bytes.

- In the export: NVME_Transactions.csv, column 207, after `SQES`; nvme_command.csv, column 189, after `SQES`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 19915 of its text. Its words:

> Minimum I/O Submission Queue Entry Size (MINSQES): This field identifies

- Note: The software shows the bit range instead of the specification's field name (MINSQES); matched by bit position 3:0. The LeCroy script manual lists it as SQES_BITS0_3.

### `SQES.Bits 7:4`

Maximum I/O Submission Queue Entry Size, bits 7:4 of Submission Queue Entry Size: the largest entry size the drive accepts, as a power of two in bytes, at least the minimum. Recommended value 6 (64 bytes); drives with proprietary extensions may report more.

- In the export: NVME_Transactions.csv, column 208, after `SQES.Bits 3:0`; nvme_command.csv, column 190, after `SQES.Bits 3:0`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 19908 of its text. Its words:

> Maximum I/O Submission Queue Entry Size (MAXSQES): This field

- Note: The software shows the bit range instead of the specification's field name (MAXSQES); matched by bit position 7:4. The LeCroy script manual lists it as SQES_BITS4_7.

### `CQES`

Completion Queue Entry Size, in the Identify Controller data the drive returns: the required (lower four bits) and maximum (upper four bits) size of an I/O Completion Queue entry. Each is a power of two in bytes; 4 means 16 bytes.

- In the export: NVME_Transactions.csv, column 209, after `SQES.Bits 7:4`; nvme_command.csv, column 191, after `SQES.Bits 7:4`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 19920 of its text. Its words:

> Completion Queue Entry Size (CQES): This field defines the required and maximum


### `CQES.Bits 3:0`

Minimum I/O Completion Queue Entry Size, bits 3:0 of Completion Queue Entry Size: the smallest entry size that may be used, as a power of two in bytes. The required value is 4, meaning 16 bytes.

- In the export: NVME_Transactions.csv, column 210, after `CQES`; nvme_command.csv, column 192, after `CQES`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 19930 of its text. Its words:

> Minimum I/O Completion Queue Entry Size (MINCQES): This field

- Note: The software shows the bit range instead of the specification's field name (MINCQES); matched by bit position 3:0.

### `CQES.Bits 7:4`

Maximum I/O Completion Queue Entry Size, bits 7:4 of Completion Queue Entry Size: the largest entry size the drive accepts, as a power of two in bytes, at least the minimum. Recommended value 4 (16 bytes); drives with proprietary extensions may report more.

- In the export: NVME_Transactions.csv, column 211, after `CQES.Bits 3:0`; nvme_command.csv, column 193, after `CQES.Bits 3:0`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 19923 of its text. Its words:

> Maximum I/O Completion Queue Entry Size (MAXCQES): This field

- Note: The software shows the bit range instead of the specification's field name (MAXCQES); matched by bit position 7:4.

### `CQES.MAXCMD`

Maximum Outstanding Commands: the largest number of commands the drive processes at one time for one queue, which may be more than the queue's size. A host may use it to size completion queues. 0 means the field is not used.

- In the export: NVME_Transactions.csv, column 212, after `CQES.Bits 7:4`; nvme_command.csv, column 194, after `CQES.Bits 7:4`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 19935 of its text. Its words:

> Maximum Outstanding Commands (MAXCMD): Indicates the maximum number of

- Note: Listed under CQES in the export, but in the specification it is a separate two-byte field (bytes 515:514) that follows CQES; the LeCroy script manual also lists it on its own, with its own bit range.

### `CQES.NN`

Number of Namespaces: the maximum value of a valid namespace identifier for the NVM subsystem, reported in the Identify Controller data. The number of namespaces actually supported is given by the Maximum Number of Allowed Namespaces field.

- In the export: NVME_Transactions.csv, column 213, after `CQES.MAXCMD`; nvme_command.csv, column 195, after `CQES.MAXCMD`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 19942 of its text. Its words:

> Number of Namespaces (NN): This field indicates the maximum value of a valid NSID

- Note: Listed under CQES in the export, but in the specification it is a separate four-byte field (bytes 519:516) that follows MAXCMD.

### `ONCS`

Optional NVM Command Support: bit field in the Identify Controller data telling which optional I/O commands and features the drive supports (Compare, Write Uncorrectable, Dataset Management, Write Zeroes, Save and Select, Reservations, Timestamp, Verify, Copy). Each child column is one bit.

- In the export: NVME_Transactions.csv, column 214, after `CQES.NN`; nvme_command.csv, column 196, after `CQES.NN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 19952 of its text. Its words:

> Optional NVM Command Support (ONCS): This field indicates the optional I/O

- Note: Bytes 521:520 of the Identify Controller data.

### `ONCS.NVMCMPS`

Compare Command Support, bit 0 of Optional NVM Command Support: 1 means the drive supports the NVM Command Set Compare command; 0 means it does not.

- In the export: NVME_Transactions.csv, column 215, after `ONCS`; nvme_command.csv, column 197, after `ONCS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20065 of its text. Its words:

> Compare Command Support (NVMCMPS): If this bit is set to


### `ONCS.NVMWUSV`

Write Uncorrectable Support Variants, bit 1 of Optional NVM Command Support: 1 means the drive supports the Write Uncorrectable command and a size limit field gives its recommended maximum data size; 0 means support is shown only by a non-zero size limit.

- In the export: NVME_Transactions.csv, column 216, after `ONCS.NVMCMPS`; nvme_command.csv, column 198, after `ONCS.NVMCMPS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20058 of its text. Its words:

> Write Uncorrectable Support Variants (NVMWUSV): If this bit is set to


### `ONCS.NVMDSMSV`

Dataset Management Support Variants, bit 2 of Optional NVM Command Support: 1 means the drive supports the Dataset Management command and states any limits in its range count and size limit fields; 0 means support is shown only by non-zero values there.

- In the export: NVME_Transactions.csv, column 217, after `ONCS.NVMWUSV`; nvme_command.csv, column 199, after `ONCS.NVMWUSV`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20049 of its text. Its words:

> Dataset Management Support Variants (NVMDSMSV): If this bit is set to


### `ONCS.NVMWZSV`

Write Zeroes Support Variants, bit 3 of Optional NVM Command Support: 1 means the drive supports the Write Zeroes command and a size limit field gives its recommended maximum data size; 0 means support is shown only by a non-zero size limit.

- In the export: NVME_Transactions.csv, column 218, after `ONCS.NVMDSMSV`; nvme_command.csv, column 200, after `ONCS.NVMDSMSV`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20042 of its text. Its words:

> Write Zeroes Support Variants (NVMWZSV): If this bit is set to


### `ONCS.SSFS`

Save and Select Feature Support, bit 4 of Optional NVM Command Support: 1 means the drive accepts a non-zero Save field in Set Features and a non-zero Select field in Get Features; 0 means it accepts neither.

- In the export: NVME_Transactions.csv, column 219, after `ONCS.NVMWZSV`; nvme_command.csv, column 201, after `ONCS.NVMWZSV`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20035 of its text. Its words:

> Save and Select Feature Support (SSFS): If this bit is set to


### `ONCS.RESERVS`

Reservations Support, bit 5 of Optional NVM Command Support: 1 means the drive supports reservations (the Reservation Report, Register, Acquire and Release commands); 0 means it does not.

- In the export: NVME_Transactions.csv, column 220, after `ONCS.SSFS`; nvme_command.csv, column 202, after `ONCS.SSFS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20028 of its text. Its words:

> Reservations Support (RESERVS): If this bit is set to


### `ONCS.TSS`

Timestamp Support, bit 6 of Optional NVM Command Support: 1 means the drive supports the Timestamp feature; 0 means it does not.

- In the export: NVME_Transactions.csv, column 221, after `ONCS.RESERVS`; nvme_command.csv, column 203, after `ONCS.RESERVS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20012 of its text. Its words:

> Timestamp Support (TSS): If this bit is set to


### `ONCS.NVMVFYS`

Verify Support, bit 7 of Optional NVM Command Support: 1 means the drive supports the Verify command and a size limit field gives its recommended maximum data size; 0 means support is shown only by a non-zero size limit.

- In the export: NVME_Transactions.csv, column 222, after `ONCS.TSS`; nvme_command.csv, column 204, after `ONCS.TSS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20005 of its text. Its words:

> Verify Support (NVMVFYS): If this bit is set to


### `ONCS.NVMCPYS`

Copy Support, bit 8 of Optional NVM Command Support: 1 means the drive supports the NVM Command Set Copy command; 0 means it does not.

- In the export: NVME_Transactions.csv, column 223, after `ONCS.NVMVFYS`; nvme_command.csv, column 205, after `ONCS.NVMVFYS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20000 of its text. Its words:

> Copy Support (NVMCPYS): If this bit is set to


### `FUSES`

Fused Operation Support: bit field in the Identify Controller data telling which fused operations (two commands the drive executes in sequence as one atomic unit) it supports. Only bit 0 is defined.

- In the export: NVME_Transactions.csv, column 224, after `ONCS.NVMCPYS`; nvme_command.csv, column 206, after `ONCS.NVMCPYS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20072 of its text. Its words:

> Fused Operation Support (FUSES): This field indicates the fused operations that the

- Note: Bytes 523:522 of the Identify Controller data.

### `FUSES.Bit 0`

Fused Compare and Write Supported, bit 0 of Fused Operation Support: 1 means the drive supports the Compare and Write fused operation (Compare is the first command of the pair); 0 means it does not.

- In the export: NVME_Transactions.csv, column 225, after `FUSES`; nvme_command.csv, column 207, after `FUSES`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20076 of its text. Its words:

> Fused Compare and Write Supported (FCWS): If this bit is set to


### `FNA`

Format NVM Attributes: bit field in the Identify Controller data describing how the drive's Format NVM command behaves (scope of format and of secure erase, cryptographic erase, broadcast to all namespaces). The child columns are bits 0 to 3.

- In the export: NVME_Transactions.csv, column 226, after `FUSES.Bit 0`; nvme_command.csv, column 208, after `FUSES.Bit 0`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20094 of its text. Its words:

> Format NVM Attributes (FNA): This field indicates attributes for the Format NVM

- Note: Byte 524 of the Identify Controller data.

### `FNA.Bit 0`

Format Namespace Scope (FNS), bit 0 of Format NVM Attributes: 1 means formatting any namespace (apart from secure erase) formats all namespaces of the NVM subsystem, which share the same attributes; 0 means the drive formats per namespace.

- In the export: NVME_Transactions.csv, column 227, after `FNA`; nvme_command.csv, column 209, after `FNA`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20117 of its text. Its words:

> Format Namespace Scope (FNS): This bit indicates whether the format


### `FNA.Bit 1`

Secure Erase Namespace Scope (SENS), bit 1 of Format NVM Attributes: 1 means a secure erase done as part of a format erases all namespaces of the NVM subsystem; 0 means only the namespace named in the command.

- In the export: NVME_Transactions.csv, column 228, after `FNA.Bit 0`; nvme_command.csv, column 210, after `FNA.Bit 0`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20108 of its text. Its words:

> Secure Erase Namespace Scope (SENS): This bit indicates whether


### `FNA.Bit 2`

Cryptographic Erase Supported (CRYES), bit 2 of Format NVM Attributes: 1 means cryptographic erase is supported as part of the secure erase function; 0 means it is not.

- In the export: NVME_Transactions.csv, column 229, after `FNA.Bit 1`; nvme_command.csv, column 211, after `FNA.Bit 1`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20103 of its text. Its words:

> Cryptographic Erase Supported (CRYES): This bit indicates whether


### `FNA.Bit 3`

Format NVM Broadcast Support (FNVMBS), bit 3 of Format NVM Attributes: 1 means the Format NVM command does NOT accept namespace identifier FFFFFFFFh (all namespaces); 0 means it accepts it. Note that 1 means not supported.

- In the export: NVME_Transactions.csv, column 230, after `FNA.Bit 2`; nvme_command.csv, column 212, after `FNA.Bit 2`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20098 of its text. Its words:

> Format NVM Broadcast Support (FNVMBS): This bit indicates whether the


### `VWC`

Volatile Write Cache: bit field in the Identify Controller data about the drive's volatile write cache. Bit 0 says whether a cache is present; bits 2:1 say whether the Flush command accepts namespace identifier FFFFFFFFh.

- In the export: NVME_Transactions.csv, column 231, after `FNA.Bit 3`; nvme_command.csv, column 213, after `FNA.Bit 3`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20139 of its text. Its words:

> Volatile Write Cache (VWC): This field indicates attributes related to the presence of a

- Note: Byte 525 of the Identify Controller data.

### `VWC.Bit 0`

Volatile Write Cache Present (VWCP), bit 0 of Volatile Write Cache: 1 means the drive has a volatile write cache, which the host switches on or off with Set Features; 0 means no volatile write cache is present.

- In the export: NVME_Transactions.csv, column 232, after `VWC`; nvme_command.csv, column 214, after `VWC`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20160 of its text. Its words:

> Volatile Write Cache Present (VWCP): If this bit is set to


### `VWC.Bits 1:2`

Flush Behavior (FB), bits 2:1 of Volatile Write Cache: whether Flush accepts namespace identifier FFFFFFFFh. 00b not indicated (only for old drives); 10b Flush rejects it; 11b Flush accepts it; 01b reserved.

- In the export: NVME_Transactions.csv, column 233, after `VWC.Bit 0`; nvme_command.csv, column 215, after `VWC.Bit 0`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20143 of its text. Its words:

> Flush Behavior (FB): This field indicates Flush command behavior (refer

- Note: The software writes the bit range as 1:2; the specification's bit range is 02:01. Matched by meaning and position.

### `VWC.AWUN`

Atomic Write Unit Normal: the largest write the drive guarantees to store atomically with respect to other reads and writes during normal operation. In logical blocks, zero-based (0 means one block); FFFFh means always atomic.

- In the export: NVME_Transactions.csv, column 234, after `VWC.Bits 1:2`; nvme_command.csv, column 216, after `VWC.Bits 1:2`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 117: Identify – Identify Controller data structure, NVM Command Set Specific Fields, line 4985 of its text. Its words:

> Atomic Write Unit Normal (AWUN): This field indicates the size of the write operation

- Note: Listed under VWC in the export, but it is a separate two-byte field (bytes 527:526) that follows VWC. The NVMe Base Specification only points to the NVM Command Set Specification for its definition.

### `VWC.AWUPF`

Atomic Write Unit Power Fail: the largest write the drive guarantees to leave as all old data or all new data if a power failure or other error interrupts it. In logical blocks, zero-based; never larger than Atomic Write Unit Normal.

- In the export: NVME_Transactions.csv, column 235, after `VWC.AWUN`; nvme_command.csv, column 217, after `VWC.AWUN`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 117: Identify – Identify Controller data structure, NVM Command Set Specific Fields, line 5004 of its text. Its words:

> Atomic Write Unit Power Fail (AWUPF): This field indicates the size of the write operation

- Note: Listed under VWC in the export, but it is a separate two-byte field (bytes 529:528) that follows AWUN.

### `ICSVSCC`

I/O Command Set Vendor Specific Command Configuration: bit field in the Identify Controller data giving the settings for how vendor specific I/O commands are handled. Only bit 0 is defined.

- In the export: NVME_Transactions.csv, column 236, after `VWC.AWUPF`; nvme_command.csv, column 218, after `VWC.AWUPF`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20179 of its text. Its words:

> I/O Command Set Vendor Specific Command Configuration (ICSVSCC): This field

- Note: Byte 530 of the Identify Controller data.

### `ICSVSCC.Bit 0`

Same NVM Vendor Specific Command Format (SNVSCF), bit 0 of I/O Command Set Vendor Specific Command Configuration: 1 means all vendor specific I/O commands use the one format the specification defines; 0 means the format of each vendor specific I/O command is vendor specific.

- In the export: NVME_Transactions.csv, column 237, after `ICSVSCC`; nvme_command.csv, column 219, after `ICSVSCC`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20184 of its text. Its words:

> Same NVM Vendor Specific Command Format (SNVSCF): If this bit is set

- Note: The LeCroy script manual lists this bit under an older name, NVM Vendor Specific Command Configuration (NVSCC_BIT0); matched by bit position 0.

### `NWPC`

Namespace Write Protection Capabilities: bit field in the Identify Controller data telling which namespace write protection states the drive supports (write protect, write protect until power cycle, permanent write protect). Child columns are bits 0 to 2.

- In the export: NVME_Transactions.csv, column 238, after `ICSVSCC.Bit 0`; nvme_command.csv, column 220, after `ICSVSCC.Bit 0`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20202 of its text. Its words:

> Namespace Write Protection Capabilities (NWPC): This field indicates the optional

- Note: Byte 531 of the Identify Controller data.

### `NWPC.Bit 0`

No Write Protect and Write Protect Support (NWPWPS), bit 0 of Namespace Write Protection Capabilities: 1 means the drive supports the No Write Protect and Write Protect states and may support the other two; 0 means namespace write protection is not supported.

- In the export: NVME_Transactions.csv, column 239, after `NWPC`; nvme_command.csv, column 221, after `NWPC`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20219 of its text. Its words:

> No Write Protect and Write Protect Support (NWPWPS)


### `NWPC.Bit 1`

Write Protect Until Power Cycle Support (WPUPCS), bit 1 of Namespace Write Protection Capabilities: 1 means the drive supports the Write Protect Until Power Cycle state; 0 means it does not.

- In the export: NVME_Transactions.csv, column 240, after `NWPC.Bit 0`; nvme_command.csv, column 222, after `NWPC.Bit 0`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20213 of its text. Its words:

> Write Protect Until Power Cycle Support (WPUPCS): If this bit is set to


### `NWPC.Bit 2`

Permanent Write Protect Support (PWPS), bit 2 of Namespace Write Protection Capabilities: 1 means the drive supports the Permanent Write Protect state; 0 means it does not.

- In the export: NVME_Transactions.csv, column 241, after `NWPC.Bit 1`; nvme_command.csv, column 223, after `NWPC.Bit 1`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20207 of its text. Its words:

> Permanent Write Protect Support (PWPS): If this bit is set to


### `NWPC.ACWU`

Atomic Compare & Write Unit: the largest write the drive guarantees to store atomically in a Compare and Write fused operation. In logical blocks, zero-based; 0 if Compare and Write is not supported. Larger requests may be aborted.

- In the export: NVME_Transactions.csv, column 242, after `NWPC.Bit 2`; nvme_command.csv, column 224, after `NWPC.Bit 2`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 117: Identify – Identify Controller data structure, NVM Command Set Specific Fields, line 5036 of its text. Its words:

> Atomic Compare & Write Unit (ACWU): This field indicates the size of the write operation

- Note: Listed under NWPC in the export, but it is a separate two-byte field (bytes 533:532) that follows NWPC.

### `Optional Copy Formats Supported`

Optional Copy Formats Supported: bit field in the Identify Controller data listing which Source Range Entries copy descriptor formats the drive's Copy command accepts. Bit n set means descriptor format n is supported. The export shows bits 0 and 1.

- In the export: NVME_Transactions.csv, column 243, after `NWPC.ACWU`; nvme_command.csv, column 225, after `NWPC.ACWU`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20231 of its text. Its words:

> Copy Descriptor Formats Supported (CDFS):

- Note: This edition of the specification names the field Copy Descriptor Formats Supported (CDFS), bytes 535:534; the software's name differs, so it is matched by meaning and by its place after ACWU and before SGL Support. The specification defines bits 0 to 4; the export shows only bits 0 and 1.

### `Optional Copy Formats Supported.Bit 0`

Copy Descriptor Format 0 Support (CDF0S), bit 0 of Optional Copy Formats Supported: 1 means the drive supports Copy descriptor format 0h; 0 means it does not.

- In the export: NVME_Transactions.csv, column 244, after `Optional Copy Formats Supported`; nvme_command.csv, column 226, after `Optional Copy Formats Supported`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20246 of its text. Its words:

> Copy Descriptor Format 0 Support (CDF0S): If this bit is set to

- Note: Matched by bit position; the specification's bit name is CDF0S.

### `Optional Copy Formats Supported.Bit 1`

Copy Descriptor Format 1 Support (CDF1S), bit 1 of Optional Copy Formats Supported: 1 means the drive supports Copy descriptor format 1h; 0 means it does not.

- In the export: NVME_Transactions.csv, column 245, after `Optional Copy Formats Supported.Bit 0`; nvme_command.csv, column 227, after `Optional Copy Formats Supported.Bit 0`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20243 of its text. Its words:

> Copy Descriptor Format 1 Support (CDF1S): If this bit is set to

- Note: Matched by bit position; the specification's bit name is CDF1S.

### `SGL Support`

SGL Support: four-byte field in the Identify Controller data telling whether the drive supports Scatter Gather Lists (a way for a command to describe a data buffer in pieces) and which descriptor types and features. Child columns are its bits and bit groups.

- In the export: NVME_Transactions.csv, column 246, after `Optional Copy Formats Supported.Bit 1`; nvme_command.csv, column 228, after `Optional Copy Formats Supported.Bit 1`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20262 of its text. Its words:

> SGL Support (SGLS): This field indicates if SGLs are supported and the particular SGL

- Note: Bytes 539:536 of the Identify Controller data.

### `SGL Support.SGLS`

SGL Support, bits 1:0 of the SGL Support field: 00b Scatter Gather Lists not supported; 01b supported with no alignment or granularity requirement for data blocks; 10b supported with dword alignment and granularity requirement for data blocks; 11b reserved.

- In the export: NVME_Transactions.csv, column 247, after `SGL Support`; nvme_command.csv, column 229, after `SGL Support`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20307 of its text. Its words:

> SGL Support (SGLS): This field is used to determine the SGL support.

- Note: The child has the same name as its parent; it is the two-bit value in bits 1:0 (the software lists the bit fields from the lowest bit upward).

### `SGL Support.KSDBDS`

Keyed SGL Data Block Descriptor Support (KSDBDS), bit 2 of SGL Support: 1 means the drive supports the Keyed SGL Data Block descriptor; 0 means it does not.

- In the export: NVME_Transactions.csv, column 248, after `SGL Support.SGLS`; nvme_command.csv, column 230, after `SGL Support.SGLS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20302 of its text. Its words:

> Keyed SGL Data Block Descriptor Support (KSDBDS): If this bit is


### `SGL Support.SDT`

SGL Descriptor Threshold (SDT), bits 15:8 of SGL Support: the recommended maximum number of SGL descriptors in one command. 0 means no recommended maximum is reported.

- In the export: NVME_Transactions.csv, column 249, after `SGL Support.KSDBDS`; nvme_command.csv, column 231, after `SGL Support.KSDBDS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20296 of its text. Its words:

> SGL Descriptor Threshold (SDT): This field indicates the


### `SGL Support.SBBDS`

SGL Bit Bucket Descriptor Supported (SBBDS), bit 16 of SGL Support: 1 means the SGL Bit Bucket descriptor, used to discard part of the source data, is supported; 0 means it is not.

- In the export: NVME_Transactions.csv, column 250, after `SGL Support.SDT`; nvme_command.csv, column 232, after `SGL Support.SDT`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20293 of its text. Its words:

> SGL Bit Bucket Descriptor Supported (SBBDS): If this bit is set to


### `SGL Support.MBA`

Metadata Buffer Alignment (MBA), bit 17 of SGL Support: 1 means a byte aligned contiguous physical buffer of metadata, given by the Metadata Pointer field, is supported when the command's data pointer type is 01b; 0 means it is not.

- In the export: NVME_Transactions.csv, column 251, after `SGL Support.SBBDS`; nvme_command.csv, column 233, after `SGL Support.SBBDS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20286 of its text. Its words:

> Metadata Buffer Alignment (MBA): This bit indicates metadata buffer


### `SGL Support.LLDTS`

Length Larger than Data Transfer Support (LLDTS), bit 18 of SGL Support: 1 means the drive accepts a command whose data or metadata SGL is longer than the amount of data transferred; 0 means the SGL length must equal the amount transferred.

- In the export: NVME_Transactions.csv, column 252, after `SGL Support.MBA`; nvme_command.csv, column 234, after `SGL Support.MBA`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20281 of its text. Its words:

> Length Larger than Data Transfer Support (LLDTS): If this bit is set


### `SGL Support.MSDS`

MPTR SGL Descriptor Support (MSDS), bit 19 of SGL Support: 1 means a Metadata Pointer holding the address of an SGL segment with exactly one qword aligned SGL descriptor is supported; 0 means a Metadata Pointer containing an SGL descriptor is not supported.

- In the export: NVME_Transactions.csv, column 253, after `SGL Support.LLDTS`; nvme_command.csv, column 235, after `SGL Support.LLDTS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20276 of its text. Its words:

> MPTR SGL Descriptor Support (MSDS): If this bit is set to


### `SGL Support.SAOS`

SGL Address Offset Supported (SAOS), bit 20 of SGL Support: 1 means the Address field of SGL Data Block, SGL Segment and SGL Last Segment descriptors may hold an offset; 0 means an offset there is not supported.

- In the export: NVME_Transactions.csv, column 254, after `SGL Support.MSDS`; nvme_command.csv, column 236, after `SGL Support.MSDS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20271 of its text. Its words:

> SGL Address Offset Supported (SAOS): If this bit is set to


### `SGL Support.TSDBDS`

Transport SGL Data Block Descriptor Support (TSDBDS), bit 21 of SGL Support: 1 means the drive supports the Transport SGL Data Block descriptor; 0 means it does not.

- In the export: NVME_Transactions.csv, column 255, after `SGL Support.SAOS`; nvme_command.csv, column 237, after `SGL Support.SAOS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20266 of its text. Its words:

> Transport SGL Data Block Descriptor Support (TSDBDS): If this bit


### `SGL Support.MNAN`

Maximum Number of Allowed Namespaces: the most namespaces the NVM subsystem supports. 0 means the maximum is at most the Number of Namespaces value. A drive that reports Asymmetric Namespace Access sets a non-zero value no larger than Number of Namespaces.

- In the export: NVME_Transactions.csv, column 256, after `SGL Support.TSDBDS`; nvme_command.csv, column 238, after `SGL Support.TSDBDS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20331 of its text. Its words:

> Maximum Number of Allowed Namespaces (MNAN): This field indicates the maximum

- Note: Listed under SGL Support in the export, but in the specification it is a separate four-byte field (bytes 543:540) that follows SGL Support.

### `SGL Support.MAXDNA`

Maximum Domain Namespace Attachments: the maximum of the sum of the namespaces attached to each I/O controller in the Domain. 0 means no maximum is specified. All I/O controllers in the Domain report the same value.

- In the export: NVME_Transactions.csv, column 257, after `SGL Support.MNAN`; nvme_command.csv, column 239, after `SGL Support.MNAN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20338 of its text. Its words:

> Maximum Domain Namespace Attachments (MAXDNA): Indicates the maximum of

- Note: Listed under SGL Support in the export, but in the specification it is a separate field (bytes 559:544) that follows MNAN.

### `SGL Support.MAXCNA`

Maximum I/O Controller Namespace Attachments: the maximum number of namespaces that may be attached to this I/O controller. 0 means no maximum is specified; otherwise at most the number of namespaces the NVM subsystem supports.

- In the export: NVME_Transactions.csv, column 258, after `SGL Support.MAXDNA`; nvme_command.csv, column 240, after `SGL Support.MAXDNA`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20342 of its text. Its words:

> Maximum I/O Controller Namespace Attachments (MAXCNA): Indicates the

- Note: Listed under SGL Support in the export, but in the specification it is a separate four-byte field (bytes 563:560) that follows MAXDNA.

### `SGL Support.SUBNQN`

NVM Subsystem NVMe Qualified Name: the name of the drive's NVM subsystem, a UTF-8 text string ending with a null character, in the Identify Controller data (256 bytes). Mandatory for controllers supporting revision 1.2.1 or later.

- In the export: NVME_Transactions.csv, column 259, after `SGL Support.MAXCNA`; nvme_command.csv, column 241, after `SGL Support.MAXCNA`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20456 of its text. Its words:

> NVM Subsystem NVMe Qualified Name (SUBNQN): This field specifies the NVM

- Note: Listed under SGL Support in the export, but in the specification it is a separate field (bytes 1023:768) far after SGL Support; the export skips the fields between.

### `Power State Descriptors`

Power State Descriptors: in the Identify Controller data, each 32-byte descriptor gives the characteristics of one power state (power drawn, entry and exit time, relative speed). Up to 32 can be reported; the child columns are the fields of one descriptor.

- In the export: NVME_Transactions.csv, column 260, after `SGL Support.SUBNQN`; nvme_command.csv, column 242, after `SGL Support.SUBNQN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20558 of its text. Its words:

> Figure 313 defines the power state descriptor that describes the attributes of each power

- Note: The export shows one set of descriptor fields; the sources do not say which power state it describes (the specification has PSD0 to PSD31, bytes 3071:2048).

### `Power State Descriptors.MP`

Maximum Power: the sustained maximum power the NVM subsystem uses in this power state (bits 15:0 of the descriptor). Watts equal the value times the scale set by Max Power Scale (0.01 W or 0.0001 W). 0 means not reported.

- In the export: NVME_Transactions.csv, column 261, after `Power State Descriptors`; nvme_command.csv, column 243, after `Power State Descriptors`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 313: Identify – Power State Descriptor Data Structure, line 20716 of its text. Its words:

> Maximum Power (MP): This field indicates the sustained maximum power consumed by the NVM


### `Power State Descriptors.MPS`

Max Power Scale (bit 24 of the descriptor): the unit of Maximum Power. 0 means the value is in 0.01 watt units; 1 means 0.0001 watt units.

- In the export: NVME_Transactions.csv, column 262, after `Power State Descriptors.MP`; nvme_command.csv, column 244, after `Power State Descriptors.MP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 313: Identify – Power State Descriptor Data Structure, line 20701 of its text. Its words:

> Max Power Scale (MXPS): This bit indicates the scale for the Maximum Power field. If this bit is cleared

- Note: The specification 2.1 abbreviates it MXPS; the software and the LeCroy script manual call it MPS. Matched by meaning and bit position 24.

### `Power State Descriptors.NOPS`

Non-Operational State (bit 25 of the descriptor): 1 means the controller does not process I/O commands in this power state; 0 means it does process them.

- In the export: NVME_Transactions.csv, column 263, after `Power State Descriptors.MPS`; nvme_command.csv, column 245, after `Power State Descriptors.MPS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 313: Identify – Power State Descriptor Data Structure, line 20696 of its text. Its words:

> Non-Operational State (NOPS): This bit indicates whether the controller processes I/O commands in


### `Power State Descriptors.ENLAT`

Entry Latency: the maximum time, in microseconds, to enter this power state. 0 means not reported.

- In the export: NVME_Transactions.csv, column 264, after `Power State Descriptors.NOPS`; nvme_command.csv, column 246, after `Power State Descriptors.NOPS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 313: Identify – Power State Descriptor Data Structure, line 20692 of its text. Its words:

> Entry Latency (ENLAT): This field indicates the maximum entry latency in microseconds associated with


### `Power State Descriptors.EXLAT`

Exit Latency: the maximum time, in microseconds, to leave this power state. 0 means not reported.

- In the export: NVME_Transactions.csv, column 265, after `Power State Descriptors.ENLAT`; nvme_command.csv, column 247, after `Power State Descriptors.ENLAT`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 313: Identify – Power State Descriptor Data Structure, line 20689 of its text. Its words:

> Exit Latency (EXLAT): This field indicates the maximum exit latency in microseconds associated with


### `Power State Descriptors.RRT`

Relative Read Throughput: ranks this power state's read throughput against the drive's other power states. The value is below the number of power states; a lower value means higher read throughput.

- In the export: NVME_Transactions.csv, column 266, after `Power State Descriptors.EXLAT`; nvme_command.csv, column 248, after `Power State Descriptors.EXLAT`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 313: Identify – Power State Descriptor Data Structure, line 20684 of its text. Its words:

> Relative Read Throughput (RRT): This field indicates the relative read throughput associated with this


### `Power State Descriptors.RRL`

Relative Read Latency: ranks this power state's read latency against the drive's other power states. The value is below the number of power states; a lower value means lower read latency.

- In the export: NVME_Transactions.csv, column 267, after `Power State Descriptors.RRT`; nvme_command.csv, column 249, after `Power State Descriptors.RRT`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 313: Identify – Power State Descriptor Data Structure, line 20680 of its text. Its words:

> Relative Read Latency (RRL): This field indicates the relative read latency associated with this power


### `Power State Descriptors.RWT`

Relative Write Throughput: ranks this power state's write throughput against the drive's other power states. The value is below the number of power states; a lower value means higher write throughput.

- In the export: NVME_Transactions.csv, column 268, after `Power State Descriptors.RRL`; nvme_command.csv, column 250, after `Power State Descriptors.RRL`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 313: Identify – Power State Descriptor Data Structure, line 20674 of its text. Its words:

> Relative Write Throughput (RWT): This field indicates the relative write throughput associated with this


### `Power State Descriptors.RWL`

Relative Write Latency: ranks this power state's write latency against the drive's other power states. The value is below the number of power states; a lower value means lower write latency.

- In the export: NVME_Transactions.csv, column 269, after `Power State Descriptors.RWT`; nvme_command.csv, column 251, after `Power State Descriptors.RWT`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 313: Identify – Power State Descriptor Data Structure, line 20670 of its text. Its words:

> Relative Write Latency (RWL): This field indicates the relative write latency associated with this power


### `Power State Descriptors.IDLP`

Idle Power: the typical power the NVM subsystem uses over 30 seconds in this power state when idle, measured after 10 idle seconds. Watts equal the value times the Idle Power Scale. 0 means not reported.

- In the export: NVME_Transactions.csv, column 270, after `Power State Descriptors.RWL`; nvme_command.csv, column 252, after `Power State Descriptors.RWL`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 313: Identify – Power State Descriptor Data Structure, line 20660 of its text. Its words:

> Idle Power (IDLP): This field indicates the typical power consumed by the NVM subsystem over 30


### `Power State Descriptors.IPS`

Idle Power Scale: the unit of Idle Power. 00b not reported for this power state; 01b 0.0001 watt; 10b 0.01 watt; 11b reserved.

- In the export: NVME_Transactions.csv, column 271, after `Power State Descriptors.IDLP`; nvme_command.csv, column 253, after `Power State Descriptors.IDLP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 313: Identify – Power State Descriptor Data Structure, line 20652 of its text. Its words:

> Idle Power Scale (IPS): This field indicates the scale for the Idle Power field.


### `Power State Descriptors.ACTP`

Active Power: the largest average power the NVM subsystem uses over a 10 second period in this power state, with the workload named in Active Power Workload. Watts equal the value times the Active Power Scale. 0 means not reported.

- In the export: NVME_Transactions.csv, column 272, after `Power State Descriptors.IPS`; nvme_command.csv, column 254, after `Power State Descriptors.IPS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 313: Identify – Power State Descriptor Data Structure, line 20646 of its text. Its words:

> Active Power (ACTP): This field indicates the largest average power consumed by the NVM subsystem


### `Power State Descriptors.APW`

Active Power Workload: the workload used to measure Active Power. 000b no workload (unknown); 001b extended idle period with a burst of random writes; 010b heavy sequential writes; other values reserved.

- In the export: NVME_Transactions.csv, column 273, after `Power State Descriptors.ACTP`; nvme_command.csv, column 255, after `Power State Descriptors.ACTP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 313: Identify – Power State Descriptor Data Structure, line 20633 of its text. Its words:

> Active Power Workload (APW): This field indicates the workload used to calculate maximum power for

- Note: The workload values are from the Workload Hints figure (Figure 626) of the power management section, line 32753 onward.

### `Power State Descriptors.APS`

Active Power Scale: the unit of Active Power. 00b not reported for this power state; 01b 0.0001 watt; 10b 0.01 watt; 11b reserved.

- In the export: NVME_Transactions.csv, column 274, after `Power State Descriptors.APW`; nvme_command.csv, column 256, after `Power State Descriptors.APW`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 313: Identify – Power State Descriptor Data Structure, line 20623 of its text. Its words:

> Active Power Scale (APS): This field indicates the scale for the Active Power field.


### `Vendor Specific`

Vendor Specific: the last 1,024 bytes (bytes 3072 to 4095) of the Identify Controller data, defined by the drive's manufacturer. The NVMe specification gives them no meaning, so they cannot be decoded without the vendor's documentation.

- In the export: NVME_Transactions.csv, column 275, after `Power State Descriptors.APS`; nvme_command.csv, column 257, after `Power State Descriptors.APS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 312: Identify – Identify Controller Data Structure, I/O Command Set Independent, line 20548 of its text. Its words:

> Vendor Specific (VS)

- Note: Placed after the Power State Descriptors in the export, which matches bytes 4095:3072 of the Identify Controller data.

### `Warnings`

Warnings: NVMe warning messages the analyzer attached to this command or transaction, or to the block of decoded fields that ends just before it (in Identify data, the Identify Controller structure).

- In the export: NVME_Transactions.csv, column 276, after `Vendor Specific`; nvme_command.csv, column 30, after `Time Stamp`.
- Source: Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), 6.3.12.25 NVMe Warning Messages, line 11063 of its text. Its words:

> The PCIe Protocol Analysis software is capable of decoding the following NVMe Warning

- Note: The real header cell has no label; the application names it Warnings (the real text is like '1 warning(s)'). The manual shows the warning texts only as pictures.

### `NSZE`

Namespace Size: the total size of the namespace, counted in logical blocks of the formatted size, in the Identify Namespace data the drive returns. A namespace of n blocks covers logical block address 0 through n minus 1.

- In the export: NVME_Transactions.csv, column 277, after `Warnings`; nvme_command.csv, column 259, after `Errors#2`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4365 of its text. Its words:

> Namespace Size (NSZE): This field indicates the total size of the namespace in logical


### `NCAP`

Namespace Capacity: the largest number of logical blocks that may be allocated in the namespace at any one time, in the Identify Namespace data. Counted in logical blocks of the formatted size; spare blocks are not included.

- In the export: NVME_Transactions.csv, column 278, after `NSZE`; nvme_command.csv, column 260, after `NSZE`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4370 of its text. Its words:

> Namespace Capacity (NCAP): This field indicates the maximum number of logical


### `NUSE`

Namespace Utilization: the number of logical blocks currently allocated in the namespace, in the Identify Namespace data. It is less than or equal to the Namespace Capacity. Counted in logical blocks of the formatted size.

- In the export: NVME_Transactions.csv, column 279, after `NCAP`; nvme_command.csv, column 261, after `NCAP`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4375 of its text. Its words:

> Namespace Utilization (NUSE): This field indicates the current number of logical


### `NSFEAT`

Namespace Features: one byte of feature flags in the Identify Namespace data the drive returns (thin provisioning, namespace-specific atomic write fields, deallocated-block error, identifier reuse, write performance hints). The columns after it show those bits.

- In the export: NVME_Transactions.csv, column 280, after `NUSE`; nvme_command.csv, column 262, after `NUSE`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4393 of its text. Its words:

> Namespace Features (NSFEAT): This field defines features of the namespace.

- Note: The column NSFEAT.NLBAF that follows it is not a bit of this byte (see its own entry).

### `NSFEAT.THINP`

Thin Provisioning, bit 0 of Namespace Features: 1 means the namespace supports thin provisioning; 0 means thin provisioning is not supported.

- In the export: NVME_Transactions.csv, column 281, after `NSFEAT`; nvme_command.csv, column 263, after `NSFEAT`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4424 of its text. Its words:

> Thin Provisioning (THINP): If this bit is set to


### `NSFEAT.NSABP`

Namespace Supported Atomic Boundary and Power, bit 1 of Namespace Features: 1 means the namespace's own atomic write size and boundary fields are defined and the host should use them instead of the controller-wide ones; 0 means use the controller-wide values.

- In the export: NVME_Transactions.csv, column 282, after `NSFEAT.THINP`; nvme_command.csv, column 264, after `NSFEAT.THINP`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4415 of its text. Its words:

> Namespace Supported Atomic Boundary & Power (NSABP): If this bit


### `NSFEAT.DAE`

Deallocated Error, bit 2 of Namespace Features: 1 means the drive supports the Deallocated or Unwritten Logical Block error for this namespace; 0 means it does not.

- In the export: NVME_Transactions.csv, column 283, after `NSFEAT.NSABP`; nvme_command.csv, column 265, after `NSFEAT.NSABP`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4410 of its text. Its words:

> Deallocated Error (DAE): If this bit is set to


### `NSFEAT.Bit 3`

UID Reuse (UIDREUSE), bit 3 of Namespace Features: 1 means the namespace's unique identifier (NGUID) and EUI64 values, if non-zero, are never reused for a new namespace after this one is deleted; 0 means they may be reused.

- In the export: NVME_Transactions.csv, column 284, after `NSFEAT.DAE`; nvme_command.csv, column 266, after `NSFEAT.DAE`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4406 of its text. Its words:

> UID Reuse (UIDREUSE): This bit is as defined in the UIDREUSE bit in the

- Note: The export labels this bit only by its number; the match to UIDREUSE is by bit position 3 in the specification. The full definition is in the NVM Express Base Specification (Identify Namespace, I/O Command Set Independent).

### `NSFEAT.OPTPERF`

Optional Write Performance, bits 5:4 of Namespace Features: says whether the namespace reports write alignment and granularity hints (preferred write granularity and alignment, preferred deallocate granularity and alignment, optimal write size). 00b means none of them are reported.

- In the export: NVME_Transactions.csv, column 285, after `NSFEAT.Bit 3`; nvme_command.csv, column 267, after `NSFEAT.Bit 3`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4404 of its text. Its words:

> Optional Write Performance (OPTPERF): Indicate support of alignment

- Note: Specification 1.1 prints it as a 2-bit field (bits 5:4); older revisions define a single bit 4. The export column does not show the width. The value table (Figure 115) calls it Optimal Write Performance.

### `NSFEAT.NLBAF`

Number of LBA Formats: how many combinations of LBA data size and metadata size the namespace supports, minus one (a 0's based value). The formats themselves are listed in the LBA Format entries later in the same data.

- In the export: NVME_Transactions.csv, column 286, after `NSFEAT.OPTPERF`; nvme_command.csv, column 268, after `NSFEAT.OPTPERF`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4427 of its text. Its words:

> Number of LBA Formats (NLBAF): This field defines the number of supported LBA

- Note: The export lists this column under the Namespace Features heading, but in the data structure it is its own field, not a bit of Namespace Features. It is a separate byte (byte 25) after the Namespace Features byte.

### `FLBAS`

Formatted LBA Size: one byte in the Identify Namespace data saying which combination of LBA data size and metadata size the namespace is currently formatted with. The columns after it are the format index and a metadata flag.

- In the export: NVME_Transactions.csv, column 287, after `NSFEAT.NLBAF`; nvme_command.csv, column 269, after `NSFEAT.NLBAF`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4457 of its text. Its words:

> Formatted LBA Size (FLBAS): This field indicates the LBA data size and metadata


### `FLBAS.Bits 3:0`

Format Index Lower, bits 3:0 of Formatted LBA Size: the least-significant 4 bits of the index of the LBA format that was used to format the namespace.

- In the export: NVME_Transactions.csv, column 288, after `FLBAS`; nvme_command.csv, column 270, after `FLBAS`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4471 of its text. Its words:

> Format Index Lower (FIDXL): This field indicates the least-significant 4

- Note: Older specification revisions call this field the LBA Format index (bits 3:0). The export labels it only by its bit range.

### `FLBAS.Bit 4`

Metadata Transferred as Extended LBA, bit 4 of Formatted LBA Size: 1 means metadata is sent at the end of the logical block (an extended logical block); 0 means all metadata of a command goes in a separate contiguous buffer. Not applicable without metadata.

- In the export: NVME_Transactions.csv, column 289, after `FLBAS.Bits 3:0`; nvme_command.csv, column 271, after `FLBAS.Bits 3:0`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4466 of its text. Its words:

> Metadata Transferred as Extended LBA (MTELBA): If this bit is set to


### `FLBAS.Bit 6:5`

Format Index Upper, bits 6:5 of Formatted LBA Size: the two most-significant bits of the format index used to format the namespace. If the drive supports 16 LBA formats or fewer, the host ignores it.

- In the export: NVME_Transactions.csv, column 290, after `FLBAS.Bit 4`; nvme_command.csv, column 272, after `FLBAS.Bit 4`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4461 of its text. Its words:

> Format Index Upper (FIDXU): This field indicates the most-significant 2

- Note: The export labels it only by its bit range; matched to FIDXU by bit position 6:5.

### `MC`

Metadata Capabilities: one byte in the Identify Namespace data saying how the namespace can transfer metadata (as part of an extended logical block, or in a separate buffer). The columns after it are its two bits.

- In the export: NVME_Transactions.csv, column 291, after `FLBAS.Bit 6:5`; nvme_command.csv, column 273, after `FLBAS.Bit 6:5`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4474 of its text. Its words:

> Metadata Capabilities (MC): This field indicates the capabilities for metadata.


### `MC.Bit 0`

Metadata Transferred as Extended LBA Support, bit 0 of Metadata Capabilities: 1 means the namespace supports metadata transferred as part of an extended data logical block; 0 means it does not.

- In the export: NVME_Transactions.csv, column 292, after `MC`; nvme_command.csv, column 274, after `MC`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4482 of its text. Its words:

> Metadata Transferred as Extended LBA Support (MTELBAS): If this bit

- Note: The export labels it only by its bit number; matched to MTELBAS by bit position 0.

### `MC.Bit 1`

Metadata Transferred as Separate Buffer Support, bit 1 of Metadata Capabilities: 1 means the namespace supports metadata transferred in a separate buffer given by the Metadata Pointer; 0 means it does not.

- In the export: NVME_Transactions.csv, column 293, after `MC.Bit 0`; nvme_command.csv, column 275, after `MC.Bit 0`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4477 of its text. Its words:

> Metadata Transferred as Separate Buffer Support (MTSBS): If this bit is

- Note: The export labels it only by its bit number; matched to MTSBS by bit position 1.

### `DPC`

End-to-end Data Protection Capabilities: one byte in the Identify Namespace data saying which protection information types (1, 2, 3) and positions (first or last bytes of the metadata) the namespace supports. Several bits may be set.

- In the export: NVME_Transactions.csv, column 294, after `MC.Bit 1`; nvme_command.csv, column 276, after `MC.Bit 1`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4500 of its text. Its words:

> End-to-end Data Protection Capabilities (DPC): This field indicates the capabilities


### `DPC.PIT1S`

Protection Information Type 1 Supported, bit 0 of End-to-end Data Protection Capabilities: 1 means the namespace supports Type 1 protection information; 0 means it does not.

- In the export: NVME_Transactions.csv, column 295, after `DPC`; nvme_command.csv, column 277, after `DPC`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4524 of its text. Its words:

> Protection Information Type 1 Supported (PIT1S): If this bit is set to


### `DPC.PIT2S`

Protection Information Type 2 Supported, bit 1 of End-to-end Data Protection Capabilities: 1 means the namespace supports Type 2 protection information; 0 means it does not.

- In the export: NVME_Transactions.csv, column 296, after `DPC.PIT1S`; nvme_command.csv, column 278, after `DPC.PIT1S`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4520 of its text. Its words:

> Protection Information Type 2 Supported (PIT2S): If this bit is set to


### `DPC.PIT3S`

Protection Information Type 3 Supported, bit 2 of End-to-end Data Protection Capabilities: 1 means the namespace supports Type 3 protection information; 0 means it does not.

- In the export: NVME_Transactions.csv, column 297, after `DPC.PIT2S`; nvme_command.csv, column 279, after `DPC.PIT2S`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4516 of its text. Its words:

> Protection Information Type 3 Supported (PIT3S): If this bit is set to


### `DPC.PIIFB`

Protection Information In First Bytes, bit 3 of End-to-end Data Protection Capabilities: 1 means the namespace supports protection information transferred as the first bytes of the metadata; 0 means it does not. Newer drives keep it 0.

- In the export: NVME_Transactions.csv, column 298, after `DPC.PIT3S`; nvme_command.csv, column 280, after `DPC.PIT3S`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4509 of its text. Its words:

> Protection Information In First Bytes (PIIFB): If this bit is set to

- Note: The specification says implementations compliant with revision 1.0 or later of the NVM Command Set Specification shall clear this bit to 0.

### `DPC.PIILB`

Protection Information In Last Bytes, bit 4 of End-to-end Data Protection Capabilities: 1 means the namespace supports protection information transferred as the last bytes of the metadata; 0 means it does not.

- In the export: NVME_Transactions.csv, column 299, after `DPC.PIIFB`; nvme_command.csv, column 281, after `DPC.PIIFB`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4505 of its text. Its words:

> Protection Information In Last Bytes (PIILB): If this bit is set to


### `DPS`

End-to-end Data Protection Type Settings: one byte in the Identify Namespace data giving the protection information type the namespace is currently set up with, and whether that information sits in the first or last bytes of the metadata.

- In the export: NVME_Transactions.csv, column 300, after `DPC.PIILB`; nvme_command.csv, column 282, after `DPC.PIILB`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4528 of its text. Its words:

> End-to-end Data Protection Type Settings (DPS): This field indicates the protection


### `DPS.PIT`

Protection Information Type, bits 2:0 of End-to-end Data Protection Type Settings: 0 means protection information is not enabled; 1, 2 or 3 means Type 1, Type 2 or Type 3 protection information is enabled. Values 4 to 7 are reserved.

- In the export: NVME_Transactions.csv, column 301, after `DPS`; nvme_command.csv, column 283, after `DPS`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4540 of its text. Its words:

> Protection Information Type (PIT): This field indicates whether


### `DPS.PIP`

Protection Information Position, bit 3 of End-to-end Data Protection Type Settings: 1 means protection information, if enabled, is transferred as the first bytes of the metadata; 0 means as the last bytes. Newer drives keep it 0.

- In the export: NVME_Transactions.csv, column 302, after `DPS.PIT`; nvme_command.csv, column 284, after `DPS.PIT`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4533 of its text. Its words:

> Protection Information Position (PIP): If this bit is set to

- Note: The specification says implementations compliant with version 1.0 or later of the NVM Command Set Specification shall clear this bit to 0.

### `NMIC`

Namespace Multi-path I/O and Namespace Sharing Capabilities: one byte in the Identify Namespace data saying whether the namespace may be shared by several controllers (and, in newer revisions, whether it is dispersed). The column after it is the shared flag.

- In the export: NVME_Transactions.csv, column 303, after `DPS.PIP`; nvme_command.csv, column 285, after `DPS.PIP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 319: Identify – I/O Command Set Independent Identify Namespace Data Structure, line 20997 of its text. Its words:

> Namespace Multi-path I/O and Namespace Sharing Capabilities (NMIC): This

- Note: The NVM Command Set Specification refers to the Base Specification for this field. The base specification also defines bit 1 (Dispersed Namespace), which this export has no column for.

### `NMIC.SHRNS`

Shared Namespace, bit 0 of Namespace Multi-path I/O and Namespace Sharing Capabilities: 1 means the namespace may be attached to two or more controllers in the subsystem at once; 0 means it is private and attaches to one controller at a time.

- In the export: NVME_Transactions.csv, column 304, after `NMIC`; nvme_command.csv, column 286, after `NMIC`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 319: Identify – I/O Command Set Independent Identify Namespace Data Structure, line 21007 of its text. Its words:

> Shared Namespace (SHRNS): If this bit is set to


### `RESCAP`

Reservation Capabilities: one byte in the Identify Namespace data saying which reservation features the namespace supports (types of reservation, persistence through power loss). 0 means reservations are not supported. The columns after it are its bits.

- In the export: NVME_Transactions.csv, column 305, after `NMIC.SHRNS`; nvme_command.csv, column 287, after `NMIC.SHRNS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 319: Identify – I/O Command Set Independent Identify Namespace Data Structure, line 21025 of its text. Its words:

> Reservation Capabilities (RESCAP): This field indicates the reservation


### `RESCAP.PTPLS`

Persist Through Power Loss Support, bit 0 of Reservation Capabilities: 1 means the namespace supports keeping reservations and registrants through a power loss; 0 means it does not.

- In the export: NVME_Transactions.csv, column 306, after `RESCAP`; nvme_command.csv, column 288, after `RESCAP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 319: Identify – I/O Command Set Independent Identify Namespace Data Structure, line 21067 of its text. Its words:

> Persist Through Power Loss Support (PTPLS): If this bit is set to


### `RESCAP.WES`

Write Exclusive Support, bit 1 of Reservation Capabilities: 1 means the namespace supports the Write Exclusive reservation type; 0 means it does not.

- In the export: NVME_Transactions.csv, column 307, after `RESCAP.PTPLS`; nvme_command.csv, column 289, after `RESCAP.PTPLS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 319: Identify – I/O Command Set Independent Identify Namespace Data Structure, line 21062 of its text. Its words:

> Write Exclusive Support (WES): If this bit is set to


### `RESCAP.EAS`

Exclusive Access Support, bit 2 of Reservation Capabilities: 1 means the namespace supports the Exclusive Access reservation type; 0 means it does not.

- In the export: NVME_Transactions.csv, column 308, after `RESCAP.WES`; nvme_command.csv, column 290, after `RESCAP.WES`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 319: Identify – I/O Command Set Independent Identify Namespace Data Structure, line 21057 of its text. Its words:

> Exclusive Access Support (EAS): If this bit is set to


### `RESCAP.WEROS`

Write Exclusive - Registrants Only Support, bit 3 of Reservation Capabilities: 1 means the namespace supports the Write Exclusive - Registrants Only reservation type; 0 means it does not.

- In the export: NVME_Transactions.csv, column 309, after `RESCAP.EAS`; nvme_command.csv, column 291, after `RESCAP.EAS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 319: Identify – I/O Command Set Independent Identify Namespace Data Structure, line 21052 of its text. Its words:

> Write Exclusive – Registrants Only Support (WEROS): If this bit is set


### `RESCAP.EAROS`

Exclusive Access - Registrants Only Support, bit 4 of Reservation Capabilities: 1 means the namespace supports the Exclusive Access - Registrants Only reservation type; 0 means it does not.

- In the export: NVME_Transactions.csv, column 310, after `RESCAP.WEROS`; nvme_command.csv, column 292, after `RESCAP.WEROS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 319: Identify – I/O Command Set Independent Identify Namespace Data Structure, line 21047 of its text. Its words:

> Exclusive Access – Registrants Only Support (EAROS): If this bit is


### `RESCAP.WEARS`

Write Exclusive - All Registrants Support, bit 5 of Reservation Capabilities: 1 means the namespace supports the Write Exclusive - All Registrants reservation type; 0 means it does not.

- In the export: NVME_Transactions.csv, column 311, after `RESCAP.EAROS`; nvme_command.csv, column 293, after `RESCAP.EAROS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 319: Identify – I/O Command Set Independent Identify Namespace Data Structure, line 21041 of its text. Its words:

> Write Exclusive – All Registrants Support (WEARS): If this bit is set


### `RESCAP.EAARS`

Exclusive Access - All Registrants Support, bit 6 of Reservation Capabilities: 1 means the namespace supports the Exclusive Access - All Registrants reservation type; 0 means it does not.

- In the export: NVME_Transactions.csv, column 312, after `RESCAP.WEARS`; nvme_command.csv, column 294, after `RESCAP.WEARS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 319: Identify – I/O Command Set Independent Identify Namespace Data Structure, line 21036 of its text. Its words:

> Exclusive Access – All Registrants Support (EAARS): If this bit is set


### `RESCAP.IEKS`

Ignore Existing Key Support, bit 7 of Reservation Capabilities: 1 means Ignore Existing Key works as defined in Base Specification 1.3 or later; 0 means as defined in 1.2.1 or earlier. It must be 1 if the controller reports version 1.3 or later.

- In the export: NVME_Transactions.csv, column 313, after `RESCAP.EAARS`; nvme_command.csv, column 295, after `RESCAP.EAARS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 319: Identify – I/O Command Set Independent Identify Namespace Data Structure, line 21029 of its text. Its words:

> Ignore Existing Key Support (IEKS): If this bit is set to


### `FPI`

Format Progress Indicator: one byte in the Identify Namespace data that, while a format is running, tells what percentage of the namespace still has to be formatted. The columns after it are the remaining percentage and a support flag.

- In the export: NVME_Transactions.csv, column 314, after `RESCAP.IEKS`; nvme_command.csv, column 296, after `RESCAP.IEKS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 319: Identify – I/O Command Set Independent Identify Namespace Data Structure, line 21085 of its text. Its words:

> Format Progress Indicator (FPI): If a format operation is in progress, this field


### `FPI.RFNVM`

Remaining Format NVM, bits 6:0 of Format Progress Indicator: the percentage of the Format NVM command still to be completed (25 means 75 percent done). With the indicator supported, 0 means no format is in progress.

- In the export: NVME_Transactions.csv, column 315, after `FPI`; nvme_command.csv, column 297, after `FPI`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 319: Identify – I/O Command Set Independent Identify Namespace Data Structure, line 21093 of its text. Its words:

> Remaining Format NVM (RFNVM): This field indicates the percentage


### `FPI.FPIS`

Format Progress Indicator Support, bit 7 of Format Progress Indicator: 1 means the namespace supports the Format Progress Indicator reported in the Remaining Format NVM value; 0 means it does not.

- In the export: NVME_Transactions.csv, column 316, after `FPI.RFNVM`; nvme_command.csv, column 298, after `FPI.RFNVM`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 319: Identify – I/O Command Set Independent Identify Namespace Data Structure, line 21088 of its text. Its words:

> Format Progress Indicator Support (FPIS): If this bit is set to


### `DLFEAT`

Deallocate Logical Block Features: one byte in the Identify Namespace data about what a read of a deallocated logical block returns and whether Write Zeroes may deallocate. The columns after it show those bits.

- In the export: NVME_Transactions.csv, column 317, after `FPI.FPIS`; nvme_command.csv, column 299, after `FPI.FPIS`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4577 of its text. Its words:

> Deallocate Logical Block Features (DLFEAT): This field indicates information about

- Note: In this export many further fields (NAWUN to ANAGRPID) are listed under the DLFEAT heading; they are separate fields of the structure, not bits of DLFEAT.

### `DLFEAT.Bits 0-2`

Deallocation Read Behavior, bits 2:0 of Deallocate Logical Block Features: what a read of a deallocated logical block returns. 0 means not reported; 1 means all bytes 0; 2 means all bytes FFh (hexadecimal). Other values are reserved.

- In the export: NVME_Transactions.csv, column 318, after `DLFEAT`; nvme_command.csv, column 300, after `DLFEAT`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4593 of its text. Its words:

> Deallocation Read Behavior (DRB): This field indicates the deallocated logical

- Note: The export labels it only by its bit range; matched to DRB by bit position 2:0.

### `DLFEAT.Bit 3`

Write Zeroes Deallocation Support, bit 3 of Deallocate Logical Block Features: 1 means the controller supports the Deallocate bit in the Write Zeroes command for this namespace; 0 means it does not.

- In the export: NVME_Transactions.csv, column 319, after `DLFEAT.Bits 0-2`; nvme_command.csv, column 301, after `DLFEAT.Bits 0-2`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4588 of its text. Its words:

> Write Zeroes Deallocation Support (WZDS): If this bit is set to

- Note: The export labels it only by its bit number; matched to WZDS by bit position 3.

### `DLFEAT.Bit 4`

Guard Deallocation Status, bit 4 of Deallocate Logical Block Features: 1 means the Guard field of deallocated blocks that carry protection information holds the CRC of the data read; 0 means every byte of that Guard field is FFh.

- In the export: NVME_Transactions.csv, column 320, after `DLFEAT.Bit 3`; nvme_command.csv, column 302, after `DLFEAT.Bit 3`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4581 of its text. Its words:

> Guard Deallocation Status (GDS): If this bit is set to

- Note: The export labels it only by its bit number; matched to GDS by bit position 4.

### `DLFEAT.NAWUN`

Namespace Atomic Write Unit Normal: size, in logical blocks (0's based), of a write guaranteed to be written atomically during normal operation. 0 means the same as the controller-wide value. Reserved unless the NSABP bit is 1.

- In the export: NVME_Transactions.csv, column 321, after `DLFEAT.Bit 4`; nvme_command.csv, column 303, after `DLFEAT.Bit 4`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4602 of its text. Its words:

> Namespace Atomic Write Unit Normal (NAWUN): This field indicates the namespace

- Note: The export lists this column under the Deallocate Logical Block Features heading, but in the data structure it is its own field, not a bit of Deallocate Logical Block Features. It is bytes 35:34.

### `DLFEAT.NAWUPF`

Namespace Atomic Write Unit Power Fail: size, in logical blocks (0's based), of a write guaranteed to be written atomically during a power fail or error condition. 0 means the same as the controller-wide value. Reserved unless NSABP is 1.

- In the export: NVME_Transactions.csv, column 322, after `DLFEAT.NAWUN`; nvme_command.csv, column 304, after `DLFEAT.NAWUN`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4609 of its text. Its words:

> Namespace Atomic Write Unit Power Fail (NAWUPF): This field indicates the

- Note: The export lists this column under the Deallocate Logical Block Features heading, but in the data structure it is its own field, not a bit of Deallocate Logical Block Features. It is bytes 37:36.

### `DLFEAT.NACWU`

Namespace Atomic Compare and Write Unit: size, in logical blocks (0's based), of a write guaranteed to be written atomically for a Compare and Write fused command. 0 means the same as the controller-wide value. Reserved unless NSABP is 1.

- In the export: NVME_Transactions.csv, column 323, after `DLFEAT.NAWUPF`; nvme_command.csv, column 305, after `DLFEAT.NAWUPF`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4631 of its text. Its words:

> Namespace Atomic Compare & Write Unit (NACWU): This field indicates the

- Note: The export lists this column under the Deallocate Logical Block Features heading, but in the data structure it is its own field, not a bit of Deallocate Logical Block Features. It is bytes 39:38.

### `DLFEAT.NABSN`

Namespace Atomic Boundary Size Normal: atomic boundary size, in logical blocks, for the normal atomic write unit. Writes crossing a boundary are not guaranteed atomic. 0 means no atomic boundaries for normal writes.

- In the export: NVME_Transactions.csv, column 324, after `DLFEAT.NACWU`; nvme_command.csv, column 306, after `DLFEAT.NACWU`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4640 of its text. Its words:

> Namespace Atomic Boundary Size Normal (NABSN): This field indicates the atomic

- Note: The export lists this column under the Deallocate Logical Block Features heading, but in the data structure it is its own field, not a bit of Deallocate Logical Block Features. It is bytes 41:40.

### `DLFEAT.NABO`

Namespace Atomic Boundary Offset: the logical block address in this namespace where the first atomic boundary starts. It is 0 when both atomic boundary size fields are 0.

- In the export: NVME_Transactions.csv, column 325, after `DLFEAT.NABSN`; nvme_command.csv, column 307, after `DLFEAT.NABSN`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4649 of its text. Its words:

> Namespace Atomic Boundary Offset (NABO): This field indicates the LBA on this

- Note: The export lists this column under the Deallocate Logical Block Features heading, but in the data structure it is its own field, not a bit of Deallocate Logical Block Features. It is bytes 43:42.

### `DLFEAT.NABSPF`

Namespace Atomic Boundary Size Power Fail: atomic boundary size, in logical blocks, for the power-fail atomic write unit. Writes crossing a boundary are not guaranteed atomic. 0 means no atomic boundaries for power fail or error conditions.

- In the export: NVME_Transactions.csv, column 326, after `DLFEAT.NABO`; nvme_command.csv, column 308, after `DLFEAT.NABO`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4654 of its text. Its words:

> Namespace Atomic Boundary Size Power Fail (NABSPF): This field indicates the

- Note: The export lists this column under the Deallocate Logical Block Features heading, but in the data structure it is its own field, not a bit of Deallocate Logical Block Features. It is bytes 45:44.

### `DLFEAT.NOIOB`

Namespace Optimal I/O Boundary: the optimal I/O boundary of the namespace in logical blocks; the host should build reads and writes that do not cross it. 0 means no optimal boundary is reported.

- In the export: NVME_Transactions.csv, column 327, after `DLFEAT.NABSPF`; nvme_command.csv, column 309, after `DLFEAT.NABSPF`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4665 of its text. Its words:

> Namespace Optimal I/O Boundary (NOIOB): This field indicates the optimal I/O

- Note: The export lists this column under the Deallocate Logical Block Features heading, but in the data structure it is its own field, not a bit of Deallocate Logical Block Features. It is bytes 47:46.

### `DLFEAT.NVMCAP`

NVM Capacity: the total size of the non-volatile memory allocated to this namespace, in bytes. It may differ from block size times namespace size because of thin provisioning or endurance settings.

- In the export: NVME_Transactions.csv, column 328, after `DLFEAT.NOIOB`; nvme_command.csv, column 310, after `DLFEAT.NOIOB`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4685 of its text. Its words:

> NVM Capacity (NVMCAP): This field indicates the total size of the NVM allocated to

- Note: The export lists this column under the Deallocate Logical Block Features heading, but in the data structure it is its own field, not a bit of Deallocate Logical Block Features. It is bytes 63:48.

### `DLFEAT.NPWG`

Namespace Preferred Write Granularity: the smallest recommended write granularity for the namespace, in logical blocks (0's based). Reserved when the namespace does not report write performance hints (OPTPERF).

- In the export: NVME_Transactions.csv, column 329, after `DLFEAT.NVMCAP`; nvme_command.csv, column 311, after `DLFEAT.NVMCAP`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4698 of its text. Its words:

> Namespace Preferred Write Granularity (NPWG): This field indicates the smallest

- Note: The export lists this column under the Deallocate Logical Block Features heading, but in the data structure it is its own field, not a bit of Deallocate Logical Block Features. It is bytes 65:64.

### `DLFEAT.NPWA`

Namespace Preferred Write Alignment: the recommended write alignment for the namespace, in logical blocks (0's based). Reserved when the namespace does not report write performance hints (OPTPERF).

- In the export: NVME_Transactions.csv, column 330, after `DLFEAT.NPWG`; nvme_command.csv, column 312, after `DLFEAT.NPWG`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4711 of its text. Its words:

> Namespace Preferred Write Alignment (NPWA): This field indicates the

- Note: The export lists this column under the Deallocate Logical Block Features heading, but in the data structure it is its own field, not a bit of Deallocate Logical Block Features. It is bytes 67:66.

### `DLFEAT.NPDG`

Namespace Preferred Deallocate Granularity: the recommended granularity, in logical blocks (0's based), for a Dataset Management command with the Deallocate attribute set. Reserved when write performance hints (OPTPERF) are not reported.

- In the export: NVME_Transactions.csv, column 331, after `DLFEAT.NPWA`; nvme_command.csv, column 313, after `DLFEAT.NPWA`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4719 of its text. Its words:

> Namespace Preferred Deallocate Granularity (NPDG): This field indicates the

- Note: The export lists this column under the Deallocate Logical Block Features heading, but in the data structure it is its own field, not a bit of Deallocate Logical Block Features. It is bytes 69:68.

### `DLFEAT.NPDA`

Namespace Preferred Deallocate Alignment: the recommended alignment, in logical blocks (0's based), for a Dataset Management command with the Deallocate attribute set. Reserved when write performance hints (OPTPERF) are not reported.

- In the export: NVME_Transactions.csv, column 332, after `DLFEAT.NPDG`; nvme_command.csv, column 314, after `DLFEAT.NPDG`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4728 of its text. Its words:

> Namespace Preferred Deallocate Alignment (NPDA): This field indicates the

- Note: The export lists this column under the Deallocate Logical Block Features heading, but in the data structure it is its own field, not a bit of Deallocate Logical Block Features. It is bytes 71:70.

### `DLFEAT.NOWS`

Namespace Optimal Write Size: the size, in logical blocks (0's based), for optimal write performance on this namespace. Reserved when write performance hints (OPTPERF) are not reported. Should not exceed the largest transfer the drive allows.

- In the export: NVME_Transactions.csv, column 333, after `DLFEAT.NPDA`; nvme_command.csv, column 315, after `DLFEAT.NPDA`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4749 of its text. Its words:

> Namespace Optimal Write Size (NOWS): This field indicates the size in logical blocks

- Note: The export lists this column under the Deallocate Logical Block Features heading, but in the data structure it is its own field, not a bit of Deallocate Logical Block Features. It is bytes 73:72.

### `DLFEAT.MSSRL`

Maximum Single Source Range Length: the largest number of logical blocks that one source range entry of a Copy command may name. Set to a non-zero value when the drive supports the Copy command.

- In the export: NVME_Transactions.csv, column 334, after `DLFEAT.NOWS`; nvme_command.csv, column 316, after `DLFEAT.NOWS`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4770 of its text. Its words:

> Maximum Single Source Range Length (MSSRL): This field indicates the maximum

- Note: The export lists this column under the Deallocate Logical Block Features heading, but in the data structure it is its own field, not a bit of Deallocate Logical Block Features. It is bytes 75:74.

### `DLFEAT.MCL`

Maximum Copy Length: the largest total number of logical blocks a single Copy command may move (the sum over all its source ranges). Set to a non-zero value when the drive supports the Copy command.

- In the export: NVME_Transactions.csv, column 335, after `DLFEAT.MSSRL`; nvme_command.csv, column 317, after `DLFEAT.MSSRL`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4775 of its text. Its words:

> Maximum Copy Length (MCL): This field indicates the maximum number of logical

- Note: The export lists this column under the Deallocate Logical Block Features heading, but in the data structure it is its own field, not a bit of Deallocate Logical Block Features. It is bytes 79:76.

### `DLFEAT.MSRC`

Maximum Source Range Count: the largest number of source range entries a Copy command may use to name its source data (0's based value).

- In the export: NVME_Transactions.csv, column 336, after `DLFEAT.MCL`; nvme_command.csv, column 318, after `DLFEAT.MCL`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4780 of its text. Its words:

> Maximum Source Range Count (MSRC): This field indicates the maximum number

- Note: The export lists this column under the Deallocate Logical Block Features heading, but in the data structure it is its own field, not a bit of Deallocate Logical Block Features. It is byte 80.

### `DLFEAT.ANAGRPID`

ANA Group Identifier: identifies the Asymmetric Namespace Access group the namespace belongs to. 0 when the controller does not support Asymmetric Namespace Access reporting.

- In the export: NVME_Transactions.csv, column 337, after `DLFEAT.MSRC`; nvme_command.csv, column 319, after `DLFEAT.MSRC`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 319: Identify – I/O Command Set Independent Identify Namespace Data Structure, line 21101 of its text. Its words:

> ANA Group Identifier (ANAGRPID): For NSID other than FFFFFFFFh, this field

- Note: The export lists this column under the Deallocate Logical Block Features heading, but in the data structure it is its own field, not a bit of Deallocate Logical Block Features. It is bytes 95:92. The NVM Command Set Specification defers to the Base Specification for it.

### `NSATTR`

Namespace Attributes: one byte in the Identify Namespace data with attributes of the namespace; the only defined bit is whether the namespace is currently write protected. The column after it is that bit.

- In the export: NVME_Transactions.csv, column 338, after `DLFEAT.ANAGRPID`; nvme_command.csv, column 320, after `DLFEAT.ANAGRPID`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 319: Identify – I/O Command Set Independent Identify Namespace Data Structure, line 21110 of its text. Its words:

> Namespace Attributes (NSATTR): This field specifies attributes of the

- Note: In this export the identifier fields NVMSETID, ENDGID, NGUID and EUI64 are listed under the NSATTR heading; they are separate fields, not bits of NSATTR.

### `NSATTR.CWP`

Currently Write Protected, bit 0 of Namespace Attributes: 1 means the namespace is write protected right now for any reason (for example write protection set, or media errors) and all writes fail; 0 means it is not.

- In the export: NVME_Transactions.csv, column 339, after `NSATTR`; nvme_command.csv, column 321, after `NSATTR`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 319: Identify – I/O Command Set Independent Identify Namespace Data Structure, line 21114 of its text. Its words:

> Currently Write Protected (CWP): If this bit is set to


### `NSATTR.NS_NVMSETID`

NVM Set Identifier: says which NVM Set the namespace is associated with. 0 when the controller does not support NVM Sets or the namespace has no formatted storage.

- In the export: NVME_Transactions.csv, column 340, after `NSATTR.CWP`; nvme_command.csv, column 322, after `NSATTR.CWP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 319: Identify – I/O Command Set Independent Identify Namespace Data Structure, line 21120 of its text. Its words:

> NVM Set Identifier (NVMSETID): For NSID other than FFFFFFFFh, this field

- Note: The export lists this column under the Namespace Attributes heading, but in the data structure it is its own field, not a bit of Namespace Attributes. The export spells the name NS_NVMSETID; matched to NVMSETID by meaning and position (bytes 101:100).

### `NSATTR.NS_ENDGID`

Endurance Group Identifier: says which Endurance Group the namespace is associated with. 0 when the controller does not support Endurance Groups or the namespace has no formatted storage.

- In the export: NVME_Transactions.csv, column 341, after `NSATTR.NS_NVMSETID`; nvme_command.csv, column 323, after `NSATTR.NS_NVMSETID`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 319: Identify – I/O Command Set Independent Identify Namespace Data Structure, line 21125 of its text. Its words:

> Endurance Group Identifier (ENDGID): For NSID other than FFFFFFFFh, this

- Note: The export lists this column under the Namespace Attributes heading, but in the data structure it is its own field, not a bit of Namespace Attributes. The export spells the name NS_ENDGID; matched to ENDGID by meaning and position (bytes 103:102).

### `NSATTR.NGUID`

Namespace Globally Unique Identifier: a 128-bit globally unique value assigned when the namespace is created. It stays fixed for the life of the namespace, also across resets and formats. 0 if the drive cannot provide one.

- In the export: NVME_Transactions.csv, column 342, after `NSATTR.NS_ENDGID`; nvme_command.csv, column 324, after `NSATTR.NS_ENDGID`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4863 of its text. Its words:

> Namespace Globally Unique Identifier (NGUID): This field contains a 128-bit value

- Note: The export lists this column under the Namespace Attributes heading, but in the data structure it is its own field, not a bit of Namespace Attributes. It is bytes 119:104.

### `NSATTR.EUI64`

IEEE Extended Unique Identifier: a 64-bit globally unique value assigned when the namespace is created. It stays fixed for the life of the namespace, also across resets and formats. 0 if the drive cannot provide one.

- In the export: NVME_Transactions.csv, column 343, after `NSATTR.NGUID`; nvme_command.csv, column 325, after `NSATTR.NGUID`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4882 of its text. Its words:

> IEEE Extended Unique Identifier (EUI64): This field contains a 64-bit IEEE Extended

- Note: The export lists this column under the Namespace Attributes heading, but in the data structure it is its own field, not a bit of Namespace Attributes. It is bytes 127:120.

### `LBA Formats`

LBA Formats: the list of LBA formats (data size, metadata size, relative performance) that the namespace supports, starting at LBA Format 0 Support in the Identify Namespace data. The columns after it describe the entries of the list.

- In the export: NVME_Transactions.csv, column 344, after `NSATTR.EUI64`; nvme_command.csv, column 326, after `NSATTR.EUI64`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4899 of its text. Its words:

> LBA Formats (refer to section 5.5)

- Note: This is the heading line of the list of LBA Format Support entries (LBAF0 up to LBAF63); the export may show only some entries, which this slice does not tell.

### `LBAF`

LBA Format Support: one entry of the list of LBA formats the drive supports (LBAF0 up to LBAF63, 4 bytes each). Each entry gives a metadata size, an LBA data size and a relative performance value, shown in the columns after it.

- In the export: NVME_Transactions.csv, column 345, after `LBA Formats`; nvme_command.csv, column 327, after `LBA Formats`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4900 of its text. Its words:

> LBA Format 0 Support (LBAF0): This field indicates the LBA format 0 that is supported

- Note: Whether the export repeats this group once per format is not visible from this slice; the entry layout is Figure 116.

### `LBAF.MS`

Metadata Size, bits 15:0 of an LBA Format entry: the number of metadata bytes provided per logical block for that format. 0 if the format has no metadata.

- In the export: NVME_Transactions.csv, column 346, after `LBAF`; nvme_command.csv, column 328, after `LBAF`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 116: LBA Format Data Structure, NVM Command Set Specific, line 4954 of its text. Its words:

> Metadata Size (MS): This field indicates the number of metadata bytes provided per


### `LBAF.LBADS`

LBA Data Size, bits 23:16 of an LBA Format entry: the data size of a logical block as a power of two (value n means 2 to the power n bytes; 9 is 512, 12 is 4096). 0 means the format is not currently available.

- In the export: NVME_Transactions.csv, column 347, after `LBAF.MS`; nvme_command.csv, column 329, after `LBAF.MS`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 116: LBA Format Data Structure, NVM Command Set Specific, line 4951 of its text. Its words:

> LBA Data Size (LBADS): This field indicates the LBA data size supported.


### `LBAF.RP`

Relative Performance, bits 25:24 of an LBA Format entry: how this format performs compared with the drive's other formats, judged on queue depth 32 with 4 KiB reads. 00b best, 01b better, 10b good, 11b degraded.

- In the export: NVME_Transactions.csv, column 348, after `LBAF.LBADS`; nvme_command.csv, column 330, after `LBAF.LBADS`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 116: LBA Format Data Structure, NVM Command Set Specific, line 4940 of its text. Its words:

> Relative Performance (RP): This field indicates the relative performance of the LBA format


### `VS`

Vendor Specific: bytes 384 to 4095 of the Identify Namespace data, left to the drive manufacturer's own use. The NVMe specification does not define their content.

- In the export: NVME_Transactions.csv, column 349, after `LBAF.RP`; nvme_command.csv, column 331, after `LBAF.RP`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 114: Identify – Identify Namespace Data Structure, NVM Command Set, line 4910 of its text. Its words:

> Vendor Specific (VS)

- Note: The content is manufacturer defined, so it cannot be decoded without the vendor's documentation.

### `FID`

Feature Identifier: the number of the feature that a Set Features or Get Features command changes or reads (for example 07h Number of Queues, 08h Interrupt Coalescing). It sits in the low byte of command dword 10.

- In the export: NVME_Transactions.csv, column 350, after `VS`; nvme_command.csv, column 332, after `VS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 192: Get Features – Command Dword 10 (Set Features: Figure 383), line 12448 of its text. Its words:

> Feature Identifier (FID): This field specifies the identifier of the Feature for which to provide data.


### `SV`

Save: bit 31 of command dword 10 of Set Features. 1 asks the drive to save the value so it persists through all power states and resets; if the feature cannot be saved, the command is aborted with status Feature Identifier Not Saveable.

- In the export: NVME_Transactions.csv, column 351, after `FID`; nvme_command.csv, column 333, after `FID`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 383: Set Features – Command Dword 10, line 23146 of its text. Its words:

> Save (SV): This bit specifies that the controller shall save the attribute so that the attribute persists


### `NSQR`

Number of I/O Submission Queues Requested: in the Number of Queues feature, how many I/O submission queues the host asks for, not counting the admin queue. It is a 0's based value, so 0 means one queue.

- In the export: NVME_Transactions.csv, column 352, after `SV`; nvme_command.csv, column 334, after `SV`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 443: Number of Queues – Command Dword 11, line 25198 of its text. Its words:

> Number of I/O Submission Queues Requested (NSQR): Indicates the number of I/O Submission

- Note: The Verification Script Engine manual text (in.NSQR / in.NCQR under Number of Queues) swaps the two descriptions; its own field table and the NVMe specification agree that NSQR (bits 15:0) counts submission queues.

### `NCQR`

Number of I/O Completion Queues Requested: in the Number of Queues feature, how many I/O completion queues the host asks for, not counting the admin queue. It is a 0's based value, so 0 means one queue.

- In the export: NVME_Transactions.csv, column 353, after `NSQR`; nvme_command.csv, column 335, after `NSQR`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 443: Number of Queues – Command Dword 11, line 25180 of its text. Its words:

> Number of I/O Completion Queues Requested (NCQR): Indicates the number of I/O Completion

- Note: The Verification Script Engine manual text (in.NSQR / in.NCQR under Number of Queues) swaps the two descriptions; its own field table and the NVMe specification agree that NCQR (bits 31:16) counts completion queues.

### `PC`

Physically Contiguous: in the Create I/O Submission Queue and Create I/O Completion Queue commands, 1 means the queue lies in one physically contiguous buffer whose address is PRP entry 1; 0 means PRP entry 1 points to a list of pages.

- In the export: NVME_Transactions.csv, column 354, after `NCQR`; nvme_command.csv, column 340, after `QSIZE`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 479: Create I/O Submission Queue – Command Dword 11 (completion queue: Figure 475), line 26141 of its text. Its words:

> Physically Contiguous (PC): If this bit is set to ‘1’, then the Submission Queue is physically


### `CQID`

Completion Queue Identifier: the number of an NVMe completion queue. Next to SQID and CID in the command file it is the completion queue of the command; next to PC and IV in the transaction file it is the Create I/O Queue field that names the completion queue.

- In the export: NVME_Transactions.csv, column 355, after `PC`; nvme_command.csv, column 5, after `SQID`.
- Holds for the NVMe transaction level and the NVMe command level only: the same name is another field at the other levels.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 479: Create I/O Submission Queue - Command Dword 11, line 26121 of its text. Its words:

> Completion Queue Identifier (CQID): This field specifies the identifier of the I/O Completion Queue

- Note: In packets.csv the same name is a Compute Express Link cache field, a different field with its own entry. That the cell next to SQID and CID is the command's own completion queue is read from its place in the row.

### `IV`

Interrupt Vector: the interrupt vector number. In Create I/O Completion Queue it is the vector the new queue uses (transport specific); in the Interrupt Vector Configuration feature it is the vector whose coalescing settings are set.

- In the export: NVME_Transactions.csv, column 356, after `CQID`; nvme_command.csv, column 342, after `NVMSETID`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 475: Create I/O Completion Queue – Command Dword 11 (feature: Figure 446), line 26029 of its text. Its words:

> Interrupt Vector (IV): This field’s value is transport specific and is described in the applicable NVMe

- Note: Next to Create I/O Queue fields (PC, CQID) in NVME_Transactions.csv; the Interrupt Vector Configuration feature (spec line 25285) uses the same name for the vector to configure.

### `NVMSETID`

NVM Set Identifier: which NVM Set the command concerns. In Create I/O Submission Queue it names the set the new queue is tied to (0 means none); in several features, for example Predictable Latency Mode Config, it selects the set to read or change.

- In the export: NVME_Transactions.csv, column 357, after `IV`; nvme_command.csv, column 341, after `PC`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 480: Create I/O Submission Queue – Command Dword 12, line 26156 of its text. Its words:

> NVM Set Identifier (NVMSETID): This field indicates the identifier of the NVM Set to be associated with

- Note: The Verification Script Engine manual also lists NVMSETID in command dword 11 of the Recovery Level Config, Predictable Latency Mode Config and Predictable Latency Mode Window features; one column serves all of them.

### `THR`

Aggregation Threshold: in the Interrupt Coalescing feature, the recommended minimum number of completion queue entries to collect per interrupt vector before the drive signals an interrupt. It is a 0's based value.

- In the export: NVME_Transactions.csv, column 358, after `NVMSETID`; nvme_command.csv, column 346, after `CHANG`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 445: Interrupt Coalescing – Command Dword 11, line 25262 of its text. Its words:

> Aggregation Threshold (THR): Specifies the recommended minimum number of completion queue


### `TIME`

Aggregation Time: in the Interrupt Coalescing feature, the recommended longest time the drive may delay an interrupt, in 100 microsecond steps; 0 means no delay.

- In the export: NVME_Transactions.csv, column 359, after `THR`; nvme_command.csv, column 347, after `THR`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 445: Interrupt Coalescing – Command Dword 11, line 25247 of its text. Its words:

> Aggregation Time (TIME): Specifies the recommended maximum time in 100 microsecond increments


### `AB`

Arbitration Burst: in the Arbitration feature, the most commands the drive may fetch at one time from one submission queue, given as a power of two (000b is one, 011b is eight); 111b means no limit.

- In the export: NVME_Transactions.csv, column 360, after `TIME`; nvme_command.csv, column 348, after `TIME`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 386: Arbitration & Command Processing – Command Dword 11, line 23346 of its text. Its words:

> Arbitration Burst (AB): Indicates the maximum number of commands that the controller may fetch at


### `LPW`

Low Priority Weight: in the Arbitration feature, the number of commands that may be executed from the low priority class in each arbitration round. It is a 0's based value.

- In the export: NVME_Transactions.csv, column 361, after `AB`; nvme_command.csv, column 349, after `AB`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 386: Arbitration & Command Processing – Command Dword 11, line 23342 of its text. Its words:

> Low Priority Weight (LPW): This field defines the number of commands that may be executed from the


### `MPW`

Medium Priority Weight: in the Arbitration feature, the number of commands that may be executed from the medium priority class in each arbitration round. It is a 0's based value.

- In the export: NVME_Transactions.csv, column 362, after `LPW`; nvme_command.csv, column 350, after `LPW`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 386: Arbitration & Command Processing – Command Dword 11, line 23339 of its text. Its words:

> Medium Priority Weight (MPW): This field defines the number of commands that may be executed from


### `HPW`

High Priority Weight: in the Arbitration feature, the number of commands that may be executed from the high priority class in each arbitration round. It is a 0's based value.

- In the export: NVME_Transactions.csv, column 363, after `MPW`; nvme_command.csv, column 351, after `MPW`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 386: Arbitration & Command Processing – Command Dword 11, line 23336 of its text. Its words:

> High Priority Weight (HPW): This field defines the number of commands that may be executed from


### `EHM`

Enable Host Memory: in the Host Memory Buffer feature (bit 0 of command dword 11), 1 enables the host memory buffer so the drive may use that host memory; 0 disables it.

- In the export: NVME_Transactions.csv, column 364, after `HPW`; nvme_command.csv, column 352, after `HPW`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 447: Host Memory Buffer – Command Dword 11, line 25378 of its text. Its words:

> Enable Host Memory (EHM): If this bit is set to ‘1’, then the host memory buffer shall be enabled and


### `MR`

Memory Return: in the Host Memory Buffer feature, 1 means the host hands back memory it earlier gave the drive, with the same size, list address and contents as last seen; 0 means newly allocated memory with undefined content.

- In the export: NVME_Transactions.csv, column 365, after `EHM`; nvme_command.csv, column 353, after `EHM`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 447: Host Memory Buffer – Command Dword 11, line 25360 of its text. Its words:

> Memory Return (MR): If this bit is set to ‘1’, then the host is returning memory previously allocated to


### `HSIZE`

Host Memory Buffer Size: in the Host Memory Buffer feature, the size of the host memory buffer given to the drive, counted in units of the memory page size.

- In the export: NVME_Transactions.csv, column 366, after `MR`; nvme_command.csv, column 354, after `MR`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 448: Host Memory Buffer – Command Dword 12, line 25387 of its text. Its words:

> Host Memory Buffer Size (HSIZE): This field specifies the size of the host memory buffer allocated in


### `HMDLLA`

Host Memory Descriptor List Lower Address: the least significant 32 bits of the physical address of the list that describes the host memory buffer (Host Memory Buffer feature). The address must be 16-byte aligned.

- In the export: NVME_Transactions.csv, column 367, after `HSIZE`; nvme_command.csv, column 356, after `HMDLAU`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 449: Host Memory Buffer– Command Dword 13, line 25394 of its text. Its words:

> Host Memory Descriptor List Lower Address (HMDLLA): This field specifies the least significant


### `HMDLUA`

Host Memory Descriptor List Upper Address: the most significant 32 bits of the physical address of the list that describes the host memory buffer (Host Memory Buffer feature).

- In the export: NVME_Transactions.csv, column 368, after `HMDLLA`; nvme_command.csv, column 357, after `HMDLLA`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 450: Host Memory Buffer – Command Dword 14, line 25403 of its text. Its words:

> Host Memory Descriptor List Upper Address (HMDLUA): This field specifies the most significant 32


### `HMDLEC`

Host Memory Descriptor List Entry Count: the number of entries in the list that describes the host memory buffer (Host Memory Buffer feature). Zero is invalid.

- In the export: NVME_Transactions.csv, column 369, after `HMDLUA`; nvme_command.csv, column 358, after `HMDLUA`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 451: Host Memory Buffer – Command Dword 15, line 25414 of its text. Its words:

> Host Memory Descriptor List Entry Count (HMDLEC): This field specifies the number of entries


### `LID`

Log Page Identifier: which log page a Get Log Page command asks for (for example 01h error information, 02h SMART and health, 05h commands supported and effects). It is the low byte of command dword 10.

- In the export: NVME_Transactions.csv, column 370, after `HMDLEC`; nvme_command.csv, column 359, after `HMDLEC`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 197: Get Log Page – Command Dword 10, line 12637 of its text. Its words:

> Log Page Identifier (LID): This field specifies the identifier of the log page to retrieve (refer to Figure


### `LSP`

Log Specific Parameter: an option field of Get Log Page (bits 14:8 of command dword 10) whose meaning depends on the log page; it is reserved when the log page defines none.

- In the export: NVME_Transactions.csv, column 371, after `LID`; nvme_command.csv, column 360, after `LID`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 197: Get Log Page – Command Dword 10, line 12634 of its text. Its words:

> Log Specific Parameter (LSP): If not defined for the log specified by the Log Page Identifier field, this


### `RAE`

Retain Asynchronous Event: bit 15 of command dword 10 of Get Log Page. 0 means the drive clears the matching asynchronous event once the command completes; 1 means the event is kept.

- In the export: NVME_Transactions.csv, column 372, after `LSP`; nvme_command.csv, column 361, after `LSP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 197: Get Log Page – Command Dword 10, line 12623 of its text. Its words:

> Retain Asynchronous Event (RAE): This bit specifies whether to retain or clear an Asynchronous


### `NUMDL`

Number of Dwords Lower: the least significant 16 bits of how many dwords (4-byte units) Get Log Page should return. Together with the upper part it forms a 0's based count.

- In the export: NVME_Transactions.csv, column 373, after `RAE`; nvme_command.csv, column 362, after `RAE`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 197: Get Log Page – Command Dword 10, line 12618 of its text. Its words:

> Number of Dwords Lower (NUMDL): This field specifies the least significant 16 bits of the number of


### `NUMDU`

Number of Dwords Upper: the most significant 16 bits of how many dwords (4-byte units) Get Log Page should return; combined with the lower part it forms a 0's based count.

- In the export: NVME_Transactions.csv, column 374, after `NUMDL`; nvme_command.csv, column 363, after `NUMDL`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 198: Get Log Page – Command Dword 11, line 12647 of its text. Its words:

> Number of Dwords (NUMDU): This field specifies the most significant 16 bits of the number of dwords


### `LSI`

Log Specific Identifier: an identifier that some log pages require (bits 31:16 of command dword 11 of Get Log Page); reserved when the requested log page does not define it.

- In the export: NVME_Transactions.csv, column 375, after `NUMDU`; nvme_command.csv, column 364, after `NUMDU`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 198: Get Log Page – Command Dword 11, line 12644 of its text. Its words:

> Log Specific Identifier (LSI): This field specifies an identifier that is required for a particular log page.


### `LPOL`

Log Page Offset Lower: the least significant 32 bits of where in the log page the returned data starts: a dword-aligned byte offset, or an index into the list of data structures when the offset type bit is 1.

- In the export: NVME_Transactions.csv, column 376, after `LSI`; nvme_command.csv, column 365, after `LSI`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 199: Get Log Page – Command Dword 12, line 12661 of its text. Its words:

> Log Page Offset Lower (LPOL): The log page offset specifies the location within a log page to start


### `LPOU`

Log Page Offset Upper: the most significant 32 bits of the log page byte offset, or of the index into the list of data structures, where the data returned by Get Log Page starts.

- In the export: NVME_Transactions.csv, column 377, after `LPOL`; nvme_command.csv, column 366, after `LPOL`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 200: Get Log Page – Command Dword 13, line 12690 of its text. Its words:

> Log Page Offset Upper (LPOU): This field specifies the most significant 32 bits of either the log page


### `Timestamp`

Timestamp feature (feature identifier 0Eh): the controller's clock value that Set Features sets and Get Features reads, in milliseconds since 1 January 1970 UTC. It stands right before TIMESTAMP, so it may be only the group heading of that value.

- In the export: NVME_Transactions.csv, column 378, after `LPOU`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 395: Timestamp – Data Structure for Set Features, line 23747 of its text. Its words:

> Timestamp (TSTMP): Number of milliseconds that have elapsed since midnight, 01-Jan-1970, UTC. Refer

- Note: Seen only in NVME_Transactions.csv, directly before TIMESTAMP; what the cell itself holds (heading or value) is not stated in the sources. Not the capture-time column 'Time Stamp'.

### `TIMESTAMP`

Timestamp: the 48-bit value of the Timestamp feature (0Eh) in the data buffer of Set Features and Get Features. Set Features gives milliseconds since 1 January 1970 UTC; Get Features returns the controller's clock.

- In the export: NVME_Transactions.csv, column 379, after `Timestamp`; nvme_command.csv, column 976, after `THSEL`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 395: Timestamp – Data Structure for Set Features, line 23747 of its text. Its words:

> Timestamp (TSTMP): Number of milliseconds that have elapsed since midnight, 01-Jan-1970, UTC. Refer

- Note: The Verification Script Engine manual lists this field as TIMESTAMP (bits 47:0) of the Set Features / Get Features Timestamp data. Not the capture-time column 'Time Stamp'.

### `SMART`

SMART / Health Critical Warnings: the low eight bits (7 to 0) of the Asynchronous Event Configuration feature value. A bit set to 1 makes the drive notify the host when the matching Critical Warning bit of the SMART / Health Information log becomes 1.

- In the export: NVME_Transactions.csv, column 380, after `TIMESTAMP`; nvme_command.csv, column 977, after `TIMESTAMP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 391: Asynchronous Event Configuration - Command Dword 11, bits 07:00, line 23630 of its text. Its words:

> SMART / Health Critical Warnings (SHCW): This field determines whether an asynchronous event

- Note: The specification abbreviates this field SHCW; the Teledyne LeCroy Verification Script Engine manual lists it as SMART, dword 11, bits 7:0.

### `NAN`

Attached Namespace Attribute Notices: bit 8 of the Asynchronous Event Configuration feature value. 1 makes the drive send an Attached Namespace Attribute Changed event to the host when such a change happens; 0 means it never sends that event.

- In the export: NVME_Transactions.csv, column 381, after `SMART`; nvme_command.csv, column 978, after `SMART`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 391: Asynchronous Event Configuration - Command Dword 11, bit 08, line 23625 of its text. Its words:

> Attached Namespace Attribute Notices (NAN): This bit determines whether an asynchronous event


### `FAN`

Firmware Activation Notices: bit 9 of the Asynchronous Event Configuration feature value. 1 makes the drive send a Firmware Activation Starting event to the host when a firmware activation is about to start; 0 means it does not.

- In the export: NVME_Transactions.csv, column 382, after `NAN`; nvme_command.csv, column 979, after `NAN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 391: Asynchronous Event Configuration - Command Dword 11, bit 09, line 23620 of its text. Its words:

> Firmware Activation Notices (FAN): This bit determines whether an asynchronous event notification


### `TLN`

Telemetry Log Notices: bit 10 of the Asynchronous Event Configuration feature value. 1 makes the drive send a Telemetry Log Changed event when the Telemetry Controller-Initiated Data Available field goes from 0 to 1; 0 means it does not.

- In the export: NVME_Transactions.csv, column 383, after `FAN`; nvme_command.csv, column 980, after `FAN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 391: Asynchronous Event Configuration - Command Dword 11, bit 10, line 23615 of its text. Its words:

> Telemetry Log Notices (TLN): This bit determines whether an asynchronous event notification is sent


### `ANACN`

Asymmetric Namespace Access Change Notices: bit 11 of the Asynchronous Event Configuration feature value. 1 makes the drive notify the host when the contents of the Asymmetric Namespace Access log page change; 0 means it does not.

- In the export: NVME_Transactions.csv, column 384, after `TLN`; nvme_command.csv, column 981, after `TLN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 391: Asynchronous Event Configuration - Command Dword 11, bit 11, line 23608 of its text. Its words:

> Asymmetric Namespace Access Change Notices (ANACN): This bit determines whether an


### `PLEALCN`

Predictable Latency Event Aggregate Log Change Notices: bit 12 of the Asynchronous Event Configuration feature value. 1 makes the drive notify the host when an entry for an NVM Set is added to the Predictable Latency Event Aggregate log; 0 means it does not.

- In the export: NVME_Transactions.csv, column 385, after `ANACN`; nvme_command.csv, column 982, after `ANACN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 391: Asynchronous Event Configuration - Command Dword 11, bit 12, line 23601 of its text. Its words:

> Predictable Latency Event Aggregate Log Change Notices (PLEALCN): This bit determines


### `LBASIN`

LBA Status Information Notices: bit 13 of the Asynchronous Event Configuration feature value. 1 makes the drive send an LBA Status Information Alert event to the host when that condition occurs; 0 means it does not.

- In the export: NVME_Transactions.csv, column 386, after `PLEALCN`; nvme_command.csv, column 983, after `PLEALCN`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), 4.1.3.4 Asynchronous Event Configuration (Feature Identifier 0Bh), Figure 98, line 3692 of its text. Its words:

> LBA Status Information Notices (LBASIN): This bit determines whether an asynchronous event

- Note: The base specification calls this bit LSIAN (LBA Status Information Alert Notices) and leaves its definition to the NVM Command Set specification; the Teledyne LeCroy manual lists LBASIN at bit 13.

### `EGEALCN`

Endurance Group Event Aggregate Log Change Notices: bit 14 of the Asynchronous Event Configuration feature value. 1 makes the drive notify the host when an Endurance Group event entry is added to the Endurance Group Event Aggregate log; 0 means it does not.

- In the export: NVME_Transactions.csv, column 387, after `LBASIN`; nvme_command.csv, column 984, after `LBASIN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 391: Asynchronous Event Configuration - Command Dword 11, bit 14, line 23591 of its text. Its words:

> Endurance Group Event Aggregate Log Change Notices (EGEALCN): This bit determines whether


### `NNSS`

Normal NVM Subsystem Shutdown notices: bit 15 of the Asynchronous Event Configuration feature value. 1 makes the drive notify the host when the NVM subsystem starts a normal shutdown; 0 means it does not.

- In the export: NVME_Transactions.csv, column 388, after `EGEALCN`; nvme_command.csv, column 985, after `EGEALCN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 391: Asynchronous Event Configuration - Command Dword 11, bit 15, line 23584 of its text. Its words:

> Normal NVM Subsystem Shutdown (NNSSHDN): This bit determines whether an asynchronous

- Note: The specification abbreviates this configuration bit NNSSHDN; NNSS is the abbreviation used for the matching support bit in the Identify Controller data. Bit 15 is inferred from the column sitting between EGEALCN (bit 14) and ZDCHN (bit 27).

### `ZDCHN`

Zone Descriptor Changed Notices: bit 27 of the Asynchronous Event Configuration feature value. It controls whether the drive notifies the host when a zone descriptor changes on a zoned namespace; the base specification leaves the exact definition to the Zoned Namespace specification.

- In the export: NVME_Transactions.csv, column 389, after `NNSS`; nvme_command.csv, column 986, after `NNSS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 391: Asynchronous Event Configuration - Command Dword 11, bit 27, line 23547 of its text. Its words:

> Zone Descriptor Changed Notices (ZDCN): I/O Command Set specific definition.

- Note: The Teledyne LeCroy Verification Script Engine manual lists ZDCHN at dword 11 bit 27 (line 2661). The Zoned Namespace specification is not among the sources, so what 1 means is by analogy with the other notice bits.

### `NSID List`

Namespace identifier list: the list of namespace identification descriptors that the drive returns as the data of an Identify command for one namespace. Its entries are decoded in the NSID Entries columns after it: identifier type, length and value.

- In the export: NVME_Transactions.csv, column 390, after `ZDCHN`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Verification Script Engine field table, Identify NSID List (NIDT, NIDL, NID), line 3812 of its text. Its words:

> Identify NSID Identify_ <index> NIDT 0 7:0 Namespace Identifier Type

- Note: The manual's table named Identify NSID List holds the NIDT, NIDL and NID fields (the title is split over two lines). The NVMe name for that data is the Namespace Identification Descriptor list (Identify, selector 03h). Not the active namespace list, which the Namespace List Entries columns show.

### `NSID Entries`

Namespace identification descriptor entries: the entries of the list that an Identify command returns for one namespace. Each entry has a type, a length and an identifier value, shown in the sub-columns NIDT, NIDL and NID.

- In the export: NVME_Transactions.csv, column 391, after `NSID List`; nvme_command.csv, column 1029, after `Namespace List Entries.NSID`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), 5.1.13.2.3 Namespace Identification Descriptor list (CNS 03h), line 20754 of its text. Its words:

> A list of Namespace Identification Descriptor structures (refer to Figure 315) is returned to the host for the


### `NSID Entries.NIDT`

Namespace Identifier Type: in a namespace identification descriptor, says what kind of identifier the value holds: 1h IEEE extended unique identifier (8 bytes), 2h namespace globally unique identifier (16), 3h namespace UUID (16), 4h command set identifier (1).

- In the export: NVME_Transactions.csv, column 392, after `NSID Entries`; nvme_command.csv, column 1030, after `NSID Entries`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 315: Identify - Namespace Identification Descriptor, bytes 00, line 20786 of its text. Its words:

> Namespace Identifier Type (NIDT): This field indicates the data type contained in the Namespace


### `NSID Entries.NIDL`

Namespace Identifier Length: in a namespace identification descriptor, the length in bytes of the identifier value that follows. The whole descriptor is this value plus four bytes long; a value of 0 marks the end of the descriptor list.

- In the export: NVME_Transactions.csv, column 393, after `NSID Entries.NIDT`; nvme_command.csv, column 1031, after `NSID Entries.NIDT`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 315: Identify - Namespace Identification Descriptor, byte 01, line 20819 of its text. Its words:

> Namespace Identifier Length (NIDL): This field contains the length in bytes of the Namespace


### `NSID Entries.NID`

Namespace Identifier: the identifier value itself in a namespace identification descriptor. Its kind is given by the type field and its size by the length field; for types 1h to 3h it is globally unique, for type 4h it is the command set identifier.

- In the export: NVME_Transactions.csv, column 394, after `NSID Entries.NIDL`; nvme_command.csv, column 1032, after `NSID Entries.NIDL`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 315: Identify - Namespace Identification Descriptor, bytes (NIDL + 3):04, line 20825 of its text. Its words:

> Namespace Identifier (NID): For an NIDT field value of 1h, 2h, and 3h, this field contains a


### `GDHM`

Generate Default Host Metadata: a bit of the Get Features command for the Host Metadata features. 1 asks the drive to replace the default host metadata with vendor-specific text strings it creates; 0 leaves the default unchanged.

- In the export: NVME_Transactions.csv, column 395, after `NSID Entries.NID`; nvme_command.csv, column 1033, after `NSID Entries.NID`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), 5.1.25.1.26 Host Metadata, Figure 430: Get Features - Command Dword 11, bit 00, line 24621 of its text. Its words:

> Generate Default Host Metadata (GDHM): If this bit is set to

- Note: This is a host metadata bit, not a host memory buffer field as the slice heading suggests.

### `NUM_DESCR`

Number of descriptors: a count of descriptor entries in the data structure decoded here. By its place right after the Generate Default Host Metadata bit it most likely is the count of Metadata Element Descriptors in the Host Metadata data structure.

- In the export: NVME_Transactions.csv, column 396, after `GDHM`; nvme_command.csv, column 1034, after `GDHM`.
- Source: none. No document that was read states this field; the meaning was written from knowledge of the protocol when this document was prepared.
- Note: No source line names NUM_DESCR. The reading rests on its position after GDHM and on the Number of Metadata Element Descriptors field at byte 0 of the Host Metadata data structure (Figure 432, base specification line 24731). Treat as unconfirmed.

### `NR`

Number of Ranges: in the Dataset Management command, how many 16-byte range sets are listed in the command's data. It is a 0's based value, so 0 means one range.

- In the export: NVME_Transactions.csv, column 397, after `NUM_DESCR`; nvme_command.csv, column 1035, after `NUM_DESCR`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 44: Dataset Management - Command Dword 10, bits 07:00, line 2333 of its text. Its words:

> Number of Ranges (NR): Indicates the number of 16 byte range sets that are specified in the command.


### `IDR`

Integral Dataset for Read: attribute bit of the Dataset Management command. 1 tells the drive to optimize the listed ranges for read access as one unit, because the host expects to read all ranges if any part is read.

- In the export: NVME_Transactions.csv, column 398, after `NR`; nvme_command.csv, column 1036, after `NR`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 45: Dataset Management - Command Dword 11, bit 00, line 2351 of its text. Its words:

> Integral Dataset for Read (IDR): If this bit is set to


### `IDW`

Integral Dataset for Write: attribute bit of the Dataset Management command. 1 tells the drive to optimize the listed ranges for write access as one unit, because the host expects to write all ranges if any part is written.

- In the export: NVME_Transactions.csv, column 399, after `IDR`; nvme_command.csv, column 1037, after `IDR`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 45: Dataset Management - Command Dword 11, bit 01, line 2346 of its text. Its words:

> Integral Dataset for Write (IDW): If this bit is set to


### `AD`

Attribute Deallocate: bit of the Dataset Management command. 1 allows the drive to deallocate all the listed ranges. Data and metadata of blocks it does not deallocate are not changed by the command.

- In the export: NVME_Transactions.csv, column 400, after `IDW`; nvme_command.csv, column 1038, after `IDW`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 45: Dataset Management - Command Dword 11, bit 02, line 2341 of its text. Its words:

> Deallocate (AD): If this bit is set to


### `PS`

Power State: in the Power Management feature, the power state the host asks the drive to move to (Set Features), or the current power state or the one being entered (Get Features reply). Must be one the drive supports.

- In the export: NVME_Transactions.csv, column 401, after `AD`; nvme_command.csv, column 1597, after `RNG 61.SLBA`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 387: Power Management - Command Dword 11, bits 04:00 (Figure 388 for the reply), line 23366 of its text. Its words:

> Power State (PS): This field indicates the new power state into which the controller is requested to


### `WH`

Workload Hint: in the Power Management feature, the kind of workload expected (bits 7 to 5), to help the drive optimize performance. 0 means no workload given, 1 means a long idle then a burst of random writes, 2 means heavy sequential writes.

- In the export: NVME_Transactions.csv, column 402, after `PS`; nvme_command.csv, column 1598, after `PS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 387: Power Management - Command Dword 11, bits 07:05; values in Figure 626: Workload Hints, line 23363 of its text. Its words:

> Workload Hint (WH): This field indicates the type of workload expected. This hint may be used to


## Columns first seen at the NVMe command level (nvme_command.csv)

### `NVMe Cmd`

NVMe Command: the number of this row at the NVMe command decoding level. An NVMe command is a submission queue entry with its doorbells, data transfers and completion entry, which are the NVMe transactions that make it up.

- In the export: nvme_command.csv, column 1.
- Source: Automation API for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.42), Decoding Levels (EPETraceDecodeLevels), line 14674 of its text. Its words:

> DECODE_LEVEL_NVMC 9 NVMe Cmd

- Note: Reading the cell as the command number is an inference (numbered commands: Summit Z5 manual line 9950, 'NVMe Command Number 204918'). Parts of a command: Metrics.# NVME Trans.

### `OPC`

Opcode: the code of the NVMe command to execute, for example Read 02h, Write 01h, Identify 06h. Admin commands and I/O commands use separate code lists.

- In the export: nvme_command.csv, column 3, after `Link Dir`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 91: Command Dword 0, line 8533 of its text. Its words:

> Opcode (OPC): This field specifies the opcode of the command to be executed as shown here:

- Note: Code lists as the analyzer knows them: Verification Script Engine manual from line 1929 (in.nvmcCommandOpCode).

### `ELBTL`

Expected Logical Block Tags Lower: command dword 14 of a Read. With bits 47:00 of command dwords 2 and 3 it forms the Expected Logical Block Storage Tag and Expected Initial Logical Block Reference Tag. Ignored without end-to-end protection.

- In the export: nvme_command.csv, column 17, after `LR`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 56: Read - Command Dword 14, line 2707 of its text. Its words:

> Expected Logical Block Tags Lower (ELBTL): This field and bits 47:00 of Command Dword 2 and

- Note: In NVME_Transactions.csv the same command dword (14) is shown under the name EILBRT.

### `ST.SCT`

Status Code Type within the Status: the category of the command's status: 0 generic command status, 1 command specific status, 2 media and data integrity errors, 3 path related status, 7 vendor specific.

- In the export: nvme_command.csv, column 21, after `ST`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 100: Completion Queue Entry: Status Field, line 8888 of its text. Its words:

> Status Code Type (SCT): Indicates the status code type of the completion queue entry. This indicates the


### `ST.SC`

Status Code within the Status: the detailed status of the command, read together with the Status Code Type. 00h with type 0 means success.

- In the export: nvme_command.csv, column 22, after `ST.SCT`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 100: Completion Queue Entry: Status Field, line 8891 of its text. Its words:

> Status Code (SC): Indicates a status code identifying any error or status information for the command


### `NSID`

Namespace Identifier: the namespace (a section of the drive's storage) the command applies to. 0 when the command does not use one; FFFFFFFFh is a broadcast value (all namespaces) for commands that allow it.

- In the export: nvme_command.csv, column 25, after `MN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 92: Common Command Format, line 8562 of its text. Its words:

> Namespace Identifier (NSID): This field specifies the namespace that this command applies to. If the


### `Metrics.# NVME Trans`

Number of NVMe Transactions: the total number of NVMe transactions that make up this NVMe command.

- In the export: nvme_command.csv, column 27, after `Metrics`.
- Source: Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), TABLE 6.1: NVMe Queue Time Metrics (Commands/Transactions), line 13655 of its text. Its words:

> # NVME Trans Number of NVME Transactions - the total number of NVME Transactions that


### `DSM`

Dataset Management: the attribute byte of a Write command that hints how its blocks will be used: access frequency, access latency, sequential request and incompressible. The next columns split it.

- In the export: nvme_command.csv, column 38, after `LBATM`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 71: Write - Command Dword 13 if CETYPE is cleared to 0h, line 2972 of its text. Its words:

> Dataset Management (DSM): This field indicates attributes for the LBA(s) being written.

- Note: Not the Dataset Management command (opcode 09h); this is the DSM field of Read and Write.

### `DSM.ACCF`

Access Frequency: 4-bit hint of how often the blocks will be read and written: 0 no information, 1 typical, 2 to 5 mixes of infrequent and frequent writes and reads, 6 one-time access.

- In the export: nvme_command.csv, column 39, after `DSM`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 71: Write - Command Dword 13 if CETYPE is cleared to 0h, line 2986 of its text. Its words:

> Access Frequency (AF): This field specifies the expected access frequency.

- Note: The analyzer's field name is ACCF (VSE manual: 'ACCF 13 3:0 Access Frequency').

### `DSM.ACCL`

Access Latency: 2-bit hint of the expected access latency: 0 none given, 1 idle (longer latency acceptable), 2 normal, 3 low (smallest possible latency).

- In the export: nvme_command.csv, column 40, after `DSM.ACCF`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 71: Write - Command Dword 13 if CETYPE is cleared to 0h, line 2980 of its text. Its words:

> Access Latency (AL): This field specifies the exected access latency.

- Note: The specification text itself reads 'exected' (typing mistake in the source).

### `DSM.SEQR`

Sequential Request: 1 means this command is part of a sequential write or read made of several commands; 0 means no information on sequential access is given.

- In the export: nvme_command.csv, column 41, after `DSM.ACCL`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 71: Write - Command Dword 13 if CETYPE is cleared to 0h, line 2977 of its text. Its words:

> Sequential Request (SEQREQ): If this bit is set to


### `DSM.INCOM`

Incompressible: 1 means the data of the blocks is not compressible; 0 means no information on compression is given.

- In the export: nvme_command.csv, column 42, after `DSM.SEQR`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 71: Write - Command Dword 13 if CETYPE is cleared to 0h, line 2974 of its text. Its words:

> Incompressible (INCPRS): If this bit is set to


### `DSM.DSPEC`

Directive Specific: the value that goes with the Directive Type of a Write command (bits 31:16 of command dword 13); how it is read depends on the directive chosen.

- In the export: nvme_command.csv, column 43, after `DSM.INCOM`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 71: Write - Command Dword 13 if CETYPE is cleared to 0h, line 2959 of its text. Its words:

> Directive Specific (DSPEC): Specifies the Directive Specific value associated with the Directive Type

- Note: The export lists it under the DSM header although the specification places it outside the DSM byte (bits 31:16 versus 07:00).

### `CSI#2`

Probably a second Command Set Identifier, which selects the I/O command set (for example the NVM command set) the command refers to. It follows UUID_IDX in the Identify fields.

- In the export: nvme_command.csv, column 49, after `UUID_IDX`.
- Source: none. No document that was read states this field; the meaning was written from knowledge of the protocol when this document was prepared.
- Note: Second column of this name in nvme_command.csv; the matching position in NVME_Transactions.csv is named CSID. The sources define CSI (NVMe Base Specification line 18472) but not which command this second column belongs to. Not confirmed.

### `Errors#2`

Errors in the Identify Controller data: the errors the analyzer found in the decoded Identify Controller structure that ends just before it, for example a reserved field that is not zero or a value outside the specified set.

- In the export: nvme_command.csv, column 258, after `Vendor Specific`.
- Source: Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual (PCIe Protocol Analysis version 13.42), Types of NVMe Errors (6.7.2.2 Error Summary for Storage Protocols -- NVMe), line 13482 of its text. Its words:

> 2. Reserved field is not zero: One (or more) of the fields set as reserved in the current spec revision

- Note: Second Errors column of nvme_command.csv, placed between Vendor Specific (last Identify Controller field) and NSZE (first Identify Namespace field). Reading it as the error cell of the Identify Controller block comes from that position, not from a manual line.

### `NSQA`

Number of I/O Submission Queues Allocated: how many I/O submission queues the drive actually allocated, returned in the completion of the Number of Queues feature. It is a 0's based value and may differ from the number requested.

- In the export: nvme_command.csv, column 336, after `NCQR`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 444: Number of Queues – Completion Queue Entry Dword 0, line 25218 of its text. Its words:

> Number of I/O Submission Queues Allocated (NSQA): Indicates the number of I/O Submission


### `NCQA`

Number of I/O Completion Queues Allocated: how many I/O completion queues the drive actually allocated, returned in the completion of the Number of Queues feature. It is a 0's based value and may differ from the number requested.

- In the export: nvme_command.csv, column 337, after `NSQA`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 444: Number of Queues – Completion Queue Entry Dword 0, line 25213 of its text. Its words:

> Number of I/O Completion Queues Allocated (NCQA): Indicates the number of I/O Completion


### `SVBL`

Saveable: bit 0 of the answer to a Get Features command that asks for Supported Capabilities. 1 means the feature's values can be saved so they persist; 0 means they cannot be saved.

- In the export: nvme_command.csv, column 343, after `IV`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 195: Completion Queue Entry Dword 0 when Select is set to 11b, line 12569 of its text. Its words:

> Saveable (SVBL): If this bit is set to ‘1’, then the feature values are saveable. If this bit is cleared to ‘0’, then


### `NSSPEC`

Namespace Specific: bit 1 of the answer to a Get Features command that asks for Supported Capabilities. 1 means the feature has namespace scope; 0 means its scope is the one listed in the Set Features feature table.

- In the export: nvme_command.csv, column 344, after `SVBL`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 195: Completion Queue Entry Dword 0 when Select is set to 11b, line 12566 of its text. Its words:

> NS Specific (NSSPEC): If this bit is set to ‘1’, then the Feature Identifier has a namespace scope. If this bit


### `CHANG`

Changeable: bit 2 of the answer to a Get Features command that asks for Supported Capabilities. 1 means the feature's values can be changed with Set Features; 0 means they cannot.

- In the export: nvme_command.csv, column 345, after `NSSPEC`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 195: Completion Queue Entry Dword 0 when Select is set to 11b, line 12563 of its text. Its words:

> Changeable (CHANG): If this bit is set to ‘1’, then the feature values are changeable. If this bit is cleared to


### `HMDLAU`

Host Memory Descriptor List Address Upper: the most significant 32 bits of the physical address of the list that describes the host memory buffer, as reported in the data returned by Get Features for the Host Memory Buffer.

- In the export: nvme_command.csv, column 355, after `HSIZE`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 455: Host Memory Buffer – Attributes Data Structure, line 25491 of its text. Its words:

> Host Memory Descriptor List Address Upper (HMDLAU): This field indicates the most significant

- Note: The Verification Script Engine manual (in.GetFeatures_HMDLAU) uses the same name; the Set Features command carries the same value as HMDLUA.

### `ACS`

Admin Command Supported: heading of the Commands Supported and Effects log page (log page 05h), which has one entry per Admin command opcode. The columns under it say whether one command is supported and what it may change.

- In the export: nvme_command.csv, column 367, after `LPOU`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 209: Commands Supported and Effects Log Page, line 13368 of its text. Its words:

> Admin Command Supported 0 (ACS0): Contains the Commands Supported and Effects data

- Note: The export shows a single group of these columns; which command opcode it describes is not stated in the sources.

### `ACS.CSUPP`

Command Supported: in the Commands Supported and Effects entry of one command, 1 means the drive supports that command; 0 means it does not and every other field of the entry is zero.

- In the export: nvme_command.csv, column 368, after `ACS`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 210: Commands Supported and Effects Data Structure, line 13521 of its text. Its words:

> Command Supported (CSUPP): If this bit is set to ‘1’, then this command is supported by the


### `ACS.LBCC`

Logical Block Content Change: in the Commands Supported and Effects entry of one command, 1 means the command may modify user data content in one or more namespaces (a write does); 0 means it modifies none.

- In the export: nvme_command.csv, column 369, after `ACS.CSUPP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 210: Commands Supported and Effects Data Structure, line 13515 of its text. Its words:

> Logical Block Content Change (LBCC): If this bit is set to ‘1’, then this command may modify


### `ACS.NCC`

Namespace Capability Change: in the Commands Supported and Effects entry of one command, 1 means the command may change the capabilities of a single namespace (for example a logical format change); 0 means it does not.

- In the export: nvme_command.csv, column 370, after `ACS.LBCC`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 210: Commands Supported and Effects Data Structure, line 13510 of its text. Its words:

> Namespace Capability Change (NCC): If this bit is set to ‘1’, then this command may change


### `ACS.NIC`

Namespace Inventory Change: in the Commands Supported and Effects entry of one command, 1 means the command may change the number of namespaces or the capabilities of several namespaces (adding or removing); 0 means it does not.

- In the export: nvme_command.csv, column 371, after `ACS.NCC`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 210: Commands Supported and Effects Data Structure, line 13505 of its text. Its words:

> Namespace Inventory Change (NIC): If this bit is set to ‘1’, then this command may change the


### `ACS.CCC`

Controller Capability Change: in the Commands Supported and Effects entry of one command, 1 means the command may change controller capabilities (for example a firmware update that changes the capability register); 0 means it does not.

- In the export: nvme_command.csv, column 372, after `ACS.NIC`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 210: Commands Supported and Effects Data Structure, line 13500 of its text. Its words:

> Controller Capability Change (CCC): If this bit is set to ‘1’, then this command may change


### `ACS.CSE`

Command Submission and Execution: in the Commands Supported and Effects entry of one command, the recommended submission rule. 000b none; 001b only with no other outstanding command on the same namespace; 010b only with none on any namespace.

- In the export: nvme_command.csv, column 373, after `ACS.CCC`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 210: Commands Supported and Effects Data Structure, line 13449 of its text. Its words:

> Command Submission and Execution (CSE): This field defines the command submission and


### `ACS.UUID Selection Supported`

UUID Selection Supported: in the Commands Supported and Effects entry of one command, 1 means the drive lets this command select a UUID (through a UUID Index); 0 means it does not.

- In the export: nvme_command.csv, column 374, after `ACS.CSE`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 210: Commands Supported and Effects Data Structure, line 13446 of its text. Its words:

> UUID Selection Supported (USS): If this bit is set to ‘1’, then the controller supports selection


### `ACS.CSP`

Command Scope: in the Commands Supported and Effects entry of one command, which parts of the drive the command may affect. 0 means no scope is reported; the scope bits in the columns after it say which parts.

- In the export: nvme_command.csv, column 375, after `ACS.UUID Selection Supported`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 210: Commands Supported and Effects Data Structure, line 13418 of its text. Its words:

> Command Scope (CSP): This field defines the scope for the associated command. If the value


### `ACS.NSCPE`

Namespace Scope: bit 0 of Command Scope in a Commands Supported and Effects entry. 1 means the command may impact namespaces; 0 means it does not (when some scope is reported).

- In the export: nvme_command.csv, column 376, after `ACS.CSP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 210: Commands Supported and Effects Data Structure, line 13443 of its text. Its words:

> Namespace Scope (NSCPE): If this bit is set to ‘1’, then the command performs


### `ACS.CSCPE`

Controller Scope: bit 1 of Command Scope in a Commands Supported and Effects entry. 1 means the command may impact controllers; 0 means it does not (when some scope is reported).

- In the export: nvme_command.csv, column 377, after `ACS.NSCPE`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 210: Commands Supported and Effects Data Structure, line 13440 of its text. Its words:

> Controller Scope (CSCPE): If this bit is set to ‘1’, then the command performs


### `ACS.NSSCPE`

NVM Set Scope: bit 2 of Command Scope in a Commands Supported and Effects entry. 1 means the command may impact NVM Sets; 0 means it does not (when some scope is reported).

- In the export: nvme_command.csv, column 378, after `ACS.CSCPE`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 210: Commands Supported and Effects Data Structure, line 13437 of its text. Its words:

> NVM Set Scope (NSSCPE): If this bit is set to ‘1’, then the command performs

- Note: The specification gives the abbreviation NSSCPE to both NVM Set Scope (bit 2) and NVM Subsystem Scope (bit 5). The export's columns follow bit order, so the first NSSCPE is read as NVM Set Scope and the one marked #2 as NVM Subsystem Scope.

### `ACS.EGSCPE`

Endurance Group Scope: bit 3 of Command Scope in a Commands Supported and Effects entry. 1 means the command may impact Endurance Groups; 0 means it does not (when some scope is reported).

- In the export: nvme_command.csv, column 379, after `ACS.NSSCPE`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 210: Commands Supported and Effects Data Structure, line 13432 of its text. Its words:

> Endurance Group Scope (EGSCPE): If this bit is set to ‘1’, then the command


### `ACS.DSCPE`

Domain Scope: bit 4 of Command Scope in a Commands Supported and Effects entry. 1 means the command may impact a single Domain; 0 means it does not (when some scope is reported).

- In the export: nvme_command.csv, column 380, after `ACS.EGSCPE`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 210: Commands Supported and Effects Data Structure, line 13429 of its text. Its words:

> Domain Scope (DSCPE): If this bit is set to ‘1’, then the command performs actions


### `ACS.NSSCPE#2`

NVM Subsystem Scope: bit 5 of Command Scope in a Commands Supported and Effects entry. 1 means the command may impact the whole NVM subsystem; 0 means it does not (when some scope is reported).

- In the export: nvme_command.csv, column 381, after `ACS.DSCPE`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 210: Commands Supported and Effects Data Structure, line 13424 of its text. Its words:

> NVM Subsystem Scope (NSSCPE): If this bit is set to ‘1’, then the command

- Note: Second column named NSSCPE in the same group. The specification uses NSSCPE for both NVM Set Scope (bit 2) and NVM Subsystem Scope (bit 5); by bit order this later column is NVM Subsystem Scope.

### `Log Page Identifier Supported`

Log Page Identifier Supported: heading of the Supported Log Pages log page (log page 00h). It lists, for every log page identifier from 00h to FFh in order, whether the drive supports that log page and whether an index offset may be used with it.

- In the export: nvme_command.csv, column 382, after `ACS.NSSCPE#2`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 203: Supported Log Pages Log Page, line 12862 of its text. Its words:

> Log Page Identifier Supported 0 (LIDS0): Contains the LID Supported and Effects data structure

- Note: The heading cell itself may also carry the flag for identifier 00h (see the note of the repeated 'Log Page Identifier Supported.Log Page Identifier Supported' column).

### `Log Page Identifier Supported.IOS`

Index Offset Supported: repeated once per log page identifier, in order from 00h to FFh. 1 means Get Log Page may use an index into the list of data structures (offset type bit set) for that log page; 0 means byte offsets only.

- In the export: nvme_command.csv, column 383, after `Log Page Identifier Supported`.
- Stands for the 256 columns of this name that the export has one after another.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 204: LID Supported and Effects Data Structure, line 12883 of its text. Its words:

> Index Offset Supported (IOS): If this bit is set to ‘1’, then the controller supports an index offset for


### `Log Page Identifier Supported.Log Page Identifier Supported`

LID Supported: tells whether the drive supports a log page identifier in a Get Log Page command (1 yes; 0 no, and the rest of that entry is to be ignored). One per identifier, in order; the export repeats it 255 times.

- In the export: nvme_command.csv, column 384, after `Log Page Identifier Supported.IOS`.
- Stands for the 255 columns of this name that the export has one after another.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 204: LID Supported and Effects Data Structure, line 12890 of its text. Its words:

> LID Supported (LSUPP): If this bit is set to ‘1’, then the controller supports this LID for a Get Log Page

- Note: Read as the LID Supported flag from its name and its place beside IOS in each entry; the sources do not name this column. Its 255 repeats plus the heading cell make 256 entries, so the heading cell may stand for identifier 00h; whether a repeat pairs with the IOS before it or after it is not certain.

### `Log Page Identifier Supported.EC_R512_HS`

Establish Context and Read 512 Bytes of Header Supported: present only in the 14th entry, log page identifier 0Dh (Persistent Event Log). 1 means the drive supports that action, and the Generation Number field of that log page.

- In the export: nvme_command.csv, column 410, after `Log Page Identifier Supported.IOS#14`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 228: Persistent Event LID Specific Parameter Field, line 14808 of its text. Its words:

> Establish Context and Read 512 Bytes of Header Supported (ECRH): If this bit is cleared to ‘0’, then

- Note: Name read as Establish Context, Read 512 bytes, Header Supported; it sits in the entry of the 14th identifier (0Dh), where the specification defines this bit in the LID Specific Parameter field.

### `Log Page Identifier Supported.Vendor Specific`

Vendor Specific: the LID Specific Parameter field of the entries for the vendor-specific log page identifiers C0h to FFh (64 entries, one column each, in order). Its content is defined by the drive maker, not by the NVMe specification.

- In the export: nvme_command.csv, column 769, after `Log Page Identifier Supported.IOS#193`.
- Stands for the 64 columns of this name that the export has one after another.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 204: LID Supported and Effects Data Structure, line 12879 of its text. Its words:

> LID Specific Parameter (LIDSP): This field is specific to the log page identifier and if not defined for

- Note: Reading: the extra column appears exactly in the 64 entries C0h to FFh (Figure 202: C0h to FFh Vendor specific), where the 16-bit LID Specific Parameter is not defined by the specification. The sources do not name this column.

### `Feature Identifier Supported`

Feature Identifier Supported: heading of the Feature Identifiers Supported and Effects log page (log page 12h), which has one entry per feature identifier. The columns under it say whether a feature is supported and what changing it may affect.

- In the export: nvme_command.csv, column 959, after `Log Page Identifier Supported.Vendor Specific#64`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 261: Feature Identifiers Effects Log Page, line 16197 of its text. Its words:

> Feature Identifier Supported 0 (FIS0): Contains the FID Supported and Effects data structure (refer

- Note: The export shows a single group of these columns; which feature identifier it describes is not stated in the sources.

### `Feature Identifier Supported.FSUPP`

FID Supported: in the Feature Identifiers Supported and Effects entry of one feature, 1 means the drive supports that feature identifier; 0 means it does not and every other field of the entry is zero.

- In the export: nvme_command.csv, column 960, after `Feature Identifier Supported`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 262: FID Supported and Effects Data Structure, line 16302 of its text. Its words:

> FID Supported (FSUPP): If this bit is set to ‘1’, then this FID is supported by the controller.


### `Feature Identifier Supported.UDCC`

User Data Content Change: in the entry of one feature, 1 means changing the feature may modify user data content in one or more namespaces; 0 means it does not.

- In the export: nvme_command.csv, column 961, after `Feature Identifier Supported.FSUPP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 262: FID Supported and Effects Data Structure, line 16297 of its text. Its words:

> User Data Content Change (UDCC): If this bit is set to ‘1’, then changing the attributes of the feature


### `Feature Identifier Supported.NCC`

Namespace Capability Change: in the entry of one feature, 1 means changing the feature may change the capabilities of a single namespace (for example a logical format change); 0 means it does not.

- In the export: nvme_command.csv, column 962, after `Feature Identifier Supported.UDCC`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 262: FID Supported and Effects Data Structure, line 16292 of its text. Its words:

> Namespace Capability Change (NCC): If this bit is set to ‘1’, then changing the attributes of the


### `Feature Identifier Supported.NIC`

Namespace Inventory Change: in the entry of one feature, 1 means changing the feature may change the number of namespaces or the capabilities of several namespaces; 0 means it does not.

- In the export: nvme_command.csv, column 963, after `Feature Identifier Supported.NCC`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 262: FID Supported and Effects Data Structure, line 16287 of its text. Its words:

> Namespace Inventory Change (NIC): If this bit is set to ‘1’, then changing the attributes of the feature


### `Feature Identifier Supported.CCC`

Controller Capability Change: in the entry of one feature, 1 means changing the feature may change controller capabilities (for example through a firmware update); 0 means it does not.

- In the export: nvme_command.csv, column 964, after `Feature Identifier Supported.NIC`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 262: FID Supported and Effects Data Structure, line 16282 of its text. Its words:

> Controller Capability Change (CCC): If this bit is set to ‘1’, then changing the attributes of the feature


### `Feature Identifier Supported.UUID Selection Supported`

UUID Selection Supported: in the entry of one feature, 1 means the drive lets Get Features or Set Features select a UUID for that feature identifier (through a UUID Index); 0 means it does not.

- In the export: nvme_command.csv, column 965, after `Feature Identifier Supported.CCC`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 262: FID Supported and Effects Data Structure, line 16265 of its text. Its words:

> UUID Selection Supported (USS): If this bit is this bit is set to ‘1’, then the controller supports the


### `Feature Identifier Supported.FSP`

FID Scope: in the entry of one feature, the scope of the feature identifier. 0 means no scope is reported; otherwise exactly one of the scope bits, shown in the columns after it, is set.

- In the export: nvme_command.csv, column 966, after `Feature Identifier Supported.UUID Selection Supported`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 262: FID Supported and Effects Data Structure, line 16226 of its text. Its words:

> FID Scope (FSP): This field defines the scope for the associated feature identifier. If the value of this


### `Feature Identifier Supported.NSCPE`

Namespace Scope: bit 0 of FID Scope. 1 means changing the feature may impact namespaces; 0 means it does not (when some scope is reported).

- In the export: nvme_command.csv, column 967, after `Feature Identifier Supported.FSP`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 262: FID Supported and Effects Data Structure, line 16260 of its text. Its words:

> Namespace Scope (NSCPE): If this bit is set to ‘1’, then modifying the attributes of the


### `Feature Identifier Supported.CSCPE`

Controller Scope: bit 1 of FID Scope. 1 means changing the feature may impact the controller; 0 means the feature does not have controller scope (when some scope is reported).

- In the export: nvme_command.csv, column 968, after `Feature Identifier Supported.NSCPE`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 262: FID Supported and Effects Data Structure, line 16255 of its text. Its words:

> Controller Scope (CSCPE): If this bit is set to ‘1’, then modifying the attributes of the


### `Feature Identifier Supported.NSSCPE`

NVM Set Scope: bit 2 of FID Scope. 1 means changing the feature may impact NVM Sets; 0 means it does not (when some scope is reported).

- In the export: nvme_command.csv, column 969, after `Feature Identifier Supported.CSCPE`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 262: FID Supported and Effects Data Structure, line 16250 of its text. Its words:

> NVM Set Scope (NSSCPE): If this bit is set to ‘1’, then modifying the attributes of the

- Note: The specification gives the abbreviation NSSCPE to both NVM Set Scope (bit 2) and NVM Subsystem Scope (bit 5). The export's columns follow bit order, so the first NSSCPE is read as NVM Set Scope and the one marked #2 as NVM Subsystem Scope.

### `Feature Identifier Supported.EGSCPE`

Endurance Group Scope: bit 3 of FID Scope. 1 means changing the feature may impact Endurance Groups; 0 means it does not (when some scope is reported).

- In the export: nvme_command.csv, column 970, after `Feature Identifier Supported.NSSCPE`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 262: FID Supported and Effects Data Structure, line 16245 of its text. Its words:

> Endurance Group Scope (EGSCPE): If this bit is set to ‘1’, then modifying the attributes


### `Feature Identifier Supported.DSCPE`

Domain Scope: bit 4 of FID Scope. 1 means changing the feature may impact a single Domain; 0 means it does not (when some scope is reported).

- In the export: nvme_command.csv, column 971, after `Feature Identifier Supported.EGSCPE`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 262: FID Supported and Effects Data Structure, line 16240 of its text. Its words:

> Domain Scope (DSCPE): If this bit is set to ‘1’, then modifying the attributes of the


### `Feature Identifier Supported.NSSCPE#2`

NVM Subsystem Scope: bit 5 of FID Scope. 1 means changing the feature may impact the whole NVM subsystem; 0 means it does not (when some scope is reported).

- In the export: nvme_command.csv, column 972, after `Feature Identifier Supported.DSCPE`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 262: FID Supported and Effects Data Structure, line 16235 of its text. Its words:

> NVM Subsystem Scope (NSSCPE): If this bit is set to ‘1’, then modifying the attributes

- Note: Second column named NSSCPE in the same group. The specification uses NSSCPE for both NVM Set Scope (bit 2) and NVM Subsystem Scope (bit 5); by bit order this later column is NVM Subsystem Scope.

### `TMPTH`

Temperature Threshold: in the Temperature Threshold feature, the threshold value for the chosen temperature sensor and threshold type, in kelvins.

- In the export: nvme_command.csv, column 973, after `Feature Identifier Supported.NSSCPE#2`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 389: Temperature Threshold – Command Dword 11, line 23484 of its text. Its words:

> Temperature Threshold (TMPTH): Indicates the threshold value for the temperature sensor and


### `TMPSEL`

Threshold Temperature Select: in the Temperature Threshold feature, which temperature the threshold belongs to: 0h composite temperature, 1h to 8h temperature sensor 1 to 8, Fh all implemented sensors (Set Features only).

- In the export: nvme_command.csv, column 974, after `TMPTH`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 389: Temperature Threshold – Command Dword 11, line 23467 of its text. Its words:

> Threshold Temperature Select (TMPSEL): This field selects the temperature whose threshold is


### `THSEL`

Threshold Type Select: in the Temperature Threshold feature, which threshold is set or read: 00b over temperature threshold, 01b under temperature threshold.

- In the export: nvme_command.csv, column 975, after `TMPSEL`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 389: Temperature Threshold – Command Dword 11, line 23460 of its text. Its words:

> Threshold Type Select (THSEL): This field selects the threshold type that is modified by a Set Features


### `Critical Warning`

Critical Warning: the first byte of the SMART / Health Information log page, with one bit per kind of critical warning about the state of the controller; several bits can be 1 together. The sub-columns show each bit, then further log fields.

- In the export: nvme_command.csv, column 987, after `ZDCHN`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, byte 00, line 13037 of its text. Its words:

> Critical Warning (CW): This field indicates critical warnings for the state of the controller. Each bit

- Note: The software shows Bit 0 to 5 under this header and then Temperature, Available Spare, Available Spare Threshold and Percentage Used, which are the next fields of the same log page (bytes 1 to 5).

### `Critical Warning.Bit 0`

Available Spare Capacity Below Threshold: bit 0 of Critical Warning in the SMART / Health Information log. 1 means the available spare capacity has fallen below the threshold.

- In the export: nvme_command.csv, column 988, after `Critical Warning`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, Critical Warning bit 0, line 13063 of its text. Its words:

> Available Spare Capacity Below Threshold (ASCBT): If this bit is set to


### `Critical Warning.Bit 1`

Temperature Threshold Condition: bit 1 of Critical Warning in the SMART / Health Information log. 1 means a temperature is at or above an over-temperature threshold, or at or below an under-temperature threshold.

- In the export: nvme_command.csv, column 989, after `Critical Warning.Bit 0`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, Critical Warning bit 1, line 13058 of its text. Its words:

> Temperature Threshold Condition (TTC): If this bit is set to


### `Critical Warning.Bit 2`

NVM Subsystem Degraded Reliability: bit 2 of Critical Warning in the SMART / Health Information log. 1 means the reliability of the NVM subsystem has been degraded by significant media-related errors or an internal error.

- In the export: nvme_command.csv, column 990, after `Critical Warning.Bit 1`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, Critical Warning bit 2, line 13055 of its text. Its words:

> NVM Subsystem Degraded Reliability (NDR): If this bit is set to


### `Critical Warning.Bit 3`

All Media Read-Only: bit 3 of Critical Warning in the SMART / Health Information log. 1 means all of the media has been placed in read-only mode.

- In the export: nvme_command.csv, column 991, after `Critical Warning.Bit 2`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, Critical Warning bit 3, line 13050 of its text. Its words:

> All Media Read-Only (AMRO): If this bit is set to


### `Critical Warning.Bit 4`

Volatile Memory Backup Failed: bit 4 of Critical Warning in the SMART / Health Information log. 1 means the volatile memory backup device has failed; valid only if the drive has a volatile memory backup solution.

- In the export: nvme_command.csv, column 992, after `Critical Warning.Bit 3`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, Critical Warning bit 4, line 13047 of its text. Its words:

> Volatile Memory Backup Failed (VMBF): If this bit is set to


### `Critical Warning.Bit 5`

Persistent Memory Region Read-Only: bit 5 of Critical Warning in the SMART / Health Information log. 1 means the Persistent Memory Region has become read-only or unreliable.

- In the export: nvme_command.csv, column 993, after `Critical Warning.Bit 4`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, Critical Warning bit 5, line 13044 of its text. Its words:

> Persistent Memory Region Read-Only (PMRRO): If this bit is set to


### `Critical Warning.Temperature`

Composite Temperature: current temperature of the controller and its namespaces, in kelvins, from bytes 2 and 1 of the SMART / Health Information log page. The value is implementation specific and need not match one physical point.

- In the export: nvme_command.csv, column 994, after `Critical Warning.Bit 5`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, bytes 02:01, line 13066 of its text. Its words:

> Composite Temperature (CTEMP): Contains a value corresponding to a temperature in Kelvins that

- Note: The software lists this log field under the Critical Warning header; it is its own field, not a bit of Critical Warning. Matched by name and position.

### `Critical Warning.Available Spare`

Available Spare: remaining spare capacity as a normalized percentage (0 to 100) in the SMART / Health Information log page.

- In the export: nvme_command.csv, column 995, after `Critical Warning.Temperature`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, byte 03, line 13073 of its text. Its words:

> Available Spare (AVSP): Contains a normalized percentage (0% to 100%) of the remaining spare

- Note: Listed by the software under the Critical Warning header; it is its own log field.

### `Critical Warning.Available Spare Threshold`

Available Spare Threshold: the normalized percentage (0 to 100) below which a falling Available Spare may cause an asynchronous event completion. Values 101 to 255 are reserved. Field of the SMART / Health Information log page.

- In the export: nvme_command.csv, column 996, after `Critical Warning.Available Spare`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, byte 04, line 13076 of its text. Its words:

> Available Spare Threshold (AVSPT): When the Available Spare falls below the threshold indicated in

- Note: Listed by the software under the Critical Warning header; it is its own log field.

### `Critical Warning.Percentage Used`

Percentage Used: a vendor-specific estimate of the percentage of drive life used. 100 means the estimated endurance is consumed, though not necessarily a failure; it may exceed 100 and is shown as 255 above 254. Field of the SMART / Health Information log page.

- In the export: nvme_command.csv, column 997, after `Critical Warning.Available Spare Threshold`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, byte 05, line 13079 of its text. Its words:

> Percentage Used (PUSED): Contains a vendor specific estimate of the percentage of NVM subsystem

- Note: Listed by the software under the Critical Warning header; it is its own log field.

### `Endurance Group Critical Warning Summary`

Endurance Group Critical Warning Summary: byte 6 of the SMART / Health Information log page, one bit per critical warning type for Endurance Groups; a bit is 1 if it is 1 in any group. Many later log values are listed under this header.

- In the export: nvme_command.csv, column 998, after `Critical Warning.Percentage Used`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, byte 06, line 13098 of its text. Its words:

> Endurance Group Critical Warning Summary (EGCWS): This field indicates critical warnings for the

- Note: Sub-columns from Data Units Read onward are the following fields of the same log page, matched by name; they are not part of this byte.

### `Endurance Group Critical Warning Summary.Bit 0`

Endurance Group Available Spare Capacity Below Threshold: bit 0 of the Endurance Group Critical Warning Summary. 1 means the available spare capacity of one or more Endurance Groups has fallen below the threshold.

- In the export: nvme_command.csv, column 999, after `Endurance Group Critical Warning Summary`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, Endurance Group Critical Warning Summary bit 0, line 13115 of its text. Its words:

> Endurance Group Available Spare Capacity Below Threshold (EGASCBT): If this bit


### `Endurance Group Critical Warning Summary.Bit 2`

Endurance Group Degraded Reliability: bit 2 of the Endurance Group Critical Warning Summary. 1 means the reliability of one or more Endurance Groups has been degraded by significant media-related errors or an internal error.

- In the export: nvme_command.csv, column 1000, after `Endurance Group Critical Warning Summary.Bit 0`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, Endurance Group Critical Warning Summary bit 2, line 13111 of its text. Its words:

> Endurance Group Degraded Reliability (EGDR): If this bit is set to


### `Endurance Group Critical Warning Summary.Bit 3`

Endurance Group Read-Only: bit 3 of the Endurance Group Critical Warning Summary. 1 means the namespaces in one or more Endurance Groups have been placed in read-only mode, not because of a namespace write-protection change.

- In the export: nvme_command.csv, column 1001, after `Endurance Group Critical Warning Summary.Bit 2`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, Endurance Group Critical Warning Summary bit 3, line 13108 of its text. Its words:

> Endurance Group Read-Only (EGRO): If this bit is set to


### `Endurance Group Critical Warning Summary.Data Units Read`

Data Units Read: number of 512-byte data units the host has read from the drive, without metadata, in thousands rounded up (1 means 1 to 1,000 units). 0 means not reported. Field of the SMART / Health Information log page.

- In the export: nvme_command.csv, column 1002, after `Endurance Group Critical Warning Summary.Bit 3`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, bytes 47:32, line 13119 of its text. Its words:

> Data Units Read (DUR): Contains the number of 512 byte data units the host has read from the

- Note: Listed by the software under the Endurance Group Critical Warning Summary header; matched to the log field of the same name.

### `Endurance Group Critical Warning Summary.Data Units Written`

Data Units Written: number of 512-byte data units the host has written to the drive, without metadata, in thousands rounded up (1 means 1 to 1,000 units). 0 means not reported. Field of the SMART / Health Information log page.

- In the export: nvme_command.csv, column 1003, after `Endurance Group Critical Warning Summary.Data Units Read`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, bytes 63:48, line 13127 of its text. Its words:

> Data Units Written (DUW): Contains the number of 512 byte data units the host has written to the

- Note: Listed by the software under the Endurance Group Critical Warning Summary header; matched to the log field of the same name.

### `Endurance Group Critical Warning Summary.Host Read Commands`

Host Read Commands: number of host read commands the controller has completed over its life. Field of the SMART / Health Information log page.

- In the export: nvme_command.csv, column 1004, after `Endurance Group Critical Warning Summary.Data Units Written`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, bytes 79:64, line 13135 of its text. Its words:

> Host Read Commands (HRC): Contains the number of SMART Host Read Commands completed by

- Note: Listed by the software under the Endurance Group Critical Warning Summary header; matched to the log field of the same name.

### `Endurance Group Critical Warning Summary.Host Write Commands`

Host Write Commands: number of write commands (User Data Out commands) the controller has completed. Field of the SMART / Health Information log page.

- In the export: nvme_command.csv, column 1005, after `Endurance Group Critical Warning Summary.Host Read Commands`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, bytes 95:80, line 13140 of its text. Its words:

> Host Write Commands (HWC): Contains the number of User Data Out Commands completed by the

- Note: Listed by the software under the Endurance Group Critical Warning Summary header; matched to the log field of the same name.

### `Endurance Group Critical Warning Summary.Controller Busy Time`

Controller Busy Time: the time the controller has been busy with I/O commands, in minutes. It is busy while a command is outstanding on an I/O queue. Field of the SMART / Health Information log page.

- In the export: nvme_command.csv, column 1006, after `Endurance Group Critical Warning Summary.Host Write Commands`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, bytes 111:96, line 13145 of its text. Its words:

> Controller Busy Time (CBT): Contains the amount of time the controller is busy with I/O commands.

- Note: Listed by the software under the Endurance Group Critical Warning Summary header; matched to the log field of the same name.

### `Endurance Group Critical Warning Summary.Power Cycles`

Power Cycles: number of power cycles of the drive. Field of the SMART / Health Information log page.

- In the export: nvme_command.csv, column 1007, after `Endurance Group Critical Warning Summary.Controller Busy Time`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, bytes 127:112, line 13150 of its text. Its words:

> Power Cycles (PWRC): Contains the number of power cycles.

- Note: Listed by the software under the Endurance Group Critical Warning Summary header; matched to the log field of the same name.

### `Endurance Group Critical Warning Summary.Power On Hours`

Power On Hours: number of hours the drive has been powered on. It may not include time powered in a non-operational power state. Field of the SMART / Health Information log page.

- In the export: nvme_command.csv, column 1008, after `Endurance Group Critical Warning Summary.Power Cycles`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, bytes 143:128, line 13151 of its text. Its words:

> Power On Hours (POH): Contains the number of power-on hours. This may not include time that the

- Note: Listed by the software under the Endurance Group Critical Warning Summary header; matched to the log field of the same name.

### `Endurance Group Critical Warning Summary.Unsafe Shutdowns`

Unsafe Shutdowns: count of unexpected power losses, counted when main power is lost without the controller having reported it was ready to be powered off. The log field is now called Unexpected Power Losses. Field of the SMART / Health Information log page.

- In the export: nvme_command.csv, column 1009, after `Endurance Group Critical Warning Summary.Power On Hours`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, bytes 159:144 (Unexpected Power Losses), line 13174 of its text. Its words:

> Note that this field was previously named Unsafe Shutdowns.

- Note: Listed by the software under the Endurance Group Critical Warning Summary header; matched to the log field by its old name.

### `Endurance Group Critical Warning Summary.Media Errors`

Media Errors: number of occurrences where the controller detected an unrecovered data integrity error, such as an uncorrectable error, a checksum failure or an LBA tag mismatch. The specification names the field Media and Data Integrity Errors.

- In the export: nvme_command.csv, column 1010, after `Endurance Group Critical Warning Summary.Unsafe Shutdowns`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, bytes 175:160 (Media and Data Integrity Errors), line 13188 of its text. Its words:

> Media and Data Integrity Errors (MDIE): Contains the number of occurrences where the controller

- Note: Matched by position (between Unsafe Shutdowns and Number of Error Info Log Entries) and meaning, not by exact name; no source line shows the shorter name Media Errors.

### `Endurance Group Critical Warning Summary.Number of Error Info Log Entries`

Number of Error Information Log Entries: how many Error Information log entries have been recorded over the life of the controller. Field of the SMART / Health Information log page.

- In the export: nvme_command.csv, column 1011, after `Endurance Group Critical Warning Summary.Media Errors`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, bytes 191:176, line 13193 of its text. Its words:

> Number of Error Information Log Entries (NEILE): Contains the number of Error Information Log

- Note: Listed by the software under the Endurance Group Critical Warning Summary header; matched to the log field of the same name.

### `Endurance Group Critical Warning Summary.Warning Composite Temperature Time`

Warning Composite Temperature Time: minutes the controller has been operational with the Composite Temperature at or above the warning threshold and below the critical threshold. Always 0 if either threshold is 0. Field of the SMART / Health Information log page.

- In the export: nvme_command.csv, column 1012, after `Endurance Group Critical Warning Summary.Number of Error Info Log Entries`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, bytes 195:192, line 13196 of its text. Its words:

> Warning Composite Temperature Time (WCTT): If the Temperature Threshold Hysteresis Attributes

- Note: Listed by the software under the Endurance Group Critical Warning Summary header; matched to the log field of the same name. With hysteresis settings non-zero, hysteresis time is included.

### `Endurance Group Critical Warning Summary.Critical Composite Temperature Time`

Critical Composite Temperature Time: minutes the controller has been operational with the Composite Temperature at or above the critical threshold. Always 0 if that threshold is 0. Field of the SMART / Health Information log page.

- In the export: nvme_command.csv, column 1013, after `Endurance Group Critical Warning Summary.Warning Composite Temperature Time`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, bytes 199:196, line 13207 of its text. Its words:

> Critical Composite Temperature Time (CCTT): Contains the amount of time in minutes that the

- Note: Listed by the software under the Endurance Group Critical Warning Summary header; matched to the log field of the same name.

### `Endurance Group Critical Warning Summary.Temperature Sensor #`

Temperature Sensor number #: current temperature, in kelvins, reported by temperature sensor # (1 to 8). A sensor the drive does not implement reports 0, and where each sensor sits is implementation specific. Field of the SMART / Health Information log page.

- In the export: nvme_command.csv, column 1014, after `Endurance Group Critical Warning Summary.Critical Composite Temperature Time`.
- Stands for 8 numbered columns (# is the number), for example `Endurance Group Critical Warning Summary.Temperature Sensor 1`, `Endurance Group Critical Warning Summary.Temperature Sensor 2`, `Endurance Group Critical Warning Summary.Temperature Sensor 3`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, bytes 201:200 to 215:214; Figure 207: Temperature Sensor Data Structure, line 13213 of its text. Its words:

> Temperature Sensor 1 (TSEN1): Contains the current temperature reported by temperature sensor 1.

- Note: # stands for 1 to 8; the quote is the entry for sensor 1. Listed by the software under the Endurance Group Critical Warning Summary header.

### `Endurance Group Critical Warning Summary.Thermal Management Temperature 1 Transition Count`

Thermal Management Temperature 1 Transition Count: times the controller moved to lower-power active states or took thermal action with minimal performance impact after the Composite Temperature rose above Thermal Management Temperature 1. 0 means never or not implemented.

- In the export: nvme_command.csv, column 1022, after `Endurance Group Critical Warning Summary.Temperature Sensor 8`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, bytes 219:216, line 13248 of its text. Its words:

> Thermal Management Temperature 1 Transition Count (TMT1TC): Contains the number of times the

- Note: Listed by the software under the Endurance Group Critical Warning Summary header; the counter does not wrap.

### `Endurance Group Critical Warning Summary.Thermal Management Temperature 2 Transition Count`

Thermal Management Temperature 2 Transition Count: times the controller moved to lower-power active states or took thermal action regardless of performance impact (heavy throttling) after the Composite Temperature rose above Thermal Management Temperature 2. 0 means never or not implemented.

- In the export: nvme_command.csv, column 1023, after `Endurance Group Critical Warning Summary.Thermal Management Temperature 1 Transition Count`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, bytes 223:220, line 13255 of its text. Its words:

> Thermal Management Temperature 2 Transition Count (TMT2TC): Contains the number of times the

- Note: Listed by the software under the Endurance Group Critical Warning Summary header; the counter does not wrap.

### `Endurance Group Critical Warning Summary.Total Time For Thermal Management Temperature 1`

Total Time For Thermal Management Temperature 1: seconds the controller spent in lower-power active states or other thermal action with minimal performance impact, because of host-controlled thermal management. 0 means never or not implemented.

- In the export: nvme_command.csv, column 1024, after `Endurance Group Critical Warning Summary.Thermal Management Temperature 2 Transition Count`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, bytes 227:224, line 13262 of its text. Its words:

> Total Time For Thermal Management Temperature 1 (TTTMT1): Contains the number of seconds

- Note: Listed by the software under the Endurance Group Critical Warning Summary header; the counter does not wrap.

### `Endurance Group Critical Warning Summary.Total Time For Thermal Management Temperature 2`

Total Time For Thermal Management Temperature 2: seconds the controller spent in lower-power active states or other thermal action regardless of performance impact (heavy throttling), because of host-controlled thermal management. 0 means never or not implemented.

- In the export: nvme_command.csv, column 1025, after `Endurance Group Critical Warning Summary.Total Time For Thermal Management Temperature 1`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 206: SMART / Health Information Log Page, bytes 231:228, line 13269 of its text. Its words:

> Total Time For Thermal Management Temperature 2 (TTTMT2): Contains the number of seconds

- Note: Listed by the software under the Endurance Group Critical Warning Summary header; the counter does not wrap.

### `WCE`

Volatile Write Cache Enable: in the Volatile Write Cache feature, 1 means the drive's volatile write cache is enabled; 0 means it is disabled, and user data written is then persistent.

- In the export: nvme_command.csv, column 1026, after `Endurance Group Critical Warning Summary.Total Time For Thermal Management Temperature 2`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), Figure 390: Volatile Write Cache – Command Dword 11, line 23516 of its text. Its words:

> Volatile Write Cache Enable (WCE): If this bit is set to ‘1’, then the volatile write cache is enabled. If


### `Namespace List Entries`

Namespace list: an ordered list of namespace IDs that the drive returns to an Identify command, for example the active namespaces; unused entries are zero. The NSID sub-column shows the IDs.

- In the export: nvme_command.csv, column 1027, after `WCE`.
- Source: NVM Express Base Specification (Revision 2.1, August 5th, 2024), 4.6.2 Namespace List, Figure 138: Namespace List Format, line 10418 of its text. Its words:

> A Namespace List, defined in Figure 138, is an ordered list of namespace IDs. Unused entries are zero

- Note: Which list kind (active, allocated or command-set specific) depends on the Identify selector of the command; the active namespace list is described at base specification line 20747.

### `Namespace List Entries.NSID`

Namespace ID: one namespace identifier in the namespace list the drive returns to an Identify command. IDs come in increasing order, and unused entries are zero.

- In the export: nvme_command.csv, column 1028, after `Namespace List Entries`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Verification Script Engine field table, Identify: List of Namespaces, NSID (dword 0, bits 31:0), line 4438 of its text. Its words:

> NSID 0 31:0 Namespace ID

- Note: Order and zero fill come from Figure 138 of the base specification (line 10424).

### `RNG #`

Range number #: one range of the list a Dataset Management command carries (numbered from 0). A range holds context attributes, a length in logical blocks and a starting logical block address, shown in the sub-columns.

- In the export: nvme_command.csv, column 1039, after `AD`.
- Stands for 62 numbered columns (# is the number), for example `RNG 0`, `RNG 1`, `RNG 2`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), 3.3.3 Dataset Management command, Figure 46: Dataset Management - Range Definition, line 2359 of its text. Its words:

> The data that the Dataset Management command provides is a list of ranges with context attributes. Each

- Note: # runs from 0 to 61 in the export; the command allows up to 256 ranges.

### `RNG #.AF`

Access Frequency: context attribute of range # in a Dataset Management command, the expected access frequency. 0 no information, 1 typical, 2 infrequent writes and reads, 3 infrequent writes but frequent reads, 4 frequent writes but infrequent reads, 5 both frequent.

- In the export: nvme_command.csv, column 1040, after `RNG 0`.
- Stands for 62 numbered columns (# is the number), for example `RNG 0.AF`, `RNG 1.AF`, `RNG 2.AF`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 47: Dataset Management - Context Attributes, bits 03:00, line 2510 of its text. Its words:

> Access Frequency (AF): This field specifies the expected access frequency.


### `RNG #.AL`

Access Latency: context attribute of range # in a Dataset Management command, the expected access latency. 0 none given, 1 idle (longer latency acceptable), 2 normal (typical latency), 3 low (smallest possible latency).

- In the export: nvme_command.csv, column 1041, after `RNG 0.AF`.
- Stands for 62 numbered columns (# is the number), for example `RNG 0.AL`, `RNG 1.AL`, `RNG 2.AL`.
- Source: NVM Express NVM Command Set Specification (Revision 1.1, August 5th, 2024), Figure 47: Dataset Management - Context Attributes, bits 05:04, line 2504 of its text. Its words:

> Access Latency (AL): This field specifies the expected access latency.


### `RNG #.SR`

Sequential Read Range: context attribute of range # in a Dataset Management command. 1 means the range should be optimized for sequential read access; the host expects to read it as a single object.

- In the export: nvme_command.csv, column 1042, after `RNG 0.AL`.
- Stands for 62 numbered columns (# is the number), for example `RNG 0.SR`, `RNG 1.SR`, `RNG 2.SR`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Verification Script Engine field table, Dataset Management: Range Definition (bit 8); Figure 47 in the NVM Command Set specification, line 4600 of its text. Its words:

> SR 0 8 Sequential Read Range

- Note: The NVM Command Set specification calls this bit SRR (line 2500).

### `RNG #.SW`

Sequential Write Range: context attribute of range # in a Dataset Management command. 1 means the range should be optimized for sequential write access; the host expects to write it as a single object.

- In the export: nvme_command.csv, column 1043, after `RNG 0.SR`.
- Stands for 62 numbered columns (# is the number), for example `RNG 0.SW`, `RNG 1.SW`, `RNG 2.SW`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Verification Script Engine field table, Dataset Management: Range Definition (bit 9); Figure 47 in the NVM Command Set specification, line 4601 of its text. Its words:

> SW 0 9 Sequential Write Range

- Note: The NVM Command Set specification calls this bit SWR (line 2497).

### `RNG #.WP`

Write Prepare: context attribute of range # in a Dataset Management command. 1 means the range is expected to be written in the near future.

- In the export: nvme_command.csv, column 1044, after `RNG 0.SW`.
- Stands for 62 numbered columns (# is the number), for example `RNG 0.WP`, `RNG 1.WP`, `RNG 2.WP`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Verification Script Engine field table, Dataset Management: Range Definition (bit 10); Figure 47 in the NVM Command Set specification, line 4602 of its text. Its words:

> WP 0 10 Write Prepare

- Note: The NVM Command Set specification calls this bit WPREP (line 2494). Not the Write Pointer of a zone descriptor, which the same manual also abbreviates WP.

### `RNG #.CAS`

Command Access Size: context attribute of range # in a Dataset Management command, the number of logical blocks expected to be transferred by a single Read or Write command on this dataset. 0 means no size is given.

- In the export: nvme_command.csv, column 1045, after `RNG 0.WP`.
- Stands for 62 numbered columns (# is the number), for example `RNG 0.CAS`, `RNG 1.CAS`, `RNG 2.CAS`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Verification Script Engine field table, Dataset Management: Range Definition (bits 31:24); Figure 47 in the NVM Command Set specification, line 4604 of its text. Its words:

> CAS 0 31:24 Command Access Size

- Note: The NVM Command Set specification calls this field CASZE (line 2490).

### `RNG #.Length LB`

Length in logical blocks: the size of range # in a Dataset Management command, counted in logical blocks. It is a 1-based value, so 1 means one block.

- In the export: nvme_command.csv, column 1046, after `RNG 0.CAS`.
- Stands for 62 numbered columns (# is the number), for example `RNG 0.Length LB`, `RNG 1.Length LB`, `RNG 2.Length LB`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Verification Script Engine field table, Dataset Management: Range Definition (LEN_LB), line 4605 of its text. Its words:

> LEN_LB 1 31:0 Length in logical blocks

- Note: The NVM Command Set specification says the field is 1-based (line 2361) and calls it LLB.

### `RNG #.SLBA`

Starting logical block address: the first logical block of range # in a Dataset Management command.

- In the export: nvme_command.csv, column 1047, after `RNG 0.Length LB`.
- Stands for 62 numbered columns (# is the number), for example `RNG 0.SLBA`, `RNG 1.SLBA`, `RNG 2.SLBA`.
- Source: Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual (PCIe Protocol Analysis version 13.20), Verification Script Engine field table, Dataset Management: Range Definition (64-bit field), line 4606 of its text. Its words:

> SLBA 2 63:0 Starting LBA


