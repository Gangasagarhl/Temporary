# Reference library

What the application already knows about the columns of the CSV files that measuring tools export, written down once with
the public document that states each meaning. Prepared on 2026-11-12.

## Why this folder exists

The Data Grounder (the agent that runs on each uploaded file after the Data Explorer) has to say what every column of
the file means. Before this folder existed it asked the model, with web searches, for every column of every file. For an
export with about 2,000 column names that was too slow, and the same column was looked up again in every run.

The owner's request was three things:

1. Read the exporting tool's own documentation first and ground the column names from it.
2. Search the web only for what that documentation does not cover.
3. Once a column is understood, it is done: never look the same column up twice.

This folder is the answer to the first two. The third is the store that the application keeps while it runs
(`knowledge/column_meanings/`, written by `agentic/column_knowledge.py`); it is not in this folder because it grows on
each machine.

## How the Data Grounder uses it

1. **Which tool exported the file.** The names in the file's header are compared with each tool's column list. The file
   is taken as a tool's export when at least 5 of its names, and at least 30 % of them, are in that list (the two limits
   are `RECOGNISE_LEAST` and `RECOGNISE_SHARE` in `agentic/column_knowledge.py`). Cells without a label do not count.
2. **For each column that holds values**, the first of these that applies gives the meaning:
   - a meaning that an admin approved earlier. Only another approved meaning can replace it.
   - the entry of the tool's reference document. It is used only when its quote is found, at run time, on the stated
     line of `document/CSV_EXPORT_REFERENCE.md`: the same check as for any other document quote.
   - what an earlier run understood for the same column (same name, same kind of values, at least one keyword in
     common), from `knowledge/column_meanings/`.
   - an entry of the list that no document states (kind `model`, see below). It carries no quote, so its source is
     given as "model knowledge" and there is nothing to check it against.
   - the model. It gets the column's name, its contents, lines of the reference documents and, when the web is allowed,
     web search.
3. **A file that matches no tool** is handled as a CSV file of an unknown tool: the web is searched first, then the name
   and the contents are read.

No meaning in this folder was written by code. The meanings were written, each with its quote, when the reference
document was prepared; code only finds the right entry for a name.

## What is in the folder

| file | what it is |
|---|---|
| `index.json` | The tools this application knows: key, name, what the tool exports, the domain, a hint for web searches, and either a column list (`columns` + `document`, status `ready`) or notes only (`notes`). |
| `<tool>/columns.json` | Master file 1. One entry per column name: where the name sits in a real export (`seen`), the meaning, the kind of source, and for kind `document` the source, the section (`where`), the quote and the line of the original text (`source_line`). Its `sources` block names every document with version, publisher and public address. |
| `<tool>/export_notes.json` | Master file 2. What the export is and how it is made, as headed sections of text with quotes. For Teledyne LeCroy: 10 sections, 28 quotes, all from the Summit Z5 user manual. |
| `<tool>/document/CSV_EXPORT_REFERENCE.md` | The reference document. It is **made** from the two master files; do not edit it. This is the file the Data Grounder searches and cites, so every quote stands on one line of it, and `columns.json` remembers that line (`doc_line`). |
| `<tool>/NOTES.md` | For a tool without a column list: how it exports, what a header looks like, what is not known, and what is needed to build the list. The program does not read these files; they are for the person who builds the list. |
| `build_reference.py` | Makes the document from the master files and checks it. |

`build_reference.py` has three uses (shown here as run from the application folder; it finds its own folder, so it can be
run from anywhere). Each run prints one line of counts per ready tool, and a line that starts with `PROBLEM:` for each
thing that is wrong; it ends with exit code 1 when there is any problem.

    python3 reference_library/build_reference.py                              write the document of every ready tool, and doc_line
    python3 reference_library/build_reference.py --check                      write nothing; fail when a document is not what the master files give
    python3 reference_library/build_reference.py --check --sources FOLDER     also look every quote up on its stated line of the original texts

`FOLDER` holds the original documents as text, made with `pdftotext -layout` and named as the `text_file` of each
source in `columns.json` says. Those texts are not shipped (see the last section); download the PDFs from the public
addresses in `columns.json` to make them. Without `--check`, `--sources` also writes the document.

## The tools today

Counted from `index.json` and `teledyne_lecroy_pcie/columns.json` on 2026-11-12.

| tool | state |
|---|---|
| Teledyne LeCroy PCIe Protocol Analysis (`teledyne_lecroy_pcie`) | ready: column list and reference document |
| Windows Performance Analyzer (`windows_wpa`) | notes only: `windows_wpa/NOTES.md` |
| PCMark 10 (`pcmark10`) | notes only: `pcmark10/NOTES.md` |

The Teledyne LeCroy list has **637 entries**:

| kind | entries | what it means |
|---|---|---|
| `document` | 615 | The meaning is stated by a public document; the entry carries the quote and where it stands. |
| `model` | 18 | No document that was read states the field. The meaning was written from knowledge of PCI Express and NVMe when the list was prepared, and it has no quote. |
| `unknown` | 4 | Not found anywhere: `PMUX Metadata`, `Jammer Phase`, `CXL Pkt Type`, `CXL Pkt Subtype`. The Data Grounder asks the model and the web for these. |

The 615 quotes come from six documents:

| document | version | quotes |
|---|---|---|
| NVM Express Base Specification | Revision 2.1, August 5th, 2024 | 374 |
| Verification Script Engine for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual | PCIe Protocol Analysis version 13.20 | 103 |
| NVM Express NVM Command Set Specification | Revision 1.1, August 5th, 2024 | 97 |
| Summit Exerciser Scripting Language Reference Manual | PCIe Protocol Analysis version 13.20 | 21 |
| Summit Z5 PCI Express 5.0 Protocol Exerciser/Analyzer User Manual | PCIe Protocol Analysis version 13.42 | 16 |
| Automation API for Teledyne LeCroy PCIe Protocol Analysis, Reference Manual | PCIe Protocol Analysis version 13.42 | 4 |

The exact titles, publishers and public addresses are in the `sources` block of `columns.json`. That block names two
more documents (the Summit M64 Analyzer User Manual and the NVM Command Set Specification Revision 1.3); no entry and no
export note quotes them.

An entry can stand for many columns of the file:

- 10 entries are numbered families, written with `#` for the number (for example `RNG #.SLBA`); together they stand for
  566 columns.
- 3 entries stand for a name that the export repeats one after another (256, 255 and 64 times).
- 3 names (`Address`, `Device ID`, `CQID`) are a different field at different levels of the export, so each has two
  entries, marked with the levels it holds for.

The list was prepared from the header rows of one real five-level export (the header index of 2026-11-03, kept in
`data/lecroy_real_headers.json`). The reference document states the size of that export in its section "What the header
row of a real export looks like": 113, 39, 22, 402 and 1,598 columns at the five levels, 1,762 different names together.

The 18 `model` entries are: `Address` (NVMe transaction level), `PMUX Channel ID`, `Snoop`, `Requirement (Snoop)`,
`Scale (Snoop)`, `Value (Snoop)`, `No-Snoop`, `Requirement (No-Snoop)`, `Scale (No-Snoop)`, `Value (No-Snoop)`,
`Link Tra Error`, `No-Snoop Requirement`, `No-Snoop Scale`, `No-Snoop Value`, `Address List`, `CSID`, `NUM_DESCR`, `CSI#2`.

## How to add a tool

1. **Get real exported files.** At least the header row and enough rows to see the values, made the way the engineer
   really exports them. The entry names must be the names this application's reader gives the columns (a part of a group
   is `Group.Part`; the second column of one name is `Name#2`), so read the file with the application once and take the
   names from there.
2. **Collect the public documents** that describe the export: the vendor's manuals first, a public specification of the
   protocol second. Turn each PDF into text with `pdftotext -layout`. Keep these texts outside the application folder.
3. **Write `<tool>/columns.json`.** Copy the shape of `teledyne_lecroy_pcie/columns.json`: `tool`, `prepared`,
   `how_to_read`, `levels` (level name to file name), `sources` (per document: `title`, `version`, `publisher`,
   `address`, `text_file`) and `entries`. Per entry: `name`, `seen` (level, file, position, the named column before and
   after), `kind`, `meaning`, and for kind `document` also `source`, `where`, `quote` and `source_line`. The quote is the
   words of one line of the text, copied exactly. Where no document states a field, use kind `model` and say so, or
   kind `unknown` and leave it to the Data Grounder. Do not fill a meaning in from the name alone and call it `document`.
4. **Write `<tool>/export_notes.json`:** `title`, `prepared` and `sections`, each with a `heading`, `text` paragraphs,
   optional `quotes` (`source`, `where`, `source_line`, `quote`) and, for numbers that were counted from a file and not
   stated by a document, `measured_from`.
5. **Add the tool to `index.json`** with `key`, `name`, `exports`, `domain`, `web_hint`, `columns`, `document` and status
   `ready`. A tool listed without `columns` is not used for recognition.
6. **Build and check.** Run `build_reference.py`, then `--check`, then `--check --sources FOLDER`. All three must end
   without a line that starts with `PROBLEM:`.
7. **Run the application's tests** (`bash run_tests.sh`) and upload one real file, to see that the file is recognised as
   the new tool and that the meanings come with their quotes.

Two things in `build_reference.py` are still written for the first tool and must be changed when a second tool gets a
document: the sentence under the source table that names the Teledyne LeCroy and NVM Express download pages, and the
level words (`LEVEL_WORDS`) used in the section headings.

## What may be put in this folder

- **Short quotes only.** Each quote is one line of the original (the longest in the list is 117 characters) and stands
  with the document's name, its version, the section and the public address it can be downloaded from.
- **No full manuals and no full specifications**, neither as PDF nor as text. They belong to their publishers. The
  original texts that `--sources` reads stay outside the application and outside the zip.
- **Public documents only.** Every source in `columns.json` is given with the publisher's own download address
  (Teledyne LeCroy's manuals page and the NVM Express specifications page). The PCI Express Base Specification is not
  among the sources and no text of it is quoted: the PCI Express fields are explained from Teledyne LeCroy's own manuals.
- **No keys, no customer data.** The only thing taken from a customer's file is the header row: column names and their
  order.

## Known limits

- Only the Teledyne LeCroy five-level export goes through the whole application today. The folder check of stage 1 still
  expects those five files, so a file of another tool is handled only as far as the Data Grounder's reading of an
  unknown tool.
- The list holds the names of one real export. A recording made with other columns switched on in the software will have
  names that are not in the list; those go to the model, and what it finds is kept in `knowledge/column_meanings/`.
- The meanings of the keywords inside a column (for example the values of a type field) are not in this folder. The
  Data Grounder asks the model for them once and keeps the answers in `knowledge/column_meanings/`.
