"""Make each tool's reference document from its two master files, and check it.

    python3 reference_library/build_reference.py                    write document/CSV_EXPORT_REFERENCE.md for every ready tool
    python3 reference_library/build_reference.py --check            write nothing: fail when a document is not what the masters give
    python3 reference_library/build_reference.py --sources FOLDER   also check every quote against the original texts in FOLDER

The masters of a tool are <tool>/columns.json (one entry per column name: meaning, source, quote) and <tool>/export_notes.json
(what the export is and how it is made). The document is what the Data Grounder searches and cites, so every quote is on one
line of it, and columns.json remembers that line ('doc_line'). The original manuals are not shipped; with --sources (a folder of
their texts, made with `pdftotext -layout`, named as columns.json 'sources' says) each quote is looked up on its stated line.
"""
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DOCUMENT = "CSV_EXPORT_REFERENCE.md"
LEVEL_WORDS = {"packets": "packet level", "link": "link transaction level", "split": "split transaction level",
               "nvme_transaction": "NVMe transaction level", "nvme_command": "NVMe command level"}


def norm(t):
    return re.sub(r"\s+", " ", str(t or "")).strip().lower()


def load(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def tools():
    """The tools of index.json that have a column list."""
    return [t for t in load(os.path.join(HERE, "index.json"))["tools"] if t.get("columns")]


def one_line(t):
    return re.sub(r"\s+", " ", str(t or "")).strip()


def source_words(sources, key, where, line):
    s = sources[key]
    return "%s (%s)%s, line %s of its text" % (s["title"], s["version"], ", " + where if where else "", line)


def render(columns, notes):
    """(lines of the document, {index of entry: line of its quote}). Lines are numbered from 1 in the file."""
    sources, out, quote_line = columns["sources"], [], {}

    def add(t=""):
        out.append(t)

    add("# " + notes["title"])
    add()
    add("Prepared on %s for the Data Grounder of the Field-to-Test Loop application. This file is made by "
        "reference_library/build_reference.py from columns.json and export_notes.json: change those two files, not this one."
        % notes["prepared"])
    add()
    add("## The documents this was prepared from")
    add()
    add("| document | version | publisher | public address |")
    add("|---|---|---|---|")
    for s in sources.values():
        add("| %s | %s | %s | %s |" % (s["title"], s["version"], s["publisher"], s["address"]))
    add()
    add("All of them are public. Teledyne LeCroy lists its manuals at "
        "https://www.teledynelecroy.com/protocolanalyzer/pci-express/resources/product-manuals and NVM Express its specifications "
        "at https://nvmexpress.org/specifications/ .")
    add()
    for sec in notes["sections"]:
        add("## " + sec["heading"])
        add()
        if sec.get("measured_from"):
            add("Measured from %s." % sec["measured_from"])
            add()
        for p in sec.get("text") or []:
            add(one_line(p))
            add()
        for q in sec.get("quotes") or []:
            add("From %s:" % source_words(sources, q["source"], q.get("where"), q["source_line"]))
            add()
            add("> " + one_line(q["quote"]))
            add()
    levels = list(columns["levels"])
    first = {}
    for i, e in enumerate(columns["entries"]):
        s = min(e["seen"], key=lambda s: (levels.index(s["level"]), s["position"]))
        first.setdefault(s["level"], []).append((s["position"], i))
    for lv in levels:
        rows = sorted(first.get(lv) or [])
        if not rows:
            continue
        add("## Columns first seen at the %s (%s)" % (LEVEL_WORDS.get(lv, lv), columns["levels"][lv]))
        add()
        for _, i in rows:
            e = columns["entries"][i]
            add("### `%s`" % e["name"])
            add()
            add(one_line(e["meaning"]) if e["kind"] != "unknown" else
                "Not found in the documents that were read. The Data Grounder asks the model and the web for this column.")
            add()
            where = "; ".join("%s, column %s%s" % (s["file"], s["position"], ", after `%s`" % s["before"] if s["before"] else "")
                              for s in e["seen"])
            add("- In the export: %s." % where)
            if e.get("only_for"):
                add("- Holds for the %s only: the same name is another field at the other levels."
                    % " and the ".join(LEVEL_WORDS.get(v, v) for v in e["only_for"]))
            if e.get("pattern"):
                add("- Stands for %s numbered columns (# is the number), for example %s."
                    % (e.get("members_count"), ", ".join("`%s`" % m for m in e.get("members_example") or [])))
            if e.get("repeated_columns"):
                add("- Stands for the %s columns of this name that the export has one after another." % e["repeated_columns"])
            if e["kind"] == "document":
                add("- Source: %s. Its words:" % source_words(sources, e["source"], e.get("where"), e["source_line"]))
                add()
                add("> " + one_line(e["quote"]))
                quote_line[i] = len(out)
                add()
            elif e["kind"] == "model":
                add("- Source: none. No document that was read states this field; the meaning was written from knowledge of "
                    "the protocol when this document was prepared.")
            else:
                add("- Source: none.")
            if e.get("note"):
                add("- Note: " + one_line(e["note"]))
            add()
    return out, quote_line


def check_document(lines, columns, notes):
    """Every quote is on its line of the document (as the Data Grounder's check reads it)."""
    bad = []
    for i, e in enumerate(columns["entries"]):
        if e["kind"] != "document":
            continue
        n = e.get("doc_line")
        if not n or n > len(lines) or norm(e["quote"])[:160] not in norm(lines[n - 1]):
            bad.append("%s: the quote is not on line %s of the document" % (e["name"], n))
    text = norm(" ".join(lines))
    for sec in notes["sections"]:
        for q in sec.get("quotes") or []:
            if norm(q["quote"])[:160] not in text:
                bad.append("export notes: quote not in the document: %s" % q["quote"][:60])
    return bad


def check_sources(columns, notes, folder):
    """Every quote is on the stated line of the original text (the texts are not shipped: see the module text)."""
    bad, cache = [], {}

    def line_of(key, n):
        f = columns["sources"][key]["text_file"]
        if f not in cache:
            p = os.path.join(folder, f)
            if not os.path.exists(p):
                cache[f] = None
            else:
                with open(p, encoding="utf-8", errors="replace") as fh:
                    cache[f] = fh.read().split("\n")
        t = cache[f]
        if t is None:
            return None
        return norm(t[n - 1]) if 0 < n <= len(t) else ""

    items = [(e["name"], e["source"], e["source_line"], e["quote"]) for e in columns["entries"] if e["kind"] == "document"]
    items += [("export notes", q["source"], q["source_line"], q["quote"]) for s in notes["sections"] for q in s.get("quotes") or []]
    missing = set()
    for name, key, n, quote in items:
        got = line_of(key, n)
        if got is None:
            missing.add(columns["sources"][key]["text_file"])
        elif norm(quote) not in got:
            bad.append("%s: not on line %s of %s: %s" % (name, n, columns["sources"][key]["text_file"], quote[:70]))
    for f in sorted(missing):
        bad.append("original text not in the folder: " + f)
    return bad, len(items)


def build(tool, write=True, sources_folder=None):
    """Render one tool. Returns (problems, facts)."""
    base = os.path.join(HERE, os.path.dirname(tool["columns"]))
    columns, notes = load(os.path.join(HERE, tool["columns"])), load(os.path.join(base, "export_notes.json"))
    lines, quote_line = render(columns, notes)
    doc_path = os.path.join(HERE, tool["document"], DOCUMENT)
    problems = []
    if write:
        changed = False
        for i, e in enumerate(columns["entries"]):
            want = quote_line.get(i)
            if e.get("doc_line") != want:
                changed = True
                if want is None:
                    e.pop("doc_line", None)
                else:
                    e["doc_line"] = want
        os.makedirs(os.path.dirname(doc_path), exist_ok=True)
        with open(doc_path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write("\n".join(lines) + "\n")
        if changed:
            with open(os.path.join(HERE, tool["columns"]), "w", encoding="utf-8", newline="\n") as fh:
                json.dump(columns, fh, indent=1, ensure_ascii=False)
                fh.write("\n")
    else:
        on_disk = open(doc_path, encoding="utf-8").read().split("\n") if os.path.exists(doc_path) else None
        if on_disk is None:
            problems.append("the document is missing: run build_reference.py")
        elif on_disk[:-1] != lines and on_disk != lines:
            problems.append("the document is not what columns.json and export_notes.json give: run build_reference.py")
        for i, e in enumerate(columns["entries"]):
            if e.get("doc_line") != quote_line.get(i):
                problems.append("%s: doc_line is %s, the document has the quote on line %s" % (e["name"], e.get("doc_line"), quote_line.get(i)))
                break
    problems += check_document(lines, columns, notes)
    facts = {"tool": tool["key"], "entries": len(columns["entries"]), "lines": len(lines)}
    for e in columns["entries"]:
        facts[e["kind"]] = facts.get(e["kind"], 0) + 1
    if sources_folder:
        bad, n = check_sources(columns, notes, sources_folder)
        problems += bad
        facts["quotes_checked_against_the_originals"] = n
    return problems, facts


def main(argv):
    write = "--check" not in argv
    folder = argv[argv.index("--sources") + 1] if "--sources" in argv else None
    failed = False
    for tool in tools():
        problems, facts = build(tool, write=write, sources_folder=folder)
        print(json.dumps(facts))
        for p in problems[:40]:
            print("  PROBLEM:", p)
        failed = failed or bool(problems)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
