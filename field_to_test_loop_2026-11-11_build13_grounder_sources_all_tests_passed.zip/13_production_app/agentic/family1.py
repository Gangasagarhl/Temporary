"""Family 1 — Data Experts: one sub-family per CSV of the input folder -> one approved data dictionary per CSV.

The sub-family has three agents, each with its OWN context (owner, 2026-11-08: "I don't want to mess the whole context"):

  Data Explorer   THE DATA, and only the data. Code reads EVERY row of the file (no sample) and records every column:
                  how many rows hold a value, its type, how many different values it has, and every special keyword:
                  the WORDS a column holds ("ACK", "UpdateFC-P", "CplD", "Link Up"; never a number, hex value, address,
                  id, time or the column's own name; see is_keyword), with how many rows hold it and the first rows where
                  it appears (kept in its memory for questions; the keywords themselves are shown by name). The model then only writes a summary
                  of that profile (what one row is, what the file records). The data is the truth: nothing about it is
                  "verified", it is counted. No notes, no meanings: those are the Grounder's.
  Data Grounder   THE MEANINGS, and only the meanings. It gets the column names and the keywords (never the data rows)
                  and finds what each one means: in the reference documents first, then on the web (when allowed), then
                  from the model's own knowledge. Every meaning says where it comes from; a document line and a web page
                  are checked by code (the quote must be there), model knowledge is labelled as such.
  Manager         TALKS TO THE ADMIN. It puts both together into the data dictionary and asks for review: a plain
                  summary of what the file is, then every column and keyword with what the data holds, what it means,
                  where the meaning comes from, and where to see it (file and line). When the admin asks a question, the
                  Manager asks the right helper (the Explorer for the data, with rows; the Grounder for a meaning) and
                  answers with the rows and the path.

Steps of a run (kind "family1"; the same steps inside the flow):
  director              lists the CSVs of the folder and what each one is (its level, its size, its header)
  explore:<csv>         the Data Explorer (code over every row, then the summary) -> runs/<run>/explorer_<csv>/memory.json
  ground:<csv>          the Data Grounder (meanings with sources) -> runs/<run>/grounder_<csv>/memory.json
  manager:<csv>         the Manager's dictionary -> REVIEW "Admin <name>, need review" (approve / change / reject)
"""
import csv
import functools
import hashlib
import json
import os
import re
import sys
import threading
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor

from . import core

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
from nvme_hier import columns as C, loader as L   # noqa: E402

BATCH = 120                    # columns per model call (the Explorer: one short sentence per column, no web)
GROUND_BATCH = 20              # columns per Grounder call (owner, 2026-11-11: with 120 columns, their keywords and web search in one call,
                               # a real export of 361 columns stood at 'columns 1 to 120 of 361 ... 0%' for many minutes)
GROUND_KEYWORDS = 15           # keywords per column whose meaning the Grounder is asked for
KEYWORD_MAX_DISTINCT = 300     # a text column with at most this many different values holds keywords
DISTINCT_CAP = 2000            # different values counted one by one per column (beyond: "more than 2,000")
ROWS_PER_VALUE = 3             # the first rows where each value appears (where to see it)
TOP_VALUES = 8


def knowledge_dir():
    d = os.path.join(APP, "knowledge")
    os.makedirs(d, exist_ok=True)
    return d


# ---------------------------------------------------------------------------------------------- the inventory
def inventory(folder):
    out = []
    if not folder or not os.path.isdir(folder):
        return out
    for fn in sorted(os.listdir(folder)):
        p = os.path.join(folder, fn)
        if not (os.path.isfile(p) and fn.lower().endswith(".csv")):
            continue
        try:
            header, _rows = L.sniff(p, 0)
        except (OSError, UnicodeDecodeError):
            continue
        level = L.guess_level(header)
        out.append({"name": fn, "path": p, "bytes": os.path.getsize(p), "level": level,
                    "level_label": C.LEVEL_LABEL.get(level) if level else "not one of the five analyzer levels",
                    "columns": len(header), "format_key": format_key(level, header)})
    return out


def folder_problem(files):
    """Why this folder cannot be built into one tree, in words, or None. One folder holds one recording: two files of the same kind are two recordings,
    and quietly using the last one by name would join the packets of one recording to the commands of another (found 2026-11-10)."""
    by = {}
    for f in files:
        if f["level"]:
            by.setdefault(f["level"], []).append(f["name"])
    if not by:
        return "none of the CSV files in this folder is an analyzer export of the five kinds (packets, link, split, NVMe transactions, NVMe commands)"
    two = sorted((k, v) for k, v in by.items() if len(v) > 1)
    if two:
        return "this folder holds more than one file of the same kind: %s. One folder holds one recording: move the other files to a folder of their own, then run again" % (
            "; ".join("%s (%s)" % (C.LEVEL_LABEL.get(k, k), ", ".join(v)) for k, v in two))
    return None


def format_key(level, header):
    """The file format: the level and its header cells. The same key = the same export layout."""
    cells = [re.sub(r"^\d+(\.\d+)?$|^\d+ (warning|error)\(s\)$", "<value>", (h or "").strip()) for h in header]
    return hashlib.sha1(("%s|%s" % (level, "|".join(cells))).encode()).hexdigest()[:12]


# ---------------------------------------------------------------------------------------------- the Explorer's code
_INT = re.compile(r"^-?\d+$")
_HEX = re.compile(r"^(0x)?[0-9A-Fa-f]+$")
_TIME = re.compile(r"^\d+\.\d+\s*s$")
_DUR = re.compile(r"^\d+(\.\d+)?\s*(ps|ns|us|µs|ms|s)$")


def _type_of(values):
    vals = [v for v in values if v][:500]
    if not vals:
        return "empty"
    for name, rx in (("integer", _INT), ("time stamp", _TIME), ("time span", _DUR), ("hex", _HEX)):
        if all(rx.match(v) for v in vals):
            return name
    return "text"


_ID = re.compile(r"^\d{1,4}:\d{1,3}[:.]\d{1,2}$")                    # a requester / completer / device id: bus:device.function
_NUMERIC_LIKE = re.compile(r"^[0-9.,:;/_\-+x ]+$", re.I)              # digits and separators only (numbers, ranges, addresses)
_QUANTITY = re.compile(r"^-?\d[\d.,]*\s*(ps|ns|us|µs|ms|s|b|kb|mb|gb|bytes?|dw|dwords?|gt/s|lanes?|%)$", re.I)


def is_keyword(value, column):
    """A special keyword is a WORD: the name of a type, an event, a status (ACK, UpdateFC-P, PM_Request_Ack, CplD, TS1,
    Link Up, Successful Completion). Never a number (a sequence number, a tag, a length), a hex value or an address, a
    bus:device.function id, a time or a quantity with its unit, or the column's own name repeated in a cell."""
    v = value.strip()
    if not v or not re.search(r"[A-Za-z]", v):
        return False
    if _NUMERIC_LIKE.match(v) or _ID.match(v) or _TIME.match(v) or _DUR.match(v) or _QUANTITY.match(v):
        return False
    if _HEX.match(v) and re.search(r"\d", v):          # 1F, 0x2A, 3fe0: a hex number, not a word
        return False
    if v.lower() == (column or "").strip().lower() or v.lower() == (column or "").partition(".")[2].strip().lower():
        return False                                    # the header repeated in the first row ("Marker" under Marker)
    return True


IDENTITY_COLUMNS = {"mn", "sn", "fr", "model number", "serial number", "firmware revision", "subnqn", "nqn"}   # the drive's identity
FLAG_WORDS = {"yes", "no", "true", "false", "on", "off"}                      # a yes/no flag is not a keyword
_CODE_NAME = re.compile(r"^(0x[0-9A-Fa-f]+|\d+)\s*\((.+)\)$")              # "0x02 (Read)" -> Read
_NAME_VALUE = re.compile(r"^([A-Za-z][^:]{0,60}?)\s*:\s*[-+]?\d[\d.,]*\s*[A-Za-z/%µ#]{0,6}$")   # "Speed Change: 16.0 GT/s" -> Speed Change
_COUNT_PHRASE = re.compile(r"^\d[\d,]*\s+[A-Za-z]")                         # "1 error(s)", "3 warnings": a count


def keyword_names(value, column):
    """The special keywords a cell holds, as NAMES: the words (ACK, UpdateFC-P, Read, Successful Completion, Speed Change),
    without the numbers around them. A listed cell ("2.5 GT/s, 5.0 GT/s") is looked at part by part."""
    col = (column or "").strip().lower()
    if col in IDENTITY_COLUMNS or col.partition(".")[2].strip() in IDENTITY_COLUMNS:
        return []
    out = []
    for part in ([x.strip() for x in value.split(",")] if "," in value else [value.strip()]):
        m = _CODE_NAME.match(part)
        if m:
            part = m.group(2).strip()
        m = _NAME_VALUE.match(part)
        if m:
            part = m.group(1).strip()
        if part.lower() in FLAG_WORDS or _COUNT_PHRASE.match(part):
            continue
        if is_keyword(part, column):
            out.append(part)
    return out


SPEC_CITE = re.compile(r"((?:NVMe|NVM Express|PCIe|PCI Express)[^|\n]{0,40}?(?:§\s*[0-9][0-9.]*[0-9]|Section\s+[0-9][0-9.]*[0-9]|Figure\s+[0-9]+|Table\s+[0-9]+)"
                       r"|doc\s+[A-Z]{2,}\s+[0-9][0-9.]*[0-9]|manual\s+v[0-9][0-9.]*[0-9])", re.I)      # specification sections, and the LeCroy manual references the notes use ("doc VSE 5.2.12")


@functools.lru_cache(maxsize=512)
def _source_details(path, line, mtime):
    kind = "project research note" if "research_notes" in path else "LeCroy manual" if "lecroy" in os.path.basename(path).lower() and not path.endswith((".md", ".json")) else \
        "specification" if re.search(r"(nvm.?express|pci.?express|base.?spec)", os.path.basename(path), re.I) else "reference document"
    heading, here = "", ""
    with open(path, encoding="utf-8", errors="replace") as fh:
        for i, text in enumerate(fh, 1):
            if text.lstrip().startswith("#"):
                heading = text.strip().lstrip("#").strip()
            if i == line:
                here = text.strip()
                break
    cites = list(dict.fromkeys(m.strip() for m in SPEC_CITE.findall(here)))
    return {"document": os.path.basename(path), "kind": kind, "section": heading[:120], "cites": cites[:4], "line_text": here[:240]}


@functools.lru_cache(maxsize=256)
def _blank_positions(path, mtime):
    header, _rows = L.sniff(path, 0)
    return [i + 1 for i, h in enumerate(header) if not (h or "").strip()]


def blank_header_positions(path):
    """The positions (1 = first) of the analyzer's blank spacer columns: no header and never a value."""
    try:
        return list(_blank_positions(path, os.path.getmtime(path)))
    except (OSError, UnicodeDecodeError, ValueError):
        return []


def source_details(ref):
    """Where a fact taken from a document comes from, in words for the page (owner, 2026-11-10: "which specification, in that .md file?"): the kind of document (a project
    research note is not a specification), the heading the line sits under, and any specification section named on that very line; none named is said as such."""
    path, _, line = (ref or "").rpartition(":")
    try:
        n = int(line)
        mtime = os.path.getmtime(path)
    except (ValueError, OSError):
        return None
    return dict(_source_details(path, n, mtime))


def reading_line(name, lines, done_bytes, size, t0, share=(0.0, 100.0), columns=None):
    """One status line while a file is read: '37% · reading packets.csv: 36,700 of about 99,100 lines, about 62,400 left · 12 s so far · about 20 s to go'.
    The total is estimated from the bytes read so far, so it says "about". share maps the reading onto part of the step's own percentage."""
    frac = min(1.0, done_bytes / float(max(1, size)))
    pct = share[0] + (share[1] - share[0]) * frac
    el = time.time() - t0
    est = int(lines / frac) if frac > 0.001 else None
    cols = " (%s columns)" % "{:,}".format(columns) if columns else ""
    text = "%d%% · reading %s%s: %s of about %s lines, about %s left" % (pct, name, cols, "{:,}".format(lines), "{:,}".format(est), "{:,}".format(max(0, est - lines))) if est else \
        "%d%% · reading %s%s: %s lines so far" % (pct, name, cols, "{:,}".format(lines))
    text += " · %s so far" % core.fmt_secs(el)
    if 0.01 < frac < 1.0:
        togo = el * (1 - frac) / frac
        text += " · about %s to go" % core.fmt_secs(togo) if togo >= 1 else " · almost done"
    return text


def full_profile(path, level, progress=None, share=(0.0, 100.0)):
    """EVERY row of the file, every column, by code (no model, no sample): per column how many rows hold a value, its
    type, how many different values, the values with their counts and the first rows where each appears (row n = line
    n + 1 of the file, after the header). Memory stays low: at most DISTINCT_CAP different values are counted per column."""
    size = os.path.getsize(path)
    with open(path, "r", encoding="utf-8-sig", errors="replace", newline="") as fh:
        rd = L.read_csv(fh, path)
        header = next(rd, [])
        al = L.align_header(level, header) if level else None
        named = sorted(al.positions.items(), key=lambda kv: kv[1]) if al else [((h or "column %d" % (i + 1)), i) for i, h in enumerate(header)]
        if al:
            named += [(h, i) for i, h in al.unknown]
            named += [("column %d" % (i + 1), i) for i in al.separators]     # no header: read too, so a value under a blank header is seen (found 2026-11-10: split.csv column 4 held the link speed); the loader stores them under the same name
        pairs = [(j, idx) for j, (_n, idx) in enumerate(named)]
        filled = [0] * len(named)
        counts = [dict() for _ in named]
        first = [dict() for _ in named]
        over = [False] * len(named)
        n, t0, bytes_seen, last_report = 0, time.time(), 0, 0.0
        for row in rd:
            n += 1
            m = len(row)
            for j, idx in pairs:
                if idx >= m:
                    continue
                v = row[idx]
                if not v or v.isspace():
                    continue
                v = v.strip()
                filled[j] += 1
                c = counts[j]
                if v in c:
                    c[v] += 1
                    f = first[j][v]
                    if len(f) < ROWS_PER_VALUE:
                        f.append(n)
                elif len(c) < DISTINCT_CAP:
                    c[v] = 1
                    first[j][v] = [n]
                else:
                    over[j] = True
            if n % 100000 == 0 and hasattr(fh, "buffer"):
                L.drop_file_cache(fh.buffer, 0, fh.buffer.tell())         # every row is read once: the file cache is left to the other programs
            if progress and n % 2000 == 0 and time.time() - last_report >= 1:      # about once a second, in one line: which file, lines read, about how many are left (owner, 2026-11-10)
                last_report = time.time()
                bytes_seen = fh.buffer.tell() if hasattr(fh, "buffer") else 0
                progress(reading_line(os.path.basename(path), n, bytes_seen, size, t0, share, columns=len(header)))
    cols = []
    for j, (name, idx) in enumerate(named):
        c = counts[j]
        typ = _type_of(list(c.keys()))
        distinct = len(c)
        top = sorted(c.items(), key=lambda kv: (-kv[1], kv[0]))
        agg = {}
        for v, k in top:
            for nm in keyword_names(v, name):
                a = agg.setdefault(nm, {"count": 0, "rows": [], "as_written": []})
                a["count"] += k
                a["rows"] = sorted(set(a["rows"] + first[j][v]))[:ROWS_PER_VALUE]
                if v != nm and len(a["as_written"]) < 3:
                    a["as_written"].append(v[:120])
        words = sorted(agg.items(), key=lambda kv: (-kv[1]["count"], kv[0]))
        keyword_col = 0 < len(words) <= KEYWORD_MAX_DISTINCT and not over[j]
        col = {"column": name, "position": idx, "header_cell": header[idx] if idx < len(header) else "", "type": typ,
               "rows_with_value": filled[j], "filled_pct": round(100.0 * filled[j] / max(1, n), 2),
               "distinct": distinct, "distinct_more_than_counted": over[j],
               "top_values": [{"value": v[:120], "count": k, "rows": first[j][v]} for v, k in top[:TOP_VALUES]]}
        if keyword_col:
            # the keywords are the words only; their counts and first rows stay in the Explorer's memory for questions
            col["keywords"] = [{"value": nm[:120], "count": a["count"], "rows": a["rows"], "as_written": a["as_written"]} for nm, a in words]
        if typ == "integer" and c:
            nums = [int(v) for v in c]
            col["min"], col["max"] = min(nums), max(nums)
        cols.append(col)
    return {"path": path, "level": level, "level_label": C.LEVEL_LABEL.get(level) if level else "", "rows": n,
            "columns_in_file": len(header), "columns_with_values": sum(1 for x in cols if x["rows_with_value"]),
            "columns_empty": [x["column"] for x in cols if not x["rows_with_value"]],
            "keyword_columns": sum(1 for x in cols if x.get("keywords")), "keywords": sum(len(x.get("keywords") or []) for x in cols),
            "header_format": al.header_format if al else "unknown", "seconds": round(time.time() - t0, 1), "columns": cols}


def where(path, rows):
    """Where to see it: the file and its line numbers (row n of the data is line n + 1, after the header line)."""
    return "%s line %s" % (path, ", ".join(str(r + 1) for r in rows[:ROWS_PER_VALUE])) if rows else path


# ---------------------------------------------------------------------------------------------- stand-ins (no model)
def _standin_explore(prof, batch, with_summary):
    out = {"columns": []}
    for c in batch:
        kw = c.get("keywords") or []
        if kw:
            what = "%d keyword%s: %s%s" % (len(kw), "" if len(kw) == 1 else "s", ", ".join(k["value"] for k in kw[:8]), " ..." if len(kw) > 8 else "")
        elif c["type"] == "integer" and "min" in c:
            what = "numbers from %s to %s (%s different)" % (c["min"], c["max"], "{:,}".format(c["distinct"]))
        else:
            what = "%s values (%s different%s), such as %s" % (c["type"], "{:,}".format(c["distinct"]), " or more" if c["distinct_more_than_counted"] else "",
                                                              ", ".join(t["value"] for t in c["top_values"][:3]))
        out["columns"].append({"column": c["column"], "observed": "%s of %s rows hold a value: %s." % ("{:,}".format(c["rows_with_value"]), "{:,}".format(prof["rows"]), what)})
    if with_summary:
        busy = sorted([c for c in prof["columns"] if c.get("keywords")], key=lambda c: -c["rows_with_value"])[:3]
        out["summary"] = ("This file has %s rows, one %s record per row, exported by the protocol analyzer. %d of its %d columns hold values; "
                          "%d columns hold special keywords (%d different keywords in all)%s." % (
                              "{:,}".format(prof["rows"]), prof["level_label"] or "analyzer", prof["columns_with_values"], prof["columns_in_file"],
                              prof["keyword_columns"], prof["keywords"],
                              ("; the most used are in " + ", ".join(c["column"] for c in busy)) if busy else ""))
    return out


def _contents(c):
    """A column's contents in a few facts that code computed from every row (the Explorer's profile): never the rows themselves."""
    out = {"observed": str(c.get("observed") or "")[:300], "rows_with_value": c.get("rows_with_value")}
    for k in ("distinct", "min", "max"):
        if c.get(k) not in (None, ""):
            out[k] = c[k]
    tops = [{"value": t.get("value"), "count": t.get("count")} for t in (c.get("top_values") or [])[:TOP_VALUES] if isinstance(t, dict)]   # every value the Explorer kept
    if tops:
        out["most_common"] = tops
    return out


def _values_of(it):
    c = it.get("contents") or {}
    vals = [str(t["value"]) for t in c.get("most_common") or [] if t.get("value") is not None] + [str(k) for k in it.get("keywords") or []]
    return vals + [str(c[k]) for k in ("min", "max") if c.get(k) not in (None, "")]


def _doc_meaning(it):
    """The last answer when the model gave none: the reference document's own words about the column, if a snippet was found
    for it (a real source); otherwise None, and the column stays without a meaning for the admin (owner, 2026-11-11: no text
    written by code)."""
    if not it.get("snippets"):
        return None
    s = it["snippets"][0]
    return {"column": it["column"], "meaning": s["quote"][:240], "source": {"kind": "document", "ref": s["ref"], "quote": s["quote"][:160]}, "keywords": []}


def _standin_ground(items):
    out = []
    for it in items:
        if not it["snippets"]:
            continue
        s = it["snippets"][0]
        out.append({"column": it["column"], "meaning": s["quote"][:240],
                    "source": {"kind": "document", "ref": s["ref"], "quote": s["quote"][:160]}, "keywords": []})
    return {"columns": out}


EXPLORE_INSTRUCTION = """You are the Data Explorer of one CSV file exported by a Teledyne LeCroy PCIe/NVMe protocol
analyzer. You know ONLY the data: CONTEXT holds the profile that code computed from EVERY row of the file (each column's
type, how many rows hold a value, how many different values, its top values, and its special keywords: the WORDS the
column holds, such as ACK, UpdateFC-P, CplD, Link Up; numbers are never keywords). The counts are exact: repeat them as
they are, never estimate. Describe only what the data holds. Do NOT say what a column or a keyword means in protocol
terms: another agent (the Grounder) does that. For each column write "observed": one plain sentence of what the data
holds (for example "99,088 rows hold a value; keywords: ACK, UpdateFC-P, UpdateFC-NP, PM_Request_Ack"). When
CONTEXT asks for a summary, write "summary": 3 to 5 plain sentences for a reader who has never seen this file: what one
row is, what the file records, how big it is, which columns carry most of the information, which keywords stand out."""
EXPLORE_SHAPE = '{"summary": "... (only when asked)", "columns": [{"column": "...", "observed": "..."}]}'

GROUND_INSTRUCTION = """You are the Data Grounder of one CSV file exported by a Teledyne LeCroy PCIe/NVMe protocol
analyzer. CONTEXT gives, for each column, its name, the special keywords found in it and a summary of its contents that
code computed from every row (what the Data Explorer observed, its most common values with their counts, its smallest and
largest value; never the rows themselves). Find what each column and each keyword means, and say where you found it.
Look in this order: (1) the snippets of the reference documents given in CONTEXT: source kind "document", ref exactly
as given, quote copied from the snippet; (2) the web, when it is allowed (see THE WEB below): kind "web"; (3) the
column's name and contents, read with your knowledge of PCI Express and NVMe: when the contents decide it, kind "data",
ref = the column name exactly as given, quote = one value from its contents that shows it; otherwise kind "model", ref
"model knowledge", quote "" (allowed, and shown to the admin as such). One short plain sentence per meaning. Leave a
meaning empty only when neither documents, the web, the name nor the contents tell it: never invent."""
GROUND_RETRY_NOTE = """

THE WEB COULD NOT BE USED for these columns (the first try gave no meaning for them): understand each column from its name
and the data it holds (its most common values with their counts, its smallest and largest value, its keywords, what the Explorer
observed), read with your knowledge of PCI Express and NVMe: kind "data" when the values decide it (quote one of them), else
"model"."""
GROUND_SHAPE = ('{"columns": [{"column": "...", "meaning": "...", "source": {"kind": "document|web|data|model", "ref": "<file:line | URL | column name | model knowledge>", '
                '"quote": "<copied exactly, or empty for model>"}, "keywords": [{"keyword": "...", "meaning": "...", "source": {"kind": "...", "ref": "...", "quote": "..."}}]}]}')


# ---------------------------------------------------------------------------------------------- the run
def steps(params, project):
    files = inventory(project.get("folder"))
    out = [{"key": "director", "title": "Director: list the CSVs of the folder and what each one is", "family": "1", "agent": "Director"}]
    for f in files:
        n = f["name"]
        out += [
            {"key": "explore:" + n, "title": "Data Explorer: every row and column of %s (the data)" % n, "family": "1", "agent": "Data Explorer", "input": {"file": f}},
            {"key": "ground:" + n, "title": "Data Grounder: what the columns and keywords of %s mean" % n, "family": "1", "agent": "Data Grounder", "input": {"file": f}},
            {"key": "manager:" + n, "title": "Manager: the data dictionary of %s, for your review" % n, "family": "1", "agent": "Manager", "review": True, "input": {"file": f}},
        ]
    return out


def refs_of(ctx):
    p = ctx.project
    folders = [x for x in (core.jload(p.get("refs"), []) or []) if x]
    return core.References(folders, os.path.join(ctx.engine.runner.sandbox_root, "_pdf_cache"))


def run_step(ctx):
    key = ctx.step["key"]
    if key == "director":
        files = inventory(ctx.project.get("folder"))
        if not files:
            raise RuntimeError("no CSV file in the folder %s" % ctx.project.get("folder"))
        problem = folder_problem(files)
        if problem:
            raise RuntimeError(problem)
        return core.Result({"files": files, "references": core.jload(ctx.project.get("refs"), [])})
    kind, _, name = key.partition(":")
    f = ctx.input["file"]
    if kind == "explore":
        return _explore(ctx, f)
    if kind == "ground":
        return _ground(ctx, f)
    if kind == "manager":
        return _manager(ctx, f)
    raise RuntimeError("unknown step %s" % key)


def _slim(c, k=25):
    """A column as the Explorer's model sees it: the counts, the top values and up to k keywords."""
    return {key: c[key] for key in ("column", "type", "rows_with_value", "filled_pct", "distinct", "distinct_more_than_counted", "min", "max") if key in c} | {
        "top_values": [{"value": t["value"], "count": t["count"]} for t in c["top_values"][:6]],
        "keywords": [t["value"] for t in (c.get("keywords") or [])[:k]]}


def _explore(ctx, f):
    ctx.progress("Data Explorer: reading every row of %s by code" % f["name"])
    prof = full_profile(f["path"], f["level"], progress=lambda t: ctx.progress(t + " · Data Explorer"), share=(0.0, 70.0))      # reading is the first 70% of this step
    box = ctx.engine.runner.sandbox(ctx.run["id"], "explorer_" + f["name"])
    filled = [c for c in prof["columns"] if c["rows_with_value"]]
    observed, summary, producers = {}, "", set()
    head = {k: prof[k] for k in ("rows", "level_label", "columns_in_file", "columns_with_values", "keyword_columns", "keywords")}
    for i in range(0, max(1, len(filled)), BATCH):
        batch = filled[i:i + BATCH]
        want = i == 0
        ctx.progress("%d%% · %s: all %s lines read · the model describes columns %d to %d of the %d that hold a value (part %d of %d) · Data Explorer" % (
            70 + 30 * i // max(1, len(filled)), f["name"], "{:,}".format(prof["rows"]), i + 1, i + len(batch), len(filled), i // BATCH + 1, max(1, -(-len(filled) // BATCH))))
        ans, producer, _ = ctx.engine.runner.ask(ctx.run["id"], "explorer_" + f["name"], EXPLORE_INSTRUCTION,
                                                 {"file": f["name"], "file_facts": head, "write_summary": want, "columns": [_slim(c) for c in batch]},
                                                 EXPLORE_SHAPE, "columns", lambda b=batch, w=want: _standin_explore(prof, b, w))
        producers.add(producer)
        for a in ans.get("columns") or []:
            if a.get("column"):
                observed[a["column"]] = str(a.get("observed") or "")[:400]
        if want:
            summary = str(ans.get("summary") or "").strip() or _standin_explore(prof, [], True)["summary"]
    for c in prof["columns"]:
        c["observed"] = observed.get(c["column"]) or (_standin_explore(prof, [c], False)["columns"][0]["observed"] if c["rows_with_value"] else "no row holds a value")
    memory = dict(prof, summary=summary, made=time.time(), agent="Data Explorer")
    path = os.path.join(box, "memory.json")
    with open(path, "w") as fh:
        json.dump(memory, fh, indent=1)
    return core.Result({"memory_file": path, "rows": prof["rows"], "columns_with_values": prof["columns_with_values"], "columns_in_file": prof["columns_in_file"],
                        "keywords": prof["keywords"], "seconds_reading": prof["seconds"], "summary": summary}, producer=", ".join(sorted(producers)))


def _terms(column, keywords):
    terms = [column]
    leaf = column.partition(".")[2]
    if leaf:
        terms.append(leaf)
    terms += [k for k in keywords[:3] if 2 <= len(k) <= 40]
    return list(dict.fromkeys(t for t in terms if t))


def _ground(ctx, f):
    ex = ctx.output_of("explore:" + f["name"])
    mem = json.load(open(ex["memory_file"]))
    refs = refs_of(ctx)
    runner = ctx.engine.runner
    web_ok = runner.can_search_web()
    items = []
    for c in mem["columns"]:
        if not c["rows_with_value"]:
            continue
        kws = [k["value"] for k in (c.get("keywords") or [])][:GROUND_KEYWORDS]
        snips = []
        if refs.folders:
            for t in _terms(c["column"], kws):
                snips += refs.search(t, limit=2)
        items.append({"column": c["column"], "header_cell": c.get("header_cell"), "type": c["type"], "keywords": kws, "snippets": snips[:4],
                      "contents": _contents(c)})
    answers, producers = [], set()
    # small parts, several at once (the runner allows AgentRunner.AT_ONCE model calls together), and a progress line that moves every
    # 10 s while the model works, so a long call is never shown as a still 0 %
    parts = [items[i:i + GROUND_BATCH] for i in range(0, len(items), GROUND_BATCH)]
    state, lock, stop, t0 = {"done": 0, "cols": 0, "busy": 0, "retries": 0}, threading.Lock(), threading.Event(), time.time()

    def say():
        with lock:
            done, cols, busy, retries = state["done"], state["cols"], state["busy"], state["retries"]
        ctx.progress("%d%% · Data Grounder: meanings of %s: %d of %d columns done (part %d of %d), %d part%s at the model now%s · %s so far (documents%s, then the names and contents)" % (
            100 * cols // max(1, len(items)), f["name"], cols, len(items), done, len(parts), busy, "" if busy == 1 else "s",
            (", %d part%s retried without the web" % (retries, "" if retries == 1 else "s")) if retries else "", core.fmt_secs(time.time() - t0),
            ", the web" if web_ok else ""))

    def tick():
        while not stop.wait(10):
            say()

    def ask(batch, name, web, note=""):
        """One call; the stand-in gives nothing here, so a failed call is seen as columns without a meaning and is retried."""
        ans, producer, _ = runner.ask(ctx.run["id"], name, GROUND_INSTRUCTION + note, {"file": f["name"], "level": f["level_label"], "columns": batch},
                                      GROUND_SHAPE, "columns", lambda: {"columns": []}, web=web)
        got = {a["column"]: a for a in ans.get("columns") or [] if isinstance(a, dict) and a.get("column") and str(a.get("meaning") or "").strip()}
        return got, producer

    def one(k_batch):
        k, batch = k_batch
        name = "grounder_%s_part%d" % (f["name"], k + 1)
        with lock:
            state["busy"] += 1
        try:
            got, producer = ask(batch, name, web_ok)
            used = [producer]
            missing = [c for c in batch if c["column"] not in got]
            if missing:               # retry 1 (owner, 2026-11-11): without the web, from each column's name and contents
                with lock:
                    state["retries"] += 1
                more, producer = ask(missing, name + "_retry", False, GROUND_RETRY_NOTE)
                got.update(more)
                used.append(producer + " (retry without the web)")
                missing = [c for c in batch if c["column"] not in got]
            if len(missing) > 1:      # retry 2: the same, in two smaller halves
                half = -(-len(missing) // 2)
                for j, part in enumerate((missing[:half], missing[half:])):
                    more, producer = ask(part, "%s_retry%d" % (name, j + 2), False, GROUND_RETRY_NOTE)
                    got.update(more)
                    used.append(producer + " (retry in halves)")
                missing = [c for c in batch if c["column"] not in got]
            if missing:               # last: a reference document's snippet, if one was found for it; never a text written by code
                for c in missing:     # (owner, 2026-11-11: "it should not be written"): without a source the column stays without a meaning
                    m = _doc_meaning(c)
                    if m:
                        got[c["column"]] = m
                left = len([c for c in batch if c["column"] not in got])
                if left:
                    used.append("%d column%s without a meaning after 3 tries" % (left, "" if left == 1 else "s"))
            return list(got.values()), "; ".join(dict.fromkeys(used))
        finally:
            with lock:
                state["busy"] -= 1
                state["done"] += 1
                state["cols"] += len(batch)

    say()
    ticker = threading.Thread(target=tick, daemon=True)
    ticker.start()
    try:
        with ThreadPoolExecutor(max_workers=max(1, core.AgentRunner.AT_ONCE)) as pool:
            for got, producer in pool.map(one, list(enumerate(parts))):
                producers.add(producer)
                answers += got
                say()                       # the line moves with every part that comes back, besides every 10 s
    finally:
        stop.set()
    say()
    web = runner.web_sources()
    seen_values = {it["column"]: _values_of(it) for it in items}        # a "data" quote must be one of the column's own values
    meanings = {}
    for a in answers:
        if not a.get("column"):
            continue
        entry = {"meaning": str(a.get("meaning") or "").strip()}
        claims = core.check_claims([{"text": a["column"], "source": a.get("source") or {}}], refs=refs, web=web, data_values=seen_values)
        entry["source"], entry["checked"], entry["why"] = claims[0]["source"], claims[0]["verified"], claims[0]["why"]
        ctx.evidence(claims if entry["meaning"] else [])
        kw = {}
        for k in a.get("keywords") or []:
            if not k.get("keyword") or not str(k.get("meaning") or "").strip():
                continue
            kc = core.check_claims([{"text": "%s = %s" % (a["column"], k["keyword"]), "source": k.get("source") or {}}], refs=refs, web=web, data_values=seen_values)[0]
            kw[k["keyword"]] = {"meaning": str(k["meaning"]).strip(), "source": kc["source"], "checked": kc["verified"], "why": kc["why"]}
        entry["keywords"] = kw
        meanings[a["column"]] = entry
    memory = {"agent": "Data Grounder", "file": f["name"], "made": time.time(), "web_allowed": web_ok,
              "reference_folders": refs.folders, "columns": meanings}
    box = runner.sandbox(ctx.run["id"], "grounder_" + f["name"])
    path = os.path.join(box, "memory.json")
    with open(path, "w") as fh:
        json.dump(memory, fh, indent=1)
    by = Counter(_status(m) for m in meanings.values())
    return core.Result({"memory_file": path, "columns_asked": len(items), "meanings": dict(by), "web_allowed": web_ok},
                       producer=", ".join(sorted(producers)))


def _status(m):
    """Where a meaning comes from, in words."""
    if not m or not m.get("meaning"):
        return "no meaning found"
    kind = (m.get("source") or {}).get("kind")
    if kind == "document":
        return "from a reference document" if m.get("checked") else "document quote not found: not trusted"
    if kind == "web":
        return "from a web page (checked)" if m.get("checked") else "web quote not found on the page: not trusted"
    if kind == "admin":
        return "given by the admin"
    if kind == "data":
        return "from the column's name and contents (checked: the value is in the column)" if m.get("checked") else "from the column's name and contents"
    return "from the model's knowledge (no source to check)"


def _manager(ctx, f):
    ex, gr = ctx.output_of("explore:" + f["name"]), ctx.output_of("ground:" + f["name"])
    emem = json.load(open(ex["memory_file"]))
    gmem = json.load(open(gr["memory_file"])) if gr.get("memory_file") and os.path.exists(gr["memory_file"]) else {"columns": {}}
    edits = ctx.input.get("edits") or {}
    rows = []
    for c in emem["columns"]:
        if not c["rows_with_value"]:
            continue
        g = gmem["columns"].get(c["column"]) or {}
        if c["column"] in edits:
            g = dict(g, meaning=edits[c["column"]], source={"kind": "admin", "ref": ctx.project.get("admin") or "admin", "quote": ""}, checked=True)
        kws = []
        for k in c.get("keywords") or []:
            gk = (g.get("keywords") or {}).get(k["value"]) or {}
            kws.append({"value": k["value"], "count": k["count"], "rows": k["rows"], "where": where(f["path"], k["rows"]),
                        "meaning": gk.get("meaning", ""), "status": _status(gk), "source": gk.get("source")})
        first_rows = (c["top_values"][0]["rows"] if c["top_values"] else [])
        rows.append({"column": c["column"], "type": c["type"], "rows_with_value": c["rows_with_value"], "distinct": c["distinct"],
                     "observed": c.get("observed", ""), "meaning": g.get("meaning", ""), "status": _status(g),
                     "sources": [g["source"]] if g.get("meaning") and g.get("source") and g.get("checked") else [],
                     "source": g.get("source") if g.get("meaning") else None, "where": where(f["path"], first_rows), "keywords": kws})
    counts = Counter(r["status"] for r in rows)
    dictionary = {"file": f["name"], "path": f["path"], "level": f["level"], "format_key": f["format_key"], "made": time.time(),
                  "rows": emem["rows"], "rows_estimate": emem["rows"], "summary": emem.get("summary", ""), "columns": rows,
                  "empty_columns": emem["columns_empty"], "explorer_memory": ex["memory_file"], "grounder_memory": gr.get("memory_file")}
    box = ctx.engine.runner.sandbox(ctx.run["id"], "manager_" + f["name"])
    path = os.path.join(box, "dictionary.json")
    with open(path, "w") as fh:
        json.dump(dictionary, fh, indent=1)
    admin = ctx.project.get("admin") or "admin"
    body = ["**Admin %s, need review.** The data dictionary of **%s**." % (admin, f["name"]), "", emem.get("summary", ""), "",
            "%s rows; %d of %d columns hold values; %d special keywords." % ("{:,}".format(emem["rows"]), len(rows), emem["columns_in_file"], emem["keywords"]), "",
            "| where the meanings come from | columns |", "|---|---|"] + ["| %s | %d |" % kv for kv in counts.most_common()]
    return core.Result({"dictionary_file": path, "counts": dict(counts)},
                       review={"title": "Data dictionary of %s" % f["name"], "body": "\n".join(body),
                               "data": {"dictionary_file": path, "summary": emem.get("summary", ""), "path": f["path"],
                                        "facts": {"rows": emem["rows"], "columns_in_file": emem["columns_in_file"], "columns_with_values": len(rows),
                                                  "keywords": emem["keywords"], "level": f["level_label"], "seconds_reading": emem.get("seconds")},
                                        "counts": dict(counts), "table": rows, "empty": list(emem["columns_empty"]), "spacers": blank_header_positions(f["path"]),
                                        "memories": {"explorer": ex["memory_file"], "grounder": gr.get("memory_file"), "dictionary": path}}})


# ---------------------------------------------------------------------------------------------- the Manager answers the admin
DATA_WORDS = re.compile(r"\b(row|rows|line|lines|how many|count|which|where|show|appear|present|value|values|keyword|keywords|data|hold|holds|contain|contains|find|list)\b", re.I)
MEANING_WORDS = re.compile(r"\b(mean|means|meaning|stand|stands|what is|what are|why|define|definition|purpose|used for)\b", re.I)


def _lookup(path, mem, question):
    """Code first: the columns and keywords the question names, with their counts and the lines where they are."""
    q = question.lower()
    hits = []
    for c in mem["columns"]:
        if not c["rows_with_value"]:
            continue
        named = c["column"].lower() in q or (c["column"].partition(".")[2] or "~").lower() in q
        for k in c.get("keywords") or []:
            if len(k["value"]) >= 2 and re.search(r"(?<![a-z0-9])%s(?![a-z0-9])" % re.escape(k["value"].lower()), q):
                hits.append({"column": c["column"], "keyword": k["value"], "rows_holding_it": k["count"], "where": where(path, k["rows"])})
        if named:
            hits.append({"column": c["column"], "rows_with_value": c["rows_with_value"], "type": c["type"], "distinct": c["distinct"],
                         "observed": c.get("observed"), "top_values": [{"value": t["value"], "count": t["count"], "where": where(path, t["rows"])} for t in c["top_values"][:6]],
                         "keywords": [{"value": k["value"], "count": k["count"]} for k in (c.get("keywords") or [])[:30]]})
    return hits[:20]


EXPLORER_ANSWER = """You are the Data Explorer of one CSV file. Answer the admin's question from your memory of the data
(CONTEXT: the summary, the profile counted from every row, and the lines the code found for what the question names).
Use the exact counts; give the file path and line numbers where the admin can see it. Say nothing about what things
mean (that is the Grounder's). If your memory does not hold the answer, say so."""
GROUNDER_ANSWER = """You are the Data Grounder of one CSV file. Answer the admin's question about what a column or a keyword
means, from your memory (CONTEXT: the meanings you found, each with its source). Say where each meaning comes from (the
document and line, the web page, or model knowledge). If your memory does not hold it, say so; you may look it up (see
THE WEB below, when allowed) and cite the page."""


def manager_ask(engine, review, step, question, history):
    """The admin asks the Manager; the Manager asks the right helper: the Explorer for the data (with the lines where it
    is), the Grounder for a meaning (with its source), or both. -> (answer text, producer)."""
    out = core.jload(step["output"], {}) or {}
    d = json.load(open(out["dictionary_file"]))
    emem = json.load(open(d["explorer_memory"]))
    gmem = json.load(open(d["grounder_memory"])) if d.get("grounder_memory") and os.path.exists(d["grounder_memory"]) else {"columns": {}}
    data_q, meaning_q = bool(DATA_WORDS.search(question)), bool(MEANING_WORDS.search(question))
    ask = (["explorer"] if data_q or not meaning_q else []) + (["grounder"] if meaning_q or not data_q else [])
    hits = _lookup(d["path"], emem, question)
    parts, producers = [], []
    runner, run_id = engine.runner, review["run"]
    if "explorer" in ask:
        ctx = {"question": question, "file": d["path"], "summary": emem.get("summary"), "rows": emem["rows"],
               "what_the_question_names": hits, "columns": [{"column": c["column"], "rows_with_value": c["rows_with_value"], "observed": c.get("observed")}
                                                            for c in emem["columns"] if c["rows_with_value"]][:150], "conversation": history[-6:]}

        def standin():
            if hits:
                return {"answer": "; ".join(("%s = %s: %s rows, see %s" % (h["column"], h["keyword"], "{:,}".format(h["rows_holding_it"]), h["where"])) if "keyword" in h else
                                            ("%s: %s rows hold a value; %s" % (h["column"], "{:,}".format(h["rows_with_value"]), h.get("observed") or "")) for h in hits[:6])}
            return {"answer": "%s (the file %s)" % (emem.get("summary") or "", d["path"])}
        a, prod, _ = runner.ask(run_id, "explorer_answers", EXPLORER_ANSWER, ctx, '{"answer": "..."}', "answer", standin)
        parts.append("**Data Explorer (the data):** " + str(a.get("answer", "")))
        producers.append("Explorer: " + prod)
    if "grounder" in ask:
        names = {h["column"] for h in hits}
        kwn = {(h["column"], h["keyword"]) for h in hits if "keyword" in h}
        mine = {c: m for c, m in gmem["columns"].items() if c in names} or gmem["columns"]
        ctx = {"question": question, "meanings": {c: {"meaning": m.get("meaning"), "status": _status(m), "source": m.get("source"),
                                                      "keywords": {k: v for k, v in (m.get("keywords") or {}).items() if not kwn or (c, k) in kwn}}
                                                  for c, m in list(mine.items())[:80]}, "conversation": history[-6:]}

        def standin():
            got = [("%s: %s (%s)" % (c, m.get("meaning"), _status(m))) for c, m in mine.items() if m.get("meaning")][:6]
            return {"answer": "; ".join(got) if got else "I have no meaning for that yet (no document, web page or model knowledge gave one)."}
        a, prod, _ = runner.ask(run_id, "grounder_answers", GROUNDER_ANSWER, ctx, '{"answer": "..."}', "answer", standin, web=runner.can_search_web())
        parts.append("**Data Grounder (the meanings):** " + str(a.get("answer", "")))
        producers.append("Grounder: " + prod)
    asked = " and ".join({"explorer": "the Data Explorer", "grounder": "the Data Grounder"}[x] for x in ask)
    return "I asked %s.\n\n%s" % (asked, "\n\n".join(parts)), "Manager (%s)" % "; ".join(producers)


def on_approve(engine, run, step, data, admin):
    if not step["key"].startswith("manager:"):
        return
    out = core.jload(step["output"], {})
    d = json.load(open(out["dictionary_file"]))
    edits = data.get("edits") or {}
    if not isinstance(edits, dict):
        edits = {}
    by_col = {r["column"]: r for r in d["columns"]}
    unknown = []
    for key, meaning in edits.items():             # "column" or "column: keyword" (owner, 2026-11-10: keyword meanings too; a name the file does not have is refused, not ignored)
        col, _, kw = str(key).partition(":")
        col, kw = col.strip(), kw.strip()
        r = by_col.get(col) or by_col.get(str(key).strip())
        if r is None:
            unknown.append(str(key))
        elif kw and r is not by_col.get(str(key).strip()):
            k = next((k for k in r.get("keywords") or [] if k.get("value") == kw), None)
            if k is None:
                unknown.append(str(key))
            else:
                k["meaning"], k["status"], k["source"] = str(meaning), "given by the admin", {"kind": "admin", "ref": admin, "quote": ""}
        else:
            r["meaning"], r["status"], r["source"] = str(meaning), "given by the admin", {"kind": "admin", "ref": admin, "quote": ""}
    empty = set(d.get("empty_columns") or [])
    for key in list(unknown):                      # a column with no value in this recording can still be given a meaning: it is kept beside the dictionary
        if key.strip() in empty:
            d.setdefault("empty_meanings", {})[key.strip()] = {"meaning": str(edits[key]), "by": admin, "at": time.time()}
            unknown.remove(key)
    if unknown:
        raise ValueError("not in %s, so not saved: %s. Correct or remove these lines, then approve" % (d.get("file"), "; ".join(unknown)))
    d["approved_by"], d["approved_at"] = admin, time.time()
    folder = os.path.join(knowledge_dir(), "dictionaries", d["format_key"])
    os.makedirs(folder, exist_ok=True)
    n = 1 + len([x for x in os.listdir(folder) if x.startswith(os.path.splitext(d["file"])[0] + ".v")])
    d["version"] = n
    base = os.path.splitext(d["file"])[0]
    L.write_json_atomic(os.path.join(folder, "%s.v%d.json" % (base, n)), d, indent=1)
    L.write_json_atomic(os.path.join(folder, "%s.current.json" % base), d, indent=1)


def approved_dictionary(format_key, file_name):
    p = os.path.join(knowledge_dir(), "dictionaries", format_key, "%s.current.json" % os.path.splitext(file_name)[0])
    try:
        return json.load(open(p)) if os.path.exists(p) else None
    except (OSError, ValueError):            # a damaged dictionary counts as none: the data is simply learned again
        return None


def dictionaries_for_level(level):
    """Every approved dictionary of a level (any format), newest first."""
    out = []
    root = os.path.join(knowledge_dir(), "dictionaries")
    if not os.path.isdir(root):
        return out
    for fk in os.listdir(root):
        for fn in os.listdir(os.path.join(root, fk)):
            if fn.endswith(".current.json"):
                try:
                    d = json.load(open(os.path.join(root, fk, fn)))
                except (OSError, ValueError):
                    continue
                if d.get("level") == level:
                    out.append(d)
    out.sort(key=lambda d: d.get("approved_at") or 0, reverse=True)
    return out
