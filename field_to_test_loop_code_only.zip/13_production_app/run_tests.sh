#!/usr/bin/env bash
# All tests: end-to-end API (stand-in LLM), stage-2 unit tests, stage-1 engine fixtures.
set -e
cd "$(dirname "$0")"
python3 -W ignore tests/test_app.py   # includes stage2/tests_v3.py + tests_v4.py and the stage-1 fixtures
