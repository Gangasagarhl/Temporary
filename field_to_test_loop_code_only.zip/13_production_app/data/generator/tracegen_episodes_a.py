"""Failure episodes, part A: shared helpers and NVMe-level patterns.

Every builder is a generator `fn(E, card, **params)` that starts from a healthy
L0 link with an enabled controller and must leave the system healthy again
(re-training / re-initialising when the fault requires it).  Rows that carry
the failure signature are registered with E.key(packet, note) so the sidecar
index can point at them.
"""
from tracegen_core import DN, HOST_RID, MS, NS, SEC, SSD_RID, UP, US
from tracegen_nvme import CQ, SQ, cqe, sqe

IO_TIMEOUT = 30 * SEC      # Linux nvme_core.io_timeout default
ADMIN_TIMEOUT = 60 * SEC   # Linux nvme_core.admin_timeout default


# ============================================================================ helpers
def bg(E, dur, qids=(2, 3, 4), rate_hz=None):
    """Healthy background I/O on other queues while an episode waits."""
    rate = rate_hz or E.bg_rate
    end = E.eng.now + dur
    gap = int(SEC / rate)
    while E.eng.now + gap < end:
        yield E.rng.randint(gap // 2, gap * 3 // 2)
        if E.eng.now >= end:
            break
        q = E.rng.choice(qids)
        if q not in E.nv.sq:
            continue
        if E.rng.random() < 0.6:
            E.sched.spawn(E.read(q, nlb=E.rng.choice((7, 15, 31, 63))))
        else:
            E.sched.spawn(E.write(q, nlb=E.rng.choice((7, 15, 31))))
    rem = end - E.eng.now
    if rem > 0:
        yield rem


def burst(E, n=4, qd=4, qids=(1, 2, 3, 4), rw=0.6, sizes=(7, 15, 31, 63, 255), f=None):
    """n concurrent healthy commands (QD-limited)."""
    active = [0]

    def wrap(g):
        try:
            yield from g
        finally:
            active[0] -= 1
    for i in range(n):
        while active[0] >= qd:
            yield 2 * US
        q = E.rng.choice([x for x in qids if x in E.nv.sq] or [1])
        nlb = E.rng.choice(sizes)
        g = E.read(q, nlb=nlb, f=f) if E.rng.random() < rw else E.write(q, nlb=nlb, f=f)
        active[0] += 1                      # counted at spawn time, not when it first runs
        E.sched.spawn(wrap(g), delay=E.rng.randint(0, 800) * NS)
        yield E.rng.randint(300, 2500) * NS
    while active[0]:
        yield 3 * US


def abort_cmd(E, sqid, cid, exec_lat=None, dw0=0, f=None, out=None):
    return E.admin(0x08, cdw10=(cid << 16) | sqid, dw0=dw0, f=dict(f or {}, exec_lat=exec_lat or 20 * US),
                   out=out, note="Abort SQID %d CID 0x%04X" % (sqid, cid))


def reset_controller(E, reason, rdy_polls=2, nq=4, init=True):
    """Host-initiated controller reset (CC.EN=0 -> CSTS.RDY=0) followed by re-initialisation."""
    E.log("host_controller_reset", reason=reason)
    yield from E.controller_disable(rdy_polls)
    if init:
        yield 5 * MS
        yield from E.controller_init(nq=nq, rdy_polls=2, note="re-init after " + reason)


def hot_reset_link(E, tc="1 0 0 0 0 0 00", reason="secondary bus reset"):
    """Secondary Bus Reset: TS1 with the Hot Reset bit from the root port, link drops."""
    e = E.eng
    first = None
    for _ in range(4):
        n = e.os(DN, "TS1", tc=tc)
        first = first or n
    for _ in range(2):
        e.os(UP, "TS1", tc=tc)
    e.event("Electrical Idle")
    e.event("Link Down", DN)
    e.event("Link Down", UP)
    E.nv.dev_open_tags.clear()
    E.log("link_hot_reset", reason=reason)
    yield 2 * MS
    return first


def full_recover(E, how="hot_reset", down_ps=None, enumerate_=True, init=True, train_kw=None,
                 reason="recovery", nq=4):
    """Bring a lost/failed link and controller back to the healthy baseline."""
    e = E.eng
    if how == "hot_reset":
        yield from hot_reset_link(E, reason=reason)
    elif how == "power":
        e.event("Link Down", DN)
        e.event("Link Down", UP)
        e.event("CLKREQ# Deasserted")
        E.nv.dev_open_tags.clear()
    yield down_ps if down_ps is not None else E.rng.randint(80, 200) * MS
    if how == "power":
        e.event("CLKREQ# Asserted")
        yield 100 * MS
    yield from E.train(**(train_kw or {}))
    E.nv.enabled = False
    E.nv.sq.clear()
    E.nv.cq.clear()
    if enumerate_:
        yield 1 * MS
        yield from E.enumerate(full=False)
    if init:
        yield 2 * MS
        yield from E.controller_init(nq=nq, rdy_polls=2, note="after " + reason)
    E.log("recovered", how=how, reason=reason)


def manual_cqe(E, qid, cid, sc=0, sct=0, dnr=0, dw0=0):
    cq = E.nv.cq[qid]
    slot = cq.tail
    ph = cq.phase
    cq.tail = (cq.tail + 1) % cq.size
    if cq.tail == 0:
        cq.phase ^= 1
    sqhd = E.nv.sq[qid].head if qid in E.nv.sq else 0
    return E.dev_mwr(cq.base + slot * 16, cqe(cid, qid, sqhd, ph, sc, sct, dnr, dw0=dw0))


def wait_with_bg(E, dur, qids=(2, 3, 4)):
    yield from bg(E, dur, qids)


def k(E, rec, field, note):
    if rec and rec.get(field) is not None:
        E.key(rec[field], note)


# ============================================================================ P01: status in a CQE
# card -> (queue, opcode, xfer, sct, sc, dnr, flavour)
P01_TABLE = {
    "S-01": ("io", 0x7F, None, 0, 0x01, 1, None), "S-02": ("io", 0x02, "d2h", 0, 0x02, 1, None),
    "S-03": ("io", 0x02, "d2h", 0, 0x03, 1, "cid_conflict"), "S-04": ("io", 0x01, "h2d", 0, 0x04, 0, "dte"),
    "S-05": ("io", 0x01, "h2d", 0, 0x05, 0, None), "S-06": ("io", 0x02, "d2h", 0, 0x06, 0, "retry_ok"),
    "S-07": ("io", 0x02, "d2h", 0, 0x07, 0, "abort"), "S-08": ("io", 0x02, "d2h", 0, 0x08, 0, "sqdel"),
    "S-09": ("io", 0x05, "h2d", 0, 0x09, 0, "fused"), "S-10": ("io", 0x02, "d2h", 0, 0x0B, 1, "nsid7"),
    "S-11": ("admin", 0x10, None, 0, 0x0C, 1, None), "S-12": ("io", 0x02, "d2h", 0, 0x13, 1, "prp_off"),
    "S-13": ("io", 0x02, "d2h", 0, 0x12, 1, None), "S-14": ("io", 0x01, "h2d", 0, 0x14, 1, None),
    "S-15": ("admin", 0x84, None, 0, 0x15, 1, None), "S-17": ("io", 0x01, "h2d", 0, 0x1B, 0, None),
    "S-18": ("admin", 0x84, None, 0, 0x1C, 1, None), "S-19": ("io", 0x02, "d2h", 0, 0x1D, 0, None),
    "S-20": ("io", 0x01, "h2d", 0, 0x20, 1, None), "S-21": ("io", 0x01, "h2d", 0, 0x21, 0, "retry_ok"),
    "S-23": ("admin", 0x02, None, 0, 0x24, 0, "retry_ok"), "S-24": ("io", 0x02, "d2h", 0, 0x2C, 1, None),
    "S-25": ("io", 0x02, "d2h", 0, 0x80, 1, None), "S-26": ("io", 0x01, "h2d", 0, 0x81, 1, None),
    "S-27": ("io", 0x02, "d2h", 0, 0x82, 0, "retry_ok"), "S-28": ("io", 0x01, "h2d", 0, 0x83, 1, None),
    "S-29": ("io", 0x02, "d2h", 0, 0x84, 0, None), "S-30": ("admin", 0x01, None, 1, 0x00, 1, None),
    "S-31": ("admin", 0x05, None, 1, 0x01, 1, None), "S-32": ("admin", 0x05, None, 1, 0x02, 1, None),
    "S-33": ("admin", 0x08, None, 1, 0x03, 1, "abort_limit"), "S-34": ("admin", 0x0C, None, 1, 0x05, 1, None),
    "S-35": ("admin", 0x10, None, 1, 0x06, 1, None), "S-36": ("admin", 0x10, None, 1, 0x07, 1, None),
    "S-37": ("admin", 0x05, None, 1, 0x08, 1, None), "S-38": ("admin", 0x02, None, 1, 0x09, 1, None),
    "S-39": ("admin", 0x80, None, 1, 0x0A, 1, None), "S-40": ("admin", 0x10, None, 1, 0x0B, 0, None),
    "S-41": ("admin", 0x10, None, 1, 0x12, 0, None), "S-42": ("admin", 0x04, None, 1, 0x0C, 1, None),
    "S-43": ("admin", 0x09, None, 1, 0x0D, 1, None), "S-44": ("admin", 0x15, None, 1, 0x18, 1, None),
    "S-45": ("admin", 0x14, None, 1, 0x1D, 1, None), "S-46": ("admin", 0x11, None, 1, 0x1E, 1, None),
    "S-47": ("admin", 0x1C, None, 1, 0x1F, 1, None), "S-48": ("admin", 0x84, None, 1, 0x23, 1, None),
    "S-49": ("io", 0x09, None, 1, 0x80, 1, None), "S-50": ("io", 0x01, "h2d", 1, 0x81, 1, None),
    "S-51": ("io", 0x01, "h2d", 1, 0x82, 1, None), "S-52": ("io", 0x19, None, 1, 0x83, 1, None),
    "S-54": ("io", 0x01, "h2d", 1, 0xB8, 1, None), "S-55": ("io", 0x7D, "h2d", 1, 0xB9, 1, None),
    "S-56": ("io", 0x01, "h2d", 1, 0xBC, 1, None), "S-57": ("io", 0x79, None, 1, 0xBD, 1, None),
    "S-58": ("io", 0x79, None, 1, 0xBF, 1, None), "S-59": ("io", 0x01, "h2d", 2, 0x80, 0, "retry_fail"),
    "S-60": ("io", 0x02, "d2h", 2, 0x81, 1, None), "S-61": ("io", 0x02, "d2h", 2, 0x82, 1, None),
    "S-62": ("io", 0x05, "h2d", 2, 0x85, 1, None), "S-63": ("io", 0x02, "d2h", 2, 0x86, 1, None),
    "S-64": ("io", 0x02, "d2h", 2, 0x87, 1, None), "S-65": ("io", 0x02, "d2h", 3, 0x00, 0, "retry_ok"),
    "S-66": ("io", 0x02, "d2h", 3, 0x02, 0, None), "S-67": ("io", 0x02, "d2h", 3, 0x60, 0, "retry_ok"),
    "S-70": ("io", 0x02, "d2h", 7, 0xC0, 0, None),
    "T-17": ("io", 0x02, "d2h", 0, 0x06, 0, "crd"), "T-18": ("io", 0x02, "d2h", 0, 0x82, 0, "retry_fail"),
    "T-24": ("io", 0x01, "h2d", 0, 0x06, 0, "retry_fail"), "N-30": ("io", 0x02, "d2h", 0, 0x23, 1, None),
    "N-31": ("io", 0x02, "d2h", 0, 0x80, 0, "retry_fail"),
}


def p01(E, c, q="io", opc=0x02, xfer=None, sct=0, sc=0, dnr=1, flavour=None):
    qid = 1 if q == "io" else 0
    st = (sct, sc, dnr)
    yield from burst(E, 3, qd=2)                          # healthy context before
    rec = {}
    if flavour == "abort":
        victim = {}
        f = {"status": st, "no_data": True, "cqe_delay": 420 * US, "media_lat": 400 * US}
        E.sched.spawn(E.read(1, f=f, out=victim))
        yield 60 * US
        ab = {}
        yield from abort_cmd(E, 1, victim.get("cid", 1), exec_lat=380 * US, out=ab)
        yield 50 * US
        rec = victim
        k(E, ab, "pkt_sqe", "Abort SQE fetched (admin SQ0)")
    elif flavour == "sqdel":
        outs = [{} for _ in range(3)]
        for o in outs:
            E.sched.spawn(E.read(4, f={"status": st, "no_data": True, "cqe_delay": 350 * US,
                                       "media_lat": 300 * US}, out=o))
            yield 2 * US
        yield 40 * US
        d = {}
        yield from E.admin(0x00, cdw10=4, f={"exec_lat": 400 * US}, out=d, note="Delete I/O SQ 4")
        k(E, d, "pkt_cqe", "Delete I/O SQ completes after the aborted CQEs")
        yield from E.admin(0x04, cdw10=4, note="Delete I/O CQ 4")
        base_c, base_s = E.nv.cq[4].base, E.nv.sq[4].base
        yield from E.admin(0x05, cdw10=(1023 << 16) | 4, cdw11=(4 << 16) | 3, f={"prp1": base_c}, note="re-create CQ4")
        E.nv.cq[4] = CQ(4, base_c, 1024, 4)
        yield from E.admin(0x01, cdw10=(1023 << 16) | 4, cdw11=(4 << 16) | 1, f={"prp1": base_s}, note="re-create SQ4")
        E.nv.sq[4] = SQ(4, base_s, 1024, 4)
        rec = outs[0]
    elif flavour == "fused":
        a, b = {}, {}
        yield from E.nvme_cmd(1, 0x05, 1, E.next_lba(7), 7, "h2d", f={"fuse": 1, "status": (2, 0x85, 1)}, out=a)
        yield from E.nvme_cmd(1, 0x01, 1, a.get("slba", 0), 7, "h2d", f={"fuse": 2, "status": st, "no_data": True}, out=b)
        k(E, a, "pkt_cqe", "Compare (FUSE=01b) CQE: Compare Failure")
        rec = b
    elif flavour == "abort_limit":
        outs = []
        for i in range(5):
            o = {}
            E.sched.spawn(E.read(2, f={"no_data": False, "media_lat": 2 * MS}, out=o))
            outs.append(o)
        yield 20 * US
        for i, o in enumerate(outs):
            r = {}
            fs = {"status": st} if i == 4 else {"exec_lat": 3 * MS}
            E.sched.spawn(abort_cmd(E, 2, o.get("cid", i), f=fs, dw0=1, out=r))
            yield 3 * US
            if i == 4:
                rec = r
        yield 4 * MS
    elif flavour in ("retry_ok", "retry_fail", "crd", "dte"):
        tries = {"retry_ok": 2, "retry_fail": 6, "crd": 3, "dte": 2}[flavour]
        slba = E.next_lba(7)
        for i in range(tries):
            ok = flavour in ("retry_ok", "crd", "dte") and i == tries - 1
            f = {} if ok else {"status": st + ((0, 1) if flavour == "crd" else ()), "no_data": flavour != "dte"}
            if flavour == "dte" and not ok:
                f = {"status": st, "cpl_status": "CA", "data_even_if_error": True}
            r = {}
            if xfer == "h2d":
                yield from E.write(qid, slba=slba, f=f, out=r)
            else:
                yield from E.read(qid if qid else 1, slba=slba, f=f, out=r) if qid else \
                    E.admin(opc, cdw10=0x7F0002, f=f, out=r)
            if not rec:
                rec = r
            if not ok:
                E.key(r.get("pkt_cqe"), "retry %d CQE status %s" % (i, r.get("status")))
            if i < tries - 1:
                yield (100 * MS if flavour == "crd" else E.rng.randint(5, 40) * US)
        if flavour == "dte":
            k(E, rec, "pkt_bad_cpl", "root complex Cpl CA to the write-data MRd")
    else:
        f = {"status": st}
        if flavour == "prp_off":
            f["prp1_off"] = 0x202
        if flavour == "cid_conflict":
            v = {}
            E.sched.spawn(E.read(1, f={"media_lat": 500 * US}, out=v))
            yield 30 * US
            f["cid"] = v.get("cid", 1)
            f["no_data"] = True
            yield from E.read(1, f=f, out=rec)
            yield 600 * US
        elif qid == 0:
            cdw10 = {0x10: 0x0000000A, 0x84: 0x2, 0x05: (0x3FF << 16) | 9, 0x01: (0x3FF << 16) | 9,
                     0x02: 0x00FF007E, 0x80: 0x9, 0x04: 1, 0x09: 0x80000006, 0x15: 0, 0x14: 1,
                     0x11: 0x3FF, 0x1C: 0x101, 0x0C: 0, 0x08: 0}.get(opc, 0)
            yield from E.admin(opc, cdw10=cdw10, f=f, out=rec, note=c["id"])
        else:
            nsid = 7 if flavour == "nsid7" else 1
            if xfer:
                yield from E.nvme_cmd(qid, opc, nsid, E.next_lba(7), 7, xfer, f=f, out=rec)
            else:
                yield from E.nvme_cmd(qid, opc, nsid, E.next_lba(7), 7, None, f=f, out=rec)
    k(E, rec, "pkt_sqe", "SQE fetched (CplD carries the 64-byte SQE)")
    k(E, rec, "pkt_cqe", "CQE MWr with non-zero status %s" % (rec.get("status") or "SCT%d/SC0x%02X" % (sct, sc)))
    E.log("p01_status", card=c["id"], sct=sct, sc="0x%02X" % sc, dnr=dnr, flavour=flavour,
          observable_in_summary_export="CQE status bits are inside DATA; summary export shows only the "
                                       "shape (SQE fetch -> CQE with no data TLPs)")
    yield from burst(E, 2, qd=2)


def host_generated_status(E, c, sct, sc):
    """Status codes the HOST fabricates (never on the wire): wire shows only the cause."""
    if c["id"] == "S-69":
        yield from p02(E, c, variant="abort_ok")
    else:
        yield from burst(E, 6, qd=3)
    E.log("host_generated_status", card=c["id"], status="SCT%d/SC0x%02X" % (sct, sc),
          note="Linux synthesises this status in nvme_*; no CQE with it exists on the link")


# ============================================================================ P02: never completed
def p02(E, c, variant="abort_ok"):
    yield from burst(E, 3, qd=2)
    v = {}
    if variant in ("abort_ok", "abort_hang", "fetch_nodata", "late_cqe"):
        f = {"no_cqe": True}
        if variant == "fetch_nodata":
            f = {"fetched_then_hang": True}
        g = E.write(3, nlb=7, f=f, out=v)
        E.sched.spawn(g)
        yield 50 * US
        k(E, v, "pkt_sqe", "SQE fetched; no CQE will follow")
        if variant == "late_cqe":
            yield from bg(E, IO_TIMEOUT - 2 * MS)
            ab = {}
            yield from abort_cmd(E, 3, v["cid"], exec_lat=200 * US, dw0=1, out=ab)
            n = manual_cqe(E, 3, v["cid"])
            E.key(n, "CQE arrives after the 30 s host deadline (abort already sent)")
            E.msi(3)
            yield 3 * US
            E.ring_cq(3)
            return
        yield from bg(E, IO_TIMEOUT)
        ab = {}
        if variant in ("abort_ok", "fetch_nodata"):
            E.sched.spawn(abort_cmd(E, 3, v.get("cid", 1), exec_lat=150 * US, out=ab))
            yield 120 * US
            n = manual_cqe(E, 3, v.get("cid", 1), sc=0x07)
            E.key(n, "victim CQE status 0x007 Command Abort Requested")
            E.msi(3)
            yield 100 * US
            E.ring_cq(3)
            k(E, ab, "pkt_sqe", "Abort SQE (opcode 08h) on admin SQ0 after 30 s timeout")
            yield 1 * MS
        else:   # abort itself never completes -> second timeout -> controller reset
            yield from E.admin(0x08, cdw10=(v.get("cid", 1) << 16) | 3, f={"no_cqe": True}, out=ab)
            k(E, ab, "pkt_sqe", "Abort fetched but never completed")
            yield from bg(E, IO_TIMEOUT)
            yield from reset_controller(E, "I/O timeout after failed abort")
    elif variant == "admin_reset":
        yield from E.admin(0x02, cdw10=(127 << 16) | 0x02, xfer=None, f={"no_cqe": True}, out=v)
        k(E, v, "pkt_sqe", "admin SQE fetched, never completed")
        yield from bg(E, ADMIN_TIMEOUT)
        yield from reset_controller(E, "admin command timeout")
    elif variant == "timeout_in_reset":
        yield from E.controller_disable(2)
        yield 5 * MS
        cap = 0
        yield from E.mmio_rd(E.nv.bar0, 2, 0x14010000003FF)
        E.mmio_wr(E.nv.bar0 + 0x24, 0x001F001F)
        E.nv.sq[0] = SQ(0, E.qalloc(32 * 64), 32, 0)
        E.nv.cq[0] = CQ(0, E.qalloc(32 * 16), 32, 0)
        for off, q in ((0x28, E.nv.sq[0]), (0x30, E.nv.cq[0])):
            E.mmio_wr(E.nv.bar0 + off, 0, length=2, lbe=0xF, payload=q.base.to_bytes(8, "little"))
            yield 400 * NS
        E.mmio_wr(E.nv.bar0 + 0x14, 0x00460001)
        yield 2 * MS
        yield from E.mmio_rd(E.nv.bar0 + 0x1C, 1, 1)
        yield from E.admin(0x06, cdw10=1, xfer=None, f={"no_cqe": True}, out=v)
        k(E, v, "pkt_sqe", "Identify during reset/connect never completes")
        yield ADMIN_TIMEOUT
        yield from reset_controller(E, "timeout while resetting")
    elif variant == "polled":
        g = E.read(2, f={"no_msix": True, "no_cq_doorbell": True}, out=v)
        yield from g
        k(E, v, "pkt_cqe", "CQE posted, no MSI-X follows")
        yield from bg(E, IO_TIMEOUT, qids=(1, 3, 4))
        n = E.ring_cq(2)
        E.key(n, "CQ head doorbell only after the 30 s timeout handler polled the CQ")
    elif variant == "fetch_gap":
        yield from E.read(1, f={"fetch_lat": 4 * MS}, out=v)
        k(E, v, "pkt_doorbell", "SQ tail doorbell")
        k(E, v, "pkt_fetch", "SQE fetch 4 ms after the doorbell")
    elif variant == "late_cqe_noto":
        yield from E.read(1, nlb=63, f={"cqe_delay": 25 * MS}, out=v)
        k(E, v, "pkt_cqe", "CQE 25 ms after the last data TLP")
    elif variant == "late_data":
        yield from E.read(1, f={"media_lat": 12 * MS}, out=v)
        k(E, v, "pkt_sqe", "SQE fetched promptly")
        k(E, v, "pkt_cqe", "CQE after a 12 ms data-phase delay")
    elif variant == "abort_race":
        E.sched.spawn(E.read(1, f={"media_lat": 120 * US}, out=v))
        yield 100 * US
        ab = {}
        yield from abort_cmd(E, 1, v.get("cid", 1), exec_lat=40 * US, dw0=1, out=ab)
        k(E, ab, "pkt_cqe", "Abort CQE DW0 bit0=1: command not aborted (it completed first)")
        k(E, v, "pkt_cqe", "original CQE races the Abort")
    elif variant == "qd_saturation":
        yield from burst(E, 192, qd=128, qids=(1,), rw=1.0, sizes=(7,),
                         f={"media_lat": 900 * US})
    elif variant in ("admin_starve", "long_admin_timeout", "long_admin_ok", "format_timeout"):
        dur = {"admin_starve": 8 * SEC, "long_admin_timeout": 70 * SEC, "long_admin_ok": 90 * SEC,
               "format_timeout": 75 * SEC}[variant]
        opc = 0x84 if variant == "long_admin_ok" else 0x80
        lr = {}
        if variant in ("long_admin_timeout", "format_timeout"):
            E.sched.spawn(E.admin(opc, cdw10=0, f={"no_cqe": True}, out=lr, nsid=1))
            yield 50 * US
            k(E, lr, "pkt_sqe", "long admin operation fetched")
            yield from bg(E, ADMIN_TIMEOUT, qids=(2,))
            yield from reset_controller(E, "admin timeout during Format NVM")
            return
        E.sched.spawn(E.admin(opc, cdw10=2, f={"exec_lat": dur}, out=lr, nsid=1))
        yield 30 * US
        if variant == "admin_starve":
            g2 = {}
            E.sched.spawn(E.admin(0x02, cdw10=(127 << 16) | 2, xfer="d2h", nbytes=512, out=g2,
                                  f={"exec_lat": dur}))
        for _ in range(int(dur // SEC) // (10 if dur > 20 * SEC else 1)):
            yield (10 if dur > 20 * SEC else 1) * SEC
            if variant == "long_admin_ok":
                yield from E.admin(0x02, cdw10=(127 << 16) | 0x81, xfer="d2h", nbytes=512)
        yield 2 * SEC
        k(E, lr, "pkt_cqe", "long admin operation completes")
    E.log("p02", card=c["id"], variant=variant)
    yield from burst(E, 2, qd=2)


# ============================================================================ P13: register timing
def p13(E, c, variant):
    nv = E.nv
    e = E.eng
    if variant in ("rdy_never", "crto"):
        yield from E.controller_disable(2)
        yield 2 * MS
        n0 = e.pkt
        yield from E.controller_init(rdy_polls=100 if variant == "rdy_never" else 3, rdy_never=True)
        E.key(n0, "CC.EN=1 then CSTS.RDY polled every ~100 ms and stays 0")
        if variant == "crto":
            yield from E.mmio_rd(nv.bar0 + 0x68, 1, 0x00320032)
        n = E.mmio_wr(nv.bar0 + 0x14, 0x00460000)
        E.key(n, "host gives up: CC.EN=0")
        yield 500 * MS
        yield from E.controller_init(rdy_polls=4, note="retry after ready timeout")
    elif variant == "rdy_stuck_1":
        n = E.mmio_wr(nv.bar0 + 0x14, 0x00460000)
        E.key(n, "CC.EN=0 written")
        for i in range(12):
            yield 1 * SEC
            m, _ = yield from E.mmio_rd(nv.bar0 + 0x1C, 1, 1)
            if i == 11:
                E.key(m, "CSTS.RDY still 1 > CAP.TO after CC.EN=0")
        nv.sq.clear()
        nv.cq.clear()
        n, _ = yield from E.cfg_wr(0x078, 0x00108830)
        E.key(n, "host escalates: Function Level Reset (Device Control bit 15)")
        yield 100 * MS
        for _ in range(3):
            yield from E.cfg_rd(0x000, 0, status="CRS")
            yield 20 * MS
        yield from E.cfg_rd(0x000, 0x00101B36)
        yield from E.cfg_wr(0x004, 0x00100406)
        yield from E.controller_init(note="after FLR")
    elif variant == "shutdown_stuck":
        n = E.mmio_wr(nv.bar0 + 0x14, nv.cc | (1 << 14))
        E.key(n, "CC.SHN=01b (normal shutdown)")
        for _ in range(8):
            yield 1 * SEC
            m, _ = yield from E.mmio_rd(nv.bar0 + 0x1C, 1, 0x5)
        E.key(m, "CSTS.SHST still 01b (in progress) when power is removed")
        e.event("Electrical Idle")
        yield from full_recover(E, how="power", down_ps=3 * SEC, reason="power cycle after incomplete shutdown")
    elif variant in ("fw_pp", "fw_pp_never"):
        yield from fw_download(E, 2)
        r = {}
        yield from E.admin(0x10, cdw10=(3 << 3) | 2, f={"exec_lat": 30 * MS}, out=r, note="Firmware Commit CA=3")
        k(E, r, "pkt_cqe", "Firmware Commit CA=3 completes; activation begins")
        polls = 15 if variant == "fw_pp" else 25
        for i in range(polls):
            yield 500 * MS
            m, _ = yield from E.mmio_rd(nv.bar0 + 0x1C, 1, 0x21 if i < polls - 2 or variant == "fw_pp_never" else 0x1)
        E.key(m, "CSTS.PP=1 for longer than MTFA (2 s advertised)")
        if variant == "fw_pp_never":
            yield from reset_controller(E, "firmware activation never finished")
    elif variant == "early_csts":
        yield from E.controller_disable(2)
        yield 2 * MS
        E.mmio_wr(nv.bar0 + 0x14, 0x00460001)
        yield 20 * US
        m, _ = yield from E.mmio_rd(nv.bar0 + 0x1C, 1, 0xFFFFFFFF)
        E.key(m, "CSTS read immediately after CC.EN=1 returns 0xFFFFFFFF (device not ready to be read)")
        yield 2 * SEC
        yield from reset_controller(E, "quirk delay before checking RDY")
    elif variant in ("cfs", "cfs_loop", "cfs_missed"):
        yield from burst(E, 3)
        loops = 3 if variant == "cfs_loop" else 1
        for i in range(loops):
            if variant == "cfs_missed":
                yield from burst(E, 2)
                yield 30 * MS
                m, _ = yield from E.mmio_rd(nv.bar0 + 0x1C, 1, 0x1)
                E.key(m, "CSTS poll shows RDY=1, CFS=0: the 2 ms CFS pulse fell between polls")
                break
            m, _ = yield from E.mmio_rd(nv.bar0 + 0x1C, 1, 0x3)
            E.key(m, "CSTS = 0x3: RDY=1 CFS=1 (Controller Fatal Status)")
            yield from reset_controller(E, "CSTS.CFS")
    elif variant == "nssro":
        yield from E.controller_disable(2)
        yield 2 * MS
        m, _ = yield from E.mmio_rd(nv.bar0 + 0x1C, 1, 0x10)
        E.key(m, "CSTS.NSSRO=1 at init: an NVM Subsystem Reset occurred")
        E.mmio_wr(nv.bar0 + 0x1C, 0x10)
        yield from E.controller_init()
    elif variant == "dead":
        yield from E.controller_disable(2)
        yield 2 * MS
        yield from E.controller_init(rdy_polls=100, rdy_never=True)
        E.key(e.pkt - 1, "re-init: RDY never 1 -> driver marks controller DEAD")
        E.mmio_wr(nv.bar0 + 0x14, 0x00460000)
        yield 5 * SEC
        E.log("namespace_io_failed_fast", note="block layer fails I/O without touching the device")
        yield from E.controller_init(note="manual rescan / rebind")
    elif variant == "no_ioq":
        yield from E.controller_disable(2)
        yield 2 * MS
        yield from E.controller_init(create_io=False, identify=False)
        r = {}
        yield from E.admin(0x06, cdw10=1, xfer="d2h", nbytes=4096)
        yield from E.admin(0x09, cdw10=0x07, cdw11=0x00030003, dw0=0, out=r)
        k(E, r, "pkt_cqe", "Set Features Number of Queues returns 0 queues allocated")
        yield 3 * SEC
        yield from reset_controller(E, "controller came back without I/O queues")
    elif variant == "flr_unusable":
        n, _ = yield from E.cfg_wr(0x078, 0x00108830)
        E.key(n, "Function Level Reset")
        nv.sq.clear()
        nv.cq.clear()
        yield 100 * MS
        yield from E.cfg_rd(0x000, 0x00101B36)
        yield from E.cfg_rd(0x010, 0x00000004)
        yield from E.cfg_wr(0x010, nv.bar0 | 4)
        yield from E.cfg_wr(0x004, 0x00100406)
        m, c_ = yield from E.mmio_rd(nv.bar0 + 0x00, 2, 0, status="UR")
        E.key(c_, "MMIO read of CAP after FLR answered with UR: function unusable")
        yield 1 * SEC
        yield from full_recover(E, reason="slot reset after unusable FLR")
    elif variant == "admin_stall_after_rdy":
        yield from E.controller_disable(2)
        yield from E.controller_init(identify=False, create_io=False, aer=0)
        r = {}
        yield from E.admin(0x06, cdw10=1, xfer="d2h", f={"no_cqe": True}, out=r)
        k(E, r, "pkt_sqe", "first Identify after RDY=1 fetched, never completed")
        yield ADMIN_TIMEOUT
        yield from reset_controller(E, "admin timeout right after ready")
    elif variant == "partial_queues":
        yield from E.controller_disable(2)
        yield from E.controller_init(nq=2, note="only 2 of 4 I/O queues re-created")
        n = E.mmio_wr(nv.db(3), 1)
        E.key(n, "doorbell for SQ3 which was not re-created after reset")
        yield 2 * SEC
        yield from reset_controller(E, "queue recreation incomplete")
    elif variant == "first_io_slow":
        yield from E.controller_disable(2)
        yield from E.controller_init()
        r = {}
        yield from E.read(1, f={"media_lat": 350 * MS}, out=r)
        k(E, r, "pkt_cqe", "first I/O after init completes 350 ms after submission")
    elif variant == "dll_up_no_resume":
        yield from hot_reset_link(E, reason="error recovery")
        yield 100 * MS
        yield from E.train()
        yield from E.enumerate(full=False)
        nv.enabled = False
        for q in (1, 2):
            n = E.mmio_wr(nv.db(q), 5)
            E.key(n, "doorbell after link recovery, controller still disabled: no SQE fetch")
            yield 1 * MS
        yield IO_TIMEOUT
        nv.sq.clear()
        nv.cq.clear()
        yield from E.controller_init(note="host finally re-initialises")
    elif variant == "spontaneous_reset":
        yield from burst(E, 3)
        v = {}
        E.sched.spawn(E.read(1, f={"no_cqe": True}, out=v))
        yield 200 * US
        m, _ = yield from E.mmio_rd(nv.bar0 + 0x1C, 1, 0x0)
        E.key(m, "CSTS.RDY=0 although the host never cleared CC.EN (controller self-reset, link stayed up)")
        nv.sq.clear()
        nv.cq.clear()
        yield 10 * MS
        yield from E.controller_init(note="after spontaneous reset")
    elif variant == "crto_inconsistent":
        yield from E.mmio_rd(nv.bar0, 2, 0x3FF | (1 << 16) | (40 << 24))
        m, _ = yield from E.mmio_rd(nv.bar0 + 0x68, 1, 0x000A000A)
        E.key(m, "CRTO = 0x000A000A (5 s) while CAP.TO = 40 (20 s): inconsistent")
    E.log("p13", card=c["id"], variant=variant)


def fw_download(E, chunks=4):
    for i in range(chunks):
        yield from E.admin(0x11, cdw10=1023, cdw11=i * 1024, xfer="h2d", nbytes=4096,
                           note="Firmware Image Download")


# ============================================================================ P14: doorbells
def p14(E, c, variant):
    nv = E.nv
    yield from burst(E, 2)
    if variant == "sq_beyond":
        n = E.mmio_wr(nv.db(1), nv.sq[1].size)
        E.key(n, "SQ1 tail doorbell = 1024 on a 1024-entry queue")
        yield 30 * US
        aen = yield from E.post_aen(0x00010100, then_log=0x01, log_bytes=64)
        E.key(aen, "AEN: Error, Invalid Doorbell Write Value (01h), LID 01h")
        yield from reset_controller(E, "invalid doorbell")
    elif variant == "cq_beyond":
        n = E.mmio_wr(nv.db(2, cq=True), nv.cq[2].size + 5)
        E.key(n, "CQ2 head doorbell beyond queue size")
        yield 30 * US
        aen = yield from E.post_aen(0x00010100, then_log=0x01, log_bytes=64)
        E.key(aen, "AEN Invalid Doorbell Write Value")
        yield from reset_controller(E, "invalid CQ doorbell")
    elif variant == "no_queue":
        n = E.mmio_wr(nv.db(7), 3)
        E.key(n, "SQ7 tail doorbell: queue 7 was never created")
        yield 30 * US
        aen = yield from E.post_aen(0x00000100, then_log=0x01, log_bytes=64)
        E.key(aen, "AEN: Invalid Doorbell Register (00h)")
    elif variant == "partial":
        sq = nv.sq[1]
        r = {}
        yield from E.read(1, f={"db_fbe": 0x3}, out=r)
        k(E, r, "pkt_doorbell", "doorbell MWr with 1st BE 0011b (16-bit write)")
    elif variant == "backwards":
        sq = nv.sq[1]
        n = E.mmio_wr(nv.db(1), (sq.tail - 2) % sq.size)
        E.key(n, "SQ1 tail moves backwards without wrap")
        yield 50 * US
    elif variant == "cq_past":
        n = E.mmio_wr(nv.db(1, cq=True), (nv.cq[1].tail + 6) % nv.cq[1].size)
        E.key(n, "CQ1 head released past the controller's last posted slot")
        yield 50 * US
    elif variant == "cq_overflow":
        outs = []
        for i in range(6):
            o = {}
            E.sched.spawn(E.read(4, f={"no_cq_doorbell": True}, out=o))
            outs.append(o)
            yield 3 * US
        yield 2 * MS
        E.log("cq_head_not_advanced", qid=4)
        n = E.ring_cq(4)
        E.key(n, "CQ4 head doorbell only after 6 completions accumulated (consumer stalled)")
    elif variant == "shadow":
        r = {}
        yield from E.admin(0x7C, cdw10=0, note="Doorbell Buffer Config")
        sq = nv.sq[1]
        sq.tail = (sq.tail + 1) % sq.size
        E.log("shadow_doorbell_updated_without_mmio", qid=1)
        yield 3 * MS
        t = nv.next_dev_tag()
        n = E.dev_mrd(E.alloc(1)[0], 1, t)
        E.key(n, "controller polls the shadow doorbell buffer (stale value)")
        yield 700 * NS
        yield from E.host_cpld(t, 0, bytes(4))
        yield 5 * MS
        sq.tail = (sq.tail - 1) % sq.size
        yield from E.read(1)
    elif variant == "head_lag":
        yield from E.read(1, f={"db_lat": 2 * MS})
        E.key(E.eng.pkt - 1, "CQ head doorbell 2 ms after the CQE (consumer lag)")
    elif variant == "occupancy":
        yield from burst(E, 64, qd=64, qids=(4,), f={"db_lat": 3 * MS})
    elif variant == "batching":
        sq = nv.sq[2]
        start = sq.tail
        outs = []
        for i in range(32):
            o = {}
            outs.append(o)
        sq.tail = (sq.tail + 32) % sq.size
        n = E.mmio_wr(nv.db(2), sq.tail)
        E.key(n, "one SQ2 doorbell publishes 32 commands")
        sq.tail = start
        for i in range(32):
            E.sched.spawn(_fetch_only_read(E, 2))
            yield 300 * NS
        yield 2 * MS
    elif variant == "late_doorbell":
        yield 1500 * US
        yield from E.read(1)
        E.log("doorbell_issued_by_software_earlier", delay_us=1500)
    elif variant == "stride":
        n = E.mmio_wr(nv.bar0 + 0x1000 + 2 * 8 + 2, 4, fbe=0xC)
        E.key(n, "doorbell written at BAR0+0x1012: not on the CAP.DSTRD grid")
        yield 1 * MS
    E.log("p14", card=c["id"], variant=variant)
    yield from burst(E, 2)


def _fetch_only_read(E, qid):
    """Device side of a read whose doorbell was already batched by the host."""
    yield from E.nvme_cmd(qid, 0x02, 1, E.next_lba(7), 7, "d2h", f={"skip_doorbell": True})


# ============================================================================ P15: CQE content
def p15(E, c, variant):
    yield from burst(E, 2)
    r = {}
    if variant == "wrong_cid":
        yield from E.read(1, f={"cqe_cid": 0x7FFE}, out=r)
        k(E, r, "pkt_cqe", "CQE names CID 0x7FFE; the real command stays open")
    elif variant == "dup":
        yield from E.read(1, f={"dup_cqe": (40 * MS, (0, 0x07, 0))}, out=r)
        k(E, r, "pkt_dup_cqe", "second CQE for the same CID with a different PSN")
    elif variant == "stale":
        yield from E.read(1, f={"cqe_cid": 0x0003}, out=r)
        k(E, r, "pkt_cqe", "CQE for CID 0x0003 that completed long ago")
    elif variant == "cid_reuse":
        v = {}
        E.sched.spawn(E.read(1, f={"media_lat": 300 * US}, out=v))
        yield 20 * US
        yield from E.read(1, f={"cid": v.get("cid", 1)}, out=r)
        k(E, r, "pkt_sqe", "host submits a second SQE with an outstanding CID")
        yield 300 * US
    elif variant == "wrong_sqid":
        yield from E.read(1, f={"cqe_sqid": 2}, out=r)
        k(E, r, "pkt_cqe", "CQE on CQ1 names SQID 2")
    elif variant == "phase":
        nv = E.nv
        bc, bs = E.qalloc(64), E.qalloc(256)
        yield from E.admin(0x05, cdw10=(3 << 16) | 5, cdw11=(5 << 16) | 3, f={"prp1": bc},
                           note="Create I/O CQ 5 (4 entries)")
        nv.cq[5] = CQ(5, bc, 4, 4)
        yield from E.admin(0x01, cdw10=(3 << 16) | 5, cdw11=(5 << 16) | 1, f={"prp1": bs}, note="Create I/O SQ 5")
        nv.sq[5] = SQ(5, bs, 4, 5)
        for i in range(5):
            f = {"phase_flip": True} if i == 4 else {}
            yield from E.read(5, f=f, out=r)
        k(E, r, "pkt_cqe", "CQ5 wrapped to slot 0 but the phase tag was not inverted")
        yield 2 * MS
        yield from E.admin(0x00, cdw10=5)
        yield from E.admin(0x04, cdw10=5)
        del nv.sq[5]
        del nv.cq[5]
    elif variant == "reset_reuse":
        yield from reset_controller(E, "reset; queues re-created at new addresses, CIDs restart")
        yield from E.read(1, out=r)
    elif variant == "parser_wrap":
        nv = E.nv
        bc, bs = E.qalloc(64), E.qalloc(256)
        yield from E.admin(0x05, cdw10=(3 << 16) | 5, cdw11=(5 << 16) | 3, f={"prp1": bc})
        nv.cq[5] = CQ(5, bc, 4, 4)
        yield from E.admin(0x01, cdw10=(3 << 16) | 5, cdw11=(5 << 16) | 1, f={"prp1": bs})
        nv.sq[5] = SQ(5, bs, 4, 5)
        for i in range(6):
            yield from E.read(5, out=r)
        yield from E.admin(0x00, cdw10=5)
        yield from E.admin(0x04, cdw10=5)
        del nv.sq[5]
        del nv.cq[5]
    E.log("p15", card=c["id"], variant=variant)
    yield from burst(E, 2)


# ============================================================================ P16: ordering / interrupts
def p16(E, c, variant):
    yield from burst(E, 2)
    r = {}
    if variant == "cqe_before_data":
        yield from E.read(1, nlb=63, f={"data_after_cqe": 2}, out=r)
        k(E, r, "pkt_cqe", "CQE posted before the last data writes")
        k(E, r, "pkt_late_data", "data MWr after the CQE")
    elif variant == "msix_first":
        yield from E.read(1, f={"msix_first": True}, out=r)
        k(E, r, "pkt_msix", "MSI-X write before its CQE")
    elif variant in ("no_msix", "polled"):
        yield from E.read(2, f={"no_msix": True, "no_cq_doorbell": True}, out=r)
        k(E, r, "pkt_cqe", "CQE with no MSI-X")
        yield from bg(E, IO_TIMEOUT, qids=(1, 3, 4))
        n = E.ring_cq(2)
        E.key(n, "CQ head doorbell after the timeout handler polled (completion polled)")
    elif variant == "misrouted":
        nv = E.nv
        old = nv.msix_addr[1]
        nv.msix_addr[1] = 0xFEE0F000
        yield from E.read(1, f={"no_cq_doorbell": True}, out=r)
        nv.msix_addr[1] = old
        k(E, r, "pkt_msix", "MSI-X written to 0xFEE0F000, not the programmed vector address")
        yield from bg(E, IO_TIMEOUT, qids=(2, 3))
        E.ring_cq(1)
    elif variant == "msi_never":
        yield from E.cfg_wr(0x0B0, 0x00200011)
        n, _ = yield from E.cfg_wr(0x050, 0x0081B011)
        E.key(n, "MSI enabled (MSI-X disabled)")
        yield from E.read(1, f={"no_msix": True, "no_cq_doorbell": True}, out=r)
        k(E, r, "pkt_cqe", "CQE; no MSI write follows")
        yield from bg(E, IO_TIMEOUT, qids=(2, 3))
        E.ring_cq(1)
        yield from E.cfg_wr(0x050, 0x0080B011)
        yield from E.cfg_wr(0x0B0, 0x80200011)
    elif variant == "dma_after_cqe":
        yield from E.read(1, f={"post_cqe_dma": True}, out=r)
        k(E, r, "pkt_post_dma", "DMA into the command's buffer after its CQE")
    elif variant == "storm":
        for i in range(300):
            E.msi(1 + i % 4)
            yield 200 * NS
        E.key(E.eng.pkt - 1, "MSI-X every ~200 ns (coalescing disabled under small-block load)")
    elif variant == "sw_late":
        yield from E.read(1, f={"db_lat": 2 * MS}, out=r)
        E.log("cqe_seen_late_by_software", latency_ms=2)
    elif variant == "moderation":
        outs = []
        for i in range(8):
            o = {}
            E.sched.spawn(E.read(1, f={"no_msix": True, "db_lat": 120 * US}, out=o))
            yield 2 * US
        yield 100 * US
        n = E.msi(1)
        E.key(n, "single coalesced MSI-X ~100 us after the first CQE (Feature 08h)")
        yield 50 * US
    elif variant == "masked":
        nv = E.nv
        n = E.mmio_wr(nv.bar0 + 0x2000 + 16 * 1 + 12, 1)
        E.key(n, "host masks MSI-X vector 1 (Vector Control bit 0)")
        yield from E.read(1, f={"no_msix": True, "no_cq_doorbell": True}, out=r)
        yield 5 * MS
        E.mmio_wr(nv.bar0 + 0x2000 + 16 * 1 + 12, 0)
        yield 300 * NS
        n = E.msi(1)
        E.key(n, "pending MSI-X sent only after unmask")
        yield 3 * US
        E.ring_cq(1)
    elif variant == "poll_transition":
        yield from E.read(1, f={"db_lat": 900 * US})
    elif variant == "ordering_visibility":
        yield from E.read(1, nlb=15, f={"data_attr": "RO"}, out=r)
        k(E, r, "pkt_cqe", "data written with Relaxed Ordering; CQE may pass it")
    elif variant == "intx":
        yield from E.cfg_wr(0x004, 0x00100006)
        yield from E.cfg_wr(0x0B0, 0x00200011)
        n = E.msg(UP, "Assert_INTA", "Local")
        E.key(n, "Assert_INTA without a matching Deassert_INTA")
        yield from E.read(1, f={"no_msix": True})
        yield 2 * MS
        yield from E.cfg_wr(0x0B0, 0x80200011)
        yield from E.cfg_wr(0x004, 0x00100406)
    E.log("p16", card=c["id"], variant=variant)
    yield from burst(E, 2)


# ============================================================================ P17: DMA addressing
def p17(E, c, variant):
    yield from burst(E, 2)
    r = {}
    if variant == "outside":
        yield from E.read(1, nlb=119, f={"extra_mwr": (0x31200F000, 256)}, out=r)
        k(E, r, "pkt_stray", "MWr outside every PRP of the command")
    elif variant == "dsm_overread":
        r = yield from E.dsm(1, ranges=((E.next_lba(7), 8),) * 4, f={"range_dw": 1024})
        k(E, r, "pkt_range_read", "DSM NR=3 (64 B) but the device reads 4 KiB of range list")
    elif variant == "addr48":
        yield from E.read(1, f={"extra_mwr": (0x0000000012340000, 256)}, out=r)
        k(E, r, "pkt_stray", "PRP 0x1_0000_1234_0000 (> 2^48) truncated: MWr lands at 0x12340000")
    elif variant == "wrong_target":
        yield from E.read(1, f={"extra_mwr": (E.alloc(1)[0], 64)}, out=r)
        k(E, r, "pkt_stray", "DMA target matches no active queue or buffer")
    elif variant == "iommu_delay":
        yield from E.write(1, nlb=63, f={"mrd_len": 512}, out=r)
        E.log("iotlb_miss_latency", note="CplD latency inflated by IOMMU page walks (sidecar: DMAR stats)")
    elif variant == "vf":
        yield from E.read(1, f={"data_rid": "002:00:4", "cqe_rid": "002:00:4"}, out=r)
        k(E, r, "pkt_cqe", "VF 002:00:4 traffic")
    elif variant == "gpa":
        yield from burst(E, 4)
        E.log("guest_physical_addresses", note="addresses are IOVAs/GPAs; host-physical mapping not visible")
    elif variant == "bounce":
        old = E.alloc
        E.alloc = lambda n, low=None: [0x7C000000 + E.rng.randrange(0, 0x400) * 4096 for _ in range(n)]
        yield from burst(E, 6, qd=3)
        E.alloc = old
        E.log("swiotlb_window", note="every DMA address inside a 4 MiB bounce window")
    elif variant == "vf_rid":
        yield from E.read(1, f={"cqe_rid": "002:00:0"}, out=r)
        k(E, r, "pkt_cqe", "CQE for a VF-owned queue written with the PF Requester ID")
    E.log("p17", card=c["id"], variant=variant)
    yield from burst(E, 2)


# ============================================================================ P18: SQE content rules
def p18(E, c, variant):
    yield from burst(E, 2)
    r = {}
    if variant == "prp1_align":
        yield from E.read(1, f={"prp1_off": 0x202, "status": (0, 0x13, 1)}, out=r)
    elif variant == "prp2_off":
        yield from E.read(1, nlb=15, f={"prp2_off": 0x200}, out=r)
    elif variant == "prp_list":
        yield from E.read(1, nlb=31, f={"list_overread": 30}, out=r)
    elif variant == "mdts":
        yield from E.read(1, nlb=2047, f={"status": (0, 0x02, 1)}, out=r)
    elif variant == "reserved":
        yield from E.read(1, f={"cdw2": 0xDEADBEEF}, out=r)
    elif variant == "fuse":
        yield from E.nvme_cmd(1, 0x05, 1, E.next_lba(7), 7, "h2d", f={"fuse": 1, "status": (0, 0x0A, 1),
                                                                      "no_data": True}, out=r)
    elif variant == "admin_on_io":
        yield from E.nvme_cmd(1, 0x06, 1, 0, 0, None, cdw10=1, f={"status": (0, 0x01, 1)}, out=r)
    elif variant == "sgl":
        yield from E.nvme_cmd(1, 0x02, 1, E.next_lba(7), 7, "d2h", f={"status": (0, 0x11, 1)}, out=r)
    elif variant == "create_params":
        yield from E.admin(0x01, cdw10=(0xFFFF << 16) | 6, cdw11=(6 << 16) | 1, f={"status": (1, 0x02, 1)}, out=r)
    elif variant == "aen_rae":
        aen = yield from E.post_aen(0x00020101, then_log=0x02, rae=1)
        E.key(aen, "SMART AEN; host reads LID 02h with RAE=1 (event stays masked)")
        yield 2 * SEC
        E.log("second_temperature_crossing_no_aen")
    elif variant == "arbitration":
        yield from burst(E, 48, qd=32, qids=(2,), rw=1.0, sizes=(7,))
        E.log("sq1_pending_while_sq2_served", pending=12)
    elif variant == "metadata":
        yield from E.write(1, f={"mptr": 0}, out=r)
    elif variant == "log_short":
        yield from E.admin(0x02, cdw10=(1023 << 16) | 0x02, xfer="d2h", nbytes=512, nsid=0xFFFFFFFF, out=r)
        k(E, r, "pkt_sqe", "Get Log Page NUMD=1023 (4 KiB) ...")
        k(E, r, "pkt_cqe", "... but only 512 B of data MWr precede the CQE")
    elif variant == "nsid_bcast":
        yield from E.nvme_cmd(1, 0x02, 0xFFFFFFFF, E.next_lba(7), 7, "d2h", f={"status": (0, 0x0B, 1)}, out=r)
    elif variant == "wz_limit":
        yield from E.nvme_cmd(1, 0x08, 1, E.next_lba(0xFFFF), 0xFFFF, None, cdw12=0xFFFF,
                              f={"exec_lat": 9 * MS}, out=r)
    elif variant == "effects":
        yield from burst(E, 37, qd=37, f={"media_lat": 3 * MS})
        yield from E.admin(0x80, cdw10=0, f={"exec_lat": 4 * SEC}, nsid=1, out=r)
        k(E, r, "pkt_sqe", "Format NVM fetched while I/O commands are outstanding")
    k(E, r, "pkt_sqe", "SQE (rule-relevant fields in the 64-byte payload)")
    k(E, r, "pkt_cqe", "CQE %s" % (r.get("status") or ""))
    E.log("p18", card=c["id"], variant=variant)
    yield from burst(E, 2)


# ============================================================================ P23-P26: data, durability, admin, AEN
def p23(E, c, variant):
    slba = E.next_lba(7)
    w = {}
    yield from E.write(1, slba=slba, out=w, f={"write_version": 77})
    k(E, w, "pkt_cqe", "write of the reference pattern completes")
    r = {}
    if variant in ("dealloc_old", "dealloc_partial", "dealloc_far"):
        d = yield from E.dsm(1, ranges=((slba, 8),), f={"dealloc_ignored": True})
        k(E, d, "pkt_cqe", "Deallocate completes with success")
        yield from E.read(1, slba=slba, out=r, f={"read_version": 77})
        k(E, r, "pkt_cqe", "read after deallocate returns the old pattern (DLFEAT promised zeros)")
    elif variant == "discard_dropped":
        yield from E.dsm(1, ranges=((slba, 8),), f={"not_sent": True})
        yield from E.read(1, slba=slba, out=r)
    elif variant == "wz_not_zero":
        z = {}
        yield from E.nvme_cmd(1, 0x08, 1, slba, 7, None, f={"exec_lat": 30 * US}, out=z)
        k(E, z, "pkt_cqe", "Write Zeroes completes with success")
        yield from E.read(1, slba=slba, out=r, f={"read_version": 77})
    elif variant == "lost_write":
        w2 = {}
        yield from E.write(1, slba=slba, out=w2, f={"write_version": 78})
        yield from E.read(1, slba=slba, out=r, f={"read_version": 77})
        k(E, w2, "pkt_cqe", "second write acknowledged")
    elif variant == "misdirected":
        yield from E.read(1, slba=slba + 8, out=r, f={"read_version": 77})
    elif variant == "stale":
        yield from E.write(1, slba=slba, f={"write_version": 79})
        yield from E.read(1, slba=slba, out=r, f={"read_version": 77})
    elif variant == "bitflip":
        yield from E.read(1, slba=slba, out=r, f={"read_version": 77, "corrupt_at": 1207})
    elif variant in ("sanitize_left", "crypto_left", "format_left"):
        opc = 0x80 if variant == "format_left" else 0x84
        cdw10 = 0 if variant == "format_left" else (4 if variant == "crypto_left" else 2)
        z = {}
        yield from E.admin(opc, cdw10=cdw10, nsid=1 if opc == 0x80 else 0, f={"exec_lat": 1500 * MS}, out=z)
        k(E, z, "pkt_cqe", "erase operation reports success")
        yield from E.read(1, slba=slba, out=r, f={"read_version": 77})
    elif variant == "pi_unchecked":
        yield from E.write(1, slba=slba, f={"cdw12_prinfo": 1})
        yield from E.read(1, slba=slba, out=r)
    elif variant in ("dup_ids", "identify_wrong", "capacity", "smart_frozen", "fw_still_old", "smart_creep"):
        lid = {"smart_frozen": 0x02, "smart_creep": 0x02}.get(variant)
        for i in range(3 if lid else 2):
            if lid:
                yield from E.admin(0x02, cdw10=(127 << 16) | lid, xfer="d2h", nbytes=512, nsid=0xFFFFFFFF, out=r)
            elif variant == "identify_wrong":
                yield from E.admin(0x06, cdw10=0x1F, xfer="d2h", nbytes=4096, out=r)
            else:
                yield from E.nvme_cmd(0, 0x06, 1 + i, 0, 0, "d2h", nbytes=4096, cdw10=0 if variant != "fw_still_old" else 1,
                                      cdw12=0, out=r)
            yield 500 * MS
    elif variant == "zns_wp":
        yield from E.nvme_cmd(1, 0x7A, 1, slba, 0, "d2h", nbytes=4096, cdw10=slba & 0xFFFFFFFF, out=r)
    elif variant == "verify_fast":
        yield from E.nvme_cmd(1, 0x0C, 1, slba, 255, None, f={"exec_lat": 2 * US}, out=r)
        k(E, r, "pkt_cqe", "Verify of 128 KiB completes in ~2 us: media not read")
    elif variant == "zone_append":
        yield from E.nvme_cmd(1, 0x7D, 1, slba, 7, "h2d", dw0=slba + 0x40, out=r)
    elif variant == "copy":
        yield from E.nvme_cmd(1, 0x19, 1, slba + 0x100, 0, "h2d", nbytes=32, out=r)
        yield from E.read(1, slba=slba + 0x100, f={"read_version": 3})
    k(E, r, "pkt_cqe", "evidence read/command completes with success")
    E.log("p23", card=c["id"], variant=variant, payload_needed=True,
          note="decisive evidence is payload content: compare DATA (hex export) with the written pattern")
    yield from burst(E, 2)


def p24(E, c, variant):
    slbas = []
    flush_lat = 9 * US if variant in ("flush_lies", "plp", "torn", "order", "measure", "vbackup") else 300 * US
    for i in range(6):
        s = E.next_lba(7)
        slbas.append(s)
        yield from E.write(1, slba=s, f={"write_version": 200 + i})
        yield from E.flush_cmd(1, lat=flush_lat)
    E.key(E.eng.pkt - 3, "Flush completes in %d us" % (flush_lat // US))
    if variant in ("features", "reservation", "wp", "pmr"):
        opc = {"features": 0x09, "reservation": 0x0D, "wp": 0x09, "pmr": 0x09}[variant]
        r = {}
        if variant == "reservation":
            yield from E.nvme_cmd(1, 0x0D, 1, 0, 0, "h2d", nbytes=16, cdw10=0x40000000, out=r)
        else:
            yield from E.admin(0x09, cdw10=0x80000000 | (0x84 if variant == "wp" else 0x06), cdw11=1, out=r)
        k(E, r, "pkt_cqe", "state change with Save/PTPL accepted")
    yield 50 * MS
    n = E.eng.event("Electrical Idle")
    E.key(n, "power cut: electrical idle without EIOS, no shutdown notification")
    yield from full_recover(E, how="power", down_ps=4 * SEC, reason="power restored after cut")
    r = {}
    if variant in ("features", "reservation", "wp", "pmr"):
        if variant == "reservation":
            yield from E.nvme_cmd(1, 0x0E, 1, 0, 0, "d2h", nbytes=4096, cdw10=1023, out=r)
        else:
            yield from E.admin(0x0A, cdw10=(2 << 8) | (0x84 if variant == "wp" else 0x06), out=r)
    else:
        for i, s in enumerate(slbas):
            yield from E.read(1, slba=s, out=r, f={"read_version": 1 if variant != "measure" else 200 + i})
    k(E, r, "pkt_cqe", "post-power-cycle read-back / state query")
    yield from E.admin(0x02, cdw10=(127 << 16) | 0x02, xfer="d2h", nbytes=512, nsid=0xFFFFFFFF)
    E.log("p24", card=c["id"], variant=variant, payload_needed=True,
          note="compare post-cycle payloads with pre-cycle writes; SMART unsafe_shutdowns +1")


def p25(E, c, variant):
    r = {}
    if variant == "selftest_log":
        yield from E.admin(0x14, cdw10=1, nsid=0xFFFFFFFF, out=r)
        for _ in range(3):
            yield 1 * SEC
            yield from E.admin(0x02, cdw10=(140 << 16) | 0x06, xfer="d2h", nbytes=564, out=r)
    elif variant == "sanitize_fail":
        yield from E.admin(0x84, cdw10=2, out=r)
        for _ in range(4):
            yield 2 * SEC
            yield from E.admin(0x02, cdw10=(127 << 16) | 0x81, xfer="d2h", nbytes=512, out=r)
    elif variant == "fw_slot":
        yield from fw_download(E, 2)
        yield from E.admin(0x10, cdw10=(1 << 3) | 2, out=r)
        yield from E.admin(0x02, cdw10=(127 << 16) | 0x03, xfer="d2h", nbytes=512, out=r)
    elif variant in ("sanitize_long", "progress_stall"):
        yield from E.admin(0x84, cdw10=2, out=r)
        for _ in range(12):
            yield 10 * SEC
            yield from E.admin(0x02, cdw10=(127 << 16) | 0x81, xfer="d2h", nbytes=512, out=r)
    elif variant == "selftest_long":
        yield from E.admin(0x14, cdw10=2, nsid=0xFFFFFFFF, out=r)
        for _ in range(10):
            yield 15 * SEC
            yield from E.admin(0x02, cdw10=(140 << 16) | 0x06, xfer="d2h", nbytes=564, out=r)
    elif variant == "fw_requires_reset":
        yield from fw_download(E, 4)
        yield from E.admin(0x10, cdw10=(3 << 3) | 2, f={"status": (1, 0x0B, 0), "exec_lat": 420 * MS}, out=r)
        yield 5 * SEC
        yield from E.admin(0x06, cdw10=1, xfer="d2h", nbytes=4096)
    k(E, r, "pkt_cqe", "last admin completion / log read of the long operation")
    E.log("p25", card=c["id"], variant=variant)


AEN_DW0 = {"S-78": 0x00010100, "S-79": 0x00010300, "S-80": 0x00040002, "S-81": 0x00030102,
           "S-82": 0x00080202, "S-83": 0x000C0302, "S-84": 0x000B0402, "S-85": 0x00800006,
           "C-11": 0x00010300}
AEN_LOG = {"S-78": 0x01, "S-79": 0x01, "S-80": 0x04, "S-81": 0x03, "S-82": 0x08, "S-83": 0x0C,
           "S-84": None, "S-85": 0x80, "C-11": 0x01}


def p26(E, c, variant):
    yield from burst(E, 2)
    if variant == "aen":
        cid = c["id"]
        if cid == "S-78":
            n = E.mmio_wr(E.nv.db(1), E.nv.sq[1].size + 3)
            E.key(n, "invalid SQ1 doorbell value")
            yield 20 * US
        aen = yield from E.post_aen(AEN_DW0[cid], then_log=AEN_LOG[cid])
        E.key(aen, "AEN CQE on admin CQ (completes the outstanding AER) DW0=0x%08X" % AEN_DW0[cid])
        if cid in ("S-81",):
            for i in range(4):
                yield 300 * MS
                yield from E.mmio_rd(E.nv.bar0 + 0x1C, 1, 0x21 if i < 3 else 0x1)
        if cid in ("S-80",):
            yield from E.nvme_cmd(0, 0x06, 1, 0, 0, "d2h", nbytes=4096, cdw10=0, cdw12=0)
        if cid == "S-78":
            yield from reset_controller(E, "invalid doorbell event")
    elif variant in ("smart", "smart_noaen"):
        bit = {"S-72": 0, "S-73": 1, "S-74": 2, "S-75": 3, "S-77": 5, "N-28": 1}.get(c["id"], 1)
        if variant == "smart":
            aen = yield from E.post_aen(0x00020001 | (bit << 8), then_log=0x02)
            E.key(aen, "AEN: SMART/Health critical warning (bit %d)" % bit)
        else:
            for _ in range(3):
                yield 2 * SEC
                r = {}
                yield from E.admin(0x02, cdw10=(127 << 16) | 0x02, xfer="d2h", nbytes=512, nsid=0xFFFFFFFF, out=r)
            E.key(r["pkt_cqe"], "SMART log shows temperature above threshold; no AEN was raised")
    elif variant == "log":
        lid = {"S-71": 0x01, "S-86": 0x0D, "S-87": 0x08, "N-34": 0x0A}.get(c["id"], 0x01)
        if c["id"] == "S-71":
            r = {}
            yield from E.read(1, f={"status": (2, 0x81, 1, 1)}, out=r)
            k(E, r, "pkt_cqe", "CQE with More=1")
        r = {}
        yield from E.admin(0x02, cdw10=(1023 << 16) | lid, xfer="d2h", nbytes=4096, nsid=0xFFFFFFFF, out=r)
        k(E, r, "pkt_cqe", "log page LID 0x%02X read" % lid)
    elif variant == "timestamp":
        for i in range(3):
            r = {}
            yield from E.admin(0x0A, cdw10=0x0E, xfer="d2h", nbytes=8, out=r)
            k(E, r, "pkt_cqe", "Get Features Timestamp (FID 0Eh) #%d" % i)
            yield 2 * SEC
    E.log("p26", card=c["id"], variant=variant)
    yield from burst(E, 2)
