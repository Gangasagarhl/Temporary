#!/usr/bin/env python3
"""Generate a synthetic Teledyne-LeCroy-style PCIe/NVMe CSV capture (113 columns)
containing one episode for each of the 485 atlas failure cards.

The rows are produced by deterministic simulation (no LLM in the loop):
desktop session -> NVMe commands -> PCIe TLP/DLLP/ordered-set traffic.
SYNTHETIC DATA: not a real hardware capture.

Examples
  python3 generate_synthetic_pcie_trace.py --output pcie_trace_485_errors.csv --target-bytes 0
  python3 generate_synthetic_pcie_trace.py --output big.csv --target-bytes 4000000000
"""
import argparse
import csv
import hashlib
import json
import os
import re
import sys
import time

from tracegen_core import HEADER, MS, SEC, US, fmt_ts
from tracegen_episodes_a import burst, reset_controller
from tracegen_episodes_b import build_registry, full_recover
from tracegen_nvme import Ctx

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
INPUTS = os.path.join(ROOT, "01_input_files")


def sidecar_dir_for(csv_path):
    """<csv>_sidecars next to the CSV, or 03_main_csv_sidecars for the main CSV in the project root."""
    own = os.path.splitext(csv_path)[0] + "_sidecars"
    if os.path.isdir(own):
        return own
    return os.path.join(ROOT, "03_main_csv_sidecars")


GEN_VERSION = "1.0.0"
PHASE_ORDER = [
    ("platform & configuration", ["P19", "P04", "P05", "P21"]),
    ("link, data link & transaction layer", ["P08", "P09", "P06", "P07", "P10", "P11"]),
    ("controller, queues & commands", ["P13", "P14", "P15", "P16", "P17", "P18", "P01", "P02", "P03"]),
    ("power management & link loss", ["P20", "P12"]),
    ("storage semantics, durability & performance", ["P23", "P24", "P25", "P26", "P22"]),
    ("capture integrity & out-of-trace evidence", ["P27", "E"]),
]
VISIBILITY_TREATMENT = {
    "Visible": "wire pattern generated; failure signature is in the CSV rows listed in key_packets",
    "Partly visible": "wire symptom generated; the proof needs the outside-the-trace evidence listed",
    "Not visible": "honest context window only (no fabricated wire symptom); hidden state in the event log",
}


def load_cards(path):
    cards = json.load(open(path, encoding="utf-8"))
    assert len(cards) == 485, len(cards)
    for c in cards:
        pats = re.findall(r"P\d\d", c["card"].get("CSV pattern", ""))
        c["pattern"] = pats[0] if pats else "E"
        c["all_patterns"] = pats
        c["evidence"] = re.findall(r"E\d\d", c["card"].get("CSV pattern", ""))
    return cards


def healthy(E):
    nv = E.nv
    e = E.eng
    if e.link.speed != 16.0 or e.link.width != 4 or e.link.state != "L0":
        E.log("baseline_restore", reason="link not at 16 GT/s x4 L0")
        E.do(full_recover(E, reason="restore baseline link"))
    if not nv.enabled or any(q not in nv.sq for q in (0, 1, 2, 3, 4)):
        E.log("baseline_restore", reason="controller/queues not at baseline")
        E.do(reset_controller(E, "restore baseline queues"))
    e.ack_mode = {k: "normal" for k in e.ack_mode}
    e.fc_hold.clear()
    e.hide_dllp = False
    e.hide_all = False
    e.fc_every = {k: 6 for k in e.fc_every}


# ---------------------------------------------------------------- desktop activities
def act_app_launch(E):
    E.log("desktop", action="application launch", detail="random reads 4K-128K")
    yield from burst(E, E.rng.randint(12, 40), qd=E.rng.choice((4, 8, 16)), rw=0.9)


def act_file_copy(E):
    E.log("desktop", action="file copy", detail="sequential 128 KiB read+write")
    for _ in range(E.rng.randint(6, 20)):
        E.sched.spawn(E.read(E.rng.choice((1, 2)), nlb=255))
        yield 20 * US
        E.sched.spawn(E.write(E.rng.choice((3, 4)), nlb=255))
        yield E.rng.randint(80, 200) * US


def act_save(E):
    E.log("desktop", action="save document", detail="small writes + flush (fsync)")
    for _ in range(E.rng.randint(2, 6)):
        yield from E.write(E.rng.choice((1, 2, 3, 4)), nlb=E.rng.choice((7, 15, 31)))
    yield from E.flush_cmd(E.rng.choice((1, 2)))


def act_delete(E):
    E.log("desktop", action="delete files / fstrim", detail="Dataset Management, Deallocate")
    ranges = tuple((E.next_lba(255), 256) for _ in range(E.rng.randint(1, 4)))
    yield from E.dsm(E.rng.choice((1, 2, 3, 4)), ranges=ranges)


def act_idle(E):
    E.log("desktop", action="user idle", detail="ASPM L1.2 entry/exit, LTR update")
    E.ltr(snoop_val=E.rng.choice((2, 3, 5)), snoop_scale=4, ns_val=3, ns_scale=4)
    yield 30 * US
    yield from E.aspm_l1(E.rng.randint(20, 400) * MS)
    E.ltr(snoop_val=60, snoop_scale=2, ns_val=60, ns_scale=2)


def act_browser(E):
    E.log("desktop", action="browser cache", detail="mixed 4K reads/writes")
    yield from burst(E, E.rng.randint(8, 24), qd=4, rw=0.6, sizes=(7, 15))


ACTS = [(act_app_launch, 3), (act_file_copy, 3), (act_save, 2), (act_delete, 1), (act_idle, 2), (act_browser, 3)]


def filler(E, goal_bytes, compact):
    """Healthy desktop traffic until the CSV reaches goal_bytes (at least one small activity)."""
    first = True
    while first or E.eng.bytes_written < goal_bytes:
        first = False
        if compact:
            fn = E.rng.choice((act_browser, act_save, act_app_launch))
            E.do(burst(E, E.rng.randint(2, 5), qd=2))
            if E.rng.random() < 0.08:
                E.do(act_idle(E))
            E.do(fn(E)) if E.rng.random() < 0.15 else None
            break
        tot = sum(w for _, w in ACTS)
        x = E.rng.uniform(0, tot)
        for fn, w in ACTS:
            x -= w
            if x <= 0:
                break
        E.do(fn(E))


# ---------------------------------------------------------------- session
def boot(E):
    E.phase = "power-on & link training"
    E.log("user", action="power button pressed")
    E.power_on_preamble()
    E.do(E.train())
    E.phase = "BIOS enumeration"
    E.do(E.enumerate())
    E.phase = "UEFI NVMe driver"
    E.log("firmware", action="UEFI NvmExpressDxe start (polled completions)")
    E.do(E.controller_init(nq=1, note="UEFI"))
    E.do(burst(E, 24, qd=1, qids=(1,), rw=1.0, sizes=(7, 15, 63)))
    E.phase = "OS kernel nvme driver"
    E.log("os", action="kernel nvme-pci probe: controller reset and full init")
    E.do(reset_controller(E, "OS driver probe"))
    E.ltr(snoop_val=60, snoop_scale=2, ns_val=60, ns_scale=2)
    E.do(burst(E, 60, qd=8, rw=0.95, sizes=(7, 15, 31, 63, 255)))
    E.phase = "login & desktop"
    E.log("user", action="login; desktop shell starts")
    E.do(act_app_launch(E))
    E.do(act_idle(E))


def shutdown(E):
    E.phase = "shutdown"
    E.log("user", action="shutdown requested")
    E.do(act_save(E))
    E.do(E.shutdown())
    E.log("platform", action="power off")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--output", default="pcie_trace_485_errors.csv")
    ap.add_argument("--target-bytes", type=int, default=0,
                    help="grow healthy filler until the CSV reaches this size (0 = compact: episodes + minimal context)")
    ap.add_argument("--seed", type=int, default=20261024)
    ap.add_argument("--data-format", choices=("summary", "hex"), default="summary",
                    help="DATA column: 'summary' like the real export ('256 B') or 'hex' payload bytes")
    ap.add_argument("--cards", default=os.path.join(INPUTS, "atlas_cards_raw.json"))
    ap.add_argument("--sidecar-dir", default=None, help="where sidecars go (default: <output>_sidecars)")
    ap.add_argument("--only", default=None, help="comma list of card IDs (debugging)")
    ap.add_argument("--bg-rate", type=float, default=None, help="background commands/s during long waits")
    a = ap.parse_args()

    compact = a.target_bytes <= 0
    side = a.sidecar_dir or (os.path.splitext(a.output)[0] + "_sidecars")
    os.makedirs(side, exist_ok=True)
    cards = load_cards(a.cards)
    reg = build_registry()
    missing = [c["id"] for c in cards if c["id"] not in reg]
    if missing:
        sys.exit("registry is missing cards: %s" % missing)
    if a.only:
        keep = set(a.only.split(","))
        cards = [c for c in cards if c["id"] in keep]

    E = Ctx(a.output, a.seed, a.data_format, os.path.join(side, "scenario_event_log.jsonl"))
    # background I/O during long host timeouts (~30 min of simulated waits) scales with the size target
    E.bg_rate = a.bg_rate or (2.0 if compact else 2.0 + 30.0 * min(1.0, a.target_bytes / 4e9))
    t_start = time.time()
    index = []
    keyrows = []
    E.eng.on_row = None

    boot(E)
    order = []
    for phase, pats in PHASE_ORDER:
        for p in pats:
            order += [(phase, c) for c in cards if c["pattern"] == p]
    assert len(order) == len(cards), (len(order), len(cards))
    n_ep = len(order)
    base_bytes = E.eng.bytes_written
    for i, (phase, c) in enumerate(order):
        if not compact:
            goal = base_bytes + (a.target_bytes * 0.985 - base_bytes) * (i + 0.5) / n_ep
        else:
            goal = 0
        E.phase = "desktop activity"
        filler(E, goal, compact)
        healthy(E)
        E.phase = phase
        fn, kw = reg[c["id"]]
        E.cur_episode = c["id"]
        E.keys = []
        p0, t0 = E.eng.pkt, E.eng.now
        E.log("episode_start", card=c["id"], title=c["title"], builder=fn.__name__, params=str(kw))
        E.do(fn(E, c, **kw))
        E.eng.flush(E.eng.now)
        p1, t1 = E.eng.pkt - 1, E.eng.now
        keys = [(n, note) for n, note in E.keys if n is not None]
        E.log("episode_end", card=c["id"], packets=[p0, p1], key_packets=[n for n, _ in keys])
        E.cur_episode = None
        index.append({"episode": i + 1, "card_id": c["id"], "title": c["title"], "phase": phase,
                      "pattern": c["pattern"], "builder": fn.__name__,
                      "variant": kw.get("variant") or kw.get("flavour") or kw.get("what") or "",
                      "pex_visibility": c["pex"], "symptom_class": c["rep"], "origin": c["origin"],
                      "packet_first": p0, "packet_last": p1, "time_first": fmt_ts(t0), "time_last": fmt_ts(t1),
                      "n_key_rows": len(keys),
                      "key_packets": ";".join(str(n) for n, _ in keys)})
        for n, note in keys:
            keyrows.append((c["id"], n, note))
        if (i + 1) % 25 == 0:
            print("  %3d/%d episodes  rows=%d  bytes~%.1f MB  t=%s  (%.0fs)" %
                  (i + 1, n_ep, E.eng.rows, E.eng.bytes_written / 1e6, fmt_ts(E.eng.now), time.time() - t_start),
                  flush=True)
    E.phase = "desktop activity"
    filler(E, a.target_bytes if not compact else 0, compact)
    shutdown(E)
    E.eng.close()
    E.evlog.close()
    elapsed = time.time() - t_start

    # ---------------------------------------------------------------- sidecars
    with open(os.path.join(side, "csv_row_scenario_index.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(index[0].keys()))
        w.writeheader()
        w.writerows(index)
    with open(os.path.join(side, "episode_key_rows.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["card_id", "packet", "what_the_row_shows"])
        w.writerows(keyrows)
    by_id = {r["card_id"]: r for r in index}
    with open(os.path.join(side, "scenario_coverage_matrix.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["card_id", "title", "pex_visibility", "symptom_class", "origin", "layer", "csv_patterns",
                    "outside_evidence", "episode", "builder", "variant", "packet_first", "packet_last",
                    "key_packets", "treatment", "coverage_status", "validator_rule"])
        for c in cards:
            r = by_id.get(c["id"])
            status = "generated" if r else "not generated (filtered by --only)"
            if r and c["pex"] != "Not visible" and not r["key_packets"]:
                status = "generated (signature is statistical/contextual: no single key row)"
            w.writerow([c["id"], c["title"], c["pex"], c["rep"], c["origin"], c["layer"],
                        " ".join(c["all_patterns"]), " ".join(c["evidence"]), r and r["episode"],
                        r and r["builder"], r and r["variant"], r and r["packet_first"], r and r["packet_last"],
                        r and r["key_packets"], VISIBILITY_TREATMENT[c["pex"]], status,
                        "XII.4 %s rule (see atlas)" % c["pattern"] if c["pattern"] != "E" else
                        "XII.5 %s evidence match" % " ".join(c["evidence"])])
    size = os.path.getsize(a.output)
    sha = hashlib.sha256()
    with open(a.output, "rb") as fh:
        for blk in iter(lambda: fh.read(1 << 22), b""):
            sha.update(blk)
    manifest = {
        "generator": "generate_synthetic_pcie_trace.py", "version": GEN_VERSION,
        "provenance": "SYNTHETIC scenario-driven data; NOT a real Teledyne LeCroy capture",
        "output": a.output, "bytes": size, "data_rows": E.eng.rows - 0, "packets": E.eng.pkt,
        "sha256": sha.hexdigest(), "seed": a.seed, "data_format": a.data_format,
        "target_bytes": a.target_bytes, "mode": "compact" if compact else "size-targeted",
        "schema_sha256": hashlib.sha256(",".join(HEADER).encode()).hexdigest(), "columns": len(HEADER),
        "capture_span": fmt_ts(E.eng.last_t), "episodes": len(index),
        "row_type_counts": dict(sorted(E.eng.counts.items())),
        "topology": {"ssd": "002:00:0 (NVMe, 16 GT/s x4, MPS 256, MRRS 512)", "root_port_completer": "000:02:4",
                     "host_requester": "000:00:0", "bar0": "0xFCE00000"},
        "conventions": {
            "Time Stamp": "seconds with 12 decimals (ps), analyzer grid 125 ps, display truncated to 10 ps",
            "Time Delta": "to the NEXT row: end->start if same direction, else start->start (inferred from sample)",
            "DATA": "payload size summary 'N B' (as in the real export)" if a.data_format == "summary"
                    else "payload bytes in hex",
            "LCRC/CRC 16": "computed over synthetic header+payload bytes (CRC-32 / CRC-16 poly 100Bh); "
                           "'(Bad)' suffix = value the analyzer flags as wrong",
            "blank": "zero-valued header bits (TC/TD/EP/Attr/AT) and non-applicable fields are blank"},
        "elapsed_s": round(elapsed, 1),
    }
    json.dump(manifest, open(os.path.join(side, "synthetic_trace_manifest.json"), "w"), indent=2)
    print("done: %s  %d bytes  %d rows  %d episodes  capture %s  in %.0fs" %
          (a.output, size, E.eng.rows, len(index), fmt_ts(E.eng.last_t), elapsed))


if __name__ == "__main__":
    main()
