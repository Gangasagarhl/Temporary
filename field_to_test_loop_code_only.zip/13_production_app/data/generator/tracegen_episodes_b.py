"""Failure episodes, part B: PCIe transaction/link/physical patterns, power, performance,
capture integrity, context-only cards, and the 485-card registry."""
from tracegen_core import DN, HOST_RID, MS, NS, RC_CPL_ID, SEC, SSD_RID, UP, US
from tracegen_episodes_a import (ADMIN_TIMEOUT, IO_TIMEOUT, P01_TABLE, abort_cmd, bg, burst,
                                 full_recover, host_generated_status, hot_reset_link, k, p01, p02,
                                 p13, p14, p15, p16, p17, p18, p23, p24, p25, p26, reset_controller)
from tracegen_nvme import cqe


def post_cqe(E, qid, cid, sc=0, sct=0, dnr=0, dw0=0):
    cq = E.nv.cq[qid]
    slot = cq.tail
    cq.tail = (cq.tail + 1) % cq.size
    ph = cq.phase
    if cq.tail == 0:
        cq.phase ^= 1
    return E.dev_mwr(cq.base + slot * 16, cqe(cid, qid, E.nv.sq[qid].head if qid in E.nv.sq else 0, ph,
                                              sc, sct, dnr, dw0=dw0))


def dma_read_stream(E, n=16, bad_at=None, nbytes=256, attr="", display_only=False):
    """A read-direction data stream (device MWr) used by link-layer episodes.

    Returns (first_pkt, bad_pkt, psn_of_first). No yields: the PSNs are contiguous."""
    base = E.alloc(1)[0]
    first = None
    bad = None
    psn0 = E.eng.psn[UP]
    for i in range(n):
        x = E.dev_mwr(base + (i * nbytes) % 4096 + ((i * nbytes) // 4096) * 4096,
                      E.data(0x400000 + i, 0, nbytes), bad_lcrc=(i == bad_at and not display_only),
                      display_bad=(i == bad_at and display_only), attr=attr)
        first = first if first is not None else x
        if i == bad_at:
            bad = x
    return first, bad, psn0


# ============================================================================ P03: completion timeout
def p03(E, c, variant):
    yield from burst(E, 2)
    e = E.eng
    if variant in ("cto", "cto_fabric"):
        v = {}
        tag = E.nv.next_dev_tag()
        a = E.alloc(1)[0]
        n = E.dev_mrd(a, 128, tag)
        E.key(n, "MRd (write data fetch) acknowledged by the link, never completed")
        yield 50 * MS
        m = E.msg(UP, "ERR_NONFATAL", "To Root Complex")
        E.key(m, "Completion Timeout reported: ERR_NONFATAL ~50 ms after the MRd")
        yield 40 * US
        cid = E.nv.sq[1].cid = (E.nv.sq[1].cid + 1) & 0xFFFF
        E.nv.sq[1].head = (E.nv.sq[1].head + 1) % E.nv.sq[1].size
        x = post_cqe(E, 1, cid, sc=0x04)
        E.key(x, "CQE: Data Transfer Error (SCT0 SC 0x04)")
        E.msi(1)
        yield 3 * US
        E.ring_cq(1)
        E.nv.dev_open_tags.discard(tag)
        yield from E.write(1)
    elif variant == "cto_disabled":
        v = {}
        E.sched.spawn(E.write(3, f={"no_cqe": True, "fetched_then_hang": True}, out=v))
        yield 30 * US
        tag = E.nv.next_dev_tag()
        n = E.dev_mrd(E.alloc(1)[0], 128, tag)
        E.key(n, "MRd never answered; CTO disabled so no ERR_NONFATAL")
        yield from bg(E, IO_TIMEOUT, qids=(2,))
        yield from reset_controller(E, "I/O timeout with completion timeout disabled")
    elif variant == "sqe_fetch":
        sq = E.nv.sq[2]
        sq.cid = (sq.cid + 1) & 0xFFFF
        slot = sq.tail
        sq.tail = (sq.tail + 1) % sq.size
        E.ring_sq(2)
        yield 800 * NS
        tag = E.nv.next_dev_tag()
        n = E.dev_mrd(sq.base + slot * 64, 16, tag)
        E.key(n, "SQE fetch MRd with no CplD")
        yield 50 * MS
        E.key(E.msg(UP, "ERR_NONFATAL", "To Root Complex"), "Completion Timeout ERR_NONFATAL")
        yield from bg(E, IO_TIMEOUT, qids=(1, 3))
        yield from reset_controller(E, "SQE fetch lost")
    elif variant == "split_stall":
        tag = E.nv.next_dev_tag()
        a = E.alloc(1)[0]
        n = E.dev_mrd(a, 128, tag)
        yield 700 * NS
        ps = yield from E.host_cpld(tag, a, E.data(0x500000, 0, 512), stall_after=1)
        E.key(ps[0], "first CplD fragment (Byte Cnt 512), the second never arrives")
        yield 50 * MS
        E.key(E.msg(UP, "ERR_NONFATAL", "To Root Complex"), "CTO after a partial completion")
        E.nv.dev_open_tags.discard(tag)
    elif variant == "posted_drain":
        dma_read_stream(E, 48)
        tag = E.nv.next_dev_tag()
        a = E.alloc(1)[0]
        n = E.dev_mrd(a, 16, tag)
        yield 42 * US
        ps = yield from E.host_cpld(tag, a, bytes(64))
        E.key(ps[0], "CplD 42 us after the MRd: queued behind posted writes in the root complex")
    elif variant == "deep_tail":
        tags = []
        for i in range(64):
            t = E.nv.next_dev_tag()
            a = E.alloc(1)[0]
            E.dev_mrd(a, 128, t)
            tags.append((t, a))
            yield 20 * NS
        for i, (t, a) in enumerate(tags):
            yield (1 + i // 8) * US
            ps = yield from E.host_cpld(t, a, E.data(0x600000 + i, 0, 512))
        E.key(ps[0], "last of 64 outstanding reads completes ~40 us late")
    elif variant == "across_reset":
        tag = E.nv.next_dev_tag()
        n = E.dev_mrd(E.alloc(1)[0], 128, tag)
        E.key(n, "MRd outstanding when the host resets the link")
        yield 5 * US
        yield from full_recover(E, reason="hot reset with a read in flight")
        return
    E.log("p03", card=c["id"], variant=variant)
    yield from burst(E, 2)


# ============================================================================ P04: UR / CA / CRS
def p04(E, c, variant):
    nv = E.nv
    yield from burst(E, 2)
    if variant == "crs_long":
        yield from E.cfg_wr(0x078, 0x00108830)
        nv.sq.clear()
        nv.cq.clear()
        yield 100 * MS
        dly = 1 * MS
        total = 0
        while total < 1500 * MS:
            n, c_ = yield from E.cfg_rd(0x000, 0, status="CRS")
            yield dly
            total += dly
            dly = min(dly * 2, 256 * MS)
        E.key(c_, "Configuration Request Retry Status still returned %d ms after FLR" % (total // MS))
        n, c_ = yield from E.cfg_rd(0x000, 0x00101B36)
        yield from E.cfg_wr(0x004, 0x00100406)
        yield from E.controller_init(note="after long CRS")
    elif variant == "crs_forever":
        yield from E.cfg_wr(0x078, 0x00108830)
        nv.sq.clear()
        nv.cq.clear()
        yield 100 * MS
        dly = 1 * MS
        total = 0
        while total < 60 * SEC:
            n, c_ = yield from E.cfg_rd(0x000, 0, status="CRS")
            yield dly
            total += dly
            dly = min(dly * 2, 4 * SEC)
        E.key(c_, "CRS for 60 s: pci_dev_wait gives up")
        yield from full_recover(E, how="power", reason="slot power cycle after CRS loop")
    elif variant == "ur_mmio":
        n, c_ = yield from E.mmio_rd(nv.bar0 + 0x4000, 1, status="UR")
        E.key(c_, "Cpl with UR for an MMIO read beyond the decoded BAR")
        yield 300 * NS
        E.key(E.msg(UP, "ERR_COR", "To Root Complex"), "Advisory Non-Fatal: UR reported as ERR_COR")
        n = E.mmio_wr(nv.bar0 + 0x4000, 0)
        yield 400 * NS
        E.key(E.msg(UP, "ERR_NONFATAL", "To Root Complex"), "posted MWr to an undecoded address: ERR_NONFATAL")
    elif variant in ("ca_dma", "ur_iommu"):
        r = {}
        st = "CA" if variant == "ca_dma" else "UR"
        yield from E.write(1, f={"status": (0, 0x04, 0), "cpl_status": st, "data_even_if_error": True}, out=r)
        k(E, r, "pkt_bad_cpl", "root complex answers the device's data read with %s" % st)
        k(E, r, "pkt_cqe", "CQE Data Transfer Error")
        if variant == "ur_iommu":
            yield from E.read(1, f={"extra_mwr": (0x31200F000, 256)})
    elif variant == "bar_unassigned":
        yield from E.cfg_rd(0x010, 0x00000004)
        n, c_ = yield from E.cfg_rd(0x004, 0x00100000)
        E.key(c_, "BAR0 reads 0 and Command.MEM=0: no resources assigned")
        n, c_ = yield from E.mmio_rd(nv.bar0 + 0x1C, 1, status="UR")
        E.key(c_, "driver MMIO read answered UR")
        yield 1 * SEC
        yield from E.cfg_wr(0x010, nv.bar0 | 4)
        yield from E.cfg_wr(0x004, 0x00100406)
    elif variant == "all_ones":
        n, c_ = yield from E.mmio_rd(nv.bar0 + 0x1C, 1, status="UR")
        E.key(c_, "CSTS read answered UR -> host sees 0xFFFFFFFF")
        yield 2 * MS
        yield from E.cfg_rd(0x004, 0x00100000)
        yield from full_recover(E, reason="device lost its configuration")
    elif variant == "wrong_completer":
        tag = nv.next_host_tag()
        E.eng.tlp(DN, "MRd(32)", 1, rid=HOST_RID, tag=tag, addr=nv.bar0 + 0x1C)
        yield 600 * NS
        n = E.eng.tlp(UP, "CplD", 1, rid=HOST_RID, tag=tag, cid="003:00:0", bytecnt=4, lwr=0x1C,
                      payload=(1).to_bytes(4, "little"))[0]
        E.key(n, "CompleterID bus 003 but the function was enumerated on bus 002")
    elif variant == "vdm":
        n = E.msg(DN, "Vendor_Defined_Type_0", "By ID", data=bytes.fromhex("B41A0000010008C8"),
                  extra={"DeviceID": SSD_RID})
        E.key(n, "MCTP VDM Type 0 to an endpoint without MCTP-over-PCIe")
        yield 600 * NS
        E.key(E.msg(UP, "ERR_NONFATAL", "To Root Complex"), "UR for a posted message is reported with ERR_NONFATAL "
                                                             "(a message never gets a completion)")
    elif variant == "ignored_msg":
        n = E.msg(DN, "Attention_Indicator_On", "Local")
        E.key(n, "legacy indicator message (must be silently ignored)")
        yield 600 * NS
        E.key(E.msg(UP, "ERR_NONFATAL", "To Root Complex"), "device flags it as UR instead of ignoring it")
    elif variant == "atomic":
        tag = nv.next_dev_tag()
        n = E.eng.tlp(UP, "CAS", 4, rid=SSD_RID, tag=tag, addr=E.alloc(1)[0], payload=bytes(16))[0]
        E.key(n, "AtomicOp CAS from the SSD")
        yield 800 * NS
        x = E.eng.tlp(DN, "Cpl", 0, rid=SSD_RID, tag=tag, cid=RC_CPL_ID, status="UR", bytecnt=4)[0]
        E.key(x, "root complex has no AtomicOp completer: UR")
        nv.dev_open_tags.discard(tag)
    elif variant == "io_request":
        tag = nv.next_host_tag()
        n = E.eng.tlp(DN, "IORd", 1, rid=HOST_RID, tag=tag, addr=0x0000E000)[0]
        E.key(n, "I/O-space read to an SSD with no I/O BAR")
        yield 600 * NS
        E.key(E.eng.tlp(UP, "Cpl", 0, rid=HOST_RID, tag=tag, cid=SSD_RID, status="UR", bytecnt=4)[0],
              "Cpl UR")
    E.log("p04", card=c["id"], variant=variant)
    yield from burst(E, 2)


# ============================================================================ P05: tags and IDs
def p05(E, c, variant):
    nv = E.nv
    yield from burst(E, 2)
    if variant == "unexpected":
        n = E.eng.tlp(DN, "CplD", 16, rid=SSD_RID, tag=0x3F, cid=RC_CPL_ID, bytecnt=64, lwr=0,
                      payload=bytes(64))[0]
        E.key(n, "CplD for tag 63 with no outstanding request")
        yield 500 * NS
        E.key(E.msg(UP, "ERR_COR", "To Root Complex"), "Unexpected Completion (advisory) ERR_COR")
    elif variant == "tag_reuse":
        t = nv.next_dev_tag()
        a1, a2 = E.alloc(1)[0], E.alloc(1)[0]
        n1 = E.dev_mrd(a1, 64, t)
        yield 200 * NS
        n2 = E.dev_mrd(a2, 64, t)
        E.key(n2, "second MRd with the same tag while the first is open")
        yield 700 * NS
        yield from E.host_cpld(t, a1, E.data(0x700000, 0, 256))
        yield 400 * NS
        yield from E.host_cpld(t, a2, E.data(0x700100, 0, 256))
    elif variant == "tag10":
        outs = []
        for tg in (260, 261):
            a = E.alloc(1)[0]
            E.key(E.dev_mrd(a, 64, tg), "10-bit tag %d used although 10-Bit Tag Requester Enable=0" % tg)
            outs.append((tg, a))
        yield 800 * NS
        for tg, a in outs:
            n = E.eng.tlp(DN, "CplD", 64, rid=SSD_RID, tag=tg & 0xFF, cid=RC_CPL_ID, bytecnt=256,
                          lwr=a & 0x7F, payload=E.data(0x710000, 0, 256))[0]
            E.key(n, "completion comes back with tag %d (8-bit wrap)" % (tg & 0xFF))
            yield 200 * NS
    elif variant == "prestart":
        n = E.eng.tlp(DN, "CplD", 16, rid=SSD_RID, tag=0x1F, cid=RC_CPL_ID, bytecnt=64, lwr=0x40,
                      payload=bytes(64))[0]
        E.key(n, "completion whose request is not in the export (filtered / before capture start)")
    elif variant == "wrong_rid":
        n = E.dev_mwr(E.alloc(1)[0], E.data(0x720000, 0, 256), rid="002:00:1")
        E.key(n, "upstream MWr with Requester ID 002:00:1 (function 1 does not exist)")
    E.log("p05", card=c["id"], variant=variant)
    yield from burst(E, 2)


# ============================================================================ P06: data link replay
def p06(E, c, variant):
    e = E.eng
    yield from burst(E, 1)
    if variant in ("nak", "flit_crc"):
        first, bad, psn0 = dma_read_stream(E, 8, bad_at=3)
        E.key(bad, "TLP received with bad LCRC")
        yield 400 * NS
        e.flush(e.now)
        n = e.replay(UP, from_psn=(psn0 + 3) & 0xFFF)
        E.key(n, "replay of the Nak'd TLP (same PSN)")
    elif variant == "bad_dllp":
        dma_read_stream(E, 4)
        yield 50 * NS
        n = e.force_ack(UP, (e.psn[UP] - 1) & 0xFFF, bad_crc=True)
        E.key(n, "Ack DLLP with bad CRC 16 (ignored by the receiver)")
        yield 300 * NS
    elif variant in ("rollover", "flit_seq"):
        e.ack_mode[UP] = "hold"
        first, _, psn0 = dma_read_stream(E, 3)
        for i in range(4):
            yield 6500 * NS
            n = e.replay(UP, from_psn=psn0)
            E.key(n, "replay #%d after replay-timer expiry (no Ack/Nak)" % (i + 1))
        yield 6500 * NS
        e.ack_mode[UP] = "normal"
        E.key(e.os(UP, "TS1"), "REPLAY_NUM rollover: transmitter enters Recovery")
        yield from E.recovery(n_ts=2, eieos=False, reason="REPLAY_NUM rollover")
        e.replay(UP, from_psn=psn0)
        yield 1 * US
        E.key(E.msg(UP, "ERR_COR", "To Root Complex"), "REPLAY_NUM Rollover correctable error")
    elif variant == "replay_timer":
        e.ack_mode[UP] = "hold"
        first, _, psn0 = dma_read_stream(E, 1)
        yield 6500 * NS
        e.ack_mode[UP] = "normal"
        n = e.replay(UP, from_psn=psn0)
        E.key(n, "replay after the replay timer with no Ack or Nak in between")
        yield 1 * US
        E.key(E.msg(UP, "ERR_COR", "To Root Complex"), "Replay Timer Timeout correctable error")
    elif variant == "ack_late":
        e.ack_mode[UP] = "late"
        e.ack_late_ps = 7 * US
        _, _, psn0 = dma_read_stream(E, 4)
        yield 6500 * NS
        n = e.replay(UP, from_psn=psn0)
        E.key(n, "needless replay: the Ack arrives after the replay timer")
        yield 2 * US
        e.ack_mode[UP] = "normal"
        e.ack_late_ps = 0
    elif variant == "seq_gap":
        e.psn[UP] = (e.psn[UP] + 1) & 0xFFF
        first, bad, psn0 = dma_read_stream(E, 3, bad_at=0)
        E.key(bad, "PSN skips one value (sequence gap): receiver treats it as a bad TLP")
        yield 400 * NS
        e.flush(e.now)
        e.replay(UP, from_psn=psn0)
    elif variant == "nak_storm":
        for j in range(25):
            first, bad, psn0 = dma_read_stream(E, 6, bad_at=2)
            if j < 3:
                E.key(bad, "bad LCRC #%d" % j)
            yield 400 * NS
            e.flush(e.now)
            e.replay(UP, from_psn=(psn0 + 2) & 0xFFF)
            yield E.rng.randint(5, 40) * US
    elif variant == "wrong_nak":
        dma_read_stream(E, 4)
        yield 100 * NS
        n = e.dllp(DN, "NAK", seq=(e.psn[UP] + 7) & 0xFFF)
        E.key(n, "Nak names a PSN that was never transmitted")
        yield 300 * NS
    elif variant == "replay_dup_cqe":
        r = {}
        e.ack_mode[UP] = "hold"
        yield from E.read(1, f={"no_cq_doorbell": True}, out=r)
        psn = int(e.retry[UP][-2][0])
        yield 6500 * NS
        e.ack_mode[UP] = "normal"
        n = e.replay(UP, from_psn=psn)
        E.key(n, "replayed CQE MWr (same PSN): one completion, not two")
        yield 3 * US
        E.ring_cq(1)
    elif variant == "latency_only":
        first, bad, psn0 = dma_read_stream(E, 16, bad_at=9)
        E.key(bad, "single LCRC error inside a read")
        yield 400 * NS
        e.flush(e.now)
        e.replay(UP, from_psn=(psn0 + 9) & 0xFFF)
    E.log("p06", card=c["id"], variant=variant)
    yield from burst(E, 1)


# ============================================================================ P07: flow control
def p07(E, c, variant):
    e = E.eng
    yield from burst(E, 2)
    if variant in ("starve", "vc"):
        e.fc_hold.add((UP, "P"))
        dma_read_stream(E, 24)
        E.key(e.pkt - 1, "last posted TLP before the posted credit limit is reached")
        tag = E.nv.next_dev_tag()
        a = E.alloc(1)[0]
        E.key(E.dev_mrd(a, 16, tag), "non-posted requests still flow")
        yield 700 * NS
        yield from E.host_cpld(tag, a, bytes(64))
        dur = 2100 * MS if variant == "vc" else IO_TIMEOUT
        yield dur
        e.fc_hold.discard((UP, "P"))
        if variant == "vc":
            n = e.dllp(DN, "UpdateFC-P", vc=0, hdr=(e.fc_limit.get((UP, "P"), (0, 0))[0] + 32) & 0xFF,
                       data=(e.fc_limit.get((UP, "P"), (0, 0))[1] + 512) & 0xFFF)
            E.key(n, "UpdateFC-P finally returned after 2.1 s")
        else:
            yield from full_recover(E, reason="secondary bus reset to recover posted credits")
            return
    elif variant == "slow_return":
        e.fc_every[DN] = 6
        e.fc_every[UP] = 48
        for _ in range(4):
            dma_read_stream(E, 12)
            yield 2 * US
        E.key(e.pkt - 1, "UpdateFC-P only every ~48 TLPs: sender stalls between bursts")
        e.fc_every[UP] = 6
    elif variant in ("violation", "overflow", "fcpe"):
        e.fc_hold.add((UP, "P"))
        dma_read_stream(E, 40)
        E.key(e.pkt - 1, "posted TLPs sent beyond the advertised credit limit")
        e.fc_hold.discard((UP, "P"))
        if variant == "fcpe":
            E.key(e.dllp(UP, "UpdateFC-P", vc=0, hdr=255, data=4095), "UpdateFC advertising > 2^(n-1) credits")
        yield 5 * US
        yield from full_recover(E, reason="fatal FC error, DPC/SBR")
        return
    elif variant == "initfc_stall":
        yield from hot_reset_link(E)
        yield 100 * MS
        e.link.speed = 2.5
        e.event("Electrical Idle Exit")
        for _ in range(3):
            e.os(DN, "TS1", link="PAD", lane="PAD")
            e.os(UP, "TS1", link="PAD", lane="PAD")
        for _ in range(3):
            e.os(DN, "TS2")
            e.os(UP, "TS2")
        e.event("Link Up", DN)
        e.event("Link Up", UP)
        yield from E.dl_init(fc_stall=True)
        E.key(e.pkt - 1, "InitFC1 repeating, InitFC2 never sent: DL_Init does not complete")
        yield 2 * MS
        yield from full_recover(E, reason="retrain after FC init stall")
        return
    E.log("p07", card=c["id"], variant=variant)
    yield from burst(E, 2)


# ============================================================================ P08: LTSSM / training
def retrain_full(E, reason, **kw):
    yield from full_recover(E, how="hot_reset", reason=reason, train_kw=kw)


def p08(E, c, variant):
    e = E.eng
    yield from burst(E, 2)
    if variant in ("downshift", "eq_fail", "eq_retry"):
        yield from hot_reset_link(E)
        yield 80 * MS
        if variant == "eq_retry":
            yield from E.train(eq_reject_lane=1, eq_fail_speed=None)
            E.key(e.pkt - 1, "link up after repeated EQ requests")
        else:
            yield from E.train(eq_reject_lane=1, eq_fail_speed=16.0)
            E.key(e.pkt - 1, "EQ phase 3 timeout at 16 GT/s: link falls back to 8 GT/s")
            yield from E.enumerate(full=False)
            yield from E.controller_init()
            yield from burst(E, 6, qd=4)
            yield from retrain_full(E, "retrain to restore 16 GT/s")
            return
        yield from E.enumerate(full=False)
        yield from E.controller_init()
    elif variant == "slow_up":
        yield from hot_reset_link(E)
        for _ in range(9):
            e.event("Receiver Detect: no termination")
            yield 100 * MS
        n = e.event("Receiver Detect")
        yield from E.train()
        E.key(n, "receiver detected ~1 s after reset (> 100 ms requirement)")
        yield from E.enumerate(full=False)
        yield from E.controller_init()
    elif variant == "aspm_exit":
        yield from E.aspm_l1(3 * MS, exit_lat=180 * US)
        E.key(e.pkt - 1, "L1 exit took ~180 us (endpoint L1 acceptable latency 64 us)")
        yield from E.read(1)
    elif variant in ("narrow", "lane_skew", "reversal"):
        yield from hot_reset_link(E)
        yield 80 * MS
        e.link.width = 2
        if variant == "lane_skew":
            E.key(e.event("Lane-to-Lane Skew Exceeded (Lane 3)"), "deskew failure on lane 3")
        if variant == "reversal":
            for _ in range(2):
                e.os(DN, "TS1", link="0", lane="3")
                e.os(UP, "TS1", link="0", lane="0")
            E.key(e.event("Lane Reversal Detected"), "lane numbers reversed and not handled")
        yield from E.train(width=2)
        E.key(e.event("Width Change: x2"), "link trained x2 although both ends are x4")
        yield from E.enumerate(full=False)
        yield from E.controller_init()
        yield from burst(E, 6, qd=4)
        e.link.width = 4
        yield from retrain_full(E, "reseat / retrain to x4")
        return
    elif variant in ("storm", "power_flap"):
        for i in range(20):
            yield from burst(E, 1)
            if variant == "power_flap" and i % 5 == 0:
                e.event("CLKREQ# Deasserted")
                e.event("CLKREQ# Asserted")
            n = e.event("Electrical Idle Exit")
            yield from E.recovery(n_ts=2, reason="recovery storm")
            if i < 3:
                E.key(n, "Recovery entry #%d (no speed change, no errors)" % (i + 1))
            yield 25 * MS
    elif variant == "no_dlactive":
        yield from hot_reset_link(E)
        for i in range(5):
            yield 20 * MS
            e.link.speed = 2.5
            e.event("Electrical Idle Exit")
            for _ in range(3):
                e.os(DN, "TS1", link="PAD", lane="PAD")
                e.os(UP, "TS1", link="PAD", lane="PAD")
            e.os(DN, "TS2", link="0", lane="0")
            e.event("Link Up", DN)
            E.key(e.event("Link Down", DN), "link drops before DL_Active (attempt %d)" % (i + 1))
        yield 50 * MS
        yield from E.train()
        yield from E.enumerate(full=False)
        yield from E.controller_init()
    elif variant == "aspm_drop":
        yield from _aspm_entry(E)
        e.event("CLKREQ# Asserted")
        yield 30 * US
        e.event("Electrical Idle Exit", DN)
        for _ in range(8):
            e.os(DN, "TS1")
        E.key(e.event("Link Down", DN), "L1 exit fails: the device never answers, link drops")
        yield from full_recover(E, how=None, reason="surprise link down from L1")
        return
    elif variant == "malformed_os":
        yield from E.recovery(n_ts=1)
        n = e.os(UP, "TS1", link="0", lane="0", rate="Reserved (0x3F)")
        E.key(n, "TS1 with reserved data-rate encoding")
        E.key(e.event("Invalid Ordered Set (Lane 1)"), "malformed ordered set")
        yield from E.recovery(n_ts=2)
    elif variant == "speed_change_live":
        yield from burst(E, 3)
        yield from E.speed_change(8.0)
        E.key(e.event("Speed Change: 8.0 GT/s (autonomous)"), "unexpected speed change during traffic")
        yield from burst(E, 6, qd=4)
        yield from E.speed_change(16.0)
    elif variant == "compliance":
        yield from hot_reset_link(E)
        e.link.speed = 2.5
        for _ in range(40):
            e.os(UP, "Compliance Pattern")
            yield 1 * MS
        E.key(e.pkt - 1, "LTSSM stuck in Polling.Compliance")
        yield from E.train()
        yield from E.enumerate(full=False)
        yield from E.controller_init()
    elif variant == "ei_glitch":
        for i in range(3):
            yield from burst(E, 1)
            n = e.event("Electrical Idle (no EIOS)", UP)
            if i == 0:
                E.key(n, "electrical idle glitch during L0")
            yield 2 * US
            yield from E.recovery(n_ts=2)
    elif variant == "not_top":
        yield from E.recovery(n_ts=2)
        n = e.os(DN, "TS2", rate="2.5 GT/s, 5.0 GT/s, 8.0 GT/s, 16.0 GT/s, 32.0 GT/s")
        E.key(n, "root port advertises up to 32 GT/s; endpoint 16 GT/s; no Flit mode on this link")
    elif variant == "dwell":
        yield from E.recovery(n_ts=60)
        E.key(e.pkt - 1, "Recovery dwell ~1 ms (baseline ~2 us)")
    elif variant == "bw_drop":
        for _ in range(8):
            first, _, psn0 = dma_read_stream(E, 4)
            yield 900 * NS
        E.key(e.pkt - 1, "16 GT/s x4 but MWr bursts separated by idle gaps")
    elif variant == "lnksta":
        yield from E.recovery(n_ts=1, eieos=True)
        n, c_ = yield from E.cfg_rd(0x080, 0x08110040)
        E.key(c_, "Link Status read during Recovery: Link Training=1, speed 2.5 GT/s, x1 (transient)")
        yield from E.recovery(n_ts=2, eieos=False)
    elif variant == "perf_baseline":
        yield from E.speed_change(8.0)
        E.key(e.pkt - 1, "link now at 8 GT/s")
        yield from burst(E, 8, qd=8)
        yield from E.speed_change(16.0)
    elif variant == "margining":
        for reg in (0x30C, 0x310, 0x314, 0x318):
            yield from E.cfg_wr(reg, 0x0000009F)
            n, c_ = yield from E.cfg_rd(reg, 0x00000000)
        E.key(c_, "Lane Margining status: no margin reported")
    E.log("p08", card=c["id"], variant=variant, speed=e.link.speed, width=e.link.width)
    yield from burst(E, 2)


def _aspm_entry(E):
    e = E.eng
    yield 2 * US
    for _ in range(3):
        e.dllp(UP, "PM_Active_State_Request_L1")
        yield 100 * NS
    e.dllp(DN, "PM_Request_Ack")
    e.os(UP, "EIOS")
    e.os(DN, "EIOS")
    e.event("Electrical Idle")
    yield 5 * US
    e.event("CLKREQ# Deasserted")
    yield 5 * MS


# ============================================================================ P09: physical layer
def p09(E, c, variant):
    e = E.eng
    yield from burst(E, 1)
    if variant in ("symbol", "disparity"):
        yield from hot_reset_link(E)
        yield 50 * MS
        e.link.speed = 2.5
        e.event("Electrical Idle Exit")
        for _ in range(2):
            e.os(DN, "TS1", link="PAD", lane="PAD")
            e.os(UP, "TS1", link="PAD", lane="PAD")
        txt = "Invalid 10b Symbol (Lane 2)" if variant == "symbol" else "Running Disparity Error (Lane 2)"
        for i in range(3):
            n = e.event(txt, UP)
            if i == 0:
                E.key(n, txt + " at 2.5 GT/s")
            e.os(UP, "TS1", link="PAD", lane="PAD")
        yield from E.train(from_detect=True)
        yield from E.enumerate(full=False)
        yield from E.controller_init()
    elif variant in ("sync", "receiver_err"):
        n = e.event("Invalid Sync Header (Lane 3)", UP)
        E.key(n, "invalid 128b/130b sync header")
        first, bad, psn0 = dma_read_stream(E, 4, bad_at=1)
        yield 400 * NS
        e.flush(e.now)
        e.replay(UP, from_psn=(psn0 + 1) & 0xFFF)
        yield from E.recovery(n_ts=2)
        if variant == "receiver_err":
            E.key(E.msg(UP, "ERR_COR", "To Root Complex"), "Receiver Error reported by the SSD (ERR_COR)")
    elif variant == "framing":
        E.key(e.event("Framing Error: STP expected", UP), "framing token error")
        yield from E.recovery(n_ts=2)
    elif variant == "nullified":
        base = E.alloc(1)[0]
        psn = e.psn[UP]
        n = e.tlp(UP, "MWr(64)" if base >= 1 << 32 else "MWr(32)", 64, rid=SSD_RID, tag=0, addr=base,
                  payload=E.data(0x800000, 0, 256), nullified=True, psn=psn)[0]
        e.psn[UP] = psn
        E.key(n, "nullified TLP (EDB, inverted LCRC) from an endpoint")
        E.dev_mwr(base, E.data(0x800000, 0, 256))
    elif variant == "skp":
        n = e.os(UP, "SKP")
        e.event("SKP OS Interval Violation (> 370 blocks)", UP)
        E.key(n, "SKP interval violated")
    elif variant in ("probe_si", "relock", "setup"):
        if variant == "relock":
            yield from E.aspm_l1(2 * MS)
            E.key(e.event("Analyzer: Loss of Lock / Resync", UP, marker="Resync"), "analyzer re-lock after idle exit")
        if variant == "setup":
            for i in range(12):
                e.event("Invalid Sync Header (Lane 1)", UP)
        first, bad, psn0 = dma_read_stream(E, 4, bad_at=0, display_only=True)
        E.key(bad, "analyzer shows a bad LCRC, but the partner Acks it (no Nak): capture artefact")
    elif variant in ("wrap", "gap"):
        yield from burst(E, 2)
        dma_read_stream(E, 1)
        yield 412 * MS
        e.psn[UP] = (e.psn[UP] + 1371) & 0xFFF
        e.psn[DN] = (e.psn[DN] + 604) & 0xFFF
        e.retry[UP].clear()
        e.retry[DN].clear()
        e.marker("Buffer Wrap: 412 ms not recorded")
        E.key(e.pkt, "first row after a buffer wrap: 412 ms of traffic missing")
    elif variant == "filter":
        e.marker("Display filter: DLLPs hidden")
        E.key(e.pkt, "DLLP rows filtered from this window")
        e.hide_dllp = True
        yield from burst(E, 6, qd=4)
        e.drain()
        e.hide_dllp = False
    E.log("p09", card=c["id"], variant=variant)
    yield from burst(E, 1)


# ============================================================================ P10: error messages
def p10(E, c, variant):
    e = E.eng
    yield from burst(E, 1)
    if variant == "storm":
        for i in range(200):
            n = E.msg(UP, "ERR_COR", "To Root Complex")
            if i < 2:
                E.key(n, "ERR_COR #%d" % (i + 1))
            yield 500 * US
    elif variant == "advisory":
        n, c_ = yield from E.mmio_rd(E.nv.bar0 + 0x4000, 1, status="UR")
        E.key(c_, "UR completion")
        yield 200 * NS
        E.key(E.msg(UP, "ERR_COR", "To Root Complex"), "UR signalled as Advisory Non-Fatal (ERR_COR)")
    elif variant == "internal_cor":
        E.key(E.msg(UP, "ERR_COR", "To Root Complex"), "ERR_COR with no link-visible cause")
        yield 2 * MS
        yield from E.cfg_rd(0x110, 0x00004000)
    elif variant == "hdr_overflow":
        for i in range(6):
            r = {}
            yield from E.write(1, f={"ep_data": True, "status": (0, 0x04, 0), "data_even_if_error": True}, out=r)
            E.key(E.msg(UP, "ERR_NONFATAL", "To Root Complex"), "ERR_NONFATAL #%d (poisoned TLP)" % (i + 1))
        yield from E.cfg_rd(0x118, 0x000003FF)
    elif variant == "undefined":
        n, c_ = yield from E.cfg_rd(0x104, 0x00000001)
        E.key(c_, "Uncorrectable Error Status bit 0 (Undefined / legacy Training Error) set")
    elif variant == "dlp":
        dma_read_stream(E, 2)
        n = e.dllp(DN, "ACK", seq=(e.psn[UP] + 100) & 0xFFF)
        E.key(n, "Ack for a PSN never transmitted: Data Link Protocol Error")
        yield 500 * NS
        E.key(E.msg(UP, "ERR_FATAL", "To Root Complex"), "ERR_FATAL")
        yield 1 * MS
        yield from full_recover(E, reason="fatal DLP error")
        return
    elif variant == "internal_uncor":
        E.key(E.msg(UP, "ERR_FATAL", "To Root Complex"), "ERR_FATAL with no link-level cause")
        yield 1 * MS
        n, c_ = yield from E.cfg_rd(0x104, 0x00400000)
        E.key(c_, "UESta bit 22 Uncorrectable Internal Error")
        yield from full_recover(E, reason="uncorrectable internal error")
        return
    elif variant == "cleared":
        E.msg(UP, "ERR_COR", "To Root Complex")
        yield 3 * MS
        yield from E.cfg_rd(0x110, 0x00000040)
        n, c_ = yield from E.cfg_wr(0x110, 0x00000040)
        E.key(n, "AER Correctable Status cleared (write-1-to-clear) before the snapshot")
    elif variant == "irq_storm":
        for i in range(400):
            E.msi(1 + i % 4)
            yield 250 * NS
        E.key(e.pkt - 1, "interrupt storm")
    elif variant == "reporter":
        n = E.eng.tlp(DN, "MWr(32)", 1, rid=HOST_RID, tag=0, addr=E.nv.bar0 + 0x2000 + 12,
                      payload=bytes(4), bad_lcrc=True)[0]
        E.key(n, "root port transmits a bad TLP; the SSD Naks and reports ERR_COR")
        yield 400 * NS
        e.flush(e.now)
        e.replay(DN)
        E.key(E.msg(UP, "ERR_COR", "To Root Complex"), "the SSD is the reporter, not the cause")
    elif variant == "masked":
        n, c_ = yield from E.cfg_wr(0x114, 0x000000C0)
        E.key(n, "AER Correctable Error Mask: Bad TLP + Bad DLLP masked")
        yield 2 * MS
        n = E.eng.tlp(DN, "MWr(32)", 1, rid=HOST_RID, tag=0, addr=E.nv.bar0 + 0x2000 + 12,
                      payload=bytes(4), bad_lcrc=True)[0]
        E.key(n, "bad TLP; Nak follows but no ERR_COR is sent")
        yield 400 * NS
        e.flush(e.now)
        e.replay(DN)
        yield 2 * MS
        yield from E.cfg_wr(0x114, 0x00002000)
    E.log("p10", card=c["id"], variant=variant)
    yield from burst(E, 1)


# ============================================================================ P11: TLP formatting
def p11(E, c, variant):
    e = E.eng
    yield from burst(E, 1)
    r = {}
    if variant in ("poison", "poison_accepted"):
        if variant == "poison":
            yield from E.write(1, f={"ep_data": True, "status": (0, 0x04, 0), "data_even_if_error": True}, out=r)
            yield 200 * NS
            E.key(E.msg(UP, "ERR_COR", "To Root Complex"), "Poisoned TLP Received (advisory)")
            k(E, r, "pkt_cqe", "CQE Data Transfer Error: poisoned data not committed")
        else:
            yield from E.write(1, f={"ep_data": True}, out=r)
            k(E, r, "pkt_cqe", "CQE status 0 after a poisoned CplD: poisoned data committed")
        k(E, r, "pkt_poisoned", "CplD with EP=1")
    elif variant in ("malformed", "oversize", "mps_mismatch"):
        if variant == "mps_mismatch":
            n, _ = yield from E.cfg_wr(0x078, 0x00102810)
            E.key(n, "Device Control MPS programmed to 128 B")
        base = E.alloc(1)[0]
        ln = 128 if variant != "malformed" else 64
        nb = 512 if variant != "malformed" else 260
        n = e.tlp(UP, "MWr(64)" if base >= 1 << 32 else "MWr(32)", ln, rid=SSD_RID, tag=0, addr=base,
                  payload=E.data(0x900000, 0, nb))[0]
        E.key(n, "MWr payload %d B (Length %d) breaks MPS / length rules: Malformed TLP" % (nb, ln))
        yield 5 * US
        yield from full_recover(E, reason="malformed TLP (fatal) -> DPC/SBR")
        return
    elif variant in ("ecrc_up", "ecrc_dn"):
        n, _ = yield from E.cfg_wr(0x118, 0x000001E0)
        base = E.alloc(1)[0]
        for i in range(3):
            if variant == "ecrc_up":
                x = e.tlp(UP, "MWr(64)" if base >= 1 << 32 else "MWr(32)", 64, rid=SSD_RID, tag=0,
                          addr=base + i * 256, payload=E.data(0x910000, i * 256, 256), td=True, bad_ecrc=(i == 1))[0]
            else:
                x = e.tlp(DN, "MWr(32)", 1, rid=HOST_RID, tag=0, addr=E.nv.bar0 + 0x2000 + 16 * i + 12,
                          payload=bytes(4), td=True, bad_ecrc=(i == 1))[0]
            if i == 1:
                E.key(x, "TD=1 and ECRC mismatch")
            yield 100 * NS
        if variant == "ecrc_dn":
            yield 400 * NS
            E.key(E.msg(UP, "ERR_NONFATAL", "To Root Complex"), "ECRC Error reported by the SSD")
    elif variant == "egress_blocked":
        n = E.dev_mwr(E.alloc(1)[0], E.data(0x920000, 0, 256), ep=True)
        E.key(n, "poisoned MWr from the SSD (blocked at the root port egress)")
    elif variant == "mrrs":
        t = E.nv.next_dev_tag()
        a = E.alloc(1)[0]
        n = E.dev_mrd(a, 256, t)
        E.key(n, "MRd of 1024 B > MRRS 512 B")
        yield 800 * NS
        yield from E.host_cpld(t, a, E.data(0x930000, 0, 1024))
    elif variant == "cross4k":
        base = E.alloc(1)[0] + 0xF80
        n = E.dev_mwr(base, E.data(0x940000, 0, 256))
        E.key(n, "256 B MWr starting at ...F80 crosses a 4 KiB boundary")
    elif variant in ("rcb", "bytecnt"):
        t = E.nv.next_dev_tag()
        a = E.alloc(1)[0]
        E.dev_mrd(a, 128, t)
        yield 800 * NS
        pl = E.data(0x950000, 0, 512)
        if variant == "rcb":
            n1 = e.tlp(DN, "CplD", 25, rid=SSD_RID, tag=t, cid=RC_CPL_ID, bytecnt=512, lwr=0, payload=pl[:100])[0]
            E.key(n1, "first CplD ends at byte 100: not on a 64 B RCB boundary")
            e.tlp(DN, "CplD", 103, rid=SSD_RID, tag=t, cid=RC_CPL_ID, bytecnt=412, lwr=100, payload=pl[100:])
        else:
            e.tlp(DN, "CplD", 64, rid=SSD_RID, tag=t, cid=RC_CPL_ID, bytecnt=512, lwr=0, payload=pl[:256])
            n2 = e.tlp(DN, "CplD", 64, rid=SSD_RID, tag=t, cid=RC_CPL_ID, bytecnt=512, lwr=0, payload=pl[256:])[0]
            E.key(n2, "second CplD repeats Byte Cnt 512 and Lwr Addr 0x000")
        E.nv.dev_open_tags.discard(t)
    elif variant in ("ordering", "ro_ok"):
        f = {"data_after_cqe": 1} if variant == "ordering" else {"data_attr": "RO", "data_after_cqe": 1}
        yield from E.read(1, nlb=15, f=f, out=r)
        k(E, r, "pkt_late_data", "data MWr after the CQE %s" % ("(no RO: ordering violation)" if variant == "ordering"
                                                                 else "(RO set: legal)"))
    elif variant == "nosnoop":
        yield from E.read(1, f={"data_attr": "NS"}, out=r)
        k(E, r, "pkt_cqe", "data MWr carried No Snoop on a coherent buffer")
    elif variant == "be":
        n = E.mmio_wr(E.nv.db(1), 0, length=2, fbe=0x5, lbe=0xF, payload=bytes(8))
        E.key(n, "MWr Length 2 with 1st BE 0101b (non-contiguous)")
    elif variant == "reserved":
        t = E.nv.next_dev_tag()
        a = E.alloc(1)[0]
        E.dev_mrd(a, 16, t)
        yield 800 * NS
        n = e.tlp(DN, "Cpl", 0, rid=SSD_RID, tag=t, cid=RC_CPL_ID, status="Reserved (0x3)", bytecnt=64)[0]
        E.key(n, "completion with a reserved Completion Status encoding")
        E.nv.dev_open_tags.discard(t)
    E.log("p11", card=c["id"], variant=variant)
    yield from burst(E, 1)


# ============================================================================ P12: link down / power
def p12(E, c, variant):
    e = E.eng
    nv = E.nv
    if variant in ("surprise", "sdes", "no_report", "rail", "sideband"):
        outs = [{} for _ in range(3)]
        for o in outs:
            E.sched.spawn(E.write(1, nlb=63, f={"no_cqe": True}, out=o))
            yield 3 * US
        yield 6 * US
        if variant == "sideband":
            E.key(e.event("CLKREQ# Deasserted"), "CLKREQ#/PERST# glitch while in L0")
        n = e.event("Electrical Idle")
        E.key(n, "electrical idle with no EIOS, no PM DLLP, no Hot Reset: uninitiated link down")
        e.event("Link Down", DN)
        e.event("Link Down", UP)
        E.sched.h.clear()
        nv.dev_open_tags.clear()
        yield from full_recover(E, how="power" if variant in ("rail", "sideband") else None,
                                down_ps=(300 * MS if variant == "rail" else 2 * SEC), reason=variant)
        if variant == "rail":
            n, c_ = yield from E.cfg_rd(0x004, 0x00100406)
    elif variant == "dpc":
        E.key(E.msg(UP, "ERR_FATAL", "To Root Complex"), "ERR_FATAL")
        yield 2 * US
        for _ in range(3):
            n = e.os(DN, "TS1", tc="0 1 0 0 0 0 00")
        E.key(n, "TS1 with Disable Link from the root port (DPC containment)")
        e.event("Link Down", DN)
        e.event("Link Down", UP)
        nv.dev_open_tags.clear()
        yield from full_recover(E, how=None, down_ps=500 * MS, reason="DPC release")
    elif variant == "orderly_removal":
        yield from E.controller_disable(2)
        E.msg(DN, "PME_Turn_Off", "Broadcast")
        yield 12 * US
        E.msg(UP, "PME_TO_Ack", "Gathered")
        for _ in range(2):
            e.dllp(UP, "PM_Enter_L23")
        e.dllp(DN, "PM_Request_Ack")
        n = e.os(DN, "TS1", tc="0 1 0 0 0 0 00")
        E.key(n, "orderly removal: quiesce, PME_Turn_Off handshake, Disable Link")
        e.event("Link Down", DN)
        yield from full_recover(E, how="power", down_ps=3 * SEC, reason="drive re-inserted")
    elif variant == "nssr":
        n = E.mmio_wr(nv.bar0 + 0x20, 0x4E564D65)
        E.key(n, "NSSR: 'NVMe' written to BAR0+0x20")
        e.event("Electrical Idle")
        e.event("Link Down", DN)
        yield from full_recover(E, how=None, down_ps=50 * MS, init=False, reason="NVM subsystem reset")
        m, _ = yield from E.mmio_rd(nv.bar0 + 0x1C, 1, 0x10)
        E.key(m, "CSTS.NSSRO=1 after the subsystem reset")
        yield from E.controller_init()
    elif variant in ("stuck_lp", "deepest_ps", "no_wake", "refclk"):
        if variant == "deepest_ps":
            yield from E.admin(0x09, cdw10=0x02, cdw11=4, note="Set Features Power State 4")
        yield from _aspm_entry(E)
        e.event("CLKREQ# Asserted")
        if variant == "refclk":
            yield 400 * US
            E.key(e.event("Electrical Idle Exit", UP), "device starts exit 400 us after CLKREQ# (refclk late)")
            yield from E.recovery(n_ts=2)
            yield from E.read(1)
            E.log("p12", card=c["id"], variant=variant)
            return
        yield 20 * US
        e.event("Electrical Idle Exit", DN)
        for _ in range(6):
            e.os(DN, "EIEOS")
            e.os(DN, "TS1")
        E.key(e.event("Link Down", DN), "no response from the device on wake (stuck in low power)")
        for _ in range(3):
            yield 300 * MS
            e.event("Receiver Detect: no device")
        yield from full_recover(E, how="power", reason="power cycle to recover device stuck in low power")
    elif variant in ("hot_reset_cut", "sbr_duration"):
        tag = nv.next_dev_tag()
        n = E.dev_mrd(E.alloc(1)[0], 128, tag)
        E.key(n, "read outstanding when the hot reset hits")
        yield 2 * US
        x = yield from hot_reset_link(E, reason=variant)
        E.key(x, "TS1 with Hot Reset bit from the root port")
        yield from full_recover(E, how=None, down_ps=(1 * SEC if variant == "sbr_duration" else 100 * MS),
                                reason=variant)
    elif variant == "sd_timeline":
        e.event("Electrical Idle")
        E.key(e.event("Link Down", DN), "surprise down")
        yield 1 * SEC
        e.event("Link Up", DN)
        yield from E.train(from_detect=True)
        yield 5 * SEC
        E.log("host_rescan_late", seconds=5)
        yield from E.enumerate(full=False)
        yield from E.controller_init()
    elif variant == "dpc_hang":
        outs = [{} for _ in range(4)]
        for o in outs:
            E.sched.spawn(E.read(2, f={"no_cqe": True, "media_lat": 50 * US}, out=o))
            yield 2 * US
        yield 10 * US
        for _ in range(3):
            n = e.os(DN, "TS1", tc="0 1 0 0 0 0 00")
        E.key(n, "DPC triggered in the root port: Disable Link; commands outstanding")
        e.event("Link Down", DN)
        E.sched.h.clear()
        yield from full_recover(E, how=None, down_ps=3 * SEC, reason="DPC")
    elif variant == "err_recovery":
        E.key(E.msg(UP, "ERR_NONFATAL", "To Root Complex"), "ERR_NONFATAL triggers pcie AER recovery")
        yield 5 * MS
        yield from E.cfg_rd(0x104, 0x00004000)
        x = yield from hot_reset_link(E, reason="slot_reset")
        yield from full_recover(E, how=None, down_ps=200 * MS, reason="error_detected/slot_reset/resume")
    E.log("p12", card=c["id"], variant=variant)


# ============================================================================ P19: configuration space
def p19(E, c, variant):
    e = E.eng
    nv = E.nv
    yield from burst(E, 1)
    if variant == "d3_early":
        n, _ = yield from E.cfg_wr(0x044, 0x00000003)
        yield 50 * MS
        n, _ = yield from E.cfg_wr(0x044, 0x00000000)
        E.key(n, "PMCSR D3hot -> D0")
        yield 2 * MS
        m, c_ = yield from E.mmio_rd(nv.bar0 + 0x1C, 1, status="UR")
        E.key(c_, "MMIO 2 ms after D0 (< 10 ms recovery): UR")
        yield 20 * MS
        yield from reset_controller(E, "after early access")
    elif variant == "flr_slow":
        n, _ = yield from E.cfg_wr(0x078, 0x00108830)
        E.key(n, "FLR initiated")
        nv.sq.clear()
        nv.cq.clear()
        yield 100 * MS
        for _ in range(4):
            m, c_ = yield from E.cfg_rd(0x000, 0, status="CRS")
            yield 100 * MS
        E.key(c_, "still CRS ~500 ms after FLR")
        yield from E.cfg_rd(0x000, 0x00101B36)
        yield from E.cfg_wr(0x004, 0x00100406)
        yield from E.controller_init()
    elif variant in ("acs_violation", "acs_p2p"):
        n = E.dev_mwr(0xFB000000, E.data(0xA00000, 0, 256))
        E.key(n, "peer-to-peer MWr to another device's BAR (0xFB000000)")
    elif variant == "ats":
        t = nv.next_dev_tag()
        n = e.tlp(UP, "MRd(64)", 2, rid=SSD_RID, tag=t, addr=0x200000000, at="01")[0]
        E.key(n, "Translation Request (AT=01) with ATS disabled")
        yield 800 * NS
        E.key(e.tlp(DN, "Cpl", 0, rid=SSD_RID, tag=t, cid=RC_CPL_ID, status="UR", bytecnt=8)[0], "UR")
        nv.dev_open_tags.discard(t)
    elif variant == "flr_unusable":
        n, _ = yield from E.cfg_wr(0x078, 0x00108830)
        nv.sq.clear()
        nv.cq.clear()
        yield 100 * MS
        yield from E.cfg_rd(0x000, 0x00101B36)
        yield from E.cfg_wr(0x004, 0x00100406)
        yield from E.controller_init(identify=False, create_io=False, aer=0)
        r = {}
        yield from E.admin(0x06, cdw10=1, xfer="d2h", f={"no_cqe": True}, out=r)
        k(E, r, "pkt_sqe", "config space looks fine after FLR but the controller never answers")
        yield ADMIN_TIMEOUT
        yield from full_recover(E, reason="FLR did not recover the function")
        return
    elif variant == "enum_delay":
        for r_ in range(0x000, 0x400, 4):
            yield from E.cfg_rd(r_, E.CFG.get(r_, 0))
            yield 1 * MS
        E.key(e.pkt - 1, "long configuration scan before the driver starts")
    elif variant == "early_access":
        yield from hot_reset_link(E)
        yield 20 * MS
        yield from E.train()
        yield 2 * MS
        for _ in range(3):
            m, c_ = yield from E.cfg_rd(0x000, 0, status="CRS")
            yield 5 * MS
        E.key(c_, "configuration access 2 ms after link up returns CRS")
        yield 100 * MS
        yield from E.enumerate(full=False)
        yield from E.controller_init()
    elif variant == "cap_chain":
        yield from E.cfg_rd(0x034, 0x40)
        m, c_ = yield from E.cfg_rd(0x040, 0x5BC30001)
        E.key(c_, "PM capability Next pointer = 0x00: PCIe and MSI-X capabilities unreachable")
    elif variant == "frs":
        n = E.msg(UP, "FRS", "To Root Complex")
        E.key(n, "FRS (function readiness) message")
        yield 100 * US
        m, c_ = yield from E.cfg_rd(0x000, 0, status="CRS")
        E.key(c_, "announced ready, still answers CRS")
        yield 50 * MS
        yield from E.cfg_rd(0x000, 0x00101B36)
    elif variant == "tph":
        n = e.tlp(UP, "MWr(64)", 64, rid=SSD_RID, tag=0, addr=0x200010000, payload=E.data(0xA10000, 0, 256), th=True)[0]
        E.key(n, "TH=1 while TPH Requester Enable is clear")
    elif variant == "prefix":
        t = nv.next_dev_tag()
        n = e.tlp(UP, "MRd(64)", 64, rid=SSD_RID, tag=t, addr=0x200020000, at="10")[0]
        E.key(n, "Translated request (AT=10) with ATS disabled")
        yield 800 * NS
        e.tlp(DN, "Cpl", 0, rid=SSD_RID, tag=t, cid=RC_CPL_ID, status="UR", bytecnt=256)
        nv.dev_open_tags.discard(t)
    E.log("p19", card=c["id"], variant=variant)
    yield from burst(E, 1)


# ============================================================================ P20: PM / LTR / OBFF
def p20(E, c, variant):
    e = E.eng
    nv = E.nv
    yield from burst(E, 1)
    if variant in ("rtd3_slow", "d3_delay"):
        yield from E.cfg_wr(0x044, 0x00000003)
        yield from _aspm_entry(E)
        yield 2 * SEC
        e.event("CLKREQ# Asserted")
        yield 30 * US
        e.event("Electrical Idle Exit")
        yield from E.recovery(n_ts=2)
        if variant == "d3_delay":
            yield 80 * MS
        n, _ = yield from E.cfg_wr(0x044, 0x00000000)
        E.key(n, "PMCSR -> D0 (runtime resume)")
        yield 10 * MS
        yield from E.controller_disable(1)
        if variant == "rtd3_slow":
            yield 2400 * MS
        yield from E.controller_init(rdy_polls=25 if variant == "rtd3_slow" else 2)
        E.key(e.pkt - 1, "controller ready long after resume (RTD3R exceeded)" if variant == "rtd3_slow"
              else "resume delay outside link wake")
    elif variant in ("l12_slow", "l1ss_exit", "wake_spike", "apst_aspm"):
        exit_lat = {"l12_slow": 380 * US, "l1ss_exit": 150 * US, "wake_spike": 60 * US, "apst_aspm": 30 * US}[variant]
        yield from E.aspm_l1(4 * MS, exit_lat=exit_lat)
        E.key(e.pkt - 1, "L1.2 exit %d us (LTR advertised 1 us snoop latency)" % (exit_lat // US))
        r = {}
        ml = 25 * MS if variant == "wake_spike" else (9 * MS if variant == "apst_aspm" else None)
        yield from E.read(1, f={"media_lat": ml} if ml else None, out=r)
        k(E, r, "pkt_cqe", "first command after wake")
    elif variant == "d3cold_absent":
        E.msg(DN, "PME_Turn_Off", "Broadcast")
        yield 12 * US
        E.msg(UP, "PME_TO_Ack", "Gathered")
        e.dllp(UP, "PM_Enter_L23")
        e.dllp(DN, "PM_Request_Ack")
        e.event("Electrical Idle")
        e.event("Link Down", DN)
        e.event("CLKREQ# Deasserted")
        yield 5 * SEC
        e.event("CLKREQ# Asserted")
        for _ in range(4):
            yield 500 * MS
            E.key(e.event("Receiver Detect: no device"), "device absent after D3cold power-up")
        yield from full_recover(E, how="power", reason="second power-up after D3cold")
        return
    elif variant == "pme_no_ack":
        n = E.msg(DN, "PME_Turn_Off", "Broadcast")
        E.key(n, "PME_Turn_Off with no PME_TO_Ack from the SSD")
        yield 10 * MS
        e.dllp(UP, "PM_Enter_L1")
        e.os(UP, "EIOS")
        E.key(e.event("Electrical Idle", UP), "PM_Enter_L1 then idle without PM_Request_Ack")
        yield 100 * US
        e.event("Electrical Idle Exit")
        yield from E.recovery(n_ts=2)
    elif variant == "obff":
        n = E.msg(DN, "OBFF", "Broadcast")
        E.key(n, "OBFF message while OBFF Enable = 0")
    elif variant == "ltr":
        for i in range(3):
            n = E.ltr(snoop_val=1, snoop_scale=2, ns_val=1, ns_scale=2)
            if i == 0:
                E.key(n, "LTR 1 us with Requirement=1 while idle")
            yield 2 * SEC
    E.log("p20", card=c["id"], variant=variant)
    yield from burst(E, 1)


# ============================================================================ P21: rare messages
def p21(E, c, variant):
    e = E.eng
    yield from burst(E, 1)
    if variant == "pri":
        for i in range(3):
            n = E.msg(UP, "Page_Request", "To Root Complex", data=bytes(8))
            if i == 0:
                E.key(n, "Page Request with no PRG Response")
            yield 5 * MS
    elif variant == "smbus":
        for sa, rw in ((0x6A, "Write"), (0x6A, "Read"), (0x6A, "Read")):
            r = e.blank()
            from tracegen_core import COL
            r[COL["Slave Address"]] = "0x%02X" % sa
            r[COL[rw]] = "1"
            r[COL["Byte Count"]] = "8"
            r[COL["PEC"]] = "0x%02X" % E.rng.randrange(256)
            e.now = max(e.now, e.last_t) + 100 * US
            n = e._write(r, e.now, 0, None)
            yield 200 * US
        E.key(n, "NVMe-MI over SMBus (BMC) traffic; SMBus columns populated")
        yield 50 * MS
        yield from full_recover(E, reason="BMC-initiated NVMe-MI reset")
        return
    elif variant == "slot_power":
        n = E.msg(DN, "Set_Slot_Power_Limit", "Local", data=bytes(4))
        E.key(n, "Set_Slot_Power_Limit with value 0 W")
    elif variant == "ptm":
        for i in range(3):
            n = E.msg(UP, "PTM_Request", "Local")
            if i == 0:
                E.key(n, "PTM Request with no PTM Response/ResponseD")
            yield 1 * MS
    elif variant == "routing":
        n = E.msg(UP, "PME_Turn_Off", "Broadcast")
        E.key(n, "endpoint transmits a downstream-only broadcast message")
    E.log("p21", card=c["id"], variant=variant)
    yield from burst(E, 1)


# ============================================================================ P22: performance
def p22(E, c, variant):
    e = E.eng
    if variant == "exit_lat":
        yield from E.aspm_l1(50 * MS)
        r = {}
        yield from E.read(1, f={"media_lat": 25 * MS}, out=r)
        k(E, r, "pkt_cqe", "read after idle completes after 25 ms (NVMe power-state exit)")
    elif variant in ("hmb", "media_retry", "cpu_bound", "misaligned", "numa", "drift", "sched", "affinity"):
        lat = {"hmb": 180 * US, "media_retry": 3 * MS, "cpu_bound": None, "misaligned": None, "numa": None,
               "drift": None, "sched": None, "affinity": None}[variant]
        for i in range(24):
            f = {}
            if lat and (variant != "media_retry" or i % 6 == 0):
                f["media_lat"] = lat
            if variant == "misaligned":
                yield from E.write(1, slba=E.next_lba(0) + 1, nlb=0, f={"cqe_delay": 600 * US})
            else:
                yield from E.read(1, f=f or None)
            yield (50 * US if variant in ("cpu_bound", "sched") else 2 * US)
    elif variant in ("tail", "outliers", "mean_hides"):
        for i in range(60):
            f = {"media_lat": 48 * MS} if i in (17, 44) else None
            E.sched.spawn(E.read(E.rng.choice((1, 2, 3, 4)), f=f))
            yield E.rng.randint(20, 60) * US
        yield 50 * MS
        E.key(e.pkt - 1, "latency outliers 48 ms in a window of ~80 us reads")
    elif variant in ("gc", "maintenance"):
        for i in range(4):
            yield from burst(E, 16, qd=16, rw=0.0, f={"cqe_delay": 9 * MS} if i % 2 else None)
        E.key(e.pkt - 1, "9 ms completion gaps with commands open (GC / maintenance)")
    elif variant in ("thermal", "thermal_cycle"):
        for i in range(6):
            yield from burst(E, 8, qd=8, f={"media_lat": (60 + 60 * i) * US})
        E.key(e.pkt - 1, "throughput falls step-wise (throttling)")
    elif variant in ("cliff", "slc"):
        for i in range(20):
            yield from E.write(1, nlb=255, f={"cqe_delay": (15 if i < 10 else 900) * US})
        E.key(e.pkt - 1, "write latency jumps from ~15 us to ~900 us")
    elif variant == "flush_slow":
        r = {}
        yield from E.write(1)
        yield from E.flush_cmd(1, lat=2500 * MS)
        E.key(e.pkt - 2, "Flush takes 2.5 s")
    elif variant == "below_link":
        for i in range(30):
            yield from E.read(1, nlb=255)
        E.key(e.pkt - 1, "QD1 128 KiB reads: link mostly idle between commands")
    elif variant == "qd_collapse":
        yield from burst(E, 256, qd=256, rw=1.0, sizes=(7,), f={"media_lat": 2 * MS})
    elif variant == "small_mps":
        n, _ = yield from E.cfg_wr(0x078, 0x00102810)
        E.key(n, "Device Control MPS = 128 B")
        for i in range(6):
            yield from E.read(1, nlb=63, f={"data_mps": 128})
        yield from E.cfg_wr(0x078, 0x00102830)
    elif variant == "flush_heavy":
        for i in range(10):
            yield from E.write(1, f={"cqe_delay": 900 * US})
            yield from E.flush_cmd(1, lat=20 * US)
    elif variant == "selftest_blocks":
        yield from E.admin(0x14, cdw10=1, nsid=0xFFFFFFFF)
        r = {}
        yield from E.read(1, f={"media_lat": 400 * MS}, out=r)
        k(E, r, "pkt_cqe", "I/O stalled 400 ms while self-test runs")
    elif variant == "ns_discovery":
        for ns in range(1, 33):
            yield from E.nvme_cmd(0, 0x06, ns, 0, 0, "d2h", nbytes=4096, cdw10=0, cdw12=0)
    elif variant == "hol":
        E.sched.spawn(E.write(1, nlb=2047))
        yield 5 * US
        r = {}
        yield from E.read(1, out=r)
        k(E, r, "pkt_cqe", "small read waits behind a 1 MiB write")
    elif variant == "telemetry_poll":
        for i in range(10):
            yield from burst(E, 4, qd=4)
            yield from E.admin(0x02, cdw10=(127 << 16) | 0x02, xfer="d2h", nbytes=512, nsid=0xFFFFFFFF)
    elif variant == "milestone":
        yield from burst(E, 8, qd=4)
    E.log("p22", card=c["id"], variant=variant)


# ============================================================================ P27: capture integrity
def p27(E, c, variant):
    e = E.eng
    if variant == "segment_end":
        outs = [{} for _ in range(4)]
        for o in outs:
            E.sched.spawn(E.read(1, f={"media_lat": 300 * MS}, out=o))
        yield 50 * US
        n = e.event("Recording paused (segment end)", marker="Segment End")
        E.key(n, "segment ends with 4 commands open: open at EOF, not timeouts")
        e.hide_all = True
        yield 400 * MS
        e.drain()
        e.hide_all = False
        e.event("Recording resumed", marker="Segment Start")
    elif variant == "align":
        e.marker("ALIGN: host nvme get-feature -f 7 at 14:03:22.118")
        r = {}
        yield from E.admin(0x0A, cdw10=0x07, out=r)
        k(E, r, "pkt_sqe", "alignment marker row for host/analyzer clock correlation")
    elif variant == "trigger":
        e.marker("Trigger")
        E.key(e.pkt, "trigger after the fault onset; pre-trigger window too short")
        E.msg(UP, "ERR_NONFATAL", "To Root Complex")
    elif variant == "precision":
        dma_read_stream(E, 40)
        E.key(e.pkt - 1, "40 back-to-back rows with Time Delta 0.000 ns")
    else:
        yield from burst(E, 6, qd=4)
    E.log("p27", card=c["id"], variant=variant)
    yield from burst(E, 1)


# ============================================================================ context-only cards
def context(E, c, what="io", note=""):
    """Card not (or only partly) visible on the probed link: emit the honest wire context only."""
    if what == "keepalive":
        for _ in range(3):
            yield from E.admin(0x18, note="Keep Alive")
            yield 1 * SEC
    elif what == "security":
        yield from E.admin(0x82, cdw10=0x01000100, xfer="d2h", nbytes=512)
        yield from E.admin(0x81, cdw10=0x01000100, xfer="h2d", nbytes=512)
    elif what == "preboot":
        yield from reset_controller(E, "OS driver takes over from UEFI")
    elif what == "host_stall":
        yield 2 * SEC
        yield from burst(E, 16, qd=16)
    elif what == "abort_limit":
        outs = [{} for _ in range(4)]
        for o in outs:
            E.sched.spawn(E.read(2, f={"media_lat": 3 * MS}, out=o))
            yield 2 * US
        for o in outs:
            E.sched.spawn(abort_cmd(E, 2, o.get("cid", 1), exec_lat=3 * MS, dw0=1))
            yield 2 * US
        yield 4 * MS
    elif what == "tc":
        for i in range(4):
            E.eng.tlp(UP, "MWr(64)", 64, rid=SSD_RID, tag=0, addr=0x210000000 + i * 256,
                      payload=E.data(0xB00000, i * 256, 256), tc=1)
            yield 200 * NS
    elif what == "reset_cascade":
        yield from reset_controller(E, "recovery cascade")
    elif what == "ide":
        E.key(E.msg(UP, "ERR_NONFATAL", "To Root Complex"), "IDE Check Failed reported as uncorrectable")
    elif what == "aen_internal":
        aen = yield from E.post_aen(0x00010300, then_log=0x01)
        E.key(aen, "AEN Persistent Internal Error")
    else:
        yield from burst(E, 6, qd=4)
    E.log("context_only", card=c["id"], what=what, note=note)


# ============================================================================ registry
def build_registry():
    R = {}

    def add(fn, ids, **kw):
        for i in ids.split():
            R[i] = (fn, kw)

    for cid, (q, opc, xfer, sct, sc, dnr, fl) in P01_TABLE.items():
        R[cid] = (p01, dict(q=q, opc=opc, xfer=xfer, sct=sct, sc=sc, dnr=dnr, flavour=fl))
    add(host_generated_status, "S-16", sct=0, sc=0x19)
    add(host_generated_status, "S-22", sct=0, sc=0x22)
    add(host_generated_status, "S-53", sct=1, sc=0x80)
    add(host_generated_status, "S-68", sct=3, sc=0x70)
    add(host_generated_status, "S-69", sct=3, sc=0x71)
    for cid in "S-78 S-79 S-80 S-81 S-82 S-83 S-84 S-85".split():
        R[cid] = (p26, dict(variant="aen"))
    add(p13, "C-13", variant="crto_inconsistent")
    # P02
    add(p02, "T-01 T-09", variant="abort_hang")
    add(p02, "T-22 C-14", variant="abort_ok")
    add(p02, "T-23 C-08", variant="admin_reset")
    add(p02, "T-25", variant="timeout_in_reset")
    add(p02, "D-30", variant="polled")
    add(p02, "M-001", variant="fetch_gap")
    add(p02, "M-003", variant="fetch_nodata")
    add(p02, "M-004", variant="late_cqe")
    add(p02, "M-005", variant="late_cqe_noto")
    add(p02, "M-009", variant="admin_starve")
    add(p02, "M-015", variant="late_data")
    add(p02, "M-035", variant="abort_race")
    add(p02, "M-067", variant="qd_saturation")
    add(p02, "M-068", variant="long_admin_timeout")
    add(p02, "M-083", variant="long_admin_ok")
    add(p02, "T-11", variant="format_timeout")
    # P03
    add(p03, "T-33 L-14", variant="cto")
    add(p03, "N-03", variant="cto_fabric")
    add(p03, "T-34", variant="cto_disabled")
    add(p03, "M-002", variant="sqe_fetch")
    add(p03, "M-016", variant="split_stall")
    add(p03, "M-017", variant="posted_drain")
    add(p03, "M-045", variant="deep_tail")
    add(p03, "M-090", variant="across_reset")
    # P04
    add(p04, "T-41", variant="crs_long")
    add(p04, "L-30", variant="crs_forever")
    add(p04, "L-20", variant="ur_mmio")
    add(p04, "L-15", variant="ca_dma")
    add(p04, "L-36", variant="ur_iommu")
    add(p04, "L-31", variant="bar_unassigned")
    add(p04, "C-16", variant="all_ones")
    add(p04, "N-38", variant="wrong_completer")
    add(p04, "N-45", variant="vdm")
    add(p04, "N-49", variant="ignored_msg")
    add(p04, "N-50", variant="atomic")
    add(p04, "N-54", variant="io_request")
    # P05
    add(p05, "L-16 V-31", variant="unexpected")
    add(p05, "V-32", variant="tag_reuse")
    add(p05, "L-40", variant="tag10")
    add(p05, "M-088", variant="prestart")
    add(p05, "N-46", variant="wrong_rid")
    # P06
    add(p06, "L-02 X-15 V-35", variant="nak")
    add(p06, "M-021", variant="latency_only")
    add(p06, "L-03 X-16", variant="bad_dllp")
    add(p06, "L-04 T-36 X-19", variant="rollover")
    add(p06, "L-05 T-35", variant="replay_timer")
    add(p06, "T-37 X-20", variant="ack_late")
    add(p06, "X-17", variant="seq_gap")
    add(p06, "X-18 M-043", variant="nak_storm")
    add(p06, "X-23 V-36", variant="flit_crc")
    add(p06, "X-24", variant="wrong_nak")
    add(p06, "M-089", variant="replay_dup_cqe")
    # P07
    add(p07, "T-38 X-22", variant="starve")
    add(p07, "M-019", variant="vc")
    add(p07, "M-020", variant="slow_return")
    add(p07, "X-21", variant="violation")
    add(p07, "L-17", variant="overflow")
    add(p07, "L-13", variant="fcpe")
    add(p07, "N-53", variant="initfc_stall")
    # P08
    add(p08, "T-39 X-13", variant="eq_fail")
    add(p08, "M-023", variant="eq_retry")
    add(p08, "T-40", variant="slow_up")
    add(p08, "T-45", variant="aspm_exit")
    add(p08, "L-25 P-11", variant="narrow")
    add(p08, "X-07", variant="lane_skew")
    add(p08, "X-08", variant="reversal")
    add(p08, "L-26 X-11", variant="storm")
    add(p08, "M-074", variant="power_flap")
    add(p08, "L-39", variant="no_dlactive")
    add(p08, "L-37", variant="aspm_drop")
    add(p08, "X-04", variant="malformed_os")
    add(p08, "X-09", variant="speed_change_live")
    add(p08, "X-12", variant="compliance")
    add(p08, "X-14", variant="ei_glitch")
    add(p08, "X-25", variant="not_top")
    add(p08, "M-022", variant="dwell")
    add(p08, "M-072", variant="bw_drop")
    add(p08, "M-073", variant="lnksta")
    add(p08, "M-092", variant="perf_baseline")
    add(p08, "N-41", variant="margining")
    # P09
    add(p09, "X-01", variant="symbol")
    add(p09, "X-02", variant="disparity")
    add(p09, "X-03", variant="sync")
    add(p09, "L-01", variant="receiver_err")
    add(p09, "X-05", variant="framing")
    add(p09, "X-06", variant="nullified")
    add(p09, "X-10", variant="skp")
    add(p09, "X-27", variant="probe_si")
    add(p09, "X-28", variant="relock")
    add(p09, "X-29", variant="setup")
    add(p09, "X-30 M-049", variant="wrap")
    add(p09, "M-048", variant="filter")
    # P10
    add(p10, "X-26", variant="storm")
    add(p10, "L-06", variant="advisory")
    add(p10, "L-07", variant="internal_cor")
    add(p10, "L-08", variant="hdr_overflow")
    add(p10, "L-09", variant="undefined")
    add(p10, "L-10", variant="dlp")
    add(p10, "L-22", variant="internal_uncor")
    add(p10, "M-044", variant="cleared")
    add(p10, "M-095", variant="irq_storm")
    add(p10, "M-099", variant="reporter")
    add(p10, "N-11", variant="masked")
    # P11
    add(p11, "L-12", variant="poison")
    add(p11, "L-38 V-37", variant="poison_accepted")
    add(p11, "L-18", variant="malformed")
    add(p11, "V-26", variant="oversize")
    add(p11, "L-32", variant="mps_mismatch")
    add(p11, "L-19", variant="ecrc_up")
    add(p11, "V-34", variant="ecrc_dn")
    add(p11, "L-23", variant="egress_blocked")
    add(p11, "V-27", variant="mrrs")
    add(p11, "V-28", variant="cross4k")
    add(p11, "V-29", variant="rcb")
    add(p11, "V-30", variant="bytecnt")
    add(p11, "V-33", variant="ordering")
    add(p11, "M-071", variant="ro_ok")
    add(p11, "N-05", variant="nosnoop")
    add(p11, "N-37", variant="be")
    add(p11, "N-52", variant="reserved")
    # P12
    add(p12, "T-44 L-29", variant="surprise")
    add(p12, "L-11", variant="sdes")
    add(p12, "L-27", variant="no_report")
    add(p12, "N-06", variant="rail")
    add(p12, "N-07", variant="sideband")
    add(p12, "L-28", variant="dpc")
    add(p12, "C-05", variant="nssr")
    add(p12, "C-07 T-15", variant="stuck_lp")
    add(p12, "C-22", variant="deepest_ps")
    add(p12, "M-024", variant="refclk")
    add(p12, "M-038", variant="hot_reset_cut")
    add(p12, "M-040", variant="sbr_duration")
    add(p12, "M-041", variant="sd_timeline")
    add(p12, "M-042", variant="dpc_hang")
    add(p12, "C-18", variant="err_recovery")
    # P13
    add(p13, "T-02 C-02", variant="rdy_never")
    add(p13, "T-03", variant="crto")
    add(p13, "T-04 C-03", variant="rdy_stuck_1")
    add(p13, "T-05 C-04", variant="shutdown_stuck")
    add(p13, "T-10", variant="fw_pp")
    add(p13, "C-12", variant="fw_pp_never")
    add(p13, "T-31 C-27", variant="early_csts")
    add(p13, "C-01 S-90", variant="cfs")
    add(p13, "C-06", variant="cfs_loop")
    add(p13, "M-031", variant="cfs_missed")
    add(p13, "S-91", variant="nssro")
    add(p13, "C-17", variant="dead")
    add(p13, "C-20", variant="no_ioq")
    add(p13, "C-28", variant="flr_unusable")
    add(p13, "M-030", variant="admin_stall_after_rdy")
    add(p13, "M-036", variant="partial_queues")
    add(p13, "M-075", variant="first_io_slow")
    add(p13, "M-100", variant="dll_up_no_resume")
    add(p13, "N-32", variant="spontaneous_reset")
    # P14
    add(p14, "V-01", variant="sq_beyond")
    add(p14, "V-02", variant="cq_beyond")
    add(p14, "V-03 C-09", variant="no_queue")
    add(p14, "V-04", variant="partial")
    add(p14, "V-05", variant="backwards")
    add(p14, "V-06", variant="cq_past")
    add(p14, "V-07", variant="cq_overflow")
    add(p14, "V-12", variant="shadow")
    add(p14, "M-007", variant="head_lag")
    add(p14, "M-008", variant="occupancy")
    add(p14, "M-013", variant="batching")
    add(p14, "M-014", variant="late_doorbell")
    add(p14, "M-069", variant="stride")
    # P15
    add(p15, "D-28", variant="wrong_cid")
    add(p15, "D-29", variant="dup")
    add(p15, "C-19 V-09", variant="stale")
    add(p15, "V-08", variant="cid_reuse")
    add(p15, "V-10", variant="wrong_sqid")
    add(p15, "V-11", variant="phase")
    add(p15, "M-065", variant="reset_reuse")
    add(p15, "M-066", variant="parser_wrap")
    # P16
    add(p16, "V-13", variant="cqe_before_data")
    add(p16, "V-14", variant="msix_first")
    add(p16, "V-15 C-15", variant="no_msix")
    add(p16, "T-21", variant="polled")
    add(p16, "L-35", variant="misrouted")
    add(p16, "C-25", variant="msi_never")
    add(p16, "V-16", variant="dma_after_cqe")
    add(p16, "P-08", variant="storm")
    add(p16, "M-006", variant="sw_late")
    add(p16, "M-010", variant="moderation")
    add(p16, "M-011", variant="masked")
    add(p16, "M-012", variant="poll_transition")
    add(p16, "M-070", variant="ordering_visibility")
    add(p16, "N-36", variant="intx")
    # P17
    add(p17, "D-31", variant="outside")
    add(p17, "D-32", variant="dsm_overread")
    add(p17, "C-26", variant="addr48")
    add(p17, "M-061", variant="wrong_target")
    add(p17, "M-062", variant="iommu_delay")
    add(p17, "M-064", variant="vf")
    add(p17, "N-10", variant="gpa")
    add(p17, "N-15", variant="bounce")
    add(p17, "N-29", variant="vf_rid")
    # P18
    add(p18, "V-17", variant="prp1_align")
    add(p18, "V-18", variant="prp2_off")
    add(p18, "V-19", variant="prp_list")
    add(p18, "V-20", variant="mdts")
    add(p18, "V-21", variant="reserved")
    add(p18, "V-22", variant="fuse")
    add(p18, "V-23", variant="admin_on_io")
    add(p18, "V-24", variant="sgl")
    add(p18, "V-25", variant="create_params")
    add(p18, "N-20", variant="aen_rae")
    add(p18, "N-21", variant="arbitration")
    add(p18, "N-26", variant="metadata")
    add(p18, "N-33", variant="log_short")
    add(p18, "N-55", variant="nsid_bcast")
    add(p18, "N-56", variant="wz_limit")
    add(p18, "N-58", variant="effects")
    # P19
    add(p19, "T-42", variant="d3_early")
    add(p19, "T-43", variant="flr_slow")
    add(p19, "L-21", variant="acs_violation")
    add(p19, "L-33", variant="acs_p2p")
    add(p19, "L-34", variant="ats")
    add(p19, "M-039", variant="flr_unusable")
    add(p19, "M-076", variant="enum_delay")
    add(p19, "M-091", variant="early_access")
    add(p19, "N-35", variant="cap_chain")
    add(p19, "N-43", variant="frs")
    add(p19, "N-44", variant="tph")
    add(p19, "N-51", variant="prefix")
    # P20
    add(p20, "T-06", variant="rtd3_slow")
    add(p20, "M-026", variant="d3_delay")
    add(p20, "T-46", variant="l12_slow")
    add(p20, "M-025", variant="l1ss_exit")
    add(p20, "P-07", variant="wake_spike")
    add(p20, "M-054", variant="apst_aspm")
    add(p20, "N-08", variant="d3cold_absent")
    add(p20, "N-39", variant="pme_no_ack")
    add(p20, "N-47", variant="obff")
    add(p20, "N-48", variant="ltr")
    # P21
    add(p21, "M-063", variant="pri")
    add(p21, "N-02", variant="smbus")
    add(p21, "N-40", variant="slot_power")
    add(p21, "N-42", variant="ptm")
    add(p21, "N-57", variant="routing")
    # P22
    add(p22, "T-14", variant="exit_lat")
    add(p22, "T-16", variant="hmb")
    add(p22, "D-17", variant="media_retry")
    add(p22, "P-09", variant="cpu_bound")
    add(p22, "P-13", variant="misaligned")
    add(p22, "P-10", variant="numa")
    add(p22, "M-080", variant="drift")
    add(p22, "M-094", variant="sched")
    add(p22, "M-096", variant="affinity")
    add(p22, "T-47 P-03", variant="tail")
    add(p22, "M-081", variant="mean_hides")
    add(p22, "M-082 M-086", variant="milestone")
    add(p22, "T-48 P-05 M-056", variant="gc")
    add(p22, "M-098", variant="maintenance")
    add(p22, "T-49 P-06", variant="thermal")
    add(p22, "M-055", variant="thermal_cycle")
    add(p22, "T-50", variant="cliff")
    add(p22, "P-04", variant="slc")
    add(p22, "T-51", variant="flush_slow")
    add(p22, "P-01", variant="below_link")
    add(p22, "P-02", variant="qd_collapse")
    add(p22, "P-12", variant="small_mps")
    add(p22, "P-14", variant="flush_heavy")
    add(p22, "M-033", variant="selftest_blocks")
    add(p22, "M-037", variant="ns_discovery")
    add(p22, "M-057", variant="hol")
    add(p22, "M-097", variant="telemetry_poll")
    # P23
    add(p23, "D-01 D-03", variant="dealloc_old")
    add(p23, "D-02", variant="dealloc_partial")
    add(p23, "D-06", variant="dealloc_far")
    add(p23, "D-04", variant="discard_dropped")
    add(p23, "D-05 C-23", variant="wz_not_zero")
    add(p23, "D-13", variant="lost_write")
    add(p23, "D-14", variant="misdirected")
    add(p23, "D-15", variant="stale")
    add(p23, "D-16", variant="bitflip")
    add(p23, "D-18", variant="sanitize_left")
    add(p23, "D-19", variant="crypto_left")
    add(p23, "D-20", variant="format_left")
    add(p23, "D-21", variant="pi_unchecked")
    add(p23, "D-22 C-24", variant="dup_ids")
    add(p23, "D-23", variant="identify_wrong")
    add(p23, "D-24 D-07", variant="capacity")
    add(p23, "D-25", variant="smart_frozen")
    add(p23, "S-93", variant="smart_creep")
    add(p23, "D-26", variant="fw_still_old")
    add(p23, "D-27", variant="zns_wp")
    add(p23, "D-33", variant="verify_fast")
    add(p23, "N-23", variant="zone_append")
    add(p23, "N-27", variant="copy")
    # P24
    add(p24, "D-08 D-10", variant="flush_lies")
    add(p24, "D-09", variant="fua")
    add(p24, "D-11", variant="torn")
    add(p24, "D-12", variant="order")
    add(p24, "M-058", variant="measure")
    add(p24, "S-76", variant="vbackup")
    add(p24, "N-17", variant="features")
    add(p24, "N-18", variant="reservation")
    add(p24, "N-19", variant="wp")
    add(p24, "N-24", variant="pmr")
    # P25
    add(p25, "S-88", variant="selftest_log")
    add(p25, "S-89", variant="sanitize_fail")
    add(p25, "S-92", variant="fw_slot")
    add(p25, "T-12", variant="sanitize_long")
    add(p25, "M-032", variant="progress_stall")
    add(p25, "T-13", variant="selftest_long")
    # P26
    add(p26, "S-72 S-73 S-74 S-75 S-77", variant="smart")
    add(p26, "N-28", variant="smart_noaen")
    add(p26, "S-71 S-86 S-87 N-34", variant="log")
    add(p26, "T-20 M-053", variant="timestamp")
    # P27
    add(p27, "M-047 M-077", variant="segment_end")
    add(p27, "M-052 M-046", variant="align")
    add(p27, "M-085 M-084", variant="trigger")
    add(p27, "M-050 M-051", variant="precision")
    add(p27, "M-060 M-078 M-079 M-087 M-101", variant="generic")
    # context-only (E-evidence cards and fabric-only cards)
    add(context, "T-07 T-08 C-10 M-034", what="keepalive")
    add(context, "T-19 T-26 T-27 T-28 T-29 T-30 M-059 N-01 N-12", what="io",
        note="NVMe-oF / other path: nothing on this PCIe link")
    add(context, "T-32 M-093", what="host_stall")
    add(context, "L-24", what="ide")
    add(context, "N-09", what="io", note="IDE-protected link: payload unreadable")
    add(context, "C-11", what="aen_internal")
    add(context, "C-21", what="abort_limit")
    add(context, "M-018", what="tc")
    add(context, "M-027 M-028 M-029", what="reset_cascade")
    add(context, "N-04 N-13 N-14 N-22", what="io", note="host or media side; wire shows correct DMA")
    add(context, "N-16", what="preboot")
    add(context, "N-25", what="security")
    return R
