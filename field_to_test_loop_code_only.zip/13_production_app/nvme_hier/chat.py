"""The chat with the model, opened only on the admin's request (statement section 9).

The model receives the scenario only: the finding (canonical fields, chain, source rows), the extracted window,
the stored procedures for the signature and the admin's message. Its job: name the scenario, explain it in plain
words, propose the reproduction sequence. Its answer is JSON checked by code (commands from the allowed set, cited
rows inside the window). It never decides whether an error exists, and nothing it writes enters the signature.
Without a reachable model the deterministic stand-in answers from the finding and the optimiser's sequence, so the
page works offline and tests are repeatable.
"""
import json
import re

from . import optimise as OPT

ALLOWED = {"Read", "Write", "Flush", "Dataset Management", "Write Zeroes", "Compare", "Identify", "Get Log Page", "Set Features",
           "Get Features", "Abort", "Keep Alive", "Create I/O Submission Queue", "Create I/O Completion Queue",
           "Delete I/O Submission Queue", "Delete I/O Completion Queue", "Format NVM", "Sanitize", "reset", "power cycle", "idle"}
SCHEMA = {
    "type": "object",
    "properties": {
        "scenario_name": {"type": "string"},
        "summary": {"type": "string"},
        "proposed_sequence": {"type": "array", "items": {"type": "object", "properties": {
            "step": {"type": "integer"}, "command": {"type": "string"}, "parameters": {"type": "object"},
            "gap_us": {"type": "integer"}, "expected": {"type": "string"}}, "required": ["step", "command"]}},
        "assumptions": {"type": "array", "items": {"type": "string"}},
        "cited_rows": {"type": "array", "items": {"type": "integer"}},
        "observed_outcome": {"type": "string"},
        "expected_outcome": {"type": "object", "properties": {
            "status": {"type": "string"}, "description": {"type": "string"}, "check": {"type": "string"}}, "required": ["status", "description", "check"]},
    },
    "required": ["scenario_name", "summary", "proposed_sequence", "observed_outcome", "expected_outcome"],
}


def observed_outcome(finding):
    """What the recording shows at the fault, in one sentence: the status, the measured value against the limit."""
    det = finding.get("detail") or {}
    parts = [finding.get("name") or finding.get("rule") or "the rule fired"]
    if finding.get("value_ps_text"):
        parts.append("measured %s, limit %s (%s)" % (finding.get("value_ps_text"), finding.get("limit_ps_text") or "-", finding.get("limit_source") or "limit"))
    if det.get("SCT") is not None:
        parts.append("status type %s code %s%s" % (det.get("SCT"), det.get("SC"), ", do not retry" if det.get("DNR") else ""))
    cmd = (finding.get("command") or {}).get("summary")
    if cmd:
        parts.append("on %s" % cmd)
    return "; ".join(parts)


def expected_outcome_default(finding):
    """What a correct device should produce for the same input, from the rule that fired (the admin verifies or edits it)."""
    rule = finding.get("rule") or ""
    lim = finding.get("limit_ps_text") or "the limit"
    table = {
        "cmd.status_error": ("Successful Completion (status type 0, code 0)", "the command completes with status success and, for a read, returns the data", "status == (0, 0)"),
        "cmd.latency_over_limit": ("Successful Completion within %s" % lim, "the command completes before the limit", "status == (0, 0) and elapsed <= limit"),
        "cmd.incomplete": ("a completion entry is written", "the command is answered; nothing is left open", "a completion arrives before the timeout"),
        "cmd.not_fetched": ("the entry is fetched after the doorbell", "the drive reads the order it was told about", "a submission entry fetch follows the doorbell"),
        "cmd.no_interrupt": ("an interrupt follows the completion", "the computer is woken for the answer", "an interrupt write follows the completion entry"),
        "cmd.bytes_short": ("all requested bytes are moved", "the data transfer is complete", "bytes moved == bytes requested"),
        "cmd.deallocate_readback": ("deallocated blocks read back as zero or the deallocate pattern", "the deallocate took effect", "read after deallocate does not return the old data"),
        "cmd.write_zeroes_readback": ("blocks read back as zero", "the Write Zeroes took effect", "read after Write Zeroes returns zeros"),
        "spl.latency_over_limit": ("the memory read is answered within %s" % lim, "the drive's read of host memory completes in time", "request to last completion <= limit"),
        "spl.cpl_ur": ("the memory read is answered with data (status SC)", "the address is served", "completion status == SC"),
        "spl.cpl_ca": ("the memory read is answered with data (status SC)", "no completer abort", "completion status == SC"),
        "spl.incomplete": ("every memory read gets its completion", "no read is left unanswered", "all requested bytes arrive"),
        "spl.short_data": ("all requested bytes arrive", "the completion is complete", "bytes == requested"),
        "lnk.replay": ("no Nak and no replay on the link", "every packet is accepted first time", "no Nak DLLP in the sequence"),
        "lnk.incomplete": ("every packet is acknowledged", "no packet is left without an Ack", "an Ack covers every PSN"),
        "lnk.response_over_limit": ("every packet is acknowledged within %s" % lim, "the link answers in time", "TLP to Ack <= limit"),
        "ntx.status_error": ("the completion carries status success", "the drive accepts the command", "status == (0, 0)"),
        "ntx.phase_wrong": ("the completion's phase bit matches the expected phase", "the queue wraps correctly", "phase bit == expected"),
        "ntx.interrupt_before_completion": ("the interrupt is written after the completion entry", "the order is right", "interrupt time > completion time"),
        "ntx.completion_unknown_command": ("every completion belongs to an open command", "no stray completions", "queue id + command id are open"),
    }
    status, desc, check = table.get(rule, ("no finding at this step", "the rule that fired here stays silent", "the rule %s does not fire" % rule))
    return {"status": status, "description": desc, "check": check}


def _row_line(r):
    f = "; ".join(x.get("name", "") for x in (r.get("findings") or []))
    return "row %s [%s] %s | t=%s gap=%s dur=%s%s" % (r.get("rowid_file"), r.get("position"), r.get("summary"), r.get("raw", {}).get("Time Stamp", ""),
                                                        r.get("gap_text", ""), r.get("dur_ps_text", ""), (" | findings: " + f) if f else "")


def build_prompt(finding, window, knowledge, message, optimised=None):
    lines = ["You are helping an NVMe/PCIe test engineer. The facts below were established by deterministic rules; do not judge whether",
             "they are errors. Your tasks: (1) give the scenario a short, specific, plain-words name (at most 8 words);",
             "(2) explain in plain words what the window shows; (3) propose the shortest command sequence that reproduces it on this device,",
             "using only these commands: " + ", ".join(sorted(ALLOWED)) + ".",
             "Answer as JSON with scenario_name, summary, proposed_sequence (step, command, parameters, gap_us, expected), assumptions, cited_rows,",
             "observed_outcome (one sentence: what the recording shows at the fault, as given below) and expected_outcome {status, description, check}:",
             "what a CORRECT device must produce for the same input: the status it should return, in words what should happen, and the check an automatic",
             "test can run (for example 'status == (0, 0) and elapsed <= 50 ms'). The admin will verify or edit the expected outcome before it is stored.",
             "", "FINDING: level %s, rule %s: %s" % (finding.get("level"), finding.get("rule"), finding.get("name")),
             "signature: %s" % (finding.get("signature") or {}).get("display", ""),
             "affected command: %s" % ((finding.get("command") or {}).get("summary") or "outside any command"),
             "measured: %s; limit: %s (%s)" % (finding.get("value_ps_text") or "-", finding.get("limit_ps_text") or "-", finding.get("limit_source") or "-")]
    if finding.get("cause"):
        lines.append("lowest-level cause inside this command: %s level, %s" % (finding["cause"].get("level"), finding["cause"].get("name")))
    if finding.get("catalogue"):
        c = finding["catalogue"]
        lines.append("catalogue: %s | %s | spec %s" % (c.get("error"), (c.get("meaning") or "")[:300], c.get("spec")))
        for d in (c.get("defects") or [])[:6]:
            lines.append("  possible defect [%s]: %s" % (d.get("domain"), d.get("cause")))
    lines.append("")
    lines.append("CHAIN (row up to its command):")
    for c in finding.get("chain") or []:
        lines.append("  %s %s: %s%s" % (c.get("label"), c.get("n"), c.get("summary"), (" | errors: " + c["errors"]) if c.get("errors") else ""))
    lines.append("")
    lines.append("OBSERVED OUTCOME (what the recording shows at the fault): " + observed_outcome(finding))
    eo = expected_outcome_default(finding)
    lines.append("EXPECTED OUTCOME, first guess from the rule (refine it; the admin verifies): status '%s'; %s; check: %s" % (eo["status"], eo["description"], eo["check"]))
    lines.append("WINDOW at the %s level (%d above, %d below, %s):" % (window.get("label"), window.get("n", 0), window.get("m", 0), "same queue" if window.get("same_queue") else "all queues"))
    for r in window.get("rows") or []:
        lines.append("  " + _row_line(r))
    if optimised and optimised.get("steps"):
        lines.append("")
        lines.append("DEPENDENCY-KEPT SEQUENCE (code-computed; refine it, do not add commands the window does not justify):")
        for s in optimised["steps"]:
            lines.append("  step %d %s %s gap %d us - %s" % (s["step"], s["command"], json.dumps(s.get("parameters", {})), s.get("gap_us", 0), s.get("expected", "")))
    k = knowledge or {}
    if k.get("exact"):
        lines.append("")
        lines.append("STORED PROCEDURES for this exact signature (seen %s times; adapt the first one to this window rather than inventing):" % k.get("seen"))
        for p in k["exact"][:3]:
            lines.append("  procedure %s v%s score %s: %s" % (p["id"], p["version"], p.get("score_text"), json.dumps(p.get("steps"))[:600]))
    elif k.get("similar"):
        lines.append("")
        lines.append("SIMILAR signatures on other devices: " + "; ".join(x.get("scenario_name") or x.get("display", "")[:60] for x in k["similar"][:3]))
    for les in (k.get("lessons") or [])[:5]:
        lines.append("lesson: " + les.get("text", "")[:300])
    lines.append("")
    lines.append("ADMIN: " + (message or "Name the scenario and propose the sequence."))
    return "\n".join(lines)


def standin_answer(finding, window, optimised):
    """Deterministic answer without a model: name from the rule and the command, sequence from the optimiser."""
    cmd = (finding.get("command") or {}).get("summary") or "no command"
    rule = finding.get("rule") or ""
    base = {"cmd.status_error": "completes with error status", "cmd.latency_over_limit": "takes longer than the limit",
            "cmd.incomplete": "never completes", "spl.latency_over_limit": "data fetch stalls past the limit",
            "spl.cpl_ur": "memory read answered Unsupported Request", "spl.incomplete": "memory read never answered",
            "lnk.replay": "packets resent on the link", "cmd.deallocate_readback": "deallocated range still readable",
            "cmd.bytes_short": "fewer bytes moved than requested"}.get(rule, rule.replace(".", " ").replace("_", " "))
    op = cmd.split(",")[0]
    name = "%s %s" % (op, base)
    if finding.get("cause"):
        name += " after %s" % (finding["cause"].get("rule", "").split(".")[-1].replace("_", " "))
    steps = (optimised or {}).get("steps") or []
    summary = ("Rule %s fired on %s. %s. The window shows %d rows before and %d after; %d of the earlier commands set up state the failing one depends on, %d later ones were affected."
               % (rule, cmd, finding.get("name", ""), window.get("n", 0), window.get("m", 0), (optimised or {}).get("kept_above", 0), (optimised or {}).get("kept_below", 0)))
    return {"scenario_name": name[:80], "summary": summary, "proposed_sequence": [{k: s[k] for k in ("step", "command", "parameters", "gap_us", "expected") if k in s} for s in steps],
            "assumptions": ["stand-in answer: no model was reachable; the sequence is the dependency-kept window"], "cited_rows": [s.get("source_row") for s in steps if s.get("source_row")],
            "observed_outcome": observed_outcome(finding), "expected_outcome": expected_outcome_default(finding),
            "producer": "stand-in"}


def check_answer(ans, window):
    """Code checks on the model's JSON; returns (ok, problems)."""
    problems = []
    rows = {r.get("rowid_file") for r in (window.get("rows") or [])}
    allowed = {a.lower() for a in ALLOWED}
    # the commands of the window itself are always allowed (the fault must be replayed, even a vendor opcode)
    for r in window.get("rows") or []:
        for key in ("opcode_name", "command"):
            if r.get(key):
                allowed.add(str(r[key]).replace(" (admin)", "").strip().lower())
        if r.get("opc") is not None:
            allowed.add("opcode 0x%02x" % int(r["opc"]))
    for s in ans.get("proposed_sequence") or []:
        c = (s.get("command") or "").replace(" (admin)", "").strip()
        cl = c.lower()
        if cl not in allowed and not re.match(r"^opcode 0x[0-9a-f]{1,2}$", cl):
            problems.append("step %s uses a command outside the allowed set: %s" % (s.get("step"), c))
    for r in ans.get("cited_rows") or []:
        if r not in rows:
            problems.append("cited row %s is not in the window" % r)
    if not (ans.get("scenario_name") or "").strip():
        problems.append("no scenario name")
    return (not problems), problems


def ask(llm, finding, window, knowledge, message):
    """Returns the answer dict (model or stand-in) with 'producer' and 'checks'."""
    optimised = OPT.optimise(window.get("rows") or [])
    prompt = build_prompt(finding, window, knowledge, message, optimised)
    ans = None
    producer = "stand-in"
    if llm is not None and getattr(llm, "name", "stand-in") not in ("standin", "stand-in"):
        try:
            out = llm.generate_json(prompt, SCHEMA)
            if isinstance(out, tuple):                       # the adapter returns (answer, served_from_cache)
                out = out[0]
            if isinstance(out, dict) and out.get("proposed_sequence") is not None:
                ans = out
                producer = getattr(llm, "name", "model")
            elif isinstance(out, dict) and out.get("_error"):
                producer = "stand-in (the model did not answer: %s)" % str(out["_error"])[:160]
        except Exception as e:      # noqa: BLE001 - the page says the stand-in answered and why
            ans = None
            producer = "stand-in (model call failed: %s)" % str(e)[:120]
    if ans is None:
        ans = standin_answer(finding, window, optimised)
    ans.setdefault("observed_outcome", observed_outcome(finding))
    if not isinstance(ans.get("expected_outcome"), dict) or not ans["expected_outcome"].get("status"):
        ans["expected_outcome"] = expected_outcome_default(finding)
    ans["expected_outcome"].setdefault("verified_by", None)
    ok, problems = check_answer(ans, window)
    ans["producer"] = producer
    ans["checks"] = {"ok": ok, "problems": problems}
    ans["optimised"] = {k: v for k, v in optimised.items() if k != "rows"}
    ans["prompt_chars"] = len(prompt)
    return ans
