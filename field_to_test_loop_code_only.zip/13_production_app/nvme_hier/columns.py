"""Canonical column lists of the five per-level exports and the renames of the label-less headers.

The lists come from the customer's COLUMN_NAMES.txt (read in full from photos on 2026-11-02; every file matches
the customer's own counts: packets 113, link 34, split 17, NVMe transactions 402, NVMe commands 1598). They are
stored in data/lecroy_export_columns.json under the names the customer's script produced; four of those names are
not labels but the text of the first row (the header cell was blank): "16.0" is the link speed, "1 warning(s)",
"2 error(s)" and "1 error(s)" are the unit's warning and error cells. This module gives them stable names.
"""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
COLUMNS_JSON = os.path.join(os.path.dirname(HERE), "data", "lecroy_export_columns.json")

# file key -> customer file name in the JSON
FILE_KEYS = {
    "packets": "packets.csv",
    "link": "link.csv",
    "split": "split.csv",
    "nvme_transaction": "NVME_Transactions.csv",
    "nvme_command": "nvme_command.csv",
}
LEVEL_ORDER = ["nvme_command", "nvme_transaction", "split", "link", "packets"]
LEVEL_LABEL = {
    "packets": "packet",
    "link": "link transaction",
    "split": "split transaction",
    "nvme_transaction": "NVMe transaction",
    "nvme_command": "NVMe command",
}

# (file key, name in the customer's list) -> canonical name. Label-less header cells are blank in the CSV; the
# customer's script named them after the first row's text. The loader recognises them by position.
LABEL_LESS = {
    ("link", "16.0"): "Link Speed",
    ("split", "16.0"): "Link Speed",
    ("nvme_command", "1 warning(s)"): "Warnings",
    ("nvme_command", "2 error(s)"): "Errors",
    ("nvme_command", "1 error(s)"): "Errors#2",
    ("nvme_transaction", "1 error(s)"): "Errors",
    ("nvme_transaction", "1 warning(s)"): "Warnings",
}
# The packet export sometimes carries an "Errors" column (Export dialog > columns > Errors); it is optional and
# not in the 113 list, so it is accepted as a known extra.
KNOWN_EXTRAS = {"packets": ["Errors"]}

# plain-words meaning of the canonical names the pages show (kept short; the FAQ has the long form)
PLAIN = {
    "Link Speed": "link speed in GT/s",
    "Warnings": "the analyzer's warning cell for this row",
    "Errors": "the analyzer's error cell for this row",
    "Errors#2": "the analyzer's error cell inside the decoded data structure",
    "Metrics.# Packets": "number of packets in this link transaction",
    "Metrics.# LinkTrans": "number of link transactions in this split transaction",
    "Metrics.# Link & Split Trans": "number of link and split transactions in this NVMe transaction",
    "Metrics.# NVME Trans": "number of NVMe transactions in this command",
    "Time Delta": "time from this row to the next row at this level",
    "Time Stamp": "time of the first packet of this row, from the start of the recording",
}


def _load():
    with open(COLUMNS_JSON, encoding="utf-8") as f:
        return json.load(f)


_DATA = None


def data():
    global _DATA
    if _DATA is None:
        _DATA = _load()
    return _DATA


def original_names(file_key):
    """The customer's list for one file, in file order (label-less names as the customer wrote them)."""
    return list(data()["columns"][FILE_KEYS[file_key]])


def canonical_names(file_key):
    """Same list with the label-less headers renamed."""
    out = []
    for n in original_names(file_key):
        out.append(LABEL_LESS.get((file_key, n), n))
    return out


def label_less_positions(file_key):
    """Indices (within the named list) whose header cell is blank in the CSV."""
    return [i for i, n in enumerate(original_names(file_key)) if (file_key, n) in LABEL_LESS]


def expected_count(file_key):
    return len(original_names(file_key))
