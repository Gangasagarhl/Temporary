"""Findings -> isolated incidents.

For every incident:
  start_pkt / end_pkt   where the error starts and where it is concluded (evidence span)
  first_abnormal        earliest defect finding (atlas XII.8 rule R1: first anomalous row, not the loudest)
  evidence graph        nodes = findings, edges = SAME_KEY (identity: PSN, RequesterID+Tag, SQID+CID, LBA)
                        and CAUSES (published cascades, earlier -> later); root = first node with no cause
  attribution           XII.8 decision procedure R0..R10 (host / device / platform / link / test setup)
  classification        ranked atlas cards + pattern vote (atlas.Classifier)
  context               the NVMe command involved, the workload the host was running (task), the driver
                        path, why it happens and how to prove/fix it (atlas card text)
  evidence rows         start-15..end+15 (bounded) plus the key rows, for the LLM review
"""
import csv
import json
import os
import pickle
import struct
from collections import Counter, defaultdict

from .atlas import Classifier, enrich
from .engine import ADMIN_NAMES, IO_NAMES
from .evidence import compact, merge_ranges
from .rules import CONTEXT, DEFECT, RULES
from .schema import fmt_dt, fmt_t

GAP_PKTS = 1000          # findings closer than this belong to one incident
MAX_REL_SPAN = 300000    # related-row pointers further away than this do not stretch an incident
CONTEXT_ROWS = 15        # rows above/below the isolated region given to the reviewer
TASK_ROWS = 1500         # rows before the incident scanned to describe the host's task
H_LEAD_PKTS = 50         # a host-only cluster this close before a wire cluster joins it

# published / atlas cascades: earlier rule family -> later rule family
CASCADE = [
    ("PHY.", ("DLL.LCRC_BAD", "DLL.NAK", "DLL.REPLAY", "LINK.RECOVERY", "MSG.ERR", "LINK.DOWN", "PHY.SPEED_DOWN",
              "PHY.WIDTH_CHANGE")),
    ("DLL.LCRC_BAD", ("DLL.NAK", "DLL.REPLAY", "MSG.ERR")),
    ("DLL.CRC16_BAD", ("DLL.REPLAY", "DLL.ACK_LATE", "MSG.ERR")),
    ("DLL.NAK", ("DLL.REPLAY", "MSG.ERR")),
    ("DLL.REPLAY", ("DLL.REPLAY_ROLLOVER", "LINK.RECOVERY", "MSG.ERR")),
    ("DLL.REPLAY_ROLLOVER", ("LINK.RECOVERY", "LINK.DOWN", "MSG.ERR")),
    ("LINK.RECOVERY", ("LINK.RECOVERY_STORM", "PHY.SPEED_DOWN", "PHY.WIDTH_CHANGE", "LINK.DOWN")),
    ("LINK.DOWN", ("LINK.DOWN_INFLIGHT", "TXN.LOST_LINKDOWN", "NVME.CMD_LOST_RESET", "NVME.CMD_TIMEOUT",
                   "REG.ALL_ONES", "LINK.TRAIN_SLOW")),
    ("PHY.EIDLE_NO_EIOS", ("LINK.DOWN", "LINK.DOWN_INFLIGHT", "DATA.LOST_AFTER_POWER", "DATA.POWER_CUT")),
    ("FC.", ("TXN.CPL_TIMEOUT", "NVME.CMD_TIMEOUT", "S.")),
    ("TXN.CPL_TIMEOUT", ("NVME.STATUS", "NVME.CMD_TIMEOUT", "MSG.ERR", "TXN.CPL_LATE")),
    ("TLP.", ("MSG.ERR", "TXN.", "NVME.STATUS")),
    ("TXN.", ("MSG.ERR", "NVME.STATUS", "NVME.CMD_TIMEOUT")),
    ("CFG.", ("TLP.CPL_STATUS", "MSG.ERR", "NVME.CMD_TIMEOUT", "REG.")),
    ("REG.RDY_TIMEOUT", ("REG.CTRL_RESET",)),
    ("NVME.SQE_", ("NVME.STATUS",)),
    ("NVME.CMD_TIMEOUT", ("NVME.ABORT", "REG.CTRL_RESET", "NVME.CQE_UNKNOWN_CID")),
    ("NVME.NOT_FETCHED", ("REG.CTRL_RESET", "NVME.CMD_TIMEOUT")),
    ("DB.", ("NVME.AEN", "NVME.STATUS", "NVME.NOT_FETCHED", "NVME.CMD_TIMEOUT")),
    ("NVME.AEN", ("NVME.LOG_CRITICAL",)),
    ("PM.", ("S.", "LINK.", "NVME.CMD_TIMEOUT")),
]


def causes(a, b):
    for pre, posts in CASCADE:
        if a.startswith(pre) and any(b.startswith(p) for p in posts):
            return True
    return False


def interval(f):
    rel = [p for p in f[6] if isinstance(p, int) and abs(p - f[0]) <= MAX_REL_SPAN]
    return min([f[0]] + rel), max([f[0]] + rel)


def cluster(findings):
    defects = sorted((f for f in findings if RULES[f[2]]["level"] == DEFECT), key=lambda f: interval(f)[0])
    groups = []
    for f in defects:
        lo, hi = interval(f)
        if groups and lo <= groups[-1]["hi"] + GAP_PKTS:
            g = groups[-1]
            g["hi"] = max(g["hi"], hi)
            g["f"].append(f)
        else:
            groups.append({"lo": lo, "hi": hi, "f": [f]})
    # attach context findings (host actions, resets) that fall inside or right next to an incident
    ctx = sorted((f for f in findings if RULES[f[2]]["level"] == CONTEXT), key=lambda f: f[0])
    import bisect
    starts = [g["lo"] for g in groups]
    for f in ctx:
        i = bisect.bisect_right(starts, f[0] + 200) - 1
        if i >= 0 and f[0] <= groups[i]["hi"] + 200:
            groups[i]["f"].append(f)
    merged = []
    for g in groups:
        only_h = all(RULES[f[2]]["tier"] == "H" for f in g["f"] if RULES[f[2]]["level"] == DEFECT)
        if merged and only_h is False and merged[-1].get("_only_h") and g["lo"] - merged[-1]["hi"] <= H_LEAD_PKTS:
            prev = merged.pop()
            g["lo"], g["f"] = prev["lo"], prev["f"] + g["f"]
        g["_only_h"] = only_h
        merged.append(g)
    for g in merged:
        g.pop("_only_h", None)
        g["f"].sort(key=lambda f: f[0])
    return merged


def evidence_graph(fs):
    nodes = []
    for i, f in enumerate(fs):
        nodes.append({"id": i, "pkt": f[0], "rule": f[2], "level": RULES[f[2]]["level"], "detail": f[4]})
    edges = []
    keyed = defaultdict(list)
    for i, f in enumerate(fs):
        for k in f[5]:
            keyed[tuple(k)].append(i)
    for k, ids in keyed.items():
        for a, b in zip(ids, ids[1:]):
            edges.append({"from": a, "to": b, "type": "SAME_KEY", "key": "/".join(str(x) for x in k)})
    incoming = set()
    defect_ids = [i for i, f in enumerate(fs) if RULES[f[2]]["level"] == DEFECT]
    for x, a in enumerate(defect_ids):
        for b in defect_ids[x + 1:]:
            if fs[a][2] != fs[b][2] and causes(fs[a][2], fs[b][2]):
                edges.append({"from": a, "to": b, "type": "CAUSES"})
                incoming.add(b)
    root = next((i for i in defect_ids if i not in incoming), defect_ids[0] if defect_ids else 0)
    if len(edges) > 400:
        edges = edges[:400]
    return nodes, edges, root


# ---------------------------------------------------------------------- one pass to pull rows back
class Extract:
    """Collects full rows for evidence ranges and slim rows for task-context ranges (one CSV pass),
    then attaches payload from the sidecar (one sidecar pass)."""

    def __init__(self, csv_path, payload_path):
        self.csv_path, self.payload_path = csv_path, payload_path
        self.full = []
        self.ctx = []

    def run(self):
        full = merge_ranges(self.full)
        ctxr = merge_ranges(self.ctx)
        import bisect
        fs, cs = [r[0] for r in full], [r[0] for r in ctxr]
        end = max([r[1] for r in full] + [r[1] for r in ctxr] + [0])
        rows, slim, lineno = {}, {}, {}
        with open(self.csv_path, newline="", encoding="utf-8", buffering=1 << 22) as f:
            header = next(csv.reader([f.readline()]))
            self.header = header
            ix = {n: i for i, n in enumerate(header)}
            take = [ix[n] for n in ("Link Dir", "TLP Type", "DLLP Type", "Ord.Set Type", "Link Event", "Address",
                                    "Length", "Tag", "Message Code", "DATA", "Time Stamp", "Cpl Status")]
            for n, line in enumerate(f, start=2):            # physical line: header is line 1
                a = line.index(",")
                p = int(line[a + 1:line.index(",", a + 1)])
                if p > end:
                    break
                i = bisect.bisect_right(fs, p) - 1
                inf = i >= 0 and p <= full[i][1]
                j = bisect.bisect_right(cs, p) - 1
                inc = j >= 0 and p <= ctxr[j][1]
                if not (inf or inc):
                    continue
                row = next(csv.reader([line]))
                if inf:
                    rows[p] = row
                    lineno[p] = n
                if inc:
                    slim[p] = [row[k] for k in take]
        pay = {}
        if self.payload_path:
            want = set(rows) | set(slim)
            with open(self.payload_path, newline="") as f:
                f.readline()
                for line in f:
                    a = line.index(",")
                    p = int(line[:a])
                    if p > end:
                        break
                    if p in want:
                        r = line.rstrip("\n").split(",")
                        pay[p] = (int(r[1]), r[2], r[3])
        self.rows, self.slim, self.pay, self.lineno = rows, slim, pay, lineno
        return self


# ---------------------------------------------------------------------- context: command and task
def decode_sqe(hexs):
    b = bytes.fromhex(hexs)
    if len(b) < 64:
        return None
    dw = struct.unpack("<16I", b[:64])
    opc, cid = dw[0] & 0xFF, dw[0] >> 16
    return {"opcode": opc, "cid": cid, "nsid": dw[1], "prp1": dw[6] | dw[7] << 32, "prp2": dw[8] | dw[9] << 32,
            "cdw10": dw[10], "cdw11": dw[11], "cdw12": dw[12], "slba": dw[10] | dw[11] << 32,
            "nlb": (dw[12] & 0xFFFF) + 1}


def describe_command(inc, ex, bar0):
    """The NVMe command(s) the incident is about, decoded from the SQE payload when available."""
    keys = []
    for f in inc["_f"]:
        for k in f[5]:
            if k and k[0] == "cmd" and (k[1], k[2]) not in keys:
                keys.append((k[1], k[2]))
    cands = set(p for f in inc["_f"] for p in [f[0]] + list(f[6]) if isinstance(p, int))
    cmds = []
    for p in sorted(cands):
        pl = ex.pay.get(p)
        row = ex.rows.get(p)
        if not pl or not row or pl[0] != 64:
            continue
        ix = ex.header.index("TLP Type")
        if row[ix] != "CplD":
            continue
        d = decode_sqe(pl[1])
        if not d:
            continue
        for sqid, cid in keys or [(None, d["cid"])]:
            if cid == d["cid"]:
                names = ADMIN_NAMES if sqid == 0 else IO_NAMES
                name = names.get(d["opcode"], "opcode 0x%02X" % d["opcode"])
                desc = {"sqid": sqid, "cid": cid, "opcode": "0x%02X" % d["opcode"], "name": name,
                        "nsid": d["nsid"], "sqe_packet": p}
                if sqid != 0:
                    desc.update({"slba": "0x%X" % d["slba"], "blocks": d["nlb"], "bytes": d["nlb"] * 512})
                else:
                    desc.update({"cdw10": "0x%08X" % d["cdw10"], "cdw11": "0x%08X" % d["cdw11"]})
                desc.update({"prp1": "0x%X" % d["prp1"], "prp2": "0x%X" % d["prp2"]})
                cmds.append(desc)
                break
    return cmds[:4], keys[:8]


def describe_task(lo, ex, bar0):
    """What the host was doing before the incident, from the TASK_ROWS rows above it."""
    rows = [(p, ex.slim[p]) for p in range(max(0, lo - TASK_ROWS), lo) if p in ex.slim]
    c = Counter()
    io = Counter()
    io_bytes = []
    admin = Counter()
    last_db_q = None
    for p, r in rows:
        d, tl, dl, os_, ev, addr, ln, tag, msg, data, ts, st = r
        if os_:
            c["ordered sets"] += 1
        if ev:
            c["link events"] += 1
            if "Electrical Idle" in ev or "CLKREQ" in ev:
                c["power-state changes"] += 1
        if dl.startswith("PM_"):
            c["power-state changes"] += 1
        if tl.startswith("Cfg"):
            c["configuration requests"] += 1
        if msg == "Latency_Tolerance_Reporting":
            c["LTR"] += 1
        if tl.startswith("MWr") and d == "Downstream" and addr and bar0:
            a = int(addr.replace(":", ""), 16)
            off = a - bar0
            if 0x14 <= off <= 0x37:
                c["controller register writes"] += 1
            elif 0x1000 <= off < 0x2000:
                idx = (off - 0x1000) // 4
                if idx % 2 == 0:
                    last_db_q = idx // 2
        if tl == "CplD" and d == "Downstream" and p in ex.pay and ex.pay[p][0] == 64:
            s = decode_sqe(ex.pay[p][1])
            if s:
                if last_db_q == 0:
                    admin[ADMIN_NAMES.get(s["opcode"], "0x%02X" % s["opcode"])] += 1
                else:
                    io[IO_NAMES.get(s["opcode"], "0x%02X" % s["opcode"])] += 1
                    if s["opcode"] in (1, 2):
                        io_bytes.append(s["nlb"] * 512)
    label = "unknown (no traffic decoded before the incident)"
    if c["ordered sets"] > 20 and not io:
        label = "link training / power-on or link recovery"
    elif c["configuration requests"] > 3 and not io:
        label = "PCIe enumeration / configuration (BIOS or OS probe)"
    elif c["controller register writes"] or (admin and not io):
        label = "NVMe controller initialisation / reset (CC, admin queue, Identify, Create I/O queues)"
    elif io:
        rd, wr, fl, dsm = io["Read"], io["Write"], io["Flush"], io["Dataset Management"]
        big = sum(1 for b in io_bytes if b >= 65536)
        if dsm:
            label = "delete files / fstrim (Dataset Management - Deallocate)"
        elif fl and wr:
            label = "save document (small writes + Flush / fsync)"
        elif big >= 3 and rd and wr:
            label = "file copy (sequential 128 KiB read + write)"
        elif rd and not wr:
            label = "application launch / file read (random reads)"
        else:
            label = "mixed small reads/writes (browser cache, desktop activity)"
    elif c["power-state changes"]:
        label = "idle: ASPM L1 / L1.2 entry-exit, LTR updates"
    detail = {"io_commands": dict(io), "admin_commands": dict(admin),
              "io_size_range": [min(io_bytes), max(io_bytes)] if io_bytes else None,
              "other": {k: v for k, v in c.items() if v}}
    return label, detail


# ---------------------------------------------------------------------- attribution (atlas XII.8)
def attribute(inc, ex, card):
    rules = [f[2] for f in inc["_f"] if RULES[f[2]]["level"] == DEFECT]
    rs = set(rules)
    first = inc["_f"][inc["_first"]]
    row = ex.rows.get(first[0])
    d = row[ex.header.index("Link Dir")] if row else ""
    sender = "device" if d == "Upstream" else ("host" if d == "Downstream" else None)
    badge = (card or {}).get("origin", "Either side")

    def has(prefix):
        return any(r.startswith(prefix) for r in rs)
    if has("CI."):
        return "test setup", "R0 capture integrity: analyzer marker / gap / filter / precision", ["re-export unfiltered"]
    if "NVME.STATUS" in rs:
        if has("NVME.SQE_") or "DB.PARTIAL" in rs:
            return "host", "R2 SQE fields invalid -> the device rejected a bad command correctly", []
        aborted = any(f[2] == "NVME.STATUS" and f[3].endswith("/0x07") for f in inc["_f"]) and \
            any(f[2] in ("NVME.ABORT", "NVME.HOST_ABORT_EARLY") for f in inc["_f"])
        if aborted:
            return "host", "R2 status SC 0x07 (Command Abort Requested) answers the host's own Abort: the device " \
                           "responded correctly; why the host aborted is host-side (application cancel, short " \
                           "timeout)", ["E05 host I/O trace: who issued the Abort and when"]
        return badge.lower() if badge != "Either side" else "device", \
            "R2 command rejected but the SQE fields checked are valid -> card origin / device", \
            ["E03 nvme error-log with the same SQID+CID"]
    if has("NVME.NOT_FETCHED"):
        return "device", "R3 doorbell valid, SQE never fetched -> first missing step is the device fetch", ["E03 PEL"]
    if "TXN.CPL_TIMEOUT" in rs and first[2] == "TXN.CPL_TIMEOUT" and "Upstream" in first[4]:
        return "platform", "R3 SSD MRd got no CplD -> root complex / platform", ["E02 IOMMU/ACS, AER on root port"]
    if "NVME.CMD_TIMEOUT" in rs:
        return "device", "R3 SQE fetched, no CQE until the host gave up -> device", ["E03 C1h/C3h logs", "reset ladder"]
    if has("DLL.") or has("PHY.SYMBOL") or "LINK.RECOVERY" in rs:
        naks = [f for f in inc["_f"] if f[2] == "DLL.NAK"]
        up = sum(1 for f in naks if f[3] == "Upstream")
        dn = sum(1 for f in naks if f[3] == "Downstream")
        if up and dn:
            return "link", "R5 Nak in both directions -> channel", ["E07 margining", "slot/riser swap"]
        if up:
            return "platform", "R5 Nak sent Upstream: the SSD receiver saw bad TLPs -> host Tx / channel", \
                ["swap slot", "E07 margining"]
        if dn:
            return "device", "R5 Nak sent Downstream: the root port saw bad TLPs -> SSD Tx / channel", \
                ["swap SSD", "E07 margining"]
        return "link", "R5 link-layer errors without Nak direction evidence", ["AER counters on both ends"]
    if has("LINK.DOWN") or has("PHY.EIDLE") or "LINK.TRAFFIC_WHILE_DOWN" in rs:
        host_act = any(f[2] in ("LINK.DOWN_HOST", "PHY.TS_HOTRESET", "REG.CTRL_RESET") for f in inc["_f"]
                       if f[0] <= first[0] + 50)
        return ("host" if host_act else (sender or "device")), \
            "R6 %s" % ("host action precedes the link loss" if host_act else "no host action before the link loss"), \
            ["E01 dmesg pciehp/DPC", "E07"]
    if has("PM."):
        return "platform" if "PM.LTR_LOW" not in rs else "device", \
            "R7 power-state trouble: policy/thresholds vs advertised exit latency", ["ASPM/APST A/B test"]
    if has("TLP.") or has("TXN.") or has("NVME.") or has("DB.") or has("CFG.") or has("REG."):
        return (sender or badge.lower()), "R4 transmitter of the first bad TLP (%s)" % (d or "direction n/a"), []
    if has("DATA."):
        return "device", "R8 data right on the wire at write, wrong at read -> device", ["E04 fio verify"]
    if has("S."):
        rr = " ".join(f[3] for f in inc["_f"] if f[2].startswith("S."))
        if any(x in rr for x in ("cq_head_lag", "sq_batch", "config_to_driver")):
            return "host", "R9 host-controlled gap dominates", ["E05 host tracing"]
        return "device", "R9 device-controlled gap dominates (fetch/data/CQE latency)", ["E03 C3h latency monitor"]
    if has("H."):                                   # proven only by outside evidence: the document names the side
        h = next(f for f in inc["_f"] if f[2].startswith("H."))
        side = {"H.OTHER_PATH": "other path", "H.HOST_TRACE": "host", "H.PLATFORM": "platform",
                "H.CAPTURE_SETUP": "test setup", "H.DATA_VERIFY": "device", "H.NVME_LOG": "device",
                "H.LAB_RESULT": "device", "H.KERNEL_ERROR": badge.lower()}[h[2]]
        return side, "R10 nothing on the wire; outside evidence (%s) decides" % h[4].split(":")[0], []
    return badge.lower(), "R10 nothing on the wire decides; card badge used as hypothesis", ["E01-E10"]


# ---------------------------------------------------------------------- main
def isolate(run_dir, library_path, csv_path, payload_path):
    from .host_evidence import load_all
    findings = load_all(run_dir)
    run = json.load(open(os.path.join(run_dir, "run.json")))
    bar0 = int(run["topology"]["bar0"], 16) if run["topology"].get("bar0") else None
    clf = Classifier(library_path)
    groups = cluster(findings)
    print("findings %d -> incidents %d" % (len(findings), len(groups)), flush=True)
    ex = Extract(csv_path, payload_path)
    incs = []
    for n, g in enumerate(groups, 1):
        fs = g["f"]
        nodes, edges, root = evidence_graph(fs)
        defect_idx = [i for i, f in enumerate(fs) if RULES[f[2]]["level"] == DEFECT]
        wire_idx = [i for i in defect_idx if RULES[fs[i][2]]["tier"] != "H"]
        first = wire_idx[0] if wire_idx else defect_idx[0]   # the wire row is the proof; host lines corroborate
        lo, hi = g["lo"], g["hi"]
        key_pkts = []
        for f in fs:
            for p in [f[0]] + [x for x in f[6] if isinstance(x, int)]:
                if lo <= p <= hi and p not in key_pkts:
                    key_pkts.append(p)
        key_pkts = sorted(key_pkts)[:40]
        if hi - lo <= 6 * CONTEXT_ROWS:
            windows = [(max(0, lo - CONTEXT_ROWS), hi + CONTEXT_ROWS)]
        else:
            windows = [(max(0, lo - CONTEXT_ROWS), lo + CONTEXT_ROWS), (hi - CONTEXT_ROWS, hi + CONTEXT_ROWS)]
        for w in windows:
            ex.full.append(w)
        for p in key_pkts:
            ex.full.append((p, p))
        ex.ctx.append((max(0, lo - TASK_ROWS), lo))
        incs.append({"_f": fs, "_first": first, "_root": root, "id": "INC-%04d" % n, "start_pkt": lo, "end_pkt": hi,
                     "windows": windows, "key_pkts": key_pkts, "nodes": nodes, "edges": edges})
    print("extracting evidence rows ...", flush=True)
    ex.run()
    out = []
    for inc in incs:
        fs = inc["_f"]
        first = fs[inc["_first"]]
        root = fs[inc["_root"]]
        ranked = clf.rank(fs)
        top = ranked[0]["card_id"] if ranked else None
        card = clf.cards_db.get(top) if top else None
        origin, why_origin, need = attribute(inc, ex, card)
        task, task_detail = describe_task(inc["start_pkt"], ex, bar0)
        cmds, cmd_keys = describe_command(inc, ex, bar0)
        ts = lambda p: ex.rows[p][ex.header.index("Time Stamp")] if p in ex.rows else None
        defects = [f for f in fs if RULES[f[2]]["level"] == DEFECT]
        caused = {e["to"] for e in inc["edges"] if e["type"] == "CAUSES"}

        def role(i, f):
            """atlas VII.6.1: first abnormal event is the root; later findings are cascade or independent."""
            if RULES[f[2]]["level"] != DEFECT:
                return "context"
            if i == inc["_root"]:
                return "root"
            return "cascade" if i in caused else "independent"
        ln = ex.lineno
        rec = {
            "id": inc["id"],
            "start_pkt": inc["start_pkt"], "end_pkt": inc["end_pkt"],
            "start_time": ts(inc["start_pkt"]), "end_time": ts(inc["end_pkt"]),
            "span_rows": inc["end_pkt"] - inc["start_pkt"] + 1,
            "csv_lines": {"start": ln.get(inc["start_pkt"]), "end": ln.get(inc["end_pkt"]),
                          "first_abnormal": ln.get(first[0]), "root": ln.get(root[0]),
                          "note": "1-based physical lines of the CSV file; the header is line 1"},
            "first_abnormal": {"pkt": first[0], "rule": first[2], "verdict": RULES[first[2]]["verdict"],
                               "detail": first[4]},
            "root_cause_node": {"pkt": root[0], "rule": root[2], "detail": root[4]},
            "verdict": max((RULES[f[2]]["verdict"] for f in defects),
                           key=lambda v: ["UNKNOWN", "ARTEFACT", "SUSPECT", "CONFIRMED"].index(v)
                           if v in ("UNKNOWN", "ARTEFACT", "SUSPECT", "CONFIRMED") else 0),
            "layer": RULES[first[2]]["layer"],
            "rules": dict(Counter(f[2] for f in defects)),
            "context_rules": dict(Counter(f[2] for f in fs if RULES[f[2]]["level"] == CONTEXT)),
            "pattern_vote": clf.pattern_vote(fs)[:4],
            "atlas_candidates": ranked,
            "attribution": {"origin": origin, "rule": why_origin, "evidence_to_collect": need,
                            "card_badge": card["origin"] if card else None},
            "nvme_commands": cmds,
            "command_keys": [list(k) for k in cmd_keys],
            "task": task, "task_detail": task_detail,
            "explanation": enrich(card) if card else None,
            "findings": [{"pkt": f[0], "line": ln.get(f[0]), "rule": f[2], "level": RULES[f[2]]["level"],
                          "verdict": RULES[f[2]]["verdict"], "qual": f[3], "detail": f[4], "role": role(i, f),
                          "related_pkts": [p for p in f[6] if isinstance(p, int)]} for i, f in enumerate(fs[:200])],
            "n_findings": len(fs),
            "evidence_graph": {"nodes": inc["nodes"][:200], "edges": inc["edges"], "root": inc["_root"]},
            "windows": inc["windows"], "key_pkts": inc["key_pkts"],
        }
        out.append(rec)
    json.dump(out, open(os.path.join(run_dir, "incidents.json"), "w"), indent=1, default=str)
    # evidence rows for the reviewer: compact text, one block per window plus key rows
    with open(os.path.join(run_dir, "incident_rows.jsonl"), "w") as fo:
        for inc, rec in zip(incs, out):
            blocks = []
            for lo, hi in inc["windows"]:
                blocks.append({"range": [lo, hi], "rows": [row_text(ex, p) for p in range(lo, hi + 1) if p in ex.rows]})
            keys = [row_text(ex, p) for p in inc["key_pkts"] if p in ex.rows and
                    not any(lo <= p <= hi for lo, hi in inc["windows"])]
            fpk = sorted({p for f in inc["_f"] for p in [f[0]] + [x for x in f[6] if isinstance(x, int)]})
            fo.write(json.dumps({"id": rec["id"], "blocks": blocks, "key_rows": keys, "finding_pkts": fpk}) + "\n")
    print("incidents -> %s" % os.path.join(run_dir, "incidents.json"))
    return out


def row_text(ex, p):
    row = ex.rows[p]
    s = compact(ex.header, row)
    if p in ex.lineno:
        s += " | Line=%d" % ex.lineno[p]
    pl = ex.pay.get(p)
    if pl:
        s += " | PAYLOAD=" + (pl[1] if pl[0] <= 64 else pl[1] + "...(%d B, crc32 %s)" % (pl[0], pl[2]))
    return s
