"""pcie_isolate: streaming defect isolation for 113-column Teledyne-LeCroy-style PCIe/NVMe CSV exports.

Pipeline (one pass over the CSV, then small in-memory steps):
  engine.Engine        typed rows -> trackers -> findings (rule id, packet, verdict, keys)
  incidents.build      findings -> incidents (first abnormal event, start/end rows, evidence graph,
                       attribution host/device/platform/link/test-setup)
  atlas.Classifier     incident -> ranked atlas cards (+ driver path, command, task, why, tests)
  evidence.extract     incident -> source rows (start-15 .. end+15) for review
  llm.review           rows + deterministic findings -> Claude Haiku confirmation
"""
__version__ = "1.0.0"
