"""Atlas knowledge: card enrichment, signature library and card classification.

Two independent ways to name the defect:
  1. pattern vote (no training): every rule carries the atlas XII.4 patterns it is evidence for;
     the incident's patterns are voted by its defect findings (earliest finding weighted most).
  2. signature library (supervised on a SEPARATE calibration capture): for each atlas card, the
     finding signatures (rule:qualifier) seen inside that card's episode in the calibration trace.
     An incident is matched by TF-IDF cosine similarity.  Cards whose library signatures are almost
     identical form an ambiguity group: the wire cannot tell them apart, and the report says so.
"""
import json
import math
import os
import re
from collections import Counter, defaultdict

from .evaluate import Truth
from .rules import DEFECT, RULES
from .schema import PROJECT

_CARD_CANDIDATES = (os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "reference",
                                 "atlas_cards_raw.json"),                                    # bundled with the package
                    os.path.join(PROJECT, "01_input_files", "atlas_cards_raw.json"))       # project layout
CARDS_JSON = next((p for p in _CARD_CANDIDATES if os.path.exists(p)), _CARD_CANDIDATES[0])

# Linux v7.2 code path per wire pattern, used when a card has no "Linux v7.2 source" field
PATTERN_DRIVER = {
    "P01": "drivers/nvme/host/core.c nvme_complete_rq() -> nvme_error_status() -> blk_mq_end_request()",
    "P02": "drivers/nvme/host/pci.c nvme_timeout() -> nvme_abort / nvme_reset_ctrl() -> nvme_reset_work()",
    "P03": "PCIe root port Completion Timeout -> drivers/pci/pcie/aer.c aer_isr() / pcie_do_recovery()",
    "P04": "drivers/pci/probe.c pci_bus_read_dev_vendor_id() (CRS), aer.c UnsupReq/CmpltAbrt handling",
    "P05": "drivers/pci/pcie/aer.c (Unexpected Completion / Malformed TLP) -> pcie_do_recovery()",
    "P06": "drivers/pci/pcie/aer.c correctable errors (BadTLP, BadDLLP, Replay Rollover, Replay Timer Timeout)",
    "P07": "flow-control stall surfaces as nvme_timeout() in drivers/nvme/host/pci.c",
    "P08": "drivers/pci/pcie/bwctrl.c / pcie_link_bandwidth_notification, pcie_retrain_link()",
    "P09": "drivers/pci/pcie/aer.c Receiver Error (correctable)",
    "P10": "drivers/pci/pcie/aer.c aer_isr() -> aer_print_error(); ERR_FATAL -> pcie_do_recovery()",
    "P11": "drivers/pci/pcie/aer.c Poisoned TLP / ECRC / Malformed TLP",
    "P12": "drivers/pci/hotplug/pciehp_ctrl.c, drivers/pci/pcie/dpc.c; nvme_remove_dead_ctrl()",
    "P13": "drivers/nvme/host/core.c nvme_wait_ready() / nvme_enable_ctrl() / nvme_disable_ctrl()",
    "P14": "drivers/nvme/host/pci.c nvme_write_sq_db() / nvme_ring_cq_doorbell()",
    "P15": "drivers/nvme/host/pci.c nvme_handle_cqe() ('invalid id %d completed on queue %d')",
    "P16": "drivers/nvme/host/pci.c nvme_irq() / nvme_poll_cq(); MSI-X via drivers/pci/msi",
    "P17": "drivers/iommu (DMAR fault), drivers/nvme/host/pci.c nvme_map_data() / nvme_setup_prps()",
    "P18": "drivers/nvme/host/pci.c nvme_setup_prps() / nvme_pci_setup_sgls(); core.c nvme_setup_cmd()",
    "P19": "drivers/pci/probe.c, pci.c pci_dev_wait() / pcie_flr() / pci_set_power_state()",
    "P20": "drivers/pci/pcie/aspm.c, drivers/nvme/host/core.c nvme_configure_apst(); pci_pm_runtime_resume()",
    "P21": "drivers/pci (message handling), drivers/pci/pcie/ptm.c, MCTP-over-PCIe VDM in the BMC",
    "P22": "block layer / blk-mq; nvme-pci queue mapping (nvme_pci_map_queues); device-side latency",
    "P23": "filesystem / block layer; no driver error - data verified by an oracle (fio verify, readback)",
    "P24": "drivers/nvme/host/core.c nvme_flush / FUA; power-loss behaviour is device side",
    "P25": "drivers/nvme/host/core.c admin passthrough (nvme_submit_user_cmd) timeouts, nvme-cli",
    "P26": "drivers/nvme/host/core.c nvme_handle_aen_notice() / nvme_get_log(); nvme_aen_uevent()",
    "P27": "analyzer / export settings (no driver path): capture integrity",
    "E": "outside the probed PCIe link: host stack, fabric, other path or media physics",
}


def load_cards():
    cards = json.load(open(CARDS_JSON, encoding="utf-8"))
    out = {}
    for c in cards:
        pats = re.findall(r"P\d\d", c["card"].get("CSV pattern", ""))
        c["pattern"] = pats[0] if pats else "E"
        c["patterns"] = pats or ["E"]
        out[c["id"]] = c
    return out


def enrich(card):
    """The atlas text that explains a card: why, driver path, how to prove, what to do."""
    k = card["card"]
    def g(*names):
        for n in names:
            if k.get(n):
                return k[n]
        return ""
    driver = g("Linux v7.2 source") or PATTERN_DRIVER.get(card["pattern"], "")
    return {
        "card_id": card["id"], "title": card["title"], "layer": card["layer"], "pattern": card["pattern"],
        "visibility": card["pex"], "symptom_class": card["rep"], "origin_badge": card["origin"],
        "origin_decided_by": g("Origin"),
        "in_a_pex_trace": g("In a PEX trace"),
        "what_happens": g("What happens"),
        "why": g("Typical causes", "Why it occurs"),
        "how_it_shows_up": g("How it shows up"),
        "driver_path": driver,
        "driver_path_source": "card" if k.get("Linux v7.2 source") else "pattern default",
        "how_to_prove": g("How to detect / prove", "How to detect / measure"),
        "what_else_proves_it": g("What else proves it"),
        "fix_or_test": g("Test to provoke it", "Corrective / validation action"),
        "spec_basis": g("Spec basis"),
        "false_positive_limits": g("Common false positive or limit"),
    }


def sig(f):
    """Signature token of one finding: rule plus a normalised qualifier."""
    q = re.sub(r"\d{3,}", "#", str(f[3]))[:48]
    return f[2] + (":" + q if q else "")


def build_library(runs):
    """runs: list of (findings, truth_dir) from calibration captures (never the capture under test).
    Per card, signature counts are averaged over the captures so a token seen in every capture weighs
    more than one that appeared by chance in a single capture."""
    per = defaultdict(Counter)
    ids = []
    for findings, truth_dir in runs:
        T = Truth(truth_dir)
        ids = [e["card_id"] for e in T.eps]
        for f in findings:
            e = T.episode_of(f[0])
            if e is not None:
                per[e["card_id"]][sig(f)] += 1.0 / len(runs)
    cards = {cid: {t: round(v, 3) for t, v in per.get(cid, {}).items()} for cid in ids}
    df = Counter()
    for c in cards.values():
        df.update(c.keys())
    return {"sources": [os.path.abspath(t) for _, t in runs], "n_cards": len(cards), "df": dict(df), "cards": cards}


class Classifier:
    def __init__(self, library_path):
        lib = json.load(open(library_path))
        self.cards_db = load_cards()
        n = lib["n_cards"]
        self.idf = {t: math.log((1 + n) / (1 + c)) + 1.0 for t, c in lib["df"].items()}
        self.default_idf = math.log(1 + n) + 1.0
        self.vecs = {}
        for cid, toks in lib["cards"].items():
            v = self._vec(toks)
            if v:
                self.vecs[cid] = v
        # ambiguity groups: cards with near-identical signatures
        self.twins = defaultdict(set)
        ids = list(self.vecs)
        for i, a in enumerate(ids):
            for b in ids[i + 1:]:
                if self._cos(self.vecs[a], self.vecs[b]) > 0.97:
                    self.twins[a].add(b)
                    self.twins[b].add(a)

    def _vec(self, toks):
        v = {}
        for t, c in toks.items():
            rule = t.split(":")[0]
            w = 1.0 if RULES.get(rule, {}).get("level") == DEFECT else 0.35
            v[t] = (1 + math.log(max(c, 1.0))) * self.idf.get(t, self.default_idf) * w
        norm = math.sqrt(sum(x * x for x in v.values()))
        return {t: x / norm for t, x in v.items()} if norm else {}

    @staticmethod
    def _cos(a, b):
        if len(a) > len(b):
            a, b = b, a
        return sum(x * b.get(t, 0.0) for t, x in a.items())

    def pattern_vote(self, findings):
        votes = Counter()
        defects = [f for f in findings if RULES[f[2]]["level"] == DEFECT]
        for i, f in enumerate(sorted(defects, key=lambda x: x[0])):
            pats = RULES[f[2]]["patterns"]
            w = (2.0 if i == 0 else 1.0) / max(1, len(pats))
            for p in pats:
                votes[p] += w
        return votes.most_common()

    def rank(self, findings, k=5):
        toks = Counter(sig(f) for f in findings)
        v = self._vec(toks)
        pv = dict(self.pattern_vote(findings))
        tot = sum(pv.values()) or 1.0
        scored = []
        for cid, cv in self.vecs.items():
            s = self._cos(v, cv)
            if s <= 0:
                continue
            card = self.cards_db.get(cid)
            prior = sum(pv.get(p, 0.0) for p in card["patterns"]) / tot if card else 0.0
            scored.append((s * (0.85 + 0.15 * prior), s, prior, cid))
        scored.sort(reverse=True)
        out = []
        for score, s, prior, cid in scored[:k]:
            out.append({"card_id": cid, "score": round(score, 4), "cosine": round(s, 4),
                        "pattern_prior": round(prior, 3), "title": self.cards_db[cid]["title"],
                        "equally_consistent_with": sorted(self.twins.get(cid, ()))})
        return out
