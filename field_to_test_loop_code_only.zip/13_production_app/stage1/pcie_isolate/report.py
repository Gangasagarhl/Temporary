"""Evaluation of a run against ground truth, and the human-readable report."""
import json
import os
import pickle
from collections import Counter, defaultdict

from .evaluate import Truth, score_findings
from .rules import APPROACH_TIERS


def evaluate_run(run_dir, truth_dir):
    from .host_evidence import load_all
    findings = load_all(run_dir)
    T = Truth(truth_dir)
    res = {"approaches": {}}
    for a in APPROACH_TIERS:
        r = score_findings(findings, T, a)
        res["approaches"][a] = r
    inc_path = os.path.join(run_dir, "incidents.json")
    if os.path.exists(inc_path):
        res["isolation"] = evaluate_incidents(json.load(open(inc_path)), T)
    json.dump(res, open(os.path.join(run_dir, "evaluation.json"), "w"), indent=1)
    for a, r in res["approaches"].items():
        print("%-14s detected %3d/%d  FP findings %5d at %3d places  key-row localised %d/%d" %
              (a, r["episodes_detected"], r["episodes_total"], r["false_positive_findings"],
               r["false_positive_places"], r["key_row_localised"], r["episodes_with_key_rows_detected"]))
    if "isolation" in res:
        print(json.dumps({k: v for k, v in res["isolation"].items() if not isinstance(v, (list, dict)) or
                          k in ("by_visibility", "incident_types")}, indent=1))
    return res


def evaluate_incidents(incs, T):
    ep_incs = defaultdict(list)
    kinds = Counter()
    fp_incs = []
    for inc in incs:
        g = inc.get("grouping") or {}
        if g.get("kind") == "series" and g.get("series_pkts"):
            # a series is located at every one of its members, not at a span
            seen, eps = set(), []
            for p in g["series_pkts"]:
                for e in T.episodes_overlapping(p, p):
                    if id(e) not in seen:
                        seen.add(id(e))
                        eps.append(e)
        else:
            eps = T.episodes_overlapping(inc["start_pkt"], inc["end_pkt"])
        if not eps:
            if T.aftermath_of(inc["start_pkt"]):
                kinds["aftermath of an episode"] += 1
            else:
                kinds["false positive"] += 1
                fp_incs.append(inc["id"])
            continue
        kinds["one episode" if len(eps) == 1 else "several adjacent episodes"] += 1
        for e in eps:
            ep_incs[e["card_id"]].append(inc)
    top1 = top3 = group = pat = start_ok = 0
    per_vis = defaultdict(lambda: Counter())
    per_pat = defaultdict(lambda: Counter())
    rows = []
    for e in T.eps:
        cid = e["card_id"]
        v = e["pex_visibility"]
        per_vis[v]["total"] += 1
        per_pat[e["pattern"]]["total"] += 1
        lst = ep_incs.get(cid, [])
        if not lst:
            rows.append({"card": cid, "detected": False})
            continue
        per_vis[v]["detected"] += 1
        per_pat[e["pattern"]]["detected"] += 1
        cands = [c for inc in lst for c in inc["atlas_candidates"]]
        best = max(lst, key=lambda inc: max([c["score"] for c in inc["atlas_candidates"] if c["card_id"] == cid]
                                             or [0]))
        ranked = [c["card_id"] for c in best["atlas_candidates"]]
        t1 = bool(ranked) and ranked[0] == cid
        t3 = cid in ranked[:3]
        grp = t1 or (bool(best["atlas_candidates"]) and cid in best["atlas_candidates"][0]["equally_consistent_with"])
        pv = [p for inc in lst for p, _ in inc["pattern_vote"][:1]]
        pk = e["pattern"] in pv
        def nearest(inc):
            g = inc.get("grouping") or {}
            pts = g.get("series_pkts") if g.get("kind") == "series" and g.get("series_pkts") else [inc["first_abnormal"]["pkt"]]
            return min(pts, key=lambda p: min(abs(p - k) for k in e["keys"]) if e["keys"] else 0)
        first = min((nearest(inc) for inc in lst), key=lambda p: min(abs(p - k) for k in e["keys"]) if e["keys"] else 0)
        so = bool(e["keys"]) and min(abs(first - k) for k in e["keys"]) <= 32
        top1 += t1
        top3 += t3
        group += grp
        pat += pk
        start_ok += so
        per_vis[v]["top1"] += t1
        per_vis[v]["top3"] += t3
        per_pat[e["pattern"]]["top1"] += t1
        rows.append({"card": cid, "detected": True, "top1": t1, "top3": t3, "in_group": grp, "pattern_ok": pk,
                     "start_within_32_rows_of_key": so, "incidents": [i["id"] for i in lst],
                     "predicted": ranked[:3]})
    det = sum(1 for r in rows if r["detected"])
    with_keys = sum(1 for e in T.eps if e["keys"] and ep_incs.get(e["card_id"]))
    return {
        "incidents": len(incs),
        "incident_types": dict(kinds),
        "episodes_isolated": det,
        "card_top1": top1, "card_top3": top3, "card_top1_or_ambiguity_group": group,
        "pattern_correct": pat,
        "first_abnormal_within_32_rows_of_key_row": start_ok, "episodes_with_key_rows_isolated": with_keys,
        "by_visibility": {k: dict(v) for k, v in per_vis.items()},
        "by_pattern": {k: dict(v) for k, v in sorted(per_pat.items())},
        "false_positive_incidents": fp_incs,
        "per_card": rows,
    }


def write_report(run_dir):
    """Readable per-incident isolation report (markdown)."""
    incs = json.load(open(os.path.join(run_dir, "incidents.json")))
    rev = {}
    rp = os.path.join(run_dir, "llm_reviews.jsonl")
    if os.path.exists(rp):
        for line in open(rp):
            r = json.loads(line)
            rev[r["id"]] = r
    L = ["# Isolated defects", ""]
    for inc in incs:
        top = inc["atlas_candidates"][0] if inc["atlas_candidates"] else None
        ex = inc.get("explanation") or {}
        L.append("## %s  packets %d-%d  (%s)" % (inc["id"], inc["start_pkt"], inc["end_pkt"],
                                                 top["card_id"] + " " + top["title"] if top else "unclassified"))
        L.append("- **Starts** at packet %d (%s): %s - %s" % (inc["first_abnormal"]["pkt"], inc["start_time"],
                                                            inc["first_abnormal"]["rule"],
                                                            inc["first_abnormal"]["detail"]))
        L.append("- **Concluded** at packet %d (%s); %d findings; verdict %s" %
                 (inc["end_pkt"], inc["end_time"], inc["n_findings"], inc["verdict"]))
        L.append("- **Who**: %s (%s)" % (inc["attribution"]["origin"], inc["attribution"]["rule"]))
        L.append("- **Task**: %s" % inc["task"])
        if inc["nvme_commands"]:
            L.append("- **Command**: " + "; ".join("%s CID %s SQ%s%s" % (c["name"], c["cid"], c["sqid"],
                                                                        (" SLBA %s, %s blocks" % (c["slba"], c["blocks"]))
                                                                        if "slba" in c else "")
                                                  for c in inc["nvme_commands"]))
        if ex:
            L.append("- **Driver path**: %s" % ex.get("driver_path", ""))
            L.append("- **Why**: %s %s" % (ex.get("what_happens", ""), ex.get("why", "")))
            L.append("- **Prove / fix**: %s" % (ex.get("fix_or_test") or ex.get("how_to_prove", "")))
        if inc["id"] in rev:
            r = rev[inc["id"]]
            L.append("- **LLM review (%s)**: %s - %s" % (r.get("model"), r.get("verdict"), r.get("summary", "")))
        L.append("- **Evidence packets**: %s" % ", ".join(str(p) for p in inc["key_pkts"][:20]))
        L.append("")
    open(os.path.join(run_dir, "isolation_report.md"), "w").write("\n".join(L))
    print("report -> %s" % os.path.join(run_dir, "isolation_report.md"))
