"""Verify a list of KNOWN or SUSPECTED errors against the isolated incidents of a run.

Input: the errors someone already found (a ticket, dmesg lines, a tester's list), one per line in a text file or
a JSON list of {"text": ..., "time": <host seconds, optional>, "card": "S-25" (optional), "rule": "NVME.STATUS" (optional)}.

For every expected error the stage
  1. matches it to incidents: card ids and rule ids named in the text (strong), status codes (SC 0x..), the
     message-class catalogue used for host logs (timeout / reset / AER / ...), keyword overlap with each
     incident's card title, rule texts and finding details, and host-clock proximity when a time and a clock
     offset are known;
  2. reports the best incidents with their CSV line span, first abnormal row, evidence rows and fix;
  3. if nothing matches above the threshold: runs the capture checklist (does the capture cover the time, mid-traffic
     start, payload, filters, gaps, wire visibility of the card family, host documents fused, thresholds) and
     states which of them explains the absence;
  4. optionally asks the model to research the error against the candidates and the capture facts (schema-validated:
     matched incident or none, why absent, what to capture next) - the agent's "research and adapt" step.

Outputs: expected_errors.json and expected_errors_report.md in the run directory.
"""
import json
import os
import re
from collections import Counter

from .host_evidence import CATALOGUE, classify
from .rules import RULES

CARD_RX = re.compile(r"\b([A-Z]-\d{2,3})\b")
RULE_RX = re.compile(r"\b([A-Z]{1,5}\.[A-Z0-9_]{3,})\b")
SC_RX = re.compile(r"\b(?:SC|status)\s*(?:=\s*)?0x([0-9A-Fa-f]{1,2})\b", re.I)
# how people describe failures -> the rule families that show them on the wire (phrase match is case-insensitive)
PHRASES = [
    (r"link (went |is )?down|link (loss|lost|drop)|surprise down|hot[- ]?plug|removed|unplug", ("LINK.DOWN", "LINK.DOWN_INFLIGHT", "TXN.LOST_LINKDOWN", "PHY.EIDLE_NO_EIOS")),
    (r"\b(8|16|32|2\.5|5)(\.0)? ?gt/?s|gen ?[2-6]|speed|downgrad|slower link|x[124] width|lane", ("PHY.SPEED_DOWN", "PHY.WIDTH_CHANGE", "PHY.SPEED_CHANGE", "PHY.TS_RATE")),
    (r"retrain|recovery|training|ltssm|equali[sz]ation|eq ", ("LINK.RECOVERY", "LINK.RECOVERY_STORM", "LINK.TRAIN_SLOW", "PHY.EQ_TIMEOUT", "PHY.EQ_REDO")),
    (r"no device|disappear|gone|all[- ]ones|0xffff|not present|receiver detect", ("PHY.RXDETECT_FAIL", "REG.ALL_ONES", "LINK.DOWN")),
    (r"lcrc|crc|nak|replay|bad tlp|bad dllp|receiver error|symbol|disparity|sync header|framing", ("DLL.", "PHY.SYMBOL_ERR")),
    (r"poison|ecrc|malformed|unsupported request|\bur\b|completer abort|\bca\b|\bcrs\b|unexpected completion", ("TLP.POISONED", "TLP.ECRC_BAD", "TLP.CPL_STATUS", "TXN.UNEXPECTED_CPL", "TLP.MPS", "TLP.MRRS", "TLP.4K", "TLP.BE")),
    (r"completion time ?out|cmplto|no completion|cplto", ("TXN.CPL_TIMEOUT", "TXN.LOST_LINKDOWN")),
    (r"aer|err_cor|err_fatal|err_nonfatal|correctable|uncorrectable|dpc|containment", ("MSG.ERR", "CFG.AER_STATUS", "DLL.", "TLP.POISONED", "LINK.DOWN")),
    (r"flow control|credit|updatefc|initfc|starv", ("FC.",)),
    (r"time ?out|timed out|stopped answering|hang|hung|stall|never complet|no response|aborting|aborted|abort", ("NVME.CMD_TIMEOUT", "NVME.NOT_FETCHED", "NVME.ABORT", "NVME.HOST_ABORT_EARLY", "REG.RDY_TIMEOUT", "TXN.CPL_TIMEOUT")),
    (r"reset|resetting|disable controller|cc\.en|not ready|csts|cfs|fatal status", ("REG.", "LINK.DOWN_HOST", "PHY.TS_HOTRESET")),
    (r"status|sct|\bsc\b|dnr|invalid field|invalid opcode|out of range|lba|namespace|capacity exceeded|write fault|unrecovered|media error|i/o error|blk_update", ("NVME.STATUS", "NVME.SQE_", "TLP.CPL_STATUS")),
    (r"doorbell|tail|head|queue (size|full|overflow)|sq ?\d|cq ?\d", ("DB.", "NVME.PHASE", "NVME.SQHD", "NVME.CQE_SQID")),
    (r"interrupt|msi|irq|vector|poll(ed|ing)? completion|lost completion", ("NVME.NO_MSIX", "NVME.MSIX_WRONG_VECTOR", "NVME.MSIX_BEFORE_CQE", "NVME.MSIX_ADDR", "CFG.INTX_WITH_MSIX")),
    (r"miscompare|verify|checksum|corrupt|wrong data|stale|zero|dealloc|trim|discard|write zeroes|data loss|lost write|torn", ("DATA.", "NVME.ADMIN_FAST")),
    (r"power|flush|fua|unsafe shutdown|power[- ]?cut|power loss|persist", ("DATA.LOST_AFTER_POWER", "DATA.POWER_CUT", "PHY.EIDLE_NO_EIOS", "NVME.FEATURE")),
    (r"aspm|l1\.?[12]?|l0s|ltr|clkreq|wake|resume|suspend|d3|runtime pm|apst|power state", ("PM.", "CFG.D3_ACCESS", "CFG.D0_EARLY", "PM.RESUME_SLOW")),
    (r"slow|latency|throughput|bandwidth|tail|p99|degraded|throttl|thermal|iops", ("S.", "FC.STALL", "PHY.SPEED_DOWN", "NVME.ADMIN_LONG")),
    (r"format|sanitize|self[- ]?test|firmware|fw (commit|activat|download)|activation", ("NVME.ADMIN_LONG", "REG.PP_LONG", "NVME.ADMIN_FAST")),
    (r"aen|async(hronous)? event|smart|critical warning|error log|log page|telemetry", ("NVME.AEN", "NVME.LOG_CRITICAL")),
    (r"bar|config(uration)? space|capabilit|enumerat|flr|function level reset|bus master|memory space", ("CFG.", "TLP.CFG_FORMAT", "TXN.CRS_LONG")),
    (r"prp|sgl|mdts|dma|outside the buffer|wrong address|iommu|dmar", ("NVME.SQE_PRP", "NVME.SQE_MDTS", "NVME.DMA_OUTSIDE", "NVME.DMA_AFTER_CQE", "NVME.PRP_LIST")),
    (r"buffer wrap|filter|trigger|analy[sz]er|capture|export|resync|jammer|gap in the trace", ("CI.",)),
    (r"tcp|rdma|fabrics|nvme-of|nvmeof|tls|multipath|\bana\b|other port|dual[- ]port|second controller", ("H.OTHER_PATH",)),
]
PHRASES = [(re.compile(p, re.I), fams) for p, fams in PHRASES]

DURATION_RX = re.compile(r"\b(\d+(?:\.\d+)?)\s*(ms|us|µs|s)\b", re.I)

STOP = set("the a an of to in on for and or is are was were be been with at by from this that it its as into after "
           "before not no yes error errors nvme nvme0 pci pcie device host controller command commands".split())

# message class (host_evidence catalogue) -> engine rule families it corresponds to
CLASS_RULES = {
    "nvme_timeout": ("NVME.CMD_TIMEOUT", "NVME.NOT_FETCHED", "TXN.CPL_TIMEOUT", "NVME.HOST_ABORT_EARLY"),
    "nvme_reset": ("REG.CTRL_RESET", "REG.RESET_UNEXPLAINED", "REG.RDY_TIMEOUT", "LINK.DOWN", "PHY.TS_HOTRESET"),
    "io_error": ("NVME.STATUS", "TLP.CPL_STATUS"),
    "aer": ("MSG.ERR", "DLL.LCRC_BAD", "DLL.NAK", "DLL.REPLAY", "TLP.POISONED", "TLP.ECRC_BAD", "LINK.DOWN",
            "CFG.AER_STATUS", "TXN.CPL_TIMEOUT"),
    "iommu": ("NVME.DMA_OUTSIDE", "TXN.CPL_TIMEOUT"),
    "verify": ("DATA.MISCOMPARE", "DATA.NOT_ZERO", "DATA.LOST_AFTER_POWER"),
    "capture": ("CI.MARKER", "CI.RECORDING_GAP", "CI.DLLP_FILTERED", "CI.ANALYZER_RESYNC", "CI.TS_TIE", "CI.JAMMER"),
    "platform": ("PM.", "PHY.", "LINK.", "CFG."),
    "host_trace": ("S.", "NVME.NO_MSIX", "NVME.MSIX_WRONG_VECTOR"),
    "device_log": ("NVME.AEN", "NVME.LOG_CRITICAL", "REG.CFS", "NVME.STATUS"),
    "fabrics": ("H.OTHER_PATH",), "multipath": ("H.OTHER_PATH",), "lab": ("H.LAB_RESULT",),
}


def load_expected(path):
    if path.endswith(".json"):
        items = json.load(open(path))
        return [i if isinstance(i, dict) else {"text": str(i)} for i in items]
    out = []
    for line in open(path, encoding="utf-8", errors="replace"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        rec = {"text": line}
        m = re.match(r"^@([\d.]+)s?\s+(.*)$", line)          # "@123.456 message" = host time in seconds
        if m:
            rec["time"], rec["text"] = float(m.group(1)), m.group(2)
        out.append(rec)
    return out


def words(s):
    return {w for w in re.findall(r"[a-z0-9_]{3,}", s.lower()) if w not in STOP}


def incident_bag(inc):
    parts = [inc.get("task", "")]
    for c in inc["atlas_candidates"][:3]:
        parts.append(c["title"])
    for f in inc["findings"][:30]:
        parts.append(f["rule"] + " " + f["detail"])
        parts.append(RULES[f["rule"]]["text"])
    ex = inc.get("explanation") or {}
    parts.append(ex.get("how_it_shows_up", ""))
    parts.append(ex.get("what_happens", ""))
    return " ".join(parts)


def score(exp, inc, bags, offset_s, time_index):
    s, why = 0.0, []
    text = exp["text"]
    cards = set(CARD_RX.findall(text)) | ({exp["card"]} if exp.get("card") else set())
    cand = [c["card_id"] for c in inc["atlas_candidates"][:3]]
    for c in cards:
        if c in cand:
            s += 3.0 if cand[0] == c else 2.0
            why.append("card %s named" % c)
    rules = set(RULE_RX.findall(text)) | ({exp["rule"]} if exp.get("rule") else set())
    for rid in rules:
        if rid in inc["rules"]:
            s += 2.5
            why.append("rule %s named" % rid)
    for m in SC_RX.findall(text):
        q = "/0x%02X" % int(m, 16)
        if any(f["rule"] == "NVME.STATUS" and f["qual"].endswith(q) for f in inc["findings"]):
            s += 2.5
            why.append("status SC 0x%02X matches" % int(m, 16))
    _, cls = classify(text, "dmesg")
    fams = CLASS_RULES.get(cls, ())
    if any(r.startswith(fams) for r in inc["rules"]) if fams else False:
        s += 1.0
        why.append("message class %s" % cls)
    hit_fams, root_hit = 0, False
    root_rule = inc["first_abnormal"]["rule"]
    for rx, pf in PHRASES:
        if rx.search(text) and any(r.startswith(pf) for r in inc["rules"]):
            hit_fams += 1
            root_hit = root_hit or root_rule.startswith(pf)
    if hit_fams:
        s += min(3.0, 1.5 * hit_fams)                     # phrases in the error text name this incident's rule family
        why.append("%d phrase-family match%s" % (hit_fams, "es" if hit_fams > 1 else ""))
    if root_hit:
        s += 1.0
        why.append("names the root rule's family")
    # a duration in the error text ("30 s", "100 ms", "2.5 s") that a finding detail reproduces (+-10%)
    for num, unit in DURATION_RX.findall(text):
        want = float(num) * {"s": 1e6, "ms": 1e3, "us": 1.0, "µs": 1.0}[unit.lower()]
        for f in inc["findings"][:30]:
            ok = False
            for n2, u2 in DURATION_RX.findall(f["detail"]):
                got = float(n2) * {"s": 1e6, "ms": 1e3, "us": 1.0, "µs": 1.0}[u2.lower()]
                if want and abs(got - want) / want <= 0.1:
                    ok = True
            if ok:
                s += 1.5
                why.append("duration %s %s matches a finding" % (num, unit))
                break
    x = isolation_of(inc["id"])
    if x and (x.get("llm_review") or {}).get("verdict") == "CONFIRMED":
        s += 0.5
        why.append("reviewer confirmed")
    ov = words(text) & bags[inc["id"]]
    if ov:
        s += min(2.0, 0.25 * len(ov))
        why.append("keywords " + ", ".join(sorted(ov)[:6]))
    if exp.get("time") is not None and offset_s is not None and time_index:
        wt = (exp["time"] - offset_s) * 1e12
        t0 = time_index.get(inc["start_pkt"])
        if t0 is not None:
            d = abs(wt - t0) / 1e12
            if d < 0.5:
                s += 2.0
                why.append("within 0.5 s of the host time")
            elif d < 5:
                s += 1.0
                why.append("within 5 s of the host time")
            elif d > 60:
                s -= 1.0
    return s, why


_ISO = {}


def isolation_of(iid):
    return _ISO.get(iid)


def capture_checklist(run, inc_count, host):
    c = run.get("capture", {})
    L = []
    L.append(("capture starts mid-traffic (queue state unknown before the next init)", bool(c.get("starts_mid_traffic"))))
    L.append(("controller initialisation NOT captured", not c.get("controller_enable_seen")))
    L.append(("no payload (NVMe-level rules did not run)", c.get("payload", "").startswith("none")))
    L.append(("columns missing from the export", bool(c.get("columns_missing"))))
    L.append(("no host documents fused (fuse not run or 0 records placed)",
              not host or not host.get("error_records_placed")))
    L.append(("no incidents at all in this run (check thresholds on a known-good capture)", inc_count == 0))
    return [{"check": k, "applies": v} for k, v in L]


def verify(run_dir, expected_path, model=None, backend="dry-run", threshold=2.5):
    exps = load_expected(expected_path)
    run = json.load(open(os.path.join(run_dir, "run.json")))
    incs = json.load(open(os.path.join(run_dir, "incidents.json")))
    iso = {}
    ip = os.path.join(run_dir, "isolation.json")
    if os.path.exists(ip):
        iso = {x["id"]: x for x in json.load(open(ip))}
    _ISO.clear()
    _ISO.update(iso)
    host = None
    hp = os.path.join(run_dir, "host_alignment.json")
    if os.path.exists(hp):
        host = json.load(open(hp))
    offset = host.get("clock_offset_s") if host else None
    tix = {}
    tp = os.path.join(run_dir, "time_index.npz")
    if os.path.exists(tp):
        import numpy as np
        z = np.load(tp)
        tix = {int(p): int(t) for t, p in zip(z["t"], z["pkt"])}
    time_index = {}
    if tix:
        import bisect
        keys = sorted(tix)
        for inc in incs:
            i = bisect.bisect_right(keys, inc["start_pkt"]) - 1
            time_index[inc["start_pkt"]] = tix[keys[max(i, 0)]]
    bags = {inc["id"]: words(incident_bag(inc)) for inc in incs}
    results = []
    for n, exp in enumerate(exps, 1):
        scored = sorted(((score(exp, inc, bags, offset, time_index), inc) for inc in incs),
                        key=lambda x: -x[0][0])[:3]
        best = scored[0] if scored and scored[0][0][0] >= threshold else None
        rec = {"n": n, "error": exp, "matched": bool(best), "candidates": []}
        for (s, why), inc in scored:
            if s <= 0:
                continue
            x = iso.get(inc["id"], {})
            rec["candidates"].append({
                "incident": inc["id"], "score": round(s, 2), "why": why, "status": x.get("status"),
                "card": inc["atlas_candidates"][0]["card_id"] if inc["atlas_candidates"] else None,
                "title": inc["atlas_candidates"][0]["title"] if inc["atlas_candidates"] else None,
                "csv_lines": inc.get("csv_lines"), "packets": [inc["start_pkt"], inc["end_pkt"]],
                "first_abnormal": inc["first_abnormal"], "who": inc["attribution"]["origin"],
                "evidence": [{"rule": f["rule"], "line": f.get("line"), "pkt": f["pkt"], "detail": f["detail"][:140]}
                             for f in inc["findings"] if f["level"] == "DEFECT"][:5],
                "fix": (x.get("fix") or {}).get("corrective_action"),
                "llm_verdict": (x.get("llm_review") or {}).get("verdict")})
        if not best:
            rec["why_absent"] = [c for c in capture_checklist(run, len(incs), host) if c["applies"]]
            rec["next"] = ("fix the capture conditions above and re-run" if rec["why_absent"] else
                           "the capture looks adequate: either the error is not wire-visible (collect the atlas "
                           "card's outside evidence and run fuse), or it happened outside this capture's time span, "
                           "or a threshold needs tuning (run a known-good capture first)")
        results.append(rec)
    if model and backend != "dry-run":
        research(results, run, model, backend)
    json.dump(results, open(os.path.join(run_dir, "expected_errors.json"), "w"), indent=1)
    write_md(run_dir, results)
    m = sum(1 for r in results if r["matched"])
    print("expected errors: %d, matched %d, not found %d -> %s" % (len(results), m, len(results) - m,
                                                                 os.path.join(run_dir, "expected_errors_report.md")))
    return results


VERIFY_SCHEMA = {
    "type": "object",
    "properties": {
        "matched_incident": {"type": "string", "description": "incident id from the candidates, or 'none'"},
        "confidence": {"type": "number"},
        "reasoning": {"type": "string", "description": "OBSERVED:/RULE:/HYPOTHESIS: sentences citing incident ids and packets"},
        "if_none_why_absent": {"type": "string"},
        "recapture": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["matched_incident", "confidence", "reasoning", "if_none_why_absent", "recapture"],
    "additionalProperties": False,
}

VERIFY_SYSTEM = """You research one reported error against the defects an engine isolated from a PCIe/NVMe analyzer
capture. You get the error text (from a host log, a ticket or a tester), up to three candidate incidents (each with
its atlas card, first abnormal row, evidence and status) and the capture facts. Decide which candidate IS this error,
or 'none'. Cite incident ids and packet numbers you were given; label sentences OBSERVED: / RULE: / HYPOTHESIS:.
If none: say why the capture cannot show it (mid-traffic start, no payload, filter/gap, outside the time span,
not wire-visible by design - then name the host/device document that would prove it) and list what to capture or
export next. Never invent an incident or a packet."""


def research(results, run, model, backend):
    from .llm import CAPTURE_CTX, import_anthropic, load_env, pick_backend
    load_env()
    backend = pick_backend(backend)
    c = run.get("capture", {})
    facts = "CAPTURE: starts %s; controller init %s; payload %s; span %.1f s" % (
        "mid-traffic" if c.get("starts_mid_traffic") else "at boot/link-up",
        "captured" if c.get("controller_enable_seen") else "NOT captured", c.get("payload"),
        (run["last_t"] - run["first_t"]) / 1e12)
    client = None
    if backend == "sdk":
        anthropic = import_anthropic()
        client = anthropic.Anthropic(max_retries=4)
    for r in results:
        L = ["ERROR: " + r["error"]["text"], facts, "CANDIDATES:"]
        for cnd in r["candidates"]:
            L.append("- %s card %s %s | status %s | lines %s-%s pkts %s | first #%d %s: %s | who %s | match: %s" % (
                cnd["incident"], cnd["card"], (cnd["title"] or "")[:60], cnd["status"],
                (cnd["csv_lines"] or {}).get("start"), (cnd["csv_lines"] or {}).get("end"), cnd["packets"],
                cnd["first_abnormal"]["pkt"], cnd["first_abnormal"]["rule"], cnd["first_abnormal"]["detail"][:100],
                cnd["who"], "; ".join(cnd["why"])))
            for e in cnd["evidence"][:3]:
                L.append("    %s @ line %s / #%d: %s" % (e["rule"], e["line"], e["pkt"], e["detail"][:100]))
        if not r["candidates"]:
            L.append("- none scored above zero")
        if r.get("why_absent"):
            L.append("CAPTURE CHECKLIST (applies): " + "; ".join(x["check"] for x in r["why_absent"]))
        prompt = "\n".join(L)
        out = {"backend": backend, "model": model}
        try:
            if backend == "cli":
                from .llm import cli_structured
                v, info = cli_structured("claude", model, VERIFY_SYSTEM, VERIFY_SCHEMA, prompt)
                out.update(info)
                if v:
                    out.update(v)
            else:
                resp = client.messages.create(model=model, max_tokens=2000,
                                              system=[{"type": "text", "text": VERIFY_SYSTEM}],
                                              messages=[{"role": "user", "content": prompt}],
                                              output_config={"effort": "low", "format": {"type": "json_schema",
                                                                                         "schema": VERIFY_SCHEMA}})
                out.update(json.loads(next(b.text for b in resp.content if b.type == "text")))
        except Exception as e:
            out["error"] = str(e)[:200]
        ids = {cnd["incident"] for cnd in r["candidates"]}
        if out.get("matched_incident") not in ids | {"none", None}:
            out["error"] = "model named an incident it was not given: %s" % out.get("matched_incident")
            out["matched_incident"] = "none"
        r["research"] = out


def write_md(run_dir, results):
    L = ["# Expected errors verified against the capture", ""]
    for r in results:
        e = r["error"]
        L.append("## %d. %s" % (r["n"], e["text"][:160]))
        if r["matched"]:
            c = r["candidates"][0]
            L.append("- **FOUND**: %s (score %.1f: %s)" % (c["incident"], c["score"], "; ".join(c["why"])))
            L.append("- card %s %s | status %s | who %s" % (c["card"], (c["title"] or "")[:80], c["status"], c["who"]))
            cl = c["csv_lines"] or {}
            L.append("- **CSV lines %s-%s** (packets %d-%d); first abnormal row: line %s, packet #%d: %s - %s" % (
                cl.get("start", "?"), cl.get("end", "?"), c["packets"][0], c["packets"][1], cl.get("first_abnormal", "?"),
                c["first_abnormal"]["pkt"], c["first_abnormal"]["rule"], c["first_abnormal"]["detail"][:120]))
            for ev in c["evidence"]:
                L.append("  - %s @ line %s / #%d: %s" % (ev["rule"], ev["line"], ev["pkt"], ev["detail"]))
            if c.get("fix"):
                L.append("- fix / validation: %s" % c["fix"][:300])
            if c.get("llm_verdict"):
                L.append("- reviewer verdict on this incident: %s" % c["llm_verdict"])
            if len(r["candidates"]) > 1:
                L.append("- other candidates: " + ", ".join("%s (%.1f)" % (x["incident"], x["score"]) for x in r["candidates"][1:]))
        else:
            L.append("- **NOT FOUND** in this capture (best score %s)" % (r["candidates"][0]["score"] if r["candidates"] else "none"))
            if r["candidates"]:
                c = r["candidates"][0]
                L.append("  - closest incident (below threshold): %s %s %s - %s" % (c["incident"], c["card"], (c["title"] or "")[:60],
                                                                                   "; ".join(c["why"])[:120]))
            for x in r.get("why_absent", []):
                L.append("  - capture condition: %s" % x["check"])
            L.append("- next: %s" % r.get("next"))
        rs = r.get("research")
        if rs and "error" not in rs:
            L.append("- **model research**: matched %s (%.2f) - %s" % (rs.get("matched_incident"), rs.get("confidence") or 0,
                                                                     (rs.get("reasoning") or "")[:500]))
            if rs.get("matched_incident") == "none":
                L.append("  - why absent: %s" % (rs.get("if_none_why_absent") or "")[:300])
                if rs.get("recapture"):
                    L.append("  - recapture: " + " | ".join(rs["recapture"][:4]))
        elif rs:
            L.append("- model research: not available (%s)" % rs["error"][:120])
        L.append("")
    open(os.path.join(run_dir, "expected_errors_report.md"), "w").write("\n".join(L))
