"""Command line entry points.

  python3 -m pcie_isolate.cli analyze  --csv TRACE.csv [--payload payload_sidecar.csv] --out DIR
  python3 -m pcie_isolate.cli library  --calib-run DIR --calib-truth SIDECAR_DIR [repeat] --out signatures.json
  python3 -m pcie_isolate.cli fuse     --run DIR [--dmesg dmesg_x.txt] [--events host_events.jsonl]
  python3 -m pcie_isolate.cli isolate  --run DIR --library signatures.json --csv TRACE.csv [--payload ...]
  python3 -m pcie_isolate.cli evaluate --run DIR --truth SIDECAR_DIR
  python3 -m pcie_isolate.cli review   --run DIR [--model claude-haiku-5-5] [--limit N]
  python3 -m pcie_isolate.cli verify   --run DIR --expected errors.txt [--backend sdk]   # known-error list
  python3 -m pcie_isolate.cli report   --run DIR
  python3 -m pcie_isolate.cli run      --csv TRACE.csv --out DIR [...]   # all of the above in one command
"""
import argparse
import hashlib
import json
import os
import pickle
import sys
import time


def cmd_analyze(a):
    from .engine import Engine
    from .statistics import statistical_findings
    from . import analyzer_errors as AE
    os.makedirs(a.out, exist_ok=True)
    t0 = time.time()
    prof = json.load(open(a.profile)) if a.profile else None
    eng = Engine(a.csv, a.payload, nsze=a.nsze, profile=prof, cmdlog_path=os.path.join(a.out, "commands.jsonl"))
    findings = eng.run()
    if eng.cmdlog:
        eng.cmdlog.close()
    stats = statistical_findings(eng)
    findings = findings + stats
    findings.sort(key=lambda f: f[0])
    rc = eng.rule_counts_summary()
    for f in stats:
        c = rc.setdefault(f[2], {"total": 0, "stored": 0})
        c["total"] += 1
        c["stored"] += 1
    run = {"csv": os.path.abspath(a.csv), "payload": os.path.abspath(a.payload) if a.payload else None,
           "rows": eng.rows, "last_pkt": eng.last_pkt, "first_t": eng.first_t, "last_t": eng.last_t,
           "elapsed_s": round(time.time() - t0, 1), "n_findings": len(findings),
           "topology": {"host_rid": eng.host_rid, "device_rid": eng.dev_rid, "rc_completer": eng.rc_cpl,
                        "bar0": hex(eng.bar0) if eng.bar0 else None, "nsze": eng.nsze,
                        "identity": eng.identity},
           "capture": {"starts_mid_traffic": eng.capture_mid_traffic, "controller_enable_seen": eng.en_pkt is not None,
                       "payload": "inline hex" if eng.inline else ("sidecar" if a.payload else "none (DATA sizes only)"),
                       "columns_missing": eng.C.missing, "cxl_rows": eng.cxl_rows,
                       "rows_not_decoded": eng.undecoded_summary()},
           "thresholds": eng.thresholds(),
           # the analyzer's own 72 error types: how each can be seen in this export and how many were found
           "rule_counts": rc, "analyzer_errors": AE.coverage(rc, "ERRORS" not in eng.C.absent),
           "vocabulary": eng.vocab_summary()}
    pickle.dump(findings, open(os.path.join(a.out, "findings.pkl"), "wb"))
    import numpy as np
    np.savez(os.path.join(a.out, "time_index.npz"), t=np.frombuffer(eng.tix, dtype=np.int64),
             pkt=np.frombuffer(eng.pix, dtype=np.int64))
    json.dump(run, open(os.path.join(a.out, "run.json"), "w"), indent=2)
    brief = {k: v for k, v in run.items() if k not in ("thresholds", "rule_counts", "analyzer_errors", "vocabulary")}
    brief["analyzer_error_types_seen"] = sum(1 for c in run["analyzer_errors"] if c["found"])
    print(json.dumps(brief, indent=2))


def cmd_library(a):
    from .atlas import build_library
    if len(a.calib_run) != len(a.calib_truth):
        sys.exit("give one --calib-truth per --calib-run")
    from .host_evidence import load_all
    lib = build_library([(load_all(r), t)
                         for r, t in zip(a.calib_run, a.calib_truth)], exclude_rules=tuple(a.exclude_rule or ()))
    json.dump(lib, open(a.out, "w"), indent=1)
    print("signatures for %d cards -> %s" % (len(lib["cards"]), a.out))


def cmd_fuse(a):
    from .host_evidence import fuse
    fuse(a.run, a.dmesg, a.events, a.clock_offset, a.snap_ms)


def cmd_isolate(a):
    from .incidents import isolate
    isolate(a.run, a.library, a.csv, a.payload)


def cmd_commands(a):
    from .commands import build
    from .command_narrative import narrate
    from .llm import pick_backend
    build(a.run)
    narrate(a.run, backend=pick_backend(a.backend) if a.backend else "dry-run", model=a.model)


def cmd_evaluate(a):
    from .report import evaluate_run
    evaluate_run(a.run, a.truth)


def cmd_review(a):
    from .llm import review_run, capture_check
    if a.capture_check:
        capture_check(a.run, a.model, a.backend)
        return
    review_run(a.run, model=a.model, limit=a.limit, workers=a.workers, context=a.context, batch=a.batch,
               backend=a.backend, ids=a.ids, per_bucket=a.sample_per_bucket)


def cmd_verify(a):
    from .verify import verify
    verify(a.run, a.expected, model=a.model, backend=a.backend, threshold=a.threshold)


def cmd_coverage(a):
    """Which rules and analyzer error kinds have evidence (stored runs, the kept 485-trace run, the unit tests)."""
    from .coverage import build
    d = build(a.app_root)
    t = d["totals"]
    print("rules %d: seen on packets %d, unit test only %d, no evidence yet %d (%d of those need outside evidence by design)" %
          (t["rules"], t["seen"], t["test"], t["none"], t["none_by_design"]))
    print("analyzer kinds %d: seen on packets %d, unit test only %d, Errors-column name only %d" %
          (t["kinds"], t["kinds_seen"], t["kinds_test"], t["kinds_name_only"]))
    if a.out:
        json.dump(d, open(a.out, "w"), indent=1)
        print("->", a.out)


def cmd_report(a):
    from .isolation import build
    build(a.run)


def cmd_run(a):
    """Front end: raw CSV in, isolated defects out. Chains analyze -> fuse -> isolate -> review -> report."""
    import subprocess
    here = [sys.executable, "-m", "pcie_isolate.cli"]
    out = a.out
    os.makedirs(out, exist_ok=True)
    lib = a.library or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                    "runs", "signature_library.json")
    steps = [["analyze", "--csv", a.csv, "--out", out] + (["--payload", a.payload] if a.payload else []) +
             (["--nsze", hex(a.nsze)] if a.nsze else []) + (["--profile", a.profile] if a.profile else [])]
    if a.dmesg or a.events:
        f = ["fuse", "--run", out]
        if a.dmesg:
            f += ["--dmesg", a.dmesg]
        if a.events:
            f += ["--events", a.events]
        if a.snap_ms:
            f += ["--snap-ms", str(a.snap_ms)]
        steps.append(f)
    steps.append(["isolate", "--run", out, "--library", lib, "--csv", a.csv] +
                 (["--payload", a.payload] if a.payload else []))
    if a.truth:
        steps.append(["evaluate", "--run", out, "--truth", a.truth])
    rv = ["review", "--run", out, "--model", a.model, "--backend", a.backend]
    if a.batch:
        rv.append("--batch")
    if a.limit:
        rv += ["--limit", str(a.limit)]
    steps.append(rv)
    steps.append(["commands", "--run", out, "--model", a.model, "--backend", a.backend])
    steps.append(["report", "--run", out])
    steps.append(["review", "--run", out, "--model", a.model, "--backend", a.backend, "--capture-check"])
    if a.expected:
        steps.append(["verify", "--run", out, "--expected", a.expected, "--model", a.model, "--backend", a.backend])
    t0 = time.time()
    for st in steps:
        print("\n==> %s" % " ".join(st[:3]), flush=True)
        r = subprocess.run(here + st)
        if r.returncode != 0:
            sys.exit("step %s failed (exit %d)" % (st[0], r.returncode))
    print("\nall stages done in %.0f s -> %s/isolation.json, %s/isolation_report.md" % (time.time() - t0, out, out))


def main(argv=None):
    ap = argparse.ArgumentParser(prog="pcie_isolate")
    sp = ap.add_subparsers(dest="cmd", required=True)
    p = sp.add_parser("analyze")
    p.add_argument("--csv", required=True)
    p.add_argument("--payload", default=None, help="outside-the-CSV payload sidecar (enables NVMe/data rules)")
    p.add_argument("--nsze", type=lambda x: int(x, 0), default=None,
                   help="namespace size in blocks if Identify Namespace is not in the capture")
    p.add_argument("--profile", default=None,
                   help="JSON of engine settings, e.g. {\"CTO_PS\": 50000000000, \"mps\": 256, \"host_rid\": \"000:00:0\"}")
    p.add_argument("--out", required=True)
    p.set_defaults(fn=cmd_analyze)
    p = sp.add_parser("library")
    p.add_argument("--calib-run", action="append", required=True)
    p.add_argument("--calib-truth", action="append", required=True)
    p.add_argument("--exclude-rule", action="append", help="rule whose findings the calibration captures cannot "
                   "model faithfully; its tokens are left out of every signature (repeatable)")
    p.add_argument("--out", required=True)
    p.set_defaults(fn=cmd_library)
    p = sp.add_parser("fuse", help="align outside evidence (dmesg -x, host_events.jsonl) to the trace")
    p.add_argument("--run", required=True)
    p.add_argument("--dmesg", default=None)
    p.add_argument("--events", default=None)
    p.add_argument("--clock-offset", type=float, default=None, help="host seconds - analyzer seconds")
    p.add_argument("--snap-ms", type=float, default=0.0,
                   help="place host records on the latest wire defect up to this many ms earlier (dmesg lag)")
    p.set_defaults(fn=cmd_fuse)
    p = sp.add_parser("isolate")
    p.add_argument("--run", required=True)
    p.add_argument("--library", required=True)
    p.add_argument("--csv", required=True)
    p.add_argument("--payload", default=None)
    p.set_defaults(fn=cmd_isolate)
    p = sp.add_parser("evaluate")
    p.add_argument("--run", required=True)
    p.add_argument("--truth", required=True)
    p.set_defaults(fn=cmd_evaluate)
    p = sp.add_parser("review")
    p.add_argument("--run", required=True)
    p.add_argument("--model", default=os.environ.get("PCIE_ISOLATE_MODEL", "claude-haiku-5-5"))
    p.add_argument("--limit", type=int, default=0)
    p.add_argument("--workers", type=int, default=6)
    p.add_argument("--context", type=int, default=15, help="rows above and below the isolated region")
    p.add_argument("--batch", action="store_true", help="Message Batches API (50%% price, results within 24 h)")
    p.add_argument("--ids", default=None, help="review only these incident ids (comma list or a JSON file)")
    p.add_argument("--capture-check", action="store_true",
                   help="one model call: can this capture show what you are looking for? -> capture_assessment.json")
    p.add_argument("--sample-per-bucket", action="store_true",
                   help="review one incident per (layer, first rule) bucket: stratified validation at low cost")
    p.add_argument("--backend", choices=("auto", "sdk", "cli", "dry-run"), default="auto",
                   help="sdk = Anthropic API (ANTHROPIC_API_KEY/_BASE_URL); cli = local `claude` login; "
                        "auto = sdk if a key is set, else cli if installed, else dry-run")
    p.set_defaults(fn=cmd_review)
    p = sp.add_parser("run", help="front end: CSV in, isolated defects out (all stages)")
    p.add_argument("--csv", required=True, help="113-column analyzer export (summary or hex DATA)")
    p.add_argument("--out", required=True, help="run directory for every output")
    p.add_argument("--payload", default=None, help="payload sidecar when DATA holds only sizes")
    p.add_argument("--nsze", type=lambda x: int(x, 0), default=None)
    p.add_argument("--profile", default=None)
    p.add_argument("--dmesg", default=None, help="host kernel log (dmesg -x)")
    p.add_argument("--events", default=None, help="host_events.jsonl from other tools")
    p.add_argument("--snap-ms", type=float, default=0.0)
    p.add_argument("--library", default=None, help="signature library (default: runs/signature_library.json)")
    p.add_argument("--truth", default=None, help="generator sidecar dir (synthetic traces only: scores the run)")
    p.add_argument("--model", default=os.environ.get("PCIE_ISOLATE_MODEL", "claude-haiku-5-5"))
    p.add_argument("--backend", choices=("auto", "sdk", "cli", "dry-run"), default="auto")
    p.add_argument("--batch", action="store_true")
    p.add_argument("--limit", type=int, default=0, help="review only the first N incidents (cost control)")
    p.add_argument("--expected", default=None, help="list of errors already found (errors.txt / errors.json) to verify")
    p.set_defaults(fn=cmd_run)
    p = sp.add_parser("verify", help="check a list of known/suspected errors against the isolated incidents")
    p.add_argument("--run", required=True)
    p.add_argument("--expected", required=True, help="errors.txt (one per line, optional '@<host s> ' prefix) or errors.json")
    p.add_argument("--model", default=os.environ.get("PCIE_ISOLATE_MODEL", "claude-haiku-5-5"))
    p.add_argument("--backend", choices=("auto", "sdk", "cli", "dry-run"), default="dry-run",
                   help="model research of each error (default: matching only, no model call)")
    p.add_argument("--threshold", type=float, default=2.5)
    p.set_defaults(fn=cmd_verify)
    p = sp.add_parser("report")
    p.add_argument("--run", required=True)
    p.set_defaults(fn=cmd_report)
    p = sp.add_parser("coverage", help="which rules and analyzer error kinds have evidence (runs, tests, kept 485 run)")
    p.add_argument("--app-root", required=True, help="the application folder that holds runs/")
    p.add_argument("--out", default=None, help="write the full result as JSON")
    p.set_defaults(fn=cmd_coverage)
    p = sp.add_parser("commands", help="per-command summary (parameters, latency, errors) -> command_summary.json")
    p.add_argument("--run", required=True)
    p.add_argument("--model", default="claude-haiku-5-5")
    p.add_argument("--backend", default="dry-run", help="auto | sdk | cli | dry-run: the narrative of the management view")
    p.set_defaults(fn=cmd_commands)
    a = ap.parse_args(argv)
    a.fn(a)


if __name__ == "__main__":
    main()
