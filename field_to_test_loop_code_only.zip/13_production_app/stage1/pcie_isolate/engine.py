"""One streaming pass over the 113-column CSV.

Every row updates the trackers named in 08_defect_detection_spec/SPEC_CONTRACT.md:
capture_integrity, link_state, dll_tracker, fc_tracker, txn_tracker, config_shadow, bar_map,
register_shadow, nvme_queue_map, nvme_cmd_tracker, msi_tracker, pm_tracker, msg_tracker,
perf_stats, payload_ledger.  Correlation is by identity (PSN, RequesterID+Tag, SQID+CID, queue
slot, page), never by row adjacency.  Rules that need payload bytes run only when a payload
sidecar (outside-the-CSV evidence) is supplied.

Output: Engine.findings = list of (pkt, t_ps, rule, qual, detail, keys, rel_pkts)
"""
import csv
import heapq
import re
import struct
import time
import zlib
from array import array
from collections import Counter, defaultdict, deque

from .rules import DEFECT, RULES
from .schema import MS, NS, SEC, US, Cols, fmt_dt, ts_ps, ts_ps_or_none

UP, DN = "Upstream", "Downstream"
OTHER = {UP: DN, DN: UP}
NP_TYPES = {"MRd(32)", "MRd(64)", "MRdLk", "IORd", "IOWr", "CfgRd0", "CfgWr0", "CfgRd1", "CfgWr1",
            "FetchAdd", "Swap", "CAS"}
CPL_TYPES = {"Cpl", "CplD", "CplLk", "CplDLk"}
WITH_DATA = {"MWr(32)", "MWr(64)", "CplD", "CplDLk", "MsgD", "IOWr", "CfgWr0", "CfgWr1", "FetchAdd", "Swap",
             "CAS", "DMWr"}
RARE_TLP = {"IORd", "IOWr", "MRdLk", "CplLk", "CplDLk", "CfgRd1", "CfgWr1", "FetchAdd", "Swap", "CAS", "DMWr",
            "MsgD"}
NORMAL_MSG = {"Latency_Tolerance_Reporting", "PME_Turn_Off", "PME_TO_Ack"}
MSG_RULES = {
    "ERR_COR": ({"To Root Complex"}, UP), "ERR_NONFATAL": ({"To Root Complex"}, UP),
    "ERR_FATAL": ({"To Root Complex"}, UP), "PM_PME": ({"To Root Complex"}, UP),
    "PME_Turn_Off": ({"Broadcast"}, DN), "PME_TO_Ack": ({"Gathered"}, UP),
    "Assert_INTA": ({"Local"}, UP), "Deassert_INTA": ({"Local"}, UP),
    "Latency_Tolerance_Reporting": ({"Local"}, UP), "Set_Slot_Power_Limit": ({"Local"}, DN),
    "PTM_Request": ({"Local"}, UP), "PTM_Response": ({"Local"}, DN), "PTM_ResponseD": ({"Local"}, DN),
    "OBFF": ({"Local", "Broadcast"}, DN), "Attention_Indicator_On": ({"Local"}, DN),
    "Unlock": ({"Broadcast"}, DN), "FRS": ({"To Root Complex"}, UP), "DRS": ({"Local"}, UP),
    "Page_Request": ({"To Root Complex"}, UP),
}
EVT_RULES = [  # (regex on Link Event text, rule)
    (re.compile(r"Invalid 10b|Running Disparity|Invalid Sync Header|Framing Error|Invalid Ordered Set|"
                r"SKP OS Interval"), "PHY.SYMBOL_ERR"),
    (re.compile(r"Skew"), "PHY.LANE_SKEW"),
    (re.compile(r"Equalization.*Timeout"), "PHY.EQ_TIMEOUT"),
    (re.compile(r"Lane Reversal"), "PHY.LANE_REVERSAL"),
    (re.compile(r"Receiver Detect: no"), "PHY.RXDETECT_FAIL"),
    (re.compile(r"Electrical Idle \(no EIOS\)"), "PHY.EIDLE_NO_EIOS"),
    (re.compile(r"Width Change"), "PHY.WIDTH_CHANGE"),
    (re.compile(r"Recording (paused|resumed)"), "CI.RECORDING_GAP"),
    (re.compile(r"Analyzer|Loss of Lock|Resync"), "CI.ANALYZER_RESYNC"),
]
ADMIN_OPC = {0x00, 0x01, 0x02, 0x04, 0x05, 0x06, 0x08, 0x09, 0x0A, 0x0C, 0x0D, 0x10, 0x11, 0x14, 0x15, 0x18,
             0x19, 0x1A, 0x1C, 0x1D, 0x1E, 0x1F, 0x20, 0x24, 0x7C, 0x7F, 0x80, 0x81, 0x82, 0x84, 0x86}
IO_OPC = {0x00, 0x01, 0x02, 0x04, 0x05, 0x08, 0x09, 0x0C, 0x0D, 0x0E, 0x11, 0x15, 0x19, 0x79, 0x7A, 0x7D}
ADMIN_NAMES = {0x00: "Delete I/O SQ", 0x01: "Create I/O SQ", 0x02: "Get Log Page", 0x04: "Delete I/O CQ",
               0x05: "Create I/O CQ", 0x06: "Identify", 0x08: "Abort", 0x09: "Set Features",
               0x0A: "Get Features", 0x0C: "Async Event Request", 0x0D: "Namespace Management",
               0x10: "Firmware Commit", 0x11: "Firmware Image Download", 0x14: "Device Self-test",
               0x15: "Namespace Attachment", 0x18: "Keep Alive", 0x19: "Directive Send",
               0x1A: "Directive Receive", 0x1C: "Virtualization Management", 0x1D: "NVMe-MI Send",
               0x1E: "NVMe-MI Receive", 0x20: "Capacity Management", 0x24: "Lockdown",
               0x7C: "Doorbell Buffer Config", 0x7F: "Fabrics", 0x80: "Format NVM", 0x81: "Security Send",
               0x82: "Security Receive", 0x84: "Sanitize", 0x86: "Get LBA Status"}
IO_NAMES = {0x00: "Flush", 0x01: "Write", 0x02: "Read", 0x04: "Write Uncorrectable", 0x05: "Compare",
            0x08: "Write Zeroes", 0x09: "Dataset Management", 0x0C: "Verify", 0x0D: "Reservation Register",
            0x0E: "Reservation Report", 0x11: "Reservation Acquire", 0x15: "Reservation Release",
            0x19: "Copy", 0x79: "Zone Mgmt Send", 0x7A: "Zone Mgmt Receive", 0x7D: "Zone Append"}
ADMIN_LONG_OPC = {0x80, 0x84, 0x14, 0x10, 0x11}
PAGE = 4096
# PCIe Base, Device Control 2, Completion Timeout Value encodings -> (text, upper bound in ps)
CTO_RANGES = {0b0000: ("default 50 us - 50 ms", 50 * MS), 0b0001: ("50 us - 100 us", 100 * US),
              0b0010: ("1 ms - 10 ms", 10 * MS), 0b0101: ("16 ms - 55 ms", 55 * MS), 0b0110: ("65 ms - 210 ms", 210 * MS),
              0b1001: ("260 ms - 900 ms", 900 * MS), 0b1010: ("1 s - 3.5 s", 3500 * MS), 0b1101: ("4 s - 13 s", 13 * SEC),
              0b1110: ("17 s - 64 s", 64 * SEC)}
# provenance of every timing threshold (atlas III.1.5 master timer table; "modeled" = tune on a known-good capture)
THRESHOLD_SOURCES = {
    "CTO_PS": ("configured", "PCIe Completion Timeout: Device Control 2 range when captured, else the default range upper bound 50 ms (atlas T-33)"),
    "IO_TIMEOUT_PS": ("host policy", "Linux nvme_core.io_timeout 30 s (atlas T-22)"),
    "ADMIN_TIMEOUT_PS": ("host policy", "Linux nvme_core.admin_timeout 60 s (atlas T-23)"),
    "FLR_WAIT_PS": ("normative", "Function Level Reset: 100 ms before the first access (PCIe Base; pcie_flr; atlas T-43)"),
    "D0_WAIT_PS": ("normative", "D3hot -> D0: 10 ms (PCI PM; PCI_PM_D3HOT_WAIT; atlas T-42)"),
    "CRS_LONG_PS": ("normative", "readiness after Conventional Reset: 1 s nominal, extendable by RRS (PCI_RESET_WAIT; atlas T-41)"),
    "RDY budget": ("advertised", "CSTS.RDY within CAP.TO x 500 ms (atlas T-02)"),
    "REPLAY_NUM": ("normative", "4th replay of one TLP rolls REPLAY_NUM over -> Recovery (atlas T-36)"),
    "TRAIN_SLOW_PS": ("modeled", "link down -> Link Up budget 100 ms; LTSSM substate timeouts are 12-48 ms each (atlas T-39)"),
    "ACK_LATE_PS": ("empirical", "Ack latency 50 us; the spec value is in symbol times per rate/width (atlas T-37)"),
    "FC_WITHHELD_TLPS": ("modeled", "64 TLPs without UpdateFC while Acks keep flowing; spec: UpdateFC at least every 30 us, 200 us watchdog (atlas T-38)"),
    "PME_ACK_PS": ("modeled", "PME_Turn_Off -> PME_TO_Ack 10 ms"),
    "PM_REQ_ACK_PS": ("modeled", "PM_Enter_L1/L23 -> PM_Request_Ack 100 us"),
    "NOT_FETCHED_PS": ("modeled", "SQ tail doorbell -> SQE fetch 100 ms (atlas M-001: no normative limit)"),
    "NO_MSIX_PS": ("modeled", "CQE -> MSI-X 100 us"),
    "RDY_SLOW_PS": ("empirical", "CC.EN -> CSTS.RDY 500 ms flagged as slow (inside the CAP.TO budget)"),
    "PP_LONG_PS": ("modeled", "CSTS.PP 1 s; the advertised limit is MTFA in 100 ms units (atlas T-10)"),
    "RESUME_SLOW_PS": ("modeled", "D0 -> controller ready 100 ms; advertised value is RTD3R (atlas T-06)"),
    "RESET_QUIET_PS": ("modeled", "a host reset is 'explained' by a wire defect within the previous 1 s"),
    "LTR_LOW_NS": ("modeled", "LTR below 10 us blocks L1.2 (atlas T-46: platform thresholds)"),
    "SHUTDOWN": ("host policy", "CC.SHN -> SHST complete within 5 s (Linux shutdown_timeout; atlas T-05)"),
    "STORM": ("modeled", "3 Recovery entries within 10 ms"),
}
# wire-visible reasons for a host to reset the controller (Linux nvme_timeout, CFS, AER, link loss ...)
RESET_CAUSES = {"NVME.CMD_TIMEOUT", "NVME.NOT_FETCHED", "REG.RDY_TIMEOUT", "REG.CFS", "REG.ALL_ONES", "REG.NSSRO",
                "LINK.DOWN", "LINK.DOWN_INFLIGHT", "TXN.CPL_TIMEOUT", "MSG.ERR", "PHY.EIDLE_NO_EIOS",
                "NVME.CQE_UNKNOWN_CID", "NVME.PHASE", "NVME.CQE_SQID", "NVME.DUP_CQE", "DB.RANGE", "DB.NOQ",
                "DB.CQ_PAST_TAIL", "DB.SQ_OVERFLOW", "TLP.CPL_STATUS", "TLP.POISONED", "CFG.MEM_DISABLED_MMIO"}


def opc_name(sqid, opc):
    return (ADMIN_NAMES if sqid == 0 else IO_NAMES).get(opc, "opcode 0x%02X" % opc)


class PayloadSidecar:
    """Merge-join reader for payload_sidecar.csv (Packet, nbytes, head_hex, crc32), sorted by Packet."""

    def __init__(self, path):
        self.f = open(path, newline="")
        self.r = csv.reader(self.f)
        next(self.r)
        self.cur = None
        self.cur_pkt = -1
        self._adv()

    def _adv(self):
        try:
            self.cur = next(self.r)
            self.cur_pkt = int(self.cur[0])
        except StopIteration:
            self.cur = None
            self.cur_pkt = 1 << 62

    def get(self, pkt):
        while self.cur_pkt < pkt:
            self._adv()
        if self.cur_pkt == pkt:
            c = self.cur
            n = int(c[1])
            return bytes.fromhex(c[2]), int(c[3], 16), n
        return None


class InlinePayload:
    """Payload taken from the DATA column itself when the export carries hex bytes (no sidecar needed)."""

    def __init__(self):
        self.cur = (-1, "")

    def get(self, pkt):
        p, data = self.cur
        if p != pkt or not data:
            return None
        b = bytes.fromhex(data.replace(" ", ""))
        return b, zlib.crc32(b) & 0xFFFFFFFF, len(b)


class Cmd:
    __slots__ = ("sqid", "cid", "opc", "nsid", "prp1", "prp2", "slba", "nlb", "xfer", "pkt_db", "t_db",
                 "pkt_fetch", "t_fetch", "pkt_sqe", "t_sqe", "pages", "pages_known", "moved", "wchunks",
                 "pkt_cqe", "t_cqe", "status", "pkt_first_data", "pkt_last_data", "t_last_data", "cdw10",
                 "cdw11", "cdw12", "dw", "flushed_after", "timed_out", "cqid", "list_addr", "npages", "qd", "aborted")

    def __init__(self):
        self.pages = []
        self.pages_known = True
        self.moved = 0
        self.wchunks = {}
        self.pkt_cqe = None
        self.t_cqe = None
        self.status = None
        self.pkt_first_data = None
        self.pkt_last_data = None
        self.t_last_data = None
        self.timed_out = False
        self.aborted = False
        self.list_addr = None


class Engine:
    # modeled thresholds (configurable; documented in the report)
    CTO_PS = 50 * MS                 # PCIe Completion Timeout default range upper end
    ACK_LATE_PS = 50 * US
    FC_WITHHELD_TLPS = 64
    DLLP_FILTER_TLPS = 400
    STORM_N, STORM_WIN = 3, 10 * MS
    TRAIN_SLOW_PS = 100 * MS
    D0_WAIT_PS = 10 * MS
    FLR_WAIT_PS = 100 * MS
    CRS_LONG_PS = 1 * SEC
    PME_ACK_PS = 10 * MS
    PM_REQ_ACK_PS = 100 * US
    IO_TIMEOUT_PS = 30 * SEC
    ADMIN_TIMEOUT_PS = 60 * SEC
    NOT_FETCHED_PS = 100 * MS
    NO_MSIX_PS = 100 * US
    LATE_DATA_PS = 50 * US          # data for a command this soon after its CQE cannot be page reuse
    RDY_SLOW_PS = 500 * MS
    PP_LONG_PS = 1 * SEC
    RESUME_SLOW_PS = 100 * MS
    RESET_QUIET_PS = 1 * SEC          # resets for CFS / link loss / fatal errors follow the cause within ~1 s
    LTR_LOW_NS = 10000
    WINDOW_SHIFT = 10                # statistical windows of 1024 packets

    def __init__(self, csv_path, payload_path=None, nsze=None, mps=256, mrrs=512, mdts_bytes=512 * 1024,
                 progress=True, profile=None):
        self.csv_path = csv_path
        self.payload = PayloadSidecar(payload_path) if payload_path else None
        self.inline = False
        self.progress = progress
        self.findings = []
        self.mps, self.mrrs, self.mdts = mps, mrrs, mdts_bytes
        self.nsze = nsze
        # device identity read from the capture (PCIe configuration header and NVMe Identify Controller data);
        # stays empty when the capture holds neither (no configuration reads, or no payload bytes)
        self.identity = {}
        # identities (calibrated from the capture; defaults = supplied topology)
        self.host_rid, self.dev_rid, self.rc_cpl = None, None, None
        # capture integrity
        self.first_t = None
        self.last_t = 0
        self.last_pkt = -1
        self.tlps_since_dllp = 0
        self.dllp_filter_open = False
        self.gap_pkt = -1                     # last capture-gap row
        # link state
        self.lstate = "UNKNOWN"
        self.speed = None
        self.max_speed = 0.0
        self.rec = None                       # open Recovery episode
        self.rec_times = deque()
        self.down_t = None
        self.last_host_action = (-1, None)    # (t, what)
        self.last_eidle_t = -1
        self.l1_exit_t = None
        self.pme_off = None
        self.pm_req = {}                      # dir -> (t, pkt, kind)
        self.last_down_t = -1
        # data link
        self.epoch = 0
        self.next_psn = {UP: None, DN: None}
        self.sent = {UP: array("i", [-1]) * 4096, DN: array("i", [-1]) * 4096}
        self.sent_t = {UP: array("q", [0]) * 4096, DN: array("q", [0]) * 4096}
        self.replay_cnt = {UP: Counter(), DN: Counter()}
        self.last_nak_t = {UP: -1, DN: -1}
        self.null_psn = {UP: None, DN: None}
        self.unacked = {UP: deque(), DN: deque()}      # (psn, t, pkt) per transmit direction
        self.last_ack_t = {UP: -1, DN: -1}
        self.fc_count = {(UP, "P"): 0, (DN, "P"): 0, (UP, "NP"): 0, (DN, "NP"): 0}
        self.fc_open = set()
        self.fc_seen = set()
        self.initfc_vals = {}
        # transactions
        self.out = {}                          # (rid, tag) -> [pkt, t, dir, type, addr, want, got, ctx, timed_out]
        self.out_heap = []
        self.crs = None                        # [first_pkt, first_t, last_t, count]
        # config shadow
        self.bar0 = None
        self.bar0_set_t = None
        self.cmd_reg = None
        self.dstate = 0
        self.d0_t = None
        self.flr_t = None
        self.msix_enabled = None
        self.devctl = None
        self.cfg_rd_pending = {}
        # NVMe
        self.cc = 0
        self.en_t = None
        self.en_pkt = None
        self.rdy = None
        self.cap_to = None
        self.dstrd = 0
        self.shn_t = None
        self.reg_rd = {}                       # tag -> (off, pkt)
        self.aqa = None
        self.asq = None
        self.acq = None
        self.sq = {}                           # qid -> dict(base,size,cqid,tail,head,db_t{slot:(t,pkt)},fetch_slot)
        self.cq = {}                           # qid -> dict(base,size,iv,tail,phase,head)
        self.open = {}                         # (sqid,cid) -> Cmd
        self.recent_done = {}                  # (sqid,cid) -> Cmd (for dup CQE / late data)
        self.page_owner = {}                   # page -> Cmd (open or recently completed)
        self.msix_vec = {}                     # (addr,data) -> vector
        self.msix_addrs = set()
        self.pending_msi = {}                  # vector -> deque of (t, pkt, cqid) CQEs waiting for an interrupt
        self.ledger = {}                       # lba byte offset -> crc | n<<32 ; ZERO marker uses crc of zeros
        self.ledger_src = {}                   # lba byte offset -> SQE packet of the write that set it
        self.ledger_t = {}
        self.old_crcs = {}
        self.zero_crc = {}
        self.flush_t = -1
        self.write_commit_t = {}
        self.power_cut = None
        # statistics
        self.win_tokens = defaultdict(dict)    # window -> {token: first_pkt}
        self.win_feat = defaultdict(lambda: [0, 0, 0, 0, 0, 0, 0])   # data bytes, data tlps, max gap, tlps, mrd, t0, gap pkt
        self.prev_tlp_t = None
        self.rows = 0
        self.tix, self.pix = array("q"), array("q")     # time -> packet index (every 16th row)
        for k, v in (profile or {}).items():             # thresholds / topology from a profile file
            if not hasattr(self, k):
                raise ValueError("unknown profile key %r" % k)
            setattr(self, k, v)
        self.rdy_seen = True
        self.size_flagged = None
        self.ntlp = 0
        self.cto_source = "default range upper bound (Device Control 2 not captured)"
        self.capture_mid_traffic = False
        self.cxl_rows = 0
        self.n_active = 0
        self.last_sqe_t = -1
        self.last_defect_t = -1
        self.n_disables = 0
        self.last_disable_t = -1
        self.aer_seen = False
        self.io_done_since_en = 0
        self.pp_t, self.pp_flagged = None, False
        self.d0_resume = None
        self.ltr_ns = None
        self.clkreq_t = None
        self.stat = defaultdict(lambda: (array("q"), array("q")))   # name -> (values, pkts) for approach C
        self.undecoded = Counter()      # reason -> rows that could not be fully decoded (kept, never fatal)
        self.undecoded_examples = []    # first few (row number, packet, reason, non-empty cells)
        self.rule_count = Counter()     # findings kept per rule
        self.suppressed = Counter()     # findings dropped per rule once MAX_PER_RULE was reached
        self.cfg_first_t = None
        self.last_speed_t = -1
        self.msi_first = None
        self.down_kind = None
        self.down_pkt = None

    # ------------------------------------------------------------------ helpers
    def emit(self, rule, pkt, t, detail="", qual="", keys=(), rel=()):
        if self.rule_count[rule] >= self.MAX_PER_RULE:
            # a rule that fires on a large share of a 30-million-row export would exhaust memory; the first
            # MAX_PER_RULE findings are kept and the rest are counted (run.json "findings_suppressed")
            self.suppressed[rule] += 1
            return
        self.rule_count[rule] += 1
        self.findings.append((pkt, t, rule, qual, detail, tuple(keys), tuple(rel)))
        if t is not None and rule in RESET_CAUSES and t > self.last_defect_t:
            self.last_defect_t = t

    def thresholds(self):
        """Current timing thresholds with their provenance (for run.json and the isolation record)."""
        vals = {"CTO_PS": self.CTO_PS, "IO_TIMEOUT_PS": self.IO_TIMEOUT_PS, "ADMIN_TIMEOUT_PS": self.ADMIN_TIMEOUT_PS,
                "FLR_WAIT_PS": self.FLR_WAIT_PS, "D0_WAIT_PS": self.D0_WAIT_PS, "CRS_LONG_PS": self.CRS_LONG_PS,
                "TRAIN_SLOW_PS": self.TRAIN_SLOW_PS, "ACK_LATE_PS": self.ACK_LATE_PS,
                "FC_WITHHELD_TLPS": self.FC_WITHHELD_TLPS, "PME_ACK_PS": self.PME_ACK_PS,
                "PM_REQ_ACK_PS": self.PM_REQ_ACK_PS, "NOT_FETCHED_PS": self.NOT_FETCHED_PS,
                "NO_MSIX_PS": self.NO_MSIX_PS, "RDY_SLOW_PS": self.RDY_SLOW_PS, "PP_LONG_PS": self.PP_LONG_PS,
                "RESUME_SLOW_PS": self.RESUME_SLOW_PS, "RESET_QUIET_PS": self.RESET_QUIET_PS,
                "LTR_LOW_NS": self.LTR_LOW_NS}
        out = {}
        for k, (src, note) in THRESHOLD_SOURCES.items():
            out[k] = {"value": vals.get(k), "source": src, "note": note}
        out["CTO_PS"]["note"] = self.cto_source + "; " + out["CTO_PS"]["note"]
        out["RDY budget"]["value"] = (self.cap_to or 0) * 500 * MS if self.cap_to else None
        return out

    def sample(self, name, value, pkt):
        v, p = self.stat[name]
        v.append(value)
        p.append(pkt)

    def zcrc(self, n):
        v = self.zero_crc.get(n)
        if v is None:
            v = self.zero_crc[n] = zlib.crc32(bytes(n)) & 0xFFFFFFFF
        return v

    # ------------------------------------------------------------------ main loop
    def run(self):
        t0 = time.time()
        f = open(self.csv_path, newline="", encoding="utf-8-sig", errors="replace", buffering=1 << 22)
        rd = csv.reader(f)
        C = self.C = Cols(next(rd))
        pad = C.pad
        self.be_cols_absent = "FBE" in C.absent or "LBE" in C.absent
        if C.missing and self.progress:
            print("  columns not in this export (treated as empty): %s" % ", ".join(C.missing), flush=True)
        dirmap = self.calibrate_dirs(C)
        iTLP, iDLLP, iOS, iEVT, iMARK, iPKT, iTS = C.TLP, C.DLLP, C.OS, C.EVT, C.MARKER, C.PKT, C.TS
        iDIR, iACK, iCRC = C.DIR, C.ACKSEQ, C.CRC16
        tie_n, tie_t = 0, -1
        rows = 0
        width = len(C.header)
        for row in rd:
            rows += 1
            if pad:
                row += pad
            if len(row) < width:
                # a short row (truncated line, export cut mid-row): pad so every column reads as empty
                row += [""] * (width - len(row))
            if dirmap:
                row[iDIR] = dirmap.get(row[iDIR], row[iDIR])
            # ---- real exports contain rows the decoder cannot place: note them, never stop on them
            pkt_s = row[iPKT]
            if not pkt_s.isdigit():
                self.skip_row(rows, pkt_s, "no packet number" if not pkt_s else "packet number is not a whole number", row)
                continue
            pkt = int(pkt_s)
            t = ts_ps_or_none(row[iTS])
            if t is None:
                if self.last_t is None:
                    self.skip_row(rows, pkt_s, "no time stamp", row)
                    continue
                t = self.last_t
                self.undecoded["no time stamp (previous row's time used)"] += 1
            tl = row[iTLP]
            try:
                if tl:
                    self.on_tlp(row, pkt, t, tl)
                else:
                    dl = row[iDLLP]
                    if dl == "ACK":
                        seq_s = row[iACK]
                        if seq_s.isdigit():
                            self.on_ack(row[iDIR], int(seq_s), pkt, t, False)
                        else:
                            # an Ack whose sequence number the analyzer could not decode: it still proves the
                            # data link is alive, but it cannot be matched to the TLPs it acknowledges
                            self.tlps_since_dllp = 0
                            self.dllp_filter_open = False
                            self.last_ack_t[row[iDIR]] = t
                            self.skip_row(rows, pkt_s, "Ack without a sequence number", row, kept=True)
                        if row[iCRC].endswith(")"):
                            self.emit("DLL.CRC16_BAD", pkt, t, "%s Ack CRC 16 %s (DLLP discarded)" %
                                      (row[iDIR], row[iCRC]), qual="ACK")
                            self.token(pkt, "D|ACK|bad")
                    elif dl:
                        self.on_dllp(row, pkt, t, dl)
                    elif row[iOS]:
                        self.on_os(row, pkt, t, row[iOS])
                    elif row[iEVT]:
                        self.on_event(row, pkt, t, row[iEVT])
                    else:
                        self.on_other(row, pkt, t)
                if row[iMARK]:
                    self.on_marker(row[iMARK], pkt, t)
            except (ValueError, IndexError, KeyError) as ex:
                # one row with a cell the decoder does not understand must not stop a 5 GB analysis
                self.skip_row(rows, pkt_s, "cell not understood (%s)" % str(ex)[:80], row, kept=True)
            if t == tie_t:
                tie_n += 1
                if tie_n == 16:
                    self.emit("CI.TS_TIE", pkt - 15, t, "16+ consecutive rows share one Time Stamp "
                              "(analyzer timestamp precision / export rounding)")
            else:
                tie_n, tie_t = 0, t
            if not rows & 15:
                self.tix.append(t)
                self.pix.append(pkt)
            if self.first_t is None:
                self.first_t = t
            self.last_t, self.last_pkt = t, pkt
            if self.progress and rows % 2000000 == 0:
                print("  %8d rows  %.0fs  findings=%d" % (rows, time.time() - t0, len(self.findings)), flush=True)
        f.close()
        self.rows = rows
        self.finish()
        if self.progress:
            print("  done %d rows in %.0fs, %d findings" % (rows, time.time() - t0, len(self.findings)), flush=True)
            n = sum(self.undecoded.values())
            if n:
                print("  %d of %d rows could not be fully decoded and were kept without a verdict: %s" %
                      (n, rows, "; ".join("%s x%d" % (k, v) for k, v in self.undecoded.most_common(6))), flush=True)
            if self.suppressed:
                print("  findings beyond %d per rule were counted but not stored: %s" %
                      (self.MAX_PER_RULE, ", ".join("%s +%d" % kv for kv in self.suppressed.most_common(6))), flush=True)
        return self.findings

    MAX_PER_RULE = 100000

    def skip_row(self, n, pkt_s, reason, row, kept=False):
        """Counts a row the decoder could not place (reason -> count) and keeps the first examples for run.json."""
        self.undecoded[reason] += 1
        if len(self.undecoded_examples) < 12:
            cells = [(self.C.header[i], v) for i, v in enumerate(row) if v and i < len(self.C.header)][:8]
            self.undecoded_examples.append({"row": n, "packet": pkt_s or None, "reason": reason, "kept": kept,
                                            "cells": ["%s=%s" % c for c in cells]})

    def undecoded_summary(self):
        return {"rows": sum(self.undecoded.values()), "reasons": dict(self.undecoded),
                "examples": self.undecoded_examples, "findings_suppressed": dict(self.suppressed),
                "max_findings_per_rule": self.MAX_PER_RULE}

    def calibrate_dirs(self, C):
        """Exports differ in how they name the two directions.  If the values are not Upstream/Downstream,
        the direction of the first configuration request is host->device (atlas XII.8.2)."""
        seen, host_dir = set(), None
        with open(self.csv_path, newline="", encoding="utf-8-sig", errors="replace") as f:
            rd = csv.reader(f)
            next(rd)
            for n, row in enumerate(rd):
                if len(row) <= C.DIR:
                    continue
                if row[C.DIR]:
                    seen.add(row[C.DIR])
                if host_dir is None and C.TLP < len(row) and row[C.TLP].startswith("CfgRd"):
                    host_dir = row[C.DIR]
                if n > 500000 or (host_dir and len(seen) >= 2):
                    break
        if seen <= {UP, DN}:
            return None
        if host_dir is None:
            raise ValueError("Link Dir values %s are not Upstream/Downstream and no configuration request "
                             "was found to calibrate them" % sorted(seen))
        m = {host_dir: DN}
        for v in seen - {host_dir}:
            m[v] = UP
        if self.progress:
            print("  Link Dir calibrated from the first CfgRd: %s" % m, flush=True)
        return m

    # ------------------------------------------------------------------ statistics tokens
    def token(self, pkt, tok):
        w = self.win_tokens[pkt >> self.WINDOW_SHIFT]
        if tok not in w:
            w[tok] = pkt

    # ------------------------------------------------------------------ capture integrity
    def on_marker(self, m, pkt, t):
        if m == "Marker" and pkt == 0:
            return
        self.token(pkt, "M|" + re.sub(r"[\d:.]+", "#", m)[:40])
        self.emit("CI.MARKER", pkt, t, m, qual=m.split(":")[0].split(" ")[0])
        if m.startswith(("Buffer Wrap", "Segment Start", "Resync", "Trigger")) or "filter" in m.lower():
            self.capture_gap(pkt, t, m)

    def capture_gap(self, pkt, t, why):
        """Rows may be missing: anything spanning this point becomes UNKNOWN, not a defect."""
        self.gap_pkt = pkt
        self.next_psn = {UP: None, DN: None}
        self.unacked = {UP: deque(), DN: deque()}
        for k in list(self.out):
            del self.out[k]
        for c in self.open.values():
            c.timed_out = True                 # censored: never reported as a timeout
        self.open.clear()
        self.n_active = 0
        for q in self.cq.values():
            q["resync"] = True

    def on_other(self, row, pkt, t):
        """Rows that are not TLP/DLLP/ordered set/link event (atlas XII.1.1 classifier order)."""
        C = self.C
        if row[C.JAMMER]:
            self.token(pkt, "JAMMER")
            self.emit("CI.JAMMER", pkt, t, "Jammer %s: %s" % (row[C.JAMMER], row[C.JACTION]), qual=row[C.JAMMER][:20])
        elif row[C.CXL]:
            self.cxl_rows += 1                 # CXL.cache/mem rows: not NVMe-over-PCIe traffic, counted only
        elif row[C.SLAVE] or row[C.ARP]:
            self.token(pkt, "SMBUS")
            self.emit("SMBUS.TRAFFIC", pkt, t, "SMBus slave %s" % row[C.SLAVE], qual="smbus")

    # ------------------------------------------------------------------ physical layer / link state
    def on_event(self, row, pkt, t, ev):
        tok = "E|" + re.sub(r"\d+(\.\d+)? ?(ms|us|ns|s)\b", "#", ev)
        self.token(pkt, tok[:60])
        for rx, rule in EVT_RULES:
            if rx.search(ev):
                self.emit(rule, pkt, t, ev, qual=re.sub(r"\s*\(Lane \d+\)", "", ev)[:40])
                if rule in ("CI.RECORDING_GAP", "CI.ANALYZER_RESYNC"):
                    self.capture_gap(pkt, t, ev)
                if rule == "PHY.EIDLE_NO_EIOS":
                    self.power_cut = (t, pkt)
                break
        if ev.startswith("CLKREQ# Asserted"):
            self.clkreq_t = (t, pkt)
        if ev.startswith("Electrical Idle Exit") and self.clkreq_t and t - self.clkreq_t[0] < 10 * MS:
            self.sample("refclk_to_exit", t - self.clkreq_t[0], self.clkreq_t[1])
        if ev.startswith("Link Down"):
            self.link_down(pkt, t, ev)
        elif ev.startswith("Link Up"):
            self.lstate = "L0"
            self.epoch += 1
            self.next_psn = {UP: None, DN: None}
            self.unacked = {UP: deque(), DN: deque()}
            if self.down_t is not None and t - self.down_t > self.TRAIN_SLOW_PS and self.down_kind != "host":
                self.emit("LINK.TRAIN_SLOW", pkt, t, "link up %s after link down" % fmt_dt(t - self.down_t),
                          rel=(self.down_pkt,))
            self.down_t = None
            self.fc_count = dict.fromkeys(self.fc_count, 0)
            self.fc_open.clear()
        elif ev.startswith("Electrical Idle Exit"):
            if self.lstate == "IDLE":
                self.l1_exit_t = t
            self.lstate = "TRAIN" if self.lstate in ("IDLE", "DOWN") else self.lstate
        elif ev.startswith("Electrical Idle"):
            self.lstate = "IDLE"
            self.last_eidle_t = t
            self.unacked = {UP: deque(), DN: deque()}
            self.close_recovery(pkt, t)
        elif ev.startswith("Speed Change"):
            m = re.search(r"([\d.]+) GT/s", ev)
            sp = float(m.group(1)) if m else None
            self.last_speed_t = t
            if self.rec:
                self.rec["speed"] = True
            if sp is not None:
                if self.speed is not None and sp < self.speed:
                    self.emit("PHY.SPEED_DOWN", pkt, t, "%s -> %s GT/s" % (self.speed, sp), qual="%g" % sp)
                elif "autonomous" in ev:
                    self.emit("PHY.SPEED_DOWN", pkt, t, ev, qual="autonomous")
                else:
                    self.emit("PHY.SPEED_CHANGE", pkt, t, ev, qual="%g" % sp)
                self.speed = sp
                self.max_speed = max(self.max_speed, sp)

    def link_down(self, pkt, t, ev):
        if self.lstate == "DOWN" and self.down_t is not None and t - self.down_t < 10 * US:
            return                              # the second direction's Link Down of the same event
        ht, what = self.last_host_action
        host = ht >= 0 and t - ht < 50 * MS
        if self.lstate == "UNKNOWN" or not self.ntlp:
            host, what = True, "capture start (no traffic captured yet)"
        self.down_kind = "host" if host else "surprise"
        self.down_t, self.down_pkt = t, pkt
        self.last_down_t = t
        if host:
            self.emit("LINK.DOWN_HOST", pkt, t, "%s after %s" % (ev, what), qual=what)
        else:
            self.emit("LINK.DOWN", pkt, t, ev, qual="surprise")
        self.close_recovery(pkt, t)
        # requests in flight across the link loss
        lost = [(k, o) for k, o in self.out.items() if not o[8]]
        ncmd = [c for c in self.open.values() if not c.timed_out and not (c.sqid == 0 and c.opc == 0x0C)]
        if lost or ncmd:
            self.emit("LINK.DOWN_INFLIGHT", pkt, t, "%d PCIe requests, %d NVMe commands outstanding" %
                      (len(lost), len(ncmd)), qual="host" if host else "surprise",
                      rel=[o[0] for _, o in lost[:8]] + [c.pkt_sqe or c.pkt_db for c in ncmd[:8]])
        for k, o in lost:
            self.emit("TXN.LOST_LINKDOWN", o[0], o[1], "%s tag %s outstanding %s at link down" %
                      (o[3], k[1], fmt_dt(t - o[1])), keys=(("tag",) + k,), rel=(pkt,))
        self.out.clear()
        self.nvme_reset(pkt, t, "link down")
        self.lstate = "DOWN"
        self.next_psn = {UP: None, DN: None}
        self.unacked = {UP: deque(), DN: deque()}
        self.cmd_reg = None if not host else self.cmd_reg

    def close_recovery(self, pkt, t):
        r = self.rec
        if not r:
            return
        self.rec = None
        if r["hot"] or r["disable"] or r["speed"] or r["after_idle"] or abs(r["t"] - self.last_speed_t) < 1 * MS:
            return
        self.emit("LINK.RECOVERY", r["pkt"], r["t"], "Recovery initiated %s" % r["dir"], qual=r["dir"],
                  rel=(pkt,))
        self.rec_times.append(r["t"])
        while self.rec_times and r["t"] - self.rec_times[0] > self.STORM_WIN:
            self.rec_times.popleft()
        if len(self.rec_times) >= self.STORM_N:
            self.emit("LINK.RECOVERY_STORM", r["pkt"], r["t"], "%d recoveries within %s" %
                      (len(self.rec_times), fmt_dt(self.STORM_WIN)))
            self.rec_times.clear()

    def on_os(self, row, pkt, t, kind):
        C = self.C
        d = row[C.DIR]
        tctl, rate, eq, lane = row[C.TCTL], row[C.TSRATE], row[C.EQCTL], row[C.TSLANE]
        self.token(pkt, "O|%s|%s|%s|%s|%s" % (kind, d[:1], tctl, eq, lane if lane not in ("0", "PAD") else "n"))
        if kind == "Compliance Pattern":
            self.emit("PHY.COMPLIANCE", pkt, t, "Compliance Pattern ordered set", qual="compliance")
        elif kind == "SKP":
            self.emit("PHY.SKP_OS", pkt, t, "SKP ordered set row", qual="skp")
        if kind in ("TS1", "TS2"):
            hot = tctl[:1] == "1"
            dis = len(tctl) > 2 and tctl[2] == "1"
            if hot:
                if d == DN:
                    self.last_host_action = (t, "hot reset")
                if not (self.rec and self.rec["hot"]):
                    self.emit("PHY.TS_HOTRESET", pkt, t, "%s %s with Hot Reset bit" % (d, kind), qual=d)
            if dis:
                self.last_host_action = (t, "link disable")
                self.emit("PHY.TS_DISABLE", pkt, t, "%s %s with Disable Link bit" % (d, kind), qual=d)
            if rate and ("Reserved" in rate or "32.0" in rate):
                self.emit("PHY.TS_RATE", pkt, t, "TS Data Rate %s" % rate, qual=rate[:12])
            if eq and eq[:1] == "1":
                self.emit("PHY.EQ_REDO", pkt, t, "TS Eq Control %s" % eq, qual=eq)
            if lane and lane not in ("0", "PAD"):
                self.emit("PHY.TS_LANE", pkt, t, "TS Lane %s" % lane, qual="lane")
            if self.lstate == "L0" and kind == "TS1":
                self.rec = {"pkt": pkt, "t": t, "dir": d, "hot": hot, "disable": dis, "speed": False,
                            "after_idle": t - self.last_eidle_t < 1 * MS}
                self.lstate = "TRAIN"
            elif self.rec:
                self.rec["hot"] |= hot
                self.rec["disable"] |= dis
            if self.lstate in ("DOWN", "IDLE", "UNKNOWN"):
                self.lstate = "TRAIN"
        elif kind == "SDS":
            if self.lstate == "TRAIN" and self.rec:
                self.close_recovery(pkt, t)
            if self.lstate == "TRAIN" and self.down_t is None:
                self.lstate = "L0"
        elif kind == "EIOS":
            pass

    def link_active(self, pkt, t, what):
        """A TLP/DLLP is on the wire: the link must be in L0."""
        if self.lstate in ("DOWN", "IDLE"):
            if self.lstate == "DOWN" and what.startswith(("InitFC", "Data Link Feature")):
                return
            self.emit("LINK.TRAFFIC_WHILE_DOWN", pkt, t, "%s while link %s" % (what, self.lstate),
                      qual=self.lstate)
            self.lstate = "L0"
        elif self.lstate == "TRAIN":
            if self.rec:
                self.close_recovery(pkt, t)
            self.lstate = "L0"
        elif self.lstate == "UNKNOWN":
            self.lstate = "L0"
            self.capture_mid_traffic = True    # traffic before any link training / Link Up row
            self.emit("CI.CAPTURE_START", pkt, t, "first %s with no link training or Link Up before it: the capture "
                      "starts mid-traffic; queue map and open requests before this row are unknown" % what)
        if self.l1_exit_t is not None:
            lat = t - self.l1_exit_t
            start = self.clkreq_t[0] if self.clkreq_t and self.l1_exit_t - self.clkreq_t[0] < 10 * MS else \
                self.l1_exit_t
            self.sample("l1_exit", t - start, pkt)
            if self.ltr_ns and (t - start) > self.ltr_ns * NS and (t - start) > 10 * US:
                self.emit("PM.L1_EXIT_VS_LTR", pkt, t, "L1 exit took %s, LTR tolerates %s" %
                          (fmt_dt(t - start), fmt_dt(self.ltr_ns * NS)), rel=(self.clkreq_t[1] if self.clkreq_t else pkt,))
            self.l1_exit_t = None

    # ------------------------------------------------------------------ data link layer
    def on_ack(self, d, seq, pkt, t, nak):
        """Ack/Nak sent in direction d acknowledges TLPs transmitted in the other direction."""
        self.tlps_since_dllp = 0
        self.dllp_filter_open = False
        self.last_ack_t[d] = t
        o = OTHER[d]
        if self.sent[o][seq] != self.epoch and not nak and self.next_psn[o] is not None:
            self.emit("DLL.ACK_UNSENT", pkt, t, "Ack %d but PSN %d was never sent %s" % (seq, seq, o),
                      keys=(("psn", o, seq),))
        q = self.unacked[o]
        if q:
            # pop every TLP with PSN <= seq (mod 4096, 2048 window)
            while q and ((seq - q[0][0]) & 0xFFF) < 2048:
                psn, ts, p = q.popleft()
                lat = t - ts
                if q and ((seq - q[0][0]) & 0xFFF) < 2048:
                    continue
                self.sample("ack_latency", lat, pkt)
                if lat > self.ACK_LATE_PS:
                    self.emit("DLL.ACK_LATE", p, ts, "PSN %d acknowledged after %s" % (psn, fmt_dt(lat)),
                              keys=(("psn", o, psn),), rel=(pkt,))

    def on_dllp(self, row, pkt, t, dl):
        C = self.C
        d = row[C.DIR]
        self.link_active(pkt, t, dl)
        crc = row[C.CRC16]
        if dl != "UpdateFC-P" and dl != "UpdateFC-NP":
            self.token(pkt, "D|%s|%s|%s" % (dl, d[:1], "bad" if "(Bad)" in crc else ""))
        if "(Bad)" in crc:
            self.emit("DLL.CRC16_BAD", pkt, t, "%s CRC 16 %s" % (dl, crc), qual=dl)
        if dl == "NAK":
            if not row[C.ACKSEQ].isdigit():
                self.last_nak_t[d] = t
                self.emit("DLL.NAK", pkt, t, "%s Nak without a decodable sequence number (receiver %s)" %
                          (d, d == UP and "SSD" or "root port"), qual=d)
                return
            seq = int(row[C.ACKSEQ])
            self.last_nak_t[d] = t
            self.emit("DLL.NAK", pkt, t, "%s Nak seq %d (receiver %s)" % (d, seq, d == UP and "SSD" or "root port"),
                      qual=d, keys=(("psn", OTHER[d], (seq + 1) & 0xFFF),))
            self.on_ack(d, seq, pkt, t, True)
            return
        self.tlps_since_dllp = 0
        self.dllp_filter_open = False
        if dl.startswith("UpdateFC-") or dl.startswith("InitFC"):
            typ = dl.split("-")[1]
            # credits flow back to the transmitter of the other direction
            k = (OTHER[d], typ)
            if k in self.fc_count:
                self.fc_count[k] = 0
                self.fc_open.discard(k)
                self.fc_seen.add(k)
            if dl.startswith("InitFC"):
                h, dd = row[C.HDRFC], row[C.DATAFC]
                seen = self.initfc_vals.setdefault((dl, d), set())
                if (h, dd) not in seen:
                    seen.add((h, dd))
                    if len(seen) > 1:
                        self.emit("FC.INIT_VALUE", pkt, t, "%s HdrFC %s DataFC %s differs from earlier InitFC" %
                                  (dl, h, dd), qual=dl)
        elif dl in ("PM_Enter_L1", "PM_Enter_L23", "PM_Active_State_Request_L1"):
            if dl == "PM_Enter_L1":
                self.emit("PM.ENTER_L1", pkt, t, "%s %s" % (d, dl), qual=d)
            if dl == "PM_Enter_L23":
                self.last_host_action = (t, "L2/L3 entry")
            if d not in self.pm_req:
                self.pm_req[d] = (t, pkt, dl)
        elif dl == "PM_Request_Ack":
            self.pm_req.pop(OTHER[d], None)

    # ------------------------------------------------------------------ transaction layer
    def on_tlp(self, row, pkt, t, tl):
        C = self.C
        d = row[C.DIR]
        self.link_active(pkt, t, tl)
        self.tlps_since_dllp += 1
        self.ntlp += 1
        if not self.ntlp & 255 and (self.pending_msi or self.msi_first):
            self.msi_deadlines(t)
        if self.tlps_since_dllp > self.DLLP_FILTER_TLPS and not self.dllp_filter_open:
            self.dllp_filter_open = True
            self.emit("CI.DLLP_FILTERED", pkt, t, "%d TLPs without any DLLP row" % self.tlps_since_dllp)
        # PM handshake deadlines
        if self.pm_req:
            for dd, (t0, p0, kind) in list(self.pm_req.items()):
                if t - t0 > self.PM_REQ_ACK_PS:
                    if kind != "PM_Active_State_Request_L1":
                        self.emit("PM.NO_REQUEST_ACK", p0, t0, "%s %s without PM_Request_Ack" % (dd, kind), qual=kind)
                    del self.pm_req[dd]
        if self.pme_off and t - self.pme_off[0] > self.PME_ACK_PS:
            self.emit("PM.NO_PME_TO_ACK", self.pme_off[1], self.pme_off[0], "PME_Turn_Off without PME_TO_Ack")
            self.pme_off = None
        lc = row[C.LCRC]
        psn_s = row[C.PSN]
        # ---- data link: PSN sequencing and replay de-duplication
        replay = False
        if psn_s:
            psn = int(psn_s)
            if "(Nullified)" in lc:
                self.emit("DLL.NULLIFIED", pkt, t, "%s %s PSN %d nullified" % (d, tl, psn), qual=d,
                          keys=(("psn", d, psn),))
                self.null_psn[d] = psn
                return
            exp = self.next_psn[d]
            if exp is not None and psn != exp:
                behind = (exp - psn) & 0xFFF
                if 0 < behind <= 1024 and self.sent[d][psn] == self.epoch:
                    replay = True
                    self.replay_cnt[d][psn] += 1
                    after_nak = t - self.last_nak_t[OTHER[d]] < 100 * US
                    if self.replay_cnt[d][psn] == 1 or after_nak:
                        self.emit("DLL.REPLAY", pkt, t, "%s %s PSN %d retransmitted (%s)" %
                                  (d, tl, psn, "after Nak" if after_nak else "replay timer"),
                                  qual="nak" if after_nak else "timer", keys=(("psn", d, psn),))
                    if self.replay_cnt[d][psn] == 4:
                        self.emit("DLL.REPLAY_ROLLOVER", pkt, t, "PSN %d replayed 4 times" % psn, qual=d,
                                  keys=(("psn", d, psn),))
                elif self.null_psn[d] is not None and psn in (self.null_psn[d], (self.null_psn[d] + 1) & 0xFFF):
                    pass
                else:
                    self.emit("DLL.PSN_OOS", pkt, t, "%s PSN %d, expected %d" % (d, psn, exp), qual=d,
                              keys=(("psn", d, psn),))
            self.null_psn[d] = None
            if not replay:
                self.next_psn[d] = (psn + 1) & 0xFFF
                self.sent[d][psn] = self.epoch
                self.unacked[d].append((psn, t, pkt))
                if len(self.unacked[d]) > 4096:
                    self.unacked[d].popleft()
        if "(Bad)" in lc:
            self.emit("DLL.LCRC_BAD", pkt, t, "%s %s LCRC flagged bad (receiver: %s)" %
                      (d, tl, "SSD" if d == DN else "root port"), qual=d, keys=(("psn", d, int(psn_s or 0)),))
        if replay:
            return
        # ---- flow control accounting (posted / non-posted credits consumed in direction d)
        typ = "P" if tl.startswith("MWr") or tl.startswith("Msg") else ("NP" if tl in NP_TYPES else None)
        if typ:
            k = (d, typ)
            n = self.fc_count[k] = self.fc_count[k] + 1
            if n > self.FC_WITHHELD_TLPS and k in self.fc_seen and k not in self.fc_open and \
                    t - self.last_ack_t[OTHER[d]] < 200 * US:
                self.fc_open.add(k)
                self.emit("FC.UPDATE_WITHHELD", pkt, t, "%d %s TLPs %s since the last UpdateFC-%s" %
                          (n, typ, d, typ), qual="%s-%s" % (d, typ))
        # ---- stateless header checks (approach A)
        tc, th, td, ep, attr, at = row[C.TC], row[C.TH], row[C.TD], row[C.EP], row[C.ATTR], row[C.AT]
        flags = ""
        if tc or th or td or ep or attr or at:
            if "(Bad)" in row[C.ECRC]:
                self.emit("TLP.ECRC_BAD", pkt, t, "%s ECRC %s" % (tl, row[C.ECRC]), qual=d)
            if ep:
                self.emit("TLP.POISONED", pkt, t, "%s %s poisoned (EP=1)" % (d, tl), qual=tl[:3])
            if td and "(Bad)" not in row[C.ECRC]:
                self.emit("TLP.TD_SET", pkt, t, "%s with TD=1" % tl, qual=d)
            if th:
                self.emit("TLP.TH_SET", pkt, t, "%s with TH=1" % tl)
            if at:
                self.emit("TLP.AT_SET", pkt, t, "%s AT=%s" % (tl, at), qual=at)
            if tc:
                self.emit("TLP.TC_NONZERO", pkt, t, "%s TC%s" % (tl, tc), qual=tc)
            if attr:
                self.emit("TLP.ATTR", pkt, t, "%s %s Attributes %s" % (d, tl, attr), qual=attr)
            flags = "%s%s%s%s%s%s" % (tc and "c", th and "h", td and "d", ep and "e", attr, at and "a")
        rid, tag_s = row[C.RID], row[C.TAG]
        length = int(row[C.LEN] or 0)
        data = row[C.DATA]
        nbytes = int(data[:-2]) if data.endswith(" B") else (len(data.split()) if data else 0)
        if data and not data.endswith(" B"):
            if self.payload is None:
                self.payload = InlinePayload()
                self.inline = True
            if self.inline:
                self.payload.cur = (pkt, data)
        if tl in RARE_TLP:
            self.emit("TLP.RARE_TYPE", pkt, t, "%s %s" % (d, tl), qual=tl)
        if tl in WITH_DATA and nbytes and nbytes != length * 4:
            self.emit("TLP.LEN_MISMATCH", pkt, t, "Length %d DW but DATA %d B" % (length, nbytes))
        if self.host_rid is None and tl == "CfgRd0":
            self.host_rid, self.dev_rid = rid, row[C.DEVID] or None
        win = self.win_feat[pkt >> self.WINDOW_SHIFT]
        if not win[3]:
            win[5] = t
        win[3] += 1
        if self.prev_tlp_t is not None and self.n_active > 0 and t - self.prev_tlp_t > win[2] and \
                self.prev_tlp_t - self.last_sqe_t < 1 * SEC:
            win[2] = t - self.prev_tlp_t
            win[6] = pkt
        self.prev_tlp_t = t
        # tokens: cheap shape of the row for rarity scoring
        if tl[0] == "C" and tl.startswith("Cpl"):
            st = row[C.CPLST]
            if flags or st != "SC" or tl != "CplD":
                self.token(pkt, "T|%s|%s|%s|%s" % (tl, d[:1], st, flags))
        elif tl[0] == "M" and tl[1] != "s":
            if flags or "(Bad)" in lc or (d == UP) != (rid == (self.dev_rid or "002:00:0")):
                self.token(pkt, "T|%s|%s|%s|%s" % (tl[:3], d[:1], flags, rid))
        else:
            self.token(pkt, "T|%s|%s|%s|%s|%s" % (tl, d[:1], row[C.MSG], row[C.ROUTE], flags))
        addr_s = row[C.ADDR]
        addr = int(addr_s.replace(":", ""), 16) if addr_s else None
        fbe, lbe = row[C.FBE], row[C.LBE]
        dev_rid = self.dev_rid or "002:00:0"
        host_rid = self.host_rid or "000:00:0"
        # ---- memory requests
        if tl[0] == "M" and (tl[1] == "R" or tl[1] == "W"):
            if (tl.endswith("(64)") and addr < (1 << 32)) or (tl.endswith("(32)") and addr >= (1 << 32)):
                self.emit("TLP.ADDR_FMT", pkt, t, "%s address %s" % (tl, addr_s))
            if (addr & 0xFFF) + length * 4 > 4096:
                self.emit("TLP.4K", pkt, t, "%s %s + %d B crosses 4 KiB" % (tl, addr_s, length * 4))
            if self.be_cols_absent:
                ok = True                   # export has no byte-enable columns: the rule cannot be judged
            elif length == 1:
                ok = lbe == "0000" and fbe != "0000"
            else:
                ok = fbe != "0000" and lbe != "0000" and ((fbe in ("1111", "1110", "1100", "1000") and
                                                           lbe in ("0001", "0011", "0111", "1111")) or
                                                          (length == 2 and addr % 8 == 0))
            if not ok:
                self.emit("TLP.BE", pkt, t, "Length %d 1st BE %s Last BE %s" % (length, fbe, lbe), qual=tl[:3])
            if (d == UP and rid != dev_rid) or (d == DN and rid != host_rid):
                self.emit("TLP.RID_UNEXPECTED", pkt, t, "%s %s from RequesterID %s" % (d, tl, rid), qual=d,
                          keys=(("rid", rid),))
            if tl[1] == "W" and length * 4 > self.mps and self.size_flagged != ("mps", self.mps):
                self.size_flagged = ("mps", self.mps)
                self.emit("TLP.MPS", pkt, t, "%d B payload > MPS %d (reported once per MPS setting)" %
                          (length * 4, self.mps), qual=d)
            if tl[1] == "R" and length * 4 > self.mrrs and self.size_flagged != ("mrrs", self.mrrs):
                self.size_flagged = ("mrrs", self.mrrs)
                self.emit("TLP.MRRS", pkt, t, "%d B read > MRRS %d (reported once per MRRS setting)" %
                          (length * 4, self.mrrs), qual=d)
            if tl[1] == "W":
                win[0] += nbytes
                win[1] += 1
                self.on_mwr(row, pkt, t, d, tl, addr, length, nbytes, fbe, rid)
                if self.out_heap:
                    self.sweep_timeouts(t)
                return
            win[4] += 1
        elif tl.startswith("Cfg"):
            reg = int(row[C.REG] or "0", 16)
            if self.cfg_first_t is None:
                self.cfg_first_t = (t, pkt)
            if d != DN or length != 1 or reg % 4 or reg > 0xFFC:
                self.emit("TLP.CFG_FORMAT", pkt, t, "%s %s reg 0x%03X Length %d" % (d, tl, reg, length))
            if tl.startswith("CfgWr"):
                self.on_cfg_write(row, pkt, t, reg)
        elif tl in ("Msg", "MsgD"):
            self.on_msg(row, pkt, t, d, tl)
            return
        # ---- non-posted: open a transaction
        if tl in NP_TYPES:
            key = (rid, tag_s)
            o = self.out.get(key)
            if o is not None:
                if not o[8] and t - o[1] < self.CTO_PS:
                    self.emit("TXN.TAG_REUSE", pkt, t, "tag %s of %s reused while its %s (pkt %d) is outstanding" %
                              (tag_s, rid, o[3], o[0]), keys=(("tag", rid, tag_s),), rel=(o[0],))
            want = length * 4 if tl.startswith("MRd") else 4
            ctx = None
            if tl.startswith("MRd"):
                ctx = self.nvme_mrd(pkt, t, d, addr, length, rid)
            elif tl.startswith("CfgRd"):
                ctx = ("cfgrd", int(row[C.REG] or "0", 16))
            o = [pkt, t, d, tl, addr or 0, want, 0, ctx, False]
            self.out[key] = o
            heapq.heappush(self.out_heap, (t, pkt, key))
            self.sweep_timeouts(t)
            return
        # ---- completions
        if tl in CPL_TYPES:
            self.on_cpl(row, pkt, t, d, tl, rid, tag_s, length, nbytes)
        self.sweep_timeouts(t)

    def sweep_timeouts(self, t):
        h = self.out_heap
        while h and t - h[0][0] > self.CTO_PS:
            t0, p0, key = heapq.heappop(h)
            o = self.out.get(key)
            if o is None or o[0] != p0 or o[8]:
                continue
            o[8] = True
            if p0 <= self.gap_pkt:
                continue
            self.emit("TXN.CPL_TIMEOUT", p0, t0, "%s %s tag %s (%s) no completion after %s" %
                      (o[2], o[3], key[1], key[0], fmt_dt(t - t0)), qual=o[3][:3], keys=(("tag",) + key,))

    def on_cpl(self, row, pkt, t, d, tl, rid, tag_s, length, nbytes):
        C = self.C
        st = row[C.CPLST]
        cplid = row[C.CPLID]
        if st != "SC":
            q = st.split(" ")[0] if not st.startswith("Reserved") else "RSVD"
            self.emit("TLP.CPL_STATUS", pkt, t, "%s %s status %s from %s" % (d, tl, st, cplid), qual=q,
                      keys=(("tag", rid, tag_s),))
        if row[C.BCM] not in ("", "0"):
            self.emit("TLP.BCM", pkt, t, "BCM=%s" % row[C.BCM])
        exp_cpl = (self.rc_cpl or "000:02:4") if d == DN else (self.dev_rid or "002:00:0")
        if self.rc_cpl is None and d == DN and tl == "CplD":
            self.rc_cpl = cplid
            exp_cpl = cplid
        if cplid != exp_cpl:
            self.emit("TLP.CPLID_UNEXPECTED", pkt, t, "%s completion from %s (expected %s)" % (d, cplid, exp_cpl),
                      qual=d, keys=(("tag", rid, tag_s),))
        key = (rid, tag_s)
        o = self.out.get(key)
        if o is None or o[2] == d:
            # atlas X.6: transactions open at capture start are censored, so a completion within one
            # completion-timeout window of the first row (or at the first row itself) is never a defect
            if (self.gap_pkt < 0 or pkt - self.gap_pkt > 2000) and \
                    (self.first_t is not None and t - self.first_t > self.CTO_PS):
                self.emit("TXN.UNEXPECTED_CPL", pkt, t, "%s %s for %s tag %s: no outstanding request" %
                          (d, tl, rid, tag_s), keys=(("tag",) + key,))
            return
        if o[8]:
            self.emit("TXN.CPL_LATE", pkt, t, "completion for tag %s after the completion timeout (%s)" %
                      (tag_s, fmt_dt(t - o[1])), qual="after_timeout", keys=(("tag",) + key,), rel=(o[0],))
            del self.out[key]
            return
        if st in ("CRS", "RRS") and not o[3].startswith("Cfg"):
            self.emit("TXN.CRS_NONCFG", pkt, t, "CRS to %s" % o[3], keys=(("tag",) + key,), rel=(o[0],))
        if st in ("CRS", "RRS"):
            if self.crs is None:
                self.crs = [o[0], o[1], t, 1]
            else:
                self.crs[2] = t
                self.crs[3] += 1
                if t - self.crs[1] > self.CRS_LONG_PS and self.crs[3] > 0:
                    self.emit("TXN.CRS_LONG", self.crs[0], self.crs[1], "device still answers CRS %s after the "
                              "first config request (%d CRS)" % (fmt_dt(t - self.crs[1]), self.crs[3]), rel=(pkt,))
                    self.crs[3] = -10 ** 9
        elif self.crs is not None and o[3].startswith("Cfg"):
            self.crs = None
        bc = int(row[C.BCNT] or 0)
        if tl == "CplD":
            owed = o[5] - o[6]
            lwr = int(row[C.LWR] or "0", 16)
            exp_lwr = ((o[4] + o[6]) & 0x7F) if o[3].startswith("MRd") else 0
            if bc != owed:
                self.emit("TXN.BYTECNT", pkt, t, "Byte Cnt %d but %d B still owed" % (bc, owed),
                          keys=(("tag",) + key,), rel=(o[0],))
            elif lwr != exp_lwr:
                self.emit("TXN.LWRADDR", pkt, t, "Lwr Addr 0x%03X expected 0x%03X" % (lwr, exp_lwr),
                          keys=(("tag",) + key,), rel=(o[0],))
            got_before = o[6]
            o[6] += length * 4
            if o[6] < o[5] and o[3].startswith("MRd") and (o[4] + o[6]) % 64:
                self.emit("TXN.RCB", pkt, t, "partial CplD ends at byte %d (address 0x%X), not on a 64 B RCB "
                          "boundary" % (o[6], o[4] + o[6]), keys=(("tag",) + key,), rel=(o[0],))
            if o[6] > o[5]:
                self.emit("TXN.OVERRUN", pkt, t, "%d B returned for a %d B request" % (o[6], o[5]),
                          keys=(("tag",) + key,), rel=(o[0],))
            if got_before == 0:
                self.sample("completion_latency_dev" if d == DN else "completion_latency_host", t - o[1], pkt)
            if o[7] is not None:
                self.nvme_cpld(pkt, t, o, got_before, nbytes, st)
            if o[6] >= o[5]:
                del self.out[key]
        else:
            if o[7] is not None and st == "SC":
                self.nvme_cpld(pkt, t, o, o[6], 0, st)
            del self.out[key]

    def on_msg(self, row, pkt, t, d, tl):
        C = self.C
        code, routing = row[C.MSG], row[C.ROUTE]
        if code.startswith("ERR_"):
            self.emit("MSG.ERR", pkt, t, "%s %s from %s" % (d, code, row[C.RID]), qual=code)
        elif code not in NORMAL_MSG:
            self.emit("MSG.OTHER", pkt, t, "%s %s %s routed %s" % (d, tl, code, routing), qual=code)
            if code == "Assert_INTA" and self.msix_enabled:
                self.emit("CFG.INTX_WITH_MSIX", pkt, t, "Assert_INTA while MSI-X Enable=1")
        rule = MSG_RULES.get(code)
        if rule and (routing not in rule[0] or (rule[1] and rule[1] != d)):
            self.emit("MSG.ROUTING", pkt, t, "%s routed %s going %s" % (code, routing, d), qual=code)
        if code == "Latency_Tolerance_Reporting":
            C = self.C
            try:
                v = int(row[C.SNOOPV] or 0)
                sc_ = row[C.SNOOPS].split()[0] if row[C.SNOOPS] else "0"
                ns = v * int(sc_)
            except ValueError:
                ns = None
            self.token(pkt, "LTR|%s|%s" % (row[C.SNOOPV], row[C.SNOOPS]))
            if ns is not None and ns:
                self.ltr_ns = ns
                if ns < self.LTR_LOW_NS:
                    self.emit("PM.LTR_LOW", pkt, t, "LTR snoop latency %d ns (Requirement set): blocks deep L1.2" % ns,
                              qual="ltr")
        if code == "PME_Turn_Off":
            self.pme_off = (t, pkt)
            self.last_host_action = (t, "PME_Turn_Off")
        elif code == "PME_TO_Ack":
            self.pme_off = None

    # ------------------------------------------------------------------ configuration shadow (payload)
    def on_cfg_write(self, row, pkt, t, reg):
        pl = self.payload.get(pkt) if self.payload else None
        if not pl:
            return
        v = int.from_bytes(pl[0][:4], "little")
        if reg == 0x010:
            if v != 0xFFFFFFFF:
                nb = v & ~0xF
                if self.bar0 is not None and nb != self.bar0 and self.bar0_set_t is not None and \
                        t - self.last_down_t > 1 * SEC:
                    self.emit("CFG.BAR_CHANGE", pkt, t, "BAR0 0x%X -> 0x%X" % (self.bar0, nb))
                self.bar0 = nb
                self.bar0_set_t = t
        elif reg == 0x004:
            self.cmd_reg = v & 0xFFFF
        elif reg == 0x044:
            ds = v & 3
            if ds == 0 and self.dstate == 3:
                self.d0_t = (t, pkt)
                self.d0_resume = (t, pkt)
            self.dstate = ds
        elif reg == 0x078:
            if v & (1 << 15):
                self.flr_t = (t, pkt)
                self.emit("CFG.FLR", pkt, t, "Function Level Reset", qual="flr")
                self.nvme_reset(pkt, t, "FLR")
            mps = 128 << ((v >> 5) & 7)
            mrrs = 128 << ((v >> 12) & 7)
            if self.devctl is not None and (mps != self.mps or mrrs != self.mrrs) and not v & (1 << 15):
                self.emit("CFG.DEVCTL_CHANGE", pkt, t, "Device Control: MPS %d->%d MRRS %d->%d" %
                          (self.mps, mps, self.mrrs, mrrs))
            if not v & (1 << 15):
                self.mps, self.mrrs, self.devctl = mps, mrrs, v
        elif reg == 0x0B0:
            self.msix_enabled = bool(v & (1 << 31))
        elif reg == 0x098:
            # Device Control 2: Completion Timeout Value (bits 3:0) and Completion Timeout Disable (bit 4).
            # The upper bound of the programmed range is the deadline a requester may use.
            if v & 0x10:
                self.CTO_PS = 1 << 62
                self.cto_source = "configured: Completion Timeout disabled (Device Control 2 = 0x%08X)" % v
            else:
                rng = CTO_RANGES.get(v & 0xF)
                if rng:
                    self.CTO_PS = rng[1]
                    self.cto_source = "configured: Device Control 2 range %s (%s)" % (format(v & 0xF, "04b"), rng[0])
        elif reg not in (0x014, 0x080, 0x018, 0x01C, 0x020, 0x024):
            self.emit("CFG.WRITE_RARE", pkt, t, "CfgWr0 reg 0x%03X = 0x%08X" % (reg, v), qual="0x%03X" % reg)

    def on_cfg_read(self, pkt, t, reg, v):
        """config_shadow: values the device returns to configuration reads."""
        # PCIe Base Specification, Type 0 configuration space header: Vendor ID 00h, Device ID 02h, Revision ID 08h,
        # Subsystem Vendor ID 2Ch, Subsystem ID 2Eh. 0xFFFF / all-ones means "no function" and is ignored.
        if v and v != 0xFFFFFFFF:
            if reg == 0x000 and (v & 0xFFFF) != 0xFFFF:
                self.identity.setdefault("pci_vendor_id", "%04X" % (v & 0xFFFF))
                self.identity.setdefault("pci_device_id", "%04X" % (v >> 16))
            elif reg == 0x008:
                self.identity.setdefault("pci_revision_id", "%02X" % (v & 0xFF))
            elif reg == 0x02C and (v & 0xFFFF) not in (0, 0xFFFF):
                self.identity.setdefault("pci_subsystem_vendor_id", "%04X" % (v & 0xFFFF))
                self.identity.setdefault("pci_subsystem_id", "%04X" % (v >> 16))
        if reg == 0x0B0:
            self.msix_enabled = bool(v & (1 << 31))
        elif reg == 0x044:
            self.dstate = v & 3
        elif reg == 0x034:
            self.cap_next = v & 0xFC
        elif reg in (0x104, 0x110) and v and v != 0xFFFFFFFF:
            self.emit("CFG.AER_STATUS", pkt, t, "AER %s Error Status = 0x%08X" %
                      ("Uncorrectable" if reg == 0x104 else "Correctable", v),
                      qual="uncorrectable" if reg == 0x104 else "correctable")
        if reg == getattr(self, "cap_next", None) and v != 0xFFFFFFFF:
            cid, nxt = v & 0xFF, (v >> 8) & 0xFC
            self.cap_next = nxt
            if nxt == 0 and cid == 0x01:
                self.emit("CFG.CAP_CHAIN", pkt, t, "capability list ends at the PM capability (0x%03X): "
                          "PCI Express / MSI-X capabilities unreachable" % reg)

    def on_identify_controller(self, b):
        """NVMe Base Specification, Identify Controller data structure (CNS 01h): VID bytes 01:00, SSVID 03:02,
        SN 23:04 (ASCII), MN 63:24 (ASCII), FR 71:64 (ASCII). The Linux driver keys its device workarounds on
        (VID, MN, FR) - drivers/nvme/host/core.c core_quirks[] - so model + firmware revision name the device context."""
        def ascii(x):
            t = bytes(x).decode("ascii", "replace").strip(" \x00")
            return t if t and all(32 <= ord(ch) < 127 for ch in t) else None
        ident = {"nvme_vendor_id": "%04X" % int.from_bytes(b[0:2], "little"),
                 "nvme_subsystem_vendor_id": "%04X" % int.from_bytes(b[2:4], "little"),
                 "serial_number": ascii(b[4:24]), "model_number": ascii(b[24:64]), "firmware_revision": ascii(b[64:72])}
        if ident["model_number"]:                         # only trust a payload whose model field is readable text
            for k, v in ident.items():
                if v:
                    self.identity[k] = v

    def mmio_gate(self, pkt, t, what):
        """Checks every host MMIO access against the config shadow."""
        if self.cfg_first_t is not None:
            self.sample("config_to_driver", t - self.cfg_first_t[0], self.cfg_first_t[1])
            self.cfg_first_t = None
        if self.cmd_reg is not None and not self.cmd_reg & 0x2:
            self.emit("CFG.MEM_DISABLED_MMIO", pkt, t, "%s with Memory Space Enable = 0" % what)
        if self.dstate == 3:
            self.emit("CFG.D3_ACCESS", pkt, t, "%s while the function is in D3hot" % what)
        if self.d0_t and t - self.d0_t[0] < self.D0_WAIT_PS:
            self.emit("CFG.D0_EARLY", pkt, t, "%s %s after D3hot->D0" % (what, fmt_dt(t - self.d0_t[0])),
                      rel=(self.d0_t[1],))
            self.d0_t = None
        elif self.d0_t and t - self.d0_t[0] >= self.D0_WAIT_PS:
            self.d0_t = None
        if self.flr_t and t - self.flr_t[0] < self.FLR_WAIT_PS:
            self.emit("CFG.FLR_EARLY", pkt, t, "%s %s after FLR" % (what, fmt_dt(t - self.flr_t[0])),
                      rel=(self.flr_t[1],))
            self.flr_t = None

    # ------------------------------------------------------------------ NVMe over PCIe (payload)
    def nvme_reset(self, pkt, t, why):
        """Controller state is lost (CC.EN=0, FLR, link down): outstanding commands end here."""
        for c in list(self.open.values()):
            if c.timed_out or (c.sqid == 0 and c.opc == 0x0C):
                continue
            age = t - (c.t_db if c.t_db is not None else c.t_fetch or t)
            limit = self.ADMIN_TIMEOUT_PS if c.sqid == 0 else self.IO_TIMEOUT_PS
            if c.pkt_fetch is None and c.pkt_db is not None and age > self.NOT_FETCHED_PS:
                self.emit("NVME.NOT_FETCHED", c.pkt_db, c.t_db, "SQ%d slot rung %s before %s, never fetched" %
                          (c.sqid, fmt_dt(age), why), keys=(("sq", c.sqid),), rel=(pkt,))
            elif age > min(limit, 1 * SEC) or c.sqid == 0 and age > 1 * SEC:
                self.emit("NVME.CMD_TIMEOUT", c.pkt_sqe or c.pkt_db, c.t_sqe or c.t_db,
                          "%s CID %d on SQ%d without completion for %s, ended by %s" %
                          (opc_name(c.sqid, c.opc), c.cid, c.sqid, fmt_dt(age), why), qual=why.split()[0],
                          keys=(("cmd", c.sqid, c.cid),), rel=(pkt,))
            else:
                self.emit("NVME.CMD_LOST_RESET", c.pkt_sqe or c.pkt_db or pkt, c.t_sqe or c.t_db or t,
                          "%s CID %d on SQ%d outstanding at %s" % (opc_name(c.sqid, c.opc), c.cid, c.sqid, why),
                          qual=why.split()[0], keys=(("cmd", c.sqid, c.cid),), rel=(pkt,))
            c.timed_out = True
        for qid, q in self.sq.items():
            stale = sorted((tdb, pdb, slot) for slot, (tdb, pdb) in q["db_t"].items() if t - tdb > self.NOT_FETCHED_PS)
            if stale:                          # one finding per queue: the first unfetched slot and the count
                tdb, pdb, slot = stale[0]
                self.emit("NVME.NOT_FETCHED", pdb, tdb, "SQ%d: %d slot(s) rung (first slot %d, %s before %s) never "
                          "fetched" % (qid, len(stale), slot, fmt_dt(t - tdb), why), keys=(("sq", qid),), rel=(pkt,))
        self.open.clear()
        self.n_active = 0
        self.page_owner.clear()
        self.sq = {}
        self.cq = {}
        self.pending_msi = {}
        self.msi_first = None

    def admin_queues(self):
        if self.asq is None or self.acq is None or self.aqa is None:
            return
        self.sq[0] = {"base": self.asq, "size": (self.aqa & 0xFFF) + 1, "cqid": 0, "tail": 0, "head": 0,
                      "db_t": {}}
        self.cq[0] = {"base": self.acq, "size": ((self.aqa >> 16) & 0xFFF) + 1, "iv": 0, "tail": 0, "phase": 1,
                      "head": 0, "posted": 0, "resync": False}

    def on_mwr(self, row, pkt, t, d, tl, addr, length, nbytes, fbe, rid):
        pl = self.payload.get(pkt) if self.payload else None
        if d == DN:
            if self.bar0 is not None and self.bar0 <= addr < self.bar0 + 0x4000:
                self.mmio_gate(pkt, t, "MMIO write 0x%X" % (addr - self.bar0))
                if pl:
                    self.nvme_reg_write(pkt, t, addr - self.bar0, pl, length, fbe, row)
            return
        # ---- device-initiated memory write
        if self.cmd_reg is not None and not self.cmd_reg & 0x4:
            self.emit("CFG.BME_OFF_DMA", pkt, t, "device MWr with Bus Master Enable = 0")
        if 0xFEE00000 <= addr <= 0xFEEFFFFF:
            self.on_msi(pkt, t, addr, pl)
            return
        if not self.payload:
            return
        for qid, q in self.cq.items():
            if q["base"] <= addr < q["base"] + q["size"] * 16:
                if pl and pl[2] == 16:
                    self.on_cqe(pkt, t, qid, (addr - q["base"]) // 16, pl[0])
                return
        self.dma(pkt, t, addr, nbytes, pl, "d2h")

    def on_msi(self, pkt, t, addr, pl):
        """msi_tracker: each MSI-X write consumes one posted CQE of its vector."""
        if not self.payload or not self.cq:
            return
        if self.msix_addrs and addr not in self.msix_addrs:
            self.emit("NVME.MSIX_ADDR", pkt, t, "MSI-X write to 0x%08X: not a programmed vector address" % addr)
        vec = self.msix_vec.get((addr, int.from_bytes(pl[0][:4], "little"))) if pl else None
        q = self.pending_msi.get(vec) if vec is not None else None
        if vec is not None and not q:
            # a CQE is waiting on ANOTHER vector and this interrupt came right after it: wrong vector
            others = [(v, d) for v, d in self.pending_msi.items() if d and v != vec and t - d[0][0] < 10 * US]
            if others:
                ov, od = min(others, key=lambda x: x[1][0][0])
                t0, p0, cqid = od.popleft()
                self.emit("NVME.MSIX_WRONG_VECTOR", pkt, t, "MSI-X on vector %d (0x%08X) %s after the CQE #%d on CQ%d, "
                          "which was created with interrupt vector %d" % (vec, addr, fmt_dt(t - t0), p0, cqid, ov),
                          qual="v%d->v%d" % (ov, vec), keys=(("cq", cqid),), rel=(p0,))
                return
        if q is None:                     # vector unknown: take the oldest pending CQE of any vector
            q = min((d for d in self.pending_msi.values() if d), key=lambda d: d[0][0], default=None)
        if q:
            q.popleft()
        else:
            self.msi_first = (t, pkt, vec)

    def msi_deadlines(self, t):
        for vec, q in self.pending_msi.items():
            while q and t - q[0][0] > self.NO_MSIX_PS:
                t0, p0, cqid = q.popleft()
                self.emit("NVME.NO_MSIX", p0, t0, "CQE on CQ%d (vector %s) not followed by an MSI-X within %s" %
                          (cqid, vec, fmt_dt(self.NO_MSIX_PS)), keys=(("cq", cqid),))
        if self.msi_first and t - self.msi_first[0] > 10 * US:
            t0, p0, vec = self.msi_first
            self.msi_first = None
            self.emit("NVME.MSIX_BEFORE_CQE", p0, t0, "MSI-X (vector %s) with no CQE posted before it" % vec,
                      qual="spurious")

    def nvme_reg_write(self, pkt, t, off, pl, length, fbe, row):
        b = pl[0]
        v = int.from_bytes(b[:4], "little")
        if off == 0x14:
            old = self.cc
            self.cc = v
            if (old & 1) and (v & 1) and (v & ~0xC000) != (old & ~0xC000):
                self.emit("REG.CC_WHILE_EN", pkt, t, "CC 0x%08X -> 0x%08X while enabled" % (old, v))
            if not (old & 1) and (v & 1):
                self.en_t, self.en_pkt = t, pkt
                self.io_done_since_en = 0
                self.shn_t = None
                self.rdy_seen = False
                if self.rdy == 1:
                    self.emit("REG.CC_WHILE_EN", pkt, t, "CC.EN=1 while CSTS.RDY still 1", qual="en_before_rdy0")
                self.admin_queues()
            elif (old & 1) and not (v & 1):
                self.emit("REG.CTRL_RESET", pkt, t, "host writes CC.EN=0", qual="disable")
                self.n_disables += 1
                stuck = any(not c.timed_out and not (c.sqid == 0 and c.opc == 0x0C) and
                            t - (c.t_db if c.t_db is not None else c.t_fetch) > 5 * SEC for c in self.open.values())
                explained = stuck or t - self.last_defect_t < self.RESET_QUIET_PS
                running = self.en_t is not None and t - self.en_t > 1 * SEC and self.io_done_since_en > 0
                storm = self.last_disable_t >= 0 and t - self.last_disable_t < 10 * SEC
                if not explained and (running or storm) and self.n_disables > 1 and not self.shn_t:
                    self.emit("REG.RESET_UNEXPLAINED", pkt, t, "host %s with no wire-visible cause (no timeout, CFS, "
                              "link loss, fatal error or invalid CQE in the previous %s): the reason is host-side - "
                              "read the host log" % ("reset the controller again within %s" %
                                                     fmt_dt(t - self.last_disable_t) if storm else
                                                     "reset a running controller (%d I/O completed)" %
                                                     self.io_done_since_en, fmt_dt(self.RESET_QUIET_PS)),
                              qual="storm" if storm else "reset")
                self.last_disable_t = t
                self.last_host_action = (t, "controller disable")
                if self.en_t is not None and not self.rdy_seen:
                    self.emit("REG.RDY_TIMEOUT", self.en_pkt, self.en_t, "CC.EN=1 but CSTS.RDY never 1; host "
                              "disabled the controller after %s" % fmt_dt(t - self.en_t), qual="host_gave_up",
                              rel=(pkt,))
                self.en_t = None
                self.nvme_reset(pkt, t, "controller disable")
            if (v >> 14) & 3 and not (old >> 14) & 3:
                self.shn_t = (t, pkt)
                self.last_host_action = (t, "shutdown notification")
        elif off == 0x24:
            self.aqa = v
        elif off == 0x28:
            self.asq = int.from_bytes(b[:8], "little") if len(b) >= 8 else v
        elif off == 0x30:
            self.acq = int.from_bytes(b[:8], "little") if len(b) >= 8 else v
        elif off >= 0x1000 and off < 0x2000:
            stride = 4 << self.dstrd
            idx = (off - 0x1000) // stride
            qid, is_cq = idx // 2, idx % 2
            if length != 1 or (not self.be_cols_absent and row[self.C.FBE] != "1111") or len(b) < 4:
                self.emit("DB.PARTIAL", pkt, t, "%s doorbell %d written with Length %d 1st BE %s" %
                          ("CQ" if is_cq else "SQ", qid, length, row[self.C.FBE]), keys=(("sq", qid),))
            if self.en_t is not None and not self.rdy_seen and t - self.en_t < 60 * SEC:
                self.emit("REG.ACCESS_NOT_READY", pkt, t, "doorbell written before CSTS.RDY=1")
            self.doorbell(pkt, t, qid, is_cq, v & 0xFFFF)
        elif off >= 0x2000 and off < 0x3000:
            vec = (off - 0x2000) // 16
            if len(b) >= 12:
                self.msix_vec[(int.from_bytes(b[:4], "little"), int.from_bytes(b[8:12], "little"))] = vec
                self.msix_addrs.add(int.from_bytes(b[:4], "little"))
            if len(b) >= 16 and b[12] & 1 or (off % 16 == 12 and b[0] & 1):
                self.emit("NVME.MSIX_MASKED", pkt, t, "host masks MSI-X vector %d (Vector Control bit 0)" % vec,
                          qual="mask")

    def doorbell(self, pkt, t, qid, is_cq, v):
        if is_cq:
            q = self.cq.get(qid)
            if q is None:
                self.emit("DB.NOQ", pkt, t, "CQ%d head doorbell but CQ%d does not exist" % (qid, qid), qual="cq",
                          keys=(("sq", qid),))
                return
            if v >= q["size"]:
                self.emit("DB.RANGE", pkt, t, "CQ%d head %d >= size %d" % (qid, v, q["size"]), qual="cq",
                          keys=(("sq", qid),))
                return
            used = (q["tail"] - q["head"]) % q["size"]
            adv = (v - q["head"]) % q["size"]
            pt = q.get("posted_t")
            if pt and adv:
                self.sample("cq_head_lag", t - pt[0][0], pt[0][1])
                self.sample("cq_batch", adv, pkt)
                for _ in range(min(adv, len(pt))):
                    pt.popleft()
            if adv > used and not q.get("resync"):
                self.emit("DB.CQ_PAST_TAIL", pkt, t, "CQ%d head %d->%d releases %d entries, %d posted" %
                          (qid, q["head"], v, adv, used), keys=(("sq", qid),))
            q["head"] = v
            return
        q = self.sq.get(qid)
        if q is None:
            self.emit("DB.NOQ", pkt, t, "SQ%d tail doorbell but SQ%d does not exist" % (qid, qid), qual="sq",
                      keys=(("sq", qid),))
            return
        if v >= q["size"]:
            self.emit("DB.RANGE", pkt, t, "SQ%d tail %d >= size %d" % (qid, v, q["size"]), qual="sq",
                      keys=(("sq", qid),))
            return
        old = q["tail"]
        n = (v - old) % q["size"]
        outstanding = (old - q["head"]) % q["size"]
        if n + outstanding >= q["size"]:
            self.emit("DB.SQ_OVERFLOW", pkt, t, "SQ%d tail %d->%d overruns head %d" % (qid, old, v, q["head"]),
                      keys=(("sq", qid),))
        if n:
            self.sample("sq_batch", n, pkt)
        s = old
        for _ in range(min(n, 4096)):
            q["db_t"][s] = (t, pkt)
            s = (s + 1) % q["size"]
        q["tail"] = v

    def nvme_mrd(self, pkt, t, d, addr, length, rid):
        """Classify an MRd: host register read, SQE fetch, PRP-list fetch or write-data fetch."""
        if d == DN:
            if self.bar0 is not None and addr is not None and self.bar0 <= addr < self.bar0 + 0x4000:
                self.mmio_gate(pkt, t, "MMIO read 0x%X" % (addr - self.bar0))
                return ("reg", addr - self.bar0)
            return None
        if self.cmd_reg is not None and not self.cmd_reg & 0x4:
            self.emit("CFG.BME_OFF_DMA", pkt, t, "device MRd with Bus Master Enable = 0")
        if not self.payload:
            return None
        for qid, q in self.sq.items():
            if q["base"] <= addr < q["base"] + q["size"] * 64:
                slot = (addr - q["base"]) // 64
                return ("sqe", qid, slot, pkt, t)
        own = self.page_owner.get(addr & ~0xFFF)
        if own is not None and own.t_cqe is not None and t - own.t_cqe > self.LATE_DATA_PS:
            del self.page_owner[addr & ~0xFFF]
            own = None
        if own is not None and own.t_cqe is None:
            if own.list_addr is not None and addr & ~0xFFF == own.list_addr & ~0xFFF and addr >= own.list_addr:
                need = (own.npages - 1) * 8
                if length * 4 > max(need, 8) + 8:
                    self.emit("NVME.PRP_LIST", pkt, t, "PRP list read of %d B, %d B needed" % (length * 4, need),
                              keys=(("cmd", own.sqid, own.cid),))
                return ("list", own, addr)
            return ("wdata", own, addr)
        return ("dma", addr)

    def nvme_cpld(self, pkt, t, o, got_before, nbytes, st):
        ctx = o[7]
        kind = ctx[0]
        pl = self.payload.get(pkt) if (self.payload and nbytes) else None
        if kind == "reg":
            if pl:
                self.nvme_reg_read(pkt, t, ctx[1], pl[0])
            return
        if kind == "cfgrd":
            if pl:
                self.on_cfg_read(pkt, t, ctx[1], int.from_bytes(pl[0][:4], "little"))
            return
        if not pl:
            return
        if kind == "sqe":
            _, qid, slot, fpkt, ft = ctx
            if pl[2] >= 64 and len(pl[0]) >= 64:
                self.on_sqe(pkt, t, qid, slot, pl[0][:64], fpkt, ft)
            return
        if kind == "list":
            c = ctx[1]
            b = pl[0]
            ents = [int.from_bytes(b[i:i + 8], "little") for i in range(0, len(b) - 7, 8)]
            base_i = 1 + (got_before + (ctx[2] - c.list_addr)) // 8
            for i, e in enumerate(ents):
                if e:
                    pi = base_i + i
                    while len(c.pages) <= pi:
                        c.pages.append(None)
                    c.pages[pi] = e & ~0xFFF
                    self.page_owner[e & ~0xFFF] = c
            if pl[2] > len(b):
                c.pages_known = False
            return
        if kind == "wdata":
            c, a = ctx[1], ctx[2]
            self.cmd_data(pkt, t, c, a + got_before, pl, write=True)
            return

    def nvme_reg_read(self, pkt, t, off, b):
        v = int.from_bytes(b[:4], "little")
        if off == 0x00 and len(b) >= 8:
            cap = int.from_bytes(b[:8], "little")
            self.cap_to = (cap >> 24) & 0xFF
            self.dstrd = (cap >> 32) & 0xF
            css = (cap >> 37) & 0xFF
            if self.cap_to == 0 or css == 0:
                self.emit("REG.CAP_ODD", pkt, t, "CAP 0x%016X: TO=%d (x500 ms = %s), CSS=0x%02X%s, CRMS=%d - %s" %
                          (cap, self.cap_to, fmt_dt(self.cap_to * 500 * MS), css,
                           " (no command set advertised)" if css == 0 else "", (cap >> 59) & 3,
                           "zero ready timeout" if self.cap_to == 0 else "no command set"))
        if off == 0x68 and self.cap_to:
            crwmt, crimt = v & 0xFFFF, (v >> 16) & 0xFFFF
            if crwmt < self.cap_to or crimt < self.cap_to:
                self.emit("REG.CRTO_LT_CAP", pkt, t, "CRTO = 0x%08X: CRWMT %d (%s), CRIMT %d (%s) < CAP.TO %d (%s); Linux "
                          "logs 'bad crto' and falls back to CAP.TO" % (v, crwmt, fmt_dt(crwmt * 500 * MS), crimt,
                                                                       fmt_dt(crimt * 500 * MS), self.cap_to,
                                                                       fmt_dt(self.cap_to * 500 * MS)),
                          qual="crwmt<cap" if crwmt < self.cap_to else "crimt<cap")
        if v == 0xFFFFFFFF:
            self.emit("REG.ALL_ONES", pkt, t, "register 0x%X read 0xFFFFFFFF" % off, qual="0x%X" % off)
            return
        if off != 0x1C:
            return
        rdy, cfs, shst = v & 1, (v >> 1) & 1, (v >> 2) & 3
        if cfs:
            self.emit("REG.CFS", pkt, t, "CSTS = 0x%08X (CFS=1)" % v)
        if v & 0x10:
            self.emit("REG.NSSRO", pkt, t, "CSTS.NSSRO=1: an NVM Subsystem Reset occurred")
        if v & 0x20:
            if self.pp_t is None:
                self.pp_t = (t, pkt)
            elif t - self.pp_t[0] > self.PP_LONG_PS and not self.pp_flagged:
                self.pp_flagged = True
                self.emit("REG.PP_LONG", self.pp_t[1], self.pp_t[0], "CSTS.PP (processing paused) still 1 after %s"
                          % fmt_dt(t - self.pp_t[0]), rel=(pkt,))
        else:
            self.pp_t, self.pp_flagged = None, False
        if rdy and self.d0_resume and t - self.d0_resume[0] > self.RESUME_SLOW_PS:
            self.emit("PM.RESUME_SLOW", self.d0_resume[1], self.d0_resume[0], "controller ready %s after D3hot->D0"
                      % fmt_dt(t - self.d0_resume[0]), rel=(pkt,))
        if rdy:
            self.d0_resume = None
        if rdy and self.en_t is not None and not self.rdy_seen:
            self.rdy_seen = True
            dt = t - self.en_t
            budget = (self.cap_to or 0) * 500 * MS
            if budget and dt > budget:
                self.emit("REG.RDY_TIMEOUT", self.en_pkt, self.en_t, "CSTS.RDY=1 after %s > CAP.TO budget %s" %
                          (fmt_dt(dt), fmt_dt(budget)), qual="late", rel=(pkt,))
            elif dt > self.RDY_SLOW_PS:
                self.emit("REG.RDY_SLOW", self.en_pkt, self.en_t, "CSTS.RDY=1 after %s" % fmt_dt(dt), rel=(pkt,))
        self.rdy = rdy
        if self.shn_t:
            if shst == 2:
                dt = t - self.shn_t[0]
                if dt > 5 * SEC:
                    self.emit("REG.SHN_SLOW", self.shn_t[1], self.shn_t[0], "shutdown complete after %s" % fmt_dt(dt),
                              rel=(pkt,))
                self.shn_t = None

    def on_sqe(self, pkt, t, qid, slot, b, fpkt, ft):
        q = self.sq.get(qid)
        dw = struct.unpack("<16I", b)
        opc, fuse, psdt, cid = dw[0] & 0xFF, (dw[0] >> 8) & 3, (dw[0] >> 14) & 3, dw[0] >> 16
        c = Cmd()
        c.sqid, c.cid, c.opc, c.nsid = qid, cid, opc, dw[1]
        c.prp1, c.prp2 = dw[6] | dw[7] << 32, dw[8] | dw[9] << 32
        c.cdw10, c.cdw11, c.cdw12 = dw[10], dw[11], dw[12]
        c.dw = dw
        c.slba, c.nlb = dw[10] | dw[11] << 32, (dw[12] & 0xFFFF) + 1
        c.pkt_fetch, c.t_fetch, c.pkt_sqe, c.t_sqe = fpkt, ft, pkt, t
        c.cqid = q["cqid"] if q else None
        dbt = q["db_t"].pop(slot, None) if q else None
        c.pkt_db, c.t_db = (dbt[1], dbt[0]) if dbt else (None, None)
        if q:
            q["head"] = (slot + 1) % q["size"]
        if c.t_db is not None:
            self.sample("fetch_latency", ft - c.t_db, fpkt)
        self.sample("queue_depth", len(self.open), pkt)
        c.qd = self.n_active
        self.last_sqe_t = t
        name = opc_name(qid, opc)
        k = (("cmd", qid, cid),)
        if (qid, cid) in self.open and not self.open[(qid, cid)].timed_out:
            self.emit("NVME.CID_REUSE", pkt, t, "CID %d reused on SQ%d while %s is outstanding" %
                      (cid, qid, opc_name(qid, self.open[(qid, cid)].opc)), keys=k,
                      rel=(self.open[(qid, cid)].pkt_sqe,))
        if (qid == 0 and opc not in ADMIN_OPC) or (qid != 0 and opc not in IO_OPC):
            self.emit("NVME.SQE_OPCODE", pkt, t, "opcode 0x%02X on %s queue" % (opc, "admin" if qid == 0 else "I/O"),
                      qual="0x%02X" % opc, keys=k)
        if qid == 0:
            bad_nsid = c.nsid not in (0, 1, 0xFFFFFFFF)
        else:
            bad_nsid = c.nsid != 1 and not (c.nsid == 0xFFFFFFFF and opc == 0x00)
        if bad_nsid:
            self.emit("NVME.SQE_NSID", pkt, t, "%s NSID 0x%X" % (name, c.nsid), keys=k)
        if fuse:
            self.emit("NVME.SQE_FUSE", pkt, t, "%s FUSE=%d" % (name, fuse), qual=str(fuse), keys=k)
        if psdt:
            self.emit("NVME.SQE_SGL", pkt, t, "%s PSDT=%d (SGL)" % (name, psdt), keys=k)
        is_rw = qid != 0 and opc in (0x01, 0x02, 0x05, 0x08, 0x0C, 0x04, 0x7D)
        moves = qid != 0 and opc in (0x01, 0x02, 0x05, 0x7D)
        c.xfer = c.nlb * 512 if moves else 0
        if qid == 0 and opc in (0x02, 0x06, 0x0A, 0x12) and c.prp1:
            c.xfer = 4096
        if is_rw:
            if self.nsze is not None and c.slba + c.nlb > self.nsze:
                self.emit("NVME.SQE_LBA", pkt, t, "%s SLBA 0x%X + %d blocks > NSZE 0x%X" %
                          (name, c.slba, c.nlb, self.nsze), keys=k)
            if dw[2] or dw[3]:
                self.emit("NVME.SQE_RSVD", pkt, t, "%s CDW2/CDW3 = 0x%X/0x%X" % (name, dw[2], dw[3]), keys=k)
            if moves and c.xfer > self.mdts:
                self.emit("NVME.SQE_MDTS", pkt, t, "%s of %d B > MDTS %d B" % (name, c.xfer, self.mdts), keys=k)
        if c.xfer and c.prp1:
            if c.prp1 % 4:
                self.emit("NVME.SQE_PRP", pkt, t, "%s PRP1 0x%X not dword aligned" % (name, c.prp1), qual="prp1",
                          keys=k)
            off0 = c.prp1 & 0xFFF
            npages = (off0 + c.xfer + PAGE - 1) // PAGE
            c.npages = npages
            c.pages = [c.prp1 & ~0xFFF]
            if npages == 2:
                if c.prp2 & 0xFFF:
                    self.emit("NVME.SQE_PRP", pkt, t, "%s PRP2 0x%X not page aligned" % (name, c.prp2),
                              qual="prp2", keys=k)
                c.pages.append(c.prp2 & ~0xFFF)
            elif npages > 2:
                if c.prp2 & 0x7:
                    self.emit("NVME.SQE_PRP", pkt, t, "%s PRP list pointer 0x%X not qword aligned" % (name, c.prp2),
                              qual="list", keys=k)
                c.list_addr = c.prp2
                self.page_owner[c.prp2 & ~0xFFF] = c
            for p in c.pages:
                self.page_owner[p] = c
        else:
            c.npages = 0
        if qid == 0 and opc == 0x0C:
            self.aer_seen = True
        if qid == 0 and opc == 0x08:
            tsq, tcid = c.cdw10 & 0xFFFF, c.cdw10 >> 16
            tgt = self.open.get((tsq, tcid))
            self.emit("NVME.ABORT", pkt, t, "Abort of CID %d on SQ%d" % (tcid, tsq), keys=(("cmd", tsq, tcid),) + k)
            if tgt is not None and not tgt.timed_out:
                t_sub = tgt.t_db if tgt.t_db is not None else tgt.t_sqe
                p_sub = tgt.pkt_db if tgt.pkt_db is not None else tgt.pkt_sqe
                early = t - t_sub < 1 * SEC
                if early:
                    self.emit("NVME.HOST_ABORT_EARLY", pkt, t, "host Abort of %s CID %d on SQ%d only %s after its %s "
                              "(#%d) - no host timeout can have fired; the device's answer is that command's CQE "
                              "status (SC 0x07 = Command Abort Requested is the correct response)" %
                              (opc_name(tsq, tgt.opc), tcid, tsq, fmt_dt(t - t_sub),
                               "doorbell" if tgt.t_db is not None else "SQE fetch", p_sub), qual="early",
                              keys=(("cmd", tsq, tcid),), rel=(p_sub, tgt.pkt_sqe))
                    tgt.aborted = True
                else:
                    self.emit("NVME.CMD_TIMEOUT", tgt.pkt_sqe, tgt.t_sqe, "%s CID %d on SQ%d aborted by the host after %s" %
                              (opc_name(tsq, tgt.opc), tcid, tsq, fmt_dt(t - tgt.t_sqe)), qual="aborted",
                          keys=(("cmd", tsq, tcid),), rel=(pkt,))
        if qid == 0 and opc in (0x09, 0x0A):
            fid = c.cdw10 & 0xFF
            if (c.cdw10 >> 31) or fid in (0x06, 0x84, 0x83, 0x0C, 0x11):
                self.emit("NVME.FEATURE", pkt, t, "%s FID 0x%02X%s" % (name, fid, " (Save)" if c.cdw10 >> 31 else ""),
                          qual="0x%02X" % fid, keys=k)
        if qid != 0 and opc == 0x09 and c.cdw11 & 0x4:
            c.xfer = ((c.cdw10 & 0xFF) + 1) * 16
        if is_rw and (dw[4] or dw[5]):
            self.emit("NVME.SQE_MPTR", pkt, t, "%s with Metadata Pointer 0x%X" % (name, dw[4] | dw[5] << 32),
                      keys=k)
        if qid == 0:
            sub = c.cdw10 & 0xFF
            self.token(pkt, "SQE|A|%02X|%02X" % (opc, sub))
        else:
            sz = c.nlb * 512
            self.token(pkt, "SQE|IO|%02X|%s|%d%d%d" % (opc, "big" if sz > 131072 else "", fuse, psdt,
                                                       1 if (c.cdw12 >> 26) & 0xF else 0))
        self.open[(qid, cid)] = c
        self.recount_active()

    def recount_active(self):
        """Commands the host is waiting for (Async Event Requests wait by design and do not count)."""
        self.n_active = sum(1 for c in self.open.values() if not c.timed_out and not (c.sqid == 0 and c.opc == 0x0C))

    def cmd_data(self, pkt, t, c, a, pl, write):
        """A data TLP belonging to command c at host address a."""
        if c.t_cqe is not None and t - c.t_cqe > self.LATE_DATA_PS:
            for p in c.pages:
                if self.page_owner.get(p) is c:
                    del self.page_owner[p]
            return
        if c.pkt_first_data is None:
            c.pkt_first_data = pkt
            if not write and c.opc == 0x02 and c.sqid != 0:
                self.sample("read_media_latency", t - c.t_sqe, pkt)
        c.pkt_last_data, c.t_last_data = pkt, t
        n = pl[2]
        c.moved += n
        if c.t_cqe is not None:
            if not write and c.opc in (0x02,) and c.sqid != 0:
                self.emit("NVME.CQE_BEFORE_DATA", pkt, t, "data for %s CID %d written %s after its CQE" %
                          (opc_name(c.sqid, c.opc), c.cid, fmt_dt(t - c.t_cqe)), keys=(("cmd", c.sqid, c.cid),),
                          rel=(c.pkt_cqe,))
            else:
                self.emit("NVME.DMA_AFTER_CQE", pkt, t, "device DMA into %s CID %d buffer %s after its CQE" %
                          (opc_name(c.sqid, c.opc), c.cid, fmt_dt(t - c.t_cqe)), keys=(("cmd", c.sqid, c.cid),),
                          rel=(c.pkt_cqe,))
            return
        if c.sqid == 0 or c.opc not in (0x01, 0x02):
            if c.sqid == 0 and c.opc == 0x02 and not write and pkt == c.pkt_first_data:
                lid = c.cdw10 & 0xFF
                b = pl[0]
                if lid == 0x02 and b and b[0]:
                    self.emit("NVME.LOG_CRITICAL", pkt, t, "SMART critical warning 0x%02X" % b[0], qual="smart",
                              keys=(("cmd", c.sqid, c.cid),))
                elif lid == 0x01 and len(b) >= 8 and 0 < int.from_bytes(b[:8], "little") < (1 << 32):
                    self.emit("NVME.LOG_CRITICAL", pkt, t, "Error log entry count %d" %
                              int.from_bytes(b[:8], "little"), qual="errlog", keys=(("cmd", c.sqid, c.cid),))
            if c.sqid == 0 and c.opc == 0x06 and not write and pkt == c.pkt_first_data and (c.cdw10 & 0xFF) == 0x01 \
                    and len(pl[0]) >= 72 and (c.prp1 & 0xFFF) == 0:
                self.on_identify_controller(pl[0])
            if c.sqid == 0 and c.opc == 0x06 and not write and pkt == c.pkt_first_data and (c.cdw10 & 0xFF) == 0 \
                    and len(pl[0]) >= 8 and c.nsid == 1:
                v = int.from_bytes(pl[0][:8], "little")
                if 0 < v < (1 << 40):                     # Identify NS NSZE (blocks); ignore implausible data
                    self.nsze = v
            if c.sqid != 0 and c.opc == 0x09 and write:
                b = pl[0]
                for i in range(0, len(b) - 15, 16):
                    nlb_r, slba_r = struct.unpack("<IQ", b[i + 4:i + 16])
                    c.wchunks.setdefault("dsm", []).append((slba_r, nlb_r))
            return
        off0 = c.prp1 & 0xFFF
        page = a & ~0xFFF
        try:
            pi = c.pages.index(page)
        except ValueError:
            return
        o = (a - c.prp1) if pi == 0 else (PAGE - off0) + (pi - 1) * PAGE + (a & 0xFFF)
        key = c.slba * 512 + o
        if write:
            c.wchunks[key] = pl[1] | (n << 32)
        else:
            exp = self.ledger.get(key)
            if exp is not None and (exp >> 32) == n:
                if exp & 0xFFFFFFFF != pl[1]:
                    zero = self.zcrc(n)
                    if exp & 0xFFFFFFFF == zero:
                        self.emit("DATA.NOT_ZERO", pkt, t, "Read LBA 0x%X+%d B returned data, zeros expected" %
                                  (c.slba, o), keys=(("lba", c.slba),), rel=(self.ledger_src.get(key, pkt),))
                    elif self.power_cut and self.ledger_t.get(key, 0) < self.power_cut[0] and \
                            self.ledger_flushed(key):
                        self.emit("DATA.LOST_AFTER_POWER", pkt, t, "Read LBA 0x%X returned older data than the "
                                  "flushed write" % c.slba, keys=(("lba", c.slba),),
                                  rel=(self.ledger_src.get(key, pkt), self.power_cut[1]))
                    else:
                        self.emit("DATA.MISCOMPARE", pkt, t, "Read LBA 0x%X+%d B differs from the last write" %
                                  (c.slba, o), qual="stale" if pl[1] in self.old_crcs.get(key, ()) else "content",
                                  keys=(("lba", c.slba),), rel=(self.ledger_src.get(key, pkt),))
                    self.ledger.pop(key, None)

    def ledger_flushed(self, key):
        return self.ledger_t.get(key, 0) <= self.flush_t

    def dma(self, pkt, t, addr, nbytes, pl, direction):
        own = self.page_owner.get(addr & ~0xFFF)
        if own is not None:
            self.cmd_data(pkt, t, own, addr, pl or (b"", 0, nbytes), write=False)
            return
        if not pl:
            return
        # commands whose PRP list was only partly visible may own this page if they still owe bytes
        cands = [c for c in self.open.values() if c.xfer and c.opc == 0x02 and c.sqid != 0 and c.t_cqe is None and
                 (not c.pages_known or (c.list_addr is not None and len([x for x in c.pages if x]) < c.npages)) and
                 c.moved < c.xfer]
        if cands:
            page = addr & ~0xFFF
            nxt = [c for c in cands if (page - PAGE) in c.pages or (page + PAGE) in c.pages]
            pick = nxt[0] if len(nxt) == 1 else (cands[0] if len(cands) == 1 else None)
            if pick is not None:              # attribute only when unambiguous; otherwise stay silent
                pick.pages.append(page)
                self.page_owner[page] = pick
                self.cmd_data(pkt, t, pick, addr, pl, write=False)
            return
        if self.open:
            self.emit("NVME.DMA_OUTSIDE", pkt, t, "device MWr of %d B to 0x%X: no outstanding command owns this page "
                      "or still owes data" % (nbytes, addr))

    def on_cqe(self, pkt, t, cqid, slot, b):
        q = self.cq[cqid]
        dw0, dw1, dw2, dw3 = struct.unpack("<IIII", b)
        cid, phase, st = dw3 & 0xFFFF, (dw3 >> 16) & 1, dw3 >> 17
        sqid, sqhd = dw2 >> 16, dw2 & 0xFFFF
        sc, sct, dnr, more = st & 0xFF, (st >> 8) & 7, (st >> 14) & 1, (st >> 13) & 1
        k = (("cmd", sqid, cid),)
        if q.get("resync"):
            q["tail"], q["phase"], q["resync"] = slot, phase, False
        if slot != q["tail"] or phase != q["phase"]:
            self.emit("NVME.PHASE", pkt, t, "CQ%d entry slot %d phase %d, expected slot %d phase %d" %
                      (cqid, slot, phase, q["tail"], q["phase"]), keys=k)
            q["tail"] = slot
        q["tail"] += 1
        if q["tail"] >= q["size"]:
            q["tail"], q["phase"] = 0, q["phase"] ^ 1
        iv = q.get("iv", 0)
        if self.msi_first and t - self.msi_first[0] <= 10 * US:
            t0, p0, vec = self.msi_first
            self.msi_first = None
            self.emit("NVME.MSIX_BEFORE_CQE", p0, t0, "MSI-X sent %s before the CQE it announces (CQ%d)" %
                      (fmt_dt(t - t0), cqid), qual="msi_first", keys=(("cmd", sqid, cid),), rel=(pkt,))
        else:
            self.pending_msi.setdefault(iv, deque()).append((t, pkt, cqid))
        sqq = self.sq.get(sqid)
        if sqq is not None and sqq["cqid"] != cqid:
            self.emit("NVME.CQE_SQID", pkt, t, "CQE on CQ%d names SQ%d (bound to CQ%d)" % (cqid, sqid, sqq["cqid"]),
                      keys=k)
        elif sqq is None and sqid not in self.sq:
            self.emit("NVME.CQE_SQID", pkt, t, "CQE names SQ%d which does not exist" % sqid, keys=k)
        if sqq is not None and sqhd >= sqq["size"]:
            self.emit("NVME.SQHD", pkt, t, "SQHD %d >= SQ%d size %d" % (sqhd, sqid, sqq["size"]), keys=k)
        c = self.open.pop((sqid, cid), None)
        if c is not None:
            self.recount_active()
        if c is None or c.timed_out:
            prev = self.recent_done.get((sqid, cid))
            if prev is not None and t - prev.t_cqe < 100 * MS:
                self.emit("NVME.DUP_CQE", pkt, t, "second CQE for %s CID %d on SQ%d" %
                          (opc_name(sqid, prev.opc), cid, sqid), keys=k, rel=(prev.pkt_cqe,))
            elif c is not None and c.timed_out:
                self.emit("NVME.CQE_UNKNOWN_CID", pkt, t, "CQE for CID %d on SQ%d after the host gave up on it" %
                          (cid, sqid), qual="late", keys=k, rel=(c.pkt_sqe,))
            elif sqid == 0 and not (sct or sc) and (dw0 & 7) in (0, 1, 2, 6) and (dw0 >> 16) & 0xFF and \
                    (self.first_t is None or t - self.first_t < 60 * SEC or not self.aer_seen):
                # completion of an Asynchronous Event Request submitted before the capture started: DW0 carries
                # a valid AEN (type, info, log page) and the command was never in our table - not a stray CQE
                self.emit("NVME.AEN", pkt, t, "Asynchronous Event type %d info 0x%02X log page 0x%02X (request "
                          "predates the capture)" % (dw0 & 7, (dw0 >> 8) & 0xFF, (dw0 >> 16) & 0xFF),
                          qual="%d/0x%02X" % (dw0 & 7, (dw0 >> 8) & 0xFF), keys=k)
            else:
                self.emit("NVME.CQE_UNKNOWN_CID", pkt, t, "CQE for CID %d on SQ%d: no such outstanding command" %
                          (cid, sqid), keys=k)
            if sct or sc:
                self.emit("NVME.STATUS", pkt, t, "status SCT %d SC 0x%02X%s on unmatched CQE" %
                          (sct, sc, " DNR" if dnr else ""), qual="%d/0x%02X" % (sct, sc), keys=k)
            return
        c.pkt_cqe, c.t_cqe, c.status = pkt, t, (sct, sc, dnr)
        self.recent_done[(sqid, cid)] = c
        if len(self.recent_done) > 4096:
            for kk in list(self.recent_done)[:1024]:
                del self.recent_done[kk]
        name = opc_name(sqid, c.opc)
        t0 = c.t_db if c.t_db is not None else c.t_fetch
        lat = t - t0
        q.setdefault("posted_t", deque()).append((t, pkt))
        if c.t_last_data is not None:
            self.sample("cqe_after_data", t - c.t_last_data, pkt)
            self.sample("data_phase", c.t_last_data - c.t_sqe, c.pkt_last_data)
        cls = "admin" if sqid == 0 else ("read" if c.opc == 0x02 else "write" if c.opc == 0x01 else
                                          "flush" if c.opc == 0x00 else "other")
        if not (sqid == 0 and c.opc == 0x0C):
            series = "cmd_latency_" + cls + ("" if c.xfer <= 8192 else "_big")
            self.sample(series, lat, pkt)
            if c.qd <= 8:
                self.sample(series + "_lowqd", lat, pkt)
        if sct or sc:
            self.emit("NVME.STATUS", pkt, t, "%s CID %d SQ%d completed with SCT %d SC 0x%02X%s%s" %
                      (name, cid, sqid, sct, sc, " DNR" if dnr else "", " More" if more else ""),
                      qual="%d/0x%02X" % (sct, sc), keys=k, rel=(c.pkt_sqe,))
        elif c.xfer and c.opc in (0x01, 0x02) and sqid != 0 and c.pages_known and \
                (c.list_addr is None or len(c.pages) >= c.npages) and c.moved != c.xfer:
            self.emit("NVME.DATA_LEN", pkt, t, "%s CID %d moved %d B, expected %d B" % (name, cid, c.moved, c.xfer),
                      keys=k, rel=(c.pkt_sqe,))
        if sqid == 0 and c.opc in ADMIN_LONG_OPC and lat > 1 * SEC:
            self.emit("NVME.ADMIN_LONG", pkt, t, "%s took %s" % (name, fmt_dt(lat)), qual="0x%02X" % c.opc, keys=k,
                      rel=(c.pkt_sqe,))
        if (sqid == 0 and c.opc in (0x80, 0x84) and lat < 10 * MS) or \
                (sqid != 0 and c.opc == 0x0C and c.nlb * 512 >= 65536 and lat < 20 * US):
            self.emit("NVME.ADMIN_FAST", pkt, t, "%s of %d blocks completed in %s" % (name, c.nlb, fmt_dt(lat)),
                      qual="0x%02X" % c.opc, keys=k, rel=(c.pkt_sqe,))
        if sqid == 0 and c.opc == 0x0C and not (sct or sc):
            atype, info, lid = dw0 & 7, (dw0 >> 8) & 0xFF, (dw0 >> 16) & 0xFF
            self.emit("NVME.AEN", pkt, t, "Asynchronous Event type %d info 0x%02X log page 0x%02X" %
                      (atype, info, lid), qual="%d/0x%02X" % (atype, info), keys=k)
        self.token(pkt, "CQE|%d|%02X|%s" % (sct, sc, ("A%02X" % c.opc) if sqid == 0 else "IO"))
        if sqid == 0 and c.opc == 0x09 and (c.cdw10 & 0xFF) == 0x07 and not (sct or sc):
            req = ((c.cdw11 & 0xFFFF) + 1, (c.cdw11 >> 16) + 1)
            got = ((dw0 & 0xFFFF) + 1, (dw0 >> 16) + 1)
            if got[0] < req[0] or got[1] < req[1]:
                self.emit("NVME.QUEUES_REDUCED", pkt, t, "Number of Queues: requested %d SQ/%d CQ, granted %d/%d" %
                          (req + got), keys=k, rel=(c.pkt_sqe,))
        if sqid == 0 and not (sct or sc):
            if c.opc == 0x05:
                qid, size = c.cdw10 & 0xFFFF, (c.cdw10 >> 16) + 1
                self.cq[qid] = {"base": c.prp1, "size": size, "iv": c.cdw11 >> 16, "tail": 0, "phase": 1, "head": 0,
                                "resync": False}
                self.emit("NVME.QUEUE_CHANGE", pkt, t, "CQ%d created (%d entries)" % (qid, size), qual="create")
            elif c.opc == 0x01:
                qid, size = c.cdw10 & 0xFFFF, (c.cdw10 >> 16) + 1
                self.sq[qid] = {"base": c.prp1, "size": size, "cqid": c.cdw11 >> 16, "tail": 0, "head": 0, "db_t": {}}
            elif c.opc == 0x00:
                self.sq.pop(c.cdw10 & 0xFFFF, None)
            elif c.opc == 0x04:
                self.cq.pop(c.cdw10 & 0xFFFF, None)
            elif c.opc in (0x80, 0x84):
                for kk in list(self.ledger):
                    self.ledger[kk] = (self.ledger[kk] & ~0xFFFFFFFF) | self.zcrc(self.ledger[kk] >> 32)
        # ---- payload ledger updates
        if sqid != 0:
            self.io_done_since_en += 1
        if sqid != 0 and not (sct or sc):
            if c.opc == 0x01:
                rng = range(c.slba * 512, (c.slba + c.nlb) * 512)
                if c.pages_known and len(c.wchunks) * 256 >= c.xfer - 256 * len(c.pages):
                    for key, v in c.wchunks.items():
                        old = self.ledger.get(key)
                        if old is not None:
                            self.old_crcs.setdefault(key, set()).add(old & 0xFFFFFFFF)
                        self.ledger[key] = v
                        self.ledger_src[key] = c.pkt_sqe
                        self.ledger_t[key] = t
                else:
                    for key in range(rng.start, rng.stop, 256):
                        self.ledger.pop(key, None)
            elif c.opc == 0x00:
                self.flush_t = t
            elif c.opc in (0x08,):
                for key in range(c.slba * 512, (c.slba + c.nlb) * 512, 256):
                    self.ledger[key] = self.zcrc(256) | (256 << 32)
                    self.ledger_src[key] = c.pkt_sqe
            elif c.opc == 0x09 and c.cdw11 & 0x4:
                for s, n in c.wchunks.get("dsm", ()):
                    for key in range(s * 512, (s + n) * 512, 256):
                        if key in self.ledger:
                            self.ledger[key] = self.zcrc(256) | (256 << 32)
                            self.ledger_src[key] = c.pkt_sqe
        for p in c.pages:
            if p is not None and self.page_owner.get(p) is c:
                pass                                   # keep ownership briefly for late-data detection
        self.recent_pages_gc(t)

    def recent_pages_gc(self, t):
        if len(self.page_owner) < 20000:
            return
        for p, c in list(self.page_owner.items()):
            if c.t_cqe is not None and t - c.t_cqe > self.LATE_DATA_PS:
                del self.page_owner[p]

    # ------------------------------------------------------------------ end of capture
    def finish(self):
        t = self.last_t
        for c in self.open.values():
            if c.timed_out or (c.sqid == 0 and c.opc == 0x0C):
                continue
            age = t - (c.t_db if c.t_db is not None else c.t_fetch)
            limit = self.ADMIN_TIMEOUT_PS if c.sqid == 0 else self.IO_TIMEOUT_PS
            if age > limit:
                self.emit("NVME.CMD_TIMEOUT", c.pkt_sqe, c.t_sqe, "%s CID %d on SQ%d without completion for %s "
                          "(capture end)" % (opc_name(c.sqid, c.opc), c.cid, c.sqid, fmt_dt(age)), qual="eof",
                          keys=(("cmd", c.sqid, c.cid),))
