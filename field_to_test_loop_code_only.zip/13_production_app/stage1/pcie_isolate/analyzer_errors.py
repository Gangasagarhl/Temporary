"""The analyzer's own error catalogue, mapped to this analyser's rules.

The Teledyne LeCroy PCIe Protocol Analysis software checks every recorded packet against a fixed list of error
types and lists them in Reports > Error Summary (72 types in version 13.x; the same names are returned by the
automation API ITrace::AnalyzerErrors, codes 0x01..0x8A).  A customer compares that list with what this analyser
reports, so every type here names:

  rules    the rule ids of this analyser that cover the type (several when the evidence can take several forms)
  how      where the evidence can come from in a 113-column export:
             column     an "Errors" column, when the export was made with it (Export dialog > columns > Errors)
             annotation a field value the analyzer marks, for example "0x1F00BAD1 (Bad)" in LCRC
             event      a Link Event row whose text names the error
             type       the TLP Type / DLLP Type / Ord.Set Type cell itself names the error ("Invalid Packet")
             undecoded  the packet is written without a packet number and only with the fields that decoded
             field      this analyser checks the exported field values itself (independent of the analyzer)
             state      this analyser rebuilds state (credits, training phases) and checks it
  meaning  what the error is, in plain words
  spec     where the rule comes from (PCI Express Base Specification section; SMBus specification)
  aliases  other spellings the analyzer uses in reports, link-event text and the automation API

What a 113-column export can and cannot carry
  * Symbol-level errors (invalid code, disparity, idle data, skew, delimiter, alignment, start lane) are decided
    per lane by the analyzer hardware.  The export has no symbol columns: such a packet appears as a row with no
    packet number and no type (see "undecoded"), as Link Event text, or in the "Errors" column if that column was
    exported.  Without the Errors column the export does not say WHICH symbol error it was, so this analyser
    reports the row as PHY.INVALID_PACKET with the candidate names, and the comparison with the analyzer's error
    summary names the missing column.
  * Header-level errors (TC, Attr, AT, Length, byte enables, 4 KB crossing, 64-bit format, register alignment,
    message code, flow-control credits, training-set fields) are recomputed here from the exported fields, so they
    are found even without the Errors column.
"""
import csv
import re

# name, analyzer code, rules, family, how, meaning, spec, aliases
_T = [
    # ---------------------------------------------------------------- physical layer: symbols, framing, ordered sets
    ("Invalid Code", 0x01, ("PHY.INVALID_CODE", "PHY.SYMBOL_ERR"), "physical", ("column", "event", "undecoded"),
     "A received symbol is not a valid 8b/10b code word (2.5 and 5 GT/s), or a 128b/130b block could not be decoded.",
     "PCIe Base 4.2.1 (8b/10b: a code violation is a Receiver Error), 4.2.2 (128b/130b decoding)",
     ("Invalid 10b Code", "Invalid 10b", "Invalid Symbol", "Symbol Error", "10b Error", "Code Violation", "ErrorSymbol")),
    ("Running Disparity Error", 0x02, ("PHY.DISPARITY", "PHY.SYMBOL_ERR"), "physical", ("column", "event", "undecoded"),
     "A valid 10-bit code arrived with the wrong running disparity: a bit error a few symbols earlier is the usual cause.",
     "PCIe Base 4.2.1.1 and 4.2.1.3 (running disparity rules; a disparity error is a Receiver Error)",
     ("Running Disparity", "Disparity Error", "Disparity", "ErrorDisparity")),
    ("Skip Late", 0x03, ("PHY.SKIP_LATE", "PHY.SKP_OS"), "physical", ("column", "event", "undecoded"),
     "A SKP ordered set (clock compensation) arrived later than the schedule allows: every 1180 to 1538 symbol times "
     "at 2.5 and 5 GT/s, every 370 to 375 blocks at 8 GT/s and above.",
     "PCIe Base 4.2.7 (SKP ordered set scheduling, clock tolerance compensation)",
     ("Skip Error", "SKP Late", "SKP OS Interval", "Skip", "IdleErrorSkip", "SKP interval violation")),
    ("Idle Data Error (not D0.0)", 0x04, ("PHY.IDLE_DATA",), "physical", ("column", "event", "undecoded"),
     "During Logical Idle the lanes must carry the D0.0 symbol (8b/10b) or the IDL token's zero bytes (128b/130b); "
     "something else was received.",
     "PCIe Base 4.2.4.7 (Logical Idle), 4.2.2.3.5 (IDL framing token)",
     ("Idle Data Error", "Idle Error", "Idle Data", "Logical Idle Error", "IdleErrorData")),
    ("Unexpected K/D Code", 0x05, ("PHY.KD_CODE", "PHY.SYMBOL_ERR"), "physical", ("column", "event", "undecoded"),
     "A control (K) symbol arrived where a data (D) symbol was expected, or the reverse.",
     "PCIe Base 4.2.1.1 (symbol encoding: special K symbols only in framing and ordered sets)",
     ("Unexpected K", "K/D Code", "Wrong Symbol", "ErrorWrongSymbol")),
    ("Bad Packet Length", 0x06, ("PHY.PKT_LENGTH",), "physical", ("column", "event", "annotation", "undecoded"),
     "The packet on the wire is longer or shorter than its framing and header say (a TLP that is not a whole number "
     "of double words, a DLLP that is not 8 symbols, a TLP that overruns its Length).",
     "PCIe Base 4.2.2.3 (framing and application of symbols to lanes), 2.2.2 (TLP size), 3.5.2 (DLLP size)",
     ("Bad Length", "Packet Length", "Bad Packet length", "ErrorLength")),
    ("Ordered Set Format Error", 0x09, ("PHY.OS_FORMAT",), "physical", ("column", "event", "type", "undecoded"),
     "An ordered set (TS1, TS2, SKP, FTS, EIOS, EIEOS, SDS) whose symbols do not match the pattern the specification defines.",
     "PCIe Base 4.2.4.1 to 4.2.4.6 (ordered set definitions)",
     ("Ordered Set Format", "Invalid Ordered Set", "OS Format", "Malformed Ordered Set")),
    ("Delimiter Error", 0x0A, ("PHY.DELIMITER",), "physical", ("column", "event", "undecoded"),
     "A packet's start or end symbol (STP, SDP, END, EDB) or framing token is missing, wrong or misplaced.",
     "PCIe Base 4.2.2.3 (8b/10b framing symbols), 4.2.2.3.1 to 4.2.2.3.5 (128b/130b framing tokens)",
     ("Delimiter", "Framing Error", "Framing", "STP expected", "END expected", "ErrorDelimiter")),
    ("Alignment Error", 0x07, ("PHY.ALIGNMENT",), "physical", ("column", "event", "undecoded"),
     "A start symbol sits in a lane or symbol position the framing rules do not allow for this link width.",
     "PCIe Base 4.2.2.3 (STP and SDP placement by link width)",
     ("Alignment", "Lane Alignment", "ErrorAlignment", "ErrorAllignment")),
    ("TLP, DLLP or EDB start lane error", None, ("PHY.START_LANE",), "physical", ("column", "event", "undecoded"),
     "At 8 GT/s and above an STP, SDP or EDB token began in a lane that the framing rules do not allow for the link width "
     "(lane 0, or lanes 0, 4, 8, 12 on x8 and wider links).",
     "PCIe Base 4.2.2.3.3 (framing token placement rules, 128b/130b)",
     ("start lane", "Start Lane Error", "EDB start lane", "Start lane")),
    ("Skew Error", 0x08, ("PHY.LANE_SKEW",), "physical", ("column", "event", "undecoded"),
     "The same ordered set reached the lanes at times too far apart for the receiver to line them up (20 ns at 2.5 GT/s, "
     "8 ns at 5 GT/s, 6 ns at 8 GT/s, 5 ns at 16 and 32 GT/s).",
     "PCIe Base 4.2.4.9 (lane-to-lane de-skew), 4.3 (electrical skew budgets)",
     ("Skew", "Lane Skew", "Lane-to-Lane Skew")),
    ("Invalid Packet", 0x1C, ("PHY.INVALID_PACKET",), "physical", ("column", "type", "undecoded"),
     "Bytes framed as a packet that could not be decoded as a TLP, a DLLP or an ordered set.",
     "PCIe Base 4.2.2.3 (framing), 2.2 (TLP format), 3.5 (DLLP format)",
     ("Invalid Packets", "Invalid TLP", "Invalid DLLP", "Unknown Packet", "_PKT_INVALID")),
    ("Gen3 TLP: Bad Len CRC/Parity", 0x1F, ("PHY.G3_LEN_CRC",), "physical", ("column", "annotation", "undecoded"),
     "At 8 GT/s and above every TLP starts with an STP token that carries the TLP length, a 4-bit CRC and a parity bit; "
     "the CRC or the parity did not match.",
     "PCIe Base 4.2.2.3.1 (STP token: Frame CRC and Frame Parity)",
     ("Bad Len CRC", "Len CRC/Parity", "G3 Len Check", "Gen3 TLP", "MsgErrorG3LenCheck", "G3ErrorFraming")),
    ("Gen3 PMUX: Bad Len CRC/Parity", 0x27, ("PHY.PMUX_LEN_CRC",), "physical", ("column", "annotation"),
     "The same length CRC/parity check failed on a Protocol Multiplexing packet (a non-PCIe protocol carried on the link).",
     "PCIe Base Appendix G (Protocol Multiplexing), 4.2.2.3.1",
     ("PMUX Len", "PmuxErrorG3LenCheck", "PMUX Bad Len")),
    ("PMUX: Bad LCRC", 0x28, ("PHY.PMUX_LCRC",), "physical", ("column", "annotation"),
     "A Protocol Multiplexing packet whose link CRC does not match.",
     "PCIe Base Appendix G, 3.6.2 (LCRC)",
     ("PmuxErrorLCRC", "PMUX LCRC")),
    # ---------------------------------------------------------------- training sets and other ordered sets
    ("Training Sequence Format Error", 0x21, ("PHY.TS_FORMAT",), "physical", ("column", "annotation", "undecoded"),
     "A TS1 or TS2 ordered set with a wrong symbol: not COM first, identifier symbols not the TS1/TS2 pattern, wrong length.",
     "PCIe Base 4.2.4.1 (TS1 and TS2 ordered sets, symbol by symbol)",
     ("TS Format", "TS1 Format", "TS2 Format", "TsErrorFormat")),
    ("Training Sequence Parity Error", 0x22, ("PHY.TS_PARITY",), "physical", ("column", "annotation"),
     "At 8 GT/s and above TS1/TS2 symbol 7 carries an even-parity bit over the equalization fields of symbols 6 and 7; "
     "the parity did not match.",
     "PCIe Base 4.2.4.1 (TS1/TS2 at 8 GT/s and above: Parity bit)",
     ("TS Parity", "Parity Error", "TsErrorParity")),
    ("Training Sequence Cursor Error", None, ("PHY.TS_CURSOR",), "physical", ("column", "annotation", "field"),
     "The equalization coefficients a TS1 requests (pre-cursor, cursor, post-cursor) break the coefficient rules: each "
     "is a 6-bit value, pre-cursor + cursor + post-cursor must equal the full swing FS, and cursor minus the two others "
     "must not fall below the low frequency value LF.",
     "PCIe Base 4.2.6.4.2 (Recovery.Equalization), 8.3.3.3 (transmitter equalization coefficient rules)",
     ("Cursor Error", "Cursor", "Coefficient Error")),
    ("Training Sequence Link Error", None, ("PHY.TS_LINK",), "physical", ("column", "annotation", "state"),
     "The Link Number symbol of a TS1/TS2 is not PAD where PAD is required, is not a legal value, or differs from the "
     "link number the two ports agreed in Configuration.",
     "PCIe Base 4.2.4.1 (symbol 1, Link Number), 4.2.6.3 (Configuration: link number negotiation)",
     ("TS Link", "Link Number Error", "Link Error")),
    ("Training Sequence Lane Error", None, ("PHY.TS_LANE",), "physical", ("column", "annotation", "field"),
     "The Lane Number symbol of a TS1/TS2 is not PAD where PAD is required, is outside 0 to 31, or does not match the lane "
     "it was received on.",
     "PCIe Base 4.2.4.1 (symbol 2, Lane Number), 4.2.6.3 (lane numbering)",
     ("TS Lane", "Lane Number Error", "Lane Error")),
    ("Training Sequence Data Rate Error", 0x38, ("PHY.TS_RATE",), "physical", ("column", "annotation", "field"),
     "The Data Rate Identifier symbol has reserved bits set, does not include 2.5 GT/s (which must always be set), or "
     "advertises rates the port cannot run.",
     "PCIe Base 4.2.4.1 (symbol 4, Data Rate Identifier: bit 1 for 2.5 GT/s must be set)",
     ("TS Data Error", "TS Data Rate", "Data Rate Error", "TSErrorDataRate", "TsErrorDataRate")),
    ("Training Sequence: Reserved Field not 0", 0x39, ("PHY.TS_RESERVED",), "physical", ("column", "annotation"),
     "A reserved bit of a TS1/TS2 symbol is set.",
     "PCIe Base 4.2.4.1 (reserved bits in training sets are 0b)",
     ("Training Sequence Reserved Field not 0", "TS Reserved", "TSErrorRsrvField", "TsErrorRsrvField")),
    ("Training Sequence Usage", 0x6D, ("PHY.TS_USAGE",), "physical", ("column", "state"),
     "A training set appears where the link state machine does not allow it: a TS2 before any TS1 of the same training, "
     "training sets after the SDS that ends training at 8 GT/s and above.",
     "PCIe Base 4.2.6 (LTSSM: which ordered sets each state sends)",
     ("TS Usage", "Training Sequence Usage Error")),
    ("Training Sequence Training Control", 0x6E, ("PHY.TS_CONTROL",), "physical", ("column", "annotation", "field"),
     "The Training Control symbol (Hot Reset, Disable Link, Loopback, Disable Scrambling, Compliance Receive) has a value "
     "that is illegal for the state or speed: Disable Scrambling at 8 GT/s and above, several exclusive bits set at once.",
     "PCIe Base 4.2.4.1 (symbol 5, Training Control), 4.2.2.1 (scrambling cannot be disabled at 8 GT/s and above)",
     ("TS Training Control", "Training Control", "Training Control Error")),
    ("Training Sequence Incorrect EQ Phase", 0x7F, ("PHY.TS_EQ_PHASE",), "physical", ("column", "annotation", "state"),
     "The Equalization Control (EC) field of a TS1 names a phase that is not allowed at this point: a phase other than 0 "
     "while the link runs below 8 GT/s, or phases out of their order 0, 1, 2, 3.",
     "PCIe Base 4.2.6.4.2 (Recovery.Equalization phases), 4.2.4.1 (symbol 6, Equalization Control)",
     ("Incorrect EQ Phase", "EQ Phase", "Incorrect Eq Phase error", "Wrong EQ Phase")),
    ("Fast Training Sequence COM error", 0x3A, ("PHY.FTS_COM",), "physical", ("column", "annotation"),
     "An FTS ordered set that does not start with the COM symbol (K28.5).",
     "PCIe Base 4.2.4.5 (FTS ordered set)",
     ("FTS COM", "FTS COM is different", "FTS COM error")),
    ("Fast Training Sequence Symbols error", 0x3B, ("PHY.FTS_SYMBOL",), "physical", ("column", "annotation"),
     "An FTS ordered set whose symbols are not K28.1.",
     "PCIe Base 4.2.4.5 (FTS ordered set)",
     ("FTS Symbol", "FTS Symbols", "FTS Symbols error")),
    ("Control SKP Transmitter Margining CRC error", 0x40, ("PHY.CSKP_MARGIN_CRC",), "physical", ("column", "annotation"),
     "At 16 GT/s and above the Control SKP ordered set carries lane-margining command and status bits protected by a CRC; "
     "the CRC failed.",
     "PCIe Base 4.2.7.3 (Control SKP ordered set), 4.2.13 (lane margining at the receiver)",
     ("Margining CRC", "Transmitter Margining CRC", "Control SKP CRC")),
    ("Control SKP Transmitter Margining Parity error", 0x41, ("PHY.CSKP_MARGIN_PARITY",), "physical", ("column", "annotation"),
     "The parity bit over the margining fields of a Control SKP ordered set did not match.",
     "PCIe Base 4.2.7.3 (Control SKP ordered set)",
     ("Margining Parity", "Transmitter Margining Parity", "Control SKP Parity")),
    ("Control SKP is used at 8.0 GT/s Speed error", 0x7B, ("PHY.CSKP_AT_GEN3",), "physical", ("column", "state"),
     "A Control SKP ordered set, defined only for 16 GT/s and above, appeared while the link ran at 8 GT/s.",
     "PCIe Base 4.2.7.3 (Control SKP ordered set: 16 GT/s and higher data rates only)",
     ("Control SKP at 8", "Control Skip is present at Gen3", "Control SKP at 8.0 GT/s")),
    # ---------------------------------------------------------------- data link layer
    ("DLLP: Invalid Encoding", 0x0B, ("DLL.INVALID_ENCODING",), "data-link", ("column", "type", "undecoded"),
     "The DLLP Type byte is a reserved or undefined encoding, so the packet cannot be an Ack, Nak, flow-control or power DLLP.",
     "PCIe Base 3.5.2.1 (DLLP format, Table 3-3 DLLP type encodings)",
     ("DLLP Invalid Encoding", "Invalid DLLP Encoding", "InvalidEncoding")),
    ("DLLP: Bad CRC16", 0x0C, ("DLL.CRC16_BAD",), "data-link", ("column", "annotation"),
     "The 16-bit CRC at the end of a DLLP does not match its contents; the receiver discards the DLLP.",
     "PCIe Base 3.5.2.1 (DLLP CRC-16)",
     ("Bad CRC16", "Bad CRC 16", "CRC16", "DLLP Bad CRC", "BadCRC")),
    ("DLLP: Reserved Field not 0", 0x0D, ("DLL.RESERVED_FIELD",), "data-link", ("column", "annotation"),
     "A reserved field of a DLLP is not zero.",
     "PCIe Base 3.5.2.1 (reserved DLLP fields are 0b)",
     ("DLLP Reserved Field", "DLLP Reserved", "ErrorRsvdFld")),
    ("DLLP: FC Initialization Error", 0x0E, ("DLL.FC_INIT", "FC.INIT_VALUE"), "data-link", ("column", "state"),
     "The flow-control initialisation handshake broke its rules: InitFC2 before InitFC1 for that credit type, credit "
     "values that change between InitFC1 and InitFC2, a reserved scale value, or re-initialisation while the link was up.",
     "PCIe Base 3.4.1.1 (FC_INIT1 and FC_INIT2), 3.4.2 (scaled flow control)",
     ("FC Initialization", "FC Init Error", "Flow control initialization violation", "InitFC contains reserved", "FCError")),
    # ---------------------------------------------------------------- transaction layer
    ("TLP: Invalid Encoding", 0x0F, ("TLP.INVALID_ENCODING",), "transaction", ("column", "type", "undecoded"),
     "The Fmt/Type fields of the TLP header are a reserved combination, so the packet is not a request, completion or message.",
     "PCIe Base 2.2.1 (Fmt and Type field encodings, Table 2-3; reserved combinations are Malformed TLPs)",
     ("TLP Invalid Encoding", "Invalid TLP Encoding", "Reserved Fmt/Type")),
    ("TLP: Bad LCRC", 0x10, ("DLL.LCRC_BAD",), "data-link", ("column", "annotation"),
     "The 32-bit link CRC at the end of a TLP does not match; the receiver must Nak it and the sender replays.",
     "PCIe Base 3.6.2.2 (LCRC), 3.6.2.3 (Nak and replay)",
     ("Bad LCRC", "Bad LCRCs", "LCRC", "LCRC Error", "BadLCRC")),
    ("TLP: Bad ECRC", 0x11, ("TLP.ECRC_BAD",), "transaction", ("column", "annotation"),
     "The optional end-to-end CRC (present when TD = 1) does not match the header and data.",
     "PCIe Base 2.7.1 (ECRC rules)",
     ("Bad ECRC", "Bad ECRCs", "ECRC", "ECRC Error", "BadECRC")),
    ("TLP: Reserved Field not 0", 0x12, ("TLP.RESERVED_FIELD",), "transaction", ("column", "annotation"),
     "A reserved field of the TLP header is not zero.",
     "PCIe Base 2.2.1 (reserved header fields are 0b; receivers ignore them)",
     ("TLP Reserved Field", "TLP Reserved", "Reserved Field not 0")),
    ("TLP: Payload/Length Error", 0x13, ("TLP.LEN_MISMATCH",), "transaction", ("column", "annotation", "field"),
     "The number of data bytes in the packet does not match the Length field (or the TD/ECRC presence).",
     "PCIe Base 2.2.2 (Length field and data payload size rules), 2.3.1 (Malformed TLP)",
     ("Payload/Length", "Payload Length", "Payload Error", "ErrorPayload")),
    ("TLP: Length Error", 0x14, ("TLP.LENGTH_FIELD", "TLP.CFG_FORMAT"), "transaction", ("column", "annotation", "field"),
     "The Length field is illegal for the packet type: I/O and configuration requests must carry exactly one double word; "
     "other requests must respect their size limits.",
     "PCIe Base 2.2.7 (I/O and configuration requests: Length 1 DW), 2.2.2 (Length rules)",
     ("TLP: Length Error (not 1)", "Length Error", "Length Field", "ErrorLengthField", "Length Error (not 1)")),
    ("TLP: TC Error (not 0)", 0x15, ("TLP.TC_NONZERO",), "transaction", ("column", "annotation", "field"),
     "The Traffic Class is not 0 on a packet type that must use TC0 (configuration, I/O, most messages).",
     "PCIe Base 2.2.6.6 (TC field rules), 2.2.8 (message TC rules)",
     ("TC Error", "TC not 0", "TC Error (not 0)", "ErrorTCField")),
    ("TLP: Attr Error (not 0)", 0x16, ("TLP.ATTR",), "transaction", ("column", "annotation", "field"),
     "The Attribute bits (Relaxed Ordering, No Snoop, ID-based Ordering) are set on a packet type where they are reserved.",
     "PCIe Base 2.2.6.3 to 2.2.6.5 (attribute rules per packet type)",
     ("Attr Error", "Attribute Error", "Attr not 0", "Attr Error (not 0)", "ErrorAttrField")),
    ("TLP: AT Error (not 0)", 0x20, ("TLP.AT_SET",), "transaction", ("column", "annotation", "field"),
     "The Address Type field is not 00b (untranslated) on a packet where translated addresses are not allowed.",
     "PCIe Base 2.2.4.1 (AT field), 10.2 (Address Translation Services)",
     ("AT Error", "AT not 0", "AT Error (not 0)")),
    ("TLP: Byte Enables Violation", 0x17, ("TLP.BE",), "transaction", ("column", "annotation", "field"),
     "The First/Last DW Byte Enables break the rules (Last BE non-zero on a 1-DW request, non-contiguous enables, "
     "an all-zero First BE with data).",
     "PCIe Base 2.2.5 (First/Last DW Byte Enables rules)",
     ("Byte Enables", "Byte Enable Violation", "Byte Enables Violation", "ErrorByteEnables")),
    ("TLP: No Header Error", 0x29, ("TLP.NO_HEADER",), "transaction", ("column", "undecoded"),
     "A TLP framing too short to hold the 3- or 4-double-word header, so no header field can be read; the export shows "
     "only the LCRC and the data size.",
     "PCIe Base 2.2.1 (header sizes), 4.2.2.3.1 (STP token length)",
     ("No Header", "No Header Error", "does not contain TLP header", "TLP packet does not contain TLP header")),
    ("Memory TLP: Address/Length Crosses 4K", 0x18, ("TLP.4K",), "transaction", ("column", "annotation", "field"),
     "A memory request whose address and length together cross a 4 KB boundary.",
     "PCIe Base 2.2.7 (memory requests must not cross a 4-KB boundary)",
     ("Crosses 4K", "4K", "Address/Length Crosses 4K", "MemErrorAddrLength")),
    ("Mem64 TLP: Used Incorrectly", 0x19, ("TLP.ADDR_FMT",), "transaction", ("column", "annotation", "field"),
     "A 64-bit address format was used for an address below 4 GB (the 32-bit format is required there).",
     "PCIe Base 2.2.4.1 (for addresses below 4 GB requesters must use the 32-bit format)",
     ("Mem64", "64-bit format", "Mem64 Used Incorrectly", "MemErrorWrongType")),
    ("Cfg TLP: Register Error", 0x1A, ("TLP.CFG_REGISTER", "TLP.CFG_FORMAT"), "transaction", ("column", "annotation", "field"),
     "The register number of a configuration request is not double-word aligned or is outside the 4 KB configuration space.",
     "PCIe Base 2.2.7 (configuration requests: Register Number and Extended Register Number fields)",
     ("Register Error", "Cfg Register", "CfgErrorRegister")),
    ("Msg TLP: Unknown Message Code", 0x49, ("MSG.UNKNOWN_CODE", "MSG.OTHER"), "transaction", ("column", "annotation", "field"),
     "The Message Code is not one the specification defines (reserved codes are handled as Unsupported Requests).",
     "PCIe Base 2.2.8 (message codes, Tables 2-16 to 2-26)",
     ("Unknown Message Code", "Unknown Message", "Invalid message code", "Message Code Error")),
    ("Msg TLP: Invalid Function Number field", 0x26, ("MSG.FUNCTION_NUMBER",), "transaction", ("column", "annotation"),
     "The Function Number inside the message's Requester ID is not the value the message type requires.",
     "PCIe Base 2.2.8 (message request rules; per-message Requester ID rules)",
     ("Invalid Function Number", "Function Number field", "Function Number Error")),
    ("TLP: Prefix order error", None, ("TLP.PREFIX_ORDER",), "transaction", ("column", "annotation"),
     "TLP prefixes in the wrong order: every Local prefix must come before any End-End prefix.",
     "PCIe Base 2.2.10 (TLP prefix rules: Local prefixes precede End-End prefixes)",
     ("Prefix order", "Prefix Order Error", "IDEErrorPrefixOrder", "Prefix Error")),
    # ---------------------------------------------------------------- flow control
    ("FC: Invalid Advertisement", 0x1D, ("FC.INVALID_ADVERTISEMENT", "FC.INIT_VALUE"), "data-link", ("column", "annotation", "state"),
     "A flow-control DLLP advertises credits the rules forbid: an initial allocation above 128 header or 2048 data "
     "credits without scaling (the counters are 8 and 12 bits wide), finite credits after infinite credits were "
     "advertised at initialisation, or a reserved scale.",
     "PCIe Base 2.6.1 (flow-control credit limits), 3.4.1 (initialisation), 3.4.2 (scaled flow control)",
     ("Invalid Advertisement", "FC Advertisement", "Credit Advertisement")),
    ("FC: Insufficient Credits", 0x1E, ("FC.INSUFFICIENT_CREDITS",), "data-link", ("column", "state"),
     "A TLP was sent although the receiver had not granted enough credits for its header or data.",
     "PCIe Base 3.4.1 (a TLP may be sent only while CREDITS_CONSUMED plus the credits it needs stays within CREDIT_LIMIT)",
     ("Insufficient Credits", "Credit Violation", "No Credits")),
    # ---------------------------------------------------------------- SMBus sideband (NVMe-MI / management)
    ("SMBUS: Too Long Packet", 0x2A, ("SMBUS.TOO_LONG",), "sideband", ("column", "annotation"),
     "An SMBus packet longer than the protocol allows.",
     "SMBus 3.x specification 6.5 (block transfer limits)",
     ("SmbusTooLongPktError", "SMBus Too Long")),
    ("SMBUS: More Than One Restart", 0x2B, ("SMBUS.MULTI_RESTART",), "sideband", ("column", "annotation"),
     "More than one repeated START inside one SMBus transaction.",
     "SMBus 3.x specification 6.5 (bus protocols: one repeated START per read transaction)",
     ("SmbusMultipleRestartError", "Multiple Restart")),
    ("SMBUS: Bad Restart", 0x2C, ("SMBUS.BAD_RESTART",), "sideband", ("column", "annotation"),
     "A repeated START at a position the protocol does not allow.",
     "SMBus 3.x specification 6.5",
     ("SmbusBadRestartError", "Bad Restart")),
    ("SMBUS: No Stop", 0x2D, ("SMBUS.NO_STOP",), "sideband", ("column", "annotation"),
     "An SMBus transaction without a STOP condition.",
     "SMBus 3.x specification 4.1 (START and STOP conditions)",
     ("SmbusNoStopError", "No Stop")),
    ("SMBUS: ACK timeout", 0x2E, ("SMBUS.ACK_TIMEOUT",), "sideband", ("column", "annotation"),
     "No acknowledge within the clock-low timeout.",
     "SMBus 3.x specification 4.2.2 (timeouts: 25 to 35 ms clock low)",
     ("SmbusAckTimeoutError", "ACK timeout")),
    ("SMBUS: Too Short Packet", 0x3D, ("SMBUS.TOO_SHORT",), "sideband", ("column", "annotation"),
     "An SMBus packet shorter than its protocol needs.",
     "SMBus 3.x specification 6.5",
     ("SmbusTooShortPktError", "SMBus Too Short")),
    ("SMBUS: Unexpected NACK", 0x30, ("SMBUS.UNEXPECTED_NACK",), "sideband", ("column", "annotation"),
     "A byte that should have been acknowledged was not.",
     "SMBus 3.x specification 4.2 (acknowledge rules)",
     ("A byte should be ACKed", "Unexpected NACK")),
    ("SMBUS: Unexpected ACK", 0x31, ("SMBUS.UNEXPECTED_ACK",), "sideband", ("column", "annotation"),
     "A byte that should have been answered with NACK (the last byte of a read) was acknowledged.",
     "SMBus 3.x specification 4.2 (acknowledge rules)",
     ("A byte should be NACKed", "Unexpected ACK")),
    ("SMBUS: 10-bit Addressing", 0x32, ("SMBUS.ADDR_10BIT",), "sideband", ("column", "annotation", "field"),
     "The slave address starts with 1111 0xx: the 10-bit addressing form, which SMBus devices here do not use.",
     "SMBus 3.x specification Appendix C (reserved addresses: 1111 0XX is 10-bit addressing)",
     ("Slave address contains 1111 0XX", "10-bit Addressing")),
    ("SMBUS: Bad Addressing", 0x33, ("SMBUS.BAD_ADDRESS",), "sideband", ("column", "annotation", "field"),
     "The slave address is a reserved value (0000 xxx or 1111 1xx).",
     "SMBus 3.x specification Appendix C (reserved slave addresses)",
     ("Slave address contains reserved value", "Bad Addressing", "Reserved Address")),
    ("SMBUS: R/W error", 0x34, ("SMBUS.RW_ERROR",), "sideband", ("column", "annotation"),
     "A transaction with a repeated START that does not follow the Write, then Restart, then Read structure.",
     "SMBus 3.x specification 6.5.5 (read word / block read protocols)",
     ("R/W error", "restart does not require", "RW error")),
    ("SMBUS: Bad PEC", 0x35, ("SMBUS.BAD_PEC",), "sideband", ("column", "annotation", "field"),
     "The Packet Error Code (CRC-8) does not match the bytes of the transaction.",
     "SMBus 3.x specification 5.4 (Packet Error Checking)",
     ("Packet error checking", "Bad PEC", "PEC Error")),
    ("SMBUS: N/A Byte Count", 0x36, ("SMBUS.BYTECOUNT_RANGE",), "sideband", ("column", "annotation", "field"),
     "The byte count of a block transfer is zero or more than 32.",
     "SMBus 2.0/3.x specification 6.5.7 (block write/read: 1 to 32 bytes; 3.x allows up to 255 with the larger block size)",
     ("Byte Count is not in allowed range", "N/A Byte Count", "Byte Count Range")),
    ("SMBUS: Bad Byte Count", 0x37, ("SMBUS.BYTECOUNT_MISMATCH",), "sideband", ("column", "annotation"),
     "The byte count does not match the number of bytes that followed.",
     "SMBus 3.x specification 6.5.7 (block transfers)",
     ("Byte Count does not match", "Bad Byte Count")),
    ("SMBUS ARP: Bad Command Code", 0x3C, ("SMBUS.ARP_COMMAND",), "sideband", ("column", "annotation", "field"),
     "An Address Resolution Protocol packet with a command code that is not defined.",
     "SMBus 3.x specification 6.6 (ARP command codes)",
     ("Reserved command code", "ARP Bad Command", "ARP Command Code")),
    ("SMBUS ARP: Too Short Packet", 0x3D, ("SMBUS.ARP_TOO_SHORT",), "sideband", ("column", "annotation"),
     "An ARP packet shorter than its command needs.",
     "SMBus 3.x specification 6.6",
     ("ARP Too Short",)),
    ("SMBUS ARP: Reserved code used", 0x3E, ("SMBUS.ARP_RESERVED", "SMBUS.ARP_COMMAND"), "sideband", ("column", "annotation", "field"),
     "An ARP packet uses a reserved code or value.",
     "SMBus 3.x specification 6.6",
     ("Reserved code", "ARP Reserved")),
    ("SMBus ARP: Incorrect bit0", 0x3F, ("SMBUS.ARP_BIT0",), "sideband", ("column", "annotation", "field"),
     "The address assigned or carried by an ARP packet has its lowest bit set; that bit must be 0.",
     "SMBus 3.x specification 6.6.3 (Assign Address: bit 0 of the address byte is 0)",
     ("Incorrect las bit in address", "Incorrect last bit in address", "ARP bit0", "Incorrect bit0")),
    ("SMBus BMC: Incorrect Length", 0x2F, ("SMBUS.BMC_LENGTH",), "sideband", ("column", "annotation"),
     "A BMC (baseboard management controller) SMBus packet with a zero or wrong length.",
     "IPMI 2.0 specification (SMBus system interface packet format)",
     ("Zero length of the packet", "BMC Incorrect Length", "BMC Length")),
]

# names the automation API uses that are not in the 72-entry report but map to rules that already exist
_EXTRA = [
    ("Msg TLP: Invalid Routing", 0x1B, ("MSG.ROUTING",), "transaction", ("column", "field"),
     "A message whose routing field does not match the routing its code requires.",
     "PCIe Base 2.2.8 (message routing rules)", ("Invalid Routing", "MsgErrorRouting")),
    ("End of Bad Packet", None, ("DLL.NULLIFIED",), "data-link", ("column", "annotation"),
     "A TLP ended with EDB (nullified).", "PCIe Base 3.6.2.1 (nullified TLPs)", ("EDB", "ErrorEndBad", "Nullified")),
]

FIELDS = ("name", "code", "rules", "family", "how", "meaning", "spec", "aliases")
CATALOGUE = [dict(zip(FIELDS, row)) for row in _T]
EXTRA = [dict(zip(FIELDS, row)) for row in _EXTRA]
BY_NAME = {e["name"]: e for e in CATALOGUE}
GENERIC_RULE = "CI.ANALYZER_FLAG"      # an analyzer error this analyser has no rule of its own for


def _norm(s):
    return re.sub(r"[^a-z0-9]+", " ", s.lower()).strip()


_INDEX = []     # (normalised name, entry), longest first so "DLLP: Bad CRC16" wins over "CRC16"
for _e in CATALOGUE + EXTRA:
    for _n in (_e["name"],) + tuple(_e["aliases"]):
        _INDEX.append((_norm(_n), _e))
_INDEX.sort(key=lambda x: -len(x[0]))
_EXACT = {n: e for n, e in _INDEX}


def by_name(text):
    """The catalogue entry an analyzer error text names, or None.
    Exact (normalised) match first, then the longest alias contained in the text ("Invalid 10b Code on channel
    Upstream (11)", "Running Disparity Error (Lane 2)")."""
    if not text:
        return None
    n = _norm(text)
    e = _EXACT.get(n)
    if e:
        return e
    for alias, e in _INDEX:
        if len(alias) >= 4 and (" " + alias + " ") in (" " + n + " "):
            return e
    return None


def find_all(text):
    """Every catalogue entry named in a text, in order of appearance, each name counted once: the Errors column may
    hold several names in one cell ("Running Disparity Error (Lane 3), Idle Data Error (not D0.0)")."""
    if not text:
        return []
    n = " " + _norm(text) + " "
    hits = []
    for alias, e in _INDEX:                      # longest alias first, so "TLP: Bad LCRC" is taken before "LCRC"
        if len(alias) < 4:
            continue
        key = " " + alias + " "
        i = n.find(key)
        while i >= 0:
            hits.append((i, e))
            n = n[:i] + " " * len(key) + n[i + len(key):]
            i = n.find(key)
    out = []
    for _, e in sorted(hits, key=lambda x: x[0]):
        if e not in out:
            out.append(e)
    return out


def rules_for(text):
    e = by_name(text)
    return e["rules"] if e else (GENERIC_RULE,)


def all_rules():
    s = set()
    for e in CATALOGUE + EXTRA:
        s.update(e["rules"])
    s.add(GENERIC_RULE)
    return s


# ---------------------------------------------------------------- the analyzer's Error Summary file
SUMMARY_HEADER = ("type", "upstream", "downstream", "sideband", "total")


def _read_text(path):
    """The file's text: UTF-8 (with or without BOM) or UTF-16 as Excel's "Unicode text" writes it."""
    with open(path, "rb") as f:
        raw = f.read()
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return raw.decode("utf-16", errors="replace")
    return raw.decode("utf-8-sig", errors="replace")


_NUM4 = re.compile(r"""^(.+?)[,;\t]\s*"?([\d,. ]+)"?\s*[,;\t]\s*"?([\d,. ]+)"?\s*[,;\t]\s*"?([\d,. ]+)"?\s*[,;\t]\s*"?([\d,. ]+)"?\s*$""")
_CHAN = re.compile(r"^(.*?)\s+on channel (Upstream|Downstream|Sideband) \((\d+)\)")


def _count(s):
    s = s.strip().strip('"').replace(",", "").replace(" ", "").replace(".", "")
    return int(s) if s.isdigit() else None


def is_error_summary(path):
    """True when the file is the analyzer's Reports > Error Summary export (CSV, any delimiter, any Excel re-save)
    or the automation API's text form ("Bad LCRCs on channel Upstream (12):")."""
    try:
        head = _read_text(path).splitlines()[:8]
    except OSError:
        return False
    first = re.sub(r"[^a-z]", "", (head[0] if head else "").lower())
    if "upstream" in first and "downstream" in first and ("type" in first or "error" in first):
        return True
    hits = 0
    for h in head:
        m = _NUM4.match(h.strip())
        if (m and all(_count(x) is not None for x in m.groups()[1:])) or _CHAN.search(h):
            hits += 1
    return hits >= 2


def load_error_summary(path):
    """Rows of the analyzer's error summary: [{name, upstream, downstream, sideband, total, entry}]."""
    out = {}
    order = []
    text = _read_text(path)
    lines = [l for l in text.splitlines() if l.strip()]
    head = lines[0] if lines else ""
    delim = "\t" if "\t" in head else (";" if head.count(";") >= head.count(",") and ";" in head else ",")
    for line in lines:
        s = line.strip()
        m = _CHAN.match(s)
        if m:
            name, ch, n = m.group(1).strip(), m.group(2).lower(), int(m.group(3))
            r = out.setdefault(name, {"name": name, "upstream": 0, "downstream": 0, "sideband": 0, "total": 0})
            if name not in order:
                order.append(name)
            r[ch] += n
            r["total"] += n
            continue
        cells = next(csv.reader([s], delimiter=delim))
        if len(cells) < 5:
            continue
        nums = [_count(c) for c in cells[-4:]]
        if any(n is None for n in nums):
            continue                                     # the header line, or a line without four counts
        # a name that itself holds the delimiter ("TLP, DLLP or EDB start lane error") spans several cells
        name = (delim if delim != "," else ",").join(cells[:-4]).strip().strip('"').strip()
        name = re.sub(r"\s*,\s*", ", ", name) if delim == "," else name
        out[name] = {"name": name, "upstream": nums[0], "downstream": nums[1], "sideband": nums[2], "total": nums[3]}
        if name not in order:
            order.append(name)
    rows = [out[n] for n in order]
    for r in rows:
        e = by_name(r["name"])
        r["entry"] = e["name"] if e else None
        r["rules"] = list(e["rules"]) if e else []
    return rows


# ---------------------------------------------------------------- what this run could and did see
HOW_WORDS = {
    "column": "the analyzer's Errors column (only when the export was made with it)",
    "annotation": "a field value the analyzer marked, for example '(Bad)'",
    "event": "a Link Event row that names the error",
    "type": "a packet type cell that names the error",
    "undecoded": "a packet written without a number or type (only the fields that decoded)",
    "field": "this analyser's own check of the exported field values",
    "state": "this analyser's own tracking across packets (credits, training phases, link state)",
}


def coverage(rule_counts, errors_column_present, undecoded_counts=None):
    """One row per analyzer error type: how it could be seen in this export and how many were found.
    rule_counts: {rule: {"total": n, "Upstream": a, "Downstream": b}}."""
    rows = []
    for e in CATALOGUE:
        tot = up = dn = 0
        for r in e["rules"]:
            c = rule_counts.get(r) or {}
            tot += c.get("total", 0)
            up += c.get("Upstream", 0)
            dn += c.get("Downstream", 0)
        hows = list(e["how"])
        independent = [h for h in hows if h in ("field", "state", "annotation", "event", "type", "undecoded")]
        if errors_column_present:
            detectable, why = True, "the export has the Errors column, so the analyzer's own flag is read directly"
        elif independent:
            detectable = True
            why = "found from " + "; ".join(HOW_WORDS[h] for h in independent[:3])
            if "field" not in hows and "state" not in hows:
                why += ". The export has no Errors column, so a packet the analyzer flagged for exactly this reason " \
                       "appears here only through those forms; the name of the error itself is not in the file"
        else:
            detectable, why = False, "only the analyzer's Errors column carries this error; the export was made without it"
        rows.append({"name": e["name"], "code": e["code"], "rules": list(e["rules"]), "family": e["family"],
                     "how": hows, "found": tot, "upstream": up, "downstream": dn, "detectable": detectable, "why": why,
                     "meaning": e["meaning"], "spec": e["spec"]})
    return rows
