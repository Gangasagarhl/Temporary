"""Test coverage of the error catalogue: which of the rules and of the 72 analyzer error kinds have real evidence.

Read by the application's "Test coverage" page (GET /api/coverage) and by the CLI (`coverage` subcommand).
Nothing here decides anything about a trace: it counts what exists on disk and says where it found it.

Evidence for a rule, strongest first:
  1. "seen on packets in a run": the rule produced at least one finding in a stored run of the application
     (runs/**/findings.pkl) or in the kept run of the 485-error trace (stage1/runs/eval_485_<date>/rule_counts.json);
  2. "unit test only": a test in stage1/tests names the rule (the test's own source is scanned, so the test
     author's statement of what it exercises is what counts);
  3. "no evidence yet": neither.  The rule still has its specification citation (test_rule_sources checks that),
     but nothing has ever made it fire.
Evidence for an analyzer error kind is the best evidence of any rule it maps to; every kind's name is also tested
through the Errors column (test_every_one_of_the_72_names_fires_its_rule), which this module reports separately.
"""
import ast
import glob
import json
import os
import pickle
import re
import time

from . import analyzer_errors as A
from . import rules as R

RULE_RX = re.compile(r"\b(PHY|NVME|TLP|SMBUS|REG|CFG|DLL|TXN|CI|H|LINK|PM|DATA|DB|FC|MSG|S)\.[A-Z0-9_]+\b")
STATUS_SEEN, STATUS_TEST, STATUS_NONE = "seen on packets in a run", "unit test only", "no evidence yet"
KIND_NAME_ONLY = "Errors-column name only"
FAMILY_WORDS = {"PHY": "Physical layer", "DLL": "Data link layer", "FC": "Flow control", "TLP": "Packet format",
                "TXN": "Transactions", "CFG": "Configuration space", "MSG": "Messages", "PM": "Power management",
                "LINK": "Link state", "NVME": "NVMe commands and queues", "REG": "NVMe registers", "DB": "Doorbells",
                "DATA": "Data integrity", "SMBUS": "SMBus sideband", "CI": "Capture integrity",
                "H": "Outside evidence (host log, lab)", "S": "Statistics"}
BY_DESIGN_NO_WIRE = ("H",)       # rules that need a host log or a lab result: a capture alone cannot exercise them


def family_word(rule_id):
    p = rule_id.split(".")[0]
    return FAMILY_WORDS.get(p, p)


def tests_naming_rules(tests_dir):
    """{rule: [{"file": f, "test": name}]}: every rule id named in the source of a test function; a rule named
    only at module level (a helper, a table) is attributed to the file itself."""
    out = {}
    for path in sorted(glob.glob(os.path.join(tests_dir, "test_*.py"))):
        src = open(path, encoding="utf-8").read()
        fname = os.path.basename(path)
        seen_in_fn = set()
        try:
            tree = ast.parse(src)
        except SyntaxError:
            tree = None
        lines = src.splitlines()
        if tree is not None:
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef) and node.name.startswith("test_"):
                    seg = "\n".join(lines[node.lineno - 1:node.end_lineno])     # whole lines: a trailing comment counts
                    for m in RULE_RX.finditer(seg):
                        out.setdefault(m.group(0), []).append({"file": fname, "test": node.name})
                        seen_in_fn.add((fname, m.group(0)))
        for m in RULE_RX.finditer(src):
            if (fname, m.group(0)) not in seen_in_fn:
                out.setdefault(m.group(0), []).append({"file": fname, "test": "(module level)"})
                seen_in_fn.add((fname, m.group(0)))
    for r, lst in out.items():                      # one entry per (file, test)
        uniq, keep = set(), []
        for e in lst:
            k = (e["file"], e["test"])
            if k not in uniq:
                uniq.add(k)
                keep.append(e)
        out[r] = keep
    return out


def _run_label(run_dir, app_root):
    label = os.path.relpath(run_dir, app_root)
    trace = ""
    p = os.path.join(run_dir, "run.json")
    if os.path.exists(p):
        try:
            r = json.load(open(p))
            for k in ("csv_path", "csv", "input", "source", "file"):
                if r.get(k):
                    trace = os.path.basename(str(r[k]))
                    break
        except (ValueError, OSError):
            pass
    return label, trace


def runs_evidence(app_root):
    """{rule: [{"run": label, "trace": csv name, "count": n}]} from every findings.pkl under <app_root>/runs."""
    out = {}
    n_runs = 0
    for p in sorted(glob.glob(os.path.join(app_root, "runs", "**", "findings.pkl"), recursive=True)):
        try:
            F = pickle.load(open(p, "rb"))
        except Exception:                                    # noqa: BLE001 - a half-written run is skipped, not fatal
            continue
        n_runs += 1
        label, trace = _run_label(os.path.dirname(p), app_root)
        counts = {}
        for f in F:
            try:
                counts[f[2]] = counts.get(f[2], 0) + 1
            except (IndexError, TypeError):
                continue
        for rule, n in counts.items():
            out.setdefault(rule, []).append({"run": label, "trace": trace, "count": n})
    return out, n_runs


def latest_kept(stage1_runs):
    """The newest kept evaluation folder stage1/runs/eval_485_<date>, or None."""
    dirs = sorted(glob.glob(os.path.join(stage1_runs, "eval_485_*")))
    return dirs[-1] if dirs else None


def kept_evaluation(folder):
    """The kept record of the 485-error trace run: per-rule counts, the scored evaluation, the un-grouped episodes."""
    if not folder:
        return None
    rc = json.load(open(os.path.join(folder, "rule_counts.json"))) if os.path.exists(os.path.join(folder, "rule_counts.json")) else {}
    ev = json.load(open(os.path.join(folder, "evaluation.json"))) if os.path.exists(os.path.join(folder, "evaluation.json")) else {}
    ng = json.load(open(os.path.join(folder, "not_grouped.json"))) if os.path.exists(os.path.join(folder, "not_grouped.json")) else []
    hyb = (ev.get("approaches") or {}).get("D_hybrid") or {}
    iso = ev.get("isolation") or {}
    planted = None
    if hyb:
        total = hyb.get("episodes_total", 0)
        planted = {
            "total": total,
            "measures": [
                {"measure": "detected by at least one finding", "count": hyb.get("episodes_detected", 0), "out_of": total},
                {"measure": "grouped into a defect", "count": iso.get("episodes_isolated", 0), "out_of": total},
                {"measure": "key packet inside the defect", "count": iso.get("episodes_with_key_rows_isolated", 0),
                 "out_of": hyb.get("episodes_with_key_rows_detected", 0)},
                {"measure": "first abnormal packet within 32 rows of the key row", "count": iso.get("first_abnormal_within_32_rows_of_key_row", 0), "out_of": total},
                {"measure": "catalogue card ranked first", "count": iso.get("card_top1", 0), "out_of": total},
                {"measure": "catalogue card in the top three", "count": iso.get("card_top3", 0), "out_of": total},
            ],
            "false_positive_findings": hyb.get("false_positive_findings", 0),
            "false_positive_rules": hyb.get("false_positive_rules", {}),
            "false_positive_incidents": len(iso.get("false_positive_incidents") or []),
            "incidents": iso.get("incidents", 0),
            # the isolation's own per-visibility counts: "grouped" = the episode is inside at least one defect
            "by_visibility": [{"visibility": k, "planted": v["total"], "grouped": v["detected"], "not_grouped": v["total"] - v["detected"],
                               "card_first": v.get("top1", 0), "card_top3": v.get("top3", 0)} for k, v in (iso.get("by_visibility") or {}).items()],
            "not_grouped": ng,
        }
    return {"folder": os.path.basename(folder), "trace": rc.get("trace", ""), "truth": rc.get("truth", ""), "command": rc.get("command", ""),
            "measured_at": rc.get("measured_at", ""), "seconds": rc.get("seconds"), "model_calls": rc.get("model_calls"),
            "n_findings": rc.get("n_findings"), "rule_counts": rc.get("rule_counts", {}), "planted": planted}


def build(app_root, stage1_dir=None):
    """Everything the Test coverage page shows, with where each number came from."""
    stage1_dir = stage1_dir or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    tests_dir = os.path.join(stage1_dir, "tests")
    t_runs, n_runs = runs_evidence(app_root)
    t_tests = tests_naming_rules(tests_dir)
    kept = kept_evaluation(latest_kept(os.path.join(stage1_dir, "runs")))
    k485 = (kept or {}).get("rule_counts") or {}
    rules = []
    for rid in sorted(R.RULES):
        r = R.RULES[rid]
        in_runs = t_runs.get(rid, [])
        in_tests = t_tests.get(rid, [])
        n485 = int(k485.get(rid, 0))
        if in_runs or n485:
            status = STATUS_SEEN
        elif in_tests:
            status = STATUS_TEST
        else:
            status = STATUS_NONE
        rules.append({"id": rid, "text": r.get("text", ""), "family": family_word(rid), "layer": r.get("layer", ""),
                      "level": r.get("level", ""), "spec": r.get("spec", ""), "why": r.get("why", ""), "status": status,
                      "runs": in_runs, "tests": in_tests, "count_485": n485,
                      "needs_outside_evidence": rid.split(".")[0] in BY_DESIGN_NO_WIRE})
    fam = {}
    for r in rules:
        f = fam.setdefault(r["family"], {"family": r["family"], "total": 0, "seen": 0, "test": 0, "none": 0})
        f["total"] += 1
        f["seen" if r["status"] == STATUS_SEEN else "test" if r["status"] == STATUS_TEST else "none"] += 1
    families = sorted(fam.values(), key=lambda x: (-x["total"], x["family"]))
    status_of = {r["id"]: r["status"] for r in rules}
    kinds = []
    for e in A.CATALOGUE:
        sts = [status_of.get(x, STATUS_NONE) for x in e["rules"]]
        ev = STATUS_SEEN if STATUS_SEEN in sts else STATUS_TEST if STATUS_TEST in sts else KIND_NAME_ONLY
        kinds.append({"name": e["name"], "code": e["code"], "family": e["family"], "meaning": e.get("meaning", ""),
                      "rules": list(e["rules"]), "evidence": ev,
                      "how": [A.HOW_WORDS.get(h, h) for h in e.get("how", ())]})
    totals = {"rules": len(rules), "seen": sum(1 for r in rules if r["status"] == STATUS_SEEN),
              "test": sum(1 for r in rules if r["status"] == STATUS_TEST), "none": sum(1 for r in rules if r["status"] == STATUS_NONE),
              "none_by_design": sum(1 for r in rules if r["status"] == STATUS_NONE and r["needs_outside_evidence"]),
              "kinds": len(kinds), "kinds_seen": sum(1 for k in kinds if k["evidence"] == STATUS_SEEN),
              "kinds_test": sum(1 for k in kinds if k["evidence"] == STATUS_TEST),
              "kinds_name_only": sum(1 for k in kinds if k["evidence"] == KIND_NAME_ONLY),
              "runs_scanned": n_runs, "test_files": len(glob.glob(os.path.join(tests_dir, "test_*.py"))),
              "rules_in_485": sum(1 for r in rules if r["count_485"])}
    totals["with_evidence"] = totals["seen"] + totals["test"]
    sources = [
        {"what": "Findings of every stored run", "where": "runs/**/findings.pkl (%d runs read)" % n_runs,
         "how": "each finding carries the rule that produced it; the rule is counted per run"},
        {"what": "The kept run of the 485-error trace", "where": "stage1/runs/%s" % (kept or {}).get("folder", "(none kept)"),
         "how": "the engine's own evaluate command scored the run against the generator's scenario record; per-rule counts were kept with it"},
        {"what": "The unit tests", "where": "stage1/tests/test_*.py (%d files)" % totals["test_files"],
         "how": "the source of every test function is scanned for rule names; a rule named only outside a test function is attributed to the file"},
        {"what": "The rule catalogue", "where": "stage1/pcie_isolate/rules.py", "how": "every rule with its plain-words text, its layer and its specification citation"},
        {"what": "The 72 analyzer error kinds", "where": "stage1/pcie_isolate/analyzer_errors.py",
         "how": "each kind maps to one or more rules; its evidence is the best evidence of those rules. The name mapping itself is tested for all 72 by test_every_one_of_the_72_names_fires_its_rule"},
    ]
    return {"generated_at": time.strftime("%Y-%m-%d %H:%M"), "totals": totals, "families": families, "rules": rules,
            "kinds": kinds, "kept": kept, "sources": sources,
            "words": {"seen": STATUS_SEEN, "test": STATUS_TEST, "none": STATUS_NONE, "name_only": KIND_NAME_ONLY}}
