"""Final confirmation by Claude Haiku over the isolated rows - token-efficient.

For each incident the model receives the deterministic findings, the rows from 15 above the start to 15
below the end (two windows when the span is long), the key evidence rows, the outside evidence placed in the
incident, and the top atlas candidates.  It returns a schema-validated verdict and cites only packets it saw.

Token economy
  * one static prefix for every request - reviewer instructions + column legend + NVMe legend + the rule
    catalogue - marked with cache_control, so it is written once and read from cache afterwards
    (Claude Haiku 5.5 caches prefixes from 512 tokens; reads cost ~0.1x).  Nothing per-incident is placed
    before the breakpoint, so the prefix is byte-identical across requests.
  * compact rows: short column codes, times relative to the first row, CRC values only when flagged bad,
    runs of healthy Ack/UpdateFC DLLPs collapsed to one line, SQE payloads decoded into fields.
  * repeated findings of one rule collapsed to one line with their packets.
  * --batch: Message Batches API (50% price); the cache then uses the 1-hour TTL because batch requests
    are not guaranteed to run back to back.

Credentials: ANTHROPIC_API_KEY (and optional ANTHROPIC_BASE_URL) from the environment or a .env file.
"""
import json
import os
import struct
import sys
import threading
import time
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor, as_completed

HERE = os.path.dirname(os.path.abspath(__file__))
ENGINE_DIR = os.path.dirname(HERE)


def import_anthropic():
    """Prefer an installed SDK; fall back to the vendored copy (built for CPython 3.13 x86-64 Linux)."""
    try:
        import anthropic
        return anthropic
    except ImportError:
        pass
    # the vendored tree must shadow older system copies of its dependencies (typing_extensions, pydantic, ...)
    sys.path.insert(0, os.path.join(ENGINE_DIR, "vendor"))
    for m in [k for k in sys.modules if k.split(".")[0] in ("typing_extensions", "pydantic", "pydantic_core",
                                                            "anyio", "httpx2", "httpcore2", "jiter", "sniffio")]:
        del sys.modules[m]
    try:
        import anthropic
        return anthropic
    except ImportError as e:
        sys.exit("The anthropic SDK is not importable on this interpreter (%s: %s).\n"
                 "Install it:  %s -m pip install -r requirements.txt\n"
                 "(the vendored copy in vendor/ is built for CPython 3.13 on x86-64 Linux; run with python3.13, "
                 "or install the SDK for your interpreter)" % (sys.version.split()[0], str(e)[:100], sys.executable))

MAX_ROWS = 120

SYSTEM = """You review isolated defect candidates in a PCIe/NVMe protocol-analyzer export (Teledyne LeCroy style).
A deterministic rule engine has flagged the incident and listed its findings; you check them against the rows.
Unrelated traffic interleaves; never infer causality from adjacency alone - pair by PSN, RequesterID+Tag,
SQID+CID, queue slot or address.
- CONFIRMED: the rows (or the outside evidence shown) show the defect the findings describe.
- NOT_CONFIRMED: the rows contradict the findings (healthy behaviour, misread fields).
- INCONCLUSIVE: the defect depends on evidence not shown (distributions, logs or payload you cannot see).
Timing findings (timeouts, "not fetched for N s", "no MSI-X within N us", latency outliers, rate thresholds) were
measured by the engine over the whole capture. The excerpt cannot contain the gap they describe. Seeing healthy
pairs inside the excerpt does NOT contradict such a finding - mark it INCONCLUSIVE unless a row directly refutes
the stated measurement. NOT_CONFIRMED is for findings a shown row contradicts (a field misread, a completion that
is present, a status that is SC). An analyzer artefact (buffer wrap, filter, resync) explaining the finding is a
CONFIRMED capture-integrity defect with responsible = "test setup".
Say where the defect starts and where it is concluded, the packets that prove it, the best atlas candidate
(its id from the CANDIDATES line, or "none") and who is most likely responsible. Cite only packet numbers that
appear in the input. Be brief.
Answer discipline (every claim must survive a bug-report review):
- Prefix each sentence of the summary with OBSERVED: (a row shows it), RULE: (name the engine rule id or the
  atlas rule; never quote spec section numbers), or HYPOTHESIS: (anything about device or host internals - the
  FTL, caches, firmware, scheduler; pair it with the experiment that would test it, and list it in hypotheses).
- Name the root: the first abnormal event (root_pkt) and which later findings are its cascade (cascade_pkts);
  the rest are independent.
- Proximity is not causality: a row that follows another is a consequence only when a rule links them.
- CAPTURE line: if the capture starts mid-traffic, unknown CIDs/tags before state was learned are not defects;
  if a marker/gap sits in the window, absence across it proves nothing.
- If the rows cannot decide, say exactly which evidence would (needs).
- When no row supports a finding, look at the CAPTURE line before naming a culprit: a mid-traffic start, missing
  controller initialisation, missing payload, a filter, a buffer wrap or a recording gap explains an absence. Then
  answer INCONCLUSIVE and put the re-capture requirement in needs (payload expanded, capture from boot, unfiltered,
  larger trigger window). Never invent a packet to fill the gap.
- pl= is raw little-endian payload; for 4- and 8-byte values use the decoded le= field (CAP, CSTS, CRTO, Device
  Control, doorbells). Decode SCT before SC. Check queue id, CID and tag against the rows, not your expectation.
- Device-internal claims are hypotheses; destructive tests (format, sanitize, register writes) are proposed only
  for scratch hardware.

ROW FORMAT  #<packet> +<microseconds since the block's first row> <D|U> <kind> fields...
D = Downstream (root port/host -> SSD), U = Upstream (SSD -> host). Kinds: TLP type, DLLP type, OS:<ordered set>,
EV:<link event>, MK:<analyzer marker>. Field codes: psn=PSN ack=AckNak Seq Num len=Length (DW) rid=RequesterID
tag=Tag cid=CompleterID a=Address reg=Register be=1st/Last BE st=Cpl Status bc=Byte Cnt la=Lwr Addr
msg=Message Code/Routing data=DATA size tc/td/ep/attr/at=header bits (shown only when set)
lcrc/crc16/ecrc=shown only when the analyzer flags them; tsctl/rate/eq/lane=training-set fields; pl=payload hex.
"~ N healthy DLLPs" stands for N consecutive Ack/UpdateFC rows without errors.
NVMe: a 64-byte CplD answering an SSD MRd of an SQ slot is a submission entry, shown decoded as
SQE{opc cid nsid slba nlb prp1 prp2 cdw10}; a 16-byte SSD MWr into a completion queue is a CQE
(pl: DW2 = SQHD|SQID<<16, DW3 = CID | phase<<16 | status<<17); MWr to 0xFEExxxxx is MSI-X; host MWr to
BAR0+0x14 is CC, BAR0+0x1000.. are doorbells. Outside evidence lines come from host/device/lab documents
aligned to the analyzer clock (prefix H.).

RULE CATALOGUE (id  verdict  meaning)
"""

SCHEMA = {
    "type": "object",
    "properties": {
        "verdict": {"type": "string", "enum": ["CONFIRMED", "NOT_CONFIRMED", "INCONCLUSIVE"]},
        "defect_start_pkt": {"type": "integer"},
        "defect_end_pkt": {"type": "integer"},
        "evidence_pkts": {"type": "array", "items": {"type": "integer"}},
        "card_id": {"type": "string", "description": "one of the CANDIDATES card ids, or 'none'"},
        "responsible": {"type": "string",
                        "enum": ["host", "device", "platform", "link", "test setup", "undetermined"]},
        "rules_confirmed": {"type": "array", "items": {"type": "string"},
                            "description": "engine rule ids whose finding the rows support"},
        "rules_refuted": {"type": "array", "items": {"type": "string"},
                          "description": "engine rule ids a shown row contradicts"},
        "root_pkt": {"type": "integer", "description": "the first abnormal event; -1 if none"},
        "cascade_pkts": {"type": "array", "items": {"type": "integer"},
                         "description": "finding packets that are consequences of the root"},
        "hypotheses": {"type": "array", "items": {"type": "string"},
                       "description": "claims about device/host internals, each with the experiment that would test it"},
        "needs": {"type": "array", "items": {"type": "string"},
                  "description": "evidence not in the rows that would settle an INCONCLUSIVE verdict"},
        "summary": {"type": "string", "description": "sentences prefixed OBSERVED: / RULE: / HYPOTHESIS:"},
    },
    "required": ["verdict", "defect_start_pkt", "defect_end_pkt", "evidence_pkts", "card_id",
                 "responsible", "rules_confirmed", "rules_refuted", "root_pkt", "cascade_pkts", "hypotheses",
                 "needs", "summary"],
    "additionalProperties": False,
}

CODES = OrderedDict([
    ("PSN", "psn"), ("AckNak Seq Num", "ack"), ("Length", "len"), ("RequesterID", "rid"), ("Tag", "tag"),
    ("CompleterID", "cid"), ("Address", "a"), ("Register", "reg"), ("Cpl Status", "st"), ("Byte Cnt", "bc"),
    ("Lwr Addr", "la"), ("Message Code", "msg"), ("Msg Routing", "route"), ("DATA", "data"), ("TC", "tc"),
    ("TD", "td"), ("EP", "ep"), ("Attributes", "attr"), ("AT", "at"), ("Training Control", "tsctl"),
    ("TS Data Rate", "rate"), ("TS Gen3 Eq Control", "eq"), ("TS Lane", "lane"), ("HdrFC", "hfc"),
    ("DataFC", "dfc"), ("Value (Snoop)", "ltr"), ("Scale (Snoop)", "ltrs"), ("Slave Address", "smb"),
])
KIND = ("TLP Type", "DLLP Type", "Ord.Set Type", "Link Event", "Marker")


def system_blocks(ttl=None):
    from .rules import RULES
    cat = "\n".join("%s %s %s" % (rid, r["verdict"], r["text"]) for rid, r in RULES.items())
    cc = {"type": "ephemeral"}
    if ttl:
        cc["ttl"] = ttl
    return [{"type": "text", "text": SYSTEM + cat, "cache_control": cc}]


def load_env():
    for p in (os.path.join(ENGINE_DIR, ".env"), os.path.join(os.path.dirname(ENGINE_DIR), ".env")):
        if os.path.exists(p):
            for line in open(p):
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    k = k.replace("export ", "").strip()
                    if k in ("ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL") and not os.environ.get(k):
                        os.environ[k] = v.strip().strip('"').strip("'")


# ---------------------------------------------------------------------- compact rows
def parse_row(text):
    f = {}
    for part in text.split(" | "):
        if "=" in part:
            k, v = part.split("=", 1)
            f[k] = v
    return f


def ts_us(s):
    sec, frac = s[:-1].split(".")
    return int(sec) * 1e6 + int(frac) / 1e6


def decode_sqe(hexs):
    b = bytes.fromhex(hexs)
    dw = struct.unpack("<16I", b[:64])
    return "SQE{opc=0x%02X cid=%d nsid=%d slba=0x%X nlb=%d prp1=0x%X prp2=0x%X cdw10=0x%X}" % (
        dw[0] & 0xFF, dw[0] >> 16, dw[1], dw[10] | dw[11] << 32, (dw[12] & 0xFFFF) + 1,
        dw[6] | dw[7] << 32, dw[8] | dw[9] << 32, dw[10])


def compact_row(f, t0):
    kind = ""
    for k in KIND:
        if f.get(k):
            kind = {"Ord.Set Type": "OS:", "Link Event": "EV:", "Marker": "MK:"}.get(k, "") + f[k]
            break
    d = {"Downstream": "D", "Upstream": "U"}.get(f.get("Link Dir", ""), "-")
    out = ["#%s" % f.get("Packet", "?"), "+%.3f" % (ts_us(f["Time Stamp"]) - t0) if "Time Stamp" in f else "",
           d, kind.replace(" ", "")]
    for col, code in CODES.items():
        v = f.get(col)
        if not v:
            continue
        if col in ("Training Control",) and v == "0 0 0 0 0 0 00":
            continue
        out.append("%s=%s" % (code, v.replace(" ", "")))
    if f.get("st BE") and f.get("TLP Type", "").startswith(("MWr", "MRd", "Cfg")):
        if (f.get("st BE"), f.get("Last BE")) not in (("1111", "1111"), ("1111", "0000")):
            out.append("be=%s/%s" % (f.get("st BE"), f.get("Last BE")))
    for col, code in (("LCRC", "lcrc"), ("CRC 16", "crc16"), ("ECRC", "ecrc")):
        v = f.get(col, "")
        if "(" in v:
            out.append("%s=%s" % (code, v.replace(" ", "")))
    pl = f.get("PAYLOAD")
    if pl:
        h = pl.split("...")[0]
        if len(h) == 128 and f.get("TLP Type") == "CplD":
            out.append(decode_sqe(h))
        elif "..." not in pl:
            out.append("pl=" + h)
            if len(h) in (8, 16):                       # 4- or 8-byte value: show it decoded (little-endian)
                out.append("le=0x%X" % int.from_bytes(bytes.fromhex(h), "little"))
    return " ".join(x for x in out if x)


def healthy_dllp(f):
    return f.get("DLLP Type", "") in ("ACK", "UpdateFC-P", "UpdateFC-NP") and "(" not in f.get("CRC 16", "")


def compact_block(rows, keep_pkts):
    parsed = [parse_row(r) for r in rows]
    t0 = next((ts_us(f["Time Stamp"]) for f in parsed if "Time Stamp" in f), 0.0)
    out, run = [], 0
    for f in parsed:
        try:
            p = int(f.get("Packet", -1))
        except ValueError:
            p = -1
        if healthy_dllp(f) and p not in keep_pkts:
            run += 1
            continue
        if run:
            out.append("~ %d healthy DLLPs" % run)
            run = 0
        out.append(compact_row(f, t0))
    if run:
        out.append("~ %d healthy DLLPs" % run)
    return out


def findings_lines(inc):
    groups = OrderedDict()
    for f in inc["findings"]:
        k = (f["rule"], f["detail"] if f["rule"].startswith("H.") else f["qual"])
        groups.setdefault(k, []).append(f)
    lines = []
    for (rule, _), fs in list(groups.items())[:30]:
        f = fs[0]
        pk = ",".join(str(x["pkt"]) for x in fs[:6]) + ("..+%d" % (len(fs) - 6) if len(fs) > 6 else "")
        rel = sorted({p for x in fs for p in x["related_pkts"]})[:4]
        lines.append("%s %s x%d @%s: %s%s" % (rule, f["verdict"], len(fs), pk, f["detail"][:160],
                                             (" rel=" + ",".join(map(str, rel))) if rel else ""))
    return lines


CAPTURE_CTX = {}      # set by review_run from run.json: capture-level facts the reviewer must know (atlas IX.4)


def capture_line(inc):
    c = CAPTURE_CTX
    if not c:
        return "CAPTURE: context unavailable"
    parts = ["starts %s" % ("mid-traffic (state before it unknown)" if c.get("starts_mid_traffic") else
                            "at link-up/boot"),
             "controller init %s" % ("captured" if c.get("controller_enable_seen") else "NOT captured"),
             "payload %s" % c.get("payload", "?")]
    gaps = [f for f in inc["findings"] if f["rule"].startswith("CI.")]
    if gaps:
        parts.append("capture-integrity rows in window: " + ", ".join("#%d %s" % (f["pkt"], f["rule"]) for f in gaps[:4]))
    if c.get("cto"):
        parts.append("completion timeout in force: %s" % c["cto"])
    return "CAPTURE: " + "; ".join(parts)


def build_prompt(inc, rows):
    keep = set(inc["key_pkts"]) | {f["pkt"] for f in inc["findings"]}
    cl = inc.get("csv_lines") or {}
    L = ["INCIDENT %s pkts %d-%d (CSV lines %s-%s) engine-verdict %s layer %s" % (
            inc["id"], inc["start_pkt"], inc["end_pkt"], cl.get("start", "?"), cl.get("end", "?"),
            inc["verdict"], inc["layer"]),
         capture_line(inc),
         "first: #%d %s - %s" % (inc["first_abnormal"]["pkt"], inc["first_abnormal"]["rule"],
                                 inc["first_abnormal"]["detail"][:200]),
         "who(engine): %s - %s" % (inc["attribution"]["origin"], inc["attribution"]["rule"]),
         "task: %s" % inc["task"]]
    if inc.get("nvme_commands"):
        c = inc["nvme_commands"][0]
        L.append("command: " + " ".join("%s=%s" % (k, v) for k, v in c.items() if k != "sqe_packet"))
    L.append("FINDINGS")
    L += findings_lines(inc)
    L.append("CANDIDATES " + "; ".join("%s %s (%.2f)" % (c["card_id"], c["title"][:70], c["score"])
                                        for c in inc["atlas_candidates"][:3]))
    ex = inc.get("explanation") or {}
    if ex.get("in_a_pex_trace"):
        L.append("top-candidate trace signature: " + ex["in_a_pex_trace"][:300])
    n = 0
    for b in rows["blocks"]:
        lines = compact_block(b["rows"], keep)
        L.append("ROWS %d..%d" % tuple(b["range"]))
        for x in lines:
            if n >= MAX_ROWS:
                break
            L.append(x)
            n += 1
    if rows["key_rows"]:
        L.append("KEY ROWS")
        L += compact_block(rows["key_rows"][:25], keep)
    return "\n".join(L)


def build_prompt_verbose(inc, rows):
    """The previous (uncompressed) layout - kept only to measure the saving."""
    L = [json.dumps({k: inc[k] for k in ("id", "start_pkt", "end_pkt", "first_abnormal", "attribution", "task")})]
    L += ["%s %s" % (f["rule"], f["detail"]) for f in inc["findings"][:25]]
    for b in rows["blocks"]:
        L += b["rows"][:140]
    L += rows["key_rows"][:25]
    return "\n".join(L)


# ---------------------------------------------------------------------- calls
def shown_pkts(rows):
    shown = set()
    for b in rows["blocks"]:
        shown.update(range(b["range"][0], b["range"][1] + 1))
    shown |= {int(r.split("Packet=")[1].split(" ")[0]) for r in rows["key_rows"] if "Packet=" in r}
    shown |= set(rows.get("finding_pkts", []))          # packets named in the FINDINGS list were shown too
    return shown


def finish_result(out, verdict, rows):
    """Attach the model's verdict dict to the record and flag packets it cited but was never shown."""
    out.update(verdict)
    shown = shown_pkts(rows)
    cited = list(out.get("evidence_pkts", [])) + list(out.get("cascade_pkts", []))
    if isinstance(out.get("root_pkt"), int) and out["root_pkt"] >= 0:
        cited.append(out["root_pkt"])
    out["cited_unseen_pkts"] = sorted({p for p in cited if p not in shown})
    return out


def parse_result(inc_id, model, resp, rows):
    """SDK backend: Messages API response -> review record."""
    out = {"id": inc_id, "model": model, "backend": "sdk", "stop_reason": resp.stop_reason,
           "input_tokens": resp.usage.input_tokens, "output_tokens": resp.usage.output_tokens,
           "cache_read_tokens": getattr(resp.usage, "cache_read_input_tokens", 0) or 0,
           "cache_write_tokens": getattr(resp.usage, "cache_creation_input_tokens", 0) or 0}
    if resp.stop_reason == "refusal":
        out["error"] = "refusal"
        return out
    text = next((b.text for b in resp.content if b.type == "text"), None)
    if text is None:
        out["error"] = "no text block (stop_reason %s)" % resp.stop_reason
        return out
    try:
        return finish_result(out, json.loads(text), rows)
    except json.JSONDecodeError:
        out["error"] = "invalid JSON"
        out["raw"] = text[:500]
        return out


def cli_structured(cli, model, system, schema, prompt, timeout=180, max_turns=2):
    """Run `claude -p` for one schema-validated answer. Returns (verdict_dict | None, info_dict).
    The CLI implements structured output as an internal tool call; if it reports error_max_turns the
    finalisation turn ran out, so the call is retried once with more turns."""
    import subprocess
    info = {}
    for attempt, turns in enumerate((max_turns, max_turns + 4)):   # the finalisation turn occasionally needs more
        cmd = [cli, "-p", "--model", model, "--effort", "low", "--tools", "", "--max-turns", str(turns),
               "--output-format", "json", "--system-prompt", system, "--json-schema", json.dumps(schema), prompt]
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        except FileNotFoundError:
            info["error"] = "claude CLI not found (install Claude Code or use the SDK backend)"
            return None, info
        except subprocess.TimeoutExpired:
            info["error"] = "cli timeout after %ds" % timeout
            return None, info
        try:
            d = json.loads(r.stdout)
        except json.JSONDecodeError:
            info["error"] = "cli exit %d, non-JSON output: %s" % (r.returncode, (r.stderr or r.stdout)[-300:])
            return None, info
        u = d.get("usage", {})
        info.update({"input_tokens": u.get("input_tokens", 0), "output_tokens": u.get("output_tokens", 0),
                     "cache_read_tokens": u.get("cache_read_input_tokens", 0),
                     "cache_write_tokens": u.get("cache_creation_input_tokens", 0),
                     "cost_usd": (info.get("cost_usd") or 0) + (d.get("total_cost_usd") or 0),
                     "cli_turns": d.get("num_turns"), "attempts": attempt + 1})
        v = d.get("structured_output")
        if v is None:
            res = d.get("result")
            try:
                v = json.loads(res) if isinstance(res, str) else None
            except json.JSONDecodeError:
                v = None
        if isinstance(v, dict):
            info.pop("error", None)
            return v, info
        info["error"] = "cli %s: %s" % (d.get("subtype") or "no structured output",
                                        "; ".join(d.get("errors") or [])[:200] or str(d.get("result"))[:200])
        if d.get("subtype") != "error_max_turns":
            return None, info
    return None, info


def review_one_cli(model, inc, rows, cli="claude", timeout=180):
    """Local `claude` CLI backend (Claude Code login; no API key needed).

    --system-prompt REPLACES the CLI's default agent prompt (otherwise ~39k tokens are sent per call),
    --tools "" disables tools and --max-turns 2 leaves room for the structured-output finalisation turn, --json-schema gives a validated object in
    the result's `structured_output` field.  The CLI reports stop_reason 'tool_use' for structured output;
    that is its mechanism, not an error."""
    out = {"id": inc["id"], "model": model, "backend": "cli"}
    verdict, info = cli_structured(cli, model, system_blocks()[0]["text"], schema_for(inc), build_prompt(inc, rows),
                                   timeout)
    out.update(info)
    if verdict is None:
        return out
    return finish_result(out, verdict, rows)


def schema_for(inc):
    """The verdict schema with card_id restricted to the candidates this incident was shown."""
    sc = json.loads(json.dumps(SCHEMA))
    ids = [c["card_id"] for c in inc["atlas_candidates"][:3]] + ["none"]
    sc["properties"]["card_id"] = {"type": "string", "enum": ids}
    return sc


def request_params(model, inc, rows, ttl=None):
    return {"model": model, "max_tokens": 4000, "system": system_blocks(ttl),
            "messages": [{"role": "user", "content": build_prompt(inc, rows)}],
            "output_config": {"effort": "low", "format": {"type": "json_schema", "schema": schema_for(inc)}}}


def review_one(client, model, inc, rows):
    anthropic = import_anthropic()
    try:
        resp = client.messages.create(**request_params(model, inc, rows))
    except anthropic.AuthenticationError:
        raise
    except anthropic.APIStatusError as e:
        return {"id": inc["id"], "model": model, "error": "HTTP %s: %s" % (e.status_code, e.message)}
    except anthropic.APIConnectionError as e:
        return {"id": inc["id"], "model": model, "error": "connection: %s" % e}
    return parse_result(inc["id"], model, resp, rows)


CAPTURE_SCHEMA = {
    "type": "object",
    "properties": {
        "capture_adequate": {"type": "boolean"},
        "can_show": {"type": "array", "items": {"type": "string"},
                     "description": "defect families this capture can prove (wire-visible with the payload available)"},
        "cannot_show": {"type": "array", "items": {"type": "string"},
                        "description": "defect families this capture cannot prove, each with the reason"},
        "recapture": {"type": "array", "items": {"type": "string"},
                      "description": "concrete export/capture changes that would close the gaps, in priority order"},
        "summary": {"type": "string"},
    },
    "required": ["capture_adequate", "can_show", "cannot_show", "recapture", "summary"],
    "additionalProperties": False,
}

CAPTURE_SYSTEM = """You assess whether a PCIe/NVMe protocol-analyzer capture is able to show the defects an engineer is
looking for. You get facts the engine measured over the whole capture (span, where it starts, whether controller
initialisation was captured, which payload is available, capture-integrity rows, thresholds in force, how many
incidents of which layer were found). Decide what this capture CAN prove and what it CANNOT, and what to change in the
next export or capture. Rules: no NVMe-level claim is possible without payload; a mid-traffic start hides queue state
until the next initialisation; a filter, buffer wrap, resync or recording gap makes absence across it UNKNOWN; a
capture that does not cover the failure time proves nothing about it; 33 of the 485 atlas defect cards have no
PCIe-wire signature by design (other path, NVMe-oF, host-synthesised statuses, host scheduling) and need host or
device documents. Be concrete and short."""


def capture_prompt(run):
    c = run.get("capture", {})
    th = run.get("thresholds", {})
    cto = th.get("CTO_PS", {})
    L = ["CAPTURE FACTS",
         "rows %d, packets 0..%d, span %.3f s" % (run["rows"], run["last_pkt"], (run["last_t"] - run["first_t"]) / 1e12),
         "starts %s; controller initialisation %s; payload: %s; columns missing: %s; CXL rows: %d" % (
             "mid-traffic" if c.get("starts_mid_traffic") else "at link-up/boot",
             "captured" if c.get("controller_enable_seen") else "NOT captured", c.get("payload"),
             ", ".join(c.get("columns_missing") or []) or "none", c.get("cxl_rows", 0)),
         "completion timeout in force: %s, %s" % ("%.0f ms" % (cto["value"] / 1e9) if cto.get("value") and cto["value"] < (1 << 60)
                                                    else "disabled", cto.get("note", "?").split(";")[0].replace(
                                                        "configured:", "read from the captured Device Control 2 write:")),
         "capture-integrity findings: %s" % (run.get("capture_integrity_findings") or "none"),
         "incidents by layer: %s" % json.dumps(run.get("incidents_by_layer") or {}),
         "incidents by status: %s" % json.dumps(run.get("incidents_by_status") or {}),
         "host documents fused: %s" % json.dumps(run.get("host_alignment") or "none")]
    return "\n".join(L)


def capture_check(run_dir, model, backend="auto"):
    """One model call: can this capture show what we are looking for? -> capture_assessment.json"""
    load_env()
    backend = pick_backend(backend)
    run = json.load(open(os.path.join(run_dir, "run.json")))
    ip = os.path.join(run_dir, "incidents.json")
    if os.path.exists(ip):
        incs = json.load(open(ip))
        from collections import Counter
        run["incidents_by_layer"] = dict(Counter(i["layer"] for i in incs))
        ci = Counter(f["rule"] for i in incs for f in i["findings"] if f["rule"].startswith("CI."))
        run["capture_integrity_findings"] = dict(ci)
    sp = os.path.join(run_dir, "isolation_summary.json")
    if os.path.exists(sp):
        run["incidents_by_status"] = json.load(open(sp)).get("status")
    hp = os.path.join(run_dir, "host_alignment.json")
    if os.path.exists(hp):
        h = json.load(open(hp))
        run["host_alignment"] = {k: h.get(k) for k in ("error_records_placed", "benign_skipped", "simulated")}
    prompt = capture_prompt(run)
    out = {"model": model, "backend": backend, "facts": prompt}
    if backend == "dry-run":
        out["error"] = "dry run: no model call"
    elif backend == "cli":
        v, info = cli_structured("claude", model, CAPTURE_SYSTEM, CAPTURE_SCHEMA, prompt)
        out.update(info)
        if v:
            out.update(v)
    else:
        anthropic = import_anthropic()
        client = anthropic.Anthropic(max_retries=4)
        try:
            resp = client.messages.create(model=model, max_tokens=2000,
                                          system=[{"type": "text", "text": CAPTURE_SYSTEM}],
                                          messages=[{"role": "user", "content": prompt}],
                                          output_config={"effort": "low",
                                                         "format": {"type": "json_schema", "schema": CAPTURE_SCHEMA}})
            text = next((b.text for b in resp.content if b.type == "text"), "")
            out.update(json.loads(text))
        except Exception as e:
            out["error"] = "sdk: %s" % e
    json.dump(out, open(os.path.join(run_dir, "capture_assessment.json"), "w"), indent=1)
    print(json.dumps({k: out.get(k) for k in ("capture_adequate", "cannot_show", "recapture", "error")}, indent=1))
    return out


def estimate(run_dir, incs, rows):
    """chars/3.6 estimate of input tokens: old layout vs compact + cached prefix (no API call)."""
    pre = len(system_blocks()[0]["text"]) / 3.6
    old = sum(len(build_prompt_verbose(i, rows[i["id"]])) / 3.6 for i in incs)
    new = sum(len(build_prompt(i, rows[i["id"]])) / 3.6 for i in incs)
    n = len(incs)
    est = {"incidents": n, "static_prefix_tokens": round(pre),
           "old_layout_input_tokens": round(old + n * 450),
           "compact_uncached_tokens": round(new),
           "compact_total_input_tokens": round(new + n * pre),
           "compact_billed_equivalent_tokens": round(new + pre * 1.25 + (n - 1) * pre * 0.1),
           "batch_billed_equivalent_tokens": round((new + pre * 2.0 + (n - 1) * pre * 0.1) * 0.5),
           "note": "billed-equivalent = uncached + cache write (1.25x, 2x for the 1-hour TTL) + cache reads "
                   "(0.1x); batch halves everything. Estimate only (chars/3.6); real usage is recorded per "
                   "request in llm_reviews.jsonl"}
    json.dump(est, open(os.path.join(run_dir, "llm_token_estimate.json"), "w"), indent=1)
    print(json.dumps(est, indent=1))
    return est


def pick_backend(requested):
    """'auto': SDK when a key is present, else the local claude CLI when installed, else dry-run."""
    import shutil
    if requested != "auto":
        return requested
    if os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"):
        return "sdk"
    if shutil.which("claude"):
        return "cli"
    return "dry-run"


def sample_per_bucket(incs):
    """One incident per (layer, first abnormal rule) bucket: a stratified validation set that covers every
    defect family the run contains, at a fraction of the cost of reviewing everything."""
    seen, out = set(), []
    for i in sorted(incs, key=lambda x: x["id"]):
        k = (i["layer"], i["first_abnormal"]["rule"])
        if k not in seen:
            seen.add(k)
            out.append(i)
    return out


def review_run(run_dir, model="claude-haiku-5-5", limit=0, workers=6, context=15, batch=False,
               backend="auto", ids=None, per_bucket=False):
    load_env()
    requested = backend
    backend = pick_backend(backend)
    rp_run = os.path.join(run_dir, "run.json")
    if os.path.exists(rp_run):
        run = json.load(open(rp_run))
        CAPTURE_CTX.update(run.get("capture", {}))
        th = run.get("thresholds", {}).get("CTO_PS")
        if th:
            CAPTURE_CTX["cto"] = "%s (%s)" % (th["note"].split(";")[0], "%.0f ms" % (th["value"] / 1e9)
                                            if th["value"] and th["value"] < (1 << 60) else "disabled")
    incs = json.load(open(os.path.join(run_dir, "incidents.json")))
    rows = {}
    for line in open(os.path.join(run_dir, "incident_rows.jsonl")):
        r = json.loads(line)
        rows[r["id"]] = r
    out_path = os.path.join(run_dir, "llm_reviews.jsonl")
    done = set()
    if os.path.exists(out_path):
        for line in open(out_path):
            r = json.loads(line)
            if "error" not in r:
                done.add(r["id"])
    todo = [i for i in incs if i["id"] not in done]
    if ids:
        want = set(json.load(open(ids))) if os.path.exists(ids) else set(ids.split(","))
        todo = [i for i in todo if i["id"] in want]
    if per_bucket:
        keep = {i["id"] for i in sample_per_bucket(incs)}
        todo = [i for i in todo if i["id"] in keep]
        print("stratified sample: %d incidents (one per layer x first-rule bucket)" % len(keep))
    if limit:
        todo = todo[:limit]
    with open(os.path.join(run_dir, "llm_prompts.jsonl"), "w") as fp:
        fp.write(json.dumps({"static_prefix": system_blocks()[0]["text"]}) + "\n")
        for inc in todo:
            fp.write(json.dumps({"id": inc["id"], "model": model, "user": build_prompt(inc, rows[inc["id"]])}) + "\n")
    estimate(run_dir, todo, rows)
    if backend == "dry-run":
        print("Dry run%s.\n" % ("" if requested == "dry-run" else
                             " (no ANTHROPIC_API_KEY / ANTHROPIC_AUTH_TOKEN and no `claude` CLI found)") +
              "The %d prompts are in %s.\nRe-run with a key for the SDK backend, or install Claude Code for the "
              "CLI backend:  python3 -m pcie_isolate.cli review --run %s [--backend sdk|cli] [--batch]"
              % (len(todo), os.path.join(run_dir, "llm_prompts.jsonl"), run_dir))
        return
    lock = threading.Lock()
    stats = {"ok": 0, "err": 0, "in": 0, "out": 0, "cache_read": 0, "cache_write": 0, "cost_usd": 0.0}

    def record(fo, r):
        with lock:
            fo.write(json.dumps(r) + "\n")
            fo.flush()
            stats["err" if "error" in r else "ok"] += 1
            stats["in"] += r.get("input_tokens", 0)
            stats["out"] += r.get("output_tokens", 0)
            stats["cache_read"] += r.get("cache_read_tokens", 0)
            stats["cache_write"] += r.get("cache_write_tokens", 0)
            stats["cost_usd"] += r.get("cost_usd") or 0.0

    if backend == "cli":
        print("reviewing %d incidents with %s via the local claude CLI (%d already done)" %
              (len(todo), model, len(done)), flush=True)
        with open(out_path, "a") as fo, ThreadPoolExecutor(max_workers=min(workers, 4)) as pool:
            futs = [pool.submit(review_one_cli, model, inc, rows[inc["id"]]) for inc in todo]
            for n, fut in enumerate(as_completed(futs), 1):
                record(fo, fut.result())
                if n % 25 == 0:
                    print("  %d/%d  %s" % (n, len(todo), stats), flush=True)
        print("done: %s -> %s" % (stats, out_path))
        return
    anthropic = import_anthropic()
    client = anthropic.Anthropic(max_retries=4)
    if batch:
        return review_batch(client, model, todo, rows, out_path)
    # warm the cache with one request, then fan out (parallel first requests would each write the prefix)

    print("reviewing %d incidents with %s via the SDK (%d already done)" % (len(todo), model, len(done)), flush=True)
    with open(out_path, "a") as fo:
        try:
            if todo:
                record(fo, review_one(client, model, todo[0], rows[todo[0]["id"]]))
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futs = [pool.submit(review_one, client, model, inc, rows[inc["id"]]) for inc in todo[1:]]
                for n, fut in enumerate(as_completed(futs), 2):
                    record(fo, fut.result())
                    if n % 50 == 0:
                        print("  %d/%d  %s" % (n, len(todo), stats), flush=True)
        except anthropic.AuthenticationError:
            sys.exit("Authentication failed: check ANTHROPIC_API_KEY (and ANTHROPIC_BASE_URL for a gateway).")
    print("done: %s -> %s" % (stats, out_path))


def review_batch(client, model, todo, rows, out_path):
    import_anthropic()
    from anthropic.types.message_create_params import MessageCreateParamsNonStreaming
    from anthropic.types.messages.batch_create_params import Request
    reqs = [Request(custom_id=inc["id"], params=MessageCreateParamsNonStreaming(
        **request_params(model, inc, rows[inc["id"]], ttl="1h"))) for inc in todo]
    b = client.messages.batches.create(requests=reqs)
    print("batch %s submitted (%d requests); polling ..." % (b.id, len(reqs)), flush=True)
    while True:
        b = client.messages.batches.retrieve(b.id)
        if b.processing_status == "ended":
            break
        time.sleep(30)
    with open(out_path, "a") as fo:
        for res in client.messages.batches.results(b.id):
            if res.result.type == "succeeded":
                r = parse_result(res.custom_id, model, res.result.message, rows[res.custom_id])
            else:
                r = {"id": res.custom_id, "model": model, "error": "batch %s" % res.result.type}
            fo.write(json.dumps(r) + "\n")
    print("batch %s ended: %s" % (b.id, b.request_counts))
