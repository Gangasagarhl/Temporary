"""Outside-the-trace evidence: parse host/device/lab documents, align their clock to the analyzer clock and
turn them into findings (tier H) on the trace's packet axis.

Inputs (any subset; formats a real lab produces):
  dmesg -x            "kern  :err   : [ 1234.567890] nvme nvme0: I/O tag 12 (100c) opcode 0x2 QID 3 timeout, aborting"
                      (plain "[ 1234.567890] msg" lines are accepted too; then only error keywords decide)
  host_events.jsonl   one JSON object per line: {"time": <host seconds>, "source": <tool>, "level": "err"|"warn"|...,
                      "text": "..."}; sources: nvme-log, smart-log, fio-verify, blktrace, lspci, bmc, scope, other-path,
                      fabric, lab, analyzer-settings

Clock alignment: anchor pairs whose order is known on both sides - controller resets the analyzer sees
(host MWr CC.EN=0) and the kernel's "resetting controller" lines.  offset = mode of host_t - wire_t over all
pairs, refined by the median within +-2 ms.  A supplied --clock-offset overrides it.

Message classification is generic (regex catalogue of Linux / tool message classes); it never uses card ids.
"""
import bisect
import json
import os
import pickle
import re
from collections import Counter

import numpy as np

from .schema import SEC

DMESG_X = re.compile(r"^\s*(\w+)\s*:\s*(\w+)\s*:\s*\[\s*(\d+\.\d+)\]\s?(.*)$")
DMESG = re.compile(r"^\s*\[\s*(\d+\.\d+)\]\s?(.*)$")
ERROR_LEVELS = {"emerg", "alert", "crit", "err", "error", "warn", "warning"}
ERROR_WORDS = re.compile(r"error|timeout|timed out|fail|abort|reset|corrupt|miscompare|mismatch|lost|stall|throttl|"
                         r"critical|fatal|not ready|dead|removing|degraded|retry|unsupported|invalid|denied|refused|"
                         r"expired|disconnect|offline|slow|violation|exceed", re.I)
ANCHOR = re.compile(r"resetting controller", re.I)
SNAP_AFTER_S = 0.0002    # snapping also accepts a wire defect up to 0.2 ms after the record (clock residue)

# (rule, class, pattern) - first match wins; order from most specific source to generic kernel errors
CATALOGUE = [
    ("H.DATA_VERIFY", "verify", re.compile(r"verify|miscompare|checksum|crc mismatch|data mismatch|stale data|"
                                            r"expected zero|read.?back|ledger|pattern", re.I)),
    ("H.CAPTURE_SETUP", "capture", re.compile(r"analy[sz]er|export|filter|truncat|decoder|trigger|buffer wrap|"
                                               r"timestamp|precision|probe|capture", re.I)),
    ("H.LAB_RESULT", "lab", re.compile(r"power.?cut|chamber|retention|margin|bake|fixture|jammer|injection", re.I)),
    ("H.OTHER_PATH", "fabrics", re.compile(r"nvme.?tcp|nvme.?rdma|nvme.?fabrics|nvme.?of|tls|keep.?alive|"
                                           r"reconnect|ctrl_loss|discovery|connect", re.I)),
    ("H.OTHER_PATH", "multipath", re.compile(r"multipath|\bana\b|anatt|path|failover|second port|dual.?port|"
                                             r"other controller|switch uplink", re.I)),
    ("H.PLATFORM", "platform", re.compile(r"bmc|smbus|mctp|nvme.?mi|ipmi|sel |power rail|perst|vrm|sideband|"
                                          r"uefi|option rom|firmware|acpi|bios", re.I)),
    ("H.HOST_TRACE", "host_trace", re.compile(r"latency|schedul|numa|cpu|irq|affinity|queue depth|runqueue|"
                                              r"softirq|blktrace|iostat|workload", re.I)),
    ("H.NVME_LOG", "device_log", re.compile(r"error.?log|smart|persistent event|telemetry|self.?test|"
                                            r"firmware slot|critical warning|media|nand|unsafe shutdown", re.I)),
    ("H.KERNEL_ERROR", "nvme_timeout", re.compile(r"timeout", re.I)),
    ("H.KERNEL_ERROR", "nvme_reset", re.compile(r"reset", re.I)),
    ("H.KERNEL_ERROR", "io_error", re.compile(r"i/o error|blk_update_request|status|sct|sc 0x", re.I)),
    ("H.KERNEL_ERROR", "aer", re.compile(r"aer|pcie bus error|corrected|uncorrect|dpc|pciehp|link down", re.I)),
    ("H.KERNEL_ERROR", "iommu", re.compile(r"dmar|iommu|swiotlb|bounce|dma", re.I)),
    ("H.KERNEL_ERROR", "memory", re.compile(r"edac|mce|memory|dram", re.I)),
    ("H.KERNEL_ERROR", "kernel", re.compile(r".", re.I)),
]
SOURCE_RULE = {"nvme-log": "H.NVME_LOG", "smart-log": "H.NVME_LOG", "fio-verify": "H.DATA_VERIFY",
               "blktrace": "H.HOST_TRACE", "bmc": "H.PLATFORM", "scope": "H.PLATFORM", "lspci": "H.PLATFORM",
               "other-path": "H.OTHER_PATH", "fabric": "H.OTHER_PATH", "lab": "H.LAB_RESULT",
               "analyzer-settings": "H.CAPTURE_SETUP"}


def classify(text, source="dmesg"):
    """(rule, message class).  A tool source fixes the rule; dmesg lines are classified by the catalogue."""
    rule0 = SOURCE_RULE.get(source)
    for rule, cls, rx in CATALOGUE:
        if (rule0 is None or rule == rule0) and rx.search(text):
            return rule, cls
    return (rule0, source) if rule0 else ("H.KERNEL_ERROR", "kernel")


def parse_dmesg(path):
    out = []
    for line in open(path, errors="replace"):
        m = DMESG_X.match(line)
        if m:
            fac, lvl, ts, msg = m.groups()
            out.append({"time": float(ts), "source": "dmesg", "level": lvl.lower(), "text": msg.strip()})
            continue
        m = DMESG.match(line)
        if m:
            out.append({"time": float(m.group(1)), "source": "dmesg", "level": "", "text": m.group(2).strip()})
    return out


def parse_events(path):
    out = []
    for line in open(path):
        line = line.strip()
        if line:
            r = json.loads(line)
            r.setdefault("level", "err")
            out.append(r)
    return out


def is_error(r):
    lvl = (r.get("level") or "").lower()
    if lvl:
        return lvl in ERROR_LEVELS
    return bool(ERROR_WORDS.search(r["text"]))


def estimate_offset(host_anchors, wire_anchors, tol=0.002):
    """offset (seconds) such that wire_t = host_t - offset; mode of pairwise differences."""
    if not host_anchors or not wire_anchors:
        return None, 0
    w = np.array(sorted(wire_anchors))
    diffs = []
    for h in host_anchors:
        diffs.extend((h - w).tolist())
    d = np.array(diffs)
    bins = Counter(np.round(d, 3))
    best, _ = bins.most_common(1)[0]
    near = d[np.abs(d - best) <= tol]
    off = float(np.median(near))
    matched = sum(1 for h in host_anchors if np.min(np.abs((h - off) - w)) <= tol)
    return off, matched


def fuse(run_dir, dmesg=None, events=None, clock_offset=None, snap_ms=0.0):
    """snap_ms > 0: place each host record on the latest wire defect up to snap_ms before it (hosts log after
    the device-visible event; use it when anchors are plain dmesg lines with millisecond lag).  0 = place by
    the aligned clock only (tracepoint / ALIGN-marker anchors)."""
    findings = pickle.load(open(os.path.join(run_dir, "findings.pkl"), "rb"))
    ix = np.load(os.path.join(run_dir, "time_index.npz"))
    tix, pix = ix["t"], ix["pkt"]
    recs = []
    if dmesg:
        recs += parse_dmesg(dmesg)
    if events:
        recs += parse_events(events)
    wire_anchors = [f[1] / SEC for f in findings if f[2] == "REG.CTRL_RESET" and f[1] is not None]
    host_anchors = [r["time"] for r in recs if r["source"] == "dmesg" and ANCHOR.search(r["text"])]
    if clock_offset is None:
        off, matched = estimate_offset(host_anchors, wire_anchors)
        how = "anchor pairs: %d kernel 'resetting controller' lines vs %d wire CC.EN=0 writes, %d matched" % (
            len(host_anchors), len(wire_anchors), matched)
    else:
        off, matched, how = clock_offset, None, "supplied"
    if off is None:
        raise SystemExit("cannot align clocks: no anchor pairs; pass --clock-offset")
    out = []
    t_lo, t_hi = tix[0], tix[-1]
    # wire defects a host record may describe: hosts log after the device-visible event
    from .rules import DEFECT, RULES
    wire = sorted((f[1], f[0]) for f in findings if f[1] is not None and RULES[f[2]]["level"] == DEFECT
                  and RULES[f[2]]["tier"] != "S")
    wt_arr = np.array([w[0] for w in wire], dtype=np.int64)
    snap_before, snap_after = int(snap_ms * 1e-3 * SEC), int(SNAP_AFTER_S * SEC)
    snapped = 0
    kept = skipped = outside = 0
    for r in recs:
        if not is_error(r) or (r["source"] == "dmesg" and ANCHOR.search(r["text"])):
            skipped += 1                       # benign, or a clock anchor (the wire already shows the reset)
            continue
        wt = int(round((r["time"] - off) * SEC))
        if wt < t_lo or wt > t_hi:
            outside += 1
            continue
        i = int(np.searchsorted(tix, wt, side="right")) - 1      # last indexed row at or before the record
        pkt = int(pix[max(i, 0)])
        if snap_ms and len(wt_arr):
            j = int(np.searchsorted(wt_arr, wt + snap_after, side="right")) - 1
            if j >= 0 and wt - wt_arr[j] <= snap_before:
                pkt = wire[j][1]
                snapped += 1
        rule, cls = classify(r["text"], r.get("source", "dmesg"))
        out.append((pkt, wt, rule, cls, "%s: %s" % (r.get("source", "dmesg"), r["text"][:240]), (), ()))
        kept += 1
    pickle.dump(out, open(os.path.join(run_dir, "host_findings.pkl"), "wb"))
    # a SIMULATED_README.json next to the documents marks synthetic test evidence (tools/simulate_host_evidence.py)
    simulated = any(os.path.exists(os.path.join(os.path.dirname(os.path.abspath(p)), "SIMULATED_README.json"))
                    for p in (dmesg, events) if p)
    info = {"clock_offset_s": off, "snap_ms": snap_ms, "simulated": simulated,
            "sources": [os.path.abspath(p) for p in (dmesg, events) if p], "alignment": how, "records": len(recs), "error_records_placed": kept,
            "benign_skipped": skipped, "outside_capture_window": outside, "snapped_to_wire_defect": snapped,
            "by_rule": dict(Counter(f[2] for f in out))}
    json.dump(info, open(os.path.join(run_dir, "host_alignment.json"), "w"), indent=1)
    print(json.dumps(info, indent=1))
    return out


def load_all(run_dir):
    """Wire findings plus host findings when a fuse step was run."""
    f = pickle.load(open(os.path.join(run_dir, "findings.pkl"), "rb"))
    hp = os.path.join(run_dir, "host_findings.pkl")
    if os.path.exists(hp):
        f = f + pickle.load(open(hp, "rb"))
        f.sort(key=lambda x: x[0])
    return f
