"""Final isolation: one structured verdict per defect, combining the engine, the atlas and the LLM review.

The engine says WHERE (packets) and WHAT (rules) and WHO (XII.8). The atlas says WHY and HOW TO FIX. The LLM
review says whether the rows really show it. This module fuses the three into one record per incident:

  status        ISOLATED            engine + atlas agree and the LLM confirmed on the rows
                ISOLATED_WIRE_ONLY  wire evidence confirmed, no LLM review ran (dry-run)
                NEEDS_OUTSIDE_EVIDENCE  the wire shows only the symptom; proof needs a listed document
                SYNTHESISED         proven only by outside evidence; on this synthetic trace the document was
                                    simulated (flagged), so the verdict is a placeholder to be re-run on real logs
                DISPUTED            the LLM did not confirm what the engine found - review by hand
  defect        card id + title, pattern, layer, origin
  where         start/end packets and times, first abnormal row, evidence packets
  why           mechanism + typical causes (atlas) + the engine's rule text
  evidence      each finding with its packet and the rows that carry it (compact form)
  fix           corrective / validation action and the test that proves it (atlas), driver path (Linux)

Written to isolation.json (machine) and isolation_report.md (human).
"""
import json
import os
import re
from collections import Counter

from .rules import DEFECT, RULES

ORDER = ["UNKNOWN", "ARTEFACT", "INFO", "SUSPECT", "CONFIRMED"]


def _status(inc, rev, wire_only, simulated_host):
    if not wire_only:
        return "SYNTHESISED" if simulated_host else "ISOLATED"
    if rev is None or "error" in rev:
        return "ISOLATED_WIRE_ONLY" if inc["verdict"] == "CONFIRMED" else "NEEDS_OUTSIDE_EVIDENCE"
    if rev.get("verdict") == "NOT_CONFIRMED":
        # the reviewer attributing the finding to the analyzer/capture is agreement with an ARTEFACT verdict
        if rev.get("responsible") == "test setup" and any(RULES[r]["verdict"] == "ARTEFACT" for r in inc["rules"]):
            return "ISOLATED"
        refuted = set(rev.get("rules_refuted") or [])
        confirmed = set(rev.get("rules_confirmed") or [])
        root_rule = inc["root_cause_node"]["rule"]
        # refuting only a non-root finding while the root stands is a partial disagreement, not a dispute
        if refuted and root_rule not in refuted and inc["first_abnormal"]["rule"] not in refuted:
            return "ISOLATED"
        # nothing refuted and wire rules confirmed: the defect stands, only the attribution is disputed
        # (recorded in who.note as "engine: X; reviewer: Y")
        if not refuted and confirmed & set(inc["rules"]):
            return "ISOLATED"
        return "DISPUTED"
    if rev.get("verdict") == "INCONCLUSIVE" or inc["verdict"] != "CONFIRMED":
        return "NEEDS_OUTSIDE_EVIDENCE"
    return "ISOLATED"


def _rows_for(rows_rec, pkts, limit=6):
    """compact rows for the evidence packets, from the stored incident rows"""
    out = {}
    want = set(pkts)
    for b in rows_rec["blocks"]:
        for r in b["rows"]:
            if r.startswith("Packet="):
                p = int(r.split("|")[0].split("=")[1])
                if p in want and p not in out:
                    out[p] = r[:260]
    for r in rows_rec["key_rows"]:
        if r.startswith("Packet="):
            p = int(r.split("|")[0].split("=")[1])
            if p in want and p not in out:
                out[p] = r[:260]
    return [{"pkt": p, "row": out[p]} for p in sorted(out)][:limit]


def build(run_dir, simulated_host=None):
    incs = json.load(open(os.path.join(run_dir, "incidents.json")))
    rows = {}
    for line in open(os.path.join(run_dir, "incident_rows.jsonl")):
        r = json.loads(line)
        rows[r["id"]] = r
    rev = {}
    rp = os.path.join(run_dir, "llm_reviews.jsonl")
    if os.path.exists(rp):
        for line in open(rp):
            r = json.loads(line)
            rev[r["id"]] = r
    if simulated_host is None:
        hp = os.path.join(run_dir, "host_alignment.json")
        simulated_host = json.load(open(hp)).get("simulated", False) if os.path.exists(hp) else False
    out = []
    for inc in incs:
        defects = [f for f in inc["findings"] if f["level"] == DEFECT]
        wire = [f for f in defects if not f["rule"].startswith("H.")]
        host = [f for f in defects if f["rule"].startswith("H.")]
        r = rev.get(inc["id"])
        top = inc["atlas_candidates"][0] if inc["atlas_candidates"] else None
        ex = inc.get("explanation") or {}
        llm_card = r.get("card_id") if r and r.get("card_id") not in (None, "none") else None
        chosen = top["card_id"] if top else None
        if llm_card and llm_card != chosen and any(c["card_id"] == llm_card for c in inc["atlas_candidates"][:3]):
            chosen = llm_card                    # the reviewer saw the rows; it may pick a lower-ranked candidate
            ex = next((c for c in [ex] if c.get("card_id") == llm_card), ex)
        status = _status(inc, r, bool(wire), simulated_host)
        rc = set((r or {}).get("rules_confirmed") or [])
        rr = set((r or {}).get("rules_refuted") or [])
        ev = []
        for f in defects[:12]:
            ev.append({"rule": f["rule"], "verdict": f["verdict"], "pkt": f["pkt"], "line": f.get("line"),
                       "role": f.get("role", "independent"), "detail": f["detail"][:200],
                       "llm": ("confirmed" if f["rule"] in rc else "refuted" if f["rule"] in rr else "unchecked")
                       if r and "error" not in r else "not reviewed",
                       "rows": _rows_for(rows[inc["id"]], [f["pkt"]] + f["related_pkts"][:3], 4)})
        who = inc["attribution"]["origin"]
        if r and r.get("responsible") and r["responsible"] != "undetermined" and r["responsible"] != who:
            who_note = "engine: %s; reviewer: %s" % (who, r["responsible"])
        else:
            who_note = who
        rec = {
            "id": inc["id"], "status": status,
            "defect": {"card_id": chosen, "title": (top or {}).get("title"), "pattern": ex.get("pattern"),
                       "layer": inc["layer"], "symptom_class": ex.get("symptom_class"),
                       "visibility": ex.get("visibility"),
                       "alternatives": [c["card_id"] for c in inc["atlas_candidates"][1:3]],
                       "ambiguity_group": (top or {}).get("equally_consistent_with", [])},
            "where": {"csv_lines": inc.get("csv_lines"),
                      "start_pkt": inc["start_pkt"], "end_pkt": inc["end_pkt"], "start_time": inc["start_time"],
                      "end_time": inc["end_time"], "first_abnormal": inc["first_abnormal"],
                      "root_cause_node": inc["root_cause_node"], "evidence_pkts": inc["key_pkts"][:20],
                      "llm_start_pkt": r.get("defect_start_pkt") if r else None,
                      "llm_end_pkt": r.get("defect_end_pkt") if r else None,
                      "llm_root_pkt": r.get("root_pkt") if r else None,
                      "llm_cascade_pkts": r.get("cascade_pkts") if r else None},
            "who": {"origin": who, "note": who_note, "decided_by": inc["attribution"]["rule"],
                    "card_badge": inc["attribution"]["card_badge"],
                    "evidence_to_collect": inc["attribution"]["evidence_to_collect"]},
            "why": {"mechanism": ex.get("what_happens"), "typical_causes": ex.get("why"),
                    "how_it_shows_up": ex.get("how_it_shows_up"), "spec_basis": ex.get("spec_basis"),
                    "engine_rules": {k: RULES[k]["text"] for k in inc["rules"]}},
            "context": {"task": inc["task"], "nvme_commands": inc["nvme_commands"][:2]},
            "evidence": ev,
            "outside_evidence": [{"pkt": f["pkt"], "source": f["detail"].split(":")[0], "text": f["detail"][:200]}
                                 for f in host[:6]],
            "fix": {"corrective_action": ex.get("fix_or_test"), "how_to_prove": ex.get("how_to_prove"),
                    "what_else_proves_it": ex.get("what_else_proves_it"), "driver_path": ex.get("driver_path"),
                    "false_positive_limits": ex.get("false_positive_limits")},
            "partial_refutation": sorted(rr - {inc["root_cause_node"]["rule"], inc["first_abnormal"]["rule"]})
            if r and rr and status != "DISPUTED" else [],
            "llm_review": ({"backend": r.get("backend"), "model": r.get("model"), "verdict": r.get("verdict"),
                            "card_id": r.get("card_id"),
                            "responsible": r.get("responsible"), "summary": r.get("summary"),
                            "rules_confirmed": sorted(rc), "rules_refuted": sorted(rr),
                            "hypotheses": r.get("hypotheses", []), "needs": r.get("needs", []),
                            "cited_unseen_pkts": r.get("cited_unseen_pkts", []),
                            "error": r.get("error")} if r else None),
            # atlas IX.4.1 "acceptance test for an AI conclusion", evaluated mechanically where possible
            "acceptance": {
                "claims_cite_shown_rows": (not r.get("cited_unseen_pkts")) if r and "error" not in r else None,
                "rule_named": (bool(rc or rr) if wire else None) if r and "error" not in r else None,
                "reproduced_by_script_on_full_file": True,
                "first_abnormal_event_identified": True,
                "root_and_cascade_cited_from_shown_rows": (not r.get("cited_unseen_pkts") and
                                                           isinstance(r.get("root_pkt"), int))
                if r and "error" not in r else None,
                "cascade_separated_by_engine": True,
                "hypotheses_labelled": (all(h.strip() for h in r.get("hypotheses", [])) and
                                        ("HYPOTHESIS" in (r.get("summary") or "") or not r.get("hypotheses")))
                if r and "error" not in r else None,
                "capture_context_given": True,
            },
        }
        out.append(rec)
    json.dump(out, open(os.path.join(run_dir, "isolation.json"), "w"), indent=1)
    summary = {"incidents": len(out), "status": dict(Counter(x["status"] for x in out)),
               "by_origin": dict(Counter(x["who"]["origin"] for x in out)),
               "by_layer": dict(Counter(x["defect"]["layer"] for x in out)),
               "llm_reviewed": sum(1 for x in out if x["llm_review"] and not x["llm_review"].get("error")),
               "llm_confirmed": sum(1 for x in out if x["llm_review"] and x["llm_review"].get("verdict") == "CONFIRMED"),
               "simulated_outside_evidence": simulated_host}
    cp = os.path.join(run_dir, "capture_assessment.json")
    if os.path.exists(cp):
        ca = json.load(open(cp))
        summary["capture_assessment"] = {k: ca.get(k) for k in ("capture_adequate", "cannot_show", "recapture", "error")}
    json.dump(summary, open(os.path.join(run_dir, "isolation_summary.json"), "w"), indent=1)
    write_md(run_dir, out, summary)
    print(json.dumps(summary, indent=1))
    return out


STATUS_WORD = {"ISOLATED": "isolated", "ISOLATED_WIRE_ONLY": "isolated from the packets alone",
               "NEEDS_OUTSIDE_EVIDENCE": "needs host evidence", "DISPUTED": "disputed", "SYNTHESISED": "synthetic"}
ROLE_WORD = {"root": "first abnormal packet", "cascade": "follow-on packet", "independent": "independent",
             "context": "context"}
VERDICT_WORD = {"CONFIRMED": "confirmed", "NOT_CONFIRMED": "not confirmed", "INCONCLUSIVE": "inconclusive"}


def _defect_number(inc_id):
    try:
        return str(int(str(inc_id).split("-")[1]))
    except (IndexError, ValueError):
        return str(inc_id)


def _who_line(who):
    """'device - decided because the first bad TLP was sent upstream (rule R4)' instead of the raw rule text."""
    rule = who.get("decided_by") or ""
    rid, _, text = rule.partition(" ")
    if not (rid.startswith("R") and text):
        return "- **Who**: %s%s" % (who["note"], (" (%s)" % rule) if rule else "")
    m = re.match(r"transmitter of the first bad TLP \((Upstream|Downstream)\)", text)
    if m:
        return "- **Who**: %s - decided because the first bad TLP was sent %s (rule %s)" % (who["note"], m.group(1).lower(), rid)
    return "- **Who**: %s - decided by rule %s: %s" % (who["note"], rid, text)


def write_md(run_dir, out, summary):
    L = ["# Defect isolation report", "",
         "%d incidents. Status: %s." % (summary["incidents"], ", ".join("%s %d" % kv for kv in summary["status"].items())),
         "Second opinion given on %d, confirmed %d.%s" % (summary["llm_reviewed"], summary["llm_confirmed"],
                                                          " Outside evidence on this trace is SIMULATED." if
                                                          summary["simulated_outside_evidence"] else ""), ""]
    for x in out:
        d, w, who, why, fx = x["defect"], x["where"], x["who"], x["why"], x["fix"]
        L.append("## Defect %s - %s - %s %s" % (_defect_number(x["id"]), STATUS_WORD.get(x["status"], x["status"].lower()),
                                              d["card_id"] or "-", d["title"] or ""))
        cl = w.get("csv_lines") or {}
        L.append("- **Where**: CSV lines %s-%s, packets %d-%d (%s .. %s). First abnormal row: line %s, packet #%d: %s - %s" %
                 (cl.get("start", "?"), cl.get("end", "?"), w["start_pkt"], w["end_pkt"], w["start_time"],
                  w["end_time"], cl.get("first_abnormal", "?"), w["first_abnormal"]["pkt"],
                  w["first_abnormal"]["rule"], w["first_abnormal"]["detail"][:160]))
        L.append(_who_line(who))
        if why.get("mechanism"):
            L.append("- **Why**: %s" % why["mechanism"][:400])
        if why.get("typical_causes"):
            L.append("- **Typical causes**: %s" % why["typical_causes"][:400])
        L.append("- **Context**: %s%s" % (x["context"]["task"], ("; command " + ", ".join(
            "%s CID %s SQ%s" % (c["name"], c["cid"], c["sqid"]) for c in x["context"]["nvme_commands"]))
            if x["context"]["nvme_commands"] else ""))
        L.append("- **Evidence** (rule, verdict, CSV line and packet):")
        for e in x["evidence"][:8]:
            agree = {"confirmed": ", model agrees", "refuted": ", model disagrees"}.get(e["llm"], "")
            L.append("  - [%s%s] rule %s - %s - CSV line %s packet #%d: %s" % (
                ROLE_WORD.get(e["role"], e["role"]), agree, e["rule"], VERDICT_WORD.get(e["verdict"], str(e["verdict"]).lower()),
                e.get("line", "?"), e["pkt"], e["detail"][:140]))
            for rr in e["rows"][:2]:
                L.append("    - `%s`" % rr["row"][:200])
        for h in x["outside_evidence"][:3]:
            L.append("  - outside evidence @%d: %s" % (h["pkt"], h["text"][:160]))
        if fx.get("corrective_action"):
            L.append("- **Fix / validation**: %s" % fx["corrective_action"][:400])
        if fx.get("driver_path"):
            L.append("- **Driver path**: %s" % fx["driver_path"][:300])
        r = x["llm_review"]
        if r and not r.get("error"):
            L.append("- **Second opinion (%s, %s)**: %s - %s" % (r["model"], r["backend"],
                                                               VERDICT_WORD.get(r["verdict"], str(r["verdict"]).lower()),
                                                               (r.get("summary") or "")[:600]))
            if r.get("hypotheses"):
                L.append("  - hypotheses: " + " | ".join(h[:160] for h in r["hypotheses"][:3]))
            if r.get("needs"):
                L.append("  - needs: " + " | ".join(n[:120] for n in r["needs"][:3]))
        elif r and r.get("error"):
            L.append("- **Second opinion**: not available (%s)" % r["error"][:120])
        L.append("")
    open(os.path.join(run_dir, "isolation_report.md"), "w").write("\n".join(L))
