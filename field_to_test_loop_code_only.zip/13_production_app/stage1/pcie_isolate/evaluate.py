"""Scoring against the generator's ground truth (used ONLY for evaluation, never by the detectors).

Ground truth per episode: card_id, packet_first..packet_last, key packets, visibility.
"""
import bisect
import csv
import os
from collections import Counter, defaultdict

from .rules import APPROACH_TIERS, DEFECT, RULES


class Truth:
    def __init__(self, sidecar_dir):
        rows = list(csv.DictReader(open(os.path.join(sidecar_dir, "csv_row_scenario_index.csv"))))
        self.eps = sorted(rows, key=lambda r: int(r["packet_first"]))
        for e in self.eps:
            e["first"], e["last"] = int(e["packet_first"]), int(e["packet_last"])
            e["keys"] = [int(x) for x in e["key_packets"].split(";") if x]
        self.starts = [e["first"] for e in self.eps]
        self.by_card = {e["card_id"]: e for e in self.eps}

    def episode_of(self, pkt):
        i = bisect.bisect_right(self.starts, pkt) - 1
        if i >= 0 and pkt <= self.eps[i]["last"]:
            return self.eps[i]
        return None

    AFTERMATH = 3000

    def aftermath_of(self, pkt):
        """The host's recovery right after an episode (controller reset / retrain that the generator runs
        to restore the baseline) is a consequence of that episode, not healthy traffic."""
        i = bisect.bisect_right(self.starts, pkt) - 1
        if i >= 0 and self.eps[i]["last"] < pkt <= self.eps[i]["last"] + self.AFTERMATH:
            return self.eps[i]
        return None

    def episodes_overlapping(self, lo, hi):
        i = max(0, bisect.bisect_right(self.starts, lo) - 1)
        out = []
        while i < len(self.eps) and self.eps[i]["first"] <= hi:
            e = self.eps[i]
            if e["last"] >= lo:
                out.append(e)
            i += 1
        return out


def is_defect(rule):
    return RULES[rule]["level"] == DEFECT


def score_findings(findings, truth, approach):
    """Episode-level detection for one approach (tier subset)."""
    tiers = APPROACH_TIERS[approach]
    hit = defaultdict(list)
    fp = Counter()
    fp_pkts = []
    aftermath = Counter()
    for f in findings:
        rule = f[2]
        r = RULES[rule]
        if r["tier"] not in tiers or r["level"] != DEFECT:
            continue
        e = truth.episode_of(f[0])
        if e is None:
            if truth.aftermath_of(f[0]) is not None:
                aftermath[rule] += 1
                continue
            fp[rule] += 1
            fp_pkts.append(f[0])
        else:
            hit[e["card_id"]].append(f)
    by_vis = defaultdict(lambda: [0, 0])
    key_loc = 0
    key_n = 0
    for e in truth.eps:
        v = e["pex_visibility"]
        by_vis[v][1] += 1
        if e["card_id"] in hit:
            by_vis[v][0] += 1
            if e["keys"]:
                key_n += 1
                pk = [f[0] for f in hit[e["card_id"]]] + [p for f in hit[e["card_id"]] for p in f[6] if p]
                if any(abs(p - k) <= 32 for p in pk for k in e["keys"]):
                    key_loc += 1
    # false-positive clusters: distinct places (>5000 packets apart)
    clusters = 0
    last = -10 ** 12
    for p in sorted(fp_pkts):
        if p - last > 5000:
            clusters += 1
        last = p
    n = len(truth.eps)
    det = sum(1 for e in truth.eps if e["card_id"] in hit)
    return {
        "approach": approach,
        "episodes_detected": det,
        "episodes_total": n,
        "recall": round(det / n, 4),
        "by_visibility": {k: {"detected": a, "total": b} for k, (a, b) in sorted(by_vis.items())},
        "key_row_localised": key_loc,
        "episodes_with_key_rows_detected": key_n,
        "false_positive_findings": sum(fp.values()),
        "false_positive_places": clusters,
        "false_positive_rules": dict(fp.most_common()),
        "aftermath_findings": sum(aftermath.values()),
        "missed_cards": [e["card_id"] for e in truth.eps if e["card_id"] not in hit],
    }
