"""Approach C: unsupervised statistics over the capture itself (no labels, no protocol verdicts).

1. Rarity windows: every 1024-packet window holds the set of row "tokens" (row shape: type, direction,
   status, flags, decoded command/opcode when payload is available).  A token present in <= rare_frac of
   all windows is rare; a window holding rare tokens is reported once, at its first rare row.
2. Timing outliers: every timing series the engine sampled (fetch latency, command latency per class,
   completion latency, CQ consumer lag, L1 exit, ...) is compared with its own distribution:
   threshold = max(k x median, quantile q, physical floor).  Floors are modeled minimums so a fast,
   tight healthy distribution does not turn microsecond jitter into findings.
3. Window shape: per-window max inter-TLP gap while traffic flows (stalls).
"""
import math
from collections import Counter

import numpy as np

from .schema import MS, US

#                        k      floor (ps)        what is anomalous
METRICS = {
    "fetch_latency":           (10, 50 * US),     # doorbell -> SQE fetch
    "read_media_latency":      (10, 1 * MS),      # SQE -> first data TLP of a read (device media access)
    "data_phase":              (10, 2 * MS),      # SQE -> last data TLP
    "cqe_after_data":          (10, 1 * MS),      # last data -> CQE
    "cmd_latency_read":        (10, 1 * MS),
    "cmd_latency_read_big":    (10, 1 * MS),
    "cmd_latency_write":       (10, 500 * US),
    "cmd_latency_write_big":   (10, 500 * US),
    "cmd_latency_flush":       (10, 20 * MS),
    "cmd_latency_other":       (10, 5 * MS),
    "cmd_latency_admin":       (10, 50 * MS),
    "cmd_latency_admin_big":   (10, 50 * MS),
    "completion_latency_dev":  (10, 20 * US),     # SSD MRd -> host CplD
    "completion_latency_host": (10, 100 * US),    # host MMIO read -> SSD CplD
    "cq_head_lag":             (10, 500 * US),    # CQE -> host CQ head doorbell
    "cq_batch":                (0, 5),            # CQEs released by one CQ head doorbell
    "sq_batch":                (0, 8),            # commands published by one SQ tail doorbell
    "queue_depth":             (0, 64),
    "refclk_to_exit":          (10, 300 * US),    # CLKREQ# -> electrical idle exit
    "l1_exit":                 (4, 100 * US),     # CLKREQ#/EI exit -> traffic
    "config_to_driver":        (10, 100 * MS),    # first config request -> first MMIO
    "ack_latency":             (10, 5 * US),
}


# protocol-normal lifecycle activity: rare in a long capture but never a defect by itself
LIFECYCLE = ("E|Link Up", "E|Link Down", "E|Speed Change", "E|Electrical Idle", "E|CLKREQ", "E|Receiver Detect|",
             "D|Data Link Feature", "D|InitFC", "D|PM_Enter_L23", "D|PM_Request_Ack", "D|PM_Active_State",
             "O|TS1|D|0 0 0 0 0 0 00", "O|TS1|U|0 0 0 0 0 0 00", "O|TS2|D|0 0 0 0 0 0 00", "O|TS2|U|0 0 0 0 0 0 00",
             "O|EIOS", "O|EIEOS", "O|SDS", "SQE|A|01|", "SQE|A|05|", "SQE|A|00|", "SQE|A|04|", "SQE|A|06|00", "SQE|A|06|01", "SQE|A|06|02",
             "SQE|A|09|07", "SQE|A|0C|", "SQE|IO|09|", "SQE|IO|00|", "CQE|0|00|", "LTR|", "T|Msg|U|Latency",
             "T|Msg|D|PME_Turn_Off", "T|Msg|U|PME_TO_Ack", "T|CfgRd0|D|", "T|CfgWr0|D|", "T|Cpl|U|SC|")


def rare_windows(win_tokens, n_windows, rare_frac=0.002, max_rare=None):
    df = Counter()
    for toks in win_tokens.values():
        df.update(toks.keys())
    for tok in list(df):
        if tok.startswith(LIFECYCLE):
            del df[tok]
    limit = max(2, int(rare_frac * n_windows))
    rare = {tok: c for tok, c in df.items() if c <= limit}
    out = []
    for w, toks in win_tokens.items():
        hits = sorted(((rare[tok], pkt, tok) for tok, pkt in toks.items() if tok in rare))
        if not hits:
            continue
        c, pkt, tok = hits[0]
        idf = math.log(n_windows / c)
        first = min(p for _, p, _ in hits)
        out.append((first, w, tok, idf, [h[2] for h in hits[:5]]))
    return out, rare


def timing_outliers(stat):
    out = []
    for name, (vals, pkts) in stat.items():
        base = name if name in METRICS else None
        if base is None:
            continue
        a = np.frombuffer(vals, dtype=np.int64) if not isinstance(vals, list) else np.array(vals, dtype=np.int64)
        p = np.frombuffer(pkts, dtype=np.int64) if not isinstance(pkts, list) else np.array(pkts, dtype=np.int64)
        if len(a) < 20:
            continue
        k, floor = METRICS[base]
        med = float(np.median(a))
        thr = max(k * med, floor)
        for i in np.nonzero(a > thr)[0]:
            out.append((int(p[i]), name, int(a[i]), med, thr))
    return out


def latency_shifts(stat, run=16, factor=4.0, media_run=8, media_factor=2.5):
    """Change-point style check: a rolling median of `run` consecutive commands of one class that sits
    `factor` x above the class median (throttling, cliffs, slow media) - catches shifts a per-command
    outlier test misses."""
    out = []
    for name in ("cmd_latency_read_lowqd", "cmd_latency_read_big_lowqd", "cmd_latency_write_lowqd",
                 "cmd_latency_write_big_lowqd"):
        if name not in stat:
            continue
        vals, pkts = stat[name]
        a = np.array(vals, dtype=np.int64)
        p = np.array(pkts, dtype=np.int64)
        if len(a) < 4 * run:
            continue
        med = float(np.median(a))
        win = np.lib.stride_tricks.sliding_window_view(a, run)
        rm = np.median(win, axis=1)
        hot = np.nonzero(rm > factor * med)[0]
        last = -10 ** 9
        for i in hot:
            if i - last >= run:
                out.append((int(p[i]), name, float(rm[i]), med))
            last = i
    # device media access time (SQE -> first data) barely depends on load or size: a sustained shift means
    # throttling, missing HMB, media retries or garbage collection
    if "read_media_latency" in stat:
        vals, pkts = stat["read_media_latency"]
        a = np.array(vals, dtype=np.int64)
        p = np.array(pkts, dtype=np.int64)
        if len(a) >= 4 * media_run:
            med = float(np.median(a))
            run = []
            # runs of consecutive slow reads (>= media_run/2), split where slow reads are > 500 packets apart
            for v, pk in zip(a, p):
                if v > media_factor * med and (not run or pk - run[-1][1] <= 500):
                    run.append((v, pk))
                    continue
                if len(run) >= media_run // 2:
                    out.append((int(run[0][1]), "read_media_latency", float(np.median([x[0] for x in run])), med))
                run = [(v, pk)] if v > media_factor * med else []
            if len(run) >= media_run // 2:
                out.append((int(run[0][1]), "read_media_latency", float(np.median([x[0] for x in run])), med))
    return out


def window_stalls(win_feat, k=50, floor=5 * MS):
    gaps = np.array([w[2] for w in win_feat.values() if w[3] > 8], dtype=np.int64)
    if not len(gaps):
        return []
    med = float(np.median(gaps))
    thr = max(k * med, floor)
    out = []
    last = -10 ** 9
    for w in sorted(win_feat):
        f = win_feat[w]
        if f[3] > 8 and f[2] > thr:
            if w - last > 64:                  # one finding per stall episode, not per window
                out.append((w, f[2], med, f[6]))
            last = w
    return out


def statistical_findings(eng, rare_frac=0.002):
    """Returns findings in the engine's tuple format, rule tier S."""
    shift = eng.WINDOW_SHIFT
    n_windows = (eng.last_pkt >> shift) + 1
    wt = {w: f[5] for w, f in eng.win_feat.items()}
    out = []
    rw, rare = rare_windows(eng.win_tokens, n_windows, rare_frac)
    rare_pct = 100.0 * max(2, int(rare_frac * n_windows)) / max(1, n_windows)   # the cut-off rare_windows applied
    for first, w, tok, idf, toks in rw:
        out.append((first, wt.get(w), "S.RARE_WINDOW", tok[:48],
                    "a packet type seen in fewer than %.1f %% of this capture's %d-packet windows: %s" % (
                        rare_pct, 1 << shift, "; ".join(toks)), (), ()))
    for pkt, name, v, med, thr in timing_outliers(eng.stat):
        out.append((pkt, wt.get(pkt >> shift), "S.LATENCY", name,
                    "%s = %.1f us (capture median %.1f us, threshold %.1f us)" % (name, v / 1e6, med / 1e6, thr / 1e6)
                    if not name.endswith(("batch", "depth")) else
                    "%s = %d (capture median %g, threshold %g)" % (name, v, med, thr), (), ()))
    for pkt, name, rm, med in latency_shifts(eng.stat):
        out.append((pkt, wt.get(pkt >> shift), "S.FEATURE_OUTLIER", "latency_shift",
                    "%s: rolling median of 16 commands %.1f us vs capture median %.1f us" % (name, rm / 1e6, med / 1e6),
                    (), ()))
    for w, gap, med, gpkt in window_stalls(eng.win_feat):
        out.append((gpkt or (w << shift), wt.get(w), "S.FEATURE_OUTLIER", "stall",
                    "traffic gap of %.2f ms inside an active window (median max-gap %.1f us)" % (gap / 1e9, med / 1e6),
                    (), ()))
    return out
