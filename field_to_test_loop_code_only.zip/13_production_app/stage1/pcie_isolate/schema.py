"""Column layout of the 113-column export and small parsers."""
import csv
import os

HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT = os.path.dirname(os.path.dirname(HERE))
_CANDIDATES = (os.path.join(os.path.dirname(HERE), "reference", "final_113_columns.csv"),   # bundled with the package
               os.path.join(PROJECT, "01_input_files", "final_113_columns.csv"))               # project layout
REFERENCE_HEADER = next((p for p in _CANDIDATES if os.path.exists(p)), _CANDIDATES[0])

PS = 1
NS = 1000
US = 1000 * NS
MS = 1000 * US
SEC = 1000 * MS


def reference_header():
    with open(REFERENCE_HEADER, newline="", encoding="utf-8-sig") as f:
        return next(csv.reader(f))


class Cols:
    """Index of every column the engine reads (exact export spelling)."""

    NAMES = {
        "MARKER": "Marker", "PKT": "Packet", "DIR": "Link Dir", "OS": "Ord.Set Type", "DLLP": "DLLP Type",
        "TLP": "TLP Type", "EVT": "Link Event", "PSN": "PSN", "ACKSEQ": "AckNak Seq Num", "HDRFC": "HdrFC",
        "DATAFC": "DataFC", "TC": "TC", "TH": "TH", "TD": "TD", "EP": "EP", "ATTR": "Attributes", "AT": "AT",
        "LEN": "Length", "RID": "RequesterID", "TAG": "Tag", "CPLID": "CompleterID", "ADDR": "Address",
        "DEVID": "DeviceID", "REG": "Register", "FBE": "st BE", "LBE": "Last BE", "CPLST": "Cpl Status",
        "BCNT": "Byte Cnt", "BCM": "BCM", "LWR": "Lwr Addr", "ROUTE": "Msg Routing", "MSG": "Message Code",
        "TSLINK": "TS Link", "TSLANE": "TS Lane", "TCTL": "Training Control", "TSRATE": "TS Data Rate",
        "EQCTL": "TS Gen3 Eq Control", "PRE": "TS Gen3 Pre-Cursor", "CUR": "TS Gen3 Cursor",
        "POST": "TS Gen3 Post-Cursor", "SLAVE": "Slave Address", "ARP": "ARP Command", "LCRC": "LCRC",
        "ECRC": "ECRC", "CRC16": "CRC 16", "DATA": "DATA", "TS": "Time Stamp", "SNOOPV": "Value (Snoop)",
        "SNOOPS": "Scale (Snoop)", "NSNOOPV": "Value (No-Snoop)", "NSNOOPS": "Scale (No-Snoop)",
        "PTMD": "PTM Propagation Delay", "FSUP": "Feature Support", "PEC": "PEC",
        "JAMMER": "Jammer Phase", "JACTION": "Action", "CXL": "CXL Pkt Type",
    }

    REQUIRED = ("Packet", "Time Stamp", "Link Dir", "TLP Type")

    def __init__(self, header):
        """Header names are matched exactly first, then case/space/underscore-insensitively
        (e.g. 'AckNak_Seq_Num' from older exports).  Optional columns that are absent are mapped to padding
        fields appended to every row (Cols.pad), so every rule sees an empty value instead of failing."""
        norm = lambda n: "".join(ch for ch in n.lower() if ch.isalnum())
        idx = {n: i for i, n in enumerate(header)}
        nidx = {norm(n): i for i, n in enumerate(header)}
        self.missing = []
        width = len(header)
        for k, v in self.NAMES.items():
            i = idx.get(v, nidx.get(norm(v)))
            if i is None:
                if v in self.REQUIRED:
                    raise ValueError("export is missing required column %r" % v)
                self.missing.append(v)
                i = width + len(self.missing) - 1
            setattr(self, k, i)
        self.pad = [""] * len(self.missing)
        self.header = list(header) + self.missing


def ts_ps(s):
    """'0123.456789012345s' -> integer picoseconds."""
    sec, frac = s[:-1].split(".")
    return int(sec) * 1000000000000 + int(frac)


def fmt_t(ps):
    return "%d.%012ds" % divmod(ps, 1000000000000)


def fmt_dt(ps):
    a = abs(ps)
    if a >= SEC:
        return "%.3f s" % (ps / SEC)
    if a >= MS:
        return "%.3f ms" % (ps / MS)
    if a >= US:
        return "%.3f us" % (ps / US)
    return "%.1f ns" % (ps / NS)


def addr_int(s):
    return int(s.replace(":", ""), 16) if s else None


def nbytes_of(data):
    """DATA summary 'N B' -> N; hex -> byte count; '' -> 0."""
    if not data:
        return 0
    if data.endswith(" B"):
        return int(data[:-2])
    return len(data.split())
