#!/usr/bin/env python3
"""Build the OUTSIDE-THE-CSV payload evidence for an existing summary-DATA trace.

A real analyzer can re-export the same capture with payload bytes ("expand data"), or export
its NVMe-decoded view.  This tool produces the equivalent for the synthetic 4 GB trace:
it re-runs the deterministic generator in hex mode, writes NO CSV, and for every TLP with a
payload records

    Packet, nbytes, head_hex, crc32

head_hex = the whole payload when it is <= 64 bytes (doorbells, register values, MSI-X data,
SQEs, CQEs, PRP-list entries) and the first 16 bytes otherwise (log-page / identify headers,
user-data block headers); crc32 = digest of the whole payload (data-integrity ledger).

Alignment proof: every row is also rendered in its summary form ('N B') and hashed; the
SHA-256 must equal the manifest hash of the summary CSV, otherwise the sidecar is rejected.

Usage
  build_payload_sidecar.py --target-bytes 4000000000 \
      --expect-sha256 8ce018c7... --out DIR
"""
import argparse
import csv
import hashlib
import io
import json
import os
import sys
import shutil
import tempfile
import time
import zlib

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
GEN = os.path.join(ROOT, "02_generator_and_validator_code")
sys.path.insert(0, GEN)

import tracegen_core  # noqa: E402
from tracegen_core import COL, HEADER  # noqa: E402

DATA_I = COL["DATA"]
PKT_I = COL["Packet"]
TLP_I = COL["TLP Type"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target-bytes", type=int, default=4000000000)
    ap.add_argument("--seed", type=int, default=20261024)
    ap.add_argument("--expect-sha256", default=None)
    ap.add_argument("--out", required=True)
    ap.add_argument("--write-csv", default=None, help="also write the summary CSV here (calibration traces)")
    ap.add_argument("--keep-truth", action="store_true",
                    help="keep the generator's ground-truth sidecars (calibration traces only)")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    # the generator also writes its ground-truth sidecars; keep them away from the evidence unless asked
    side_tmp = os.path.join(a.out, "_generator_truth") if a.keep_truth else tempfile.mkdtemp(prefix="gen_truth_")
    os.makedirs(side_tmp, exist_ok=True)
    out_path = os.path.join(a.out, "payload_sidecar.csv")
    tmp_path = out_path + ".partial"

    sha = hashlib.sha256()
    buf = io.StringIO()
    hw = csv.writer(buf, lineterminator="\n")
    hw.writerow(HEADER)
    sha.update(buf.getvalue().encode("utf-8"))
    side = open(tmp_path, "w", newline="")
    sw = csv.writer(side, lineterminator="\n")
    sw.writerow(["Packet", "nbytes", "head_hex", "crc32"])
    stats = {"rows": 0, "payload_rows": 0, "full_payload_rows": 0}
    csv_out = open(a.write_csv, "w", encoding="utf-8") if a.write_csv else None
    if csv_out:
        csv_out.write(buf.getvalue())

    def emit_line(self, row):
        data = row[DATA_I]
        if data and not data.endswith(" B"):
            b = bytes.fromhex(data.replace(" ", ""))
            n = len(b)
            head = b if n <= 64 else b[:16]
            sw.writerow([row[PKT_I], n, head.hex(), "%08x" % (zlib.crc32(b) & 0xFFFFFFFF)])
            stats["payload_rows"] += 1
            stats["full_payload_rows"] += n <= 64
            row = row[:]
            row[DATA_I] = "%d B" % n
        buf.seek(0)
        buf.truncate()
        hw.writerow(row)
        line = buf.getvalue()
        sha.update(line.encode("utf-8"))
        if csv_out:
            csv_out.write(line)
        self.rows += 1
        self.bytes_written += 113 + sum(len(x) for x in row if x)   # same accounting as summary mode
        stats["rows"] += 1

    tracegen_core.Engine._emit_line = emit_line
    import generate_synthetic_pcie_trace as gen  # noqa: E402

    sys.argv = ["gen", "--output", os.devnull, "--target-bytes", str(a.target_bytes), "--seed", str(a.seed),
                "--data-format", "hex", "--sidecar-dir", side_tmp]
    t0 = time.time()
    gen.main()
    side.close()
    if csv_out:
        csv_out.close()
    digest = sha.hexdigest()
    ok = a.expect_sha256 is None or digest == a.expect_sha256
    info = {"summary_csv_sha256_reproduced": digest, "expected": a.expect_sha256, "aligned": ok,
            "rows": stats["rows"], "payload_rows": stats["payload_rows"],
            "full_payload_rows(<=64B)": stats["full_payload_rows"], "elapsed_s": round(time.time() - t0, 1),
            "meaning": "head_hex = full payload if <=64 B else first 16 B; crc32 over the full payload"}
    json.dump(info, open(os.path.join(a.out, "payload_sidecar_manifest.json"), "w"), indent=2)
    print(json.dumps(info, indent=2))
    if not ok:
        sys.exit("ALIGNMENT FAILED: payload sidecar does not belong to the expected CSV")
    os.replace(tmp_path, out_path)
    if not a.keep_truth:
        shutil.rmtree(side_tmp, ignore_errors=True)


if __name__ == "__main__":
    main()
