#!/usr/bin/env python3
"""SIMULATED outside evidence for a synthetic capture (for testing the fusion pipeline only).

A real lab collects these documents next to the analyzer capture (atlas XII.5, E01-E10).  The synthetic
generator has no host, so this tool writes what the host / device / lab tools would have recorded for each
injected fault, in the formats the fusion step parses:

  dmesg_x.txt        `dmesg -x` style kernel log on the HOST clock (analyzer time + offset, small jitter)
  host_events.jsonl  records of other tools (nvme-cli logs, fio verify, blktrace, BMC, fabric, lab, analyzer settings)

Content per fault comes from the atlas card of the injected episode: the E-codes the card names select the
tool, and the card's "How it shows up" quotes (or "What else proves it" / "Why it occurs") become the message
text - the description of what that tool would show.  Card ids and titles are never written.  Benign background
lines (boot, mounts, queue setup, periodic service messages) are mixed in so the fusion must ignore noise.
Controller resets the analyzer sees also produce the kernel's "resetting controller" line, which the fusion
uses as clock anchors.  Results that depend on this tool measure the pipeline, not discovery.

Each record is timed at the episode's evidence packet (last key packet, else its middle packet) read from the
capture, plus a logging delay (20-80% of the way to the episode's last packet, at most 300 us).

Usage: simulate_host_evidence.py --event-log scenario_event_log.jsonl --csv TRACE.csv --out DIR [--offset 37.25]
"""
import argparse
import csv
import json
import os
import random
import re

HERE = os.path.dirname(os.path.abspath(__file__))
CARDS = os.path.join(os.path.dirname(os.path.dirname(HERE)), "01_input_files", "atlas_cards_raw.json")
SOURCE = {"E01": "dmesg", "E02": "lspci", "E03": "nvme-log", "E04": "fio-verify", "E05": "blktrace", "E06": "bmc",
          "E07": "scope", "E08": "other-path", "E09": "lab", "E10": "fabric"}
BENIGN = ["EXT4-fs (nvme0n1p2): re-mounted. Quota mode: none.", "systemd-journald[412]: Received client request to "
          "flush runtime journal.", "nvme nvme0: 8/0/0 default/read/poll queues", "audit: type=1400 apparmor=\"STATUS\"",
          "usb 1-4: new high-speed USB device number 3 using xhci_hcd", "wlp2s0: associated", "NET: Registered "
          "PF_ALG protocol family", "nvme nvme0: Shutdown timeout set to 8 seconds", "Bluetooth: RFCOMM ver 1.11"]


def text_for(card):
    k = card["card"]
    q = re.findall(r'"([^"]{6,140})"', k.get("How it shows up", ""))
    if q:
        return q[0]
    for f in ("How it shows up", "What else proves it", "Why it occurs", "What happens"):
        if k.get(f):
            return re.split(r"(?<=[.;])\s", k[f].strip())[0][:200]
    return "device reported an error"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--event-log", required=True)
    ap.add_argument("--csv", required=True, help="the capture, to time each record at the fault's packets")
    ap.add_argument("--out", required=True)
    ap.add_argument("--offset", type=float, default=37.25, help="host clock = analyzer clock + offset (s)")
    ap.add_argument("--seed", type=int, default=5)
    a = ap.parse_args()
    rng = random.Random(a.seed)
    cards = {c["id"]: c for c in json.load(open(CARDS, encoding="utf-8"))}
    os.makedirs(a.out, exist_ok=True)
    dm, ev = [], []
    start = {}
    last_t = 0.0
    want = {}
    for line in open(a.event_log):
        d = json.loads(line)
        if d["event"] == "episode_end":
            p0, p1 = d["packets"]
            keys = [k for k in d.get("key_packets") or [] if p0 <= k <= p1]
            want[d["card"]] = (keys[-1] if keys else (p0 + p1) // 2, p1)
    need = {p for pair in want.values() for p in pair}
    pkt_t = {}
    with open(a.csv) as f:
        hdr = f.readline().split(",")
        its = hdr.index("Time Stamp")
        last = max(need) if need else -1
        for n, line in enumerate(f):
            if n > last:
                break
            if n in need:
                ts = next(csv.reader([line]))[its]
                sec, frac = ts[:-1].split(".")
                pkt_t[n] = int(sec) + int(frac) / 1e12
    for line in open(a.event_log):
        d = json.loads(line)
        t = d["t_ps"] / 1e12
        last_t = max(last_t, t)
        e = d["event"]
        if e == "host_controller_reset":
            # modeled as a tracepoint-level anchor (E05 host tracing, ~10 us accuracy); a plain dmesg line would
            # lead the CC.EN=0 write by a variable delay and bias the offset - use tracepoints or an ALIGN marker
            dm.append((t + rng.uniform(-1e-5, 1e-5), "warn", "nvme nvme0: resetting controller"))
        elif e == "episode_start":
            start[d["card"]] = t
        elif e == "episode_end":
            c = cards[d["card"]]
            pe, plast = want[d["card"]]
            te, tl = pkt_t.get(pe, t), pkt_t.get(plast, t)
            when = te + min(300e-6, max(0.0, tl - te) * rng.uniform(0.2, 0.8))   # logged after the evidence
            codes = re.findall(r"E\d\d", c["card"].get("CSV pattern", "")) or ["E01"]
            msg = text_for(c)
            for code in codes[:2]:
                src = SOURCE[code]
                if src == "dmesg":
                    dm.append((when, "err", "nvme nvme0: " + msg))
                else:
                    ev.append({"time": round(when + a.offset, 6), "source": src, "level": "err", "text": msg})
            if c["origin"] == "Test setup":       # method / capture problems show in the analyzer settings
                ev.append({"time": round(when + a.offset, 6), "source": "analyzer-settings", "level": "err",
                           "text": msg})
    t = 0.0
    while t < last_t:                      # benign background noise on the host
        t += rng.uniform(5, 40)
        dm.append((t, "info", rng.choice(BENIGN)))
    dm.sort()
    with open(os.path.join(a.out, "dmesg_x.txt"), "w") as f:
        for t, lvl, msg in dm:
            f.write("kern  :%-6s: [%12.6f] %s\n" % (lvl, t + a.offset, msg))
    ev.sort(key=lambda r: r["time"])
    with open(os.path.join(a.out, "host_events.jsonl"), "w") as f:
        for r in ev:
            f.write(json.dumps(r) + "\n")
    json.dump({"SIMULATED": True, "offset_s": a.offset, "dmesg_lines": len(dm), "tool_records": len(ev),
               "note": "simulated outside evidence for pipeline testing; see tool docstring"},
              open(os.path.join(a.out, "SIMULATED_README.json"), "w"), indent=1)
    print("dmesg lines %d, tool records %d -> %s" % (len(dm), len(ev), a.out))


if __name__ == "__main__":
    main()
