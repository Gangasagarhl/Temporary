"""Edge cases meant to break the analyzer-error detection (analyzer_errors.py and the engine paths that use it).

Each test describes a way a real export, a real Errors.csv or a real trace could differ from the happy path.
Run:  cd 13_production_app/stage1 && python3 -m unittest discover -s tests -v
"""
import csv
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pcie_isolate import analyzer_errors as AE          # noqa: E402
from pcie_isolate.engine import Engine                  # noqa: E402
from pcie_isolate.rules import RULES                    # noqa: E402
from test_fixtures import HDR, HOST, DEV, Trace, base   # noqa: E402

ERR_HDR = HDR + ["Errors"]


def with_errors():
    t = Trace(header=ERR_HDR)
    t.add(1000, **{"Link Dir": "Downstream", "Link Event": "Link Up"})
    return t


class SummaryFile(unittest.TestCase):
    """The analyzer's Errors.csv as people really save it."""

    def _rows(self, text, encoding="utf-8"):
        d = tempfile.mkdtemp()
        try:
            p = os.path.join(d, "Errors.csv")
            with open(p, "w", encoding=encoding, newline="") as f:
                f.write(text)
            self.assertTrue(AE.is_error_summary(p), "not recognised as an error summary")
            return AE.load_error_summary(p)
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_unquoted_name_with_commas_is_one_row(self):
        rows = self._rows("Type,Upstream,Downstream,Sideband,Total\nInvalid Code,0,882,0,882\n"
                          "TLP, DLLP or EDB start lane error,0,0,0,0\nTLP: Bad LCRC,8,14299,0,14307\n")
        names = [r["name"] for r in rows]
        self.assertEqual(names, ["Invalid Code", "TLP, DLLP or EDB start lane error", "TLP: Bad LCRC"], names)
        self.assertEqual(rows[1]["entry"], "TLP, DLLP or EDB start lane error")

    def test_thousands_separators_semicolons_and_other_header(self):
        rows = self._rows('Error Type;Upstream;Downstream;Sideband;Total\r\n"Idle Data Error (not D0.0)";"10";"21,862";0;"21,862"\r\n'
                          "Skip Late;0;0;0;0\r\n\r\n")
        self.assertEqual(rows[0]["total"], 21862)
        self.assertEqual(rows[0]["downstream"], 21862)
        self.assertEqual(rows[0]["entry"], "Idle Data Error (not D0.0)")
        self.assertEqual(len(rows), 2)

    def test_utf16_file_from_excel(self):
        rows = self._rows("Type\tUpstream\tDownstream\tSideband\tTotal\nTLP: Bad ECRC\t0\t260\t0\t260\n"
                          "DLLP: Bad CRC16\t1\t2471\t0\t2472\n", encoding="utf-16")
        self.assertEqual([r["total"] for r in rows], [260, 2472])

    def test_automation_text_format(self):
        rows = self._rows("Bad LCRCs on channel Upstream (12):\n____\nBad LCRCs on channel Downstream (0):\n"
                          "Invalid 10b Code on channel Upstream (11):\nIdle Error on channel Downstream (3):\n")
        by = {r["name"]: r for r in rows}
        self.assertEqual(by["Bad LCRCs"]["total"], 12)
        self.assertEqual(by["Bad LCRCs"]["entry"], "TLP: Bad LCRC")
        self.assertEqual(by["Invalid 10b Code"]["entry"], "Invalid Code")
        self.assertEqual(by["Idle Error"]["entry"], "Idle Data Error (not D0.0)")

    def test_free_text_and_empty_files_are_not_summaries(self):
        d = tempfile.mkdtemp()
        try:
            p = os.path.join(d, "errors.txt")
            open(p, "w").write("@2231.248968 nvme nvme0: No status.\nlink went down and came back at 8 GT/s\n")
            self.assertFalse(AE.is_error_summary(p))
            open(p, "w").write("")
            self.assertFalse(AE.is_error_summary(p))
        finally:
            shutil.rmtree(d, ignore_errors=True)


class Names(unittest.TestCase):
    def test_every_catalogue_name_and_alias_resolves_to_its_own_entry(self):
        for e in AE.CATALOGUE:
            for n in (e["name"],) + tuple(e["aliases"]):
                got = AE.by_name(n)
                self.assertIsNotNone(got, n)
                self.assertEqual(got["name"], e["name"], "alias %r of %r resolved to %r" % (n, e["name"], got["name"]))

    def test_ordinary_link_events_do_not_match_any_error(self):
        for ev in ("Link Up", "Link Down", "Speed Change: 8.0 GT/s", "Electrical Idle Exit", "CLKREQ# Asserted",
                   "Recording paused", "Lane Reversal detected", "Receiver Detect: no device", "Width Change x4 -> x1",
                   "Equalization Phase 3 Timeout (Lane 0)", "Analyzer: re-lock", "Link Training Start"):
            self.assertIsNone(AE.by_name(ev), ev)

    def test_longest_name_wins(self):
        self.assertEqual(AE.by_name("Invalid TLP Encoding")["name"], "TLP: Invalid Encoding")
        self.assertEqual(AE.by_name("Bad Packet Length Error")["name"], "Bad Packet Length")
        self.assertEqual(AE.by_name("DLLP: Bad CRC-16")["name"], "DLLP: Bad CRC16")
        self.assertEqual(AE.by_name("RUNNING DISPARITY ERROR")["name"], "Running Disparity Error")


class ErrorsColumn(unittest.TestCase):
    def test_name_with_commas_is_one_error(self):
        t = with_errors()
        t.add(100, **{"Link Dir": "Upstream", "Ord.Set Type": "TS1", "TS Link": "PAD", "TS Lane": "PAD",
                      "Errors": "TLP, DLLP or EDB start lane error"})
        r = t.run()
        self.assertEqual(r.count("PHY.START_LANE"), 1, r)
        self.assertNotIn("CI.ANALYZER_FLAG", r)

    def test_separators_case_and_lane_suffix(self):
        t = with_errors()
        t.add(100, **{"Link Dir": "Upstream", "Ord.Set Type": "TS1", "TS Link": "PAD", "TS Lane": "PAD",
                      "Errors": " bad lcrc | skip late ; Running Disparity Error (Lane 3), Idle Data Error (not D0.0) "})
        r = t.run()
        for rule in ("DLL.LCRC_BAD", "PHY.SKIP_LATE", "PHY.DISPARITY", "PHY.IDLE_DATA"):
            self.assertIn(rule, r, rule)
        self.assertNotIn("CI.ANALYZER_FLAG", r)

    def test_flagged_cell_and_errors_column_count_once(self):
        t = with_errors()
        for _ in range(3):
            t.tlp("Upstream", "MWr(32)", RequesterID=DEV, Address="00000000:80001000", Length="16", DATA="64 B",
                  LCRC="0x1F00BAD1 (Bad)", Errors="TLP: Bad LCRC", **{"st BE": "1111", "Last BE": "1111"})
        r = t.run()
        self.assertEqual(r.count("DLL.LCRC_BAD"), 3, r)
        self.assertEqual(t.eng.rule_dir[("DLL.LCRC_BAD", "Upstream")], 3)

    def test_every_one_of_the_72_names_fires_its_rule(self):
        t = with_errors()
        for e in AE.CATALOGUE:
            t.add(10, **{"Link Dir": "Upstream", "Errors": e["name"]})
        r = t.run()
        missing = [e["name"] for e in AE.CATALOGUE if e["rules"][0] not in r]
        self.assertEqual(missing, [])
        self.assertEqual(len(t.eng.vocab["Errors"]), 72)


class LinkEvents(unittest.TestCase):
    def test_specific_name_beats_generic_symbol_rule(self):
        t = base()
        for ev in ("Invalid TLP Encoding", "Equalization Phase 3 Timeout (Lane 0)", "Invalid Sync Header (Lane 2)",
                   "Framing Error: STP expected", "SKP OS Interval Violation (> 370 blocks)"):
            t.add(50, **{"Link Dir": "Upstream", "Link Event": ev})
        r = t.run()
        self.assertIn("TLP.INVALID_ENCODING", r)
        self.assertNotIn("PHY.INVALID_PACKET", r)
        self.assertIn("PHY.EQ_TIMEOUT", r)
        self.assertNotIn("PHY.TS_EQ_PHASE", r)
        self.assertIn("PHY.SYMBOL_ERR", r)          # sync header: no analyzer name, the generic rule stays
        self.assertIn("PHY.DELIMITER", r)
        self.assertIn("PHY.SKIP_LATE", r)


class TypeCells(unittest.TestCase):
    def test_unknown_but_plausible_type_names_are_not_invalid_encodings(self):
        t = base()
        t.tlp("Upstream", "MemRd(32)", RequesterID=DEV, Tag="3", Address="00000000:80001000", Length="16",
              **{"st BE": "1111", "Last BE": "1111"})
        t.add(100, **{"Link Dir": "Upstream", "DLLP Type": "UpdateFC-P2", "HdrFC": "3", "DataFC": "8", "CRC 16": "0x1111"})
        t.add(100, **{"Link Dir": "Upstream", "Ord.Set Type": "TS0"})
        r = t.run()
        self.assertNotIn("TLP.INVALID_ENCODING", r, r)
        self.assertNotIn("DLL.INVALID_ENCODING", r, r)
        self.assertNotIn("PHY.OS_FORMAT", r, r)
        self.assertIn("MemRd(32)", t.eng.vocab["TLP Type"])

    def test_cells_that_say_invalid_are(self):
        t = base()
        for v in ("Rsvd(0x1B)", "Reserved", "0x1B", "Unknown Type", "Invalid TLP"):
            t.add(100, **{"Link Dir": "Upstream", "TLP Type": v, "LCRC": "0x12345678"})
        t.add(100, **{"Link Dir": "Upstream", "DLLP Type": "Reserved (0x3)", "CRC 16": "0x1234"})
        r = t.run()
        self.assertEqual(r.count("TLP.INVALID_ENCODING") + r.count("PHY.INVALID_PACKET"), 5, r)
        self.assertIn("DLL.INVALID_ENCODING", r)


class UnnumberedRows(unittest.TestCase):
    def test_unnumbered_row_with_a_decoded_type_is_handled_as_that_type(self):
        t = base()
        t.mrd(80)
        t.tlp("Upstream", "MWr(32)", RequesterID=DEV, Address="00000000:80001000", Length="16", DATA="64 B",
              LCRC="0x1F00BAD1 (Bad)", **{"st BE": "1111", "Last BE": "1111"})
        t.rows[-1]["Packet"] = ""
        t.add(10, **{"Link Dir": "Downstream", "DLLP Type": "ACK", "AckNak Seq Num": "5", "CRC 16": "0xCD46 (Bad)"})
        t.rows[-1]["Packet"] = ""
        t.cpld(80)
        r = t.run()
        self.assertIn("DLL.LCRC_BAD", r)
        self.assertNotIn("TLP.NO_HEADER", r)
        self.assertIn("DLL.CRC16_BAD", r)
        self.assertNotIn("DLL.INVALID_ENCODING", r)
        self.assertFalse([x for x in r if x.startswith("TXN.")], r)
        self.assertEqual(sum(v for k, v in t.eng.undecoded.items() if "no packet number" in k), 2, t.eng.undecoded)

    def test_first_row_unnumbered_without_time(self):
        t = Trace()
        t.add(10, **{"CRC 16": "0x3DD2"})
        t.rows[-1]["Packet"] = ""
        t.rows[-1]["Time Stamp"] = ""
        t.add(1000, **{"Link Dir": "Downstream", "Link Event": "Link Up"})
        t.mrd(80)
        t.cpld(80)
        r = t.run()
        self.assertEqual(t.eng.rows, 4)
        self.assertFalse([x for x in r if x.startswith("TXN.")], r)


class MarkedCells(unittest.TestCase):
    def test_bad_marker_in_any_case(self):
        t = base()
        t.mwr()
        t.rows[-1]["LCRC"] = "0x12345678 (bad)"
        t.add(10, **{"Link Dir": "Downstream", "DLLP Type": "ACK", "AckNak Seq Num": "0", "CRC 16": "0xCD46 (BAD)"})
        t.add(10, **{"Link Dir": "Downstream", "DLLP Type": "UpdateFC-P", "HdrFC": "3", "DataFC": "8", "CRC 16": "0x1111 (Bad)"})
        r = t.run()
        self.assertIn("DLL.LCRC_BAD", r)
        self.assertEqual(r.count("DLL.CRC16_BAD"), 2, r)

    def test_ecrc_marker_case(self):
        t = base()
        t.mwr()
        t.rows[-1]["ECRC"] = "0xABCDEF01 (BAD)"
        t.rows[-1]["TD"] = "1"
        r = t.run()
        self.assertIn("TLP.ECRC_BAD", r)
        self.assertNotIn("TLP.TD_SET", r)


class FlowControl(unittest.TestCase):
    def _init(self, t, scale_h="", scale_d="", hdr="2", data="8", crc="0x1111"):
        for k in ("InitFC1-P", "InitFC1-NP", "InitFC1-Cpl"):
            t.add(50, **{"Link Dir": "Downstream", "DLLP Type": k, "HdrFC": hdr if k == "InitFC1-P" else "0",
                         "DataFC": data if k == "InitFC1-P" else "0", "CRC 16": crc, "HdrScale": scale_h, "DataScale": scale_d})
        for k in ("InitFC2-P", "InitFC2-NP", "InitFC2-Cpl"):
            t.add(50, **{"Link Dir": "Downstream", "DLLP Type": k, "HdrFC": hdr if k == "InitFC2-P" else "0",
                         "DataFC": data if k == "InitFC2-P" else "0", "CRC 16": crc, "HdrScale": scale_h, "DataScale": scale_d})

    def test_scaled_credits_written_as_factor_or_code(self):
        for sh, sd in (("x4", "x16"), ("4", "16"), ("2", "3")):
            t = base()
            self._init(t, sh, sd, hdr="300", data="4000")
            r = t.run()
            self.assertNotIn("FC.INVALID_ADVERTISEMENT", r, (sh, sd, r))

    def test_initfc_with_bad_crc_is_ignored(self):
        t = base()
        self._init(t, crc="0x1111 (Bad)")
        for _ in range(3):
            t.tlp("Upstream", "MWr(32)", RequesterID=DEV, Address="00000000:80001000", Length="16", DATA="64 B",
                  **{"st BE": "1111", "Last BE": "1111"})
        r = t.run()
        self.assertNotIn("FC.INSUFFICIENT_CREDITS", r, r)

    def test_infinite_type_updates_are_reported_once(self):
        t = base()
        self._init(t)
        for n in range(5):
            t.add(50, **{"Link Dir": "Downstream", "DLLP Type": "UpdateFC-Cpl", "HdrFC": str(n + 1), "DataFC": "0", "CRC 16": "0x1111"})
        r = t.run()
        self.assertEqual(r.count("FC.INVALID_ADVERTISEMENT"), 1, r)

    def test_update_counter_wraps_without_alarm(self):
        t = base()
        self._init(t, hdr="8", data="64")
        pkts = 0
        for n in range(40):                                   # 40 x 64 B = 160 data credits against a 64-credit window
            t.tlp("Upstream", "MWr(32)", RequesterID=DEV, Address="00000000:80001000", Length="16", DATA="64 B",
                  **{"st BE": "1111", "Last BE": "1111"})
            pkts += 1
            if pkts % 2 == 0:                                 # the receiver grants 8 more credits every 2 packets
                t.add(50, **{"Link Dir": "Downstream", "DLLP Type": "UpdateFC-P", "HdrFC": str((8 + pkts) % 256),
                             "DataFC": str((64 + 4 * pkts) % 4096), "CRC 16": "0x1111"})
        r = t.run()
        self.assertNotIn("FC.INSUFFICIENT_CREDITS", r, r)


class TrainingSets(unittest.TestCase):
    def test_hex_link_and_lane_numbers_and_gen_names(self):
        t = base()
        t.add(100, **{"Link Dir": "Downstream", "Ord.Set Type": "TS2", "TS Link": "0x00", "TS Lane": "0x00",
                      "TS Data Rate": "Gen1, Gen2, Gen3", "Training Control": "0 0 0 0 0 0 00"})
        t.add(100, **{"Link Dir": "Downstream", "Ord.Set Type": "TS2", "TS Link": "0", "TS Lane": "0",
                      "TS Data Rate": "2,5 GT/s; 5,0 GT/s", "Training Control": "0 0 0 0 0 0 00"})
        r = t.run()
        self.assertNotIn("PHY.TS_LINK", r, r)
        self.assertNotIn("PHY.TS_LANE", r, r)
        self.assertNotIn("PHY.TS_RATE", r, r)

    def test_equalization_redo_after_phase_3_is_legal(self):
        t = base()
        t.add(100, **{"Link Dir": "Downstream", "Link Event": "Speed Change: 8.0 GT/s"})
        for ec in ("00", "01", "10", "11", "00", "01", "10", "11"):
            t.add(100, **{"Link Dir": "Downstream", "Ord.Set Type": "TS1", "TS Link": "0", "TS Lane": "0",
                          "TS Gen3 Eq Control": "0 %s 10" % ec})
        r = t.run()
        self.assertNotIn("PHY.TS_EQ_PHASE", r, r)
        t.add(100, **{"Link Dir": "Downstream", "Ord.Set Type": "TS1", "TS Link": "0", "TS Lane": "0",
                      "TS Gen3 Eq Control": "0 01 10"})
        t.add(100, **{"Link Dir": "Downstream", "Ord.Set Type": "TS1", "TS Link": "0", "TS Lane": "0",
                      "TS Gen3 Eq Control": "0 11 10"})
        r = t.run()
        self.assertEqual(r.count("PHY.TS_EQ_PHASE"), 2, r)        # 3 -> 1 skips phase 0, 1 -> 3 skips phase 2


class Sideband(unittest.TestCase):
    def test_slave_address_spellings(self):
        t = base()
        for a in ("7Ah", "0x74 (W)", "0xF4", "0b1111010", "", "0x3A"):
            t.add(100, **{"Slave Address": a, "Byte Count": "16"})
        r = t.run()
        self.assertEqual(r.count("SMBUS.ADDR_10BIT"), 1, r)      # only 0xF4 (8-bit form of 0x7A)
        self.assertNotIn("SMBUS.BAD_ADDRESS", r)


class MessageCodes(unittest.TestCase):
    def test_names_hex_and_unknown(self):
        t = base()
        for code in ("Vendor_Defined Type 0", "0x7E", "Unknown (0x45)", "0x66", "PM_PME", "Set_Slot_Power_Limit"):
            t.tlp("Upstream", "Msg", RequesterID=DEV, **{"Message Code": code, "Msg Routing": "To Root Complex"})
        r = t.run()
        self.assertEqual(r.count("MSG.UNKNOWN_CODE"), 2, r)


class Comparison(unittest.TestCase):
    def test_counts_match_exactly_when_the_errors_column_exists(self):
        t = with_errors()
        t.mrd(80)
        t.cpld(80)
        for _ in range(3):
            t.tlp("Upstream", "MWr(32)", RequesterID=DEV, Address="00000000:80001000", Length="16", DATA="64 B",
                  LCRC="0x1F00BAD1 (Bad)", Errors="TLP: Bad LCRC", **{"st BE": "1111", "Last BE": "1111"})
        t.add(10, **{"Link Dir": "Downstream", "Errors": "Invalid Code"})
        t.rows[-1]["Packet"] = ""
        d = tempfile.mkdtemp()
        try:
            csv_path = os.path.join(d, "trace.csv")
            with open(csv_path, "w", newline="") as f:
                w = csv.writer(f)
                w.writerow(t.header)
                for r in t.rows:
                    w.writerow([r[h] for h in t.header])
            errs = os.path.join(d, "Errors.csv")
            open(errs, "w").write("Type,Upstream,Downstream,Sideband,Total\nTLP: Bad LCRC,3,0,0,3\nInvalid Code,0,1,0,1\n"
                                  "TLP: No Header Error,0,0,0,0\n")
            out = os.path.join(d, "run")
            here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            r = subprocess.run([sys.executable, "-m", "pcie_isolate.cli", "run", "--csv", csv_path, "--out", out,
                                "--backend", "dry-run", "--expected", errs], cwd=here, capture_output=True, text=True, timeout=300)
            self.assertEqual(r.returncode, 0, r.stderr[-800:])
            chk = json.load(open(os.path.join(out, "analyzer_check.json")))
            by = {x["name"]: x for x in chk["types"]}
            self.assertEqual(by["TLP: Bad LCRC"]["ours"], {"total": 3, "upstream": 3, "downstream": 0}, by["TLP: Bad LCRC"])
            self.assertEqual(by["Invalid Code"]["ours"]["total"], 1)
            self.assertEqual(by["TLP: No Header Error"]["status"], "AGREE: none")
            run = json.load(open(os.path.join(out, "run.json")))
            self.assertTrue(run["vocabulary"]["errors_column"])
        finally:
            shutil.rmtree(d, ignore_errors=True)


class FieldChecks(unittest.TestCase):
    """The kinds the catalogue says are checked from the exported fields must fire without any analyzer flag."""

    def test_tc_attr_at_and_payload_length(self):
        t = base()
        t.tlp("Downstream", "CfgRd0", RequesterID=HOST, Tag="7", DeviceID=DEV, Register="0x000", Length="1",
              TC="1", Attributes="RO", AT="01", **{"st BE": "1111", "Last BE": "0000"})
        t.tlp("Upstream", "MWr(32)", RequesterID=DEV, Address="00000000:80002000", Length="32", DATA="64 B",
              **{"st BE": "1111", "Last BE": "1111"})
        r = t.run()
        for rule in ("TLP.TC_NONZERO", "TLP.ATTR", "TLP.AT_SET", "TLP.LEN_MISMATCH"):
            self.assertIn(rule, r, rule)

    def test_lane_range_and_cursor_rules(self):
        t = base()
        t.add(100, **{"Link Dir": "Downstream", "Ord.Set Type": "TS1", "TS Link": "0", "TS Lane": "77"})
        t.add(100, **{"Link Dir": "Downstream", "Ord.Set Type": "TS1", "TS Link": "0", "TS Lane": "0",
                      "TS Gen3 Pre-Cursor": "4", "TS Gen3 Cursor": "70", "TS Gen3 Post-Cursor": "6"})
        t.add(100, **{"Link Dir": "Downstream", "Ord.Set Type": "TS1", "TS Link": "0", "TS Lane": "0",
                      "TS Gen3 Pre-Cursor": "10", "TS Gen3 Cursor": "12", "TS Gen3 Post-Cursor": "8"})
        t.add(100, **{"Link Dir": "Downstream", "Ord.Set Type": "TS1", "TS Link": "0", "TS Lane": "0",
                      "TS Gen3 Pre-Cursor": "4", "TS Gen3 Cursor": "30", "TS Gen3 Post-Cursor": "6"})
        r = t.run()
        self.assertIn("PHY.TS_LANE", r)
        self.assertEqual(r.count("PHY.TS_CURSOR"), 2, r)
        self.assertEqual(t.eng.rule_dir[("PHY.TS_CURSOR", "Downstream")], 2)

    def test_arp_command_codes(self):
        t = base()
        t.add(100, **{"Slave Address": "0x61", "ARP Command": "Reserved (0x09)"})
        t.add(100, **{"Slave Address": "0x61", "ARP Command": "Prepare to ARP"})
        r = t.run()
        self.assertEqual(r.count("SMBUS.ARP_COMMAND"), 1, r)


if __name__ == "__main__":
    unittest.main()
