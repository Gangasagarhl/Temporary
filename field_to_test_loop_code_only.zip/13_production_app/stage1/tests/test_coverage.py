"""Test coverage module (pcie_isolate/coverage.py): the counts are consistent and every number says where it came from.

Run:  cd 13_production_app/stage1 && python3 -m unittest tests.test_coverage -v
"""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pcie_isolate import analyzer_errors as A  # noqa: E402
from pcie_isolate import coverage as C  # noqa: E402
from pcie_isolate import rules as R  # noqa: E402

APP = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))      # 13_production_app


class OnTheProject(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.d = C.build(APP)

    def test_every_rule_has_exactly_one_status_and_the_totals_add_up(self):
        t = self.d["totals"]
        self.assertEqual(t["rules"], len(R.RULES))
        self.assertEqual(t["seen"] + t["test"] + t["none"], t["rules"])
        self.assertEqual(t["with_evidence"], t["seen"] + t["test"])
        self.assertEqual(sum(f["total"] for f in self.d["families"]), t["rules"])
        for f in self.d["families"]:
            self.assertEqual(f["seen"] + f["test"] + f["none"], f["total"])
        self.assertEqual({r["status"] for r in self.d["rules"]} - {C.STATUS_SEEN, C.STATUS_TEST, C.STATUS_NONE}, set())

    def test_a_status_is_backed_by_the_evidence_it_claims(self):
        for r in self.d["rules"]:
            if r["status"] == C.STATUS_SEEN:
                self.assertTrue(r["runs"] or r["count_485"], r["id"])
            elif r["status"] == C.STATUS_TEST:
                self.assertTrue(r["tests"], r["id"])
                self.assertFalse(r["runs"] or r["count_485"], r["id"])
            else:
                self.assertFalse(r["runs"] or r["tests"] or r["count_485"], r["id"])
            for x in r["runs"]:
                self.assertGreater(x["count"], 0)

    def test_outside_evidence_rules_are_marked_by_design(self):
        for r in self.d["rules"]:
            self.assertEqual(r["needs_outside_evidence"], r["id"].startswith("H."), r["id"])
        self.assertEqual(self.d["totals"]["none_by_design"],
                         sum(1 for r in self.d["rules"] if r["status"] == C.STATUS_NONE and r["id"].startswith("H.")))

    def test_every_kind_follows_the_best_evidence_of_its_rules(self):
        status = {r["id"]: r["status"] for r in self.d["rules"]}
        self.assertEqual(len(self.d["kinds"]), len(A.CATALOGUE))
        for k in self.d["kinds"]:
            sts = [status[x] for x in k["rules"]]
            want = C.STATUS_SEEN if C.STATUS_SEEN in sts else C.STATUS_TEST if C.STATUS_TEST in sts else C.KIND_NAME_ONLY
            self.assertEqual(k["evidence"], want, k["name"])
        t = self.d["totals"]
        self.assertEqual(t["kinds_seen"] + t["kinds_test"] + t["kinds_name_only"], t["kinds"])

    def test_the_kept_485_run_is_read_when_present(self):
        k = self.d["kept"]
        if not k or not k["planted"]:
            self.skipTest("no kept eval_485 folder")
        pl = k["planted"]
        self.assertEqual(pl["total"], 485)
        for m in pl["measures"]:
            self.assertLessEqual(m["count"], m["out_of"], m["measure"])
        self.assertEqual(sum(v["planted"] for v in pl["by_visibility"]), 485)
        grouped = next(m for m in pl["measures"] if m["measure"] == "grouped into a defect")
        self.assertEqual(sum(v["grouped"] for v in pl["by_visibility"]), grouped["count"])
        self.assertEqual(sum(v["not_grouped"] for v in pl["by_visibility"]), len(pl["not_grouped"]))
        self.assertTrue(k["command"] and k["trace"] and k["measured_at"])

    def test_every_source_names_a_place_and_a_method(self):
        for s in self.d["sources"]:
            self.assertTrue(s["what"] and s["where"] and s["how"])


class TestScanner(unittest.TestCase):
    def test_a_rule_named_inside_a_test_function_is_attributed_to_it(self):
        with tempfile.TemporaryDirectory() as d:
            open(os.path.join(d, "test_x.py"), "w").write(
                # made-up rule ids, so this file itself never counts as evidence for a real rule
                "HELPER = 'DLL.ZZZ_NOT_A_RULE'\n\nclass T:\n    def test_one(self):\n        assert 'TXN.ZZZ_NOT_A_RULE' in x  # PHY.ZZZ_NOT_A_RULE in a comment counts too\n"
                "    def test_two(self):\n        y = ['TXN.ZZZ_NOT_A_RULE']\n")
            m = C.tests_naming_rules(d)
            self.assertEqual([e["test"] for e in m["TXN.ZZZ_NOT_A_RULE"]], ["test_one", "test_two"])
            self.assertEqual(m["PHY.ZZZ_NOT_A_RULE"], [{"file": "test_x.py", "test": "test_one"}])
            self.assertEqual(m["DLL.ZZZ_NOT_A_RULE"], [{"file": "test_x.py", "test": "(module level)"}])

    def test_an_empty_application_folder_counts_zero_runs_without_an_error(self):
        with tempfile.TemporaryDirectory() as d:
            res = C.build(d)
            self.assertEqual(res["totals"]["runs_scanned"], 0)
            self.assertFalse(any(r["runs"] for r in res["rules"]))

    def test_a_half_written_findings_file_is_skipped(self):
        with tempfile.TemporaryDirectory() as d:
            os.makedirs(os.path.join(d, "runs", "r1"))
            open(os.path.join(d, "runs", "r1", "findings.pkl"), "wb").write(b"\x80\x04not a pickle")
            ev, n = C.runs_evidence(d)
            self.assertEqual((ev, n), ({}, 0))


if __name__ == "__main__":
    unittest.main()
