"""Adversarial fixtures (graph research benchmark plan): tiny exports with a known correct verdict.

Run:  cd 10_defect_isolation_engine && python3 -m unittest discover -s tests -v
"""
import csv
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pcie_isolate.engine import Engine  # noqa: E402
from pcie_isolate.schema import reference_header  # noqa: E402

HDR = reference_header()
HOST, DEV, RC = "000:00:0", "002:00:0", "000:02:4"


class Trace:
    def __init__(self, header=HDR):
        self.header = header
        self.rows = []
        self.t = 0
        self.psn = {"Upstream": 0, "Downstream": 0}

    def add(self, dt_ns=100, **f):
        self.t += dt_ns * 1000
        r = dict.fromkeys(self.header, "")
        r["Packet"] = str(len(self.rows))
        r["Time Stamp"] = "%04d.%012ds" % divmod(self.t, 10 ** 12)
        for k, v in f.items():
            r[k.replace("_", " ") if k.replace("_", " ") in r else k] = v
        self.rows.append(r)

    def tlp(self, d, kind, dt_ns=100, psn=None, **f):
        if psn is None:
            psn = self.psn[d]
            self.psn[d] = (psn + 1) & 0xFFF
        fields = {"Link Dir": d, "TLP Type": kind, "PSN": str(psn), "LCRC": "0x12345678"}
        fields.update(f)
        self.add(dt_ns, **fields)

    def mrd(self, tag, addr="00000004:80000000", length=16, dt_ns=100):
        self.tlp("Upstream", "MRd(64)", dt_ns, Length=str(length), RequesterID=DEV, Tag=str(tag), Address=addr,
                 **{"st BE": "1111", "Last BE": "1111"})

    def cpld(self, tag, nbytes=64, owed=None, lwr="0x000", dt_ns=100):
        self.tlp("Downstream", "CplD", dt_ns, Length=str(nbytes // 4), RequesterID=DEV, Tag=str(tag),
                 CompleterID=RC, DATA="%d B" % nbytes, BCM="0", **{"Cpl Status": "SC",
                 "Byte Cnt": str(owed if owed is not None else nbytes), "Lwr Addr": lwr})

    def mwr(self, dt_ns=100):
        self.tlp("Upstream", "MWr(64)", dt_ns, Length="64", RequesterID=DEV, Tag="0", Address="00000004:90000000",
                 DATA="256 B", **{"st BE": "1111", "Last BE": "1111"})

    def run(self, rename=None, max_per_rule=None):
        fd, path = tempfile.mkstemp(suffix=".csv")
        with os.fdopen(fd, "w", newline="") as f:
            w = csv.writer(f)
            hdr = [rename.get(h, h) for h in self.header] if rename else self.header
            w.writerow(hdr)
            for r in self.rows:
                w.writerow([r[h] for h in self.header])
        eng = self.eng = Engine(path, progress=False)
        if max_per_rule:
            eng.MAX_PER_RULE = max_per_rule
        out = eng.run()
        os.unlink(path)
        return [f[2] for f in out]


def base():
    t = Trace()
    t.add(1000, **{"Link Dir": "Downstream", "Link Event": "Link Up"})
    t.tlp("Downstream", "CfgRd0", RequesterID=HOST, Tag="1", DeviceID=DEV, Register="0x000", Length="1",
          **{"st BE": "1111", "Last BE": "0000"})
    t.tlp("Upstream", "CplD", RequesterID=HOST, Tag="1", CompleterID=DEV, Length="1", DATA="4 B", BCM="0",
          **{"Cpl Status": "SC", "Byte Cnt": "4", "Lwr Addr": "0x000"})
    return t


class Fixtures(unittest.TestCase):
    def test_interleaved_out_of_order_is_healthy(self):
        t = base()
        t.mrd(10)
        t.mwr()
        t.mrd(11, "00000004:80001000")
        t.cpld(11)
        t.add(50, **{"Link Dir": "Downstream", "DLLP Type": "ACK", "AckNak Seq Num": "3", "CRC 16": "0x1234"})
        t.cpld(10)
        r = t.run()
        self.assertFalse([x for x in r if x.startswith(("TXN.", "TLP."))], r)

    def test_eof_before_deadline_is_not_a_timeout(self):
        t = base()
        t.mrd(20)
        for _ in range(20):
            t.mwr(dt_ns=1000)
        self.assertNotIn("TXN.CPL_TIMEOUT", t.run())

    def test_missing_completion_past_deadline_is_a_timeout(self):
        t = base()
        t.mrd(21)
        for _ in range(30):
            t.mwr(dt_ns=3 * 1000 * 1000)            # 90 ms of traffic, completion timeout 50 ms
        self.assertIn("TXN.CPL_TIMEOUT", t.run())

    def test_completion_with_wrong_tag_is_unexpected(self):
        t = base()
        for _ in range(5):
            t.mwr(dt_ns=20 * 1000 * 1000)           # past the capture-start guard
        t.mrd(30)
        t.cpld(31)
        t.cpld(30)
        r = t.run()
        self.assertIn("TXN.UNEXPECTED_CPL", r)
        self.assertNotIn("TXN.CPL_TIMEOUT", r)

    def test_tag_reuse_after_completion_is_legal(self):
        t = base()
        t.mrd(40)
        t.cpld(40)
        t.mrd(40, "00000004:80002000")
        t.cpld(40)
        self.assertNotIn("TXN.TAG_REUSE", t.run())

    def test_tag_reuse_while_outstanding_is_flagged(self):
        t = base()
        t.mrd(41)
        t.mrd(41, "00000004:80003000")
        self.assertIn("TXN.TAG_REUSE", t.run())

    def test_legal_split_completion(self):
        t = base()
        t.mrd(50, length=128)                       # 512 B read
        t.cpld(50, 256, owed=512)
        t.cpld(50, 256, owed=256)
        r = t.run()
        self.assertFalse([x for x in r if x in ("TXN.BYTECNT", "TXN.LWRADDR", "TXN.RCB", "TXN.OVERRUN")], r)

    def test_orphan_completion_after_buffer_wrap_is_not_flagged(self):
        t = base()
        for _ in range(5):
            t.mwr(dt_ns=20 * 1000 * 1000)
        t.add(10, Marker="Buffer Wrap: 412 ms not recorded", **{"Link Dir": "Upstream", "TLP Type": "MWr(64)",
              "PSN": "900", "RequesterID": DEV, "Address": "00000004:90000000", "Length": "64", "DATA": "256 B",
              "LCRC": "0x1", "st BE": "1111", "Last BE": "1111"})
        t.cpld(60)
        r = t.run()
        self.assertIn("CI.MARKER", r)
        self.assertNotIn("TXN.UNEXPECTED_CPL", r)

    def test_lcrc_nak_replay_is_not_a_new_request(self):
        t = base()
        t.mrd(70)
        t.tlp("Upstream", "MRd(64)", psn=t.psn["Upstream"], Length="16", RequesterID=DEV, Tag="71",
              Address="00000004:80004000", LCRC="0xDEADBEEF (Bad)", **{"st BE": "1111", "Last BE": "1111"})
        bad = t.psn["Upstream"]
        t.psn["Upstream"] += 1
        t.add(100, **{"Link Dir": "Downstream", "DLLP Type": "NAK", "AckNak Seq Num": str(bad - 1),
                      "CRC 16": "0x1"})
        t.tlp("Upstream", "MRd(64)", psn=bad, Length="16", RequesterID=DEV, Tag="71", Address="00000004:80004000",
              **{"st BE": "1111", "Last BE": "1111"})
        r = t.run()
        for rule in ("DLL.LCRC_BAD", "DLL.NAK", "DLL.REPLAY"):
            self.assertIn(rule, r)
        self.assertNotIn("TXN.TAG_REUSE", r)

    def test_header_alias_and_missing_columns(self):
        t = base()
        t.mrd(80)
        t.cpld(80)
        r = t.run(rename={"AckNak Seq Num": "AckNak_Seq_Num", "PTM Propagation Delay": "x_unused"})
        self.assertFalse([x for x in r if x.startswith("TXN.")], r)

    def test_direction_labels_are_calibrated(self):
        t = base()
        t.mrd(90)
        t.cpld(90)
        for r in t.rows:
            r["Link Dir"] = {"Downstream": "H->D", "Upstream": "D->H"}.get(r["Link Dir"], r["Link Dir"])
        r = t.run()
        self.assertFalse([x for x in r if x.startswith(("TXN.", "TLP.RID"))], r)


    def test_completion_timeout_range_from_device_control_2(self):
        """PCIe Base, Device Control 2: a programmed Completion Timeout range replaces the 50 ms default.
        Range 1010b = 1 s - 3.5 s, so 90 ms without a completion is not a timeout."""
        t = base()
        t.tlp("Downstream", "CfgWr0", RequesterID=HOST, Tag="2", DeviceID=DEV, Register="0x098", Length="1",
              DATA="0A 00 00 00", **{"st BE": "1111", "Last BE": "0000"})     # inline hex payload
        t.tlp("Upstream", "Cpl", RequesterID=HOST, Tag="2", CompleterID=DEV, BCM="0",
              **{"Cpl Status": "SC", "Byte Cnt": "4", "Lwr Addr": "0x000"})
        t.mrd(21)
        for _ in range(30):
            t.mwr(dt_ns=3 * 1000 * 1000)
        self.assertNotIn("TXN.CPL_TIMEOUT", t.run())

    def test_jammer_row_is_an_artefact_record(self):
        t = base()
        t.add(100, **{"Jammer Phase": "Inject", "Action": "Corrupt LCRC", "Jammer Target Packet": "5"})
        r = t.run()
        self.assertIn("CI.JAMMER", r)
        self.assertNotIn("TXN.UNEXPECTED_CPL", r)

    def test_capture_starting_mid_traffic_is_flagged_not_blamed(self):
        t = Trace()                       # no Link Up, no enumeration: first row is a completion
        t.cpld(5)
        t.mrd(6)
        t.cpld(6)
        r = t.run()
        self.assertIn("CI.CAPTURE_START", r)
        self.assertNotIn("TXN.UNEXPECTED_CPL", r)

    # ---- rows seen in real analyzer exports (field test of 2026-10-27, 5.8 GB export: ValueError on an Ack row)
    def test_ack_without_sequence_number_is_kept_not_fatal(self):
        t = base()
        t.mrd(80)
        t.add(50, **{"Link Dir": "Upstream", "DLLP Type": "ACK", "AckNak Seq Num": "", "CRC 16": "0xCD46"})
        t.cpld(80)
        r = t.run()
        self.assertEqual(t.eng.undecoded.get("Ack without a sequence number"), 1)
        self.assertFalse([x for x in r if x.startswith(("TXN.", "DLL.ACK"))], r)

    def test_nak_without_sequence_number_is_kept_not_fatal(self):
        t = base()
        t.add(50, **{"Link Dir": "Upstream", "DLLP Type": "NAK", "AckNak Seq Num": "", "CRC 16": "0xCD46"})
        r = t.run()
        self.assertIn("DLL.NAK", r)

    def test_rows_without_packet_number_or_time_stamp_are_counted(self):
        t = base()
        t.mrd(80)
        t.add(10, **{"CRC 16": "0x3DD2"})
        t.rows[-1]["Packet"] = ""                         # analyzer note row: no packet number
        t.cpld(80)
        t.rows[-1]["Time Stamp"] = ""                     # time missing: previous row's time is used
        t.mwr()
        t.add(10, **{"Marker": "BOOM"})                   # a row whose handler raises: the row guard must catch it
        orig = Engine.on_marker
        Engine.on_marker = lambda self, m, pkt, t_: (_ for _ in ()).throw(ValueError("boom")) if m == "BOOM" else orig(self, m, pkt, t_)
        try:
            r = t.run()
        finally:
            Engine.on_marker = orig
        u = t.eng.undecoded
        self.assertEqual(u.get("analyzer error packet (no packet number)"), 1, u)
        self.assertEqual(u.get("no time stamp (previous row's time used)"), 1, u)
        self.assertEqual(sum(v for k, v in u.items() if k.startswith("cell not understood")), 1, u)
        self.assertEqual(t.eng.rows, len(t.rows))
        self.assertFalse([x for x in r if x.startswith("TXN.")], r)
        self.assertEqual(t.eng.undecoded_summary()["rows"], 3)

    def test_first_byte_enable_column_spelled_1st_be(self):
        t = base()
        t.mwr()
        t.mwr()
        self.assertNotIn("TLP.BE", t.run(rename={"st BE": "1st BE"}))
        # no byte-enable columns at all: the rule cannot be judged, so it must not fire on every request
        self.assertNotIn("TLP.BE", t.run(rename={"st BE": "x_gone", "Last BE": "y_gone"}))
        self.assertEqual(sorted(x for x in t.eng.C.missing if x != "Errors"), ["Last BE", "st BE"])

    def test_findings_beyond_the_per_rule_cap_are_counted(self):
        t = base()
        for _ in range(12):
            t.tlp("Downstream", "MWr(32)", RequesterID=HOST, Address="00000000:80001000", Length="2", DATA="8 B",
                  **{"st BE": "0000", "Last BE": "0000"})
        r = t.run(max_per_rule=5)
        self.assertEqual(r.count("TLP.BE"), 5)
        self.assertEqual(t.eng.suppressed["TLP.BE"], 7)
        self.assertEqual(t.eng.undecoded_summary()["findings_suppressed"], {"TLP.BE": 7})

    def test_reference_export_decodes_every_row(self):
        path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            "reference", "final_113_columns.csv")
        eng = Engine(path, progress=False)
        eng.run()
        self.assertEqual(eng.rows, 242)
        self.assertEqual(eng.undecoded.get("analyzer error packet (no packet number)"), 4)

    # ---- the analyzer's own 72 error types (analyzer_errors.py): every evidence path the export can carry
    def test_analyzer_catalogue_is_complete_and_its_rules_exist(self):
        from pcie_isolate import analyzer_errors as AE
        from pcie_isolate.rules import RULES
        self.assertEqual(len(AE.CATALOGUE), 72)
        for e in AE.CATALOGUE:
            self.assertIs(AE.by_name(e["name"]), e)
            for r in e["rules"]:
                self.assertIn(r, RULES, (e["name"], r))
        self.assertIn(AE.GENERIC_RULE, RULES)
        self.assertEqual(AE.by_name("Bad LCRCs on channel Upstream (12)")["name"], "TLP: Bad LCRC")

    def test_errors_column_names_map_to_rules(self):
        t = Trace(header=HDR + ["Errors"])
        t.add(1000, **{"Link Dir": "Downstream", "Link Event": "Link Up"})
        t.add(100, **{"Link Dir": "Upstream", "Ord.Set Type": "TS1", "TS Link": "PAD", "TS Lane": "PAD",
                      "Errors": "Training Sequence Parity Error; Skip Late"})
        t.mwr()
        t.rows[-1]["Errors"] = "CXL Flit CRC Error"
        r = t.run()
        self.assertIn("PHY.TS_PARITY", r)
        self.assertIn("PHY.SKIP_LATE", r)
        self.assertIn("CI.ANALYZER_FLAG", r)
        self.assertEqual(t.eng.rule_dir[("PHY.TS_PARITY", "Upstream")], 1)

    def test_marked_cells_map_to_rules(self):
        t = base()
        t.add(100, **{"Link Dir": "Upstream", "Ord.Set Type": "TS1", "TS Link": "5 (Error)", "TS Lane": "PAD"})
        t.mwr()
        t.rows[-1]["Length"] = "64 (Bad)"
        t.rows[-1]["Address"] = "00000000:80000000 (Bad)"
        r = t.run()
        self.assertIn("PHY.TS_LINK", r)
        self.assertIn("TLP.LENGTH_FIELD", r)
        self.assertIn("TLP.4K", r)
        self.assertFalse([x for x in t.eng.undecoded if x.startswith("cell")], t.eng.undecoded)

    def test_link_event_text_with_analyzer_names(self):
        t = base()
        for ev in ("Idle Data Error (not D0.0)", "Running Disparity Error (Lane 1)", "Invalid 10b Code (Lane 0)",
                   "Delimiter Error", "Skew Error", "Bad Packet Length", "Invalid Sync Header (Lane 3)",
                   "Equalization Phase 3 Timeout (Lane 0)"):
            t.add(50, **{"Link Dir": "Upstream", "Link Event": ev})
        r = t.run()
        for rule in ("PHY.IDLE_DATA", "PHY.DISPARITY", "PHY.INVALID_CODE", "PHY.DELIMITER", "PHY.LANE_SKEW",
                     "PHY.PKT_LENGTH", "PHY.SYMBOL_ERR", "PHY.EQ_TIMEOUT"):
            self.assertIn(rule, r, rule)

    def test_undecoded_packets_become_findings(self):
        t = base()
        t.mrd(80)
        t.add(10, **{"LCRC": "0xB6206FBA", "DATA": "256 B"})
        t.rows[-1]["Packet"] = ""                         # TLP without a header, no packet number
        t.add(10, **{"CRC 16": "0x3DD2 (Bad)"})
        t.rows[-1]["Packet"] = ""                         # DLLP without a type
        t.add(10)
        t.rows[-1]["Packet"] = ""                         # nothing decoded at all
        t.cpld(80)
        r = t.run()
        self.assertIn("TLP.NO_HEADER", r)
        self.assertIn("DLL.INVALID_ENCODING", r)
        self.assertIn("DLL.CRC16_BAD", r)
        self.assertIn("PHY.INVALID_PACKET", r)
        self.assertEqual(t.eng.undecoded.get("analyzer error packet (no packet number)"), 3)
        self.assertFalse([x for x in r if x.startswith("TXN.")], r)

    def test_unknown_type_cells_are_invalid_encodings(self):
        t = base()
        t.add(100, **{"Link Dir": "Upstream", "TLP Type": "Rsvd(0x1B)", "LCRC": "0x12345678"})
        t.add(100, **{"Link Dir": "Upstream", "DLLP Type": "Reserved", "CRC 16": "0x1234"})
        t.add(100, **{"Link Dir": "Upstream", "Ord.Set Type": "Invalid Packet"})
        t.add(100, **{"Link Dir": "Upstream", "Ord.Set Type": "Reserved OS (0x7)"})
        r = t.run()
        self.assertIn("TLP.INVALID_ENCODING", r)
        self.assertIn("DLL.INVALID_ENCODING", r)
        self.assertIn("PHY.INVALID_PACKET", r)
        self.assertIn("PHY.OS_FORMAT", r)

    def test_io_and_cfg_requests_must_carry_one_dw(self):
        t = base()
        t.tlp("Downstream", "IORd", RequesterID=HOST, Tag="5", Address="00001000", Length="2",
              **{"st BE": "1111", "Last BE": "1111"})
        t.tlp("Downstream", "Msg", RequesterID=HOST, **{"Message Code": "0x66", "Msg Routing": "Local"})
        t.tlp("Downstream", "CfgRd0", RequesterID=HOST, Tag="6", DeviceID=DEV, Register="0x006", Length="1",
              **{"st BE": "1111", "Last BE": "0000"})
        r = t.run()
        self.assertIn("TLP.LENGTH_FIELD", r)
        self.assertIn("MSG.UNKNOWN_CODE", r)
        self.assertIn("TLP.CFG_REGISTER", r)

    def test_flow_control_credits_are_rebuilt(self):
        t = base()
        for k in ("InitFC1-P", "InitFC1-NP", "InitFC1-Cpl"):
            t.add(50, **{"Link Dir": "Downstream", "DLLP Type": k, "HdrFC": "2" if k == "InitFC1-P" else "0",
                         "DataFC": "8" if k == "InitFC1-P" else "0", "CRC 16": "0x1111"})
        t.add(50, **{"Link Dir": "Downstream", "DLLP Type": "InitFC2-Cpl", "HdrFC": "0", "DataFC": "0", "CRC 16": "0x1111"})
        t.add(50, **{"Link Dir": "Downstream", "DLLP Type": "InitFC2-P", "HdrFC": "3", "DataFC": "8", "CRC 16": "0x1111"})
        t.add(50, **{"Link Dir": "Downstream", "DLLP Type": "InitFC2-NP", "HdrFC": "0", "DataFC": "0", "CRC 16": "0x1111"})
        for _ in range(3):                                # 3 x 64 B = 12 data credits against a limit of 8
            t.tlp("Upstream", "MWr(32)", RequesterID=DEV, Address="00000000:80001000", Length="16", DATA="64 B",
                  **{"st BE": "1111", "Last BE": "1111"})
        t.add(50, **{"Link Dir": "Downstream", "DLLP Type": "UpdateFC-P", "HdrFC": "200", "DataFC": "30", "CRC 16": "0x1111"})
        t.add(50, **{"Link Dir": "Downstream", "DLLP Type": "UpdateFC-Cpl", "HdrFC": "9", "DataFC": "0", "CRC 16": "0x1111"})
        t.add(50, **{"Link Dir": "Downstream", "Link Event": "Link Down"})
        t.add(50, **{"Link Dir": "Downstream", "Link Event": "Link Up"})
        t.add(50, **{"Link Dir": "Downstream", "DLLP Type": "InitFC1-P", "HdrFC": "200", "DataFC": "8", "CRC 16": "0x1111"})
        r = t.run()
        self.assertIn("FC.INSUFFICIENT_CREDITS", r)
        self.assertEqual(r.count("FC.INSUFFICIENT_CREDITS"), 1)
        self.assertIn("DLL.FC_INIT", r)                   # InitFC2-P credits differ from InitFC1-P
        self.assertEqual(r.count("FC.INVALID_ADVERTISEMENT"), 2)   # finite Cpl credits after infinite; InitFC1 200 > 127

    def test_training_set_phase_control_and_control_skp(self):
        t = base()
        t.add(100, **{"Link Dir": "Downstream", "Link Event": "Speed Change: 2.5 GT/s"})
        t.add(100, **{"Link Dir": "Downstream", "Ord.Set Type": "TS1", "TS Link": "0", "TS Lane": "0",
                      "Training Control": "1 1 0 0 0 0 00", "TS Gen3 Eq Control": "0 10 10",
                      "TS Data Rate": "5.0 GT/s, 8.0 GT/s"})
        t.add(100, **{"Link Dir": "Downstream", "Ord.Set Type": "TS1", "TS Link": "7", "TS Lane": "0"})
        t.add(100, **{"Link Dir": "Downstream", "Link Event": "Speed Change: 8.0 GT/s"})
        t.add(100, **{"Link Dir": "Downstream", "Ord.Set Type": "Control SKP"})
        t.add(100, **{"Link Dir": "Downstream", "Ord.Set Type": "TS1", "TS Link": "0", "TS Lane": "0",
                      "Training Control": "0 0 0 1 0 0 00"})
        r = t.run()
        self.assertIn("PHY.TS_EQ_PHASE", r)
        self.assertEqual(r.count("PHY.TS_CONTROL"), 2)    # exclusive bits, scrambling at 8 GT/s
        self.assertIn("PHY.TS_LINK", r)
        self.assertIn("PHY.TS_RATE", r)
        self.assertIn("PHY.CSKP_AT_GEN3", r)

    def test_smbus_field_checks(self):
        t = base()
        t.add(100, **{"Slave Address": "0x7A", "Byte Count": "40", "PEC": "0x12 (Bad)"})
        t.add(100, **{"Slave Address": "0x03", "ARP Command": "Assign Address", "Assign Address": "0x21"})
        r = t.run()
        for rule in ("SMBUS.TRAFFIC", "SMBUS.ADDR_10BIT", "SMBUS.BYTECOUNT_RANGE", "SMBUS.BAD_PEC", "SMBUS.BAD_ADDRESS",
                     "SMBUS.ARP_BIT0"):
            self.assertIn(rule, r, rule)

    def test_analyzer_error_summary_is_compared_type_by_type(self):
        import json
        import shutil
        import subprocess
        from pcie_isolate import analyzer_errors as AE
        from pcie_isolate.verify import verify
        t = base()
        t.mrd(80)
        t.cpld(80)
        t.add(10, **{"LCRC": "0xB6206FBA (Bad)", "DATA": "256 B"})
        t.rows[-1]["Packet"] = ""
        t.add(50, **{"Link Dir": "Upstream", "Link Event": "Running Disparity Error (Lane 1)"})
        t.mwr()
        t.rows[-1]["Length"] = "4"
        t.rows[-1]["Address"] = "00000000:80000FF8"      # 16 bytes from 0xFF8: crosses 4 KiB
        d = tempfile.mkdtemp()
        try:
            csv_path = os.path.join(d, "trace.csv")
            with open(csv_path, "w", newline="") as f:
                w = csv.writer(f)
                w.writerow(t.header)
                for r in t.rows:
                    w.writerow([r[h] for h in t.header])
            errs = os.path.join(d, "Errors.csv")
            with open(errs, "w") as f:
                f.write("Type,Upstream,Downstream,Sideband,Total\n")
                f.write("Invalid Code,0,0,0,0\nRunning Disparity Error,1,0,0,1\nTLP: Bad LCRC,1,0,0,1\n")
                f.write("TLP: No Header Error,1,0,0,1\nMemory TLP: Address/Length Crosses 4K,0,1,0,1\n")
                f.write("Skip Late,0,5,0,5\nSMBUS: Bad PEC,0,0,0,0\nSome Future Error,0,0,0,3\n")
            self.assertTrue(AE.is_error_summary(errs))
            out = os.path.join(d, "run")
            here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            r = subprocess.run([sys.executable, "-m", "pcie_isolate.cli", "run", "--csv", csv_path, "--out", out,
                                "--backend", "dry-run"], cwd=here, capture_output=True, text=True, timeout=300)
            self.assertEqual(r.returncode, 0, r.stderr[-800:])
            run = json.load(open(os.path.join(out, "run.json")))
            self.assertEqual(len(run["analyzer_errors"]), 72)
            self.assertFalse(run["vocabulary"]["errors_column"])
            verify(out, errs)
            chk = json.load(open(os.path.join(out, "analyzer_check.json")))
            s = chk["summary"]
            self.assertEqual((s["with_errors"], s["found"], s["not_found"]), (5, 4, 1),
                             [(x["name"], x["status"]) for x in chk["types"]])
            self.assertEqual((s["zero"], s["agree"], s["unknown"]), (2, 2, 1), s)
            by = {x["name"]: x for x in chk["types"]}
            self.assertEqual(by["Skip Late"]["status"], "NOT FOUND")
            self.assertIn("Errors column", by["Skip Late"]["why"])
            self.assertEqual(by["Running Disparity Error"]["ours"]["upstream"], 1)
            self.assertEqual(by["Memory TLP: Address/Length Crosses 4K"]["status"], "FOUND")
            md = open(os.path.join(out, "expected_errors_report.md")).read()
            self.assertIn("Compared with the analyzer's Error Summary", md)
        finally:
            shutil.rmtree(d, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
