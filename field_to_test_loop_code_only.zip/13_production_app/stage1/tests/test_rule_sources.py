"""Every rule names where it comes from (specification, manual or project method) and why it is checked."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from pcie_isolate.rules import RULES, SOURCE  # noqa: E402

DOCS = ("PCIe", "PCI PM", "NVMe", "NVM CS", "NVMe-MI", "SMBus", "Teledyne", "Linux", "atlas", "project", "host")


def test_every_rule_has_a_source():
    missing = [r for r in RULES if r not in SOURCE]
    assert not missing, "rules without a source: %s" % missing


def test_every_source_is_a_rule():
    extra = [r for r in SOURCE if r not in RULES]
    assert not extra, "sources for unknown rules: %s" % extra


def test_source_names_a_document_and_a_reason():
    for rid, (where, why) in SOURCE.items():
        assert any(d in where for d in DOCS), "%s: 'where' names no known document: %r" % (rid, where)
        assert len(why) >= 20, "%s: 'why' too short: %r" % (rid, why)
        assert RULES[rid]["spec"] == where and RULES[rid]["why"] == why
