"""The per-command view: parameters decoded as the specifications define them, latency measured from the capture,
labels with a stated basis, and packet-level errors attached only through the command's own identity or packets."""
import json
import os
import subprocess
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
STAGE1 = os.path.dirname(HERE)
sys.path.insert(0, STAGE1)
from pcie_isolate import commands as C  # noqa: E402
from pcie_isolate.engine import MS, SEC, US  # noqa: E402

SAMPLE = os.path.join(os.path.dirname(STAGE1), "samples", "sample_T-42_L-21_C-16_seed11.csv")
LIBRARY = os.path.join(STAGE1, "runs", "signature_library.json")


def rec(sqid, opc, dw, **kw):
    r = {"sqid": sqid, "cid": 7, "opc": opc, "nsid": 1, "dw": dw, "prp1": 0x1000, "prp2": 0, "lba_bytes": 512,
         "slba": dw[0] | dw[1] << 32, "nlb": (dw[2] & 0xFFFF) + 1, "ranges": [], "pages": [0x1000], "pkts": [],
         "t_db": 0, "t_fetch": 10 * US, "t_first_data": 30 * US, "t_last_data": 40 * US, "t_cqe": 50 * US,
         "end": "cqe", "status": [0, 0, 0], "inst": 100}
    r.update(kw)
    return r


class Parameters(unittest.TestCase):
    def names(self, rows):
        return [r[0] for r in rows]

    def test_read_carries_lba_count_bytes_and_hints(self):
        # Read, SLBA 0x1000, NLB field 7 (= 8 blocks), FUA set, DSM access latency "low", sequential request
        dw = [0x1000, 0, (7 | 1 << 30), (3 << 4) | (1 << 6) | 2, 0, 0]
        rows = C.param_rows(rec(1, 0x02, dw, lba_bytes=4096))
        d = {r[0]: r[1] for r in rows}
        self.assertEqual(d["SLBA"], 0x1000)
        self.assertEqual(d["NLB"], 8)
        self.assertEqual(d["bytes"], 8 * 4096)          # LBA data size from Identify Namespace, not a fixed 512
        self.assertTrue(d["FUA"])
        self.assertEqual(d["DSM access latency"], "low")
        self.assertEqual(d["DSM access frequency"], "infrequent writes and reads")
        self.assertTrue(d["DSM sequential request"])
        self.assertTrue(all("NVM Command Set 1.0" in r[3] for r in rows))

    def test_dataset_management_lists_its_ranges(self):
        dw = [2, 0b100, 0, 0, 0, 0]                                   # NR field 2 = 3 ranges, AD set
        rows = C.param_rows(rec(1, 0x09, dw, ranges=[(100, 8), (200, 16), (300, 32)]))
        d = {r[0]: r[1] for r in rows}
        self.assertEqual(d["NR"], 3)
        self.assertTrue(d["AD"])
        self.assertEqual(d["range 2"], "LBA 200, 16 blocks (8192 B)")

    def test_set_features_decodes_number_of_queues(self):
        dw = [0x07, (14 << 16) | 38, 0, 0, 0, 0]                       # FID 7, NSQR 38 (+1), NCQR 14 (+1)
        rows = C.param_rows(rec(0, 0x09, dw))
        d = {r[0]: r[1] for r in rows}
        self.assertEqual(d["FID"], "0x07 Number of Queues")
        self.assertEqual(d["NSQR / NCQR"], "39 / 15")
        self.assertTrue(all("NVMe Base 2.0" in r[3] for r in rows))

    def test_create_io_completion_queue(self):
        dw = [(1023 << 16) | 5, (3 << 16) | 0b11, 0, 0, 0, 0]          # QID 5, QSIZE 1024, PC, IEN, IV 3
        d = {r[0]: r[1] for r in C.param_rows(rec(0, 0x05, dw))}
        self.assertEqual((d["QID"], d["QSIZE"], d["PC"], d["IEN"], d["IV"]), (5, 1024, True, True, 3))

    def test_unknown_opcode_still_shows_its_dwords(self):
        d = {r[0]: r[1] for r in C.param_rows(rec(1, 0x7F, [1, 2, 3, 4, 5, 6]))}
        self.assertIn("CDW10..15", d)

    def test_field_list_per_kind(self):
        self.assertEqual(C.param_fields(1, 0x02)[:4], ["NSID", "SLBA", "NLB", "bytes"])
        self.assertIn("FID", C.param_fields(0, 0x09))


class StatusWords(unittest.TestCase):
    def test_specification_names(self):
        self.assertEqual(C.status_words((0, 0, 0)), "Successful Completion")
        self.assertTrue(C.status_words((0, 0x80, 1)).startswith("LBA Out of Range"))
        self.assertIn("do not retry", C.status_words((0, 0x80, 1)))
        self.assertTrue(C.status_words((2, 0x81, 0)).startswith("Unrecovered Read Error"))
        self.assertTrue(C.status_words((1, 0x02, 0)).startswith("Invalid Queue Size"))
        self.assertEqual(C.status_words(None), "no completion")


class LatencyAndLabels(unittest.TestCase):
    def test_steps_and_owners(self):
        r = rec(1, 0x02, [0, 0, 7, 0, 0, 0])
        st = {s["step"]: s for s in C.steps_of(r)}
        self.assertEqual(st["doorbell to fetch"]["ps"], 10 * US)
        self.assertEqual(st["data phase"]["ps"], 10 * US)
        self.assertEqual(st["doorbell to completion"]["ps"], 50 * US)
        self.assertEqual(st["doorbell to fetch"]["owner"], "device")
        self.assertEqual(st["data phase"]["owner"], "link")

    def test_labels_have_a_basis(self):
        r = rec(1, 0x02, [0, 0, 7, 0, 0, 0])
        self.assertEqual(C.label_for(r, 40 * US, p90=100 * US, p99=200 * US), "typical for its kind in this capture")
        self.assertEqual(C.label_for(r, 150 * US, p90=100 * US, p99=200 * US), "slowest 10 % of its kind in this capture")
        self.assertEqual(C.label_for(r, 250 * US, p90=100 * US, p99=200 * US), "slowest 1 % of its kind in this capture")
        self.assertEqual(C.label_for(r, 31 * SEC, p90=100 * US, p99=200 * US), "over the host's limit (30 s)")
        a = rec(0, 0x06, [1, 0, 0, 0, 0, 0])
        self.assertEqual(C.label_for(a, 61 * SEC, None, None), "over the host's limit (60 s)")
        f = rec(0, 0x80, [0, 0, 0, 0, 0, 0])
        self.assertEqual(C.label_for(f, 5 * SEC, None, None), "long by nature")
        lost = rec(1, 0x02, [0, 0, 7, 0, 0, 0], end="lost", lost="controller disable", t_cqe=None)
        self.assertTrue(C.label_for(lost, None, None, None).startswith("no completion"))
        self.assertIn("30 s", C.HOST_LIMIT_SOURCE)
        self.assertIn("no per-command limit", C.HOST_LIMIT_SOURCE)

    def test_percentiles_and_buckets(self):
        self.assertEqual(C.percentile([1, 2, 3, 4, 5], .5), 3)
        s = C.stats([5 * US, 1 * US, 3 * US])
        self.assertEqual((s["min"], s["max"], s["n"]), (1 * US, 5 * US, 3))
        b = C.bucket_counts([5 * US, 15 * US, 250 * US], C.LAT_BUCKETS, US)
        self.assertEqual([x["count"] for x in b][:2], [1, 1])
        self.assertEqual(b[-1]["count"], 1)
        sz = {x["bucket"]: x["count"] for x in C.size_bucket_counts([4096, 8192, 1 << 21])}
        self.assertEqual((sz["4K"], sz["4K < N ≤ 8K"], sz["1024K < N"]), (1, 1, 1))

    def test_pieces_map_data_packets_to_lbas(self):
        r = rec(1, 0x02, [1000, 0, 15, 0, 0, 0], pages=[0x1000, 0x2000],
                pkts=[[50, 0x1000, 4096, 31 * US], [51, 0x2000, 4096, 32 * US]])
        p = C.pieces_of(r)
        self.assertEqual([x["lba"] for x in p], [1000, 1008])
        self.assertEqual(p[1]["since_fetch_ps"], 22 * US)


class ErrorsBelongToTheCommand(unittest.TestCase):
    def test_only_the_commands_identity_or_packets_attach_a_finding(self):
        r = rec(1, 0x02, [0, 0, 7, 0, 0, 0], pkt_db=90, pkt_fetch=100, pkt_sqe=101, pkt_cqe=120,
                pkts=[[110, 0x1000, 4096, 31 * US]])
        mine = (110, 31 * US, "DLL.LCRC_BAD", "Downstream", "bad LCRC", (("psn", "Downstream", 5, 110), ("cmd", 1, 7, 100)), ())
        other = (115, 32 * US, "DLL.LCRC_BAD", "Downstream", "bad LCRC elsewhere", (("psn", "Downstream", 6, 115),), ())
        ctx = (101, 30 * US, "NVME.QUEUE_CHANGE", "", "queue", (("cmd", 1, 7, 100),), ())
        by_pkt, by_cmd = {}, {}
        for f in (mine, other, ctx):
            by_pkt.setdefault(f[0], []).append(f)
            for k in f[5]:
                if k[0] == "cmd":
                    by_cmd.setdefault((k[1], k[2], k[3]), []).append(f)
        errs = C.errors_for(r, by_pkt, by_cmd, {110: ("INC-0003", ["DLL.LCRC_BAD", "DLL.NAK"])})
        self.assertEqual([e["pkt"] for e in errs], [110])          # the other packet's error is not ours; context is not an error
        self.assertEqual(errs[0]["defect"], "INC-0003")
        self.assertEqual(errs[0]["defect_rules"], ["DLL.LCRC_BAD", "DLL.NAK"])


class EndToEnd(unittest.TestCase):
    """The sample capture with hex payload: the engine logs every command, the summary names kinds, parameters,
    latencies and the packet errors under them."""
    @classmethod
    def setUpClass(cls):
        if not os.path.exists(SAMPLE):
            raise unittest.SkipTest("sample trace not shipped with the code-only package: %s" % SAMPLE)
        cls.run_dir = tempfile.mkdtemp(prefix="cmdtest_")
        env = dict(os.environ, PYTHONPATH=STAGE1)
        for args in (["analyze", "--csv", SAMPLE, "--out", cls.run_dir],
                     ["isolate", "--run", cls.run_dir, "--library", LIBRARY, "--csv", SAMPLE],
                     ["commands", "--run", cls.run_dir]):
            p = subprocess.run([sys.executable, "-m", "pcie_isolate.cli"] + args, cwd=STAGE1, env=env,
                               capture_output=True, text=True, timeout=300)
            assert p.returncode == 0, p.stderr[-800:]
        cls.summary = json.load(open(os.path.join(cls.run_dir, "command_summary.json")))

    def test_every_command_is_logged_once(self):
        lines = [json.loads(l) for l in open(os.path.join(self.run_dir, "commands.jsonl"))]
        self.assertEqual(len(lines), self.summary["n_commands"])
        self.assertGreater(len(lines), 100)
        self.assertEqual(len({(r["sqid"], r["cid"], r["inst"]) for r in lines}), len(lines))

    def test_kinds_have_the_four_columns(self):
        names = {t["name"] for t in self.summary["types"]}
        self.assertTrue({"Read", "Write", "Identify", "Create I/O SQ"} <= names, names)
        rd = next(t for t in self.summary["types"] if t["name"] == "Read")
        self.assertEqual(rd["parameters"]["fields"][:3], ["NSID", "SLBA", "NLB"])
        self.assertIn("LBA range", rd["parameters"]["observed"])
        self.assertIsNotNone(rd["latency"]["total"])
        self.assertEqual([s["step"] for s in rd["latency"]["steps"]][0], "doorbell to fetch")
        self.assertIn("host_limit_s", rd["latency"])
        self.assertIsInstance(rd["errors"], list)
        self.assertEqual(sum(rd["status"].values()), rd["count"])

    def test_examples_carry_pieces_and_steps(self):
        rd = next(t for t in self.summary["types"] if t["name"] == "Read")
        ex = rd["examples"][0]
        self.assertTrue(ex["pieces"])
        self.assertEqual(len(ex["steps"]), 5)
        self.assertTrue(ex["label"])
        self.assertTrue(any(p[0] == "SLBA" for p in ex["params"]))

    def test_error_rows_tie_command_parameters_time_and_packets(self):
        s = self.summary
        self.assertEqual(s["n_error_rows"], len(s["error_rows"]))
        self.assertGreater(s["n_error_rows"], 0)
        kinds = {k["kind"] for k in s["error_kinds"]}
        self.assertTrue(kinds)
        for r in s["error_rows"][:20]:
            self.assertTrue(r["kinds"] and set(r["kinds"]) <= kinds)
            self.assertTrue(r["params"])                      # the parameters it carried
            self.assertEqual(len(r["steps"]), 5)              # the time, step by step
            self.assertTrue(r["errors"] or r["end"] != "cqe" or (r["status"] and not r["status"].startswith("Successful")))
            self.assertTrue(r["label"])
        # every row has a reason to be there: a failed status, no completion, or a packet-level error
        self.assertTrue(all(r["errors"] or r["end"] != "cqe" or not (r["status"] or "").startswith("Successful")
                            for r in s["error_rows"]))

    def test_basis_is_written_down(self):
        b = self.summary["basis"]
        for k in ("parameters", "latency", "labels", "errors"):
            self.assertTrue(b[k])
        self.assertIn("NVMe Base 2.0", b["parameters"])
        self.assertIn("io_timeout = 30 s", b["labels"])

    def test_rows_detail_and_csv(self):
        r = C.rows(self.run_dir, kind="io/0x02", only_errors=False, sort="latency", limit=5)
        self.assertEqual(len(r["rows"]), 5)
        self.assertGreaterEqual(r["rows"][0]["latency_ps"], r["rows"][-1]["latency_ps"])
        one = r["rows"][0]
        d = C.detail(self.run_dir, one["sqid"], one["cid"], one["inst"])
        self.assertEqual(d["name"], "Read")
        self.assertEqual(len(d["steps"]), 5)
        n = C.to_csv(self.run_dir, os.path.join(self.run_dir, "commands.csv"))
        self.assertEqual(n, self.summary["n_commands"])
        head = open(os.path.join(self.run_dir, "commands.csv")).readline()
        self.assertTrue(head.startswith("queue,cid,class,opcode,command,"))


if __name__ == "__main__":
    unittest.main()


class ManagementView(unittest.TestCase):
    def test_who_by_status_follows_the_specification(self):
        self.assertEqual(C.who_by_status((2, 0x80, 0))[0], "device")      # Write Fault: media error
        self.assertEqual(C.who_by_status((0, 0x80, 1))[0], "host")        # LBA Out of Range: the host addressed it
        self.assertEqual(C.who_by_status((0, 0x03, 1))[0], "host")        # Command ID Conflict
        self.assertEqual(C.who_by_status((0, 0x06, 0))[0], "device")      # Internal Error
        self.assertEqual(C.who_by_status((3, 0x00, 0))[0], "platform")    # path related
        self.assertEqual(C.who_by_status((0, 0, 0)), (None, None))

    def test_wilson_interval(self):
        lo, hi = C.wilson(6, 111)
        self.assertTrue(0.02 < lo < 0.06 and 0.09 < hi < 0.13)
        self.assertEqual(C.wilson(0, 0), (0.0, 0.0))

    def test_lines_are_built_from_facts_only(self):
        f = {"kind": "Write", "klass": "I/O", "opcode": "0x01", "called": 111, "went_wrong": 6, "rate": 6 / 111,
             "rate_ci": (0.025, 0.11), "failed_status": 6, "never_completed": 0, "packet_errors_on_successful": 0,
             "over_host_limit": 0, "statuses": [{"status": "Write Fault (media and data integrity error, SCT 2 SC 0x80)", "count": 6, "side": "device", "reason": "the media could not be written"}],
             "responsible": {"device": 6}, "separating": [{"attribute": "FUA (Force Unit Access)", "value": "set", "failed": 6, "total": 6, "rate": 1.0, "others_failed": 0, "others_total": 105}],
             "lba": {"lba_min": 2108560, "lba_max": 2108624, "blocks": [8], "all_lba_min": 2099336, "all_lba_max": 2114984},
             "packets": [{"rule": "NVME.STATUS", "text": "CQE with non-zero status", "layer": "nvme", "count": 6, "example_pkts": [49559, 49571]}],
             "defects": ["INC-0009", "INC-0010"],
             "timing": {"usual_successful": "19.4 µs", "usual_successful_ps": 19400000, "successful_n": 105, "failed_min": "9.5 µs", "failed_max": "20.1 µs", "host_limit_s": 30, "spec_note": "the NVMe specification sets no completion time for Write"}}
        L = C.management_lines(f)
        text = " ".join(L)
        self.assertIn("called 111 times; 6 went wrong (5 %", text)
        self.assertIn("assigns this code to the device: the media could not be written", text)
        self.assertIn("6 of the 6 problems carry FUA (Force Unit Access) = set", text)
        self.assertIn("Defect 9, Defect 10", text)
        self.assertIn("usually takes 19.4 µs (median of 105)", text)
        self.assertIn("6 point at the device", text)

    def test_narrative_check_rejects_new_numbers_and_sides(self):
        from pcie_isolate import command_narrative as N
        facts = {"kind": "Write", "called": 111, "went_wrong": 6, "rate_percent": 5, "rate_interval_percent": [3, 11],
                 "statuses": [{"status": "Write Fault", "count": 6, "side": "device", "reason": "the media could not be written"}],
                 "responsible": {"device": 6}, "separating": [], "packets": [], "defects": [], "timing": {"host_limit_s": 30}, "lines": []}
        ok, why = N.check({"headline": "Write went wrong 6 of 111 times (5 %); the device could not write the media.",
                           "what_happens": "All 6 returned Write Fault.", "tell_the_team": "Start with the device."}, facts)
        self.assertTrue(ok, why)
        ok, why = N.check({"headline": "Write went wrong 7 of 111 times.", "what_happens": "", "tell_the_team": ""}, facts)
        self.assertFalse(ok); self.assertIn("7", why)
        ok, why = N.check({"headline": "Write went wrong 6 times.", "what_happens": "", "tell_the_team": "Blame the platform."}, facts)
        self.assertFalse(ok); self.assertIn("platform", why)
        ok, why = N.check({"headline": "Write went wrong 6 times.", "what_happens": "This is caused by a firmware bug.", "tell_the_team": ""}, facts)
        self.assertFalse(ok); self.assertIn("cause", why)
        ok, why = N.check({"headline": "x " * 250, "what_happens": "", "tell_the_team": ""}, facts)
        self.assertFalse(ok); self.assertEqual(why, "too long")

    def test_narrative_falls_back_to_facts_without_a_model(self):
        from pcie_isolate import command_narrative as N
        run = tempfile.mkdtemp(prefix="narr_")
        summ = {"management": [{"kind": "Write", "klass": "I/O", "opcode": "0x01", "called": 2, "went_wrong": 1, "rate": .5, "rate_ci": (.1, .9),
                                "failed_status": 1, "never_completed": 0, "packet_errors_on_successful": 0, "over_host_limit": 0,
                                "statuses": [], "responsible": {}, "separating": [], "lba": None, "packets": [], "defects": [],
                                "timing": {"host_limit_s": 30}, "lines": ["Write was called 2 times; 1 went wrong.", "For the team: look."]}]}
        json.dump(summ, open(os.path.join(run, "command_summary.json"), "w"))
        N.narrate(run, backend="dry-run")
        out = json.load(open(os.path.join(run, "command_summary.json")))
        m = out["management"][0]
        self.assertEqual(m["narrative"]["headline"], "Write was called 2 times; 1 went wrong.")
        self.assertIn("no model", m["narrative_source"])
        self.assertEqual(out["narrative"]["model_calls"], 0)

    def test_end_to_end_management_entries(self):
        if not hasattr(EndToEnd, "summary"):
            EndToEnd.setUpClass()
        s = EndToEnd.summary
        self.assertIn("management", s)
        for m in s["management"]:
            self.assertGreater(m["went_wrong"], 0)
            self.assertTrue(m["lines"])
            self.assertIn("narrative", m)
            self.assertTrue(m["narrative"]["headline"])
            self.assertIn("sentences built from the facts", m["narrative_source"])   # dry-run backend in the test


class EdgeCases(unittest.TestCase):
    """Adversarial inputs: captures without payload, commands that never complete, missing doorbells, unknown
    status codes, commands with no successful peer, a model answer that plays with number formats."""

    def test_no_payload_capture_gives_an_empty_but_honest_summary(self):
        run = tempfile.mkdtemp(prefix="nopay_")
        open(os.path.join(run, "commands.jsonl"), "w").close()
        s = C.build(run)
        self.assertEqual((s["n_commands"], s["n_types"], s["n_error_rows"]), (0, 0, 0))
        self.assertEqual(s["management"], [])
        self.assertEqual(C.rows(run, kind="io/0x02"), {"total": 0, "rows": []})
        self.assertIsNone(C.detail(run, 1, 1, None))
        self.assertEqual(C.to_csv(run, os.path.join(run, "c.csv")), 0)
        run2 = tempfile.mkdtemp(prefix="nofile_")
        s2 = C.build(run2)                                  # no commands.jsonl at all
        self.assertEqual(s2["n_commands"], 0)

    def _run_with(self, recs):
        run = tempfile.mkdtemp(prefix="edge_")
        with open(os.path.join(run, "commands.jsonl"), "w") as f:
            for r in recs:
                f.write(json.dumps(r) + "\n")
        return run, C.build(run)

    def test_lost_and_open_commands_have_no_latency_and_count_as_never_completed(self):
        lost = rec(1, 0x02, [0, 0, 7, 0, 0, 0], end="lost", lost="controller disable", t_cqe=None, status=None, end_t=5 * SEC, inst=10)
        eof = rec(1, 0x02, [0, 0, 7, 0, 0, 0], end="eof", lost="open at capture end", t_cqe=None, status=None, end_t=9 * SEC, inst=20, cid=8)
        good = rec(1, 0x02, [0, 0, 7, 0, 0, 0], inst=30, cid=9)
        run, s = self._run_with([lost, eof, good])
        t = s["types"][0]
        self.assertEqual((t["count"], t["completed"], t["not_completed"]), (3, 1, 2))
        self.assertEqual(s["n_not_completed"], 2)
        rows = {r["cid"]: r for r in s["error_rows"]}
        self.assertTrue(rows[7]["label"].startswith("no completion"))
        self.assertEqual(rows[7]["latency"], "5.000 s")             # how long it was outstanding, not a completion time
        m = s["management"][0]
        self.assertEqual(m["never_completed"], 2)
        self.assertEqual(m["responsible"], {})                       # no status code, so no side is named
        self.assertTrue(any("never completed" in l for l in m["lines"]))
        self.assertTrue(any("status codes name no side" in l for l in m["lines"]))

    def test_missing_doorbell_measures_from_the_fetch(self):
        r = rec(1, 0x02, [0, 0, 7, 0, 0, 0], t_db=None, inst=5)
        self.assertEqual(C.total_latency(r), 40 * US)
        st = {x["step"]: x["ps"] for x in C.steps_of(r)}
        self.assertIsNone(st["doorbell to fetch"])
        self.assertEqual(st["doorbell to completion"], 40 * US)

    def test_unknown_and_path_status_codes(self):
        self.assertTrue(C.status_words((0, 0x7E, 0)).startswith("status code 0x7E"))
        self.assertEqual(C.who_by_status((0, 0x7E, 0))[0], "undetermined")
        self.assertEqual(C.who_by_status((3, 0x71, 0))[0], "platform")
        self.assertEqual(C.who_by_status((7, 0x10, 0))[0], "undetermined")   # vendor specific
        r = rec(1, 0x02, [0, 0, 7, 0, 0, 0], status=[7, 0x10, 1])
        run, s = self._run_with([r])
        self.assertEqual(s["management"][0]["statuses"][0]["side"], "undetermined")

    def test_all_commands_failed_gives_no_contrast_and_no_usual_time(self):
        recs = [rec(1, 0x01, [i * 8, 0, 7 | 1 << 30, 0, 0, 0], status=[2, 0x80, 0], cid=i, inst=100 + i) for i in range(5)]
        run, s = self._run_with(recs)
        m = s["management"][0]
        self.assertEqual((m["called"], m["went_wrong"]), (5, 5))
        self.assertEqual(m["separating"], [])                        # nothing to compare against
        self.assertIsNone(m["timing"]["usual_successful"])
        self.assertTrue(any("No successful Write" in l for l in m["lines"]))
        self.assertEqual(m["rate_ci"][1], 1.0)

    def test_contrast_needs_a_large_enough_comparison_group(self):
        bad = [rec(1, 0x01, [0, 0, 7 | 1 << 30, 0, 0, 0], status=[2, 0x80, 0], cid=i, inst=100 + i) for i in range(3)]
        few_ok = [rec(1, 0x01, [0, 0, 7, 0, 0, 0], cid=50 + i, inst=500 + i) for i in range(4)]       # 4 without FUA: too few
        run, s = self._run_with(bad + few_ok)
        self.assertFalse(any(c["attribute"].startswith("FUA") for c in s["management"][0]["separating"]))
        many_ok = [rec(1, 0x01, [0, 0, 7, 0, 0, 0], cid=50 + i, inst=500 + i) for i in range(20)]
        run, s = self._run_with(bad + many_ok)
        sep = {c["attribute"]: c for c in s["management"][0]["separating"]}
        self.assertIn("FUA (Force Unit Access)", sep)
        self.assertEqual((sep["FUA (Force Unit Access)"]["failed"], sep["FUA (Force Unit Access)"]["others_failed"]), (3, 0))

    def test_lba_size_changes_bytes_but_not_blocks(self):
        d = {r[0]: r[1] for r in C.param_rows(rec(1, 0x02, [0, 0, 15, 0, 0, 0], lba_bytes=4096))}
        self.assertEqual((d["NLB"], d["bytes"]), (16, 65536))

    def test_narrative_check_number_formats(self):
        from pcie_isolate import command_narrative as N
        facts = {"kind": "Write", "opcode": "0x08", "called": 2108560, "went_wrong": 6, "rate_percent": 5,
                 "responsible": {"device": 6}, "statuses": [], "separating": [], "packets": [], "defects": [], "timing": {"usual_successful": "19.4 µs"}, "lines": []}
        ok, why = N.check({"headline": "2,108,560 calls; opcode 0x08; 6 failed (5%); usual 19.4 microseconds.", "what_happens": "", "tell_the_team": ""}, facts)
        self.assertTrue(ok, why)
        ok, why = N.check({"headline": "usual 0.0194 ms", "what_happens": "", "tell_the_team": ""}, facts)
        self.assertFalse(ok)                                          # a converted unit is a number the facts do not hold
        ok, why = N.check({"headline": "the data was bad", "what_happens": "", "tell_the_team": ""}, facts)
        self.assertTrue(ok, why)                                      # 'data' is a word, not a side

    def test_rows_paging_and_filters(self):
        recs = [rec(1, 0x02, [0, 0, 7, 0, 0, 0], cid=i, inst=1000 + i, t_cqe=(50 + i) * US) for i in range(12)]
        recs[3]["status"] = [0, 0x80, 1]
        run, s = self._run_with(recs)
        r = C.rows(run, kind="io/0x02", only_errors=True)
        self.assertEqual([x["cid"] for x in r["rows"]], [3])
        r = C.rows(run, kind="io/0x02", sort="packet", offset=10, limit=5)
        self.assertEqual((r["total"], [x["cid"] for x in r["rows"]]), (12, [10, 11]))
        r = C.rows(run, kind="admin/0x06")
        self.assertEqual(r["total"], 0)
        self.assertEqual(C.rows(run, offset=99)["rows"], [])
