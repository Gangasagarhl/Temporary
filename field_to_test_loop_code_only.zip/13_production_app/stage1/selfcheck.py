#!/usr/bin/env python3
"""Verify this package on the target machine before running a real capture.

  python3 selfcheck.py              # environment + unit fixtures + a 1000-row end-to-end run (no LLM)
  python3 selfcheck.py --llm        # also one real LLM call through the selected backend

Exit code 0 = ready. Every check prints PASS / FAIL / SKIP with the reason.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
PY = sys.executable
results = []


def check(name, ok, note=""):
    results.append((name, ok))
    print("%-5s %s%s" % ("PASS" if ok else ("SKIP" if ok is None else "FAIL"), name, (" - " + note) if note else ""))


def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


print("python %s at %s" % (sys.version.split()[0], PY))
check("python >= 3.10", sys.version_info >= (3, 10))
try:
    import numpy
    check("numpy", True, numpy.__version__)
except ImportError:
    check("numpy", False, "run:  %s -m pip install -r requirements.txt" % PY)
    print("\nNOT READY: numpy is required for every stage. Install it for this interpreter and re-run.")
    sys.exit(1)

sys.path.insert(0, HERE)
try:
    from pcie_isolate.llm import import_anthropic   # noqa: E402
    try:
        a = import_anthropic()
        check("anthropic SDK", True, "%s (%s)" % (a.__version__, "installed" if "vendor" not in a.__file__ else "vendored"))
    except SystemExit as e:
        check("anthropic SDK", None, "SDK backend unavailable: " + str(e).splitlines()[0][:90])
except Exception as e:  # pragma: no cover
    check("anthropic SDK", False, str(e)[:100])

check("claude CLI", bool(shutil.which("claude")) or None, "found" if shutil.which("claude") else "not installed (CLI backend off)")
has_key = bool(os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"))
check("API credentials", has_key or None, "set" if has_key else "none (set ANTHROPIC_API_KEY / ANTHROPIC_BASE_URL)")
check("signature library", os.path.exists("runs/signature_library.json"))
check("reference header", os.path.exists(os.path.join(os.path.dirname(HERE), "01_input_files", "final_113_columns.csv"))
      or os.path.exists("reference/final_113_columns.csv"), "")

r = run([PY, "-m", "unittest", "discover", "-s", "tests"])
check("unit fixtures (14)", r.returncode == 0, r.stderr.strip().splitlines()[-1] if r.stderr else "")

# end-to-end on the bundled sample
sample = "reference/sample_1000_rows.csv"
if os.path.exists(sample):
    out = tempfile.mkdtemp(prefix="pcie_selfcheck_")
    r = run([PY, "-m", "pcie_isolate.cli", "analyze", "--csv", sample, "--out", out])
    ok = r.returncode == 0 and os.path.exists(os.path.join(out, "findings.pkl"))
    check("end-to-end analyze on sample", ok, (r.stderr or r.stdout).strip().splitlines()[-1][:100] if not ok else "")
    if ok:
        r = run([PY, "-m", "pcie_isolate.cli", "isolate", "--run", out, "--library", "runs/signature_library.json",
                 "--csv", sample])
        check("end-to-end isolate on sample", r.returncode == 0, (r.stderr or "").strip().splitlines()[-1][:100] if r.returncode else "")
        r = run([PY, "-m", "pcie_isolate.cli", "report", "--run", out])
        check("end-to-end report on sample", r.returncode == 0 and os.path.exists(os.path.join(out, "isolation.json")))
        ep = os.path.join(out, "errors.txt")
        open(ep, "w").write("link went down and came back at a lower speed\nread completed with status 0x80\n")
        r = run([PY, "-m", "pcie_isolate.cli", "verify", "--run", out, "--expected", ep, "--backend", "dry-run"])
        check("end-to-end verify (error list) on sample", r.returncode == 0 and
              os.path.exists(os.path.join(out, "expected_errors_report.md")),
              (r.stderr or "").strip().splitlines()[-1][:100] if r.returncode else "")
        if "--llm" in sys.argv:
            r = run([PY, "-m", "pcie_isolate.cli", "review", "--run", out, "--limit", "1"])
            rev = os.path.join(out, "llm_reviews.jsonl")
            if os.path.exists(rev) and os.path.getsize(rev):
                rec = json.loads(open(rev).readline())
                check("LLM review (1 incident)", "error" not in rec, rec.get("error") or
                      "%s via %s, verdict %s" % (rec.get("model"), rec.get("backend"), rec.get("verdict")))
            else:
                check("LLM review (1 incident)", None, (r.stdout or r.stderr).strip().splitlines()[-1][:100])
    shutil.rmtree(out, ignore_errors=True)
else:
    check("end-to-end on sample", None, "reference/sample_1000_rows.csv not present")

bad = [n for n, ok in results if ok is False]
print("\n%s" % ("READY" if not bad else "NOT READY: " + ", ".join(bad)))
sys.exit(1 if bad else 0)
