# PCIe/NVMe defect isolation from a 113-column analyzer CSV

CSV in, isolated defects out. One streaming pass over a Teledyne-LeCroy-style export (any size; 4 GB takes
~5 minutes on one core) finds every wire-visible protocol defect, isolates each one to its packets, names the
atlas card, says who caused it and why, attaches the evidence rows and the fix, and has an LLM confirm the
verdict on the rows alone.

```
python3 selfcheck.py                                           # 1. is this machine ready?  (~5 s)
python3 -m pcie_isolate.cli run --csv CAPTURE.csv --out runs/x # 2. everything, one command
#   add --expected errors.txt when you already have a list of errors to verify and isolate
cat runs/x/isolation_report.md                                 # 3. the result
```

Requirements: Python >= 3.10, numpy; for the LLM step the `anthropic` SDK (`pip install -r requirements.txt`;
a copy for CPython 3.13 / x86-64 Linux is vendored in `vendor/`) **or** a local Claude Code login (`claude` CLI).
No credentials: `review` writes the prompts and the rest of the pipeline still runs.

## What you get per defect (`isolation.json`, `isolation_report.md`)

| field | content |
|---|---|
| `status` | `ISOLATED` (engine + LLM agree) · `ISOLATED_WIRE_ONLY` (no LLM run) · `NEEDS_OUTSIDE_EVIDENCE` (symptom only; names the document to collect) · `DISPUTED` (LLM disagrees: inspect by hand) · `SYNTHESISED` (synthetic traces only) |
| `defect` | atlas card id + title, pattern, layer, alternatives, ambiguity group |
| `where` | **CSV lines from-to** (1-based, header = line 1), start/end packet and time, first abnormal row, root-cause node, evidence packets |
| `who` | host / device / platform / link / test setup, and the atlas XII.8 rule that decided it |
| `why` | mechanism, typical causes, how it shows up, spec basis, the engine rule texts |
| `context` | the host task before the incident, the NVMe command (opcode, CID, SQ, SLBA, PRPs) |
| `evidence` | each finding with its CSV line, packet, **role** (root / cascade / independent, atlas VII.6.1), the rows that carry it, and the reviewer's verdict on that rule |
| `fix` | corrective / validation action, how to prove it, Linux driver path (v7.2) |
| `llm_review` | backend, model, verdict, confidence, card, responsible party, rules confirmed/refuted, root and cascade packets, hypotheses, evidence still needed, summary (OBSERVED/RULE/HYPOTHESIS), unseen-citation check |
| `acceptance` | the atlas IX.4.1 acceptance test for an AI conclusion, evaluated per record |

## The pipeline

```
analyze  one pass: capture integrity -> link/LTSSM -> data link (PSN, Ack/Nak, replay) -> flow control
         -> transactions (RequesterID+Tag) -> config shadow -> NVMe registers, doorbells, SQE/CQE, MSI-X, PRPs
         -> data ledger -> statistics (rarity, timing, shifts)            162 rules, 4 tiers
fuse     optional: dmesg -x + host_events.jsonl, clock-aligned, placed on the packet axis (tier H)
isolate  findings -> incidents: clustering, evidence graph, first abnormal row, XII.8 attribution,
         signature library -> atlas card, task and command context, rows start-15..end+15
review   LLM confirmation per incident (claude-haiku-5-5, effort low, JSON schema; cached static prefix)
report   engine + atlas + LLM -> isolation.json / isolation_report.md
review --capture-check   one model call: can this capture show what you are looking for? -> capture_assessment.json
verify   a list of errors already found (--expected errors.txt) checked against the incidents: FOUND with
         CSV lines / evidence / fix, or NOT FOUND with the capture condition that explains it -> expected_errors_report.md
```

Every stage is a sub-command (`python3 -m pcie_isolate.cli <stage> --help`). `run` chains them.

## LLM backends (`--backend`)

| | transport | when |
|---|---|---|
| `sdk` | Anthropic SDK; `ANTHROPIC_API_KEY` (+ `ANTHROPIC_BASE_URL` for a gateway); `--batch` = Message Batches at half price | production |
| `cli` | local `claude -p --effort low` with the package's own system prompt and JSON schema | development without a key (~$0.19/incident, no prefix cache) |

Validate on a stratified sample first: `review --sample-per-bucket` reviews one incident per (layer, first rule)
bucket - every defect family the run contains - at a fraction of the cost.
| `dry-run` | writes `llm_prompts.jsonl` only | no credentials |
| `auto` | sdk if a key is set, else cli if installed, else dry-run | default |

Swapping to another vendor's endpoint: `AGENT_INSTRUCTIONS_real_environment.md`, section 1b (one function).

## Layout

| path | what |
|---|---|
| `pcie_isolate/engine.py` | the streaming pass and all trackers |
| `pcie_isolate/rules.py` | rule catalogue: tier (A stateless, B stateful, N payload, S statistics, H outside evidence), verdict, layer, atlas patterns |
| `pcie_isolate/statistics.py` | approach C: rarity windows, timing outliers, latency shifts, stalls |
| `pcie_isolate/host_evidence.py` | outside evidence: parsers, clock alignment, placement |
| `pcie_isolate/incidents.py` | clustering, evidence graph, attribution, context, evidence rows |
| `pcie_isolate/atlas.py` | atlas card text, signature library, card classifier |
| `pcie_isolate/llm.py` | prompt builder (one static prefix + compact incident), three backends, schema |
| `pcie_isolate/isolation.py` | the final per-defect record and report |
| `pcie_isolate/verify.py` | known-error list verification: matching, capture checklist, model research |
| `LLM_REVIEWER_INSTRUCTIONS.md` | the reviewer's discipline (Part A) and the agent's operating loop incl. "nothing found" and "error list" flows (Part B) |
| `MAIL_TO_AGENTS.md` | mail-safe brief for the team receiving the zip (placeholders for key, URL, model) |
| `pcie_isolate/evaluate.py`, `report.py` | scoring against synthetic ground truth |
| `runs/signature_library.json` | per-card finding signatures (learned on two calibration captures) |
| `runs/run_4GB/` | results on the 4 GB synthetic trace: `isolation.json`, `isolation_report.md`, `evaluation.json`, reviews |
| `reference/` | the 485 atlas cards, the column header, a 1000-row sample used by `selfcheck.py`, `example_errors_4GB.txt` (a tester-style error list for the 4 GB run) |
| `tests/test_fixtures.py` | 14 adversarial fixtures (`python3 -m unittest discover -s tests`) |
| `PRODUCTION_READINESS.md` | flow, column usage, threshold provenance, spec baseline, acceptance test, limits, checklist |
| `tools/build_payload_sidecar.py` | payload sidecar for exports whose DATA column holds only sizes |
| `tools/simulate_host_evidence.py` | SIMULATED host documents for synthetic captures (testing only) |
| `calibration/` | the two calibration captures (not in the zip; rebuild below) |

## Results on the 4 GB synthetic trace (485 injected defects)

| approach | detected | false positives in healthy traffic |
|---|---|---|
| wire only (CSV + payload) | **437 / 485** | 0 |
| + outside evidence (simulated here) | **483 / 485** | 2 findings at 1 place |

544 incidents, 0 in healthy traffic; atlas card ranked first 387 / 483, top-3 442. LLM review on 88 stratified
incidents (every defect family): 51 confirmed, 36 inconclusive, 0 disputed after the engine fixes the reviews drove,
0 invented rule ids. Capture check: adequate, gaps named. Error-list verify on 10 tester-style errors: 10/10 matched.
Full account: `REPORT_defect_isolation.md`; production notes: `PRODUCTION_READINESS.md`.

## Real capture checklist

1. Export the packet view with **payload expanded** (DATA as hex) from boot or link-up.
2. `python3 selfcheck.py` on the target machine.
3. Collect `dmesg -x` (and other tools' errors in `host_events.jsonl`) at the same time; see
   `AGENT_INSTRUCTIONS_real_environment.md` section 2.
4. `run --csv ... --dmesg ... --events ... --nsze 0x<blocks> --backend sdk --batch`.
5. The engine must report **0 incidents on a known-good capture of the same system** before its findings on a faulty
   one mean anything; tune modeled thresholds with `--profile` if it does not.

## Rebuilding the calibration captures (signature library)

```bash
python3 tools/build_payload_sidecar.py --target-bytes 0 --seed 7  --out calibration/seed7  --write-csv calibration/seed7/calib_seed7.csv  --keep-truth
python3 tools/build_payload_sidecar.py --target-bytes 0 --seed 11 --out calibration/seed11 --write-csv calibration/seed11/calib_seed11.csv --keep-truth
python3 -m pcie_isolate.cli analyze --csv calibration/seed7/calib_seed7.csv --payload calibration/seed7/payload_sidecar.csv --nsze 0x3A386030 --out runs/calib_seed7
python3 -m pcie_isolate.cli analyze --csv calibration/seed11/calib_seed11.csv --payload calibration/seed11/payload_sidecar.csv --nsze 0x3A386030 --out runs/calib_seed11
python3 -m pcie_isolate.cli library --calib-run runs/calib_seed7 --calib-truth calibration/seed7/_generator_truth \
    --calib-run runs/calib_seed11 --calib-truth calibration/seed11/_generator_truth --out runs/signature_library.json
```

(needs the generator in `../02_generator_and_validator_code`; the shipped library already covers all 485 cards.)
