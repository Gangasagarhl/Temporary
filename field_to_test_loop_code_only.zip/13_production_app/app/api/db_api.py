"""The knowledge database, read-only views + undo: overview, tables, one signature's graph, verdict cache."""
from flask import Blueprint, jsonify, request

from . import svc

bp = Blueprint("db", __name__)


@bp.get("/api/db/summary")
def summary():
    s = svc()
    with s.s2.lock:
        return jsonify(dict(s.s2.db_summary(), cache=s.cache.stats()))


@bp.get("/api/db/overview")
def overview():
    """Counts, the signatures with their causes / approved procedures / tests, recent events."""
    s = svc()
    with s.s2.lock:
        db, g = s.s2.db, s.s2.s2.graph
        sigs = []
        for sig, meta in db.all_signatures().items():
            sol = db.solutions(sig)
            sigs.append({"sig": sig, "pattern": meta["pattern"], "seen": (db.signature(sig) or {}).get("seen"),
                         "causes": len(db.causes(sig)), "procedures": len(sol),
                         "approved": sum(1 for x in sol if x["status"] == "admin-approved"),
                         "tests": sum(1 for x in g.nodes("test", sig)), "lessons": len(db.lessons(sig, 50))})
        sigs.sort(key=lambda x: (-(x["seen"] or 0), x["sig"]))
        ev = s.s2.db_table("event", 25, 0)
        return jsonify({"knowledge": db.stats(), "graph": g.stats(), "cache": s.cache.stats(), "llm": getattr(s.s2.llm, "name", "stand-in"),
                        "llm_usage": getattr(s.s2.llm, "usage", None), "counters": s.s2.s2.counters, "signatures": sigs,
                        "recent_events": ev["rows"] if ev else []})


@bp.get("/api/db/table/<name>")
def table(name):
    s = svc()
    with s.s2.lock:
        t = s.s2.db_table(name, int(request.args.get("limit", 200)), int(request.args.get("offset", 0)), request.args.get("sig"))
    return (jsonify(t), 200) if t else (jsonify({"error": "unknown table"}), 404)


@bp.get("/api/db/signature/<sig>")
def signature(sig):
    """One signature as a tree: causes -> procedures (with steps, counts, status) -> tests, plus lessons."""
    s = svc()
    with s.s2.lock:
        p = s.s2.procedures(sig)
        g = s.s2.s2.graph
        tree = []
        for c in p["causes"]:
            procs = [x for x in p["procedures"] if x["cause"].endswith("::" + c["id"])]
            for x in procs:
                x["tests"] = [{"id": t["dst"], "admitted": (t.get("test") or {}).get("props", {}).get("admitted")} for t in g.tests_for(x["scenario_id"])]
                x["chain"] = g.procedure_chain(x["scenario_id"])
            tree.append({"cause": c["id"], "content": c["content"], "edge": c["edge"], "procedures": procs})
        return jsonify({"sig": sig, "tree": tree, "solutions": p["solutions"], "lessons": p["lessons"]})


@bp.get("/api/db/cache")
def cache():
    s = svc()
    return jsonify({"stats": s.cache.stats(), "rows": s.cache.rows(int(request.args.get("limit", 200)))})


@bp.post("/api/db/undo")
def undo():
    s = svc()
    body = request.get_json(force=True) or {}
    if "event_id" not in body:
        return jsonify({"error": "event_id required"}), 400
    return jsonify(s.s2.undo(body["event_id"], body.get("actor", "admin")))
