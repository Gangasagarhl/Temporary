"""API blueprints. Each module exposes `bp` (a Flask Blueprint) and reads the shared services from the app config."""
from flask import current_app


def svc():
    return current_app.config["services"]


ACTION_HELP = {
    "accept": "Correct (+1): this procedure is right; it is re-run in the lab, then the test script is written",
    "accept_with_note": "Correct (+1), with a note that is kept with the procedure",
    "revise": "change the stored text of the ticked cause or the notes on a procedure (text in step 3); nothing runs in the lab and the earlier counts are reduced; to change the steps and run them use Needs changes on a card or the editor",
    "reject": "Not correct (-1): only this procedure is marked wrong",
    "not_reproducible": "ran it on the drive, the error did not appear (the procedure is not called wrong)",
    "wrong_signature": "stage 1 picked the wrong error type: recorded for the analysis team",
    "duplicate_of": "this cause is the same as another one: the two are merged (their histories are kept)",
    "rerank": "your order, best first (this does not count as \"correct\")",
    "prefer": "you prefer the first of the two ticked procedures, the one higher in the list (this does not count as \"correct\")", "tie": "no preference between the two",
    "promote": "approve this procedure so it is used as the saved procedure",
    "deprecate": "retire this procedure",
    "delete_request": "ask for a cause to be removed", "delete_approve": "confirm the removal of a cause",
    "undo": "undo one event by its number (shown as # in the decision history and on the Knowledge base page); the tables are rebuilt without it", "skip": "no decision now", "defer": "come back to this later",
    "escalate": "needs more evidence; a note is recorded", "lesson": "a note about this error; the next proposal must read it",
    "compose_tests": "make more test variants from the saved command sequences; each is run on the drive and kept only if the same error appears",
    "restart_failed": "failed trial (-1): recorded against the ticked procedure or cause; the search starts again with another random seed",
    "sweep": "try the procedure with each timing halved and doubled, every power state and a longer burst; variants that still show the error are saved as tests",
    "add_cause": "my own description of the cause",
    "add_procedure": "my own procedure: opens the editor below; your procedure is run in the lab before it is saved",
    "link": "copy a procedure saved for another error type under this cause, as a proposal (it runs in the lab when someone accepts it)", "split": "split a cause in two"}
