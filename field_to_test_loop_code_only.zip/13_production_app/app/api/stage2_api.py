"""Incidents and the stage-2 review queue: list, detail, prepare (lookup + LLM for every incident in the background,
cached), present (cached until the admin acts), act, state."""
import json
import os

from flask import Blueprint, jsonify, request

from . import ACTION_HELP, svc
from stage2_service import ACTIONS

bp = Blueprint("stage2", __name__)


@bp.get("/api/runs/<run_id>/incidents")
def list_incidents(run_id):
    s = svc()
    if not s.run_job(run_id):
        return jsonify({"error": "unknown run"}), 404
    return jsonify(s.incidents_of(run_id))


@bp.get("/api/runs/<run_id>/incidents/<inc_id>")
def get_incident(run_id, inc_id):
    s = svc()
    rd = s.run_dir_of(run_id)
    inc = next((i for i in s.load_json(os.path.join(rd, "incidents.json"), []) if i["id"] == inc_id), None)
    if inc is None:
        return jsonify({"error": "unknown incident"}), 404
    rows, review = [], None
    try:
        from stage1_adapter import signature_of
        topo = (s.load_json(os.path.join(rd, "run.json")) or {}).get("topology") or {}
        sig_obj = signature_of(s.s2.load(run_id, rd, s.firmware_of(s.run_job(run_id)))[inc_id], workload=(s.run_job(run_id) or {}).get("params", {}).get("label"),
                               device=(("device %s, root complex %s" % (topo.get("device_rid"), topo.get("rc_completer"))) if topo.get("device_rid") else None))
    except Exception as e:                       # noqa: BLE001
        sig_obj = {"error": str(e)[:120]}
    rp = os.path.join(rd, "incident_rows.jsonl")
    if os.path.exists(rp):
        with open(rp) as f:
            for line in f:
                d = json.loads(line)
                if d["id"] == inc_id:
                    rows = d.get("blocks", [])
                    break
    lp = os.path.join(rd, "llm_reviews.jsonl")
    if os.path.exists(lp):
        with open(lp) as f:
            for line in f:
                r = json.loads(line)
                if r["id"] == inc_id:
                    review = r
    iso = next((x for x in s.load_json(os.path.join(rd, "isolation.json"), []) if x["id"] == inc_id), None)
    return jsonify({"incident": inc, "signature": sig_obj, "rows": rows, "llm_review": review, "isolation": iso, "stage2": s.s2.state(rd, inc_id)})


STATUS_MEANING = {
    "ISOLATED": "the analyser's rules and the AI reviewer agree: the defect is isolated to these packets",
    "ISOLATED_WIRE_ONLY": "isolated from the packets alone; no second opinion was asked",
    "NEEDS_OUTSIDE_EVIDENCE": "the wire shows only the symptom; proof needs a document from the host or the lab (listed below)",
    "DISPUTED": "the AI reviewer disagreed with the analyser - inspect by hand",
    "SYNTHESISED": "synthetic capture (demo data only)"}


@bp.get("/api/runs/<run_id>/defect/<inc_id>")
def defect_record(run_id, inc_id):
    """Everything about one isolated defect, in the order a non-expert reads it: which error, where, how it is
    proven, the evidence rows, outside evidence (needed? from which source, why), what the LLM returned, the fix,
    the stage-2 state and the admin's earlier decisions on this card."""
    s = svc()
    rd = s.run_dir_of(run_id)
    if not rd or not s.run_job(run_id):
        return jsonify({"error": "unknown run"}), 404
    inc = next((i for i in s.load_json(os.path.join(rd, "incidents.json"), []) if i["id"] == inc_id), None)
    if inc is None:
        return jsonify({"error": "unknown incident"}), 404
    iso = next((x for x in s.load_json(os.path.join(rd, "isolation.json"), []) if x["id"] == inc_id), None) or {}
    rows, review = [], None
    rp = os.path.join(rd, "incident_rows.jsonl")
    if os.path.exists(rp):
        with open(rp) as f:
            for line in f:
                d = json.loads(line)
                if d["id"] == inc_id:
                    rows = d.get("blocks", [])
                    break
    lp = os.path.join(rd, "llm_reviews.jsonl")
    if os.path.exists(lp):
        with open(lp) as f:
            for line in f:
                r = json.loads(line)
                if r["id"] == inc_id:
                    review = r
    c = (inc.get("atlas_candidates") or [{}])[0]
    defect = iso.get("defect") or {"card_id": c.get("card_id"), "title": c.get("title"), "pattern": (inc.get("explanation") or {}).get("pattern"),
                                   "layer": inc.get("layer"), "alternatives": [x["card_id"] for x in (inc.get("atlas_candidates") or [])[1:3]]}
    who = iso.get("who") or inc.get("attribution") or {}
    fa = (iso.get("where") or {}).get("first_abnormal") or inc.get("first_abnormal") or {}
    ev = iso.get("evidence") or [{"rule": r, "verdict": inc.get("verdict"), "detail": "", "rows": []} for r in (inc.get("rules") or {})]
    outside = iso.get("outside_evidence") or []
    status = iso.get("status") or ("ISOLATED_WIRE_ONLY" if inc.get("verdict") == "CONFIRMED" else "NEEDS_OUTSIDE_EVIDENCE")
    proof = {"status": status, "status_meaning": STATUS_MEANING.get(status, status),
             "belongs_to": {"card": defect.get("card_id"), "title": defect.get("title"), "pattern": defect.get("pattern"), "layer": defect.get("layer"),
                            "of": 485, "alternatives": defect.get("alternatives") or [], "ambiguity_group": defect.get("ambiguity_group") or [],
                            "candidates": [{"card": x["card_id"], "title": x.get("title"), "score": x.get("score")} for x in (inc.get("atlas_candidates") or [])[:3]]},
             "first_abnormal": fa, "root_cause": (iso.get("where") or {}).get("root_cause_node") or inc.get("root_cause_node"),
             "rules": [{"rule": e.get("rule"), "verdict": e.get("verdict"), "detail": e.get("detail"), "packet": e.get("pkt"), "line": e.get("line"),
                        "role": e.get("role"), "llm": e.get("llm"), "rows": [r.get("row") for r in (e.get("rows") or [])][:6]} for e in ev],
             "attribution": {"origin": who.get("origin"), "decided_by": who.get("decided_by") or who.get("rule"), "card_badge": who.get("card_badge")},
             "needs_outside_evidence": status == "NEEDS_OUTSIDE_EVIDENCE" or bool(outside),
             "outside_evidence": [{"source": o.get("source"), "packet": o.get("pkt"), "text": o.get("text"),
                                   "why": "the packets show only the symptom; this %s line names the cause and happened at the time of packet #%s" % (o.get("source"), o.get("pkt"))} for o in outside],
             "evidence_to_collect": who.get("evidence_to_collect") or [],
             "acceptance": iso.get("acceptance") or {}}
    sig = defect.get("card_id")
    with s.s2.lock:
        history = s.s2.feedback_history(sig) if sig else []
    try:
        from stage1_adapter import signature_of
        topo = (s.load_json(os.path.join(rd, "run.json")) or {}).get("topology") or {}
        sig_obj = signature_of(s.s2.load(run_id, rd, s.firmware_of(s.run_job(run_id)))[inc_id], workload=(s.run_job(run_id) or {}).get("params", {}).get("label"),
                               device=(("device %s, root complex %s" % (topo.get("device_rid"), topo.get("rc_completer"))) if topo.get("device_rid") else None))
    except Exception as e:                       # noqa: BLE001
        sig_obj = {"error": str(e)[:120]}
    return jsonify({"run_id": run_id, "incident": inc, "defect": defect, "signature": sig_obj, "proof": proof, "where": iso.get("where"), "why": iso.get("why"),
                    "context": iso.get("context"), "fix": iso.get("fix"), "rows": rows, "llm_review": review,
                    "stage2": s.s2.state(rd, inc_id), "stage2_started": s.stage2_started(run_id), "history": history})


@bp.get("/api/db/feedback/<sig>")
def feedback(sig):
    s = svc()
    with s.s2.lock:
        return jsonify({"sig": sig, "history": s.s2.feedback_history(sig)})


@bp.get("/api/runs/<run_id>/stage2/queue")
def queue(run_id):
    s = svc()
    if not s.run_job(run_id):
        return jsonify({"error": "unknown run"}), 404
    return jsonify(s.queue(run_id))


def _gate(s, run_id):
    """Stage 2 is only reachable after stage 1 finished AND the admin started stage 2."""
    j = s.run_job(run_id)
    if not j:
        return None, (jsonify({"error": "unknown run"}), 404)
    if j["status"] != "done":
        return None, (jsonify({"error": "stage 1 has not finished for this run (%s)" % j["status"]}), 409)
    if not s.stage2_started(run_id):
        return None, (jsonify({"error": "stage 2 has not been started for this run - POST /api/runs/<run>/stage2/start"}), 409)
    return j, None


@bp.post("/api/runs/<run_id>/stage2/start")
def start(run_id):
    """The admin starts stage 2 for a finished run: marks it and prepares every defect in the background."""
    s = svc()
    j = s.run_job(run_id)
    if not j:
        return jsonify({"error": "unknown run"}), 404
    if j["status"] != "done":
        return jsonify({"error": "stage 1 has not finished for this run (%s)" % j["status"]}), 409
    s.start_stage2(run_id)
    r = _prepare(s, j, run_id)
    return jsonify(dict(r, started=True))


@bp.post("/api/runs/<run_id>/stage2/prepare")
def prepare(run_id):
    """Background: database lookup + LLM digest for every incident not presented yet (results cached on disk)."""
    s = svc()
    j, err = _gate(s, run_id)
    if err:
        return err
    return jsonify(_prepare(s, j, run_id))


def _prepare(s, j, run_id):
    rd, fw = s.run_dir_of(run_id), s.firmware_of(j)
    todo = [i["id"] for i in s.queue(run_id)["incidents"] if not i["stage2"]["presented"]]

    def body(jid, params, mgr):
        done = []
        for n, inc_id in enumerate(todo):
            if mgr.cancelled(jid):
                break
            with mgr.span(jid, "stage2.present." + inc_id):
                mgr.progress(jid, "prepare", "%s (%d of %d)" % (inc_id, n + 1, len(todo)), int(100 * n / max(1, len(todo))))
                s.s2.present(run_id, rd, inc_id, fw, meta=s.run_meta(j))
            done.append(inc_id)
        return {"prepared": done, "skipped": len(todo) - len(done)}
    if not todo:
        return {"job": None, "count": 0}
    jid = s.jobs.submit("stage2_prepare", {"run_id": run_id, "count": len(todo)}, body)
    return {"job": jid, "count": len(todo)}


@bp.post("/api/runs/<run_id>/incidents/<inc_id>/present")
def present(run_id, inc_id):
    s = svc()
    j, err = _gate(s, run_id)
    if err:
        return err
    rd = s.run_dir_of(run_id)
    force = (request.args.get("force") == "1") or bool((request.get_json(silent=True) or {}).get("force"))
    st = s.s2.state(rd, inc_id)
    if st.get("view") and not st.get("last") and not force:        # already processed and no decision since: cached
        v = dict(st["view"], cached=True)
        return jsonify(v)
    try:
        view = s.s2.present(run_id, rd, inc_id, s.firmware_of(j), meta=s.run_meta(j))
    except KeyError:
        return jsonify({"error": "incident has no atlas card (not presentable)"}), 400
    return jsonify(dict(view, cached=False))


@bp.get("/api/runs/<run_id>/incidents/<inc_id>/solutions")
def solutions(run_id, inc_id):
    """Candidate solutions as the manager sees them: the card's stored procedures first (approved / validated),
    then approved procedures of the same failure family, then the LLM proposal. Each with provenance and numbers."""
    s = svc()
    j, err = _gate(s, run_id)
    if err:
        return err
    rd = s.run_dir_of(run_id)
    st = s.s2.state(rd, inc_id)
    v = st.get("view")
    if not v:
        v = s.s2.present(run_id, rd, inc_id, s.firmware_of(j), meta=s.run_meta(j))
    card = v["card"]
    sig, fam = card["card"], card["pattern"]
    out, seen = [], set()
    with s.s2.lock:
        db, g = s.s2.db, s.s2.s2.graph
        hist = {}
        for h in s.s2.feedback_history(sig):
            for t in h.get("targets") or []:
                if t.startswith("sol::"):
                    hist.setdefault(t[5:], []).append(h)
        def add(sol, source):
            if sol["vhash"] in seen:
                return
            seen.add(sol["vhash"])
            sc = sol["scenario"]
            n_ = g.node("scn::" + sol["vhash"]) or {}
            e_ = g.edges("REPRODUCED_BY", dst="scn::" + sol["vhash"])
            tests = g.tests_for("scn::" + sol["vhash"])
            hs = hist.get(sol["vhash"], [])
            out.append({"id": "sol::" + sol["vhash"], "vhash": sol["vhash"], "source": source, "sig": sol["sig"], "cause": sol["cause"],
                        "status": sol["status"], "approved_by": sol.get("approved_by"), "repro_lower95": sol.get("repro_lower95"),
                        "commands": [c["op"] if isinstance(c, dict) else c for c in sc.get("commands", [])], "timing": sc.get("timing"),
                        "power_state": sc.get("power_state", "none"),
                        "feedback": {"positive": sum(1 for h in hs if h["polarity"] == "positive"), "negative": sum(1 for h in hs if h["polarity"] == "negative"),
                                     "posterior": round((e_[0]["posterior"] if e_ else n_.get("posterior", 0.5)), 2), "n": (e_[0]["n"] if e_ else n_.get("n", 0))},
                        "tests": len(tests), "last_decision": hs[0] if hs else None, "history": s.s2.solution_summary(sol["vhash"])})
        def evidence(sol):      # order within a status group: reproduction bound, then admin feedback, then tests on file
            e_ = g.edges("REPRODUCED_BY", dst="scn::" + sol["vhash"])
            return (sol.get("repro_lower95") or 0.0, (e_[0]["posterior"] if e_ else 0.5), len(g.tests_for("scn::" + sol["vhash"])))
        for sol in sorted(db.solutions(sig, None, "admin-approved"), key=evidence, reverse=True):
            add(sol, "saved for this error type")
        for sol in sorted(db.solutions(sig, None, "validated-by-execution"), key=evidence, reverse=True):
            add(sol, "reproduced in the lab, not yet approved")
        for c in db.approved_cases():
            if c["sig"] != sig and fam and db.signature(c["sig"]) and db.signature(c["sig"])["pattern"] == fam and len(out) < 5:
                full = next((x for x in db.solutions(c["sig"], None, "admin-approved") if x["vhash"] == c["vhash"]), None)
                if full:
                    add(full, "saved for error type %s (same kind of failure)" % c["sig"])
    out = out[:5]                                           # the LLM proposal always keeps its slot
    llm = card.get("llm")
    if llm and llm.get("recommended_sequence", {}).get("commands"):
        rs = llm["recommended_sequence"]
        with s.s2.lock:
            llm_last = next((h for h in s.s2.feedback_history(sig) if h.get("incident") == inc_id and h.get("action") == "lesson"
                             and str(h.get("note") or "").upper().startswith("NOT CORRECT")), None)
        out.append({"id": "llm", "vhash": None, "source": "proposed now by the AI reviewer from these packets", "sig": sig, "cause": None, "status": "proposal",
                    "commands": rs["commands"], "timing": rs["timing"], "power_state": rs.get("power_state", "none"),
                    "feedback": {"positive": 0, "negative": 0, "posterior": None, "n": 0}, "tests": 0, "last_decision": llm_last,
                    "headline": llm.get("headline"), "mechanism": llm.get("mechanism"), "key_packets": llm.get("key_packets")})
    cause_target = next((a["doc_id"] for a in card["alternatives"] if a["kind"] == "cause" and a["sig"] == sig), None)
    stored_same = sum(1 for x in out if x["id"].startswith("sol::") and x["sig"] == sig)
    stored_family = sum(1 for x in out if x["id"].startswith("sol::") and x["sig"] != sig)
    return jsonify({"incident": inc_id, "card": sig, "title": next((a.get("label") for a in card["alternatives"] if a["kind"] == "signature"), None),
                    "seen": v["seen"], "seen_label": v.get("seen_label"), "solutions": out[:6], "cause_target": cause_target,
                    "stored_count": stored_same, "family_count": stored_family, "layer": card.get("layer"), "run_meta": s.run_meta(j),
                    "llm_headline": (llm or {}).get("headline"), "llm_mechanism": (llm or {}).get("mechanism")})


@bp.post("/api/runs/<run_id>/incidents/<inc_id>/act")
def act(run_id, inc_id):
    s = svc()
    j, err = _gate(s, run_id)
    if err:
        return err
    action = request.get_json(force=True) or {}
    out, jid = s.s2.act(run_id, s.run_dir_of(run_id), inc_id, action, s.firmware_of(j), meta=s.run_meta(j))
    code = 400 if (isinstance(out, dict) and out.get("error")) else 200
    return jsonify({"result": out, "job": jid}), code


@bp.get("/api/runs/<run_id>/incidents/<inc_id>/state")
def state(run_id, inc_id):
    s = svc()
    return jsonify(s.s2.state(s.run_dir_of(run_id), inc_id))


@bp.get("/api/actions")
def actions():
    return jsonify({"all": list(ACTIONS), "help": ACTION_HELP})
