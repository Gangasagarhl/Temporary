"""Jobs, report, generated test suite, synthetic samples."""
import os
import pathlib
import subprocess
import sys
import time

from flask import Blueprint, jsonify, request, send_from_directory

from . import svc
from report import build_report, write_report

bp = Blueprint("misc", __name__)
_COVERAGE = {"at": 0.0, "data": None}


@bp.get("/api/coverage")
def coverage():
    """Which rules and analyzer error kinds have real evidence: findings in stored runs, the kept run of the
    485-error trace, and the unit tests that name them (stage1/pcie_isolate/coverage.py). Recounted at most once a
    minute; ?refresh=1 recounts now."""
    s = svc()
    now = time.time()
    if _COVERAGE["data"] is None or now - _COVERAGE["at"] > 60 or request.args.get("refresh") in ("1", "true"):
        here = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        st1 = os.path.join(here, "stage1")
        if st1 not in sys.path:
            sys.path.insert(0, st1)
        from pcie_isolate import coverage as C      # noqa: E402
        _COVERAGE["data"] = C.build(s.root, st1)
        _COVERAGE["at"] = now
    return jsonify(_COVERAGE["data"])


@bp.get("/api/jobs")
def list_jobs():
    s = svc()
    return jsonify(s.jobs.list(request.args.get("kind"), int(request.args.get("limit", 50))))


@bp.get("/api/jobs/<jid>")
def get_job(jid):
    j = svc().jobs.get(jid)
    return (jsonify(j), 200) if j else (jsonify({"error": "unknown job"}), 404)


@bp.get("/api/jobs/<jid>/events")
def job_events(jid):
    """Activity stream with a cursor: ?after=<last seq seen> returns only the newer lines."""
    ev = svc().jobs.events(jid, int(request.args.get("after", 0)), int(request.args.get("limit", 500)))
    return jsonify({"events": ev, "last_seq": ev[-1]["seq"] if ev else int(request.args.get("after", 0))})


@bp.get("/api/runs/<run_id>/report")
def report(run_id):
    s = svc()
    j = s.run_job(run_id)
    if not j:
        return jsonify({"error": "unknown run"}), 404
    rd = s.run_dir_of(run_id)
    rep = write_report(rd, build_report(j, j, s.stage2_jobs(run_id), s.states_of(run_id), s.cache.stats()))
    if request.args.get("format") == "md":
        with open(os.path.join(rd, "report.md")) as f:
            return f.read(), 200, {"Content-Type": "text/markdown; charset=utf-8"}
    return jsonify(rep)


@bp.get("/api/kpi")
def kpi():
    """The statement's KPIs and the diagram's two rules, measured on every run of this installation:
    first-level triage time vs the 10-minute rule, automatic isolation share, LLM calls saved by the caches, known
    signatures covered by admitted tests, recurrences re-admitted (leakage must be 0), tests authored automatically,
    and - when the configuration gives your manual baselines - the saving against them."""
    import sys as _sys
    s = svc()
    sys_path = os.path.join(s.root, "stage2")
    if sys_path not in _sys.path:
        _sys.path.insert(0, sys_path)
    from loop_rules import FIRST_LEVEL_TRIAGE_S, OPTIMAL_CONSECUTIVE, SCORE_THRESHOLD
    runs = []
    for j in s.jobs.list("stage1", 500):
        if j["status"] != "done":
            continue
        rid = j["params"].get("run_id")
        spans = {sp["name"]: sp["seconds"] for sp in j.get("spans", [])}
        s1 = round(sum(v for k, v in spans.items() if k.startswith("stage1.")), 1)
        incs = s.incidents_of(rid)
        with_card = [i for i in incs if i["card"]]
        summ = s.load_json(os.path.join(j["params"].get("run_dir", ""), "stage1_summary.json")) or {}
        st = (j.get("progress") or {}).get("stats") or {}
        runs.append({"run_id": rid, "label": j["params"].get("label"), "kind": j["params"].get("kind", "pcie_csv"),
                     "rows_read": st.get("rows_read"), "triage_seconds": s1, "within_triage_budget": s1 <= FIRST_LEVEL_TRIAGE_S,
                     "incidents": len(incs), "isolated_with_card": len(with_card), "confirmed": sum(1 for i in incs if i["status_word"] == "Confirmed"),
                     "needs_evidence": sum(1 for i in incs if i["status_word"] == "Needs evidence"),
                     "llm_called": summ.get("llm_called"), "llm_cached": summ.get("llm_cached"),
                     "stage2": {"decided": sum(1 for i in with_card if i["stage2"]["decided"]), "admitted": sum(1 for i in with_card if i["stage2"]["admitted"]),
                                "optimal": sum(1 for i in with_card if i["stage2"].get("optimal")),
                                "recurrences": sum(1 for i in with_card if i["stage2"].get("seen") == "match"),
                                # leakage is judged where the stored test was actually re-run: a recurrence on which the admin said
                                # Correct (regression guard + closed loop) and the test was NOT re-admitted
                                "recurrences_tested": sum(1 for i in with_card if i["stage2"].get("seen") == "match" and i["stage2"].get("action") in ("accept", "accept_with_note")),
                                "recurrences_readmitted": sum(1 for i in with_card if i["stage2"].get("seen") == "match" and i["stage2"].get("action") in ("accept", "accept_with_note") and i["stage2"]["admitted"])}})
    with s.s2.lock:
        g = s.s2.s2.graph
        tests = g.nodes("test")
        admitted_sigs = sorted({t["sig"] for t in tests if (t.get("props") or {}).get("admitted")})
        known = sorted({x["sig"] for x in g.nodes("signature")})
    rec = sum(r["stage2"]["recurrences"] for r in runs)
    rec_t = sum(r["stage2"]["recurrences_tested"] for r in runs)
    rec_ok = sum(r["stage2"]["recurrences_readmitted"] for r in runs)
    decided = sum(r["stage2"]["decided"] for r in runs)
    leakage = rec_t - rec_ok
    cfg_k = s.cfg.get("kpi") or {}
    auto_min = sum(r["triage_seconds"] for r in runs) / 60.0
    manual = cfg_k.get("manual_triage_minutes_per_run")
    saving = None
    if manual and runs:
        saving = round(100.0 * (1 - auto_min / (manual * len(runs))), 1)
    return jsonify({
        "rules": {"score_threshold": SCORE_THRESHOLD, "optimal_consecutive": OPTIMAL_CONSECUTIVE, "first_level_triage_s": FIRST_LEVEL_TRIAGE_S},
        "runs": runs,
        "efficiency": {"runs": len(runs), "runs_within_triage_budget": sum(1 for r in runs if r["within_triage_budget"]),
                       "triage_minutes_total_automatic": round(auto_min, 1), "manual_triage_minutes_per_run_baseline": manual,
                       "triage_effort_saving_pct": saving, "note": "to show the saving in %, enter how many minutes a manual first look takes (config kpi.manual_triage_minutes_per_run); the automatic minutes are measured",
                       "llm_calls": sum(r["llm_called"] or 0 for r in runs), "llm_calls_saved_by_cache": sum(r["llm_cached"] or 0 for r in runs)},
        "quality": {"incidents": sum(r["incidents"] for r in runs), "isolated_with_card": sum(r["isolated_with_card"] for r in runs),
                    "known_signatures": len(known), "signatures_with_admitted_test": len(admitted_sigs),
                    "recurrences_seen": rec, "recurrences_tested": rec_t, "recurrences_readmitted": rec_ok, "known_signature_leakage": leakage,
                    "leakage_rule": "an error seen before, judged Correct again, must pass its own test again: this count must stay 0"},
        "productivity": {"tests_on_file": len(tests), "tests_authored_by_hand": 0, "decisions": decided,
                         "manual_script_minutes_per_test_baseline": cfg_k.get("manual_script_minutes_per_test"),
                         "script_minutes_saved": (round(cfg_k["manual_script_minutes_per_test"] * len(tests), 1) if cfg_k.get("manual_script_minutes_per_test") else None)}})


@bp.get("/api/suite")
def suite():
    s = svc()
    sd = os.path.join(s.root, "suite")
    out = []
    if os.path.isdir(sd):
        for d in sorted(os.listdir(sd)):
            m = s.load_json(os.path.join(sd, d, "manifest.json"))
            if m:
                out.append({"test_id": d, "card": m.get("card"), "incident": m.get("incident_id"), "pattern": m.get("pattern"),
                            "closed_loop": m.get("closed_loop_at_generation"), "repro_lower95": (m.get("measured_at_generation") or {}).get("repro_lower95"),
                            "steps": [x["op"] for x in (m.get("stimulus") or {}).get("steps", [])], "files": sorted(os.listdir(os.path.join(sd, d)))})
    return jsonify(out)


@bp.get("/api/suite/<test_id>/<path:fname>")
def suite_file(test_id, fname):
    s = svc()
    sd = pathlib.Path(s.root, "suite").resolve()
    target = pathlib.Path(sd, test_id, fname).resolve()
    if not target.is_relative_to(sd) or not target.is_file():
        return jsonify({"error": "bad path"}), 400
    return send_from_directory(str(sd), "%s/%s" % (test_id, fname), as_attachment=request.args.get("download") == "1")


@bp.get("/api/samples")
def samples():
    s = svc()
    sd = os.path.join(s.root, "samples")
    return jsonify([{"path": os.path.join(sd, f), "bytes": os.path.getsize(os.path.join(sd, f))} for f in sorted(os.listdir(sd)) if f.endswith(".csv")])


@bp.post("/api/samples/generate")
def generate_sample():
    """Synthetic capture for a demo: the chosen atlas cards' episodes + simulated host evidence (dmesg, tool records)."""
    s = svc()
    body = request.get_json(force=True) or {}
    cards = [c.strip() for c in (body.get("cards") or "T-42,L-21,C-16").split(",") if c.strip()]
    seed = int(body.get("seed", 7))
    name = "sample_%s_seed%d.csv" % ("_".join(c.replace("/", "_") for c in cards)[:40], seed)
    out = os.path.join(s.root, "samples", name)
    gen = os.path.join(s.root, "data", "generator", "generate_synthetic_pcie_trace.py")
    cmd = [sys.executable, gen, "--only", ",".join(cards), "--output", out, "--seed", str(seed), "--data-format",
           body.get("data_format", "hex"), "--cards", os.path.join(s.root, "data", "atlas_cards_raw.json")]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    if not os.path.exists(out):
        return jsonify({"error": (r.stderr or r.stdout)[-500:]}), 500
    side = out[:-4] + "_sidecars"
    host = {}
    ev = os.path.join(side, "scenario_event_log.jsonl")
    if body.get("host_evidence", True) and os.path.exists(ev):
        hd = os.path.join(side, "simulated_host")
        os.makedirs(hd, exist_ok=True)
        subprocess.run([sys.executable, os.path.join(s.root, "stage1", "tools", "simulate_host_evidence.py"), "--event-log", ev,
                        "--csv", out, "--out", hd], capture_output=True, text=True, timeout=300)
        host = {k: v for k, v in {"dmesg": os.path.join(hd, "dmesg_x.txt"), "events": os.path.join(hd, "host_events.jsonl")}.items()
                if os.path.exists(v)}
    with open(out) as f:
        rows = sum(1 for _ in f) - 1
    return jsonify({"csv_path": out, "rows": rows, "host_evidence": host, "nsze": "0x3A386030", "cards": cards})
