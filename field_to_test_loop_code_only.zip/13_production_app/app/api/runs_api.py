"""Runs = stage 1 on one CSV. A CSV that was already processed with the same inputs and LLM settings is not
re-processed: the finished run is reused (force=true re-runs)."""
import os
import pathlib
import shutil
import time
import uuid

from flask import Blueprint, jsonify, request, send_from_directory

from . import svc
from stage1_runner import run_stage1

bp = Blueprint("runs", __name__)


@bp.post("/api/runs")
def start_run():
    s = svc()
    body = request.get_json(force=True) or {}
    if body.get("kind") == "workload":                      # ADK / PCMark artifact (JSON) instead of an analyzer CSV
        from workload_import import run_workload_import
        path, err = s.safe_path(body.get("artifact_path") or body.get("csv_path"))
        if err:
            return jsonify({"error": err}), 400
        if not path.lower().endswith(".json"):
            return jsonify({"error": "a workload artifact is a JSON file (boot_etl stage1.json or the generic shape in app/workload_import.py)"}), 400
        key = s.run_key(path, {"kind": "workload"}, s.cfg["llm"])
        if not body.get("force"):
            prev = s.find_run(key)
            if prev:
                return jsonify({"run_id": prev["params"]["run_id"], "job": prev["id"], "reused": True, "message": "this artifact was already imported; opened the existing run"})
        run_id = time.strftime("run-%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:4]
        rd = os.path.join(s.root, "runs", run_id)
        os.makedirs(rd, exist_ok=True)
        params = {"run_id": run_id, "run_dir": rd, "csv_path": path, "artifact_path": path, "kind": "workload", "key": key,
                  "firmware": body.get("firmware") or s.cfg["stage1"].get("firmware_label", "FW-A"), "llm": dict(s.cfg["llm"]),
                  "operator": (body.get("operator") or "").strip(), "device": (body.get("device") or "").strip(),
                  "cache_db": os.path.join(s.root, "db", "app.sqlite"), "label": body.get("label", "") or "workload artifact"}
        jid = s.jobs.submit("stage1", params, run_workload_import)
        return jsonify({"run_id": run_id, "job": jid, "reused": False, "kind": "workload"})
    csv_path, err = s.safe_path(body.get("csv_path"))
    if err:
        return jsonify({"error": err}), 400
    extra = {}
    for k in ("dmesg", "events", "payload"):
        if body.get(k):
            p, e = s.safe_path(body[k])
            if e:
                return jsonify({"error": "%s: %s" % (k, e)}), 400
            extra[k] = p
    nsze = body.get("nsze") or s.cfg["stage1"].get("nsze") or ""
    key = s.run_key(csv_path, dict(extra, nsze=nsze), s.cfg["llm"])
    if not body.get("force"):
        prev = s.find_run(key)
        if prev:
            return jsonify({"run_id": prev["params"]["run_id"], "job": prev["id"], "reused": True,
                            "message": "this CSV was already processed with the same inputs and LLM settings; opened the existing run"})
    run_id = time.strftime("run-%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:4]
    rd = os.path.join(s.root, "runs", run_id)
    os.makedirs(rd, exist_ok=True)
    params = {"run_id": run_id, "run_dir": rd, "csv_path": csv_path, "nsze": nsze, "key": key,
              "firmware": body.get("firmware") or s.cfg["stage1"].get("firmware_label", "FW-A"), "llm": dict(s.cfg["llm"]),
                  "operator": (body.get("operator") or "").strip(), "device": (body.get("device") or "").strip(),
              "cache_db": os.path.join(s.root, "db", "app.sqlite"), "label": body.get("label", ""), **extra}
    jid = s.jobs.submit("stage1", params, run_stage1)
    return jsonify({"run_id": run_id, "job": jid, "reused": False})


@bp.get("/api/runs/inputs")
def find_inputs():
    """Companion files next to a CSV: payload sidecar (DATA bytes), dmesg -x, host_events.jsonl, nsze.
    Looks in <name>_outside_evidence/, <name>_sidecars/ and the CSV's own folder."""
    s = svc()
    csv_path, err = s.safe_path(request.args.get("csv_path"))
    if err:
        return jsonify({"error": err}), 400
    base = csv_path[:-4] if csv_path.lower().endswith(".csv") else csv_path
    cands = [base + "_outside_evidence", base + "_sidecars", os.path.dirname(csv_path)]
    found = {"payload": None, "dmesg": None, "events": None, "nsze": None, "looked_in": cands}
    for d in cands:
        if not os.path.isdir(d):
            continue
        for root_, _, files in os.walk(d):
            for f in files:
                p_ = os.path.join(root_, f)
                if f == "payload_sidecar.csv" and not found["payload"]:
                    found["payload"] = p_
                elif f in ("dmesg_x.txt", "dmesg.txt") and not found["dmesg"]:
                    found["dmesg"] = p_
                elif f == "host_events.jsonl" and not found["events"]:
                    found["events"] = p_
                elif f in ("synthetic_trace_manifest.json", "payload_sidecar_manifest.json") and not found["nsze"]:
                    try:
                        m = s.load_json(p_, {})
                        n = m.get("nsze") or (m.get("topology") or {}).get("nsze")
                        if n:
                            found["nsze"] = hex(n) if isinstance(n, int) else str(n)
                    except Exception:           # noqa: BLE001
                        pass
    found["message"] = ("found: " + ", ".join(k for k in ("payload", "dmesg", "events", "nsze") if found[k])) if any(found[k] for k in ("payload", "dmesg", "events", "nsze")) \
        else "no companion files found next to the CSV (looked for payload_sidecar.csv, dmesg_x.txt, host_events.jsonl)"
    return jsonify(found)


@bp.get("/api/runs")
def list_runs():
    s = svc()
    return jsonify([s.run_view(j) for j in s.jobs.list("stage1", 200)])


@bp.get("/api/runs/<run_id>")
def get_run(run_id):
    s = svc()
    j = s.run_job(run_id)
    if not j:
        return jsonify({"error": "unknown run"}), 404
    rd = s.run_dir_of(run_id)
    run_json = s.load_json(os.path.join(rd, "run.json"), {})
    cap = run_json.get("capture") or {}
    warnings = []
    if cap.get("payload", "").startswith("none"):
        warnings.append("The DATA column holds only sizes, so the NVMe-level rules (commands, completions, PRPs, registers, "
                        "doorbells, MSI-X) could not run. Re-export the capture with payload bytes or give the payload sidecar.")
    if not (j["params"].get("dmesg") or j["params"].get("events")):
        warnings.append("No host log was given: about 46 error types leave no trace in the packets and will be reported as "
                        "\"Needs evidence\". Add dmesg -x or host_events.jsonl.")
    if not j["params"].get("nsze"):
        warnings.append("No namespace size (nsze): LBA-range rules were off.")
    return jsonify({"job": j, "view": s.run_view(j), "summary": s.load_json(os.path.join(rd, "stage1_summary.json")),
                    "firmware": s.firmware_of(j), "meta": s.run_meta(j), "capture": cap, "inputs_warnings": warnings,
                    "capture_assessment": s.load_json(os.path.join(rd, "capture_assessment.json"))})


@bp.post("/api/runs/<run_id>/cancel")
def cancel_run(run_id):
    s = svc()
    j = s.run_job(run_id)
    if j:
        s.jobs.cancel(j["id"])
    return jsonify({"ok": bool(j)})


@bp.delete("/api/runs/<run_id>")
def delete_run(run_id):
    """Remove a run: its stage-1 outputs, stage-2 state files, jobs and activity log. The knowledge database
    (the admin's decisions, procedures, tests) is NOT touched - it is the learned state, not run data."""
    s = svc()
    j = s.run_job(run_id)
    if not j:
        return jsonify({"error": "unknown run"}), 404
    if j["status"] in ("queued", "running"):
        return jsonify({"error": "the run is still in progress - cancel it first"}), 409
    rd = s.run_dir_of(run_id)
    for x in s.stage2_jobs(run_id) + [y for y in s.jobs.list("stage2_prepare", 1000) if y["params"].get("run_id") == run_id]:
        if x["status"] in ("queued", "running"):
            return jsonify({"error": "a stage-2 job of this run is still in progress - wait for it to finish"}), 409
    for x in s.stage2_jobs(run_id) + [y for y in s.jobs.list("stage2_prepare", 1000) if y["params"].get("run_id") == run_id]:
        s.jobs.delete(x["id"])
    s.jobs.delete(j["id"])
    s.s2.forget_run(run_id)
    if rd and os.path.isdir(rd):
        shutil.rmtree(rd, ignore_errors=True)
    return jsonify({"deleted": run_id})


@bp.get("/api/runs/<run_id>/files")
def run_files(run_id):
    s = svc()
    rd = s.run_dir_of(run_id)
    if not rd or not os.path.isdir(rd):
        return jsonify({"error": "unknown run"}), 404
    out = []
    for base, _, files in os.walk(rd):
        for f in files:
            p = os.path.join(base, f)
            if f.endswith((".md", ".json", ".jsonl", ".py", ".log", ".txt")) and "det_" not in base and "_bench" not in base:
                out.append({"path": os.path.relpath(p, rd), "bytes": os.path.getsize(p)})
    return jsonify(sorted(out, key=lambda x: x["path"]))


@bp.get("/api/runs/<run_id>/file")
def run_file(run_id):
    s = svc()
    rd = s.run_dir_of(run_id)
    rel = request.args.get("path", "")
    if not rd:
        return jsonify({"error": "unknown run"}), 404
    target = pathlib.Path(rd, rel).resolve()
    if not target.is_relative_to(pathlib.Path(rd).resolve()) or not target.is_file():
        return jsonify({"error": "bad path"}), 400
    return send_from_directory(rd, rel, as_attachment=request.args.get("download") == "1")
