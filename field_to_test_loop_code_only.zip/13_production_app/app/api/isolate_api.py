"""The isolation tab (owner's statement of 2026-11-03, parts 4 to 8): one defect of one command, opened by page 3 in
a new browser tab at /isolate?upload=<upload id>&finding=<finding id>.

Endpoints (all under /api/isolate/<upload>/<finding>):
  GET  /                 the header: the defect in words, the chain, the catalogue, the device, the memory, the chat history
  GET  /window           n commands above, the command, m below; under each the ticked lower levels (first 50 rows per level, with counts)
  POST /chat             the stateful chat: {message, context: {rows: [{level, rowid}], include_defect, include_catalogue, include_memory}, name?}
  GET  /memory           the signature memory: seen before, on this device, on other devices, the stored facts, the retrieval context
  POST /isolate          the evidence loop: {n, m, levels, name?, hint?, queue?, anyway?} -> reason, cited rows, optimised sequence, rounds
  POST /signal           one of the four signals on the seed or a stored procedure (+ scenario name + reason); POST /reorder the admin's order
  POST /testcase         {sequence, expected_after: n} -> the expected outcomes to verify; with expected_outcomes + verified -> the test file
  POST /summary          the four-line summary, stored with the signature
No admin name is required: the actor recorded is the device name unless a name is typed in the optional field.
Every model call works without a model (the stand-in from nvme_hier/isolate.py); ?standin=1 or body.standin forces it.
"""
import copy
import json
import os
import sqlite3
import sys

from flask import Blueprint, jsonify, request

from . import svc
from .hier_api import (_window, _chain, _below, _finding, _row, _summary, _signature_of, knowledge, upload_dir, db_of, read_meta,
                       current_app_ctx, TABLE, LEVELS)

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
from nvme_hier import chat as CH, isolate as ISO, optimise as OPT, parse as P, rules as RL, store as ST, testcase as TC   # noqa: E402
from nvme_hier import loader as L   # noqa: E402

bp = Blueprint("isolate", __name__)
PER_LEVEL = 50
MAX_CONTEXT_ROWS = 400
LABEL = ISO.LEVEL_LABEL


# ---------------------------------------------------------------------------------------------- shared pieces
def _catalogue(f):
    cat = RL.Catalogue()
    ref = f.get("cat_ref")
    entry = None
    if ref:
        entry = cat.by_id.get(ref) or cat.by_name.get(str(ref).lower()) or cat.silent.get(str(ref).lower())
        if entry is None:
            for e in cat.by_status.values():
                if e.get("error") == ref:
                    entry = e
                    break
    b = RL.brief(entry)
    if b and not b.get("meaning"):
        # a status-code entry has no meaning text of its own: its rule description and the specification section say what it is
        b["meaning"] = ((entry.get("rule") or {}).get("description") if isinstance(entry.get("rule"), dict) else None) or \
                       ("the drive answered with the status '%s'" % entry.get("error"))
    return b


def _load(s, uid, fid):
    """The finding with its chain, catalogue, command, cause and signature; the metadata; the device name."""
    with current_app_ctx(s, uid) as (d, meta, con):
        f = _finding(con, fid)
        if f is None:
            return None
        f["level_label"] = LABEL.get(f["level"], f["level"])
        f["rule_words"] = ISO.rule_in_words(f)
        f["basis"] = RL.basis(f.get("rule"))
        f["catalogue"] = _catalogue(f)
        f["chain"] = [{k: v for k, v in c.items() if k != "row"} for c in _chain(con, f["level"], f["rowid"])]
        cmd_row = _row(con, "nvme_command", f["cmd_rowid"]) if f.get("cmd_rowid") else None
        f["command"] = {"rowid": f["cmd_rowid"], "n": cmd_row.get("n"), "summary": _summary("nvme_command", cmd_row),
                        "parameters": {k: cmd_row.get(k) for k in ("nsid", "slba", "nlb", "fua", "nbytes") if cmd_row.get(k) is not None},
                        "duration": cmd_row.get("dur_ps_text"), "status": _status_words(cmd_row)} if cmd_row else None
        cause = _finding(con, f["cause_finding"]) if f.get("cause_finding") else None
        f["cause"] = {k: cause.get(k) for k in ("id", "level", "rule", "name", "value_ps_text", "limit_ps_text")} if cause else None
        sig = _signature_of(con, meta, f, cmd_row)
        f["signature"] = {k: sig.get(k) for k in ("fine", "coarse", "display", "fields", "device", "firmware")}
        f["signature"]["family"] = sig["coarse"]
        f["levels_present"] = L.get_meta(con, "levels_present", [])
        f["observed_outcome"] = CH.observed_outcome(f)
        f["expected_outcome_default"] = CH.expected_outcome_default(f)
        device = (meta.get("device") or "").strip() or sig.get("device") or "unknown device"
        return {"f": f, "sig": sig, "cmd_row": cmd_row, "meta": meta, "device": device}


def _status_words(r):
    if not r or r.get("sct") is None:
        return None
    if r.get("sct") == 0 and r.get("sc") == 0:
        return "success"
    raw = r.get("raw") or {}
    txt = (raw.get("ST") or raw.get("Cpl Status") or "").strip()
    return txt or ("status type %s code %s" % (r.get("sct"), r.get("sc")))


def _actor(body, ctx):
    name = ((body or {}).get("name") or request.args.get("name") or "").strip()
    return name or ctx["device"]


def _llm(s, body):
    """The configured model with the isolation system text, or None for the stand-in (also when asked for)."""
    if (body or {}).get("standin") or request.args.get("standin") == "1":
        return None
    llm = getattr(getattr(s, "s2", None), "llm", None)
    if not ISO.is_model(llm):
        return None
    if hasattr(llm, "system"):
        llm = copy.copy(llm)
        llm.system = ISO.SYSTEM
    return llm


def _findings_of(con, level, rowid):
    return [dict(x) for x in con.execute("SELECT id, rule, name, severity FROM finding WHERE level=? AND rowid=?", (level, rowid))]


def _evidence_row(con, level, row, position=None, command=None):
    """The row shape the page and the prompts use: level, row number, summary, time, gap, duration, findings."""
    raw = row.get("raw") or {}
    out = {"level": level, "label": LABEL[level], "rowid": row["rowid_file"], "n": row.get("n"), "summary": _summary(level, row),
           "t": raw.get("Time Stamp"), "gap": row.get("delta_ps_text") or (P.fmt_ps(row["delta_ps"]) if row.get("delta_ps") is not None else ""),
           "dur": row.get("dur_ps_text") or (P.fmt_ps(row["dur_ps"]) if row.get("dur_ps") is not None else ""), "dur_ps": row.get("dur_ps"), "t_ps": row.get("t_ps"),
           "findings": _findings_of(con, level, row["rowid_file"]), "relation": row.get("relation"), "position": position,
           "errors": row.get("errors") or "", "status": _status_words(row) if level in ("nvme_command", "nvme_transaction") else (row.get("cpl_status") or None)}
    if level == "nvme_command":
        out["parameters"] = {k: row.get(k) for k in ("nsid", "slba", "nlb", "fua", "nbytes") if row.get(k) is not None}
        out["queue"], out["cid"], out["opc"], out["sqid"] = row.get("sqid"), row.get("cid"), row.get("opc"), row.get("sqid")
    if command:
        out["command_rowid"], out["command_n"] = command.get("rowid"), command.get("n")
    if row.get("parent") is not None:
        out["parent_level"], out["parent_rowid"] = row.get("parent_level"), row.get("parent")
    return out


def _parents(con, level, ids):
    """Row numbers (n) of the parents of lower-level rows, for 'the packets of link 21837'."""
    out = {}
    if not ids:
        return out
    for lv in set(level for level, _ in ids):
        rids = [rid for l2, rid in ids if l2 == lv]
        for r in con.execute("SELECT rowid_file, n FROM %s WHERE rowid_file IN (%s)" % (TABLE[lv], ",".join("?" * len(rids))), rids):
            out[(lv, r[0])] = r[1]
    return out


UNDER_SQL = {
    "nvme_transaction": "parent_level='nvme_command' AND parent=?",
    "split": "parent_level='nvme_transaction' AND parent IN (SELECT rowid_file FROM ntx WHERE parent_level='nvme_command' AND parent=?)",
    "link": "(parent_level='nvme_transaction' AND parent IN (SELECT rowid_file FROM ntx WHERE parent_level='nvme_command' AND parent=?)) OR "
            "(parent_level='split' AND parent IN (SELECT rowid_file FROM spl WHERE parent_level='nvme_transaction' AND parent IN (SELECT rowid_file FROM ntx WHERE parent_level='nvme_command' AND parent=?)))",
    "packets": "(parent_level='link' AND parent IN (SELECT rowid_file FROM lnk WHERE (parent_level='nvme_transaction' AND parent IN (SELECT rowid_file FROM ntx WHERE parent_level='nvme_command' AND parent=?)) OR "
               "(parent_level='split' AND parent IN (SELECT rowid_file FROM spl WHERE parent_level='nvme_transaction' AND parent IN (SELECT rowid_file FROM ntx WHERE parent_level='nvme_command' AND parent=?))))) OR "
               "(parent_level='nvme_command' AND parent=?)",
}


def _under(con, cmd, levels, per_level=PER_LEVEL, present=None):
    """The rows of the ticked lower levels under one command (bounded: the first per_level rows per level, member rows first, with the count)."""
    out = {}
    tables = present or [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")]
    for lv in levels:
        if lv not in UNDER_SQL or TABLE[lv] not in tables:
            continue
        where = UNDER_SQL[lv]
        args = [cmd["rowid"]] * where.count("?")
        total = con.execute("SELECT COUNT(*) FROM %s WHERE %s" % (TABLE[lv], where), args).fetchone()[0]
        rows = []
        for r in con.execute("SELECT * FROM %s WHERE %s ORDER BY (relation='context'), rowid_file LIMIT ?" % (TABLE[lv], where), args + [per_level]):
            row = dict(r)
            row["raw"] = json.loads(row["raw"]) if isinstance(row.get("raw"), str) else (row.get("raw") or {})
            for k in ("t_ps", "delta_ps", "dur_ps"):
                if row.get(k) is not None:
                    row[k + "_text"] = P.fmt_ps(row[k])
            rows.append(_evidence_row(con, lv, row, command=cmd))
        pn = _parents(con, lv, [(x["parent_level"], x["parent_rowid"]) for x in rows if x.get("parent_rowid") is not None and x.get("parent_level") in TABLE])
        for x in rows:
            if x.get("parent_rowid") is not None:
                x["parent_n"] = pn.get((x.get("parent_level"), x["parent_rowid"]))
        out[lv] = {"rows": rows, "count": total, "shown": len(rows), "label": LABEL[lv]}
    return out


def _levels_arg(v):
    if isinstance(v, list):
        want = v
    else:
        want = [x.strip() for x in (v or "").split(",") if x.strip()]
    return [lv for lv in ISO.LOWER_LEVELS if lv in want]


def _window_rows(s, uid, fid, n, m, same_queue, levels):
    """The command-level window (hier_api._window) with the ticked lower levels under every command."""
    w = _window(s, uid, fid, "nvme_command", n, m, same_queue)
    if w is None:
        return None
    with current_app_ctx(s, uid) as (d, meta, con):
        tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        cmds = []
        for r in w["rows"]:
            er = _evidence_row(con, "nvme_command", r, position=r["position"])
            er["gap"] = r.get("gap_text") or ""          # in a command window the gap is to the previous command of the window
            er["time_delta"] = r.get("delta_ps_text") or ""
            er["under"] = _under(con, er, levels, present=tables) if levels else {}
            cmds.append(er)
        f = _finding(con, fid)
        below_defect = _below(con, f["level"], f["rowid"], per_level=PER_LEVEL) if f and f["level"] != "nvme_command" else []
    w["commands"] = cmds
    w["levels"] = levels
    w["per_level"] = PER_LEVEL
    w["defect_below"] = [{"under": b["under"], "under_label": b["under_label"], "counts": b["counts"],
                          "rows": [{k: v for k, v in r.items() if k != "row"} for r in b["rows"]]} for b in below_defect]
    return w


def _ok_upload(s, uid):
    d = upload_dir(s, uid)
    return bool(d and os.path.exists(db_of(d)))


def _memory(s, ctx, uid):
    """Seen before? on this device? on other devices? plus the stored facts and the retrieval context."""
    st = knowledge(s)
    sig = ctx["sig"]
    st.touch_signature(sig, ctx["device"], upload_id=uid, finding_id=ctx["f"]["id"])
    st.set_device(sig["fine"], ctx["device"], sig.get("firmware"))
    know = st.lookup(sig)
    sightings = st.sightings(sig["fine"])
    other_uploads = sorted({x["upload_id"] for x in sightings if x["upload_id"] != uid})
    facts = st.retrieve(sig, ctx["device"])
    fam = [x for x in facts if x["tier"] >= 2]
    other_devices = sorted({(x.get("device") or "unknown") for x in fam if (x.get("device") or "").strip().upper() != ctx["device"].strip().upper()})
    exact = next((x for x in facts if x["tier"] == 1), None)
    seen_before = bool(other_uploads) or bool(know.get("exact")) or bool(know.get("reason")) or bool(know.get("summary4"))
    return {"signature": ctx["f"]["signature"], "seen": know.get("seen"), "seen_before": seen_before,
            "seen_before_text": ("seen before: yes, in %d earlier upload%s of this device" % (len(other_uploads), "" if len(other_uploads) == 1 else "s")) if other_uploads
            else ("seen before: yes (facts are stored for it)" if seen_before else "seen before: no, this is the first time this exact defect is recorded on this device"),
            "on_this_device": seen_before, "on_other_devices": other_devices,
            "on_other_devices_text": ("the same kind of defect was seen on %s" % ", ".join(other_devices)) if other_devices else "the same kind of defect has not been seen on another device",
            "exact": exact, "family": fam, "retrieval": facts, "stored": know, "device": ctx["device"]}


# ---------------------------------------------------------------------------------------------- endpoints
@bp.get("/api/isolate/<uid>/<int:fid>")
def header(uid, fid):
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    ctx = _load(s, uid, fid)
    if ctx is None:
        return jsonify({"error": "no such finding"}), 404
    st = knowledge(s)
    mem = _memory(s, ctx, uid)
    llm = getattr(getattr(s, "s2", None), "llm", None)
    f = ctx["f"]
    th = (ctx["meta"].get("thresholds") or {})
    return jsonify({"upload": uid, "finding": f, "device": ctx["device"], "trace_name": ctx["meta"].get("trace_name"), "recording_date": ctx["meta"].get("recording_date"),
                    "memory": mem, "history": st.chat_history(uid, fid), "stored": mem["stored"],
                    "model": {"available": ISO.is_model(llm), "name": getattr(llm, "name", "stand-in") if llm else "stand-in"},
                    "limits": {"command_limit_text": _cmd_limit(ctx)[1], "command_limit_source": _cmd_limit(ctx)[2], "thresholds": th},
                    "bounds": {"max_rounds": ISO.MAX_ROUNDS, "max_above": ISO.MAX_ABOVE, "step_above": ISO.STEP_ABOVE, "per_level": PER_LEVEL, "history_turns": ISO.HISTORY_TURNS}})


def _cmd_limit(ctx):
    """(limit in microseconds, text, source) for the command level: the finding's own limit, else the admin's command limit, else the default."""
    f, meta, cmd = ctx["f"], ctx["meta"], ctx.get("cmd_row") or {}
    if f.get("limit_ps") and f.get("level") == "nvme_command":
        return f["limit_ps"] // 10 ** 6, f.get("limit_ps_text"), f.get("limit_source") or "the finding's limit"
    th = (meta.get("thresholds") or {}).get("nvme_command")
    if th and th.get("ps"):
        return th["ps"] // 10 ** 6, P.fmt_ps(th["ps"]), th.get("source") or "set by the admin"
    key = "nvme_command_admin" if cmd.get("sqid") == 0 else "nvme_command"
    d = RL.DEFAULT_LIMITS[key]
    return d["ps"] // 10 ** 6, P.fmt_ps(d["ps"]), d["source"]


@bp.get("/api/isolate/<uid>/<int:fid>/window")
def window(uid, fid):
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    try:
        n, m = max(0, min(int(request.args.get("n") or 10), ISO.MAX_ABOVE)), max(0, min(int(request.args.get("m") or 10), 100))
    except ValueError:
        return jsonify({"error": "n and m must be whole numbers"}), 400
    levels = _levels_arg(request.args.get("levels"))
    same_queue = request.args.get("queue", "all") == "same"
    try:
        w = _window_rows(s, uid, fid, n, m, same_queue, levels)
    except FileNotFoundError:
        return jsonify({"error": "no such upload"}), 404
    if w is None:
        return jsonify({"error": "no NVMe command can be placed around this finding"}), 400
    w.pop("rows", None)
    return jsonify(w)


def _context_rows(con, items):
    """The rows the admin ticked for the prompt, as evidence rows (bounded)."""
    rows, problems = [], []
    for it in (items or [])[:MAX_CONTEXT_ROWS]:
        lv, rid = (it or {}).get("level"), (it or {}).get("rowid")
        if lv not in LEVELS or not isinstance(rid, int):
            problems.append("row %s at level %s was not understood" % (rid, lv))
            continue
        r = _row(con, lv, rid)
        if r is None:
            problems.append("no %s with row id %s" % (LABEL.get(lv, lv), rid))
            continue
        cmd = None
        if lv != "nvme_command":
            top = _chain(con, lv, rid)
            c = next((c for c in top if c["level"] == "nvme_command"), None)
            cmd = {"rowid": c["rowid"], "n": c["n"]} if c else None
        er = _evidence_row(con, lv, r, command=cmd)
        rows.append(er)
    pn = _parents(con, "link", [(x["parent_level"], x["parent_rowid"]) for x in rows if x.get("level") == "packets" and x.get("parent_level") == "link" and x.get("parent_rowid") is not None]) if rows else {}
    for x in rows:
        if x.get("level") == "packets" and x.get("parent_rowid") is not None:
            x["parent_n"] = pn.get(("link", x["parent_rowid"]))
    return rows, problems


@bp.post("/api/isolate/<uid>/<int:fid>/chat")
def chat(uid, fid):
    """Option 1: the stateful chat. The whole history (last 20 entries) and the selected context go to the model every time."""
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    message = (body.get("message") or "").strip()
    if not message:
        return jsonify({"error": "type a message first"}), 400
    ctx = _load(s, uid, fid)
    if ctx is None:
        return jsonify({"error": "no such finding"}), 404
    f, sig = ctx["f"], ctx["sig"]
    c = body.get("context") or {}
    with current_app_ctx(s, uid) as (d, meta, con):
        rows, problems = _context_rows(con, c.get("rows") or [])
    st = knowledge(s)
    facts = st.retrieve(sig, ctx["device"]) if c.get("include_memory", True) else []
    history = st.chat_history(uid, fid)
    ctext = ISO.context_text(rows)
    actor = _actor(body, ctx)
    prompt = ISO.chat_prompt(f, ctx["device"], facts, rows, history, message, include_defect=c.get("include_defect", True),
                             include_catalogue=c.get("include_catalogue", True), include_memory=c.get("include_memory", True))
    st.chat_append(uid, fid, sig["fine"], "admin:" + actor, message, {"context": ctext, "rows": len(rows), "problems": problems})
    llm = _llm(s, body)
    ans, producer = ISO.call_model(llm, prompt, ISO.CHAT_SCHEMA, "answer")
    standin = ans is None
    if ans is None:
        w = _window(s, uid, fid, "nvme_command", 10, 10, False) or {"rows": []}
        ans = ISO.standin_chat(f, ctx["device"], rows, message, OPT.optimise(w["rows"]), facts)
    # code checks: cited rows must be in the selected context; a proposed sequence may only name commands of the context or the fault
    idx = {(r["level"], r["rowid"]): r for r in rows}
    ans["cited_rows"], cite_problems = ISO.check_cited(ans.get("cited_rows") or [], idx)
    ans["checks"] = {"ok": not cite_problems, "problems": cite_problems + problems}
    ans["producer"] = producer
    ans["standin"] = standin
    ans["prompt_chars"] = len(prompt)
    st.chat_append(uid, fid, sig["fine"], producer, ans.get("answer") or "", {k: v for k, v in ans.items() if k != "answer"})
    if ans.get("scenario_name") and not st.lookup(sig).get("scenario_name"):
        st.set_scenario_name(sig["fine"], ans["scenario_name"], producer)
    out = {"answer": ans, "history": st.chat_history(uid, fid), "context_text": ctext, "context_rows": len(rows), "prompt_chars": len(prompt),
           "producer": producer, "standin": standin, "actor": actor}
    if request.args.get("debug") == "1":
        out["debug"] = {"prompt": prompt}
    return jsonify(out)


@bp.get("/api/isolate/<uid>/<int:fid>/memory")
def memory(uid, fid):
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    ctx = _load(s, uid, fid)
    if ctx is None:
        return jsonify({"error": "no such finding"}), 404
    return jsonify(_memory(s, ctx, uid))


@bp.post("/api/isolate/<uid>/<int:fid>/isolate")
def isolate(uid, fid):
    """Part 7, the evidence loop. The deterministic optimiser runs first; the model refines, asks for more evidence
    (the next 20 commands above, the lower levels of the suspect commands) at most 5 times, and every round is logged."""
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    ctx = _load(s, uid, fid)
    if ctx is None:
        return jsonify({"error": "no such finding"}), 404
    f, sig = ctx["f"], ctx["sig"]
    st = knowledge(s)
    know = st.lookup(sig)
    if know.get("exact") and not body.get("anyway"):
        return jsonify({"error": "this defect is already stored (%d procedure%s for this signature); use a stored procedure, or tick \"a new proposal anyway\""
                        % (len(know["exact"]), "" if len(know["exact"]) == 1 else "s"), "stored": know["exact"], "seed": False}), 409
    try:
        n, m = max(0, min(int(body.get("n") or 10), ISO.MAX_ABOVE)), max(0, min(int(body.get("m") or 10), 100))
    except (TypeError, ValueError):
        return jsonify({"error": "n and m must be whole numbers"}), 400
    levels = _levels_arg(body.get("levels"))
    same_queue = body.get("queue", "all") == "same"
    hint = (body.get("hint") or "").strip()
    actor = _actor(body, ctx)
    w = _window_rows(s, uid, fid, n, m, same_queue, levels)
    if w is None:
        return jsonify({"error": "no NVMe command can be placed around this finding"}), 400
    cmd_rows = {r["rowid_file"]: r for r in w["rows"]}                     # the raw command rows (for the optimiser and the step builder)
    fault_raw = next(r for r in w["rows"] if r["position"] == "fault")
    optimised = OPT.optimise(w["rows"])
    evidence, order = {}, []

    def add(r):
        key = (r["level"], r["rowid"])
        if key not in evidence:
            evidence[key] = r
            order.append(key)

    for c in w["commands"]:
        add(c)
        for lv, blk in (c.get("under") or {}).items():
            for r in blk["rows"]:
                add(r)
    lower_fetched = set(levels)
    above_fetched = sum(1 for c in w["commands"] if c["position"] == "above")
    facts = st.retrieve(sig, ctx["device"])
    llm = _llm(s, body)
    rounds, producer, ans, standin_used = [], "stand-in", None, False
    st.chat_append(uid, fid, sig["fine"], "admin:" + actor, "isolate: %d above, %d below, levels %s%s" % (n, m, ", ".join(levels) or "commands only", ("; hint: " + hint) if hint else ""),
                   {"kind": "isolate_start", "n": n, "m": m, "levels": levels, "hint": hint})
    final = False
    for k in range(1, ISO.MAX_ROUNDS + 1):
        ev = [evidence[key] for key in order]
        final = final or k == ISO.MAX_ROUNDS
        prompt = ISO.loop_prompt(f, ctx["device"], facts, optimised, ev, hint, rounds, above_fetched, lower_fetched, final=final)
        ans, producer = ISO.call_model(llm, prompt, ISO.LOOP_SCHEMA, "verdict")
        if final and ans is not None and ans.get("verdict") == "need_more_evidence" and (ans.get("reason") or "").strip():
            # the model still asked although nothing more can be fetched: its reason text is the verdict (it was told so)
            ans["verdict"] = "reason"
            producer = producer + " (final round: answered with the evidence at hand)"
        if ans is None:
            standin_used = True
            ans = ISO.standin_loop(f, ctx["device"], optimised, ev, hint, rounds, above_fetched, lower_fetched, fault_raw["rowid_file"])
        text = ISO.round_text(ans, k)
        rec = {"round": k, "verdict": ans.get("verdict"), "text": text, "producer": producer, "prompt_chars": len(prompt), "evidence_rows": len(ev),
               "above_fetched": above_fetched, "levels_fetched": sorted(lower_fetched), "need": ans.get("need") if ans.get("verdict") == "need_more_evidence" else None}
        rounds.append(rec)
        st.chat_append(uid, fid, sig["fine"], "loop", text, rec)
        if ans.get("verdict") != "need_more_evidence" or k == ISO.MAX_ROUNDS:
            break
        need = ans.get("need") or {}
        fetched_any = False
        if need.get("more_above") and above_fetched < ISO.MAX_ABOVE:
            new_n = min(ISO.MAX_ABOVE, above_fetched + ISO.STEP_ABOVE)
            w2 = _window_rows(s, uid, fid, new_n, 0, same_queue, levels)
            if w2:
                lowest = min(cmd_rows)
                for r in w2["rows"]:
                    if r["rowid_file"] < lowest and r["rowid_file"] not in cmd_rows:
                        cmd_rows[r["rowid_file"]] = r
                for c in w2["commands"]:
                    if (c["level"], c["rowid"]) not in evidence:
                        fetched_any = True
                        add(c)
                        for lv, blk in (c.get("under") or {}).items():
                            for r in blk["rows"]:
                                add(r)
                above_fetched = sum(1 for key in order if key[0] == "nvme_command" and evidence[key]["position"] == "above")
        want_levels = [lv for lv in _levels_arg(need.get("levels") or []) if lv in f["levels_present"]]
        if want_levels:
            suspects = [c for c in need.get("commands") or [] if isinstance(c, int) and ("nvme_command", c) in evidence]
            if not suspects:
                suspects = [fault_raw["rowid_file"]] + [s_["source_row"] for s_ in optimised["steps"] if s_.get("position") == "above"]
            with current_app_ctx(s, uid) as (d, meta, con):
                for c in suspects[:40]:
                    cmd = evidence.get(("nvme_command", c))
                    if not cmd:
                        continue
                    under = _under(con, cmd, [lv for lv in want_levels if lv not in (cmd.get("under") or {})])
                    for lv, blk in under.items():
                        cmd.setdefault("under", {})[lv] = blk
                        for r in blk["rows"]:
                            if (r["level"], r["rowid"]) not in evidence:
                                fetched_any = True
                            add(r)
            lower_fetched |= set(want_levels)
        if not fetched_any:
            rounds[-1]["text"] += " (nothing more could be fetched: the bounds are reached or the rows do not exist; the next round is the final one)"
            final = True                     # one last round with what there is, told so; then the loop closes
            continue
    if ans.get("verdict") != "reason":
        # the bounds are reached without any reason text: the deterministic answer closes the loop (it replaces the last round's record, so the rounds stay within the bound)
        ev = [evidence[key] for key in order]
        ans = ISO.standin_loop(f, ctx["device"], optimised, ev, "", rounds, above_fetched, lower_fetched, fault_raw["rowid_file"])
        producer = "stand-in (the bounds were reached without a verdict)"
        standin_used = True
        last = rounds[-1] if rounds else {"round": 1}
        rec = {"round": last.get("round", len(rounds)), "verdict": "reason", "text": ISO.round_text(ans, last.get("round", len(rounds))) + " (closed by the code: the model gave no reason within %d rounds)" % len(rounds), "producer": producer}
        if rounds:
            rounds[-1] = rec
        else:
            rounds.append(rec)
        st.chat_append(uid, fid, sig["fine"], "loop", rec["text"], rec)
    # code checks on the final answer
    cited, cite_problems = ISO.check_cited(ans.get("cited_rows") or [], evidence)
    above_rows = sorted([r for r in cmd_rows.values() if r["position"] == "above"], key=lambda r: r["rowid_file"])
    below_rows = sorted([r for r in cmd_rows.values() if r["position"] == "below"], key=lambda r: r["rowid_file"])
    kept, seq_problems = ISO.check_sequence(ans.get("optimised_sequence") or [], above_rows, fault_raw)
    steps = ISO.assemble(kept, fault_raw, below_rows, optimised)
    reason = (ans.get("reason") or "").strip() or ISO.reason_text(f, ctx["device"])
    result = {"verdict": "reason", "reason": reason, "cited_rows": cited, "sequence": steps, "kept_above": len(kept), "dropped_above": len(above_rows) - len(kept),
              "below_copied": len(below_rows), "fault_step": next(s_["step"] for s_ in steps if s_["position"] == "fault"),
              "checks": {"ok": not (cite_problems or seq_problems), "problems": cite_problems + seq_problems,
                         "rules": ["commands after the defect copied unchanged", "only commands from the fetched window", "names matched case-insensitively", "the fault's own command allowed"]},
              "optimiser": {k: v for k, v in optimised.items() if k != "rows"}, "rounds": rounds, "producer": producer, "standin": standin_used,
              "evidence_rows": len(evidence), "above_fetched": above_fetched, "levels_fetched": sorted(lower_fetched),
              "seed": not know.get("exact"), "stored": know.get("exact"), "scenario_name": know.get("scenario_name") or CH.standin_answer(f, {"rows": [], "n": n, "m": m}, optimised)["scenario_name"],
              "expected_outcome": f["expected_outcome_default"], "observed_outcome": f["observed_outcome"], "actor": actor}
    st.chat_append(uid, fid, sig["fine"], producer, "reason: " + reason, {"kind": "isolate_result", **{k: v for k, v in result.items() if k not in ("rounds", "optimiser")}})
    result["history"] = st.chat_history(uid, fid)
    if request.args.get("debug") == "1":
        result["debug"] = {"last_prompt": prompt}
    return jsonify(result)


@bp.post("/api/isolate/<uid>/<int:fid>/signal")
def signal(uid, fid):
    """Part 8: one of the four signals on the seed (procedure_id null + proposal_steps) or on a stored procedure;
    stores the scenario name and the reason in words with it. No admin name required."""
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    if body.get("signal") not in ST.SIGNALS:
        return jsonify({"error": "signal must be one of: " + ", ".join(ST.SIGNALS)}), 400
    ctx = _load(s, uid, fid)
    if ctx is None:
        return jsonify({"error": "no such finding"}), 404
    sig = ctx["sig"]
    actor = _actor(body, ctx)
    st = knowledge(s)
    outcome = body.get("outcome") or {"observed": ctx["f"]["observed_outcome"], "expected": ctx["f"]["expected_outcome_default"], "verified_by": None}
    try:
        r = st.signal(sig["fine"], body.get("procedure_id"), body["signal"], actor, edited_steps=body.get("edited_steps"), edited_text=body.get("edited_text"),
                      upload_id=uid, finding_id=fid, proposal_steps=body.get("proposal_steps"), proposal_text=body.get("proposal_text"),
                      scenario_name=body.get("scenario_name"), outcome=outcome)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    if (body.get("scenario_name") or "").strip():
        st.set_scenario_name(sig["fine"], body["scenario_name"].strip(), "admin:" + actor)
    if (body.get("reason") or "").strip():
        st.set_reason(sig["fine"], body["reason"].strip(), "admin:" + actor)
    st.chat_append(uid, fid, sig["fine"], "admin:" + actor, "signal %s%s" % (body["signal"], (" on procedure %s" % body.get("procedure_id")) if body.get("procedure_id") else " on the seed"),
                   {"kind": "signal", "result": r})
    return jsonify({"result": r, "stored": st.lookup(sig), "memory": _memory(s, ctx, uid), "actor": actor})


@bp.post("/api/isolate/<uid>/<int:fid>/reorder")
def reorder(uid, fid):
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    ctx = _load(s, uid, fid)
    if ctx is None:
        return jsonify({"error": "no such finding"}), 404
    st = knowledge(s)
    st.reorder(ctx["sig"]["fine"], body.get("order") or [], _actor(body, ctx))
    return jsonify({"stored": st.lookup(ctx["sig"])})


@bp.post("/api/isolate/<uid>/<int:fid>/testcase")
def testcase(uid, fid):
    """Part 8, the test case in two steps. Without expected_outcomes: the model is asked once for the expected outcomes
    of the n commands from the defect onward (status and timing a correct device must produce); the admin verifies them
    in the page. With expected_outcomes and verified=true: the file is written (input = the kept sequence above the
    defect; expected output = the verified outcomes)."""
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    ctx = _load(s, uid, fid)
    if ctx is None:
        return jsonify({"error": "no such finding"}), 404
    f, sig = ctx["f"], ctx["sig"]
    steps = body.get("sequence") or []
    if not steps:
        return jsonify({"error": "no sequence: run the isolation first or use a stored procedure"}), 400
    steps = [dict(s_) for s_ in steps]
    if not any(s_.get("position") == "fault" for s_ in steps):
        steps[-1]["position"] = "fault"
    for i, s_ in enumerate(steps):
        s_["step"] = i + 1
    fault_step = next(s_["step"] for s_ in steps if s_.get("position") == "fault")
    try:
        n_after = max(1, int(body.get("expected_after") or (len(steps) - fault_step + 1)))
    except (TypeError, ValueError):
        return jsonify({"error": "expected_after must be a whole number"}), 400
    n_after = min(n_after, len(steps) - fault_step + 1)
    limit_us, limit_text, limit_source = _cmd_limit(ctx)
    actor = _actor(body, ctx)
    st = knowledge(s)
    if not body.get("expected_outcomes"):
        prompt = ISO.outcomes_prompt(f, ctx["device"], steps, fault_step, n_after, limit_text, limit_source)
        ans, producer = ISO.call_model(_llm(s, body), prompt, ISO.OUTCOMES_SCHEMA, "outcomes")
        standin = ans is None
        if ans is None:
            ans = ISO.standin_outcomes(f, steps, fault_step, n_after, limit_us, limit_text, limit_source)
        by_step = {s_["step"]: s_ for s_ in steps}
        outs = []
        for o in ans.get("outcomes") or []:
            try:
                stp = int(o.get("step"))
            except (TypeError, ValueError):
                continue
            if stp < fault_step or stp >= fault_step + n_after or stp not in by_step:
                continue
            code = [int(o.get("status_type") or 0), int(o.get("status_code") or 0)] if o.get("status_type") is not None else None
            outs.append({"step": stp, "command": by_step[stp]["command"], "position": by_step[stp].get("position"), "status": o.get("status") or "", "status_code": code,
                         "success": code in (None, [0, 0]), "timing_us": int(o["timing_us"]) if isinstance(o.get("timing_us"), int) and o["timing_us"] > 0 else int(limit_us),
                         "timing_text": P.fmt_ps(int(o["timing_us"]) * 10 ** 6) if isinstance(o.get("timing_us"), int) and o["timing_us"] > 0 else limit_text,
                         "check": o.get("check") or "", "basis": o.get("basis") or "", "verified": False})
        missing = [stp for stp in range(fault_step, fault_step + n_after) if stp not in {o["step"] for o in outs}]
        if missing:     # the model skipped steps: the stand-in fills them so every step has an outcome to verify
            fill = ISO.standin_outcomes(f, steps, fault_step, n_after, limit_us, limit_text, limit_source)["outcomes"]
            for o in fill:
                if o["step"] in missing:
                    outs.append({"step": o["step"], "command": o["command"], "position": by_step[o["step"]].get("position"), "status": o["status"], "status_code": [0, 0], "success": True,
                                 "timing_us": o["timing_us"], "timing_text": P.fmt_ps(o["timing_us"] * 10 ** 6), "check": o["check"], "basis": o["basis"], "verified": False})
        outs.sort(key=lambda o: o["step"])
        st.chat_append(uid, fid, sig["fine"], producer, "expected outcomes proposed for steps %d to %d" % (fault_step, fault_step + n_after - 1), {"kind": "expected_outcomes", "outcomes": outs})
        return jsonify({"expected_outcomes": outs, "fault_step": fault_step, "expected_after": n_after, "producer": producer, "standin": standin, "prompt_chars": len(prompt),
                        "limit": {"text": limit_text, "source": limit_source}, "sequence": steps})
    if not body.get("verified"):
        return jsonify({"error": "tick 'verified' after checking the expected outcomes; the file is written only with verified outcomes"}), 400
    outs = body["expected_outcomes"]
    fault_exp = next((o for o in outs if int(o.get("step", 0)) == fault_step), None)
    outcome = {"observed": f["observed_outcome"], "verified_by": actor,
               "expected": {"status": (fault_exp or {}).get("status") or f["expected_outcome_default"]["status"], "description": f["expected_outcome_default"]["description"],
                           "check": (fault_exp or {}).get("check") or f["expected_outcome_default"]["check"]}}
    suite = os.path.join(s.root, "suite", "hier")
    os.makedirs(suite, exist_ok=True)
    version = 1 + len([x for x in os.listdir(suite) if x.startswith("%s_f%d_" % (uid, fid))])
    name = "%s_f%d_v%d.py" % (uid, fid, version)
    nsid = (ctx.get("cmd_row") or {}).get("nsid") or 1
    text = TC.generate(f, steps, sig, (body.get("scenario_name") or st.lookup(sig).get("scenario_name")), uid, version=version, device=ctx["device"],
                       firmware=sig.get("firmware"), nsid=nsid, name=name, outcome=outcome, limit_us=limit_us, expected_after=outs)
    path = os.path.join(suite, name)
    with open(path, "w") as fh:
        fh.write(text)
    if body.get("procedure_id"):
        st.set_test_path(int(body["procedure_id"]), path)
    st.chat_append(uid, fid, sig["fine"], "admin:" + actor, "test case written: " + name, {"kind": "testcase", "path": path})
    return jsonify({"path": path, "name": name, "version": version, "text": text, "steps": steps, "expected_after": TC.normalise_expected(outs, steps, fault_step), "actor": actor})


@bp.post("/api/isolate/<uid>/<int:fid>/summary")
def summary(uid, fid):
    """Part 8: exactly four lines (what happened, where, why, what the test checks); stored with the signature."""
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    ctx = _load(s, uid, fid)
    if ctx is None:
        return jsonify({"error": "no such finding"}), 404
    f, sig = ctx["f"], ctx["sig"]
    st = knowledge(s)
    know = st.lookup(sig)
    reason = (body.get("reason") or know.get("reason") or "").strip()
    steps = body.get("sequence") or []
    expected = body.get("expected_outcome") or f["expected_outcome_default"]
    prompt = ISO.summary_prompt(f, ctx["device"], reason, steps, expected)
    ans, producer = ISO.call_model(_llm(s, body), prompt, ISO.SUMMARY_SCHEMA, "what_happened")
    standin = ans is None
    lines = ISO.four_lines(ans) if ans else None
    if lines is None:
        if ans is not None:
            producer = "stand-in (the model did not give four lines)"
        standin = True
        lines = ISO.four_lines(ISO.standin_summary(f, ctx["device"], reason, steps, expected))
    text = "\n".join(lines)
    actor = _actor(body, ctx)
    st.set_summary(sig["fine"], text, producer if not body.get("name") else "admin:" + actor)
    st.chat_append(uid, fid, sig["fine"], producer, "summary:\n" + text, {"kind": "summary", "lines": lines})
    return jsonify({"lines": lines, "text": text, "producer": producer, "standin": standin, "prompt_chars": len(prompt), "stored": st.lookup(sig)})
