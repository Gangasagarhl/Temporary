"""Field-to-Test Loop - local full-stack application.

Flask app factory: registers the API blueprints (config, runs, stage 2, database, misc) and serves the two pages
(the workflow at / and the database interface at /db). Binds to 127.0.0.1 only; single admin, no authentication.
"""
import json
import os
import sys

from flask import Flask, send_from_directory

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from services import Services                       # noqa: E402
from api import config_api, db_api, misc_api, runs_api, stage2_api   # noqa: E402


def load_config(path):
    with open(path) as f:
        cfg = json.load(f)
    cfg["_path"] = path
    return cfg


def create_app(cfg, root):
    app = Flask("field_to_test_loop", static_folder=os.path.join(HERE, "static"), static_url_path="/static")
    app.config["services"] = Services(cfg, root)
    app.config["JSON_SORT_KEYS"] = False
    for m in (config_api, runs_api, stage2_api, db_api, misc_api):
        app.register_blueprint(m.bp)

    @app.get("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    @app.get("/db")
    def db_page():
        return send_from_directory(app.static_folder, "db.html")

    @app.get("/defect")
    def defect_page():
        return send_from_directory(app.static_folder, "defect.html")

    @app.after_request
    def no_cache(resp):
        if resp.mimetype in ("text/html", "application/javascript", "text/css"):
            resp.headers["Cache-Control"] = "no-store"
        return resp
    return app
