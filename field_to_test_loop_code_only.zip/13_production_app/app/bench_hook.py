"""Hardware bench hook (stage 2). Implement run() and detect() and set "bench": "hook" in config/app_config.json
(restart the app after changing "bench"; it is read at start-up). A complete template with dry-run mode, a deny-list
and site hooks is deploy/bench_hook_template.py; the full guide is deploy/BENCH_INTEGRATION.md.

Construction (app/stage2_service.py _bench_factory, positional):
    HardwareBench(sig, family, expected_cards, fixed, decoy, seed)
    two objects per defect: the known-bad bench (fixed=False) and the fixed-firmware bench (fixed=True).
Attributes the app reads: expected (set of error types), sig, calls, seconds; optional inject / clear_faults (None if
the bench has no jammer).

run(scenario) -> dict, NOT a path. scenario = {"commands": [{"op": ...}], "timing": {"inter_cmd_us", "qd", "bs_kb",
               "burst_len", "idle_gap_ms"}, "power_state": "none|L1|L1.2|D3hot|APST"}. Execute it on the device under
               test, export the analyzer capture (113-column CSV), run detect() on it and return
               {"trace": csv path, "isolated": [findings of the expected error types, CONFIRMED or SUSPECT],
                "isolated_top1": [the primary finding, if it is an expected error type],
                "stage": 0-4, "closeness": 0-1, "reproduced": bool (stage >= 3), "cost_s": seconds of bench time}.
               verify_closed_loop reads isolated / isolated_top1; the search (search_on = "bench") reads stage,
               closeness, reproduced and cost_s. testgen.GeneratorBench.run / stage_from_findings show how the
               simulated bench derives them.
detect(trace)  run the stage-1 analyser on that capture and return findings
               [{"card_id", "verdict" (CONFIRMED|SUSPECT), "closeness", "pkt", "incident", "rule", "rank"}].
               testgen.run_engine + testgen.findings_of do this, but run_engine passes the simulated namespace size and
               returns no incidents when the analyser fails: on real hardware raise on failure instead (the template
               does), otherwise a broken analysis would make the fixed-firmware check pass.
Safety: never let this hook run format / sanitize / firmware download or commit / namespace delete (spelled fw_download,
ns_delete in optimizer.DENY_OPS and fw-download, delete-ns in manifests: refuse both); keep the device in a scratch
namespace and refuse to run on a different device model than the manifest's preconditions name.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "stage2"))
from testgen import findings_of, run_engine   # noqa: E402


class HardwareBench:
    def __init__(self, sig, family=None, expected_cards=None, fixed=False, decoy=None, seed=0, workdir=None):
        self.sig, self.family, self.fixed = sig, family, fixed
        self.expected = set(expected_cards or [sig])
        self.workdir = workdir or os.path.join(os.path.dirname(HERE), "runs", "bench_" + sig.replace("/", "_"))
        os.makedirs(self.workdir, exist_ok=True)
        self.calls, self.seconds = 0, 0.0
        self._detections = {}

    def run(self, scenario):
        raise NotImplementedError("app/bench_hook.py is not implemented yet: drive the device (nvme-cli / fio), export the "
                                  "analyzer capture, run detect() on it and return a dict {'trace': csv path, 'isolated': [...], "
                                  "'isolated_top1': [...], 'stage': 0-4, 'closeness': 0-1, 'reproduced': stage >= 3, 'cost_s': seconds} "
                                  "(see the docstring, deploy/bench_hook_template.py and deploy/BENCH_INTEGRATION.md), or set "
                                  "stage2.bench back to \"synthetic\" and restart")

    # Optional (vulnerability sweep, jammer variants): a VIAVI Xgig-class jammer on the link. Leave them unset (None) when
    # the bench has no jammer; the sweep then reports the jammer variants as "hardware bench only".
    #   inject(spec)   arm a fault for the following runs: {"kind": "tlp_corrupt", "rate": 1e-4} | {"kind": "delay_completion", "us": 500}
    #                  | {"kind": "force_recovery", "every_ms": 50}
    #   clear_faults() disarm every fault (called before the closed loop and after a jammer variant)
    inject = None
    clear_faults = None

    def detect(self, trace):
        if isinstance(trace, dict):
            trace = trace["trace"]
        if trace not in self._detections:
            out = run_engine(trace, os.path.join(self.workdir, "det_" + os.path.basename(trace).replace(".csv", "")),
                             host_evidence=False)
            self._detections[trace] = findings_of(out["incidents"])
        return self._detections[trace]
