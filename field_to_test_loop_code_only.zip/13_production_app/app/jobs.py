"""Background jobs for the local app: one worker thread per job, progress + timing spans persisted in SQLite so the
report can show exactly how long every stage took and a restarted server still lists earlier runs.

A job is a dict: {id, kind, status (queued|running|done|failed|cancelled), params, progress {step, detail, pct},
                  spans [{name, start, end, seconds, meta}], result, error, created, started, ended}
"""
import json
import sqlite3
import threading
import time
import traceback
import uuid

SCHEMA = """
CREATE TABLE IF NOT EXISTS job (id TEXT PRIMARY KEY, kind TEXT, status TEXT, params TEXT, progress TEXT, spans TEXT,
  result TEXT, error TEXT, created REAL, started REAL, ended REAL);
CREATE INDEX IF NOT EXISTS ix_job_kind ON job(kind, created);
CREATE TABLE IF NOT EXISTS job_event (job_id TEXT, seq INTEGER, ts REAL, text TEXT, data TEXT, PRIMARY KEY (job_id, seq));
"""


class Span:
    """with jobs.span(job, 'analyze', meta): ... -> appends {name, seconds, ...} to the job's spans."""

    def __init__(self, mgr, job_id, name, meta=None):
        self.mgr, self.job_id, self.name, self.meta = mgr, job_id, name, meta or {}
        self.start = None

    def __enter__(self):
        self.start = time.time()
        self.mgr.progress(self.job_id, self.name, "running")
        return self

    def __exit__(self, et, ev, tb):
        end = time.time()
        self.meta["ok"] = et is None
        self.mgr._append_span(self.job_id, {"name": self.name, "start": self.start, "end": end,
                                            "seconds": round(end - self.start, 3), "meta": self.meta})
        return False


class JobManager:
    def __init__(self, db_path):
        self.db_path = db_path
        self.lock = threading.Lock()
        self.threads = {}
        self.cancel_flags = {}
        con = self._con()
        con.executescript(SCHEMA)
        # a server restart leaves no running threads: mark stale jobs
        con.execute("UPDATE job SET status='failed', error='server restarted while running', ended=? WHERE status IN ('queued','running')",
                    (time.time(),))
        con.commit()
        con.close()

    def _con(self):
        con = sqlite3.connect(self.db_path, timeout=30)
        con.execute("PRAGMA journal_mode=WAL")
        return con

    # ------------------------------------------------------------------ CRUD
    def create(self, kind, params):
        jid = "%s-%s" % (kind, uuid.uuid4().hex[:10])
        with self.lock:
            con = self._con()
            con.execute("INSERT INTO job(id,kind,status,params,progress,spans,result,error,created) VALUES(?,?,?,?,?,?,?,?,?)",
                        (jid, kind, "queued", json.dumps(params), json.dumps({"step": "queued", "detail": "", "pct": 0}),
                         "[]", "null", None, time.time()))
            con.commit()
            con.close()
        return jid

    def get(self, jid):
        con = self._con()
        r = con.execute("SELECT id,kind,status,params,progress,spans,result,error,created,started,ended FROM job WHERE id=?", (jid,)).fetchone()
        con.close()
        return None if r is None else self._row(r)

    def list(self, kind=None, limit=50):
        con = self._con()
        q = "SELECT id,kind,status,params,progress,spans,result,error,created,started,ended FROM job"
        args = []
        if kind:
            q += " WHERE kind=?"
            args.append(kind)
        rows = con.execute(q + " ORDER BY created DESC LIMIT ?", args + [limit]).fetchall()
        con.close()
        return [self._row(r) for r in rows]

    @staticmethod
    def _row(r):
        return {"id": r[0], "kind": r[1], "status": r[2], "params": json.loads(r[3]), "progress": json.loads(r[4]),
                "spans": json.loads(r[5]), "result": json.loads(r[6]) if r[6] else None, "error": r[7],
                "created": r[8], "started": r[9], "ended": r[10],
                "elapsed_s": round(((r[10] or time.time()) - (r[9] or r[8])), 1) if r[9] else 0.0}

    def _update(self, jid, **fields):
        with self.lock:
            con = self._con()
            sets = ", ".join("%s=?" % k for k in fields)
            con.execute("UPDATE job SET %s WHERE id=?" % sets, list(fields.values()) + [jid])
            con.commit()
            con.close()

    def progress(self, jid, step, detail="", pct=None, stats=None):
        j = self.get(jid)
        old = (j or {}).get("progress") or {}
        st = dict(old.get("stats") or {})
        if stats:
            st.update(stats)
        p = {"step": step, "detail": str(detail)[:400], "pct": pct if pct is not None else old.get("pct"), "at": time.time(), "stats": st}
        self._update(jid, progress=json.dumps(p))

    def event(self, jid, text, data=None):
        """Append one line to the job's activity stream (what the UI streams)."""
        with self.lock:
            con = self._con()
            seq = con.execute("SELECT COALESCE(MAX(seq),0)+1 FROM job_event WHERE job_id=?", (jid,)).fetchone()[0]
            con.execute("INSERT INTO job_event(job_id,seq,ts,text,data) VALUES(?,?,?,?,?)",
                        (jid, seq, time.time(), str(text)[:600], json.dumps(data) if data else None))
            con.commit()
            con.close()
        return seq

    def events(self, jid, after=0, limit=500):
        con = self._con()
        rows = con.execute("SELECT seq,ts,text,data FROM job_event WHERE job_id=? AND seq>? ORDER BY seq LIMIT ?", (jid, after, limit)).fetchall()
        con.close()
        return [{"seq": r[0], "ts": r[1], "text": r[2], "data": json.loads(r[3]) if r[3] else None} for r in rows]

    def _append_span(self, jid, span):
        with self.lock:
            con = self._con()
            r = con.execute("SELECT spans FROM job WHERE id=?", (jid,)).fetchone()
            spans = json.loads(r[0]) if r else []
            spans.append(span)
            con.execute("UPDATE job SET spans=? WHERE id=?", (json.dumps(spans), jid))
            con.commit()
            con.close()

    def span(self, jid, name, meta=None):
        return Span(self, jid, name, meta)

    def delete(self, jid):
        with self.lock:
            con = self._con()
            con.execute("DELETE FROM job_event WHERE job_id=?", (jid,))
            con.execute("DELETE FROM job WHERE id=?", (jid,))
            con.commit()
            con.close()

    def cancelled(self, jid):
        return self.cancel_flags.get(jid, False)

    def cancel(self, jid):
        self.cancel_flags[jid] = True
        j = self.get(jid)
        if j and j["status"] == "queued":
            self._update(jid, status="cancelled", ended=time.time())

    # ------------------------------------------------------------------ run
    def start(self, jid, fn):
        """fn(job_id, params, mgr) -> result dict. Runs in a daemon thread."""
        job = self.get(jid)

        def body():
            self._update(jid, status="running", started=time.time())
            try:
                result = fn(jid, job["params"], self)
                self._update(jid, status="done", result=json.dumps(result, default=str), ended=time.time())
                self.progress(jid, "done", "", 100)
            except Exception as e:                        # noqa: BLE001 - the job record carries the traceback
                self._update(jid, status="failed", error="%s\n%s" % (e, traceback.format_exc()[-1500:]), ended=time.time())
                self.progress(jid, "failed", str(e)[:300], None)
        t = threading.Thread(target=body, name=jid, daemon=True)
        self.threads[jid] = t
        t.start()
        return jid

    def submit(self, kind, params, fn):
        return self.start(self.create(kind, params), fn)
