"""Stage-1 LLM verdict cache keyed by the isolated PATTERN, not by the trace.

"If this pattern occurred, it is this error": once the model has confirmed an isolated defect, an incident of the
same card, same first-abnormal rule, same failure pattern, same layer, same rule set and the same evidence-row
kind sequence gets the stored verdict without a model call. The key also carries the model id and the prompt
version (hash of the engine's static prefix), so a model or prompt change invalidates the cache automatically.

Cache hits are written into the run's llm_reviews.jsonl in the engine's own record format with
backend = "pattern-cache", evidence packets re-pointed to THIS incident's key packets; the engine's `review`
then calls the model only for the incidents that are not in the file yet, and `report` consumes both alike.
"""
import hashlib
import json
import re
import sqlite3
import time

SCHEMA = """
CREATE TABLE IF NOT EXISTS verdict_cache (
  key TEXT PRIMARY KEY, card TEXT, rule TEXT, pattern TEXT, layer TEXT, rowsig TEXT, model TEXT, prompt_version TEXT,
  record TEXT, source_run TEXT, source_incident TEXT, hits INTEGER DEFAULT 0, created REAL, last_hit REAL);
CREATE INDEX IF NOT EXISTS ix_vc_card ON verdict_cache(card, rule);
"""
KIND_RE = re.compile(r"(TLP Type|DLLP Type|Ord\.Set Type|Link Event)=([^|]+)")


def row_kinds(blocks, limit=40):
    kinds = []
    for b in blocks:
        for r in b.get("rows", []):
            m = KIND_RE.search(r)
            if m:
                kinds.append(m.group(2).strip())
    return kinds[:limit]


def prompt_version(static_prefix):
    return hashlib.sha256((static_prefix or "").encode()).hexdigest()[:12]


def pattern_key(inc, blocks, model, pver):
    cands = inc.get("atlas_candidates") or []
    card = cands[0]["card_id"] if cands else "none"
    rule = (inc.get("first_abnormal") or {}).get("rule", "")
    pattern = (inc.get("explanation") or {}).get("pattern", "")
    rules = ",".join(sorted((inc.get("rules") or {}).keys()))
    rowsig = "/".join(row_kinds(blocks))
    raw = "|".join([card, rule, pattern, inc.get("layer", ""), rules, rowsig, model, pver])
    return hashlib.sha256(raw.encode()).hexdigest()[:24], {"card": card, "rule": rule, "pattern": pattern,
                                                          "layer": inc.get("layer", ""), "rowsig": rowsig}


class VerdictCache:
    def __init__(self, db_path):
        self.db_path = db_path
        con = sqlite3.connect(db_path)
        con.executescript(SCHEMA)
        con.commit()
        con.close()

    def _con(self):
        return sqlite3.connect(self.db_path, timeout=30)

    def lookup(self, key):
        con = self._con()
        r = con.execute("SELECT record FROM verdict_cache WHERE key=?", (key,)).fetchone()
        if r:
            con.execute("UPDATE verdict_cache SET hits=hits+1, last_hit=? WHERE key=?", (time.time(), key))
            con.commit()
        con.close()
        return json.loads(r[0]) if r else None

    def store(self, key, meta, model, pver, record, run_id, inc_id):
        con = self._con()
        con.execute("INSERT OR IGNORE INTO verdict_cache(key,card,rule,pattern,layer,rowsig,model,prompt_version,record,"
                    "source_run,source_incident,hits,created) VALUES(?,?,?,?,?,?,?,?,?,?,?,0,?)",
                    (key, meta["card"], meta["rule"], meta["pattern"], meta["layer"], meta["rowsig"], model, pver,
                     json.dumps(record), run_id, inc_id, time.time()))
        con.commit()
        con.close()

    def stats(self):
        con = self._con()
        n, hits = con.execute("SELECT COUNT(*), COALESCE(SUM(hits),0) FROM verdict_cache").fetchone()
        con.close()
        return {"entries": n, "hits": hits}

    def rows(self, limit=200):
        con = self._con()
        out = [{"key": r[0], "card": r[1], "rule": r[2], "pattern": r[3], "layer": r[4], "model": r[5], "hits": r[6],
                "source_run": r[7], "source_incident": r[8], "verdict": json.loads(r[9]).get("verdict"),
                "created": r[10]} for r in con.execute(
            "SELECT key,card,rule,pattern,layer,model,hits,source_run,source_incident,record,created FROM verdict_cache "
            "ORDER BY created DESC LIMIT ?", (limit,)).fetchall()]
        con.close()
        return out


VERDICT_FIELDS = ("verdict", "card_id", "responsible", "rules_confirmed", "summary", "root_cause",
                  "mechanism", "fix", "what_else", "alternatives", "severity")


def cached_record(inc, cached, model):
    """Build this incident's review record from a cached verdict: verdict fields copied, packets re-pointed."""
    rec = {"id": inc["id"], "model": model, "backend": "pattern-cache", "cached_from": cached.get("id"),
           "input_tokens": 0, "output_tokens": 0, "cache_read_tokens": 0, "cache_write_tokens": 0, "cost_usd": 0.0}
    for k, v in cached.items():
        # "confidence" is left out on purpose: older cache entries may still carry the model's self-rating
        if k in VERDICT_FIELDS or (k not in rec and k not in ("evidence_pkts", "cascade_pkts", "root_pkt", "defect_start_pkt",
                                                                   "defect_end_pkt", "cited_unseen_pkts", "stop_reason",
                                                                   "backend", "model", "id", "error", "raw", "confidence")):
            rec[k] = v
    key_pkts = sorted({(inc.get("first_abnormal") or {}).get("pkt")} | {f.get("pkt") for f in inc.get("findings", [])} - {None})
    rec["evidence_pkts"] = key_pkts[:8]
    rec["defect_start_pkt"], rec["defect_end_pkt"] = inc.get("start_pkt"), inc.get("end_pkt")
    rec["root_pkt"] = (inc.get("root_cause_node") or {}).get("pkt", -1)
    rec["cited_unseen_pkts"] = []
    return rec
