"""Stage 1 as a job: CSV path in, isolated + LLM-confirmed defects out, one timing span per step.

Steps (each is the engine's own sub-command, run in the stage1/ package directory):
  analyze        one streaming pass over the CSV (link, data link, transactions, NVMe, statistics)
  fuse           optional: dmesg -x / host_events.jsonl placed on the packet axis (silent defects need this evidence)
  isolate        findings -> incidents (clustering, first abnormal row, attribution, atlas card, evidence rows)
  pattern-cache  incidents whose pattern was confirmed before get the stored verdict (no model call)
  review         the LLM confirms the remaining incidents (backend cli | sdk [--batch] | dry-run)
  report         isolation.json / isolation_report.md
  capture-check  one model call: can this capture show what we are looking for (optional)
"""
import json
import os
import re
import subprocess
import sys
import time

from pattern_cache import VerdictCache, cached_record, pattern_key, prompt_version

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STAGE1 = os.path.join(APP, "stage1")
LIBRARY = os.path.join(STAGE1, "runs", "signature_library.json")


RE_ROWS = re.compile(r"^\s*(\d+) rows\s+(\d+)s\s+findings=(\d+)")
RE_DONE = re.compile(r"^\s*done (\d+) rows in (\d+)s, (\d+) findings")
RE_INC = re.compile(r"^findings (\d+) -> incidents (\d+)")
RE_REV = re.compile(r"^\s*(\d+)/(\d+)\s+(\{.*\})")


def engine(args, on_line=None, timeout=36000):
    """Run one engine sub-command, streaming its stdout line by line to on_line (progress parsing + activity log)."""
    proc = subprocess.Popen([sys.executable, "-u", "-m", "pcie_isolate.cli"] + args, cwd=STAGE1, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, bufsize=1)
    tail = []
    for line in proc.stdout:
        line = line.rstrip("\n")
        tail.append(line)
        if len(tail) > 200:
            tail.pop(0)
        if on_line:
            try:
                on_line(line)
            except Exception:                     # noqa: BLE001 - the stream must never break the run
                pass
    rc = proc.wait(timeout=timeout)
    return rc, "\n".join(tail)[-4000:], ""


def estimate_rows(csv_path, sample_bytes=2_000_000):
    """Rows in the CSV estimated from the file size and the mean line length of a sample (counting lines of a
    multi-GB file would take as long as reading it)."""
    size = os.path.getsize(csv_path)
    with open(csv_path, "rb") as f:
        head = f.read(sample_bytes)
    n = head.count(b"\n") or 1
    return max(1, int(size / (len(head) / n)) - 1)


def llm_backend(cfg):
    b = cfg.get("backend", "auto")
    if b == "openai-compat":                      # the engine has no generic backend: its review runs dry, stage 2 uses the endpoint
        return "dry-run"
    if b in ("auto", "sdk", "cli"):              # the only transports the analyser's own review has (pcie_isolate.cli)
        return b
    return "dry-run"                             # standin, ollama, anything else: stage-1 review runs without a model


def run_stage1(job_id, params, mgr):
    csv_path, run_dir, cfg = params["csv_path"], params["run_dir"], params["llm"]
    os.makedirs(run_dir, exist_ok=True)
    model = cfg.get("model", "claude-haiku-5-5")
    backend = llm_backend(cfg)
    if backend == "sdk":
        if cfg.get("base_url"):
            os.environ["ANTHROPIC_BASE_URL"] = cfg["base_url"]
        if cfg.get("api_key_env") and os.environ.get(cfg["api_key_env"]) and not os.environ.get("ANTHROPIC_API_KEY"):
            os.environ["ANTHROPIC_API_KEY"] = os.environ[cfg["api_key_env"]]
    summary = {"csv": csv_path, "run_dir": run_dir, "model": model, "backend": backend, "steps": {}}
    log = open(os.path.join(run_dir, "stage1_app.log"), "a")
    rows_est = estimate_rows(csv_path)
    live = {"rows_read": 0, "rows_total_est": rows_est, "findings": 0, "incidents": None, "reviewed": 0, "review_total": None,
            "llm_ok": 0, "llm_err": 0}
    mgr.event(job_id, "stage 1 started on %s (%.1f MB, about %s rows)" % (os.path.basename(csv_path), os.path.getsize(csv_path) / 1e6, "{:,}".format(rows_est)))
    mgr.progress(job_id, "start", "", 0, live)
    PCT = {"analyze": (2, 60), "fuse": (60, 64), "isolate": (64, 72), "review": (74, 94), "report": (95, 97), "capture_check": (97, 99)}

    def on_line(name):
        lo, hi = PCT.get(name, (0, 100))

        def handler(line):
            m = RE_ROWS.match(line) or RE_DONE.match(line)
            if m:
                live["rows_read"], live["findings"] = int(m.group(1)), int(m.group(3))
                frac = min(1.0, live["rows_read"] / max(1, live["rows_total_est"]))
                mgr.progress(job_id, name, "%s rows read, %d findings" % ("{:,}".format(live["rows_read"]), live["findings"]), int(lo + (hi - lo) * frac), live)
                mgr.event(job_id, "analyze: %s of ~%s rows read, %d findings so far" % ("{:,}".format(live["rows_read"]), "{:,}".format(live["rows_total_est"]), live["findings"]), dict(live))
                return
            m = RE_INC.match(line)
            if m:
                live["findings"], live["incidents"] = int(m.group(1)), int(m.group(2))
                mgr.progress(job_id, name, "%d findings -> %d defects" % (live["findings"], live["incidents"]), hi, live)
                mgr.event(job_id, "isolate: %d findings clustered into %d defects" % (live["findings"], live["incidents"]), dict(live))
                return
            m = RE_REV.match(line)
            if m:
                live["reviewed"], live["review_total"] = int(m.group(1)), int(m.group(2))
                try:
                    st = json.loads(m.group(3).replace("'", '"'))
                    live["llm_ok"], live["llm_err"] = st.get("ok", 0), st.get("err", 0)
                except ValueError:
                    pass
                frac = live["reviewed"] / max(1, live["review_total"])
                mgr.progress(job_id, name, "AI reviewer checked %d of %d defects" % (live["reviewed"], live["review_total"]), int(lo + (hi - lo) * frac), live)
                mgr.event(job_id, "second opinion: %d of %d defects checked by the AI reviewer (%d answered, %d errors)" % (live["reviewed"], live["review_total"], live["llm_ok"], live["llm_err"]), dict(live))
                return
            if line.strip() and not line.startswith(("{", "}", " \"", "  \"")):
                mgr.event(job_id, "%s: %s" % (name, line.strip()[:300]))
        return handler

    def step(name, args, pct):
        mgr.progress(job_id, name, "starting " + name, PCT.get(name, (pct, pct))[0], live)
        mgr.event(job_id, "==> %s" % name)
        with mgr.span(job_id, "stage1." + name, {"args": args[:6]}) as sp:
            t = time.time()
            rc, out, err = engine(args, on_line(name))
            log.write("==> %s\n%s\n%s\n" % (" ".join(args), out, err))
            log.flush()
            sp.meta["rc"] = rc
            summary["steps"][name] = {"seconds": round(time.time() - t, 2), "rc": rc}
            if rc != 0:
                raise RuntimeError("stage-1 step %s failed (exit %d): %s" % (name, rc, (err or out)[-600:]))
        if mgr.cancelled(job_id):
            raise RuntimeError("cancelled")

    an = ["analyze", "--csv", csv_path, "--out", run_dir]
    if params.get("payload"):
        an += ["--payload", params["payload"]]
    if params.get("nsze"):
        an += ["--nsze", str(params["nsze"])]
    step("analyze", an, 10)
    if params.get("dmesg") or params.get("events"):
        f = ["fuse", "--run", run_dir]
        if params.get("dmesg"):
            f += ["--dmesg", params["dmesg"]]
        if params.get("events"):
            f += ["--events", params["events"]]
        step("fuse", f, 25)
    iso = ["isolate", "--run", run_dir, "--library", LIBRARY, "--csv", csv_path]
    if params.get("payload"):
        iso += ["--payload", params["payload"]]
    step("isolate", iso, 40)
    incs = json.load(open(os.path.join(run_dir, "incidents.json")))
    summary["incidents"] = len(incs)
    # ---------------- pattern cache -> llm_reviews.jsonl (engine skips ids already present)
    cache = VerdictCache(params["cache_db"])
    rows = {}
    rp = os.path.join(run_dir, "incident_rows.jsonl")
    if os.path.exists(rp):
        for line in open(rp):
            d = json.loads(line)
            rows[d["id"]] = d.get("blocks", [])
    pver = prompt_version(_static_prefix())
    keys = {}
    hits = 0
    with mgr.span(job_id, "stage1.pattern_cache", {}) as sp:
        with open(os.path.join(run_dir, "llm_reviews.jsonl"), "a") as fo:
            for inc in incs:
                k, meta = pattern_key(inc, rows.get(inc["id"], []), model, pver)
                keys[inc["id"]] = (k, meta)
                c = cache.lookup(k)
                if c:
                    fo.write(json.dumps(cached_record(inc, c, model)) + "\n")
                    hits += 1
        sp.meta["hits"] = hits
    summary["llm_cached"] = hits
    mgr.event(job_id, "pattern cache: %d of %d defects already confirmed earlier (no model call needed)" % (hits, len(incs)), {"cached": hits})
    mgr.progress(job_id, "pattern_cache", "%d cached verdicts" % hits, 73, dict(live, incidents=len(incs), cached=hits))
    # ---------------- LLM confirmation for the rest
    if backend != "dry-run" and hits < len(incs):
        rv = ["review", "--run", run_dir, "--model", model, "--backend", backend]
        if cfg.get("batch") and backend == "sdk":
            rv.append("--batch")
        if cfg.get("workers"):
            rv += ["--workers", str(cfg["workers"])]
        step("review", rv, 75)
    else:
        summary["steps"]["review"] = {"seconds": 0.0, "rc": 0, "skipped": True}
    step("report", ["report", "--run", run_dir], 90)
    if cfg.get("capture_check", True) and backend != "dry-run":
        try:
            step("capture_check", ["review", "--run", run_dir, "--model", model, "--backend", backend, "--capture-check"], 95)
        except RuntimeError as e:                 # advisory step: never fails the run
            summary["steps"]["capture_check"] = {"seconds": 0.0, "rc": 1, "error": str(e)[-300:]}
    # ---------------- store the new verdicts in the cache
    reviewed = called = confirmed = 0
    cost = 0.0
    if os.path.exists(os.path.join(run_dir, "llm_reviews.jsonl")):
        for line in open(os.path.join(run_dir, "llm_reviews.jsonl")):
            r = json.loads(line)
            if "error" in r:
                continue
            reviewed += 1
            confirmed += r.get("verdict") == "CONFIRMED"
            cost += r.get("cost_usd") or 0.0
            if r.get("backend") != "pattern-cache":
                called += 1
                k, meta = keys.get(r["id"], (None, None))
                if k:
                    cache.store(k, meta, model, pver, r, params["run_id"], r["id"])
    summary.update(llm_reviewed=reviewed, llm_called=called, llm_confirmed=confirmed, llm_cost_usd=round(cost, 4),
                   cache=cache.stats())
    sp_ = os.path.join(run_dir, "isolation_summary.json")
    if os.path.exists(sp_):
        summary["isolation_summary"] = json.load(open(sp_))
    summary["seconds_total"] = round(sum(s["seconds"] for s in summary["steps"].values()), 2)
    mgr.event(job_id, "stage 1 complete: %d defects isolated, %d confirmed (%d model calls, %d from cache) in %.1f s" % (
        len(incs), confirmed, called, hits, summary["seconds_total"]), {"done": True})
    mgr.progress(job_id, "done", "", 100, dict(live, incidents=len(incs), reviewed=reviewed, llm_ok=confirmed))
    json.dump(summary, open(os.path.join(run_dir, "stage1_summary.json"), "w"), indent=1)
    log.close()
    return summary


def _static_prefix():
    try:
        sys.path.insert(0, STAGE1)
        from pcie_isolate.llm import system_blocks       # noqa: E402
        return system_blocks()[0]["text"]
    except Exception:                                    # noqa: BLE001
        return ""
