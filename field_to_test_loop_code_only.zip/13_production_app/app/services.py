"""Shared services for the API blueprints: jobs, verdict cache, stage-2 service, path safety, run helpers.

Caching layers (what was already processed is never recomputed):
  run cache        the same CSV (path, size, mtime) with the same inputs/LLM settings -> the finished run is reused
  pattern cache    stage-1 LLM verdicts keyed by the isolated pattern (pattern_cache.py)
  presentation     a stage-2 card already built for an incident is served from disk until the admin acts on it
  LLM prompt cache every model answer keyed by prompt hash (stage2/llm_adapter.py)
"""
import hashlib
import json
import os
import pathlib
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from jobs import JobManager                  # noqa: E402
from pattern_cache import VerdictCache       # noqa: E402
from stage2_service import Stage2Service     # noqa: E402


class Services:
    def __init__(self, cfg, root):
        self.cfg, self.root = cfg, root
        for d in ("db", "runs", "samples", "suite"):
            os.makedirs(os.path.join(root, d), exist_ok=True)
        self.jobs = JobManager(os.path.join(root, "db", "app.sqlite"))
        self.cache = VerdictCache(os.path.join(root, "db", "app.sqlite"))
        self.s2 = Stage2Service(cfg, root, self.jobs)
        self.roots = [pathlib.Path(os.path.expanduser(p)).resolve() for p in cfg["paths"].get("allowed_csv_roots", ["~"])]
        self.roots.append(pathlib.Path(root).resolve())

    # ------------------------------------------------------------------ paths
    def safe_path(self, p, must_exist=True):
        if not p:
            return None, "path required"
        rp = pathlib.Path(os.path.expanduser(p)).resolve()
        if must_exist and not rp.is_file():
            return None, "not a file: %s" % rp
        if not any(rp == r or rp.is_relative_to(r) for r in self.roots):
            return None, "path outside the allowed roots (config paths.allowed_csv_roots): %s" % rp
        return str(rp), None

    def run_dir_of(self, run_id):
        base = pathlib.Path(self.root, "runs").resolve()
        d = pathlib.Path(base, run_id).resolve()
        return str(d) if d.is_relative_to(base) and d != base else None

    @staticmethod
    def load_json(p, default=None):
        if not p or not os.path.exists(p):
            return default
        with open(p) as f:
            return json.load(f)

    # ------------------------------------------------------------------ runs
    def run_job(self, run_id):
        for j in self.jobs.list("stage1", 1000):
            if j["params"].get("run_id") == run_id:
                return j
        return None

    def firmware_of(self, job):
        return (job or {}).get("params", {}).get("firmware") or self.cfg["stage1"].get("firmware_label", "FW-A")

    def device_of(self, job):
        """The device a run belongs to. The analyser reads the identity from the trace itself when the capture holds it:
        NVMe Identify Controller data (model number, serial number, firmware revision - NVMe Base Spec, Identify
        Controller data structure bytes 04:71) and the PCIe configuration header (Vendor ID / Device ID). The operator
        may also type a device name on the Choose-trace page. Name priority: the typed name, else the model number
        from the trace, else the PCI ids, else "unknown device"."""
        p = (job or {}).get("params", {})
        rd = p.get("run_dir", "")
        ident = ((self.load_json(os.path.join(rd, "run.json"), {}) or {}).get("topology") or {}).get("identity") or {}
        pci = ("%s:%s" % (ident["pci_vendor_id"], ident.get("pci_device_id"))) if ident.get("pci_vendor_id") else None
        typed = (p.get("device") or "").strip() or None
        name = typed or ident.get("model_number") or (("PCI device %s" % pci) if pci else None)
        source = ("typed by the operator" if typed else "read from the trace (NVMe Identify Controller)" if ident.get("model_number")
                  else "read from the trace (PCIe configuration header)" if pci else "not known: the trace holds no Identify Controller answer and no name was typed")
        return {"name": name or "unknown device", "known": bool(name), "label": typed, "model_number": ident.get("model_number"),
                "serial_number": ident.get("serial_number"), "firmware_revision": ident.get("firmware_revision"), "pci": pci, "source": source}

    def run_meta(self, job):
        """Who started the run, when, on which trace, device and firmware - stamped on every stage-2 event and test."""
        p = (job or {}).get("params", {})
        return {"run": p.get("run_id"), "trace": os.path.basename(p.get("csv_path") or ""), "operator": (p.get("operator") or "").strip() or None,
                "started": (job or {}).get("created"), "firmware": self.firmware_of(job), "device": self.device_of(job), "label": p.get("label") or None}

    @staticmethod
    def run_key(csv_path, extra, llm):
        st = os.stat(csv_path)
        raw = json.dumps({"csv": csv_path, "size": st.st_size, "mtime": int(st.st_mtime), "extra": extra,
                          "model": llm.get("model"), "backend": llm.get("backend"), "effort": llm.get("effort")}, sort_keys=True)
        return hashlib.sha256(raw.encode()).hexdigest()[:20]

    def find_run(self, key):
        for j in self.jobs.list("stage1", 1000):
            if j["params"].get("key") == key and j["status"] == "done":
                return j
        return None

    # ------------------------------------------------------------------ phases: stage 1 -> (admin starts) stage 2
    def stage2_started(self, run_id):
        rd = self.run_dir_of(run_id)
        return bool(rd) and os.path.exists(os.path.join(rd, "stage2", "STARTED"))

    def start_stage2(self, run_id):
        rd = self.run_dir_of(run_id)
        os.makedirs(os.path.join(rd, "stage2"), exist_ok=True)
        with open(os.path.join(rd, "stage2", "STARTED"), "w") as f:
            f.write(str(time.time()))

    def phase(self, j):
        """stage1_running | stage1_failed | stage1_done | stage2 | stage2_done"""
        if j["status"] in ("queued", "running"):
            return "stage1_running"
        if j["status"] != "done":
            return "stage1_failed"
        run_id = j["params"]["run_id"]
        if not self.stage2_started(run_id):
            return "stage1_done"
        c = self.queue(run_id)["counts"]
        return "stage2_done" if c["total"] and c["decided"] >= c["total"] else "stage2"

    @staticmethod
    def eta_s(j):
        """Rounded, padded ETA from the elapsed time and the percentage - only once 10 % is done (research: padded,
        honest ETAs after the early noise)."""
        pct = (j.get("progress") or {}).get("pct") or 0
        if j["status"] != "running" or pct < 10 or not j.get("started"):
            return None
        el = time.time() - j["started"]
        rem = el * (100 - pct) / pct * 1.15
        return int(round(rem / 10.0) * 10) if rem > 60 else int(round(rem / 5.0) * 5)

    def run_view(self, j):
        rd = j["params"].get("run_dir", "")
        summ = self.load_json(os.path.join(rd, "stage1_summary.json")) if rd else None
        ph = self.phase(j)
        q = self.queue(j["params"]["run_id"]) if ph in ("stage2", "stage2_done") else None
        dev = self.device_of(j)
        return {"run_id": j["params"].get("run_id"), "csv": j["params"].get("csv_path"), "label": j["params"].get("label"),
                "operator": (j["params"].get("operator") or "").strip() or None, "device": dev["name"], "device_source": dev["source"],
                "firmware": self.firmware_of(j),
                "status": j["status"], "progress": j["progress"], "elapsed_s": j["elapsed_s"], "created": j["created"], "phase": ph,
                "eta_s": self.eta_s(j), "stale_s": round(time.time() - ((j.get("progress") or {}).get("at") or j["created"]), 0) if j["status"] == "running" else None,
                "incidents": (summ or {}).get("incidents"), "llm": {"called": (summ or {}).get("llm_called"), "cached": (summ or {}).get("llm_cached"),
                                                                     "confirmed": (summ or {}).get("llm_confirmed")},
                "stage2": (q or {}).get("counts"), "job": j["id"], "key": j["params"].get("key"), "reused_from": j["params"].get("reused_from")}

    # ------------------------------------------------------------------ incidents
    def incidents_of(self, run_id):
        rd = self.run_dir_of(run_id)
        incs = self.load_json(os.path.join(rd, "incidents.json"), [])
        reviews = {}
        rp = os.path.join(rd, "llm_reviews.jsonl")
        if os.path.exists(rp):
            with open(rp) as f:
                for line in f:
                    r = json.loads(line)
                    reviews[r["id"]] = r
        iso = {x["id"]: x for x in self.load_json(os.path.join(rd, "isolation.json"), [])}
        out = []
        for i in incs:
            c = (i.get("atlas_candidates") or [{}])[0]
            r = reviews.get(i["id"]) or {}
            st = self.s2.state(rd, i["id"])
            last = st.get("last") or {}
            view = st.get("view") or {}
            status = iso.get(i["id"], {}).get("status")
            word = ("Needs evidence" if status == "NEEDS_OUTSIDE_EVIDENCE" else "Suspect" if status == "DISPUTED" or i.get("verdict") == "SUSPECT"
                    else "Confirmed" if i.get("verdict") == "CONFIRMED" else "Suspect")
            out.append({"id": i["id"], "card": c.get("card_id"), "title": c.get("title"), "score": c.get("score"), "status_word": word,
                        "pattern": (i.get("explanation") or {}).get("pattern"), "layer": i.get("layer"), "verdict": i.get("verdict"),
                        "origin": (i.get("attribution") or {}).get("origin"), "start_pkt": i.get("start_pkt"), "end_pkt": i.get("end_pkt"),
                        "first_rule": (i.get("first_abnormal") or {}).get("rule"), "status": iso.get(i["id"], {}).get("status"),
                        "llm": {"verdict": r.get("verdict"), "card_id": r.get("card_id"),
                                "backend": r.get("backend"), "cached": r.get("backend") == "pattern-cache", "error": r.get("error")} if r else None,
                        "stage2": {"presented": st.get("presented", False), "seen": view.get("seen"), "seen_label": view.get("seen_label"),
                                   "stored": bool(view.get("stored")), "action": last.get("action"), "status": last.get("status"),
                                   "admitted": last.get("admitted"), "optimal": last.get("optimal"), "decided": bool(last)}})
        return out

    def queue(self, run_id):
        incs = [i for i in self.incidents_of(run_id) if i["card"]]
        counts = {"total": len(incs), "presented": sum(1 for i in incs if i["stage2"]["presented"]),
                  "decided": sum(1 for i in incs if i["stage2"]["decided"]), "admitted": sum(1 for i in incs if i["stage2"]["admitted"]),
                  "llm_confirmed": sum(1 for i in incs if (i["llm"] or {}).get("verdict") == "CONFIRMED")}
        nxt = next((i["id"] for i in incs if not i["stage2"]["decided"]), None)
        return {"incidents": incs, "counts": counts, "next": nxt, "started": self.stage2_started(run_id)}

    def states_of(self, run_id):
        rd = self.run_dir_of(run_id)
        out = {}
        sd = os.path.join(rd, "stage2")
        if os.path.isdir(sd):
            for f in sorted(os.listdir(sd)):
                if f.endswith(".json"):
                    out[f[:-5]] = self.load_json(os.path.join(sd, f), {})
        return out

    def stage2_jobs(self, run_id):
        return [x for x in self.jobs.list("stage2", 1000) if x["params"].get("run_id") == run_id]

    @staticmethod
    def now():
        return time.time()
