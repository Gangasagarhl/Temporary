/* Shared helpers: HTTP, formatting, toast (with undo), small renderers, status vocabulary. */
export async function api(method, url, body) {
  const r = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || (j.result && j.result.error) || r.statusText);
  return j;
}
export const $ = (id) => document.getElementById(id);
export const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
export const fmt = (x, d = 1) => (x === null || x === undefined || x === "") ? "-" : (typeof x === "number" ? x.toFixed(d) : x);
export const num = (x) => (x === null || x === undefined) ? "-" : Number(x).toLocaleString();
export function toast(msg, ms = 6000, undoFn = null) {
  const t = $("toast"); $("toast-text").textContent = msg; t.hidden = false; clearTimeout(t._t);
  const u = $("toast-undo"); u.hidden = !undoFn; u.onclick = undoFn ? async () => { u.disabled = true; try { await undoFn(); $("toast-text").textContent = "undone"; } catch (e) { $("toast-text").textContent = "undo failed: " + e.message; } u.disabled = false; u.hidden = true; } : null;
  t._t = setTimeout(() => t.hidden = true, ms);
}
export const pill = (text, cls = "", icon = "") => `<span class="pill ${cls}">${icon ? icon + " " : ""}${esc(text)}</span>`;
/* fixed three-word status vocabulary: colour + icon + word, never colour alone */
export const STATUS = { "Confirmed": ["ok", "✓"], "Suspect": ["warn", "?"], "Needs evidence": ["info", "!"], "Failed": ["bad", "✕"] };
export const statusPill = (word) => { const [c, i] = STATUS[word] || ["", ""]; return pill(word, c, i); };
export const statusCls = (s) => ["done", "confirmed", "reused_validated", "CONFIRMED", "admin-approved"].includes(s) ? "ok" : ["failed", "NOT_CONFIRMED", "triage_timeout", "admin_procedure_failed"].includes(s) ? "bad" : s ? "warn" : "";
export const confidenceWord = (c) => c === null || c === undefined ? "-" : c >= 0.8 ? "high" : c >= 0.5 ? "medium" : "low";
export function seq(x, diffAgainst = null) {
  if (!x) return "<span class=muted>none</span>";
  const ops = (x.commands || x.procedure || []).map(c => c.op || c); const t = x.timing || {};
  let cmds;
  if (diffAgainst) {                                     // highlight steps that differ from the other side (by position)
    const other = (diffAgainst.commands || diffAgainst.procedure || []).map(c => c.op || c);
    cmds = ops.map((o, i) => `<span class="${other[i] === o ? "" : "diff"}">${esc(o)}</span>`).join(" → ");
  } else cmds = ops.map(esc).join(" → ");
  const tt = diffAgainst ? (diffAgainst.timing || {}) : null;
  const f = (k, label, unit = "") => `<span class="${tt && tt[k] !== t[k] ? "diff" : ""}">${label} ${t[k] ?? "-"}${unit}</span>`;
  return `<div class=seq>${cmds || "<span class=muted>no steps</span>"}</div><div class="muted small">${f("qd", "queue depth")} · ${f("inter_cmd_us", "", " µs between commands")} · ${f("bs_kb", "", " KB")} · ${f("burst_len", "burst")} · ${f("idle_gap_ms", "idle", " ms")} · <span class="${tt && (diffAgainst.power_state || "none") !== (x.power_state || "none") ? "diff" : ""}">power ${esc(x.power_state || "none")}</span></div>`;
}
export function diffCount(a, b) {
  if (!a || !b) return null;
  const oa = (a.commands || a.procedure || []).map(c => c.op || c), ob = (b.commands || b.procedure || []).map(c => c.op || c);
  let n = Math.abs(oa.length - ob.length); for (let i = 0; i < Math.min(oa.length, ob.length); i++) if (oa[i] !== ob[i]) n++;
  for (const k of ["qd", "inter_cmd_us", "bs_kb", "burst_len", "idle_gap_ms"]) if ((a.timing || {})[k] !== (b.timing || {})[k]) n++;
  if ((a.power_state || "none") !== (b.power_state || "none")) n++;
  return n;
}
export const kv = (pairs) => `<div class=kv>${pairs.map(([k, v]) => `<b>${esc(k)}</b><span>${v}</span>`).join("")}</div>`;
export function poll(jid, onTick, onDone, every = 2000) {
  const t = setInterval(async () => {
    let j; try { j = await api("GET", `/api/jobs/${jid}`); } catch (e) { return; }
    if (j.status === "done" || j.status === "failed" || j.status === "cancelled") { clearInterval(t); onDone(j); } else onTick(j);
  }, every);
  return t;
}

/* Plain names for the operator: a defect record "INC-0007" is shown as "Defect 7"; the record id stays internal. */
export function defectName(id) {
  const m = /^INC-0*(\d+)$/.exec(String(id || ""));
  return m ? `Defect ${m[1]}` : String(id || "");
}
/* any server text that still names a defect record ("INC-0002") reads "Defect 2" on the screen */
export const plainIds = (t) => String(t ?? "").replace(/\bINC-0*(\d+)\b/g, "Defect $1");
/* "T-42" is the catalogue number of a known error type; shown as "error type T-42". */
export function errorType(card) { return card ? `error type ${card}` : "no catalogue match"; }

// The catalogue of 485 known error types is split into ten chapters; the letter of an id is the chapter,
// the number is only the position inside that chapter (T-42 = 42nd entry of the "timeouts" chapter).
export const CATALOGUE_GROUPS = {
  S: "errors reported with a status code",
  T: "timeouts and time limits",
  D: "silent failures (reported Success but the work was not done)",
  L: "PCIe link and transaction errors",
  C: "NVMe controller and host-driver failures",
  X: "physical and link-layer errors only an analyzer sees",
  V: "protocol rule violations visible in the trace",
  P: "performance failures",
  M: "timing, evidence-gap and cross-layer failures",
  N: "failures outside the probed link",
};
export function groupOf(card) { const m = /^([A-Z])-0*(\d+)$/.exec(String(card || "")); return m ? { letter: m[1], n: m[2], text: CATALOGUE_GROUPS[m[1]] || "" } : null; }
// "error type T-42 (chapter T = timeouts and time limits, entry 42): Flush takes far longer than expected"
export function errorTypeFull(card, title) {
  const g = groupOf(card);
  if (!g) return title ? `no catalogue match — ${title}` : "no catalogue match";
  return `error type ${card} (chapter ${g.letter} = ${g.text}, entry ${g.n})${title ? ": " + title : ""}`;
}
// Short form for table cells: "T-42 · timeouts and time limits"
export function errorTypeShort(card) { const g = groupOf(card); return g ? `${card} · ${g.text}` : "no catalogue match"; }

// Error families: how a failure shows on the wire (the 27 "wire patterns" P01-P27 of the master report).
// The number is only an index; the name says what the family is.
export const FAMILY_NAMES = {
  P01: "completion returned with an error status", P02: "command never completed (timeout)", P03: "PCIe completion lost or late",
  P04: "configuration or register access refused (UR / CA / CRS)", P05: "request and completion do not match (tag errors)",
  P06: "data-link replay and LCRC errors", P07: "flow-control credit stall", P08: "link training, speed or width downgrade",
  P09: "physical-layer symbol or receiver errors", P10: "error-message storm (ERR_COR / ERR_NONFATAL)", P11: "poisoned data or ECRC error",
  P12: "surprise link down or hot-unplug", P13: "controller readiness (CC / CSTS registers)", P14: "queue doorbell violations",
  P15: "completion-queue phase or duplicate completions", P16: "completion posted before its data", P17: "DMA outside the allowed addresses (IOMMU faults)",
  P18: "PRP / SGL list format errors", P19: "configuration space, power state and reset sequencing", P20: "power-management handshakes (ASPM, L1, PME)",
  P21: "PCIe messages and vendor-defined messages", P22: "latency and throughput anomalies", P23: "data integrity (read-back mismatch)",
  P24: "flush, FUA and power-loss durability", P25: "firmware activation and admin-command sequencing", P26: "asynchronous events and SMART log",
  P27: "capture artefacts (export, gaps, filters)", E: "outside the probed PCIe link",
};
// "configuration space, power state and reset sequencing (family P19)"
export function familyName(p) { const k = String(p || "").trim(); if (!k) return "-"; const n = FAMILY_NAMES[k]; return n ? `${n} (family ${k})` : `family ${k}`; }

// Local date and time of a server timestamp (seconds since the epoch)
export const when = (ts) => ts ? new Date(ts * 1000).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }) : "-";
