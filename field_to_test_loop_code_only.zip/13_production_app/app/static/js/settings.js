/* Settings: LLM endpoint / model / effort and stage-2 budgets; saved to config/app_config.json, LLM hot-swapped. */
import { api, $ } from "./api.js";
import { S } from "./main.js";

export function init(state) {
  const l = state.cfg.llm, s2 = state.cfg.stage2, s1 = state.cfg.stage1;
  $("s-backend").value = l.backend; $("s-model").value = l.model; $("s-effort").value = l.effort || "low"; $("s-url").value = l.base_url || ""; $("s-keyenv").value = l.api_key_env || "";
  $("s-batch").checked = !!l.batch; $("s-capture").checked = l.capture_check !== false;
  $("s-bench").value = s2.bench; $("s-budget").value = s2.opt_budget; $("s-time").value = s2.time_budget_s; $("s-consec").value = s2.optimal_consecutive; $("s-stress").value = s2.stress_trials ?? 30; $("s-nbad").value = s2.n_bad; $("s-nfixed").value = s2.n_fixed; $("s-searchon").value = s2.search_on;
  $("firmware").value = s1.firmware_label || "FW-A"; if (s1.nsze) $("nsze").value = s1.nsze;
  $("btn-save").onclick = async () => {
    const body = { llm: { backend: $("s-backend").value, model: $("s-model").value, effort: $("s-effort").value, base_url: $("s-url").value, api_key_env: $("s-keyenv").value, batch: $("s-batch").checked, capture_check: $("s-capture").checked },
      stage2: { bench: $("s-bench").value, opt_budget: +$("s-budget").value, time_budget_s: +$("s-time").value, optimal_consecutive: +$("s-consec").value, stress_trials: +$("s-stress").value, n_bad: +$("s-nbad").value, n_fixed: +$("s-nfixed").value, search_on: $("s-searchon").value },
      stage1: { firmware_label: $("firmware").value, nsze: $("nsze").value } };
    try { const r = await api("PUT", "/api/config", body); $("s-msg").textContent = "saved · the AI reviewer now in use: " + r.llm_active + (body.stage2.bench !== S.cfg.stage2.bench ? " · the Bench change takes effect after a restart of the application" : ""); $("llm-badge").textContent = r.llm_active;  Object.assign(S.cfg.llm, body.llm); Object.assign(S.cfg.stage2, body.stage2); }
    catch (e) { $("s-msg").textContent = "could not save: " + e.message; }
  };
}
export function enter() {}
