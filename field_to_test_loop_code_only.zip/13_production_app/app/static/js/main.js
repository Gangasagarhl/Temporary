/* Router + shared state. The sidebar is a linear five-step tracker (Choose the trace -> Analyse the trace -> Defects found ->
   Reproduce and decide -> Report and tests) plus Settings and the Help page; a step unlocks only when the previous phase is complete, and the live state is written
   under each step in the same words as the status chips. */
import { api, $, esc, toast } from "./api.js";
import * as run from "./run.js";
import * as incidents from "./incidents.js";
import * as commands from "./commands.js";
import * as review from "./review.js";
import * as report from "./report.js";
import * as settings from "./settings.js";

export const S = { run: null, runs: [], cfg: null, actions: {} };
const TITLES = { "run:choose": "Choose the trace", "run:analyse": "Analyse the trace (stage 1)", commands: "NVMe commands", incidents: "Defects found", review: "Reproduce and decide (stage 2)", report: "Report and tests", settings: "Settings", help: "What the words mean" };
const PAGES = { run, commands, incidents, review, report, settings, help: {} };
/* short labels for the stage 1 step under the sidebar entry (the internal step ids are never shown) */
const STEP_SHORT = { start: "starting", analyze: "reading packets", fuse: "host evidence", isolate: "grouping defects", commands: "summarising commands", pattern_cache: "reusing verdicts", review: "AI reviewer", report: "writing report", capture_check: "capture check", done: "complete" };
/* the AI reviewer backend name and the lab device, in the operator's words */
export const llmWord = (n) => { n = String(n || "?"); return n === "stand-in" ? "stand-in (no model)" : n.startsWith("anthropic:") ? "Anthropic " + n.slice(10).split(":")[0] : n.startsWith("ollama:") ? "Ollama " + n.slice(7) : n.startsWith("openai-compat:") ? "OpenAI-compatible " + n.slice(14) : n; };
const benchWord = (b) => b === "synthetic" ? "simulated device" : b === "hook" ? "real device" : String(b || "?");
export const PHASE_TEXT = { stage1_running: "stage 1 running", stage1_failed: "stage 1 failed", stage1_done: "stage 1 complete, stage 2 not started", stage2: "stage 2 in progress", stage2_done: "stage 2 complete" };

export function currentRun() { return S.runs.find(r => r.run_id === S.run) || null; }
export function unlocked(page, step) {
  if (page === "settings" || page === "help" || (page === "run" && step !== "analyse")) return true;
  const r = currentRun(); if (!r) return false;
  const ph = r.phase;
  if (page === "run") return true;                                       // analyse: any run selected
  if (page === "incidents" || page === "report" || page === "commands") return ph !== "stage1_running" && ph !== "stage1_failed";
  if (page === "review") return ph === "stage1_done" || ph === "stage2" || ph === "stage2_done";
  return false;
}
export function applyLocks() {
  document.querySelectorAll("aside .nav").forEach(b => { const ok = unlocked(b.dataset.page, b.dataset.step); b.disabled = !ok; b.classList.toggle("locked", !ok); });
  const r = currentRun(); $("phase-badge").textContent = r ? PHASE_TEXT[r.phase] || r.phase : "no run selected";
  $("phase-badge").className = "pill " + (r ? (r.phase === "stage1_running" ? "warn" : r.phase === "stage1_failed" ? "bad" : r.phase === "stage1_done" ? "info" : "ok") : "");
  const set = (id, html) => { $(id).innerHTML = html; };
  const LOCK = (n) => `<span class="lock">locked · complete step ${n} first</span>`;
  if (!r) {
    set("nav-choose", "nothing selected yet · enter a CSV path, or open an earlier run from the history");
    set("nav-analyse", LOCK(1)); set("nav-commands", LOCK(2)); set("nav-defects", LOCK(2)); set("nav-review", LOCK(4)); set("nav-report", LOCK(5));
    set("nav-summary", "0 of 6 steps completed · 6 remaining");
    return;
  }
  const s1done = r.phase !== "stage1_running" && r.phase !== "stage1_failed";
  const done = [true, s1done, s1done, s1done, r.phase === "stage2_done", r.phase === "stage2_done"].filter(Boolean).length;
  set("nav-summary", `${done} of 6 steps completed · ${6 - done} remaining${r.phase === "stage1_failed" ? " · stage 1 failed" : ""}`);
  const cm = r.commands;
  set("nav-commands", r.phase === "stage1_running" ? LOCK(2) + " · waiting for stage 1" : r.phase === "stage1_failed" ? "-" : cm ? `${cm.n} commands · ${cm.kinds} kinds · ${cm.with_errors} with errors` : "no command summary (older run or no payload)");
  set("nav-choose", esc((r.csv || "").split("/").pop()));
  set("nav-analyse", r.phase === "stage1_running" ? `${esc(STEP_SHORT[r.progress.step] || String(r.progress.step || "").replace(/_/g, " "))} · ${r.progress.pct || 0}%<div class=bar><div style="width:${r.progress.pct || 0}%"></div></div>` : r.phase === "stage1_failed" ? "failed" : `complete · ${r.elapsed_s} s`);
  set("nav-defects", r.phase === "stage1_running" ? LOCK(2) + " · waiting for stage 1" : r.phase === "stage1_failed" ? "-" : `${r.incidents ?? "?"} defects · ${r.llm && r.llm.confirmed != null ? "AI reviewer agrees on " + r.llm.confirmed : "AI reviewer not run"}`);
  set("nav-review", !s1done ? LOCK(2) : r.stage2 ? `${r.stage2.decided} of ${r.stage2.total} decided · ${r.stage2.admitted} regression tests<div class=bar><div style="width:${r.stage2.total ? 100 * r.stage2.decided / r.stage2.total : 0}%"></div></div>` : r.phase === "stage1_done" ? "stage 1 complete · stage 2 not started" : "");
  set("nav-report", !s1done ? LOCK(2) : r.phase === "stage2_done" ? "available · complete" : "available");
}
export function show(page, arg, step) {
  if (!unlocked(page, step)) { toast(page === "review" ? "Stage 1 must complete before stage 2 can be started." : "Choose a trace and let stage 1 complete first."); page = "run"; step = "choose"; arg = undefined; }
  if (page === "run" && !step) step = currentRun() ? "analyse" : "choose";
  document.querySelectorAll("aside .nav").forEach(b => b.classList.toggle("active", b.dataset.page === page && (page !== "run" || b.dataset.step === step)));
  document.querySelectorAll(".page").forEach(s => s.classList.toggle("active", s.id === "page-" + page));
  $("page-title").textContent = TITLES[page === "run" ? "run:" + step : page];
  if (PAGES[page].enter) PAGES[page].enter(arg, step);
  location.hash = page + (arg ? "/" + arg : "") + (page === "run" && step ? "/" + step : "");
}
document.querySelectorAll("aside .nav").forEach(b => b.onclick = () => show(b.dataset.page, undefined, b.dataset.step));

export async function refreshRuns() {
  S.runs = await api("GET", "/api/runs");
  const sel = $("run-select"); const cur = S.run;
  sel.innerHTML = '<option value="">- no run selected -</option>' + S.runs.map(r => `<option value="${esc(r.run_id)}">${esc(r.run_id)}${r.label ? " - " + esc(r.label) : ""} · ${esc(PHASE_TEXT[r.phase] || r.phase)}</option>`).join("");
  if (cur) sel.value = cur;
  if (S.run && !S.runs.some(r => r.run_id === S.run)) S.run = null;      // a deleted run is no longer selected; nothing is selected by default
  applyLocks();
  return S.runs;
}
$("run-select").onchange = () => { S.run = $("run-select").value || null; applyLocks(); show("run", undefined, S.run ? "analyse" : "choose"); };

(async function boot() {
  const c = await api("GET", "/api/config");
  S.cfg = c.config; S.actions = c.actions;
  $("llm-badge").textContent = llmWord(c.llm_active); $("bench-badge").textContent = benchWord(c.config.stage2.bench);
  for (const p of Object.values(PAGES)) if (p.init) p.init(S);
  await refreshRuns();
  // a link from the defect or knowledge-base page names the run in the query (?run=...): select it before routing
  const wanted = new URLSearchParams(location.search).get("run");
  if (wanted && S.runs.some(r => r.run_id === wanted)) { S.run = wanted; $("run-select").value = wanted; applyLocks(); }
  const parts = (location.hash.replace("#", "") || "run").split("/");
  const page = PAGES[parts[0]] ? parts[0] : "run";
  show(page, page === "run" ? undefined : parts[1], page === "run" ? parts[1] : undefined);
})();
