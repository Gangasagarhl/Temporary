/* Page 3: the errors found under NVMe commands.  Each row ties one command to the parameters it carried, the time
   it took to complete and the low-level PCIe packets that went wrong under it.  Below: every command by kind, and
   the pacing tables.  Data: GET /api/runs/<run>/commands (built by the stage-1 step "commands"), /commands/rows
   (one kind, paged) and /commands/<sqid>/<cid> (one command). */
import { api, $, esc, toast, defectName } from "./api.js";
import { S } from "./main.js";

let SUMMARY = null, KIND = null, ERRKIND = null;

export function init() {
  $("cmd-refresh").onclick = () => load(true);
  $("cmd-only-errors").onchange = renderTypes;
  $("cmd-sort").onchange = () => KIND && loadRows(KIND);
  $("cmd-rows-errors").onchange = () => KIND && loadRows(KIND);
}
export async function enter() { if (S.run) await load(false); }

const n = (x) => (x === null || x === undefined) ? "-" : Number(x).toLocaleString();
const OWNER = { device: "the controller", host: "the host", link: "the link (both sides)", both: "host waits, controller works" };
const LAYER = { "data-link": "data link layer", physical: "physical layer", transaction: "transaction layer", nvme: "NVMe level",
  "nvme-cmd": "NVMe command", config: "configuration space", capture: "capture itself", data: "data integrity", "data integrity": "data integrity" };
const layer = (l) => LAYER[l] || (l ? String(l).replace(/[-_]/g, " ") : "-");
const kindKey = (t) => (t.klass.startsWith("Admin") ? "admin" : "io") + "/" + t.opcode;
function fmtPs(ps) {
  if (ps === null || ps === undefined) return "-";
  if (ps >= 1e12) return (ps / 1e12).toFixed(3) + " s";
  if (ps >= 1e9) return (ps / 1e9).toFixed(3) + " ms";
  if (ps >= 1e6) return (ps / 1e6).toFixed(1) + " µs";
  return Math.round(ps / 1000) + " ns";
}
const defectLink = (id) => id ? `<a href="/defect?run=${encodeURIComponent(S.run)}&inc=${encodeURIComponent(id)}" target="_blank">${esc(defectName(id))}</a>` : "";

async function load(force) {
  if (!S.run) return toast("select a run first");
  $("cmd-errbody").innerHTML = `<tr><td colspan="4" class="empty">loading…</td></tr>`;
  try { SUMMARY = await api("GET", `/api/runs/${S.run}/commands`); } catch (e) { SUMMARY = null; }
  $("cmd-csv").hidden = !SUMMARY || !SUMMARY.n_commands;
  $("cmd-csv").href = `/api/runs/${S.run}/commands.csv`;
  ERRKIND = null; KIND = null; $("cmd-one").innerHTML = ""; $("cmd-kind-card").hidden = true;
  if (!SUMMARY || SUMMARY.missing || !SUMMARY.n_commands) {
    $("cmd-chips").innerHTML = ""; $("cmd-kinds").innerHTML = "";
    const why = (SUMMARY && SUMMARY.note) || "no NVMe command could be decoded in this capture";
    $("cmd-errbody").innerHTML = `<tr><td colspan="4" class="empty">${esc(why)}.<br>
      <span class="muted">Commands are decoded from the 64-byte submission entries the controller fetches. That needs an export whose DATA column holds the bytes (hex), or the payload side-car. A capture analysed before this page existed needs stage 1 to be run again.</span></td></tr>`;
    $("cmd-body").innerHTML = `<tr><td colspan="4" class="empty">${esc(why)}</td></tr>`;
    $("cmd-basis").textContent = ""; $("cmd-timing").innerHTML = ""; $("cmd-controller").textContent = "none";
    return;
  }
  const s = SUMMARY;
  $("cmd-chips").innerHTML = [[s.n_error_rows, "commands with something wrong"], [s.n_with_errors, "with a packet-level error"], [s.n_not_completed, "never completed"],
    [s.n_commands, "commands decoded in all"], [s.n_types, "kinds of command"]]
    .map(([v, t]) => `<div class=chip><b>${n(v)}</b><span>${esc(t)}</span></div>`).join("");
  $("cmd-kinds").innerHTML = s.error_kinds.length ? `<span class="muted small">errors found:</span> ` + s.error_kinds.map(k => `<button class="atile small" data-kind="${esc(k.kind)}">${esc(k.kind)} <b>×${n(k.count)}</b></button>`).join(" ") : "";
  document.querySelectorAll("#cmd-kinds button").forEach(b => b.onclick = () => { ERRKIND = ERRKIND === b.dataset.kind ? null : b.dataset.kind; renderErrors(); });
  $("cmd-basis").innerHTML = `<b>Where each column comes from.</b> Parameters: ${esc(s.basis.parameters)}. Latency: ${esc(s.basis.latency)}. Labels: ${esc(s.basis.labels)}. Errors: ${esc(s.basis.errors)}. ${esc(s.basis.buckets)}.`;
  renderManagement();
  renderErrors();
  renderTypes();
  renderTiming();
}

/* ---------------- the management view */
function renderManagement() {
  const s = SUMMARY, M = s.management || [];
  const b = s.management_basis || {};
  $("cmd-mgmt-basis").innerHTML = M.length ? `<b>How to read it.</b> Rate: ${esc(b.rate || "")}. Responsible: ${esc(b.responsible || "")}. Parameters: ${esc(b.contrast || "")}. Time: ${esc(b.timing || "")}.` : "";
  if (!M.length) { $("cmd-mgmt").innerHTML = `<span class="pill ok">every decoded command completed successfully and no packet went wrong under any of them</span>`; return; }
  const pct = (x) => Math.round(100 * x) + " %";
  $("cmd-mgmt").innerHTML = `<div class="tablewrap"><table class="report"><thead><tr><th>Command</th><th>Called</th><th>Went wrong</th><th>Failed status</th><th>Never completed</th><th>Over the host's limit</th><th>Responsible by the status codes</th><th>Defects</th></tr></thead><tbody>
    ${M.map((m, i) => `<tr class="mgrow" data-i="${i}" style="cursor:pointer"><td><b>${esc(m.kind)}</b><br><span class="muted small">${esc(m.klass)} command, opcode ${esc(m.opcode)}</span></td><td class=mono>${n(m.called)}</td><td><b>${n(m.went_wrong)}</b> <span class="muted small">(${pct(m.rate)}, ${pct(m.rate_ci[0])} to ${pct(m.rate_ci[1])})</span></td><td class=mono>${n(m.failed_status)}</td><td class=mono>${n(m.never_completed)}</td><td class=mono>${n(m.over_host_limit)}</td><td>${Object.keys(m.responsible).length ? Object.entries(m.responsible).map(([k, v]) => `<span class="pill ${k === "device" ? "bad" : k === "host" ? "warn" : "info"}">${esc(k)} ×${n(v)}</span>`).join(" ") : "<span class=muted>not decided by a status code</span>"}</td><td>${(m.defects || []).map(d => `<a href="/defect?run=${encodeURIComponent(S.run)}&inc=${encodeURIComponent(d)}" target="_blank">${esc(defectName(d))}</a>`).join(", ") || "-"}</td></tr>`).join("")}
    </tbody></table></div><div id="cmd-mgmt-detail"></div>`;
  document.querySelectorAll("#cmd-mgmt tr.mgrow").forEach(tr => tr.onclick = () => showManagement(+tr.dataset.i));
  showManagement(0);
}
function showManagement(i) {
  const m = (SUMMARY.management || [])[i]; if (!m) return;
  document.querySelectorAll("#cmd-mgmt tr.mgrow").forEach(tr => tr.classList.toggle("on", +tr.dataset.i === i));
  const nar = m.narrative || {};
  const sep = (m.separating || []).map(c => `<li><b>${esc(c.attribute)} = ${esc(c.value)}</b>: ${n(c.failed)} of the ${n(m.went_wrong)} problems; ${n(c.failed)} of ${n(c.total)} such commands went wrong, against ${n(c.others_failed)} of ${n(c.others_total)} with other values <span class="muted small">(an association in this capture, not a proven cause)</span></li>`).join("");
  const pk = (m.packets || []).map(p => `<li>${n(p.count)} × ${esc(p.text)} <span class="muted small">(${esc(p.layer || "")}; packets ${p.example_pkts.map(n).join(", ")})</span></li>`).join("");
  const st = (m.statuses || []).map(x => `<li>${n(x.count)} × ${esc(x.status)}${x.side ? ` → <b>${esc(x.side)}</b>: ${esc(x.side === "host" ? "the host " + x.reason : x.reason)}` : ""}</li>`).join("");
  const t = m.timing || {};
  $("cmd-mgmt-detail").innerHTML = `<h3>${esc(m.kind)}: what to tell the team</h3>
    <div class="box"><p><b>${esc(nar.headline || "")}</b></p><p>${esc(nar.what_happens || "")}</p><p><b>Tell the team:</b> ${esc(nar.tell_the_team || "")}</p><p class="muted small">source: ${esc(m.narrative_source || "sentences built from the facts")}</p></div>
    <div class="grid2">
      <div><h4>The facts behind it</h4><ul class="small">${m.lines.map(l => `<li>${esc(l)}</li>`).join("")}</ul></div>
      <div><h4>Status codes returned, and who the specification points at</h4><ul class="small">${st || "<li>none: these commands did not return an error status</li>"}</ul>
      <h4>Parameters the failures share</h4><ul class="small">${sep || "<li>no parameter value separates the failures from the successful commands of this kind</li>"}</ul>
      <h4>Low-level packets behind them</h4><ul class="small">${pk || "<li>none: the controller answered each command, with the status above</li>"}</ul>
      <h4>Time</h4><ul class="small"><li>usual successful ${esc(m.kind)} in this capture: ${esc(t.usual_successful || "no successful one to compare")}${t.successful_n ? ` (median of ${n(t.successful_n)})` : ""}</li><li>the ones that went wrong: ${esc(t.failed_min || "-")} to ${esc(t.failed_max || "-")}</li><li>host's limit: ${n(t.host_limit_s)} s · ${esc(t.spec_note || "")}</li></ul></div>
    </div>`;
}

/* ---------------- the error-first table */
function renderErrors() {
  const s = SUMMARY;
  document.querySelectorAll("#cmd-kinds button").forEach(b => b.classList.toggle("on", b.dataset.kind === ERRKIND));
  const rows = s.error_rows.filter(r => !ERRKIND || r.kinds.includes(ERRKIND));
  if (!s.error_rows.length) { $("cmd-errbody").innerHTML = `<tr><td colspan="4" class="empty"><span class="pill ok">every decoded command completed successfully and no packet went wrong under any of them</span></td></tr>`; return; }
  if (!rows.length) { $("cmd-errbody").innerHTML = `<tr><td colspan="4" class="empty">no command with that error</td></tr>`; return; }
  $("cmd-errbody").innerHTML = rows.map(r => {
    const params = r.params.map(p => `<div><span class="muted">${esc(p[0])}</span> <span class=mono>${esc(String(p[1]))}</span></div>`).join("");
    const steps = r.steps.filter(x => x.text !== "-").map(x => `<div><span class="muted">${esc(x.step)}</span> <span class=mono>${esc(x.text)}</span> <span class="muted small">(${esc(OWNER[x.owner] || x.owner)})</span></div>`).join("");
    const lbl = r.end !== "cqe" ? `<span class="pill warn">${esc(r.label)}</span>` : /over the host/.test(r.label) ? `<span class="pill bad">${esc(r.label)}</span>` : /slowest/.test(r.label) ? `<span class="pill warn">${esc(r.label)}</span>` : `<span class="pill">${esc(r.label)}</span>`;
    const st = r.status && !/^Successful/.test(r.status) ? `<div><span class="pill bad">failed</span> ${esc(r.status)}</div>` : (r.end !== "cqe" ? `<div><span class="pill warn">never completed</span> ${esc(r.lost || r.end)}</div>` : `<div><span class="pill ok">completed successfully</span> but a packet under it went wrong:</div>`);
    const errs = r.errors.map(e => `<div>packet <span class=mono>${n(e.pkt)}</span>: ${esc(e.text)} <span class="muted small">(${esc(layer(e.layer))})</span>${e.defect ? ` · ${defectLink(e.defect)}` : ""}</div>`).join("");
    return `<tr class="errrow" data-sqid="${r.sqid}" data-cid="${r.cid}" data-inst="${r.inst ?? ""}" style="cursor:pointer">
      <td><b>${esc(r.name)}</b><br><span class="muted small">${r.klass === "admin" ? "admin" : "I/O"} command, opcode 0x${esc(r.opc.toString(16).toUpperCase().padStart(2, "0"))}</span><br><span class="small">queue ${r.sqid} · command id ${r.cid}</span><br><span class="muted small">submitted at packet ${n(r.inst)}</span></td>
      <td class="small">${params || "<span class=muted>none</span>"}</td>
      <td class="small"><div><b>${esc(r.latency)}</b> doorbell to completion ${lbl}</div>${steps}${r.n_pieces ? `<div class="muted">${n(r.n_pieces)} data packet${r.n_pieces === 1 ? "" : "s"}</div>` : ""}</td>
      <td class="small">${st}${errs}</td></tr>`;
  }).join("");
  document.querySelectorAll("#cmd-errbody tr.errrow").forEach(tr => tr.onclick = () => loadOne(tr.dataset.sqid, tr.dataset.cid, tr.dataset.inst, "cmd-one"));
}

/* ---------------- every command by kind */
function latencyCell(t) {
  const L = t.latency, st = L.total_text || {};
  if (!L.total) return `<span class="muted">no completed command of this kind</span>`;
  const over = L.over_host_limit ? `<div><span class="pill bad">${n(L.over_host_limit)} over the host's limit of ${L.host_limit_s} s</span></div>` : "";
  const lbn = L.long_by_nature ? `<div class="muted small">long by nature: ${esc(L.long_by_nature)} works on the whole media or firmware</div>` : "";
  const steps = (L.steps || []).filter(x => x.stats).map(x => `<tr><td>${esc(x.step)}</td><td class="muted">${esc(OWNER[x.owner] || x.owner)}</td><td class=mono>${esc(fmtPs(x.stats.p50))}</td><td class=mono>${esc(fmtPs(x.stats.p99))}</td><td class=mono>${esc(fmtPs(x.stats.max))}</td></tr>`).join("");
  return `<div><b>typical ${esc(st.p50)}</b> · slowest 10 % from ${esc(L.p90_text)} · slowest 1 % from ${esc(L.p99_text)} · longest ${esc(st.max)}</div>${over}${lbn}
    <details><summary class="small">each step (median · slowest 1 % · longest)</summary><table class="small"><tr><th>step</th><th>who</th><th>median</th><th>p99</th><th>longest</th></tr>${steps}</table></details>`;
}
function paramsCell(t) {
  const p = t.parameters, obs = p.observed || {};
  const o = Object.entries(obs).map(([k, v]) => `<div><span class="muted">${esc(k)}:</span> ${esc(typeof v === "object" ? JSON.stringify(v) : v)}</div>`).join("");
  return `<div class="small"><b>fields:</b> ${esc((p.fields || []).join(", "))}</div>${o}<div class="muted small">from ${esc(p.source)}</div>`;
}
function errorsCell(t) {
  const st = Object.entries(t.status || {}).filter(([k]) => k !== "Successful Completion");
  const stHtml = st.length ? `<div><b>failed status:</b> ${st.map(([k, v]) => `${esc(k)} ×${n(v)}`).join("; ")}</div>` : "";
  if (!t.errors.length && !st.length) return `<span class="pill ok">no packet error, every completion successful</span>`;
  const e = t.errors.map(x => `<div><span class="pill ${x.layer === "capture" ? "info" : "bad"}">${n(x.count)}</span> ${esc(x.text)} <span class="muted small">(${esc(layer(x.layer))}; e.g. packet ${n(x.examples[0].pkt)}${x.examples[0].defect ? `, ${esc(defectName(x.examples[0].defect))}` : ""})</span></div>`).join("");
  return `${stHtml}${e}<div class="muted small">${n(t.commands_with_errors)} of ${n(t.count)} commands of this kind carry a packet-level error</div>`;
}
function renderTypes() {
  if (!SUMMARY) return;
  const only = $("cmd-only-errors").checked;
  const types = SUMMARY.types.filter(t => !only || t.errors.length || t.not_completed || Object.keys(t.status).some(k => k !== "Successful Completion"));
  $("cmd-body").innerHTML = types.length ? types.map(t => `<tr class="cmdrow" data-kind="${esc(kindKey(t))}" style="cursor:pointer">
      <td><b>${esc(t.name)}</b><br><span class="muted small">${esc(t.klass)}, opcode ${esc(t.opcode)}</span><br>${n(t.count)} seen${t.not_completed ? `, <span class="pill warn">${n(t.not_completed)} never completed</span>` : ""}</td>
      <td>${paramsCell(t)}</td><td>${latencyCell(t)}</td><td>${errorsCell(t)}</td></tr>`).join("")
    : `<tr><td colspan="4" class="empty">no kind of command has a failed status or a packet error in this capture</td></tr>`;
  document.querySelectorAll("#cmd-body tr.cmdrow").forEach(tr => tr.onclick = () => { KIND = tr.dataset.kind; loadRows(KIND); });
}
function renderTiming() {
  const s = SUMMARY;
  const bucketTable = (title, rows) => `<div><h3>${esc(title)}</h3><table class="small"><tr><th>bucket (ms)</th><th>commands</th></tr>${rows.map(r => `<tr><td>${esc(r.bucket)}</td><td class=mono>${n(r.count)}</td></tr>`).join("")}</table></div>`;
  const gaps = (k) => { const g = s.host_gaps_text[k] || {}; return Object.keys(g).length ? `median ${esc(g.p50)} · slowest 10 % from ${esc(g.p90)} · longest ${esc(g.max)}` : "not measurable"; };
  $("cmd-timing").innerHTML = bucketTable("Command interval, I/O queues", s.intervals_ms.io) + bucketTable("Command interval, admin queue", s.intervals_ms.admin) +
    `<div><h3>Host gap after a completion</h3><div>I/O queues: ${gaps("io")}</div><div>admin queue: ${gaps("admin")}</div></div>`;
  $("cmd-controller").innerHTML = s.controller_events.length ? `<table class="small"><tr><th>event</th><th>times</th><th>specification basis</th></tr>${s.controller_events.map(c => `<tr><td>${esc(c.text)}</td><td class=mono>${n(c.count)}</td><td class="muted">${esc(c.spec)}</td></tr>`).join("")}</table>` : "none";
}

async function loadRows(kind) {
  const t = SUMMARY.types.find(x => kindKey(x) === kind); if (!t) return;
  $("cmd-kind-card").hidden = false;
  $("cmd-kind-title").textContent = `${t.name} commands (${t.klass.toLowerCase()}, opcode ${t.opcode})`;
  $("cmd-rows").innerHTML = `<span class="muted">loading…</span>`;
  const r = await api("GET", `/api/runs/${S.run}/commands/rows?kind=${encodeURIComponent(kind)}&errors=${$("cmd-rows-errors").checked ? 1 : 0}&sort=${$("cmd-sort").value}&limit=200`);
  if (!r.rows.length) { $("cmd-rows").innerHTML = `<span class="muted">no ${esc(t.name)} command matches the filter (${n(r.total)} in total)</span>`; return; }
  $("cmd-rows").innerHTML = `<p class="help">${n(r.rows.length)} of ${n(r.total)} shown. Click a command for its parameters, each step, each data piece and its errors.</p>
    <div class="tablewrap"><table class="report small"><thead><tr><th>queue · command id</th><th>submitted at packet</th><th>latency</th><th>status</th><th>bytes</th><th>queue depth at submission</th><th>packet errors</th></tr></thead><tbody>
    ${r.rows.map(x => `<tr class="onecmd" data-sqid="${x.sqid}" data-cid="${x.cid}" data-inst="${x.inst ?? ""}" style="cursor:pointer"><td>SQ ${x.sqid} · ${x.cid}</td><td class=mono>${n(x.inst)}</td><td class=mono>${esc(x.latency)}</td><td>${x.end === "cqe" ? esc(x.status_text || "-") : `<span class="pill warn">never completed (${esc(x.end)})</span>`}</td><td class=mono>${n(x.xfer)}</td><td class=mono>${n(x.qd)}</td><td>${x.n_errors ? `<span class="pill bad">${n(x.n_errors)}</span>` : "none"}</td></tr>`).join("")}
    </tbody></table></div><div id="cmd-one-kind"></div>`;
  document.querySelectorAll("#cmd-rows tr.onecmd").forEach(tr => tr.onclick = () => loadOne(tr.dataset.sqid, tr.dataset.cid, tr.dataset.inst, "cmd-one-kind"));
}

/* ---------------- one command, piece by piece */
async function loadOne(sqid, cid, inst, target) {
  const box = $(target) || $("cmd-one");
  box.innerHTML = `<span class="muted">loading…</span>`;
  let d; try { d = await api("GET", `/api/runs/${S.run}/commands/${sqid}/${cid}${inst ? "?inst=" + inst : ""}`); } catch (e) { box.innerHTML = `<span class="muted">command not found</span>`; return; }
  const params = d.params.map(p => `<tr><td><b>${esc(p[0])}</b></td><td class=mono>${esc(String(p[1]))}</td><td>${esc(p[2])}</td><td class="muted small">${esc(p[3])}</td></tr>`).join("");
  const steps = d.steps.map(s => `<tr><td>${esc(s.step)}</td><td class="muted">${esc(OWNER[s.owner] || s.owner)}</td><td class=mono>${esc(s.text)}</td><td class="muted small">${esc(s.plain)}</td></tr>`).join("");
  const pieces = d.pieces.length ? d.pieces.map(p => `<tr><td class=mono>${n(p.pkt)}</td><td class=mono>${p.lba === null || p.lba === undefined ? "-" : n(p.lba)}</td><td class=mono>${n(p.bytes)}</td><td class=mono>${esc(fmtPs(p.since_fetch_ps))}</td><td>${(d.errors.filter(e => e.pkt === p.pkt).map(e => esc(e.text)).join("; ")) || "clean"}</td></tr>`).join("") : `<tr><td colspan="5" class="muted">no data packet (a command without data, or the data was not captured)</td></tr>`;
  const errs = d.errors.length ? d.errors.map(e => `<tr><td class=mono>${n(e.pkt)}</td><td>${esc(e.text)}</td><td class="muted">${esc(layer(e.layer))}</td><td class="small">${esc(e.detail)}</td><td>${e.defect ? `${defectLink(e.defect)}${e.defect_rules ? ` <span class="muted small">(${esc(e.defect_rules.join(", "))})</span>` : ""}` : "-"}</td></tr>`).join("") : "";
  const pk = d.packets;
  box.innerHTML = `<h3>${esc(d.name)} · queue ${esc(String(d.sqid))} · command id ${esc(String(d.cid))}</h3>
    <div class="chips"><div class=chip><b>${esc(d.latency)}</b><span>doorbell to completion</span></div><div class=chip><b>${esc(d.status || (d.end === "cqe" ? "-" : "never completed"))}</b><span>completion status</span></div>${d.lost ? `<div class=chip><b>${esc(d.lost)}</b><span>how it ended</span></div>` : ""}</div>
    <div class="muted small">packets: doorbell ${n(pk.pkt_db)} · fetch ${n(pk.pkt_fetch)} · entry ${n(pk.pkt_sqe)} · first data ${n(pk.pkt_first_data)} · last data ${n(pk.pkt_last_data)} · completion ${n(pk.pkt_cqe)}</div>
    <div class="grid2"><div><h4>Parameters</h4><table class="small"><tr><th>field</th><th>value</th><th>plain words</th><th>source</th></tr>${params}</table></div>
    <div><h4>Each step</h4><table class="small"><tr><th>step</th><th>who</th><th>time</th><th>what happens</th></tr>${steps}</table></div></div>
    <h4>Pieces of the transfer (each data packet)</h4><div class="tablewrap"><table class="small"><tr><th>packet</th><th>LBA</th><th>bytes</th><th>time after fetch</th><th>errors on this packet</th></tr>${pieces}</table></div>
    ${d.errors.length ? `<h4>Low-level packets and errors under this command</h4><div class="tablewrap"><table class="small"><tr><th>packet</th><th>what went wrong</th><th>layer</th><th>detail</th><th>defect</th></tr>${errs}</table></div>` : `<p class="pill ok">no packet-level error under this command</p>`}`;
}
