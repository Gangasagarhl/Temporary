/* The database interface: overview, signature explorer (causes -> procedures -> tests), tables, event log + undo, caches. */
import { api, $, esc, fmt, toast, pill, statusCls, seq, kv, defectName, errorTypeShort, errorTypeFull, CATALOGUE_GROUPS, groupOf, familyName } from "./api.js";

let OV = null;
const procStatus = (status, by) => status === "admin-approved" ? (by ? "approved by " + by : "approved by a second admin") : status === "validated-by-execution" ? "awaiting approval by a second admin" : status === "deprecated" ? "retired" : status === "superseded" ? "replaced by a newer version" : String(status || "-").replace(/_/g, " ");
const procId = (id) => { const h = String(id || "").split("::").pop(); return h ? "procedure #" + h.slice(0, 8) : "-"; };
const pct = (p) => p == null ? "-" : Math.round(p * 100) + " %";
const chapterOf = (sig) => { const g = groupOf(sig); return g ? `${g.letter} = ${g.text}` : "-"; };
document.querySelectorAll(".tabs button").forEach(b => b.onclick = () => { document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("active", x === b)); document.querySelectorAll(".sub").forEach(s => s.classList.toggle("active", s.id === "sub-" + b.dataset.sub)); if (b.dataset.sub === "cache") loadCache(); if (b.dataset.sub === "events") loadEvents(); });

async function overview() {
  OV = await api("GET", "/api/db/overview"); const k = OV.knowledge, g = OV.graph;
  $("db-chips").innerHTML = [["events logged", k.events], ["error types seen", k.signatures], ["causes", k.cause_nodes], ["procedures", g.n_scenario], ["approved procedures", k.approved_solutions], ["regression tests", g.n_test], ["lessons", k.lessons], ["links between causes and procedures", g.pedges], ["verdicts reused from the cache", `${OV.cache.entries} (${OV.cache.hits} times reused)`], ["AI reviewer", OV.llm]].map(([a, b]) => `<div class=chip><b>${esc(b)}</b><span>${esc(a)}</span></div>`).join("");
  renderSigs(); $("llm-usage").textContent = JSON.stringify({ llm: OV.llm, usage: OV.llm_usage, stage2_counters: OV.counters }, null, 1);
  loadEvents(OV.recent_events);
}
function renderSigs() {
  const f = ($("sig-filter").value || "").toLowerCase(); const tb = $("sig-table").querySelector("tbody"); tb.innerHTML = "";
  for (const s of OV.signatures) { if (f && !(s.sig + s.pattern + chapterOf(s.sig)).toLowerCase().includes(f)) continue;
    const tr = document.createElement("tr"); tr.className = "click"; tr.innerHTML = `<td><b>${esc(s.sig)}</b></td><td>${esc(chapterOf(s.sig))}</td><td>${esc(familyName(s.pattern))}</td><td>${s.seen ?? "-"}</td><td>${s.causes}</td><td>${s.procedures}</td><td>${s.approved}</td><td>${s.tests}</td><td>${s.lessons}</td>`;
    tr.onclick = () => openSig(s.sig); tb.appendChild(tr); }
  if (!tb.children.length) tb.innerHTML = "<tr><td colspan=9 class=muted>empty - the knowledge base fills as the admin decides</td></tr>";
}
$("sig-filter").oninput = renderSigs;
async function openSig(sig) {
  const d = await api("GET", `/api/db/signature/${encodeURIComponent(sig)}`); $("sig-title").textContent = errorTypeFull(sig);
  const el = $("sig-tree"); el.className = "tree"; el.innerHTML = "";
  let first = true;
  for (const c of d.tree) {
    const e = c.edge || {};
    el.innerHTML += `<div class=node><b>cause</b> <span class="small">${esc((c.content || {}).text || JSON.stringify(c.content || {}).slice(0, 80))}</span><br>
      <span class=small>admin feedback rating ${fmt(e.a / (e.a + e.b), 2)} from ${e.n} decisions (1 = always judged correct) · lab reliability ${fmt(e.ta / (e.ta + e.tb), 2)} (1 = always reproduced)</span>
      ${c.procedures.map(p => { const lbl = first ? " (its id in the knowledge base)" : ""; first = false; return `<div class=proc>${pill(procStatus(p.scenario_status), statusCls(p.scenario_status === "admin-approved" ? "done" : p.scenario_status))} <span class="muted small">${esc(procId(p.scenario_id))}${lbl}</span> · reproduced in at least ${pct(p.repro_lower95)} of lab runs · admin feedback rating ${fmt(p.edge_post, 2)} from ${p.edge_n} decisions
        ${seq(p.procedure)}<div class=small>regression tests: ${p.tests.length ? p.tests.map(t => `${esc(t.id.split("::")[1])} ${t.admitted ? pill("filed", "ok") : pill("not filed", "bad")}`).join(" ") : "none"} · versions, newest first: ${p.chain.map(x => esc(procStatus(x.status))).join(" ← ")}</div></div>`; }).join("") || "<div class='muted small'>no procedure yet</div>"}</div>`;
  }
  if (d.lessons.length) el.innerHTML += `<h3>Lessons learned</h3>${d.lessons.map(l => `<div class=small>[recorded by ${esc(l.producer)}] ${esc(l.text)}</div>`).join("")}`;
  if (!d.tree.length) el.innerHTML = "<span class=muted>no causes saved for this error type yet</span>";
}
$("btn-db-load").onclick = async () => {
  const t = await api("GET", `/api/db/table/${$("db-table").value}?limit=${+$("db-limit").value || 200}&sig=${encodeURIComponent($("db-sig").value)}`);
  $("db-rows").innerHTML = `<p class="help">Advanced view: the raw columns of the table, exactly as stored.</p><table><thead><tr>${t.columns.map(c => "<th>" + esc(c) + "</th>").join("")}</tr></thead><tbody>${t.rows.map(r => "<tr>" + t.columns.map(c => "<td>" + esc(typeof r[c] === "object" ? JSON.stringify(r[c]).slice(0, 180) : (typeof r[c] === "number" ? +r[c].toFixed(3) : r[c])) + "</td>").join("") + "</tr>").join("")}</tbody></table>`;
};
async function loadEvents(rows) {
  if (!rows) rows = (await api("GET", "/api/db/table/event?limit=60")).rows;
  $("ev-rows").innerHTML = `<table><thead><tr><th>event number</th><th>time</th><th>what happened</th><th>who</th><th>details (advanced: as stored)</th><th>undone</th></tr></thead><tbody>${rows.map(r => `<tr><td>${r.id}</td><td class=small>${new Date(r.ts * 1000).toLocaleTimeString()}</td><td>${esc(String(r.kind || "").replace(/_/g, " "))}</td><td>${esc(r.actor)}</td><td class="small mono">${esc(JSON.stringify(r.payload).slice(0, 200))}</td><td>${r.undone ? pill("undone", "warn") : ""}</td></tr>`).join("")}</tbody></table>`;
}
$("btn-ev-refresh").onclick = () => loadEvents();
$("btn-undo").onclick = async () => { const id = $("db-undo-id").value; if (!id || !confirm("Undo event " + id + " and rebuild the knowledge base from the event log?")) return; try { await api("POST", "/api/db/undo", { event_id: +id, actor: "admin" }); toast("event " + id + " undone; the knowledge base was rebuilt from the event log"); overview(); loadEvents(); } catch (e) { toast("undo failed: " + e.message); } };
async function loadCache() {
  const c = await api("GET", "/api/db/cache");
  $("cache-rows").innerHTML = `<p class=muted>${c.stats.entries} verdicts in the cache, reused ${c.stats.hits} times - a defect with the same error type, rule, error family, layer, rule set and evidence-row sequence (and the same model and prompt version) is confirmed without asking the AI reviewer again.</p>
    <table><thead><tr><th>error type</th><th>rule</th><th>error family</th><th>layer</th><th>verdict</th><th>model</th><th>times reused</th><th>first seen in (run / defect)</th></tr></thead><tbody>${c.rows.map(r => `<tr><td><b>${esc(errorTypeShort(r.card))}</b></td><td>${esc(r.rule)}</td><td>${esc(familyName(r.pattern))}</td><td>${esc(r.layer)}</td><td>${pill(r.verdict, statusCls(r.verdict))}</td><td>${esc(r.model)}</td><td>${r.hits}</td><td class=small>${esc(r.source_run)} / ${esc(defectName(r.source_incident))}</td></tr>`).join("")}</tbody></table>`;
}
overview();
