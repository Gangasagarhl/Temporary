/* Test coverage: which rules and analyzer error kinds have real evidence (stored runs, unit tests, the kept run of
   the 485-error trace). Everything shown comes from GET /api/coverage (stage1/pcie_isolate/coverage.py). */
import { api, $, esc, num } from "./api.js";

let D = null, famFilter = null, statusFilter = "all";
const CLS = { "seen on packets in a run": "ok", "unit test only": "warn", "no evidence yet": "bad", "Errors-column name only": "bad" };
const pillOf = (word) => `<span class="pill ${CLS[word] || ""}">${esc(word)}</span>`;
const pct = (a, b) => b ? Math.round(100 * a / b) : 0;

export function init() {
  $("cov-refresh").onclick = () => load(true);
  $("cov-search").oninput = () => renderRules();
}
export async function enter() { if (!D) await load(false); }

async function load(force) {
  $("cov-chips").innerHTML = '<div class="empty">counting</div>';
  try { D = await api("GET", "/api/coverage" + (force ? "?refresh=1" : "")); }
  catch (e) { $("cov-chips").innerHTML = `<div class="empty">could not count: ${esc(e.message)}</div>`; return; }
  renderAll();
}

function renderAll() {
  const t = D.totals, k = D.kept, pl = k && k.planted;
  const chip = (big, small) => `<div class="chip"><b>${big}</b><span>${esc(small)}</span></div>`;
  $("cov-chips").innerHTML =
    (pl ? chip(`${num(pl.measures[0].count)} of ${num(pl.total)}`, "planted errors found in the 485-error trace") : "") +
    chip(`${num(t.with_evidence)} of ${num(t.rules)}`, "rules with evidence (seen on packets, or a unit test)") +
    chip(`${num(t.none)} of ${num(t.rules)}`, `rules with no evidence yet (${t.none_by_design} of them need outside evidence by design)`) +
    chip(`${num(t.kinds_seen)} of ${num(t.kinds)}`, "analyzer error kinds seen on packets (all 72 are tested by name)");
  $("cov-when").textContent = `Counted ${D.generated_at} from ${t.runs_scanned} stored runs, ${t.test_files} test files and the kept run of the 485-error trace` + (k ? ` (${k.measured_at}, ${k.seconds} s, ${k.model_calls} model calls)` : " (none kept)") + ".";
  renderFamilies(); renderFilter(); renderRules(); renderPlanted(); renderKinds(); renderSources();
}

function bar(f) {
  const w = (n) => `${100 * n / f.total}%`;
  return `<div class="covbar" title="${f.seen} seen on packets, ${f.test} unit test only, ${f.none} no evidence yet"><i class="ok" style="width:${w(f.seen)}"></i><i class="warn" style="width:${w(f.test)}"></i><i class="bad" style="width:${w(f.none)}"></i></div>`;
}

function renderFamilies() {
  $("cov-fambody").innerHTML = D.families.map(f => `<tr class="famrow${famFilter === f.family ? " sel" : ""}" data-f="${esc(f.family)}"><td>${esc(f.family)}</td><td>${f.total}</td><td>${bar(f)}</td><td>${f.seen}</td><td>${f.test}</td><td>${f.none}</td></tr>`).join("");
  $("cov-fambody").querySelectorAll("tr.famrow").forEach(tr => tr.onclick = () => { famFilter = famFilter === tr.dataset.f ? null : tr.dataset.f; renderFamilies(); renderRules(); });
}

function renderFilter() {
  const t = D.totals, W = D.words;
  const opts = [["all", "all rules", t.rules], [W.seen, "seen on packets in a run", t.seen], [W.test, "unit test only", t.test], [W.none, "no evidence yet", t.none]];
  $("cov-filter").innerHTML = opts.map(([v, label, n]) => `<button class="chip${statusFilter === v ? " sel" : ""}" data-v="${esc(v)}"><b>${n}</b><span>${esc(label)}</span></button>`).join("");
  $("cov-filter").querySelectorAll("button").forEach(b => b.onclick = () => { statusFilter = b.dataset.v; renderFilter(); renderRules(); });
}

function evidenceText(r) {
  const parts = [];
  if (r.count_485) parts.push(`the 485-error trace: ${num(r.count_485)} finding${r.count_485 === 1 ? "" : "s"}`);
  if (r.runs.length) {
    const top = r.runs.slice().sort((a, b) => b.count - a.count).slice(0, 2).map(x => `${esc(x.trace || x.run)}: ${num(x.count)}`);
    parts.push(`${r.runs.length} stored run${r.runs.length === 1 ? "" : "s"} (${top.join("; ")}${r.runs.length > 2 ? "; and more" : ""})`);
  }
  if (r.tests.length) {
    const byFile = {};
    r.tests.forEach(x => (byFile[x.file] = byFile[x.file] || []).push(x.test));
    parts.push("named in " + Object.entries(byFile).map(([f, ts]) => `${esc(f)} (${ts.slice(0, 3).map(esc).join(", ")}${ts.length > 3 ? `, and ${ts.length - 3} more` : ""})`).join("; "));
  }
  if (!parts.length) return r.needs_outside_evidence ? "nothing on the wire can exercise it: it needs a host log or a lab result by design" : "nothing yet: no run has made it fire and no test names it";
  return parts.join(". ");
}

function renderRules() {
  const q = $("cov-search").value.trim().toLowerCase();
  let rows = D.rules;
  if (famFilter) rows = rows.filter(r => r.family === famFilter);
  if (statusFilter !== "all") rows = rows.filter(r => r.status === statusFilter);
  if (q) rows = rows.filter(r => `${r.id} ${r.text} ${r.family} ${r.spec}`.toLowerCase().includes(q));
  $("cov-rulebody").innerHTML = rows.length ? rows.map(r => `<tr><td>${esc(r.text || r.id)}<br><span class="muted small">code in the engine: ${esc(r.id)}</span></td><td>${esc(r.family)}</td><td>${pillOf(r.status)}</td><td>${evidenceText(r)}</td><td>${esc(r.spec)}</td></tr>`).join("")
    : '<tr><td colspan="5" class="empty">no rule matches</td></tr>';
  $("cov-rulenote").textContent = `${rows.length} of ${D.rules.length} rules shown` + (famFilter ? ` · family: ${famFilter} (click it again to clear)` : "") + (statusFilter !== "all" ? ` · evidence: ${statusFilter}` : "") + ".";
}

function renderPlanted() {
  const k = D.kept, pl = k && k.planted;
  if (!pl) { $("cov-planted-intro").textContent = "No kept run of the 485-error trace was found under stage1/runs. Run the command in the last card to make one."; $("cov-plantedbody").innerHTML = ""; return; }
  $("cov-planted-intro").textContent = `The synthetic trace ${k.trace} carries ${num(pl.total)} planted errors with their key packets. The current engine was run on it on ${k.measured_at} (${k.seconds} s, ${k.model_calls} model calls, ${num(k.n_findings)} findings) and scored against the generator's own record.`;
  $("cov-plantedbody").innerHTML = pl.measures.map(m => `<tr><td>${esc(m.measure)}</td><td>${num(m.count)} of ${num(m.out_of)}</td><td><div class="progress" style="min-width:160px"><div style="width:${pct(m.count, m.out_of)}%"></div></div>${pct(m.count, m.out_of)} %</td></tr>`).join("");
  const fpr = Object.entries(pl.false_positive_rules || {});
  $("cov-fp").textContent = `False positives: ${num(pl.false_positive_findings)} findings and ${num(pl.false_positive_incidents)} defects outside any planted error` + (fpr.length ? `, from ${fpr.map(([r, n]) => `${r} (${num(n)})`).join(", ")}` : "") + (fpr.length === 1 && fpr[0][0] === "FC.INSUFFICIENT_CREDITS" ? ". That rule is a known artefact of the generator, which advertises more credits than the 12-bit field allows; it is excluded from the signature library for the same reason." : ".");
  $("cov-visbody").innerHTML = pl.by_visibility.map(v => `<tr><td>${esc(v.visibility)}</td><td>${num(v.planted)}</td><td>${num(v.grouped)}</td><td>${num(v.not_grouped)}</td><td>${num(v.card_first)}</td><td>${num(v.card_top3)}</td></tr>`).join("");
  $("cov-ng-count").textContent = `(${pl.not_grouped.length})`;
  $("cov-ngbody").innerHTML = pl.not_grouped.map(r => `<tr><td>${esc(r.card)}</td><td>${esc(r.title)}</td><td>${esc(r.visibility)}</td><td>${esc(r.symptom)}</td><td>${esc(r.layer)}</td></tr>`).join("");
}

function renderKinds() {
  const t = D.totals, W = D.words;
  const chip = (big, small) => `<div class="chip"><b>${big}</b><span>${esc(small)}</span></div>`;
  $("cov-kindchips").innerHTML = chip(t.kinds_seen, W.seen) + chip(t.kinds_test, W.test) + chip(t.kinds_name_only, W.name_only);
  const byId = Object.fromEntries(D.rules.map(r => [r.id, r]));
  const order = { [W.seen]: 0, [W.test]: 1, [W.name_only]: 2 };
  const rows = D.kinds.slice().sort((a, b) => order[a.evidence] - order[b.evidence] || a.name.localeCompare(b.name));
  $("cov-kindbody").innerHTML = rows.map(k => `<tr><td>${esc(k.name)}<br><span class="muted small">family: ${esc(k.family)}</span></td><td>${esc(k.meaning)}</td><td>${esc(k.how.join("; "))}</td><td>${k.rules.map(id => `${esc((byId[id] || {}).text || id)} <span class="muted small">(${esc(id)})</span>`).join("<br>")}</td><td>${pillOf(k.evidence)}</td></tr>`).join("");
}

function renderSources() {
  $("cov-srcbody").innerHTML = D.sources.map(s => `<tr><td>${esc(s.what)}</td><td>${esc(s.where)}</td><td>${esc(s.how)}</td></tr>`).join("");
  const k = D.kept;
  $("cov-cmd").innerHTML = k && k.command ? `To measure the 485-error trace again with the current engine (no model calls), run from the stage1 folder:<br><code>${esc(k.command)}</code><br>then copy evaluation.json, rule_counts.json and not_grouped.json into a new stage1/runs/eval_485_&lt;date&gt; folder. The truth record was ${esc(k.truth)}.` : "";
}
