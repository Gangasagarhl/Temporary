/* Page 4: timing report for the active run and the generated test suite. */
import { api, $, esc, fmt, toast, defectName, errorTypeFull, errorTypeShort } from "./api.js";
import { S } from "./main.js";
import { statusWord, modeWord, actionWord } from "./decision.js";

const pct = (p) => p == null ? "-" : Math.round(p * 100) + " %";

export function init() { $("btn-report").onclick = build; }
export async function enter() { await loadSuite(); if (S.run) build(); }

async function build() {
  if (!S.run) return toast("select a run first");
  const r = await api("GET", `/api/runs/${S.run}/report`); const s1 = r.stage1, s2 = r.stage2, l = s1.llm;
  let kpiHtml = "";
  try { const k = await api("GET", "/api/kpi"); const e = k.efficiency, q = k.quality, pr = k.productivity;
    kpiHtml = `<h3>Key results — all runs on this installation</h3>
    <div class=chips><div class=chip><b>${e.runs_within_triage_budget} / ${e.runs}</b><span>runs within the first-level triage limit (${Math.round(k.rules.first_level_triage_s / 60)} min)</span></div>
      <div class=chip><b>${q.isolated_with_card} / ${q.incidents}</b><span>defects isolated automatically and matched to a known error type</span></div>
      <div class=chip><b>${q.known_signature_leakage}</b><span>known defects that came back and slipped past their test (must be 0)</span></div>
      <div class=chip><b>${q.signatures_with_admitted_test} / ${q.known_signatures}</b><span>known failure signatures (fingerprints of defects) with a regression test filed</span></div>
      <div class=chip><b>${pr.tests_on_file}</b><span>regression tests generated automatically (${pr.tests_authored_by_hand} written by hand)</span></div>
      <div class=chip><b>${e.llm_calls_saved_by_cache}</b><span>AI reviewer calls saved by reusing earlier verdicts</span></div>
      <div class=chip><b>${e.triage_effort_saving_pct != null ? e.triage_effort_saving_pct + " %" : "n/a"}</b><span>triage effort saved compared with your manual baseline${e.manual_triage_minutes_per_run_baseline ? "" : " (set kpi.manual_triage_minutes_per_run in the config file)"}</span></div></div>
    <p class="help">Rules: optimal = score (how closely a lab run matched the original packets) above ${k.rules.score_threshold} in ${k.rules.optimal_consecutive} lab runs in a row · fail = first-level triage over ${Math.round(k.rules.first_level_triage_s / 60)} min. Minutes of automatic triage measured: ${e.triage_minutes_total_automatic}. Defects seen again in a later capture: ${q.recurrences_seen}; re-run in the lab: ${q.recurrences_tested}; caught again by their test: ${q.recurrences_readmitted}.</p>`; } catch (e) { kpiHtml = `<p class=muted>Key results: ${esc(e.message)}</p>`; }
  $("rep-md").hidden = false; $("rep-md").href = `/api/runs/${S.run}/report?format=md`; $("rep-iso").hidden = false; $("rep-iso").href = `/api/runs/${S.run}/file?path=isolation_report.md`;
  $("rep-body").innerHTML = kpiHtml + `<div class=chips><div class=chip><b>${fmt(s1.seconds_total)} s</b><span>stage 1 (analysis)</span></div><div class=chip><b>${fmt(s2.seconds_total)} s</b><span>stage 2 (reproduction)</span></div><div class=chip><b>${fmt(r.total_seconds)} s</b><span>total</span></div>
    <div class=chip><b>${s1.incidents ?? "-"}</b><span>defects isolated</span></div><div class=chip><b>${l.confirmed ?? "-"}</b><span>confirmed by the AI reviewer</span></div><div class=chip><b>${l.called ?? "-"} / ${l.from_pattern_cache ?? "-"}</b><span>AI reviewer calls / verdicts reused from the cache</span></div><div class=chip><b>${s2.admitted}</b><span>regression tests filed</span></div></div>
    <div class=grid2><div><h3>Stage 1 steps</h3><table><tr><th>Step</th><th>Seconds</th></tr>${s1.steps.map(s => `<tr><td>${esc(s.step)}</td><td class=mono>${fmt(s.seconds, 2)}</td></tr>`).join("")}</table></div>
    <div><h3>AI reviewer</h3><p>Model ${esc(l.model)} (connection: ${esc(l.backend)}): ${l.reviewed} defects reviewed, ${l.called} model calls, ${l.from_pattern_cache} verdicts reused from the cache, ${l.confirmed} confirmed, cost ${fmt(l.cost_usd, 3)} USD.</p>
    <h3>Stage 2 totals</h3><p>${s2.incidents_presented} looked up, ${s2.incidents_executed} decided, ${s2.admitted} regression tests filed, ${s2.optimal} optimal, ${s2.triage_timeouts} over the first-level triage limit · lookup and proposal ${fmt(s2.seconds_present)} s (of which the AI reviewer ${fmt(s2.seconds_llm_in_present)} s), search ${fmt(s2.seconds_search)} s, lab check on known-bad and fixed firmware ${fmt(s2.seconds_verify)} s.</p></div></div>
    <h3>Stage 2 per defect</h3>${s2.incidents.length ? `<p class="help">The "Error type" column shows the catalogue number and its chapter; written out, the first one is ${esc(errorTypeFull(s2.incidents[0].card))}. "Lab" counts the lab runs of the search, then how often the analyser found the defect on the known-bad and on the fixed firmware. "Time" is lookup and proposal, search, and lab check, in seconds.</p>` : ""}
    <div class="tablewrap"><table class="report perdefect"><thead><tr><th>Defect</th><th>Error type</th><th>Knowledge base</th><th>Decision</th><th>What happened</th><th>Lab</th><th>Result</th><th>Time</th></tr></thead><tbody>
    ${s2.incidents.map(i => { const how = modeWord(i.mode), out = statusWord(i.status), cl = i.closed_loop;
      return `<tr><td><b>${esc(defectName(i.incident))}</b></td><td>${esc(errorTypeShort(i.card))}</td>
      <td>seen before: <b>${esc((i.seen || "-").split(" - ")[0])}</b><br>saved procedure: ${i.stored_exists ? "yes" : "no"}<br>AI reviewer proposal: ${i.generated_exists ? "yes" : "no"}</td>
      <td>${i.action ? esc(actionWord(i.action)) : "<span class=muted>not decided yet</span>"}</td><td>${i.action ? esc(how) + (out && out !== how && out !== "-" ? `<br><span class="muted">→ ${esc(out)}</span>` : "") : "<span class=muted>nothing run yet</span>"}</td>
      <td>${i.trials != null ? `${i.trials} run${i.trials === 1 ? "" : "s"}` : "-"}${cl ? `<br>known-bad: found ${cl.known_bad_hits} of ${cl.known_bad_n}<br>fixed: found ${cl.fixed_hits} of ${cl.fixed_n}` : ""}</td>
      <td>${i.admitted ? "✓ test filed" : "no test filed"}<br><span class="muted">${i.optimal ? "optimal" : "not optimal"}</span></td>
      <td class="mono small">lookup ${fmt(i.present_s)} s${i.action ? `<br>search ${fmt(i.search_s)} s<br>lab check ${fmt(i.verify_s)} s` : ""}</td></tr>`; }).join("")}</tbody></table></div>`;
}
async function loadSuite() {
  const s = await api("GET", "/api/suite");
  $("suite").innerHTML = s.length ? `<p class="help">The test name is built from the error type and the procedure's id in the knowledge base; the files are the generated test script and its description.</p><div class="tablewrap"><table class="report"><tr><th>Test name</th><th>Error type</th><th>Defect</th><th>Procedure</th><th>Reproduced in at least</th><th>Lab check when generated (known-bad / fixed firmware)</th><th>Files</th></tr>${s.map(t => `<tr><td>${esc(t.test_id)}</td><td>${esc(errorTypeShort(t.card))}</td><td>${esc(defectName(t.incident))}</td><td class=seq>${esc((t.steps || []).join(" → "))}</td><td>${pct(t.repro_lower95)} of lab runs</td><td>${t.closed_loop ? `${t.closed_loop.known_bad_hits} of ${t.closed_loop.known_bad_n} known-bad, ${t.closed_loop.fixed_hits} of ${t.closed_loop.fixed_n} fixed` : "-"}</td><td>${t.files.map(f => `<a href="/api/suite/${encodeURIComponent(t.test_id)}/${encodeURIComponent(f)}" target=_blank>${esc(f)}</a>`).join(" · ")}</td></tr>`).join("")}</table></div>` : "<span class=muted>no regression tests filed yet</span>";
}
