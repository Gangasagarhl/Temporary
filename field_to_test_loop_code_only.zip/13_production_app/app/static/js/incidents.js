/* Step 3: every defect stage 1 found, with the fixed verdict vocabulary and the AI reviewer's second opinion. */
import { api, $, esc, pill, statusCls, statusPill, defectName, errorTypeShort } from "./api.js";
import { S, show } from "./main.js";

let INC = [], STARTED = false;
const AI_WORD = { CONFIRMED: "agrees", REFUTED: "disagrees", DISPUTED: "disagrees", INCONCLUSIVE: "not sure" };
const aiWord = (v) => AI_WORD[v] || String(v || "").toLowerCase().replace(/_/g, " ");
const WHO = { device: "device side", host: "host side" };
const who = (o) => WHO[o] || (o ? String(o) : "not decided");
const WHERE = { physical: "physical link", data_link: "data link", transaction: "transaction", config: "configuration", nvme: "NVMe command", host: "host", power: "power management", sideband: "sideband (outside the probed link)", statistics: "statistics over the whole trace", capture: "the capture itself", workload: "host workload record" };
const where = (l) => WHERE[l] || (l ? String(l) : "-");
/* stage 2 action and status ids, in the operator's words */
const ACTION_WORD = { accept: "accepted", reject: "rejected", revise: "corrected", rerank: "reordered", add_cause: "cause added", add_procedure: "procedure added", promote: "promoted", delete_request: "deletion requested", delete_approve: "deletion approved", duplicate_of: "marked as duplicate", escalate: "escalated", link: "linked", not_reproducible: "marked not reproducible", split: "split", wrong_signature: "wrong signature" };
const STATUS_WORD = { done: "lab run done", confirmed: "reproduced", reused_validated: "saved procedure reproduced", failed: "failed", not_reproduced: "not reproduced", triage_timeout: "10-minute triage limit reached", admin_procedure_failed: "your procedure did not reproduce it", awaiting_hardware_bench: "waiting for the lab device", rejected: "rejected", swept: "sweep done", running: "running", cancelled: "cancelled", admitted: "regression test admitted", no_valid_variants: "no valid variation found", no_sources: "no procedure to start from", no_base: "no base procedure", not_applicable_workload: "not applicable (host workload record)", no_search: "no search run" };
const actionWord = (a) => ACTION_WORD[a] || String(a || "").replace(/_/g, " ");
const statusWord = (s) => STATUS_WORD[s] || String(s || "").replace(/_/g, " ");

export function init() { $("inc-filter").oninput = render; $("btn-review").onclick = () => show("review"); }
export async function enter() {
  if (!S.run) { $("inc-table").querySelector("tbody").innerHTML = "<tr><td colspan=8 class=empty>Choose a trace and let stage 1 complete first.</td></tr>"; return; }
  const q = await api("GET", `/api/runs/${S.run}/stage2/queue`);
  INC = await api("GET", `/api/runs/${S.run}/incidents`); STARTED = q.started;
  const c = q.counts, words = {};
  for (const i of INC) words[i.status_word] = (words[i.status_word] || 0) + 1;
  const chips = [["defects found", INC.length], ["Confirmed", words["Confirmed"] || 0], ["Suspect", words["Suspect"] || 0], ["Needs evidence", words["Needs evidence"] || 0]];
  if (STARTED) chips.push(["decided", c.decided], ["regression tests admitted", c.admitted]);
  $("inc-chips").innerHTML = chips.map(([a, b]) => `<div class=chip><b>${b}</b><span>${esc(a)}</span></div>`).join("");
  $("btn-review").textContent = STARTED ? "Open stage 2 (reproduce and decide) →" : "Continue to stage 2 →";
  $("inc-note").textContent = STARTED ? "Click a row to open it in stage 2 (reproduce and decide)." : "Stage 1 is complete. Stage 2 (knowledge base lookup, AI reviewer proposal, your decisions, reproduction on the device, regression tests) has not been started for this run.";
  document.querySelectorAll("#inc-table .s2col").forEach(e => e.hidden = !STARTED);
  render();
}
function render() {
  const f = $("inc-filter").value.toLowerCase(); const tb = $("inc-table").querySelector("tbody"); tb.innerHTML = "";
  for (const i of INC) {
    const txt = [defectName(i.id), i.card, errorTypeShort(i.card), i.title, i.first_rule, i.status_word, i.status, where(i.layer), who(i.origin), aiWord((i.llm || {}).verdict)].join(" ").toLowerCase();
    if (f && !txt.includes(f)) continue;
    const l = i.llm || {}, s2 = i.stage2 || {};
    const tr = document.createElement("tr"); tr.className = STARTED ? "click" : "";
    tr.innerHTML = `<td class=mono>${esc(defectName(i.id))}</td><td><b>${esc(errorTypeShort(i.card))}</b><br><span class="muted small">${esc((i.title || "").slice(0, 80))}</span></td>
      <td>${statusPill(i.status_word)}</td><td>${esc(where(i.layer))}</td><td>${esc(who(i.origin))}</td>
      <td class="muted small"><span class=mono>${esc(i.start_pkt ?? "-")}-${esc(i.end_pkt ?? "-")}</span><br>rule that fired: ${esc(i.first_rule || "-")}</td>
      <td>${l.verdict ? `${pill("AI reviewer " + aiWord(l.verdict), statusCls(l.verdict))} ${l.cached ? pill("verdict reused from the cache", "info") : pill("fresh model call")}` : "<span class=muted>AI reviewer not run</span>"}</td>
      <td class=s2col ${STARTED ? "" : "hidden"}>${s2.decided ? pill(actionWord(s2.action) + " → " + statusWord(s2.status), statusCls(s2.status)) + (s2.admitted ? " " + pill("regression test", "ok", "✓") : "") : s2.presented ? pill("looked up" + (s2.stored ? " · saved procedure found" : " · no saved procedure"), "info") : "<span class=muted>not yet decided</span>"}</td>`;
    if (STARTED) tr.onclick = () => show("review", i.id);
    tb.appendChild(tr);
  }
  if (!tb.children.length) tb.innerHTML = `<tr><td colspan=8 class=empty>${INC.length ? "No defect matches the filter." : "No defects were found in this trace."}</td></tr>`;
}
