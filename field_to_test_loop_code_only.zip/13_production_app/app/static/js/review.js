/* Step 4: stage 2. A gate until the admin starts it; then the review queue. For each defect: the stored procedure
   next to the LLM's proposal with differences highlighted, a callout when an earlier decision on this error was
   negative, the candidates, a decision bar with nothing pre-selected, a reason panel for negative decisions, a
   "what happens next" receipt with undo, the history, and an editor (original read-only, your version editable). */
import { api, $, esc, fmt, toast, pill, statusCls, statusPill, seq, diffCount, kv, poll, defectName, errorType, errorTypeFull, errorTypeShort, familyName, when, plainIds } from "./api.js";
import { S, refreshRuns, applyLocks } from "./main.js";
import * as decision from "./decision.js";

const R = { queue: [], cur: null, view: null, ranking: [], started: false, pending: null };
const ED = { steps: [], orig: null };
const RECEIPT = { accept: "What happens next: the accepted procedure is re-run first as a safety check. If it still reproduces the defect, it is reused and a regression test is filed; otherwise the search for a reproducing procedure starts from it.",
  accept_with_note: "What happens next: the same as Accept; your note is saved with the procedure.", add_cause: "What happens next: the new cause is recorded, a procedure that reproduces it is searched for, then checked in the lab on known-bad and fixed firmware.",
  add_procedure: "What happens next: your procedure is run first in the lab; if it reproduces the defect it is kept as validated in the lab (under your name) and checked on known-bad and fixed firmware. Approving it as the saved procedure is a separate decision by a second admin.",
  reject: "Recorded as a negative decision with your reason: only this candidate loses credit. Nothing else changes.", not_reproducible: "Recorded as 'could not be reproduced': this counts against the procedure's lab record only; whether the cause is right is left untouched.",
  revise: "The text was revised; the counts are kept, the weight of its evidence is reduced. No search was started.", rerank: "Your order is recorded as a rating only (never as a success).", prefer: "Your preference is recorded as a rating.",
  promote: "The procedure is now approved by a second admin; the approver's name is kept in the record.", deprecate: "The procedure is retired; it stays in the history.", skip: "Logged only. No counts or ratings changed.", defer: "Logged only; the defect stays in the queue.",
  restart_failed: "Failed attempt recorded (−1): it counts against the procedure's lab record, a lesson is kept, and the search restarts with a different random seed.",
  sweep: "What happens next: nearby variations of the reproducing procedure are tried to find other failure-prone conditions; the failure-prone ones are filed as regression tests, most stressful first. Nothing is approved automatically.",
  compose_tests: "What happens next: the AI reviewer composes up to three test variants from the saved procedures; each is run in the lab and filed only if the analyser finds the same defect. Nothing is approved automatically.",
  escalate: "A lesson 'needs more evidence' was recorded.", wrong_signature: "A dispute of the stage-1 finding was recorded; the causes are untouched." };
/* the "Other decisions" form: actions grouped by what they do, and what each one needs before it can be recorded */
const GROUPS = [["Judge the ticked procedure", ["accept", "accept_with_note", "revise", "reject", "not_reproducible"]],
  ["Order or compare procedures", ["rerank", "prefer", "tie"]],
  ["Tidy the knowledge base", ["promote", "deprecate", "duplicate_of", "link", "split", "delete_request", "delete_approve"]],
  ["Add what you know", ["lesson", "add_cause", "add_procedure", "escalate", "wrong_signature"]],
  ["Run more in the lab", ["compose_tests", "sweep", "restart_failed"]],
  ["Put it aside", ["skip", "defer", "undo"]]];
const NEED = { one: ["accept", "accept_with_note", "revise", "reject", "not_reproducible", "promote", "deprecate", "delete_request", "delete_approve", "split", "link", "restart_failed"],
  two: ["prefer", "tie", "duplicate_of"], ranking: ["rerank"], reason: ["reject", "not_reproducible", "wrong_signature"],
  approver: ["promote", "deprecate", "delete_approve"], event: ["undo"], content: ["revise", "add_cause", "split"],
  minutes: ["accept", "accept_with_note", "add_cause", "add_procedure", "compose_tests", "sweep", "restart_failed"] };
const TAGS = [["one", "needs one ticked record"], ["two", "needs two ticked records"], ["ranking", "needs an order (click the candidates)"], ["reason", "asks for a reason"], ["approver", "needs a second admin"], ["event", "asks which decision"], ["minutes", "runs in the lab, takes minutes"]];
const tagsOf = (a) => TAGS.filter(([k]) => NEED[k].includes(a)).map(([, t]) => t);
/* a candidate in plain words: from the summary fields when the lookup provides them, else from an older label */
const CAND_STATUS = { "admin-approved": "approved by a second admin", "validated-by-execution": "awaiting approval by a second admin", superseded: "replaced by a newer version", deprecated: "retired", proposal: "proposal, not run yet" };
function candText(a) {
  const sm = a.summary;
  if (sm && sm.kind === "procedure") {
    const t = sm.timing || {}, bits = [`queue depth ${t.qd ?? "?"}`, `${t.inter_cmd_us ?? "?"} µs between commands`];
    if (t.idle_gap_ms) bits.push(`idle ${t.idle_gap_ms} ms`); if (sm.power_state && sm.power_state !== "none") bits.push(`power state ${sm.power_state}`);
    const st = [CAND_STATUS[sm.status] || statusWord(sm.status)]; if (sm.repro_lower95 != null) st.push(`reproduced in at least ${pct(sm.repro_lower95)} of lab runs`);
    return { title: `Saved procedure: ${(sm.commands || []).join(", ") || "no commands"}`, sub: bits.join(" · "), status: st.join(" · ") };
  }
  if (sm && sm.kind === "cause") return { title: "Possible cause: " + sm.text, sub: "", status: "" };
  if (sm && sm.kind === "note") return { title: "Note: " + sm.text, sub: "", status: "" };
  const m = /^procedure [0-9a-f]+ for \S+: (.+?) @ qd(\d+) (\d+)us \((.+?), repro>=([\d.]+)\)$/.exec(a.label || "");   // label format of lookups made before 2026-10-27
  if (m) return { title: `Saved procedure: ${m[1].split(">").join(", ")}`, sub: `queue depth ${m[2]} · ${m[3]} µs between commands`, status: `${CAND_STATUS[m[4]] || m[4]} · reproduced in at least ${Math.round(+m[5] * 100)} % of lab runs` };
  return { title: a.label || a.doc_id, sub: "", status: "" };
}
const plainWhy = (w) => (w || []).filter(x => !/BM25|structured match|lexical|idf/i.test(x));
const list = (xs) => (xs || []).length ? `<ul class="plain">${xs.map(x => `<li>${esc(x)}</li>`).join("")}</ul>` : "-";
/* plain names for the editor's timing fields (the keys stay the API's) */
const TIMING_NAME = { qd: "queue depth", inter_cmd_us: "µs between commands", bs_kb: "block size KB", burst_len: "burst length", idle_gap_ms: "idle gap ms" };
const pct = (p) => p == null ? "-" : Math.round(p * 100) + " %";
const { statusWord, modeWord, actionWord, procStatus, procId, likelihood } = decision;

function edRender() { $("ed-steps").innerHTML = ED.steps.map((op, i) => `<span class="ed-step" data-i="${i}" title="remove this step">${i + 1}. ${esc(op)} ✕</span>`).join("") || "<span class='muted small'>no steps</span>"; document.querySelectorAll("#ed-steps .ed-step").forEach(e => e.onclick = () => { ED.steps.splice(+e.dataset.i, 1); edRender(); }); edPreview(); }
function edLoad(sc, label) { if (!sc) return; ED.orig = sc; ED.steps = (sc.commands || sc.procedure || []).map(c => c.op || c); const t = sc.timing || {}; $("ed-qd").value = t.qd ?? 8; $("ed-us").value = t.inter_cmd_us ?? 50; $("ed-bs").value = t.bs_kb ?? 4; $("ed-burst").value = t.burst_len ?? 16; $("ed-idle").value = t.idle_gap_ms ?? 0; $("ed-power").value = sc.power_state || "none"; $("ed-orig").innerHTML = `<span class="muted small">${esc(label || "")}</span>${seq(sc)}`; edRender(); }
function edScenario() { return { commands: ED.steps.map(op => ({ op })), timing: { qd: +$("ed-qd").value, inter_cmd_us: +$("ed-us").value, bs_kb: +$("ed-bs").value, burst_len: +$("ed-burst").value, idle_gap_ms: +$("ed-idle").value }, power_state: $("ed-power").value }; }
function edValid() { const t = edScenario().timing; const lim = { qd: [1, 256], inter_cmd_us: [1, 5000], bs_kb: [4, 1024], burst_len: [1, 128], idle_gap_ms: [0, 2000] }; const bad = Object.entries(lim).filter(([k, [lo, hi]]) => !(t[k] >= lo && t[k] <= hi)).map(([k, [lo, hi]]) => `${TIMING_NAME[k] || k} must be ${lo}-${hi}`); if (!ED.steps.length) bad.push("add at least one step"); return bad; }
function edPreview() { const bad = edValid(); const sc = edScenario(); $("ed-preview").innerHTML = `<b>Preview as it will be saved:</b> ${seq(sc, ED.orig)} ${diffCount(sc, ED.orig) != null ? `<span class=muted>${diffCount(sc, ED.orig)} change(s) compared with the original</span>` : ""}${bad.length ? `<div class="bad">${esc(bad.join("; "))}</div>` : ""}`; $("ed-submit").disabled = bad.length > 0; }

const KIND_RE = /(TLP Type|DLLP Type|Ord\.Set Type|Link Event)=([^|]+)/;
function observedSequence(d) {
  const inc = d.incident, kinds = {};
  for (const b of d.rows) for (const r of b.rows) { const m = r.match(/^Packet=(\d+)/), k = r.match(KIND_RE); if (m && k) kinds[m[1]] = k[2].trim(); }
  const pk = (inc.evidence_packets && inc.evidence_packets.length ? inc.evidence_packets : Object.keys(kinds).slice(0, 8)).slice(0, 10);
  const packets = pk.map(p => `<span class=mono>#${p}</span> ${esc(kinds[p] || "")}`).join(" → ") || "<span class=muted>-</span>";
  const cmds = (inc.nvme_commands || []).map(c => Object.entries(c).filter(([k]) => ["opcode", "name", "cid", "sqid", "slba", "nlb", "opc"].includes(k)).map(([k, v]) => `${k}=${esc(String(v))}`).join(" ")).join("<br>");
  return `<div class=small><b>Packets</b><br>${packets}</div><div class="small" style="margin-top:6px"><b>NVMe commands</b><br>${cmds || esc(inc.task || "no NVMe command in the window")}</div>
    <div class="help">First abnormal packet <span class=mono>#${esc((inc.first_abnormal || {}).pkt)}</span>: ${esc((inc.first_abnormal || {}).detail)}</div>`;
}

export function init() {
  $("btn-start-stage2").onclick = startStage2;

  $("btn-present").onclick = () => present(true); $("btn-represent").onclick = () => present(true);
  $("btn-prev").onclick = () => step(-1); $("btn-next").onclick = () => step(1);
  $("a-rank-clear").onclick = () => { R.ranking = []; $("a-ranking").value = ""; document.querySelectorAll("#r-cands li").forEach(l => l.classList.remove("picked")); };
  $("ed-add").onclick = () => { ED.steps.push($("ed-op").value); edRender(); };
  ["ed-qd", "ed-us", "ed-bs", "ed-burst", "ed-idle", "ed-power"].forEach(id => $(id).oninput = edPreview);
  $("ed-from-stored").onclick = () => { if (R.view && R.view.stored) edLoad(R.view.stored, "saved procedure"); else toast("nothing saved for this defect yet"); };
  $("ed-from-llm").onclick = () => { if (R.view && R.view.generated) edLoad(R.view.generated, "AI reviewer's proposal"); else toast("no proposal from the AI reviewer available"); };
  $("ed-submit").onclick = () => { if (edValid().length) return; $("ed-msg").textContent = "proposing your procedure and validating it in the lab…"; doAction("add_procedure", edScenario()); };
  $("a-go").onclick = confirmAction; $("a-cancel").onclick = hideStep3;
  $("a-reason").addEventListener("keydown", e => { if (e.key === "Enter") confirmAction(); });
  document.querySelectorAll("#page-review .tabs button").forEach(b => b.onclick = () => sub(b.dataset.sub));
  document.addEventListener("keydown", (e) => {
    if (!R.started || !document.getElementById("page-review").classList.contains("active") || ["INPUT", "TEXTAREA", "SELECT"].includes(e.target.tagName)) return;
    if (e.key === "j") step(1); else if (e.key === "k") step(-1); else if (e.key === "a" && R.view) startAction("accept"); else if (e.key === "r" && R.view) startAction("reject");
  });
}
function sub(name) { document.querySelectorAll("#page-review .tabs button").forEach(b => b.classList.toggle("active", b.dataset.sub === name)); document.querySelectorAll("#page-review .sub").forEach(s => s.classList.toggle("active", s.id === "sub-" + name)); }

export async function enter(incId) {
  if (!S.run) { $("r-gate").hidden = true; $("r-work").hidden = true; return; }
  const q = await api("GET", `/api/runs/${S.run}/stage2/queue`);
  R.queue = q.incidents; R.started = q.started;
  if (!q.started) {
    $("r-work").hidden = true; $("r-gate").hidden = false; $("r-gate-progress").hidden = true; $("r-gate-msg").textContent = "";
    $("r-gate-text").textContent = `Stage 1 isolated ${q.counts.total} defects in this capture (${q.counts.llm_confirmed} confirmed by the AI reviewer). Nothing has been looked up in the knowledge base or proposed yet.`;
    return;
  }
  $("r-gate").hidden = true; $("r-work").hidden = false;
  const c = q.counts; $("q-count").textContent = `${c.decided} of ${c.total} decided · ${c.admitted} regression tests filed`; $("q-progress").style.width = (c.total ? 100 * c.decided / c.total : 0) + "%";
  renderQueue();
  open(incId || R.cur || q.next || (R.queue[0] || {}).id);
}
async function startStage2() {
  $("btn-start-stage2").disabled = true; $("r-gate-msg").textContent = "starting stage 2: looking up every defect in the knowledge base and asking the AI reviewer for a proposal…";
  try {
    const r = await api("POST", `/api/runs/${S.run}/stage2/start`);
    await refreshRuns(); applyLocks();
    if (!r.job) { $("r-gate-msg").textContent = "every defect was already prepared earlier (reused)"; return enter(); }
    $("r-gate-progress").hidden = false;
    poll(r.job, j => { $("r-gate-progress").firstElementChild.style.width = (j.progress.pct || 2) + "%"; $("r-gate-msg").textContent = `preparing: ${plainIds(j.progress.detail)} · ${fmt(j.elapsed_s)} s`; },
      async j => { $("r-gate-msg").textContent = j.status === "done" ? `prepared ${j.result.prepared.length} defects` : "failed: " + (j.error || "").slice(0, 200); $("btn-start-stage2").disabled = false; await refreshRuns(); applyLocks(); enter(); }, 1500);
  } catch (e) { $("r-gate-msg").textContent = "error: " + e.message; $("btn-start-stage2").disabled = false; }
}
function showRunMeta(rm) {
  rm = rm || {}; const dv = rm.device || {};
  $("r-meta").innerHTML = `Trace <b>${esc(rm.trace || "")}</b> analysed ${rm.started ? when(rm.started) : ""} by <b>${esc(rm.operator || "name not recorded")}</b> · device <b>${esc(dv.name || "unknown device")}</b> <span class="muted">(${esc(dv.source || "")})</span>${dv.serial_number ? ` · serial ${esc(dv.serial_number)}` : ""}${dv.firmware_revision ? ` · firmware revision ${esc(dv.firmware_revision)} (from the trace)` : ""} · firmware label ${esc(rm.firmware || "")}. Your decisions are recorded with your name, the date and this device.`;
  const req = $("a-requester"); let saved = ""; try { saved = localStorage.getItem("operator") || ""; } catch (e) { /* storage may be unavailable */ }
  if (!req.value.trim()) req.value = rm.operator || saved;
}
function renderQueue() {
  const el = $("q-list"); el.innerHTML = "";
  for (const i of R.queue) {
    const s2 = i.stage2, d = document.createElement("div"); d.className = "item" + (i.id === R.cur ? " sel" : ""); d.dataset.id = i.id;
    const st = s2.decided ? pill(s2.admitted ? "test filed ✓" : statusWord(s2.status), statusCls(s2.status)) : s2.presented ? pill(s2.stored ? "saved procedure" : "new", s2.stored ? "ok" : "info") : pill("not looked up yet");
    d.innerHTML = `<div><b>${esc(defectName(i.id))}</b> <span class="muted small">${esc(errorTypeShort(i.card))}</span><span class=t>${esc((i.title || "").slice(0, 44))}</span></div>${st}`;
    d.onclick = () => open(i.id); el.appendChild(d);
  }
}
function step(d) { const idx = R.queue.findIndex(i => i.id === R.cur); const n = R.queue[idx + d]; if (n) open(n.id); }

async function open(id) {
  if (!id) return;
  R.cur = id; R.view = null; R.ranking = []; hideStep3(); renderQueue(); sub("decision");
  const pos = R.queue.findIndex(i => i.id === id); $("r-pos").textContent = `${pos + 1} of ${R.queue.length}`;
  const d = await api("GET", `/api/runs/${S.run}/incidents/${id}`);
  const inc = d.incident, iso = d.isolation || {}, c = (inc.atlas_candidates || [])[0] || {}, rv = d.llm_review || {};
  $("r-title").innerHTML = `${esc(defectName(id))} · <b>${esc(errorTypeFull(c.card_id, (c.title || "").slice(0, 90)))}</b>`;
  const rvVerdict = rv.verdict ? (rv.verdict === "CONFIRMED" ? "agrees" : rv.verdict === "NOT_CONFIRMED" ? "disagrees" : "not sure") : null;
  $("r-stage1").innerHTML = kv([["Error type", `<b>${esc(errorTypeFull(c.card_id, c.title))}</b>`],
    ["Error family / layer / who caused it", `${esc(familyName((inc.explanation || {}).pattern))} / ${esc(inc.layer)} / ${esc((inc.attribution || {}).origin)}`],
    ["Where in the trace", `packets ${inc.start_pkt}-${inc.end_pkt}; first abnormal packet #${esc((inc.first_abnormal || {}).pkt)} (rule ${esc((inc.first_abnormal || {}).rule)}): ${esc((inc.first_abnormal || {}).detail)}`],
    ["Why it was flagged", `verdict ${esc(inc.verdict)} · rules that fired: ${esc(Object.keys(inc.rules || {}).join(", "))} · isolation ${esc(statusWord(iso.status))}`],
    ["Mechanism", esc(((iso.why || {}).mechanism || (inc.explanation || {}).why || "").slice(0, 700))],
    ["AI reviewer's second opinion", rv.verdict ? `${pill(rvVerdict, statusCls(rv.verdict))} with the stage-1 verdict · ${esc(errorTypeShort(rv.card_id))} · responsible: ${esc(rv.responsible)} · ${rv.backend === "pattern-cache" ? pill("verdict reused from the cache", "info") : pill("fresh model call", "")}<br>${esc((rv.summary || "").slice(0, 700))}` : "<span class=muted>not reviewed by the AI reviewer</span>"],
    ["Failure signature (the fingerprint of the defect)", d.signature && !d.signature.error ? `${esc(errorTypeShort(d.signature.card))} / rule ${esc(d.signature.rule || "-")} · layer ${esc(d.signature.layer)} · timing class ${esc(d.signature.latency_class)} · preceding packets ${esc((d.signature.preceding_packets || []).slice(0, 8).join(", "))}${Object.keys(d.signature.link_events || {}).length ? " · link events " + esc(JSON.stringify(d.signature.link_events)) : ""}` : "-"],
    ["Suggested fix", esc(((iso.fix || {}).corrective_action || "").slice(0, 300))], ["", `<a href="/defect?run=${encodeURIComponent(S.run)}&inc=${encodeURIComponent(id)}" target="_blank">Open the full record ↗</a>`]]);
  const rows = []; for (const b of d.rows) { rows.push(`Trace rows ${b.range[0]} to ${b.range[1]}`); for (const x of b.rows.slice(0, 40)) rows.push(x); }
  $("r-rows").textContent = rows.join("\n");
  $("r-card").hidden = true; $("r-seen").textContent = ""; $("r-seen").className = "pill"; $("r-present-time").textContent = "";
  const st = d.stage2 || {};
  R.detail = d; $("r-decision").hidden = true; $("r-decision").innerHTML = ""; $("r-busy").hidden = true; $("r-advanced").hidden = true;
  if (st.view) renderView(Object.assign({ cached: true }, st.view)); else present(false);
  renderResult(st.last);
}
async function present(force) {
  $("btn-present").disabled = true; $("r-present-time").textContent = "looking up the knowledge base and asking the AI reviewer…";
  try { const v = await api("POST", `/api/runs/${S.run}/incidents/${R.cur}/present${force ? "?force=1" : ""}`); renderView(v); }
  catch (e) { toast("lookup failed: " + e.message); $("r-present-time").textContent = ""; }
  finally { $("btn-present").disabled = false; }
}
async function loadHistory(sig) {
  try {
    const h = (await api("GET", `/api/db/feedback/${encodeURIComponent(sig)}`)).history;
    const pos = h.filter(x => x.polarity === "positive").length, neg = h.filter(x => x.polarity === "negative").length;
    const lastNeg = h.find(x => x.polarity === "negative");
    $("r-callout").hidden = !lastNeg;
    if (lastNeg) $("r-callout").innerHTML = `<b>Earlier negative decision on this error type:</b> ${esc(actionWord(lastNeg.action))} by ${esc(lastNeg.actor)} on ${new Date(lastNeg.when * 1000).toLocaleString()}${lastNeg.note ? ` - "${esc(lastNeg.note)}"` : ""}. The saved procedure below may be the one that was rejected; you can edit it.`;
    $("r-history").innerHTML = h.length ? `<div class="chips"><div class=chip><b>${h.length}</b><span>decisions</span></div><div class=chip><b>${pos}</b><span>positive</span></div><div class=chip><b>${neg}</b><span>negative</span></div></div>
      <table><thead><tr><th>When <span class="muted small">(# = event number, for Undo)</span></th><th>Who</th><th>Decision</th><th>Reason or note</th><th>Lab outcome</th></tr></thead><tbody>${h.map(x => `<tr><td>${new Date(x.when * 1000).toLocaleString()} <span class="muted small">#${x.event_id}</span></td><td>${esc(x.actor)}</td><td>${pill(actionWord(x.action), x.polarity === "positive" ? "ok" : x.polarity === "negative" ? "bad" : "", x.polarity === "positive" ? "+" : x.polarity === "negative" ? "−" : "")}</td><td>${esc(x.note || "")}</td><td>${x.outcome ? (x.outcome.admitted ? pill("regression test filed", "ok", "✓") : pill("no test filed", "warn")) + ` found on known-bad firmware ${esc(x.outcome.known_bad)} · on fixed firmware ${esc(x.outcome.fixed)}` : "-"}</td></tr>`).join("")}</tbody></table>` : "no decision recorded for this error type yet";
  } catch (e) { $("r-history").textContent = "-"; $("r-callout").hidden = true; }
}
async function renderDecision() {
  if (!R.detail || !R.view) return;
  const el = $("r-decision"); el.hidden = false; $("r-advanced").hidden = false;
  let sols; try { sols = await api("GET", `/api/runs/${S.run}/incidents/${R.cur}/solutions`); } catch (e) { el.innerHTML = `<p class=empty>${esc(e.message)}</p>`; return; }
  showRunMeta(sols.run_meta);
  const targetOf = (sol) => sol.id.startsWith("sol::") ? sol.id : sols.cause_target;
  decision.render(el, { detail: R.detail, sols, key: `${S.run}/${R.cur}`,
    engineer: () => { $("r-advanced").open = true; $("r-advanced").scrollIntoView({ behavior: "smooth" }); },
    refresh: () => enter(R.cur),
    act: async (kind, sol, x) => {
      const q = { quiet: !!x.quiet };
      if (kind === "rerank") { const ids = x.order.filter(i => i.startsWith("sol::")); if (ids.length < 2) return; R.ranking = ids; return doAction("rerank", null, null, null, ids, q); }
      if (kind === "promote") { $("a-approver").value = x.approver || ""; return doAction("promote", null, null, null, [sol.id]); }
      if (kind === "sweep") { $("r-busy").hidden = false; $("r-busy").textContent = "trying nearby variations of the reproducing procedure (timing, power states, bursts, injected link faults where the bench supports them) to find other failure-prone conditions; the failure-prone ones are filed as regression tests…";
        return doAction("sweep", null, null, null, []); }
      if (kind === "restart") { const t = (sol && sol.id.startsWith("sol::")) ? sol.id : sols.cause_target; $("r-busy").hidden = false; $("r-busy").textContent = "failed attempt recorded (−1); the search restarts with a different random seed…";
        return doAction("restart_failed", null, (x && x.note) || "no reproduction within the limits", null, t ? [t] : []); }
      if (kind === "compose") { $("r-busy").hidden = false; $("r-busy").textContent = "the AI reviewer is composing test variants from the saved procedures; each is run in the lab and the ones that reproduce the defect are filed…";
        return doAction("compose_tests", null, null, null, []); }
      const target = targetOf(sol);
      if (kind === "accept") { $("r-busy").hidden = false; $("r-busy").textContent = "accepted: running it in the lab, checking it on known-bad and fixed firmware, writing the regression test…";
        return target ? doAction("accept", null, null, null, [target]) : doAction("add_cause", null, null, { text: sols.llm_headline || "cause from stage-1 evidence" }, []); }
      if (kind === "procedure") { $("r-busy").hidden = false; $("r-busy").textContent = "validating your version: it is run first in the lab, checked on known-bad and fixed firmware, then saved…";
        return doAction("add_procedure", x.scenario, null, null, target && target.startsWith("cause::") ? [target] : []); }
      if (kind === "reject") {
        if (!sol.id.startsWith("sol::")) return doAction("lesson", null, `NOT CORRECT: the AI reviewer's new proposal (${decision.titleOf(sol)}) — ${x.note || "no reason given"}`, null, sols.cause_target ? [sols.cause_target] : [], q);
        await doAction("reject", null, x.note || "not correct", null, [sol.id], q);
        if (x.retire && sol.id.startsWith("sol::")) {
          const who = prompt("Retiring a procedure needs a second admin. Name of the second admin (must differ from you):", "");
          if (who && who.trim()) { $("a-approver").value = who.trim(); await doAction("deprecate", null, x.note || "retired by admin", null, [sol.id], q); }
          else toast("not retired: no second admin was named (the rejection is recorded)", 7000);
        } }
    } });
  decision.renderResult(el, (R.detail.stage2 || {}).last);
}
function renderView(v) {
  R.view = v; R.ranking = []; $("a-ranking").value = ""; $("r-card").hidden = false;
  if (R.detail) renderDecision();
  $("r-seen").textContent = v.seen_label || v.seen; $("r-seen").className = "pill " + (v.seen === "match" ? "ok" : v.seen === "ambiguous" ? "warn" : "info");
  $("r-present-time").textContent = v.cached ? "shown from the earlier lookup (already processed)" : `knowledge-base lookup and proposal took ${fmt(v.timings.present_s)} s, of which the AI reviewer ${fmt(v.timings.llm_s)} s`;
  const st = v.stored, l = v.llm, gen = l ? l.recommended_sequence : null;
  $("r-stored-prov").textContent = st ? `${procStatus(st.status, st.approved_by)} · reproduced in at least ${pct(st.repro_lower95)} of lab runs (${likelihood(st.repro_lower95)}) · admin feedback rating ${fmt(st.edge_posterior, 2)} from ${st.edge_n} decisions (1 = always judged correct)` : "";
  $("r-stored").innerHTML = st ? `${seq(st, gen)}${kv([["Regression tests", `${(st.tests || []).length} filed`], ["Changed since it was saved", esc((st.what_changed_vs_stored || []).join("; ") || "nothing")]])}<details><summary>preview of the regression test</summary><pre>${esc(st.test_preview)}</pre></details>`
    : `<p class=empty>Nothing saved for this error type yet. The proposal on the right is the only one; accepting a cause starts the search from it.</p>`;
  $("r-gen-prov").textContent = l ? `AI reviewer model ${l.model}${l.cached ? " · reused from the earlier lookup" : " · fresh model call"}` : "";
  $("r-generated").innerHTML = l ? `<p><b>${esc(l.headline)}</b></p><p>${esc(l.mechanism)}</p>${seq(gen, st)}${kv([["Assessment", `${esc(l.seen_before_assessment)} ${l.agrees_with_matcher ? "(agrees with the knowledge-base lookup)" : "(differs from the knowledge-base lookup)"}`],
    ["Key packets", (l.key_packets || []).map(p => "#" + esc(p)).join(", ") || "-"], ["Differences from the saved procedure", list(l.differences_vs_stored)], ["Risks", list(l.risks)]])}
    ${v.llm_problems && v.llm_problems.length ? `<p class="bad small">problems in the proposal found by the analyser's checks: ${esc(v.llm_problems.join("; "))}</p>` : ""}` : `<p class=empty>No AI reviewer configured (stand-in mode): the search starts from the error family's template procedure.</p>`;
  const n = diffCount(st, gen);
  $("r-diff").innerHTML = st && gen ? (n ? `<span class="diff">${n}</span> difference(s) between the saved procedure and the proposal are highlighted.` : "The proposal matches the saved procedure exactly.") : "";
  const ol = $("r-cands"); ol.innerHTML = ""; const tg = $("a-targets"); tg.innerHTML = "";
  const addTarget = (id, c, extra) => { const lab = document.createElement("label"); lab.className = "target"; lab.innerHTML = `<input type="checkbox" value="${esc(id)}"><span><b>${esc(c.title)}</b>${c.sub ? `<span class="muted"> · ${esc(c.sub)}</span>` : ""}${c.status ? `<span class="small muted"> · ${esc(c.status)}</span>` : ""}${extra || ""}</span>`; lab.querySelector("input").onchange = refreshStep3; tg.appendChild(lab); };
  if (st && !v.card.alternatives.some(a => a.doc_id === st.doc_id)) addTarget(st.doc_id, { title: "The saved procedure shown above", sub: "", status: procStatus(st.status, st.approved_by) }, "");
  for (const a of v.card.alternatives) {
    const c = candText(a), why = plainWhy(a.why);
    const li = document.createElement("li"); li.innerHTML = `<div class="ctitle">${esc(c.title)}${c.sub ? ` <span class="muted">· ${esc(c.sub)}</span>` : ""}</div>
      <div class="why">${c.status ? esc(c.status) + " · " : ""}lookup match ${Math.round(a.score * 100)} % <span class="muted">(100 % = identical to the stored record)</span>${a.n ? ` · admins judged it ${a.n} time${a.n === 1 ? "" : "s"}` : ""}${a.explore ? " · shown to give a less-tried procedure a chance" : ""}${why.length ? `<br>why it matched: ${esc(why.join(", "))}` : ""}</div>`;
    li.onclick = () => { if (!R.ranking.includes(a.doc_id)) R.ranking.push(a.doc_id); li.classList.add("picked"); $("a-ranking").value = R.ranking.map((x, i) => `${i + 1}. ${candText(v.card.alternatives.find(b => b.doc_id === x) || { label: x }).title}`).join("  →  "); refreshStep3(); };
    ol.appendChild(li); addTarget(a.doc_id, c, "");
  }
  if (!tg.children.length) tg.innerHTML = `<p class="empty">No record to tick: nothing is saved for this error type yet.</p>`;
  loadHistory(v.card.card); edLoad(st || gen || { commands: [], timing: {} }, st ? "saved procedure" : "AI reviewer's proposal");
  const box = $("r-actions"); box.innerHTML = ""; const offered = new Set(v.actions);
  for (const [title, names] of GROUPS) {
    const acts = names.filter(a => offered.has(a)); if (!acts.length) continue;
    const g = document.createElement("div"); g.className = "agroup"; g.innerHTML = `<div class="gtitle">${esc(title)}</div>`;
    for (const a of acts) {
      const b = document.createElement("button"); b.className = "atile" + (["accept", "accept_with_note", "add_cause"].includes(a) ? " go" : ["promote", "deprecate", "delete_approve"].includes(a) ? " two" : ["reject", "not_reproducible", "wrong_signature"].includes(a) ? " neg" : "");
      b.dataset.a = a; b.innerHTML = `<span class="aname">${esc(actionWord(a))}</span><span class="adesc">${esc(S.actions[a] || "")}</span>${tagsOf(a).length ? `<span class="atags">${tagsOf(a).map(t => `<span class="tag">${esc(t)}</span>`).join("")}</span>` : ""}`;
      b.onclick = () => startAction(a); g.appendChild(b);
    }
    box.appendChild(g);
  }
}
const ticked = () => [...document.querySelectorAll("#a-targets input:checked")].map(i => i.value);
function hideStep3() { R.pending = null; $("a-step3").hidden = true; $("a-check").textContent = ""; document.querySelectorAll("#r-actions .atile").forEach(b => b.classList.remove("chosen")); }
/* what is still missing for the chosen action (empty = can be recorded) */
function missing(name) {
  const t = ticked(), out = [];
  if (NEED.one.includes(name) && t.length < 1) out.push("tick the record this is about (step 1)");
  if (NEED.two.includes(name) && t.length < 2) out.push("tick the two records to compare (step 1)");
  if (NEED.ranking.includes(name) && R.ranking.length < 2) out.push("click at least two candidates above, in your order");
  if (NEED.reason.includes(name) && !$("a-reason").value.trim()) out.push("say why");
  if (NEED.approver.includes(name) && !$("a-approver").value.trim()) out.push("name the second admin");
  if (NEED.approver.includes(name) && $("a-approver").value.trim() && $("a-approver").value.trim() === $("a-requester").value.trim()) out.push("the second admin must be a different person from you");
  if (NEED.event.includes(name) && !$("a-event").value) out.push("give the number of the decision to undo");
  return out;
}
function refreshStep3() { if (!R.pending) return; const m = missing(R.pending); $("a-check").textContent = m.length ? "Before recording: " + m.join("; ") : ""; $("a-go").disabled = m.length > 0; }
function startAction(name) {
  if (name === "add_procedure") {                 // your own procedure is built in the editor, which sends add_procedure itself
    hideStep3(); const ed = $("ed-box"); ed.open = true; ed.scrollIntoView({ behavior: "smooth", block: "start" });
    toast("build your procedure in the editor (steps, timing, power state), then press \"Propose my procedure and run it on the device\"", 8000); return;
  }
  R.pending = name;
  document.querySelectorAll("#r-actions .atile").forEach(b => b.classList.toggle("chosen", b.dataset.a === name));
  $("a-chosen").textContent = actionWord(name); $("a-what").textContent = S.actions[name] || ""; $("a-receipt").textContent = RECEIPT[name] || "";
  $("a-reason-row").hidden = !NEED.reason.includes(name); $("a-approver-row").hidden = !NEED.approver.includes(name); $("a-event-row").hidden = !NEED.event.includes(name); $("a-content-row").hidden = !NEED.content.includes(name);
  $("a-go").textContent = NEED.approver.includes(name) ? `Record: ${actionWord(name)} (written to the event log with both names)` : `Record: ${actionWord(name)}`;
  ["a-reason", "a-approver", "a-event", "a-requester"].forEach(id => $(id).oninput = refreshStep3);
  $("a-step3").hidden = false; refreshStep3();
  const first = NEED.reason.includes(name) ? "a-reason" : NEED.approver.includes(name) ? "a-approver" : NEED.event.includes(name) ? "a-event" : null;
  if (first) $(first).focus(); else $("a-step3").scrollIntoView({ behavior: "smooth", block: "nearest" });
}
function confirmAction() {
  const name = R.pending; if (!name) return;
  const m = missing(name); if (m.length) { refreshStep3(); return toast(m[0]); }
  const reason = NEED.reason.includes(name) ? $("a-reason").value.trim() : null;
  hideStep3(); doAction(name, null, reason);
}
async function doAction(name, editedScenario, reason, autoContent, explicitTargets, opts) {
  const quiet = !!(opts && opts.quiet);
  const targets = explicitTargets || ticked();
  let content; if (editedScenario) content = editedScenario; else if (autoContent) content = autoContent; else if ($("a-content").value.trim()) { try { content = JSON.parse($("a-content").value); } catch (e) { return toast("content is not valid JSON"); } }
  const body = { action: name, requester: $("a-requester").value.trim() || undefined, approver: NEED.approver.includes(name) ? $("a-approver").value.trim() : "", targets, ranking: R.ranking.length ? R.ranking : undefined, note: reason || $("a-note").value, content, event_id: $("a-event").value ? +$("a-event").value : undefined };
  if (!["accept", "add_cause", "add_procedure", "skip"].includes(name)) sub("result");
  $("r-result").innerHTML = `<span class=muted>applying: ${esc(actionWord(name))}…</span>`;
  if (NEED.approver.includes(name)) $("a-approver").value = "";      // a second admin's name counts for this one decision only
  try {
    const r = await api("POST", `/api/runs/${S.run}/incidents/${R.cur}/act`, body);
    if (r.job) { $("r-result").innerHTML = `<p>${esc(RECEIPT[name] || "")}</p><span class=muted>running: re-run as a safety check, search for a reproducing procedure, then the lab check on known-bad and fixed firmware…</span>`; toast(RECEIPT[name] || "started", 7000);
      poll(r.job, j => { $("r-result").innerHTML = `<p>${esc(RECEIPT[name] || "")}</p><div class=progress><div style="width:${j.progress.pct || 10}%"></div></div><span class=muted>${esc(plainIds(j.progress.detail))} · ${fmt(j.elapsed_s)} s</span>`; $("r-busy").textContent = `working… ${fmt(j.elapsed_s, 0)} s — searching on the simulated device, then the lab check on known-bad and fixed firmware, then writing the regression test`; },
        async j => { if (j.status === "done") { renderResult(j.result); toast("stage 2 finished: " + statusWord(j.result.status), 8000, undoFor(j.result)); } else $("r-result").innerHTML = `${pill("failed", "bad")}<pre>${esc(j.error)}</pre>`; $("ed-msg").textContent = ""; $("r-busy").hidden = true; await refreshRuns(); await enter(R.cur); });
    } else {
      renderResult(r.result); if (r.result.action_error) toast("refused: " + r.result.action_error, 8000); else toast(RECEIPT[name] || (r.result.action_effects || []).join("; ") || "applied", quiet ? 3000 : 8000, undoFor(r.result));
      if (!quiet) { $("r-busy").hidden = true; await refreshRuns(); await enter(R.cur); }
    }
  } catch (e) { $("r-result").innerHTML = `${pill("error", "bad")} ${esc(e.message)}`; }
}
function undoFor(res) {
  const ids = (res && res.action_events) || [];
  if (!ids.length) return null;
  return async () => { for (const id of [...ids].reverse()) await api("POST", "/api/db/undo", { event_id: id, actor: $("a-requester").value }); await enter(R.cur); };
}
/* "how the search went" and "most stressful conditions" in plain words (shared with decision.js through exports) */
export function searchWords(r) {
  const st = r && r.search; if (!st) return r && r.mode === "reuse" ? "no search needed: the saved procedure still reproduced the defect" : "-";
  const ops = (st.operators_that_helped || []).map(o => `${o.operator} (${o.improvements})`).join(", ");
  return `${st.trials} procedures tried; ${st.archive_cells || 0} distinct shapes kept as stepping stones${st.llm_proposals_used ? `; the AI reviewer was asked for ${st.llm_proposals_used} fresh proposal${st.llm_proposals_used > 1 ? "s" : ""} when the search stalled` : ""}. Changes that brought the trace closer to the failure signature: ${ops || "none beyond the starting point"}.`;
}
export function stressWords(r) {
  const st = r && r.stress; if (!st) return "-";
  if (!st.differs) return `the confirmed procedure could not be pushed harder: every tighter timing stopped the defect (${st.trials} lab runs)`;
  const pushed = Object.entries(st.pushed || {}).map(([k, v]) => `${(TIMING_NAME[k] || k).replace("µs ", "spacing ")} ×${v}`).join(", ");
  return `the defect still appears with ${pushed} (${st.trials} lab runs)${st.admitted ? " → filed as a second regression test guarding this margin" : st.closed_loop ? " → not filed: the lab check on known-bad and fixed firmware did not pass it" : ""}`;
}
function renderResult(r) {
  if (!r) { $("r-result").innerHTML = "<span class=muted>no action yet</span>"; return; }
  const cl = r.closed_loop;
  $("r-result").innerHTML = `<p>${esc(RECEIPT[r.action] || "")}</p>` + kv([["Action", `${esc(actionWord(r.action))} → ${esc((r.action_effects || []).join("; "))}${r.action_error ? " " + pill(r.action_error, "bad") : ""}`],
    ["How it ran / outcome", `${esc(modeWord(r.mode))} / ${pill(statusWord(r.status), statusCls(r.status))}${r.triage_timeout ? " " + pill("first-level triage limit (10 min) exceeded", "bad") : ""}`],
    ["Search", `${r.trials} lab runs · ${r.repro_lower95 != null ? `reproduced in at least ${pct(r.repro_lower95)} of lab runs (${likelihood(r.repro_lower95)})` : "no reproduction"} · ${fmt(r.search_s)} s`],
    ["Lab check on known-bad and fixed firmware", cl ? `the analyser found the same defect in ${cl.known_bad_hits} of ${cl.known_bad_n} lab runs on known-bad firmware and in ${cl.fixed_hits} of ${cl.fixed_n} on fixed firmware · best streak ${cl.max_consecutive_hits} in a row → ${cl.passed ? pill("regression test filed", "ok", "✓") : pill("no test filed", "bad", "✕")} ${r.optimal ? pill("optimal (score above 0.9 three times in a row)", "ok") : ""} (${fmt(r.verify_s)} s)` : "-"],
    ["How the search went", searchWords(r)], ["Most stressful conditions", stressWords(r)],
    ["Procedure", r.best ? seq(r.best) : "-"], ["Regression tests", (r.test_files || []).join(", ") || "-"],
    ["Time", `lookup and proposal ${fmt(r.present_s)} s (of which the AI reviewer ${fmt(r.llm_present_s)} s) + search ${fmt(r.search_s)} s + lab check ${fmt(r.verify_s)} s`]]);
}
