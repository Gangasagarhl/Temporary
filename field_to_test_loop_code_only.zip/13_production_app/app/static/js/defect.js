/* The full record of one defect: What this means -> Where -> Why it was flagged (rule checklist, host evidence,
   the AI reviewer's second opinion) -> Evidence packets -> What usually fixes it -> Related error types -> Stage 2 -> History.
   No record id, catalogue id without its chapter, or confidence number is shown to the operator. */
import { api, $, esc, fmt, pill, statusCls, statusPill, seq, kv, defectName, errorTypeFull, errorTypeShort, familyName } from "./api.js";

const q = new URLSearchParams(location.search); const RUN = q.get("run"), INC = q.get("inc");
const WORD = (p) => p.status === "NEEDS_OUTSIDE_EVIDENCE" ? "Needs evidence" : p.status === "DISPUTED" ? "Suspect" : "Confirmed";
const AI_WORD = { CONFIRMED: "agrees", NOT_CONFIRMED: "disagrees", REFUTED: "disagrees", DISPUTED: "disagrees", INCONCLUSIVE: "not sure" };
const aiWord = (v) => AI_WORD[v] || String(v || "").toLowerCase().replace(/_/g, " ");
const WHO = { device: "device side", host: "host side" };
const who = (o) => WHO[o] || (o ? String(o) : "not decided");
const WHERE = { physical: "physical link", data_link: "data link", "data-link": "data link", transaction: "transaction", config: "configuration", nvme: "NVMe command", "nvme-cmd": "NVMe command", "nvme-queue": "NVMe queues", "nvme-reg": "NVMe controller registers", data: "data integrity", device: "the drive", platform: "platform (root complex, IOMMU)", lab: "lab setup", "other-path": "outside the probed link", host: "host", power: "power management", sideband: "sideband (outside the probed link)", statistics: "statistics over the whole trace", capture: "the capture itself", workload: "host workload record" };
const where = (l) => WHERE[l] || (l ? String(l) : "-");
const ROLE = { root: "root cause", cascade: "knock-on effect", independent: "separate finding", context: "context only" };
const ACTION_WORD = { accept: "accepted", reject: "rejected", revise: "corrected", rerank: "reordered", add_cause: "cause added", add_procedure: "procedure added", promote: "promoted", delete_request: "deletion requested", delete_approve: "deletion approved", duplicate_of: "marked as duplicate", escalate: "escalated", link: "linked", not_reproducible: "marked not reproducible", split: "split", wrong_signature: "wrong signature" };
const STATUS_WORD = { done: "lab run done", confirmed: "reproduced", reused_validated: "saved procedure reproduced", failed: "failed", not_reproduced: "not reproduced", triage_timeout: "10-minute triage limit reached", admin_procedure_failed: "your procedure did not reproduce it", awaiting_hardware_bench: "waiting for the lab device", rejected: "rejected", swept: "sweep done", running: "running", cancelled: "cancelled", admitted: "regression test admitted", no_valid_variants: "no valid variation found", no_sources: "no procedure to start from", no_base: "no base procedure", not_applicable_workload: "not applicable (host workload record)", no_search: "no search run" };
const actionWord = (a) => ACTION_WORD[a] || String(a || "").replace(/_/g, " ");
const statusWord = (s) => STATUS_WORD[s] || String(s || "").replace(/_/g, " ");
const CHECK = { claims_cite_shown_rows: "every claim cites a packet that was shown", rule_named: "a rule is named", reproduced_by_script_on_full_file: "reproduced by the analyser on the full file", first_abnormal_event_identified: "first abnormal packet identified", root_and_cascade_cited_from_shown_rows: "root cause and knock-on effects cited from shown packets", cascade_separated_by_engine: "knock-on effects separated by the analyser", hypotheses_labelled: "other explanations labelled as such" };
const checkWord = (k) => CHECK[k] || k.replace(/_/g, " ");
/* texts that arrive from the server still say "engine" / "LLM" / "wire"; they are reworded for the operator here */
const plain = (t) => String(t || "").replace(/the engine's/g, "the analyser's").replace(/\bthe engine\b/g, "the analyser").replace(/\bLLM\b/g, "AI reviewer").replace(/\bthe wire\b/g, "the packets");
const hist = (h) => h.length ? `<table><thead><tr><th>When</th><th>Who</th><th>Decision</th><th>Note</th><th>Outcome</th></tr></thead><tbody>${h.map(x => `<tr><td>${new Date(x.when * 1000).toLocaleString()}</td><td>${esc(x.actor)}</td><td>${pill(actionWord(x.action), x.polarity === "positive" ? "ok" : x.polarity === "negative" ? "bad" : "", x.polarity === "positive" ? "+" : x.polarity === "negative" ? "−" : "")}</td><td>${esc(x.note || "")}</td><td>${x.outcome ? (x.outcome.admitted ? pill("regression test admitted", "ok", "✓") : pill("not admitted", "warn")) + ` lab check: known-bad firmware ${esc(x.outcome.known_bad)} · fixed firmware ${esc(x.outcome.fixed)}` : "-"}</td></tr>`).join("")}</tbody></table>` : "<p class=empty>No decision recorded for this error type yet.</p>";

(async function main() {
  if (!RUN || !INC) { $("d-head").innerHTML = "<p class=empty>Open this page from the workflow (it needs a run and a defect).</p>"; return; }
  const d = await api("GET", `/api/runs/${RUN}/defect/${INC}`); const p = d.proof, b = p.belongs_to, inc = d.incident, rv = d.llm_review || {};
  $("h-sub").textContent = `${defectName(INC)} · run ${RUN}`;
  $("d-head").innerHTML = `<div class=row><h2 style="margin:0">${esc(defectName(INC))} · ${esc(errorTypeFull(b.card, b.title))}</h2>${statusPill(WORD(p))}</div><p class=muted>${esc(plain(p.status_meaning))}.</p><p class="help">Defects are numbered 1, 2, 3 … in the order the analyser met them in this trace. The verdict words: Confirmed = proven by the analyser's rules on the packets; Suspect = a rule fired but the proof is incomplete; Needs evidence = the packets show only a symptom and host evidence would be needed.</p>`;
  $("d-which").innerHTML = kv([["Error type", `<b>${esc(errorTypeFull(b.card, b.title))}</b> <span class=muted>(one of the catalogue of ${b.of} known PCIe / NVMe error types)</span>`],
    ["Error family (how it shows on the wire)", esc(familyName(b.pattern))],
    ["Where", esc(where(b.layer))],
    ["Who", `<b>${esc(who(p.attribution.origin))}</b> <span class=muted>(decided by rule ${esc(p.attribution.decided_by || "-")}; the catalogue entry itself says: ${esc(p.attribution.card_badge || "-")})</span>`],
    ["Verdict", `${statusPill(WORD(p))} ${esc(plain(p.status_meaning))}`]]);
  const w = d.where || {};
  $("d-where").innerHTML = kv([["Packets", `<span class=mono>${inc.start_pkt} - ${inc.end_pkt}</span>${w.csv_lines ? ` (CSV lines ${w.csv_lines.start} - ${w.csv_lines.end})` : ""}`],
    ["Time", `<span class=mono>${esc(w.start_time || "")} - ${esc(w.end_time || "")}</span>`],
    ["First abnormal packet", p.first_abnormal ? `<span class=mono>#${esc(p.first_abnormal.pkt)}</span> · rule that fired: ${esc(p.first_abnormal.detail)} (${esc(p.first_abnormal.rule)})` : "-"],
    ["Root cause packet", p.root_cause ? `<span class=mono>#${esc(p.root_cause.pkt)}</span> · ${esc(p.root_cause.detail)} (${esc(p.root_cause.rule)})` : "-"],
    ["Evidence packets", `<span class=mono>${esc(((w.evidence_pkts) || inc.evidence_packets || []).join(", "))}</span>`]]);
  $("d-rules").innerHTML = `<table class=checklist><tbody>${p.rules.map(r => `<tr><td class="st ${r.verdict === "CONFIRMED" ? "ok" : "warn"}">${r.verdict === "CONFIRMED" ? "✓" : "?"}</td><td><b>${esc(r.rule)}</b> ${r.role ? pill(ROLE[r.role] || r.role) : ""} ${r.llm ? pill("AI reviewer " + (r.llm === "confirmed" ? "agrees" : r.llm === "refuted" ? "disagrees" : r.llm), r.llm === "confirmed" ? "ok" : "warn") : ""}<div>${esc(r.detail || "")}</div>${r.packet ? `<div class="muted small mono">packet #${r.packet}${r.line ? ", CSV line " + r.line : ""}</div>` : ""}${r.rows.length ? `<details><summary>packets that carry it</summary><pre style="max-height:140px">${esc(r.rows.join("\n"))}</pre></details>` : ""}</td></tr>`).join("")}</tbody></table>` || "<p class=empty>No rule details recorded.</p>";
  const acc = p.acceptance || {};
  if (Object.keys(acc).length) $("d-rules").innerHTML += `<div class="muted small">Proof checks: ${Object.entries(acc).map(([k, v]) => `${v ? "✓" : "✗"} ${esc(checkWord(k))}`).join(" · ")}</div>`;
  $("d-outside").innerHTML = (p.needs_outside_evidence ? `<p>${p.outside_evidence.length ? "Host evidence <b>was needed and was taken</b> from the host:" : "Host evidence <b>is needed</b> - the packets show only the symptom."}</p>` : `<p>No host evidence was needed: the packets alone prove this error.</p>`)
    + p.outside_evidence.map(o => `<div class=panel style="margin:6px 0"><b>${esc(o.source)}</b> at packet <span class=mono>#${esc(o.packet)}</span><div class=mono>${esc(o.text)}</div><div class="muted small">why this source: ${esc(plain(o.why))}</div></div>`).join("")
    + (p.evidence_to_collect.length ? `<p class=small>Still to collect: ${esc(plain(p.evidence_to_collect.join("; ")))}</p>` : "");
  $("d-llm").innerHTML = rv.verdict ? kv([["Verdict", pill("AI reviewer " + aiWord(rv.verdict), statusCls(rv.verdict))],
    ["Source", rv.backend === "pattern-cache" ? pill("verdict reused from the cache (no model call) - the same error family was confirmed in an earlier run", "info") : esc("fresh model call: " + rv.model + " via " + rv.backend)],
    ["Error type the AI reviewer picked", esc(rv.card_id ? errorTypeShort(rv.card_id) : "-")], ["Who, in the AI reviewer's view", esc(who(rv.responsible))], ["Rules it agrees with", esc((rv.rules_confirmed || []).join(", ") || "-")], ["Rules it disagrees with", esc((rv.rules_refuted || []).join(", ") || "-")],
    ["Packets it cites", `<span class=mono>${esc((rv.evidence_pkts || []).join(", "))}</span>`], ["Summary", esc(plain(rv.summary || ""))], ["Other explanations it considered", esc(plain((rv.hypotheses || []).join(" | ")) || "-")], ["What it would still need", esc(plain((rv.needs || []).join(" | ")) || "-")]]) : "<p class=empty>The AI reviewer was not asked (dry run or stand-in).</p>";
  const rows = []; for (const bl of d.rows) { rows.push(`CSV ROWS ${bl.range[0]}..${bl.range[1]}`); for (const x of bl.rows) rows.push(x); }
  $("d-rows").textContent = rows.join("\n");
  const y = d.why || {}, f = d.fix || {};
  $("d-why").innerHTML = kv([["Mechanism", esc(plain(y.mechanism || ""))], ["Typical causes", esc(plain(y.typical_causes || ""))], ["How it shows up", esc(plain(y.how_it_shows_up || ""))], ["Specification reference", esc(y.spec_basis || "")], ["What usually fixes it", esc(plain(f.corrective_action || ""))], ["How to prove the fix", esc(plain(f.how_to_prove || ""))]]);
  $("d-related").innerHTML = kv([["Error types the analyser scored", b.candidates.map(c => `${esc(errorTypeShort(c.card))} · match ${fmt(c.score, 2)}${c.title ? " - " + esc(c.title.slice(0, 60)) : ""}`).join("<br>") || "-"],
    ["Alternatives kept in mind", esc(b.alternatives.map(errorTypeShort).join(", ") || "none")], ["Cannot be told apart from the packets alone", esc(b.ambiguity_group.map(errorTypeShort).join(", ") || "none")]]);
  const st = d.stage2 || {}, v = st.view, last = st.last;
  $("d-stage2").innerHTML = !d.stage2_started ? "<p class=empty>Stage 2 has not been started for this run.</p>" : !v ? "<p class=empty>Not looked up yet.</p>" :
    kv([["Seen before", esc(plain(v.seen_label))], ["Saved procedure", v.stored ? seq(v.stored) : "none"], ["AI reviewer's proposal", v.generated ? seq(v.generated) : "none"],
      ["Decision", last ? `${esc(actionWord(last.action))} → ${esc(statusWord(last.status))} ${last.admitted ? pill("regression test admitted", "ok", "✓") : ""}` : "none yet"]]) + `<p><a href="/?run=${encodeURIComponent(RUN)}#review/${encodeURIComponent(INC)}">open in stage 2 (reproduce and decide) →</a></p>`;
  $("d-history").innerHTML = hist(d.history || []);
})();
