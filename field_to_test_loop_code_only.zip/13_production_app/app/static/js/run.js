/* Steps 1-2: choose the trace, analyse it (stage 1) with an honest progress view, then the defects found. */
import { api, $, esc, fmt, num, toast, pill, statusCls, statusPill, when, defectName, errorTypeFull, familyName, plainIds } from "./api.js";
import { S, show, refreshRuns, applyLocks, PHASE_TEXT } from "./main.js";

let timer = null, streamSeq = 0, streamJob = null, DEF_RUN = null;
const STEP_TEXT = { start: "Starting", analyze: "Reading the capture and checking every packet", fuse: "Lining up the host evidence with the packets", isolate: "Grouping the rules that fired into defects",
  pattern_cache: "Looking up AI reviewer verdicts from earlier runs", review: "Asking the AI reviewer for a second opinion on each defect", report: "Writing the stage 1 report", capture_check: "Assessing the capture as a whole", done: "Stage 1 complete" };
/* short labels for the ring centre and the per-step timing table (the internal step ids are never shown) */
const STEP_SHORT = { start: "starting", analyze: "reading packets", fuse: "host evidence", isolate: "grouping defects", pattern_cache: "reusing verdicts", review: "AI reviewer", report: "writing report", capture_check: "capture check", done: "complete" };
const stepLabel = (id) => STEP_SHORT[id] || String(id || "").replace(/_/g, " ");
const ORDER = ["analyze", "fuse", "isolate", "pattern_cache", "review", "report"];
const AI_WORD = { CONFIRMED: "agrees", REFUTED: "disagrees", DISPUTED: "disagrees", INCONCLUSIVE: "not sure" };
const aiWord = (v) => AI_WORD[v] || String(v || "").toLowerCase().replace(/_/g, " ");
const WHO = { device: "device side", host: "host side" };
const who = (o) => WHO[o] || (o ? String(o) : "not decided");
const WHERE = { physical: "physical link", data_link: "data link", transaction: "transaction", config: "configuration", nvme: "NVMe command", host: "host", power: "power management", sideband: "sideband (outside the probed link)", statistics: "statistics over the whole trace", capture: "the capture itself", workload: "host workload record" };
const where = (l) => WHERE[l] || (l ? String(l) : "-");
/* texts that arrive from the server still say "engine" / "LLM" / "wire"; they are reworded for the operator here */
const plain = (t) => plainIds(t).replace(/the engine's/g, "the analyser's").replace(/\bthe engine\b/g, "the analyser").replace(/\bLLM\b/g, "AI reviewer").replace(/\bthe wire\b/g, "the packets");

export function init() {
  try { if (!$("operator").value) $("operator").value = localStorage.getItem("operator") || ""; } catch (e) { /* storage may be unavailable */ }
  $("btn-inputs").onclick = async () => {
    if (!$("csv_path").value.trim()) { $("run-msg").textContent = "enter the CSV path first"; return; }
    try { const f = await api("GET", `/api/runs/inputs?csv_path=${encodeURIComponent($("csv_path").value)}`);
      if (f.payload) $("payload").value = f.payload; if (f.dmesg) $("dmesg").value = f.dmesg; if (f.events) $("events").value = f.events; if (f.nsze && !$("nsze").value) $("nsze").value = f.nsze;
      $("run-msg").textContent = f.message; } catch (e) { $("run-msg").textContent = "error: " + e.message; }
  };
  $("btn-start").onclick = async () => {
    if (!$("operator").value.trim()) { $("run-msg").textContent = "Please type your name first: it is recorded with the run and with every decision."; $("operator").focus(); return; }
    try { localStorage.setItem("operator", $("operator").value.trim()); } catch (e) { /* storage may be unavailable */ }
    if (!$("csv_path").value.trim()) { $("run-msg").textContent = "the CSV path is required"; $("csv_path").focus(); return; }
    try {
      const r = await api("POST", "/api/runs", { csv_path: $("csv_path").value, operator: $("operator").value.trim(), device: $("device").value.trim(), payload: $("payload").value, dmesg: $("dmesg").value, events: $("events").value, nsze: $("nsze").value, firmware: $("firmware").value, label: $("label").value, force: $("force").checked });
      $("run-msg").textContent = r.reused ? "this file was already analysed - opened the existing run " + r.run_id : "analysis started: run " + r.run_id;
      if (r.reused) toast(r.message, 7000);
      S.run = r.run_id; await refreshRuns(); $("run-select").value = S.run; show("run", undefined, "analyse");
    } catch (e) { $("run-msg").textContent = "error: " + e.message; }
  };
  $("btn-cancel").onclick = async () => { if (S.run && confirm("Stop the analysis of this trace? Partial results are discarded; you can start it again later.")) { await api("POST", `/api/runs/${S.run}/cancel`); toast("stop requested"); } };
  $("btn-to-incidents").onclick = () => show("incidents");
  $("btn-to-stage2").onclick = () => show("review");
}

export async function enter(arg, step) {
  await renderRuns();
  const hasRun = !!S.run;
  $("run-detail").hidden = !hasRun || step === "choose"; $("run-results").hidden = true;
  if (hasRun && step !== "choose") { $("choose-block").hidden = true; loadRun(); } else { $("choose-block").hidden = false; clearTimeout(timer); }
}

async function renderRuns() {
  await refreshRuns();
  const tb = $("runs-table").querySelector("tbody"); tb.innerHTML = ""; $("runs-empty").hidden = S.runs.length > 0;
  for (const r of S.runs) {
    const tr = document.createElement("tr"); tr.className = "click" + (r.run_id === S.run ? " sel" : "");
    const pc = r.phase === "stage1_running" ? "warn" : r.phase === "stage1_failed" ? "bad" : r.phase === "stage1_done" ? "info" : "ok";
    const s2 = r.stage2 ? ` · ${r.stage2.decided} of ${r.stage2.total} decided` : "";
    tr.innerHTML = `<td>${esc(r.run_id)}<br><span class="muted small">${esc(r.label || "")}</span></td><td class="muted small">${esc((r.csv || "").split("/").pop())}</td><td class=small>${esc(r.operator || "name not recorded")}<br><span class="muted">${when(r.created)}</span></td><td class=small>${esc(r.device || "unknown device")}<br><span class="muted">${esc(r.device_source || "")}</span></td>
      <td>${pill((PHASE_TEXT[r.phase] || r.phase) + s2, pc)}</td><td class=mono>${fmt(r.elapsed_s)} s</td><td>${r.incidents ?? "-"}</td>
      <td class=small>${r.llm && r.llm.called != null ? `agrees on ${r.llm.confirmed} · ${r.llm.called} fresh model calls · ${r.llm.cached} verdicts reused from the cache` : "-"}</td>
      <td><button class="small primary" data-open="${esc(r.run_id)}" title="Open this run">Open</button> <button class="small danger" data-del="${esc(r.run_id)}" title="Delete this run" ${r.status === "running" || r.status === "queued" ? "disabled" : ""}>Delete</button></td>`;
    const open = () => { S.run = r.run_id; $("run-select").value = S.run; applyLocks(); show("run", undefined, "analyse"); };
    tr.onclick = open;
    tr.querySelector("button[data-open]").onclick = (e) => { e.stopPropagation(); open(); };
    tr.querySelector("button[data-del]").onclick = async (e) => {
      e.stopPropagation();
      if (!confirm(`Delete run ${r.run_id} (${(r.csv || "").split("/").pop()})?\n\nThis removes its stage 1 results, stage 2 state and logs. The knowledge base (your decisions, procedures, tests) is kept. This cannot be undone.`)) return;
      try { await api("DELETE", `/api/runs/${r.run_id}`); if (S.run === r.run_id) { S.run = null; $("run-detail").hidden = true; $("run-results").hidden = true; $("choose-block").hidden = false; } toast("run " + r.run_id + " deleted"); await renderRuns(); applyLocks(); }
      catch (err) { toast("cannot delete: " + err.message, 8000); }
    };
    tb.appendChild(tr);
  }
}

function ring(j, v) {
  const pct = j.status === "done" ? 100 : Math.max(0, Math.min(99, Math.round(j.progress.pct || 0)));
  $("ring-fg").style.strokeDashoffset = (326.7 * (1 - pct / 100)).toFixed(1);
  $("ring-pct").textContent = pct + "%"; $("ring").setAttribute("aria-valuenow", pct);
  $("ring-step").textContent = j.status === "done" ? "complete" : j.status === "failed" ? "failed" : stepLabel(j.progress.step || "start");
  const el = $("ring"); el.classList.toggle("done", j.status === "done"); el.classList.toggle("running", j.status === "running"); el.classList.toggle("failed", j.status === "failed");
  const t = (j.progress || {}).stats || {};
  $("ring-text").textContent = j.status === "done" ? `Stage 1 complete: ${num(t.incidents)} defects found` : j.status === "failed" ? "Stage 1 failed - see the activity log" :
    (STEP_TEXT[j.progress.step] || stepLabel(j.progress.step)) + (j.progress.detail ? " - " + plain(j.progress.detail) : "");
  let eta = "";
  if (j.status === "running") {
    if (v.eta_s != null) eta = `about ${v.eta_s >= 60 ? Math.round(v.eta_s / 60) + " min" : v.eta_s + " s"} remaining · `;
    eta += `${fmt(j.elapsed_s, 0)} s elapsed`;
    if (v.stale_s > 120) eta += ` · no update for ${Math.round(v.stale_s)} s - the analyser is still working on a long step`; else if (v.stale_s > 30) eta += " · still working…";
  }
  $("ring-eta").textContent = eta;
  const done = new Set(j.spans.map(s => s.name.replace("stage1.", ""))), cur = j.progress.step;
  for (const tr of document.querySelectorAll("#steplist tr")) {
    const st = tr.dataset.step; const td = tr.querySelector(".st"), cnt = tr.querySelector(".cnt");
    const skipped = (st === "fuse" && !done.has("fuse") && (done.has("isolate") || (cur !== "fuse" && ORDER.indexOf(cur) > 1))) || (st === "review" && j.status === "done" && !done.has("review"));
    td.textContent = done.has(st) ? "✓" : cur === st && j.status === "running" ? "●" : skipped ? "–" : "○";
    tr.className = done.has(st) ? "done" : cur === st && j.status === "running" ? "cur" : skipped ? "skip" : "";
    cnt.textContent = st === "analyze" ? (t.rows_read ? `${num(t.rows_read)} of about ${num(t.rows_total_est)} packets read · ${num(t.findings)} rules fired` : "")
      : st === "isolate" ? (t.incidents != null ? `${num(t.incidents)} defects` : "") : st === "pattern_cache" ? (t.cached != null ? `${num(t.cached)} verdicts reused` : "")
      : st === "review" ? (t.review_total ? `${num(t.reviewed)} of ${num(t.review_total)} reviewed` : skipped ? "no AI reviewer configured" : "") : st === "fuse" ? (skipped ? "no host evidence given" : "") : "";
  }
}
async function stream(jid) {
  if (streamJob !== jid) { streamJob = jid; streamSeq = 0; $("run-stream").textContent = ""; }
  const r = await api("GET", `/api/jobs/${jid}/events?after=${streamSeq}`);
  if (r.events.length) { const el = $("run-stream"); el.textContent += r.events.map(e => `${new Date(e.ts * 1000).toLocaleTimeString()}  ${plain(e.text)}`).join("\n") + "\n"; streamSeq = r.last_seq; el.scrollTop = el.scrollHeight; }
}

async function loadRun() {
  clearTimeout(timer);
  if (!S.run) return;
  const r = await api("GET", `/api/runs/${S.run}`); const j = r.job, st = j.status, v = r.view;
  $("run-detail").hidden = false; $("run-id").textContent = S.run;
  $("run-status").textContent = PHASE_TEXT[v.phase] || v.phase; $("run-status").className = "pill " + (st === "done" ? "ok" : st === "failed" ? "bad" : "warn");
  await stream(j.id); ring(j, v);
  const tb = $("run-steps").querySelector("tbody"); tb.innerHTML = ""; let tot = 0;
  for (const s of j.spans) { tot += s.seconds; tb.innerHTML += `<tr><td>${esc(stepLabel(s.name.replace("stage1.", "")))}</td><td class=mono>${fmt(s.seconds, 2)}</td><td class="muted small">${s.meta.hits != null ? "verdicts reused from the cache: " + s.meta.hits : s.meta.ok === false ? "failed" : "done"}</td></tr>`; }
  $("run-total").textContent = st === "running" ? `running - ${fmt(j.elapsed_s)} s so far` : `stage 1 total ${tot.toFixed(1)} s`;
  const sm = r.summary;
  if (sm && st === "done") {
    $("run-chips").innerHTML = [["defects found", sm.incidents], ["AI reviewer agrees", sm.llm_confirmed], ["fresh model calls", sm.llm_called], ["verdicts reused from the cache (no model call)", sm.llm_cached], ["seconds taken", tot.toFixed(1)]].map(([a, b]) => `<div class=chip><b>${esc(b ?? "-")}</b><span>${esc(a)}</span></div>`).join("");
    $("run-summary").textContent = JSON.stringify({ "AI reviewer model": sm.model, "how it was reached": sm.backend, "stage 1 summary": sm.isolation_summary }, null, 1);
    $("run-warnings").innerHTML = (r.inputs_warnings || []).length ? `<div class=callout><b>This trace was analysed with limited inputs - fewer defects are visible than the trace contains.</b><ul>${r.inputs_warnings.map(w => "<li>" + esc(plain(w)) + "</li>").join("")}</ul>Use <i>Find companion files</i> in step 1 and analyse again with "analyse again even if this file was analysed before" ticked.</div>` : "";
    $("run-results").hidden = false; await renderDefects(); $("run-cta").hidden = false;
    if (v.phase === "stage1_done") { $("run-cta-text").innerHTML = `<b>Stage 1 complete.</b> ${sm.incidents} defects found; the AI reviewer agrees on ${sm.llm_confirmed}; ${tot.toFixed(1)} s taken. Stage 2 has not started: when you continue, each defect is looked up in the knowledge base and a procedure to reproduce it is proposed to you for a decision.`; $("btn-to-stage2").textContent = "Continue to stage 2 →"; }
    else { $("run-cta-text").innerHTML = `<b>Stage 2 ${v.phase === "stage2_done" ? "complete" : "in progress"}:</b> ${v.stage2.decided} of ${v.stage2.total} defects decided, ${v.stage2.admitted} regression tests admitted.`; $("btn-to-stage2").textContent = "Open stage 2 (reproduce and decide) →"; }
  } else { $("run-results").hidden = true; $("run-summary").textContent = j.error ? plain(j.error) : ""; $("run-cta").hidden = true; }
  applyLocks();
  if (st === "running" || st === "queued") timer = setTimeout(() => { loadRun(); renderRuns(); }, 1500);
}

async function renderDefects() {
  if (DEF_RUN === S.run && $("defects-list").children.length) return;
  DEF_RUN = S.run;
  const incs = await api("GET", `/api/runs/${S.run}/incidents`);
  const el = $("defects-list"); el.innerHTML = "";
  if (!incs.length) { el.innerHTML = `<p class=empty>No defects were found in this trace. If the trace shows a known problem, host evidence (the Linux kernel log dmesg -x, host tool records) may be needed: add it in step 1 and analyse again.</p>`; return; }
  for (const i of incs) {
    const l = i.llm || {};
    const d = document.createElement("details"); d.className = "defect";
    d.innerHTML = `<summary><span class="card-id">${esc(defectName(i.id))}</span><span class="ttl">${esc(errorTypeFull(i.card, i.title))}</span>${statusPill(i.status_word)}
      ${l.verdict ? pill("AI reviewer " + aiWord(l.verdict), statusCls(l.verdict)) : pill("AI reviewer not run")}
      <span class="llmline">${l.verdict ? (l.cached ? "verdict reused from the cache (no model call): the same error family was confirmed in an earlier run" : "fresh model call") : "the AI reviewer was not asked (dry run or no backend configured)"}</span>
      <span class="muted small">packets ${esc(i.start_pkt ?? "-")}-${esc(i.end_pkt ?? "-")}</span></summary>
      <div class="body muted small">loading…</div>`;
    d.addEventListener("toggle", async () => { if (d.open && !d.dataset.loaded) { d.dataset.loaded = "1"; d.querySelector(".body").innerHTML = await defectSummary(i.id); } });
    el.appendChild(d);
  }
}
async function defectSummary(id) {
  const d = await api("GET", `/api/runs/${S.run}/defect/${id}`); const p = d.proof, b = p.belongs_to, rv = d.llm_review || {};
  const fa = p.first_abnormal || {};
  return `<div class=kv>
    <b>What this means</b><span><b>${esc(errorTypeFull(b.card, b.title))}</b> · error family: ${esc(familyName(b.pattern))} · where: ${esc(where(b.layer))} - one of the catalogue of 485 known error types. ${esc(plain(p.status_meaning))}.</span>
    <b>Where</b><span>first abnormal packet #${esc(fa.pkt)} · rule that fired: ${esc(fa.detail)} (${esc(fa.rule)}) · packets ${d.incident.start_pkt}-${d.incident.end_pkt}</span>
    <b>Why it was flagged</b><span>${p.rules.map(r => `${r.verdict === "CONFIRMED" ? "✓" : "?"} ${esc(r.rule)}${r.packet ? " at packet #" + r.packet : ""}`).join(" · ") || "-"}</span>
    <b>Who</b><span>${esc(who(p.attribution.origin))}</span>
    <b>Host evidence</b><span>${p.needs_outside_evidence ? (p.outside_evidence.length ? p.outside_evidence.map(o => `needed and taken from <b>${esc(o.source)}</b>: "${esc(o.text)}"`).join("; ") : "needed, not yet available: " + esc(p.evidence_to_collect.join("; ") || "see the full record")) : "not needed - the packets alone prove it"}</span>
    <b>AI reviewer</b><span>${rv.verdict ? `${pill("AI reviewer " + aiWord(rv.verdict), statusCls(rv.verdict))} ${rv.backend === "pattern-cache" ? "verdict reused from the cache (no model call)" : "fresh model call"} · ${esc(plain((rv.summary || "").slice(0, 400)))}` : "not asked"}</span>
    <b></b><span><a href="/defect?run=${encodeURIComponent(S.run)}&inc=${encodeURIComponent(id)}" target="_blank">Open the full record ↗</a></span></div>`;
}
