"""Run report: how long each stage took, explicitly, plus what came out of it. JSON + Markdown."""
import json
import os
import time


def build_report(run, stage1_job, stage2_jobs, states, cache_stats):
    s1 = (stage1_job or {}).get("result") or {}
    steps = s1.get("steps", {})
    spans = [s for s in (stage1_job or {}).get("spans", []) if s["name"].startswith("stage1.")]
    s1_total = round(sum(s["seconds"] for s in spans), 2)
    inc_rows = []
    s2_present = s2_llm = s2_search = s2_verify = 0.0
    for inc_id, st in sorted(states.items()):
        v = st.get("view") or {}
        last = st.get("last") or {}
        t = v.get("timings") or {}
        s2_present += t.get("present_s", 0.0) or 0.0
        s2_llm += t.get("llm_s", 0.0) or 0.0
        s2_search += last.get("search_s", 0.0) or 0.0
        s2_verify += last.get("verify_s", 0.0) or 0.0
        inc_rows.append({"incident": inc_id, "card": (v.get("card") or {}).get("card"), "seen": v.get("seen_label") or v.get("seen"),
                         "stored_exists": bool(v.get("stored")), "generated_exists": bool(v.get("generated")),
                         "action": last.get("action"), "mode": last.get("mode"), "status": last.get("status"),
                         "trials": last.get("trials"), "repro_lower95": last.get("repro_lower95"),
                         "closed_loop": last.get("closed_loop"), "admitted": last.get("admitted"), "optimal": last.get("optimal"),
                         "triage_timeout": last.get("triage_timeout"),
                         "present_s": t.get("present_s"), "llm_s": t.get("llm_s"), "search_s": last.get("search_s"),
                         "verify_s": last.get("verify_s"), "total_s": last.get("seconds"), "test_files": last.get("test_files")})
    s2_total = round(s2_present + s2_search + s2_verify, 1)
    rep = {"run_id": run["id"], "csv": run["params"].get("csv_path"), "generated_at": time.time(),
           "stage1": {"status": (stage1_job or {}).get("status"), "seconds_total": s1_total,
                      "steps": [{"step": s["name"].split(".", 1)[1], "seconds": s["seconds"], "meta": s.get("meta", {})} for s in spans],
                      "incidents": s1.get("incidents"), "llm": {"model": s1.get("model"), "backend": s1.get("backend"),
                                                                "reviewed": s1.get("llm_reviewed"), "called": s1.get("llm_called"),
                                                                "from_pattern_cache": s1.get("llm_cached"), "confirmed": s1.get("llm_confirmed"),
                                                                "cost_usd": s1.get("llm_cost_usd")},
                      "isolation_summary": s1.get("isolation_summary"), "cache": cache_stats},
           "stage2": {"incidents_presented": sum(1 for st in states.values() if st.get("presented")),
                      "incidents_executed": sum(1 for st in states.values() if st.get("last")),
                      "seconds_present": round(s2_present, 1), "seconds_llm_in_present": round(s2_llm, 1),
                      "seconds_search": round(s2_search, 1), "seconds_verify": round(s2_verify, 1), "seconds_total": s2_total,
                      "admitted": sum(1 for r in inc_rows if r["admitted"]), "optimal": sum(1 for r in inc_rows if r["optimal"]),
                      "triage_timeouts": sum(1 for r in inc_rows if r["triage_timeout"]),
                      "jobs": [{"id": j["id"], "status": j["status"], "elapsed_s": j["elapsed_s"], "incident": j["params"].get("incident")}
                               for j in stage2_jobs], "incidents": inc_rows},
           "total_seconds": round(s1_total + s2_total, 1)}
    return rep


STARTED_FROM = {"reuse": "saved procedure", "adapt": "related procedure", "generate": "AI reviewer's proposal",
                "admin_procedure": "your own procedure", "compose": "saved command sequences (new variants)",
                "sweep": "the reproducing procedure (timing / power-state variants)"}


def to_markdown(rep):
    L = ["# Run %s" % rep["run_id"], "", "CSV: `%s`" % rep["csv"], "",
         "## Time taken", "", "| Stage | Seconds |", "|---|---|",
         "| Stage 1 (isolation + LLM confirmation) | %.1f |" % rep["stage1"]["seconds_total"],
         "| Stage 2 (present + search + verification) | %.1f |" % rep["stage2"]["seconds_total"],
         "| **Total** | **%.1f** |" % rep["total_seconds"], "",
         "### Stage 1 steps", "", "| Step | Seconds |", "|---|---|"]
    for s in rep["stage1"]["steps"]:
        L.append("| %s | %.2f |" % (s["step"], s["seconds"]))
    l = rep["stage1"]["llm"]
    L += ["", "Incidents isolated: %s. LLM confirmation: model %s via %s - %s reviewed, %s model calls, %s from the pattern cache, %s confirmed, cost %s USD." % (
        rep["stage1"]["incidents"], l["model"], l["backend"], l["reviewed"], l["called"], l["from_pattern_cache"], l["confirmed"], l["cost_usd"]),
          "", "### Stage 2 per incident", "",
          "| Defect | Error type | Seen before | Saved procedure | AI reviewer proposal | Decision | How it ran | Outcome | Lab runs | Showed the error in at least (%) | Lab check (known-bad / fixed) | Test filed | Optimal | Lookup (s) | AI reviewer (s) | Search (s) | Lab check (s) |",
          "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in rep["stage2"]["incidents"]:
        cl = r.get("closed_loop") or {}
        L.append("| %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s |" % (
            r["incident"], r["card"], r["seen"], "yes" if r["stored_exists"] else "no", "yes" if r["generated_exists"] else "no",
            r["action"] or "-", STARTED_FROM.get(r["mode"], r["mode"]) if r["mode"] else "-", r["status"] or "-",
            r["trials"] if r["trials"] is not None else "-",
            ("%d" % round(100 * float(r["repro_lower95"]))) if r["repro_lower95"] is not None else "-",
            ("%s of %s known-bad / %s of %s fixed" % (cl.get("known_bad_hits"), cl.get("known_bad_n"), cl.get("fixed_hits"), cl.get("fixed_n"))) if cl else "-",
            "yes" if r["admitted"] else "no", "yes" if r["optimal"] else "no", r["present_s"] or "-", r["llm_s"] or "-",
            r["search_s"] or "-", r["verify_s"] or "-"))
    L += ["", "Stage 2 totals: %d presented, %d executed, %d tests admitted, %d optimal (same error in 3 runs in a row), %d first-level-triage timeouts." % (
        rep["stage2"]["incidents_presented"], rep["stage2"]["incidents_executed"], rep["stage2"]["admitted"], rep["stage2"]["optimal"],
        rep["stage2"]["triage_timeouts"])]
    return "\n".join(L)


def write_report(run_dir, rep):
    with open(os.path.join(run_dir, "report.json"), "w") as f:
        json.dump(rep, f, indent=1, default=str)
    with open(os.path.join(run_dir, "report.md"), "w") as f:
        f.write(to_markdown(rep))
    return rep
