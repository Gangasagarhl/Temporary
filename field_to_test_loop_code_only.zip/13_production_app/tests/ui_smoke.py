#!/usr/bin/env python3
"""Browser smoke test of the stage-2 manager decision view, driven through Chrome's DevTools protocol against a
RUNNING application (python3 run_app.py). It opens the real page, selects a run that is in stage 2, goes to the review
step, checks the view, and exercises every manager option: drag/menu ranking + Save decisions, Not correct on the
LLM proposal (lesson, no weights), Needs changes -> Save corrected version (validated by execution), Correct on the
stored procedure (regression guard -> test script). Screenshots go to runs/ui_smoke/.

Needs google-chrome (or chromium) and the `websocket-client` module.   Usage: python3 tests/ui_smoke.py [--base URL] [--quick]
"""
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request

BASE = "http://127.0.0.1:8077"
QUICK = "--quick" in sys.argv
if "--base" in sys.argv:
    BASE = sys.argv[sys.argv.index("--base") + 1]
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(HERE, "runs", "ui_smoke")
os.makedirs(OUT, exist_ok=True)
RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append((bool(ok), name, detail))
    print("%s  %s%s" % ("PASS" if ok else "FAIL", name, ("  | " + str(detail)[:160]) if detail else ""), flush=True)
    return bool(ok)


def api(method, path, body=None):
    req = urllib.request.Request(BASE + path, method=method, data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.loads(r.read().decode() or "null")


class Browser:
    def __init__(self, port=9333):
        import websocket
        exe = shutil.which("google-chrome") or shutil.which("chromium") or shutil.which("chromium-browser")
        if not exe:
            sys.exit("no chrome/chromium found")
        self.proc = subprocess.Popen([exe, "--headless=new", "--disable-gpu", "--no-sandbox", "--hide-scrollbars",
                                      "--remote-debugging-port=%d" % port, "--remote-allow-origins=*", "--window-size=1280,1800", "about:blank"],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(50):
            try:
                targets = json.load(urllib.request.urlopen("http://127.0.0.1:%d/json" % port))
                page = next(t for t in targets if t["type"] == "page")
                break
            except Exception:
                time.sleep(0.2)
        else:
            sys.exit("chrome did not start")
        self.ws = websocket.create_connection(page["webSocketDebuggerUrl"], timeout=60)
        self.n = 0
        self.send("Page.enable")
        self.send("Runtime.enable")

    def send(self, method, params=None):
        self.n += 1
        self.ws.send(json.dumps({"id": self.n, "method": method, "params": params or {}}))
        while True:
            m = json.loads(self.ws.recv())
            if m.get("id") == self.n:
                return m.get("result", m)

    def ev(self, expr):
        r = self.send("Runtime.evaluate", {"expression": expr, "awaitPromise": True, "returnByValue": True})
        if "exceptionDetails" in r:
            raise RuntimeError(r["exceptionDetails"].get("exception", {}).get("description", str(r["exceptionDetails"]))[:300])
        return r.get("result", {}).get("value")

    def wait(self, expr, timeout=60, every=0.5):
        t0 = time.time()
        while time.time() - t0 < timeout:
            try:
                v = self.ev(expr)
                if v:
                    return v
            except RuntimeError:
                pass
            time.sleep(every)
        return None

    def shot(self, name):
        h = int(self.ev("Math.min(6000, document.documentElement.scrollHeight)") or 1800)
        self.send("Emulation.setDeviceMetricsOverride", {"width": 1280, "height": h, "deviceScaleFactor": 1, "mobile": False})
        r = self.send("Page.captureScreenshot", {"format": "png", "captureBeyondViewport": True})
        import base64
        p = os.path.join(OUT, name + ".png")
        open(p, "wb").write(base64.b64decode(r["data"]))
        return p

    def close(self):
        try:
            self.ws.close()
        except Exception:
            pass
        self.proc.terminate()


def pick_run():
    runs = api("GET", "/api/runs")
    for r in runs:
        if r.get("phase") in ("stage2", "stage2_done"):
            q = api("GET", "/api/runs/%s/stage2/queue" % r["run_id"])
            if q.get("started") and q.get("incidents"):
                return r["run_id"]
    return None


def wait_state(rid, inc, pred, timeout=420):
    t0 = time.time()
    while time.time() - t0 < timeout:
        st = api("GET", "/api/runs/%s/incidents/%s/state" % (rid, inc))
        if pred(st):
            return st
        time.sleep(2)
    return None


def main():
    rid = pick_run()
    if not check("U0 a run in stage 2 exists on the server", rid, rid):
        return finish()
    b = Browser()
    try:
        b.send("Page.navigate", {"url": BASE + "/"})
        check("U1 the application page loads", b.wait("document.getElementById('run-select') && document.getElementById('run-select').options.length > 1", 30))
        b.ev("(()=>{const s=document.getElementById('run-select'); s.value=%s; s.dispatchEvent(new Event('change')); return s.value;})()" % json.dumps(rid))
        b.ev("document.querySelector('aside .nav[data-page=\"review\"]').click(); true")
        ok = b.wait("document.querySelectorAll('#sol-list .solcard').length >= 1 && !document.getElementById('r-decision').hidden", 120)
        check("U2 review step opens the manager decision view with at least one candidate", ok)
        # prefer a defect that has a stored, approved procedure so that every verdict path is exercised
        want = None
        for i in api("GET", "/api/runs/%s/stage2/queue" % rid)["incidents"]:
            sol = api("GET", "/api/runs/%s/incidents/%s/solutions" % (rid, i["id"]))
            if any(x["id"].startswith("sol::") and x["status"] == "admin-approved" for x in sol["solutions"]):
                want = i["id"]
                break
        # the screens never show the raw INC id: the queue and the title say "Defect N"
        want_name = ("Defect %d" % int(want.split("-")[1])) if want else None
        if want:
            b.ev("[...document.querySelectorAll('#q-list .item')].find(x => x.dataset.id === %s || x.textContent.includes(%s + ' ')).click(); true" % (json.dumps(want), json.dumps(want_name)))
            b.wait("document.getElementById('r-title').textContent.includes(%s) && document.querySelectorAll('#sol-list .solcard').length >= 1" % json.dumps(want_name), 120)
        title = b.ev("document.getElementById('r-title').textContent") or ""
        shown = title.split("·")[0].strip()
        inc = b.ev("(document.querySelector('#q-list .item.sel') || {}).dataset ? document.querySelector('#q-list .item.sel').dataset.id : null") or want
        check("U3 the open defect is named in plain words (%s = %s)" % (shown, inc), shown.startswith("Defect ") and "INC-" not in title and bool(inc), title[:80])
        n_bluf = b.ev("document.querySelectorAll('#r-decision .bluf > div').length")
        has_flow = b.ev("!!document.querySelector('#r-decision svg.flow')")
        n_cards = b.ev("document.querySelectorAll('#sol-list .solcard:not(.stub)').length")
        n_btn = b.ev("document.querySelectorAll('#sol-list .solcard .verdicts button[data-v]:not([data-v=\"approve\"])').length")
        n_appr = b.ev("document.querySelectorAll('#sol-list .solcard .verdicts button[data-v=\"approve\"]').length")
        check("U4 bottom line (3 lines), packet flow graph, cards with the 3 verdict buttons each (+ 'Approve as second admin' on validated ones)", n_bluf == 3 and has_flow and n_cards >= 1 and n_btn == 3 * n_cards,
              "bluf %s flow %s cards %s verdict buttons %s approve buttons %s" % (n_bluf, has_flow, n_cards, n_btn, n_appr))
        summ = b.ev("document.querySelector('#r-advanced > summary').textContent")
        check("U5 everything else is behind 'All details'", summ.startswith("All details") and b.ev("!document.getElementById('r-advanced').open"), summ[:60])
        check("U6 the raw rows and the full action list are inside All details", b.ev("!!document.querySelector('#r-advanced #r-actions') && !!document.querySelector('#r-advanced #r-rows')"))
        b.shot("01_decision_view")
        ev0 = api("GET", "/api/db/overview")["knowledge"]["events"]
        # ---- ranking: menu "Move to bottom" on card 1, then Save decisions
        first = b.ev("document.querySelector('#sol-list .solcard:not(.stub)').dataset.id")
        if n_cards >= 2:
            b.ev("(()=>{const c=document.querySelector('#sol-list .solcard:not(.stub)'); c.querySelector('details.menu').open=true; c.querySelector('button[data-m=\"bottom\"]').click(); return true;})()")
            last = b.ev("[...document.querySelectorAll('#sol-list .solcard:not(.stub)')].pop().dataset.id")
            foot = b.ev("document.getElementById('dfoot-sum').textContent")
            check("U7 Move to bottom re-orders the cards (footer reports an unsaved ranking only when it has database meaning)", last == first, foot)
            live = b.ev("document.getElementById('sol-live').textContent")
            check("U8 the move is announced for screen readers (rank old -> new)", "moved to rank" in (live or ""), live)
            b.shot("02_reordered")
            n_stored = b.ev("document.querySelectorAll('#sol-list .solcard[data-id^=\"sol::\"]').length")
            if n_stored >= 2:
                b.ev("document.getElementById('btn-save-decisions').click(); true")
                time.sleep(3)
                ev1 = api("GET", "/api/db/overview")["knowledge"]["events"]
                rec = [e for e in api("GET", "/api/db/overview")["recent_events"] if e["kind"] == "admin_action"]
                check("U9 Save decisions records a rerank event (ratings only)", ev1 > ev0 and rec and rec[0]["payload"].get("action") == "rerank", "events %d -> %d, last %s" % (ev0, ev1, rec[0]["payload"].get("action") if rec else None))
            else:
                check("U9 with a single stored procedure the order is session-only: nothing claimed as unsaved, Save disabled", "not yet saved" not in foot and b.ev("document.getElementById('btn-save-decisions').disabled"), foot)
            b.wait("document.querySelectorAll('#sol-list .solcard').length >= 1", 60)
        # ---- Not correct on the LLM proposal -> stub with reason -> Save decisions -> lesson, no weights
        sig = api("GET", "/api/runs/%s/incidents/%s/solutions" % (rid, inc))
        card_sig = sig["card"]
        cnt0 = api("GET", "/api/db/signature/%s" % card_sig)
        a0 = [(c["cause"], round(c["edge"]["a"], 3), round(c["edge"]["b"], 3)) for c in cnt0.get("tree", [])]
        has_llm = b.ev("!!document.querySelector('#sol-list .solcard.proposal')")
        if has_llm:
            b.ev("document.querySelector('#sol-list .solcard.proposal button[data-v=\"wrong\"]').click(); true")
            stub = b.wait("!!document.querySelector('#sol-list .solcard.stub')", 10)
            check("U10 Not correct collapses the LLM proposal to a stub with Undo and reason chips", stub and b.ev("!!document.querySelector('#sol-list .solcard.stub .btn-undo') && document.querySelectorAll('#sol-list .solcard.stub .rchip').length >= 3"))
            b.ev("[...document.querySelectorAll('#sol-list .solcard.stub .rchip')].find(x => x.textContent === 'Wrong timing').click(); true")
            b.shot("03_removed_stub")
            tally = b.ev("document.getElementById('bluf-decision').textContent")
            check("U11 the bottom line tally counts the removal", "1 removed" in (tally or ""), tally)
            b.ev("document.getElementById('btn-save-decisions').click(); true")
            settled = b.wait("!!document.querySelector('#sol-list .solcard.stub.earlier') && document.getElementById('btn-save-decisions').disabled", 150)
            hist = api("GET", "/api/db/feedback/%s" % card_sig)["history"]
            a1 = [(c["cause"], round(c["edge"]["a"], 3), round(c["edge"]["b"], 3)) for c in api("GET", "/api/db/signature/%s" % card_sig).get("tree", [])]
            check("U12 rejecting the LLM's proposal records a lesson (note starts NOT CORRECT) and changes NO weights",
                  hist and hist[0]["action"] == "lesson" and str(hist[0].get("note") or "").startswith("NOT CORRECT") and a1 == a0,
                  "last action %s · counts %s -> %s" % (hist[0]["action"] if hist else None, a0, a1))
            check("U13 the history shows it as a negative decision with the reason", hist and hist[0]["polarity"] == "negative" and "Wrong timing" in (hist[0]["note"] or ""), (hist[0]["note"] if hist else "")[:100])
            check("U13b after the save the proposal stays collapsed as 'marked not correct earlier' with 'Show it again'", settled and b.ev("!!document.querySelector('#sol-list .solcard.stub.earlier .btn-show')"))
        if QUICK:
            return finish(b)
        # ---- Needs changes on the first stored card -> Save corrected version -> validated by execution
        stored = b.ev("(()=>{const c=document.querySelector('#sol-list .solcard:not(.stub):not(.proposal)'); return c ? c.dataset.id : null;})()")
        if stored:
            b.ev("document.querySelector('#sol-list .solcard[data-id=\"%s\"] button[data-v=\"partial\"]').click(); true" % stored)
            ok = b.wait("!!document.querySelector('#sol-list .solcard[data-id=\"%s\"] .editor:not([hidden]) .edrow.yours')" % stored, 10)
            check("U14 Needs changes opens Stored vs Your version in place", ok)
            b.ev("(()=>{const i=document.querySelector('#sol-list .solcard[data-id=\"%s\"] input.t[data-k=\"inter_cmd_us\"]'); i.value=String(Math.max(2, Math.round(+i.value*2))); i.dispatchEvent(new Event('change')); return i.value;})()" % stored)
            nch = b.ev("document.querySelector('#sol-list .solcard[data-id=\"%s\"] .edlbl small').textContent" % stored)
            check("U15 a changed timing is counted and highlighted", "1 change" in (nch or "") and b.ev("!!document.querySelector('#sol-list .solcard[data-id=\"%s\"] input.t.changed')" % stored), nch)
            b.shot("04_needs_changes_editor")
            st0 = api("GET", "/api/runs/%s/incidents/%s/state" % (rid, inc)).get("last") or {}
            b.ev("document.querySelector('#sol-list .solcard[data-id=\"%s\"] .editor .save').click(); true" % stored)
            prev_box = b.ev("document.getElementById('d-result-box').textContent") or ""
            busy = b.wait("!document.getElementById('r-busy').hidden && document.getElementById('r-busy').textContent.includes('validating')", 15)
            check("U16 Save corrected version starts the lab validation (status line visible)", busy, b.ev("document.getElementById('r-busy').textContent"))
            st = wait_state(rid, inc, lambda s: (s.get("last") or {}).get("action") == "add_procedure" and (s.get("last") or {}) != st0, 600)
            check("U17 the manager's version was executed first: kept (mode admin_procedure) or, if it did not reproduce, searched from (mode adapt) and reported", st and st["last"].get("mode") in ("admin_procedure", "adapt"),
                  "%s · status %s · trials %s · admitted %s" % (st and st["last"].get("mode"), st and st["last"].get("status"), st and st["last"].get("trials"), st and st["last"].get("admitted")))
            ok = b.wait("!document.getElementById('dsec-result').hidden && document.getElementById('d-result-box').textContent.includes('lab run') && document.getElementById('d-result-box').textContent !== %s" % json.dumps(prev_box), 120)
            check("U18 the Result section shows the lab outcome in the manager's words", ok, b.ev("document.getElementById('d-result-box').textContent.slice(0,140)"))
            if st and st["last"].get("mode") == "adapt":
                check("U18b the manager is told that his version did not reproduce and that the lab searched from it", b.ev("document.getElementById('d-result-box').textContent.includes('did not reproduce')"))
            b.shot("05_result_after_correction")
        # ---- Correct on the stored, approved procedure -> regression guard -> test script
        appr = b.ev("(()=>{const c=document.querySelector('#sol-list .solcard.approved:not(.stub)'); return c ? c.dataset.id : null;})()")
        if appr:
            st0 = api("GET", "/api/runs/%s/incidents/%s/state" % (rid, inc)).get("last") or {}
            b.ev("document.querySelector('#sol-list .solcard[data-id=\"%s\"] button[data-v=\"correct\"]').click(); true" % appr)
            st = wait_state(rid, inc, lambda s: (s.get("last") or {}).get("action") == "accept" and (s.get("last") or {}) != st0, 600)
            check("U19 Correct on the stored procedure runs the regression guard and reuses it (mode reuse/adapt)", st and st["last"].get("mode") in ("reuse", "adapt"),
                  "%s · status %s · trials %s · admitted %s · files %s" % (st and st["last"].get("mode"), st and st["last"].get("status"), st and st["last"].get("trials"), st and st["last"].get("admitted"), st and st["last"].get("test_files")))
            ok = b.wait("!document.getElementById('dsec-result').hidden", 120)
            check("U20 the Result section is shown after Correct", ok)
            hist = api("GET", "/api/db/feedback/%s" % card_sig)["history"]
            check("U21 the history now starts with the positive decision", hist and hist[0]["polarity"] == "positive", hist[0]["action"] if hist else "")
            b.shot("06_result_after_correct")
        # ---- Generate test case from the stored knowledge (LLM composition, validated by execution)
        if b.wait("!!document.getElementById('btn-compose') && !document.getElementById('btn-compose').disabled", 60):
            st0 = api("GET", "/api/runs/%s/incidents/%s/state" % (rid, inc)).get("last") or {}
            txt = b.ev("document.getElementById('compose-text').textContent")
            check("U22 the Generate test case section names how many stored sequences exist", "sequence" in (txt or "") and "database holds" in (txt or ""), (txt or "")[:120])
            b.ev("document.getElementById('btn-compose').click(); true")
            st = wait_state(rid, inc, lambda s: (s.get("last") or {}).get("action") == "compose_tests" and (s.get("last") or {}) != st0, 900)
            vs = (st or {}).get("last", {}).get("variants") or []
            check("U23 the LLM composed variants from the stored sequences and each was run in the lab", st and st["last"].get("mode") == "compose" and len(vs) >= 1,
                  "%s · %s" % (st and st["last"].get("status"), [(v["name"], v["repro_k"], v.get("admitted")) for v in vs]))
            ok = b.wait("!document.getElementById('dsec-result').hidden && document.getElementById('d-result-box').textContent.includes('stored')", 120)
            check("U24 the Result lists the composed variants with their lab numbers and test scripts", ok and b.ev("document.querySelectorAll('#d-result-box article.solcard').length >= 1"))
            b.shot("07_composed_tests")
        # ---- vulnerability sweep from the screen
        if b.wait("!!document.getElementById('btn-sweep') && !document.getElementById('dsec-sweep').hidden", 60):
            st0 = api("GET", "/api/runs/%s/incidents/%s/state" % (rid, inc)).get("last") or {}
            b.ev("document.getElementById('btn-sweep').click(); true")
            st = wait_state(rid, inc, lambda s: (s.get("last") or {}).get("action") == "sweep" and (s.get("last") or {}) != st0, 900)
            vs = (st or {}).get("last", {}).get("variants") or []
            check("U25 the neighbourhood sweep ran from the screen: %d variants, %d failure-prone, %d filed" % (len(vs), len((st or {}).get("last", {}).get("failure_prone") or []), sum(1 for v in vs if v.get("admitted"))),
                  st and st["last"].get("mode") == "sweep" and len(vs) >= 8)
            ok = b.wait("!document.getElementById('dsec-result').hidden && document.getElementById('d-result-box').textContent.includes('failure-prone')", 120)
            check("U26 the Result lists the variants with reproduction counts and the filed tests", ok and b.ev("document.querySelectorAll('#d-result-box table tbody tr').length >= 8"))
            b.shot("08_sweep")
        return finish(b)
    finally:
        b.close()


def finish(b=None):
    n_ok = sum(1 for ok, _, _ in RESULTS if ok)
    print("\n%d/%d checks passed · screenshots in %s" % (n_ok, len(RESULTS), OUT))
    with open(os.path.join(OUT, "ui_smoke_report.md"), "w") as f:
        f.write("# UI smoke test of the manager decision view\n\n%d/%d checks passed\n\n| Result | Check | Detail |\n|---|---|---|\n" % (n_ok, len(RESULTS)))
        for ok, name, detail in RESULTS:
            f.write("| %s | %s | %s |\n" % ("PASS" if ok else "FAIL", name, str(detail).replace("|", "/")[:200]))
    sys.exit(0 if n_ok == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
