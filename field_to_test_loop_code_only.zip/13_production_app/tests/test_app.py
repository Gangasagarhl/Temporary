#!/usr/bin/env python3
"""End-to-end test of the application through its HTTP API, with the deterministic stand-in LLM (no model calls,
no network): generate a synthetic capture -> stage 1 (analyze, isolate, pattern cache, report) -> incidents ->
stage 2 present (stored vs generated) -> admin action -> search + closed-loop verification job -> report with
explicit timings -> database browser -> undo. Also runs the stage-2 unit tests and the stage-1 engine fixtures.

Run: python3 tests/test_app.py        (~3-5 minutes; writes to a temporary copy of db/ runs/ samples/ suite/)
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import unittest

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(APP, "app"))


class AppTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = tempfile.mkdtemp(prefix="f2t_app_")
        for d in ("app", "stage1", "stage2", "data", "config"):
            os.symlink(os.path.join(APP, d), os.path.join(cls.root, d))
        from server import create_app, load_config
        cfg = load_config(os.path.join(APP, "config", "app_config.json"))
        cfg["_path"] = os.path.join(cls.root, "app_config.json")
        cfg["llm"]["backend"] = "standin"
        cfg["llm"]["capture_check"] = False
        cfg["stage2"].update(opt_budget=80, n_bad=2, n_fixed=1, time_budget_s=300, optimal_consecutive=2,
                             bench="synthetic", search_on="model")          # the functional test always runs on the synthetic bench
        cfg["paths"]["allowed_csv_roots"] = [cls.root, "/tmp"]
        cls.app = create_app(cfg, cls.root)
        cls.c = cls.app.test_client()

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.root, ignore_errors=True)

    def wait_job(self, jid, timeout=900):
        t0 = time.time()
        while time.time() - t0 < timeout:
            j = self.c.get("/api/jobs/%s" % jid).get_json()
            if j["status"] in ("done", "failed", "cancelled"):
                return j
            time.sleep(1.0)
        self.fail("job %s did not finish" % jid)

    def test_pipeline(self):
        # 0. config + actions
        c = self.c.get("/api/config").get_json()
        self.assertEqual(c["config"]["llm"]["backend"], "standin")
        self.assertIn("accept", self.c.get("/api/actions").get_json()["all"])
        # 1. a synthetic capture with host evidence
        r = self.c.post("/api/samples/generate", json={"cards": "T-42,L-21", "seed": 5}).get_json()
        self.assertTrue(os.path.exists(r["csv_path"]), r)
        self.assertGreater(r["rows"], 1000)
        f = self.c.get("/api/runs/inputs?csv_path=%s" % r["csv_path"]).get_json()
        self.assertIn("message", f)
        self.assertTrue(f["dmesg"] or f["events"] or "no companion" in f["message"])
        # path safety
        bad = self.c.post("/api/runs", json={"csv_path": "/etc/passwd"})
        self.assertEqual(bad.status_code, 400)
        # 2. stage 1
        body = {"csv_path": r["csv_path"], "nsze": r["nsze"], "firmware": "FW-A", "label": "test", "operator": "tester one", "device": "Test drive A"}
        body.update(r.get("host_evidence") or {})
        run = self.c.post("/api/runs", json=body).get_json()
        j = self.wait_job(run["job"])
        self.assertEqual(j["status"], "done", j.get("error"))
        names = [s["name"] for s in j["spans"]]
        for step in ("stage1.analyze", "stage1.isolate", "stage1.pattern_cache", "stage1.report"):
            self.assertIn(step, names)
        self.assertTrue(all(s["seconds"] >= 0 for s in j["spans"]))
        ev = self.c.get("/api/jobs/%s/events" % run["job"]).get_json()["events"]
        self.assertTrue(any("rows read" in e["text"] for e in ev), [e["text"] for e in ev][:10])
        self.assertTrue(any("stage 1 complete" in e["text"] for e in ev))
        self.assertGreater(j["progress"]["stats"]["rows_read"], 0)
        self.assertEqual(self.c.get("/api/jobs/%s/events?after=%d" % (run["job"], ev[-1]["seq"])).get_json()["events"], [])
        runs = self.c.get("/api/runs").get_json()
        self.assertEqual(runs[0]["run_id"], run["run_id"])
        detail = self.c.get("/api/runs/%s" % run["run_id"]).get_json()
        self.assertGreaterEqual(detail["summary"]["incidents"], 1)
        self.assertIn("inputs_warnings", detail)
        # 2b. run cache: the same CSV with the same inputs is not processed twice
        again = self.c.post("/api/runs", json=body).get_json()
        self.assertTrue(again["reused"])
        self.assertEqual(again["run_id"], run["run_id"])
        # 3. incidents + queue
        q = self.c.get("/api/runs/%s/stage2/queue" % run["run_id"]).get_json()
        self.assertEqual(q["counts"]["decided"], 0)
        self.assertIsNotNone(q["next"])
        incs = self.c.get("/api/runs/%s/incidents" % run["run_id"]).get_json()
        self.assertGreaterEqual(len(incs), 1)
        inc = next(i for i in incs if i["card"])
        d = self.c.get("/api/runs/%s/incidents/%s" % (run["run_id"], inc["id"])).get_json()
        self.assertEqual(d["incident"]["id"], inc["id"])
        self.assertTrue(d["rows"])
        # 4. stage 2 is gated: nothing happens before the admin starts it
        self.assertFalse(q["started"])
        self.assertEqual(self.c.post("/api/runs/%s/incidents/%s/present" % (run["run_id"], inc["id"])).status_code, 409)
        self.assertEqual(self.c.post("/api/runs/%s/incidents/%s/act" % (run["run_id"], inc["id"]), json={"action": "skip"}).status_code, 409)
        self.assertEqual(self.c.get("/api/runs/%s" % run["run_id"]).get_json()["view"]["phase"], "stage1_done")
        pj = self.c.post("/api/runs/%s/stage2/start" % run["run_id"]).get_json()
        self.assertTrue(pj["started"])
        self.assertGreaterEqual(pj["count"], 1)
        self.assertEqual(self.wait_job(pj["job"])["status"], "done")
        self.assertEqual(self.c.get("/api/runs/%s" % run["run_id"]).get_json()["view"]["phase"], "stage2")
        q2 = self.c.get("/api/runs/%s/stage2/queue" % run["run_id"]).get_json()
        self.assertEqual(q2["counts"]["presented"], q2["counts"]["total"])
        v = self.c.post("/api/runs/%s/incidents/%s/present" % (run["run_id"], inc["id"])).get_json()
        self.assertTrue(v["cached"])
        v = self.c.post("/api/runs/%s/incidents/%s/present?force=1" % (run["run_id"], inc["id"])).get_json()
        self.assertFalse(v["cached"])
        self.assertIn(v["seen"], ("new", "ambiguous", "match"))
        self.assertIn("accept", v["actions"]) if v["card"]["alternatives"] else self.assertIn("add_cause", v["actions"])
        self.assertIn("present_s", v["timings"])
        # 4b. the manager's decision view: candidate solutions with provenance (gated, cached view reused)
        sol = self.c.get("/api/runs/%s/incidents/%s/solutions" % (run["run_id"], inc["id"])).get_json()
        self.assertEqual(sol["card"], inc["card"])
        self.assertIn("solutions", sol)
        for x in sol["solutions"]:
            for k in ("id", "source", "status", "commands", "timing", "feedback"):
                self.assertIn(k, x)
            self.assertTrue(x["id"] == "llm" or x["id"].startswith("sol::"))
        self.assertTrue(all(x["status"] != "proposal" for x in sol["solutions"][:-1]))   # the LLM proposal is last
        # 5. a non-search action (skip) applies immediately
        s = self.c.post("/api/runs/%s/incidents/%s/act" % (run["run_id"], inc["id"]), json={"action": "skip", "requester": "a1"}).get_json()
        self.assertEqual(s["result"]["status"], "no_search")
        # 6. accept / add_cause -> background search + closed loop
        tgt = next((a["doc_id"] for a in v["card"]["alternatives"] if a["kind"] == "cause" and a["sig"] == inc["card"]), None)
        act = {"action": "accept", "targets": [tgt], "requester": "a1", "approver": "a2"} if tgt else \
              {"action": "add_cause", "content": {"text": "test cause"}, "requester": "a1", "approver": "a2"}
        a = self.c.post("/api/runs/%s/incidents/%s/act" % (run["run_id"], inc["id"]), json=act).get_json()
        self.assertIn("job", a)
        j2 = self.wait_job(a["job"])
        self.assertEqual(j2["status"], "done", j2.get("error"))
        res = j2["result"]
        self.assertIn(res["status"], ("confirmed", "budget_exhausted", "reused_validated", "triage_timeout"))
        self.assertGreaterEqual(res["search_s"], 0.0)
        if res["status"] in ("confirmed", "reused_validated"):
            self.assertIsNotNone(res["closed_loop"])
            self.assertIn("max_consecutive_hits", res["closed_loop"])
        st = self.c.get("/api/runs/%s/incidents/%s/state" % (run["run_id"], inc["id"])).get_json()
        self.assertEqual(st["last"]["incident"], inc["id"])
        # 6a. after a validated+approved procedure the manager view lists it first, with its lab numbers
        if res["status"] in ("confirmed", "reused_validated") and res.get("best_vhash"):
            sol = self.c.get("/api/runs/%s/incidents/%s/solutions" % (run["run_id"], inc["id"])).get_json()
            stored = [x for x in sol["solutions"] if x["id"].startswith("sol::")]
            self.assertTrue(stored, sol)
            self.assertIn(stored[0]["status"], ("admin-approved", "validated-by-execution"))
            self.assertIsNotNone(stored[0]["repro_lower95"])
            # 6b. metadata: who started the run, which device, and the procedure's own dates (proposed / validated)
            self.assertEqual(sol["run_meta"]["operator"], "tester one")
            self.assertEqual(sol["run_meta"]["device"]["name"], "Test drive A")
            h = stored[0]["history"]
            self.assertIsNotNone(h["proposed_at"])
            self.assertIsNotNone(h["validated_at"])
            self.assertEqual(h["validated_on_device"], "Test drive A")
            runs = self.c.get("/api/runs").get_json()
            me = next(x for x in runs if x["run_id"] == run["run_id"])
            self.assertEqual((me["operator"], me["device"]), ("tester one", "Test drive A"))
        # 6c. "generate test case": the LLM (stand-in here) composes variants from the stored sequences; execution decides
        if res["status"] in ("confirmed", "reused_validated"):
            a = self.c.post("/api/runs/%s/incidents/%s/act" % (run["run_id"], inc["id"]),
                            json={"action": "compose_tests", "requester": "a1", "approver": "a2"}).get_json()
            self.assertIn("job", a)
            j3 = self.wait_job(a["job"])
            self.assertEqual(j3["status"], "done", j3.get("error"))
            r3 = j3["result"]
            self.assertEqual(r3["mode"], "compose")
            self.assertGreaterEqual(r3["n_sources"], 1)
            self.assertIn(r3["status"], ("composed", "not_reproduced"))
            self.assertGreaterEqual(len(r3["variants"]), 1)
            for vv in r3["variants"]:
                for k in ("name", "rationale", "scenario", "repro_k", "repro_n", "confirmed", "admitted", "sources_used"):
                    self.assertIn(k, vv)
                self.assertTrue(all(c["op"] for c in vv["scenario"]["commands"]))
            if r3["admitted"]:
                vv = next(x for x in r3["variants"] if x["admitted"])
                man = json.load(open(os.path.join(vv["test_dir"], "manifest.json")))
                self.assertIn("composition", man)
                self.assertEqual(man["composition"]["name"], vv["name"])
                self.assertTrue(man["composition"]["sources"])
                self.assertIn("signature_id", man)
                py = next(f for f in vv["test_files"] if f.startswith("test_") and f.endswith(".py"))
                self.assertIn("Composed by the AI reviewer", open(os.path.join(vv["test_dir"], py)).read())
            sol2 = self.c.get("/api/runs/%s/incidents/%s/solutions" % (run["run_id"], inc["id"])).get_json()
            self.assertGreaterEqual(sol2["stored_count"], 1)
        # 6d. vulnerability analysis: sweep the neighbourhood of the reproducing procedure (checklist H8)
        if res["status"] in ("confirmed", "reused_validated"):
            a = self.c.post("/api/runs/%s/incidents/%s/act" % (run["run_id"], inc["id"]), json={"action": "sweep", "requester": "a1", "approver": "a2"}).get_json()
            j4 = self.wait_job(a["job"])
            self.assertEqual(j4["status"], "done", j4.get("error"))
            r4 = j4["result"]
            self.assertEqual(r4["mode"], "sweep")
            self.assertIn(r4["status"], ("swept", "no_variants"))
            self.assertGreaterEqual(len(r4["variants"]), 8)
            self.assertIn("jammer", r4)
            for vv in r4["variants"]:
                self.assertIn("failure_prone", vv)
            if r4["most_stressful"]:
                self.assertTrue(any(vv.get("vhash") for vv in r4["variants"]))
            self.assertIn("rules", r4)
            self.assertEqual(r4["rules"]["score_threshold"], 0.9)
            cl = res.get("closed_loop")
            if cl:
                self.assertIn("scores", cl)
                self.assertIn("max_consecutive_score_hits", cl)
        # 6e. Negative Ack: record the failed trial (-1) and restart on another random stream
        tgt2 = tgt or next((a["doc_id"] for a in v["card"]["alternatives"] if a["kind"] == "cause"), None)
        if tgt2:
            e0 = self.c.get("/api/db/signature/%s" % inc["card"]).get_json()
            a = self.c.post("/api/runs/%s/incidents/%s/act" % (run["run_id"], inc["id"]), json={"action": "restart_failed", "targets": [tgt2], "requester": "a1", "note": "test"}).get_json()
            j5 = self.wait_job(a["job"])
            self.assertEqual(j5["status"], "done", j5.get("error"))
            r5 = j5["result"]
            self.assertEqual(r5["action"], "restart_failed")
            self.assertTrue(any("failed trial recorded" in x for x in r5.get("action_effects", [])), r5.get("action_effects"))
            e1 = self.c.get("/api/db/signature/%s" % inc["card"]).get_json()
            tb0 = (e0.get("tree") or [{}])[0].get("edge", {}).get("tb")
            tb1 = (e1.get("tree") or [{}])[0].get("edge", {}).get("tb")
            if tb0 is not None and tb1 is not None and tgt2.startswith("cause::"):
                self.assertEqual(tb1, tb0 + 1)
        # 6f. KPI against the statement and the diagram's rules
        k = self.c.get("/api/kpi").get_json()
        self.assertEqual(k["rules"], {"score_threshold": 0.9, "optimal_consecutive": 3, "first_level_triage_s": 600})
        self.assertGreaterEqual(k["efficiency"]["runs"], 1)
        self.assertEqual(k["productivity"]["tests_authored_by_hand"], 0)
        self.assertIn("known_signature_leakage", k["quality"])
        # 6b. the full defect record and the admin's history on this error
        rec = self.c.get("/api/runs/%s/defect/%s" % (run["run_id"], inc["id"])).get_json()
        self.assertEqual(rec["defect"]["card_id"], inc["card"])
        for k in ("status", "status_meaning", "belongs_to", "rules", "attribution", "needs_outside_evidence", "outside_evidence"):
            self.assertIn(k, rec["proof"])
        self.assertEqual(rec["proof"]["belongs_to"]["of"], 485)
        self.assertEqual(self.c.get("/defect").status_code, 200)
        h = self.c.get("/api/db/feedback/%s" % inc["card"]).get_json()["history"]
        self.assertGreaterEqual(len(h), 2)                       # skip + accept/add_cause
        self.assertIn(h[0]["polarity"], ("positive", "negative", "neutral"))
        # 6c. the admin edits a procedure: proposed, validated by execution, closed loop
        ed = {"action": "add_procedure", "requester": "a1", "approver": "a2",
              "content": {"commands": [{"op": "write"}, {"op": "flush"}, {"op": "read"}], "timing": {"qd": 8, "inter_cmd_us": 50, "bs_kb": 4, "burst_len": 16, "idle_gap_ms": 0}, "power_state": "none"}}
        a3 = self.c.post("/api/runs/%s/incidents/%s/act" % (run["run_id"], inc["id"]), json=ed).get_json()
        self.assertIn("job", a3)
        j3 = self.wait_job(a3["job"])
        self.assertEqual(j3["status"], "done", j3.get("error"))
        self.assertIn(j3["result"]["mode"], ("admin_procedure", "adapt"))
        # 7. second presentation of the same incident sees the ledger (match or ambiguous when a solution exists)
        v2 = self.c.post("/api/runs/%s/incidents/%s/present" % (run["run_id"], inc["id"])).get_json()
        if res["status"] in ("confirmed", "reused_validated"):
            self.assertIn(v2["seen"], ("match", "ambiguous"))
            self.assertIsNotNone(v2["stored"])
        # 8. report with explicit timings
        rep = self.c.get("/api/runs/%s/report" % run["run_id"]).get_json()
        self.assertGreater(rep["stage1"]["seconds_total"], 0)
        self.assertGreaterEqual(rep["stage2"]["incidents_executed"], 1)
        self.assertTrue(any(s["step"] == "analyze" for s in rep["stage1"]["steps"]))
        md = self.c.get("/api/runs/%s/report?format=md" % run["run_id"]).data.decode()
        self.assertIn("Time taken", md)
        self.assertTrue(os.path.exists(os.path.join(self.root, "runs", run["run_id"], "report.md")))
        # 9. database interface + undo
        self.assertEqual(self.c.get("/db").status_code, 200)
        self.assertEqual(self.c.get("/").status_code, 200)
        ov = self.c.get("/api/db/overview").get_json()
        self.assertGreaterEqual(len(ov["signatures"]), 1)
        tree = self.c.get("/api/db/signature/%s" % inc["card"]).get_json()
        self.assertEqual(tree["sig"], inc["card"])
        summ = self.c.get("/api/db/summary").get_json()
        self.assertGreaterEqual(summ["knowledge"]["events"], 3)
        ev = self.c.get("/api/db/table/event?limit=5").get_json()
        self.assertEqual(ev["table"], "event")
        last_id = ev["rows"][0]["id"]
        u = self.c.post("/api/db/undo", json={"event_id": last_id, "actor": "a1"}).get_json()
        self.assertEqual(u["undone"], last_id)
        self.assertEqual(self.c.get("/api/db/signature/%s" % inc["card"]).get_json()["sig"], inc["card"])
        self.assertIn("stats", self.c.get("/api/db/cache").get_json())
        # 10. files + suite listing
        files = self.c.get("/api/runs/%s/files" % run["run_id"]).get_json()
        self.assertTrue(any(f["path"] == "report.md" for f in files))
        self.assertEqual(self.c.get("/api/runs/%s/file?path=../../etc/passwd" % run["run_id"]).status_code, 400)
        self.assertIsInstance(self.c.get("/api/suite").get_json(), list)
        # 10b. delete a run: outputs and jobs gone, the knowledge database untouched
        before = self.c.get("/api/db/summary").get_json()["knowledge"]["events"]
        self.assertEqual(self.c.delete("/api/runs/%s" % run["run_id"]).status_code, 200)
        self.assertEqual(self.c.get("/api/runs/%s" % run["run_id"]).status_code, 404)
        self.assertFalse(any(x["run_id"] == run["run_id"] for x in self.c.get("/api/runs").get_json()))
        self.assertFalse(os.path.exists(os.path.join(self.root, "runs", run["run_id"])))
        self.assertEqual(self.c.get("/api/db/summary").get_json()["knowledge"]["events"], before)
        self.assertEqual(self.c.delete("/api/runs/no-such-run").status_code, 404)
        # 11. config update hot-swaps settings
        put = self.c.put("/api/config", json={"stage2": {"opt_budget": 50}}).get_json()
        self.assertTrue(put["ok"])
        self.assertEqual(self.c.get("/api/config").get_json()["config"]["stage2"]["opt_budget"], 50)


class WorkloadArtifactTest(AppTest):
    """Input kind 'workload' (checklist H1): an ADK-style stage-1 artifact becomes a run; stage 2 looks it up, writes the
    baseline scenario (stand-in here) and files it as a proposed test for the hardware bench."""

    def test_pipeline(self):
        art = {"run": {"run_id": "fail_01", "assessment": "Fast-Startup"}, "verdict": {"outcome": "FAIL", "measured_ms": 14948, "limit_ms": 14000},
               "primary_hypothesis": "Flush blocked behind background work after unaligned trims",
               "abnormalities": [{"id": "ABN-001", "kind": "performance", "severity": "warning", "phase": "postboot",
                                  "component": {"type": "driver", "name": "stornvme"}, "title": "flush latency regressed", "statement": "flush p99 rose from 41 ms to 1512 ms",
                                  "observed": {"metric_id": "postboot.stornvme.flush_latency_p99_ms", "value": 1512, "unit": "ms"},
                                  "baseline": {"center": 41, "spread": 3.0, "n": 10}, "delta": {"abs": 1471, "robust_z": 37.1, "impact_ms": 1471},
                                  "evidence": [{"source_file": "FastStartup_IO_1.etl", "source_offset": 3}], "confidence": 0.9,
                                  "graph_keys": {"symptom": "storage.flush.latency", "component_class": "driver"}}]}
        path = os.path.join(self.root, "stage1_adk.json")
        json.dump(art, open(path, "w"))
        run = self.c.post("/api/runs", json={"kind": "workload", "artifact_path": path, "firmware": "SCBM9C1A-1628", "label": "ADK fail run"}).get_json()
        self.assertEqual(run.get("kind"), "workload", run)
        j = self.wait_job(run["job"])
        self.assertEqual(j["status"], "done", j.get("error"))
        incs = self.c.get("/api/runs/%s/incidents" % run["run_id"]).get_json()
        self.assertEqual(len(incs), 1)
        self.assertEqual(incs[0]["card"], "WL-storage.flush.latency")
        self.assertEqual(incs[0]["layer"], "workload")
        d = self.c.get("/api/runs/%s/incidents/%s" % (run["run_id"], incs[0]["id"])).get_json()
        self.assertEqual(d["signature"]["workload"], "ADK fail run")
        self.assertEqual(d["signature"]["metric"], "postboot.stornvme.flush_latency_p99_ms")
        pj = self.c.post("/api/runs/%s/stage2/start" % run["run_id"]).get_json()
        self.assertEqual(self.wait_job(pj["job"])["status"], "done")
        v = self.c.post("/api/runs/%s/incidents/%s/present" % (run["run_id"], incs[0]["id"])).get_json()
        self.assertIn(v["seen"], ("new", "ambiguous", "match"))
        self.assertIn("card", v)                                                  # presented (the stand-in writes the baseline at execute time)
        a = self.c.post("/api/runs/%s/incidents/%s/act" % (run["run_id"], incs[0]["id"]), json={"action": "add_cause", "content": {"text": "flush path"}, "requester": "a1", "approver": "a2"}).get_json()
        j2 = self.wait_job(a["job"])
        self.assertEqual(j2["status"], "done", j2.get("error"))
        r = j2["result"]
        self.assertEqual(r["mode"], "workload")
        self.assertEqual(r["status"], "awaiting_hardware_bench")
        self.assertTrue(r["test_files"])
        man = json.load(open(os.path.join(r["test_dir"], "manifest.json")))
        self.assertEqual(man["bench"], "hardware")
        self.assertEqual(man["workload"]["metric_id"], "postboot.stornvme.flush_latency_p99_ms")
        self.assertEqual(man["signature"]["workload"], "Fast-Startup")       # the assessment name; the run label is shown in the UI


class ComponentTests(unittest.TestCase):
    def test_stage2_unit_tests(self):
        r = subprocess.run([sys.executable, "-m", "unittest", "tests_v3", "tests_v4"], cwd=os.path.join(APP, "stage2"), capture_output=True, text=True, timeout=300)
        self.assertEqual(r.returncode, 0, r.stderr[-800:])

    def test_stage1_engine_fixtures(self):
        if not os.path.isdir(os.path.join(APP, "stage1", "tests")):
            self.skipTest("stage-1 fixture traces are not shipped in the code-only package")
        r = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "tests"], cwd=os.path.join(APP, "stage1"),
                           capture_output=True, text=True, timeout=300)
        self.assertEqual(r.returncode, 0, r.stderr[-800:])


if __name__ == "__main__":
    unittest.main(verbosity=2)
