"""Trial environment for stage 2 (Iterative Optimization).

`Oracle` is the interface the optimizer talks to:  result = oracle.run(scenario) -> dict with
  stage      0 nothing / 1 right failure family seen / 2 target signature SUSPECT / 3 target CONFIRMED /
             4 CONFIRMED with the reproduction parameters matching the field signature
  closeness  continuous [0,1] credit inside the current stage (latency vs threshold, replays of 4, ...)
  reproduced bool (stage >= 3)
  cost_s     simulated trial time

`SyntheticDeviceOracle` is the stand-in used when no emulator / bench is attached: a hidden trigger
model per failure signature (required command motif, queue-depth floor, timing window, power-state
precondition) with flakiness. It is derived deterministically from the signature id so runs are
reproducible, and it is NEVER readable by the optimizer.

To attach the real pipeline: subclass Oracle.run() to (1) render the scenario to fio/nvme-cli,
(2) execute on QEMU/SPDK/bench, (3) run the 10_defect_isolation_engine detector on the exported trace,
(4) map its verdict to stage/closeness exactly as `stage_from_detector` does.
"""
import hashlib
import random

OPS = ["read", "write", "flush", "trim", "write_zeroes", "reset", "power_cycle", "aspm_idle", "identify",
       "get_log", "set_feature", "abort"]
TIMING_KEYS = {"inter_cmd_us": (1, 5000), "burst_len": (1, 128), "idle_gap_ms": (0, 2000), "qd": (1, 256),
               "bs_kb": (4, 1024)}
POWER = ["none", "L1", "L1.2", "D3hot", "APST"]


def stage_from_detector(findings, target_card, target_variant):
    """Map detector output (list of {card_id, verdict, params}) to (stage, closeness)."""
    best = (0, 0.0)
    for f in findings:
        if f["card_id"] == target_card:
            if f["verdict"] == "CONFIRMED":
                s = 4 if f.get("params") == target_variant else 3
            elif f["verdict"] == "SUSPECT":
                s = 2
            else:
                continue
            best = max(best, (s, f.get("closeness", 1.0)))
        elif f["card_id"].split("-")[0] == target_card.split("-")[0] and f["verdict"] in ("CONFIRMED", "SUSPECT"):
            best = max(best, (1, 0.5))
    return best


class Oracle:
    def run(self, scenario):
        raise NotImplementedError


class SyntheticDeviceOracle(Oracle):
    def __init__(self, sig, variant, flaky=0.15, seed=0, family=None):
        h = int(hashlib.sha256(("%s|%d" % (sig, variant)).encode()).hexdigest(), 16)
        r = random.Random(h)
        fam = random.Random(int(hashlib.sha256(("fam|%s" % (family or sig)).encode()).hexdigest(), 16))
        n_motif = r.choice([2, 2, 3])
        ops = ["write", "read", "flush", "trim", "write_zeroes", "reset", "abort"]
        first = fam.choice(ops)                                  # shared within a failure family
        self.motif = [first] + r.sample([o for o in ops if o != first], n_motif - 1)
        self.qd_min = r.choice([1, 4, 8, 16, 32, 64])
        lo = fam.choice([1, 5, 20, 50, 200, 1000])               # timing scale shared within the family
        self.t_win = (lo, lo * r.choice([2, 4, 10]))
        self.power = r.choice(POWER) if r.random() < 0.5 else None
        self.bs_min = r.choice([4, 4, 64, 256])
        self.idle_min = r.choice([0, 0, 0, 100, 500])
        self.family_motif = self.motif[0]
        self.flaky = flaky
        self.rng = random.Random(seed ^ (h & 0xFFFF))
        self.calls = 0

    def _ordered_subseq(self, ops, motif):
        i = 0
        for o in ops:
            if i < len(motif) and o == motif[i]:
                i += 1
        return i

    def run(self, scenario):
        self.calls += 1
        ops = [c["op"] for c in scenario["commands"]]
        t = scenario["timing"]
        got = self._ordered_subseq(ops, self.motif)
        req = []
        req.append(got / len(self.motif))
        req.append(min(1.0, t["qd"] / self.qd_min))
        lo, hi = self.t_win
        x = t["inter_cmd_us"]
        req.append(1.0 if lo <= x <= hi else max(0.0, 1 - abs(x - (lo if x < lo else hi)) / max(hi, 1)))
        req.append(min(1.0, t["bs_kb"] / self.bs_min))
        req.append(1.0 if self.idle_min == 0 else min(1.0, t["idle_gap_ms"] / self.idle_min))
        req.append(1.0 if (self.power is None or scenario["power_state"] == self.power) else 0.0)
        met = sum(1 for v in req if v >= 0.999)
        closeness = sum(req) / len(req)
        # stage ladder
        if met == len(req):
            stage = 4 if scenario.get("variant_match", True) else 3
            if self.rng.random() < self.flaky:
                stage, closeness = 2, 0.9
        elif met >= len(req) - 1 and got == len(self.motif):
            stage = 2
        elif got >= 1 and self.family_motif in ops:
            stage = 1
        else:
            stage = 0
        cost = 2.0 + 0.001 * sum(t["burst_len"] for _ in ops) + (30.0 if "power_cycle" in ops else 0.0)
        return {"stage": stage, "closeness": round(closeness, 4), "reproduced": stage >= 3, "cost_s": cost,
                "requirements_met": met, "requirements": len(req)}

    def describe_hidden_truth(self):
        return {"motif": self.motif, "qd_min": self.qd_min, "timing_window_us": self.t_win, "power": self.power,
                "bs_min_kb": self.bs_min, "idle_min_ms": self.idle_min}
