"""Hybrid, feedback-driven retrieval over the procedural knowledge graph (v3). No training.

Candidate generation (all channels run over the same document set, which is re-synced from the DB):
  struct   exact structured match: card, failure family, first-abnormal rule, layer, origin, verdict, firmware
  bm25     Okapi BM25 over field-prefixed tokens (card:T-42, rule:CFG.D0_EARLY, k:CfgRd0, w:d3hot, ...)
  tri      cosine over hashed character trigrams of the free text (robust to spelling / id variants)
  rows     position-weighted LCS over the evidence-row kinds (ReBucket idea, from matcher.py)
  dense    optional sentence embeddings (callable texts -> vectors), cached per document
Fusion:    weighted reciprocal-rank fusion, k = 60, normalised to [0, 1]
Feedback:  final = fused x (0.5 + 0.5 x BetaMean(counts)) x exp(0.5 tanh(pl)); counts are the live graph counts
           the admin's actions maintain (credit / blame / decay / firmware halving), so retrieval changes the next
           time without any training. Slot k of the shown list is an exploration pick (Thompson sample).
Decision:  seen_before = match | ambiguous | new, from the best procedure candidate (same card AND same context
           AND fused >= T_HI -> match; same card or family or strongly similar rows -> ambiguous; else new).
Evaluation helpers: recall@k / MRR against hidden truth, team-draft interleaving for online A/B.
"""
import hashlib
import json
import math
import random
import re

from matcher import lcs_weighted, row_kinds

RRF_K = 60
CHANNEL_W = {"struct": 1.0, "bm25": 1.0, "tri": 0.7, "rows": 0.7, "dense": 0.7}
T_HI, T_LO = 0.70, 0.35
STOP = set("the a an of in on to for and or with by is are be not no from at as its it this that into than".split())


def tokens_of(text):
    return [w for w in re.findall(r"[a-z][a-z0-9_.\-]{2,}", (text or "").lower()) if w not in STOP]


def trigrams(text, dims=2 ** 18):
    t = re.sub(r"\s+", " ", (text or "").lower())
    v = {}
    for i in range(len(t) - 2):
        h = int(hashlib.blake2b(t[i:i + 3].encode(), digest_size=4).hexdigest(), 16) % dims
        v[h] = v.get(h, 0.0) + 1.0
    return v


def _norm(v):
    s = math.sqrt(sum(x * x for x in v.values())) or 1.0
    return {k: x / s for k, x in v.items()}


def cosine_sparse(a, b):
    if len(a) > len(b):
        a, b = b, a
    return sum(x * b.get(k, 0.0) for k, x in a.items())


class Doc:
    __slots__ = ("id", "kind", "sig", "cause", "vhash", "fields", "tokens", "text", "row_kinds", "tri", "dense", "payload")

    def __init__(self, id, kind, sig, fields, tokens, text, row_kinds=None, cause=None, vhash=None, payload=None):
        self.id, self.kind, self.sig, self.cause, self.vhash = id, kind, sig, cause, vhash
        self.fields, self.tokens, self.text, self.row_kinds = fields, list(tokens), text, row_kinds or []
        self.tri, self.dense, self.payload = _norm(trigrams(text)), None, payload


class HybridIndex:
    def __init__(self, db, graph=None, dense_fn=None, k=5, explore_slot=True, seed=0, weights=None):
        self.db, self.graph, self.dense_fn = db, graph, dense_fn
        self.k, self.explore_slot = k, explore_slot
        self.rng = random.Random(seed)
        self.w = dict(CHANNEL_W, **(weights or {}))
        self.docs = {}
        self.df, self.N, self.avgdl = {}, 0, 1.0
        self.post = {}           # token -> {doc_id: tf}   (inverted index for BM25)
        self.by_card, self.by_family, self.by_sig = {}, {}, {}
        self._dense_cache = {}
        self._event_mark = -1
        self.pool_cap = 300      # expensive channels (trigrams, row LCS, dense) run on this many pooled candidates

    # ------------------------------------------------------------------ document set
    def add(self, doc):
        if doc.id in self.docs:
            self.remove(doc.id)
        self.docs[doc.id] = doc
        tf = {}
        for t in doc.tokens:
            tf[t] = tf.get(t, 0) + 1
        for t, f in tf.items():
            self.df[t] = self.df.get(t, 0) + 1
            self.post.setdefault(t, {})[doc.id] = f
        if doc.fields.get("card"):
            self.by_card.setdefault(doc.fields["card"], set()).add(doc.id)
        if doc.fields.get("family"):
            self.by_family.setdefault(doc.fields["family"], set()).add(doc.id)
        if doc.sig:
            self.by_sig.setdefault(doc.sig, set()).add(doc.id)
        self.N = len(self.docs)
        self.avgdl = sum(len(d.tokens) for d in self.docs.values()) / max(1, self.N)
        if self.dense_fn and doc.id not in self._dense_cache:
            try:
                self._dense_cache[doc.id] = self.dense_fn([doc.text])[0]
            except Exception:
                self._dense_cache[doc.id] = None

    def remove(self, doc_id):
        d = self.docs.pop(doc_id, None)
        if d:
            for t in set(d.tokens):
                self.df[t] = self.df.get(t, 1) - 1
                self.post.get(t, {}).pop(doc_id, None)
            for ix, key in ((self.by_card, "card"), (self.by_family, "family")):
                if d.fields.get(key):
                    ix.get(d.fields[key], set()).discard(doc_id)
            if d.sig:
                self.by_sig.get(d.sig, set()).discard(doc_id)
            self.N = len(self.docs)

    def sync(self, force=False):
        """Keep the document set in step with the event log: full build the first time, then re-index only the
        signatures touched by events appended since the last sync (every incident appends an event)."""
        mark = self.db.con.execute("SELECT COALESCE(MAX(id),0) FROM event").fetchone()[0]
        if mark == self._event_mark and not force:
            return
        if force or self._event_mark < 0:
            self.docs, self.df, self.post, self.by_card, self.by_family, self.by_sig = {}, {}, {}, {}, {}, {}
            for sig in self.db.all_signatures():
                self._reindex_sig(sig)
        else:
            touched = set()
            for kind, payload in self.db.con.execute("SELECT kind, payload FROM event WHERE id > ? AND kind<>'undo'",
                                                     (self._event_mark,)).fetchall():
                pl = json.loads(payload)
                if pl.get("sig"):
                    touched.add(pl["sig"])
                if kind in ("merge", "soft_delete", "undo") or kind.startswith("solution_"):
                    touched.add(pl.get("sig"))
            undone = self.db.con.execute("SELECT COUNT(*) FROM event WHERE id > ? AND kind='undo'", (self._event_mark,)).fetchone()[0]
            if undone:                                     # a rebuild happened: safest is a full re-index
                self._event_mark = -1
                return self.sync(force=True)
            for sig in touched - {None}:
                self._reindex_sig(sig)
        self._event_mark = mark

    def _reindex_sig(self, sig):
        for did in list(self.by_sig.get(sig, ())):
            self.remove(did)
        meta = self.db.all_signatures().get(sig)
        if meta is None:
            return
        feats = sorted(meta["feats"])
        self.add(Doc("sig::" + sig, "signature", sig, {"card": sig, "family": meta["pattern"]}, feats,
                     " ".join(t.split(":", 1)[-1] for t in feats), payload={"pattern": meta["pattern"]}))
        for i, toks in enumerate(self.db.cases(sig, 10)):
            toks = sorted(toks)
            self.add(Doc("case::%s::%d" % (sig, i), "case", sig, {"card": sig, "family": meta["pattern"]}, toks,
                         " ".join(t.split(":", 1)[-1] for t in toks)))
        for cid in self.db.causes(sig):
            c = self.db.content(sig, cid) or {}
            txt = " ".join(str(v) for v in c.values() if isinstance(v, (str, int, float)))
            self.add(Doc("cause::%s::%s" % (sig, cid), "cause", sig, {"card": sig, "family": meta["pattern"]},
                         ["card:" + sig] + tokens_of(txt), txt, cause=cid, payload=c))
        for sol in self._all_solutions(sig):
            fp = sol["scenario"].get("_fingerprint") or {}
            sc = sol["scenario"]
            ops = [c["op"] if isinstance(c, dict) else str(c) for c in sc.get("commands", [])]
            txt = "%s %s %s %s" % (sol["sig"], sol["cause"], " ".join(ops), " ".join(fp.get("row_kinds") or []))
            toks = ["card:" + sol["sig"], "cause:" + str(sol["cause"])] + ["op:" + o for o in ops] + \
                   ["k:" + k for k in (fp.get("row_kinds") or [])] + (["rule:" + str(fp["rule"])] if fp.get("rule") else [])
            fields = {"card": sol["sig"], "family": fp.get("family") or meta["pattern"], "rule": fp.get("rule"), "layer": fp.get("layer"),
                      "origin": fp.get("origin"), "verdict": fp.get("verdict"), "context_hash": sol["context_hash"]}
            self.add(Doc("sol::" + sol["vhash"], "solution", sol["sig"], fields, toks, txt, fp.get("row_kinds"),
                         cause=sol["cause"], vhash=sol["vhash"], payload=sol))
        for i, l in enumerate(self.db.lessons(sig, 10)):
            self.add(Doc("lesson::%s::%d" % (sig, i), "lesson", sig, {"card": sig, "family": meta["pattern"]},
                         ["card:" + sig] + tokens_of(l["text"]), l["text"], cause=l.get("cause"), payload=l))

    def _all_solutions(self, sig=None):
        q = ("SELECT vhash,sig,cause,scenario,context_hash,producer,status,repro_lower95,approved_by FROM solution "
             "WHERE status IN ('admin-approved','validated-by-execution','superseded')")
        rows = self.db.con.execute(q + (" AND sig=?" if sig else ""), (sig,) if sig else ()).fetchall()
        return [{"vhash": r[0], "sig": r[1], "cause": r[2], "scenario": json.loads(r[3]), "context_hash": r[4],
                 "producer": r[5], "status": r[6], "repro_lower95": r[7], "approved_by": r[8]} for r in rows]

    # ------------------------------------------------------------------ channels
    def _bm25(self, qtoks, k1=1.2, b=0.75):
        scores = {}
        for t in set(qtoks):
            plist = self.post.get(t)
            if not plist:
                continue
            idf = math.log(1 + (self.N - self.df.get(t, 0) + 0.5) / (self.df.get(t, 0) + 0.5))
            for did, f in plist.items():
                dl = len(self.docs[did].tokens)
                scores[did] = scores.get(did, 0.0) + idf * f * (k1 + 1) / (f + k1 * (1 - b + b * dl / self.avgdl))
        return scores

    def _struct(self, q):
        scores = {}
        ids = set()
        if q.get("card"):
            ids |= self.by_card.get(q["card"], set())
        if q.get("family"):
            ids |= self.by_family.get(q["family"], set())
        for did in ids:
            d = self.docs[did]
            f = d.fields
            s = 0.0
            if q.get("card") and f.get("card") == q["card"]:
                s += 1.0
            elif q.get("family") and f.get("family") == q["family"]:
                s += 0.5
            m = [q.get(k) and f.get(k) == q.get(k) for k in ("rule", "layer", "origin", "verdict")]
            s += 0.25 * sum(1 for x in m if x) / 4
            if q.get("context_hash") and f.get("context_hash") == q["context_hash"]:
                s += 0.25
            if s > 0:
                scores[d.id] = s
        return scores

    def _tri(self, qtri, pool):
        return {did: c for did in pool for c in [cosine_sparse(qtri, self.docs[did].tri)] if c > 0.05}

    def _rows(self, qkinds, pool):
        if not qkinds:
            return {}
        return {did: s for did in pool if self.docs[did].row_kinds
                for s in [lcs_weighted(qkinds, self.docs[did].row_kinds)] if s > 0.1}

    def _dense(self, qtext, pool):
        if not self.dense_fn:
            return {}
        try:
            qv = self.dense_fn([qtext])[0]
        except Exception:
            return {}
        out = {}
        qn = math.sqrt(sum(x * x for x in qv)) or 1.0
        for did in pool:
            v = self._dense_cache.get(did)
            if v is None:
                continue
            vn = math.sqrt(sum(x * x for x in v)) or 1.0
            out[did] = sum(a * b for a, b in zip(qv, v)) / (qn * vn)
        return out

    # ------------------------------------------------------------------ query
    def query(self, q, k=None, kinds=("solution", "cause", "case", "signature", "lesson"), explore=None):
        """q: {card, family, rule, layer, origin, verdict, context_hash, tokens[], text, row_kinds[]}.
        Returns ranked candidates with per-channel scores, graph posterior and a 'why' list."""
        self.sync()
        k = k or self.k
        explore = self.explore_slot if explore is None else explore
        qtoks = list(q.get("tokens") or []) + ["k:" + x for x in (q.get("row_kinds") or [])]
        struct, bm25 = self._struct(q), self._bm25(qtoks)
        # candidate pool for the expensive channels: everything the cheap channels found, best first
        pool = sorted(set(struct) | set(bm25), key=lambda d: -(struct.get(d, 0.0) + bm25.get(d, 0.0) / 10.0))[:self.pool_cap]
        if len(pool) < self.pool_cap:                    # small index: let the text channels see everything
            pool = pool + [d for d in self.docs if d not in struct and d not in bm25][:self.pool_cap - len(pool)]
        channels = {"struct": struct, "bm25": bm25, "tri": self._tri(_norm(trigrams(q.get("text", ""))), pool),
                    "rows": self._rows(q.get("row_kinds") or [], pool), "dense": self._dense(q.get("text", ""), pool)}
        fused, parts = {}, {}
        for name, sc in channels.items():
            if not sc:
                continue
            for rank, (did, val) in enumerate(sorted(sc.items(), key=lambda x: -x[1])):
                if self.docs[did].kind not in kinds:
                    continue
                fused[did] = fused.get(did, 0.0) + self.w[name] / (RRF_K + rank + 1)
                parts.setdefault(did, {})[name] = round(val, 3)
        top = sum(self.w[n] for n in channels if channels[n]) / (RRF_K + 1) or 1.0
        cands = []
        for did, f in fused.items():
            d = self.docs[did]
            post, n, pl, a, b = self._posterior(d)
            # tempered feedback (beta = 0.5 in the research note): strong priors cannot lock the ranking (rich-get-richer)
            final = (f / top) * math.sqrt(0.5 + 0.5 * post) * math.exp(0.5 * math.tanh(pl))
            cands.append({"doc_id": did, "kind": d.kind, "sig": d.sig, "cause": d.cause, "vhash": d.vhash,
                          "fused": round(f / top, 4), "posterior": round(post, 3), "n": n, "score": round(final, 4),
                          "channels": parts.get(did, {}), "fields": d.fields, "payload": d.payload,
                          "why": self._why(d, q, parts.get(did, {}), a, b, n)})
        cands.sort(key=lambda c: -c["score"])
        shown = cands[:k - 1] if (explore and len(cands) > k) else cands[:k]
        if explore and len(cands) > k:
            rest = [c for c in cands[k - 1:] if c["fused"] >= 0.4 and c["n"] < 5] or cands[k - 1:]
            pick = max(rest, key=lambda c: self.rng.betavariate(1 + c["posterior"] * max(1, c["n"]),
                                                                 1 + (1 - c["posterior"]) * max(1, c["n"])) * c["fused"])
            pick = dict(pick, why=pick["why"] + ["shown to give a less-tried procedure a chance"], explore=True)
            shown = shown + [pick]
        return shown, cands

    def _posterior(self, d):
        """(posterior, n, pl, a, b): a and b are the Beta parameters (both start at 1.0), so a - 1 and b - 1 are
        the admins' Correct / Not-correct counts (decayed and capped, hence rounded when shown)."""
        if d.kind == "solution" and self.graph is not None:
            n_ = self.graph.node("scn::" + d.vhash)
            e_ = self.graph.edges("REPRODUCED_BY", dst="scn::" + d.vhash)
            if n_ and e_:
                a = n_["a"] + e_[0]["a"] - 1
                b = n_["b"] + e_[0]["b"] - 1
                return a / (a + b), n_["n"] + e_[0]["n"], n_.get("pl", 0.0), a, b
            if n_:
                return n_["posterior"], n_["n"], n_.get("pl", 0.0), n_["a"], n_["b"]
        if d.cause is not None and d.sig is not None and d.kind in ("cause", "solution", "lesson"):
            e = self.db.cache.get((d.sig, self.db.nid(d.sig, d.cause)))
            if e:
                return e["a"] / (e["a"] + e["b"]), e["n"], e["pl"], e["a"], e["b"]
        return 0.5, 0, 0.0, 1.0, 1.0

    @staticmethod
    def judged_counts(a, b):
        """Correct / Not-correct counts as the admin sees them (whole numbers, never negative)."""
        return max(0, int(round((a or 1.0) - 1.0))), max(0, int(round((b or 1.0) - 1.0)))

    @staticmethod
    def _why(d, q, parts, a, b, n):
        """Plain sentences, no numbers: what this candidate shares with the incident, and how admins judged it."""
        f = d.fields or {}
        why = []
        if q.get("card") and f.get("card") == q.get("card"):
            why.append("same error type")
        if q.get("rule") and f.get("rule") == q.get("rule"):
            why.append("same first rule")
        if q.get("context_hash") and f.get("context_hash") == q.get("context_hash"):
            why.append("same firmware")
        if parts.get("rows", 0.0) >= 0.5:
            why.append("same packet sequence around the first abnormal packet")
        if n:
            ok, bad = HybridIndex.judged_counts(a, b)
            why.append("judged correct %d time%s, not correct %d time%s" % (ok, "" if ok == 1 else "s", bad, "" if bad == 1 else "s"))
        else:
            why.append("not judged yet")
        return why

    # ------------------------------------------------------------------ seen-before decision
    def seen_before(self, q, shown):
        """match / ambiguous / new from the best solution candidate (+ the matcher's row/field logic)."""
        sols = [c for c in shown if c["kind"] == "solution"]
        if not sols:
            return "new", None, 0.0
        best = sols[0]
        f = best["fields"]
        same_card = f.get("card") == q.get("card")
        same_ctx = f.get("context_hash") and f.get("context_hash") == q.get("context_hash")
        # match = same card, same context, strong fusion AND the manifestation agrees (>= 2 of the 4 structured
        # fields rule/layer/origin/verdict; struct = 1.0 card + 0.25 ctx + 0.25 * agreeing/4 -> >= 1.375)
        if same_card and same_ctx and best["fused"] >= T_HI and best["channels"].get("struct", 0.0) >= 1.375:
            return "match", best, best["fused"]
        rows = best["channels"].get("rows", 0.0)
        struct = best["channels"].get("struct", 0.0)       # >= 0.4 means most structured fields (rule/layer/origin/
        same_family = bool(q.get("family")) and f.get("family") == q.get("family")   # verdict/context) agree
        if same_card or same_family or (rows >= 0.5 and struct >= 0.4 and best["fused"] >= T_LO):
            return "ambiguous", best, best["fused"]
        return "new", best, best["fused"]


# ---------------------------------------------------------------------- query construction from an incident
def query_from_incident(inc, context_hash=None, rows=None):
    """inc: stage1_adapter.Incident (or the benchmark obs with 'tokens'); rows: evidence row strings."""
    if hasattr(inc, "card"):
        fa = inc.first_abnormal or {}
        rk = row_kinds([r for blk in (inc.rows or []) for r in blk["rows"]]) if rows is None else row_kinds(rows)
        text = " ".join([str(inc.card or ""), str(inc.pattern or ""), str(fa.get("rule", "")), str(fa.get("detail", "")),
                         (inc.explanation or {}).get("title", ""), str(inc.task or "")] + rk)
        return {"card": inc.card, "family": inc.pattern, "rule": fa.get("rule"), "layer": inc.layer, "origin": inc.origin,
                "verdict": inc.verdict, "context_hash": context_hash, "tokens": inc.tokens, "text": text, "row_kinds": rk}
    d = inc
    det = d.get("detector", {})
    return {"card": det.get("card_hint"), "family": d.get("pattern"), "rule": None, "layer": None, "origin": None,
            "verdict": det.get("verdict"), "context_hash": context_hash, "tokens": d.get("tokens", []),
            "text": " ".join(t.split(":", 1)[-1] for t in d.get("tokens", [])), "row_kinds": d.get("row_kinds", [])}


# ---------------------------------------------------------------------- evaluation helpers
def recall_mrr(ranked_ids, truth_ids, k=5):
    hit = [i for i, x in enumerate(ranked_ids[:k]) if x in truth_ids]
    return (1.0 if hit else 0.0), (1.0 / (hit[0] + 1) if hit else 0.0)


def team_draft_interleave(rank_a, rank_b, k, rng):
    """Team-draft interleaving: returns (interleaved list, team_of[item]) for online A/B of two rankers."""
    out, team, ia, ib = [], {}, 0, 0
    ca = cb = 0
    while len(out) < k and (ia < len(rank_a) or ib < len(rank_b)):
        pick_a = (ca < cb) or (ca == cb and rng.random() < 0.5)
        if pick_a and ia < len(rank_a) or ib >= len(rank_b):
            while ia < len(rank_a) and rank_a[ia] in team:
                ia += 1
            if ia < len(rank_a):
                out.append(rank_a[ia]); team[rank_a[ia]] = "A"; ca += 1; ia += 1
                continue
        while ib < len(rank_b) and rank_b[ib] in team:
            ib += 1
        if ib < len(rank_b):
            out.append(rank_b[ib]); team[rank_b[ib]] = "B"; cb += 1; ib += 1
        else:
            break
    return out, team
