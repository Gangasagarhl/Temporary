"""Event-sourced procedural-knowledge database (SQLite, PostgreSQL-compatible schema).

The database starts EMPTY. Every create / update / delete happens only through an admin event
(`apply_event`). Node and edge tables are projections of the append-only `event` table, so any
event can be undone and the whole graph rebuilt by replay (`rebuild`).

Graph:   Signature --(SUGGESTS: a,b counts)--> Cause --(SCENARIO)--> Scenario(version chain) --> Script
Events:  incident_seen, node_create, node_edit, verdict, ranking, soft_delete, merge, undo, firmware_change,
         optimizer_result, script_gate
"""
import json
import sqlite3
import time

SCHEMA = """
CREATE TABLE IF NOT EXISTS event (
  id INTEGER PRIMARY KEY, ts REAL, kind TEXT, actor TEXT, payload TEXT, undone INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS node (
  id TEXT PRIMARY KEY, kind TEXT, sig TEXT, status TEXT DEFAULT 'active', created_by INTEGER, prior_rank INTEGER);
CREATE TABLE IF NOT EXISTS node_version (
  node_id TEXT, ver INTEGER, content TEXT, event_id INTEGER, PRIMARY KEY (node_id, ver));
CREATE TABLE IF NOT EXISTS edge (
  src TEXT, dst TEXT, kind TEXT, a REAL DEFAULT 1, b REAL DEFAULT 1, n INTEGER DEFAULT 0,
  pl REAL DEFAULT 0, ta REAL DEFAULT 1, tb REAL DEFAULT 1, status TEXT DEFAULT 'active', PRIMARY KEY (src, dst));
CREATE TABLE IF NOT EXISTS case_memory (sig TEXT, tokens TEXT, event_id INTEGER);
CREATE TABLE IF NOT EXISTS signature (sig TEXT PRIMARY KEY, pattern TEXT, feats TEXT, first_seen INTEGER, seen INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS ranking_run (event_id INTEGER, sig TEXT, shown TEXT, policy TEXT, params TEXT);
CREATE TABLE IF NOT EXISTS artifact (id INTEGER PRIMARY KEY, kind TEXT, sig TEXT, cause TEXT, path TEXT,
  payload TEXT, event_id INTEGER);
CREATE TABLE IF NOT EXISTS solution (
  vhash TEXT PRIMARY KEY, sig TEXT, cause TEXT, scenario TEXT, context_hash TEXT, producer TEXT,
  status TEXT, repro_lower95 REAL, created_event INTEGER, approved_by TEXT, supersedes TEXT);
CREATE TABLE IF NOT EXISTS lesson (sig TEXT, cause TEXT, text TEXT, producer TEXT, event_id INTEGER);
CREATE INDEX IF NOT EXISTS ix_solution_sig ON solution(sig, status);
CREATE INDEX IF NOT EXISTS ix_node_sig ON node(sig);
CREATE INDEX IF NOT EXISTS ix_edge_src ON edge(src);
CREATE INDEX IF NOT EXISTS ix_case_sig ON case_memory(sig);
"""


class KGDB:
    def __init__(self, path=":memory:", policy_params=None):
        self.con = sqlite3.connect(path, check_same_thread=False)   # the app serializes access with a lock
        self.con.executescript(SCHEMA)
        if path != ":memory:":
            # crash-safe on disk: write-ahead log + NORMAL sync (a committed decision survives a process crash; a power
            # cut can lose at most the last commit, never corrupt the file). The in-memory test databases stay fast.
            self.con.execute("PRAGMA journal_mode=WAL")
            self.con.execute("PRAGMA synchronous=NORMAL")
        else:
            self.con.execute("PRAGMA journal_mode=MEMORY")
            self.con.execute("PRAGMA synchronous=OFF")
        self.p = {"gamma": 0.02, "cap": 50.0, "fw_halve": 0.5, "edit_shrink": 0.7}
        self.p.update(policy_params or {})
        self.cache = {}            # (src,dst) -> dict, write-through cache of edge stats
        self.hooks = []            # projections owned by other modules (procgraph): .project(eid,kind,pl), .reset()
        self._load_cache()

    # ------------------------------------------------------------------ plumbing
    def _load_cache(self):
        self.cache = {}
        for src, dst, a, b, n, pl, ta, tb, status in self.con.execute(
                "SELECT src,dst,a,b,n,pl,ta,tb,status FROM edge"):
            self.cache[(src, dst)] = {"a": a, "b": b, "n": n, "pl": pl, "ta": ta, "tb": tb, "status": status}

    def _edge(self, src, dst):
        e = self.cache.get((src, dst))
        if e is None:
            e = {"a": 1.0, "b": 1.0, "n": 0, "pl": 0.0, "ta": 1.0, "tb": 1.0, "status": "active"}
            self.cache[(src, dst)] = e
            self.con.execute("INSERT OR IGNORE INTO edge(src,dst,kind) VALUES(?,?,?)", (src, dst, "SUGGESTS"))
        return e

    def _flush_edge(self, src, dst):
        e = self.cache[(src, dst)]
        self.con.execute("UPDATE edge SET a=?,b=?,n=?,pl=?,ta=?,tb=?,status=? WHERE src=? AND dst=?",
                         (e["a"], e["b"], e["n"], e["pl"], e["ta"], e["tb"], e["status"], src, dst))

    def log(self, kind, payload, actor="system"):
        # event_meta (set by the application while it holds the stage-2 lock): which run, defect, device, firmware,
        # trace and person the event belongs to. Stored with the event only; the projections never read it.
        meta = getattr(self, "event_meta", None)
        if meta and isinstance(payload, dict) and "meta" not in payload:
            payload = dict(payload, meta=meta)
        cur = self.con.execute("INSERT INTO event(ts,kind,actor,payload) VALUES(?,?,?,?)",
                               (time.time(), kind, actor, json.dumps(payload, sort_keys=True)))
        return cur.lastrowid

    def solution_history(self, vhash, limit=60):
        """Every event that names this procedure, oldest first: when it was proposed, validated (on which device and
        firmware), approved, judged, retired - with the person (actor) and the run/defect/device metadata."""
        out = []
        for eid, ts, kind, actor, payload, undone in self.con.execute(
                "SELECT id,ts,kind,actor,payload,undone FROM event WHERE payload LIKE ? ORDER BY id", ("%" + vhash + "%",)):
            try:
                pl = json.loads(payload)
            except ValueError:
                pl = {}
            if kind.startswith("solution_"):
                if pl.get("vhash") != vhash:
                    continue
            elif kind == "admin_action":                  # only decisions aimed at this procedure, not ones that merely showed it
                if not any(vhash in str(t) for t in (pl.get("targets") or [])):
                    continue
            elif kind != "script_gate":
                continue
            out.append({"event_id": eid, "ts": ts, "kind": kind, "actor": actor, "undone": bool(undone),
                        "action": pl.get("action"), "repro_lower95": pl.get("repro_lower95"),
                        "approved_by": pl.get("approved_by"), "producer": pl.get("producer"), "admitted": pl.get("admitted"),
                        "note": pl.get("note"), "meta": pl.get("meta") or {}})
        return out[-limit:]

    def commit(self):
        self.con.commit()

    # ------------------------------------------------------------------ queries
    def signature(self, sig):
        r = self.con.execute("SELECT sig,pattern,feats,seen FROM signature WHERE sig=?", (sig,)).fetchone()
        return None if r is None else {"sig": r[0], "pattern": r[1], "feats": json.loads(r[2]), "seen": r[3]}

    @staticmethod
    def nid(sig, cid):
        return "%s::%s" % (sig, cid)

    def causes(self, sig):
        return [r[0].split("::", 1)[1] for r in self.con.execute(
            "SELECT id FROM node WHERE sig=? AND kind='cause' AND status='active' ORDER BY prior_rank, id", (sig,))]

    def content(self, sig, cid):
        r = self.con.execute("SELECT content FROM node_version WHERE node_id=? ORDER BY ver DESC LIMIT 1",
                             (self.nid(sig, cid),)).fetchone()
        return None if r is None else json.loads(r[0])

    def edge(self, sig, cause_id):
        return self._edge(sig, self.nid(sig, cause_id))

    def cases(self, sig, limit=15):
        return [set(json.loads(r[0])) for r in self.con.execute(
            "SELECT tokens FROM case_memory WHERE sig=? ORDER BY event_id DESC LIMIT ?", (sig, limit))]

    def all_signatures(self):
        return {r[0]: {"pattern": r[1], "feats": set(json.loads(r[2]))} for r in
                self.con.execute("SELECT sig,pattern,feats FROM signature")}

    # ------------------------------------------------------------------ solution ledger & lessons (read)
    def solutions(self, sig, cause=None, status=None):
        q = "SELECT vhash,sig,cause,scenario,context_hash,producer,status,repro_lower95,approved_by FROM solution WHERE sig=?"
        args = [sig]
        if cause:
            q += " AND cause=?"
            args.append(cause)
        if status:
            q += " AND status=?"
            args.append(status)
        rows = self.con.execute(q + " ORDER BY created_event DESC", args).fetchall()
        return [{"vhash": r[0], "sig": r[1], "cause": r[2], "scenario": json.loads(r[3]), "context_hash": r[4],
                 "producer": r[5], "status": r[6], "repro_lower95": r[7], "approved_by": r[8]} for r in rows]

    def lessons(self, sig, limit=6):
        return [{"cause": r[0], "text": r[1], "producer": r[2]} for r in self.con.execute(
            "SELECT cause,text,producer FROM lesson WHERE sig=? ORDER BY event_id DESC LIMIT ?", (sig, limit))]

    def approved_cases(self, limit=400):
        """Admin-approved, execution-validated solutions = the exemplar bank for prompts."""
        return [{"sig": r[0], "cause": r[1], "scenario": json.loads(r[2]), "repro_lower95": r[3], "vhash": r[4], "family": r[5]}
                for r in self.con.execute("SELECT s.sig,s.cause,s.scenario,s.repro_lower95,s.vhash,g.pattern FROM solution s "
                                          "LEFT JOIN signature g ON g.sig = s.sig WHERE s.status='admin-approved' ORDER BY s.created_event DESC LIMIT ?", (limit,))]

    def stats(self):
        q = lambda s: self.con.execute(s).fetchone()[0]
        return {"events": q("SELECT COUNT(*) FROM event"), "signatures": q("SELECT COUNT(*) FROM signature"),
                "cause_nodes": q("SELECT COUNT(*) FROM node WHERE kind='cause' AND status='active'"),
                "deleted_nodes": q("SELECT COUNT(*) FROM node WHERE status='deleted'"),
                "edges": q("SELECT COUNT(*) FROM edge"), "node_versions": q("SELECT COUNT(*) FROM node_version"),
                "cases": q("SELECT COUNT(*) FROM case_memory"), "artifacts": q("SELECT COUNT(*) FROM artifact"),
                "solutions": q("SELECT COUNT(*) FROM solution"),
                "approved_solutions": q("SELECT COUNT(*) FROM solution WHERE status='admin-approved'"),
                "lessons": q("SELECT COUNT(*) FROM lesson")}

    # ------------------------------------------------------------------ event application (the only writers)
    def apply_event(self, kind, payload, actor="admin"):
        eid = self.log(kind, payload, actor)
        self._project(eid, kind, payload)
        for h in self.hooks:
            h.project(eid, kind, payload)
        return eid

    def _project(self, eid, kind, pl):
        p = self.p
        if kind == "incident_seen":
            if self.signature(pl["sig"]) is None:
                self.con.execute("INSERT INTO signature(sig,pattern,feats,first_seen,seen) VALUES(?,?,?,?,0)",
                                 (pl["sig"], pl.get("pattern", "?"), json.dumps(sorted(pl.get("feats", []))), eid))
            self.con.execute("UPDATE signature SET seen=seen+1 WHERE sig=?", (pl["sig"],))
        elif kind == "node_create":                       # admin authors a cause/scenario node
            nid = self.nid(pl["sig"], pl["node_id"])
            rank = self.con.execute("SELECT COUNT(*) FROM node WHERE sig=? AND kind='cause'", (pl["sig"],)).fetchone()[0]
            self.con.execute("INSERT OR REPLACE INTO node(id,kind,sig,status,created_by,prior_rank) VALUES(?,?,?,?,?,?)",
                             (nid, pl.get("kind", "cause"), pl["sig"], "active", eid, pl.get("prior_rank", rank)))
            self.con.execute("INSERT OR REPLACE INTO node_version(node_id,ver,content,event_id) VALUES(?,?,?,?)",
                             (nid, 1, json.dumps(pl.get("content", {})), eid))
            self._edge(pl["sig"], nid)
            self._flush_edge(pl["sig"], nid)
        elif kind == "node_edit":                         # "partially correct": new content version, counts kept
            nid = self.nid(pl["sig"], pl["node_id"])
            ver = self.con.execute("SELECT COALESCE(MAX(ver),0)+1 FROM node_version WHERE node_id=?", (nid,)).fetchone()[0]
            self.con.execute("INSERT INTO node_version(node_id,ver,content,event_id) VALUES(?,?,?,?)",
                             (nid, ver, json.dumps(pl["content"]), eid))
            e = self._edge(pl["sig"], nid)                # content changed -> shrink old evidence toward prior
            e["a"] = 1.0 + (e["a"] - 1.0) * p["edit_shrink"]
            e["b"] = 1.0 + (e["b"] - 1.0) * p["edit_shrink"]
            self._flush_edge(pl["sig"], nid)
        elif kind == "verdict":
            sig = pl["sig"]
            for cid in self.causes(sig):                  # per-event decay on the signature's edges
                e = self._edge(sig, self.nid(sig, cid))
                e["a"] = 1.0 + (e["a"] - 1.0) * (1 - p["gamma"])
                e["b"] = 1.0 + (e["b"] - 1.0) * (1 - p["gamma"])
            v = pl["verdict"]
            if v in ("correct", "partial") and pl.get("chosen"):
                self._credit(sig, pl["chosen"], 1.0)
            elif v == "not":
                if pl.get("rejected"):                    # localized blame: only the node the admin rejected
                    self._credit(sig, pl["rejected"], 0.0)
                if pl.get("chosen"):
                    self._credit(sig, pl["chosen"], 1.0)
            if pl.get("lab_result") is not None and pl.get("chosen"):   # verdict "lab": ONLY this block applies
                e = self._edge(sig, self.nid(sig, pl["chosen"]))
                e["ta" if pl["lab_result"] else "tb"] += 1.0
            for cid in self.causes(sig):
                self._flush_edge(sig, self.nid(sig, cid))
            if pl.get("tokens"):
                tgt = pl.get("chosen") or (sig if v != "not" else None)
                if tgt:
                    self.con.execute("INSERT INTO case_memory(sig,tokens,event_id) VALUES(?,?,?)",
                                     (sig, json.dumps(sorted(pl["tokens"])), eid))
        elif kind == "ranking":                           # admin's order of the shown items -> relative skill
            sig, keys = pl["sig"], pl["ranking"]
            eta = 0.3
            keys = [self.nid(sig, k) for k in keys]
            sk = [self._edge(sig, k)["pl"] for k in keys]
            import math
            for i in range(len(keys)):
                denom = sum(math.exp(x) for x in sk[i:])
                for m in range(i, len(keys)):
                    pr = math.exp(sk[m]) / denom
                    self._edge(sig, keys[m])["pl"] += eta * ((1 - pr) if m == i else -pr) / len(keys)
            for k in keys:
                self._edge(sig, k)["n"] += 0            # ranking never counts as success
                self._flush_edge(sig, k)
        elif kind == "soft_delete":                       # needs approver != requester (two-person rule)
            if pl.get("approved_by") and pl["approved_by"] != pl.get("requested_by"):
                nid = self.nid(pl["sig"], pl["node_id"])
                self.con.execute("UPDATE node SET status='deleted' WHERE id=?", (nid,))
                e = self._edge(pl["sig"], nid)
                e["status"] = "deleted"
                self._flush_edge(pl["sig"], nid)
        elif kind == "merge":
            sig = pl["sig"]
            keep, drop = self.nid(sig, pl["keep"]), self.nid(sig, pl["drop"])
            ek, ed = self._edge(sig, keep), self._edge(sig, drop)
            for f in ("a", "b", "ta", "tb"):
                ek[f] += ed[f] - 1.0
            ek["n"] += ed["n"]
            self.con.execute("UPDATE node SET status='merged' WHERE id=?", (drop,))
            ed["status"] = "merged"
            self._flush_edge(sig, keep)
            self._flush_edge(sig, drop)
        elif kind == "firmware_change":                   # halve accumulated evidence everywhere
            for (src, dst), e in self.cache.items():
                e["a"] = 1.0 + (e["a"] - 1.0) * p["fw_halve"]
                e["b"] = 1.0 + (e["b"] - 1.0) * p["fw_halve"]
                self._flush_edge(src, dst)
        elif kind == "solution_propose":                  # LLM / optimizer may only append 'proposed'
            self.con.execute("INSERT OR IGNORE INTO solution(vhash,sig,cause,scenario,context_hash,producer,status,"
                             "repro_lower95,created_event,supersedes) VALUES(?,?,?,?,?,?,?,?,?,?)",
                             (pl["vhash"], pl["sig"], pl["cause"], json.dumps(pl["scenario"], sort_keys=True),
                              pl.get("context_hash", ""), pl.get("producer", "llm"), "proposed",
                              pl.get("repro_lower95"), eid, pl.get("supersedes")))
            # re-proposing a procedure that failed validation earlier puts it back to 'proposed' (it is validated again)
            self.con.execute("UPDATE solution SET status='proposed', producer=?, created_event=? WHERE vhash=? AND status='failed-validation'",
                             (pl.get("producer", "llm"), eid, pl["vhash"]))
        elif kind == "solution_validate":                 # the bench/execution is the arbiter
            self.con.execute("UPDATE solution SET status=CASE WHEN ?>0 THEN 'validated-by-execution' ELSE 'failed-validation' END,"
                             " repro_lower95=? WHERE vhash=? AND status IN ('proposed','validated-by-execution')",
                             (pl["repro_lower95"], pl["repro_lower95"], pl["vhash"]))
        elif kind == "solution_approve":                  # four-eyes: approver bound to the immutable hash
            r = self.con.execute("SELECT status, producer FROM solution WHERE vhash=?", (pl["vhash"],)).fetchone()
            if r and r[0] == "validated-by-execution" and pl.get("approved_by") != r[1]:
                self.con.execute("UPDATE solution SET status='admin-approved', approved_by=? WHERE vhash=?",
                                 (pl["approved_by"], pl["vhash"]))
                self.con.execute("UPDATE solution SET status='superseded' WHERE sig=? AND cause=? AND vhash<>? "
                                 "AND status='admin-approved'", (pl["sig"], pl["cause"], pl["vhash"]))
        elif kind == "solution_deprecate":
            if pl.get("approved_by") and pl["approved_by"] != pl.get("requested_by"):
                self.con.execute("UPDATE solution SET status='deprecated' WHERE vhash=?", (pl["vhash"],))
        elif kind == "lesson":
            self.con.execute("INSERT INTO lesson(sig,cause,text,producer,event_id) VALUES(?,?,?,?,?)",
                             (pl["sig"], pl.get("cause"), pl["text"][:400], pl.get("producer", "admin"), eid))
        elif kind in ("optimizer_result", "script_gate"):
            self.con.execute("INSERT INTO artifact(kind,sig,cause,path,payload,event_id) VALUES(?,?,?,?,?,?)",
                             (kind, pl.get("sig"), pl.get("cause"), pl.get("path", ""), json.dumps(pl), eid))
            if kind == "optimizer_result" and pl.get("cause") and pl.get("best_scenario") is not None:
                # the optimizer's trigger becomes the next content version of the scenario node
                nid = self.nid(pl["sig"], pl["cause"])
                ver = self.con.execute("SELECT COALESCE(MAX(ver),0)+1 FROM node_version WHERE node_id=?",
                                       (nid,)).fetchone()[0]
                self.con.execute("INSERT INTO node_version(node_id,ver,content,event_id) VALUES(?,?,?,?)",
                                 (nid, ver, json.dumps({"optimized": pl["best_scenario"],
                                                        "repro_rate": pl.get("repro_rate")}), eid))

    def _credit(self, sig, cid, r):
        e = self._edge(sig, self.nid(sig, cid))
        e["a"] += r
        e["b"] += 1 - r
        e["n"] += 1
        tot = e["a"] + e["b"]
        if tot > self.p["cap"]:
            e["a"] *= self.p["cap"] / tot
            e["b"] *= self.p["cap"] / tot

    # ------------------------------------------------------------------ undo & rebuild (event sourcing)
    def undo(self, event_id, actor="admin"):
        self.con.execute("UPDATE event SET undone=1 WHERE id=?", (event_id,))
        self.log("undo", {"event_id": event_id}, actor)
        self.rebuild()

    def rebuild(self):
        """Recompute every projection table from the non-undone events."""
        for t in ("node", "node_version", "edge", "case_memory", "signature", "artifact", "solution", "lesson"):
            self.con.execute("DELETE FROM %s" % t)
        self.cache = {}
        for h in self.hooks:
            h.reset()
        for eid, kind, payload in self.con.execute(
                "SELECT id,kind,payload FROM event WHERE undone=0 AND kind<>'undo' ORDER BY id"):
            pl = json.loads(payload)
            self._project(eid, kind, pl)
            for h in self.hooks:
                h.project(eid, kind, pl)
        self.con.commit()

    def snapshot(self, path):
        bk = sqlite3.connect(path)
        self.con.commit()
        self.con.backup(bk)
        bk.close()
