"""PPO option for the reproduction search (the architecture names "RL Agent (PPO) - search params").

Same interface and budgets as `optimizer.Optimizer` (search() -> the same result dict; minimize()), same reward
(stage + closeness from the oracle) and the same safety deny-list. The agent is a clipped-surrogate policy-gradient
learner (Schulman et al., 2017, "Proximal Policy Optimization Algorithms", arXiv 1707.06347) over the SAME discrete
action set as the bandit search: the mutation operators. State = the current scenario (normalised timing, length,
power state) plus the last reward and stage; the policy is a linear-softmax over 20 features (no deep network, so
it trains inside one search of a few hundred trials and needs no GPU or framework); advantages by GAE (lambda 0.95,
gamma 0.9); clip 0.2; 4 epochs per batch of 24 steps; entropy bonus 0.01. The archive / Go-Explore restart and the
Wilson confirmation are shared with the bandit search. Measured against the bandit on the synthetic device model in
docs/PROVENANCE_AUDIT.md (section "optimizer"). Pure Python + math.
"""
import math
import random
import time

from optimizer import OPERATORS, Optimizer, is_safe, mutate, wilson_lower

POWER = ("none", "L1", "L1.2", "D3hot", "APST")
TIMING = (("qd", 256.0), ("inter_cmd_us", 5000.0), ("bs_kb", 1024.0), ("burst_len", 128.0), ("idle_gap_ms", 2000.0))
N_FEAT = 1 + len(TIMING) + 1 + len(POWER) + 2 + len(OPERATORS)   # bias, timing, len, power one-hot, last reward, stage, last op one-hot


def features(sc, last_r, last_stage, last_op):
    t = sc["timing"]
    f = [1.0] + [min(1.0, float(t.get(k, 0)) / hi) for k, hi in TIMING] + [min(1.0, len(sc["commands"]) / 24.0)]
    f += [1.0 if sc.get("power_state", "none") == p else 0.0 for p in POWER]
    f += [last_r / 5.0, last_stage / 4.0]
    f += [1.0 if last_op == o else 0.0 for o in OPERATORS]
    return f


class PPOOptimizer(Optimizer):
    """Keeps Optimizer's archive, reward, evaluate(), confirm and minimize; replaces pick_operator/pick_parent by a
    PPO-trained policy over operators (the parent is the current scenario; a Go-Explore restart happens on plateau)."""

    def __init__(self, oracle, seed_sc, budget=120, rng_seed=0, confirm_n=8, confirm_min_lower=0.5, ranges=None,
                 propose_fn=None, extra_seeds=None, time_budget_s=None, lr=0.05, clip=0.2, gamma=0.9, lam=0.95,
                 epochs=4, batch=24, entropy=0.01):
        super().__init__(oracle, seed_sc, budget=budget, rng_seed=rng_seed, confirm_n=confirm_n, confirm_min_lower=confirm_min_lower,
                         ranges=ranges, propose_fn=propose_fn, extra_seeds=extra_seeds, time_budget_s=time_budget_s)
        self.rng = random.Random(rng_seed)
        self.theta = [[0.0] * N_FEAT for _ in OPERATORS]        # policy weights (actions x features)
        self.w_v = [0.0] * N_FEAT                                 # value head
        self.lr, self.clip, self.gamma, self.lam, self.epochs, self.batch, self.entropy = lr, clip, gamma, lam, epochs, batch, entropy
        self.updates = 0
        self.current, self.current_r, self.stagnation = None, 0.0, 0

    # ------------------------------------------------------------------ policy
    def _logits(self, f):
        return [sum(w * x for w, x in zip(row, f)) for row in self.theta]

    def _probs(self, f):
        lg = self._logits(f)
        m = max(lg)
        e = [math.exp(v - m) for v in lg]
        z = sum(e)
        return [v / z for v in e]

    def _value(self, f):
        return sum(w * x for w, x in zip(self.w_v, f))

    def _update(self, traj):
        """traj: list of (features, action index, old prob, reward, value). GAE + clipped surrogate, `epochs` passes."""
        adv, ret, g, nxt_v = [0.0] * len(traj), [0.0] * len(traj), 0.0, 0.0
        for i in range(len(traj) - 1, -1, -1):
            f, a, p_old, r, v = traj[i]
            delta = r + self.gamma * nxt_v - v
            g = delta + self.gamma * self.lam * g
            adv[i], ret[i], nxt_v = g, g + v, v
        m = sum(adv) / len(adv)
        sd = math.sqrt(sum((x - m) ** 2 for x in adv) / len(adv)) or 1.0
        adv = [(x - m) / sd for x in adv]
        for _ in range(self.epochs):
            for (f, a, p_old, r, v), A, R in zip(traj, adv, ret):
                pr = self._probs(f)
                ratio = pr[a] / max(p_old, 1e-8)
                clipped = (A > 0 and ratio > 1 + self.clip) or (A < 0 and ratio < 1 - self.clip)
                if not clipped:                              # d/dtheta [ratio * A] = ratio * A * dlog pi
                    for k in range(len(OPERATORS)):
                        coef = ratio * A * ((1.0 if k == a else 0.0) - pr[k]) + self.entropy * (-pr[k] * (math.log(pr[k] + 1e-8) + 1.0))
                        row = self.theta[k]
                        for j, x in enumerate(f):
                            row[j] += self.lr * coef * x
                err = R - self._value(f)                      # value regression
                for j, x in enumerate(f):
                    self.w_v[j] += 0.5 * self.lr * err * x
        self.updates += 1

    def finish(self, sc, k, n, status):
        out = super().finish(sc, k, n, status)
        out["policy_updates"] = self.updates
        out["policy"] = "ppo"
        return out

    # ------------------------------------------------------------------ search
    def search(self):
        self.t_start = time.time()
        self.cell_n = {}
        self.patience = 25
        if not is_safe(self.seed_sc):
            return self.finish(self.seed_sc, 0, 0, "unsafe_seed")
        best_sc, best_r = self.seed_sc, -1.0
        for sc in [self.seed_sc] + list(self.extra_seeds):
            if len(self.trials) >= self.budget or not is_safe(sc):
                continue
            r, res = self.evaluate(sc, "seed")
            if r > best_r:
                best_sc, best_r = sc, r
            if res["reproduced"] and len(self.trials) + self.confirm_n <= self.budget:
                k = sum(int(self.evaluate(sc, "confirm")[1]["reproduced"]) for _ in range(self.confirm_n))
                if wilson_lower(k, self.confirm_n) >= self.confirm_min_lower:
                    return self.finish(sc, k, self.confirm_n, "confirmed")
        cur, cur_r, cur_stage, last_op, stale, traj = best_sc, best_r, 0, None, 0, []
        while len(self.trials) < self.budget and not self._timed_out():
            f = features(cur, cur_r, cur_stage, last_op)
            pr = self._probs(f)
            a = self.rng.choices(range(len(OPERATORS)), weights=pr)[0]
            op = OPERATORS[a]
            other = self.rng.choice([t["scenario"] for t in self.trials]) if op == "crossover" and self.trials else None
            child = mutate(cur, op, self.rng, other, self.ranges)
            if not is_safe(child):
                continue
            r, res = self.evaluate(child, op)
            step_r = (r - cur_r) + (2.0 if res["reproduced"] else 0.0)      # improvement + bonus for a reproduction
            traj.append((f, a, pr[a], step_r, self._value(f)))
            if r >= cur_r - 1e-9:                            # accept equal-or-better (walk plateaus), as the bandit does
                cur, cur_r, cur_stage, stale = child, r, res["stage"], (stale + 1 if r <= cur_r + 1e-9 else 0)
            else:
                stale += 1
            last_op = op
            if r > best_r:
                best_sc, best_r = child, r
            if res["reproduced"] and len(self.trials) + self.confirm_n <= self.budget:
                k = sum(int(self.evaluate(child, "confirm")[1]["reproduced"]) for _ in range(self.confirm_n))
                if wilson_lower(k, self.confirm_n) >= self.confirm_min_lower:
                    if traj:
                        self._update(traj)
                    return self.finish(child, k, self.confirm_n, "confirmed")
            if len(traj) >= self.batch:
                self._update(traj)
                traj = []
            if stale >= self.patience and self.archive:      # Go-Explore style restart from a Thompson-sampled archive cell
                self.stagnation = self.patience
                cur, stale = self.pick_parent(), 0
                cur_r, cur_stage = self.current_r, 0
        if traj:
            self._update(traj)
        k = n = 0
        if best_r >= 3.0 and len(self.trials) < self.budget:
            for _ in range(min(self.confirm_n, max(1, self.budget - len(self.trials)))):
                k += int(self.evaluate(best_sc, "confirm")[1]["reproduced"])
                n += 1
        return self.finish(best_sc, k, n, "triage_timeout" if self._timed_out() else "budget_exhausted")
