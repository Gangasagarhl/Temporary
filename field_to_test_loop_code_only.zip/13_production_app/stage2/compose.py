"""Test composition from the stored knowledge (stage 2 v3 add-on).

When the database holds one or more admin-approved / execution-validated procedures for an isolated error, the admin
can ask for test cases that recreate the same mistake: the LLM COMPOSES up to three variants from those stored
sequences and the packet evidence; code validates every variant (op vocabulary, timing ranges, power state, no
duplicate of a stored sequence); each variant is RUN on the bench and kept only if it reproduces; kept variants go
through the closed loop and are filed as regression tests that name their sources and rationale. The LLM never
changes a ledger status; composed variants are 'validated-by-execution', never auto-approved (so they never displace
the admin's approved procedure - approval stays a two-person decision).  Research: research_notes_v3/llm_test_composition.md
"""
import json
import re

from llm_adapter import ALLOWED_OPS
from stage2_pipeline import vhash

TIMING_RANGES = {"inter_cmd_us": (1, 5000), "burst_len": (1, 128), "idle_gap_ms": (0, 2000), "qd": (1, 256), "bs_kb": (4, 1024)}
TIMING_DEFAULTS = {"inter_cmd_us": 50, "burst_len": 16, "idle_gap_ms": 0, "qd": 8, "bs_kb": 4}
POWER_STATES = ("none", "L1", "L1.2", "D3hot", "APST")
MAX_VARIANTS = 3

COMPOSE_SCHEMA = {
    "type": "object",
    "properties": {
        "summary": {"type": "string", "description": "<= 2 sentences: the mistake and how the variants recreate it; cite packets as #N"},
        "variants": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "<= 8 words"},
                    "rationale": {"type": "string", "description": "<= 2 sentences citing packets as #N and sources as S#"},
                    "commands": {"type": "array", "items": {"type": "string"}},
                    "timing": {"type": "object",
                               "properties": {"inter_cmd_us": {"type": "integer"}, "burst_len": {"type": "integer"},
                                              "idle_gap_ms": {"type": "integer"}, "qd": {"type": "integer"}, "bs_kb": {"type": "integer"}},
                               "required": ["inter_cmd_us", "burst_len", "idle_gap_ms", "qd", "bs_kb"]},
                    "power_state": {"type": "string"},
                    "expected_packets": {"type": "array", "items": {"type": "string"},
                                         "description": "packet kinds the analyzer must show when the mistake is recreated"},
                    "sources_used": {"type": "array", "items": {"type": "string"}, "description": "S ids"},
                    "risks": {"type": "array", "items": {"type": "string"}},
                },
                "required": ["name", "rationale", "commands", "timing", "power_state", "expected_packets", "sources_used", "risks"],
            },
        },
    },
    "required": ["summary", "variants"],
}

COMPOSE_ROLE = ("You are a senior SSD/PCIe validation engineer writing regression tests. The team's knowledge base holds command "
                "sequences that reproduced an isolated defect in the lab and were judged by an admin. Compose test cases that "
                "recreate the SAME mistake again from that knowledge and the packet evidence. Use ONLY the allowed commands; never "
                "format, sanitize or firmware commands. Cite packet numbers only from the evidence.")


def content_key(commands, timing, power_state):
    ops = [c["op"] if isinstance(c, dict) else str(c) for c in commands]
    return json.dumps({"c": ops, "t": {k: int(timing.get(k, TIMING_DEFAULTS[k])) for k in TIMING_RANGES}, "p": power_state or "none"}, sort_keys=True)


def sources_for(db, graph, sig, family, k_family=2):
    """The stored knowledge for this error: approved procedures first, then execution-validated ones, then up to
    k_family approved exemplars of the same failure family. Returns (sources, n_same_error)."""
    out, seen = [], set()

    def add(sol, origin):
        if sol["vhash"] in seen:
            return
        seen.add(sol["vhash"])
        sc = sol["scenario"]
        e = graph.edges("REPRODUCED_BY", dst="scn::" + sol["vhash"]) if graph is not None else []
        out.append({"vhash": sol["vhash"], "sig": sol["sig"], "cause": sol["cause"], "origin": origin,
                    "commands": [c["op"] if isinstance(c, dict) else c for c in sc.get("commands", [])],
                    "timing": dict(sc.get("timing") or {}), "power_state": sc.get("power_state", "none"),
                    "status": sol["status"], "approved_by": sol.get("approved_by"), "repro_lower95": sol.get("repro_lower95"),
                    "feedback_posterior": round(e[0]["posterior"], 2) if e else None, "feedback_n": e[0]["n"] if e else 0})

    for st in ("admin-approved", "validated-by-execution"):
        for sol in db.solutions(sig, None, st):
            add(sol, "this error")
    n_same = len(out)
    if family:
        for c in db.approved_cases():
            if len(out) >= n_same + k_family:
                break
            if c["sig"] != sig and (db.signature(c["sig"]) or {}).get("pattern") == family:
                full = next((x for x in db.solutions(c["sig"], None, "admin-approved") if x["vhash"] == c["vhash"]), None)
                if full:
                    add(full, "same failure family (%s)" % c["sig"])
    return out, n_same


def build_compose_prompt(inc_text, card, family, rule_def, sources, lessons, headline=None, mechanism=None, n_variants=MAX_VARIANTS):
    parts = [COMPOSE_ROLE, "", "FAILURE CARD: %s   family/pattern: %s" % (card, family)]
    if headline:
        parts.append("WHAT THE PACKETS SHOWED: %s %s" % (headline, mechanism or ""))
    if rule_def:
        parts.append("RULE / CARD KNOWLEDGE:\n" + rule_def[:1200])
    parts.append("STORED SEQUENCES (the admin's knowledge for this error; cite as S1..; compose FROM these):")
    for i, s in enumerate(sources):
        parts.append("S%d origin=%s status=%s approved_by=%s repro_lower95=%s admin_feedback=%s/%s commands=%s timing=%s power_state=%s" % (
            i + 1, s["origin"], s["status"], s.get("approved_by"), s.get("repro_lower95"), s.get("feedback_posterior"), s.get("feedback_n"),
            json.dumps(s["commands"]), json.dumps(s["timing"], sort_keys=True), s["power_state"]))
    if lessons:
        parts.append("LESSONS (append-only, with provenance):")
        for l in lessons[-8:]:
            parts.append("- [%s] %s" % (l["producer"], l["text"]))
    parts.append("EVIDENCE (stage 1):\n" + inc_text)
    parts.append("TASK: Compose %d test variants that recreate this defect. Each variant = ordered commands (allowed: %s), "
                 "timing {inter_cmd_us 1-5000, burst_len 1-128, idle_gap_ms 0-2000, qd 1-256, bs_kb 4-1024}, power_state "
                 "(none|L1|L1.2|D3hot|APST). Every variant must DIFFER from every stored sequence and from the other variants in "
                 "at least one command or timing value, so that each adds coverage: V1 = the most robust recreation (the trigger of "
                 "the best source plus the precondition the evidence shows), V2 = the same trigger at the timing boundary the "
                 "stored sequences still reproduce, V3 = a different command path to the same device state. For each give: name "
                 "(<= 8 words), rationale (<= 2 sentences citing packets as #N and sources as S#), expected_packets (the packet "
                 "kinds the analyzer must show when the mistake is recreated, e.g. 'CfgWr0 PMCSR D3hot', 'MRd within 10 ms', "
                 "'Cpl status UR'), sources_used (S ids), risks. Also a summary (<= 2 sentences). Output JSON only."
                 % (n_variants, ", ".join(sorted(ALLOWED_OPS))))
    return "\n\n".join(parts)


def standin_variants(sources, n=MAX_VARIANTS):
    """Deterministic composition without a model (tests, offline): precondition + stored trigger, the stored trigger at
    tighter timing, and either two stored paths in sequence or the trigger after a longer idle."""
    base = sources[0]
    t, cmds = dict(base["timing"]), list(base["commands"])
    pre = "flush" if cmds[:1] != ["flush"] else "identify"
    v1 = {"name": "precondition then stored trigger", "rationale": "stand-in: %s before the stored trigger (S1)" % pre,
          "commands": [pre] + cmds, "timing": t, "power_state": base["power_state"], "expected_packets": [], "sources_used": ["S1"], "risks": []}
    t2 = dict(t)
    t2["inter_cmd_us"] = max(1, int(t.get("inter_cmd_us", 50)) // 2)
    v2 = {"name": "stored trigger at tighter timing", "rationale": "stand-in: S1 with half the inter-command gap",
          "commands": cmds, "timing": t2, "power_state": base["power_state"], "expected_packets": [], "sources_used": ["S1"], "risks": []}
    if len(sources) > 1:
        v3 = {"name": "two stored paths in sequence", "rationale": "stand-in: S1 followed by S2 under S1 timing",
              "commands": cmds + list(sources[1]["commands"]), "timing": t, "power_state": base["power_state"], "expected_packets": [],
              "sources_used": ["S1", "S2"], "risks": []}
    else:
        t3 = dict(t)
        t3["idle_gap_ms"] = min(2000, int(t.get("idle_gap_ms", 0)) * 2 + 100)
        v3 = {"name": "stored trigger after a longer idle", "rationale": "stand-in: S1 after a longer idle gap",
              "commands": cmds, "timing": t3, "power_state": base["power_state"], "expected_packets": [], "sources_used": ["S1"], "risks": []}
    return {"summary": "stand-in composition from %d stored sequence(s)" % len(sources), "variants": [v1, v2, v3][:n]}


def clean_scenario(sc):
    """Validate / repair one admin-authored scenario. Returns (scenario, problems, fatal): fatal when a command is outside
    the vocabulary (format, sanitize, firmware ... can never reach a bench) or no command is left."""
    problems = []
    cmds = [str(c["op"] if isinstance(c, dict) else c).lower().strip() for c in (sc or {}).get("commands") or []]
    bad = [c for c in cmds if c not in ALLOWED_OPS]
    if bad:
        return None, ["commands outside the vocabulary: %s" % bad[:4]], True
    if not cmds:
        return None, ["no command"], True
    t = (sc or {}).get("timing") if isinstance((sc or {}).get("timing"), dict) else {}
    timing = {}
    for k, (lo, hi) in TIMING_RANGES.items():
        try:
            val = int(t.get(k, TIMING_DEFAULTS[k]))
        except (TypeError, ValueError):
            val, _ = TIMING_DEFAULTS[k], problems.append("timing %s not a number; default used" % k)
        if not lo <= val <= hi:
            problems.append("timing %s=%s clamped to [%d, %d]" % (k, val, lo, hi))
            val = min(hi, max(lo, val))
        timing[k] = val
    pw = str((sc or {}).get("power_state") or "none")
    if pw not in POWER_STATES:
        problems.append("power_state %s unknown; none used" % pw)
        pw = "none"
    return {"commands": [{"op": c} for c in cmds[:24]], "timing": timing, "power_state": pw}, problems, False


def clean_variants(raw, sources, max_n=MAX_VARIANTS):
    """Code-side validation and repair of the LLM output. Returns (variants, problems)."""
    problems, out = [], []
    seen = {content_key(s["commands"], s["timing"], s["power_state"]) for s in sources}
    if not isinstance(raw, dict) or "_error" in raw:
        return [], ["not JSON: %s" % (raw.get("_error") if isinstance(raw, dict) else type(raw).__name__)]
    for i, v in enumerate(raw.get("variants") or []):
        if not isinstance(v, dict):
            continue
        name = str(v.get("name") or "variant %d" % (i + 1))[:60]
        cmds = [str(c).lower().strip() for c in (v.get("commands") or [])]
        bad = [c for c in cmds if c not in ALLOWED_OPS]
        if bad:
            problems.append("%s: unknown commands %s dropped" % (name, bad[:4]))
        cmds = [c for c in cmds if c in ALLOWED_OPS][:24]
        if not cmds:
            problems.append("%s: no valid command; dropped" % name)
            continue
        t = v.get("timing") if isinstance(v.get("timing"), dict) else {}
        timing = {}
        for k, (lo, hi) in TIMING_RANGES.items():
            try:
                val = int(t.get(k, TIMING_DEFAULTS[k]))
            except (TypeError, ValueError):
                val = TIMING_DEFAULTS[k]
            if not lo <= val <= hi:
                problems.append("%s: timing %s=%s clamped to [%d, %d]" % (name, k, val, lo, hi))
                val = min(hi, max(lo, val))
            timing[k] = val
        pw = str(v.get("power_state") or "none")
        pw = pw if pw in POWER_STATES else "none"
        key = content_key(cmds, timing, pw)
        if key in seen:
            problems.append("%s: identical to a stored sequence or another variant; dropped" % name)
            continue
        seen.add(key)
        used = []
        for s in v.get("sources_used") or []:
            m = re.match(r"\s*S(\d+)", str(s))
            if m and 0 < int(m.group(1)) <= len(sources):
                used.append(sources[int(m.group(1)) - 1]["vhash"])
        sc = {"commands": [{"op": c} for c in cmds], "timing": timing, "power_state": pw}
        out.append({"name": name, "rationale": str(v.get("rationale") or "")[:400], "scenario": sc, "vhash": vhash(sc),
                    "expected_packets": [str(x)[:60] for x in (v.get("expected_packets") or [])][:8],
                    "sources_used": sorted(set(used)), "risks": [str(x)[:120] for x in (v.get("risks") or [])][:4]})
        if len(out) >= max_n:
            break
    return out, problems
