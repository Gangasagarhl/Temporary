"""Admin presentation (v3): "seen before?" + the recommended procedure + test preview + top-5 alternatives,
with Claude Haiku 5.5 (effort low) extracting only the necessary and exact content, verified by code.

The card is built deterministically first (retrieval + graph); the LLM adds a short digest and may re-order
near-ties (listwise rerank, Borda-combined with the retrieval order so one model call can never dominate).
Everything the LLM emits is checked: packet citations must exist in the evidence, commands must be allowed,
timings within range; failures are reported next to the card, never silently dropped.
"""
import json

from admin_actions import available
from llm_adapter import ALLOWED_OPS, StandInLLM
from integration import render_shell
from oracle import TIMING_KEYS

DIGEST_SCHEMA = {
    "type": "object",
    "properties": {
        "headline": {"type": "string", "description": "<= 25 words: what failed and the trigger, for the admin"},
        "seen_before_assessment": {"type": "string", "enum": ["same_defect", "related", "new", "unsure"]},
        "key_packets": {"type": "array", "items": {"type": "integer"}, "description": "packet numbers from EVIDENCE only"},
        "mechanism": {"type": "string", "description": "<= 2 sentences, cite packets as #N"},
        "recommended_sequence": {
            "type": "object",
            "properties": {"commands": {"type": "array", "items": {"type": "string"}},
                           "timing": {"type": "object",
                                      "properties": {"inter_cmd_us": {"type": "integer"}, "qd": {"type": "integer"},
                                                     "bs_kb": {"type": "integer"}, "burst_len": {"type": "integer"},
                                                     "idle_gap_ms": {"type": "integer"}},
                                      "required": ["inter_cmd_us", "qd", "bs_kb", "burst_len", "idle_gap_ms"]},
                           "power_state": {"type": "string"}},
            "required": ["commands", "timing", "power_state"]},
        "differences_vs_stored": {"type": "array", "items": {"type": "string"}},
        "risks": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["headline", "seen_before_assessment", "key_packets", "mechanism", "recommended_sequence",
                 "differences_vs_stored", "risks"],
}
RERANK_SCHEMA = {"type": "object",
                 "properties": {"order": {"type": "array", "items": {"type": "integer"}}, "reason": {"type": "string"}},
                 "required": ["order", "reason"]}


STATUS_WORD = {"admin-approved": "approved", "validated-by-execution": "reproduced in the lab, not yet approved",
               "proposed": "proposed, not yet run in the lab", "superseded": "replaced by a newer version",
               "deprecated": "retired", "failed-validation": "did not reproduce in the lab"}


def _status_word(status):
    return STATUS_WORD.get(status, status or "unknown status")


def _repro_words(low, what="lab runs"):
    """'showed the error in at least 40 % of lab runs' from the Wilson lower bound, or '' when not run yet."""
    try:
        return "showed the error in at least %d %% of %s" % (int(round(float(low) * 100)), what)
    except (TypeError, ValueError):
        return "not yet run in the lab"


def _judged_words(a, b, n):
    """'admins said Correct N times, Not correct M times' from the Beta counts (both start at 1), or 'not judged yet'."""
    if not n:
        return "not judged yet"
    ok = max(0, int(round((a or 1.0) - 1.0)))
    bad = max(0, int(round((b or 1.0) - 1.0)))
    return "admins said Correct %d time%s, Not correct %d time%s" % (ok, "" if ok == 1 else "s", bad, "" if bad == 1 else "s")


def _summary(c):
    """The fields the screen needs to describe a candidate in plain words (the label is kept for logs and old views)."""
    pay = c.get("payload") or {}
    if c["kind"] == "solution":
        sc = pay.get("scenario") or {}
        return {"kind": "procedure", "commands": [x["op"] if isinstance(x, dict) else str(x) for x in sc.get("commands", [])],
                "timing": sc.get("timing") or {}, "power_state": sc.get("power_state", "none"), "status": pay.get("status"),
                "approved_by": pay.get("approved_by"), "repro_lower95": pay.get("repro_lower95")}
    if c["kind"] == "cause":
        return {"kind": "cause", "text": (pay.get("text") or "")[:200]}
    if c["kind"] == "lesson":
        return {"kind": "note", "text": (pay.get("text") or "")[:200]}
    return {"kind": c["kind"]}


def _label(c):
    if c["kind"] == "solution":
        sc = (c.get("payload") or {}).get("scenario") or {}
        ops = [x["op"] if isinstance(x, dict) else str(x) for x in sc.get("commands", [])]
        t = sc.get("timing") or {}
        pay = c.get("payload") or {}
        return "saved procedure: %s - queue depth %s, %s us apart (%s; %s)" % (
            ", ".join(ops) or "no commands", t.get("qd", "?"), t.get("inter_cmd_us", "?"),
            _status_word(pay.get("status")), _repro_words(pay.get("repro_lower95")))
    if c["kind"] == "cause":
        txt = (c.get("payload") or {}).get("text") or json.dumps(c.get("payload") or {})[:80]
        return "possible cause: %s" % txt[:90]
    if c["kind"] == "lesson":
        return "note: %s" % ((c.get("payload") or {}).get("text") or "")[:90]
    if c["kind"] == "case":
        return "an earlier capture with error type %s" % c["sig"]
    return "error type %s" % c["sig"]


def _diff_fields(q, stored_fp):
    out = []
    for k in ("card", "family", "rule", "layer", "origin", "verdict", "context_hash"):
        a, b = q.get(k), (stored_fp or {}).get(k)
        if a != b and (a or b):
            out.append("%s: now %s, stored %s" % (k, a, b))
    return out


def build_card(inc, q, shown, seen, best, graph, evidence_text, allowed_packets, rule_def="", lessons=None,
               llm=None, llm_rerank=True, counters=None):
    """Returns the admin card (dict). `shown` from HybridIndex.query, `seen`/`best` from seen_before."""
    counters = counters if counters is not None else {}
    rec = None
    if best is not None and best["kind"] == "solution":
        sol = best["payload"]
        # a superseded procedure is never the recommendation: show the CURRENT procedure under the same cause instead
        # (admin-approved first, else validated-by-execution). Approval of a sibling supersedes without a SUPERSEDES edge.
        if graph is not None and sol.get("status") in ("superseded", "deprecated", "failed-validation"):
            cur = None
            for statuses in (("admin-approved",), ("validated-by-execution",)):
                cur = next((pr for pr in graph.procedures_for(sol["sig"], statuses)
                            if pr["cause"] == sol["cause"] or str(pr["cause"]).endswith("::" + str(sol["cause"]))), None)
                if cur:
                    break
            if cur:
                props = (graph.node(cur["scenario_id"]) or {}).get("props") or {}
                vh = cur["scenario_id"][5:]
                sol = dict(sol, vhash=vh, scenario=cur.get("scenario") or sol["scenario"], status=cur["scenario_status"],
                           approved_by=props.get("approved_by"), repro_lower95=cur.get("repro_lower95"))
                best = dict(best, doc_id="sol::" + vh, vhash=vh, payload=sol,
                            why=list(best.get("why") or []) + ["an older version matched; showing the current version"])
        sc = sol["scenario"]
        edges = graph.edges("REPRODUCED_BY", dst="scn::" + best["vhash"]) if graph else []
        tests = graph.tests_for("scn::" + best["vhash"]) if graph else []
        rec = {"doc_id": best["doc_id"], "vhash": best["vhash"], "cause": best["cause"], "status": sol.get("status"),
               "approved_by": sol.get("approved_by"), "repro_lower95": sol.get("repro_lower95"),
               "procedure": (edges[0]["props"].get("procedure") if edges else None) or
                            [{"i": i, "op": c["op"] if isinstance(c, dict) else c} for i, c in enumerate(sc["commands"])],
               "timing": sc.get("timing"), "power_state": sc.get("power_state", "none"),
               "edge_posterior": edges[0]["posterior"] if edges else None, "edge_n": edges[0]["n"] if edges else 0,
               "judged_correct": max(0, int(round(edges[0]["a"] - 1.0))) if edges else 0,
               "judged_not_correct": max(0, int(round(edges[0]["b"] - 1.0))) if edges else 0,
               "judged": _judged_words(edges[0]["a"] if edges else None, edges[0]["b"] if edges else None, edges[0]["n"] if edges else 0),
               "tests": [{"id": t["dst"], "admitted": (t.get("test") or {}).get("props", {}).get("admitted")} for t in tests],
               "test_preview": render_shell(inc.card, best["cause"] or "c0",
                                            {"commands": [{"op": c["op"] if isinstance(c, dict) else c} for c in sc["commands"]],
                                             "timing": sc.get("timing"), "power_state": sc.get("power_state", "none")}),
               "what_changed_vs_stored": _diff_fields(q, sc.get("_fingerprint")),
               "why": best["why"]}
    alts = []
    for i, c in enumerate(shown):
        alts.append({"rank": i + 1, "doc_id": c["doc_id"], "kind": c["kind"], "sig": c["sig"], "cause": c["cause"],
                     "vhash": c["vhash"], "label": _label(c), "score": c["score"], "posterior": c["posterior"], "n": c["n"],
                     "explore": bool(c.get("explore")), "why": c["why"], "summary": _summary(c)})
    fa = inc.first_abnormal or {}
    card = {"incident": inc.id, "card": inc.card, "pattern": inc.pattern, "firmware": inc.firmware, "layer": inc.layer,
            "origin": inc.origin, "verdict": inc.verdict,
            "seen_before": {"verdict": seen, "label": _seen_label(seen, q, best), "score": best["fused"] if best else 0.0,
                            "basis": best["why"] if best else ["no stored procedure matches"]},
            "recommended": rec, "alternatives": alts,
            "evidence_digest": {"first_abnormal": fa, "packets": inc.packets, "evidence_packets": inc.evidence_packets[:12],
                                "rows": sum(len(b["rows"]) for b in (inc.rows or []))},
            "lessons": lessons or [], "actions": available(seen, bool(shown)), "llm": None, "llm_problems": []}
    if llm is None:
        return card
    # ---------------- LLM digest (extract only what the admin needs), verified by code
    prompt = _digest_prompt(card, evidence_text, rule_def)
    out, cached = llm.generate_json(prompt, DIGEST_SCHEMA, allow_tools=True)   # the baseline (recommended_sequence) may use web search when enabled
    counters["llm_calls"] = counters.get("llm_calls", 0) + (0 if cached else 1)
    if not isinstance(out, dict) or "_error" in out:
        card["llm_problems"].append("digest failed: %s" % (out or {}).get("_error"))
        counters["llm_invalid"] = counters.get("llm_invalid", 0) + 1
        return card
    problems = []
    pk = [int(p) for p in out.get("key_packets", []) if str(p).lstrip("-").isdigit()]
    bad = [p for p in pk if allowed_packets and p not in allowed_packets]
    if bad:
        problems.append("cited packets not in evidence: %s" % bad[:5])
        counters["citation_violations"] = counters.get("citation_violations", 0) + 1
    rs = out.get("recommended_sequence") or {}
    cmds = [str(c).lower().strip() for c in rs.get("commands", [])]
    unk = [c for c in cmds if c not in ALLOWED_OPS]
    if unk:
        problems.append("unknown ops %s" % unk)
    t = rs.get("timing") or {}
    for k, (lo, hi) in TIMING_KEYS.items():
        v = t.get(k)
        if isinstance(v, int) and not lo <= v <= hi:
            problems.append("timing %s out of range" % k)
    card["llm"] = {"headline": str(out.get("headline", ""))[:300], "seen_before_assessment": out.get("seen_before_assessment"),
                   "agrees_with_matcher": _agrees(out.get("seen_before_assessment"), seen),
                   "key_packets": [p for p in pk if p not in bad], "mechanism": str(out.get("mechanism", ""))[:600],
                   "recommended_sequence": {"commands": [c for c in cmds if c in ALLOWED_OPS], "timing": t,
                                            "power_state": rs.get("power_state", "none")},
                   "differences_vs_stored": [str(x)[:200] for x in out.get("differences_vs_stored", [])][:6],
                   "risks": [str(x)[:200] for x in out.get("risks", [])][:6],
                   "model": getattr(llm, "name", "?"), "cached": cached}
    card["llm_problems"] = problems
    # ---------------- optional listwise rerank of near-ties (only when the retrieval order is not decisive)
    if llm_rerank and len(alts) >= 3 and not isinstance(llm, StandInLLM):
        near_tie = (alts[0]["score"] - alts[1]["score"]) / max(alts[0]["score"], 1e-9) < 0.05
        if seen == "ambiguous" or near_tie:
            order = _llm_rerank(llm, card, evidence_text, counters)
            if order:
                card["alternatives"] = order
                card["rerank"] = "borda(retrieval, llm)"
    return card


def _seen_label(seen, q, best):
    """What the admin reads: match -> yes; ambiguous -> same card other context, or a related procedure; new -> no."""
    if seen == "match":
        return "Seen before on this firmware - the saved procedure applies"
    if seen == "new" or best is None:
        return "Not seen before - a procedure will be proposed from the packets"
    f = best["fields"]
    if f.get("card") == q.get("card"):
        if f.get("context_hash") == q.get("context_hash"):
            return "Seen before on this firmware, but a different rule fired first - start from the saved procedure"
        return "Seen before on another firmware - start from the saved procedure"
    if q.get("family") and f.get("family") == q.get("family"):
        return "Not seen before, but error type %s fails the same way and has a procedure" % f.get("card")
    return "Not seen before, but a capture with the same packet pattern (%s) has a procedure" % f.get("card")


def _agrees(assess, seen):
    return {"same_defect": "match", "related": "ambiguous", "new": "new"}.get(assess) == seen


def _digest_prompt(card, evidence_text, rule_def):
    parts = ["INCIDENT %s  card %s  pattern %s  firmware %s  layer %s  origin %s  stage-1 verdict %s" % (
        card["incident"], card["card"], card["pattern"], card["firmware"], card["layer"], card["origin"], card["verdict"])]
    parts.append("RETRIEVAL SAYS seen_before=%s (%s; score %.2f): %s" % (card["seen_before"]["verdict"], card["seen_before"]["label"],
                                                                         card["seen_before"]["score"], "; ".join(card["seen_before"]["basis"][:3])))
    if rule_def:
        parts.append("RULE / CARD KNOWLEDGE:\n" + rule_def[:900])
    r = card["recommended"]
    if r:
        parts.append("STORED PROCEDURE (status %s, repro lower95 %s, admin feedback posterior %s over %s): steps=%s timing=%s power=%s" % (
            r["status"], r["repro_lower95"], r["edge_posterior"], r["edge_n"],
            json.dumps([s["op"] for s in r["procedure"]]), json.dumps(r["timing"]), r["power_state"]))
        if r["what_changed_vs_stored"]:
            parts.append("CONTEXT DIFFERENCES vs stored: " + "; ".join(r["what_changed_vs_stored"]))
    if card["alternatives"]:
        parts.append("TOP CANDIDATES (retrieval order):\n" + "\n".join(
            "%d. %s | score %.2f posterior %.2f n=%d" % (a["rank"], a["label"], a["score"], a["posterior"], a["n"]) for a in card["alternatives"]))
    if card["lessons"]:
        parts.append("LESSONS:\n" + "\n".join("- [%s] %s" % (l.get("producer"), l.get("text")) for l in card["lessons"][:5]))
    parts.append("EVIDENCE (stage 1, cite only these packet numbers):\n" + evidence_text)
    parts.append("TASK: Fill the schema for the admin. headline <= 25 words. seen_before_assessment: same_defect if the stored "
                 "procedure's defect and context match this evidence, related if same card/family but different context or "
                 "variant, new if nothing stored applies, unsure otherwise. key_packets: the 2-6 packets that decide it. "
                 "mechanism: <= 2 sentences citing packets as #N. recommended_sequence: the stored procedure if it applies, "
                 "else the smallest allowed command sequence and timing the evidence supports (integers; inter_cmd_us 1-5000, "
                 "qd 1-256, bs_kb 4-1024, burst_len 1-128, idle_gap_ms 0-2000; power_state none|L1|L1.2|D3hot|APST). "
                 "differences_vs_stored: what differs from the stored procedure (empty if none). risks: destructive or "
                 "flaky steps. Do not pad; do not invent packets or commands.")
    return "\n\n".join(parts)


def _llm_rerank(llm, card, evidence_text, counters):
    alts = card["alternatives"]
    prompt = ("Order these candidate causes/procedures from most to least likely to explain and reproduce the incident. "
              "Answer with the 1-based indexes in your order (all of them, each once) and one sentence of reason.\n\n"
              "INCIDENT %s card %s pattern %s\nEVIDENCE:\n%s\n\nCANDIDATES:\n%s" % (
                  card["incident"], card["card"], card["pattern"], evidence_text[:3000],
                  "\n".join("%d. %s" % (a["rank"], a["label"]) for a in alts)))
    out, cached = llm.generate_json(prompt, RERANK_SCHEMA)
    counters["llm_calls"] = counters.get("llm_calls", 0) + (0 if cached else 1)
    if not isinstance(out, dict) or "_error" in out:
        return None
    order = [int(i) for i in out.get("order", []) if isinstance(i, int) and 1 <= int(i) <= len(alts)]
    if len(set(order)) != len(alts):
        counters["rerank_invalid"] = counters.get("rerank_invalid", 0) + 1
        return None
    # Borda: retrieval rank + LLM rank, lower is better; retrieval breaks ties
    llm_rank = {idx: r for r, idx in enumerate(order)}
    scored = sorted(alts, key=lambda a: (a["rank"] - 1 + llm_rank[a["rank"]], a["rank"]))
    for i, a in enumerate(scored):
        a["rank_retrieval"], a["rank_llm"], a["rank"] = a["rank"], llm_rank[a["rank"]] + 1, i + 1
    card["rerank_reason"] = str(out.get("reason", ""))[:300]
    return scored


def render_markdown(card):
    L = ["# Incident %s - card %s (%s)" % (card["incident"], card["card"], card["pattern"]), ""]
    sb = card["seen_before"]
    L.append("**Seen before: %s** - %s" % (sb["label"], "; ".join(sb["basis"][:2])))
    if card.get("llm"):
        l = card["llm"]
        L += ["", "**%s**" % l["headline"], "", l["mechanism"], "",
              "AI reviewer's reading: %s (%s with the database lookup), key packets %s" % (
                  l["seen_before_assessment"], "agrees" if l["agrees_with_matcher"] else "disagrees", l["key_packets"])]
        if card["llm_problems"]:
            L.append("Problems in the AI reviewer's answer caught by code: " + "; ".join(card["llm_problems"]))
    r = card["recommended"]
    if r:
        L += ["", "## Saved procedure (%s; %s; %s)" % (
            _status_word(r["status"]), _repro_words(r["repro_lower95"]),
            r.get("judged") or _judged_words(None, None, r.get("edge_n", 0))),
              "steps: " + " -> ".join(s["op"] for s in r["procedure"]), "timing: %s  power: %s" % (r["timing"], r["power_state"])]
        if r["what_changed_vs_stored"]:
            L.append("changed vs stored: " + "; ".join(r["what_changed_vs_stored"]))
        L += ["", "```bash", r["test_preview"].strip(), "```"]
    L += ["", "## Top candidates"]
    for a in card["alternatives"]:
        L.append("%d. %s%s" % (a["rank"], a["label"], "  (shown to give a less-tried procedure a chance)" if a["explore"] else ""))
    L += ["", "Actions: " + ", ".join(card["actions"])]
    return "\n".join(L)
