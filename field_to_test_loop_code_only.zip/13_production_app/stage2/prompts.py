"""Prompt construction for the inference-only LLM (evidence-packaging findings applied):
  key packets first; pre-decoded compact rows; the firing rule's definition and the atlas card's own
  'test to provoke it'; the stored solution when one exists; admin-approved exemplars of the same family
  chosen by similarity x posterior with one exploration pick; lessons with provenance; the question repeated
  at the end; citations restricted to listed packet numbers.
Two passes for small models: pass 1 free-text reasoning (no schema), pass 2 flat JSON with the schema.
"""
import json
import random

ROLE = ("You are a senior SSD/PCIe validation engineer. From an isolated defect (stage-1 output) and the team's "
        "knowledge base you propose the command sequence and timing most likely to reproduce the failure signature "
        "in the lab. Use ONLY the evidence and knowledge given. Cite packet numbers only from the evidence list. "
        "Allowed commands: read, write, flush, trim, write_zeroes, reset, power_cycle, aspm_idle, identify, get_log, "
        "set_feature, abort. Never propose format, sanitize or firmware commands.")


def exemplars_for(db, sig, family, k=3, rng=None):
    """Exemplar bank: admin-approved solutions, same signature first, then same family; one exploration pick."""
    rng = rng or random.Random(0)
    cases = db.approved_cases()
    same = [c for c in cases if c["sig"] == sig]
    fam = [c for c in cases if c["sig"] != sig and c.get("family") == family] if family else []
    pool = same + fam
    scored = []
    for c in pool:
        e = db.edge(c["sig"], c["cause"])
        post = e["a"] / (e["a"] + e["b"])
        scored.append((post * (1.0 if c["sig"] == sig else 0.6), c))
    scored.sort(key=lambda x: -x[0])
    chosen = [c for _, c in scored[:max(0, k - 1)]]
    rest = [c for _, c in scored[k - 1:]]
    if rest:                                           # exploration pick: Thompson over the remaining
        chosen.append(max(rest, key=lambda c: rng.betavariate(db.edge(c["sig"], c["cause"])["a"],
                                                              db.edge(c["sig"], c["cause"])["b"])))
    return chosen


def build_prompt(inc_text, card, rule_def, stored, exemplars, lessons, family, mode, pass_no=1, pass1_text=None):
    """mode: reuse | adapt | generate."""
    parts = [ROLE, ""]
    parts.append("TASK MODE: %s" % {"reuse": "a validated solution exists for this exact defect and context - "
                                            "check it against the evidence; reuse it unless the evidence contradicts it",
                                    "adapt": "a validated solution exists for a near-duplicate (other context or "
                                             "variant) - adapt its parameters to this evidence, keep its structure",
                                    "generate": "no earlier solution - derive the scenario from the evidence and the "
                                                "card's known trigger"}[mode])
    parts.append("FAILURE CARD: %s   family/pattern: %s" % (card, family))
    if rule_def:
        parts.append("RULE / CARD KNOWLEDGE:\n" + rule_def[:1200])
    if stored:
        parts.append("STORED_SOLUTION (status %s, repro lower95 %s, producer %s):\nSTORED_SOLUTION_JSON=%s" % (
            stored["status"], stored.get("repro_lower95"), stored.get("producer"),
            json.dumps(stored["scenario"], sort_keys=True)))
    if exemplars:
        parts.append("APPROVED EXEMPLARS (same signature or family; cite as E1..):")
        for i, c in enumerate(exemplars):
            parts.append("E%d sig=%s cause=%s repro=%s scenario=%s" % (i + 1, c["sig"], c["cause"],
                                                                   c.get("repro_lower95"), json.dumps(c["scenario"])))
    if lessons:
        parts.append("LESSONS (append-only, with provenance):")
        for l in lessons:
            parts.append("- [%s] %s" % (l["producer"], l["text"]))
    parts.append("EVIDENCE (stage 1):\n" + inc_text)
    if pass_no == 1:
        parts.append("QUESTION: Reason step by step in plain text (max 12 lines): which mechanism the evidence shows "
                     "(cite packets), whether the stored solution/exemplars apply, and the command order, queue depth, "
                     "block size, inter-command timing, idle gap and power state that should trigger it. Then stop.")
    else:
        parts.append("YOUR REASONING (pass 1):\n" + (pass1_text or "")[:2500])
        parts.append("QUESTION: Now output ONLY JSON with keys: cause, reasoning (1 sentence), commands (ordered list "
                     "of allowed commands), timing {inter_cmd_us, burst_len, idle_gap_ms, qd, bs_kb}, power_state "
                     "(none|L1|L1.2|D3hot|APST), parameter_ranges {name: [lo, hi]} for the values you are unsure of, "
                     "evidence_packets (packet numbers from EVIDENCE only), reuses_stored_solution (true/false).")
    return "\n\n".join(parts)
