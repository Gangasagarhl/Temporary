"""Stage 1 -> Stage 2 hand-over.

Reads the defect-isolation engine's run folder (10_defect_isolation_engine/runs/<run>/):
  incidents.json       one object per isolated defect: packet range, first abnormal rule, verdict, layer,
                       ranked atlas candidates, attribution, task, nvme_commands, explanation
  incident_rows.jsonl  the evidence rows (±context) per incident, already compacted for an LLM
  llm_prompts.jsonl    the engine's own review prompt per incident (static_prefix + user text)
and turns each into the Stage-2 `Incident` the knowledge loop consumes.

Nothing here depends on the synthetic benchmark; point it at a real run folder in production.
"""
import json
import os
import re


class Incident:
    __slots__ = ("id", "card", "candidates", "verdict", "layer", "pattern", "origin", "task", "first_abnormal",
                 "packets", "evidence_packets", "rows", "explanation", "nvme_commands", "tokens", "firmware", "raw")

    def __init__(self, **kw):
        for k in self.__slots__:
            setattr(self, k, kw.get(k))

    def to_obs(self):
        """The observable record the ranking policy sees (same shape as the benchmark 'obs')."""
        return {"tokens": self.tokens,
                "detector": {"card_hint": self.card, "verdict": self.verdict,
                             "confidence": self.candidates[0]["score"] if self.candidates else 0.0},
                "retrieval": [(c["card_id"], c["score"]) for c in self.candidates[:5]],
                "context": {"firmware": self.firmware, "time_s": 0.0}, "admin_id": "admin", "pattern": self.pattern}


STOP = set("the a an of in on to for and or with by is are be not no from at as its it this that into than".split())


def _tokens(inc):
    t = set()
    for c in inc.get("atlas_candidates", [])[:1]:
        t.add("card:" + c["card_id"])
    ex = inc.get("explanation") or {}
    if ex.get("pattern"):
        t.add("pat:" + ex["pattern"])
    if inc.get("layer"):
        t.add("layer:" + inc["layer"])
    for r in inc.get("rules", {}):
        t.add("rule:" + r)
    for w in re.findall(r"[a-z][a-z0-9_]{2,}", (ex.get("title") or "").lower()):
        if w not in STOP:
            t.add("w:" + w)
    return sorted(t)


def load_run(run_dir, firmware="FW-A"):
    incs = json.load(open(os.path.join(run_dir, "incidents.json")))
    rows = {}
    p = os.path.join(run_dir, "incident_rows.jsonl")
    if os.path.exists(p):
        for line in open(p):
            d = json.loads(line)
            rows[d["id"]] = d["blocks"]
    out = []
    for i in incs:
        cands = i.get("atlas_candidates", [])
        ex = i.get("explanation") or {}
        out.append(Incident(
            id=i["id"], card=cands[0]["card_id"] if cands else None, candidates=cands, verdict=i.get("verdict"),
            layer=i.get("layer"), pattern=ex.get("pattern"), origin=(i.get("attribution") or {}).get("origin"),
            task=i.get("task"), first_abnormal=i.get("first_abnormal"), packets=(i.get("start_pkt"), i.get("end_pkt")),
            evidence_packets=sorted({i.get("first_abnormal", {}).get("pkt")} | {int(x) for x in re.findall(
                r"@(\d+)", json.dumps(i.get("rules", {})))} - {None}),
            rows=rows.get(i["id"], []), explanation=ex, nvme_commands=i.get("nvme_commands", []),
            tokens=_tokens(i), firmware=firmware, raw=i))
    return out


LINK_EVENT_WORDS = ("NAK", "Recovery", "Retrain", "Replay", "TS1", "TS2", "EIOS", "EIEOS", "UpdateFC")


def signature_of(inc, workload=None, device=None):
    """The failure signature (checklist H4): device/firmware/workload context, phase, command, latency class, the
    preceding packets and the link events around the first abnormal packet. Keyed by the atlas card and first rule."""
    fa = inc.first_abnormal or {}
    rows = [r for b in (inc.rows or []) for r in b.get("rows", [])]
    kinds, before, after = [], [], []
    fa_pkt = fa.get("pkt")
    for r in rows:
        m = re.search(r"(?:TLP Type|DLLP Type|Ord\.Set Type|Link Event)=([^|]+)", r)
        if not m:
            continue
        k = m.group(1).strip()
        kinds.append(k)
        mp = re.match(r"Packet=(\d+)", r)
        pk = int(mp.group(1)) if mp else None
        (before if (pk is None or fa_pkt is None or pk < fa_pkt) else after).append(k)
    link = {w: sum(1 for r in rows if w in r) for w in LINK_EVENT_WORDS}
    link = {k: v for k, v in link.items() if v}
    rule = fa.get("rule") or ""
    latency = ("timeout" if "TIMEOUT" in rule.upper() or "CTO" in rule.upper() else
               "slow" if any(w in rule.upper() for w in ("LATE", "SLOW", "LONG", "WAIT", "EARLY", "STORM")) else "n/a")
    cmd = None
    for c in inc.nvme_commands or []:
        cmd = c.get("opcode_name") or c.get("name") or c.get("opc") if isinstance(c, dict) else str(c)
        if cmd:
            break
    raw = inc.raw or {}
    wl = raw.get("workload") or {}
    return {"signature_id": "sig-%s-%s" % (inc.id, inc.card or "none"), "card": inc.card, "family": inc.pattern,
            "rule": rule or None, "layer": inc.layer, "origin": inc.origin, "verdict": inc.verdict, "firmware": inc.firmware,
            "workload": workload or wl.get("assessment") or wl.get("workload"), "phase": wl.get("phase") or inc.layer,
            "command": cmd or wl.get("component"), "latency_class": latency if not wl else (wl.get("symptom") or latency),
            "metric": wl.get("metric_id"), "observed": wl.get("observed"), "baseline": wl.get("baseline"),
            "device": device or (wl.get("device") if wl else None), "preceding_packets": before[-12:], "following_packets": after[:6],
            "all_packet_kinds": kinds[:16], "latency_class_basis": "keyword heuristic on the rule name",
            "link_events": link, "first_abnormal_packet": fa.get("pkt"), "detail": fa.get("detail")}


def evidence_text(inc, max_rows=60):
    """Compact evidence block for the LLM: key packets first, then the rows around them."""
    lines = ["INCIDENT %s  packets %s-%s  verdict %s  layer %s  origin %s" % (
        inc.id, inc.packets[0], inc.packets[1], inc.verdict, inc.layer, inc.origin)]
    wl = (inc.raw or {}).get("workload") if inc.raw else None
    if wl:                                             # workload artifact (ADK / PCMark): no packets, the metric evidence instead
        lines.append("WORKLOAD %s  phase %s  component %s" % (wl.get("assessment") or wl.get("workload"), wl.get("phase"), wl.get("component")))
        lines.append("abnormality: %s" % (wl.get("statement") or wl.get("title")))
        lines.append("metric %s observed %s %s vs baseline %s (spread %s, n %s); delta %s (robust z %s); confidence %s" % (
            wl.get("metric_id"), wl.get("observed"), wl.get("unit") or "", wl.get("baseline"), wl.get("spread"), wl.get("baseline_n"),
            wl.get("delta"), wl.get("robust_z"), wl.get("confidence")))
        for e in (wl.get("evidence") or [])[:6]:
            lines.append("evidence: %s" % json.dumps(e)[:220])
        if wl.get("hypothesis"):
            lines.append("stage-1 hypothesis: %s" % wl["hypothesis"])
        if wl.get("change_points"):
            lines.append("firmware change points: %s" % "; ".join(str(x) for x in wl["change_points"])[:400])
    fa = inc.first_abnormal or {}
    lines.append("first abnormal: #%s %s - %s" % (fa.get("pkt"), fa.get("rule"), fa.get("detail")))
    lines.append("task: %s" % inc.task)
    lines.append("candidates: " + "; ".join("%s %s (%.2f)" % (c["card_id"], c.get("title", "")[:60], c["score"])
                                            for c in inc.candidates[:3]))
    n = 0
    for blk in inc.rows:
        lines.append("ROWS %d..%d" % tuple(blk["range"]))
        for r in blk["rows"]:
            lines.append(r if len(r) < 220 else r[:217] + "...")
            n += 1
            if n >= max_rows:
                lines.append("... (%d more rows omitted)" % (sum(len(b["rows"]) for b in inc.rows) - n))
                return "\n".join(lines)
    return "\n".join(lines)
