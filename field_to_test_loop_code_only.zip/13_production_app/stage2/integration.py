"""Stage 2 - Integration: optimized trigger -> executable test scripts -> gate -> validation suite.

Scripts are rendered from templates (no LLM). They must pass: static checks, allow/deny lists, and a
canary gate (fails on the known-bad model, 0 hits in n runs on the fixed model) before entering the
suite manifest. Traceability: signature -> cause -> scenario version -> script -> gate result.
"""
import json
import math
import os
import re
import shlex

ALLOWED_NVME = {"read", "write", "flush", "dsm", "write-zeroes", "reset", "id-ctrl", "get-log", "set-feature",
                "admin-passthru", "io-passthru", "list", "smart-log", "error-log"}
DENY_PATTERNS = [r"\bformat\b", r"\bsanitize\b", r"fw-(download|commit|activate)", r"delete-ns", r"\bdd\b.*of=/dev/"]
OP_TO_FIO = {"read": "randread", "write": "randwrite", "trim": "trim", "write_zeroes": "write"}


def render_fio(sig, cause, sc, device="/dev/nvme0n1"):
    jobs = ["[global]", "ioengine=io_uring", "direct=1", "filename=%s" % device, "time_based=0",
            "iodepth=%d" % sc["timing"]["qd"], "bs=%dk" % sc["timing"]["bs_kb"], "thinktime=%dus" % sc["timing"]["inter_cmd_us"],
            "verify=crc32c", "verify_fatal=1", "# signature=%s cause=%s" % (sig, cause), ""]
    for i, c in enumerate(sc["commands"]):
        op = c["op"]
        if op in OP_TO_FIO:
            jobs += ["[step%02d_%s]" % (i, op), "rw=%s" % OP_TO_FIO[op], "number_ios=%d" % sc["timing"]["burst_len"],
                     "stonewall", ""]
        elif op == "flush":
            jobs += ["[step%02d_flush]" % i, "rw=write", "fsync=1", "number_ios=1", "stonewall", ""]
    return "\n".join(jobs)


def render_shell(sig, cause, sc, device="/dev/nvme0", ns="/dev/nvme0n1"):
    lines = ["#!/usr/bin/env bash", "set -euo pipefail", "# generated test for %s / %s" % (sig, cause),
             "DEV=%s; NS=%s" % (shlex.quote(device), shlex.quote(ns)),
             'IDLE_MS=%d' % sc["timing"]["idle_gap_ms"]]
    if sc["power_state"] != "none":
        lines.append("# precondition: device in %s (configure via sysfs/setpci per platform; not automated here)"
                     % sc["power_state"])
    for i, c in enumerate(sc["commands"]):
        op = c["op"]
        if op in ("read", "write", "trim", "write_zeroes", "flush"):
            lines.append("fio step%02d.fio --section=step%02d_%s" % (i, i, op) if op != "flush" else
                         "fio step%02d.fio --section=step%02d_flush" % (i, i))
        elif op == "reset":
            lines.append('nvme reset "$DEV"')
        elif op == "identify":
            lines.append('nvme id-ctrl "$DEV" > /dev/null')
        elif op == "get_log":
            lines.append('nvme smart-log "$DEV" > /dev/null')
        elif op == "set_feature":
            lines.append('nvme set-feature "$DEV" -f 0x07 -v 0x00030003 > /dev/null   # Number of Queues (benign)')
        elif op == "abort":
            lines.append('nvme admin-passthru "$DEV" --opcode=0x08 --cdw10=0x00010001 > /dev/null || true')
        elif op == "power_cycle":
            lines.append('pdu_power_cycle "$DEV"   # lab PDU helper; drive must be in the scratch set')
        elif op == "aspm_idle":
            lines.append('sleep "$((IDLE_MS/1000 + 1))"')
        if sc["timing"]["idle_gap_ms"]:
            lines.append('sleep "$(awk "BEGIN{print $IDLE_MS/1000}")"')
    lines.append('echo "run complete: export analyzer trace and run the detector for %s"' % sig)
    return "\n".join(lines) + "\n"


def render_pytest(sig, cause, sc, repro):
    body = '''"""Regression test generated from field signature %(sig)s (cause %(cause)s).
Oracle: detector must NOT report %(sig)s CONFIRMED on fixed firmware; canary run on known-bad firmware must."""
import json, subprocess, pytest

SCENARIO = %(sc)s
REPRO_LOWER95 = %(repro)s   # measured reproduction rate (Wilson lower bound) when generated
REPEATS = %(repeats)d        # chosen so that 0 hits bounds the leak rate below the target

@pytest.mark.signature("%(sig)s")
@pytest.mark.parametrize("rep", range(REPEATS))
def test_signature_absent_after_fix(rep, bench):
    trace = bench.run(SCENARIO)                      # fixture: executes scenario, exports analyzer CSV
    findings = bench.detect(trace)                   # fixture: 10_defect_isolation_engine on the CSV
    hits = [f for f in findings if f["card_id"] == "%(sig)s" and f["verdict"] == "CONFIRMED"]
    assert not hits, "signature %(sig)s reproduced on supposedly fixed firmware: %%s" %% hits

@pytest.mark.canary
def test_canary_known_bad(bench_known_bad):
    k = sum(1 for _ in range(%(canary_n)d)
            if any(f["card_id"] == "%(sig)s" and f["verdict"] == "CONFIRMED"
                   for f in bench_known_bad.detect(bench_known_bad.run(SCENARIO))))
    assert k >= %(canary_k)d, "canary lost: the test no longer triggers the known defect"
'''
    if 0 < repro < 1:
        repeats = max(3, int(math.ceil(math.log(0.05) / math.log(1 - repro))))   # 0 hits in n => leak < 5%
    else:
        repeats = 3 if repro >= 1 else 10
    return body % {"sig": sig, "cause": cause, "sc": json.dumps(sc, indent=1), "repro": repro,
                   "repeats": min(repeats, 60), "canary_n": 10, "canary_k": max(2, int(10 * repro * 0.6))}


def static_checks(files):
    problems = []
    for path, text in files.items():
        for pat in DENY_PATTERNS:
            if re.search(pat, text):
                problems.append("%s: denied command pattern %r" % (os.path.basename(path), pat))
        if path.endswith(".sh"):
            for line in text.splitlines():
                m = re.match(r"\s*nvme\s+(\S+)", line)
                if m and m.group(1) not in ALLOWED_NVME:
                    problems.append("%s: nvme subcommand not on allow-list: %s" % (os.path.basename(path), m.group(1)))
        if path.endswith(".fio"):
            flags = {"stonewall", "group_reporting", "direct", "thread", "new_group", "wait_for_previous"}
            for line in text.splitlines():
                if line and not line.startswith(("[", "#")) and "=" not in line and line.strip() not in flags:
                    problems.append("%s: malformed fio line %r" % (os.path.basename(path), line))
    return problems


def gate(oracle_known_bad, oracle_fixed, sc, n=10, min_bad_hits=3):
    """Canary gate: the scenario must reproduce on the known-bad model and be silent on the fixed model."""
    bad = sum(int(oracle_known_bad.run(sc)["reproduced"]) for _ in range(n))
    fixed = sum(int(oracle_fixed.run(sc)["reproduced"]) for _ in range(n))
    return {"known_bad_hits": bad, "fixed_hits": fixed, "n": n,
            "passed": bad >= min_bad_hits and fixed == 0}


def emit(suite_dir, sig, cause, sc, repro_lower, gate_result):
    d = os.path.join(suite_dir, sig.replace("/", "_"))
    os.makedirs(d, exist_ok=True)
    files = {os.path.join(d, "scenario.fio"): render_fio(sig, cause, sc),
             os.path.join(d, "run.sh"): render_shell(sig, cause, sc),
             os.path.join(d, "test_%s.py" % sig.replace("-", "_")): render_pytest(sig, cause, sc, repro_lower)}
    problems = static_checks(files)
    if not problems:
        for p, t in files.items():
            open(p, "w").write(t)
    entry = {"signature": sig, "cause": cause, "scenario": sc, "repro_lower95": repro_lower,
             "gate": gate_result, "static_problems": problems,
             "admitted": gate_result["passed"] and not problems, "files": [os.path.basename(p) for p in files]}
    man = os.path.join(suite_dir, "suite_manifest.jsonl")
    with open(man, "a") as f:
        f.write(json.dumps(entry) + "\n")
    return entry
