"""Neighbourhood of a reproducing procedure for the vulnerability sweep (checklist H8 / "surrounding failure-prone areas")."""
from compose import TIMING_RANGES, POWER_STATES


PARAM_WORDS = {"inter_cmd_us": ("spacing between commands", " us"), "burst_len": ("burst length", ""),
               "idle_gap_ms": ("idle gap", " ms"), "qd": ("queue depth", ""), "bs_kb": ("block size", " kB")}
POWER_WORDS = {"none": "no low-power state", "L1": "ASPM L1", "L1.2": "ASPM L1.2", "D3hot": "D3hot", "APST": "APST"}


def neighbourhood(base):
    """Variants around `base`: each timing parameter x0.5 and x2 (clamped to the lab ranges), every other power state,
    the last command doubled (burst), and a long idle when the base has none. Each variant = one named change.
    `variation` is the short key used for matching (unchanged); `name` is the plain label the operator reads."""
    out = []
    t = base["timing"]
    for k, (lo, hi) in TIMING_RANGES.items():
        cur = int(t.get(k, lo))
        word, unit = PARAM_WORDS.get(k, (k, ""))
        for f, lbl, verb in ((0.5, "x0.5", "halved"), (2.0, "x2", "doubled")):
            nv = int(min(hi, max(lo, round(cur * f))))
            if nv != cur:
                nt = dict(t)
                nt[k] = nv
                out.append({"name": "%s %s (%d -> %d%s)" % (word, verb, cur, nv, unit), "variation": "%s %s" % (k, lbl),
                            "scenario": {"commands": [dict(c) for c in base["commands"]], "timing": nt, "power_state": base.get("power_state", "none")}})
    if not t.get("idle_gap_ms"):
        nt = dict(t)
        nt["idle_gap_ms"] = 500
        out.append({"name": "idle gap added (0 -> 500 ms)", "variation": "idle 500 ms", "scenario": {"commands": [dict(c) for c in base["commands"]], "timing": nt, "power_state": base.get("power_state", "none")}})
    for p in POWER_STATES:
        if p != base.get("power_state", "none"):
            out.append({"name": "power state %s before the sequence" % POWER_WORDS.get(p, p), "variation": "power %s" % p,
                        "scenario": {"commands": [dict(c) for c in base["commands"]], "timing": dict(t), "power_state": p}})
    if base["commands"]:
        cmds = [dict(c) for c in base["commands"]] + [dict(base["commands"][-1])]
        out.append({"name": "last command repeated (longer burst)", "variation": "burst +1 cmd",
                    "scenario": {"commands": cmds, "timing": dict(t), "power_state": base.get("power_state", "none")}})
    return out


def stress_of(base, variant):
    """How far the variant pushes beyond the base (larger = more stressful): ratio of the changed timing value, 2 for a
    power-state change, 1.5 for a longer command list, 2 for a jammer fault."""
    if variant.get("jammer"):
        return 2.0
    bt, vt = base["timing"], variant["scenario"]["timing"]
    for k in bt:
        if vt.get(k) != bt.get(k):
            if not bt.get(k):
                return 2.0
            r = vt[k] / float(bt[k])
            return r if r >= 1 else 1.0 / max(r, 1e-6) * 0.9
    if variant["scenario"].get("power_state") != base.get("power_state"):
        return 2.0
    if len(variant["scenario"]["commands"]) != len(base["commands"]):
        return 1.5
    return 1.0
