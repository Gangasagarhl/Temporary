"""The two rules of the system-architecture diagram, as named constants, and the "test score" they apply to.

    "Loop for best params; if test score > 0.9 [3 times consecutively] is considered as optimal params;
     > 10 mins (first level triage) is fail."

SCORE_THRESHOLD / OPTIMAL_CONSECUTIVE / FIRST_LEVEL_TRIAGE_S are reported against in every stage-2 result, the
closed-loop verdict and the KPI report.

`signature_score` is the "test score" of one lab run, written as checks passed out of 3. For every finding of the
stage-1 detector that isolated the expected error type (or an error type the detector cannot tell apart from it)
as CONFIRMED or SUSPECT, three plain checks are made:

    1. the same error type was isolated          (always true for such a finding)
    2. the same first rule fired                 (or no field rule was given, so the rule cannot be compared)
    3. the detector's verdict is CONFIRMED       (not merely SUSPECT)

score = checks passed / 3, rounded to 3 decimals; the best finding of the run counts; 0.0 when nothing matched.
So a run scores 1.0 (> 0.9) only when all three checks pass; a SUSPECT isolation or a different rule gives 0.667.
There are no weights and no closeness term: every number the operator sees is a count of checks.
"""
SCORE_THRESHOLD = 0.9          # "test score > 0.9"
OPTIMAL_CONSECUTIVE = 3        # "[3 times consecutively] is considered as optimal params"
FIRST_LEVEL_TRIAGE_S = 600     # "> 10 mins (first level triage) is fail"

N_CHECKS = 3


def score_checks(finding, expected_cards, field_rule=None):
    """The three checks for one detector finding, as plain booleans.
    A finding whose card is not expected, or whose verdict is neither CONFIRMED nor SUSPECT, fails all three."""
    f = finding or {}
    matched = f.get("card_id") in (expected_cards or ()) and f.get("verdict") in ("CONFIRMED", "SUSPECT")
    return {"same_error_type": bool(matched),
            "same_rule": bool(matched and (not field_rule or f.get("rule") == field_rule)),
            "confirmed": bool(matched and f.get("verdict") == "CONFIRMED")}


def _passed(checks):
    return sum(1 for v in checks.values() if v)


def best_finding(findings, expected_cards, field_rule=None):
    """The finding with the most checks passed (None when nothing matched) and its checks."""
    best, best_checks = None, None
    for f in findings or []:
        c = score_checks(f, expected_cards, field_rule)
        if not c["same_error_type"]:
            continue
        if best_checks is None or _passed(c) > _passed(best_checks):
            best, best_checks = f, c
    return best, best_checks


def signature_score(findings, expected_cards, field_rule=None):
    """Checks passed out of 3 for the best matching finding; 0.0 when no finding matched."""
    _, checks = best_finding(findings, expected_cards, field_rule)
    if checks is None:
        return 0.0
    return round(_passed(checks) / N_CHECKS, 3)


def consecutive_above(scores, threshold=SCORE_THRESHOLD):
    best = run = 0
    for s in scores:
        run = run + 1 if s > threshold else 0
        best = max(best, run)
    return best


def rules_summary():
    return {"score_threshold": SCORE_THRESHOLD, "optimal_consecutive": OPTIMAL_CONSECUTIVE,
            "first_level_triage_s": FIRST_LEVEL_TRIAGE_S,
            "text": "optimal = the same error type isolated by the same rule and confirmed (all 3 checks) in %d lab runs "
                    "in a row; the search stops after %d s (first-level triage limit)"
                    % (OPTIMAL_CONSECUTIVE, FIRST_LEVEL_TRIAGE_S)}
