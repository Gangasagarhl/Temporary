"""Stage 2 - Iterative Optimization without a trained agent.

Mimics the RL agent of the project statement with CPU-only online learning:
  seed        knowledge-based scenario from the admin-chosen cause node (template per failure family,
              atlas 'Test to provoke it' parameters) - replaces "the LLM's scenario"
  policy      Thompson-sampling bandit over MUTATION OPERATORS (which operator reproduces more)
  memory      Go-Explore style archive: best scenario per (stage, motif-signature) cell; parents drawn by
              Thompson over cells so promising-but-untested cells are revisited
  reward      staged signature distance  R = stage + closeness  (stage 0..4), shaped, dense
  noise       candidate reproducers are re-run (successive halving); reproduction rate reported with a
              Wilson lower bound, never a single lucky trial
  minimize    ddmin over commands, then bisection on timing, re-checking k-of-n each step
  safety      deny-list (format/sanitize/firmware), write budget, trial budget, time budget
"""
import math
import random
import time

from oracle import OPS, POWER, TIMING_KEYS

DENY_OPS = {"format", "sanitize", "fw_download", "fw_commit", "ns_delete"}
# the stressful direction of each timing value (ratio applied per step): tighter spacing, deeper queue, longer burst,
# bigger blocks, longer idle gap - the directions a drive is least likely to survive
STRESS_DIRECTION = {"inter_cmd_us": 0.5, "qd": 2.0, "burst_len": 2.0, "bs_kb": 2.0, "idle_gap_ms": 2.0}
# what each mutation operator does, in the operator's words (shown in "how the search went")
OPERATOR_WORDS = {"insert_cmd": "insert a command", "delete_cmd": "remove a command", "swap_cmds": "swap two commands",
                  "replace_cmd": "replace a command", "dup_cmd": "repeat a command", "mut_qd": "change the queue depth",
                  "mut_bs": "change the block size", "mut_inter_cmd": "change the spacing between commands",
                  "mut_burst": "change the burst length", "mut_idle": "change the idle gap", "mut_power": "change the power state",
                  "crossover": "combine two procedures", "nudge_timing": "small step on one timing value",
                  "step_timing": "jump one timing value to a standard point"}
OPERATORS = ["insert_cmd", "delete_cmd", "swap_cmds", "replace_cmd", "dup_cmd", "mut_qd", "mut_bs",
             "mut_inter_cmd", "mut_burst", "mut_idle", "mut_power", "crossover", "nudge_timing", "step_timing"]


def wilson_lower(k, n, z=1.96):
    if n == 0:
        return 0.0
    p = k / n
    d = 1 + z * z / n
    c = p + z * z / (2 * n)
    r = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return max(0.0, (c - r) / d)


def seed_scenario(cause_content, family):
    """Knowledge-based seed: the admin's chosen cause/scenario node content, or a family template."""
    tpl = {
        "P01": ["write", "read"], "P02": ["write", "flush", "read"], "P06": ["write", "write", "write"],
        "P08": ["aspm_idle", "read"], "P12": ["write", "power_cycle", "read"], "P13": ["reset", "identify"],
        "P16": ["write", "read", "read"], "P22": ["write", "write", "read"], "P23": ["write", "trim", "read"],
        "P24": ["write", "flush", "power_cycle", "read"],
    }
    ops = (cause_content or {}).get("commands") or tpl.get(family, ["write", "read"])
    timing = {"inter_cmd_us": 50, "burst_len": 16, "idle_gap_ms": 0, "qd": 8, "bs_kb": 4}
    timing.update((cause_content or {}).get("timing", {}))
    return {"commands": [{"op": o} for o in ops], "timing": timing,
            "power_state": (cause_content or {}).get("power_state", "none")}


def mutate(sc, op, rng, other=None, ranges=None):
    s = {"commands": [dict(c) for c in sc["commands"]], "timing": dict(sc["timing"]), "power_state": sc["power_state"]}
    cmds, t = s["commands"], s["timing"]
    if op == "insert_cmd":
        cmds.insert(rng.randint(0, len(cmds)), {"op": rng.choice(OPS)})
    elif op == "delete_cmd" and len(cmds) > 1:
        cmds.pop(rng.randrange(len(cmds)))
    elif op == "swap_cmds" and len(cmds) > 1:
        i, j = rng.sample(range(len(cmds)), 2)
        cmds[i], cmds[j] = cmds[j], cmds[i]
    elif op == "replace_cmd":
        cmds[rng.randrange(len(cmds))] = {"op": rng.choice(OPS)}
    elif op == "dup_cmd":
        i = rng.randrange(len(cmds))
        cmds.insert(i, dict(cmds[i]))
    elif op.startswith("mut_") and op != "mut_power":
        key = {"mut_qd": "qd", "mut_bs": "bs_kb", "mut_inter_cmd": "inter_cmd_us", "mut_burst": "burst_len",
               "mut_idle": "idle_gap_ms"}[op]
        lo, hi = TIMING_KEYS[key]
        if ranges and key in ranges and rng.random() < 0.7:        # LLM-proposed range (SLLMBO-style prior)
            rlo, rhi = ranges[key]
            lo, hi = max(lo, int(rlo)), min(hi, int(rhi)) if int(rhi) > int(rlo) else (lo, hi)
        if rng.random() < 0.5:
            t[key] = int(min(hi, max(lo, t[key] * rng.choice([0.25, 0.5, 2, 4]))))
        else:
            t[key] = int(lo + (hi - lo) * rng.random() ** 2)
    elif op == "mut_power":
        s["power_state"] = rng.choice(POWER)
    elif op == "nudge_timing":                                  # small local step on one timing value
        key = rng.choice(list(TIMING_KEYS))
        lo, hi = TIMING_KEYS[key]
        t[key] = int(min(hi, max(lo, round(t[key] * rng.choice([0.7, 0.85, 1.2, 1.5])))))
    elif op == "step_timing":                                   # move one value to a canonical grid point
        key = rng.choice(list(TIMING_KEYS))
        grid = {"inter_cmd_us": [1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000],
                "burst_len": [1, 4, 16, 64, 128], "idle_gap_ms": [0, 100, 200, 500, 1000, 2000],
                "qd": [1, 4, 8, 16, 32, 64, 128, 256], "bs_kb": [4, 64, 256, 1024]}[key]
        t[key] = rng.choice(grid)
    elif op == "crossover" and other:
        cut = rng.randint(0, len(cmds))
        cmds[:] = cmds[:cut] + [dict(c) for c in other["commands"][cut:]] or cmds
        for k in t:
            if rng.random() < 0.5:
                t[k] = other["timing"][k]
    if len(cmds) > 12:
        del cmds[12:]
    return s


def is_safe(sc):
    return not any(c["op"] in DENY_OPS for c in sc["commands"])


def cell_of(sc, res):
    return (res["stage"], tuple(sorted(set(c["op"] for c in sc["commands"]))))


class Optimizer:
    def __init__(self, oracle, seed_sc, budget=120, rng_seed=0, confirm_n=8, confirm_min_lower=0.5,
                 ranges=None, propose_fn=None, extra_seeds=None, time_budget_s=None):
        self.time_budget_s = time_budget_s          # wall-clock limit (first-level triage), None = trials only
        self.t_start = None
        self.oracle = oracle
        self.budget = budget
        self.rng = random.Random(rng_seed)
        self.confirm_n = confirm_n
        self.confirm_min_lower = confirm_min_lower
        self.op_ab = {o: [1.0, 1.0] for o in OPERATORS}      # Beta per mutation operator
        self.archive = {}                                    # cell -> (reward, scenario, result)
        self.trials = []
        self.seed_sc = seed_sc
        self.spent_s = 0.0
        self.ranges = ranges or {}
        self.propose_fn = propose_fn            # called on plateau: (best_scenario, trials) -> scenario or None
        self.extra_seeds = extra_seeds or []    # exemplar scenarios evaluated right after the seed
        self.proposals_used = 0

    def reward(self, res):
        return res["stage"] + res["closeness"]

    def evaluate(self, sc, tag=""):
        res = self.oracle.run(sc)
        self.spent_s += res["cost_s"]
        r = self.reward(res)
        self.trials.append({"n": len(self.trials) + 1, "tag": tag, "stage": res["stage"],
                            "closeness": res["closeness"], "reward": round(r, 3), "scenario": sc})
        cell = cell_of(sc, res)
        if cell not in self.archive or r > self.archive[cell][0]:
            self.archive[cell] = (r, sc, res)
        return r, res

    def pick_parent(self):
        """Hill-climb on the current scenario; after `patience` trials without improvement restart from a
        Thompson-sampled archive cell (Go-Explore stepping stone) and climb from there."""
        if self.current is not None and self.stagnation < self.patience:
            return self.current
        self.stagnation = 0
        best, best_v = None, -1
        for cell, (r, sc, res) in self.archive.items():
            n = self.cell_n.get(cell, 0)
            v = self.rng.betavariate(1 + 3 * r, 1 + (5 - r) + n * 0.3)
            if v > best_v:
                best, best_v = cell, v
        self.cell_n[best] = self.cell_n.get(best, 0) + 1
        self.current, self.current_r = self.archive[best][1], self.archive[best][0]
        return self.current

    def pick_operator(self):
        return max(OPERATORS, key=lambda o: self.rng.betavariate(*self.op_ab[o]))

    def _timed_out(self):
        return bool(self.time_budget_s) and (time.time() - self.t_start) > self.time_budget_s

    def search(self):
        self.t_start = time.time()
        self.cell_n = {}
        self.patience = 25
        if not is_safe(self.seed_sc):
            raise ValueError("seed scenario contains a denied operation")
        r0, res0 = self.evaluate(self.seed_sc, "seed")
        best_r, best_sc, best_res = r0, self.seed_sc, res0
        self.current, self.current_r, self.stagnation = self.seed_sc, r0, 0
        for sc in self.extra_seeds:                                  # knowledge-based extra seeds (exemplars)
            if len(self.trials) >= self.budget or not is_safe(sc):
                continue
            r, res = self.evaluate(sc, "exemplar")
            if r > best_r:
                best_r, best_sc, best_res = r, sc, res
                self.current, self.current_r, self.stagnation = sc, r, 0
            if res["reproduced"] and len(self.trials) + self.confirm_n <= self.budget:
                k = 1 + sum(int(self.evaluate(sc, "confirm")[1]["reproduced"]) for _ in range(self.confirm_n - 1))
                if wilson_lower(k, self.confirm_n) >= self.confirm_min_lower:
                    return self.finish(sc, k, self.confirm_n, "confirmed")
        while len(self.trials) < self.budget and not self._timed_out():
            if self.propose_fn and self.stagnation >= self.patience and self.proposals_used < 3:
                prop = self.propose_fn(best_sc, len(self.trials))          # LLM proposal on plateau only
                self.proposals_used += 1
                if prop and is_safe(prop):
                    r, res = self.evaluate(prop, "llm_proposal")
                    if r > self.current_r:
                        self.current, self.current_r, self.stagnation = prop, r, 0
                    if r > best_r:
                        best_r, best_sc, best_res = r, prop, res
                    continue
            parent = self.pick_parent()
            op = self.pick_operator()
            other = self.archive[self.rng.choice(list(self.archive))][1] if op == "crossover" else None
            child = mutate(parent, op, self.rng, other, self.ranges)
            if not is_safe(child):
                continue
            r, res = self.evaluate(child, op)
            improved = r > self.current_r + 1e-9
            self.op_ab[op][0 if improved else 1] += 1.0          # operator credit vs the parent
            if r >= self.current_r - 1e-9:                      # accept equal-or-better (walk plateaus)
                self.current, self.current_r = child, r
            self.stagnation = 0 if improved else self.stagnation + 1
            if r > best_r:
                best_r, best_sc, best_res = r, child, res
            if res["reproduced"] and len(self.trials) + self.confirm_n <= self.budget:
                k = 1
                for _ in range(self.confirm_n - 1):          # successive confirmation
                    rr, rres = self.evaluate(child, "confirm")
                    k += int(rres["reproduced"])
                lower = wilson_lower(k, self.confirm_n)
                if lower >= self.confirm_min_lower:
                    return self.finish(child, k, self.confirm_n, "confirmed")
        # best effort: confirm the best scenario found
        k = n = 0
        if best_res["reproduced"]:
            for _ in range(min(self.confirm_n, max(1, self.budget - len(self.trials)))):
                n += 1
                k += int(self.evaluate(best_sc, "confirm")[1]["reproduced"])
        return self.finish(best_sc, k, n, "triage_timeout" if self._timed_out() else "budget_exhausted")

    def finish(self, sc, k, n, status):
        return {"status": status, "best_scenario": sc, "repro_k": k, "repro_n": n,
                "repro_rate_lower95": round(wilson_lower(k, n), 3), "trials": len(self.trials),
                "simulated_time_s": round(self.spent_s, 1), "operator_stats": {o: ab[:] for o, ab in self.op_ab.items()},
                "archive_cells": len(self.archive), "best_reward": round(max((t["reward"] for t in self.trials), default=0.0), 3),
                "llm_proposals_used": self.proposals_used}

    # ------------------------------------------------------------------ most stressful trigger conditions
    def stress_ascent(self, sc, max_trials=30, deadline=None):
        """From a confirmed (and minimised) procedure, push each timing value one step in its stressful direction -
        commands closer together, deeper queue, longer burst, bigger blocks, longer idle gap - and keep the step only
        when the defect still reproduces (2 of 3 runs). Repeats until no value can be pushed further or the trial /
        time budget is used up. Returns the most stressful procedure that still triggers the defect, how far each value
        was pushed (ratio to the confirmed procedure) and the trials spent. This is the "most stressful trigger
        conditions" of the project statement; the regression test built from it guards the margin, not just the point."""
        cur = {"commands": [dict(c) for c in sc["commands"]], "timing": dict(sc["timing"]), "power_state": sc.get("power_state", "none")}
        pushed, steps, trials, progress = {}, [], 0, True
        while progress and trials + 3 <= max_trials and not (deadline and time.time() > deadline):
            progress = False
            for key, f in STRESS_DIRECTION.items():
                if trials + 3 > max_trials or (deadline and time.time() > deadline):
                    break
                lo, hi = TIMING_KEYS[key]
                v = int(cur["timing"].get(key, lo))
                if v == 0:
                    continue                                 # a value of 0 (no idle gap) has no stressful direction here
                nv = int(min(hi, max(lo, round(v * f))))
                if nv == v:
                    continue
                t2 = dict(cur["timing"])
                t2[key] = nv
                trial = {"commands": cur["commands"], "timing": t2, "power_state": cur["power_state"]}
                trials += 3
                kept = self.still_fails(trial)
                steps.append({"value": key, "from": v, "to": nv, "kept": kept})
                if kept:
                    cur = trial
                    pushed[key] = round(pushed.get(key, 1.0) * (f if f > 1 else 1.0 / f), 2)
                    progress = True
        stress = 1.0
        for ratio in pushed.values():
            stress *= ratio
        return {"scenario": cur, "pushed": pushed, "stress": round(stress, 2), "steps": steps, "trials": trials}

    # ------------------------------------------------------------------ minimization
    def still_fails(self, sc, n=3, need=2):
        return sum(int(self.oracle.run(sc)["reproduced"]) for _ in range(n)) >= need

    def minimize(self, sc):
        cmds = list(sc["commands"])
        changed = True
        while changed and len(cmds) > 1:
            changed = False
            for i in range(len(cmds)):
                trial = {"commands": cmds[:i] + cmds[i + 1:], "timing": sc["timing"], "power_state": sc["power_state"]}
                if self.still_fails(trial):
                    cmds = trial["commands"]
                    changed = True
                    break
        out = {"commands": cmds, "timing": dict(sc["timing"]), "power_state": sc["power_state"]}
        for key, (lo, hi) in TIMING_KEYS.items():        # relax each timing value toward its default
            default = {"inter_cmd_us": 50, "burst_len": 16, "idle_gap_ms": 0, "qd": 8, "bs_kb": 4}[key]
            cur = out["timing"][key]
            if cur != default:
                t2 = dict(out["timing"])
                t2[key] = default
                if self.still_fails({"commands": cmds, "timing": t2, "power_state": out["power_state"]}):
                    out["timing"] = t2
        if out["power_state"] != "none":
            t = dict(out)
            t["power_state"] = "none"
            if self.still_fails(t):
                out = t
        return out
