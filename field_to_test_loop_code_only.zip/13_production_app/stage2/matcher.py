"""Three-way recurrence matcher: is this incident the SAME defect as a stored, approved solution?

Signals (all training-free), fused by reciprocal rank fusion (k=60) over the stored cases:
  s_card   detector card id equal (1) / same failure family (0.5) / else 0
  s_fields structured-field match: first-abnormal rule, layer, origin, verdict
  s_rows   position-weighted longest-common-subsequence over evidence row "kinds" (ReBucket idea)
  s_ctx    context hash equal (firmware / platform)
Decision: fused score >= T_HI -> "match" (reuse), T_LO <= score < T_HI -> "ambiguous" (adapt, admin confirms),
          < T_LO -> "new" (generate). Thresholds are configuration, meant to be re-fitted on the admin's own
          "same defect?" answers (logged as events); defaults are conservative.
"""
import re

T_HI, T_LO = 0.70, 0.35
RRF_K = 60


def row_kinds(rows):
    kinds = []
    for r in rows:
        m = re.search(r"(TLP Type|DLLP Type|Ord\.Set Type|Link Event)=([^|]+)", r)
        if m:
            kinds.append(m.group(2).strip())
    return kinds[:60]


def lcs_weighted(a, b):
    """LCS over kinds, weighting matches near the END of the sequence (closest to the first abnormal row)."""
    if not a or not b:
        return 0.0
    n, m = len(a), len(b)
    dp = [[0.0] * (m + 1) for _ in range(n + 1)]
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if a[i - 1] == b[j - 1]:
                w = 0.5 + 0.5 * (i / n)
                dp[i][j] = dp[i - 1][j - 1] + w
            else:
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])
    return dp[n][m] / max(1e-9, sum(0.5 + 0.5 * (i / n) for i in range(1, n + 1)))


def fingerprint(incident_like):
    """incident_like: dict with card, family, rule, layer, origin, verdict, row_kinds, context_hash."""
    return {k: incident_like.get(k) for k in ("card", "family", "rule", "layer", "origin", "verdict", "row_kinds", "context_hash")}


def score_pair(q, c):
    s_card = 1.0 if q["card"] == c["card"] else (0.5 if q.get("family") and q.get("family") == c.get("family") else 0.0)
    f = [q.get("rule") == c.get("rule"), q.get("layer") == c.get("layer"), q.get("origin") == c.get("origin"),
         q.get("verdict") == c.get("verdict")]
    s_fields = sum(1 for x in f if x) / len(f)
    s_rows = lcs_weighted(q.get("row_kinds") or [], c.get("row_kinds") or [])
    s_ctx = 1.0 if q.get("context_hash") == c.get("context_hash") else 0.0
    return {"card": s_card, "fields": s_fields, "rows": s_rows, "ctx": s_ctx}


def classify(query, candidates, t_hi=T_HI, t_lo=T_LO):
    """candidates: list of (case_id, fingerprint). Returns (decision, best_case_id, fused_score, per_signal)."""
    if not candidates:
        return "new", None, 0.0, {}
    sig_scores = {cid: score_pair(query, fp) for cid, fp in candidates}
    fused = {cid: 0.0 for cid, _ in candidates}
    for name in ("card", "fields", "rows", "ctx"):
        ranked = sorted(sig_scores, key=lambda cid: -sig_scores[cid][name])
        for rank, cid in enumerate(ranked):
            if sig_scores[cid][name] > 0:
                fused[cid] += 1.0 / (RRF_K + rank + 1)
    best = max(fused, key=fused.get)
    # normalise RRF to [0,1] against the maximum possible (rank 1 on every signal)
    norm = fused[best] / (4.0 / (RRF_K + 1))
    s = sig_scores[best]
    # "match" needs the same card AND the same context; same card in another context, same family, or
    # strongly similar evidence rows are "ambiguous" (adapt + admin confirms); anything else is "new"
    if s["card"] >= 1.0 and s["ctx"] >= 1.0 and norm >= t_hi:
        decision = "match"
    elif s["card"] >= 0.5 or (s["rows"] >= 0.5 and s["fields"] >= 0.5 and norm >= t_lo):
        decision = "ambiguous"
    else:
        decision = "new"
    return decision, best, round(norm, 3), s
