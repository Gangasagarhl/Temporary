#!/usr/bin/env python3
"""Bandit search vs PPO option on the synthetic device model: same seeds, same budget, same reward.
Usage: python3 bench_optimizers.py [--budget 300] [--cards T-42,L-21,...] [--seeds 0,1]   -> prints a table + JSON."""
import argparse, json, random, sys, time, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from oracle import SyntheticDeviceOracle
from optimizer import Optimizer
from ppo_optimizer import PPOOptimizer
from llm_adapter import family_template_scenario

FAMILY = {"T-42": "P19", "L-21": "P06", "C-16": "P08", "M-039": "P13", "M-020": "P22", "S-01": "P01", "D-07": "P16", "X-14": "P08",
          "N-02": "P12", "L-15": "P02", "T-33": "P23", "P-03": "P24"}
ap = argparse.ArgumentParser()
ap.add_argument("--budget", type=int, default=300)
ap.add_argument("--cards", default=",".join(FAMILY))
ap.add_argument("--seeds", default="0,1")
a = ap.parse_args()
rows = []
for card in a.cards.split(","):
    fam = FAMILY.get(card, "P01")
    for seed in [int(x) for x in a.seeds.split(",")]:
        for kind, cls in (("bandit", Optimizer), ("ppo", PPOOptimizer)):
            oracle = SyntheticDeviceOracle(card, 0, seed=seed, family=fam)
            rng = random.Random(seed)
            seed_sc = family_template_scenario(fam)                      # same seed for both: the family template, nothing else
            seed_sc["timing"]["inter_cmd_us"] = rng.choice([20, 50, 200, 800])
            t0 = time.time()
            r = cls(oracle, seed_sc, budget=a.budget, rng_seed=seed).search()
            first = next((t["n"] for t in cls.__dict__ and [] or []), None)
            rows.append({"card": card, "seed": seed, "optimizer": kind, "status": r["status"], "trials": r["trials"],
                         "repro_k": r["repro_k"], "repro_n": r["repro_n"], "best_reward": r["best_reward"], "seconds": round(time.time() - t0, 2)})
by = {}
for r in rows:
    d = by.setdefault(r["optimizer"], {"runs": 0, "confirmed": 0, "trials_when_confirmed": [], "best_reward": []})
    d["runs"] += 1
    d["confirmed"] += r["status"] == "confirmed"
    if r["status"] == "confirmed":
        d["trials_when_confirmed"].append(r["trials"])
    d["best_reward"].append(r["best_reward"])
print("%-8s %6s %10s %18s %12s" % ("policy", "runs", "confirmed", "median trials (ok)", "mean reward"))
for k, d in by.items():
    tr = sorted(d["trials_when_confirmed"])
    med = (sorted(tr)[len(tr) // 2] if len(tr) % 2 else (sorted(tr)[len(tr) // 2 - 1] + sorted(tr)[len(tr) // 2]) / 2) if tr else None
    print("%-8s %6d %10d %18s %12.2f" % (k, d["runs"], d["confirmed"], med, sum(d["best_reward"]) / len(d["best_reward"])))
json.dump({"budget": a.budget, "rows": rows, "summary": {k: {"runs": d["runs"], "confirmed": d["confirmed"],
           "median_trials_when_confirmed": (sorted(d["trials_when_confirmed"])[len(d["trials_when_confirmed"]) // 2] if d["trials_when_confirmed"] else None),
           "mean_best_reward": round(sum(d["best_reward"]) / len(d["best_reward"]), 3)} for k, d in by.items()}},
          open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "bench_optimizers_result.json"), "w"), indent=1)
