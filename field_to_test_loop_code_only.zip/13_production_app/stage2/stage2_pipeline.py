"""Stage 2 v2 - from stage-1 incident to admitted regression test.

  1. recurrence check   exact (card, context) with an admin-approved solution -> REUSE
                        approved solution for the card in another context / variant   -> ADAPT
                        otherwise                                                       -> GENERATE
  2. knowledge          stored solution, exemplar bank (approved cases, same sig/family, similarity x posterior,
                        one exploration pick), lessons, rule/card knowledge
  3. LLM (inference)    two-pass (reason, then flat JSON) -> validated/cleaned; citations checked by code;
                        LLM verdict never changes ledger status; fallback = deterministic stand-in
  4. regression guard   in REUSE mode the stored solution is re-run first (canary); the LLM proposal is only
                        tried if the stored solution no longer reproduces; an approved solution is never
                        overwritten - a new version is proposed and must pass execution + admin approval
  5. search             optimizer seeded by the LLM scenario, exemplar seeds, LLM parameter ranges, LLM
                        re-proposals on plateau; staged signature-distance reward; confirmation re-runs
  6. admin confirm      correct -> solution_approve (four-eyes), tests rendered + gated + filed
"""
import hashlib
import json
import os

from integration import emit, gate
from llm_adapter import StandInLLM, check_output, pick_backend
from optimizer import Optimizer, seed_scenario
from oracle import SyntheticDeviceOracle
from prompts import build_prompt, exemplars_for
from matcher import classify as match_classify, row_kinds


def vhash(scenario):
    return hashlib.sha256(json.dumps(scenario, sort_keys=True).encode()).hexdigest()[:16]


def context_hash(firmware, extra=""):
    return hashlib.sha256(("%s|%s" % (firmware, extra)).encode()).hexdigest()[:12]


class Stage2:
    def __init__(self, db, llm=None, suite_dir=None, opt_budget=300, opt_seed=0, rule_defs=None,
                 use_llm=True, use_ledger=True, use_exemplars=True, oracle_factory=None, log_path=None,
                 max_llm_proposals=3):
        self.db = db
        self.llm = llm or StandInLLM()
        self.suite_dir = suite_dir
        self.opt_budget = opt_budget
        self.opt_seed = opt_seed
        self.rule_defs = rule_defs or {}
        self.use_llm, self.use_ledger, self.use_exemplars = use_llm, use_ledger, use_exemplars
        self.oracle_factory = oracle_factory or (lambda sig, variant, family: SyntheticDeviceOracle(
            sig, variant, seed=opt_seed, family=family))
        self.log = open(log_path, "a") if log_path else None
        self.max_llm_proposals = max_llm_proposals
        self.counters = {"reuse": 0, "adapt": 0, "generate": 0, "llm_calls": 0, "llm_cached": 0,
                         "llm_invalid": 0, "citation_violations": 0, "stored_still_reproduces": 0,
                         "stored_regressed": 0, "confirmed": 0, "gate_passed": 0, "zero_trial_repro": 0,
                         "trials_total": 0}

    # ------------------------------------------------------------------ 1. recurrence
    def classify(self, sig, cause, ctx, fingerprint=None):
        """reuse / adapt / generate. With a fingerprint (card, family, rule, layer, origin, verdict, row_kinds,
        context_hash) the three-way matcher decides over ALL approved solutions (match -> reuse, ambiguous ->
        adapt); without one, the exact (card, cause, context) ledger lookup is used."""
        if not self.use_ledger:
            return "generate", None
        appr = [s for s in self.db.solutions(sig, cause, "admin-approved")]
        if fingerprint is not None:
            cands = []
            for sol in self.db.solutions(sig, None, "admin-approved"):
                fp = sol["scenario"].get("_fingerprint") if isinstance(sol["scenario"], dict) else None
                cands.append((sol["vhash"], fp or {"card": sig, "family": fingerprint.get("family"),
                                                   "context_hash": sol["context_hash"]}))
            decision, best, score, sig_scores = match_classify(fingerprint, cands)
            self.counters["match_" + decision] = self.counters.get("match_" + decision, 0) + 1
            if decision == "match":
                return "reuse", next(s_ for s_ in self.db.solutions(sig, None, "admin-approved") if s_["vhash"] == best)
            if decision == "ambiguous" and best:
                return "adapt", next(s_ for s_ in self.db.solutions(sig, None, "admin-approved") if s_["vhash"] == best)
            return "generate", None
        exact = [s for s in appr if s["context_hash"] == ctx]
        if exact:
            return "reuse", exact[0]
        if appr:
            return "adapt", appr[0]
        other = [s for s in self.db.solutions(sig, None, "admin-approved")]
        if other:
            return "adapt", other[0]
        return "generate", None

    # ------------------------------------------------------------------ 3. LLM
    def propose(self, inc_text, card, family, mode, stored, exemplars, lessons, allowed_packets):
        rule_def = self.rule_defs.get(card, "")
        p1 = build_prompt(inc_text, card, rule_def, stored, exemplars, lessons, family, mode, 1)
        if isinstance(self.llm, StandInLLM):
            out, cached = self.llm.generate_json(p1)
        else:
            text_schema = {"type": "object", "properties": {"reasoning": {"type": "string"}}, "required": ["reasoning"]}
            r1, c1 = self.llm.generate_json(p1, text_schema)
            p2 = build_prompt(inc_text, card, rule_def, stored, exemplars, lessons, family, mode, 2,
                              (r1 or {}).get("reasoning", ""))
            out, cached = self.llm.generate_json(p2)
            self.counters["llm_calls"] += (0 if c1 else 1)
            self.counters["llm_cached"] += int(c1)
        self.counters["llm_calls"] += (0 if cached else 1)
        self.counters["llm_cached"] += int(cached)
        ok, problems, cleaned = check_output(out, allowed_packets)
        if cleaned is None:
            self.counters["llm_invalid"] += 1
            fb, _ = StandInLLM().generate_json(p1)
            ok, problems, cleaned = check_output(fb, allowed_packets)
            cleaned["reasoning"] = "fallback: " + "; ".join(problems)
        elif not ok:
            self.counters["citation_violations"] += 1
        return cleaned, problems

    # ------------------------------------------------------------------ whole flow for one confirmed cause
    def run(self, sig, cause, family, inc_text, allowed_packets, firmware, variant_for_oracle=0, admin="admin",
            approver="second_admin", fingerprint=None):
        ctx = context_hash(firmware)
        if fingerprint is not None:
            fingerprint = dict(fingerprint, card=sig, family=family, context_hash=ctx)
        mode, stored = self.classify(sig, cause, ctx, fingerprint)
        self.counters[mode] += 1
        oracle = self.oracle_factory(sig, variant_for_oracle, family)
        exemplars = exemplars_for(self.db, sig, family) if self.use_exemplars else []
        lessons = self.db.lessons(sig)
        result = {"sig": sig, "cause": cause, "mode": mode, "stored_vhash": stored["vhash"] if stored else None}
        # ---- regression guard: a stored solution is executed first, LLM only reviews it
        if mode == "reuse" and stored:
            k = sum(int(oracle.run(stored["scenario"])["reproduced"]) for _ in range(6))
            if k >= 3:
                self.counters["stored_still_reproduces"] += 1
                self.counters["zero_trial_repro"] += 1
                result.update(best_scenario=stored["scenario"], repro_k=k, repro_n=6, trials=6,
                              status="reused_validated", llm_used=False)
                return self.finish(result, oracle, sig, cause, family, firmware, ctx, stored, admin, approver, fingerprint)
            self.counters["stored_regressed"] += 1
            self.db.apply_event("lesson", {"sig": sig, "cause": cause, "producer": "bench",
                                           "text": "stored solution %s stopped reproducing in context %s" % (stored["vhash"], ctx)},
                                "bench")
            mode = "adapt"
        # ---- LLM / stand-in proposal (seed + ranges)
        if self.use_llm:
            prop, problems = self.propose(inc_text, sig, family, mode, stored, exemplars, lessons, allowed_packets)
        else:
            tpl = seed_scenario(None, family)
            prop = {"commands": tpl["commands"], "timing": tpl["timing"], "power_state": "none", "confidence": 0.3,
                    "reasoning": "template", "evidence_packets": [], "reuses_stored_solution": False}
            problems = []
        seed = {"commands": prop["commands"], "timing": prop["timing"], "power_state": prop["power_state"]}
        ranges = {k: v for k, v in (prop.get("parameter_ranges") or {}).items()
                  if isinstance(v, (list, tuple)) and len(v) == 2} if self.use_llm else {}
        extra = ([stored["scenario"]] if stored else []) + [c["scenario"] for c in exemplars[:2]]

        def plateau_proposal(best_sc, trials):
            if not self.use_llm or self.max_llm_proposals <= 0:
                return None
            txt = inc_text + "\n\nBEST SO FAR (reward plateau after %d trials): %s" % (trials, json.dumps(best_sc))
            p2, _ = self.propose(txt, sig, family, "adapt", {"scenario": best_sc, "status": "search-best",
                                                              "repro_lower95": None, "producer": "optimizer"},
                                 exemplars, lessons, allowed_packets)
            return {"commands": p2["commands"], "timing": p2["timing"], "power_state": p2["power_state"]}
        opt = Optimizer(oracle, seed, budget=self.opt_budget, rng_seed=self.opt_seed, ranges=ranges,
                        propose_fn=plateau_proposal if self.max_llm_proposals > 0 else None, extra_seeds=extra)
        r = opt.search()
        self.counters["trials_total"] += r["trials"]
        minimized = opt.minimize(r["best_scenario"]) if r["repro_k"] else r["best_scenario"]
        result.update(best_scenario=minimized, repro_k=r["repro_k"], repro_n=r["repro_n"], trials=r["trials"],
                      status=r["status"], llm_used=self.use_llm, llm_problems=problems,
                      llm_confidence=prop.get("confidence"), llm_reuse_claim=prop.get("reuses_stored_solution"),
                      llm_proposals_used=r.get("llm_proposals_used", 0))
        return self.finish(result, oracle, sig, cause, family, firmware, ctx, stored, admin, approver, fingerprint)

    # ------------------------------------------------------------------ 4-6. ledger, gate, tests
    def finish(self, result, oracle, sig, cause, family, firmware, ctx, stored, admin, approver, fingerprint=None):
        sc = result["best_scenario"]
        vh = vhash(sc)
        from optimizer import wilson_lower
        lower = wilson_lower(result["repro_k"], result["repro_n"])
        result["repro_lower95"] = round(lower, 3)
        if result["status"] != "reused_validated":
            if fingerprint is not None:
                sc = dict(sc, _fingerprint=fingerprint)
                vh = vhash(sc)
            self.db.apply_event("solution_propose", {"vhash": vh, "sig": sig, "cause": cause, "scenario": sc,
                                                     "context_hash": ctx, "producer": "llm+optimizer" if result.get("llm_used") else "optimizer",
                                                     "supersedes": stored["vhash"] if stored else None}, "optimizer")
            self.db.apply_event("solution_validate", {"vhash": vh, "repro_lower95": lower}, "bench")
        confirmed = lower >= 0.5 or result["status"] == "reused_validated"
        if confirmed:
            self.counters["confirmed"] += 1
        fixed = self.oracle_factory(sig, 0, family)
        fixed.motif = ["__never__"]
        g = gate(oracle, fixed, sc, n=10)
        entry = None
        if confirmed and result["status"] != "reused_validated":
            # admin confirms the optimized trigger -> four-eyes approval -> tests filed
            self.db.apply_event("solution_approve", {"vhash": vh, "sig": sig, "cause": cause, "approved_by": approver}, approver)
        if confirmed and self.suite_dir:
            entry = emit(self.suite_dir, sig, cause, sc, round(lower, 3), g)
            if entry["admitted"]:
                self.counters["gate_passed"] += 1
        self.db.apply_event("optimizer_result", {"sig": sig, "cause": cause, "best_scenario": sc, "repro_rate": lower,
                                                 "status": result["status"], "trials": result["trials"],
                                                 "mode": result["mode"]}, "optimizer")
        self.db.apply_event("script_gate", {"sig": sig, "cause": cause, "gate": g, "admitted": bool(entry and entry["admitted"])}, "integration")
        result.update(gate=g, admitted=bool(entry and entry["admitted"]), vhash=vh)
        if self.log:
            self.log.write(json.dumps(result) + "\n")
            self.log.flush()
        return result
