#!/usr/bin/env python3
"""Unit tests for stage 2 v3: procedural graph projection + rebuild, hybrid retrieval with feedback,
every admin action (weight semantics, two-person rules, undo), presenter card without an LLM.
Run: python3 tests_v3.py   (no network, no LLM, no bench; ~2 s)"""
import json
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from admin_actions import ALL, apply, available            # noqa: E402
from kgdb import KGDB                                      # noqa: E402
from procgraph import ProcGraph                            # noqa: E402
from retrieval_v3 import HybridIndex, recall_mrr, team_draft_interleave   # noqa: E402
from stage1_adapter import Incident                        # noqa: E402
from presenter import build_card, render_markdown          # noqa: E402
from retrieval_v3 import query_from_incident               # noqa: E402

FP = {"card": "X-1", "family": "P19", "rule": "R.A", "layer": "transaction", "origin": "device", "verdict": "CONFIRMED",
      "row_kinds": ["MWr", "Cpl", "Nak", "Cpl"], "context_hash": "ctx-A"}
SC = {"commands": [{"op": "write"}, {"op": "flush"}], "timing": {"inter_cmd_us": 50, "burst_len": 16, "idle_gap_ms": 0, "qd": 8, "bs_kb": 4},
      "power_state": "none", "_fingerprint": FP}


def seeded():
    db = KGDB(":memory:")
    g = ProcGraph(db)
    db.apply_event("incident_seen", {"sig": "X-1", "pattern": "P19", "feats": ["card:X-1", "pat:P19", "w:replay"]}, "detector")
    db.apply_event("node_create", {"sig": "X-1", "node_id": "c0", "content": {"variant": 0, "text": "replay timer"}}, "admin")
    db.apply_event("node_create", {"sig": "X-1", "node_id": "c1", "content": {"variant": 1, "text": "nak storm"}}, "admin")
    db.apply_event("verdict", {"sig": "X-1", "verdict": "correct", "chosen": "c0", "tokens": ["card:X-1", "w:replay"], "firmware": "FW-A"}, "admin")
    db.apply_event("solution_propose", {"vhash": "v1", "sig": "X-1", "cause": "c0", "scenario": SC, "context_hash": "ctx-A", "producer": "optimizer"}, "optimizer")
    db.apply_event("solution_validate", {"vhash": "v1", "repro_lower95": 0.6}, "bench")
    db.apply_event("solution_approve", {"vhash": "v1", "sig": "X-1", "cause": "c0", "approved_by": "second"}, "second")
    return db, g


class ProcGraphTests(unittest.TestCase):
    def test_projection_and_rebuild(self):
        db, g = seeded()
        st = g.stats()
        self.assertEqual((st["n_signature"], st["n_cause"], st["n_scenario"]), (1, 2, 1))
        self.assertEqual(st["e_CAUSED_BY"], 2)
        self.assertEqual(st["e_REPRODUCED_BY"], 1)
        procs = g.procedures_for("X-1")
        self.assertEqual(len(procs), 1)
        self.assertEqual([s["op"] for s in procs[0]["procedure"]["procedure"]], ["write", "flush"])
        self.assertEqual(procs[0]["scenario_status"], "admin-approved")
        before = (g.stats(), g.node("scn::v1")["a"], g.edges("CAUSED_BY", src="X-1")[0]["a"])
        db.rebuild()
        after = (g.stats(), g.node("scn::v1")["a"], g.edges("CAUSED_BY", src="X-1")[0]["a"])
        self.assertEqual(before, after)

    def test_supersede_chain_and_firmware_halving(self):
        db, g = seeded()
        sc2 = dict(SC, timing=dict(SC["timing"], qd=16))
        db.apply_event("solution_propose", {"vhash": "v2", "sig": "X-1", "cause": "c0", "scenario": sc2, "context_hash": "ctx-A",
                                            "producer": "optimizer", "supersedes": "v1"}, "optimizer")
        db.apply_event("solution_validate", {"vhash": "v2", "repro_lower95": 0.7}, "bench")
        db.apply_event("solution_approve", {"vhash": "v2", "sig": "X-1", "cause": "c0", "approved_by": "second"}, "second")
        chain = g.procedure_chain("scn::v2")
        self.assertEqual([c["id"] for c in chain], ["scn::v2", "scn::v1"])
        self.assertEqual(g.node("scn::v1")["props"]["status"], "superseded")
        a0 = g.node("scn::v2")["a"]
        db.apply_event("firmware_change", {"from": "FW-A", "to": "FW-B"}, "admin")
        self.assertLess(g.node("scn::v2")["a"], a0)


class RetrievalTests(unittest.TestCase):
    def test_feedback_changes_ranking(self):
        db, g = seeded()
        idx = HybridIndex(db, g, k=5, explore_slot=False)
        q = {"card": "X-1", "family": "P19", "rule": "R.A", "layer": "transaction", "origin": "device", "verdict": "CONFIRMED",
             "context_hash": "ctx-A", "tokens": ["card:X-1", "pat:P19", "w:replay"], "text": "X-1 P19 replay MWr Cpl Nak",
             "row_kinds": ["MWr", "Cpl", "Nak", "Cpl"]}
        shown, _ = idx.query(q)
        seen, best, score = idx.seen_before(q, shown)
        self.assertEqual(seen, "match")
        self.assertEqual(best["vhash"], "v1")
        s_before = best["score"]
        for _ in range(8):
            db.apply_event("proc_credit", {"node_id": "scn::v1", "edge_id": g.edge_id("REPRODUCED_BY", "X-1::c0", "scn::v1"), "r": 0.0}, "admin")
        shown2, _ = idx.query(q)
        sol = next(c for c in shown2 if c["doc_id"] == "sol::v1")
        self.assertLess(sol["score"], s_before)
        q2 = dict(q, context_hash="ctx-B")
        self.assertEqual(idx.seen_before(q2, idx.query(q2)[0])[0], "ambiguous")
        # same card and context but a different manifestation (rule/layer/origin differ) is NOT a match
        q3 = dict(q, rule="R.Z", layer="host", origin="host")
        seen3, best3, _ = idx.seen_before(q3, idx.query(q3)[0])
        self.assertEqual(seen3, "ambiguous")
        from presenter import _seen_label
        self.assertIn("different rule fired first", _seen_label(seen3, q3, best3))

    def test_helpers(self):
        self.assertEqual(recall_mrr(["a", "b", "c"], {"b"}, k=5), (1.0, 0.5))
        import random
        out, team = team_draft_interleave(["a", "b", "c"], ["c", "d", "a"], 4, random.Random(0))
        self.assertEqual(len(out), 4)
        self.assertEqual(set(team.values()), {"A", "B"})


class AdminActionTests(unittest.TestCase):
    def edge(self, db, cid):
        return dict(db.edge("X-1", cid))

    def test_vocabulary_and_availability(self):
        self.assertGreaterEqual(len(ALL), 20)
        self.assertIn("promote", available("match", True))
        self.assertNotIn("promote", available("new", True))

    def test_accept_credits_only_chosen(self):
        db, g = seeded()
        e0, e1 = self.edge(db, "c0"), self.edge(db, "c1")
        r = apply(db, g, {"action": "accept", "sig": "X-1", "requester": "a1", "targets": ["cause::X-1::c0"]}, tokens=["card:X-1"], firmware="FW-A")
        self.assertIsNone(r["error"])
        self.assertGreater(self.edge(db, "c0")["a"], e0["a"])
        self.assertAlmostEqual(self.edge(db, "c1")["a"], 1.0 + (e1["a"] - 1.0) * (1 - db.p["gamma"]))   # only decay
        self.assertEqual(self.edge(db, "c0")["ta"], e0["ta"] + 1)

    def test_accept_procedure_credits_edge_node_and_cause(self):
        db, g = seeded()
        n0 = g.node("scn::v1")["a"]
        apply(db, g, {"action": "accept", "sig": "X-1", "requester": "a1", "targets": ["sol::v1"]}, firmware="FW-A")
        self.assertGreater(g.node("scn::v1")["a"], n0)
        self.assertGreater(g.edges("REPRODUCED_BY", dst="scn::v1")[0]["a"], 1.0)

    def test_reject_blames_only_target(self):
        db, g = seeded()
        b0, b1 = self.edge(db, "c0")["b"], self.edge(db, "c1")["b"]
        apply(db, g, {"action": "reject", "sig": "X-1", "requester": "a1", "targets": ["cause::X-1::c1"]}, firmware="FW-A")
        self.assertGreater(self.edge(db, "c1")["b"], b1)
        self.assertLessEqual(self.edge(db, "c0")["b"], b0)

    def test_revise_keeps_counts_shrinks_evidence(self):
        db, g = seeded()
        a0 = self.edge(db, "c0")["a"]
        apply(db, g, {"action": "revise", "sig": "X-1", "requester": "a1", "targets": ["cause::X-1::c0"], "content": {"text": "revised"}})
        self.assertEqual(db.content("X-1", "c0")["text"], "revised")
        self.assertAlmostEqual(self.edge(db, "c0")["a"], 1.0 + (a0 - 1.0) * db.p["edit_shrink"])

    def test_not_reproducible_touches_only_technical_counts(self):
        db, g = seeded()
        e = self.edge(db, "c0")
        apply(db, g, {"action": "not_reproducible", "sig": "X-1", "requester": "a1", "targets": ["cause::X-1::c0"], "note": "bench silent"}, firmware="FW-A")
        e2 = self.edge(db, "c0")
        self.assertEqual(e2["tb"], e["tb"] + 1)
        self.assertAlmostEqual(e2["a"], 1.0 + (e["a"] - 1.0) * (1 - db.p["gamma"]))   # decay only, no blame
        self.assertEqual(e2["n"], e["n"])

    def test_rankings_never_count_as_success(self):
        db, g = seeded()
        e0, e1 = self.edge(db, "c0"), self.edge(db, "c1")
        apply(db, g, {"action": "rerank", "sig": "X-1", "requester": "a1", "ranking": ["cause::X-1::c1", "cause::X-1::c0"]})
        self.assertEqual((self.edge(db, "c0")["a"], self.edge(db, "c0")["n"]), (e0["a"], e0["n"]))
        self.assertGreater(self.edge(db, "c1")["pl"], e1["pl"])
        db.apply_event("solution_propose", {"vhash": "v2", "sig": "X-1", "cause": "c1", "scenario": SC, "context_hash": "ctx-A", "producer": "x"}, "x")
        n1 = g.node("scn::v1")
        apply(db, g, {"action": "rerank", "sig": "X-1", "requester": "a1", "ranking": ["sol::v2", "sol::v1"]})
        self.assertEqual(g.node("scn::v1")["a"], n1["a"])
        self.assertGreater(g.node("scn::v2")["pl"], 0.0)

    def test_two_person_rules(self):
        db, g = seeded()
        r = apply(db, g, {"action": "delete_approve", "sig": "X-1", "requester": "a1", "approver": "a1", "targets": ["cause::X-1::c1"]})
        self.assertIsNotNone(r["error"])
        apply(db, g, {"action": "delete_request", "sig": "X-1", "requester": "a1", "targets": ["cause::X-1::c1"]})
        r = apply(db, g, {"action": "delete_approve", "sig": "X-1", "requester": "a2", "approver": "a2", "targets": ["cause::X-1::c1"]})
        self.assertIsNone(r["error"])
        self.assertNotIn("c1", db.causes("X-1"))
        self.assertEqual(g.node("X-1::c1")["status"], "deleted")
        db.apply_event("solution_propose", {"vhash": "v3", "sig": "X-1", "cause": "c0", "scenario": SC, "context_hash": "ctx-A", "producer": "optimizer"}, "optimizer")
        db.apply_event("solution_validate", {"vhash": "v3", "repro_lower95": 0.55}, "bench")
        r = apply(db, g, {"action": "promote", "sig": "X-1", "requester": "optimizer", "approver": "optimizer", "targets": ["sol::v3"]})
        self.assertIsNotNone(r["error"])
        r = apply(db, g, {"action": "promote", "sig": "X-1", "requester": "a1", "approver": "a2", "targets": ["sol::v3"]})
        self.assertEqual(db.solutions("X-1", "c0", "admin-approved")[0]["vhash"], "v3")
        self.assertEqual(db.solutions("X-1", "c0", "superseded")[0]["vhash"], "v1")

    def test_duplicate_merge_keeps_histories_and_repoints(self):
        db, g = seeded()
        db.apply_event("solution_propose", {"vhash": "v9", "sig": "X-1", "cause": "c1", "scenario": SC, "context_hash": "ctx-A", "producer": "x"}, "x")
        apply(db, g, {"action": "accept", "sig": "X-1", "requester": "a1", "targets": ["cause::X-1::c1"]}, firmware="FW-A")
        a_keep = self.edge(db, "c0")["a"]
        apply(db, g, {"action": "duplicate_of", "sig": "X-1", "requester": "a1", "targets": ["cause::X-1::c1", "cause::X-1::c0"]})
        self.assertGreater(self.edge(db, "c0")["a"], a_keep)
        self.assertNotIn("c1", db.causes("X-1"))
        self.assertTrue(any(e["dst"] == "scn::v9" for e in g.edges("REPRODUCED_BY", src="X-1::c0")))
        self.assertEqual(db.con.execute("SELECT COUNT(*) FROM event WHERE kind='merge'").fetchone()[0], 1)

    def test_undo_restores_everything(self):
        db, g = seeded()
        snap = (g.stats(), self.edge(db, "c0"))
        r = apply(db, g, {"action": "add_cause", "sig": "X-1", "requester": "a1", "content": {"text": "new"}, "targets": ["cause::X-1::c0"]}, firmware="FW-A")
        self.assertIn("c2", db.causes("X-1"))
        for eid in r["events"]:
            db.undo(eid, "a1")
        self.assertNotIn("c2", db.causes("X-1"))
        self.assertEqual((g.stats(), self.edge(db, "c0")), snap)

    def test_structure_actions(self):
        db, g = seeded()
        r = apply(db, g, {"action": "add_procedure", "sig": "X-1", "requester": "a1", "targets": ["cause::X-1::c0"],
                          "content": {"commands": [{"op": "reset"}], "timing": SC["timing"], "power_state": "none"}})
        self.assertEqual(db.solutions("X-1", "c0", "proposed")[0]["vhash"], r["vhash"])
        r = apply(db, g, {"action": "split", "sig": "X-1", "requester": "a1", "targets": ["cause::X-1::c0"],
                          "content": {"new": {"text": "part b"}, "old": {"text": "part a"}}})
        self.assertIn(r["node_id"], db.causes("X-1"))
        db.apply_event("incident_seen", {"sig": "Y-2", "pattern": "P19", "feats": []}, "detector")
        db.apply_event("node_create", {"sig": "Y-2", "node_id": "c0", "content": {}}, "admin")
        r = apply(db, g, {"action": "link", "sig": "Y-2", "requester": "a1", "targets": ["cause::Y-2::c0", "sol::v1"]})
        self.assertEqual(db.solutions("Y-2", "c0", "proposed")[0]["scenario"]["_linked_from"], "v1")
        for name in ("skip", "defer", "tie"):
            self.assertIsNone(apply(db, g, {"action": name, "sig": "X-1", "requester": "a1"})["error"])
        r = apply(db, g, {"action": "escalate", "sig": "X-1", "requester": "a1", "note": "need lspci"})
        self.assertTrue(db.lessons("X-1")[0]["text"].startswith("ESCALATED"))
        r = apply(db, g, {"action": "wrong_signature", "sig": "X-1", "requester": "a1", "note": "it is a Y-2"})
        self.assertEqual(db.con.execute("SELECT COUNT(*) FROM event WHERE kind='signature_dispute'").fetchone()[0], 1)


class PresenterTests(unittest.TestCase):
    def test_card_without_llm(self):
        db, g = seeded()
        inc = Incident(id="I-1", card="X-1", candidates=[{"card_id": "X-1", "score": 0.9}], verdict="CONFIRMED", layer="transaction",
                       pattern="P19", origin="device", task="t", first_abnormal={"pkt": 10, "rule": "R.A", "detail": "d"}, packets=(1, 20),
                       evidence_packets=[10], rows=[{"range": [1, 20], "rows": ["Packet=10 | TLP Type=MWr", "Packet=11 | TLP Type=Cpl"]}],
                       explanation={}, nvme_commands=[], tokens=["card:X-1", "pat:P19"], firmware="FW-A", raw={})
        idx = HybridIndex(db, g, explore_slot=False)
        q = query_from_incident(inc, "ctx-A")
        shown, _ = idx.query(q)
        seen, best, _ = idx.seen_before(q, shown)
        card = build_card(inc, q, shown, seen, best, g, "EVIDENCE", {10, 11})
        self.assertEqual(card["seen_before"]["verdict"], "match")
        self.assertEqual(card["recommended"]["vhash"], "v1")
        self.assertIn("fio", card["recommended"]["test_preview"])
        self.assertIn("promote", card["actions"])
        md = render_markdown(card)
        self.assertIn("Saved procedure", md)


if __name__ == "__main__":
    unittest.main(verbosity=1)
