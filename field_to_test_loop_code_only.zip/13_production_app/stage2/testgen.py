"""Closed-loop test generation (v3): a test case that MIMICS THE ISOLATION of the defect.

A generated test is not "run the scenario and hope": it is
    arrange   device in the recorded context (firmware, power state)
    act       execute the procedure (ordered commands with timing) from the approved scenario
    capture   export the analyzer trace of that run (113-column CSV)
    analyze   run the SAME stage-1 detector (10_defect_isolation_engine) on the capture
    assert    the detector isolates the same card (or its ambiguity group) with a CONFIRMED/SUSPECT verdict,
              repeated n times with a Wilson lower bound on the hit rate;
              on fixed firmware the same procedure must NOT isolate the card (regression test)

`GeneratorBench` is the synthetic "device" used on test data: the hidden trigger model decides whether the defect
manifests for a given procedure (never readable by the search), the project's trace generator renders the capture
the analyzer would have seen (with the card's episode when it manifested, a healthy trace otherwise), and the real
stage-1 engine is the oracle. On hardware, replace `GeneratorBench` by a class with the same two methods
(`run(scenario) -> trace path`, `detect(trace) -> findings`), e.g. fio/nvme-cli + analyzer export.
"""
import hashlib
import json
import math
import os
import pprint
import shutil
import subprocess
import sys
import time

from oracle import SyntheticDeviceOracle
from optimizer import wilson_lower
from loop_rules import SCORE_THRESHOLD, OPTIMAL_CONSECUTIVE, signature_score, consecutive_above, score_checks, best_finding

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
# Resolution order for the engine, the trace generator and the atlas cards: an environment variable (set by the app),
# else the packaged layout next to this file (<app>/stage1, <app>/data/...), else the development tree. A generated
# test therefore runs as plain pytest from an extracted package without any environment variable.
_APP = os.path.dirname(HERE)
def _first(*cands):
    return next((c for c in cands if c and os.path.exists(c)), cands[-1])
ENGINE_DIR = os.environ.get("PCIE_ENGINE_DIR") or _first(os.path.join(_APP, "stage1"), os.path.join(ROOT, "10_defect_isolation_engine"))
GENERATOR = os.environ.get("PCIE_GENERATOR") or _first(os.path.join(_APP, "data", "generator", "generate_synthetic_pcie_trace.py"),
                                                      os.path.join(ROOT, "02_generator_and_validator_code", "generate_synthetic_pcie_trace.py"))
ATLAS_CARDS = os.environ.get("PCIE_ATLAS_CARDS") or (os.path.join(_APP, "data", "atlas_cards_raw.json")
                                                     if os.path.exists(os.path.join(_APP, "data", "atlas_cards_raw.json")) else None)   # generator --cards


# ---------------------------------------------------------------------- the stage-1 engine as a library call
SIMULATE_HOST = os.path.join(ENGINE_DIR, "tools", "simulate_host_evidence.py")
NSZE = "0x3A386030"            # the generator's namespace size (976,773,168 blocks)


def host_evidence_for(csv_path, out_dir, timeout=300):
    """What the host would have recorded next to this capture (dmesg -x, tool logs), simulated from the
    generator's event log exactly as the 4 GB evaluation did. Returns (dmesg, events) or (None, None)."""
    side = csv_path[:-4] + "_sidecars"
    ev = os.path.join(side, "scenario_event_log.jsonl")
    if not (os.path.exists(ev) and os.path.getsize(ev) > 0):
        return None, None
    hdir = os.path.join(out_dir, "simulated_host")
    os.makedirs(hdir, exist_ok=True)
    r = subprocess.run([sys.executable, SIMULATE_HOST, "--event-log", ev, "--csv", csv_path, "--out", hdir],
                       capture_output=True, text=True, timeout=timeout)
    dm, hv = os.path.join(hdir, "dmesg_x.txt"), os.path.join(hdir, "host_events.jsonl")
    if r.returncode != 0 or not os.path.exists(dm):
        return None, None
    return dm, (hv if os.path.exists(hv) else None)


def run_engine(csv_path, out_dir, timeout=600, host_evidence=True):
    """Run the stage-1 detector on a capture the way the 4 GB evaluation ran it (hex DATA in the CSV, the
    namespace size, and the host-side documents fused in); returns the isolated incidents."""
    if os.path.isdir(out_dir):
        shutil.rmtree(out_dir)
    os.makedirs(out_dir, exist_ok=True)
    cmd = [sys.executable, "-m", "pcie_isolate.cli", "run", "--csv", csv_path, "--out", out_dir, "--backend", "dry-run",
           "--nsze", NSZE]
    if host_evidence:
        dm, hv = host_evidence_for(csv_path, out_dir)
        if dm:
            cmd += ["--dmesg", dm]
        if hv:
            cmd += ["--events", hv]
    r = subprocess.run(cmd, cwd=ENGINE_DIR, capture_output=True, text=True, timeout=timeout)
    p = os.path.join(out_dir, "incidents.json")
    if r.returncode != 0 or not os.path.exists(p):
        return {"error": (r.stderr or r.stdout)[-500:], "incidents": []}
    with open(p) as f:
        return {"error": None, "incidents": json.load(f)}


def findings_of(incidents):
    """Detector incidents -> flat findings the oracle mapping understands.
    top-1 atlas candidate = CONFIRMED (the engine's verdict), 2nd/3rd = SUSPECT (ambiguity group)."""
    out = []
    for inc in incidents:
        cands = inc.get("atlas_candidates", [])[:3]
        for r, c in enumerate(cands):
            out.append({"card_id": c["card_id"], "verdict": inc.get("verdict", "CONFIRMED") if r == 0 else "SUSPECT",
                        "closeness": float(c.get("score", 0.0)), "pkt": inc.get("start_pkt"), "incident": inc["id"],
                        "rule": (inc.get("first_abnormal") or {}).get("rule"), "rank": r + 1})
    return out


def generate_trace(cards, out_csv, seed, timeout=600):
    """Render a capture with the given cards' episodes (healthy filler traffic only when cards is empty)."""
    only = ",".join(cards) if cards else "NONE"
    cmd = [sys.executable, GENERATOR, "--only", only, "--output", out_csv, "--seed", str(seed), "--data-format", "hex"]
    if ATLAS_CARDS:
        cmd += ["--cards", ATLAS_CARDS]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    ok = os.path.exists(out_csv) and os.path.getsize(out_csv) > 10000
    if not ok:
        raise RuntimeError("generator failed: %s" % (r.stderr or r.stdout)[-400:])
    return out_csv


class GeneratorBench:
    """Synthetic device + analyzer + detector. Same interface the optimizer's oracle uses (run -> stage, closeness,
    reproduced) PLUS the closed-loop facts (trace path, detector findings)."""

    def __init__(self, sig, variant=0, family=None, workdir=None, seed=0, flaky=0.15, fixed=False,
                 expected_cards=None, reward_from="detector", decoy=None):
        self.sig, self.variant, self.family = sig, variant, family
        self.workdir = workdir or os.path.join(os.environ.get("PCIE_BENCH_WORKDIR", os.path.join(HERE, "closed_loop_out")),
                                               "bench_" + sig.replace("/", "_"))
        os.makedirs(self.workdir, exist_ok=True)
        self.seed, self.fixed, self.decoy = seed, fixed, decoy   # decoy: neighbour card injected on the FIXED bench
                                                                 # (negative control: silence must not be trivial)
        self.hidden = None if fixed else SyntheticDeviceOracle(sig, variant, flaky=flaky, seed=seed, family=family)
        self.expected = set(expected_cards or [sig])
        self.reward_from = reward_from
        self.calls = 0
        self.seconds = 0.0
        self._traces = {}
        self._detections = {}
        self.log = []

    # ---- the two methods a hardware bench must provide
    def run(self, scenario):
        """Execute the procedure on the (synthetic) device and return the analyzer capture + verdicts."""
        t0 = time.time()
        self.calls += 1
        hid = self.hidden.run(scenario) if self.hidden else {"stage": 0, "closeness": 0.0, "reproduced": False, "cost_s": 1.0}
        manifested = bool(hid["reproduced"])
        cards = [self.sig] if manifested else ([self.decoy] if (self.fixed and self.decoy) else [])
        trace = self._trace(cards, self.seed + (self.calls % 7))
        findings = self.detect(trace)
        st, cl = self.stage_from_findings(findings)
        if self.reward_from == "detector":
            stage, closeness = st, max(cl, hid["closeness"] if st == 0 else cl)
            if st == 0 and hid["stage"] > 0:              # defect did not manifest: keep the dense shaping signal
                stage, closeness = min(hid["stage"], 2), hid["closeness"]
        else:
            stage, closeness = hid["stage"], hid["closeness"]
        res = {"stage": stage, "closeness": round(closeness, 4), "reproduced": stage >= 3, "cost_s": hid.get("cost_s", 2.0),
               "manifested": manifested, "detector_stage": st, "trace": trace,
               # positive side: the card or its ambiguity group isolated (CONFIRMED or SUSPECT)
               "isolated": [f for f in findings if f["card_id"] in self.expected and f["verdict"] in ("CONFIRMED", "SUSPECT")],
               # negative side (fixed firmware / decoy traffic): the card itself as the PRIMARY isolation
               "isolated_top1": [f for f in findings if f["card_id"] == self.sig and f["verdict"] == "CONFIRMED"]}
        self.seconds += time.time() - t0
        self.log.append({"call": self.calls, "manifested": manifested, "detector_stage": st, "stage": stage})
        return res

    def detect(self, trace):
        """trace: the capture path, or the record run() returned (its 'trace' field is the path)."""
        if isinstance(trace, dict):
            trace = trace["trace"]
        if trace in self._detections:
            return self._detections[trace]
        out = run_engine(trace, os.path.join(self.workdir, "det_" + os.path.basename(trace).replace(".csv", "")))
        f = findings_of(out["incidents"])
        self._detections[trace] = f
        return f

    # ---- helpers
    def _trace(self, cards, seed):
        key = (tuple(cards), seed)
        if key not in self._traces:
            name = "trace_%s_%d.csv" % ("_".join(c.replace("/", "_") for c in cards) or "healthy", seed)
            self._traces[key] = generate_trace(cards, os.path.join(self.workdir, name), seed)
        return self._traces[key]

    def stage_from_findings(self, findings):
        best = (0, 0.0)
        for f in findings:
            if f["card_id"] in self.expected:
                s = 3 if f["verdict"] == "CONFIRMED" else 2
                best = max(best, (s, f["closeness"]))
            elif f["card_id"].split("-")[0] == self.sig.split("-")[0]:
                best = max(best, (1, 0.5))
        return best

    def detectability(self, n=2):
        """Can the stage-1 engine isolate this card at all on a synthetic capture that contains its episode?
        Returns the cards the engine proposes (used as the ambiguity group) and whether the card is in them."""
        seen, hits = {}, 0
        for i in range(n):
            tr = self._trace([self.sig], self.seed + 100 + i)
            fs = self.detect(tr)
            ok = any(f["card_id"] == self.sig for f in fs)
            hits += ok
            # ambiguity group = the engine's alternatives in the incident(s) that contain this card, not every
            # incident on the capture (background traffic can raise unrelated incidents)
            own = {f["incident"] for f in fs if f["card_id"] == self.sig}
            for f in fs:
                if f["incident"] in own:
                    seen[f["card_id"]] = max(seen.get(f["card_id"], 0.0), f["closeness"])
        return {"card": self.sig, "isolated_runs": hits, "runs": n, "detectable": hits > 0,
                "engine_candidates": sorted(seen.items(), key=lambda x: -x[1])[:5]}


# ---------------------------------------------------------------------- the test contract
def test_manifest(incident_id, sig, pattern, scenario, expected_cards, firmware_known_bad, firmware_fixed,
                  repro_lower95, context_hash, source_vhash, ambiguity_note="", composition=None, signature=None, device=None):
    # Repeats on known-bad firmware so that a defect which reproduces with probability p is seen at least once with
    # 95 % confidence: P(no hit in n runs) = (1 - p)^n <= 0.05  =>  n >= ln(0.05) / ln(1 - p)   (independent Bernoulli
    # trials; the same algebra as the "rule of three", Hanley & Lippman-Hand, JAMA 1983). p is the Wilson 95 % lower
    # bound measured at generation (a conservative p => more repeats). Engineering clamps, not from any standard:
    # p in [0.05, 0.95] keeps n finite, n in [3, 20] bounds bench time (p = 0.5 -> 5 runs; p = 0.2 -> 14; p = 0.14 -> 20).
    p_lo = min(0.95, max(0.05, repro_lower95))
    n_bad = max(3, min(20, int(math.ceil(math.log(0.05) / math.log(1 - p_lo)))))
    man = _manifest(incident_id, sig, pattern, scenario, expected_cards, firmware_known_bad, firmware_fixed, repro_lower95,
                    context_hash, source_vhash, ambiguity_note, n_bad)
    if composition:
        man["composition"] = composition          # provenance: which stored sequences, which model, why (LLM-composed tests)
    if signature:
        man["signature"] = signature              # the field failure signature the test guards (checklist H4 / H9)
        man["signature_id"] = signature.get("signature_id")
    man["optimal_rule"] = {"score_threshold": SCORE_THRESHOLD, "consecutive": OPTIMAL_CONSECUTIVE}
    if device and device.get("name"):
        # a regression test belongs to one device model + firmware: the id carries the device so that the same error
        # on another drive gets its own test, and the bench refuses to run it on a different model (preconditions)
        man["device"] = {k: device.get(k) for k in ("name", "model_number", "serial_number", "firmware_revision", "pci", "source")
                         if device.get(k)}
        man["preconditions"]["device_model"] = device["name"]
        man["test_id"] = "T-%s-%s-%s" % (sig.replace("/", "_"), device_slug(device["name"]), source_vhash[:8])
    return man


def device_slug(name):
    """File-system-safe short form of a device name: 'Samsung SSD 990 PRO 2TB' -> 'Samsung_SSD_990_PRO_2TB'."""
    import re as _re
    return (_re.sub(r"[^A-Za-z0-9]+", "_", str(name)).strip("_") or "device")[:40]


def _manifest(incident_id, sig, pattern, scenario, expected_cards, firmware_known_bad, firmware_fixed, repro_lower95, context_hash,
              source_vhash, ambiguity_note, n_bad):
    return {
        "test_id": "T-%s-%s" % (sig.replace("/", "_"), source_vhash[:8]),
        "incident_id": incident_id, "card": sig, "pattern": pattern, "expected_cards": sorted(expected_cards),
        "ambiguity_note": ambiguity_note, "source_solution": source_vhash, "context_hash": context_hash,
        "firmware": {"known_bad": firmware_known_bad, "fixed": firmware_fixed},
        "preconditions": {"power_state": scenario.get("power_state", "none"), "scratch_namespace": True},
        "stimulus": {"steps": [{"i": i, "op": (c["op"] if isinstance(c, dict) else c)} for i, c in enumerate(scenario["commands"])],
                     "timing": scenario["timing"]},
        "capture": {"tool": "analyzer export (113-column CSV)", "trigger": "start of stimulus", "window": "stimulus + 2 s"},
        "analysis": {"detector": "10_defect_isolation_engine (pcie_isolate.cli run --backend dry-run)",
                     "same_detector_as_stage1": True},
        "expected": {"card_in": sorted(expected_cards), "verdict_in": ["CONFIRMED", "SUSPECT"],
                     "fixed_firmware_rule": "the card itself must not be the primary (CONFIRMED) isolation; decoy traffic "
                                            "of a neighbour card may list it as a secondary candidate",
                     "position_tolerance_rows": 32,
                     "position_check": "hardware bench only (first abnormal row within 32 rows of the stimulus anchor); "
                                       "the synthetic bench has no stimulus anchor, so position is not asserted there"},
        "verdict_rules": {"known_bad": {"repeats": n_bad, "min_hits": 1, "report": "wilson_lower95",
                                        "derivation": "n = ceil(ln(0.05)/ln(1-p)), p = Wilson lower bound at generation clamped to [0.05, 0.95], n clamped to [3, 20]: at least one hit with 95 % confidence"},
                          "fixed": {"repeats": 5, "max_hits": 0}},
        "safety": {"deny": ["format", "sanitize", "fw-download", "fw-commit", "delete-ns"], "canary_first": True},
        "measured_at_generation": {"repro_lower95": repro_lower95},
    }


def _composition_doc(manifest):
    c = manifest.get("composition")
    if not c:
        return ""
    srcs = "; ".join("%s (%s, %s%s)" % (s.get("vhash", "")[:8], s.get("origin"), s.get("status"),
                                       ", approved by %s" % s["approved_by"] if s.get("approved_by") else "") for s in c.get("sources", []))
    lines = ["%s, validated by execution before filing%s:" % (
             c.get("producer_text") or "Composed by the AI reviewer (%s) from the saved command sequences" % c.get("composed_by", "?"),
             " (adapted by the search)" if c.get("adapted_by_search") else ""),
             "  Variant: %s" % c.get("name", ""), "  Why: %s" % c.get("rationale", ""),
             "  Expected on the analyzer: %s" % (", ".join(c.get("expected_packets") or []) or "-"),
             "  Sources: %s" % (srcs or "-")]
    if c.get("risks"):
        lines.append("  Risks: %s" % "; ".join(c["risks"]))
    return ("\n" + "\n".join(lines)).replace('"""', "'''")


def render_closed_loop_pytest(manifest):
    return '''"""Closed-loop regression test generated for incident %(inc)s (card %(card)s, pattern %(pat)s).
The test mimics the isolation: it runs the approved procedure, captures the analyzer trace and runs the SAME
stage-1 detector on it; the defect counts as reproduced only when the detector isolates %(card)s (or an error
type the detector cannot tell apart from it on the wire: %(exp)s). On fixed firmware the same procedure must stay silent.
Fixtures (conftest.py): `bench` = known-bad device, `bench_fixed` = fixed device; both provide
run(scenario) -> trace path and detect(trace) -> findings [{card_id, verdict, closeness, pkt}].%(compose)s"""
import json
import pytest

MANIFEST = %(man)s
SCENARIO = {"commands": [{"op": s["op"]} for s in MANIFEST["stimulus"]["steps"]],
            "timing": MANIFEST["stimulus"]["timing"], "power_state": MANIFEST["preconditions"]["power_state"]}
EXPECTED = set(MANIFEST["expected"]["card_in"])
VERDICTS = set(MANIFEST["expected"]["verdict_in"])


def _isolated(findings):
    """Positive side: the card or its engine-measured ambiguity group, CONFIRMED or SUSPECT."""
    return [f for f in findings if f["card_id"] in EXPECTED and f["verdict"] in VERDICTS]


def _isolated_top1(findings):
    """Negative side: the card itself as the primary (CONFIRMED) isolation - a decoy's secondary candidate is not a hit."""
    return [f for f in findings if f["card_id"] == MANIFEST["card"] and f["verdict"] == "CONFIRMED"]


@pytest.mark.card("%(card)s")
@pytest.mark.incident("%(inc)s")
def test_known_bad_reproduces_and_detector_isolates(bench):
    n = MANIFEST["verdict_rules"]["known_bad"]["repeats"]
    hits = 0
    for _ in range(n):
        trace = bench.run(SCENARIO)                 # act + capture
        hits += bool(_isolated(bench.detect(trace)))   # analyze with the stage-1 detector
    assert hits >= MANIFEST["verdict_rules"]["known_bad"]["min_hits"], \\
        "procedure no longer makes the detector isolate %(card)s (%%d/%%d)" %% (hits, n)


@pytest.mark.card("%(card)s")
def test_fixed_firmware_stays_silent(bench_fixed):
    n = MANIFEST["verdict_rules"]["fixed"]["repeats"]
    hits = sum(bool(_isolated_top1(bench_fixed.detect(bench_fixed.run(SCENARIO)))) for _ in range(n))
    assert hits <= MANIFEST["verdict_rules"]["fixed"]["max_hits"], \\
        "regression: %(card)s isolated on fixed firmware (%%d/%%d)" %% (hits, n)
''' % {"inc": manifest["incident_id"], "card": manifest["card"], "pat": manifest["pattern"],
       "exp": manifest["expected_cards"], "man": pprint.pformat(manifest, width=110),   # Python literal, not JSON
       "compose": _composition_doc(manifest)}


CONFTEST = '''"""Bench fixtures. Synthetic: GeneratorBench (hidden trigger + trace generator + stage-1 engine).
Hardware: implement a class with run(scenario) -> trace path and detect(trace) -> findings and return it here."""
import os
import sys
import pytest

def _stage2_dir():
    """STAGE2_DIR, else the nearest ancestor that holds testgen.py (development tree: the suite lives under the stage-2
    package) or an ancestor's stage2/ folder (packaged application: <app>/suite/<id> next to <app>/stage2)."""
    d = os.environ.get("STAGE2_DIR")
    if d:
        return d
    here = os.path.dirname(os.path.abspath(__file__))
    while here != os.path.dirname(here):
        for cand in (here, os.path.join(here, "stage2")):
            if os.path.exists(os.path.join(cand, "testgen.py")):
                return cand
        here = os.path.dirname(here)
    raise RuntimeError("set STAGE2_DIR to the stage-2 package directory")


sys.path.insert(0, _stage2_dir())
from testgen import GeneratorBench   # noqa: E402

MANIFEST = __import__("json").load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "manifest.json")))


def pytest_configure(config):
    config.addinivalue_line("markers", "card(id): atlas card the test reproduces")
    config.addinivalue_line("markers", "incident(id): stage-1 incident the test was generated from")


@pytest.fixture(scope="module")
def bench():
    return GeneratorBench(MANIFEST["card"], family=MANIFEST["pattern"], expected_cards=MANIFEST["expected_cards"],
                          seed=1, fixed=False)


@pytest.fixture(scope="module")
def bench_fixed():
    return GeneratorBench(MANIFEST["card"], family=MANIFEST["pattern"], expected_cards=MANIFEST["expected_cards"],
                          seed=1, fixed=True)
'''


def emit_closed_loop_test(suite_dir, manifest):
    d = os.path.join(suite_dir, manifest["test_id"])
    os.makedirs(d, exist_ok=True)
    files = {"manifest.json": json.dumps(manifest, indent=1),
             # unique basename per test id: several procedures of one card (versions, adaptations) must collect together
             "test_%s.py" % manifest["test_id"].replace("-", "_").replace("/", "_"): render_closed_loop_pytest(manifest),
             "conftest.py": CONFTEST}
    for name, text in files.items():
        with open(os.path.join(d, name), "w") as f:
            f.write(text)
    return d, sorted(files)


WORKLOAD_PYTEST = '''"""Proposed regression test for a WORKLOAD abnormality (%(wl)s): %(title)s
Generated from the field signature %(sid)s; the hardware bench must run the workload with the preconditions below and
report the metric. Known-bad firmware: the metric must leave the baseline band in at least one of REPEAT runs; fixed
firmware: it must stay inside the band in every run. Needs a bench fixture `workload_bench` with
run_workload(manifest, firmware) -> {"metric": value}; on the synthetic bench the tests are skipped.
%(compose)s"""
import pytest

MANIFEST = %(man)s
REPEAT = MANIFEST["verdict_rules"]["known_bad"]["repeats"]
BAND = (MANIFEST["workload"]["baseline"] or 0) + 3 * (MANIFEST["workload"]["spread"] or 0)


@pytest.mark.card("%(card)s")
def test_known_bad_reproduces_the_metric_deviation(workload_bench):
    hits = 0
    for _ in range(REPEAT):
        hits += workload_bench.run_workload(MANIFEST, MANIFEST["firmware"]["known_bad"])["metric"] > BAND
    assert hits >= MANIFEST["verdict_rules"]["known_bad"]["min_hits"], "the %(metric)s deviation did not reproduce in %%d runs" %% REPEAT


def test_fixed_firmware_stays_in_band(workload_bench):
    for _ in range(MANIFEST["verdict_rules"]["fixed"]["repeats"]):
        assert workload_bench.run_workload(MANIFEST, MANIFEST["firmware"]["fixed"])["metric"] <= BAND
'''

WORKLOAD_CONFTEST = '''"""Workload bench fixture: implement run_workload(manifest, firmware) -> {"metric": value} on the hardware bench
(ADK / PCMark driven by your tooling, metric read from the result file). Without it the tests are skipped."""
import pytest


class _NoBench:
    def run_workload(self, manifest, firmware):
        pytest.skip("workload tests need the hardware bench (implement run_workload in this conftest)")


@pytest.fixture(scope="module")
def workload_bench():
    return _NoBench()


def pytest_configure(config):
    config.addinivalue_line("markers", "card(id): signature class the test guards")
'''


def emit_workload_test(suite_dir, manifest):
    d = os.path.join(suite_dir, manifest["test_id"])
    os.makedirs(d, exist_ok=True)
    wl = manifest.get("workload") or {}
    body = WORKLOAD_PYTEST % {"wl": wl.get("assessment"), "title": (manifest.get("signature") or {}).get("detail") or "", "sid": manifest.get("signature_id"),
                              "compose": _composition_doc(manifest), "man": pprint.pformat(manifest, width=110), "card": manifest["card"], "metric": wl.get("metric_id")}
    files = {"manifest.json": json.dumps(manifest, indent=1),
             "test_%s.py" % manifest["test_id"].replace("-", "_").replace("/", "_").replace(".", "_"): body, "conftest.py": WORKLOAD_CONFTEST}
    for name, text in files.items():
        with open(os.path.join(d, name), "w") as f:
            f.write(text)
    return d, sorted(files)


def verify_closed_loop(bench, bench_fixed, scenario, n_bad=6, n_fixed=3, optimal_consecutive=OPTIMAL_CONSECUTIVE, field_rule=None):
    """Execute the contract now (what the rendered pytest will do later) and report the numbers.
    Each known-bad run gets a score = checks passed out of 3 (loop_rules.score_checks: same error type isolated,
    same first rule, verdict CONFIRMED) and the three checks as words. 'optimal' = all 3 checks passed
    (score > SCORE_THRESHOLD) in `optimal_consecutive` consecutive runs - the diagram's "test score > 0.9 three
    times consecutively"."""
    hits, scores, checks, run, best_run = [], [], [], 0, 0
    expected = getattr(bench, "expected", set()) or {getattr(bench, "sig", None)}
    for _ in range(n_bad):
        res = bench.run(scenario)
        h = bool(res["isolated"])
        hits.append(h)
        scores.append(signature_score(res["isolated"], expected, field_rule))
        _, c = best_finding(res["isolated"], expected, field_rule)
        checks.append(c or score_checks(None, expected, field_rule))
        run = run + 1 if h else 0
        best_run = max(best_run, run)
    bad = sum(hits)
    fixed = sum(bool(bench_fixed.run(scenario)["isolated_top1"]) for _ in range(n_fixed))
    streak = consecutive_above(scores, SCORE_THRESHOLD)
    return {"known_bad_hits": bad, "known_bad_n": n_bad, "wilson_lower95": round(wilson_lower(bad, n_bad), 3),
            "max_consecutive_hits": best_run, "scores": scores, "checks": checks, "score_threshold": SCORE_THRESHOLD,
            "max_consecutive_score_hits": streak, "optimal_rule": "all 3 checks passed in %d consecutive lab runs" % optimal_consecutive,
            "optimal": streak >= optimal_consecutive, "fixed_hits": fixed, "fixed_n": n_fixed, "passed": bad >= 1 and fixed == 0}
