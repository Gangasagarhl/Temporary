"""Admin action vocabulary (v3) -> primitive events -> weight updates. No training; every action is an event.

Each action is applied through `apply(db, graph, action)` where `action` is the JSON object the UI sends:
  {"action": <name>, "sig": <card>, "requester": <admin id>, "approver": <second admin or null>,
   "targets": [<candidate ids>], "ranking": [<candidate ids in admin order>], "note": "...",
   "content": {...}, "evidence_refs": [<packet numbers>], "event_id": <for undo>}
Candidate ids are the retrieval doc ids: "cause::<sig>::<cid>", "sol::<vhash>", "case::", "lesson::".

Weight semantics (research note admin_feedback_actions.md, retrieval note B6):
  accept               success on the chosen cause edge (a+1) and on the chosen procedure edge+node (r=1)
  accept_with_note     accept + lesson (the note travels with the procedure)
  revise               content changes, counts kept but shrunk toward the prior (edit_shrink); NO success credit
  reject               failure on the rejected item only (b+1); items the admin did not touch are not punished
  not_reproducible     technical-validation failure (tb+1 on the cause edge, r=0 on the procedure), lesson; the
                       cause's correctness counts (a, b) are untouched: "could not reproduce" != "wrong"
  wrong_signature      stage-1 attribution disputed: nothing on causes; lesson + dispute record for stage 1
  duplicate_of         merge drop -> keep (counts union, procedures re-pointed, both histories kept as events)
  rerank / prefer      Plackett-Luce rating only (never counted as success); tie = no update
  promote              four-eyes approval of a validated procedure (approver != producer)
  deprecate            two-person deprecation of an approved procedure (failure credit on its node)
  delete_request       stored; takes effect only with delete_approve by another admin (soft delete)
  undo                 marks the event undone and rebuilds every projection
  skip / defer         impression logged, no weights touched (feedback fatigue is not a signal)
  escalate             needs more evidence: lesson + flag, no weights
  lesson               a plain note about this error (e.g. "the AI reviewer's new proposal is not correct: ..."): lesson only,
                       no weights - used when the judged item is not stored (nothing to blame), the next prompt sees it
  add_cause            new cause node + success credit on it; optional blame on the item it replaces
  add_procedure        admin-authored procedure -> 'proposed' (must still pass execution + approval)
  link                 reuse another signature's procedure under this cause (REPRODUCED_BY copy, prior counts)
  split                new cause from part of an existing one (node_create + node_edit)
  compose_tests        "generate test case": the AI reviewer composes test variants from the STORED sequences of this error; each is
                       run on the bench, kept only if it reproduces, filed with its sources; no weights, never auto-approved
  restart_failed       the diagram's "Negative Ack (-1)": the failed trial is recorded (b+1 AND tb+1 on the cause edge,
                       r=0 on the procedure edge, a lesson) and the search RESTARTS on the next random stream
  sweep                "vulnerability analysis": the neighbourhood of the reproducing procedure is swept (timing x0.5/x2,
                       power states, bursts, jammer faults when the bench has one); the failure-prone variants are
                       filed as tests (most stressful first); no weights, never auto-approved
"""
import json

VERDICT_ON_CANDIDATE = ("accept", "accept_with_note", "revise", "reject", "not_reproducible", "wrong_signature", "duplicate_of")
ORDERING = ("rerank", "prefer", "tie")
LIFECYCLE = ("promote", "deprecate", "delete_request", "delete_approve", "undo", "skip", "defer", "escalate", "lesson", "restart_failed")
STRUCTURE = ("add_cause", "add_procedure", "link", "split", "compose_tests", "sweep")
ALL = VERDICT_ON_CANDIDATE + ORDERING + LIFECYCLE + STRUCTURE
TWO_PERSON = {"promote", "deprecate"}      # delete_approve checks against the ORIGINAL delete_request's actor


def available(seen_before, has_candidates):
    """Which actions the UI should offer for this presentation."""
    acts = ["skip", "defer", "escalate", "lesson", "add_cause", "add_procedure", "compose_tests", "sweep", "restart_failed", "wrong_signature"]
    if has_candidates:
        acts = ["accept", "accept_with_note", "revise", "reject", "not_reproducible", "rerank", "prefer", "tie",
                "duplicate_of", "link", "split", "delete_request", "delete_approve", "undo"] + acts
    if seen_before in ("match", "ambiguous"):
        acts = ["promote", "deprecate"] + acts
    return acts


def parse_target(t):
    """'cause::SIG::cid' -> ('cause', sig, cid);  'sol::vhash' -> ('solution', vhash)."""
    parts = t.split("::")
    if parts[0] == "cause" and len(parts) == 3:
        return ("cause", parts[1], parts[2])
    if parts[0] == "sol" and len(parts) == 2:
        return ("solution", parts[1])
    if parts[0] in ("case", "lesson", "sig"):
        return (parts[0],) + tuple(parts[1:])
    return ("unknown", t)


def _solution(db, vhash):
    r = db.con.execute("SELECT sig,cause,scenario,status,producer,context_hash FROM solution WHERE vhash=?", (vhash,)).fetchone()
    return None if r is None else {"vhash": vhash, "sig": r[0], "cause": r[1], "scenario": json.loads(r[2]), "status": r[3],
                                   "producer": r[4], "context_hash": r[5]}


def apply(db, graph, action, shown_ids=None, tokens=None, firmware=None):
    """Apply one admin action. Returns {"events": [ids], "effects": [str], "error": str|None}."""
    name = action.get("action")
    sig = action.get("sig")
    who = action.get("requester", "admin")
    appr = action.get("approver")
    targets = action.get("targets") or []
    note = (action.get("note") or "")[:400]
    ev, fx = [], []
    log = lambda k, p, a=who: ev.append(db.apply_event(k, p, a))
    if name not in ALL:
        return {"events": [], "effects": [], "error": "unknown action %s" % name}
    if name in TWO_PERSON and (not appr or appr == who):
        return {"events": [], "effects": [], "error": "%s needs a second admin (approver != requester)" % name}
    # impression record (for counterfactual evaluation of the ranker; position + policy are logged by the presenter)
    log("admin_action", {"action": name, "sig": sig, "targets": targets, "ranking": action.get("ranking"),
                         "note": note, "approver": appr, "evidence_refs": action.get("evidence_refs", []),
                         "shown": shown_ids or [], "incident": action.get("incident"), "run": action.get("run")})
    if name in ("skip", "defer"):
        fx.append("recorded; nothing else changes")
        return {"events": ev, "effects": fx, "error": None}
    if name == "escalate":
        log("lesson", {"sig": sig, "cause": None, "text": "ESCALATED: needs more evidence. " + note, "producer": who})
        fx.append("recorded; nothing else changes")
        return {"events": ev, "effects": fx, "error": None}
    if name == "lesson":
        cause = next((parse_target(t)[2] for t in targets if parse_target(t)[0] == "cause"), None)
        vhash = next((parse_target(t)[1] for t in targets if parse_target(t)[0] == "solution"), None)
        log("lesson", {"sig": sig, "cause": cause, "vhash": vhash, "text": "ADMIN NOTE: " + note, "producer": who})
        fx.append("recorded; nothing else changes")
        return {"events": ev, "effects": fx, "error": None}
    if name == "undo":
        db.undo(int(action["event_id"]), who)
        fx.append("decision %s undone" % action["event_id"])
        return {"events": ev, "effects": fx, "error": None}
    if name == "wrong_signature":
        log("lesson", {"sig": sig, "cause": None, "text": "SIGNATURE DISPUTED by admin: " + note, "producer": who})
        log("signature_dispute", {"sig": sig, "note": note, "evidence_refs": action.get("evidence_refs", [])})
        fx.append("recorded for the analysis team")
        return {"events": ev, "effects": fx, "error": None}

    # ---------------- ordering
    if name in ("rerank", "prefer"):
        order = action.get("ranking") or targets
        cids = [parse_target(t)[2] for t in order if parse_target(t)[0] == "cause"]
        if len(cids) >= 2:
            log("ranking", {"sig": sig, "ranking": cids})
            fx.append("your order was recorded")
        sols = [parse_target(t)[1] for t in order if parse_target(t)[0] == "solution"]
        if len(sols) >= 2:
            log("proc_rank", {"ranking": ["scn::" + vh for vh in sols]})
            fx.append("your order was recorded")
        return {"events": ev, "effects": fx, "error": None}
    if name == "tie":
        fx.append("recorded; nothing else changes")
        return {"events": ev, "effects": fx, "error": None}

    # ---------------- verdicts on candidates
    if name in ("accept", "accept_with_note"):
        for t in targets:
            p = parse_target(t)
            if p[0] == "cause":
                log("verdict", {"sig": p[1], "verdict": "correct", "chosen": p[2], "tokens": tokens or [], "firmware": firmware,
                                "lab_result": True})
                fx.append("marked correct (+1)")
            elif p[0] == "solution":
                sol = _solution(db, p[1])
                if sol:
                    e_id = graph.edge_id("REPRODUCED_BY", db.nid(sol["sig"], sol["cause"]), "scn::" + p[1])
                    log("proc_credit", {"edge_id": e_id, "node_id": "scn::" + p[1], "r": 1.0})
                    log("verdict", {"sig": sol["sig"], "verdict": "correct", "chosen": sol["cause"], "tokens": tokens or [],
                                    "firmware": firmware, "lab_result": True})
                    fx.append("marked correct (+1)")
            if name == "accept_with_note" and note:
                log("lesson", {"sig": sig, "cause": p[2] if p[0] == "cause" else None, "vhash": p[1] if p[0] == "solution" else None,
                               "text": "ADMIN NOTE on accept: " + note, "producer": who})
        return {"events": ev, "effects": fx, "error": None}
    if name == "revise":
        for t in targets:
            p = parse_target(t)
            if p[0] == "cause":
                log("node_edit", {"sig": p[1], "node_id": p[2], "content": action.get("content", {})})
                fx.append("revised; the new version is run in the lab before it is saved")
            elif p[0] == "solution":
                sol = _solution(db, p[1])
                if sol:
                    e_id = graph.edge_id("REPRODUCED_BY", db.nid(sol["sig"], sol["cause"]), "scn::" + p[1])
                    log("proc_edge_edit", {"edge_id": e_id, "props": {"admin_revision": action.get("content", {}), "note": note}})
                    fx.append("revised; the new version is run in the lab before it is saved")
        return {"events": ev, "effects": fx, "error": None}
    if name == "reject":
        for t in targets:
            p = parse_target(t)
            if p[0] == "cause":
                log("verdict", {"sig": p[1], "verdict": "not", "rejected": p[2], "tokens": tokens or [], "firmware": firmware})
                fx.append("marked not correct (-1)")
            elif p[0] == "solution":
                sol = _solution(db, p[1])
                if sol:
                    e_id = graph.edge_id("REPRODUCED_BY", db.nid(sol["sig"], sol["cause"]), "scn::" + p[1])
                    log("proc_credit", {"edge_id": e_id, "node_id": "scn::" + p[1], "r": 0.0})
                    fx.append("marked not correct (-1)")
        return {"events": ev, "effects": fx, "error": None}
    if name == "not_reproducible":
        for t in targets:
            p = parse_target(t)
            if p[0] == "cause":
                log("verdict", {"sig": p[1], "verdict": "lab", "chosen": p[2], "tokens": [], "firmware": firmware, "lab_result": False})
                fx.append("recorded: did not reproduce on the drive")
            elif p[0] == "solution":
                sol = _solution(db, p[1])
                if sol:
                    e_id = graph.edge_id("REPRODUCED_BY", db.nid(sol["sig"], sol["cause"]), "scn::" + p[1])
                    log("proc_credit", {"edge_id": e_id, "r": 0.0})
                    log("lesson", {"sig": sol["sig"], "cause": sol["cause"], "vhash": p[1],
                                   "text": "NOT REPRODUCIBLE by admin in %s: %s" % (firmware, note), "producer": who})
                    fx.append("recorded: did not reproduce on the drive")
        return {"events": ev, "effects": fx, "error": None}
    if name == "duplicate_of":
        if len(targets) == 2 and parse_target(targets[0])[0] == "cause" and parse_target(targets[1])[0] == "cause":
            drop, keep = parse_target(targets[0]), parse_target(targets[1])
            log("merge", {"sig": sig, "keep": keep[2], "drop": drop[2]})
            fx.append("merged into one cause")
        else:
            return {"events": ev, "effects": fx, "error": "duplicate_of needs targets [drop, keep] of kind cause"}
        return {"events": ev, "effects": fx, "error": None}

    # ---------------- lifecycle
    if name == "promote":
        for t in targets:
            p = parse_target(t)
            if p[0] == "solution":
                sol = _solution(db, p[1])
                if sol:
                    log("solution_approve", {"vhash": p[1], "sig": sol["sig"], "cause": sol["cause"], "approved_by": appr}, appr)
                    st = _solution(db, p[1])["status"]
                    fx.append("approved" if st == "admin-approved" else "status is now %s" % st)
        return {"events": ev, "effects": fx, "error": None}
    if name == "deprecate":
        for t in targets:
            p = parse_target(t)
            if p[0] == "solution":
                log("solution_deprecate", {"vhash": p[1], "requested_by": who, "approved_by": appr}, appr)
                fx.append("retired")
        return {"events": ev, "effects": fx, "error": None}
    if name == "delete_request":
        for t in targets:
            p = parse_target(t)
            if p[0] == "cause":
                log("delete_request", {"sig": p[1], "node_id": p[2], "requested_by": who, "note": note})
                fx.append("delete requested; a second admin must approve it")
        return {"events": ev, "effects": fx, "error": None}
    if name == "delete_approve":
        for t in targets:
            p = parse_target(t)
            if p[0] == "cause":
                req = db.con.execute("SELECT actor FROM event WHERE kind='delete_request' AND payload LIKE ? AND undone=0 "
                                     "ORDER BY id DESC LIMIT 1", ('%%"node_id": "%s"%%' % p[2],)).fetchone()
                if req is None:
                    return {"events": ev, "effects": fx, "error": "no pending delete_request for %s" % p[2]}
                requester, approver = req[0], appr or who
                if requester == approver:
                    return {"events": ev, "effects": fx, "error": "delete needs a second admin (approver != requester of the delete)"}
                log("soft_delete", {"sig": p[1], "node_id": p[2], "requested_by": requester, "approved_by": approver}, approver)
                fx.append("deleted")
        return {"events": ev, "effects": fx, "error": None}

    if name == "restart_failed":                      # Negative Ack (-1): record the failed trial, then the search restarts
        for t in targets:
            p = parse_target(t)
            if p[0] == "cause":
                log("verdict", {"sig": p[1], "verdict": "not", "rejected": p[2], "tokens": [], "firmware": firmware})        # the edge weight goes down (b+1)
                log("verdict", {"sig": p[1], "verdict": "lab", "chosen": p[2], "tokens": [], "firmware": firmware, "lab_result": False})   # and the technical count
                fx.append("failed trial recorded (-1); the search starts again")
            elif p[0] == "solution":
                sol = _solution(db, p[1])
                if sol:
                    e_id = graph.edge_id("REPRODUCED_BY", db.nid(sol["sig"], sol["cause"]), "scn::" + p[1])
                    log("proc_credit", {"edge_id": e_id, "r": 0.0})
                    fx.append("failed trial recorded (-1); the search starts again")
        log("lesson", {"sig": sig, "cause": None, "text": "FAILED TRIAL recorded by %s; the search starts again: %s" % (who, note or "the error did not appear within the limits"), "producer": who})
        return {"events": ev, "effects": fx, "error": None}
    # ---------------- structure
    if name == "sweep":
        fx.append("sweep started")
        return {"events": ev, "effects": fx, "error": None}
    if name == "compose_tests":
        fx.append("test variants being made")
        return {"events": ev, "effects": fx, "error": None}
    if name == "add_cause":
        cid = action.get("node_id") or "c%d" % len(db.causes(sig))
        log("node_create", {"sig": sig, "node_id": cid, "content": action.get("content", {"text": note})})
        rejected = next((parse_target(t)[2] for t in targets if parse_target(t)[0] == "cause"), None)
        log("verdict", {"sig": sig, "verdict": "not", "chosen": cid, "rejected": rejected, "tokens": tokens or [], "firmware": firmware})
        fx.append("your cause was saved and marked correct (+1)%s" % ("; the shown one marked not correct (-1)" if rejected else ""))
        return {"events": ev, "effects": fx, "error": None, "node_id": cid}
    if name == "add_procedure":
        import hashlib
        from compose import clean_scenario
        sc, problems, fatal = clean_scenario(action.get("content") or {})
        if fatal:
            return {"events": ev, "effects": fx, "error": "procedure rejected: %s" % "; ".join(problems)}
        if problems:
            fx.append("your procedure was corrected before saving: %s" % "; ".join(problems))
        cid = next((parse_target(t)[2] for t in targets if parse_target(t)[0] == "cause"), None) or (db.causes(sig) or ["c0"])[0]
        vh = hashlib.sha256(json.dumps(sc, sort_keys=True).encode()).hexdigest()[:16]
        log("solution_propose", {"vhash": vh, "sig": sig, "cause": cid, "scenario": sc, "context_hash": action.get("context_hash", ""),
                                 "producer": "admin:" + who})
        fx.append("your procedure was saved and will now be run in the lab")
        return {"events": ev, "effects": fx, "error": None, "vhash": vh}
    if name == "link":
        src_sol = next((parse_target(t)[1] for t in targets if parse_target(t)[0] == "solution"), None)
        cid = next((parse_target(t)[2] for t in targets if parse_target(t)[0] == "cause"), None) or (db.causes(sig) or ["c0"])[0]
        sol = _solution(db, src_sol) if src_sol else None
        if not sol:
            return {"events": ev, "effects": fx, "error": "link needs a solution target"}
        import hashlib
        sc = dict(sol["scenario"])
        sc["_linked_from"] = src_sol
        vh = hashlib.sha256(json.dumps(sc, sort_keys=True).encode()).hexdigest()[:16]
        log("solution_propose", {"vhash": vh, "sig": sig, "cause": cid, "scenario": sc, "context_hash": action.get("context_hash", ""),
                                 "producer": "link:" + who, "supersedes": None})
        fx.append("your procedure was saved and will now be run in the lab")
        return {"events": ev, "effects": fx, "error": None, "vhash": vh}
    if name == "split":
        src = next((parse_target(t) for t in targets if parse_target(t)[0] == "cause"), None)
        if not src:
            return {"events": ev, "effects": fx, "error": "split needs a cause target"}
        new_id = action.get("node_id") or "c%d" % len(db.causes(sig))
        log("node_create", {"sig": sig, "node_id": new_id, "content": action.get("content", {}).get("new", {"text": note})})
        log("node_edit", {"sig": sig, "node_id": src[2], "content": action.get("content", {}).get("old", {})})
        fx.append("split into two causes")
        return {"events": ev, "effects": fx, "error": None, "node_id": new_id}
    return {"events": ev, "effects": fx, "error": "unhandled"}


ACTION_SCHEMA = {
    "type": "object",
    "properties": {
        "action": {"type": "string", "enum": list(ALL)},
        "sig": {"type": "string"}, "requester": {"type": "string"}, "approver": {"type": ["string", "null"]},
        "targets": {"type": "array", "items": {"type": "string"}},
        "ranking": {"type": "array", "items": {"type": "string"}},
        "note": {"type": "string"}, "content": {"type": "object"},
        "evidence_refs": {"type": "array", "items": {"type": "integer"}},
        "event_id": {"type": ["integer", "null"]},
    },
    "required": ["action", "sig", "requester"],
}
