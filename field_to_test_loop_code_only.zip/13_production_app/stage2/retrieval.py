"""Layered retrieval over the (initially empty) knowledge DB: exact signature id -> structured field match
-> weighted token similarity, boosted by retained cases. No model, no training."""
import math


class Retriever:
    def __init__(self, db):
        self.db = db
        self._idf = None
        self._n = 0

    def _refresh(self):
        sigs = self.db.all_signatures()
        if len(sigs) == self._n:
            return sigs
        df = {}
        for s in sigs.values():
            for t in s["feats"]:
                df[t] = df.get(t, 0) + 1
        self._idf = {t: math.log(1 + len(sigs) / d) for t, d in df.items()}
        self._n = len(sigs)
        return sigs

    def wjac(self, a, b):
        idf = self._idf or {}
        inter = sum(idf.get(t, 1.0) for t in a & b)
        union = sum(idf.get(t, 1.0) for t in a | b)
        return inter / union if union else 0.0

    def signatures(self, obs, k=3):
        """Return [(sig, similarity)], best first. Layer 1: detector's card id. Layer 2: analyzer's
        own retrieval list (if provided). Layer 3: token similarity against known signatures + cases."""
        sigs = self._refresh()
        hint = obs["detector"].get("card_hint")
        out = {}
        if hint:
            out[hint] = 1.0
        for s, sim in obs.get("retrieval", [])[:5]:
            out[s] = max(out.get(s, 0.0), sim * (0.5 if hint else 1.0))
        toks = set(obs["tokens"])
        if not hint:
            for sig, meta in sigs.items():
                if sig in out:
                    continue
                best = self.wjac(toks, meta["feats"])
                for c in self.db.cases(sig, 10):
                    inter = len(toks & c)
                    if inter:
                        best = max(best, inter / len(toks | c))
                if best > 0.15:
                    out[sig] = max(out.get(sig, 0.0), best)
        ranked = sorted(out.items(), key=lambda x: -x[1])[:k]
        return ranked
