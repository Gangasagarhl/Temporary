"""Procedural property graph on top of the event log (v3).

Procedures live on EDGES and on NODES:
  node kinds  signature | cause | scenario (the procedure: ordered steps with timing) | test | lesson | context
  edge kinds  CAUSED_BY     signature -> cause        counts mirror the human-loop edge (admin verdicts)
              REPRODUCED_BY cause -> scenario         props.procedure = the steps as executed on that edge,
                                                      counts = admin accept / reject of this reproduction
              TESTED_BY     scenario -> test          props = gate result, files
              SUPERSEDES    scenario -> scenario      version chain of approved solutions
              LESSON_ABOUT  lesson -> cause|scenario
              IN_CONTEXT    scenario -> context       firmware / platform the procedure was validated in
Every node and edge carries Beta-Bernoulli counts (a, b, n) and a status; props are JSON. The tables are pure
projections of KGDB's event table (registered as a hook), so undo / rebuild keep them consistent.

PostgreSQL note: swap TEXT props for JSONB; the recursive CTE in `procedure_chain` is standard SQL.
"""
import json

SCHEMA = """
CREATE TABLE IF NOT EXISTS pnode (
  id TEXT PRIMARY KEY, kind TEXT, sig TEXT, props TEXT, a REAL DEFAULT 1, b REAL DEFAULT 1, n INTEGER DEFAULT 0,
  pl REAL DEFAULT 0, status TEXT DEFAULT 'active', ver INTEGER DEFAULT 1, created_event INTEGER, updated_event INTEGER);
CREATE TABLE IF NOT EXISTS pnode_version (node_id TEXT, ver INTEGER, props TEXT, event_id INTEGER,
  PRIMARY KEY (node_id, ver));
CREATE TABLE IF NOT EXISTS pedge (
  id TEXT PRIMARY KEY, kind TEXT, src TEXT, dst TEXT, props TEXT, a REAL DEFAULT 1, b REAL DEFAULT 1,
  n INTEGER DEFAULT 0, status TEXT DEFAULT 'active', created_event INTEGER, updated_event INTEGER);
CREATE INDEX IF NOT EXISTS ix_pnode_sig ON pnode(sig, kind);
CREATE INDEX IF NOT EXISTS ix_pedge_src ON pedge(src, kind);
CREATE INDEX IF NOT EXISTS ix_pedge_dst ON pedge(dst, kind);
"""
TABLES = ("pnode", "pnode_version", "pedge")


def steps_of(scenario):
    """The procedure as ordered steps (what goes on the REPRODUCED_BY edge)."""
    t = scenario.get("timing", {})
    out = []
    for i, c in enumerate(scenario.get("commands", [])):
        op = c["op"] if isinstance(c, dict) else str(c)
        st = {"i": i, "op": op, "delay_us": t.get("inter_cmd_us", 50), "qd": t.get("qd", 8),
              "bs_kb": t.get("bs_kb", 4), "burst_len": t.get("burst_len", 16)}
        if isinstance(c, dict):
            for k in ("delay_us", "qd", "bs_kb", "burst_len"):
                if k in c:
                    st[k] = c[k]
        out.append(st)
    return out


class ProcGraph:
    def __init__(self, db):
        self.db = db
        self.con = db.con
        self.con.executescript(SCHEMA)
        db.hooks.append(self)

    # ------------------------------------------------------------------ hook interface
    def reset(self):
        for t in TABLES:
            self.con.execute("DELETE FROM %s" % t)

    def project(self, eid, kind, pl):
        p = self.db.p
        if kind == "incident_seen":
            self._upsert_node(pl["sig"], "signature", pl["sig"], {"pattern": pl.get("pattern", "?")}, eid, bump_seen=True)
        elif kind == "node_create":
            nid = self.db.nid(pl["sig"], pl["node_id"])
            self._upsert_node(nid, pl.get("kind", "cause"), pl["sig"], pl.get("content", {}), eid)
            self._upsert_node(pl["sig"], "signature", pl["sig"], {}, eid)
            self._upsert_edge("CAUSED_BY", pl["sig"], nid, {}, eid)
            self._mirror(pl["sig"], nid)
        elif kind == "node_edit":
            nid = self.db.nid(pl["sig"], pl["node_id"])
            self._new_version(nid, pl["content"], eid)
            self._mirror(pl["sig"], nid)
        elif kind == "verdict":
            for cid in self.db.causes(pl["sig"]):
                self._mirror(pl["sig"], self.db.nid(pl["sig"], cid))
        elif kind == "ranking":
            for cid in pl["ranking"]:
                self._mirror(pl["sig"], self.db.nid(pl["sig"], cid))
        elif kind == "soft_delete":
            if pl.get("approved_by") and pl["approved_by"] != pl.get("requested_by"):
                nid = self.db.nid(pl["sig"], pl["node_id"])
                self.con.execute("UPDATE pnode SET status='deleted', updated_event=? WHERE id=?", (eid, nid))
                self.con.execute("UPDATE pedge SET status='deleted', updated_event=? WHERE dst=? AND kind='CAUSED_BY'", (eid, nid))
        elif kind == "merge":
            keep, drop = self.db.nid(pl["sig"], pl["keep"]), self.db.nid(pl["sig"], pl["drop"])
            self.con.execute("UPDATE pnode SET status='merged', updated_event=? WHERE id=?", (eid, drop))
            # procedures of the dropped cause are re-pointed to the kept cause; both histories survive as events
            for (e_id, dst, props, a, b, n, status) in self.con.execute(
                    "SELECT id,dst,props,a,b,n,status FROM pedge WHERE src=? AND kind='REPRODUCED_BY'", (drop,)).fetchall():
                self.con.execute("UPDATE pedge SET status='merged', updated_event=? WHERE id=?", (eid, e_id))
                self._upsert_edge("REPRODUCED_BY", keep, dst, json.loads(props), eid, counts=(a, b, n))
            self._mirror(pl["sig"], keep)
            self._mirror(pl["sig"], drop)
        elif kind == "firmware_change":
            for t in ("pnode", "pedge"):
                self.con.execute("UPDATE %s SET a=1+(a-1)*?, b=1+(b-1)*?, updated_event=?" % t,
                                 (p["fw_halve"], p["fw_halve"], eid))
            self._upsert_node("ctx::" + pl.get("to", "?"), "context", None, {"firmware": pl.get("to")}, eid)
        elif kind == "solution_propose":
            sid = "scn::" + pl["vhash"]
            sc = pl["scenario"]
            self._upsert_node(sid, "scenario", pl["sig"], {"scenario": sc, "status": "proposed",
                                                           "producer": pl.get("producer"), "context_hash": pl.get("context_hash"),
                                                           "repro_lower95": pl.get("repro_lower95")}, eid)
            cause = self.db.nid(pl["sig"], pl["cause"])
            self._upsert_edge("REPRODUCED_BY", cause, sid, {"procedure": steps_of(sc), "timing": sc.get("timing", {}),
                                                            "power_state": sc.get("power_state", "none"),
                                                            "context_hash": pl.get("context_hash")}, eid)
            if pl.get("context_hash"):
                self._upsert_node("ctx::" + pl["context_hash"], "context", None, {"context_hash": pl["context_hash"]}, eid)
                self._upsert_edge("IN_CONTEXT", sid, "ctx::" + pl["context_hash"], {}, eid)
            if pl.get("supersedes"):
                self._upsert_edge("SUPERSEDES", sid, "scn::" + pl["supersedes"], {}, eid)
        elif kind == "solution_validate":
            sid = "scn::" + pl["vhash"]
            st = "validated-by-execution" if pl["repro_lower95"] > 0 else "failed-validation"
            self._patch_props(sid, {"status": st, "repro_lower95": pl["repro_lower95"]}, eid)
            for (e_id,) in self.con.execute("SELECT id FROM pedge WHERE dst=? AND kind='REPRODUCED_BY'", (sid,)).fetchall():
                self._patch_edge_props(e_id, {"repro_lower95": pl["repro_lower95"]}, eid)
                self._credit_edge(e_id, 1.0 if pl["repro_lower95"] >= 0.5 else 0.0)
        elif kind == "solution_approve":
            r = self.con.execute("SELECT status FROM solution WHERE vhash=?", (pl["vhash"],)).fetchone()
            if r and r[0] == "admin-approved":
                sid = "scn::" + pl["vhash"]
                self._patch_props(sid, {"status": "admin-approved", "approved_by": pl.get("approved_by")}, eid)
                self._credit_node(sid, 1.0)
                for (other,) in self.con.execute(
                        "SELECT vhash FROM solution WHERE sig=? AND cause=? AND vhash<>? AND status='superseded'",
                        (pl["sig"], pl["cause"], pl["vhash"])).fetchall():
                    self._patch_props("scn::" + other, {"status": "superseded"}, eid)
        elif kind == "solution_deprecate":
            if pl.get("approved_by") and pl["approved_by"] != pl.get("requested_by"):
                self._patch_props("scn::" + pl["vhash"], {"status": "deprecated"}, eid)
                self._credit_node("scn::" + pl["vhash"], 0.0)
        elif kind == "lesson":
            lid = "lesson::%d" % eid
            self._upsert_node(lid, "lesson", pl["sig"], {"text": pl["text"][:400], "producer": pl.get("producer")}, eid)
            tgt = ("scn::" + pl["vhash"]) if pl.get("vhash") else (self.db.nid(pl["sig"], pl["cause"]) if pl.get("cause") else pl["sig"])
            self._upsert_edge("LESSON_ABOUT", lid, tgt, {}, eid)
        elif kind == "script_gate":
            if pl.get("vhash"):
                tid = "test::%s::%d" % (pl["vhash"], eid)
                self._upsert_node(tid, "test", pl.get("sig"), {"gate": pl.get("gate"), "admitted": pl.get("admitted"),
                                                               "files": pl.get("files", [])}, eid)
                self._upsert_edge("TESTED_BY", "scn::" + pl["vhash"], tid, {"admitted": pl.get("admitted")}, eid)
        elif kind == "proc_credit":                       # admin feedback on a procedure (edge) or a node
            if pl.get("edge_id"):
                self._credit_edge(pl["edge_id"], float(pl["r"]))
            if pl.get("node_id"):
                self._credit_node(pl["node_id"], float(pl["r"]))
        elif kind == "proc_rank":                         # admin ordering of procedures -> Plackett-Luce rating only
            import math
            ids = [i for i in pl["ranking"] if self.con.execute("SELECT 1 FROM pnode WHERE id=?", (i,)).fetchone()]
            sk = [self.con.execute("SELECT pl FROM pnode WHERE id=?", (i,)).fetchone()[0] for i in ids]
            eta = 0.3
            for i in range(len(ids)):
                denom = sum(math.exp(x) for x in sk[i:])
                for m in range(i, len(ids)):
                    pr = math.exp(sk[m]) / denom
                    sk[m] += eta * ((1 - pr) if m == i else -pr) / max(1, len(ids))
            for i, v in zip(ids, sk):
                self.con.execute("UPDATE pnode SET pl=?, updated_event=? WHERE id=?", (v, eid, i))
        elif kind == "proc_edge_edit":                    # admin revises the procedure on an edge: new props, counts shrink
            e = self.con.execute("SELECT props,a,b FROM pedge WHERE id=?", (pl["edge_id"],)).fetchone()
            if e:
                props = json.loads(e[0])
                props.update(pl["props"])
                sh = p["edit_shrink"]
                self.con.execute("UPDATE pedge SET props=?, a=1+(a-1)*?, b=1+(b-1)*?, updated_event=? WHERE id=?",
                                 (json.dumps(props, sort_keys=True), sh, sh, eid, pl["edge_id"]))

    # ------------------------------------------------------------------ writers (projection only)
    def _upsert_node(self, nid, kind, sig, props, eid, bump_seen=False, counts=None):
        r = self.con.execute("SELECT props, ver FROM pnode WHERE id=?", (nid,)).fetchone()
        if r is None:
            a, b, n = counts or (1.0, 1.0, 0)
            if bump_seen:
                props = dict(props, seen=1)
            self.con.execute("INSERT INTO pnode(id,kind,sig,props,a,b,n,status,ver,created_event,updated_event) "
                             "VALUES(?,?,?,?,?,?,?,'active',1,?,?)", (nid, kind, sig, json.dumps(props, sort_keys=True), a, b, n, eid, eid))
            self.con.execute("INSERT OR REPLACE INTO pnode_version(node_id,ver,props,event_id) VALUES(?,1,?,?)",
                             (nid, json.dumps(props, sort_keys=True), eid))
        elif props or bump_seen:
            old = json.loads(r[0])
            if bump_seen:
                old["seen"] = old.get("seen", 0) + 1
            old.update(props)
            self.con.execute("UPDATE pnode SET props=?, updated_event=? WHERE id=?", (json.dumps(old, sort_keys=True), eid, nid))

    def _new_version(self, nid, props, eid):
        r = self.con.execute("SELECT props, ver FROM pnode WHERE id=?", (nid,)).fetchone()
        if r is None:
            return
        old = json.loads(r[0])
        old.update(props)
        ver = r[1] + 1
        self.con.execute("UPDATE pnode SET props=?, ver=?, updated_event=? WHERE id=?", (json.dumps(old, sort_keys=True), ver, eid, nid))
        self.con.execute("INSERT OR REPLACE INTO pnode_version(node_id,ver,props,event_id) VALUES(?,?,?,?)",
                         (nid, ver, json.dumps(old, sort_keys=True), eid))

    def _patch_props(self, nid, props, eid):
        r = self.con.execute("SELECT props FROM pnode WHERE id=?", (nid,)).fetchone()
        if r is None:
            return
        old = json.loads(r[0])
        old.update(props)
        self.con.execute("UPDATE pnode SET props=?, updated_event=? WHERE id=?", (json.dumps(old, sort_keys=True), eid, nid))

    @staticmethod
    def edge_id(kind, src, dst):
        return "%s|%s|%s" % (kind, src, dst)

    def _upsert_edge(self, kind, src, dst, props, eid, counts=None):
        e_id = self.edge_id(kind, src, dst)
        r = self.con.execute("SELECT props FROM pedge WHERE id=?", (e_id,)).fetchone()
        if r is None:
            a, b, n = counts or (1.0, 1.0, 0)
            self.con.execute("INSERT INTO pedge(id,kind,src,dst,props,a,b,n,status,created_event,updated_event) "
                             "VALUES(?,?,?,?,?,?,?,?,'active',?,?)", (e_id, kind, src, dst, json.dumps(props, sort_keys=True), a, b, n, eid, eid))
        elif props:
            old = json.loads(r[0])
            old.update(props)
            self.con.execute("UPDATE pedge SET props=?, status='active', updated_event=? WHERE id=?",
                             (json.dumps(old, sort_keys=True), eid, e_id))
        return e_id

    def _patch_edge_props(self, e_id, props, eid):
        r = self.con.execute("SELECT props FROM pedge WHERE id=?", (e_id,)).fetchone()
        if r:
            old = json.loads(r[0])
            old.update(props)
            self.con.execute("UPDATE pedge SET props=?, updated_event=? WHERE id=?", (json.dumps(old, sort_keys=True), eid, e_id))

    def _mirror(self, sig, nid):
        """CAUSED_BY counts mirror the human-loop edge the benchmarked C2 policy maintains."""
        e = self.db.cache.get((sig, nid))
        if e is None:
            return
        self.con.execute("UPDATE pedge SET a=?, b=?, n=?, status=? WHERE id=?",
                         (e["a"], e["b"], e["n"], e["status"], self.edge_id("CAUSED_BY", sig, nid)))

    def _credit(self, table, id_, r):
        row = self.con.execute("SELECT a,b,n FROM %s WHERE id=?" % table, (id_,)).fetchone()
        if row is None:
            return
        a, b, n = row[0] + r, row[1] + (1 - r), row[2] + 1
        cap = self.db.p["cap"]
        if a + b > cap:
            a, b = a * cap / (a + b), b * cap / (a + b)
        self.con.execute("UPDATE %s SET a=?, b=?, n=? WHERE id=?" % table, (a, b, n, id_))

    def _credit_edge(self, e_id, r):
        self._credit("pedge", e_id, r)

    def _credit_node(self, nid, r):
        self._credit("pnode", nid, r)

    # ------------------------------------------------------------------ queries
    def node(self, nid):
        r = self.con.execute("SELECT id,kind,sig,props,a,b,n,status,ver,pl FROM pnode WHERE id=?", (nid,)).fetchone()
        return None if r is None else self._nrow(r)

    @staticmethod
    def _nrow(r):
        return {"id": r[0], "kind": r[1], "sig": r[2], "props": json.loads(r[3]), "a": r[4], "b": r[5], "n": r[6],
                "status": r[7], "ver": r[8], "pl": r[9] if len(r) > 9 else 0.0, "posterior": r[4] / (r[4] + r[5])}

    @staticmethod
    def _erow(r):
        return {"id": r[0], "kind": r[1], "src": r[2], "dst": r[3], "props": json.loads(r[4]), "a": r[5], "b": r[6],
                "n": r[7], "status": r[8], "posterior": r[5] / (r[5] + r[6])}

    def nodes(self, kind=None, sig=None, status="active"):
        q, args = "SELECT id,kind,sig,props,a,b,n,status,ver,pl FROM pnode WHERE 1=1", []
        if kind:
            q += " AND kind=?"; args.append(kind)
        if sig:
            q += " AND sig=?"; args.append(sig)
        if status:
            q += " AND status=?"; args.append(status)
        return [self._nrow(r) for r in self.con.execute(q, args).fetchall()]

    def edges(self, kind=None, src=None, dst=None, status="active"):
        q, args = "SELECT id,kind,src,dst,props,a,b,n,status FROM pedge WHERE 1=1", []
        if kind:
            q += " AND kind=?"; args.append(kind)
        if src:
            q += " AND src=?"; args.append(src)
        if dst:
            q += " AND dst=?"; args.append(dst)
        if status:
            q += " AND status=?"; args.append(status)
        return [self._erow(r) for r in self.con.execute(q, args).fetchall()]

    def procedures_for(self, sig, statuses=("admin-approved", "validated-by-execution")):
        """Every procedure reachable from a signature: sig -CAUSED_BY-> cause -REPRODUCED_BY-> scenario, with the
        counts of both hops and the scenario node. One row per procedure edge."""
        rows = self.con.execute(
            "SELECT c.id, c.a, c.b, c.n, r.id, r.props, r.a, r.b, r.n, s.id, s.props, s.a, s.b, s.n, s.status "
            "FROM pedge c JOIN pedge r ON r.src=c.dst AND r.kind='REPRODUCED_BY' AND r.status='active' "
            "JOIN pnode s ON s.id=r.dst WHERE c.src=? AND c.kind='CAUSED_BY' AND c.status='active'", (sig,)).fetchall()
        out = []
        for r in rows:
            sprops = json.loads(r[10])
            if statuses and sprops.get("status") not in statuses:
                continue
            out.append({"cause": r[0], "cause_post": r[1] / (r[1] + r[2]), "cause_n": r[3],
                        "edge_id": r[4], "procedure": json.loads(r[5]), "edge_post": r[6] / (r[6] + r[7]), "edge_n": r[8],
                        "scenario_id": r[9], "scenario": sprops.get("scenario"), "scenario_status": sprops.get("status"),
                        "repro_lower95": sprops.get("repro_lower95"), "scenario_post": r[11] / (r[11] + r[12]),
                        "scenario_n": r[13], "context_hash": sprops.get("context_hash")})
        return out

    def procedure_chain(self, scenario_id):
        """SUPERSEDES chain back to the first version (recursive CTE)."""
        rows = self.con.execute("""
            WITH RECURSIVE chain(id, depth) AS (
                SELECT ?, 0
                UNION ALL
                SELECT e.dst, chain.depth + 1 FROM pedge e JOIN chain ON e.src = chain.id
                WHERE e.kind = 'SUPERSEDES' AND chain.depth < 50)
            SELECT c.id, c.depth, n.props FROM chain c JOIN pnode n ON n.id = c.id ORDER BY c.depth""",
                                (scenario_id,)).fetchall()
        return [{"id": r[0], "depth": r[1], "status": json.loads(r[2]).get("status")} for r in rows]

    def tests_for(self, scenario_id):
        return [dict(e, test=self.node(e["dst"])) for e in self.edges("TESTED_BY", src=scenario_id)]

    def lessons_about(self, target_id):
        return [self.node(e["src"]) for e in self.edges("LESSON_ABOUT", dst=target_id)]

    def stats(self):
        q = lambda s, *a: self.con.execute(s, a).fetchone()[0]
        out = {"pnodes": q("SELECT COUNT(*) FROM pnode"), "pedges": q("SELECT COUNT(*) FROM pedge")}
        for k in ("signature", "cause", "scenario", "test", "lesson", "context"):
            out["n_" + k] = q("SELECT COUNT(*) FROM pnode WHERE kind=? AND status='active'", k)
        for k in ("CAUSED_BY", "REPRODUCED_BY", "TESTED_BY", "SUPERSEDES", "LESSON_ABOUT", "IN_CONTEXT"):
            out["e_" + k] = q("SELECT COUNT(*) FROM pedge WHERE kind=? AND status='active'", k)
        return out
