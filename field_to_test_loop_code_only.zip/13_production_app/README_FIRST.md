# Read me first: Field-to-Test Loop

**What it is.** A web application that runs on one server. An engineer gives it the path of a protocol-analyzer
capture of PCI Express (PCIe) / NVM Express (NVMe) traffic, exported as a 113-column CSV (comma-separated values)
file. **Stage 1** isolates every defect in the capture using rules taken from the specifications; an AI reviewer
(a large language model, LLM) gives a second opinion but never decides. **Stage 2** looks each defect up in a
knowledge base (`db/knowledge.sqlite`), an admin decides (**Correct** / **Needs changes** / **Not correct** and 23
more decisions), the lab reproduces the defect (a search over command sequences and timing, then a "most stressful
conditions" step), a lab check runs it on known-bad and fixed firmware, and a regression test is written to
`suite/`. No model is ever trained; the application learns by counting decisions and lab results.

**Read in this order**

| You are | Read |
|---|---|
| An engineer or AI coding agent installing or running it | 1. `deploy/AGENT_INSTRUCTIONS.md` (the master runbook: rules, ordered checklist, troubleshooting, report template) · 2. `deploy/INSTALL.md` and `deploy/DEPLOY.md` · 3. `deploy/OPERATIONS.md` (day to day) · 4. `deploy/BENCH_INTEGRATION.md` (connecting a real lab bench) |
| An operator or manager using it | `docs/OPERATOR_AND_BACKEND_GUIDE.html` (open in a browser: every screen and button, what happens behind it, how to check it) · then "Decide these three things before production" below |
| Someone checking what changed | `docs/CHANGES_2026-10-27.md` · `README.md` (design and background) |

**Quick start** (Linux, Python 3.10 or newer; for a first look on your own machine — production goes through
`deploy/AGENT_INSTRUCTIONS.md`)

```bash
unzip <archive>.zip && cd 13_production_app        # every later command runs in this folder
python3 restore_names.py                            # ONLY for the mail-safe archive (*_MAIL_SAFE.zip): renames the 10 browser scripts back to .js
python3 -m venv .venv && . .venv/bin/activate
python3 -m pip install -r deploy/requirements.txt
python3 deploy/preflight.py                         # PASS / WARN / FAIL per check; fix every FAIL (shipped config: 25 PASS, 2 WARN)
./run_tests.sh                                      # offline tests, about 90-110 s: expect "OK" (or "OK (skipped=1)"); writes ~166 MB to runs/_bench (may be deleted)
python3 run_app.py                                  # open http://127.0.0.1:8077   (--port N for another port; --standin = no model)
```

A first run from a synthetic sample through stage 2, the lab check and the regression test, without a browser, is
a copy-paste walk-through in `deploy/AGENT_INSTRUCTIONS.md` step 2.6 A.

**Decide these three things before production**

1. **The AI endpoint.** Which backend (`llm.backend`: `cli` = the `claude` command-line login, `sdk` = Anthropic API
   or a company gateway, `openai-compat` = any chat-completions endpoint, `standin` = no model), which model, and
   which environment variable holds the key. Keys are never written into files. Only `cli`, `sdk` and `auto` give
   stage 1 its AI second opinion; with `openai-compat`, `ollama` or `standin` stage 1 runs without a model. In
   production set `server.lock_endpoint: true` (`deploy/config.production.example.json`) so the Settings page cannot
   redirect the key to another server.
2. **A real lab bench, or simulated.** With `stage2.bench = "synthetic"` (the shipped setting) every lab run is
   **simulated**: the loop works end to end, but procedures found are not physically meaningful. A real drive needs
   `app/bench_hook.py` implemented (`deploy/BENCH_INTEGRATION.md`) and `stage2.bench = "hook"`.
3. **Who may reach the application.** It has **no login of its own** and the operator names are typed by the users
   themselves. It listens on 127.0.0.1 only and must be reached through an authenticating reverse proxy
   (`deploy/DEPLOY.md`). Name at least two admins: approving, retiring and deleting need a second, real person.
