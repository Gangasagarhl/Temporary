# Read me first: Field-to-Test Loop

**What it is.** A web application that runs on one server. An engineer gives it the path of a protocol-analyzer
capture of PCI Express (PCIe) / NVM Express (NVMe) traffic, exported as a 113-column CSV (comma-separated values)
file. **Stage 1** isolates every defect in the capture using rules taken from the specifications; an AI reviewer
(a large language model, LLM) gives a second opinion but never decides. **Stage 2** looks each defect up in a
knowledge base (`db/knowledge.sqlite`), an admin decides (**Correct** / **Needs changes** / **Not correct** and 23
more decisions), the lab reproduces the defect (a search over command sequences and timing, then a "most stressful
conditions" step), a lab check runs it on known-bad and fixed firmware, and a regression test is written to
`suite/`. No model is ever trained; the application learns by counting decisions and lab results.

**Read in this order**

| You are | Read |
|---|---|
| An engineer or AI coding agent installing or running it | 1. `deploy/AGENT_INSTRUCTIONS.md` (the master runbook: rules, ordered checklist, troubleshooting, report template) · 2. `deploy/INSTALL.md` and `deploy/DEPLOY.md` · 3. `deploy/OPERATIONS.md` (day to day) · 4. `deploy/BENCH_INTEGRATION.md` (connecting a real lab bench) |
| An operator or manager using it | `docs/APPLICATION_MAP.html` (open in a browser: every button and every piece of content, one entry each, with an arrow chain from the click to the database and back, the real code, and numbered screenshots) and `docs/OPERATOR_AND_BACKEND_GUIDE.html` (the background: what the numbers mean, the learning rules, the lab, how to check it) · then "Decide these three things before production" below |
| Someone checking what changed | `docs/CHANGES_2026-10-27.md` · `README.md` (design and background) |

**Quick start** (Linux, Python 3.10 or newer; for a first look on your own machine — production goes through
`deploy/AGENT_INSTRUCTIONS.md`)

```bash
unzip <archive>.zip && cd 13_production_app        # every later command runs in this folder
python3 restore_names.py                            # ONLY for the mail-safe archive (*_MAIL_SAFE.zip): renames the 10 browser scripts back to .js
python3 -m venv .venv && . .venv/bin/activate
python3 -m pip install -r deploy/requirements.txt
python3 deploy/preflight.py                         # PASS / WARN / FAIL per check; fix every FAIL (shipped config: 25 PASS, 2 WARN)
./run_tests.sh                                      # offline tests, about 90-110 s: expect "OK" (or "OK (skipped=1)"); writes ~166 MB to runs/_bench (may be deleted)
python3 run_app.py                                  # open http://127.0.0.1:8077   (--port N for another port; --standin = no model)
```

A first run from a synthetic sample through stage 2, the lab check and the regression test, without a browser, is
a copy-paste walk-through in `deploy/AGENT_INSTRUCTIONS.md` step 2.6 A.

**Decide these three things before production**

1. **The AI endpoint.** Which backend (`llm.backend`: `cli` = the `claude` command-line login, `sdk` = Anthropic API
   or a company gateway, `openai-compat` = any chat-completions endpoint, `standin` = no model), which model, and
   which environment variable holds the key. Keys are never written into files. Only `cli`, `sdk` and `auto` give
   stage 1 its AI second opinion; with `openai-compat`, `ollama` or `standin` stage 1 runs without a model. In
   production set `server.lock_endpoint: true` (`deploy/config.production.example.json`) so the Settings page cannot
   redirect the key to another server.
2. **A real lab bench, or simulated.** With `stage2.bench = "synthetic"` (the shipped setting) every lab run is
   **simulated**: the loop works end to end, but procedures found are not physically meaningful. A real drive needs
   `app/bench_hook.py` implemented (`deploy/BENCH_INTEGRATION.md`) and `stage2.bench = "hook"`.
3. **Who may reach the application.** It has **no login of its own** and the operator names are typed by the users
   themselves. It listens on 127.0.0.1 only and must be reached through an authenticating reverse proxy
   (`deploy/DEPLOY.md`). Name at least two admins: approving, retiring and deleting need a second, real person.

## Comparing with the analyzer's own error list

The analyzer software (Reports > Error Summary) counts 72 kinds of packet errors. Save that report as a CSV file
(columns Type, Upstream, Downstream, Sideband, Total), put it next to the trace as `Errors.csv` or type its path in
the "Analyzer error summary" box of step 1, and step 2 shows a table: every kind, the analyzer's count, this
analysis's count, and the reason when a kind cannot be seen. For the best match, export the trace with the
analyzer's **Errors** column included: without it, the analyzer writes some error packets without a packet number
and without the error name, and those kinds can only be reported as packets that could not be decoded.


## Step 3 · NVMe commands (added 2026-10-29)

After stage 1 the new step 3 leads with the errors found under NVMe commands, one row per failed command: the command, the parameters
it carries (decoded as NVMe Base 2.0 and the NVM Command Set define them), the measured latency of each step with a
label whose basis is stated (host driver limits, the capture's own percentiles), and the low-level PCIe packets and
errors under it. It needs the payload bytes (hex DATA or the side-car). Runs made before this version have no
command summary until stage 1 is run again. `docs/FAQ.html` entry 41 explains the page.
