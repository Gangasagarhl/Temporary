"""Part C of the button-by-button map: Step 4 · "All details" (screen S4D).

The area behind "All details (the AI reviewer's explanation, candidates, every admin action, history, editor)" on
http://127.0.0.1:8077/?run=run-20261026-145008-0220#review/INC-0001 : the three tabs, the saved procedure next to the
AI reviewer's proposal, the top candidates, the three-step "Other decisions" form with all 26 decision tiles, the
keyboard keys, the procedure editor, the "Earlier decisions on this error type" table, the Stage 1 evidence tab, the
Result tab and the Undo message.

Format: docs/ui_map_src/SCHEMA.md. Examples quote values read (read-only) from this installation on 27 Oct 2026, or,
where marked "scratch copy", values observed in a private copy of the application (stand-in AI reviewer, a T-42
sample made with seed 5) in which every one of the 26 decisions was sent once to see exactly what it writes.
"""

RJ = "app/static/js/review.js"
DJ = "app/static/js/decision.js"
AJ = "app/static/js/api.js"
MJ = "app/static/js/main.js"
IH = "app/static/index.html"
AA = "stage2/admin_actions.py"
KG = "stage2/kgdb.py"
PG = "stage2/procgraph.py"
PR = "stage2/presenter.py"
RV = "stage2/retrieval_v3.py"
V3 = "stage2/stage2_v3.py"
SV = "app/stage2_service.py"
SA = "app/api/stage2_api.py"

ELEMENTS = []


def js(path, marker, n=None):
    return "js:%s::%s" % (path, marker) + ("::%d" % n if n else "")


def py(path, name, start=None, stop=None):
    r = "py:%s::%s" % (path, name)
    if start:
        r += "::" + start
        if stop:
            r += "::" + stop
    return r


def S(layer, text, ref=None):
    d = {"layer": layer, "text": text}
    if ref:
        d["ref"] = ref
    return d


def E(id, group, label, kind, selector, what, why, when, chain, code=None, example=""):
    ELEMENTS.append({"id": id, "screen": "S4D", "group": group, "label": label, "kind": kind, "selector": selector,
                     "what": what, "why": why, "when": when, "chain": chain, "code": code or [], "example": example})


# ---------------------------------------------------------------------------------------------------------------
# references used many times
# ---------------------------------------------------------------------------------------------------------------
R_AVAILABLE = py(AA, "available")
R_APPLY = py(AA, "apply")
R_APPLY_HEAD = py(AA, "apply", "name = action.get(\"action\")", "if name in (\"skip\", \"defer\")")
R_ACT_API = py(SA, "act")
R_ACT_SVC = py(SV, "Stage2Service.act")
R_JOB = py(SV, "Stage2Service._execute_job")
R_EXEC_APPLY = py(V3, "Stage2V3.execute", "res = apply_action(", "out[\"rules\"] = rules_summary()")
R_EXEC_LAB = py(V3, "Stage2V3.execute", "# ---------------- which cause, which stored procedure", "# ---------------- bench (closed loop) and device model")
R_EXEC_REUSE = py(V3, "Stage2V3.execute", "if mode == \"reuse\" and action[\"action\"] == \"add_procedure\"", "self.counters[mode] += 1")
R_EXEC_SEARCH = py(V3, "Stage2V3.execute", "# ---------------- proposal (LLM or stand-in)", "if out[\"triage_timeout\"]")
R_FINISH_LOOP = py(V3, "Stage2V3._finish", "# ---------------- closed loop: the test that mimics the isolation", "# ---------------- the most stressful conditions")
R_FINISH_APPROVE = py(V3, "Stage2V3._finish", "# ---------------- four-eyes approval", "extra = [f for f in")
R_VERDICT = py(KG, "KGDB._project", "elif kind == \"verdict\"", "elif kind == \"ranking\"")
R_CREDIT = py(KG, "KGDB._credit")
R_PROC_CREDIT = py(PG, "ProcGraph.project", "elif kind == \"proc_credit\"", "elif kind == \"proc_rank\"")
R_PG_CREDIT = py(PG, "ProcGraph._credit")
R_START = js(RJ, "function startAction(name)", 15)
R_CONFIRM = js(RJ, "function confirmAction()", 6)
R_DOACTION = js(RJ, "async function doAction(", 20)
R_RECEIPT = js(RJ, "const RECEIPT = {", 10)
R_RESULT = js(RJ, "function renderResult(r)", 11)
R_UNDOFOR = js(RJ, "function undoFor(res)", 5)

ACT_URL = "POST /api/runs/<run>/incidents/<defect>/act  "
NEWREC_ADD_PROCEDURE = ("What happens next: your procedure is run first in the lab; if it reproduces the defect it is "
                        "kept as validated in the lab (under your name) and checked on known-bad and fixed firmware. "
                        "Approving it as the saved procedure is a separate decision by a second admin.")
SRV_TEXT = ("stage2_api.act checks that stage 1 has finished and that stage 2 was started for this run (otherwise 409), then "
            "passes the decision to the stage-2 service. A refusal from the decision itself comes back as \"action_error\" "
            "inside a normal 200 answer.")
SVC_DIRECT = ("Stage2Service.act fills in the error type and your name (empty name: the run's operator, else \"admin\"), "
              "stamps every event with the run, defect, device, firmware and person, and - because this decision does not "
              "need the lab - applies it at once under the stage-2 lock, commits db/knowledge.sqlite and appends the result "
              "to runs/<run>/stage2/<defect>.json (Stage2Service._record).")
SVC_JOB = ("Stage2Service.act sees a lab decision (one of SEARCH_ACTIONS in stage2/stage2_v3.py) and queues it as a "
           "background job (job table in db/app.sqlite); the answer {\"job\": id} comes back at once. The job "
           "(Stage2Service._execute_job) takes the stage-2 lock, runs Stage2V3.execute, commits and records the result.")
EXEC_TEXT = ("Stage2V3.execute first calls admin_actions.apply with your decision and the list of records the lookup showed; "
             "apply always writes one admin_action event first (decision, targets, ranking, note, second admin, shown "
             "records, run, defect), then the branch for this decision.")


# ===============================================================================================================
# 1. Why these things are here (explanations first)
# ===============================================================================================================
G0 = "Why these things are here"

E("s4d-why-tiles", G0, "Why exactly these 26 decision tiles appear", "display", "#r-actions",
  "Step 2 of the form (\"What do you want to do?\") shows one tile per decision the knowledge base understands, sorted "
  "into six groups. The list of decisions is not written in the page: the server decides which decisions make sense "
  "for this defect when it looks the defect up, and the page only draws them. The full vocabulary is the 26 names in "
  "ALL in stage2/admin_actions.py (7 verdicts on a record, 3 orderings, 10 life-cycle decisions, 6 structure "
  "decisions). available(seen_before, has_candidates) picks from it: 10 are always offered (Skip, Defer, Needs more "
  "evidence, Record a lesson, Add a cause, Add a procedure, Generate test cases, Try nearby variations, Restart the "
  "search after a failed attempt, Dispute the stage-1 finding); 14 more when the lookup found at least one record "
  "(Accept, Accept with a note, Revise the text, Reject, Could not be reproduced, Record my ranking, Prefer this one, "
  "Tie, Mark as a duplicate, Link to another, Split, Request deletion, Approve the deletion, Undo a decision); 2 more "
  "(Approve as second admin, Retire the procedure) only when the lookup says the defect was seen before (\"match\" or "
  "\"ambiguous\"), because only then is there a saved procedure to approve or retire. 10 + 14 + 2 = 26. "
  "The page groups them with GROUPS in review.js: (1) \"Judge the ticked procedure\" - Accept, Accept with a note, "
  "Revise the text, Reject, Could not be reproduced: a verdict on one record; (2) \"Order or compare procedures\" - "
  "Record my ranking, Prefer this one, Tie: relative judgements; (3) \"Tidy the knowledge base\" - Approve as second "
  "admin, Retire the procedure, Mark as a duplicate, Link to another, Split, Request deletion, Approve the deletion: "
  "the life cycle and structure of stored records; (4) \"Add what you know\" - Record a lesson, Add a cause, Add a "
  "procedure, Needs more evidence, Dispute the stage-1 finding: knowledge the system does not have; (5) \"Run more in "
  "the lab\" - Generate test cases, Try nearby variations, Restart the search after a failed attempt; (6) \"Put it "
  "aside\" - Skip, Defer, Undo a decision. Each tile shows its name (actionWord in decision.js), a one-line meaning "
  "(ACTION_HELP in app/api/__init__.py, sent to the page by GET /api/config) and grey tags from NEED and TAGS in "
  "review.js saying what it needs (\"needs one ticked record\", \"needs two ticked records\", \"needs an order (click "
  "the candidates)\", \"asks for a reason\", \"needs a second admin\", \"asks which decision\", \"runs in the lab, "
  "takes minutes\"). Green tiles (Accept, Accept with a note, Add a cause) give credit, red tiles (Reject, Could not be "
  "reproduced, Dispute) take it away, yellow tiles (Approve as second admin, Retire the procedure, Approve the "
  "deletion) need two people.",
  "The project asks that the administrator's feedback - positive, negative, partial, re-ordering - teaches the "
  "knowledge base without training a model. Every kind of feedback therefore needs its own, precisely defined "
  "decision, because each one changes different counters (a correct cause must not be blamed when only the lab bench "
  "failed; an order is not a success). The groups exist so a manager can find a decision by intent: judging one "
  "record, comparing records, keeping the knowledge base tidy under a two-person rule, adding knowledge, asking for "
  "more lab work, or not deciding now (not deciding is deliberately not a signal). Offering only what makes sense "
  "(no Approve when nothing was seen before) prevents decisions that could only fail.",
  "Shown when All details is open, after the defect was looked up. A group whose decisions are all missing from the "
  "offered list is left out.",
  [S("database", "The lookup reads the knowledge base db/knowledge.sqlite (solution, node, edge, pnode, pedge, lesson "
                 "tables) to find records for this error type."),
   S("engine", "Stage2V3.present runs the hybrid lookup (HybridIndex.query) and decides \"seen before\" "
               "(HybridIndex.seen_before: match / ambiguous / new).", py(V3, "Stage2V3.present")),
   S("engine", "admin_actions.available(seen_before, has_candidates) returns the offered decisions: 10 always, +14 when "
               "the lookup returned any record, +2 (promote, deprecate) when seen before is match or ambiguous. ALL holds "
               "the 26 names.", R_AVAILABLE),
   S("engine", "presenter.build_card puts that list into the card: card[\"actions\"] = available(seen, bool(shown)).",
     py(PR, "build_card", "\"actions\": available(seen, bool(shown))", "if llm is None")),
   S("service", "Stage2Service.present copies card[\"actions\"] into view[\"actions\"] and saves the whole view in "
                "runs/<run>/stage2/<defect>.json, so the next visit reuses it without a new lookup.",
     py(SV, "Stage2Service.present")),
   S("http", "GET /api/runs/<run>/incidents/<defect> returns the saved view under stage2.view (POST "
             "/api/runs/<run>/incidents/<defect>/present makes a new one); GET /api/config returns the tile texts "
             "(ACTION_HELP) as \"actions\"."),
   S("browser", "review.js renderView walks GROUPS, keeps the names that are in view.actions, and draws one button "
                ".atile per decision with actionWord, the ACTION_HELP text and the NEED/TAGS tags; the colour class "
                "is go / two / neg.", js(RJ, "const box = $(\"r-actions\"); box.innerHTML = \"\"", 11)),
   S("screen", "Up to six groups of tiles under \"2 What do you want to do?\"; clicking one opens step 3 (Confirm).")],
  code=[py(AA, "available"), js(RJ, "const GROUPS = [", 12)],
  example="On this page (run run-20261026-145008-0220, Defect 1, error type T-42, seen before = match) only 23 tiles "
          "in 5 groups are drawn: the view in runs/run-20261026-145008-0220/stage2/INC-0001.json was saved by the "
          "lookup of 26 Oct 2026 14:50, and its action list has no compose_tests, sweep or restart_failed, which the "
          "current available() always offers (stage2/admin_actions.py was changed on 27 Oct 2026 00:53). \"Look up "
          "again\" would store the current list of 26. Scratch copy: a never-seen error type got 24 tiles (seen before "
          "= new, so no Approve / Retire); after one decision the same defect was a match and got all 26.")

E("s4d-why-history", G0, "Where the 'Earlier decisions on this error type' rows come from and why there are so many",
  "display", "#r-history",
  "The table at the bottom of the tab lists every decision any admin recorded on this error type (here T-42), from "
  "any run and any defect, newest first, at most 50. It is read from the event table of the knowledge base: "
  "Stage2Service.feedback_history selects the admin_action events and the script_gate events (the lab check that "
  "files a regression test) whose payload names this error type and that were not undone; each decision is paired "
  "with the next lab check of the same error type, which becomes its \"Lab outcome\". Each decision gets a polarity: "
  "positive = Accept, Accept with a note, Approve as second admin, Add a procedure, Add a cause; negative = Reject, "
  "Could not be reproduced, Dispute the stage-1 finding, Retire the procedure, Request deletion, Approve the deletion, "
  "and a lesson whose note starts with \"NOT CORRECT\" (what \"Not correct\" on the AI (artificial intelligence) "
  "reviewer's proposal writes on the main screen); everything else is neutral. "
  "Why so many rows on this laptop: the database was filled mostly by the automated tests. tests/exercise_loop.py "
  "drives the running application through captures with T-42 (cards \"T-42,L-21,C-16\" and \"T-42,L-21,M-039\") and "
  "sends, as requester \"admin\", accept, compose_tests, sweep, reject (note \"exercise: timing is wrong for this "
  "firmware\"), add_procedure, rerank, not_reproducible (note \"exercise: bench silent\"), revise, deprecate (then "
  "undone), skip, defer and escalate (note \"exercise\"), plus add_cause when nothing is stored and restart_failed "
  "when a defect did not reproduce. tests/ui_smoke.py drives this very screen in a browser "
  "(ranking + Save decisions, Not correct on the proposal, Save corrected version, Correct, Generate test cases, Try "
  "nearby variations); when \"Your name\" is empty the server records \"admin\". Every run of these tests adds the "
  "same dozen rows again. A production database starts empty (stage2/kgdb.py: \"The database starts EMPTY\") and "
  "contains only real decisions.",
  "The project requires that every decision is kept with who, when and why, and that the next person sees earlier "
  "negative feedback before trusting a saved procedure. Pairing a decision with the lab check that followed shows "
  "whether the decision held up in the lab.",
  "Loaded each time a defect is shown (after the lookup), for that defect's error type.",
  [S("database", "db/knowledge.sqlite, table event: rows of kind admin_action (written first by every decision) and "
                 "script_gate (written by the lab check); undone = 0 only; payload LIKE '%\"sig\": \"T-42\"%'."),
   S("service", "Stage2Service.feedback_history(sig, limit=50) builds one row per admin_action (event id, time, actor, "
                "decision, targets, note, second admin, defect, run, polarity) and attaches the first following "
                "script_gate of the same error type as outcome {admitted, known_bad hits/runs, fixed hits/runs}; "
                "returns the newest 50.", py(SV, "Stage2Service.feedback_history")),
   S("server", "The route takes the stage-2 lock and returns {sig, history}.", py(SA, "feedback")),
   S("http", "GET /api/db/feedback/<error type>   (for example /api/db/feedback/T-42)"),
   S("browser", "review.js loadHistory(sig) counts positive and negative rows, shows the yellow callout for the newest "
                "negative one, and draws the chips and the table.", js(RJ, "async function loadHistory(sig)", 11)),
   S("screen", "The three chips and the five-column table under \"Earlier decisions on this error type\".")],
  code=[py(SV, "Stage2Service.feedback_history")],
  example="Read-only on 27 Oct 2026: the event table holds 1178 events; 162 are admin_action events for T-42 (11 of "
          "them undone - the exercise's deprecate + undo), 160 by \"admin\" and 2 by \"tester one\"; their notes are "
          "\"exercise: timing is wrong for this firmware\" (11), \"exercise: bench silent\" (11), \"exercise\" (9), "
          "three \"NOT CORRECT: the LLM's new proposal …\" lessons and 128 empty notes. The first is from 26 Oct 2026 "
          "13:27, the newest from 27 Oct 2026 12:59 (Try nearby variations by admin). Of the 151 that were not undone "
          "the table shows the newest 50.")

E("s4d-hist-chips", G0, "50 decisions · 20 positive · 5 negative", "display", "#r-history .chips",
  "Three counters above the history table: the number of rows listed (\"decisions\"), how many of them are positive "
  "and how many are negative. Neutral rows (orderings, Tie, Skip, Defer, Needs more evidence, lessons, Generate test "
  "cases, Try nearby variations, Restart the search …) have no chip of their own: they are the difference. The first "
  "number is the length of the list, and the list is cut at 50, so \"50\" means \"50 or more\".",
  "A manager sees at a glance whether this error type has a history of approval or of rejection before reading the "
  "rows.",
  "Shown when at least one decision exists for this error type; otherwise the text \"no decision recorded for this "
  "error type yet\".",
  [S("database", "event table: admin_action and script_gate events of this error type, not undone."),
   S("service", "Stage2Service.feedback_history gives each row polarity positive / negative / neutral and returns at "
                "most limit=50 rows, newest first.", py(SV, "Stage2Service.feedback_history", "\"polarity\": \"positive\"", "\"outcome\": None}")),
   S("http", "GET /api/db/feedback/<error type>"),
   S("browser", "loadHistory: h.length, the count of polarity \"positive\" and of \"negative\".",
     js(RJ, "const pos = h.filter(x => x.polarity === \"positive\")", 2)),
   S("screen", "Chips \"<n> decisions\", \"<n> positive\", \"<n> negative\".")],
  example="Defect 1 of run run-20261026-145008-0220 (T-42): 50 decisions, 20 positive, 5 negative - the other 25 are "
          "neutral (10 Generate test cases, 9 Try nearby variations, 4 Record my ranking, 2 Revise the text). The event "
          "table holds 151 not-undone T-42 decisions, so the 50 is the cap, not the total.")


# ===============================================================================================================
# 2. The panel and its tabs
# ===============================================================================================================
G1 = "The panel and its tabs"

E("s4d-summary", G1, "All details (the AI reviewer's explanation, candidates, every admin action, history, editor)",
  "button", "#r-advanced > summary",
  "The fold-out line at the bottom of the step-4 card. Clicking it opens (or closes) everything the main screen leaves "
  "out: the AI (artificial intelligence) reviewer's full explanation, the saved procedure next to the proposal, the "
  "lookup's top candidates, the three-step form with every decision, the editor, the history, and two more tabs. The "
  "\"All details\" item in a card's \"…\" menu opens it too and scrolls to it.",
  "The main screen is kept to the everyday decisions (Correct / Needs changes / Not correct) so a manager is not "
  "overwhelmed; the engineer still needs every detail and every decision the knowledge base offers, one click away.",
  "Hidden until the defect has been looked up and the decision view is drawn (renderDecision un-hides it). Opening it "
  "sends nothing to the server.",
  [S("you", "You click the line \"All details …\" (or \"All details\" in a card's … menu)."),
   S("browser", "The <details id=\"r-advanced\"> element opens; the content was already filled by renderView and "
                "renderResult. The card menu calls engineer(), which sets open = true and scrolls.",
     js(RJ, "engineer: () => { $(\"r-advanced\").open = true;", 1)),
   S("browser", "renderDecision un-hides the element once GET …/solutions has answered.", js(RJ, "async function renderDecision()", 3)),
   S("screen", "The tabs \"Candidates & actions\", \"Stage 1 evidence\", \"Result\" appear, the first one active.")],
  example="On this page the line reads exactly \"All details (the AI reviewer's explanation, candidates, every admin "
          "action, history, editor)\".")

for sub_, lab_, what_, src_ in (
        ("decision", "Candidates & actions",
         "The first tab: the saved procedure next to the AI (artificial intelligence) reviewer's proposal, the top "
         "candidates, the three-step decision form, the keyboard hint, the editor and the earlier decisions.",
         "renderView (view from the lookup) and loadHistory."),
        ("evidence", "Stage 1 evidence",
         "The second tab: the stage-1 facts of this defect in one table (error type, family, where, why flagged, "
         "mechanism, the AI reviewer's second opinion, failure signature, suggested fix, link to the full record) and "
         "the raw evidence rows of the trace.",
         "open() from GET /api/runs/<run>/incidents/<defect> (incidents.json, isolation.json, incident_rows.jsonl, "
         "llm_reviews.jsonl)."),
        ("result", "Result",
         "The third tab: the outcome of the last decision on this defect as a table (decision and effects, how it ran, "
         "search, lab check on known-bad and fixed firmware, how the search went, most stressful conditions, "
         "procedure, regression tests, time).",
         "renderResult(stage2.last) from runs/<run>/stage2/<defect>.json, or the answer of the decision just sent.")):
    E("s4d-tab-" + sub_, G1, lab_, "tab", "#page-review .tabs button[data-sub=\"%s\"]" % sub_,
      what_,
      "Three tabs keep the decision work, the evidence it rests on and the result of the last decision apart, so each "
      "can be read without scrolling past the others.",
      "Always present inside All details. Opening a defect, and the refresh after every decision, switch back to "
      "\"Candidates & actions\"; most decisions switch to \"Result\" while they are being applied.",
      [S("you", "You click the tab \"%s\"." % lab_),
       S("browser", "The click handler calls sub(\"%s\"), which marks the button active and shows <div id=\"sub-%s\">; "
                    "nothing is sent." % (sub_, sub_), js(RJ, "function sub(name)", 1)),
       S("browser", "The content was filled earlier by " + src_, js(IH, "data-sub=\"decision\"", 1)),
       S("screen", "Only the content of \"%s\" is shown." % lab_)])

E("s4d-callout", G1, "Earlier negative decision on this error type:", "display", "#r-callout",
  "A yellow box at the top of the tab with the newest negative decision on this error type: the decision in words, "
  "who, when and the note, followed by \"The saved procedure below may be the one that was rejected; you can edit "
  "it.\" It does not check whether that decision was about the procedure shown below - it is a warning to look.",
  "Earlier negative feedback must not be lost on the next defect of the same kind: before a manager accepts a saved "
  "procedure again, he sees that someone rejected or could not reproduce something for this error type.",
  "Shown only when the history (newest 50 decisions) contains a negative one; hidden otherwise.",
  [S("database", "event table: admin_action events of this error type (not undone)."),
   S("service", "Stage2Service.feedback_history marks Reject, Could not be reproduced, Dispute, Retire, Request "
                "deletion, Approve the deletion and \"NOT CORRECT…\" lessons as negative.",
     py(SV, "Stage2Service.feedback_history", "\"negative\" if pl.get(\"action\") in", "\"outcome\": None}")),
   S("http", "GET /api/db/feedback/<error type>"),
   S("browser", "loadHistory takes the first negative row (the newest) and writes actionWord(action), actor, local "
                "date/time and note.", js(RJ, "$(\"r-callout\").hidden = !lastNeg", 2)),
   S("screen", "Yellow box \"Earlier negative decision on this error type: …\".")],
  example="Here: \"Earlier negative decision on this error type: Could not be reproduced by admin on 10/26/2026, "
          "11:11:08 PM - \"exercise: bench silent\". The saved procedure below may be the one that was rejected; you "
          "can edit it.\" - written by tests/exercise_loop.py.")


# ===============================================================================================================
# 3. Saved procedure (left panel)
# ===============================================================================================================
G2 = "Saved procedure (left panel)"
STORED_SRC = [
    S("database", "solution table (status, approved_by, repro_lower95), pedge REPRODUCED_BY edge cause → procedure "
                  "(a, b, n), pnode of the procedure, TESTED_BY edges to its tests."),
    S("engine", "presenter.build_card makes card[\"recommended\"] from the best procedure the lookup found (a "
                "superseded, retired or failed one is replaced by the current version of the same cause when there is "
                "one).", py(PR, "build_card", "rec = None", "alts = []")),
    S("service", "Stage2Service.present: view[\"stored\"] = card[\"recommended\"]; saved in runs/<run>/stage2/<defect>.json.",
      py(SV, "Stage2Service.present")),
    S("http", "GET /api/runs/<run>/incidents/<defect> (saved view) or POST …/present (new lookup)."),
]

E("s4d-stored-status", G2, "replaced by a newer version · reproduced in at least 68 % of lab runs (likely)", "display",
  "#r-stored-prov",
  "The grey line next to the heading \"Saved procedure (from the knowledge base)\". First its status in words "
  "(procStatus): \"approved by <name>\" (a second admin approved it), \"awaiting approval by a second admin\" "
  "(reproduced in the lab, not approved), \"replaced by a newer version\" (another procedure of the same cause was "
  "approved later), \"retired\", \"proposed\" … Then \"reproduced in at least X % of lab runs\" with a word: X is "
  "the 95 % lower bound (Wilson) of the lab runs that showed the defect, \"very likely\" from 80 %, \"likely\" from "
  "50 %, \"possible\" from 25 %, else \"unlikely\".",
  "A saved procedure is only trustworthy if a second person approved it and the lab reproduced the defect with it; "
  "the lower bound instead of the plain rate stops six lucky runs from looking like 100 %.",
  "Shown when the lookup found a saved procedure for this error type.",
  STORED_SRC + [
      S("browser", "renderView writes procStatus(status, approved_by), pct(repro_lower95) and likelihood(…).",
        js(RJ, "$(\"r-stored-prov\").textContent", 1)),
      S("screen", "\"<status> · reproduced in at least X % of lab runs (<word>) · admin feedback rating …\"")],
  code=[js(DJ, "export const procStatus", 1), js(DJ, "export function likelihood(p)", 1)],
  example="Here: \"replaced by a newer version · reproduced in at least 68 % of lab runs (likely)\" - procedure "
          "074e18b2… (status superseded, repro_lower95 0.676, approved_by second_admin). The view dates from 26 Oct "
          "2026 14:50; a new lookup would show the current approved version of the same cause instead.")

E("s4d-stored-rating", G2, "admin feedback rating 0.73 from 9 decisions (1 = always judged correct)", "display",
  "#r-stored-prov",
  "The end of the same grey line: the rating of the link \"cause → this procedure\" = a ÷ (a + b), where a and b are "
  "the success and failure counters of that link (both start at 1, so an unjudged procedure has 0.5), and n = the "
  "number of judgements. Accept adds to a; Reject, Could not be reproduced and Restart (on a procedure) add to b; "
  "every procedure the lab validates adds one judgement too (a when at least 50 % reproduced, else b). Revising the procedure "
  "shrinks both toward 1 (×0.7); a and b together are capped at 50.",
  "Learning from feedback without training: the counters are the memory of every decision, and the rating decides "
  "how high the procedure ranks next time.",
  "Shown with the saved procedure.",
  STORED_SRC + [
      S("engine", "build_card: edge_posterior = posterior of the REPRODUCED_BY pedge (a ÷ (a + b)), edge_n = its n.",
        py(PR, "build_card", "\"edge_posterior\": edges[0][\"posterior\"]", "\"judged_correct\"")),
      S("browser", "renderView: fmt(edge_posterior, 2) and edge_n.", js(RJ, "$(\"r-stored-prov\").textContent", 1)),
      S("screen", "\"admin feedback rating 0.73 from 9 decisions (1 = always judged correct)\"")],
  code=[py(PG, "ProcGraph._credit")],
  example="Here: rating 0.73 from 9 decisions for procedure 074e18b2… The candidate list below says \"admins judged it "
          "18 times\" for the same procedure, because the lookup adds the procedure's own counters (pnode) to the "
          "link's (pedge).")

E("s4d-stored-seq", G2, "flush → write  queue depth 8 · 200 µs between commands · 4 KB · burst 16 · idle 1866 ms · power none",
  "display", "#r-stored .seq",
  "The saved procedure itself: the commands in order, then the timing - queue depth, microseconds (µs) between "
  "commands, block size in kilobytes (KB), burst length, idle gap in milliseconds (ms) - and the power state. A value "
  "with a yellow background and \"~\" differs from the AI (artificial intelligence) reviewer's proposal on the right "
  "(commands are compared position by position).",
  "The procedure is what the lab bench will run; showing it next to the fresh proposal with the differences marked "
  "lets the manager judge which one fits the evidence.",
  "Shown with the saved procedure.",
  STORED_SRC + [
      S("browser", "renderView: seq(stored, generated) from api.js marks every command and value that differs.",
        js(AJ, "export function seq(x, diffAgainst = null)", 11)),
      S("screen", "Command chain and timing line, differences highlighted yellow.")],
  example="Here: flush → write, queue depth 8, 200 µs between commands, 4 KB, burst 16, idle 1866 ms, power none - all "
          "highlighted, because the proposal is aspm_idle → read at queue depth 1, 2000 µs, burst 1, idle 2 ms, D3hot.")

E("s4d-stored-tests", G2, "Regression tests  5 filed", "display", "#r-stored .kv > b:nth-of-type(1)",
  "How many regression tests have been filed from this procedure: one per lab check (script_gate event) recorded "
  "for it, each a TESTED_BY link from the procedure to a test node. A lab check that did not pass is counted too "
  "(\"filed\" means a gate result was recorded).",
  "The project's output is regression tests; a procedure that already produced tests is proven useful.",
  "Shown with the saved procedure.",
  STORED_SRC + [
      S("engine", "build_card: tests = graph.tests_for(\"scn::<hash>\") → [{id, admitted}].",
        py(PG, "ProcGraph.tests_for")),
      S("browser", "renderView: (stored.tests || []).length + \" filed\".", js(RJ, "$(\"r-stored\").innerHTML = st ?", 1)),
      S("screen", "\"Regression tests 5 filed\"")],
  example="Here: 5 filed - test::074e18b2b58a5676::16, ::39, ::63, ::97, ::121, all admitted.")

E("s4d-stored-changed", G2, "Changed since it was saved  nothing", "display", "#r-stored .kv > b:nth-of-type(2)",
  "Which facts of this defect differ from the defect the procedure was saved for: error type, family, first rule, "
  "layer, who caused it, verdict and the device-and-firmware fingerprint (\"context hash\"), written as \"rule: now X, "
  "stored Y\". \"nothing\" = the same situation.",
  "A procedure saved on another firmware or for another manifestation may not reproduce here; the manager must know "
  "before reusing it.",
  "Shown with the saved procedure.",
  STORED_SRC + [
      S("engine", "presenter._diff_fields compares the lookup query with the fingerprint (_fingerprint) stored inside "
                  "the procedure.", py(PR, "_diff_fields")),
      S("browser", "renderView: what_changed_vs_stored joined with \"; \" or \"nothing\".", js(RJ, "$(\"r-stored\").innerHTML = st ?", 1)),
      S("screen", "\"Changed since it was saved nothing\"")],
  example="Here: nothing.")

E("s4d-stored-preview", G2, "preview of the regression test", "button", "#r-stored details > summary",
  "A fold-out with the shell script a lab bench would run for this procedure: one fio step per command with the idle "
  "gap between them, ending with the instruction to export the analyzer trace and run the detector for the error type.",
  "The regression test is the deliverable; seeing it before accepting shows exactly what will be run on the drive.",
  "Shown with the saved procedure; closed by default.",
  STORED_SRC + [
      S("engine", "build_card: test_preview = integration.render_shell(error type, cause, procedure).",
        py("stage2/integration.py", "render_shell")),
      S("browser", "renderView puts it into <details><summary>preview of the regression test</summary><pre>…",
        js(RJ, "$(\"r-stored\").innerHTML = st ?", 1)),
      S("screen", "Clicking the line shows the script in a dark box.")],
  example="Here: \"#!/usr/bin/env bash … # generated test for T-42 / c0 … IDLE_MS=1866 … fio step00.fio "
          "--section=step00_flush … fio step01.fio --section=step01_write … echo \"run complete: export analyzer "
          "trace and run the detector for T-42\"\".")

E("s4d-stored-empty", G2, "Nothing saved for this error type yet.", "display", "#r-stored .empty",
  "Instead of the saved procedure: \"Nothing saved for this error type yet. The proposal on the right is the only "
  "one; accepting a cause starts the search from it.\"",
  "Says plainly that there is no earlier knowledge, so the first decision will start a search.",
  "Only when the lookup found no saved procedure (a new error type).",
  [S("database", "No validated, approved or replaced procedure for this error type in the solution table."),
   S("engine", "build_card leaves card[\"recommended\"] = None.", py(PR, "build_card", "rec = None", "alts = []")),
   S("http", "GET /api/runs/<run>/incidents/<defect> or POST …/present"),
   S("browser", "renderView writes the empty text.", js(RJ, "Nothing saved for this error type yet.", 1)),
   S("screen", "Grey text in the left panel.")])


# ===============================================================================================================
# 4. Proposed now by the AI reviewer (right panel)
# ===============================================================================================================
G3 = "Proposed now by the AI reviewer (right panel)"
LLM_SRC = [
    S("engine", "presenter.build_card asks the AI (artificial intelligence) reviewer once per lookup with "
                "_digest_prompt (error type, the lookup's answer, the saved procedure, top candidates, lessons, the "
                "evidence rows) and the answer schema DIGEST_SCHEMA; the answer is checked by code and stored as "
                "card[\"llm\"].", py(PR, "build_card", "# ---------------- LLM digest", "# ---------------- optional listwise rerank")),
    S("files", "db/llm_cache.jsonl keeps every answer; the same question is answered from the cache next time."),
    S("service", "Stage2Service.present: view[\"llm\"] = card[\"llm\"], view[\"generated\"] = its recommended_sequence, "
                 "view[\"llm_problems\"] = the problems the checks found.", py(SV, "Stage2Service.present")),
    S("http", "GET /api/runs/<run>/incidents/<defect> (saved view) or POST …/present"),
]

E("s4d-gen-model", G3, "AI reviewer model anthropic:claude-haiku-5-5:low · fresh model call", "display", "#r-gen-prov",
  "The grey line next to \"Proposed now by the AI reviewer\": which model answered (backend:model:effort) and whether "
  "it was \"fresh model call\" (asked during this lookup) or \"reused from the earlier lookup\" (the same question "
  "answered from the cache file).",
  "Provenance: a manager must know which model produced the text and whether it is new, before relying on it.",
  "Shown when an AI (artificial intelligence) reviewer is configured; with the stand-in (no model) the panel says "
  "\"No AI reviewer configured (stand-in mode): the search starts from the error family's template procedure.\"",
  LLM_SRC + [
      S("browser", "renderView: \"AI reviewer model \" + llm.model + (llm.cached ? \" · reused from the earlier "
                   "lookup\" : \" · fresh model call\").", js(RJ, "$(\"r-gen-prov\").textContent", 1)),
      S("screen", "\"AI reviewer model anthropic:claude-haiku-5-5:low · fresh model call\"")],
  example="Here: \"AI reviewer model anthropic:claude-haiku-5-5:low · fresh model call\" (lookup of 26 Oct 2026 14:50, "
          "27.6 s).")

E("s4d-gen-headline", G3, "T-42 MMIO read 2.000 ms after PMCSR D3hot→D0 write returns UR; …", "display",
  "#r-generated > p:first-child",
  "The bold first line: the AI (artificial intelligence) reviewer's one-sentence summary of what failed and what "
  "triggers it (asked for in at most 25 words; cut at 300 characters).",
  "Gives the manager the gist of the evidence in one sentence before the details.",
  "Shown when the AI reviewer answered.",
  LLM_SRC + [S("browser", "renderView: <p><b>headline</b></p>.", js(RJ, "$(\"r-generated\").innerHTML = l ?", 1)),
             S("screen", "Bold sentence at the top of the right panel.")],
  example="Here: \"T-42 MMIO read 2.000 ms after PMCSR D3hot→D0 write returns UR; stored flush>write procedure lacks the "
          "power transition, so it does not reproduce this.\" (MMIO = memory-mapped input/output, PMCSR = power "
          "management control/status register, UR = Unsupported Request.)")

E("s4d-gen-mechanism", G3, "The host wrote PMCSR=03 (D3hot) in #37387, …", "display", "#r-generated > p:nth-of-type(2)",
  "The second paragraph: how the failure happened, in at most two sentences, citing packets as #N (cut at 600 "
  "characters).",
  "The mechanism ties the proposal to the packets, so it can be checked against the trace.",
  "Shown when the AI reviewer answered.",
  LLM_SRC + [S("browser", "renderView: <p>mechanism</p>.", js(RJ, "$(\"r-generated\").innerHTML = l ?", 1)),
             S("screen", "Paragraph under the headline.")],
  example="Here: \"The host wrote PMCSR=03 (D3hot) in #37387, then PMCSR=00 (D0) in #37391 with Cpl #37393 completing "
          "it. The MRd to FCE0001C in #37395 was issued 2.000 ms later, inside the 10 ms D3hot→D0 recovery window, and "
          "returned UR in #37398.\"")

E("s4d-gen-seq", G3, "aspm_idle → read  queue depth 1 · 2000 µs between commands · 4 KB · burst 1 · idle 2 ms · power D3hot",
  "display", "#r-generated .seq",
  "The procedure the AI (artificial intelligence) reviewer proposes from this evidence, in the same form as the saved "
  "one (commands, queue depth, microseconds between commands, block size, burst, idle gap, power state); values that "
  "differ from the saved procedure are highlighted yellow. Commands outside the bench's twelve are dropped by the "
  "checks.",
  "The proposal is the starting point of the search when nothing is saved, and a second opinion when something is.",
  "Shown when the AI reviewer answered.",
  LLM_SRC + [S("browser", "renderView: seq(generated, stored).", js(AJ, "export function seq(x, diffAgainst = null)", 11)),
             S("screen", "Command chain and timing line in the right panel.")],
  example="Here: aspm_idle → read, queue depth 1, 2000 µs, 4 KB, burst 1, idle 2 ms, power D3hot (all but 4 KB "
          "highlighted).")

E("s4d-gen-assessment", G3, "Assessment  related (differs from the knowledge-base lookup)", "display", "#r-generated .kv > b:nth-of-type(1)",
  "The AI (artificial intelligence) reviewer's own answer to \"seen before?\": same_defect, related, new or unsure, "
  "followed by \"(agrees with the knowledge-base lookup)\" or \"(differs from the knowledge-base lookup)\". It agrees "
  "when same_defect ↔ match, related ↔ ambiguous, new ↔ new.",
  "The lookup decides \"seen before\" by matching records; a second, independent reading of the evidence warns when "
  "the match is only on the surface.",
  "Shown when the AI reviewer answered.",
  LLM_SRC + [S("engine", "presenter._agrees maps the assessment onto the lookup's verdict.", py(PR, "_agrees")),
             S("browser", "renderView: seen_before_assessment + agrees_with_matcher in words.", js(RJ, "$(\"r-generated\").innerHTML = l ?", 1)),
             S("screen", "\"Assessment related (differs from the knowledge-base lookup)\"")],
  example="Here: the lookup says match (\"YES - same defect seen before …\"), the AI reviewer says related → \"differs\".")

E("s4d-gen-keypackets", G3, "Key packets  #37387, #37391, #37393, #37395, #37398", "display", "#r-generated .kv > b:nth-of-type(2)",
  "The two to six packet numbers that decide the case, according to the AI (artificial intelligence) reviewer. Numbers "
  "that are not in this defect's evidence rows are removed by the checks (and reported as a problem).",
  "Every claim must point at packets in the trace; invented packet numbers are filtered out, never shown.",
  "Shown when the AI reviewer answered; \"-\" when none.",
  LLM_SRC + [S("engine", "build_card keeps only key_packets that are among the allowed packet numbers of the evidence.",
               py(PR, "build_card", "pk = [int(p) for p in out.get(\"key_packets\", [])", "rs = out.get(\"recommended_sequence\")")),
             S("browser", "renderView: \"#\" + each number.", js(RJ, "[\"Key packets\", (l.key_packets || [])", 1)),
             S("screen", "\"Key packets #37387, #37391, …\"")],
  example="Here: #37387, #37391, #37393, #37395, #37398.")

E("s4d-gen-differences", G3, "Differences from the saved procedure", "display", "#r-generated .kv > b:nth-of-type(3)",
  "A bullet list, in the AI (artificial intelligence) reviewer's words, of what differs between its proposal and the "
  "saved procedure and why (at most six points of 200 characters).",
  "Explains the yellow highlights: why the proposal deviates from what worked before.",
  "Shown when the AI reviewer answered; \"-\" when the list is empty.",
  LLM_SRC + [S("browser", "renderView: list(l.differences_vs_stored).", js(RJ, "[\"Key packets\", (l.key_packets || [])", 1)),
             S("screen", "Bullet list under \"Differences from the saved procedure\".")],
  example="Here five points, the first: \"Stored procedure is flush>write at qd8 with 200 us spacing and 1866 ms idle "
          "gap; this trigger is a single read 2 ms after a D0 transition, not a write burst.\"")

E("s4d-gen-risks", G3, "Risks", "display", "#r-generated .kv > b:nth-of-type(4)",
  "A bullet list of destructive or unreliable steps the AI (artificial intelligence) reviewer sees in its proposal "
  "(at most six points).",
  "A procedure is run on a real drive; the manager should know what could go wrong before approving it.",
  "Shown when the AI reviewer answered; \"-\" when empty.",
  LLM_SRC + [S("browser", "renderView: list(l.risks).", js(RJ, "[\"Key packets\", (l.key_packets || [])", 1)),
             S("screen", "Bullet list under \"Risks\".")],
  example="Here four points, for example \"Read to an unassigned/UR region may stall or leave the device in an error "
          "state; abort/reset may be needed to recover.\"")

E("s4d-gen-problems", G3, "problems in the proposal found by the analyser's checks:", "display", "#r-generated p.bad",
  "A red line listing what the code checks rejected in the AI (artificial intelligence) reviewer's answer: \"cited "
  "packets not in evidence: […]\", \"unknown ops […]\" (commands the bench cannot send), \"timing <name> out of "
  "range\", or \"digest failed: …\". The checks are in presenter.build_card (not in the stage-1 analyser, despite the "
  "wording).",
  "Nothing the model writes is trusted silently: violations are shown next to the proposal instead of being hidden.",
  "Only when at least one check failed.",
  LLM_SRC + [S("engine", "build_card: packets outside the evidence, commands outside ALLOWED_OPS, timings outside "
                         "TIMING_KEYS ranges → card[\"llm_problems\"].",
               py(PR, "build_card", "problems = []", "card[\"llm\"] = {")),
             S("browser", "renderView adds the red line when view.llm_problems is not empty.",
               js(RJ, "problems in the proposal found by the analyser's checks", 1)),
             S("screen", "Red line at the bottom of the right panel.")],
  example="Not shown here: the answer of 26 Oct 2026 passed every check (llm_problems = []).")

E("s4d-diff-count", G3, "7 difference(s) between the saved procedure and the proposal are highlighted.", "display", "#r-diff",
  "The count under the two panels: one per command that differs by position, one per extra or missing command, one per "
  "timing value that differs (queue depth, microseconds between commands, block size, burst length, idle gap) and one "
  "if the power state differs. \"The proposal matches the saved procedure exactly.\" when the count is 0.",
  "A single number says how far the fresh proposal is from what was saved, before reading the details.",
  "Only when both a saved procedure and a proposal exist.",
  STORED_SRC[:1] + LLM_SRC[3:] + [
      S("browser", "diffCount(stored, generated) in api.js; renderView writes the sentence with the number highlighted.",
        js(AJ, "export function diffCount(a, b)", 8)),
      S("screen", "\"~7 difference(s) between the saved procedure and the proposal are highlighted.\"")],
  example="Here 7: two commands (flush/aspm_idle, write/read), four timing values (queue depth, spacing, burst, idle) "
          "and the power state; the block size (4 KB) is equal.")

# ===============================================================================================================
# 5. Top candidates
# ===============================================================================================================
G4 = "Top candidates"
CAND_SRC = [
    S("database", "Every stored record is a document of the lookup: procedures (solution table: approved, awaiting "
                  "approval, replaced), causes (node, node_version), earlier judged cases (case_memory), the error type "
                  "itself (signature) and lessons (lesson); their counters come from edge, pedge and pnode."),
    S("engine", "HybridIndex.query compares this defect with every document in five ways (structured fields, word "
                "score BM25 = 'best matching 25', letter-triplet similarity, the evidence-row sequence, optional "
                "embeddings), merges the five ranked lists by reciprocal-rank fusion and multiplies by the feedback "
                "factors; it returns the best five.", py(RV, "HybridIndex.query")),
    S("engine", "presenter.build_card turns them into card[\"alternatives\"]: rank, record id, score, posterior, n, "
                "explore, why and a plain summary.", py(PR, "build_card", "alts = []", "fa = inc.first_abnormal or {}")),
    S("service", "Stage2Service.present saves the card with the view in runs/<run>/stage2/<defect>.json.",
      py(SV, "Stage2Service.present")),
    S("http", "GET /api/runs/<run>/incidents/<defect> (saved view) or POST …/present (new lookup)"),
]

E("s4d-cands", G4, "Top candidates (what the knowledge-base lookup found for this error type, best match first)", "table",
  "#r-cands",
  "A numbered list of the five records the knowledge-base lookup ranked highest for this defect, best first. A record "
  "can be a saved procedure, a possible cause, a note (lesson), an earlier judged case of the error type, or the "
  "error type itself. Each line has a title, a status, the match percentage, how often admins judged it and why it "
  "matched (entries below).",
  "The project asks that a recurring defect is recognised and its stored solution offered first; showing the five "
  "best matches with their reasons lets the manager check the lookup instead of trusting a single answer.",
  "Shown after the lookup.",
  CAND_SRC + [S("browser", "renderView draws one <li> per card.alternatives entry with candText and plainWhy.",
                js(RJ, "for (const a of v.card.alternatives) {", 7)),
              S("screen", "List 1-5 under \"Top candidates\".")],
  code=[py(RV, "HybridIndex.query", "fused, parts = {}, {}", "return shown, cands")],
  example="Here: three saved procedures of T-42 (flush, write at 200, 800 and 400 µs between commands) and twice "
          "\"earlier case of T-42\".")

E("s4d-cand-title", G4, "Saved procedure: flush, write · queue depth 8 · 200 µs between commands", "display",
  "#r-cands li .ctitle",
  "The bold title of a line: for a procedure \"Saved procedure: <commands>\" with queue depth, microseconds (µs) "
  "between commands and, when set, idle gap and power state; for a cause \"Possible cause: <text>\"; for a lesson "
  "\"Note: <text>\"; otherwise the server's label (\"earlier case of T-42\" in lookups made before 27 Oct 2026, now "
  "\"an earlier capture with error type T-42\", or \"error type T-42\").",
  "Names each record in words instead of an internal id, so a manager can tell the records apart.",
  "Shown for every candidate.",
  CAND_SRC + [S("engine", "presenter._summary gives kind, commands, timing, power state, status, approver and the "
                          "lower bound; _label gives the older one-line label.", py(PR, "_summary")),
              S("browser", "candText(a) builds title, sub and status from the summary, or parses the old label.",
                js(RJ, "function candText(a)", 14)),
              S("screen", "Bold title, grey timing after it.")])

E("s4d-cand-status", G4, "replaced by a newer version · reproduced in at least 68 % of lab runs", "display",
  "#r-cands li .why",
  "First part of the grey line of a procedure: its status in words (approved by a second admin, awaiting approval by "
  "a second admin, replaced by a newer version, retired, proposal …) and the 95 % lower bound of its lab "
  "reproduction rate.",
  "Status and lab evidence decide whether a candidate may be reused as it is.",
  "Only for procedure candidates.",
  CAND_SRC + [S("browser", "candText: CAND_STATUS word + \"reproduced in at least X % of lab runs\".",
                js(RJ, "const CAND_STATUS = {", 1)),
              S("screen", "Grey text at the start of the second line.")])

E("s4d-cand-match", G4, "lookup match 96 % (100 % = identical to the stored record)", "display", "#r-cands li .why",
  "The lookup's final score as a percentage: the merged score of the five comparisons (1 = first in every "
  "comparison) × √(0.5 + 0.5 × the admin rating) × e^(0.5 × tanh(ranking score)). A record often judged correct "
  "keeps its full score, one always judged wrong keeps 71 %; the ranking score from \"Record my ranking\" can raise "
  "it by up to 65 % - so the value can exceed 100 % and \"100 % = identical\" is only a rough guide.",
  "One number to compare candidates; the feedback factors are deliberately mild so a well-liked record cannot lock "
  "out a better match.",
  "Shown for every candidate.",
  CAND_SRC + [S("engine", "query: final = (fused / top) × sqrt(0.5 + 0.5 × posterior) × exp(0.5 × tanh(pl)); "
                          "_posterior gives the rating.", py(RV, "HybridIndex._posterior")),
              S("browser", "renderView: Math.round(a.score * 100) + \" %\".", js(RJ, "lookup match ${Math.round(a.score * 100)} %", 1)),
              S("screen", "\"lookup match 96 % (100 % = identical to the stored record)\"")],
  example="Here 96 %, 93 %, 93 %, 64 %, 62 %.")

E("s4d-cand-judged", G4, "admins judged it 18 times", "display", "#r-cands li .why",
  "How many judgements the record's counters hold (n): for a procedure the judgements of the procedure itself plus "
  "those of its link from the cause (pnode n + pedge n), which include the automatic one each lab validation adds; "
  "for a cause, the judgements on the link from the error type. Left out when 0.",
  "Shows how much experience stands behind a record: 18 judgements weigh more than 1.",
  "Only when n > 0.",
  CAND_SRC + [S("engine", "HybridIndex._posterior returns n = node n + edge n for a procedure.", py(RV, "HybridIndex._posterior")),
              S("browser", "renderView: \" · admins judged it \" + a.n + \" time(s)\".", js(RJ, "admins judged it ${a.n} time", 1)),
              S("screen", "\"admins judged it 18 times\"")],
  example="Here 18, 10 and 12 for the three procedures; the left panel shows 9 for the first one because it counts the "
          "link only.")

E("s4d-cand-why", G4, "why it matched: text similarity 0.95, evidence-row sequence LCS 1.00, admin feedback posterior 0.75 over 18 signals",
  "display", "#r-cands li .why",
  "The reasons the lookup gives for the match, after the page drops the technical ones (word score BM25, \"structured "
  "match\", \"lexical\", \"idf\"). In lookups saved before 27 Oct 2026 (like this one) they are numbers: \"text "
  "similarity\" (letter-triplet similarity of the texts, 1 = same text), \"evidence-row sequence LCS\" (longest common "
  "subsequence of the packet kinds around the defect, earlier positions weigh more; 1 = same order), \"admin feedback "
  "posterior 0.75 over 18 signals\" (the rating a ÷ (a + b) and n), \"no admin feedback yet (prior 0.50)\", "
  "\"exploration slot (Thompson sample)\". The current code writes plain sentences instead: \"same error type\", "
  "\"same first rule\", \"same firmware\", \"same packet sequence around the first abnormal packet\", \"judged correct "
  "N times, not correct M times\" or \"not judged yet\".",
  "The manager must be able to see why the system thinks a record fits, not just a score.",
  "Shown when at least one reason is left after filtering.",
  CAND_SRC + [S("engine", "HybridIndex._why builds the reasons (current wording).", py(RV, "HybridIndex._why")),
              S("browser", "plainWhy removes BM25 / structured match / lexical / idf; renderView writes \"why it matched: …\".",
                js(RJ, "const plainWhy", 1)),
              S("screen", "Third line of each candidate.")],
  example="Here: \"text similarity 0.95, evidence-row sequence LCS 1.00, admin feedback posterior 0.75 over 18 signals\". "
          "Scratch copy (current wording): \"same error type, same first rule, same firmware, same packet sequence "
          "around the first abnormal packet, judged correct 1 time, not correct 0 times\".")

E("s4d-cand-explore", G4, "shown to give a less-tried procedure a chance", "display", "#r-cands li:last-child .why",
  "Marks the fifth line when it is an exploration pick: when more than five records match, the best four are shown and "
  "the fifth place is drawn at random (Thompson sampling) among the less-judged records (fewer than 5 judgements, "
  "match at least 0.4), weighted by their rating and match.",
  "Without it a record nobody has looked at could never earn credit, and the ranking would only confirm itself.",
  "Only on the exploration pick.",
  CAND_SRC + [S("engine", "query: shown = best k-1 + one pick drawn with rng.betavariate; the pick gets explore = True.",
                py(RV, "HybridIndex.query", "shown = cands[:k - 1]", "return shown, cands")),
              S("browser", "renderView adds \" · shown to give a less-tried procedure a chance\".",
                js(RJ, "a.explore ? \" · shown to give a less-tried procedure a chance\"", 1)),
              S("screen", "Text on line 5.")],
  example="Here line 5, \"earlier case of T-42\", lookup match 62 %.")

E("s4d-cand-click", G4, "(click a candidate line)", "button", "#r-cands li",
  "Clicking a candidate line appends it to your order: the line turns blue (\"picked\") and the box \"Order you built "
  "by clicking the candidates above\" in step 1 shows \"1. … → 2. …\". Nothing is sent: the order is used by \"Record "
  "my ranking\" (and by \"Prefer this one\" when present).",
  "Ordering by clicking is quicker than typing ids, and an order is a separate kind of feedback (a rating, never a "
  "success).",
  "Always clickable; clicking the same line twice does not add it twice. \"clear\" empties the order.",
  [S("you", "You click candidates in the order you think is right, best first."),
   S("browser", "li.onclick pushes the record id into R.ranking, adds the class picked, writes the order into #a-ranking "
                "and re-checks step 3.", js(RJ, "li.onclick = () => {", 1)),
   S("browser", "refreshStep3 updates \"Before recording: …\" if a decision is chosen.", js(RJ, "function refreshStep3()", 1)),
   S("screen", "Picked lines are tinted; the order appears in step 1.")])


# ===============================================================================================================
# 6. Step 1 · Which record is the decision about?
# ===============================================================================================================
G5 = "Step 1 · Which record is the decision about?"

E("s4d-step1-targets", G5, "Which record is the decision about?", "checkbox", "#a-targets .target",
  "One checkbox row per candidate (same title, timing and status as the list above), plus \"The saved procedure shown "
  "above\" when the saved procedure is not among the candidates. The value of each box is the record id the server "
  "understands: \"sol::<procedure hash>\" for a procedure, \"cause::<error type>::<cause id>\" for a cause, "
  "\"case::…\", \"sig::…\", \"lesson::…\" for the others. The help line says: tick one; Prefer, Tie and Mark as a "
  "duplicate take two (Link to another takes one: the procedure to copy); decisions about the defect as a whole need none. The ticked ids are sent in "
  "screen order as \"targets\"; for two-record decisions the first ticked (higher in the list) comes first.",
  "Every verdict must name exactly which record it is about, so the credit or blame lands on that record only "
  "(\"localized blame\": records the admin did not touch are not punished).",
  "Shown after the lookup; \"No record to tick: nothing is saved for this error type yet.\" when the lookup found "
  "nothing.",
  [S("http", "The ids come from the saved view (GET /api/runs/<run>/incidents/<defect>)."),
   S("browser", "renderView adds one label.target with a checkbox per candidate (addTarget); changing a box re-checks "
                "step 3.", js(RJ, "const addTarget = (id, c, extra) =>", 1)),
   S("browser", "ticked() collects the checked values in screen order; doAction sends them as targets.",
     js(RJ, "const ticked = () =>", 1)),
   S("engine", "admin_actions.parse_target turns each id into (kind, error type, id).", py(AA, "parse_target")),
   S("screen", "Checkbox rows in step 1.")],
  example="Here five rows: three \"Saved procedure: flush, write …\" (sol::074e18b2b58a5676, sol::755341171843367d, "
          "sol::93d32f1934f5f676) and two \"earlier case of T-42\" (case::T-42::2, case::T-42::4). No cause is among "
          "them, so Mark as a duplicate, Split, Request deletion and Approve the deletion cannot succeed on this page.")

E("s4d-step1-ranking", G5, "Order you built by clicking the candidates above (saved by \"Record my ranking\"):", "field",
  "#a-ranking",
  "A read-only box showing the order you built by clicking candidate lines, for example \"1. Saved procedure: flush, "
  "write  →  2. …\"; \"none yet\" when empty. It is sent as \"ranking\" with every decision while it is not empty.",
  "Lets you see the order before you record it with \"Record my ranking\".",
  "Always shown in step 1; emptied when a defect is opened or a new lookup is drawn.",
  [S("you", "You click candidate lines in your order."),
   S("browser", "li.onclick writes R.ranking into the box; doAction sends ranking: R.ranking when it is not empty.",
     js(RJ, "li.onclick = () => {", 1)),
   S("http", ACT_URL + '{"action": "rerank", "ranking": ["sol::…", "sol::…"], …}'),
   S("screen", "The order as text in the box.")])

E("s4d-step1-clear", G5, "clear", "button", "#a-rank-clear",
  "Empties the order you built: removes the blue highlight from the candidate lines and clears the box.",
  "A wrong click must be easy to correct before an order is recorded.",
  "Always available; sends nothing.",
  [S("you", "You click \"clear\"."),
   S("browser", "The handler sets R.ranking = [], empties #a-ranking and removes the class picked.",
     js(RJ, "$(\"a-rank-clear\").onclick", 1)),
   S("screen", "No candidate highlighted; the box shows \"none yet\".")])


# ===============================================================================================================
# 7. Step 2 · the 26 decision tiles
# ===============================================================================================================
TAGS_WORDS = {"one": "needs one ticked record", "two": "needs two ticked records",
              "ranking": "needs an order (click the candidates)", "reason": "asks for a reason",
              "approver": "needs a second admin", "event": "asks which decision", "minutes": "runs in the lab, takes minutes"}


def tile(name, group, label, desc, tags, colour, what, why, you, browser, body, apply_rng, apply_text, db_steps,
         lab=None, screen="", when="", example="", code=None):
    """One decision tile. apply_rng = (start text, stop text) of its branch in admin_actions.apply."""
    tag_txt = ", ".join("\"%s\"" % TAGS_WORDS[t] for t in tags) if tags else "no tags (needs nothing ticked)"
    head = ("Tile text: \"%s\" — %s. Tags: %s.%s " % (label, desc, tag_txt, (" Colour: %s." % colour) if colour else ""))
    apply_ref = py(AA, "apply", apply_rng[0], apply_rng[1])
    chain = [S("you", you),
             S("browser", "startAction(\"%s\") marks the tile and opens step 3; %s confirmAction re-checks missing() and "
                          "calls doAction, which sends the ticked records, your name, the note and, when filled, the "
                          "change text, the order and the decision number (a second admin's name only for Approve as "
                          "second admin, Retire the procedure and Approve the deletion)." % (name, browser),
               R_START),
             S("http", ACT_URL + body),
             S("server", SRV_TEXT, R_ACT_API)]
    if lab:
        chain.append(S("service", SVC_JOB, R_JOB))
    else:
        chain.append(S("service", SVC_DIRECT, R_ACT_SVC))
    chain.append(S("engine", EXEC_TEXT + " " + apply_text, apply_ref))
    chain += db_steps
    if lab:
        chain += lab
    chain.append(S("screen", screen))
    base = ("Offered only when the lookup found a record and says seen before = match or ambiguous."
            if name in ("promote", "deprecate") else
            "Offered whenever the lookup found at least one record." if name in WHEN_CANDIDATES else "Offered always.")
    E("s4d-tile-" + name.replace("_", "-"), group, label, "button", "#r-actions .atile[data-a=\"%s\"]" % name,
      head + what, why, base + (" " + when if when else ""), chain, code=code or [apply_ref], example=example)


WHEN_CANDIDATES = ("accept", "accept_with_note", "revise", "reject", "not_reproducible", "rerank", "prefer", "tie",
                   "duplicate_of", "link", "split", "delete_request", "delete_approve", "undo")


LAB_FILES = S("files", "suite/<test id>/manifest.json, test_<test id>.py and conftest.py for every procedure that passed "
                       "the lab check (emit_closed_loop_test); the result is appended to runs/<run>/stage2/<defect>.json "
                       "and db/stage2_log.jsonl.")
JOB_SCREEN = ("While the job runs the Result tab shows the receipt and a progress bar (\"running: re-run as a safety "
              "check, search for a reproducing procedure, then the lab check on known-bad and fixed firmware…\"); a "
              "first message shows the receipt for 7 s. When the job ends, the message \"stage 2 finished: <outcome>\" "
              "appears for 8 s with Undo, the Result tab shows the outcome, the queue and the page refresh.")
DIRECT_SCREEN = ("The Result tab shows the outcome; the message (toast) shows the receipt or the effects for 8 s with an "
                 "Undo button (\"refused: …\" without Undo when the decision was refused); then the page refreshes and "
                 "returns to \"Candidates & actions\".")

# ---------------------------------------------------------------- Judge the ticked procedure
GJ = "Step 2 · Judge the ticked procedure"

tile("accept", GJ, "Accept", "Correct (+1): this procedure is right; it is re-run in the lab, then the test script is written",
     ["one", "minutes"], "green",
     "Gives one success (+1) to the ticked record and starts the lab work. On a procedure: +1 on the procedure and on "
     "its link from the cause, and +1 on the cause; the saved procedure is then run first as a safety check "
     "(\"regression guard\"): if it still shows the defect in at least 3 of 6 runs it is reused (no search), otherwise "
     "a lesson is written and the search starts from it. On a cause: +1 on the cause and a new search for a "
     "procedure. Ticking an \"earlier case\" gives no credit (that kind of record has no counters) and starts a "
     "search from scratch. Same as \"Correct\" on a card of the main screen.",
     "The project's positive feedback: an admin confirmation must strengthen exactly the confirmed record, and a "
     "confirmed procedure must be re-validated on the device before it becomes a regression test.",
     "You tick one record, click \"Accept\", then \"Record: Accept\" (the key a opens the same step).",
     "no extra field is shown;",
     '{"action": "accept", "targets": ["sol::<hash>"], "requester": "<your name>", "approver": "", "note": ""}  (approver always empty here)',
     ("if name in (\"accept\", \"accept_with_note\")", "if name == \"revise\""),
     "Branch accept: for a procedure it logs proc_credit {edge_id: \"REPRODUCED_BY|<type>::<cause>|scn::<hash>\", "
     "node_id: \"scn::<hash>\", r: 1.0} and verdict {verdict: \"correct\", chosen: <cause>, lab_result: true}; for a "
     "cause only the verdict. Effect text: \"marked correct (+1)\".",
     [S("database", "verdict → KGDB._project: first every cause of this error type fades 2 % toward the start "
                    "(a = 1 + (a − 1) × 0.98, the same for b), then the chosen cause gets a + 1, n + 1 (a + b capped at "
                    "50) and, because lab_result is true, ta + 1; the defect's tokens go into case_memory. proc_credit → "
                    "ProcGraph: the cause → procedure link (pedge) and the procedure (pnode) each a + 1, n + 1.", R_VERDICT)],
     lab=[S("engine", "Lab: a procedure of the same error type → mode reuse: it is run 6 times on the device model; 3 or "
                      "more reproductions → status reused_validated, stress step, then _finish; fewer → lesson \"the "
                      "saved procedure no longer shows the error on …\" and mode adapt (search). A cause → mode generate: "
                      "AI (artificial intelligence) proposal, search under 300 trials and the 600 s triage limit, "
                      "shortening, stress step. _finish checks the procedure on known-bad firmware (6 runs) and fixed "
                      "firmware (3 runs): passed = found at least once on known-bad and never on fixed → test files and a "
                      "script_gate event; new procedures get solution_propose + solution_validate. _finish would also "
                      "approve a new procedure when the request names a second admin, but the page sends that name only "
                      "with Approve / Retire / Approve the deletion, so a lab decision made here approves nothing.", R_EXEC_REUSE),
          LAB_FILES],
     screen="Receipt: \"" + "What happens next: the accepted procedure is re-run first as a safety check. If it still "
            "reproduces the defect, it is reused and a regression test is filed; otherwise the search for a "
            "reproducing procedure starts from it.\" Accept stays on \"Candidates & actions\". " + JOB_SCREEN,
     example="Scratch copy, Accept on the saved procedure: events admin_action, proc_credit, verdict, then "
             "solution_propose + solution_validate (stress variant) and two script_gate; cause edge a 2.0 → 2.98 "
             "(fade, then +1), n 1 → 2, ta 1 → 2; procedure link a 2 → 3; procedure node a 1 → 2. Live: the newest "
             "Accept on T-42 (27 Oct 2026 12:57:54, admin) shows \"✓ regression test filed found on known-bad firmware "
             "6/6 · on fixed firmware 0/3\".",
     code=[py(AA, "apply", "if name in (\"accept\", \"accept_with_note\")", "if name == \"revise\""), R_VERDICT, R_EXEC_REUSE])

tile("accept_with_note", GJ, "Accept with a note", "Correct (+1), with a note that is kept with the procedure",
     ["one", "minutes"], "green",
     "Exactly Accept, plus a lesson \"ADMIN NOTE on accept: <your note>\" attached to the ticked cause or procedure; "
     "lessons are given to the AI (artificial intelligence) reviewer the next time this error type is looked up or "
     "searched. The note field is optional in step 3, so with an empty note this tile does the same as Accept (no "
     "lesson is written).",
     "Some confirmations come with a condition (\"only on firmware B\", \"needs a cold boot first\"); the note travels "
     "with the procedure so the next person and the next proposal see it.",
     "You tick one record, click the tile, type the note in \"Note\", click \"Record: Accept with a note\".",
     "the Note field is the one that matters (not enforced);",
     '{"action": "accept_with_note", "targets": ["cause::T-42::c0"], "note": "<your note>", …}',
     ("if name in (\"accept\", \"accept_with_note\")", "if name == \"revise\""),
     "Same branch as Accept; when the note is not empty it also logs lesson {text: \"ADMIN NOTE on accept: <note>\", "
     "cause or vhash, producer: <you>}.",
     [S("database", "As Accept (fade 0.98, +1, ta + 1; pedge / pnode a + 1), plus a row in the lesson table and a "
                    "lesson node with a LESSON_ABOUT link (pnode, pedge).", py(KG, "KGDB._project", "elif kind == \"lesson\"", "elif kind in (\"optimizer_result\", \"script_gate\")"))],
     lab=[S("engine", "Lab exactly as Accept: reuse / adapt / generate, then the lab check in _finish.", R_EXEC_REUSE),
          LAB_FILES],
     screen="Receipt: \"What happens next: the same as Accept; your note is saved with the procedure.\" " + JOB_SCREEN,
     example="Scratch copy on the cause: events admin_action, verdict, lesson \"ADMIN NOTE on accept: kept with the "
             "procedure\", then the lab's solution_propose / solution_validate / script_gate; cause a 2.98 → 3.94, n 2 → 3.")

tile("revise", GJ, "Revise the text", "change the stored text of the ticked cause or the notes on a procedure (text in "
     "step 3); nothing runs in the lab and the earlier counts are reduced; to change the steps and run them use Needs "
     "changes on a card or the editor",
     ["one"], "",
     "Stores your corrected text (the JSON (JavaScript Object Notation) in \"Text of your change\") as a new version of "
     "the ticked record and shrinks its old evidence toward neutral (both counters × 0.7), because the counts were "
     "earned by the old content. On a cause the text becomes a new node version; on a procedure it is stored as "
     "\"admin_revision\" (notes) on the link cause → procedure - the procedure's steps are not changed. No credit is "
     "given and, as the tile says, nothing runs in the lab (revise is not one of the lab decisions); to change the "
     "steps and have them run, use the editor below (\"Propose my procedure and run it on the device\") or \"Needs "
     "changes\" on a card. The effect text the server returns, shown in the Result tab's Action row, says the same: "
     "\"revised: the stored text was changed; nothing was run in the lab; the earlier counts were reduced\".",
     "A record can be partly right; changing its content without throwing away its history, but with less weight, is "
     "the honest way to record \"partially correct\".",
     "You tick one record, click the tile, type the new content as JSON, e.g. {\"text\": \"…\"}, click \"Record: Revise "
     "the text\".",
     "the field \"Text of your change\" appears (not enforced);",
     '{"action": "revise", "targets": ["cause::T-42::c0"], "content": {"text": "<new text>"}, …}',
     ("if name == \"revise\"", "if name == \"reject\""),
     "Branch revise: cause → node_edit {sig, node_id, content}; procedure → proc_edge_edit {edge_id, props: "
     "{admin_revision: <content>, note}}. Effect text (both branches): \"revised: the stored text was changed; nothing was "
     "run in the lab; the earlier counts were reduced\".",
     [S("database", "node_edit → KGDB: new row in node_version, the cause's a and b shrink: a = 1 + (a − 1) × 0.7 "
                    "(edit shrink); ProcGraph: new pnode version. proc_edge_edit → ProcGraph: the pedge props get "
                    "admin_revision and a, b shrink × 0.7.", py(KG, "KGDB._project", "elif kind == \"node_edit\"", "elif kind == \"verdict\""))],
     screen="Receipt: \"The text was revised; the counts are kept, the weight of its evidence is reduced. No search was "
            "started.\" " + DIRECT_SCREEN,
     example="Scratch copy: revise on the cause → node_edit, cause a 3.94 → 3.06 (1 + 2.94 × 0.7), node version 1 → 2; "
             "revise on a procedure → proc_edge_edit, link a 4.0 → 3.1. No lab run in either case.",
     code=[py(AA, "apply", "if name == \"revise\"", "if name == \"reject\""),
           py(PG, "ProcGraph.project", "elif kind == \"proc_edge_edit\"", "(json.dumps(props, sort_keys=True), sh, sh, eid, pl[\"edge_id\"]))")])

tile("reject", GJ, "Reject (not correct)", "Not correct (-1): only this procedure is marked wrong",
     ["one", "reason"], "red",
     "Gives one failure (−1) to the ticked record only. On a procedure: the procedure and its link from the cause get "
     "b + 1 and the cause is untouched. On a cause: b + 1 on the cause (after the 2 % fading of all causes of the error "
     "type). Your reason is stored as the note of the decision; the history shows it as negative and the yellow callout "
     "shows it to the next person. Nothing runs in the lab. The key r opens the same step.",
     "The project's negative feedback; blame is local on purpose, so a wrong procedure does not drag down a correct "
     "cause or other candidates.",
     "You tick one record, click the tile, type \"Why is it not correct?\", click \"Record: Reject (not correct)\" (Enter "
     "in the reason field also records).",
     "the field \"Why is it not correct?\" appears and \"Record\" stays disabled until it is filled;",
     '{"action": "reject", "targets": ["sol::<hash>"], "note": "<your reason>", …}',
     ("if name == \"reject\"", "if name == \"not_reproducible\""),
     "Branch reject: cause → verdict {verdict: \"not\", rejected: <cause>}; procedure → proc_credit {edge_id, node_id, "
     "r: 0.0}. Effect text: \"marked not correct (-1)\".",
     [S("database", "verdict \"not\" → KGDB: fade × 0.98, then the rejected cause b + 1, n + 1 (cap 50). proc_credit "
                    "r = 0 → ProcGraph: pedge and pnode b + 1, n + 1.", R_VERDICT),
      S("database", "ProcGraph._credit adds r to a and 1 − r to b, n + 1, and scales a and b down when a + b > 50.", R_PG_CREDIT)],
     screen="Receipt: \"Recorded as a negative decision with your reason: only this candidate loses credit. Nothing else "
            "changes.\" The page switches to Result while applying. " + DIRECT_SCREEN,
     example="Scratch copy: reject on a procedure → proc_credit r 0, link b 1 → 2, node b 1 → 2, cause unchanged; "
             "reject on the cause → verdict not, cause b 1 → 2, a 3.06 → 3.02 (fading). Live: exercise_loop writes "
             "\"exercise: timing is wrong for this firmware\" 11 times on T-42.")

tile("not_reproducible", GJ, "Could not be reproduced", "ran it on the drive, the error did not appear (the procedure is not called wrong)",
     ["one", "reason"], "red",
     "Records that a lab run did not show the defect. On a cause: only the cause's lab counter tb + 1 - its correctness "
     "counters a and b only fade. On a procedure: b + 1 on the link cause → procedure (the procedure node is untouched) "
     "and a lesson \"NOT REPRODUCIBLE by admin in <firmware>: <reason>\". NOTE: for a procedure this b + 1 is the same "
     "counter Reject uses on the link, so the procedure's rating does drop; only the cause is spared.",
     "\"Could not reproduce\" is not \"wrong\": a flaky bench or a different drive must not make a correct cause look "
     "wrong, so it is counted separately.",
     "You tick one record, click the tile, give the reason, click \"Record: Could not be reproduced\".",
     "the reason field appears and is required;",
     '{"action": "not_reproducible", "targets": ["cause::T-42::c0"], "note": "<your reason>", …}',
     ("if name == \"not_reproducible\"", "if name == \"duplicate_of\""),
     "Branch not_reproducible: cause → verdict {verdict: \"lab\", chosen, lab_result: false}; procedure → proc_credit "
     "{edge_id, r: 0.0} + lesson. Effect text: \"recorded: did not reproduce on the drive\".",
     [S("database", "verdict \"lab\" → KGDB: fade × 0.98 of all causes, then tb + 1 on the chosen cause (no a/b credit). "
                    "proc_credit → pedge b + 1, n + 1; lesson → lesson table.", R_VERDICT)],
     screen="Receipt: \"Recorded as 'could not be reproduced': this counts against the procedure's lab record only; "
            "whether the cause is right is left untouched.\" " + DIRECT_SCREEN,
     example="Scratch copy: on the cause → tb 1 → 2, a 3.02 → 2.98 and b 2.0 → 1.98 (fading only); on a procedure → "
             "link b 2 → 3 and the lesson \"NOT REPRODUCIBLE by admin in FW-A: bench silent\". Live: the callout on this "
             "page is such a decision (\"exercise: bench silent\").")

# ---------------------------------------------------------------- Order or compare procedures
GO = "Step 2 · Order or compare procedures"

tile("rerank", GO, "Record my ranking", "your order, best first (this does not count as \"correct\")",
     ["ranking"], "",
     "Records the order you built by clicking candidates as a rating only (Plackett–Luce): the first record's ranking "
     "score rises by 0.3 × (1 − its predicted chance of being first) ÷ number of items, the others fall by their share. "
     "Causes and procedures are ranked separately and only when at least two of the same kind are in your order; "
     "\"earlier case\" lines are ignored. a, b and n never change. NOTE: if your order holds fewer than two procedures "
     "(or causes), nothing is recorded, yet the receipt still says the order was recorded.",
     "An order (\"this one before that one\") is a different signal from \"correct\"; mixing them would let a mere "
     "preference count as proof.",
     "You click at least two candidates in your order, click the tile, then \"Record: Record my ranking\".",
     "\"Record\" stays disabled until at least two candidates are clicked;",
     '{"action": "rerank", "ranking": ["sol::<first>", "sol::<second>"], "targets": [], …}',
     ("if name in (\"rerank\", \"prefer\")", "if name == \"tie\""),
     "Branch rerank: ≥ 2 causes → ranking {sig, ranking: [cause ids]}; ≥ 2 procedures → proc_rank {ranking: "
     "[\"scn::…\"]}. Effect text: \"your order was recorded\".",
     [S("database", "proc_rank → ProcGraph: the pnode pl scores move (learning rate 0.3); ranking → KGDB: the edge pl "
                    "scores move the same way, n += 0.", py(PG, "ProcGraph.project", "elif kind == \"proc_rank\"", "elif kind == \"proc_edge_edit\""))],
     screen="Receipt: \"Your order is recorded as a rating only (never as a success).\" " + DIRECT_SCREEN,
     example="Scratch copy, two procedures: proc_rank, pl 0 → +0.075 for the first and −0.075 for the second (0.3 × 0.5 ÷ 2).",
     code=[py(AA, "apply", "if name in (\"rerank\", \"prefer\")", "if name == \"tie\""),
           py(PG, "ProcGraph.project", "elif kind == \"proc_rank\"", "elif kind == \"proc_edge_edit\"")])

tile("prefer", GO, "Prefer this one", "you prefer the first of the two ticked procedures, the one higher in the list "
     "(this does not count as \"correct\")",
     ["two"], "",
     "The same rating update as Record my ranking for two records: the two ticked records are sent in screen order, so "
     "the one higher in the list is the preferred one, as the tile says. One exception: if you clicked candidate lines "
     "before (the box in step 1 is not empty), that clicked order is sent as \"ranking\" and is used instead of the "
     "ticked order - press \"clear\" first if you only want the two ticks to count.",
     "A pairwise preference is the simplest relative judgement and is often all an admin can say.",
     "You tick two records - the preferred one is the higher one in the list - click the tile, then \"Record: Prefer "
     "this one\".",
     "\"Record\" stays disabled until two records are ticked;",
     '{"action": "prefer", "targets": ["sol::<preferred>", "sol::<other>"], …}',
     ("if name in (\"rerank\", \"prefer\")", "if name == \"tie\""),
     "Branch prefer (shared with rerank): order = ranking or targets; proc_rank / ranking as above.",
     [S("database", "proc_rank → pnode pl of the two procedures move in opposite directions; a, b, n unchanged.",
        py(PG, "ProcGraph.project", "elif kind == \"proc_rank\"", "elif kind == \"proc_edge_edit\""))],
     screen="Receipt: \"Your preference is recorded as a rating.\" " + DIRECT_SCREEN,
     example="Scratch copy: the two ticked procedures in screen order → proc_rank, pl −0.075 → +0.006 and +0.075 → −0.006.")

tile("tie", GO, "Tie (no preference)", "no preference between the two", ["two"], "",
     "Records only that you looked at two records and have no preference. No counter changes.",
     "An explicit \"no preference\" is logged so it can be told apart from \"not looked at\"; it must not move ratings.",
     "You tick two records, click the tile, then \"Record: Tie (no preference)\".",
     "\"Record\" stays disabled until two records are ticked;",
     '{"action": "tie", "targets": ["sol::…", "sol::…"], …}',
     ("if name == \"tie\"", "# ---------------- verdicts on candidates"),
     "Branch tie: nothing after admin_action. Effect text: \"recorded; nothing else changes\".",
     [S("database", "Only the admin_action event (neutral in the history).")],
     screen="No receipt is defined; the message shows \"recorded; nothing else changes\". " + DIRECT_SCREEN)

# ---------------------------------------------------------------- Tidy the knowledge base
GT = "Step 2 · Tidy the knowledge base"

tile("promote", GT, "Approve as second admin", "approve this procedure so it is used as the saved procedure",
     ["one", "approver"], "yellow (two people)",
     "The four-eyes approval of a procedure the lab has reproduced: its status becomes \"approved by <second admin>\" "
     "and any earlier approved procedure of the same cause becomes \"replaced by a newer version\". It only takes "
     "effect if the procedure is \"awaiting approval\" (validated in the lab) and the second admin is not the one who "
     "produced it; otherwise the event is recorded but nothing changes - the message still shows the receipt \"The "
     "procedure is now approved …\" and the Result tab says \"approved\" or \"status is now …\". A real approval also adds "
     "+1 to the procedure node.",
     "Two-person rule: nothing becomes the reference regression test on one person's word, and nothing is approved "
     "that the lab has not reproduced.",
     "You tick the procedure, click the tile, type \"Name of the second admin\" (must differ from \"Your name\"), click "
     "\"Record: Approve as second admin (written to the event log with both names)\".",
     "the field \"Name of the second admin\" appears and is required and must differ from your name;",
     '{"action": "promote", "targets": ["sol::<hash>"], "approver": "<second admin>", …}',
     ("if name == \"promote\"", "if name == \"deprecate\""),
     "Before anything is written, apply refuses when approver is empty or equal to requester (\"promote needs a second "
     "admin (approver != requester)\", nothing logged). Branch promote: solution_approve {vhash, sig, cause, "
     "approved_by} with the second admin as actor. Effect text: \"approved\" or \"status is now <status>\".",
     [S("database", "solution_approve → KGDB: status admin-approved and approved_by only if the status was "
                    "validated-by-execution and approved_by ≠ producer; the other approved procedure of the cause → "
                    "superseded. ProcGraph: props updated, pnode a + 1.",
        py(KG, "KGDB._project", "elif kind == \"solution_approve\"", "elif kind == \"solution_deprecate\""))],
     screen="Receipt: \"The procedure is now approved by a second admin; the approver's name is kept in the record.\" " + DIRECT_SCREEN,
     example="Scratch copy: same name as approver → refused, no event; with \"mapper two\" → solution_approve (actor "
             "mapper two), status validated-by-execution → admin-approved, node a 2 → 3. Sent again on the approved "
             "procedure → a second solution_approve that changes nothing, message still \"approved\".",
     code=[py(AA, "apply", "if name in TWO_PERSON", "# impression record"),
           py(AA, "apply", "if name == \"promote\"", "if name == \"deprecate\""),
           py(KG, "KGDB._project", "elif kind == \"solution_approve\"", "elif kind == \"solution_deprecate\"")])

tile("deprecate", GT, "Retire the procedure", "retire this procedure", ["one", "approver"], "yellow (two people)",
     "Retires a procedure (any status) so the lookup no longer offers it; it stays in the history and can be brought "
     "back with Undo. Needs a second admin different from you. The procedure node gets b + 1.",
     "Removing a reference procedure is as serious as approving one, so it also needs two people.",
     "You tick the procedure, click the tile, type the second admin, click \"Record: Retire the procedure (written to "
     "the event log with both names)\".",
     "the second-admin field appears and is required;",
     '{"action": "deprecate", "targets": ["sol::<hash>"], "approver": "<second admin>", …}',
     ("if name == \"deprecate\"", "if name == \"delete_request\""),
     "Same two-person check as promote. Branch deprecate: solution_deprecate {vhash, requested_by: <you>, approved_by: "
     "<second admin>}. Effect text: \"retired\".",
     [S("database", "solution_deprecate → KGDB: status deprecated when approved_by ≠ requested_by; ProcGraph: props "
                    "status deprecated, pnode b + 1.", py(KG, "KGDB._project", "elif kind == \"solution_deprecate\"", "elif kind == \"lesson\""))],
     screen="Receipt: \"The procedure is retired; it stays in the history.\" " + DIRECT_SCREEN,
     example="Scratch copy: solution_deprecate (actor mapper two), status admin-approved → deprecated, node b 2 → 3; "
             "undoing that event restored admin-approved and b 2.")

tile("duplicate_of", GT, "Mark as a duplicate", "this cause is the same as another one: the two are merged (their histories are kept)",
     ["two"], "",
     "Merges two causes of the error type: the first ticked (higher in the list) is dropped into the second. The kept "
     "cause adds the dropped one's extra counts (a, b, ta, tb, n); the dropped cause becomes \"merged\" and its "
     "procedures are re-pointed to the kept cause. Both must be causes - procedures or cases are refused with "
     "\"duplicate_of needs targets [drop, keep] of kind cause\" (the refused decision is still in the history).",
     "The same cause entered twice splits its evidence in two; merging restores one record with all its history.",
     "You tick the two causes (the one to drop higher in the list), click the tile, click \"Record: Mark as a duplicate\".",
     "\"Record\" stays disabled until two records are ticked;",
     '{"action": "duplicate_of", "targets": ["cause::T-42::c1", "cause::T-42::c0"], …}',
     ("if name == \"duplicate_of\"", "# ---------------- lifecycle"),
     "Branch duplicate_of: merge {sig, keep: <second>, drop: <first>}. Effect text: \"merged into one cause\".",
     [S("database", "merge → KGDB: keep a, b, ta, tb += drop − 1, n += drop n, drop node status merged; ProcGraph: drop "
                    "pnode merged, its REPRODUCED_BY links copied to the kept cause.", py(KG, "KGDB._project", "elif kind == \"merge\"", "elif kind == \"firmware_change\""))],
     screen="No receipt is defined; the message shows \"merged into one cause\". " + DIRECT_SCREEN,
     example="Scratch copy: c1 into c0 → merge, c0 a 2.94 → 3.94, n 5 → 6, c1 status merged. A later Split or Add a "
             "cause then picked the id c1 again (new ids are \"c\" + number of active causes) and re-activated the merged "
             "c1 with new content.")

tile("link", GT, "Link to another", "copy a procedure saved for another error type under this cause, as a proposal (it "
     "runs in the lab when someone accepts it)", ["one"], "",
     "Copies the ticked procedure (it may belong to another error type of the same family) under a cause of this error "
     "type (a ticked cause, else the first cause) as a new procedure with status \"proposed\". Nothing runs now - link "
     "is not a lab decision, as the tile and the effect text say. NOTE: a \"proposed\" procedure is not offered by the "
     "lookup or by the cards of the main screen (they list only approved, awaiting-approval and replaced procedures), "
     "so on these screens nobody can tick it and accept it yet; it waits in the solution table until it is validated "
     "some other way.",
     "Different error types of one family often reproduce the same way; reusing a known procedure saves a search.",
     "You tick the procedure to reuse, click the tile, click \"Record: Link to another\".",
     "\"Record\" stays disabled until one record is ticked;",
     '{"action": "link", "targets": ["sol::<hash of the other procedure>"], …}',
     ("if name == \"link\"", "if name == \"split\""),
     "Branch link: solution_propose {vhash: <new hash>, sig, cause, scenario + _linked_from, producer: \"link:<you>\"}; "
     "effect text \"the procedure was copied under this cause as a proposal; it runs in the lab when someone accepts it\"; "
     "refused with \"link needs a solution target\" when no procedure is ticked.",
     [S("database", "solution_propose → KGDB: new solution row, status proposed; ProcGraph: a scenario node and a "
                    "REPRODUCED_BY link from the cause.", py(KG, "KGDB._project", "elif kind == \"solution_propose\"", "elif kind == \"solution_validate\""))],
     screen="No receipt is defined; the message shows \"the procedure was copied under this cause as a proposal; it runs "
            "in the lab when someone accepts it\". " + DIRECT_SCREEN,
     example="Scratch copy: solution_propose (producer \"link:mapper one\"), new procedure afb292de… with status "
             "proposed; no lab event followed (observed before the effect text was reworded; the events are unchanged).")

tile("split", GT, "Split", "split a cause in two", ["one"], "",
     "Creates a new cause next to the ticked one and gives the ticked one a new version. The text must be JSON "
     "(JavaScript Object Notation) of the form {\"new\": {\"text\": \"…\"}, \"old\": {\"text\": \"…\"}}. NOTE: the field's "
     "own hint suggests {\"text\": \"…\"}; with that, the new cause gets your note as text and the old cause gets an "
     "EMPTY new version, and its counters shrink × 0.7 (edit shrink). A procedure or case ticked instead of a cause is "
     "refused with \"split needs a cause target\".",
     "One stored cause sometimes covers two different mechanisms; splitting keeps both explanations without losing the "
     "history.",
     "You tick the cause, click the tile, type {\"new\": {…}, \"old\": {…}} into \"Text of your change\", click \"Record: Split\".",
     "\"Text of your change\" appears (not enforced);",
     '{"action": "split", "targets": ["cause::T-42::c0"], "content": {"new": {"text": "…"}, "old": {"text": "…"}}, …}',
     ("if name == \"split\"", "return {\"events\": ev, \"effects\": fx, \"error\": \"unhandled\"}"),
     "Branch split: node_create {sig, node_id: \"c<number of active causes>\", content: content.new or {text: note}} + "
     "node_edit {sig, node_id: <old>, content: content.old or {}}. Effect text: \"split into two causes\".",
     [S("database", "node_create → node, node_version, edge (a = b = 1); node_edit → new version of the old cause, its a "
                    "and b × 0.7. ProcGraph: new cause node + CAUSED_BY link, new version of the old one.",
        py(KG, "KGDB._project", "elif kind == \"node_create\"", "elif kind == \"node_edit\""))],
     screen="No receipt is defined; the message shows \"split into two causes\". " + DIRECT_SCREEN,
     example="Scratch copy with {\"text\": …}: node_create c1 {\"text\": \"split note\"} + node_edit c0 {} (a 3.94 → 3.06, "
             "b 2.96 → 2.37); with {\"new\": …, \"old\": …}: node_create c2 \"new part\" + node_edit c0 \"old part\".")

tile("delete_request", GT, "Request deletion", "ask for a cause to be removed", ["one"], "",
     "Records a request to remove the ticked cause. Nothing is removed yet: a second admin must use \"Approve the "
     "deletion\". Only causes can be requested; with a procedure or case ticked nothing but the admin_action is written "
     "and no error is shown (the history still lists it as a negative decision).",
     "Deleting knowledge is irreversible in effect, so it needs a request and a separate approval by another person.",
     "You tick the cause, click the tile, optionally give a note, click \"Record: Request deletion\".",
     "\"Record\" stays disabled until one record is ticked;",
     '{"action": "delete_request", "targets": ["cause::T-42::c2"], "note": "<why>", …}',
     ("if name == \"delete_request\"", "if name == \"delete_approve\""),
     "Branch delete_request: delete_request {sig, node_id, requested_by: <you>, note}. Effect text: \"delete requested; "
     "a second admin must approve it\".",
     [S("database", "Only the event table: delete_request has no projection; it waits there for delete_approve.")],
     screen="No receipt is defined; the message shows \"delete requested; a second admin must approve it\" (or "
            "\"applied\" when nothing was requested). " + DIRECT_SCREEN,
     example="Scratch copy: on cause c2 → delete_request; on a procedure → only admin_action, effects empty.")

tile("delete_approve", GT, "Approve the deletion (second admin)", "confirm the removal of a cause", ["one", "approver"],
     "yellow (two people)",
     "Carries out a pending deletion request for the ticked cause: the cause is hidden (status \"deleted\", soft delete) "
     "and its link from the error type too; the events stay. Refused with \"no pending delete_request for <cause>\" when "
     "nobody asked, and with \"delete needs a second admin (approver != requester of the delete)\" when the second admin "
     "is the person who made the request. The check is against the original requester, not against \"Your name\".",
     "Two-person rule for deletions, and soft delete so nothing is lost for good.",
     "You tick the cause, click the tile, type the second admin, click \"Record: Approve the deletion (second admin) "
     "(written to the event log with both names)\".",
     "the second-admin field appears and is required;",
     '{"action": "delete_approve", "targets": ["cause::T-42::c2"], "approver": "<second admin>", …}',
     ("if name == \"delete_approve\"", "if name == \"restart_failed\""),
     "Branch delete_approve: looks up the newest not-undone delete_request event for that cause; soft_delete {sig, "
     "node_id, requested_by, approved_by} with the approver as actor. Effect text: \"deleted\".",
     [S("database", "soft_delete → KGDB: node status deleted, edge status deleted (approved_by ≠ requested_by); "
                    "ProcGraph: pnode and CAUSED_BY pedge deleted.", py(KG, "KGDB._project", "elif kind == \"soft_delete\"", "elif kind == \"merge\""))],
     screen="No receipt is defined; the message shows \"deleted\" or \"refused: …\". " + DIRECT_SCREEN,
     example="Scratch copy: approver = requester → refused (the admin_action stays in the history as negative); with "
             "\"mapper two\" → soft_delete, c2 node and edge status deleted.")

# ---------------------------------------------------------------- Add what you know
GA = "Step 2 · Add what you know"

tile("lesson", GA, "Record a lesson", "a note about this error; the next proposal must read it", [], "",
     "Saves your note as a lesson \"ADMIN NOTE: <note>\" for this error type (attached to a ticked cause or procedure "
     "if any). Lessons are put into the AI (artificial intelligence) reviewer's prompt at the next lookup and search of "
     "this error type and are themselves found by the lookup (\"Note: …\"). No counter changes. The note is not "
     "enforced: an empty lesson can be recorded.",
     "Knowledge that is not a verdict (\"the trigger needs a D3hot to D0 transition\") must still reach the next "
     "proposal; the project wants the admin's corrections to steer the next attempt.",
     "You type the note in \"Note\", click the tile, click \"Record: Record a lesson\".",
     "only the Note field matters;",
     '{"action": "lesson", "targets": [], "note": "<the lesson>", …}',
     ("if name == \"lesson\"", "if name == \"undo\""),
     "Branch lesson: lesson {sig, cause, vhash, text: \"ADMIN NOTE: <note>\", producer: <you>}. Effect text: "
     "\"recorded; nothing else changes\".",
     [S("database", "lesson → lesson table; ProcGraph: lesson node + LESSON_ABOUT link. Read by KGDB.lessons for the "
                    "next prompts.", py(KG, "KGDB.lessons"))],
     screen="No receipt is defined; the message shows \"recorded; nothing else changes\". " + DIRECT_SCREEN,
     example="Scratch copy: lesson \"ADMIN NOTE: the trigger needs a D3hot to D0 transition\", lesson node lesson::85.")

tile("add_cause", GA, "Add a cause", "my own description of the cause", ["minutes"], "green",
     "Saves your own explanation of the cause as a new cause of this error type (id \"c<number of active causes>\") with "
     "one success (+1); if you ticked an existing cause, that one gets one failure (−1). Then a lab job searches for a "
     "procedure that reproduces your cause and checks it on known-bad and fixed firmware. The text goes into \"Text of "
     "your change\" as JSON (JavaScript Object Notation) {\"text\": \"…\"}; when empty, the note is used.",
     "When the stored causes are all wrong, the admin's own diagnosis must become a first-class record that the lab "
     "then tries to prove.",
     "Optionally tick the cause it replaces, click the tile, type {\"text\": \"…\"}, click \"Record: Add a cause\".",
     "\"Text of your change\" appears (not enforced);",
     '{"action": "add_cause", "targets": [], "content": {"text": "<your cause>"}, …}',
     ("if name == \"add_cause\"", "if name == \"add_procedure\""),
     "Branch add_cause: node_create {sig, node_id, content} + verdict {verdict: \"not\", chosen: <new id>, rejected: "
     "<ticked cause or null>}. Effect text: \"your cause was saved and marked correct (+1)\" [+ \"; the shown one marked "
     "not correct (-1)\"].",
     [S("database", "node_create → node, node_version, edge; verdict → fade × 0.98, new cause a + 1, n + 1, ticked cause "
                    "b + 1.", R_VERDICT)],
     lab=[S("engine", "Lab: mode generate - proposal by the AI reviewer (or the stand-in), search under the trial budget "
                      "and the 600 s triage limit, a second search from the family template if nothing reproduced, "
                      "shortening, stress step, then _finish (lab check, test files, script_gate).", R_EXEC_SEARCH),
          LAB_FILES],
     screen="Receipt: \"What happens next: the new cause is recorded, a procedure that reproduces it is searched for, then "
            "checked in the lab on known-bad and fixed firmware.\" Add a cause stays on \"Candidates & actions\". " + JOB_SCREEN,
     example="Scratch copy (empty knowledge base): node_create c0, verdict, then 263 trials, reproduced in at least 68 %, "
             "lab check 6 of 6 known-bad / 0 of 3 fixed, regression test filed.")

E("s4d-tile-add-procedure", GA, "Add a procedure", "button", "#r-actions .atile[data-a=\"add_procedure\"]",
  "Tile text: \"Add a procedure\" — my own procedure: opens the editor below; your procedure is run in the lab before "
  "it is saved. Tags: \"runs in the lab, takes minutes\". The tile itself sends nothing and opens no step 3: it opens "
  "the editor \"Edit the procedure yourself …\", scrolls to it and shows the message \"build your procedure in the "
  "editor (steps, timing, power state), then press \"Propose my procedure and run it on the device\"\". That button "
  "sends the decision add_procedure with your procedure: it is saved as \"proposed\" (producer \"admin:<you>\") and "
  "run in the lab - 6 runs; at least 3 reproductions → validated under its own hash, checked on known-bad and fixed "
  "firmware and filed; fewer → \"failed validation\", a lesson \"your procedure showed the error in k of 6 runs - not "
  "enough; the search starts from it\" and a search from it. Nothing is approved automatically, as the receipt says: "
  "approving it as the saved procedure stays a separate \"Approve as second admin\".",
  "The admin may know a better procedure than the search; it must be written with the bench's own vocabulary (the "
  "editor) and still be proven in the lab before it is trusted.",
  "Offered always.",
  [S("you", "You click the tile \"Add a procedure\"."),
   S("browser", "startAction(\"add_procedure\") hides step 3, opens <details id=\"ed-box\">, scrolls to it and shows the "
                "message; nothing is sent.", R_START),
   S("you", "You build the steps, timing and power state in the editor and click \"Propose my procedure and run it on the "
            "device\"."),
   S("browser", "The editor's button calls doAction(\"add_procedure\", edScenario()) with the ticked records of step 1.",
     js(RJ, "$(\"ed-submit\").onclick", 1)),
   S("http", ACT_URL + '{"action": "add_procedure", "targets": [...], "content": {"commands": [{"op": "…"}], '
                       '"timing": {…}, "power_state": "…"}, "approver": "", …}'),
   S("server", SRV_TEXT, R_ACT_API),
   S("service", SVC_JOB, R_JOB),
   S("engine", EXEC_TEXT + " Branch add_procedure: compose.clean_scenario checks the procedure (unknown commands or no "
               "command → refused; timings clamped to range); solution_propose {vhash, sig, cause, scenario, producer: "
               "\"admin:<you>\"} → solution row with status proposed, scenario node and REPRODUCED_BY link. Effect text: "
               "\"your procedure was saved and will now be run in the lab\".",
     py(AA, "apply", "if name == \"add_procedure\"", "if name == \"link\"")),
   S("engine", "Lab: mode admin_procedure - 6 runs; ≥ 3 → stress step and _finish with validate_vhash (validated under "
               "its hash, author kept, lab check, script_gate, files under suite/); else solution_validate 0.0 "
               "(failed-validation), the lesson, mode adapt → search.", R_EXEC_REUSE),
   S("screen", "Receipt \"%s\" in the Result tab and the message, progress, then \"stage 2 finished: …\" with Undo "
               "and the outcome in the Result tab." % NEWREC_ADD_PROCEDURE)],
  code=[js(RJ, "if (name === \"add_procedure\") {", 4), py(AA, "apply", "if name == \"add_procedure\"", "if name == \"link\""), R_EXEC_REUSE],
  example="Scratch copy, a procedure from the editor (aspm_idle, read, D3hot): solution_propose by admin:mapper one, "
          "solution_validate 0.0 (0 of 6), the lesson, then a search that found a reproducing procedure (10 trials) "
          "and filed it.")

tile("escalate", GA, "Needs more evidence", "needs more evidence; a note is recorded", [], "",
     "Records a lesson \"ESCALATED: needs more evidence. <note>\" for this error type. Nothing else: the defect is not "
     "flagged in the queue and no counter changes.",
     "When the packets cannot decide, the honest answer is \"not enough evidence\"; the lesson tells the next person "
     "and the next proposal what is missing.",
     "Type what is missing in \"Note\", click the tile, click \"Record: Needs more evidence\".",
     "only the Note field matters;",
     '{"action": "escalate", "targets": [], "note": "<what is missing>", …}',
     ("if name == \"escalate\"", "if name == \"lesson\""),
     "Branch escalate: lesson {sig, cause: null, text: \"ESCALATED: needs more evidence. <note>\"}. Effect text: "
     "\"recorded; nothing else changes\".",
     [S("database", "lesson table + lesson node.", py(KG, "KGDB._project", "elif kind == \"lesson\"", "elif kind in (\"optimizer_result\", \"script_gate\")"))],
     screen="Receipt: \"A lesson 'needs more evidence' was recorded.\" " + DIRECT_SCREEN,
     example="Scratch copy: lesson \"ESCALATED: needs more evidence. need host log\".")

tile("wrong_signature", GA, "Dispute the stage-1 finding", "stage 1 picked the wrong error type: recorded for the analysis team",
     ["reason"], "red",
     "Records that you think stage 1 matched the wrong error type: a lesson \"SIGNATURE DISPUTED by admin: <reason>\" "
     "and a signature_dispute event. The causes are not touched. The dispute stays in the event table (visible on the "
     "Knowledge base page); no report of the application reads signature_dispute events yet.",
     "A wrong stage-1 match would make every stage-2 decision on this defect meaningless; the dispute must be kept "
     "apart from the verdicts on causes.",
     "Click the tile, give the reason, click \"Record: Dispute the stage-1 finding\".",
     "the reason field appears and is required;",
     '{"action": "wrong_signature", "targets": [], "note": "<why the error type is wrong>", …}',
     ("if name == \"wrong_signature\"", "# ---------------- ordering"),
     "Branch wrong_signature: lesson {text: \"SIGNATURE DISPUTED by admin: <note>\"} + signature_dispute {sig, note, "
     "evidence_refs}. Effect text: \"recorded for the analysis team\".",
     [S("database", "lesson table + lesson node; signature_dispute only in the event table.")],
     screen="Receipt: \"A dispute of the stage-1 finding was recorded; the causes are untouched.\" " + DIRECT_SCREEN,
     example="Scratch copy: lesson \"SIGNATURE DISPUTED by admin: this is T-43\" + signature_dispute.")

# ---------------------------------------------------------------- Run more in the lab
GL = "Step 2 · Run more in the lab"

tile("compose_tests", GL, "Generate test cases", "make more test variants from the saved command sequences; each is run on the drive and kept only if the same error appears",
     ["minutes"], "",
     "The AI (artificial intelligence) reviewer composes up to three test variants from the procedures saved for this "
     "error type (and up to two of the same failure family), for example a robust recreation, the trigger at its "
     "timing boundary, a different path to the same state; code checks them, each runs 6 times and is kept when the "
     "lower bound reaches 50 %; if none is, the search changes the best one (up to 120 trials). Every kept variant is "
     "checked on known-bad and fixed firmware and filed with its sources. Nothing is approved automatically. Ticked "
     "records are not used. Same as \"Generate test cases\" on the main screen.",
     "The project asks for more than one test per defect; composing from proven procedures is cheaper than searching "
     "from scratch.",
     "Click the tile, then \"Record: Generate test cases\".",
     "no field is needed;",
     '{"action": "compose_tests", "targets": [], …}',
     ("if name == \"compose_tests\"", "if name == \"add_cause\""),
     "Branch compose_tests: nothing after admin_action; effect text \"test variants being made\".",
     [S("database", "Later, per kept variant: solution_propose (producer \"llm:composed\" or \"composed\"), "
                    "solution_validate, script_gate.")],
     lab=[S("engine", "Stage2V3._compose: compose.sources_for, build_compose_prompt, clean_variants, 6 runs per variant, "
                      "optional search, verify_closed_loop, test files; status composed / not_reproduced / no_sources "
                      "(\"nothing saved to compose from\").", py(V3, "Stage2V3._compose")),
          LAB_FILES],
     screen="Receipt: \"What happens next: the AI reviewer composes up to three test variants from the saved procedures; "
            "each is run in the lab and filed only if the analyser finds the same defect. Nothing is approved "
            "automatically.\" " + JOB_SCREEN,
     when="Not shown on this page, because its saved lookup predates this decision.",
     example="Scratch copy (stand-in): 3 sources, 3 variants, 18 lab runs; \"precondition then stored trigger\" "
             "reproduced 6 of 6 and was filed, two more variants were filed too. Live: 10 of the 50 rows in the history "
             "are Generate test cases by admin.")

tile("sweep", GL, "Try nearby variations", "try the procedure with each timing halved and doubled, every power state and a longer burst; variants that still show the error are saved as tests",
     ["minutes"], "",
     "Takes the newest approved procedure of this error type (else the newest awaiting approval; ticked records are not "
     "used) and tries its neighbourhood: each timing value halved and doubled, every other power state, the last "
     "command repeated, and injected link faults when the bench supports them. Each variant runs 3 times; 2 or more "
     "reproductions = failure-prone. The three most stressful failure-prone variants are checked on known-bad and fixed "
     "firmware and filed as tests. Nothing is approved automatically. Same as \"Try nearby variations\" on the main "
     "screen.",
     "The project asks for vulnerability analysis: knowing which nearby conditions also fail tells the firmware team "
     "how wide the weakness is, and the tests guard the margin.",
     "Click the tile, then \"Record: Try nearby variations\".",
     "no field is needed;",
     '{"action": "sweep", "targets": [], …}',
     ("if name == \"sweep\"", "if name == \"compose_tests\""),
     "Branch sweep: nothing after admin_action; effect text \"sweep started\".",
     [S("database", "Later, per filed variant: solution_propose (producer \"sweep\"), solution_validate, script_gate.")],
     lab=[S("engine", "Stage2V3._sweep: base procedure, sweep.neighbourhood(base), 3 runs each, failure-prone ≥ 2 of 3, "
                      "the 3 most stressful → verify_closed_loop + test files; status swept / no_base (\"nothing to vary\").",
            py(V3, "Stage2V3._sweep")),
          LAB_FILES],
     screen="Receipt: \"What happens next: nearby variations of the reproducing procedure are tried to find other "
            "failure-prone conditions; the failure-prone ones are filed as regression tests, most stressful first. "
            "Nothing is approved automatically.\" " + JOB_SCREEN,
     when="Not shown on this page, because its saved lookup predates this decision.",
     example="Live, the last decision on this defect: 42 lab runs, 13 failure-prone variations, most stressful \"burst "
             "length doubled (16 -> 32)\", \"queue depth doubled (8 -> 16)\", \"block size doubled (4 -> 8 kB)\"; lab "
             "check 6 of 6 / 0 of 3; regression test filed.")

tile("restart_failed", GL, "Restart the search after a failed attempt", "failed trial (-1): recorded against the ticked "
     "procedure or cause; the search starts again with another random seed",
     ["one", "minutes"], "",
     "The \"Negative Ack (−1)\" of the project's flow: records the failed attempt and starts the search again on "
     "another random stream. With a cause ticked: b + 1 and the lab counter tb + 1 on it; with a procedure ticked: b + 1 "
     "on its link from the cause (and the lab then re-runs that procedure first, as with Accept); always a lesson "
     "\"FAILED TRIAL recorded by <you>; the search starts again: <note>\". The attempt number = how many earlier results "
     "of this defect ended without a reproduction; the search seed is shifted by 10 per attempt. The tile needs one "
     "ticked record (\"Before recording: tick the record this is about (step 1)\"), so the −1 is recorded against it - "
     "except when the ticked record is an \"earlier case\" or the error type itself, which have no counters: then only "
     "the lesson is written and the effect text is empty. NOTE: the history still counts this decision as neutral, not "
     "negative.",
     "A search that found nothing must count against what was tried, and simply repeating the same random search would "
     "repeat the same failure.",
     "Tick the cause (or procedure) that failed, click the tile, optionally add a note, click \"Record: Restart the "
     "search after a failed attempt\".",
     "\"Record\" stays disabled until one record is ticked;",
     '{"action": "restart_failed", "targets": ["cause::T-42::c0"], "note": "", …}',
     ("if name == \"restart_failed\"", "# ---------------- structure"),
     "Branch restart_failed: cause → verdict {verdict: \"not\", rejected} + verdict {verdict: \"lab\", chosen, "
     "lab_result: false}; procedure → proc_credit {edge_id, r: 0.0}; then lesson. Effect text: \"failed trial recorded "
     "(-1); the search starts again\" (empty when the ticked record is neither a cause nor a procedure).",
     [S("database", "Each verdict fades all causes × 0.98 (twice here); the cause gets b + 1, n + 1 and tb + 1. "
                    "proc_credit → pedge b + 1.", R_VERDICT)],
     lab=[S("engine", "Stage2Service.act sets attempt; Stage2V3.execute uses seed opt_seed + 10 × attempt and runs the "
                      "normal search and lab check.", py(V3, "Stage2V3.execute", "seed_off = int(action.get(\"attempt\") or 0)", "if inc.layer == \"workload\"")),
          LAB_FILES],
     screen="Receipt: \"Failed attempt recorded (−1): it counts against the procedure's lab record, a lesson is kept, and "
            "the search restarts with a different random seed.\" " + JOB_SCREEN,
     when="Not shown on this page, because its saved lookup predates this decision. The Result box of the main "
          "screen offers the same after a failed search.",
     example="Scratch copy, cause ticked: two verdicts (c0 b 1.96 → 2.90, tb 2 → 3) and the lesson, then a new search. "
             "(Sent with nothing ticked - no longer possible from the tile - only the lesson was written.)")

# ---------------------------------------------------------------- Put it aside
GP = "Step 2 · Put it aside"

tile("skip", GP, "Skip", "no decision now", [], "",
     "Logs that you saw the defect and decided nothing. No counter or rating changes. The defect nevertheless counts as "
     "\"decided\" in the queue afterwards (any recorded result does), so \"next\" moves past it.",
     "Not deciding is deliberately not a signal: tiredness or lack of time must not be learned as \"wrong\".",
     "Click the tile, then \"Record: Skip\".",
     "no field is needed;",
     '{"action": "skip", "targets": [], …}',
     ("if name in (\"skip\", \"defer\")", "if name == \"escalate\""),
     "Branch skip: nothing after admin_action; effect text \"recorded; nothing else changes\".",
     [S("database", "Only the admin_action event (neutral).")],
     screen="Receipt: \"Logged only. No counts or ratings changed.\" Skip stays on \"Candidates & actions\". " + DIRECT_SCREEN)

tile("defer", GP, "Defer (keep in the queue)", "come back to this later", [], "",
     "Logs that you want to come back later. No counter changes. NOTE: the defect stays in the list, but it is counted "
     "as \"decided\" afterwards (queue counter, \"next\" skips it), because any recorded result marks a defect decided.",
     "Lets the admin put a hard case aside without a verdict that would teach the system something false.",
     "Click the tile, then \"Record: Defer (keep in the queue)\".",
     "no field is needed;",
     '{"action": "defer", "targets": [], …}',
     ("if name in (\"skip\", \"defer\")", "if name == \"escalate\""),
     "Branch defer (shared with skip): effect text \"recorded; nothing else changes\".",
     [S("database", "Only the admin_action event; runs/<run>/stage2/<defect>.json gets a result, which the queue counts "
                    "as decided.", py("app/services.py", "Services.queue"))],
     screen="Receipt: \"Logged only; the defect stays in the queue.\" " + DIRECT_SCREEN)

tile("undo", GP, "Undo a decision", "undo one event by its number (shown as # in the decision history and on the "
     "Knowledge base page); the tables are rebuilt without it", ["event"], "",
     "Marks ONE event of the knowledge base as undone and rebuilds every table from the remaining events, so its effect "
     "disappears. You give the event number: the history table below shows it as \"#<number>\" next to the date, and "
     "the Knowledge base page lists every event. NOTE: one decision consists of several events (admin_action + verdict "
     "/ proc_credit / lesson / …), and the # in the history is the number of its admin_action event. Undoing that "
     "number only removes the row from the history and leaves the counters as they are; undoing a primitive event "
     "(number from the Knowledge base page) reverses the counters but leaves the history row. Only the Undo button in "
     "the message right after a decision undoes all of that decision's events at once.",
     "Every change is an event, so every change can be reversed exactly; mistakes must be correctable without editing "
     "the database by hand.",
     "Click the tile, type the event number in \"Which decision to undo\", click \"Record: Undo a decision\".",
     "the field \"Which decision to undo\" appears and is required;",
     '{"action": "undo", "event_id": 1169, "targets": [], …}',
     ("if name == \"undo\"", "if name == \"wrong_signature\""),
     "Branch undo (after logging admin_action): KGDB.undo(event_id) - UPDATE event SET undone = 1, log an undo event, "
     "rebuild(). Effect text: \"decision <n> undone\".",
     [S("database", "KGDB.rebuild empties node, node_version, edge, case_memory, signature, artifact, solution, lesson, "
                    "pnode, pnode_version, pedge and replays every event that is not undone.", py(KG, "KGDB.rebuild"))],
     screen="No receipt is defined; the message shows \"decision <n> undone\". " + DIRECT_SCREEN,
     example="Scratch copy: undoing event 55 (the solution_deprecate of a Retire) brought the procedure back to "
             "admin-approved and its node b 3 → 2, while the Retire row (its admin_action, event 54) stayed in the "
             "history as negative. Live: the newest history row of T-42 is #1169 (Try nearby variations).",
     code=[py(AA, "apply", "if name == \"undo\"", "if name == \"wrong_signature\""), py(KG, "KGDB.undo"), py(KG, "KGDB.rebuild")])

# ===============================================================================================================
# 8. Step 3 · Confirm
# ===============================================================================================================
G6 = "Step 3 · Confirm"
BODY_LINE = js(RJ, "const body = { action: name, requester", 1)

E("s4d-step3-confirm", G6, "Confirm:", "display", "#a-step3 .dq",
  "Step 3 appears when you click a tile (except \"Add a procedure\", which opens the editor instead): \"Confirm: "
  "<decision>\", under it the tile's meaning (ACTION_HELP) and, for "
  "the decisions that have one, the receipt \"What happens next: …\" (RECEIPT in review.js). Only the fields this "
  "decision needs are shown (NEED in review.js): the reason for Reject / Could not be reproduced / Dispute, the second "
  "admin for Approve / Retire / Approve the deletion, the decision number for Undo, the change text for Revise / Add a "
  "cause / Split; Note and Your name are always there.",
  "A decision is written to the knowledge base for good (only an explicit undo reverses it); a confirmation step "
  "with the consequences spelled out prevents accidental clicks.",
  "Hidden until a tile is clicked; hidden again after Record, cancel, or opening another defect.",
  [S("you", "You click a tile in step 2."),
   S("browser", "startAction fills #a-chosen with actionWord, #a-what with ACTION_HELP, #a-receipt with RECEIPT and "
                "shows only the rows in NEED for this decision.", R_START),
   S("browser", "The receipts are fixed texts in review.js.", R_RECEIPT),
   S("screen", "\"3 Confirm: Reject (not correct)\" with meaning, receipt and the needed fields.")],
  code=[js(RJ, "const NEED = {", 4), R_START])

E("s4d-step3-reason", G6, "Why is it not correct? required", "field", "#a-reason",
  "The reason for a negative decision. Required: \"Record\" stays disabled and \"Before recording: say why\" is shown "
  "until it is filled. Pressing Enter in it records the decision. It is sent as the decision's note (it replaces the "
  "Note field) and cut at 400 characters by the server.",
  "Negative feedback without a reason cannot be checked or learned from; the next admin sees the reason in the yellow "
  "callout and in the history.",
  "Shown only for Reject (not correct), Could not be reproduced and Dispute the stage-1 finding.",
  [S("you", "You type why the record is wrong, e.g. \"wrong cause: the completion status was Successful, not "
            "Unsupported Request\"."),
   S("browser", "Each keystroke re-checks missing(); confirmAction passes the trimmed text as the reason; doAction sends "
                "note: reason || Note.", js(RJ, "const reason = NEED.reason.includes(name)", 1)),
   S("http", ACT_URL + '{"action": "reject", "note": "<your reason>", …}'),
   S("engine", "admin_actions.apply keeps note[:400] in the admin_action event (and in the lesson text for Could not be "
               "reproduced and Dispute).", R_APPLY_HEAD),
   S("database", "event table: admin_action payload \"note\"."),
   S("screen", "\"Reason or note\" column of the history; the yellow callout of the next defect of this error type.")])

E("s4d-step3-note", G6, "Note (optional, kept with the decision)", "field", "#a-note",
  "Free text kept with any decision. For Accept with a note, Record a lesson and Needs more evidence it is the "
  "content of the lesson; for Add a cause and Split it is the fallback text; for Restart it is the reason in the "
  "lesson. It is not cleared after recording, so it is sent again with the next decision unless you empty it.",
  "Context that is not a verdict (\"only on firmware B\") must travel with the decision.",
  "Always shown in step 3.",
  [S("you", "You type a note."),
   S("browser", "doAction sends note: reason || $(\"a-note\").value.", BODY_LINE),
   S("http", ACT_URL + '{"note": "<your note>", …}'),
   S("engine", "apply: note = (action.get(\"note\") or \"\")[:400] → admin_action payload and, depending on the "
               "decision, a lesson.", R_APPLY_HEAD),
   S("database", "event table (admin_action note); lesson table for the lesson-writing decisions."),
   S("screen", "\"Reason or note\" column of the history.")])

E("s4d-step3-name", G6, "Your name (recorded with every decision)", "field", "#a-requester",
  "Who is deciding. Pre-filled with the person who started the analysis of this trace or, if that is not recorded, "
  "with the name this browser remembered. It becomes the actor of every event of the decision and the \"operator\" in "
  "the event's metadata (with run, trace, defect, device, firmware and time). When it is empty the server records the "
  "run's operator, else \"admin\". For two-person decisions it must differ from the second admin.",
  "The project requires every decision to be traceable to a person; the two-person rule needs two names.",
  "Always shown in step 3.",
  [S("browser", "showRunMeta fills it from run_meta.operator or localStorage \"operator\" if it is empty.",
     js(RJ, "const req = $(\"a-requester\"); let saved = \"\"", 2)),
   S("browser", "doAction sends requester: the trimmed value, or nothing when empty.", BODY_LINE),
   S("http", ACT_URL + '{"requester": "<your name>", …}'),
   S("service", "Stage2Service.act: action.setdefault(\"requester\", run operator or \"admin\"); _event_meta puts it into "
                "every event as meta.operator.", py(SV, "Stage2Service._event_meta")),
   S("database", "event table: column actor and payload.meta.operator of every event the decision writes."),
   S("screen", "\"Who\" column of the history.")],
  example="On this page the field is empty (the run's operator is \"name not recorded\"), so a decision would be "
          "recorded as \"admin\" - which is why most live history rows say admin.")

E("s4d-step3-approver", G6, "Name of the second admin required: this action needs two people", "field", "#a-approver",
  "The second person for two-person decisions. Required and must be different from \"Your name\" (\"Before recording: "
  "name the second admin\" / \"the second admin must be a different person from you\"). The name is sent only with "
  "Approve as second admin, Retire the procedure and Approve the deletion (second admin); every other decision sends an "
  "empty approver. The field is emptied as soon as such a request is sent, so a name counts for one decision only - "
  "including a name the main screen puts there for its \"Approve as second admin\" button or its retire question. "
  "(Stage2V3._finish would approve a new lab procedure if a request named a second admin, but requests from this page "
  "never do for lab decisions.)",
  "Four-eyes principle for approving, retiring and deleting knowledge, without a name lingering into later decisions.",
  "Shown for Approve as second admin, Retire the procedure and Approve the deletion (second admin).",
  [S("you", "You type the second admin's name."),
   S("browser", "missing() checks it is filled and differs from Your name.",
     js(RJ, "if (NEED.approver.includes(name) && $(\"a-approver\").value.trim() && ", 1)),
   S("browser", "doAction: approver = the trimmed name only when NEED.approver includes the decision, else \"\"; then the "
                "field is cleared.", js(RJ, "if (NEED.approver.includes(name)) $(\"a-approver\").value = \"\"", 1)),
   S("http", ACT_URL + '{"action": "promote", "approver": "<second admin>", …}'),
   S("engine", "apply refuses promote / deprecate when approver is empty or equal to requester; delete_approve compares "
               "with the original requester.", py(AA, "apply", "if name in TWO_PERSON", "# impression record")),
   S("engine", "Lab decisions: _finish writes solution_approve only when a request names an approver different from the "
               "requester - not the case for lab decisions sent from this page.", R_FINISH_APPROVE),
   S("database", "solution_approve / solution_deprecate / soft_delete events carry approved_by; their actor is the "
                 "second admin."),
   S("screen", "Record button reads \"Record: <decision> (written to the event log with both names)\"; afterwards the "
               "field is empty again.")])

E("s4d-step3-event", G6, "Which decision to undo required", "field", "#a-event",
  "The number of the event to undo (a whole number ≥ 1), as the hint says \"the event number shown in the history "
  "table below\": the When column shows it as \"#<number>\" - the number of the decision's admin_action event. Every "
  "event, including the verdict and credit events a decision writes after it, is listed with its number on the "
  "Knowledge base page (/db, event table). One number undoes one event only; undoing the # from the history removes "
  "the history row but not the counters (see Undo a decision).",
  "Undo must name exactly what it reverses.",
  "Shown only for Undo a decision.",
  [S("you", "You type the event number."),
   S("browser", "missing() requires a value; doAction sends event_id: +value.", BODY_LINE),
   S("http", ACT_URL + '{"action": "undo", "event_id": <number>, …}'),
   S("engine", "apply: db.undo(int(action[\"event_id\"]), who).", py(AA, "apply", "if name == \"undo\"", "if name == \"wrong_signature\"")),
   S("database", "event.undone = 1 for that row, a new undo event, every projection rebuilt.", py(KG, "KGDB.undo")),
   S("screen", "Message \"decision <n> undone\".")])

E("s4d-step3-content", G6, "Text of your change (JSON, for example {\"text\": \"…\"})", "field", "#a-content",
  "A small text box for the new content, written as JSON (JavaScript Object Notation). Revise and Add a cause expect "
  "{\"text\": \"…\"}; Split expects {\"new\": {\"text\": \"…\"}, \"old\": {\"text\": \"…\"}} (the hint's example does "
  "not fit Split). If the text is not valid JSON the page refuses with \"content is not valid JSON\". The box is not "
  "cleared and is sent with any later decision while it holds text.",
  "Structured content can be stored as a new version of a record and searched later.",
  "Shown for Revise the text, Add a cause and Split.",
  [S("you", "You type for example {\"text\": \"access before the 10 ms recovery time\"}."),
   S("browser", "doAction: content = JSON.parse(value) when the box is not empty.", js(RJ, "let content; if (editedScenario)", 1)),
   S("http", ACT_URL + '{"content": {"text": "…"}, …}'),
   S("engine", "apply: node_edit / node_create / proc_edge_edit carry the content.", R_APPLY),
   S("database", "node_version.content (causes) or pedge.props.admin_revision (procedures)."),
   S("screen", "Visible as the cause text in later lookups (\"Possible cause: …\").")])

E("s4d-step3-go", G6, "Record this decision", "button", "#a-go",
  "Records the chosen decision. Its text changes to \"Record: <decision>\" (\"… (written to the event log with both "
  "names)\" for two-person decisions). Disabled while \"Before recording: …\" lists something missing.",
  "One explicit click per decision keeps the event log free of accidental entries.",
  "Shown in step 3; disabled until everything the decision needs is filled.",
  [S("you", "You click \"Record: …\"."),
   S("browser", "confirmAction: missing() empty → hides step 3 and calls doAction(name, null, reason).", R_CONFIRM),
   S("browser", "doAction builds the body, switches to the Result tab (except Accept, Add a cause, Add a procedure, "
                "Skip), shows \"applying: …\" and sends the request.", R_DOACTION),
   S("http", ACT_URL + '{"action": …, "targets": […], "requester": …, "approver": …, "note": …, "content": …, '
                       '"ranking": …, "event_id": …}'),
   S("server", SRV_TEXT, R_ACT_API),
   S("service", "Stage2Service.act applies it at once or queues a lab job.", R_ACT_SVC),
   S("screen", "Result tab, message with Undo, refreshed page (details per tile above).")],
  code=[R_CONFIRM, R_DOACTION])

E("s4d-step3-cancel", G6, "cancel", "button", "#a-cancel",
  "Closes step 3 without recording anything and removes the highlight from the chosen tile.",
  "Lets you back out after reading the receipt.",
  "Shown in step 3.",
  [S("you", "You click \"cancel\"."),
   S("browser", "hideStep3: R.pending = null, step 3 hidden, tile highlight removed; nothing is sent.",
     js(RJ, "function hideStep3()", 1)),
   S("screen", "Step 3 disappears.")])

E("s4d-step3-check", G6, "Before recording: …", "display", "#a-check",
  "The red line next to Record listing what is still missing: \"tick the record this is about (step 1)\", \"tick the "
  "two records to compare (step 1)\", \"click at least two candidates above, in your order\", \"say why\", \"name the "
  "second admin\", \"the second admin must be a different person from you\", \"give the number of the decision to "
  "undo\". It is computed in the browser only; the server checks again where it matters (two-person rule, target "
  "kinds).",
  "Tells the admin exactly what to fill instead of failing after the click.",
  "Shown while something is missing for the chosen decision.",
  [S("you", "You tick records, click candidates or type into the fields."),
   S("browser", "missing(name) builds the list from NEED; refreshStep3 writes it and disables Record.",
     js(RJ, "function missing(name)", 11)),
   S("screen", "\"Before recording: say why; name the second admin\" in red.")],
  code=[js(RJ, "function missing(name)", 12)])


# ===============================================================================================================
# 9. Keyboard
# ===============================================================================================================
G7 = "Keyboard keys"
KEY_REF = js(RJ, "document.addEventListener(\"keydown\", (e) => {", 4)
for key_, word_, act_, what_ in (
        ("a", "accept the ticked record", "startAction(\"accept\")",
         "Opens step 3 for Accept, exactly like clicking the Accept tile; it does not record anything until you click "
         "Record (the tick in step 1 is still needed)."),
        ("r", "reject it", "startAction(\"reject\")",
         "Opens step 3 for Reject (not correct) and puts the cursor into the reason field."),
        ("j", "next defect", "step(1)", "Opens the next defect of the queue (below the current one)."),
        ("k", "previous defect", "step(-1)", "Opens the previous defect of the queue.")):
    E("s4d-key-" + key_, G7, key_, "key", "",
      what_ + " Listed in the line \"Keyboard: a = accept the ticked record · r = reject it · j / k = next / previous "
      "defect.\" The keys are ignored while you type in a field, a text box or a list, before stage 2 is started, and "
      "on other pages.",
      "An admin reviewing many defects works faster with the keyboard.",
      "Active on the step-4 page while stage 2 is started.",
      [S("you", "You press %s." % key_),
       S("browser", "The page's keydown handler calls %s (a and r only when a lookup is shown)." % act_, KEY_REF),
       S("screen", "Step 3 opens for the decision." if key_ in "ar" else
               "The other defect opens (GET /api/runs/<run>/incidents/<defect>) on \"Candidates & actions\".")])


# ===============================================================================================================
# 10. Edit the procedure yourself
# ===============================================================================================================
G8 = "Edit the procedure yourself"
ED_PREVIEW = js(RJ, "function edPreview()", 1)

E("s4d-ed-summary", G8, "Edit the procedure yourself and propose it (it is run on the device before it is saved)",
  "button", "#ed-box > summary",
  "A fold-out editor under the decision form: the original procedure on the left (read-only), your version on the "
  "right. It is filled with the saved procedure (or, when nothing is saved, the AI (artificial intelligence) reviewer's "
  "proposal) each time the defect is shown.",
  "An admin who knows a better procedure must be able to write it down with the bench's own vocabulary, and it must be "
  "proven in the lab before it is saved (the same as \"Needs changes\" → \"Save corrected version\" on a card).",
  "Closed by default; the \"Add a procedure\" tile opens it and scrolls to it. Opening sends nothing.",
  [S("browser", "renderView calls edLoad(stored || generated, label) after every lookup.", js(RJ, "loadHistory(v.card.card); edLoad(", 1)),
   S("browser", "edLoad copies the commands and the five timing values (defaults 8 / 50 / 4 / 16 / 0) and the power "
                "state into the editor.", js(RJ, "function edLoad(sc, label)", 1)),
   S("screen", "\"Original (read-only)\" and \"Your version\" side by side.")])

E("s4d-ed-help", G8, "The twelve steps in the list are every command the lab bench can send to the drive: …", "display",
  "#ed-box > p.help",
  "The explanation box: the twelve commands (NVMe (Non-Volatile Memory express) reads, writes, flush, trim, write "
  "zeroes, Identify, Get Log Page, Set Features, Abort, plus controller reset, power cycle and an ASPM (Active State "
  "Power Management) idle period) are all the bench can send; the five timing values and the power state are its "
  "knobs; your version is run as given and, if it does not show the error reliably, becomes the starting point of the "
  "search, which changes the same steps and knobs; after a confirmed reproduction the timing is pushed harder and the "
  "most stressful version is filed as a second regression test. NOTE: the text says \"up to twelve steps\", but the "
  "editor does not stop at twelve; the server keeps at most 24 commands.",
  "Makes clear that the editor is not a fixed recipe list but the bench's vocabulary, and what happens to your version.",
  "Inside the open editor.",
  [S("engine", "compose.clean_scenario accepts only ALLOWED_OPS (stage2/llm_adapter.py), clamps timings to "
               "TIMING_RANGES, keeps at most 24 commands.", py("stage2/compose.py", "clean_scenario")),
   S("browser", "Fixed text in index.html.", js(IH, "The twelve steps in the list are every command the lab bench can send", 1)),
   S("screen", "Grey paragraph at the top of the editor.")])

E("s4d-ed-orig", G8, "Original (read-only)", "display", "#ed-orig",
  "The procedure the editor was filled from, labelled \"saved procedure\" or \"AI reviewer's proposal\": commands and "
  "timing line. It never changes while you edit; the preview counts your changes against it.",
  "You always see what you started from.",
  "Inside the open editor.",
  [S("http", "From the view: stored or generated (GET /api/runs/<run>/incidents/<defect>)."),
   S("browser", "edLoad writes the label and seq(sc) into #ed-orig and keeps ED.orig.", js(RJ, "function edLoad(sc, label)", 1)),
   S("screen", "Left panel of the editor.")],
  example="Here: \"saved procedure\" flush → write, queue depth 8 · 200 µs between commands · 4 KB · burst 16 · idle "
          "1866 ms · power none.")

E("s4d-ed-steps", G8, "Steps (click to remove)", "display", "#ed-steps",
  "Your command sequence as numbered chips (\"1. flush ✕\", \"2. write ✕\"). Clicking a chip removes that step. With no "
  "steps the preview says \"add at least one step\" and the propose button is disabled.",
  "Editing by clicking avoids typing errors; only commands the bench knows can be added.",
  "Inside the open editor.",
  [S("you", "You click a chip to remove it."),
   S("browser", "edRender draws ED.steps; a click splices the step out and redraws the preview.", js(RJ, "function edRender()", 1)),
   S("screen", "The chips and the preview update.")],
  example="Here: \"1. flush ✕\", \"2. write ✕\".")

E("s4d-ed-op", G8, "Add step", "select", "#ed-op",
  "The list of the twelve commands the bench can send: read, write, flush, trim, write_zeroes, reset, power_cycle, "
  "aspm_idle, identify, get_log, set_feature, abort. Choose one, then click \"add\".",
  "Only commands the bench can execute safely are offered; destructive ones (format, sanitize, firmware download, "
  "namespace delete) are not in the list and the server refuses them.",
  "Inside the open editor.",
  [S("you", "You choose a command."),
   S("browser", "The value is read when you click add.", js(IH, "<select id=\"ed-op\">", 1)),
   S("screen", "The chosen command is shown in the list.")])

E("s4d-ed-add", G8, "add", "button", "#ed-add",
  "Appends the command chosen in \"Add step\" to the end of your steps.",
  "Builds the sequence step by step.",
  "Inside the open editor.",
  [S("you", "You click \"add\"."),
   S("browser", "ED.steps.push(value); edRender() redraws chips and preview; nothing is sent.", js(RJ, "$(\"ed-add\").onclick", 1)),
   S("screen", "A new chip at the end; the preview counts one more change.")])

for id_, lab_, key_, lo_, hi_, dflt_, mean_ in (
        ("qd", "Queue depth", "qd", 1, 256, 8, "how many commands are outstanding at the same time"),
        ("us", "µs between commands", "inter_cmd_us", 1, 5000, 50, "the gap between two commands in microseconds (µs)"),
        ("bs", "Block size KB", "bs_kb", 4, 1024, 4, "the size of each read or write in kilobytes (KB)"),
        ("burst", "Burst length", "burst_len", 1, 128, 16, "how many commands are sent back to back in one burst"),
        ("idle", "Idle gap ms", "idle_gap_ms", 0, 2000, 0, "the pause between the steps in milliseconds (ms); the test "
                                                           "script sleeps this long after each step")):
    E("s4d-ed-" + id_, G8, lab_, "field", "#ed-" + id_,
      "Timing value \"%s\" = %s. Allowed %d–%d (default %d when the loaded procedure has none). A value outside the range "
      "makes the preview show \"%s must be %d-%d\" in red and disables the propose button. Sent as timing.%s."
      % (lab_, mean_, lo_, hi_, dflt_, {"qd": "queue depth", "inter_cmd_us": "µs between commands", "bs_kb": "block size KB",
                                        "burst_len": "burst length", "idle_gap_ms": "idle gap ms"}[key_], lo_, hi_, key_),
      "Timing is often what makes a defect appear (a command too soon after a power transition); the ranges are what the "
      "bench can set, and the server clamps to the same ranges (compose.TIMING_RANGES).",
      "Inside the open editor.",
      [S("you", "You type a number."),
       S("browser", "oninput → edPreview → edValid checks the range.", js(RJ, "function edValid()", 1)),
       S("browser", "edScenario puts it into timing.%s of the procedure that is sent." % key_, js(RJ, "function edScenario()", 1)),
       S("engine", "clean_scenario clamps it to [%d, %d] again on the server." % (lo_, hi_), py("stage2/compose.py", "clean_scenario")),
       S("screen", "The preview updates; red message when out of range.")])

E("s4d-ed-power", G8, "Power state", "select", "#ed-power",
  "The power state the device is put in before the sequence: none, L1 or L1.2 (link power-saving states of ASPM, "
  "Active State Power Management), D3hot (the device's low-power state) or APST (Autonomous Power State Transition). "
  "Sent as power_state; an unknown value becomes none on the server.",
  "Many defects (like T-42, an access too soon after leaving D3hot) only appear around power transitions.",
  "Inside the open editor.",
  [S("you", "You choose a power state."),
   S("browser", "oninput → edPreview; edScenario sends power_state.", js(RJ, "function edScenario()", 1)),
   S("engine", "clean_scenario keeps it only if it is in POWER_STATES.", py("stage2/compose.py", "clean_scenario")),
   S("screen", "\"power <state>\" in the preview, highlighted when it differs from the original.")])

E("s4d-ed-from-stored", G8, "start from the saved procedure", "button", "#ed-from-stored",
  "Refills the editor (and the Original) with the saved procedure of this lookup.",
  "Quick way back to the known procedure after experimenting.",
  "Inside the open editor; says \"nothing saved for this defect yet\" when there is none.",
  [S("you", "You click it."),
   S("browser", "edLoad(R.view.stored, \"saved procedure\") or the message; nothing is sent.", js(RJ, "$(\"ed-from-stored\").onclick", 1)),
   S("screen", "Steps, timing and power state of the saved procedure.")])

E("s4d-ed-from-llm", G8, "start from the AI reviewer's proposal", "button", "#ed-from-llm",
  "Refills the editor (and the Original) with the AI (artificial intelligence) reviewer's proposal of this lookup.",
  "Lets you take the proposal as a draft and correct it instead of typing it.",
  "Inside the open editor; says \"no proposal from the AI reviewer available\" when there is none (stand-in mode).",
  [S("you", "You click it."),
   S("browser", "edLoad(R.view.generated, \"AI reviewer's proposal\") or the message; nothing is sent.", js(RJ, "$(\"ed-from-llm\").onclick", 1)),
   S("screen", "Steps, timing and power state of the proposal.")])

E("s4d-ed-preview", G8, "Preview as it will be saved:", "display", "#ed-preview",
  "Your version exactly as it will be sent - commands and timing line, values that differ from the Original "
  "highlighted - followed by \"N change(s) compared with the original\" and, in red, every range problem or \"add at "
  "least one step\".",
  "You see what will be run before anything is sent.",
  "Inside the open editor; recomputed after every change.",
  [S("browser", "edPreview: seq(edScenario(), ED.orig), diffCount, edValid; disables #ed-submit when a problem exists.", ED_PREVIEW),
   S("browser", "diffCount counts commands by position, the five timing values and the power state.",
     js(AJ, "export function diffCount(a, b)", 8)),
   S("screen", "\"Preview as it will be saved: … 0 change(s) compared with the original\"")],
  example="Here: flush → write, queue depth 8 · 200 µs … · power none, \"0 change(s) compared with the original\".")

E("s4d-ed-submit", G8, "Propose my procedure and run it on the device", "button", "#ed-submit",
  "Sends your version as the decision \"Add a procedure\" (add_procedure) with the procedure as content: it is saved "
  "as \"proposed\" under your name and run in the lab first; if it shows the defect in at least 3 of 6 runs it is "
  "validated, checked on known-bad and fixed firmware and filed as a regression test; otherwise it is marked \"failed "
  "validation\", a lesson says so and the search starts from it. The ticked records of step 1 are sent too (a ticked "
  "cause becomes the procedure's cause).",
  "The admin's knowledge is used, but the lab - not the admin - decides whether it reproduces the defect (the "
  "project's \"validated by execution\" rule).",
  "Inside the open editor; disabled while the preview lists a problem.",
  [S("you", "You click \"Propose my procedure and run it on the device\"."),
   S("browser", "The handler shows \"proposing your procedure and validating it in the lab…\" and calls "
                "doAction(\"add_procedure\", edScenario()).", js(RJ, "$(\"ed-submit\").onclick", 1)),
   S("http", ACT_URL + '{"action": "add_procedure", "content": {"commands": [{"op": "flush"}, {"op": "write"}], '
                       '"timing": {"qd": 8, "inter_cmd_us": 200, "bs_kb": 4, "burst_len": 16, "idle_gap_ms": 1866}, '
                       '"power_state": "none"}, "targets": [...], …}'),
   S("server", SRV_TEXT, R_ACT_API),
   S("service", SVC_JOB, R_JOB),
   S("engine", "admin_actions.apply → clean_scenario, then solution_propose {producer: \"admin:<you>\"} (status proposed).",
     py(AA, "apply", "if name == \"add_procedure\"", "if name == \"link\"")),
   S("engine", "Stage2V3.execute: 6 runs; ≥ 3 → stress step and _finish (solution_validate under its hash, lab check, "
               "script_gate, test files); else solution_validate 0.0, lesson \"your procedure showed the error in k of 6 "
               "runs - not enough; the search starts from it\", search.", R_EXEC_REUSE),
   LAB_FILES,
   S("screen", "Receipt \"%s\", progress, then \"stage 2 finished: …\" with Undo and the outcome in the Result tab."
               % NEWREC_ADD_PROCEDURE)],
  code=[js(RJ, "$(\"ed-submit\").onclick", 1), py(AA, "apply", "if name == \"add_procedure\"", "if name == \"link\""), R_EXEC_REUSE],
  example="Scratch copy (aspm_idle → read, D3hot): solution_propose by admin:mapper one, 0 of 6 reproductions → "
          "failed-validation and the lesson, then a search that found and filed a reproducing procedure.")

# ===============================================================================================================
# 11. Earlier decisions on this error type
# ===============================================================================================================
G9 = "Earlier decisions on this error type"
HIST_SRC = [
    S("database", "event table of db/knowledge.sqlite: admin_action and script_gate events of this error type, not undone."),
    S("service", "Stage2Service.feedback_history: one row per decision, newest first, at most 50.", py(SV, "Stage2Service.feedback_history")),
    S("http", "GET /api/db/feedback/<error type>"),
]
HIST_ROW = js(RJ, "<table><thead><tr><th>When <span", 1)

E("s4d-hist-table", G9, "Earlier decisions on this error type", "table", "#r-history table",
  "The table of earlier decisions on this error type from every run and defect, newest first, at most 50 rows, with "
  "the columns When (with the event number \"#<n>\" used by Undo), Who, Decision, Reason or note, Lab outcome. Undone "
  "decisions are left out. A decision the server refused after logging it (for example Mark as a duplicate on "
  "procedures, Split on a procedure, Approve the deletion by the requester) is still listed, because its admin_action "
  "event was written first.",
  "History of feedback per error type is a project requirement; it lets the next admin see what was tried and how it "
  "ended.",
  "Shown after the lookup; \"no decision recorded for this error type yet\" when empty.",
  HIST_SRC + [S("browser", "loadHistory builds the table rows.", HIST_ROW),
              S("screen", "Five-column table under the chips.")],
  example="Here 50 rows; the newest: 27 Oct 2026 12:59:54 #1169, admin, Try nearby variations, no note, \"✓ "
          "regression test filed found on known-bad firmware 6/6 · on fixed firmware 0/3\".")

for col_, lab_, what_, why_ in (
        ("when", "When (# = event number, for Undo)", "The local date and time of the admin_action event (the event's "
                         "ts, seconds since 1970, shown with the browser's date format), followed by its event number in "
                         "grey, for example \"#1169\". That number is what \"Which decision to undo\" asks for; it "
                         "undoes this admin_action event only (the row disappears, the counters stay) - the Undo button "
                         "right after a decision undoes all of its events.",
         "Order and age of the decisions matter (old feedback fades 2 % per verdict, the newest negative one is shown "
         "in the callout), and the number makes each row addressable for Undo."),
        ("who", "Who", "The actor of the admin_action event: \"Your name\" of the person who decided, or \"admin\" when "
                       "the name was empty.",
         "Every decision must be traceable to a person."),
        ("decision", "Decision", "The decision in words (actionWord) in a coloured pill: \"+\" green for positive "
                                 "(Accept, Accept with a note, Approve as second admin, Add a procedure, Add a cause), "
                                 "\"−\" red for negative (Reject, Could not be reproduced, Dispute, Retire, Request "
                                 "deletion, Approve the deletion, a lesson starting \"NOT CORRECT\"), grey for neutral "
                                 "(everything else, including Restart the search after a failed attempt although it "
                                 "records −1).",
         "Colour plus sign (never colour alone) shows at a glance whether the error type was confirmed or rejected."),
        ("note", "Reason or note", "The note of the decision (the reason for negative decisions), up to 400 characters.",
         "The reason is what makes negative feedback usable by the next person."),
        ("outcome", "Lab outcome", "The first lab check (script_gate event) of this error type after the decision: "
                                   "\"✓ regression test filed\" (passed) or \"no test filed\", then \"found on known-bad "
                                   "firmware <hits>/<runs> · on fixed firmware <hits>/<runs>\"; \"-\" when no lab check "
                                   "followed before the next decision.",
         "Shows whether a decision held up in the lab, which is the real test of the feedback.")):
    E("s4d-hist-" + col_, G9, lab_, "row", "#r-history thead th:nth-child(%d)" % ("when who decision note outcome".split().index(col_) + 1),
      what_, why_, "One cell per history row.",
      HIST_SRC + [S("browser", "loadHistory writes the cell: " + {"when": "new Date(x.when * 1000).toLocaleString() + \" #\" + x.event_id",
                                                                  "who": "esc(x.actor)",
                                                                  "decision": "pill(actionWord(x.action), ok / bad, + / −)",
                                                                  "note": "esc(x.note)",
                                                                  "outcome": "x.outcome.admitted, known_bad, fixed"}[col_] + ".", HIST_ROW),
                  S("screen", "Column \"%s\" of the history table." % lab_)],
      code=[py(SV, "Stage2Service.feedback_history", "elif kind == \"script_gate\"", "return list(reversed(out))[:limit]")] if col_ == "outcome" else [])


# ===============================================================================================================
# 12. Stage 1 evidence tab
# ===============================================================================================================
G10 = "Stage 1 evidence tab"
EV_SRC = [
    S("files", "runs/<run>/incidents.json (the defect), isolation.json (status, mechanism, fix), incident_rows.jsonl "
               "(evidence rows), llm_reviews.jsonl (the AI reviewer's second opinion), run.json (topology)."),
    S("server", "get_incident reads those files, computes the failure signature (stage1_adapter.signature_of) and adds "
                "the stage-2 state.", py(SA, "get_incident")),
    S("http", "GET /api/runs/<run>/incidents/<defect>"),
]
EV_KV = js(RJ, "$(\"r-stage1\").innerHTML = kv([[\"Error type\"", 8)
for n_, (lab_, what_, ex_) in enumerate((
        ("Error type", "The catalogue entry the defect was matched to, written out: \"error type T-42 (chapter T = "
                       "timeouts and time limits, entry 42): <title>\" (atlas_candidates[0] of the defect).",
         "error type T-42 (chapter T = timeouts and time limits, entry 42): D3hot→D0 transition: access before the 10 ms "
         "recovery time"),
        ("Error family / layer / who caused it", "The error family in words (familyName of explanation.pattern), the layer "
                                                 "(physical link, data link, transaction, configuration, NVMe command, "
                                                 "host) and the side that caused it (host or device).",
         "configuration space, power state and reset sequencing (family P19) / config / host"),
        ("Where in the trace", "The packet range of the defect and the first abnormal packet with the rule that fired "
                               "first and its detail.",
         "packets 37391-37398; first abnormal packet #37395 (rule CFG.D0_EARLY): MMIO read 0x1C 2.000 ms after D3hot->D0"),
        ("Why it was flagged", "The stage-1 verdict, every rule that fired, and the isolation status from isolation.json.",
         "verdict CONFIRMED · rules that fired: CFG.D0_EARLY, S.RARE_WINDOW, TLP.CPL_STATUS · isolation ISOLATED"),
        ("Mechanism", "How the failure works, from isolation.json (why.mechanism) or the defect's explanation, up to 700 "
                      "characters.",
         "After writing PowerState=D0 in the PM capability of a function that was in D3hot, software must wait 10 ms …"),
        ("AI reviewer's second opinion", "The AI (artificial intelligence) reviewer's stage-1 verdict in words (agrees / "
                                         "disagrees / not sure with the stage-1 verdict), its error type, who it holds "
                                         "responsible, whether the verdict was reused from the cache or a fresh model "
                                         "call, and its summary (700 characters).",
         "agrees with the stage-1 verdict · T-42 · timeouts and time limits · responsible: host · verdict reused from the "
         "cache, then \"OBSERVED: CfgWr at #37387 sets PMCSR …\""),
        ("Failure signature (the fingerprint of the defect)", "The fingerprint a lab run must reproduce: error type, rule, "
                                                              "layer, timing class, the packets before the first "
                                                              "abnormal one, link events.",
         "T-42 · timeouts and time limits / rule CFG.D0_EARLY · layer config · timing class slow · preceding packets ACK, "
         "ACK, MWr(32), ACK, CfgWr0, ACK, Cpl, ACK · link events {\"UpdateFC\":1}"),
        ("Suggested fix", "The corrective action from isolation.json (fix.corrective_action), up to 300 characters.",
         "Runtime PM: echo auto > /sys/bus/pci/devices/BDF/power/control and idle the device; measure resume. SAFE."))):
    E("s4d-ev-" + str(n_ + 1), G10, lab_, "row", "#r-stage1 .kv > b:nth-of-type(%d)" % (n_ + 1),
      what_,
      "Every stage-2 decision rests on the stage-1 evidence; it is shown next to the decision so the admin can check the "
      "packets without leaving the page.",
      "In the \"Stage 1 evidence\" tab, filled when the defect is opened.",
      EV_SRC + [S("browser", "open() writes the row with kv([...]).", EV_KV),
                S("screen", "Row \"%s\" of the evidence table." % lab_)],
      example="Here: " + ex_ + ".")

E("s4d-ev-link", G10, "Open the full record ↗", "link", "#r-stage1 .kv a",
  "Opens the defect page (/defect?run=<run>&inc=<defect>) in a new browser tab: everything about this defect in reading "
  "order, including outside evidence and the earlier decisions.",
  "The full record is too long for a tab; one click gets there.",
  "Last row of the evidence table.",
  [S("you", "You click the link."),
   S("browser", "A plain link with target=_blank.", EV_KV),
   S("http", "GET /defect?run=<run>&inc=<defect>, then GET /api/runs/<run>/defect/<defect>"),
   S("screen", "The defect page opens in a new tab.")])

E("s4d-ev-rows", G10, "Evidence packets", "display", "#r-rows",
  "The raw analyzer rows of the defect as text: for each block \"Trace rows A to B\" followed by up to 40 rows (Packet=…, "
  "Link Dir=…, TLP / DLLP type, fields, time stamp, line).",
  "The packets are the evidence; everything else is built on them and can be checked against these rows.",
  "In the \"Stage 1 evidence\" tab.",
  EV_SRC[:1] + [S("server", "get_incident reads the defect's blocks from incident_rows.jsonl.", py(SA, "get_incident")),
                S("http", "GET /api/runs/<run>/incidents/<defect>"),
                S("browser", "open() joins \"Trace rows A to B\" and the first 40 rows of each block into #r-rows.",
                  js(RJ, "const rows = []; for (const b of d.rows)", 2)),
                S("screen", "Monospaced block under \"Evidence packets\".")],
  example="Here: \"Trace rows 37376 to 37413\", then \"Packet=37376 | Link Dir=Upstream | DLLP Type=ACK | AckNak Seq "
          "Num=1602 | …\".")


# ===============================================================================================================
# 13. Result tab
# ===============================================================================================================
G11 = "Result tab"
RES_SRC = [
    S("engine", "Stage2V3.execute / _finish / _compose / _sweep build the result dict (action, effects, mode, status, "
                "trials, repro_lower95, closed_loop, search, stress, best, test_files, times) and log it (_emit).",
      py(V3, "Stage2V3._emit")),
    S("service", "Stage2Service._record appends it to runs/<run>/stage2/<defect>.json as \"last\".", py(SV, "Stage2Service._record")),
    S("http", "GET /api/runs/<run>/incidents/<defect> (stage2.last), or the answer of POST …/act / GET /api/jobs/<job>"),
]
RES_KV = js(RJ, "$(\"r-result\").innerHTML = `<p>${esc(RECEIPT[r.action]", 8)
for n_, (lab_, what_, ex_, extra_) in enumerate((
        ("Action", "The last decision in words and, after \"→\", the effect texts the decision returned (for example "
                   "\"marked correct (+1)\", \"sweep started\"); a refusal appears as a red pill (\"procedure rejected: no "
                   "command\").",
         "Try nearby variations → sweep started", None),
        ("How it ran / outcome", "How the lab part ran (modeWord: \"saved procedure reused\", \"searched from the saved "
                                 "procedure\", \"searched from the evidence\", \"your version, run as given\", \"tests "
                                 "composed by the AI reviewer\", \"nearby variations tried\") and the outcome pill "
                                 "(statusWord: \"reproduced\", \"not reproduced (trial budget used up)\", \"no search run\" "
                                 "…), plus a red pill when the first-level triage limit (10 min) was exceeded.",
         "nearby variations tried / nearby variations tried", js(DJ, "const MODE_WORD = {", 2)),
        ("Search", "Number of lab runs (trials), \"reproduced in at least X % of lab runs (<word>)\" - the 95 % lower "
                   "bound (Wilson) - or \"no reproduction\", and the search time.",
         "42 lab runs · reproduced in at least 44 % of lab runs (possible) · 0.0 s", py("stage2/optimizer.py", "wilson_lower")),
        ("Lab check on known-bad and fixed firmware", "The closed loop: in how many of the known-bad runs the analyser "
                                                      "found the same defect, in how many fixed-firmware runs, the best "
                                                      "streak, then \"✓ regression test filed\" (found at least once on "
                                                      "known-bad and never on fixed) or \"✕ no test filed\", \"optimal "
                                                      "(score above 0.9 three times in a row)\" when reached, and the "
                                                      "check time.",
         "the analyser found the same defect in 6 of 6 lab runs on known-bad firmware and in 0 of 3 on fixed firmware · "
         "best streak 6 in a row → ✓ regression test filed (45.7 s)", py("stage2/testgen.py", "verify_closed_loop")),
        ("How the search went", "searchWords: procedures tried, distinct shapes kept as stepping stones, how often the AI "
                                "(artificial intelligence) reviewer was asked for fresh proposals, and the changes that "
                                "brought the trace closer to the failure signature; \"no search needed: the saved procedure "
                                "still reproduced the defect\" for a reuse; \"-\" otherwise.",
         "- (a sweep has no search)", py(V3, "Stage2V3._search_stats")),
        ("Most stressful conditions", "stressWords: after a confirmed reproduction each timing value is pushed in its "
                                      "stressful direction while the defect still appears in 2 of 3 runs; shows the "
                                      "multipliers reached and whether that version was filed as a second regression "
                                      "test, or that it could not be pushed harder.",
         "- (a sweep has no stress step)", py(V3, "Stage2V3._stress")),
        ("Procedure", "The best procedure of the decision (the reused, found, composed or most stressful one) as commands "
                      "and timing line.",
         "flush → write, queue depth 8 · 800 µs between commands · 4 KB · burst 32 · idle 1866 ms · power none", None),
        ("Regression tests", "The files written for the tests (manifest.json, conftest.py, test_*.py), comma separated.",
         "conftest.py, manifest.json, test_T_T_42_ad4740d9.py, test_T_T_42_c103605f.py, test_T_T_42_cce766ee.py",
         py("stage2/testgen.py", "emit_closed_loop_test")),
        ("Time", "Where the time went: lookup and proposal (of which the AI reviewer), search, lab check, in seconds.",
         "lookup and proposal 27.6 s (of which the AI reviewer 27.6 s) + search 0.0 s + lab check 45.7 s", None))):
    ch_ = RES_SRC + ([S("engine", "Computed by this function.", extra_)] if extra_ and extra_.startswith("py:") else []) + \
          [S("browser", "renderResult writes the row." + (" Words from decision.js." if extra_ and extra_.startswith("js:") else ""),
             extra_ if extra_ and extra_.startswith("js:") else RES_KV),
           S("screen", "Row \"%s\" of the Result tab." % lab_)]
    E("s4d-res-" + str(n_ + 1), G11, lab_, "row", "#r-result .kv > b:nth-of-type(%d)" % (n_ + 1),
      what_,
      "The project asks for a timed, verifiable outcome per defect: what was decided, what the lab did, whether a "
      "regression test was filed and how long it took.",
      "In the \"Result\" tab; \"no action yet\" before the first decision on this defect.",
      ch_, example="Here (the last decision on Defect 1 was Try nearby variations): " + ex_ + ".")

E("s4d-res-receipt", G11, "What happens next: …", "display", "#r-result > p",
  "The first line of the Result tab: the receipt of the last decision (the same RECEIPT text as in step 3), so the "
  "result is read together with what the decision promised.",
  "Keeps promise and outcome next to each other.",
  "Shown when the last decision has a receipt.",
  RES_SRC + [S("browser", "renderResult: <p>RECEIPT[r.action]</p> before the table.", R_RESULT),
             S("screen", "Paragraph at the top of the Result tab.")],
  example="Here: \"What happens next: nearby variations of the reproducing procedure are tried to find other "
          "failure-prone conditions; the failure-prone ones are filed as regression tests, most stressful first. "
          "Nothing is approved automatically.\"")


# ===============================================================================================================
# 14. The message after a decision (toast) and its Undo
# ===============================================================================================================
G12 = "The message after a decision"

E("s4d-toast", G12, "Undo", "button", "#toast-undo",
  "After a decision a dark message appears at the top right with the receipt or the effects (8 s; 3 s for the quiet "
  "saves of the main screen) and an \"Undo\" button. Undo marks every event the decision itself wrote (action_events: "
  "the admin_action and the verdict / credit / lesson events) as undone, newest first, rebuilds the knowledge base and "
  "refreshes the page; the message then says \"undone\". For a lab decision the Undo comes with the second message "
  "\"stage 2 finished: <outcome>\"; it removes the decision's credit, but the procedures, lab checks and test files "
  "the lab produced remain. A refused decision shows \"refused: …\" without Undo.",
  "Every mistake must be reversible in one click, right after it happened.",
  "Shown after each decision; hides itself after a few seconds.",
  [S("you", "You click \"Undo\" in the message."),
   S("browser", "undoFor(result) loops over result.action_events in reverse and posts each one.", R_UNDOFOR),
   S("http", "POST /api/db/undo  {\"event_id\": <n>, \"actor\": \"<your name>\"}   (once per event)"),
   S("server", "db_api.undo requires event_id and calls the service.", py("app/api/db_api.py", "undo")),
   S("service", "Stage2Service.undo: under the lock KGDB.undo, then the lookup index is rebuilt.", py(SV, "Stage2Service.undo")),
   S("database", "event.undone = 1, an undo event per undone event, every projection table rebuilt from the remaining "
                 "events.", py(KG, "KGDB.rebuild")),
   S("browser", "toast() shows \"undone\" (or \"undo failed: …\"); enter(R.cur) redraws the page.", js(AJ, "export function toast(msg", 4)),
   S("screen", "The decision disappears from the history and its counters are back.")],
  code=[R_UNDOFOR, py(KG, "KGDB.undo")],
  example="Scratch copy: the Accept on the saved procedure returned action_events [14, 15, 16] (admin_action, "
          "proc_credit, verdict); Undo would post 16, 15, 14.")
