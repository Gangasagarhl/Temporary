"""Button-by-button map, part A: the sidebar and top bar (SB), Step 1 - Choose the trace (S1), Step 2 - Analyse the
trace (S2), Step 3 - Defects found (S3) and the defect page /defect?run=...&inc=... (DP).

Format: docs/ui_map_src/SCHEMA.md. The small helpers below only build the dicts of that format (one dict per element,
one dict per chain step); ELEMENTS is the list the generator reads. Every `ref` and `code` string names a function
(py:) or a marker line (js:) that exists in the code; examples use values read (GET only) from this installation, run
run-20261026-145008-0220 ("exercise A", trace samples/sample_T-42_L-21_C-16_seed11.csv), defect INC-0001.
"""

# ---------------------------------------------------------------- file paths (relative to 13_production_app)
IDX = "app/static/index.html"
DHTML = "app/static/defect.html"
MAIN = "app/static/js/main.js"
RUN = "app/static/js/run.js"
INCJ = "app/static/js/incidents.js"
DEFJ = "app/static/js/defect.js"
APIJ = "app/static/js/api.js"
SETJ = "app/static/js/settings.js"
REVJ = "app/static/js/review.js"
REPJ = "app/static/js/report.js"
RUNS_API = "app/api/runs_api.py"
S2_API = "app/api/stage2_api.py"
MISC_API = "app/api/misc_api.py"
CFG_API = "app/api/config_api.py"
SVC = "app/services.py"
JOBS = "app/jobs.py"
RUNNER = "app/stage1_runner.py"
PCACHE = "app/pattern_cache.py"
S2SVC = "app/stage2_service.py"
SERVER = "app/server.py"
ENGINE = "stage1/pcie_isolate/engine.py"
CLI = "stage1/pcie_isolate/cli.py"
INCID = "stage1/pcie_isolate/incidents.py"
ISO = "stage1/pcie_isolate/isolation.py"
LLM = "stage1/pcie_isolate/llm.py"
HOST = "stage1/pcie_isolate/host_evidence.py"
ATLAS = "stage1/pcie_isolate/atlas.py"
ADAPTER = "stage2/stage1_adapter.py"
S2V3 = "stage2/stage2_v3.py"


def js(path, marker, lines=None):
    """js:<path>::<marker text>[::<number of lines>]"""
    return "js:%s::%s%s" % (path, marker, ("::%d" % lines) if lines else "")


def py(path, name, start=None, stop=None):
    """py:<path>::<Qualified.name>[::<start text>::<stop text>]"""
    return "py:%s::%s%s" % (path, name, ("::%s::%s" % (start, stop)) if start else "")


def st(layer, text, ref=None):
    """one arrow of a chain"""
    d = {"layer": layer, "text": text}
    if ref:
        d["ref"] = ref
    return d


def el(id, screen, group, label, kind, selector, what, why, when, chain, code=None, example=""):
    return {"id": id, "screen": screen, "group": group, "label": label, "kind": kind, "selector": selector,
            "what": what, "why": why, "when": when, "chain": chain, "code": list(code or []), "example": example}


# ---------------------------------------------------------------- chain pieces used by many entries
def page_static(marker, where_text, path=IDX):
    """static text written in the page file itself"""
    page = "/" if path == IDX else "/defect"
    srv = py(SERVER, "create_app", '@app.get("/")', '@app.get("/db")') if path == IDX else \
        py(SERVER, "create_app", '@app.get("/defect")', "@app.after_request")
    return [st("files", "%s: the text is written in the page file itself (%s); nothing is computed." % (path, where_text),
               js(path, marker, 3)),
            st("server", "The Flask route for %s sends the page file unchanged." % page, srv),
            st("http", "GET %s" % page),
            st("screen", "The text is shown as written, the same for every run.")]


def runs_list_tail(js_step, screen_text):
    """value of one run in the run list: job row -> run_view -> GET /api/runs -> browser"""
    return [st("database", "db/app.sqlite table job: one row per stage-1 run, with params (the inputs you gave), status, "
                           "progress, timing spans, created/started/ended times."),
            st("service", "Reads every stage-1 job (newest first, at most 200) and turns each into one plain record.",
               py(JOBS, "JobManager.list")),
            st("service", "Builds the run record: trace, label, your name, device, phase, elapsed seconds, defect and "
                          "AI reviewer counts, stage-2 counts.", py(SVC, "Services.run_view")),
            st("server", "Answers the list of runs.", py(RUNS_API, "list_runs")),
            st("http", "GET /api/runs"),
            js_step,
            st("screen", screen_text)]


def run_detail_tail(js_step, screen_text):
    """value shown in step 2: job row -> get_run -> GET /api/runs/<run> -> loadRun"""
    return [st("database", "db/app.sqlite table job: progress {step, detail, pct, stats} and the timing spans of the "
                           "stage-1 job, written while the job runs."),
            st("server", "Answers the job, its run record, the stage-1 summary and the warnings about missing inputs.",
               py(RUNS_API, "get_run")),
            st("http", "GET /api/runs/<run>   (asked again every 1.5 seconds while the analysis runs)"),
            js_step,
            st("screen", screen_text)]


def incidents_tail(js_step, screen_text):
    """value of one defect in the list: run files -> incidents_of -> GET /api/runs/<run>/incidents"""
    return [st("files", "runs/<run>/incidents.json (the analyser's defects), isolation.json (final status per defect), "
                        "llm_reviews.jsonl (the AI reviewer's second opinions) and stage2/INC-*.json (stage-2 state)."),
            st("service", "Joins the three files per defect into one plain row: number, error type, verdict word, "
                          "layer, side, packets, first rule, AI reviewer verdict, stage-2 state.",
               py(SVC, "Services.incidents_of")),
            st("server", "Answers the rows of the selected run.", py(S2_API, "list_incidents")),
            st("http", "GET /api/runs/<run>/incidents"),
            js_step,
            st("screen", screen_text)]


def record_tail(js_step, screen_text, server_text="Collects everything about one defect in reading order (proof, where, "
                                                  "why, fix, rows, AI review, stage-2 state, earlier decisions)."):
    """value shown from the defect record: run files -> defect_record -> GET /api/runs/<run>/defect/<inc>"""
    return [st("server", server_text, py(S2_API, "defect_record")),
            st("http", "GET /api/runs/<run>/defect/<defect>"),
            js_step,
            st("screen", screen_text)]


DP_MAIN = js(DEFJ, "(async function main()")

ELEMENTS = []

# =====================================================================================================================
# SB - sidebar and top bar (on every page of the workflow)
# =====================================================================================================================
ELEMENTS += [
    el("sb-logo", "SB", "Sidebar", "Field-to-Test Loop  ·  PCIe trace → defects found → reproduced → tested", "display",
       "aside .logo",
       "The name of the application and, under it, the whole loop in four words: a PCIe (PCI Express, the bus between "
       "the computer and the drive) trace goes in, defects are found, each defect is reproduced in the lab, and it ends "
       "as a test.",
       "The project statement asks for one closed loop from field failure to long-term validation; the line tells a "
       "newcomer the order of the work before any button is pressed.",
       "",
       page_static('<div class="logo">Field-to-Test Loop', "the sidebar head")),

    el("sb-step1", "SB", "Sidebar · the five steps", "1  Choose the trace", "button", 'aside .nav[data-step="choose"]',
       "Opens step 1: the form where you give the analyzer CSV (comma-separated values) export and the list of earlier "
       "runs. The button is highlighted while step 1 is shown.",
       "Step 1 is the only way into the loop, so it is never locked: a new trace can be started at any time, even while "
       "another run is selected.",
       "Always enabled.",
       [st("you", "You click the button."),
        st("browser", "Every sidebar button calls show() with its page and step.",
           js(MAIN, 'document.querySelectorAll("aside .nav").forEach(b => b.onclick', 1)),
        st("browser", "show() checks the lock (unlocked() always allows this step), marks the button active, switches "
                      "the page, sets the title and the address to #run/choose, then calls the step's enter().",
           js(MAIN, "export function show(page, arg, step)", 9)),
        st("browser", "Step 1 shows the form, hides the progress card and redraws the Earlier runs table.",
           js(RUN, "export async function enter(arg, step)", 6)),
        st("http", "GET /api/runs"),
        st("server", "List of every run with its phase.", py(RUNS_API, "list_runs")),
        st("screen", "The step 1 form and the Earlier runs table.")]),

    el("sb-step1-status", "SB", "Sidebar · the five steps", "nothing selected yet · enter a CSV path, or open an earlier "
       "run from the history", "display", "#nav-choose",
       "The small line under step 1. With no run selected it says what to do; once a run is selected it shows the file "
       "name of that run's trace.",
       "Several people share one installation; the line shows at a glance which trace every step below is about.",
       "Changes as soon as a run is selected or cleared.",
       runs_list_tail(st("browser", "applyLocks() writes the line: the advice text when nothing is selected, else the "
                                    "last part of the run's CSV path.", js(MAIN, 'set("nav-choose", esc(', 1)),
                      "The trace file name under step 1."),
       example='"sample_T-42_L-21_C-16_seed11.csv" for run run-20261026-145008-0220.'),

    el("sb-step2", "SB", "Sidebar · the five steps", "2  Analyse the trace (stage 1)", "button",
       'aside .nav[data-step="analyse"]',
       "Opens step 2 for the selected run: the progress ring, the step list with live counts and, once stage 1 is "
       "complete, the defects found. Grey with a lock symbol while no run is selected.",
       "Stage 1 runs in the background; this button lets you come back to it at any time and watch or read the result "
       "without starting anything again.",
       "Enabled as soon as a run is selected (a running, failed or finished one).",
       [st("you", "You click the button."),
        st("browser", "unlocked(): step 2 needs a selected run; applyLocks() disables the button otherwise.",
           js(MAIN, "export function unlocked(page, step)", 8)),
        st("browser", "show() switches to the run page with step \"analyse\"; run.enter() hides the form and loads the "
                      "run.", js(RUN, "export async function enter(arg, step)", 6)),
        st("browser", "loadRun() asks for the run, its activity lines and, when finished, its defects; it asks again "
                      "every 1.5 seconds while the job is queued or running.", js(RUN, "async function loadRun()", 4)),
        st("http", "GET /api/runs/<run>  ·  GET /api/jobs/<job>/events?after=<n>  ·  GET /api/runs/<run>/incidents"),
        st("server", "Job, run record, summary and input warnings of the run.", py(RUNS_API, "get_run")),
        st("screen", "Step 2: ring, step list, activity log, results.")]),

    el("sb-step2-status", "SB", "Sidebar · the five steps", "complete · 14.7 s", "display", "#nav-analyse",
       "The line under step 2. While stage 1 runs: the current step in short words and the percentage, with a thin bar "
       "(for example \"reading packets · 42%\"). Afterwards \"complete · <seconds> s\", or \"failed\". Without a run: "
       "\"locked · complete step 1 first\".",
       "Stage 1 of a large trace takes minutes (the 4 GB trace in this installation took 1,326.6 s); the line keeps the "
       "progress visible while you look at other pages.",
       "Updated whenever the run list is re-read (every 1.5 seconds while step 2 watches a running analysis).",
       [st("engine", "The analyser's sub-commands print their progress; run_stage1 turns each line into a step name and "
                     "a percentage.", py(RUNNER, "run_stage1", "def on_line(name)", "def step(name")),
        st("service", "Stores {step, detail, pct, stats} on the job row.", py(JOBS, "JobManager.progress")),
        st("database", "db/app.sqlite table job: progress and the started/ended times (elapsed seconds = ended − "
                       "started).")] +
       runs_list_tail(st("browser", "applyLocks() writes \"<short step> · <pct>%\" plus a bar while running, \"failed\", "
                                    "or \"complete · <elapsed_s> s\".", js(MAIN, 'set("nav-analyse", r.phase', 1)),
                      "The status line under step 2.")[1:],
       example='"complete · 14.7 s" for run run-20261026-145008-0220 (job elapsed 14.7 s).'),

    el("sb-step3", "SB", "Sidebar · the five steps", "3  Defects found", "button", 'aside .nav[data-page="incidents"]',
       "Opens step 3: every defect of the selected run as one table row, with a filter.",
       "A table is the fastest way to scan many defects (the 4 GB trace gave 189); step 2 shows them as expandable "
       "rows instead.",
       "Enabled when a run is selected and its stage 1 is neither running nor failed.",
       [st("you", "You click the button."),
        st("browser", "unlocked(): step 3 needs a finished stage 1.", js(MAIN, 'if (page === "incidents" || page === "report")', 1)),
        st("browser", "show(\"incidents\") calls the step's enter(), which asks for the stage-2 queue (has stage 2 "
                      "started?) and the defect rows.", js(INCJ, "export async function enter()", 4)),
        st("http", "GET /api/runs/<run>/stage2/queue  ·  GET /api/runs/<run>/incidents"),
        st("server", "Defect rows of the run.", py(S2_API, "list_incidents")),
        st("screen", "Step 3: chips, filter and the defects table.")]),

    el("sb-step3-status", "SB", "Sidebar · the five steps", "3 defects · AI reviewer agrees on 2", "display",
       "#nav-defects",
       "The line under step 3: how many defects stage 1 found and on how many the AI reviewer agrees (\"AI reviewer "
       "not run\" when no second opinion exists). While stage 1 runs: \"locked · complete step 2 first · waiting for "
       "stage 1\"; after a failure: \"-\".",
       "Gives the size of the work waiting in steps 3 and 4 without opening them.",
       "",
       [st("engine", "At the end of stage 1 run_stage1 counts the defects and the AI reviewer's CONFIRMED answers and "
                     "writes runs/<run>/stage1_summary.json.", py(RUNNER, "run_stage1", "reviewed = called = confirmed = 0", "sp_ = os.path.join")),
        st("files", "runs/<run>/stage1_summary.json: incidents, llm_confirmed, llm_called, llm_cached.")] +
       runs_list_tail(st("browser", "applyLocks() writes \"<incidents> defects · AI reviewer agrees on <llm.confirmed>\".",
                         js(MAIN, 'set("nav-defects", r.phase', 1)), "The status line under step 3.")[2:],
       example='"3 defects · AI reviewer agrees on 2" for run run-20261026-145008-0220.'),

    el("sb-step4", "SB", "Sidebar · the five steps", "4  Reproduce and decide (stage 2)", "button",
       'aside .nav[data-page="review"]',
       "Opens step 4 (stage 2): first the \"Start stage 2\" gate, after that the queue of defects to review. "
       "Described in detail in the step-4 parts of this map.",
       "Stage 2 must not start on half-finished evidence; the lock forces stage 1 to complete first.",
       "Enabled when stage 1 is complete (phase \"stage 1 complete, stage 2 not started\", \"stage 2 in progress\" or "
       "\"stage 2 complete\"). A link or the hash #review on a locked run shows the message \"Stage 1 must complete "
       "before stage 2 can be started.\" and step 1 instead.",
       [st("you", "You click the button."),
        st("browser", "unlocked(): stage 2 needs phase stage1_done, stage2 or stage2_done.",
           js(MAIN, 'if (page === "review") return ph === "stage1_done"', 1)),
        st("browser", "show(\"review\") calls the review page's enter(), which asks for the queue and shows the gate "
                      "or the work view.", js(REVJ, "export async function enter(incId)", 5)),
        st("http", "GET /api/runs/<run>/stage2/queue"),
        st("server", "Whether stage 2 was started (the runs/<run>/stage2/STARTED marker) and every defect's state.",
           py(S2_API, "queue")),
        st("screen", "Step 4: the gate or the review queue.")]),

    el("sb-step4-status", "SB", "Sidebar · the five steps", "3 of 3 decided · 2 regression tests", "display",
       "#nav-review",
       "The line under step 4: how many defects have a decision, out of how many, and how many regression tests were "
       "admitted, with a bar. Before stage 2: \"stage 1 complete · stage 2 not started\"; while stage 1 is not finished: "
       "\"locked · complete step 2 first\".",
       "Shows how far the review has gone, so the next person knows whether work is left.",
       "",
       [st("files", "runs/<run>/stage2/INC-*.json: the stage-2 state of each defect (looked up, last decision, "
                    "admitted).", py(S2SVC, "Stage2Service.state")),
        st("service", "Counts, over the defects that have a catalogue match: total, looked up, decided, admitted.",
           py(SVC, "Services.queue"))] +
       runs_list_tail(st("browser", "applyLocks() writes \"<decided> of <total> decided · <admitted> regression tests\" "
                                    "and the bar.", js(MAIN, 'set("nav-review", !s1done', 1)),
                      "The status line under step 4.")[2:],
       example='"3 of 3 decided · 2 regression tests" for run run-20261026-145008-0220.'),

    el("sb-step5", "SB", "Sidebar · the five steps", "5  Report and tests", "button", 'aside .nav[data-page="report"]',
       "Opens step 5: the report of the run and the list of generated regression tests (described in the step-5 part "
       "of this map).",
       "The report is the record a manager reads afterwards: time per stage, results per defect, tests filed.",
       "Enabled when stage 1 is complete (the report can be built before stage 2).",
       [st("you", "You click the button."),
        st("browser", "unlocked(): same rule as step 3.", js(MAIN, 'if (page === "incidents" || page === "report")', 1)),
        st("browser", "The report page's enter() loads the test list and builds the report of the selected run.",
           js(REPJ, "export async function enter()", 1)),
        st("http", "GET /api/suite  ·  GET /api/runs/<run>/report  ·  GET /api/kpi"),
        st("server", "Builds the report and writes report.md into the run folder.", py(MISC_API, "report")),
        st("screen", "Step 5: report and generated tests.")]),

    el("sb-step5-status", "SB", "Sidebar · the five steps", "available", "display", "#nav-report",
       "The line under step 5: \"available\" once stage 1 is complete, \"available · complete\" once stage 2 is "
       "complete, \"locked · complete step 4 first\" (no run) or \"locked · complete step 2 first\" (stage 1 not "
       "finished).",
       "Tells you the report can already be read before every defect is decided.",
       "",
       [st("service", "phase(): from the job status, the stage-2 STARTED marker and the decided count.",
           py(SVC, "Services.phase"))] +
       runs_list_tail(st("browser", "applyLocks() writes the line from the phase only.", js(MAIN, 'set("nav-report", !s1done', 1)),
                      "The status line under step 5.")[2:]),

    el("sb-counter", "SB", "Sidebar", "0 of 5 steps completed · 5 remaining", "display", "#nav-summary",
       "The step counter under the five steps. Step 1 counts as soon as a run is selected; steps 2 and 3 when its stage 1 "
       "has finished; steps 4 and 5 when every defect with a catalogue match has a decision (phase \"stage 2 "
       "complete\"). \" · stage 1 failed\" is added after a failure.",
       "One number tells a manager how far the selected run is through the loop.",
       "Recomputed whenever the run list is re-read.",
       [st("service", "phase() decides stage1_running / stage1_failed / stage1_done / stage2 / stage2_done.",
           py(SVC, "Services.phase"))] +
       runs_list_tail(st("browser", "applyLocks() counts [step 1 = true, step 2 = stage 1 done, step 3 = stage 1 done, "
                                    "step 4 = stage 2 complete, step 5 = stage 2 complete].",
                         js(MAIN, "const done = [true, s1done", 2)),
                      "\"<n> of 5 steps completed · <5−n> remaining\".")[2:],
       example='"5 of 5 steps completed · 0 remaining" for run run-20261026-145008-0220 (stage 2 complete).'),

    el("sb-settings", "SB", "Sidebar", "⚙  Settings", "button", 'aside .nav[data-page="settings"]',
       "Opens the Settings page (AI reviewer connection, stage-2 limits; see the Settings part of this map). The fields "
       "were already filled from the configuration when the application loaded.",
       "The AI reviewer endpoint and the stage-2 limits differ between the lab and production; they are changed here "
       "without editing files.",
       "Always enabled.",
       [st("you", "You click the button."),
        st("browser", "show(\"settings\"); the page's enter() does nothing - the fields were set at start-up by "
                      "init().", js(SETJ, "export function init(state)", 6)),
        st("http", "GET /api/config   (once, when the application loads)"),
        st("server", "Answers config/app_config.json without the private keys and the name of the AI reviewer in use.",
           py(CFG_API, "get_config")),
        st("files", "config/app_config.json"),
        st("screen", "The Settings page.")]),

    el("sb-help", "SB", "Sidebar", "?  What the words mean", "button", 'aside .nav[data-page="help"]',
       "Opens the glossary: every word used on the screens, in the order you meet it, and the ten catalogue chapters "
       "(the letter of an error type such as T-42).",
       "Operators know the packets, not the application's vocabulary; the plain-language rule of this project says every "
       "term on a screen must be explained in one place.",
       "Always enabled.",
       [st("you", "You click the button."),
        st("browser", "show(\"help\"): the help page has no script of its own; its text is part of index.html.",
           js(MAIN, "const PAGES = { run, incidents, review, report, settings, help: {} };", 1)),
        st("files", "app/static/index.html section page-help: the two glossary tables.",
           js(IDX, '<section id="page-help" class="page">', 3)),
        st("screen", "The glossary page.")]),

    el("sb-kb", "SB", "Sidebar", "Knowledge base (opens in a new tab) ↗", "link", "aside a.ext",
       "Opens the knowledge base page /db in a new browser tab: decisions, procedures, tests and the verdict cache "
       "(see the Knowledge base part of this map).",
       "The knowledge base is shared by all runs and is kept when a run is deleted; it gets its own page so it can stay "
       "open next to the workflow.",
       "Always shown.",
       [st("you", "You click the link."),
        st("browser", "A plain link with target=_blank: the browser opens a new tab.", js(IDX, '<a class="ext" href="/db"', 1)),
        st("http", "GET /db"),
        st("server", "Sends app/static/db.html.", py(SERVER, "create_app", '@app.get("/db")', '@app.get("/defect")')),
        st("screen", "The knowledge base page in a new tab.")]),

    el("sb-ai", "SB", "Sidebar foot", "AI reviewer  Anthropic claude-haiku-5-5", "display", "#llm-badge",
       "Which AI (artificial intelligence) model answers as \"AI reviewer\": \"Anthropic <model>\", \"Ollama <model>\", "
       "\"OpenAI-compatible <model>\" or \"stand-in (no model)\" when no model can be reached.",
       "Every second opinion and every stage-2 proposal depends on this model; the operator must see which one is in use "
       "before trusting an answer.",
       "Set once when the application loads. After Save on the Settings page the raw name (for example "
       "anthropic:claude-haiku-5-5:low) is written here until the page is reloaded. The name is the stage-2 reviewer; "
       "stage 1 reaches a model only with the cli, sdk or auto backend (openai-compat runs its review without one).",
       [st("files", "config/app_config.json section llm: backend, model, effort."),
        st("service", "make_llm() builds the AI reviewer object for stage 2 from that section; its name is for example "
                      "anthropic:<model>:<effort>, or stand-in when the backend is not reachable.",
           py(S2SVC, "make_llm")),
        st("server", "llm_active = the name of that object.", py(CFG_API, "get_config")),
        st("http", "GET /api/config"),
        st("browser", "llmWord() rewrites the name in words.", js(MAIN, "const llmWord = (n) =>", 1)),
        st("screen", "\"AI reviewer Anthropic claude-haiku-5-5\".")],
       example='llm_active "anthropic:claude-haiku-5-5:low" is shown as "Anthropic claude-haiku-5-5" in this '
               'installation (backend "cli").'),

    el("sb-bench", "SB", "Sidebar foot", "lab device  simulated device", "display", "#bench-badge",
       "Where stage 2 runs its lab runs: \"simulated device\" (the built-in simulated drive) or \"real device\" (a real "
       "drive connected through app/bench_hook.py).",
       "A reproduction on a simulated drive is not the same proof as one on the real drive; the operator must know "
       "which one produced a result.",
       "Set once when the application loads; a change in Settings takes effect after a restart.",
       [st("files", "config/app_config.json: stage2.bench = \"synthetic\" or \"hook\"."),
        st("server", "Answers the configuration.", py(CFG_API, "get_config")),
        st("http", "GET /api/config"),
        st("browser", "benchWord(): synthetic → \"simulated device\", hook → \"real device\".",
           js(MAIN, "const benchWord = (b) =>", 1)),
        st("screen", "\"lab device simulated device\".")],
       example='stage2.bench is "synthetic" in this installation, shown as "simulated device".'),

    el("sb-title", "SB", "Top bar", "Choose the trace", "display", "#page-title",
       "The large title at the top: the name of the step or page you are on (\"Choose the trace\", \"Analyse the trace "
       "(stage 1)\", \"Defects found\", \"Reproduce and decide (stage 2)\", \"Report and tests\", \"Settings\", \"What "
       "the words mean\").",
       "Confirms where you are, in the same words as the sidebar.",
       "Changes with every page switch.",
       [st("files", "The fixed list of page titles in main.js.", js(MAIN, "const TITLES = {", 1)),
        st("browser", "show() writes the title of the page it opens.", js(MAIN, '$("page-title").textContent', 1)),
        st("screen", "The title in the top bar.")]),

    el("sb-phase", "SB", "Top bar", "no run selected", "display", "#phase-badge",
       "The coloured pill left of the run selector: the phase of the selected run - \"stage 1 running\" (yellow), "
       "\"stage 1 failed\" (red), \"stage 1 complete, stage 2 not started\" (blue), \"stage 2 in progress\" or \"stage 2 "
       "complete\" (green); \"no run selected\" without a run.",
       "The phase decides which steps are unlocked; showing it in words explains why a step is locked.",
       "",
       [st("database", "db/app.sqlite table job: status of the stage-1 job (queued, running, done, failed)."),
        st("files", "runs/<run>/stage2/STARTED (written by Start stage 2) and runs/<run>/stage2/INC-*.json."),
        st("service", "phase(): queued/running → stage1_running; not done → stage1_failed; no STARTED marker → "
                      "stage1_done; every defect decided → stage2_done; else stage2.", py(SVC, "Services.phase")),
        st("service", "The phase is part of the run record.", py(SVC, "Services.run_view")),
        st("server", "List of runs.", py(RUNS_API, "list_runs")),
        st("http", "GET /api/runs"),
        st("browser", "applyLocks() writes PHASE_TEXT[phase] and picks the colour.", js(MAIN, '$("phase-badge").textContent', 2)),
        st("screen", "The pill in the top bar.")],
       example='"stage 2 complete" (green) for run run-20261026-145008-0220.'),

    el("sb-run-select", "SB", "Top bar", "selected run  - no run selected -", "select", "#run-select",
       "The drop-down that chooses which run every step shows. Each option reads \"<run id> - <run label> · <phase>\". "
       "Choosing one opens its step 2; choosing \"- no run selected -\" goes back to step 1.",
       "Nothing is selected when the page opens, so nobody continues someone else's run by accident; a link that names "
       "a run (/?run=...) selects it on purpose (used by the defect page and the knowledge base page).",
       "Options are refreshed whenever the run list is re-read; a deleted run disappears and is unselected.",
       [st("you", "You pick a run in the list (or open a link /?run=<run>)."),
        st("browser", "The options come from the run list.", js(MAIN, "export async function refreshRuns()", 9)),
        st("http", "GET /api/runs"),
        st("browser", "On change: remember the run, recompute the locks, open step 2 (or step 1 when cleared).",
           js(MAIN, '$("run-select").onchange', 1)),
        st("browser", "At start-up a ?run= in the address selects that run before the page is routed.",
           js(MAIN, "const wanted = new URLSearchParams", 2)),
        st("http", "GET /api/runs/<run>   (step 2 loads the chosen run)"),
        st("server", "Answers the chosen run.", py(RUNS_API, "get_run")),
        st("screen", "Step 2 of the chosen run; phase pill and sidebar lines change.")],
       example='"run-20261026-145008-0220 - exercise A · stage 2 complete".'),
]

# =====================================================================================================================
# S1 - Step 1 · Choose the trace
# =====================================================================================================================
POST_RUNS = st("http", "POST /api/runs  {csv_path, operator, device, payload, dmesg, events, nsze, firmware, label, force}")
START_JS = st("browser", "The Analyse button reads every field and sends them in one request.", js(RUN, '$("btn-start").onclick', 6))
START_PY = st("server", "start_run checks each path, builds the run key, reuses a finished identical run or starts the "
                        "stage-1 job.", py(RUNS_API, "start_run"))

ELEMENTS += [
    el("s1-intro", "S1", "What you see", "1 · Choose the trace", "display", "#choose-block > .card:first-child > h2",
       "The heading of step 1 and the paragraph under it: give the application one analyzer capture; only the file path "
       "is sent, the file stays where it is; stage 1 finds every defect it can prove, stage 2 reproduces each on the "
       "device and turns it into a regression test.",
       "A newcomer must know before typing anything that the trace is not uploaded (captures are gigabytes) and what the "
       "two stages will do with it.",
       "Shown on step 1.",
       page_static("<h2>1 · Choose the trace</h2>", "the step 1 card")),

    el("s1-guide-table", "S1", "What you see", "What to give · Needed? · Why", "table", "#choose-block table.guide-table",
       "A seven-row table that explains every input before the fields: Analyzer CSV (required), Payload sidecar (only "
       "for exports that show sizes such as \"256 B\" instead of bytes), Host evidence dmesg -x and host_events.jsonl "
       "(optional, recommended), Namespace size (optional), Your name (required), Device under test (optional), "
       "Firmware label and run label (optional), each with the reason.",
       "The inputs decide how many defects can be proven (without bytes the NVMe command rules cannot run; without host "
       "evidence the defects that leave no trace in the packets stay \"Needs evidence\"); the operator must know that "
       "before starting.",
       "Shown on step 1.",
       page_static('<table class="guide-table"><thead><tr><th style="width:26%">What to give</th>', "the guide table")),

    el("s1-csv", "S1", "Fields", "Analyzer CSV path  required", "field", "#csv_path",
       "The full path, on the server's disk, of the 113-column export from the LeCroy or VIAVI analyzer, for example "
       "/home/you/captures/trace.csv. The grey line under it says the path must lie under one of the folders the "
       "administrator allowed (config/app_config.json).",
       "The packets are the evidence for every rule, defect and proof. Only the path is sent because captures are too "
       "big to upload (this installation holds a 4 GB one); the folder check stops the screen from being used to read "
       "arbitrary files of the server.",
       "Required: the browser refuses to start without it (\"the CSV path is required\").",
       [st("you", "You type the path and press Analyse the trace (stage 1)."),
        START_JS, POST_RUNS, START_PY,
        st("service", "safe_path(): the file must exist and lie under paths.allowed_csv_roots (or the application "
                      "folder); else \"not a file: ...\" or \"path outside the allowed roots ...\" comes back.",
           py(SVC, "Services.safe_path")),
        st("service", "run_key(): a fingerprint of the path, its size and modification time, the extra inputs and the "
                      "AI reviewer settings.", py(SVC, "Services.run_key")),
        st("engine", "The analyse step reads the CSV once, row by row (never loaded whole).", py(ENGINE, "Engine.run")),
        st("files", "runs/<run>/run.json, findings.pkl, time_index.npz"),
        st("screen", "Step 2 opens and shows the progress of this trace.")],
       code=[py(SVC, "Services.safe_path")],
       example='Allowed folders in this installation: "~", "/tmp", "/mnt", "/media" plus the application folder. '
               'Example path: /home/raghavendra/Desktop/Project_Implmentation/13_production_app/samples/'
               'sample_T-42_L-21_C-16_seed11.csv (23.1 MB, about 47,413 rows).'),

    el("s1-payload", "S1", "Fields", "Payload sidecar (the bytes inside the packets; only for size-only exports)",
       "field", "#payload",
       "Optional path of a separate file that holds the bytes inside the packets, for analyzer exports whose DATA column "
       "shows only sizes such as \"256 B\".",
       "The NVMe (NVM Express, the drive's command protocol) rules read commands, completions, PRP lists (the memory "
       "page lists of a command) and registers from those bytes; without them those rules cannot run and step 2 warns "
       "that the trace was analysed with limited inputs.",
       "Leave empty when the export already carries the bytes (\"inline hex\").",
       [st("you", "You type the path, or Find companion files fills it."),
        START_JS, POST_RUNS,
        st("server", "Checks this path like the CSV path and adds it to the run key.", py(RUNS_API, "start_run")),
        st("service", "run_stage1 passes --payload to the analyse and the isolate steps.",
           py(RUNNER, "run_stage1", 'an = ["analyze", "--csv", csv_path, "--out", run_dir]', 'step("analyze", an, 10)')),
        st("engine", "The analyser reads the bytes of each packet from the sidecar, in packet order.",
           py(ENGINE, "PayloadSidecar")),
        st("files", "runs/<run>/run.json capture.payload = \"sidecar\", \"inline hex\" or \"none (DATA sizes only)\"."),
        st("screen", "With \"none\", step 2 shows the warning \"The DATA column holds only sizes ...\".")],
       example="Not needed for the sample traces of this installation: their run.json says payload \"inline hex\"."),

    el("s1-dmesg", "S1", "Fields", "Linux kernel log (dmesg -x)", "field", "#dmesg",
       "Optional path of the host computer's kernel log, saved with dmesg -x (each line with its level and time). It "
       "sits under the sub-heading \"Host evidence, for defects that leave no trace in the packets (optional, "
       "recommended)\".",
       "Some failures are visible only on the host (driver timeouts, garbage configuration reads, management actions); "
       "the kernel log lets stage 1 prove them instead of reporting them as \"Needs evidence\".",
       "Optional. When given (or host_events.jsonl), the step \"Line up the host evidence with the packets\" runs. A "
       "log without any \"resetting controller\" line, or a trace without a controller reset, cannot be aligned: the "
       "step stops and stage 1 fails.",
       [st("you", "You type the path, or Find companion files fills it."),
        START_JS, POST_RUNS,
        st("server", "Checks the path and adds it to the run key.", py(RUNS_API, "start_run")),
        st("service", "run_stage1 adds the fuse step with --dmesg.",
           py(RUNNER, "run_stage1", 'if params.get("dmesg") or params.get("events")', 'iso = ["isolate"')),
        st("engine", "fuse(): reads the log lines, aligns the host clock to the trace clock (kernel \"resetting "
                     "controller\" lines against the controller resets seen in the packets) and places every error line "
                     "on the packet axis.", py(HOST, "fuse")),
        st("files", "runs/<run>/host_findings.pkl, host_alignment.json"),
        st("engine", "isolate reads wire and host findings together.", py(HOST, "load_all")),
        st("screen", "Step 2 ticks \"Line up the host evidence\"; the defect page lists the host line under Host "
                     "evidence.")],
       example="The runs of this installation were made without host evidence (step 2 shows \"no host evidence given\")."),

    el("s1-events", "S1", "Fields", "Host tool records (host_events.jsonl)", "field", "#events",
       "Optional path of a file with one JSON (JavaScript Object Notation) record per line from host tools: "
       "{\"time\", \"source\" (nvme-log, smart-log, fio-verify, blktrace, lspci, bmc, ...), \"level\", \"text\"}.",
       "Tool records (drive error logs, data-verify results, board management logs) carry causes the analyzer cannot "
       "see; each record names the side that caused the defect.",
       "Optional. Same fuse step as the kernel log. Given without a kernel log whose \"resetting controller\" lines "
       "match controller resets in the trace, the fuse step stops with \"cannot align clocks: no anchor pairs; pass "
       "--clock-offset\" and stage 1 fails; the screen has no field for a clock offset.",
       [st("you", "You type the path, or Find companion files fills it."),
        START_JS, POST_RUNS,
        st("server", "Checks the path and adds it to the run key.", py(RUNS_API, "start_run")),
        st("service", "run_stage1 adds the fuse step with --events.",
           py(RUNNER, "run_stage1", 'if params.get("dmesg") or params.get("events")', 'iso = ["isolate"')),
        st("engine", "parse_events() reads the records; fuse() places them on the packet axis with the clock offset.",
           py(HOST, "parse_events")),
        st("engine", "The clock offset is estimated only from kernel-log \"resetting controller\" lines; with no such "
                     "pair fuse stops with \"cannot align clocks: no anchor pairs\".", py(HOST, "estimate_offset")),
        st("files", "runs/<run>/host_findings.pkl, host_alignment.json"),
        st("screen", "Host evidence on the defect page, or stage 1 failed when the clocks cannot be aligned.")],
       example="Checked on a scratch copy of run run-20261026-145008-0220: fuse with only a host_events.jsonl ends with "
               "\"cannot align clocks: no anchor pairs; pass --clock-offset\" (exit code 1)."),

    el("s1-operator", "S1", "Fields", "Your name  required (recorded with the run and every decision)", "field",
       "#operator",
       "Your name. The browser remembers it for the next visit.",
       "Anyone must later be able to see who analysed a trace and who judged a procedure; the name is stamped on the run "
       "and, as the default decider, on every stage-2 event in the knowledge base.",
       "Required by the browser (\"Please type your name first: it is recorded with the run and with every "
       "decision.\"). Not part of the run key: when the same file was analysed before, the earlier run (with its "
       "earlier name) is opened instead.",
       [st("you", "You type your name."),
        st("browser", "Filled from the browser's local storage when the page opens; saved there when you press "
                      "Analyse.", js(RUN, 'localStorage.getItem("operator")', 1)),
        START_JS, POST_RUNS,
        st("server", "Stored, trimmed, in the job params.", py(RUNS_API, "start_run")),
        st("database", "db/app.sqlite table job: params.operator"),
        st("service", "run_meta() hands it to stage 2, which writes it into every knowledge-base event.",
           py(SVC, "Services.run_meta")),
        st("screen", "Earlier runs, column \"Started by · when\".")],
       example='The runs listed in this installation have no name recorded and show "name not recorded".'),

    el("s1-device", "S1", "Fields", "Device under test (model or name of the drive; leave empty to read it from the "
       "trace)", "field", "#device",
       "Optional name of the drive the trace came from, for example \"Samsung SSD 990 PRO 2TB, unit 7\".",
       "Procedures and regression tests are filed per device model, because the same error type needs different test "
       "cases on different drives.",
       "Leave empty when the trace holds the drive's Identify Controller answer: the analyser then reads model number, "
       "serial number and firmware revision from the packets. Not part of the run key.",
       [st("you", "You type a name (or leave it empty)."),
        START_JS, POST_RUNS,
        st("server", "Stored in the job params.", py(RUNS_API, "start_run")),
        st("engine", "While reading, the analyser decodes an Identify Controller answer (model, serial, firmware "
                     "revision) into run.json topology.identity.", py(ENGINE, "Engine.on_identify_controller")),
        st("service", "device_of(): the typed name, else the model number from the trace, else the PCI ids from the "
                      "configuration header, else \"unknown device\" - with the source of the name.",
           py(SVC, "Services.device_of")),
        st("server", "Part of every run record.", py(SVC, "Services.run_view")),
        st("screen", "Earlier runs, column Device (name and where it came from); stage-2 cards and test ids.")],
       code=[py(SVC, "Services.device_of")],
       example='All runs of this installation show "unknown device" - "not known: the trace holds no Identify '
               'Controller answer and no name was typed".'),

    el("s1-nsze", "S1", "Fields", "Namespace size (nsze, from Identify Namespace)", "field", "#nsze",
       "Optional size of the drive's namespace in logical blocks (nsze, as reported by Identify Namespace), for example "
       "0x3A386030.",
       "Lets the address-range rules tell an out-of-range read or write (a logical block address beyond the end of the "
       "namespace) from a valid one.",
       "Optional. Pre-filled from config stage1.nsze when set; the analyser also takes the value from an Identify "
       "Namespace answer found in the trace.",
       [st("you", "You type the size (or Find companion files fills it from a trace manifest)."),
        START_JS, POST_RUNS,
        st("server", "nsze = the field, else config stage1.nsze; part of the run key.", py(RUNS_API, "start_run")),
        st("service", "run_stage1 adds --nsze to the analyse step.",
           py(RUNNER, "run_stage1", 'an = ["analyze", "--csv", csv_path, "--out", run_dir]', 'step("analyze", an, 10)')),
        st("engine", "The analyser keeps nsze and fires the range rule when a command's start block plus length "
                     "exceeds it.", py(ENGINE, "Engine.on_sqe")),
        st("server", "When the field was empty get_run adds the warning \"No namespace size (nsze): LBA-range rules "
                     "were off.\"", py(RUNS_API, "get_run")),
        st("screen", "Step 2 warning box (only when it was missing).")],
       example='Run run-20261026-145008-0220 was started with nsze "0x3A386030".'),

    el("s1-firmware", "S1", "Fields", "Firmware label (which firmware the device ran)", "field", "#firmware",
       "Which firmware the drive ran when the trace was captured. Default \"FW-A\".",
       "The knowledge base files procedures under it, and the lab check of stage 2 runs a procedure on this firmware "
       "(known bad) and on \"<label>+fix\" (fixed).",
       "Pre-filled from config stage1.firmware_label at start-up. Not part of the run key.",
       [st("you", "You type the label."),
        st("browser", "At start-up the Settings code copies config stage1.firmware_label into this field.",
           js(SETJ, '$("firmware").value = s1.firmware_label', 1)),
        START_JS, POST_RUNS,
        st("server", "firmware = the field, else config stage1.firmware_label, else FW-A.", py(RUNS_API, "start_run")),
        st("service", "firmware_of() returns it for stage 2.", py(SVC, "Services.firmware_of")),
        st("engine", "Stage 2 loads the defects with this firmware; tests are filed with known-bad = label and fixed = "
                     "label + \"+fix\".", py(ADAPTER, "load_run")),
        st("screen", "Stage-2 cards, lab-check lines and test manifests.")],
       example='"FW-A" for every run of this installation.'),

    el("s1-label", "S1", "Fields", "Run label", "field", "#label",
       "Free text so you recognise the run later, for example \"field return 2026-10 unit 7\".",
       "Run ids are dates and random letters; a label in your own words makes the right run easy to find in the history "
       "and in the run selector.",
       "Optional. Not part of the run key.",
       [st("you", "You type a label."),
        START_JS, POST_RUNS,
        st("server", "Stored in the job params.", py(RUNS_API, "start_run")),
        st("database", "db/app.sqlite table job: params.label"),
        st("service", "Part of the run record.", py(SVC, "Services.run_view")),
        st("screen", "Earlier runs, column Run (under the id), and the selected-run list.")],
       example='"exercise A" and "exercise B (recurrences of T-42, L-21)" are labels used in this installation.'),

    el("s1-find", "S1", "Buttons", "Find companion files next to the CSV", "button", "#btn-inputs",
       "Looks next to the CSV for the payload sidecar, the kernel log, the host tool records and a manifest that holds "
       "the namespace size, and fills the fields it finds. Nothing is started.",
       "Analyzer exports often come with these files in a folder of the same name; finding them saves typing and avoids "
       "an analysis with limited inputs.",
       "Needs the CSV path first (\"enter the CSV path first\").",
       [st("you", "You type the CSV path and click the button."),
        st("browser", "Sends the CSV path; fills payload, dmesg and events with what was found, nsze only when the field "
                      "is empty, and writes the answer's message.", js(RUN, '$("btn-inputs").onclick', 5)),
        st("http", "GET /api/runs/inputs?csv_path=<path>"),
        st("server", "Checks the path, then searches <name>_outside_evidence/, <name>_sidecars/ and the CSV's own folder "
                     "(including its sub-folders) for payload_sidecar.csv, dmesg_x.txt or dmesg.txt, host_events.jsonl, "
                     "and synthetic_trace_manifest.json / payload_sidecar_manifest.json for nsze.",
           py(RUNS_API, "find_inputs")),
        st("files", "Only reads folder listings and the manifest; writes nothing."),
        st("screen", "The fields are filled; the message line says \"found: payload, dmesg, events, nsze\" or \"no "
                     "companion files found next to the CSV (looked for ...)\".")],
       example='For samples/sample_T-42_L-21_C-16_seed11.csv this installation answers "no companion files found next to '
               'the CSV (looked for payload_sidecar.csv, dmesg_x.txt, host_events.jsonl)".'),

    el("s1-analyse", "S1", "Buttons", "Analyse the trace (stage 1)", "button", "#btn-start",
       "Starts stage 1 on the trace, or opens the earlier run when exactly this file was already analysed with the same "
       "inputs and AI reviewer settings. The page then switches to step 2.",
       "The project's first goal is automatic first-level triage of a field trace; nothing already processed is "
       "computed twice (the run key), so a repeated click costs nothing.",
       "Your name and the CSV path must be filled.",
       [st("you", "You fill the fields and click the button."),
        st("browser", "Checks your name and the CSV path, remembers your name, sends the request; on reuse shows the "
                      "message \"this file was already analysed - opened the existing run ...\".",
           js(RUN, '$("btn-start").onclick', 11)),
        POST_RUNS,
        st("server", "safe_path on every path; run_key; find_run looks for a finished job with the same key unless "
                     "\"analyse again\" is ticked; else creates runs/<run>/ and submits the job.",
           py(RUNS_API, "start_run")),
        st("service", "A finished stage-1 job with the same key is reused.", py(SVC, "Services.find_run")),
        st("service", "submit(): a job row (status queued) and one background thread.", py(JOBS, "JobManager.submit")),
        st("service", "run_stage1: analyse → (fuse) → isolate → pattern cache → (review) → report → (capture check).",
           py(RUNNER, "run_stage1")),
        st("database", "db/app.sqlite table job (one row), table job_event (the activity lines)."),
        st("files", "runs/<run>/run.json, incidents.json, incident_rows.jsonl, llm_reviews.jsonl, isolation.json, "
                    "isolation_report.md, stage1_summary.json"),
        st("screen", "Step 2 with the progress ring of the new (or reused) run.")],
       code=[js(RUN, '$("btn-start").onclick', 11), py(RUNS_API, "start_run", 'csv_path, err = s.safe_path(body.get("csv_path"))', 'return jsonify({"run_id": run_id, "job": jid, "reused": False})'),
             py(SVC, "Services.run_key")],
       example='Run run-20261026-145008-0220 got run key 56585731e0f3dc35ba9d; its stage 1 took 14.7 s.'),

    el("s1-force", "S1", "Buttons", "analyse again even if this file was analysed before", "checkbox", "#force",
       "When ticked, the trace is analysed again as a new run even if a finished run with the same inputs exists. The "
       "earlier run is kept.",
       "Needed after the analyser, the inputs outside the key (name, device, firmware label) or the knowledge changed, "
       "or when the warning box of step 2 advises it.",
       "Unticked by default.",
       [st("you", "You tick the box, then click Analyse the trace (stage 1)."),
        st("browser", "Sent as force: true.", js(RUN, '$("btn-start").onclick', 6)),
        POST_RUNS,
        st("server", "With force the reuse check (find_run) is skipped and a new run id is made.",
           py(RUNS_API, "start_run", 'key = s.run_key(csv_path, dict(extra, nsze=nsze), s.cfg["llm"])', 'params = {"run_id": run_id, "run_dir": rd, "csv_path": csv_path')),
        st("screen", "A new run appears at the top of Earlier runs.")]),

    el("s1-msg", "S1", "What you see", "analysis started: run run-…", "display", "#run-msg",
       "The short message line next to the Analyse button: \"enter the CSV path first\", \"Please type your name first "
       "...\", \"the CSV path is required\", \"analysis started: run <id>\", \"this file was already analysed - opened "
       "the existing run <id>\", the answer of Find companion files, or \"error: <the server's reason>\".",
       "Tells you why nothing happened, in the server's own words when a path is refused.",
       "Written by the two buttons of step 1.",
       [st("server", "Error answers carry a reason, for example \"path outside the allowed roots (config "
                     "paths.allowed_csv_roots): ...\".", py(SVC, "Services.safe_path")),
        st("http", "POST /api/runs  or  GET /api/runs/inputs"),
        st("browser", "api() turns an error answer into an exception with the server's reason.",
           js(APIJ, "export async function api(method, url, body)", 6)),
        st("browser", "The buttons write the message.", js(RUN, '$("run-msg").textContent = r.reused', 1)),
        st("screen", "The message line.")]),

    el("s1-whatnext", "S1", "What you see", "What happens next: …", "display",
       "#choose-block > .card:first-child > p.guide:last-of-type",
       "The paragraph under the button: the analyser reads the file with live counts; when it finishes, step 3 lists "
       "every defect with its evidence; stage 2 is offered only then.",
       "Sets the expectation that stage 2 cannot start before stage 1 has finished.",
       "Shown on step 1.",
       page_static("What happens next: the analyser reads the file", "the step 1 card")),

    el("s1-history", "S1", "Earlier runs", "Earlier runs (history)", "table", "#runs-table",
       "The list of every earlier analysis, newest first (up to 200), with the advice \"Open an earlier run to see its "
       "results and continue where it stopped; nothing is selected until you do.\"",
       "Results are kept, so a run can be continued later by anyone; the list also shows who started what and when.",
       "Shown on step 1; redrawn each time step 1 or step 2 opens and every 1.5 seconds while an analysis runs.",
       runs_list_tail(st("browser", "renderRuns() builds one row per run.", js(RUN, "async function renderRuns()", 5)),
                      "One row per run in the Earlier runs table."),
       example="This installation lists 36 runs."),

    el("s1-col-run", "S1", "Earlier runs", "Run", "display", "#runs-table tbody tr:first-child td:nth-child(1)",
       "The run id and, under it in grey, the run label. The id is made when the run starts: \"run-\", the date and time, "
       "and four random letters or digits.",
       "A unique id names the run folder and the address of every request; the label is the human name.",
       "",
       [st("server", "start_run makes the id from the clock and a random part and creates runs/<run>/.",
           py(RUNS_API, "start_run", 'key = s.run_key(csv_path, dict(extra, nsze=nsze), s.cfg["llm"])', 'params = {"run_id": run_id, "run_dir": rd, "csv_path": csv_path')),
        st("database", "db/app.sqlite table job: params.run_id, params.label")] +
       runs_list_tail(st("browser", "First cell: id and label.", js(RUN, 'tr.innerHTML = `<td>${esc(r.run_id)}', 1)),
                      "\"run-20261026-145008-0220\" with \"exercise A\" under it.")[2:]),

    el("s1-col-trace", "S1", "Earlier runs", "Trace file", "display", "#runs-table tbody tr:first-child td:nth-child(2)",
       "The file name of the analysed CSV (the folder part of the path is left out).",
       "The same trace can be analysed several times; the file name shows which runs belong together.",
       "",
       runs_list_tail(st("browser", "Second cell: the last part of r.csv.", js(RUN, 'tr.innerHTML = `<td>${esc(r.run_id)}', 1)),
                      "\"sample_T-42_L-21_C-16_seed11.csv\"."),
       example='"sample_T-42_L-21_C-16_seed11.csv".'),

    el("s1-col-started", "S1", "Earlier runs", "Started by · when", "display",
       "#runs-table tbody tr:first-child td:nth-child(3)",
       "Who started the run (\"name not recorded\" when no name was given) and, under it, the local date and time it "
       "was started.",
       "Traceability: who analysed which trace, and when.",
       "",
       [st("database", "db/app.sqlite table job: params.operator and created (seconds since 1970).")] +
       runs_list_tail(st("browser", "Third cell: operator or \"name not recorded\"; when() writes the date and time in "
                                    "the browser's local time.", js(APIJ, "export const when = (ts)", 1)),
                      "\"name not recorded\" and the date.")[1:],
       example='"name not recorded" / "Oct 26, 2026, 02:50 PM" style (local time of the browser).'),

    el("s1-col-device", "S1", "Earlier runs", "Device", "display", "#runs-table tbody tr:first-child td:nth-child(4)",
       "The device under test and, under it, where that name came from (typed by the operator, read from the trace's "
       "Identify Controller answer or configuration header, or not known).",
       "Procedures and tests are filed per device; the source line tells you whether to trust the name.",
       "",
       [st("files", "runs/<run>/run.json topology.identity (decoded from the trace) and the typed name in the job "
                    "params."),
        st("service", "device_of() picks the name and writes its source.", py(SVC, "Services.device_of"))] +
       runs_list_tail(st("browser", "Fourth cell: r.device and r.device_source.", js(RUN, 'tr.innerHTML = `<td>${esc(r.run_id)}', 1)),
                      "\"unknown device\" with its source line.")[2:],
       example='"unknown device" - "not known: the trace holds no Identify Controller answer and no name was typed".'),

    el("s1-col-stage", "S1", "Earlier runs", "Stage", "display", "#runs-table tbody tr:first-child td:nth-child(5)",
       "The phase of the run as a coloured pill (stage 1 running, stage 1 failed, stage 1 complete - stage 2 not "
       "started, stage 2 in progress, stage 2 complete), with \" · <d> of <t> decided\" once stage 2 has counts.",
       "Shows which runs still need work.",
       "",
       [st("service", "phase() and the stage-2 counts.", py(SVC, "Services.phase"))] +
       runs_list_tail(st("browser", "Fifth cell: pill(PHASE_TEXT[phase] + \" · d of t decided\").",
                         js(RUN, "const s2 = r.stage2 ? ` · ${r.stage2.decided}", 1)),
                      "\"stage 2 complete · 3 of 3 decided\".")[2:],
       example='"stage 2 complete · 3 of 3 decided" for run run-20261026-145008-0220.'),

    el("s1-col-time", "S1", "Earlier runs", "Time taken", "display", "#runs-table tbody tr:first-child td:nth-child(6)",
       "Seconds the stage-1 job took, from its start to its end (still growing while it runs).",
       "The project measures first-level triage time; this is that time for each trace.",
       "",
       [st("service", "elapsed_s = ended − started of the job row.", py(JOBS, "JobManager._row"))] +
       runs_list_tail(st("browser", "Sixth cell: fmt(r.elapsed_s) + \" s\".", js(RUN, "<td class=mono>${fmt(r.elapsed_s)} s</td>", 1)),
                      "\"14.7 s\".")[2:],
       example='"14.7 s" for run run-20261026-145008-0220; "1326.6 s" for the 4 GB trace.'),

    el("s1-col-defects", "S1", "Earlier runs", "Defects", "display", "#runs-table tbody tr:first-child td:nth-child(7)",
       "How many defects stage 1 found in the trace (\"-\" while it runs).",
       "The size of the work for stages 2 and 3 at a glance.",
       "",
       [st("files", "runs/<run>/stage1_summary.json: incidents (written at the end of stage 1).",
           py(RUNNER, "run_stage1", 'summary["incidents"] = len(incs)', "# ---------------- pattern cache"))] +
       runs_list_tail(st("browser", "Seventh cell: r.incidents.", js(RUN, "<td>${r.incidents ?? \"-\"}</td>", 1)),
                      "\"3\".")[2:],
       example='"3" for run run-20261026-145008-0220; "189" for the 4 GB trace.'),

    el("s1-col-ai", "S1", "Earlier runs", "AI reviewer", "display", "#runs-table tbody tr:first-child td:nth-child(8)",
       "The AI reviewer's second opinions of the run: \"agrees on <n> · <m> fresh model calls · <k> verdicts reused from "
       "the cache\" (\"-\" without a summary).",
       "Model calls cost time and money; the line shows how many were made and how many earlier verdicts were reused.",
       "",
       [st("engine", "At the end of stage 1 the reviews are counted: confirmed, called (not from the cache), cached.",
           py(RUNNER, "run_stage1", "reviewed = called = confirmed = 0", "sp_ = os.path.join")),
        st("files", "runs/<run>/stage1_summary.json: llm_confirmed, llm_called, llm_cached.")] +
       runs_list_tail(st("browser", "Eighth cell.", js(RUN, "r.llm && r.llm.called != null", 1)),
                      "\"agrees on 2 · 0 fresh model calls · 3 verdicts reused from the cache\".")[2:],
       example='"agrees on 2 · 0 fresh model calls · 3 verdicts reused from the cache" for run run-20261026-145008-0220.'),

    el("s1-row", "S1", "Earlier runs", "(a row of the table)", "row", "#runs-table tbody tr:first-child",
       "Clicking anywhere on a row selects that run (the row is highlighted) and opens its step 2. Same as Open.",
       "Continuing someone's run should take one click; selecting is explicit so nobody works on a run by accident.",
       "Every row is clickable.",
       [st("you", "You click a row."),
        st("browser", "open(): select the run in memory and in the selector, recompute the locks, show step 2.",
           js(RUN, "const open = () => { S.run = r.run_id", 2)),
        st("http", "GET /api/runs/<run>  ·  GET /api/jobs/<job>/events  ·  GET /api/runs/<run>/incidents"),
        st("server", "Answers the run.", py(RUNS_API, "get_run")),
        st("screen", "Step 2 of that run. Nothing is written on the server.")]),

    el("s1-open", "S1", "Earlier runs", "Open", "button", "#runs-table tbody tr:first-child button[data-open]",
       "Opens the run of this row in step 2 (same as clicking the row).",
       "A visible button for people who do not expect a table row to be clickable.",
       "Always enabled.",
       [st("you", "You click Open."),
        st("browser", "Stops the row click from firing twice and calls open().",
           js(RUN, 'tr.querySelector("button[data-open]")', 1)),
        st("browser", "open() selects the run and shows step 2.", js(RUN, "const open = () => { S.run = r.run_id", 1)),
        st("http", "GET /api/runs/<run>"),
        st("server", "Answers the run.", py(RUNS_API, "get_run")),
        st("screen", "Step 2 of that run.")]),

    el("s1-delete", "S1", "Earlier runs", "Delete", "button", "#runs-table tbody tr:first-child button[data-del]",
       "Deletes the run after a confirmation (\"Delete run <id> (<file>)? This removes its stage 1 results, stage 2 state "
       "and logs. The knowledge base (your decisions, procedures, tests) is kept. This cannot be undone.\").",
       "Run folders grow (the 4 GB trace's run is large); deleting must never touch the knowledge base, which is learned "
       "state shared by all runs, not run data.",
       "Disabled while the run is queued or running. The server also refuses while a stage-2 job of the run is still "
       "working (\"a stage-2 job of this run is still in progress - wait for it to finish\").",
       [st("you", "You click Delete and confirm."),
        st("browser", "Asks for confirmation, sends the delete, unselects the run if it was selected, shows \"run <id> "
                      "deleted\" and redraws the table.", js(RUN, 'tr.querySelector("button[data-del]")', 6)),
        st("http", "DELETE /api/runs/<run>"),
        st("server", "Refuses (409) while the run or one of its stage-2 jobs runs; deletes its stage-2 jobs, its "
                     "stage-1 job and activity lines, forgets the cached stage-2 objects, removes runs/<run>/.",
           py(RUNS_API, "delete_run")),
        st("service", "Deletes the job row and its job_event lines.", py(JOBS, "JobManager.delete")),
        st("service", "Drops the run's defects and lookups held in memory.", py(S2SVC, "Stage2Service.forget_run")),
        st("database", "db/app.sqlite: job and job_event rows of the run deleted. db/knowledge.sqlite: untouched."),
        st("files", "runs/<run>/ removed with everything in it."),
        st("screen", "The row disappears; the message \"run <id> deleted\" (or \"cannot delete: <reason>\").")],
       code=[py(RUNS_API, "delete_run")]),

    el("s1-delete-note", "S1", "Earlier runs", "Deleting a run removes its stage 1 results, stage 2 state and logs. The "
       "knowledge base (your decisions, procedures, tests) is kept.", "display", "#history-card > p:nth-of-type(2)",
       "The note under the table that says what Delete removes and what it keeps.",
       "Prevents the fear that deleting a run throws away decisions or tests.",
       "Shown on step 1.",
       page_static("Deleting a run removes its stage 1 results", "the Earlier runs card")),

    el("s1-empty", "S1", "Earlier runs", "No runs yet. Enter the path of a trace above and start the analysis.",
       "display", "#runs-empty",
       "Shown instead of rows when no run exists.",
       "An empty table with no explanation looks like an error.",
       "Only when the run list is empty.",
       [st("http", "GET /api/runs  →  []"),
        st("browser", "renderRuns() shows the line when the list is empty.", js(RUN, '$("runs-empty").hidden = S.runs.length > 0', 1)),
        st("files", "The text is in index.html.", js(IDX, '<p id="runs-empty" class="empty" hidden>', 1)),
        st("screen", "The empty-list line.")]),
]

# =====================================================================================================================
# S2 - Step 2 · Analyse the trace (stage 1)
# =====================================================================================================================
PROGRESS_SRC = [st("service", "run_stage1 reads every line the analyser prints and turns it into progress: step, detail "
                              "text, percentage and live counts.", py(RUNNER, "run_stage1", "def on_line(name)", "def step(name")),
                st("service", "Stores {step, detail, pct, at, stats} on the job row.", py(JOBS, "JobManager.progress"))]


def step_line(sid, label, what, why, when, sources, cnt_text, example="", code=None):
    return el("s2-step-" + sid.replace("_", "-"), "S2", "Progress · the step list", label, "row",
              '#steplist tr[data-step="%s"]' % sid, what, why, when,
              sources + run_detail_tail(st("browser", "ring() sets the mark (✓ done, ● running, ○ not yet, – skipped) and "
                                                      "the count on the right.",
                                           js(RUN, 'cnt.textContent = st === "analyze"', 3)), cnt_text),
              code=code, example=example)


ELEMENTS += [
    el("s2-title", "S2", "Header", "2 · Analysing the trace · run run-…", "display", "#run-detail h2",
       "The heading of step 2 with the id of the selected run.",
       "Every number below belongs to this run; the id ties the screen to the run folder runs/<run>/.",
       "Shown when a run is selected and step 2 is open (the heading keeps the word \"Analysing\" after the analysis "
       "has finished).",
       [st("you", "You open step 2, pick a run in the selector or click a row of Earlier runs."),
        st("browser", "loadRun() writes the selected run id.", js(RUN, '$("run-detail").hidden = false; $("run-id").textContent', 1)),
        st("screen", "\"2 · Analysing the trace · run run-20261026-145008-0220\".")]),

    el("s2-status", "S2", "Header", "stage 2 complete", "display", "#run-status",
       "The pill next to the heading: the phase of the run in words (same words as the top bar), green when stage 1 is "
       "done, red when it failed, yellow while it runs.",
       "Repeats the phase next to the progress so you do not have to look up to the top bar.",
       "",
       [st("service", "phase() of the job.", py(SVC, "Services.phase"))] +
       run_detail_tail(st("browser", "loadRun() writes PHASE_TEXT[view.phase]; the colour follows the job status.",
                          js(RUN, '$("run-status").textContent', 1)), "The pill next to the heading."),
       example='"stage 2 complete" for run run-20261026-145008-0220.'),

    el("s2-stop", "S2", "Header", "Stop the analysis", "button", "#btn-cancel",
       "Asks to stop the running analysis, after the confirmation \"Stop the analysis of this trace? It stops after the step "
       "that is running now; the run is then marked failed. Its partial files stay in the run folder (Delete in Earlier "
       "runs removes them). You can analyse the file again later.\" The message \"stop requested\" appears.",
       "A wrong file or a missing input should not block the server for the full duration of a multi-gigabyte analysis.",
       "The button is always shown, also on a finished run, where the request changes nothing. A running analysis "
       "stops only when its current step ends (the analyser's long reading step is not interrupted).",
       [st("you", "You click the button and confirm."),
        st("browser", "Sends the stop request and shows \"stop requested\".", js(RUN, '$("btn-cancel").onclick', 1)),
        st("http", "POST /api/runs/<run>/cancel"),
        st("server", "Finds the job of the run and asks it to stop.", py(RUNS_API, "cancel_run")),
        st("service", "Sets the stop flag; a job that has not started yet is marked cancelled at once.",
           py(JOBS, "JobManager.cancel")),
        st("service", "After each step run_stage1 checks the flag and ends with \"cancelled\"; the job manager then "
                      "marks the job failed.", py(RUNNER, "run_stage1", "def step(name, args, pct)", "an = [\"analyze\"")),
        st("database", "db/app.sqlite table job: status failed, error \"cancelled ...\"."),
        st("files", "runs/<run>/ keeps the files the finished steps had written."),
        st("screen", "Phase \"stage 1 failed\", ring \"failed\"; the run stays in Earlier runs and can be deleted.")]),

    el("s2-ring", "S2", "Progress", "100%", "display", "#ring",
       "The progress ring with the percentage in the middle. Each step owns a share: reading packets 2-60 % (moving with "
       "the rows read), host evidence 60-64 %, grouping 64-72 %, reusing verdicts 73 %, AI reviewer 74-94 %, report "
       "95-97 %, capture check 97-99 %. It shows 100 % only when the job is done (at most 99 % before).",
       "An honest progress view: the operator can tell a long, healthy analysis from a stuck one.",
       "Shown while a run is selected on step 2; green when done, red when failed.",
       PROGRESS_SRC + run_detail_tail(st("browser", "ring() draws the arc and writes the percentage.",
                                         js(RUN, "function ring(j, v)", 6)), "The ring and its percentage."),
       code=[py(RUNNER, "run_stage1", "PCT = {", "def on_line(name)")],
       example='100 % for run run-20261026-145008-0220 (job done).'),

    el("s2-ring-step", "S2", "Progress", "complete", "display", "#ring-step",
       "The small word under the percentage: the current step in short words - starting, reading packets, host "
       "evidence, grouping defects, reusing verdicts, AI reviewer, writing report, capture check - then complete or "
       "failed.",
       "Tells at a glance which part of the analysis is working; the internal step ids are never shown.",
       "",
       PROGRESS_SRC + run_detail_tail(st("browser", "ring() maps the step id to its short label.",
                                         js(RUN, '$("ring-step").textContent', 1)), "The word under the percentage.")),

    el("s2-ring-text", "S2", "Progress", "Stage 1 complete: 3 defects found", "display", "#ring-text",
       "The headline next to the ring. While running: what the analyser is doing in a full sentence plus the latest "
       "detail (for example \"Reading the capture and checking every packet - 2,000,000 rows read, 31 findings\"). "
       "Done: \"Stage 1 complete: <n> defects found\". Failed: \"Stage 1 failed - see the activity log\".",
       "A sentence in the operator's words instead of an internal step name.",
       "After a failure the reason itself is written in the data block under Time taken per step, not in the Activity "
       "log.",
       PROGRESS_SRC + run_detail_tail(st("browser", "ring() writes STEP_TEXT[step] + the detail, reworded by plain() "
                                                    "(\"engine\" → \"analyser\", \"LLM\" → \"AI reviewer\").",
                                         js(RUN, '$("ring-text").textContent', 2)), "The headline."),
       example='"Stage 1 complete: 3 defects found" for run run-20261026-145008-0220.'),

    el("s2-eta", "S2", "Progress", "about 2 min remaining · 95 s elapsed", "display", "#ring-eta",
       "The grey line under the headline while the analysis runs: the time left, the time elapsed, and \"still "
       "working…\" after 30 seconds without an update (after 120 seconds: \"no update for <n> s - the analyser is still "
       "working on a long step\").",
       "A padded, rounded estimate shown only after the noisy start (10 %) is more honest than a jumping one; the "
       "staleness note prevents a long step from looking like a hang.",
       "Only while the job runs; empty when it is done or failed.",
       [st("database", "db/app.sqlite table job: started time and progress.pct, progress.at."),
        st("service", "eta_s(): elapsed × (100 − pct) / pct × 1.15, rounded to 5 or 10 s, only from 10 %.",
           py(SVC, "Services.eta_s")),
        st("service", "run_view() adds eta_s and stale_s (seconds since the last progress update).",
           py(SVC, "Services.run_view"))] +
       run_detail_tail(st("browser", "ring() writes the line.", js(RUN, 'let eta = "";', 6)), "The time line.")[1:],
       code=[py(SVC, "Services.eta_s")]),

    el("s2-steplist", "S2", "Progress · the step list", "✓ ● ○ –", "table", "#steplist",
       "The six stage-1 steps, each with a mark: ✓ done, ● running now, ○ not yet, – skipped (with the reason on the "
       "right). The optional seventh step (capture check) is not listed; it shows in the ring label and in Time taken "
       "per step.",
       "The operator sees which steps ran and which were skipped for lack of an input, not only a percentage.",
       "",
       [st("service", "Every step is timed; a finished step leaves a span named stage1.<step> on the job.",
           py(JOBS, "Span.__exit__"))] +
       run_detail_tail(st("browser", "ring(): ✓ when a span exists, ● for the current step, – for a skipped one, "
                                     "○ otherwise.", js(RUN, 'for (const tr of document.querySelectorAll("#steplist tr"))', 5)),
                       "The marks of the six lines.")),

    step_line("analyze", "Read the capture and check every packet",
              "The first and longest step: one pass over the CSV, row by row. Each row goes to the checks for its kind "
              "(transaction packets, acknowledgements, ordered sets, link events, markers); whenever the state the "
              "specification defines goes wrong, a rule fires. The count on the right: \"<rows read> of about <rows> "
              "packets read · <n> rules fired\".",
              "This is where the evidence comes from; the live count shows the analyser is moving through a large "
              "file. The total is estimated from the file size because counting the lines of a 4 GB file would take as "
              "long as reading it.",
              "The count is updated every 2,000,000 rows and at the end of the step; the number of rules fired is "
              "replaced at the grouping step by the final count (host and whole-trace findings included).",
              [st("files", "The analyzer CSV given in step 1."),
               st("service", "estimate_rows(): file size ÷ mean line length of the first 2 MB.", py(RUNNER, "estimate_rows")),
               st("engine", "Engine.run() prints \"<rows> rows <s>s findings=<n>\" every 2,000,000 rows and \"done <rows> "
                            "rows ...\" at the end.", py(ENGINE, "Engine.run")),
               PROGRESS_SRC[0], PROGRESS_SRC[1]],
              "\"42,906 of about 47,413 packets read · 30 rules fired\".",
              example='"42,906 of about 47,413 packets read · 30 rules fired" for run run-20261026-145008-0220.'),

    step_line("fuse", "Line up the host evidence with the packets",
              "Places each host line (kernel log, tool records) on the packet time axis so a defect can cite it. "
              "Skipped (–, \"no host evidence given\") when neither file was given in step 1.",
              "About 46 known error types leave no trace in the packets; this step is what lets stage 1 prove them.",
              "Runs only with a kernel log or host tool records.",
              [st("files", "The dmesg -x file and/or host_events.jsonl given in step 1."),
               st("engine", "fuse(): clock alignment and placement; writes host_findings.pkl and host_alignment.json.",
                  py(HOST, "fuse")),
               PROGRESS_SRC[1]],
              "\"no host evidence given\" when skipped.",
              example='"no host evidence given" for run run-20261026-145008-0220.'),

    step_line("isolate", "Group the rules that fired into defects",
              "Findings closer than 1,000 packets form one defect; for each: the first abnormal packet, the evidence "
              "graph whose root is the root cause, the best catalogue matches, who caused it (rules R0-R10), the NVMe "
              "command and host task, and the packet rows around it. The count: \"<n> defects\".",
              "Many rule firings belong to one failure; grouping them is what turns thousands of findings into a short "
              "list a person can review.",
              "",
              [st("engine", "isolate() clusters the findings, ranks the catalogue cards, attributes each defect, prints "
                            "\"findings <n> -> incidents <m>\".", py(INCID, "isolate")),
               st("files", "runs/<run>/incidents.json, incident_rows.jsonl"),
               PROGRESS_SRC[0], PROGRESS_SRC[1]],
              "\"3 defects\".",
              example='"3 defects" for run run-20261026-145008-0220.'),

    step_line("pattern_cache", "Reuse AI reviewer verdicts from earlier runs (no model call)",
              "For each defect a key is built from error type, first rule, error family, layer, the set of rules, the "
              "sequence of packet kinds in its rows, the model and the prompt version; a verdict stored under that key "
              "earlier is reused. The count: \"<n> verdicts reused\".",
              "The same pattern confirmed once does not need to be paid for again; a model or prompt change changes the "
              "key, so an old verdict is never reused for a new model.",
              "",
              [st("service", "pattern_key() builds the key.", py(PCACHE, "pattern_key")),
               st("database", "db/app.sqlite table verdict_cache: one stored verdict per key (hits counted).",
                  py(PCACHE, "VerdictCache.lookup")),
               st("files", "A hit is written into runs/<run>/llm_reviews.jsonl with backend \"pattern-cache\".",
                  py(PCACHE, "cached_record")),
               PROGRESS_SRC[1]],
              "\"3 verdicts reused\".",
              example='"3 verdicts reused" for run run-20261026-145008-0220 (all three defects).'),

    step_line("review", "Ask the AI reviewer for a second opinion on each defect",
              "The defects not answered by the cache are sent, with their packet rows and rule texts, to the AI reviewer, "
              "which answers whether the rows show the defect, which rules it agrees with, which packets it cites and "
              "who caused it. The count: \"<n> of <m> reviewed\".",
              "Rules can fire for the wrong reason; a second opinion that must cite packets catches that, without ever "
              "overruling the rules.",
              "Skipped (–) when the backend runs without a model (stand-in, openai-compat) or when every defect already "
              "got a cached verdict; the right column then says \"no AI reviewer configured\" or, when every verdict came from the cache, \"not needed: every verdict was reused from the cache\". The live "
              "count arrives every 25 defects (command-line backend) or 50 (programming-interface backend).",
              [st("service", "llm_backend(): only cli, sdk and auto reach a model in stage 1; anything else runs dry.",
                  py(RUNNER, "llm_backend")),
               st("engine", "review_run() calls the model for every defect not yet in llm_reviews.jsonl and prints "
                            "\"<n>/<m> {stats}\".", py(LLM, "review_run")),
               st("files", "runs/<run>/llm_reviews.jsonl"),
               PROGRESS_SRC[0]],
              "\"<n> of <m> reviewed\", or, when skipped, \"not needed: every verdict was reused from the cache\" or \"no AI reviewer configured\".",
              code=[py(RUNNER, "run_stage1", 'if backend != "dry-run" and hits < len(incs)', 'step("report", ["report", "--run", run_dir], 90)'),
                    js(RUN, 'cnt.textContent = st === "analyze"', 3)],
              example='Run run-20261026-145008-0220 shows "not needed: every verdict was reused from the cache": the backend "cli" is '
                      'configured, and all three verdicts came from the cache.'),

    step_line("report", "Write the stage 1 report",
              "Fuses the analyser, the catalogue and the AI reviewer into one final record per defect: status "
              "(isolated, isolated from the packets alone, needs host evidence, disputed), where, why, evidence rows, "
              "host evidence and the fix text. No count is shown.",
              "One record per defect is what step 3, the defect page and stage 2 read; the Markdown copy is for people.",
              "",
              [st("engine", "build() writes isolation.json, isolation_summary.json and isolation_report.md.",
                  py(ISO, "build")),
               st("files", "runs/<run>/isolation.json, isolation_report.md"),
               PROGRESS_SRC[1]],
              "✓ when the report step has a timing span."),

    el("s2-log", "S2", "Details", "Activity log", "display", "#run-detail > details:nth-of-type(1) > summary",
       "A fold-out box with every line the analyser printed, each with the local time: \"stage 1 started on <file> "
       "(<MB>, about <rows> rows)\", \"==> analyze\", progress lines, \"pattern cache: <n> of <m> defects already "
       "confirmed earlier\", \"stage 1 complete: ...\".",
       "When something goes wrong the operator (or the developer) needs the analyser's own words, not only a red ring.",
       "Closed by default; new lines are added while the analysis runs. The pretty-printed run summary of the analyse "
       "step also appears in it, line by line.",
       [st("you", "You click \"Activity log\" to open it."),
        st("service", "run_stage1 writes one event per useful line (lines that start like a JSON object are skipped).",
           py(RUNNER, "run_stage1", "def on_line(name)", "def step(name")),
        st("service", "event(): appends (job, seq, time, text) to job_event.", py(JOBS, "JobManager.event")),
        st("database", "db/app.sqlite table job_event"),
        st("server", "Returns only the lines after the last one the screen has (?after=<seq>).", py(MISC_API, "job_events")),
        st("http", "GET /api/jobs/<job>/events?after=<n>"),
        st("browser", "stream() appends the new lines with their time, reworded by plain().", js(RUN, "async function stream(jid)", 5)),
        st("screen", "The lines in the fold-out box.")],
       example='Job stage1-31a8d8bfe6 (run run-20261026-145008-0220) has 139 lines; line 1 "stage 1 started on '
               'sample_T-42_L-21_C-16_seed11.csv (23.1 MB, about 47,413 rows)".'),

    el("s2-times", "S2", "Details", "Time taken per step", "table", "#run-detail > details:nth-of-type(2) > summary",
       "A fold-out table: Step, Seconds, Note - one row per finished step (reading packets, host evidence, grouping "
       "defects, reusing verdicts, AI reviewer, writing report, capture check). The note says \"done\", \"failed\" or "
       "\"verdicts reused from the cache: <n>\".",
       "The project measures triage time; the per-step seconds show where the time goes (for example the model call of "
       "the capture check).",
       "Closed by default.",
       [st("you", "You click \"Time taken per step\" to open it."),
        st("service", "Each step runs inside a timing span; at its end the span {name, seconds, meta} is appended to the "
                      "job.", py(JOBS, "Span.__exit__")),
        st("database", "db/app.sqlite table job: spans")] +
       run_detail_tail(st("browser", "loadRun() writes one row per span.", js(RUN, "for (const s of j.spans)", 1)),
                       "The table of steps and seconds.")[1:],
       example='Run run-20261026-145008-0220: reading packets 1.49 s, grouping defects 0.44 s, reusing verdicts 0.02 s '
               '(3 reused), writing report 0.06 s, capture check 12.67 s.'),

    el("s2-total", "S2", "Details", "stage 1 total 14.7 s", "display", "#run-total",
       "The line under the table: \"stage 1 total <s> s\" (sum of the step times) or \"running - <s> s so far\".",
       "The single number that is compared with the first-level triage budget.",
       "Inside Time taken per step.",
       [st("database", "db/app.sqlite table job: spans and started time")] +
       run_detail_tail(st("browser", "loadRun() adds the span seconds.", js(RUN, '$("run-total").textContent', 1)),
                       "\"stage 1 total 14.7 s\".")[1:],
       example='"stage 1 total 14.7 s" for run run-20261026-145008-0220.'),

    el("s2-summary-json", "S2", "Details", "{ \"AI reviewer model\": …, \"how it was reached\": …, \"stage 1 summary\": … }",
       "display", "#run-summary",
       "A block of raw data under the total: which model the AI reviewer used, how it was reached (cli, sdk, dry-run), "
       "and the stage-1 summary (defects by status, by side, by layer). After a failure it holds the error text "
       "instead.",
       "For the person who has to explain a run: the exact model and the counts behind the chips, and the reason of a "
       "failure.",
       "Inside Time taken per step; the error text only after a failure.",
       [st("engine", "build() counts the defects by status, origin and layer into isolation_summary.json.", py(ISO, "build")),
        st("service", "run_stage1 copies it into stage1_summary.json with model and backend.",
           py(RUNNER, "run_stage1", "sp_ = os.path.join", "mgr.event(job_id, \"stage 1 complete")),
        st("files", "runs/<run>/stage1_summary.json")] +
       run_detail_tail(st("browser", "loadRun() writes the JSON, or the job error reworded by plain().",
                          js(RUN, '$("run-summary").textContent = JSON.stringify', 1)), "The data block.")[1:],
       example='Run run-20261026-145008-0220: model "claude-haiku-5-5", how it was reached "cli".'),

    el("s2-warnings", "S2", "Results", "This trace was analysed with limited inputs - fewer defects are visible than the "
       "trace contains.", "display", "#run-warnings .callout",
       "A yellow box above the results when an input was missing: no payload bytes (\"The DATA column holds only sizes "
       "...\"), no host log (\"No host log was given: about 46 error types leave no trace in the packets ...\") or no "
       "namespace size (\"No namespace size (nsze): LBA-range rules were off.\"), ending with the advice to use Find "
       "companion files and analyse again.",
       "A short defect list may mean a healthy trace or a blind analysis; the box says which inputs were missing.",
       "Only after stage 1 is done and only when at least one input was missing.",
       [st("files", "runs/<run>/run.json capture.payload, and the job params dmesg, events, nsze."),
        st("server", "get_run() builds the warning texts.", py(RUNS_API, "get_run", "warnings = []", "return jsonify({\"job\": j")),
        st("http", "GET /api/runs/<run>"),
        st("browser", "loadRun() draws the box, rewording each warning by plain().", js(RUN, '$("run-warnings").innerHTML', 1)),
        st("screen", "The yellow box.")],
       example='Run run-20261026-145008-0220 shows one warning: "No host log was given ...".'),

    el("s2-results-title", "S2", "Results", "Defects found in this trace", "display", "#run-results h2",
       "The heading of the results card and the paragraph under it: one row per defect, numbered in the order the "
       "analyser met them; the first badge is the analyser's verdict (Confirmed / Suspect / Needs evidence), the second "
       "the AI reviewer's second opinion (agrees / not sure / disagrees), and what \"verdict reused from the cache\" and "
       "\"fresh model call\" mean.",
       "The verdict words are fixed and explained once, right where they are first used.",
       "Shown when stage 1 is done.",
       page_static("<h2 style=\"margin:0\">Defects found in this trace</h2>", "the results card")),

    el("s2-chip-defects", "S2", "Results · chips", "defects found", "display", "#run-chips .chip:nth-child(1)",
       "The number of defects stage 1 found.",
       "The headline result of the triage.",
       "Shown when stage 1 is done.",
       [st("engine", "run_stage1 counts incidents.json.", py(RUNNER, "run_stage1", 'summary["incidents"] = len(incs)', "# ---------------- pattern cache")),
        st("files", "runs/<run>/stage1_summary.json: incidents")] +
       run_detail_tail(st("browser", "loadRun() draws the five chips from the summary.", js(RUN, '$("run-chips").innerHTML', 1)),
                       "\"3 defects found\".")[1:],
       example='3 for run run-20261026-145008-0220.'),

    el("s2-chip-agrees", "S2", "Results · chips", "AI reviewer agrees", "display", "#run-chips .chip:nth-child(2)",
       "On how many defects the AI reviewer's verdict is CONFIRMED (fresh or reused from the cache).",
       "Shows how much of the analyser's result an independent reader backs.",
       "Shown when stage 1 is done.",
       [st("engine", "run_stage1 counts the CONFIRMED answers in llm_reviews.jsonl.",
           py(RUNNER, "run_stage1", "reviewed = called = confirmed = 0", "sp_ = os.path.join")),
        st("files", "runs/<run>/stage1_summary.json: llm_confirmed")] +
       run_detail_tail(st("browser", "Chip 2.", js(RUN, '$("run-chips").innerHTML', 1)), "\"2 AI reviewer agrees\".")[1:],
       example='2 for run run-20261026-145008-0220.'),

    el("s2-chip-fresh", "S2", "Results · chips", "fresh model calls", "display", "#run-chips .chip:nth-child(3)",
       "How many defects were sent to the model in this run (the reviews not taken from the cache). The one extra call "
       "of the capture check is not counted here.",
       "Model calls cost money and time; the chip shows how many were really made.",
       "Shown when stage 1 is done.",
       [st("engine", "Reviews whose backend is not \"pattern-cache\" are counted as called and stored in the cache.",
           py(RUNNER, "run_stage1", "reviewed = called = confirmed = 0", "sp_ = os.path.join")),
        st("files", "runs/<run>/stage1_summary.json: llm_called")] +
       run_detail_tail(st("browser", "Chip 3.", js(RUN, '$("run-chips").innerHTML', 1)), "\"0 fresh model calls\".")[1:],
       example='0 for run run-20261026-145008-0220; 189 for the 4 GB trace.'),

    el("s2-chip-cached", "S2", "Results · chips", "verdicts reused from the cache (no model call)", "display",
       "#run-chips .chip:nth-child(4)",
       "How many defects got a verdict stored in an earlier run for the same pattern.",
       "Reuse is one of the project's efficiency measures (model calls saved).",
       "Shown when stage 1 is done.",
       [st("database", "db/app.sqlite table verdict_cache", py(PCACHE, "VerdictCache.lookup")),
        st("engine", "run_stage1 counts the hits of the pattern-cache step.",
           py(RUNNER, "run_stage1", 'with mgr.span(job_id, "stage1.pattern_cache", {}) as sp', "# ---------------- LLM confirmation")),
        st("files", "runs/<run>/stage1_summary.json: llm_cached")] +
       run_detail_tail(st("browser", "Chip 4.", js(RUN, '$("run-chips").innerHTML', 1)), "\"3 verdicts reused ...\".")[1:],
       example='3 for run run-20261026-145008-0220.'),

    el("s2-chip-seconds", "S2", "Results · chips", "seconds taken", "display", "#run-chips .chip:nth-child(5)",
       "The sum of the step times of stage 1, in seconds.",
       "The triage time of this trace, next to its result.",
       "Shown when stage 1 is done.",
       [st("database", "db/app.sqlite table job: spans", py(JOBS, "Span.__exit__"))] +
       run_detail_tail(st("browser", "Chip 5 = the same total as \"stage 1 total\".", js(RUN, '$("run-chips").innerHTML', 1)),
                       "\"14.7 seconds taken\".")[1:],
       example='14.7 for run run-20261026-145008-0220.'),

    el("s2-def-row", "S2", "Results · one defect", "▸ Defect 1  error type T-42 …  ✓ Confirmed  AI reviewer agrees",
       "row", "#defects-list details.defect:first-child > summary",
       "One row per defect. Closed, it shows the defect number, the error type written out, the verdict badge, the AI "
       "reviewer badge, where the verdict came from and the packet range. Clicking opens it and loads the summary of "
       "its full record (What this means, Where, Why it was flagged, Who, Host evidence, AI reviewer, Open the full "
       "record).",
       "The defects can be read right under the progress, without leaving step 2; the details are fetched only when "
       "you open a row.",
       "Shown when stage 1 is done; the summary is loaded once per row.",
       [st("you", "You click a row."),
        st("browser", "The rows are drawn from the defect list.", js(RUN, "async function renderDefects()", 4)),
        st("http", "GET /api/runs/<run>/incidents   (once per run)"),
        st("browser", "Opening a row the first time loads its summary.", js(RUN, 'd.addEventListener("toggle"', 1)),
        st("http", "GET /api/runs/<run>/defect/<defect>"),
        st("server", "The full record of the defect.", py(S2_API, "defect_record")),
        st("browser", "defectSummary() writes the six lines and the link.", js(RUN, "async function defectSummary(id)", 11)),
        st("screen", "The opened row.")]),

    el("s2-def-name", "S2", "Results · one defect", "Defect 1", "display",
       "#defects-list details.defect:first-child .card-id",
       "The defect's number in this trace: Defect 1, 2, 3 … in the order the analyser met them (by packet number).",
       "The internal record id (INC-0001) means nothing to an operator; \"Defect 1\" does.",
       "",
       [st("engine", "isolate() numbers the groups in packet order as INC-0001, INC-0002 …", py(INCID, "isolate"))] +
       incidents_tail(st("browser", "defectName() turns INC-0001 into \"Defect 1\".", js(APIJ, "export function defectName(id)", 4)),
                      "\"Defect 1\".")),

    el("s2-def-type", "S2", "Results · one defect", "error type T-42 (chapter T = timeouts and time limits, entry 42): "
       "D3hot→D0 transition: access before the 10 ms recovery time", "display",
       "#defects-list details.defect:first-child .ttl",
       "The error type the defect was matched to in the catalogue of 485 known error types, written out: its id, the "
       "chapter its letter stands for, its position, and its title. \"no catalogue match\" when none fits.",
       "The id alone (T-42) is meaningless to a newcomer; the chapter and title say what kind of failure it is.",
       "",
       [st("engine", "Classifier.rank() scores the catalogue against the defect's findings; the best one comes first.",
           py(ATLAS, "Classifier.rank"))] +
       incidents_tail(st("browser", "errorTypeFull(card, title).", js(APIJ, "export function errorTypeFull(card, title)", 4)),
                      "The written-out error type."),
       example='"error type T-42 (chapter T = timeouts and time limits, entry 42): D3hot→D0 transition: access before '
               'the 10 ms recovery time" for Defect 1 of run run-20261026-145008-0220.'),

    el("s2-def-verdict", "S2", "Results · one defect", "✓ Confirmed", "display",
       "#defects-list details.defect:first-child > summary > span.pill:nth-of-type(3)",
       "The analyser's verdict in three fixed words, with colour and symbol: ✓ Confirmed (proven by the rules on the "
       "packets), ? Suspect (a rule fired but the proof is incomplete, or the AI reviewer disputed it), ! Needs evidence "
       "(the packets show only a symptom).",
       "A fixed three-word vocabulary, never colour alone, so every reader interprets a verdict the same way.",
       "",
       [st("engine", "The isolation status of the defect: ISOLATED, ISOLATED_WIRE_ONLY, NEEDS_OUTSIDE_EVIDENCE, DISPUTED.",
           py(ISO, "_status"))] +
       incidents_tail(st("browser", "statusPill() draws the word with its colour and symbol.", js(APIJ, "export const STATUS = {", 2)),
                      "The verdict badge."),
       example='Defect 1 "✓ Confirmed", Defect 2 "! Needs evidence" in run run-20261026-145008-0220.'),

    el("s2-def-ai", "S2", "Results · one defect", "AI reviewer agrees", "display",
       "#defects-list details.defect:first-child > summary > span.pill:nth-of-type(4)",
       "The AI reviewer's second opinion on the defect: \"AI reviewer agrees\" (green), \"AI reviewer not sure\" "
       "(yellow), \"AI reviewer disagrees\" (red), or \"AI reviewer not run\".",
       "The second opinion is shown next to the verdict but separately: it never changes the analyser's verdict.",
       "A model answer NOT_CONFIRMED (or REFUTED / DISPUTED) is shown as \"AI reviewer disagrees\" (red).",
       [st("engine", "review_run() or the verdict cache writes the verdict (CONFIRMED, NOT_CONFIRMED, INCONCLUSIVE).",
           py(LLM, "review_run"))] +
       incidents_tail(st("browser", "aiWord() maps CONFIRMED → agrees, INCONCLUSIVE → not sure, NOT_CONFIRMED (and REFUTED, DISPUTED) → disagrees.",
                         js(RUN, "const AI_WORD = {", 2)), "The AI reviewer badge."),
       example='Defect 1 "AI reviewer agrees", Defect 2 "AI reviewer not sure" in run run-20261026-145008-0220.'),

    el("s2-def-source", "S2", "Results · one defect", "verdict reused from the cache (no model call): the same error "
       "family was confirmed in an earlier run", "display", "#defects-list details.defect:first-child .llmline",
       "Where the AI reviewer's verdict came from: \"verdict reused from the cache (no model call) ...\", \"fresh model "
       "call\", or \"the AI reviewer was not asked (dry run or no backend configured)\".",
       "A reused verdict is cheaper but was given on another trace; the reader must know which kind it is.",
       "",
       [st("files", "runs/<run>/llm_reviews.jsonl: backend = \"pattern-cache\" for a reused verdict.",
           py(PCACHE, "cached_record"))] +
       incidents_tail(st("browser", "The line under the badges.", js(RUN, '<span class="llmline">', 1)), "The source line."),
       example='All three defects of run run-20261026-145008-0220 say "verdict reused from the cache (no model call) ...".'),

    el("s2-def-packets", "S2", "Results · one defect", "packets 37391-37398", "display",
       "#defects-list details.defect:first-child > summary > span:nth-of-type(6)",
       "The packet numbers where the defect starts and ends in the trace (the evidence span).",
       "Lets the operator find the defect in the analyzer software straight away.",
       "",
       [st("engine", "isolate(): start_pkt / end_pkt of the group.", py(INCID, "isolate"))] +
       incidents_tail(st("browser", "\"packets <start>-<end>\".", js(RUN, "packets ${esc(i.start_pkt", 1)), "\"packets 37391-37398\"."),
       example='"packets 37391-37398" for Defect 1 of run run-20261026-145008-0220.'),

    el("s2-def-means", "S2", "Results · one defect opened", "What this means", "display",
       "#defects-list details.defect:first-child .kv > span:nth-of-type(1)",
       "The error type written out, its error family (how it shows on the wire, for example \"configuration space, power "
       "state and reset sequencing (family P19)\"), where (the layer), and the isolation status in a sentence.",
       "Answers the first question of a newcomer: what kind of failure is this?",
       "After the row is opened.",
       [st("files", "runs/<run>/isolation.json defect {card_id, title, pattern, layer} and status.")] +
       record_tail(st("browser", "defectSummary() line 1: errorTypeFull, familyName, where(), status meaning.",
                      js(RUN, "<b>What this means</b>", 1)), "The first line of the opened row."),
       example='"error type T-42 ... · error family: configuration space, power state and reset sequencing (family P19) · '
               'where: configuration - ... the analyser\'s rules and the AI reviewer agree: the defect is isolated to '
               'these packets."'),

    el("s2-def-where", "S2", "Results · one defect opened", "Where", "display",
       "#defects-list details.defect:first-child .kv > span:nth-of-type(2)",
       "The first abnormal packet, the rule that fired there with its detail and rule id, and the packet range.",
       "The first abnormal packet is where normal traffic stops being normal; everything after it may be a knock-on "
       "effect.",
       "After the row is opened.",
       [st("engine", "isolate(): first_abnormal = the earliest defect finding on the wire.", py(INCID, "isolate"))] +
       record_tail(st("browser", "defectSummary() line 2.", js(RUN, "<b>Where</b><span>first abnormal packet", 1)),
                   "\"first abnormal packet #37395 · rule that fired: MMIO read 0x1C 2.000 ms after D3hot->D0 "
                   "(CFG.D0_EARLY) · packets 37391-37398\"."),
       example='"first abnormal packet #37395 · rule that fired: MMIO read 0x1C 2.000 ms after D3hot->D0 (CFG.D0_EARLY)".'),

    el("s2-def-why", "S2", "Results · one defect opened", "Why it was flagged", "display",
       "#defects-list details.defect:first-child .kv > span:nth-of-type(3)",
       "Every rule that fired for the defect, with ✓ (confirmed by the rule) or ? (suspect only) and the packet it fired "
       "on.",
       "The verdict is only as good as the rules behind it; the list shows them one by one.",
       "After the row is opened.",
       [st("engine", "build(): the evidence list of the defect (rule, verdict, packet).", py(ISO, "build"))] +
       record_tail(st("browser", "defectSummary() line 3.", js(RUN, "<b>Why it was flagged</b>", 1)),
                   "\"✓ CFG.D0_EARLY at packet #37395 · ✓ TLP.CPL_STATUS at packet #37398 · ? S.RARE_WINDOW at packet "
                   "#37398\"."),
       example='"✓ CFG.D0_EARLY at packet #37395 · ✓ TLP.CPL_STATUS at packet #37398 · ? S.RARE_WINDOW at packet #37398".'),

    el("s2-def-who", "S2", "Results · one defect opened", "Who", "display",
       "#defects-list details.defect:first-child .kv > span:nth-of-type(4)",
       "Which side caused the defect: host side, device side, or platform, link, test setup as decided by the "
       "attribution rules.",
       "Decides who must fix it: the drive's firmware team or the host / platform team.",
       "After the row is opened.",
       [st("engine", "attribute(): the decision procedure R0-R10 (for example R4: the sender of the first bad "
                     "transaction packet).", py(INCID, "attribute"))] +
       record_tail(st("browser", "defectSummary() line 4: who().", js(RUN, "<b>Who</b>", 1)), "\"host side\"."),
       example='"host side" for Defect 1 of run run-20261026-145008-0220.'),

    el("s2-def-host", "S2", "Results · one defect opened", "Host evidence", "display",
       "#defects-list details.defect:first-child .kv > span:nth-of-type(5)",
       "Whether host evidence was needed: \"not needed - the packets alone prove it\", \"needed and taken from <source>: "
       "...\", or \"needed, not yet available: <what to collect>\".",
       "Tells the operator whether to go and fetch a host log before trusting or deciding on the defect.",
       "After the row is opened.",
       [st("engine", "fuse() / build(): host findings attached to the defect, and attribute()'s list of evidence to "
                     "collect.", py(ISO, "build"))] +
       record_tail(st("browser", "defectSummary() line 5.", js(RUN, "<b>Host evidence</b>", 1)),
                   "\"not needed - the packets alone prove it\"."),
       example='"not needed - the packets alone prove it" for Defect 1 of run run-20261026-145008-0220.'),

    el("s2-def-ai-line", "S2", "Results · one defect opened", "AI reviewer", "display",
       "#defects-list details.defect:first-child .kv > span:nth-of-type(6)",
       "The AI reviewer's badge, whether the verdict was reused or fresh, and the first 400 characters of its summary "
       "(OBSERVED / RULE / HYPOTHESIS statements that cite packets).",
       "The reasoning behind the second opinion, readable without opening the full record.",
       "After the row is opened; \"not asked\" when no review exists.",
       [st("files", "runs/<run>/llm_reviews.jsonl: verdict, backend, summary.")] +
       record_tail(st("browser", "defectSummary() line 6.", js(RUN, "<b>AI reviewer</b>", 1)),
                   "\"AI reviewer agrees · verdict reused from the cache (no model call) · OBSERVED: ...\"."),
       example='Summary of Defect 1 begins "OBSERVED: CfgWr at #37387 sets PMCSR (reg 0x044) to D3hot (data 03) ...".'),

    el("s2-def-link", "S2", "Results · one defect opened", "Open the full record ↗", "link",
       '#defects-list details.defect:first-child .kv a[href^="/defect"]',
       "Opens the defect page (/defect?run=<run>&inc=<defect>) in a new tab: the full record in eight sections.",
       "The summary in the row is short on purpose; the full record has every rule, every packet and the stage-2 "
       "history.",
       "After the row is opened.",
       [st("you", "You click the link."),
        st("browser", "A link with the run and the defect in the address, target=_blank.", js(RUN, "Open the full record", 1)),
        st("http", "GET /defect?run=<run>&inc=<defect>"),
        st("server", "Sends app/static/defect.html.", py(SERVER, "create_app", '@app.get("/defect")', "@app.after_request")),
        st("browser", "defect.js reads run and inc from the address and loads the record.", DP_MAIN),
        st("http", "GET /api/runs/<run>/defect/<defect>"),
        st("screen", "The defect page in a new tab.")]),

    el("s2-def-empty", "S2", "Results", "No defects were found in this trace. …", "display", "#defects-list p.empty",
       "Shown instead of rows when stage 1 found nothing, with the advice that host evidence may be needed for a known "
       "problem.",
       "\"Nothing found\" must not be read as \"the drive is healthy\" when inputs were missing.",
       "Only when the defect list is empty.",
       incidents_tail(st("browser", "renderDefects() writes the line for an empty list.",
                         js(RUN, "No defects were found in this trace. If the trace", 1)), "The empty-list line.")),

    el("s2-cta", "S2", "Results", "Stage 2 complete: 3 of 3 defects decided, 2 regression tests admitted.", "display",
       "#run-cta-text",
       "The bar at the bottom of the results. Before stage 2: \"Stage 1 complete. <n> defects found; the AI reviewer "
       "agrees on <m>; <s> s taken. Stage 2 has not started: ...\". Afterwards: \"Stage 2 in progress / complete: <d> of "
       "<t> defects decided, <a> regression tests admitted.\"",
       "Says what comes next, and that stage 2 is not started automatically.",
       "Shown when stage 1 is done.",
       [st("service", "Counts over the defects with a catalogue match.", py(SVC, "Services.queue"))] +
       run_detail_tail(st("browser", "loadRun() writes the text for the phase.",
                          js(RUN, 'if (v.phase === "stage1_done") { $("run-cta-text")', 2)), "The bottom bar.")[1:],
       example='"Stage 2 complete: 3 of 3 defects decided, 2 regression tests admitted." for run run-20261026-145008-0220.'),

    el("s2-to-table", "S2", "Results", "Show as a table", "button", "#btn-to-incidents",
       "Opens step 3 with the same defects as a table.",
       "A table with a filter is easier to scan when there are many defects.",
       "Shown with the bottom bar.",
       [st("you", "You click the button."),
        st("browser", "show(\"incidents\").", js(RUN, '$("btn-to-incidents").onclick', 1)),
        st("browser", "Step 3 enter() loads the queue and the defect rows.", js(INCJ, "export async function enter()", 4)),
        st("http", "GET /api/runs/<run>/stage2/queue  ·  GET /api/runs/<run>/incidents"),
        st("server", "Defect rows.", py(S2_API, "list_incidents")),
        st("screen", "Step 3.")]),

    el("s2-to-stage2", "S2", "Results", "Continue to stage 2 → / Open stage 2 (reproduce and decide) →", "button",
       "#btn-to-stage2",
       "Opens step 4. Before stage 2 it reads \"Continue to stage 2 →\" and leads to the Start stage 2 gate; afterwards "
       "\"Open stage 2 (reproduce and decide) →\" and leads to the review queue.",
       "Stage 2 is the second half of the loop (reproduce, decide, test); the button is offered only once stage 1 is "
       "done.",
       "Shown with the bottom bar.",
       [st("you", "You click the button."),
        st("browser", "show(\"review\").", js(RUN, '$("btn-to-stage2").onclick', 1)),
        st("browser", "The review page's enter() asks for the queue.", js(REVJ, "export async function enter(incId)", 5)),
        st("http", "GET /api/runs/<run>/stage2/queue"),
        st("server", "Whether stage 2 was started, and every defect's state.", py(S2_API, "queue")),
        st("screen", "Step 4: the gate or the review queue.")]),
]

# =====================================================================================================================
# S3 - Step 3 · Defects found
# =====================================================================================================================
INC_RENDER = js(INCJ, "<td class=mono>${esc(defectName(i.id))}</td>", 5)
QUEUE_STEP = [st("service", "queue(): counts of the defects with a catalogue match, and whether runs/<run>/stage2/STARTED "
                            "exists.", py(SVC, "Services.queue")),
              st("server", "Answers the queue.", py(S2_API, "queue")),
              st("http", "GET /api/runs/<run>/stage2/queue")]


def s3_col(n, cid, label, what, why, sources, js_text, screen_text, example="", sel=None):
    return el("s3-col-" + cid, "S3", "Defects table · columns", label, "display",
              sel or "#inc-table tbody tr:first-child td:nth-child(%d)" % n, what, why, "",
              sources + incidents_tail(st("browser", js_text, INC_RENDER), screen_text), example=example)


def s3_chip(n, cid, label, what, why, when, sources, example=""):
    return el("s3-chip-" + cid, "S3", "Chips", label, "display", "#inc-chips .chip:nth-child(%d)" % n, what, why, when,
              sources + [st("browser", "enter() counts the rows by verdict word and draws the chips.",
                            js(INCJ, 'const chips = [["defects found", INC.length]', 2)),
                         st("screen", "The chip \"%s\"." % label)], example=example)


ELEMENTS += [
    el("s3-title", "S3", "What you see", "All defects found in this trace", "display", "#page-incidents h2",
       "The heading of step 3 and the paragraph under it: defects are numbered 1, 2, 3 … in the order the analyser met "
       "them; error types are entries of the catalogue of 485 known error types, the letter being the chapter.",
       "The same numbering and vocabulary as step 2, explained where the table starts.",
       "Shown on step 3.",
       page_static("<h2 style=\"margin:0\">All defects found in this trace</h2>", "the step 3 card")),

    s3_chip(1, "defects", "defects found", "The number of rows: every defect of the run.",
            "The size of the list before filtering.", "",
            incidents_tail(st("browser", "INC = the defect rows.", js(INCJ, "INC = await api(\"GET\", `/api/runs/${S.run}/incidents`)", 1)),
                           "")[:-1][:5],
            example='3 for run run-20261026-145008-0220.'),
    s3_chip(2, "confirmed", "Confirmed", "How many defects have the verdict Confirmed.",
            "Confirmed defects are proven on the packets alone and can go straight to stage 2.", "",
            incidents_tail(st("browser", "", INC_RENDER), "")[:4], example='2 for run run-20261026-145008-0220.'),
    s3_chip(3, "suspect", "Suspect", "How many defects have the verdict Suspect (a rule fired but the proof is "
            "incomplete, or the AI reviewer disputed it).",
            "Suspect defects need a person to check the packets by hand.", "",
            incidents_tail(st("browser", "", INC_RENDER), "")[:4], example='0 for run run-20261026-145008-0220.'),
    s3_chip(4, "needs", "Needs evidence", "How many defects have the verdict Needs evidence (the packets show only a "
            "symptom).",
            "These defects need host evidence (kernel log, tool records) before they can be proven.", "",
            incidents_tail(st("browser", "", INC_RENDER), "")[:4], example='1 for run run-20261026-145008-0220.'),
    s3_chip(5, "decided", "decided", "How many defects already have a stage-2 decision.",
            "Shows how much of the review is done, next to the verdict counts.", "Only after stage 2 was started.",
            [st("files", "runs/<run>/stage2/INC-*.json: the last decision of each defect.", py(S2SVC, "Stage2Service.state"))]
            + QUEUE_STEP, example='3 for run run-20261026-145008-0220.'),
    s3_chip(6, "admitted", "regression tests admitted", "How many defects ended with an admitted regression test.",
            "The end product of the loop: tests that guard against the defect coming back.", "Only after stage 2 was started.",
            [st("files", "runs/<run>/stage2/INC-*.json: last.admitted.", py(S2SVC, "Stage2Service.state"))] + QUEUE_STEP,
            example='2 for run run-20261026-145008-0220.'),

    el("s3-note", "S3", "What you see", "Click a row to open it in stage 2 (reproduce and decide).", "display", "#inc-note",
       "One line under the paragraph. After stage 2 has started: \"Click a row to open it in stage 2 (reproduce and "
       "decide).\" Before: \"Stage 1 is complete. Stage 2 (knowledge base lookup, AI reviewer proposal, your decisions, "
       "reproduction on the device, regression tests) has not been started for this run.\"",
       "Explains why the rows are (or are not) clickable.",
       "",
       QUEUE_STEP + [st("browser", "enter() picks the sentence from queue.started.", js(INCJ, '$("inc-note").textContent', 1)),
                     st("screen", "The note line.")]),

    el("s3-filter", "S3", "Filter and button", "Filter", "field", "#inc-filter",
       "A text box: only rows whose text contains what you type stay visible (defect number, error type id or chapter, "
       "title, rule, verdict word, layer, side, AI reviewer word). Upper and lower case do not matter.",
       "Narrows a long list (189 defects in the 4 GB trace) to one error type or one verdict in a keystroke.",
       "Works in the browser only; nothing is sent to the server.",
       [st("you", "You type in the box."),
        st("browser", "Every keystroke redraws the table.", js(INCJ, 'export function init() { $("inc-filter").oninput = render;', 1)),
        st("browser", "render() joins the searchable texts of a row and keeps it only if the typed text occurs.",
           js(INCJ, "const txt = [defectName(i.id)", 2)),
        st("screen", "Only matching rows; \"No defect matches the filter.\" when none.")]),

    el("s3-continue", "S3", "Filter and button", "Continue to stage 2 →", "button", "#btn-review",
       "Opens step 4. Reads \"Continue to stage 2 →\" before stage 2 has started (it leads to the Start stage 2 gate) "
       "and \"Open stage 2 (reproduce and decide) →\" afterwards.",
       "The natural next step after reading the defects.",
       "Always shown on step 3.",
       QUEUE_STEP[1:] + [st("browser", "enter() sets the button text from queue.started.", js(INCJ, '$("btn-review").textContent', 1)),
                         st("you", "You click the button."),
                         st("browser", "show(\"review\").", js(INCJ, '$("btn-review").onclick = () => show("review")', 1)),
                         st("browser", "The review page loads the queue again.", js(REVJ, "export async function enter(incId)", 5)),
                         st("screen", "Step 4: the gate or the review queue.")]),

    s3_col(1, "defect", "Defect", "The defect number in this trace (Defect 1, 2, 3 … in packet order).",
           "Same number as on step 2, the defect page and the report.",
           [st("engine", "isolate() numbers the groups INC-0001, INC-0002 … in packet order.", py(INCID, "isolate"))],
           "Cell 1: defectName(i.id).", "\"Defect 1\"."),
    s3_col(2, "type", "Error type", "The catalogue match in short form (\"T-42 · timeouts and time limits\") and, under "
           "it, the first 80 characters of its title.",
           "Short enough for a table, still with the chapter written out.",
           [st("engine", "Classifier.rank(): best-scoring catalogue card first.", py(ATLAS, "Classifier.rank")),
            st("browser", "errorTypeShort(card).", js(APIJ, "export function errorTypeShort(card)", 1))],
           "Cell 2.", "\"T-42 · timeouts and time limits\" / \"D3hot→D0 transition: access before the 10 ms recovery time\".",
           example='Defect 2 of run run-20261026-145008-0220: "M-020 · timing, evidence-gap and cross-layer failures" / '
                   '"Credit return is too slow for offered load".'),
    s3_col(3, "verdict", "Verdict", "The verdict badge: ✓ Confirmed, ? Suspect or ! Needs evidence.",
           "The fixed three-word vocabulary of the whole application.",
           [st("engine", "_status(): the isolation status of each defect.", py(ISO, "_status")),
            st("service", "incidents_of() turns status and verdict into the word: NEEDS_OUTSIDE_EVIDENCE → Needs "
                          "evidence; DISPUTED or analyser verdict SUSPECT → Suspect; CONFIRMED → Confirmed.",
               py(SVC, "Services.incidents_of", "word = (\"Needs evidence\"", "out.append({\"id\""))],
           "Cell 3: statusPill(status_word).", "The verdict badge."),
    s3_col(4, "where", "Where", "The layer where the defect sits, in words: physical link, data link, transaction, "
           "configuration, NVMe command, NVMe queues, NVMe controller registers, data integrity, power management, host, "
           "the drive, platform (root complex, IOMMU), lab setup, outside the probed link, statistics over the whole "
           "trace, the capture itself.",
           "Tells which specialist should look at it.",
           [st("engine", "isolate(): layer = the layer of the rule of the first abnormal packet.", py(INCID, "isolate"))],
           "Cell 4: where(layer) turns the stored layer id into words with the WHERE word list, which covers every "
           "layer the analyser uses (for example nvme-cmd = NVMe command, data-link = data link).",
           "\"configuration\".",
           example='Defect 1 "configuration"; Defect 2 (stored layer nvme-cmd) "NVMe command".'),
    s3_col(5, "who", "Who", "Which side caused it: host side, device side, or platform, link, test setup.",
           "Decides which team owns the fix.",
           [st("engine", "attribute(): decision rules R0-R10.", py(INCID, "attribute"))],
           "Cell 5: who(origin).", "\"host side\".",
           example='Defect 1 "host side", Defects 2 and 3 "device side" in run run-20261026-145008-0220.'),
    s3_col(6, "packets", "Packets", "The packet range of the defect and, under it, \"rule that fired: <rule id>\" (the "
           "rule of the first abnormal packet).",
           "Lets the operator jump to the packets in the analyzer software and see which rule started it.",
           [st("engine", "isolate(): start_pkt, end_pkt, first_abnormal.rule.", py(INCID, "isolate"))],
           "Cell 6.", "\"37391-37398\" / \"rule that fired: CFG.D0_EARLY\".",
           example='Defect 1: "37391-37398", "rule that fired: CFG.D0_EARLY".'),
    s3_col(7, "ai", "AI reviewer", "The AI reviewer's badge (agrees / not sure) and a second badge saying \"verdict "
           "reused from the cache\" or \"fresh model call\"; \"AI reviewer not run\" when no review exists.",
           "The second opinion and its cost, per defect.",
           [st("files", "runs/<run>/llm_reviews.jsonl: verdict and backend (\"pattern-cache\" = reused).",
               py(PCACHE, "cached_record"))],
           "Cell 7.", "\"AI reviewer agrees\" + \"verdict reused from the cache\".",
           example='Defect 2 of run run-20261026-145008-0220: "AI reviewer not sure" + "verdict reused from the cache".'),
    s3_col(8, "stage2", "Stage 2 state", "After stage 2 has started: the last decision and its result (for example "
           "\"accepted → reproduced\") with a \"regression test\" badge when one was admitted; \"looked up · saved "
           "procedure found / no saved procedure\" when only looked up; \"not yet decided\".",
           "Shows the progress of the review per defect, next to the stage-1 result.",
           [st("files", "runs/<run>/stage2/INC-*.json: presented, view.stored, last {action, status, admitted}.",
               py(S2SVC, "Stage2Service.state"))],
           "Cell 8 (hidden before stage 2 starts): actionWord → statusWord.",
           "\"accepted → reproduced\" + \"✓ regression test\".",
           example='Defect 3 of run run-20261026-145008-0220: "accepted → reproduced ✓ regression test"; Defect 1: '
                   '"sweep → sweep done ✓ regression test".',
           sel="#inc-table tbody tr:first-child td.s2col"),

    el("s3-row", "S3", "Defects table", "(a row of the table)", "row", "#inc-table tbody tr:first-child",
       "After stage 2 has started, clicking a row opens that defect in step 4. Before that the rows are not clickable.",
       "Goes straight from the overview to the decision on one defect.",
       "Clickable only after stage 2 was started.",
       [st("you", "You click a row."),
        st("browser", "show(\"review\", <defect>).", js(INCJ, "if (STARTED) tr.onclick", 1)),
        st("browser", "The review page opens that defect.", js(REVJ, "export async function enter(incId)", 14)),
        st("http", "GET /api/runs/<run>/stage2/queue"),
        st("server", "Queue and states.", py(S2_API, "queue")),
        st("screen", "Step 4 with this defect open.")]),

    el("s3-empty", "S3", "Defects table", "No defect matches the filter.", "display", "#inc-table tbody td.empty",
       "A single row shown when the filter hides every row, or \"No defects were found in this trace.\" when the run has "
       "none.",
       "An empty table must say why it is empty.",
       "Only when no row is shown.",
       [st("you", "You type a filter text that no row contains (or open a run without defects)."),
        st("browser", "render() adds the line when the table is empty.", js(INCJ, "No defect matches the filter.", 1)),
        st("screen", "The single explanatory row.")]),
]

# =====================================================================================================================
# DP - the defect page /defect?run=<run>&inc=<defect>
# =====================================================================================================================
G1, G2, G3, G4 = "1 · What this means", "2 · Where in the trace", "3 · Why it was flagged", "4 · Evidence packets"
G5, G6, G7 = "5 · What usually fixes it", "6 · Related error types", "7 · Stage 2 (reproduce and decide) for this defect"
G8 = "8 · Earlier decisions on this error type"
ISO_FILE = st("files", "runs/<run>/isolation.json: the final record of the defect (written by the report step of stage 1).")
INC_FILE = st("files", "runs/<run>/incidents.json: the analyser's defect (packets, first abnormal finding, findings, "
                       "catalogue candidates, attribution).")
LLM_FILE = st("files", "runs/<run>/llm_reviews.jsonl: the AI reviewer's record for this defect (fresh or reused from "
                       "the cache).")
S2_FILE = st("files", "runs/<run>/stage2/<defect>.json: the stage-2 state (lookup shown, every result, last decision).",
             py(S2SVC, "Stage2Service.state"))


def dp_kv(group, container, n, cid, label, what, why, sources, marker, js_text, screen_text, when="", example="", lines=1,
          code=None):
    return el("dp-%s" % cid, "DP", group, label, "display", "#%s .kv > span:nth-of-type(%d)" % (container, n), what, why,
              when, sources + record_tail(st("browser", js_text, js(DEFJ, marker, lines)), screen_text), code=code,
              example=example)


def dp_llm(n, cid, label, what, why, field, marker, screen_text, example=""):
    return dp_kv(G3, "d-llm", n, "3-ai-" + cid, label, what, why,
                 [st("engine", "The AI reviewer's answer for this defect (field %s), or the reused cached answer." % field,
                     py(LLM, "review_run")), LLM_FILE], marker,
                 "The \"AI reviewer's second opinion\" block, line %d." % n, screen_text,
                 when="Only when a review exists; otherwise the block says \"The AI reviewer was not asked (dry run or "
                      "stand-in).\"", example=example)


ELEMENTS += [
    el("dp-page", "DP", "Header", "Full record of one defect", "display", ".header-bar b",
       "A read-only page with everything about one defect, in the order a newcomer reads it: a header card, then eight "
       "sections (what it means, where, why flagged, evidence packets, what usually fixes it, related error types, "
       "stage 2, earlier decisions). It is opened from \"Open the full record ↗\" in step 2 and loads everything with "
       "one request.",
       "Step 2 shows only a summary; a person who must decide or explain a defect needs every rule, packet and earlier "
       "decision in one place, shareable as one address.",
       "Opened in a new tab; the address names the run and the defect.",
       [st("you", "You click \"Open the full record ↗\" in an opened defect row of step 2."),
        st("http", "GET /defect?run=<run>&inc=<defect>"),
        st("server", "Sends app/static/defect.html.", py(SERVER, "create_app", '@app.get("/defect")', "@app.after_request")),
        st("browser", "main() reads run and inc from the address and asks for the record.", DP_MAIN),
        st("http", "GET /api/runs/<run>/defect/<defect>"),
        st("server", "Reads incidents.json, isolation.json, incident_rows.jsonl, llm_reviews.jsonl, the stage-2 state "
                     "and the knowledge base's earlier decisions, and answers them in reading order.",
           py(S2_API, "defect_record")),
        st("screen", "The header card and the eight sections.")],
       code=[py(S2_API, "defect_record")],
       example="http://127.0.0.1:8077/defect?run=run-20261026-145008-0220&inc=INC-0001"),

    el("dp-sub", "DP", "Header", "Defect 1 · run run-20261026-145008-0220", "display", "#h-sub",
       "The grey text after the page title: the defect number and the run it belongs to.",
       "Several defect pages may be open in tabs; this line says which one this is.",
       "",
       [st("http", "The address: /defect?run=<run>&inc=<defect>"),
        st("browser", "main() writes defectName(inc) and the run id.", js(DEFJ, '$("h-sub").textContent', 1)),
        st("screen", "\"Defect 1 · run run-20261026-145008-0220\".")]),

    el("dp-back", "DP", "Header", "← back to the workflow", "link", '.header-bar a[href="/"]',
       "Goes to the workflow page /. No run is selected there (the link does not name one); use the run selector or "
       "\"open in stage 2\" in section 7 to return to this run.",
       "The page is opened in a new tab; the link gives a way back when the tab was opened alone.",
       "Always shown.",
       [st("you", "You click the link."),
        st("files", "A plain link to / in defect.html.", js(DHTML, '<a href="/">&larr; back to the workflow</a>', 1)),
        st("http", "GET /"),
        st("server", "Sends index.html.", py(SERVER, "create_app", '@app.get("/")', '@app.get("/db")')),
        st("screen", "Step 1 with no run selected.")]),

    el("dp-head-title", "DP", "Header", "Defect 1 · error type T-42 (chapter T = timeouts and time limits, entry 42): "
       "D3hot→D0 transition: access before the 10 ms recovery time", "display", "#d-head h2",
       "The defect number and its error type written out (id, chapter, position, title).",
       "The one line to quote when talking about this defect.",
       "",
       [ISO_FILE] + record_tail(st("browser", "main() writes defectName and errorTypeFull(card, title).",
                                   js(DEFJ, '$("d-head").innerHTML = `<div class=row>', 1)), "The title of the header card."),
       example="As in the label, for INC-0001 of run run-20261026-145008-0220."),

    el("dp-badge", "DP", "Header", "✓ Confirmed", "display", "#d-head .row > .pill",
       "The verdict badge of the defect: Confirmed, Suspect or Needs evidence, derived from the isolation status "
       "(NEEDS_OUTSIDE_EVIDENCE → Needs evidence, DISPUTED → Suspect, every other status → Confirmed).",
       "The same three words as steps 2 and 3, so the verdict reads the same everywhere.",
       "Steps 2 and 3 also turn an analyser verdict SUSPECT into \"Suspect\"; this page does not, so a defect with "
       "status ISOLATED and analyser verdict SUSPECT reads Suspect there and Confirmed here.",
       [st("engine", "_status(): ISOLATED, ISOLATED_WIRE_ONLY, NEEDS_OUTSIDE_EVIDENCE, DISPUTED, SYNTHESISED.",
           py(ISO, "_status")), ISO_FILE] +
       record_tail(st("browser", "WORD(p) chooses the word; statusPill() draws it.", js(DEFJ, "const WORD = (p) =>", 1)),
                   "The badge next to the title."),
       example='Defect 1 of run run-20261026-145008-0220: "✓ Confirmed" (status ISOLATED).'),

    el("dp-meaning", "DP", "Header", "the analyser's rules and the AI reviewer agree: the defect is isolated to these "
       "packets.", "display", "#d-head p.muted",
       "The isolation status as a sentence: \"... agree: the defect is isolated to these packets\", \"isolated from the "
       "packets alone; no second opinion was asked\", \"the packets show only the symptom; proof needs a document from "
       "the host or the lab\", \"the AI reviewer disagreed with the analyser - inspect by hand\".",
       "The verdict word is short; the sentence says what it means for this defect.",
       "",
       [ISO_FILE,
        st("server", "defect_record looks the status up in STATUS_MEANING, the table of sentences.", py(S2_API, "defect_record", 'proof = {"status": status', '"first_abnormal": fa'))] +
       record_tail(st("browser", "main() writes plain(p.status_meaning) (\"the wire\" → \"the packets\").",
                      js(DEFJ, '$("d-head").innerHTML = `<div class=row>', 1)), "The grey sentence."),
       example="As in the label, for INC-0001 of run run-20261026-145008-0220."),

    el("dp-head-help", "DP", "Header", "Defects are numbered 1, 2, 3 … in the order the analyser met them in this trace. "
       "The verdict words: …", "display", "#d-head p.help",
       "A fixed explanation of the numbering and of the three verdict words.",
       "The page can be opened alone from a shared link; it must explain its own words.",
       "",
       [st("files", "The text is fixed in defect.js (not computed).", js(DEFJ, "Defects are numbered 1, 2, 3", 1)),
        st("browser", "main() writes it together with the header once the record has arrived.", js(DEFJ, '$("d-head").innerHTML = `<div class=row>', 1)),
        st("screen", "The small help text of the header card.")]),

    el("dp-missing", "DP", "Header", "Open this page from the workflow (it needs a run and a defect).", "display",
       "#d-head p.empty",
       "Shown instead of the record when the address lacks run= or inc=.",
       "A bare /defect address cannot show anything; the line says how to get a valid one.",
       "Only when run or inc is missing from the address.",
       [st("http", "GET /defect without ?run=...&inc=..."),
        st("browser", "main() stops and writes the line.", js(DEFJ, "if (!RUN || !INC)", 1)),
        st("screen", "The single line.")]),

    # ---------------------------------------------------------------- 1 · What this means
    dp_kv(G1, "d-which", 1, "1-type", "Error type",
          "The error type written out (\"error type T-42 (chapter T = ..., entry 42): <title>\") and \"(one of the "
          "catalogue of 485 known PCIe / NVMe error types)\".",
          "Names the failure in the catalogue's terms, which link it to causes, fixes and earlier decisions.",
          [st("engine", "build(): the error type is the top catalogue candidate, or the AI reviewer's pick when it chose "
                        "another of the top three; the title is always the top candidate's.", py(ISO, "build")), ISO_FILE],
          '$("d-which").innerHTML = kv([["Error type"', "Line 1 of section 1.", "The error type line.",
          when="When the AI reviewer picked a lower-ranked candidate, this line names that candidate with the top "
               "candidate's title, while steps 2 and 3 and stage 2 use the top candidate.",
          code=[py(ISO, "build", 'chosen = top["card_id"] if top else None', "status = _status(inc, r, bool(wire), simulated_host)"),
                py(SVC, "Services.incidents_of", 'c = (i.get("atlas_candidates") or [{}])[0]', "r = reviews.get(i[\"id\"]) or {}")],
          example='Run run-20261026-121711-1a46 (4 GB trace), Defect 1: steps 2/3 say "L-31 · BAR not assigned ..."; '
                  'this page says "error type L-20 ...: BAR not assigned / resource conflict ...". 53 of its 189 defects '
                  'differ this way.'),
    dp_kv(G1, "d-which", 2, "1-family", "Error family (how it shows on the wire)",
          "The error family written out, for example \"configuration space, power state and reset sequencing (family "
          "P19)\": one of 27 ways a failure shows on the link.",
          "Families group error types that look alike on the packets; the verdict cache and the stage-2 lookup use them.",
          [st("engine", "The family is the first \"P..\" pattern of the catalogue card.", py(ATLAS, "load_cards")), ISO_FILE,
           st("browser", "familyName() writes the family name.", js(APIJ, "export function familyName(p)", 1))],
          '["Error family (how it shows on the wire)"', "Line 2 of section 1.", "The family line.",
          example='"configuration space, power state and reset sequencing (family P19)" for INC-0001.'),
    dp_kv(G1, "d-which", 3, "1-where", "Where",
          "The layer where the defect sits, in words (configuration, transaction, physical link, NVMe command, NVMe "
          "queues, NVMe controller registers, data integrity, the drive, platform (root complex, IOMMU), lab setup, ...).",
          "Points to the part of the specification and the team concerned.",
          [st("engine", "isolate(): layer of the rule of the first abnormal packet.", py(INCID, "isolate")), ISO_FILE],
          '["Where", esc(where(b.layer))]', "Line 3 of section 1: where() turns the stored layer id into words; the "
          "word list covers every layer the analyser uses (nvme-cmd = NVMe command, data-link = data link …).",
          "\"configuration\".",
          example='"configuration" for INC-0001.'),
    dp_kv(G1, "d-which", 4, "1-who", "Who",
          "Which side caused it, in bold, then \"(decided by rule <R-rule and its text>; the catalogue entry itself says: "
          "<the card's hint>)\".",
          "Attribution decides who must act; showing the deciding rule and the catalogue's own hint lets a reader check "
          "it.",
          [st("engine", "attribute(): decision procedure R0-R10; card_badge = the catalogue card's origin hint.",
              py(INCID, "attribute")), ISO_FILE],
          '["Who", `<b>${esc(who(p.attribution.origin))}</b>', "Line 4 of section 1.", "The Who line.",
          example='"host side (decided by rule R4 transmitter of the first bad TLP (Downstream); the catalogue entry '
                  'itself says: Either side)" for INC-0001.'),
    dp_kv(G1, "d-which", 5, "1-verdict", "Verdict",
          "The verdict badge again, followed by the status sentence.",
          "Keeps verdict and meaning together inside the section a reader starts with.",
          [st("engine", "_status()", py(ISO, "_status")), ISO_FILE],
          '["Verdict", `${statusPill(WORD(p))}', "Line 5 of section 1.", "The Verdict line.",
          example='"✓ Confirmed the analyser\'s rules and the AI reviewer agree: the defect is isolated to these packets".'),

    # ---------------------------------------------------------------- 2 · Where in the trace
    dp_kv(G2, "d-where", 1, "2-packets", "Packets",
          "The packet range of the defect and, in brackets, the line numbers in the CSV file (the header is line 1).",
          "Packet numbers find the defect in the analyzer software; line numbers find it in the exported file.",
          [st("engine", "isolate(): start_pkt, end_pkt and csv_lines from one pass over the CSV.", py(INCID, "isolate")),
           INC_FILE, ISO_FILE],
          '$("d-where").innerHTML = kv([["Packets"', "Line 1 of section 2.", "\"37391 - 37398 (CSV lines 37393 - 37400)\".",
          example='"37391 - 37398 (CSV lines 37393 - 37400)" for INC-0001.'),
    dp_kv(G2, "d-where", 2, "2-time", "Time",
          "The analyzer time stamps of the first and last packet of the defect.",
          "Lets a host log or a scope capture be lined up with the defect by time.",
          [st("engine", "isolate(): start_time / end_time = the Time Stamp column of those packets.", py(INCID, "isolate")),
           ISO_FILE],
          '["Time", `<span class=mono>${esc(w.start_time', "Line 2 of section 2.", "\"0000.644644710750s - 0000.646645924750s\".",
          example='"0000.644644710750s - 0000.646645924750s" for INC-0001.'),
    dp_kv(G2, "d-where", 3, "2-first", "First abnormal packet",
          "The first packet where normal traffic stops being normal, with the rule that fired there (its detail text and "
          "rule id).",
          "Rule R1 of the attribution: the first anomalous packet, not the loudest one, points at the cause.",
          [st("engine", "isolate(): first_abnormal = the earliest defect finding on the wire (host lines only "
                        "corroborate).", py(INCID, "isolate")), ISO_FILE],
          '["First abnormal packet", ', "Line 3 of section 2.",
          "\"#37395 · rule that fired: MMIO read 0x1C 2.000 ms after D3hot->D0 (CFG.D0_EARLY)\".",
          example='"#37395 · rule that fired: MMIO read 0x1C 2.000 ms after D3hot->D0 (CFG.D0_EARLY)".'),
    dp_kv(G2, "d-where", 4, "2-root", "Root cause packet",
          "The root of the defect's evidence graph: the first finding that no other finding of the defect causes "
          "(following the published cause → effect chains, for example a link error causing replays).",
          "Separates the cause from its knock-on effects, which is what a fix must target.",
          [st("engine", "evidence_graph(): SAME_KEY and CAUSES links; the root has no incoming CAUSES link.",
              py(INCID, "evidence_graph")), ISO_FILE],
          '["Root cause packet", ', "Line 4 of section 2.", "\"#37395 · MMIO read 0x1C 2.000 ms after D3hot->D0 (CFG.D0_EARLY)\".",
          example='Packet #37395 (the same as the first abnormal packet) for INC-0001.'),
    dp_kv(G2, "d-where", 5, "2-evidence", "Evidence packets",
          "The key packets of the defect (at most 20): every packet a finding fired on or pointed to, inside the defect's "
          "range.",
          "The packets a reviewer should look at first.",
          [st("engine", "isolate(): key_pkts; build() keeps the first 20 as evidence_pkts.", py(INCID, "isolate")), ISO_FILE],
          '["Evidence packets", ', "Line 5 of section 2.", "\"37391, 37395, 37398\".",
          example='"37391, 37395, 37398" for INC-0001.'),

    # ---------------------------------------------------------------- 3 · Why it was flagged
    el("dp-3-help", "DP", G3, "Each rule the analyser checked, with the packet it fired on and the values seen. The first "
       "abnormal packet is where normal traffic stops being normal.", "display", ".card:has(> #d-rules) > p.help",
       "The fixed explanation at the top of section 3.",
       "Tells the reader how to read the rule checklist below.",
       "",
       page_static("<h2>3 · Why it was flagged</h2>", "section 3", path=DHTML)),

    el("dp-3-rule", "DP", G3, "CFG.D0_EARLY  ·  MMIO read 0x1C 2.000 ms after D3hot->D0", "row",
       "#d-rules table.checklist tbody tr:first-child",
       "One row per rule that fired for the defect (at most 12): the rule id in bold, its role and the AI reviewer's "
       "view as badges, the detail text with the values seen, and the packet and CSV line it fired on.",
       "The verdict rests on these rules; each is listed with the exact packet so it can be checked by hand.",
       "\"No rule details recorded.\" when the list is empty.",
       [st("engine", "The analyser's rule fired and recorded (rule, packet, detail).", py(ENGINE, "Engine.emit")),
        st("engine", "build(): evidence = the defect's first 12 defect findings with rule, verdict, packet, CSV line, "
                     "role, detail, AI view and rows.", py(ISO, "build")), ISO_FILE] +
       record_tail(st("browser", "main() writes one checklist row per rule.", js(DEFJ, "<table class=checklist>", 1)),
                   "The rule checklist."),
       example='INC-0001: CFG.D0_EARLY (packet #37395, CSV line 37397), TLP.CPL_STATUS (#37398), S.RARE_WINDOW (#37398).'),

    el("dp-3-mark", "DP", G3, "✓ / ?", "display", "#d-rules table.checklist tbody tr:first-child td.st",
       "The mark in front of each rule: ✓ when the rule's own verdict is CONFIRMED (it proves a defect), ? for a "
       "suspect-only rule (for example a whole-trace statistical outlier).",
       "Not every rule is proof; the mark separates proving rules from hints.",
       "",
       [st("files", "stage1/pcie_isolate/rules.py: the rule table gives each rule its verdict (CONFIRMED, SUSPECT, "
                    "ARTEFACT, UNKNOWN)."), ISO_FILE] +
       record_tail(st("browser", "✓ for CONFIRMED, ? otherwise.", js(DEFJ, "<table class=checklist>", 1)), "The mark."),
       example='INC-0001: ✓ CFG.D0_EARLY, ✓ TLP.CPL_STATUS, ? S.RARE_WINDOW.'),

    el("dp-3-role", "DP", G3, "root cause", "display",
       "#d-rules table.checklist tbody tr:first-child td:nth-child(2) > span.pill:nth-of-type(1)",
       "The role of the rule in the defect: \"root cause\", \"knock-on effect\" (caused by an earlier finding), "
       "\"separate finding\" or \"context only\".",
       "A fix must target the root cause; knock-on effects disappear with it.",
       "",
       [st("engine", "isolate(): role() - root of the evidence graph, cascade when a CAUSES link points to it, else "
                     "independent; context findings are context.", py(INCID, "isolate")), ISO_FILE] +
       record_tail(st("browser", "ROLE turns the role id into words.", js(DEFJ, "const ROLE = {", 1)), "The role badge."),
       example='INC-0001: CFG.D0_EARLY "root cause", TLP.CPL_STATUS "knock-on effect", S.RARE_WINDOW "separate finding".'),

    el("dp-3-ai-rule", "DP", G3, "AI reviewer agrees", "display",
       "#d-rules table.checklist tbody tr:first-child td:nth-child(2) > span.pill:nth-of-type(2)",
       "The AI reviewer's view of this one rule: \"AI reviewer agrees\" (green), \"AI reviewer disagrees\", \"AI "
       "reviewer unchecked\" or \"AI reviewer not reviewed\" (yellow).",
       "The second opinion is checked rule by rule, so a disagreement points at the exact rule.",
       "",
       [st("engine", "build(): confirmed if the rule is in the review's rules_confirmed, refuted if in rules_refuted, "
                     "else unchecked; not reviewed without a review.", py(ISO, "build")), LLM_FILE, ISO_FILE] +
       record_tail(st("browser", "The per-rule badge.", js(DEFJ, "<table class=checklist>", 1)), "The AI badge of the rule."),
       example='All three rules of INC-0001: "AI reviewer agrees".'),

    el("dp-3-packet", "DP", G3, "packet #37395, CSV line 37397", "display",
       "#d-rules table.checklist tbody tr:first-child td:nth-child(2) > div.mono",
       "The packet number the rule fired on and its line in the CSV file.",
       "The exact place to check the rule by hand.",
       "",
       [st("engine", "isolate(): every finding keeps its packet and CSV line.", py(INCID, "isolate")), ISO_FILE] +
       record_tail(st("browser", "Written under the detail text.", js(DEFJ, "<table class=checklist>", 1)), "The packet line."),
       example='"packet #37395, CSV line 37397" for CFG.D0_EARLY of INC-0001.'),

    el("dp-3-carry", "DP", G3, "packets that carry it", "link",
       "#d-rules table.checklist tbody tr:first-child details > summary",
       "A fold-out under each rule with the packet rows that carry it (the packet it fired on and up to three related "
       "packets), field by field as in the export.",
       "The proof of a rule is in these few rows; showing them saves searching the trace.",
       "Closed by default; shown only when rows were stored for the rule.",
       [st("you", "You click \"packets that carry it\"."),
        st("files", "runs/<run>/incident_rows.jsonl: the rows around the defect and its key rows."),
        st("engine", "_rows_for(): the stored rows of the rule's packets (at most 4).", py(ISO, "_rows_for")), ISO_FILE] +
       record_tail(st("browser", "A details box per rule; the page shows at most 6 rows.", js(DEFJ, "packets that carry it", 1)),
                   "The rows of that rule."),
       example='For CFG.D0_EARLY of INC-0001: "Packet=37391 | Link Dir=Downstream | TLP Type=CfgWr0 | ... | Register=0x044 '
               '..." and "Packet=37395 | ... TLP Type=MRd(32) | ... Address=FCE0001C ...".'),

    el("dp-3-proof", "DP", G3, "Proof checks: ✓ capture context given · ✓ knock-on effects separated by the analyser · …",
       "display", "#d-rules > div.muted.small",
       "Eight yes/no checks of the conclusion, each ✓ or ✗: capture context given, every claim cites a packet that was "
       "shown, knock-on effects separated by the analyser, first abnormal packet identified, other explanations labelled "
       "as such, reproduced by the analyser on the full file, root cause and knock-on effects cited from shown packets, "
       "a rule is named.",
       "An AI-assisted conclusion is accepted only if these checks pass (the acceptance test for an AI conclusion); "
       "they are evaluated mechanically, not by the model.",
       "Only when the record carries the checks.",
       [st("engine", "build(): the acceptance block (some checks are fixed true, the others are computed from the "
                     "review).", py(ISO, "build", '"acceptance": {', "out.append(rec)")), ISO_FILE] +
       record_tail(st("browser", "CHECK turns each check id into words.", js(DEFJ, "Proof checks: ", 1)), "The proof line."),
       example='All eight checks are ✓ for INC-0001.'),

    el("dp-3-host", "DP", G3, "Host evidence", "display", "#d-outside",
       "Whether host evidence was needed: \"No host evidence was needed: the packets alone prove this error.\", or "
       "\"Host evidence was needed and was taken from the host:\" with one panel per host line (source, packet, text, why "
       "this source), or \"Host evidence is needed - the packets show only the symptom.\", then \"Still to collect: "
       "...\".",
       "The defects that leave no trace in the packets can only be proven with host documents; the section says which "
       "line proved it or what is still missing.",
       "",
       [st("engine", "fuse() places host lines on the packet axis; build() attaches up to 6 of them to the defect.",
           py(HOST, "fuse")),
        st("engine", "attribute(): the list of evidence to collect (for example \"E03 nvme error-log with the same "
                     "SQID+CID\").", py(INCID, "attribute")), ISO_FILE] +
       record_tail(st("browser", "main() writes the section.", js(DEFJ, '$("d-outside").innerHTML', 3)), "The Host evidence part."),
       example='"No host evidence was needed: the packets alone prove this error." for INC-0001.'),

    dp_llm(1, "verdict", "Verdict", "The AI reviewer's verdict on the defect: agrees, not sure, or disagrees (a NOT_CONFIRMED, REFUTED or "
           "DISPUTED answer).", "The headline of the second opinion.", "verdict",
           '$("d-llm").innerHTML = rv.verdict ? kv([["Verdict"', "\"AI reviewer agrees\".",
           example='"AI reviewer agrees" for INC-0001.'),
    dp_llm(2, "source", "Source", "Where the verdict came from: \"verdict reused from the cache (no model call) - the "
           "same error family was confirmed in an earlier run\", or \"fresh model call: <model> via <backend>\".",
           "A reused verdict was given on another trace; the reader must know.", "backend, model",
           '["Source", rv.backend', "The Source line.",
           example='"verdict reused from the cache (no model call) ..." for INC-0001.'),
    dp_llm(3, "type", "Error type the AI reviewer picked", "The catalogue error type the AI reviewer chose among the "
           "candidates, in short form.", "Shows whether the model agrees with the analyser's match.", "card_id",
           '["Error type the AI reviewer picked"', "\"T-42 · timeouts and time limits\".",
           example='"T-42 · timeouts and time limits" for INC-0001.'),
    dp_llm(4, "who", "Who, in the AI reviewer's view", "The side the AI reviewer blames: host side, device side, "
           "platform, link, test setup or undetermined.", "A second view of the attribution.", "responsible",
           '["Who, in the AI reviewer\'s view"', "\"host side\".", example='"host side" for INC-0001.'),
    dp_llm(5, "agrees", "Rules it agrees with", "The rule ids the AI reviewer says the rows really show.",
           "Ties the agreement to specific rules.", "rules_confirmed",
           '["Rules it agrees with"', "\"CFG.D0_EARLY, TLP.CPL_STATUS, S.RARE_WINDOW, REG.CTRL_RESET\".",
           example='"CFG.D0_EARLY, TLP.CPL_STATUS, S.RARE_WINDOW, REG.CTRL_RESET" for INC-0001.'),
    dp_llm(6, "disagrees", "Rules it disagrees with", "The rule ids the AI reviewer says the rows contradict "
           "(\"-\" when none).", "A disagreement on one rule points at a possible false alarm.", "rules_refuted",
           '["Rules it disagrees with"', "\"-\".", example='"-" for INC-0001.'),
    dp_llm(7, "packets", "Packets it cites", "The packet numbers the AI reviewer's answer cites (for a reused verdict: "
           "this defect's key packets).",
           "Every claim of the model must point at a packet that was shown to it.", "evidence_pkts",
           '["Packets it cites"', "\"37395, 37398, 37400\".", example='"37395, 37398, 37400" for INC-0001.'),
    dp_llm(8, "summary", "Summary", "The AI reviewer's full explanation, as OBSERVED / RULE / HYPOTHESIS statements "
           "citing packets.", "The reasoning in full, so a person can follow or reject it.", "summary",
           '["Summary", esc(plain(rv.summary', "The summary text.",
           example='Begins "OBSERVED: CfgWr at #37387 sets PMCSR (reg 0x044) to D3hot (data 03), and CfgWr at #37391 sets '
                   'it to D0 (data 00) ..." for INC-0001.'),
    dp_llm(9, "other", "Other explanations it considered", "The alternative explanations the AI reviewer labelled as "
           "hypotheses, separated by \" | \".", "Labelled hypotheses keep guesses apart from observations.", "hypotheses",
           '["Other explanations it considered"', "The hypotheses.",
           example='"HYPOTHESIS: the device was still in its D3hot-to-D0 wake-up window at 37395 ..." for INC-0001.'),
    dp_llm(10, "needs", "What it would still need", "What the AI reviewer says would make the conclusion certain (for "
           "example a host log around the transition).", "Tells the operator which document to collect next.", "needs",
           '["What it would still need"', "The list of missing evidence.",
           example='"Host driver or kernel log around the D3hot->D0 transition showing whether a delay was applied ..." '
                   'for INC-0001.'),

    # ---------------------------------------------------------------- 4 · Evidence packets
    el("dp-4-rows", "DP", G4, "CSV ROWS 37376..37413", "display", "#d-rows",
       "The trace rows around the defect, one per line, field by field (\"Packet=37376 | Link Dir=Upstream | DLLP "
       "Type=ACK | ... | Line=37378\"), in blocks headed \"CSV ROWS <from>..<to>\": 15 rows before and after the defect "
       "(two windows for a long defect), as the analyser and the AI reviewer saw them.",
       "The reviewer, human or AI, must judge on the same rows; nothing is summarised away.",
       "",
       [st("files", "The analyzer CSV (and payload sidecar)."),
        st("engine", "isolate(): one extra pass collects the rows of each window and the key rows into "
                     "incident_rows.jsonl.", py(INCID, "isolate")),
        st("files", "runs/<run>/incident_rows.jsonl: blocks [{range, rows}] per defect.")] +
       record_tail(st("browser", "main() writes \"CSV ROWS a..b\" and the rows of each block.", js(DEFJ, "const rows = []; for (const bl of d.rows)", 2)),
                   "The dark box of rows."),
       example='INC-0001: one block "CSV ROWS 37376..37413" with 38 rows.'),

    # ---------------------------------------------------------------- 5 · What usually fixes it
    dp_kv(G5, "d-why", 1, "5-mechanism", "Mechanism",
          "What happens in the failure, from the catalogue entry (field \"What happens\").",
          "Explains the failure in specification terms to someone who has not met it.",
          [st("files", "data/: the catalogue of 485 cards (atlas_cards_raw.json)."),
           st("engine", "enrich(): the card's texts; isolate() stores them as explanation.", py(ATLAS, "enrich")), ISO_FILE],
          '$("d-why").innerHTML = kv([["Mechanism"', "Line 1 of section 5.", "The mechanism text.",
          example='"After writing PowerState=D0 in the PM capability of a function that was in D3hot, software must wait '
                  '10 ms before accessing it ..." for INC-0001.'),
    dp_kv(G5, "d-why", 2, "5-causes", "Typical causes",
          "The usual causes, from the card (\"Typical causes\" or \"Why it occurs\").",
          "Gives the investigator a short list of suspects.",
          [st("engine", "enrich(): why = Typical causes, else Why it occurs.", py(ATLAS, "enrich")), ISO_FILE],
          '$("d-why").innerHTML = kv([["Mechanism"', "Line 2 of section 5.", "The causes text.",
          example='"Device firmware needs longer than 10 ms; platform-specific slowness; driver skipping the wait."'),
    dp_kv(G5, "d-why", 3, "5-shows", "How it shows up",
          "How the failure appears to the host and in the trace, from the card.",
          "Helps recognise the same failure elsewhere.",
          [st("engine", "enrich(): How it shows up.", py(ATLAS, "enrich")), ISO_FILE],
          '$("d-why").innerHTML = kv([["Mechanism"', "Line 3 of section 5.", "The text.",
          example='"Config reads return garbage or all-ones; MMIO reads time out (T-33); the NVMe driver sees '
                  'CSTS=0xffffffff on resume ..."'),
    dp_kv(G5, "d-why", 4, "5-spec", "Specification reference",
          "The specification clause the rule rests on, from the card (\"Spec basis\").",
          "Every rule must be traceable to a specification, not to an opinion.",
          [st("engine", "enrich(): spec_basis.", py(ATLAS, "enrich")), ISO_FILE],
          '$("d-why").innerHTML = kv([["Mechanism"', "Line 4 of section 5.", "The reference.",
          example='"PCI Power Management: D3hot→D0 recovery time 10 ms; "No Soft Reset" bit determines whether state '
                  'is preserved."'),
    dp_kv(G5, "d-why", 5, "5-fix", "What usually fixes it",
          "The card's action text: the first non-empty of its fields \"Test to provoke it\" and \"Corrective / "
          "validation action\".",
          "Points the owner of the defect at a next step.",
          [st("engine", "enrich(): fix_or_test = Test to provoke it, else Corrective / validation action.",
              py(ATLAS, "enrich")), ISO_FILE],
          '$("d-why").innerHTML = kv([["Mechanism"', "Line 5 of section 5.", "The action text.",
          when="For 383 of the 485 cards the field \"Test to provoke it\" exists, so this line shows how to provoke the "
               "error rather than how to fix it.",
          example='"Runtime PM: echo auto > /sys/bus/pci/devices/BDF/power/control and idle the device; measure resume. '
                  'SAFE." for INC-0001 (the card\'s "Test to provoke it").'),
    dp_kv(G5, "d-why", 6, "5-prove", "How to prove the fix",
          "The card's \"How to detect / prove\" (or \"How to detect / measure\") text.",
          "A fix is accepted only when it can be shown that the error no longer occurs.",
          [st("engine", "enrich(): how_to_prove.", py(ATLAS, "enrich")), ISO_FILE],
          '$("d-why").innerHTML = kv([["Mechanism"', "Line 6 of section 5.", "The text.",
          example='"dmesg with PM debug; analyzer: CfgWr to PMCSR (D0) followed by CfgRd sooner than 10 ms, answered '
                  'badly."'),

    # ---------------------------------------------------------------- 6 · Related error types
    dp_kv(G6, "d-related", 1, "6-scored", "Error types the analyser scored",
          "The three best catalogue matches, one per line: short error type, \"match <score>\" and the first 60 "
          "characters of the title. The score is the similarity of the defect's rule pattern to the card's learned "
          "signature, weighted by the error-family vote.",
          "Shows how clear the match was: a close second candidate means the error type should be checked.",
          [st("engine", "Classifier.rank(): score = similarity × (0.85 + 0.15 × family share).", py(ATLAS, "Classifier.rank")),
           INC_FILE],
          '$("d-related").innerHTML = kv([["Error types the analyser scored"', "Line 1 of section 6.", "Three lines.",
          example='INC-0001: "T-42 · timeouts and time limits · match 0.66", "L-31 · ... · match 0.37", "L-36 · ... · match 0.22".'),
    dp_kv(G6, "d-related", 2, "6-alt", "Alternatives kept in mind",
          "The second and third candidates (short form), or \"none\".",
          "If the first match is wrong, these are the next suspects.",
          [st("engine", "build(): alternatives = candidates 2 and 3.", py(ISO, "build")), ISO_FILE],
          '["Alternatives kept in mind"', "Line 2 of section 6.", "\"L-31 · PCIe link and transaction errors, L-36 · ...\".",
          example='"L-31 · PCIe link and transaction errors, L-36 · PCIe link and transaction errors" for INC-0001.'),
    dp_kv(G6, "d-related", 3, "6-twins", "Cannot be told apart from the packets alone",
          "Error types whose packet signature is identical to the chosen one, or \"none\".",
          "Some failures look the same on the link; only host evidence or a lab run can separate them.",
          [st("engine", "Classifier.rank(): equally_consistent_with = twins in the signature library.", py(ATLAS, "Classifier.rank")),
           ISO_FILE],
          '["Cannot be told apart from the packets alone"', "Line 3 of section 6.", "\"none\".",
          example='"none" for INC-0001.'),

    # ---------------------------------------------------------------- 7 · Stage 2
    dp_kv(G7, "d-stage2", 1, "7-seen", "Seen before",
          "The knowledge-base lookup's answer: whether this defect was seen before and whether a saved procedure "
          "applies.",
          "A known defect reuses its saved procedure; a new one gets a proposed procedure.",
          [st("engine", "The stage-2 lookup writes the label of the card shown to you.", py(S2SVC, "Stage2Service.present")),
           S2_FILE],
          '["Seen before", ', "Line 1 of section 7.", "The label.",
          when="\"Stage 2 has not been started for this run.\" before Start stage 2; \"Not looked up yet.\" before the "
               "lookup. The label is the one saved at lookup time, in the wording of that time.",
          example='INC-0001 shows "YES - same defect seen before in this context; stored procedure applies" (saved by an '
                  'earlier version; the current wording is "Seen before on this firmware - the saved procedure applies").'),
    dp_kv(G7, "d-stage2", 2, "7-saved", "Saved procedure",
          "The procedure saved in the knowledge base for this error type: the command steps and, under them, queue "
          "depth, µs between commands, KB block size, burst, idle ms and power state; \"none\" without one.",
          "The saved procedure is tried first: it already reproduced the defect once.",
          [S2_FILE, st("browser", "seq() draws steps and timing.", js(APIJ, "export function seq(x, diffAgainst = null)", 3))],
          '["Saved procedure", ', "Line 2 of section 7.", "\"flush → write\" and its timing line.",
          example='INC-0001: timing "queue depth 8 · 200 µs between commands · 4 KB · burst 16 · idle 1866 ms · power none".'),
    dp_kv(G7, "d-stage2", 3, "7-proposal", "AI reviewer's proposal",
          "The procedure the AI reviewer proposed from this defect's evidence, in the same form.",
          "The model's seed scenario, which the search then optimises.",
          [S2_FILE, st("browser", "seq() draws it.", js(APIJ, "export function seq(x, diffAgainst = null)", 3))],
          '["AI reviewer\'s proposal"', "Line 3 of section 7.", "\"aspm_idle → read\" and its timing line.",
          example='INC-0001: "aspm_idle → read", "queue depth 1 · 2000 µs between commands · 4 KB · burst 1 · idle 2 ms · '
                  'power D3hot".'),
    dp_kv(G7, "d-stage2", 4, "7-decision", "Decision",
          "The last decision and its result (\"accepted → reproduced\"), with \"✓ regression test admitted\" when a test "
          "was admitted; \"none yet\".",
          "The outcome of the loop for this defect.",
          [st("service", "Each decision's result is appended to the state file; last = the latest.",
              py(S2SVC, "Stage2Service._record")), S2_FILE],
          '["Decision", last ?', "Line 4 of section 7: actionWord → statusWord.", "The decision line.",
          example='INC-0001 currently shows "sweep → sweep done ✓ regression test admitted".'),
    el("dp-7-link", "DP", G7, "open in stage 2 (reproduce and decide) →", "link", "#d-stage2 p a",
       "Opens the workflow page with this run selected and this defect open in step 4.",
       "Goes from reading to deciding without searching for the run and the defect.",
       "Shown once the defect has been looked up in stage 2.",
       [st("you", "You click the link."),
        st("browser", "The link carries the run in the query and the defect in the hash: /?run=<run>#review/<defect>.",
           js(DEFJ, "open in stage 2 (reproduce and decide)", 1)),
        st("http", "GET /?run=<run>"),
        st("browser", "At start-up main.js selects the run named in ?run= and routes to #review/<defect>.",
           js(MAIN, "const wanted = new URLSearchParams", 5)),
        st("http", "GET /api/runs/<run>/stage2/queue"),
        st("server", "Queue and states.", py(S2_API, "queue")),
        st("screen", "Step 4 with this defect open.")]),

    # ---------------------------------------------------------------- 8 · Earlier decisions
    el("dp-8-table", "DP", G8, "When · Who · Decision · Note · Outcome", "table", "#d-history table",
       "Every decision ever recorded on this error type, from any run, newest first (at most 50). \"No decision recorded "
       "for this error type yet.\" when none.",
       "Earlier judgements on the same error type are the best guide for the current one, and the audit trail of who "
       "decided what.",
       "",
       [st("database", "db/knowledge.sqlite table event: admin_action and script_gate events (never edited; undone "
                       "ones are skipped)."),
        st("service", "feedback_history(): each decision paired with the next lab-check result of the same error type.",
           py(S2SVC, "Stage2Service.feedback_history"))] +
       record_tail(st("browser", "hist() draws the table.", js(DEFJ, "const hist = (h) =>", 1)), "The history table."),
       code=[py(S2SVC, "Stage2Service.feedback_history")],
       example='50 rows are shown for error type T-42 (INC-0001).'),
    el("dp-8-when", "DP", G8, "When", "display", "#d-history table tbody tr:first-child td:nth-child(1)",
       "Local date and time the decision was recorded.", "Traceability: when it was decided.",
       "On this page the cell holds the date and time only; the Earlier decisions table of step 4 (All details) also "
       "shows \"#<event number>\" there, the number Undo asks for.",
       [st("database", "db/knowledge.sqlite table event: ts"),
        st("service", "feedback_history(): when = ts.", py(S2SVC, "Stage2Service.feedback_history"))] +
       record_tail(st("browser", "new Date(when).toLocaleString().", js(DEFJ, "const hist = (h) =>", 1)), "The date."),
       example='"10/27/2026, 10:52:02 AM" style (browser locale).'),
    el("dp-8-who", "DP", G8, "Who", "display", "#d-history table tbody tr:first-child td:nth-child(2)",
       "Who made the decision (the actor of the event).", "Traceability: who decided.", "",
       [st("database", "db/knowledge.sqlite table event: actor"),
        st("service", "feedback_history(): actor.", py(S2SVC, "Stage2Service.feedback_history"))] +
       record_tail(st("browser", "esc(actor).", js(DEFJ, "const hist = (h) =>", 1)), "The name."),
       example='"admin" and "tester one" appear for T-42.'),
    el("dp-8-decision", "DP", G8, "Decision", "display", "#d-history table tbody tr:first-child td:nth-child(3)",
       "The decision in words, with + (green) for positive ones (accepted, promoted, procedure or cause added), − (red) "
       "for negative ones (rejected, not reproducible, wrong signature, deletions, a \"NOT CORRECT\" lesson), plain for "
       "the rest (sweep, compose tests, ...).",
       "Positive and negative judgements are what the knowledge base learns from.",
       "",
       [st("database", "db/knowledge.sqlite table event: payload.action"),
        st("service", "feedback_history(): polarity from the action.", py(S2SVC, "Stage2Service.feedback_history"))] +
       record_tail(st("browser", "actionWord() and the polarity sign.", js(DEFJ, "const ACTION_WORD = {", 1)), "The decision badge."),
       example='"sweep", "compose tests", "+ accepted", "+ procedure added" for T-42.'),
    el("dp-8-note", "DP", G8, "Note", "display", "#d-history table tbody tr:first-child td:nth-child(4)",
       "The free-text note typed with the decision (empty when none).", "Keeps the reason next to the decision.", "",
       [st("database", "db/knowledge.sqlite table event: payload.note"),
        st("service", "feedback_history(): note.", py(S2SVC, "Stage2Service.feedback_history"))] +
       record_tail(st("browser", "esc(note).", js(DEFJ, "const hist = (h) =>", 1)), "The note.")),
    el("dp-8-outcome", "DP", G8, "Outcome", "display", "#d-history table tbody tr:first-child td:nth-child(5)",
       "What came of the decision in the lab: \"✓ regression test admitted\" or \"not admitted\", then \"lab check: "
       "known-bad firmware <hits>/<runs> · fixed firmware <hits>/<runs>\"; \"-\" when no lab check followed.",
       "A procedure becomes a test only if it reproduces the defect on the known-bad firmware and not on the fixed one "
       "(the closed loop); the counts show that proof.",
       "",
       [st("database", "db/knowledge.sqlite table event: the script_gate event after the decision (admitted, gate "
                       "counts)."),
        st("service", "feedback_history(): outcome {admitted, known_bad, fixed}.", py(S2SVC, "Stage2Service.feedback_history"))] +
       record_tail(st("browser", "The outcome cell.", js(DEFJ, "const hist = (h) =>", 1)), "The outcome."),
       example='"✓ regression test admitted lab check: known-bad firmware 6/6 · fixed firmware 0/3" (newest T-42 row).'),
]
