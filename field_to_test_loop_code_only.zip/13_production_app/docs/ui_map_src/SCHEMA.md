# Data format for the button-by-button map (docs/ui_map_src/part_*.py)

Each part file is a Python module that defines one list, `ELEMENTS`, of dicts. The generator
`docs/build_ui_map.py` turns them into `docs/APPLICATION_MAP.html`. It REFUSES to build when a `ref` or a `code`
entry names a function or marker that does not exist, so every reference must be real.

```python
ELEMENTS = [
  {
    "id": "s1-analyse",                        # unique, lowercase, letters/digits/dashes; prefix = screen code below
    "screen": "S1",                            # one of the screen codes below
    "group": "Buttons",                        # sub-heading inside the screen (e.g. "Fields", "Buttons", "What you see")
    "label": "Analyse the trace (stage 1)",    # the EXACT text on the screen (copy it from index.html / the JS)
    "kind": "button",                          # button | field | checkbox | select | link | tab | display | table | key | row
    "selector": "#btn-start",                  # CSS selector of the element in the live page (for the numbered
                                               # screenshot); "" when it cannot be selected (e.g. a keyboard key)
    "what": "Plain words: what it is and what you see.",
    "why": "Why it exists: the problem it solves or the project requirement it serves.",
    "when": "When it is shown / enabled / disabled (optional, \"\" if always).",
    "chain": [                                 # the arrow flow, in order; 3-10 steps
      {"layer": "you",      "text": "You type your name and the CSV path, then click the button."},
      {"layer": "browser",  "text": "Checks the name and path are filled, remembers your name, sends the request.",
                            "ref": "js:app/static/js/run.js::$(\"btn-start\").onclick"},
      {"layer": "http",     "text": "POST /api/runs  {csv_path, operator, device, payload, dmesg, events, nsze, firmware, label, force}"},
      {"layer": "server",   "text": "Checks the paths are allowed, reuses an identical earlier run, else starts the stage-1 job.",
                            "ref": "py:app/api/runs_api.py::start_run"},
      {"layer": "engine",   "text": "Runs analyze → fuse → isolate → pattern cache → review → report.",
                            "ref": "py:app/stage1_runner.py::run_stage1"},
      {"layer": "database", "text": "db/app.sqlite table job: one row, progress and timings."},
      {"layer": "files",    "text": "runs/<run>/run.json, incidents.json, isolation.json …"},
      {"layer": "screen",   "text": "The page switches to step 2 and shows the progress ring."},
    ],
    "code": ["py:app/api/runs_api.py::start_run"],   # 0-3 excerpts to show in full under the entry (optional)
    "example": "Optional: a concrete example with real values from this installation.",
  },
]
```

## Layers (use exactly these words)
`you` (what the person does) · `browser` (JavaScript in app/static/js) · `http` (the request: METHOD /path  body) ·
`server` (Flask route in app/api/*.py) · `service` (app/services.py, app/stage2_service.py, app/jobs.py,
app/stage1_runner.py, app/report.py) · `engine` (stage1/pcie_isolate/*, stage2/*) · `database` (which events and
tables: db/knowledge.sqlite or db/app.sqlite) · `files` (files written or read) · `screen` (what you see afterwards).
A display element (content, not a button) uses the chain to show WHERE ITS VALUE COMES FROM: database/files →
engine/service → server → http → browser → screen.

## References
- `py:<path>::<Qualified.name>` — a function, method or class in a .py file (path relative to 13_production_app).
  Optional narrowing: `py:<path>::<Qualified.name>::<start text>::<stop text>` (lines from the first line containing
  start text up to, not including, the next line containing stop text).
- `js:<path>::<marker text>` — the first line of a .js/.html file that contains the marker text (the generator shows
  from that line). Optional `::<number of lines>` (default 14).
- Every `ref` and every `code` entry is checked by the generator. Use exact, unique marker texts.

## Screen codes
- `SB` sidebar and top bar (on every page)
- `S1` Step 1 · Choose the trace
- `S2` Step 2 · Analyse the trace (stage 1)
- `S3C` Step 3 · NVMe commands
- `S3` Step 4 · Defects found
- `DP` the defect page (/defect)
- `S4G` Step 5 · the Start stage 2 gate
- `S4` Step 5 · main screen: queue, title, bottom line, packet picture, cards, Save decisions, Generate test cases,
  Try nearby variations, Result
- `S4D` Step 5 · All details: tabs, saved vs proposed, top candidates, Other decisions (all 26 tiles), editor,
  Earlier decisions table, Stage 1 evidence tab, Result tab, keyboard keys, the Undo message (toast)
- `S5` Step 6 · Report and tests
- `ST` Settings
- `HP` What the words mean (help)
- `KB` the Knowledge base page (/db)

## Writing rules
- Plain language for a manager who has never seen the project; expand every abbreviation on first use in an entry.
- Every function name, address, table, event kind, file and screen text must exist in the code (grep it).
- "why" must be a real reason (a requirement of the project statement, a safety rule, a problem it prevents), not a
  restatement of "what".
- Do not invent numbers; an "example" uses values you read from this installation (read-only) or leave it "".
