# Part D of the button-by-button map: Step 6 (Report and tests), Settings, What the words mean, Knowledge base (/db).
# Format: docs/ui_map_src/SCHEMA.md. Every ref below was checked against the source on 27 Oct 2026.
# Examples are values read (GET only) from the installation on port 8077 on 27 Oct 2026, or from a scratch copy
# (port 8104, --standin) where Save and Undo were tried; the live database was never written.


def S(layer, text, ref=None):
    d = {"layer": layer, "text": text}
    if ref:
        d["ref"] = ref
    return d


R = "js:app/static/js/report.js::"
ST = "js:app/static/js/settings.js::"
D = "js:app/static/js/db.js::"
A = "js:app/static/js/api.js::"
M = "js:app/static/js/main.js::"
DEC = "js:app/static/js/decision.js::"
IX = "js:app/static/index.html::"
DH = "js:app/static/db.html::"

P_REPORT = "py:app/api/misc_api.py::report"
P_KPI = "py:app/api/misc_api.py::kpi"
P_BUILD = "py:app/report.py::build_report"
P_STATES = "py:app/services.py::Services.states_of"
P_INCS = "py:app/services.py::Services.incidents_of"
P_RUN1 = "py:app/stage1_runner.py::run_stage1"
P_SPAN = "py:app/jobs.py::JobManager._append_span"
P_RECORD = "py:app/stage2_service.py::Stage2Service._record"
P_PRESENT = "py:app/stage2_service.py::Stage2Service.present"
P_PUT = "py:app/api/config_api.py::put_config"
P_SAVE = "py:app/api/config_api.py::save_config"
P_RELOAD = "py:app/stage2_service.py::Stage2Service.reload_llm"
P_MAKE = "py:app/stage2_service.py::make_llm"
P_LOCK = "py:app/api/config_api.py::put_config::if (s.cfg.get(\"server\")::for sec in (\"llm\""
P_OV = "py:app/api/db_api.py::overview"
P_KSTATS = "py:stage2/kgdb.py::KGDB.stats"
P_GSTATS = "py:stage2/procgraph.py::ProcGraph.stats"
P_CSTATS = "py:app/pattern_cache.py::VerdictCache.stats"
P_SIG = "py:app/api/db_api.py::signature"
P_PROCS = "py:app/stage2_service.py::Stage2Service.procedures"
P_PFOR = "py:stage2/procgraph.py::ProcGraph.procedures_for"
P_TABLE = "py:app/api/db_api.py::table"
P_DBT = "py:app/stage2_service.py::Stage2Service.db_table"

PUT_HTTP = ("PUT /api/config  {llm: {backend, model, effort, base_url, api_key_env, batch, capture_check}, stage2: {bench, "
            "opt_budget, time_budget_s, optimal_consecutive, stress_trials, n_bad, n_fixed, search_on}, stage1: {firmware_label, nsze}}")
SAVE_SCREEN = "The message line under the Save button says \"saved · the AI reviewer now in use: …\" (or \"could not save: …\")."

ELEMENTS = [
    # ================================================================================================ S5 · Report
    {
        "id": "s5-build", "screen": "S5", "group": "Buttons and links", "label": "Build or refresh the report", "kind": "button",
        "selector": "#btn-report",
        "what": "The blue button at the top of the Report card. It asks the server for this run's report and for the key results of every "
                "run, then redraws everything in the card below it. Opening Step 6 with a run selected does the same automatically.",
        "why": "The project statement asks for the time taken by each stage to be reported explicitly, and for key results such as "
               "first-level triage time, automatic isolation and tests generated. The report is computed afresh from the saved timings "
               "and decisions every time, so it can never be stale after another decision in step 5.",
        "when": "Step 6 unlocks once a run is selected and its stage 1 has finished (main.js `unlocked`). With no run selected the button "
                "only shows \"select a run first\". The button does not reload the Generated regression tests card; that list is read "
                "when the page is opened.",
        "chain": [
            S("you", "You click the button, or simply open Step 6 with a run selected."),
            S("browser", "build() asks for the run report, then for the key results, and writes the chips and tables.", R + "async function build() {"),
            S("http", "GET /api/runs/<run>/report   then   GET /api/kpi"),
            S("server", "report(): finds the run's stage-1 job, its stage-2 jobs and every stage-2 state file, builds the report and "
                        "writes it to disk before answering.", P_REPORT),
            S("service", "build_report(): adds up the timed stage-1 steps and the lookup, search and lab-check seconds of each defect.", P_BUILD),
            S("database", "db/app.sqlite table job: the stage-1 job row (column spans = the timed steps, column result = the stage-1 "
                          "summary) and the stage-2 job rows; table verdict_cache for the cache counts."),
            S("files", "Reads runs/<run>/stage2/<defect>.json; writes runs/<run>/report.json and runs/<run>/report.md (write_report)."),
            S("screen", "The card fills: Key results, the run's chips, Stage 1 steps, AI reviewer, Stage 2 totals and the per-defect "
                        "table; the two report links appear."),
        ],
        "code": [P_REPORT, P_BUILD],
        "example": "Run run-20261026-225757-5cd5 (label \"exercise A\"): stage 1 17.9 s, stage 2 209.4 s, total 227.3 s.",
    },
    {
        "id": "s5-link-md", "screen": "S5", "group": "Buttons and links", "label": "Stage 2 report (report.md)", "kind": "link",
        "selector": "#rep-md",
        "what": "Opens the run report as a Markdown file (plain text with simple table marks) in a new tab: time per stage, the stage-1 "
                "steps, the AI reviewer line, one table row per defect and the stage-2 totals.",
        "why": "A file that can be attached to a bug report or archived with a firmware release, independent of the application. It is "
               "rebuilt on every request, so it always matches the screen.",
        "when": "Hidden until the report has been built once on this page; build() then points it at the selected run.",
        "chain": [
            S("you", "You click the link."),
            S("browser", "build() made the link visible and set its address to the selected run with ?format=md.", R + "$(\"rep-md\").hidden = false"),
            S("http", "GET /api/runs/<run>/report?format=md"),
            S("server", "report(): rebuilds and writes report.json and report.md, then returns the text of report.md.", P_REPORT),
            S("service", "to_markdown() writes the tables. This file still uses internal words: INC-0001 for Defect 1 and raw decision "
                         "names such as compose_tests.", "py:app/report.py::to_markdown"),
            S("files", "runs/<run>/report.md"),
            S("screen", "A new browser tab with the Markdown text."),
        ],
        "code": ["py:app/report.py::to_markdown"],
        "example": "",
    },
    {
        "id": "s5-link-iso", "screen": "S5", "group": "Buttons and links", "label": "Stage 1 report (isolation_report.md)", "kind": "link",
        "selector": "#rep-iso",
        "what": "Opens the analyser's own stage-1 report: one section per defect with its status, the rule that fired, the packets and the "
                "AI reviewer's opinion, exactly as written when stage 1 finished.",
        "why": "The stage-1 evidence as the analyser recorded it, with nothing of the application in between: for the analysis team or an audit.",
        "when": "Hidden until the report has been built once on this page.",
        "chain": [
            S("you", "You click the link."),
            S("browser", "build() set the address to the run's file isolation_report.md.", R + "$(\"rep-md\").hidden = false"),
            S("http", "GET /api/runs/<run>/file?path=isolation_report.md"),
            S("server", "run_file(): checks that the path stays inside the run folder, then sends the file.", "py:app/api/runs_api.py::run_file"),
            S("engine", "Written once, in the report step of stage 1, by the analyser (isolation.build calls write_md). This click does "
                        "not rebuild it.", "py:stage1/pcie_isolate/isolation.py::write_md"),
            S("files", "runs/<run>/isolation_report.md"),
            S("screen", "A new browser tab with the stage-1 report."),
        ],
        "code": ["py:app/api/runs_api.py::run_file"],
        "example": "",
    },
    {
        "id": "s5-empty", "screen": "S5", "group": "What you see", "label": "Select a run and build the report.", "kind": "display",
        "selector": "#rep-body",
        "what": "The placeholder text inside the Report card before anything has been built.",
        "why": "Says the card is empty because nothing was built yet, not because the run has no results.",
        "when": "Only until build() runs. Opening Step 6 with a run selected builds at once, so it is seldom seen.",
        "chain": [
            S("files", "The text is written in the page itself.", IX + "<div id=\"rep-body\" class=\"empty\">"),
            S("browser", "build() replaces the whole contents of this box.", R + "async function build() {"),
            S("screen", "The placeholder disappears once the report is drawn."),
        ],
        "example": "",
    },
    {
        "id": "s5-kpi-heading", "screen": "S5", "group": "Key results — all runs", "label": "Key results — all runs on this installation",
        "kind": "display", "selector": "#rep-body > h3:nth-of-type(1)",
        "what": "The heading of the seven key-result chips and the rules line under them. They are measured over every finished stage-1 "
                "run on this installation (up to 500), not only the selected run.",
        "why": "The project statement judges the tool by these results: first-level triage within 10 minutes, defects isolated "
               "automatically, regression tests generated, AI reviewer calls saved, and no known defect slipping past its own test.",
        "when": "If GET /api/kpi fails, the heading and chips are replaced by \"Key results: <error message>\".",
        "chain": [
            S("database", "db/app.sqlite table job: the stage-1 jobs; only those with status done are counted."),
            S("server", "kpi(): goes through those runs, reads each run's defects and summary, and asks the knowledge base for the "
                        "test and error-type counts.", P_KPI),
            S("http", "GET /api/kpi  →  {rules, runs, efficiency, quality, productivity}"),
            S("browser", "build() writes the heading, the chips and the rules line.", R + "const k = await api(\"GET\", \"/api/kpi\")"),
            S("screen", "The heading and seven chips at the top of the report."),
        ],
        "code": [P_KPI],
        "example": "36 finished runs on 27 Oct 2026.",
    },
    {
        "id": "s5-kpi-triage", "screen": "S5", "group": "Key results — all runs", "label": "runs within the first-level triage limit (10 min)",
        "kind": "display", "selector": "#rep-body > div.chips:nth-of-type(1) > .chip:nth-child(1)",
        "what": "Shown as \"<runs within> / <runs>\". A run is within the limit when the seconds of its timed stage-1 steps add up to no "
                "more than 600. The 600 seconds (and the \"10 min\" in the label) come from the fixed constant FIRST_LEVEL_TRIAGE_S in "
                "stage2/loop_rules.py, not from the Settings field \"First-level triage limit in seconds\", which limits the stage-2 "
                "search per defect instead.",
        "why": "The system diagram's rule: more than 10 minutes of first-level triage is a fail.",
        "when": "",
        "chain": [
            S("database", "db/app.sqlite table job, column spans: the timed steps of each finished stage-1 job.", P_SPAN),
            S("server", "kpi(): adds the seconds of every span whose name starts with stage1. and compares the sum with FIRST_LEVEL_TRIAGE_S.",
              "py:app/api/misc_api.py::kpi::from loop_rules import::incs = s.incidents_of(rid)"),
            S("http", "GET /api/kpi  →  efficiency.runs_within_triage_budget, efficiency.runs, rules.first_level_triage_s"),
            S("browser", "Writes \"within / runs\" and turns the 600 seconds into minutes for the label.", R + "runs_within_triage_budget} / ${e.runs}"),
            S("screen", "The first chip."),
        ],
        "example": "35 / 36",
    },
    {
        "id": "s5-kpi-isolated", "screen": "S5", "group": "Key results — all runs",
        "label": "defects isolated automatically and matched to a known error type", "kind": "display",
        "selector": "#rep-body > div.chips:nth-of-type(1) > .chip:nth-child(2)",
        "what": "\"<matched> / <all defects>\": all defects of all finished runs, and how many of them the analyser matched to an entry "
                "of the catalogue of 485 known error types (the first catalogue candidate of the defect).",
        "why": "The statement's automation goal: the share of defects that need no manual identification.",
        "when": "",
        "chain": [
            S("files", "runs/<run>/incidents.json of each run: every defect with its catalogue candidates (atlas_candidates)."),
            S("service", "Services.incidents_of(): takes the error type of the first candidate as the defect's card.", P_INCS),
            S("server", "kpi(): incidents = all defects, isolated_with_card = defects with a card, summed over the runs.", P_KPI),
            S("http", "GET /api/kpi  →  quality.isolated_with_card, quality.incidents"),
            S("browser", "Writes \"matched / all\".", R + "${q.isolated_with_card} / ${q.incidents}"),
            S("screen", "The second chip."),
        ],
        "example": "294 / 294",
    },
    {
        "id": "s5-kpi-leakage", "screen": "S5", "group": "Key results — all runs",
        "label": "known defects that came back and slipped past their test (must be 0)", "kind": "display",
        "selector": "#rep-body > div.chips:nth-of-type(1) > .chip:nth-child(3)",
        "what": "A count. Among the defects whose stage-2 lookup said \"seen before\" (exact match) and which the admin then confirmed "
                "(Accept or Accept with a note, so the stored test was re-run in the lab), those whose test was not filed again.",
        "why": "A known defect that recurs and is not caught again by its own test means the test does not guard what it should. The "
               "statement's goal is zero such leaks.",
        "when": "",
        "chain": [
            S("files", "runs/<run>/stage2/<defect>.json: view.seen (match, …), last.action and last.admitted."),
            S("service", "Services.incidents_of() copies those three values into each defect's stage2 block.", P_INCS),
            S("server", "kpi(): recurrences_tested minus recurrences_readmitted = known_signature_leakage.",
              "py:app/api/misc_api.py::kpi::rec = sum(::cfg_k = s.cfg"),
            S("http", "GET /api/kpi  →  quality.known_signature_leakage"),
            S("browser", "Writes the number.", R + "${q.known_signature_leakage}"),
            S("screen", "The third chip."),
        ],
        "example": "0 (22 recurrences re-run in the lab, 22 caught again by their test).",
    },
    {
        "id": "s5-kpi-sigs", "screen": "S5", "group": "Key results — all runs",
        "label": "known failure signatures (fingerprints of defects) with a regression test filed", "kind": "display",
        "selector": "#rep-body > div.chips:nth-of-type(1) > .chip:nth-child(4)",
        "what": "\"<with a filed test> / <known>\": the error types in the knowledge base's procedure graph, and how many of them have "
                "at least one test whose lab check passed (admitted).",
        "why": "Coverage: every error type met in the field should end up guarded by a test.",
        "when": "",
        "chain": [
            S("database", "db/knowledge.sqlite table pnode: items of kind signature, and items of kind test with admitted = true."),
            S("engine", "ProcGraph.nodes() reads the active items of one kind.", "py:stage2/procgraph.py::ProcGraph.nodes"),
            S("server", "kpi(): known = distinct error types; admitted_sigs = distinct error types of admitted tests.",
              "py:app/api/misc_api.py::kpi::with s.s2.lock::rec = sum("),
            S("http", "GET /api/kpi  →  quality.signatures_with_admitted_test, quality.known_signatures"),
            S("browser", "Writes \"with test / known\".", R + "${q.signatures_with_admitted_test} / ${q.known_signatures}"),
            S("screen", "The fourth chip."),
        ],
        "example": "3 / 5",
    },
    {
        "id": "s5-kpi-tests", "screen": "S5", "group": "Key results — all runs",
        "label": "regression tests generated automatically (0 written by hand)", "kind": "display",
        "selector": "#rep-body > div.chips:nth-of-type(1) > .chip:nth-child(5)",
        "what": "The number of active test items in the knowledge base. Every lab check of a procedure (event script_gate) creates one, "
                "whether or not the check passed, and a procedure checked again creates another; so the number is larger than the number "
                "of test folders listed in Generated regression tests. The \"written by hand\" figure is the fixed value 0 in the code.",
        "why": "The statement's productivity goal: regression tests produced without writing scripts by hand.",
        "when": "",
        "chain": [
            S("database", "db/knowledge.sqlite table pnode, kind test: one per script_gate event that names a procedure."),
            S("engine", "ProcGraph.project() creates a test item for every such event, filed or not.",
              "py:stage2/procgraph.py::ProcGraph.project::elif kind == \"script_gate\"::elif kind == \"proc_credit\""),
            S("server", "kpi(): tests_on_file = number of test items; tests_authored_by_hand = 0.",
              "py:app/api/misc_api.py::kpi::\"productivity\": {"),
            S("http", "GET /api/kpi  →  productivity.tests_on_file, productivity.tests_authored_by_hand"),
            S("browser", "Writes the number and the hand-written count.", R + "${pr.tests_on_file}"),
            S("screen", "The fifth chip."),
        ],
        "example": "173, while the folder suite/ holds 53 test folders.",
    },
    {
        "id": "s5-kpi-cache", "screen": "S5", "group": "Key results — all runs",
        "label": "AI reviewer calls saved by reusing earlier verdicts", "kind": "display",
        "selector": "#rep-body > div.chips:nth-of-type(1) > .chip:nth-child(6)",
        "what": "The sum over all finished runs of the defects whose stage-1 second opinion was taken from the verdict cache instead of a "
                "fresh call to the AI reviewer (a language model).",
        "why": "Each saved call saves money and minutes; the statement asks that what was already processed is not processed again.",
        "when": "",
        "chain": [
            S("service", "run_stage1(): the pattern-cache step looks up each defect's key in the cache and counts the hits as llm_cached.", P_RUN1),
            S("files", "runs/<run>/stage1_summary.json: llm_cached."),
            S("server", "kpi(): adds llm_cached over the runs.", P_KPI),
            S("http", "GET /api/kpi  →  efficiency.llm_calls_saved_by_cache"),
            S("browser", "Writes the number.", R + "${e.llm_calls_saved_by_cache}"),
            S("screen", "The sixth chip."),
        ],
        "example": "99",
    },
    {
        "id": "s5-kpi-saving", "screen": "S5", "group": "Key results — all runs",
        "label": "triage effort saved compared with your manual baseline", "kind": "display",
        "selector": "#rep-body > div.chips:nth-of-type(1) > .chip:nth-child(7)",
        "what": "A percentage: 100 × (1 − automatic triage minutes ÷ (your manual minutes per run × number of runs)). While the manual "
                "number is not set it shows \"n/a\" and the hint \"(set kpi.manual_triage_minutes_per_run in the config file)\".",
        "why": "The statement's target is about 50 % less triage effort. That cannot be measured without your current manual time, so "
               "the application shows nothing rather than invent a baseline.",
        "when": "There is no field for the baseline on the Settings page; it is set only in config/app_config.json.",
        "chain": [
            S("files", "config/app_config.json, section kpi: manual_triage_minutes_per_run (null in this installation)."),
            S("server", "kpi(): automatic minutes = all stage-1 seconds ÷ 60; saving computed only when the baseline is set.",
              "py:app/api/misc_api.py::kpi::auto_min = ::return jsonify("),
            S("http", "GET /api/kpi  →  efficiency.triage_effort_saving_pct, efficiency.manual_triage_minutes_per_run_baseline"),
            S("browser", "Writes the percentage, or n/a with the hint.", R + "e.triage_effort_saving_pct != null"),
            S("screen", "The seventh chip."),
        ],
        "example": "n/a (no baseline set).",
    },
    {
        "id": "s5-kpi-rules", "screen": "S5", "group": "Key results — all runs",
        "label": "Rules: optimal = score (how closely a lab run matched the original packets) above … · fail = first-level triage over … min. …",
        "kind": "display", "selector": "#rep-body > p:nth-of-type(1)",
        "what": "One line under the chips: the two rules of the system diagram (score above 0.9 in 3 lab runs in a row = optimal; "
                "first-level triage over 10 min = fail), the minutes of automatic triage measured over all runs, and three recurrence "
                "counts: defects seen again in a later capture, re-run in the lab, caught again by their test. The rule numbers are the "
                "constants of stage2/loop_rules.py: changing \"Optimal = … in a row\" in Settings does not change this line. The "
                "\"score\" is in fact checks passed out of 3 (same error type, same rule, confirmed).",
        "why": "Shows the yardstick next to the results, so the chips can be read without the documentation.",
        "when": "",
        "chain": [
            S("engine", "stage2/loop_rules.py: SCORE_THRESHOLD = 0.9, OPTIMAL_CONSECUTIVE = 3, FIRST_LEVEL_TRIAGE_S = 600.",
              "py:stage2/loop_rules.py::rules_summary"),
            S("server", "kpi(): returns the three constants, triage_minutes_total_automatic and recurrences_seen / _tested / _readmitted.",
              "py:app/api/misc_api.py::kpi::rec = sum(::cfg_k = s.cfg"),
            S("http", "GET /api/kpi  →  rules, efficiency.triage_minutes_total_automatic, quality.recurrences_*"),
            S("browser", "Writes the line.", R + "<p class=\"help\">Rules: optimal"),
            S("screen", "The small line under the key-result chips."),
        ],
        "example": "Minutes of automatic triage measured: 33.3. Defects seen again in a later capture: 52; re-run in the lab: 22; caught again by their test: 22.",
    },
    # ---------------------------------------------------------------------------------------- run chips
    {
        "id": "s5-run-s1", "screen": "S5", "group": "This run", "label": "stage 1 (analysis)", "kind": "display",
        "selector": "#rep-body > div.chips:nth-of-type(2) > .chip:nth-child(1)",
        "what": "Seconds of stage 1 for this run: the sum of its timed steps (analyze, fuse, isolate, pattern_cache, review, report, "
                "capture_check) as recorded in the stage-1 job.",
        "why": "The statement asks for the time taken by each stage to be reported explicitly.",
        "when": "",
        "chain": [
            S("service", "run_stage1(): every step runs inside a timer named stage1.<step>.", P_RUN1),
            S("database", "db/app.sqlite table job, column spans of the run's stage-1 job.", P_SPAN),
            S("service", "build_report(): keeps the spans whose name starts with stage1. and adds their seconds.", P_BUILD),
            S("server", "report() returns the report.", P_REPORT),
            S("http", "GET /api/runs/<run>/report  →  stage1.seconds_total"),
            S("browser", "Writes the seconds with one decimal.", R + "<b>${fmt(s1.seconds_total)} s</b>"),
            S("screen", "First chip of the run."),
        ],
        "example": "17.9 s (run \"exercise A\").",
    },
    {
        "id": "s5-run-s2", "screen": "S5", "group": "This run", "label": "stage 2 (reproduction)", "kind": "display",
        "selector": "#rep-body > div.chips:nth-of-type(2) > .chip:nth-child(2)",
        "what": "Seconds of stage 2: for every defect, lookup and proposal seconds + search seconds + lab-check seconds of its last "
                "decision. Earlier attempts on the same defect and the time between decisions are not counted.",
        "why": "The statement asks for the time of each stage; stage 2 is where the lab time is spent.",
        "when": "",
        "chain": [
            S("service", "Stage2Service.present() stores the lookup seconds; _record() stores each decision result as \"last\".", P_RECORD),
            S("files", "runs/<run>/stage2/<defect>.json: view.timings.present_s, last.search_s, last.verify_s."),
            S("service", "Services.states_of() reads every state file of the run.", P_STATES),
            S("service", "build_report(): seconds_total = lookup + search + lab check, summed over the defects.", P_BUILD),
            S("http", "GET /api/runs/<run>/report  →  stage2.seconds_total"),
            S("browser", "Writes the seconds.", R + "<b>${fmt(s1.seconds_total)} s</b>"),
            S("screen", "Second chip of the run."),
        ],
        "example": "209.4 s",
    },
    {
        "id": "s5-run-total", "screen": "S5", "group": "This run", "label": "total", "kind": "display",
        "selector": "#rep-body > div.chips:nth-of-type(2) > .chip:nth-child(3)",
        "what": "Stage 1 seconds plus stage 2 seconds.",
        "why": "One number for the whole loop, from trace to tests.",
        "when": "",
        "chain": [
            S("service", "build_report(): total_seconds = stage 1 total + stage 2 total.", P_BUILD),
            S("http", "GET /api/runs/<run>/report  →  total_seconds"),
            S("browser", "Writes the seconds.", R + "<b>${fmt(s1.seconds_total)} s</b>"),
            S("screen", "Third chip of the run."),
        ],
        "example": "227.3 s",
    },
    {
        "id": "s5-run-defects", "screen": "S5", "group": "This run", "label": "defects isolated", "kind": "display",
        "selector": "#rep-body > div.chips:nth-of-type(2) > .chip:nth-child(4)",
        "what": "How many defects stage 1 isolated in this trace (the number of entries in incidents.json).",
        "why": "The size of the work stage 2 has in front of it.",
        "when": "",
        "chain": [
            S("engine", "The analyser's isolate step writes runs/<run>/incidents.json."),
            S("service", "run_stage1(): counts the defects into the stage-1 summary (incidents), which becomes the job's result.", P_RUN1),
            S("database", "db/app.sqlite table job, column result."),
            S("service", "build_report() copies it as stage1.incidents.", P_BUILD),
            S("http", "GET /api/runs/<run>/report  →  stage1.incidents"),
            S("browser", "Writes the number.", R + "${s1.incidents ?? \"-\"}"),
            S("screen", "Fourth chip of the run."),
        ],
        "example": "3",
    },
    {
        "id": "s5-run-confirmed", "screen": "S5", "group": "This run", "label": "confirmed by the AI reviewer", "kind": "display",
        "selector": "#rep-body > div.chips:nth-of-type(2) > .chip:nth-child(5)",
        "what": "How many second-opinion records of this run say CONFIRMED, including verdicts reused from the cache.",
        "why": "Shows how often the AI reviewer's second opinion agreed with the analyser.",
        "when": "",
        "chain": [
            S("files", "runs/<run>/llm_reviews.jsonl: one second opinion per defect (fresh or from the cache)."),
            S("service", "run_stage1(): counts the records with verdict CONFIRMED as llm_confirmed.", P_RUN1),
            S("service", "build_report() copies it as stage1.llm.confirmed.", P_BUILD),
            S("http", "GET /api/runs/<run>/report  →  stage1.llm.confirmed"),
            S("browser", "Writes the number.", R + "${s1.incidents ?? \"-\"}"),
            S("screen", "Fifth chip of the run."),
        ],
        "example": "2",
    },
    {
        "id": "s5-run-calls", "screen": "S5", "group": "This run", "label": "AI reviewer calls / verdicts reused from the cache",
        "kind": "display", "selector": "#rep-body > div.chips:nth-of-type(2) > .chip:nth-child(6)",
        "what": "\"<fresh model calls> / <verdicts reused>\" for this run's stage-1 second opinions.",
        "why": "Shows directly what the verdict cache saved on this trace.",
        "when": "",
        "chain": [
            S("service", "run_stage1(): llm_called = records not from the cache; llm_cached = cache hits of the pattern-cache step.", P_RUN1),
            S("service", "build_report(): stage1.llm.called and stage1.llm.from_pattern_cache.", P_BUILD),
            S("http", "GET /api/runs/<run>/report  →  stage1.llm.called, stage1.llm.from_pattern_cache"),
            S("browser", "Writes \"calls / reused\".", R + "${s1.incidents ?? \"-\"}"),
            S("screen", "Sixth chip of the run."),
        ],
        "example": "0 / 3",
    },
    {
        "id": "s5-run-tests", "screen": "S5", "group": "This run", "label": "regression tests filed", "kind": "display",
        "selector": "#rep-body > div.chips:nth-of-type(2) > .chip:nth-child(7)",
        "what": "How many defects of this run ended with a regression test filed (their last result says admitted). It counts defects, "
                "not test files: one \"Try nearby variations\" can file several tests for a single defect.",
        "why": "The outcome that matters: defects turned into tests.",
        "when": "",
        "chain": [
            S("engine", "Stage2V3 sets admitted when the lab check on known-bad and fixed firmware passed and the test was written.",
              "py:stage2/stage2_v3.py::Stage2V3._finish"),
            S("files", "runs/<run>/stage2/<defect>.json: last.admitted."),
            S("service", "build_report(): stage2.admitted = defects whose last result is admitted.", P_BUILD),
            S("http", "GET /api/runs/<run>/report  →  stage2.admitted"),
            S("browser", "Writes the number.", R + "${s1.incidents ?? \"-\"}"),
            S("screen", "Seventh chip of the run."),
        ],
        "example": "3",
    },
    {
        "id": "s5-steps", "screen": "S5", "group": "This run", "label": "Stage 1 steps", "kind": "table",
        "selector": "#rep-body .grid2 > div:nth-child(1) table",
        "what": "Columns Step and Seconds: one row per timed stage-1 step, in the order they ran, seconds with two decimals. A step that "
                "did not run has no row (no host evidence means no fuse; every verdict reused means no review).",
        "why": "Shows where the stage-1 time goes, for example the optional capture check taking most of it.",
        "when": "",
        "chain": [
            S("service", "run_stage1(): each step and the pattern-cache step is timed.", P_RUN1),
            S("database", "db/app.sqlite table job, column spans.", P_SPAN),
            S("service", "build_report(): one row per stage1.* span, the name after the dot as the step.", P_BUILD),
            S("http", "GET /api/runs/<run>/report  →  stage1.steps[] {step, seconds}"),
            S("browser", "Draws the table.", R + "<h3>Stage 1 steps</h3>"),
            S("screen", "The small table on the left under the chips."),
        ],
        "example": "analyze 1.80 · isolate 0.62 · pattern_cache 0.02 · report 0.07 · capture_check 15.36",
    },
    {
        "id": "s5-ai", "screen": "S5", "group": "This run", "label": "AI reviewer", "kind": "display",
        "selector": "#rep-body .grid2 > div:nth-child(2) > p:nth-of-type(1)",
        "what": "\"Model <name> (connection: <backend>): N defects reviewed, N model calls, N verdicts reused from the cache, N confirmed, "
                "cost X USD.\" Connection is how stage 1 reached the model (cli, sdk, auto, or dry-run = no model). It covers stage 1's "
                "second opinions only; the AI reviewer's stage-2 calls are counted on the Knowledge base page under AI reviewer usage.",
        "why": "Model, cost and cache use of the second opinions in one sentence, for budgeting and for audits.",
        "when": "",
        "chain": [
            S("files", "runs/<run>/llm_reviews.jsonl: each record with its backend and cost."),
            S("service", "run_stage1(): counts reviewed, called, confirmed and adds the cost; stores model and backend in the summary.", P_RUN1),
            S("service", "build_report(): stage1.llm = {model, backend, reviewed, called, from_pattern_cache, confirmed, cost_usd}.", P_BUILD),
            S("http", "GET /api/runs/<run>/report  →  stage1.llm"),
            S("browser", "Writes the sentence; cost with three decimals.", R + "<h3>AI reviewer</h3>"),
            S("screen", "The paragraph on the right under the chips."),
        ],
        "example": "Model claude-haiku-5-5 (connection: cli): 3 defects reviewed, 0 model calls, 3 verdicts reused from the cache, 2 confirmed, cost 0.000 USD.",
    },
    {
        "id": "s5-s2totals", "screen": "S5", "group": "This run", "label": "Stage 2 totals", "kind": "display",
        "selector": "#rep-body .grid2 > div:nth-child(2) > p:nth-of-type(2)",
        "what": "\"N looked up, N decided, N regression tests filed, N optimal, N over the first-level triage limit · lookup and proposal "
                "X s (of which the AI reviewer X s), search X s, lab check on known-bad and fixed firmware X s.\" Looked up = defects "
                "with a lookup on file; decided = defects with at least one result. \"Optimal\" counts the optimal flag of the last "
                "result; for Generate test cases and Try nearby variations that flag is never set, so those defects always count as not "
                "optimal even when their lab check met the optimal rule.",
        "why": "The stage-2 summary of the run in one sentence, with the time split the statement asks for.",
        "when": "",
        "chain": [
            S("files", "runs/<run>/stage2/<defect>.json: presented, view.timings, last."),
            S("service", "Services.states_of() reads them.", P_STATES),
            S("service", "build_report(): counts and sums them.", P_BUILD),
            S("http", "GET /api/runs/<run>/report  →  stage2.incidents_presented, incidents_executed, admitted, optimal, "
                      "triage_timeouts, seconds_present, seconds_llm_in_present, seconds_search, seconds_verify"),
            S("browser", "Writes the sentence.", R + "<h3>Stage 2 totals</h3>"),
            S("screen", "The second paragraph on the right."),
        ],
        "example": "3 looked up, 3 decided, 3 regression tests filed, 0 optimal, 0 over the first-level triage limit · lookup and proposal 103.1 s (of which the AI reviewer 103.0 s), search 0.0 s, lab check 106.3 s.",
    },
    {
        "id": "s5-pd-help", "screen": "S5", "group": "Stage 2 per defect",
        "label": "The \"Error type\" column shows the catalogue number and its chapter; …", "kind": "display",
        "selector": "#rep-body > p:nth-of-type(2)",
        "what": "A help line above the per-defect table: it writes out the first defect's error type in full and explains the Lab and "
                "Time columns.",
        "why": "The table cells are short; the line tells a first-time reader how to read them.",
        "when": "Only when at least one defect of the run has a stage-2 state.",
        "chain": [
            S("http", "GET /api/runs/<run>/report  →  stage2.incidents[0].card"),
            S("browser", "Writes the line with the first error type in full.", R + "<h3>Stage 2 per defect</h3>"),
            S("browser", "errorTypeFull() turns \"T-42\" into \"error type T-42 (chapter T = timeouts and time limits, entry 42)\".",
              A + "export function errorTypeFull(card, title)"),
            S("screen", "The help line above the table."),
        ],
        "example": "\"… written out, the first one is error type T-42 (chapter T = timeouts and time limits, entry 42).\"",
    },
    {
        "id": "s5-pd-table", "screen": "S5", "group": "Stage 2 per defect", "label": "Stage 2 per defect", "kind": "table",
        "selector": "#rep-body table.report.perdefect",
        "what": "One row per defect that has a stage-2 state file (looked up or decided), in the order of the analyser's defect numbers. "
                "Eight columns: Defect, Error type, Knowledge base, Decision, What happened, Lab, Result, Time.",
        "why": "Accountability per defect: what the knowledge base knew, what the admin decided, what the lab did, what came out, how long it took.",
        "when": "A defect never opened in step 5 has no state file and no row.",
        "chain": [
            S("files", "runs/<run>/stage2/<defect>.json: view = the lookup shown, last = the result of the last decision."),
            S("service", "Services.states_of() reads every state file of the run.", P_STATES),
            S("service", "build_report(): one row per state file (stage2.incidents).", P_BUILD),
            S("server", "report() returns it.", P_REPORT),
            S("http", "GET /api/runs/<run>/report  →  stage2.incidents[]"),
            S("browser", "Draws the table, one row per defect.", R + "<table class=\"report perdefect\">"),
            S("screen", "The table at the bottom of the Report card."),
        ],
        "example": "",
    },
    {
        "id": "s5-pd-defect", "screen": "S5", "group": "Stage 2 per defect", "label": "Defect", "kind": "display",
        "selector": "#rep-body table.perdefect th:nth-child(1)",
        "what": "\"Defect <n>\": the defect's number in this trace. Internally the defect record is called INC-0007; the screen shows Defect 7.",
        "why": "Ties the row to the same defect on steps 3 and 4.",
        "when": "",
        "chain": [
            S("files", "The state file's name: runs/<run>/stage2/INC-0001.json."),
            S("service", "Services.states_of() uses the file name as the key; build_report() puts it in incident.", P_STATES),
            S("http", "GET /api/runs/<run>/report  →  stage2.incidents[].incident"),
            S("browser", "defectName() turns INC-0001 into Defect 1.", A + "export function defectName(id) {"),
            S("screen", "First column, in bold."),
        ],
        "example": "Defect 1",
    },
    {
        "id": "s5-pd-type", "screen": "S5", "group": "Stage 2 per defect", "label": "Error type", "kind": "display",
        "selector": "#rep-body table.perdefect th:nth-child(2)",
        "what": "\"T-42 · timeouts and time limits\": the catalogue error type the stage-2 lookup worked on, with its chapter.",
        "why": "The error type decides which procedures and tests in the knowledge base apply.",
        "when": "",
        "chain": [
            S("service", "Stage2Service.present() stores the lookup card, with its error type, in the state file.", P_PRESENT),
            S("files", "runs/<run>/stage2/<defect>.json: view.card.card"),
            S("service", "build_report(): card.", P_BUILD),
            S("http", "GET /api/runs/<run>/report  →  stage2.incidents[].card"),
            S("browser", "errorTypeShort() adds the chapter text.", A + "export function errorTypeShort(card)"),
            S("screen", "Second column."),
        ],
        "example": "M-020 · timing, evidence-gap and cross-layer failures",
    },
    {
        "id": "s5-pd-kb", "screen": "S5", "group": "Stage 2 per defect", "label": "Knowledge base", "kind": "display",
        "selector": "#rep-body table.perdefect th:nth-child(3)",
        "what": "Three lines: \"seen before:\" with the first word of the lookup's answer (YES, NO, …); \"saved procedure: yes/no\" (a "
                "procedure the admin saved earlier was found); \"AI reviewer proposal: yes/no\" (the AI reviewer proposed a sequence).",
        "why": "Shows what the knowledge base already knew when the defect came in, the core of the field-to-test loop.",
        "when": "",
        "chain": [
            S("engine", "Stage2V3.present(): searches the knowledge base, decides \"seen before\" and builds the card with the stored and "
                        "proposed procedures.", "py:stage2/stage2_v3.py::Stage2V3.present"),
            S("service", "Stage2Service.present(): view.seen_label, view.stored, view.generated.", P_PRESENT),
            S("files", "runs/<run>/stage2/<defect>.json: view"),
            S("service", "build_report(): seen, stored_exists, generated_exists.", P_BUILD),
            S("http", "GET /api/runs/<run>/report  →  stage2.incidents[].seen, .stored_exists, .generated_exists"),
            S("browser", "Keeps the text before \" - \" of the seen-before answer.", R + "seen before: <b>"),
            S("screen", "Third column."),
        ],
        "example": "seen before: YES · saved procedure: yes · AI reviewer proposal: yes (Defect 1 of \"exercise A\").",
    },
    {
        "id": "s5-pd-decision", "screen": "S5", "group": "Stage 2 per defect", "label": "Decision", "kind": "display",
        "selector": "#rep-body table.perdefect th:nth-child(4)",
        "what": "The admin's last decision on this defect in plain words (Accept, Try nearby variations, Generate test cases, …), or "
                "\"not decided yet\".",
        "why": "Every result in the report is traceable to a human decision.",
        "when": "",
        "chain": [
            S("you", "Earlier, in step 5, the admin chose a decision."),
            S("service", "Stage2Service.act() ran it and _record() stored the result as last.", P_RECORD),
            S("files", "runs/<run>/stage2/<defect>.json: last.action"),
            S("service", "build_report(): action.", P_BUILD),
            S("http", "GET /api/runs/<run>/report  →  stage2.incidents[].action"),
            S("browser", "actionWord() turns compose_tests into \"Generate test cases\".", DEC + "const ACTION_WORD = {"),
            S("screen", "Fourth column."),
        ],
        "example": "Try nearby variations (Defect 1)",
    },
    {
        "id": "s5-pd-what", "screen": "S5", "group": "Stage 2 per defect", "label": "What happened", "kind": "display",
        "selector": "#rep-body table.perdefect th:nth-child(5)",
        "what": "How the lab work started (saved procedure reused, searched from the evidence, tests composed by the AI reviewer, nearby "
                "variations tried, …) and, after an arrow, the outcome when it says something different; \"nothing run yet\" before a decision.",
        "why": "Says in words what the engine actually did with the decision.",
        "when": "",
        "chain": [
            S("engine", "Stage2V3.execute() sets mode (how it started) and status (outcome) of the result.", "py:stage2/stage2_v3.py::Stage2V3.execute"),
            S("files", "runs/<run>/stage2/<defect>.json: last.mode, last.status"),
            S("service", "build_report(): mode, status.", P_BUILD),
            S("http", "GET /api/runs/<run>/report  →  stage2.incidents[].mode, .status"),
            S("browser", "modeWord() and statusWord() give the words; the outcome is added only when it differs.", R + "esc(how) + (out && out !== how"),
            S("screen", "Fifth column."),
        ],
        "example": "tests composed by the AI reviewer → tests composed (Defect 2)",
    },
    {
        "id": "s5-pd-lab", "screen": "S5", "group": "Stage 2 per defect", "label": "Lab", "kind": "display",
        "selector": "#rep-body table.perdefect th:nth-child(6)",
        "what": "\"<n> runs\": the lab runs of the search; then \"known-bad: found h of n\" and \"fixed: found h of n\": how often the "
                "analyser found the defect again when the procedure was re-run on the firmware known to be bad and on the fixed firmware.",
        "why": "The closed loop: a procedure is trusted only if it reproduces the defect on known-bad firmware and not on fixed firmware.",
        "when": "The known-bad and fixed lines appear only when a lab check was run.",
        "chain": [
            S("engine", "verify_closed_loop(): n_bad runs on known-bad, n_fixed runs on fixed firmware, each analysed by the stage-1 detector.",
              "py:stage2/testgen.py::verify_closed_loop"),
            S("engine", "Stage2V3._finish() stores trials and the lab-check result.", "py:stage2/stage2_v3.py::Stage2V3._finish"),
            S("files", "runs/<run>/stage2/<defect>.json: last.trials, last.closed_loop"),
            S("service", "build_report(): trials, closed_loop.", P_BUILD),
            S("http", "GET /api/runs/<run>/report  →  stage2.incidents[].trials, .closed_loop {known_bad_hits, known_bad_n, fixed_hits, fixed_n}"),
            S("browser", "Writes the three lines.", R + "known-bad: found ${cl.known_bad_hits}"),
            S("screen", "Sixth column."),
        ],
        "example": "42 runs · known-bad: found 6 of 6 · fixed: found 0 of 3 (Defect 1)",
    },
    {
        "id": "s5-pd-result", "screen": "S5", "group": "Stage 2 per defect", "label": "Result", "kind": "display",
        "selector": "#rep-body table.perdefect th:nth-child(7)",
        "what": "\"✓ test filed\" or \"no test filed\", and \"optimal\" or \"not optimal\". A test is filed when the lab check found the "
                "defect in at least one known-bad run and in none of the fixed runs. Optimal is the last result's flag; for Generate test "
                "cases and Try nearby variations it is never set, so such rows read \"not optimal\" even when the Lab column shows the "
                "defect found in every known-bad run.",
        "why": "The two outcomes the statement asks for: a regression test, and whether the optimal rule was met.",
        "when": "",
        "chain": [
            S("engine", "Stage2V3._finish(): admitted = lab check passed; optimal = all 3 checks in the configured number of runs in a row.",
              "py:stage2/stage2_v3.py::Stage2V3._finish"),
            S("files", "runs/<run>/stage2/<defect>.json: last.admitted, last.optimal"),
            S("service", "build_report(): admitted, optimal.", P_BUILD),
            S("http", "GET /api/runs/<run>/report  →  stage2.incidents[].admitted, .optimal"),
            S("browser", "Writes the two words.", R + "✓ test filed"),
            S("screen", "Seventh column."),
        ],
        "example": "✓ test filed · not optimal (Defect 1, although known-bad was found 6 of 6 and the lab check itself recorded optimal = true).",
    },
    {
        "id": "s5-pd-time", "screen": "S5", "group": "Stage 2 per defect", "label": "Time", "kind": "display",
        "selector": "#rep-body table.perdefect th:nth-child(8)",
        "what": "\"lookup X s\" (knowledge-base search and AI reviewer proposal), and after a decision \"search X s\" and \"lab check X s\".",
        "why": "Per-defect timing, to check each defect against the first-level triage limit.",
        "when": "",
        "chain": [
            S("service", "Stage2Service.present() stores present_s; the decision result carries search_s and verify_s.", P_PRESENT),
            S("files", "runs/<run>/stage2/<defect>.json: view.timings.present_s, last.search_s, last.verify_s"),
            S("service", "build_report(): present_s, search_s, verify_s.", P_BUILD),
            S("http", "GET /api/runs/<run>/report  →  stage2.incidents[].present_s, .search_s, .verify_s"),
            S("browser", "Writes the lines in seconds.", R + "lookup ${fmt(i.present_s)} s"),
            S("screen", "Eighth column."),
        ],
        "example": "lookup 34.8 s · search 0.0 s · lab check 52.0 s (Defect 1)",
    },
    # ---------------------------------------------------------------------------------------- test suite
    {
        "id": "s5-suite", "screen": "S5", "group": "Generated regression tests", "label": "Generated regression tests", "kind": "table",
        "selector": "#suite table.report",
        "what": "Every test folder under suite/ on this installation, for all runs (not only the selected run), sorted by folder name. "
                "Seven columns: Test name, Error type, Defect, Procedure, Reproduced in at least, Lab check when generated, Files. "
                "\"no regression tests filed yet\" when the folder is empty.",
        "why": "The deliverable of the whole loop: test scripts to run on every future firmware.",
        "when": "Read when Step 6 is opened (enter → loadSuite); the Build button does not reload it.",
        "chain": [
            S("engine", "emit_closed_loop_test() writes suite/<test>/manifest.json, test_<test>.py and conftest.py.",
              "py:stage2/testgen.py::emit_closed_loop_test"),
            S("files", "suite/<test>/manifest.json: card, incident_id, stimulus.steps, measured_at_generation, closed_loop_at_generation."),
            S("server", "suite(): reads the manifest of every folder and lists its files.", "py:app/api/misc_api.py::suite"),
            S("http", "GET /api/suite"),
            S("browser", "loadSuite() draws one row per test.", R + "async function loadSuite() {"),
            S("screen", "The Generated regression tests card under the Report card."),
        ],
        "code": ["py:app/api/misc_api.py::suite"],
        "example": "53 tests on 27 Oct 2026.",
    },
    {
        "id": "s5-suite-help", "screen": "S5", "group": "Generated regression tests",
        "label": "The test name is built from the error type and the procedure's id in the knowledge base; …", "kind": "display",
        "selector": "#suite > p.help",
        "what": "A help line above the test table explaining the test name and the files.",
        "why": "The test names are ids; the line says what they are made of.",
        "when": "Only when at least one test exists.",
        "chain": [
            S("http", "GET /api/suite  →  a non-empty list"),
            S("browser", "loadSuite() writes the line before the table.", R + "async function loadSuite() {"),
            S("screen", "The help line in the Generated regression tests card."),
        ],
        "example": "",
    },
    {
        "id": "s5-suite-name", "screen": "S5", "group": "Generated regression tests", "label": "Test name", "kind": "display",
        "selector": "#suite table.report th:nth-child(1)",
        "what": "The folder name: T-<error type>-<first 8 characters of the procedure's fingerprint (its hash in the knowledge base)>; "
                "when the device is known its name is put in between.",
        "why": "One name per procedure and device: the same error on another drive gets its own test.",
        "when": "",
        "chain": [
            S("engine", "test_manifest() builds test_id; the folder is named after it.", "py:stage2/testgen.py::test_manifest"),
            S("files", "suite/<test>/"),
            S("server", "suite(): test_id = folder name.", "py:app/api/misc_api.py::suite"),
            S("http", "GET /api/suite  →  [].test_id"),
            S("browser", "Writes it.", R + "async function loadSuite() {"),
            S("screen", "First column."),
        ],
        "example": "T-C-16-6effea0f",
    },
    {
        "id": "s5-suite-type", "screen": "S5", "group": "Generated regression tests", "label": "Error type", "kind": "display",
        "selector": "#suite table.report th:nth-child(2)",
        "what": "The error type the test guards, with its chapter.",
        "why": "Tells which catalogue entry a future failure of the test points to.",
        "when": "",
        "chain": [
            S("files", "suite/<test>/manifest.json: card"),
            S("server", "suite(): card.", "py:app/api/misc_api.py::suite"),
            S("http", "GET /api/suite  →  [].card"),
            S("browser", "errorTypeShort() adds the chapter.", A + "export function errorTypeShort(card)"),
            S("screen", "Second column."),
        ],
        "example": "C-16 · NVMe controller and host-driver failures",
    },
    {
        "id": "s5-suite-defect", "screen": "S5", "group": "Generated regression tests", "label": "Defect", "kind": "display",
        "selector": "#suite table.report th:nth-child(3)",
        "what": "The defect the test was generated from, as Defect <n>. The run it belongs to is not shown, so \"Defect 3\" can mean "
                "defect 3 of any run.",
        "why": "Links the test back to the field defect it came from.",
        "when": "",
        "chain": [
            S("files", "suite/<test>/manifest.json: incident_id"),
            S("server", "suite(): incident.", "py:app/api/misc_api.py::suite"),
            S("http", "GET /api/suite  →  [].incident"),
            S("browser", "defectName() turns INC-0003 into Defect 3.", A + "export function defectName(id) {"),
            S("screen", "Third column."),
        ],
        "example": "Defect 3",
    },
    {
        "id": "s5-suite-proc", "screen": "S5", "group": "Generated regression tests", "label": "Procedure", "kind": "display",
        "selector": "#suite table.report th:nth-child(4)",
        "what": "The command steps of the test's procedure, joined by arrows (timing is in the manifest, not shown here).",
        "why": "What the test does to the drive, at a glance.",
        "when": "",
        "chain": [
            S("files", "suite/<test>/manifest.json: stimulus.steps[].op"),
            S("server", "suite(): steps = the op of each step.", "py:app/api/misc_api.py::suite"),
            S("http", "GET /api/suite  →  [].steps"),
            S("browser", "Joins them with →.", R + "<td class=seq>"),
            S("screen", "Fourth column."),
        ],
        "example": "write → reset",
    },
    {
        "id": "s5-suite-repro", "screen": "S5", "group": "Generated regression tests", "label": "Reproduced in at least", "kind": "display",
        "selector": "#suite table.report th:nth-child(5)",
        "what": "\"X % of lab runs\": the 95 % lower bound of the reproduction rate measured by the search when the test was generated.",
        "why": "How reliably the test can be expected to catch the defect; it also sets how many repeats the generated script makes.",
        "when": "",
        "chain": [
            S("engine", "Stage2V3._finish(): the lower bound (Wilson) of reproductions out of lab runs goes into the manifest.",
              "py:stage2/stage2_v3.py::Stage2V3._finish"),
            S("files", "suite/<test>/manifest.json: measured_at_generation.repro_lower95"),
            S("server", "suite(): repro_lower95.", "py:app/api/misc_api.py::suite"),
            S("http", "GET /api/suite  →  [].repro_lower95"),
            S("browser", "Rounds to a whole percent.", R + "${pct(t.repro_lower95)} of lab runs"),
            S("screen", "Fifth column."),
        ],
        "example": "68 % of lab runs (0.676)",
    },
    {
        "id": "s5-suite-lab", "screen": "S5", "group": "Generated regression tests",
        "label": "Lab check when generated (known-bad / fixed firmware)", "kind": "display",
        "selector": "#suite table.report th:nth-child(6)",
        "what": "\"h of n known-bad, h of n fixed\": the closed-loop lab check made when the test was written.",
        "why": "Proof, stored with the test, that it fails on bad firmware and passes on fixed firmware.",
        "when": "",
        "chain": [
            S("engine", "verify_closed_loop() result is stored in the manifest.", "py:stage2/testgen.py::verify_closed_loop"),
            S("files", "suite/<test>/manifest.json: closed_loop_at_generation"),
            S("server", "suite(): closed_loop.", "py:app/api/misc_api.py::suite"),
            S("http", "GET /api/suite  →  [].closed_loop"),
            S("browser", "Writes the two counts.", R + "t.closed_loop.known_bad_hits} of"),
            S("screen", "Sixth column."),
        ],
        "example": "2 of 6 known-bad, 0 of 3 fixed",
    },
    {
        "id": "s5-suite-files", "screen": "S5", "group": "Generated regression tests", "label": "Files", "kind": "display",
        "selector": "#suite table.report th:nth-child(7)",
        "what": "The files in the test folder, sorted by name, each a link: conftest.py (shared test setup), manifest.json (the test's "
                "description and lab evidence) and test_<test>.py (the test script).",
        "why": "The test is meant to be taken out and run elsewhere; the files are the test.",
        "when": "",
        "chain": [
            S("files", "suite/<test>/ folder listing."),
            S("server", "suite(): files = sorted folder listing.", "py:app/api/misc_api.py::suite"),
            S("http", "GET /api/suite  →  [].files"),
            S("browser", "One link per file.", R + "/api/suite/${encodeURIComponent(t.test_id)}"),
            S("screen", "Seventh column."),
        ],
        "example": "conftest.py · manifest.json · test_T_C_16_6effea0f.py",
    },
    {
        "id": "s5-suite-file-link", "screen": "S5", "group": "Generated regression tests", "label": "test_T_C_16_6effea0f.py (any file name)",
        "kind": "link", "selector": "#suite table.report td:nth-child(7) a",
        "what": "Clicking a file name opens that file from the test folder in a new tab.",
        "why": "Lets the reviewer read the generated script and its manifest before trusting it.",
        "when": "",
        "chain": [
            S("you", "You click a file name."),
            S("browser", "The link address names the test and the file.", R + "/api/suite/${encodeURIComponent(t.test_id)}"),
            S("http", "GET /api/suite/<test>/<file>"),
            S("server", "suite_file(): refuses any path outside suite/ (answer 400 \"bad path\"), else sends the file.",
              "py:app/api/misc_api.py::suite_file"),
            S("files", "suite/<test>/<file>"),
            S("screen", "A new tab with the file (or a download, depending on the browser)."),
        ],
        "code": ["py:app/api/misc_api.py::suite_file"],
        "example": "",
    },

    # ================================================================================================ ST · Settings
    {
        "id": "st-heading", "screen": "ST", "group": "AI reviewer",
        "label": "AI reviewer · used twice: the second opinion in stage 1 and the procedure proposal in stage 2", "kind": "display",
        "selector": "#page-settings .card > h2:nth-of-type(1)",
        "what": "The Settings page. Every field is filled once, when the application page loads, from the configuration in memory; "
                "re-opening Settings does not re-read the server.",
        "why": "The project statement requires the AI reviewer's address and model, and the stage-2 limits, to be set for the "
               "production environment without changing code.",
        "when": "Always reachable from the sidebar (never locked).",
        "chain": [
            S("files", "config/app_config.json, read when the server starts.", "py:app/server.py::load_config"),
            S("server", "get_config(): the configuration without internal keys, and the name of the AI reviewer in use. API keys are "
                        "not in the configuration, so they are never sent.", "py:app/api/config_api.py::get_config"),
            S("http", "GET /api/config"),
            S("browser", "At start-up main.js calls settings.init(), which copies each value into its field.", ST + "export function init(state) {"),
            S("screen", "The Settings page with the current values."),
        ],
        "example": "",
    },
    {
        "id": "st-backend", "screen": "ST", "group": "AI reviewer", "label": "How the AI reviewer is reached (backend)", "kind": "select",
        "selector": "#s-backend",
        "what": "Config key llm.backend. cli = the `claude` command-line login on this machine (no key); sdk = the Anthropic API or a company "
                "gateway (base URL + key variable); openai-compat = any chat-completions endpoint; auto = sdk when a key is set, else cli; "
                "standin = no model, fixed answers (tests). In stage 2 the new choice is used at once after Save; if it cannot be reached "
                "(no `claude` command, no key) the stand-in is used silently and the message line says \"stand-in\". Stage 1 uses it from "
                "the next run started: openai-compat and standin make stage 1's second opinion run without a model (dry-run). The value is "
                "part of the run key, so an identical CSV is analysed afresh instead of reused.",
        "why": "Production reaches the model through a company gateway; laptops use the command-line login.",
        "when": "With server.lock_endpoint true (deploy/config.production.example.json) a change is refused with 403 and nothing is saved.",
        "chain": [
            S("you", "You pick a value and press Save."),
            S("browser", "The Save handler sends it as llm.backend.", ST + "const body = { llm: { backend: $(\"s-backend\").value"),
            S("http", PUT_HTTP),
            S("server", "put_config(): refuses a change when the endpoint is locked, else stores it, writes the file and reloads the AI reviewer.", P_LOCK),
            S("service", "make_llm(): builds the AI reviewer object for that backend, or the stand-in when it is not available.", P_MAKE),
            S("service", "For stage 1, llm_backend() maps the value for the analyser (cli, sdk, auto pass through; everything else is dry-run).",
              "py:app/stage1_runner.py::llm_backend"),
            S("files", "config/app_config.json: llm.backend"),
            S("screen", SAVE_SCREEN),
        ],
        "example": "cli in this installation; sdk in deploy/config.production.example.json.",
    },
    {
        "id": "st-model", "screen": "ST", "group": "AI reviewer", "label": "Model", "kind": "field", "selector": "#s-model",
        "what": "Config key llm.model: the model name. Stage 2 uses it at once after Save; stage 1 passes it to the analyser's second "
                "opinion and capture check from the next run started. It is part of the run key and of the verdict-cache key, so a new "
                "model gets fresh second opinions instead of reusing old ones.",
        "why": "The model name differs between accounts and gateways; the statement asks for it to be set here in production.",
        "when": "",
        "chain": [
            S("you", "You type a model name and press Save."),
            S("browser", "Sent as llm.model.", ST + "const body = { llm: { backend: $(\"s-backend\").value"),
            S("http", PUT_HTTP),
            S("server", "put_config() stores it and reloads the AI reviewer.", P_PUT),
            S("service", "reload_llm() → make_llm(): a new AI reviewer object named anthropic:<model>:<effort>.", P_RELOAD),
            S("engine", "AnthropicLLM uses the model for every stage-2 call.", "py:stage2/llm_adapter.py::AnthropicLLM"),
            S("files", "config/app_config.json: llm.model"),
            S("screen", SAVE_SCREEN),
        ],
        "example": "claude-haiku-5-5",
    },
    {
        "id": "st-url", "screen": "ST", "group": "AI reviewer", "label": "API base URL (for the sdk and openai-compat backends)", "kind": "field",
        "selector": "#s-url",
        "what": "Config key llm.base_url. For sdk it is put into the environment variable ANTHROPIC_BASE_URL of the server process (it "
                "stays set until a restart even if the field is later emptied); for openai-compat it is the endpoint address. Used at "
                "once in stage 2 and by the next stage-1 run with sdk.",
        "why": "Production sends every request to the company gateway, not the public API.",
        "when": "Locked in production: with server.lock_endpoint true a change answers 403 \"llm.base_url is locked by "
                "server.lock_endpoint: stop the service, edit the config file, start it again\", because whoever could change it could "
                "send the API key to another server.",
        "chain": [
            S("you", "You type the address and press Save."),
            S("browser", "Sent as llm.base_url.", ST + "const body = { llm: { backend: $(\"s-backend\").value"),
            S("http", PUT_HTTP),
            S("server", "put_config(): the lock check, then store and reload.", P_LOCK),
            S("service", "make_llm(): sets ANTHROPIC_BASE_URL for sdk, or passes the address to the OpenAI-compatible client.", P_MAKE),
            S("files", "config/app_config.json: llm.base_url"),
            S("screen", SAVE_SCREEN),
        ],
        "example": "empty here; https://llm-gateway.example.com in the production example.",
    },
    {
        "id": "st-keyenv", "screen": "ST", "group": "AI reviewer", "label": "API key environment variable", "kind": "field",
        "selector": "#s-keyenv",
        "what": "Config key llm.api_key_env: the NAME of the environment variable that holds the key, never the key. make_llm() copies "
                "that variable into ANTHROPIC_API_KEY only when ANTHROPIC_API_KEY is not set yet, so after the first copy another name "
                "has no effect until a restart; openai-compat reads the named variable directly.",
        "why": "Keys must never be stored in files or shown on screens.",
        "when": "Locked in production (server.lock_endpoint), like the base URL.",
        "chain": [
            S("you", "You type the variable name and press Save."),
            S("browser", "Sent as llm.api_key_env.", ST + "const body = { llm: { backend: $(\"s-backend\").value"),
            S("http", PUT_HTTP),
            S("server", "put_config(): the lock check, then store and reload.", P_LOCK),
            S("service", "make_llm(): reads the key from the named variable.", P_MAKE),
            S("files", "config/app_config.json: llm.api_key_env (the name only)."),
            S("screen", SAVE_SCREEN),
        ],
        "example": "ANTHROPIC_API_KEY",
    },
    {
        "id": "st-time", "screen": "ST", "group": "Stage 2", "label": "First-level triage limit in seconds (600 = 10 minutes)", "kind": "field",
        "selector": "#s-time",
        "what": "Config key stage2.time_budget_s. Applied at once after Save. When a stage-2 search starts, deadline = start + this many "
                "seconds; past it the search stops and the result is marked \"first-level triage limit (10 min) exceeded\". 0, or an "
                "empty field (sent as 0), switches the limit off; the value is not checked. The Report's \"runs within the first-level "
                "triage limit\" chip does not use this field.",
        "why": "The system diagram's rule: more than 10 minutes of first-level triage is a fail.",
        "when": "",
        "chain": [
            S("you", "You type seconds and press Save."),
            S("browser", "Sent as stage2.time_budget_s (a number).", ST + "stage2: { bench: $(\"s-bench\").value"),
            S("http", PUT_HTTP),
            S("server", "put_config() stores it and calls reload_llm().", P_PUT),
            S("service", "reload_llm() copies it to the running stage-2 engine.", P_RELOAD),
            S("engine", "Stage2V3.execute(): deadline for the search and the lab check.",
              "py:stage2/stage2_v3.py::Stage2V3.execute::t_search = time.time()::if action[\"action\"] == \"compose_tests\""),
            S("files", "config/app_config.json: stage2.time_budget_s"),
            S("screen", SAVE_SCREEN),
        ],
        "example": "600",
    },
    {
        "id": "st-consec", "screen": "ST", "group": "Stage 2", "label": "Optimal = the same error isolated in this many lab runs in a row",
        "kind": "field", "selector": "#s-consec",
        "what": "Config key stage2.optimal_consecutive. Applied at once. The lab check calls a procedure optimal when all 3 checks pass "
                "(score above 0.9) in this many known-bad runs in a row. The Report's rules line and the test manifest still show the "
                "constant 3 from stage2/loop_rules.py.",
        "why": "The system diagram's rule: test score above 0.9 three times in a row = optimal parameters.",
        "when": "",
        "chain": [
            S("you", "You type a number and press Save."),
            S("browser", "Sent as stage2.optimal_consecutive.", ST + "stage2: { bench: $(\"s-bench\").value"),
            S("http", PUT_HTTP),
            S("server", "put_config() stores it and calls reload_llm().", P_PUT),
            S("service", "reload_llm() copies it to the engine.", P_RELOAD),
            S("engine", "verify_closed_loop(): optimal = longest run of full scores ≥ this number.", "py:stage2/testgen.py::verify_closed_loop"),
            S("files", "config/app_config.json: stage2.optimal_consecutive"),
            S("screen", SAVE_SCREEN),
        ],
        "example": "3",
    },
    {
        "id": "st-stress", "screen": "ST", "group": "Stage 2",
        "label": "Lab runs for the most-stressful-conditions step (after a reproduction is confirmed, each timing value is pushed harder while the error still appears; 0 = off)",
        "kind": "field", "selector": "#s-stress",
        "what": "Config key stage2.stress_trials. Applied at once. After a reproduction is confirmed, the stress ascent may use this many "
                "lab runs to push each timing value harder; the hardest version that still shows the defect is lab-checked and filed as a "
                "second regression test. 0 switches the step off.",
        "why": "A test at the margin of the trigger guards more than a test at one point; the statement asks for failure-prone conditions.",
        "when": "",
        "chain": [
            S("you", "You type a number and press Save."),
            S("browser", "Sent as stage2.stress_trials.", ST + "stage2: { bench: $(\"s-bench\").value"),
            S("http", PUT_HTTP),
            S("server", "put_config() stores it and calls reload_llm().", P_PUT),
            S("service", "reload_llm() copies it to the engine.", P_RELOAD),
            S("engine", "Stage2V3._stress(): stops at once when the budget is 0.", "py:stage2/stage2_v3.py::Stage2V3._stress"),
            S("files", "config/app_config.json: stage2.stress_trials"),
            S("screen", SAVE_SCREEN),
        ],
        "example": "30",
    },
    {
        "id": "st-advanced", "screen": "ST", "group": "Advanced settings", "label": "Advanced settings (normally left as in the config file)",
        "kind": "button", "selector": "#page-settings details.adv > summary",
        "what": "A fold-out line. Clicking it shows or hides the eight advanced fields below. It sends nothing; the advanced values are "
                "sent with every Save whether the box is open or not.",
        "why": "Keeps values that are rarely changed out of the way of an operator.",
        "when": "",
        "chain": [
            S("you", "You click the line."),
            S("browser", "The browser's built-in fold-out element opens or closes; no JavaScript of the application runs.", IX + "<details class=\"adv\">"),
            S("screen", "The advanced fields appear or disappear."),
        ],
        "example": "",
    },
    {
        "id": "st-effort", "screen": "ST", "group": "Advanced settings",
        "label": "Effort (how much thinking the AI reviewer may spend on stage 2's proposals; stage 1's second opinions always use low)",
        "kind": "select", "selector": "#s-effort",
        "what": "Config key llm.effort (low, medium, high). Applied at once, after Save, to the AI reviewer's stage-2 calls (proposal, "
                "composition of test cases). It is also part of the AI reviewer's name (anthropic:<model>:<effort>) and of the run key, "
                "so after a change an identical CSV is analysed afresh instead of reused. As the label says, stage 1's second opinions "
                "are not affected: the analyser always asks with effort low (fixed in stage1/pcie_isolate/llm.py).",
        "why": "More effort can give better proposals at a higher cost and time.",
        "when": "",
        "chain": [
            S("you", "You pick a value and press Save."),
            S("browser", "Sent as llm.effort.", ST + "const body = { llm: { backend: $(\"s-backend\").value"),
            S("http", PUT_HTTP),
            S("server", "put_config() stores it and reloads the AI reviewer.", P_PUT),
            S("service", "make_llm() passes effort to the new AI reviewer object.", P_MAKE),
            S("engine", "AnthropicLLM sends it with each stage-2 call.", "py:stage2/llm_adapter.py::AnthropicLLM"),
            S("engine", "Stage 1's second opinion always asks with \"--effort\", \"low\", as the label states.", "py:stage1/pcie_isolate/llm.py::cli_structured"),
            S("screen", SAVE_SCREEN),
        ],
        "example": "low",
    },
    {
        "id": "st-batch", "screen": "ST", "group": "Advanced settings",
        "label": "Batches: send all stage 1 second opinions of a run as one batch (sdk backend only; slower to return, cheaper)",
        "kind": "checkbox", "selector": "#s-batch",
        "what": "Config key llm.batch. Used by the next stage-1 run started, only with the sdk backend: the analyser's review is called "
                "with --batch. No effect on stage 2.",
        "why": "Batch requests cost about half; useful for large traces when waiting is acceptable.",
        "when": "",
        "chain": [
            S("you", "You tick the box and press Save."),
            S("browser", "Sent as llm.batch (true/false).", ST + "const body = { llm: { backend: $(\"s-backend\").value"),
            S("http", PUT_HTTP),
            S("server", "put_config() stores it.", P_PUT),
            S("service", "start_run() copies the llm settings into the new run's parameters.", "py:app/api/runs_api.py::start_run"),
            S("service", "run_stage1(): adds --batch to the review step when the backend is sdk.",
              "py:app/stage1_runner.py::run_stage1::if backend != \"dry-run\" and hits < len(incs)::step(\"report\""),
            S("files", "config/app_config.json: llm.batch"),
            S("screen", SAVE_SCREEN),
        ],
        "example": "off",
    },
    {
        "id": "st-capture", "screen": "ST", "group": "Advanced settings",
        "label": "Capture check: one extra model call per run that says whether the capture as a whole can show the error",
        "kind": "checkbox", "selector": "#s-capture",
        "what": "Config key llm.capture_check. Used by the next stage-1 run started: after the report step one more model call judges the "
                "whole capture. Advisory: if it fails, the run still completes. Skipped when stage 1 runs without a model.",
        "why": "Warns when a capture (filters, gaps) cannot show the defect at all, before anyone trusts an empty result.",
        "when": "",
        "chain": [
            S("you", "You tick or untick the box and press Save."),
            S("browser", "Sent as llm.capture_check.", ST + "const body = { llm: { backend: $(\"s-backend\").value"),
            S("http", PUT_HTTP),
            S("server", "put_config() stores it.", P_PUT),
            S("service", "run_stage1(): runs the capture_check step when it is on.",
              "py:app/stage1_runner.py::run_stage1::if cfg.get(\"capture_check\", True)::# ---------------- store the new verdicts"),
            S("engine", "capture_check() asks the model once about the whole capture.", "py:stage1/pcie_isolate/llm.py::capture_check"),
            S("files", "config/app_config.json: llm.capture_check; the run writes runs/<run>/capture_assessment.json."),
            S("screen", SAVE_SCREEN),
        ],
        "example": "on; in run \"exercise A\" it took 15.36 s of 17.9 s of stage 1.",
    },
    {
        "id": "st-bench", "screen": "ST", "group": "Advanced settings",
        "label": "Bench (where lab runs happen: synthetic = a simulated drive, hook = your real device through app/bench_hook.py)",
        "kind": "select", "selector": "#s-bench",
        "what": "Config key stage2.bench. Read only when the server starts: with hook, every lab run goes to HardwareBench in "
                "app/bench_hook.py; with synthetic, to the simulated drive. Save writes it to the file but does not apply it; when the "
                "value differs from the one loaded with the page, the message line adds \"· the Bench change takes effect after a "
                "restart of the application\". Save does not change the sidebar's \"lab device\" badge: main.js writes it once, when "
                "the page loads, so it keeps naming the bench that is really in use until the restart and a reload.",
        "why": "The same workflow runs on a laptop with a simulated drive and in the lab with the real device.",
        "when": "",
        "chain": [
            S("you", "You pick a value and press Save."),
            S("browser", "Sent as stage2.bench; the handler compares it with the value at load to add the restart note.",
              ST + "const r = await api(\"PUT\", \"/api/config\", body)"),
            S("http", PUT_HTTP),
            S("server", "put_config() writes it to the file; reload_llm() does not touch the bench.", P_PUT),
            S("service", "After a restart, Stage2Service.__init__ passes a bench factory for the real device when the value is hook.",
              "py:app/stage2_service.py::Stage2Service.__init__"),
            S("engine", "HardwareBench: the hook to your device.", "py:app/bench_hook.py::HardwareBench"),
            S("files", "config/app_config.json: stage2.bench"),
            S("browser", "The \"lab device\" badge is set only at page load, from the configuration in memory.",
              M + "$(\"bench-badge\").textContent = benchWord"),
            S("screen", "The message line with the restart note; the badge is unchanged."),
        ],
        "example": "synthetic (badge \"simulated device\"). On the scratch copy, changing it to hook and pressing Save added \"· the Bench "
                   "change takes effect after a restart of the application\" and the badge stayed \"simulated device\".",
    },
    {
        "id": "st-searchon", "screen": "ST", "group": "Advanced settings",
        "label": "Search on (model = the search predicts results, bench = every trial is run on the lab device)", "kind": "select",
        "selector": "#s-searchon",
        "what": "Config key stage2.search_on. Applied at once. model: the search tries its procedures on a fast device model and the bench "
                "is used for the checks; bench: every search trial is a lab run. The lab check on known-bad and fixed firmware always "
                "runs on the bench.",
        "why": "A real device is slow; searching on a model keeps the search inside the triage limit.",
        "when": "",
        "chain": [
            S("you", "You pick a value and press Save."),
            S("browser", "Sent as stage2.search_on.", ST + "stage2: { bench: $(\"s-bench\").value"),
            S("http", PUT_HTTP),
            S("server", "put_config() stores it and calls reload_llm().", P_PUT),
            S("service", "reload_llm() copies it to the engine.", P_RELOAD),
            S("engine", "Stage2V3.execute(): oracle = bench or device model.",
              "py:stage2/stage2_v3.py::Stage2V3.execute::expected, decoy = self._expected::t_search = time.time()"),
            S("files", "config/app_config.json: stage2.search_on"),
            S("screen", SAVE_SCREEN),
        ],
        "example": "model",
    },
    {
        "id": "st-budget", "screen": "ST", "group": "Advanced settings",
        "label": "Search trials (how many procedure variations the search may try before it gives up)", "kind": "field",
        "selector": "#s-budget",
        "what": "Config key stage2.opt_budget. Applied at once. The search's budget per defect (composed test variants use at most 120).",
        "why": "Bounds the cost of one search; together with the time limit it keeps stage 2 predictable.",
        "when": "",
        "chain": [
            S("you", "You type a number and press Save."),
            S("browser", "Sent as stage2.opt_budget.", ST + "stage2: { bench: $(\"s-bench\").value"),
            S("http", PUT_HTTP),
            S("server", "put_config() stores it and calls reload_llm().", P_PUT),
            S("service", "reload_llm() copies it to the engine.", P_RELOAD),
            S("engine", "Stage2V3._optimizer(): builds the search with this budget.", "py:stage2/stage2_v3.py::Stage2V3._optimizer"),
            S("files", "config/app_config.json: stage2.opt_budget"),
            S("screen", SAVE_SCREEN),
        ],
        "example": "300",
    },
    {
        "id": "st-nbad", "screen": "ST", "group": "Advanced settings",
        "label": "Known-bad repeats (how many times a procedure is re-run on the firmware known to be bad during the lab check; the check passes when the error appears at least once there and never on the fixed firmware)",
        "kind": "field", "selector": "#s-nbad",
        "what": "Config key stage2.n_bad. Applied at once, after Save: the number of known-bad runs in the lab check. As the label says, "
                "the check passes, and the test is filed, when at least one of these runs shows the error and none of the fixed runs "
                "does. The lab check is reached only after the search counts the procedure as reproduced: the 95 % lower bound of its "
                "reproduction rate must be at least 0.5.",
        "why": "More repeats give a more reliable lab check at the cost of lab time.",
        "when": "",
        "chain": [
            S("you", "You type a number and press Save."),
            S("browser", "Sent as stage2.n_bad.", ST + "stage2: { bench: $(\"s-bench\").value"),
            S("http", PUT_HTTP),
            S("server", "put_config() stores it and calls reload_llm().", P_PUT),
            S("service", "reload_llm() copies it to the engine.", P_RELOAD),
            S("engine", "Stage2V3._finish(): reproduced = lower bound ≥ 0.5, then the lab check.",
              "py:stage2/stage2_v3.py::Stage2V3._finish::lower = wilson_lower::fp = {"),
            S("engine", "verify_closed_loop(): passed = known-bad hits ≥ 1 and fixed hits = 0.", "py:stage2/testgen.py::verify_closed_loop"),
            S("screen", SAVE_SCREEN),
        ],
        "example": "6",
    },
    {
        "id": "st-nfixed", "screen": "ST", "group": "Advanced settings",
        "label": "Fixed repeats (how many times it is re-run on the fixed firmware, where the error must not appear)", "kind": "field",
        "selector": "#s-nfixed",
        "what": "Config key stage2.n_fixed. Applied at once: the number of runs on the fixed firmware in the lab check; one hit there and "
                "no test is filed.",
        "why": "A test that also fails on fixed firmware would raise false alarms on every future release.",
        "when": "",
        "chain": [
            S("you", "You type a number and press Save."),
            S("browser", "Sent as stage2.n_fixed.", ST + "stage2: { bench: $(\"s-bench\").value"),
            S("http", PUT_HTTP),
            S("server", "put_config() stores it and calls reload_llm().", P_PUT),
            S("service", "reload_llm() copies it to the engine.", P_RELOAD),
            S("engine", "verify_closed_loop(): fixed hits must be 0.", "py:stage2/testgen.py::verify_closed_loop"),
            S("files", "config/app_config.json: stage2.n_fixed"),
            S("screen", SAVE_SCREEN),
        ],
        "example": "3",
    },
    {
        "id": "st-save", "screen": "ST", "group": "Save", "label": "Save", "kind": "button", "selector": "#btn-save",
        "what": "Sends every field of this page in one request, plus two fields of Step 1: the firmware label and namespace size typed "
                "there become the defaults stage1.firmware_label and stage1.nsze. The server merges the values, writes the whole "
                "configuration to config/app_config.json and rebuilds the AI reviewer and the stage-2 limits at once "
                "(Stage2Service.reload_llm). Bench, the allowed trace folders and the server address and port need a restart; the "
                "model, backend, batch and capture-check settings reach stage 1 with the next run started. The AI reviewer usage counters "
                "restart from zero (a new AI reviewer object). A server started with --standin writes backend standin into the file on "
                "the next Save.",
        "why": "The statement: \"in the production environment put the final API URL and model name\". The lock (server.lock_endpoint) "
               "stops anyone who reaches the page from redirecting the key, turning on web search or widening the readable folders.",
        "when": "With server.lock_endpoint true, a change of llm.base_url, llm.api_key_env, llm.backend, llm.tools or "
                "paths.allowed_csv_roots is refused with 403 and nothing at all is saved.",
        "chain": [
            S("you", "You press Save."),
            S("browser", "Collects the fields into {llm, stage2, stage1}.", ST + "$(\"btn-save\").onclick = async () => {"),
            S("http", PUT_HTTP),
            S("server", "put_config(): lock check, merge of the sections llm, stage1, stage2, paths, write, reload.", P_PUT),
            S("server", "save_config(): writes every key except the internal _path; the help notes inside the sections are kept.", P_SAVE),
            S("service", "reload_llm(): new AI reviewer; opt_budget, optimizer, time_budget_s, stress_trials, optimal_consecutive, n_bad, "
                         "n_fixed, search_on copied into the running engine.", P_RELOAD),
            S("files", "config/app_config.json rewritten."),
            S("screen", SAVE_SCREEN),
        ],
        "code": [P_PUT, P_SAVE, P_RELOAD],
        "example": "On a scratch copy started with --standin, Save answered {\"llm_active\": \"stand-in\", \"ok\": true} and the file then "
                   "held backend \"standin\" and the Step-1 firmware label; with server.lock_endpoint true, a new base URL answered 403 "
                   "\"llm.base_url is locked by server.lock_endpoint: stop the service, edit the config file, start it again\".",
    },
    {
        "id": "st-msg", "screen": "ST", "group": "Save", "label": "saved · the AI reviewer now in use: …", "kind": "display",
        "selector": "#s-msg",
        "what": "The line next to Save: \"saved · the AI reviewer now in use: <name>\", plus \"· the Bench change takes effect after a "
                "restart of the application\" when Bench changed, or \"could not save: <reason>\". The name is the plain form made by "
                "llmWord() in main.js from the server's internal name: anthropic:claude-haiku-5-5:low becomes \"Anthropic "
                "claude-haiku-5-5\" (the effort is left out), stand-in becomes \"stand-in (no model)\". The sidebar's \"AI reviewer\" "
                "badge gets the same plain name, so it reads as it did at page load. The \"lab device\" badge is not touched by Save.",
        "why": "Confirms which AI reviewer is really in use after the change; a backend that cannot be reached shows up here as stand-in.",
        "when": "Empty until Save is pressed.",
        "chain": [
            S("server", "put_config() answers with the name of the new AI reviewer object, or an error.", P_PUT),
            S("http", "200 {ok: true, llm_active}   or   403 {error}"),
            S("browser", "api() turns an error answer into a message.", A + "export async function api(method, url, body) {"),
            S("browser", "The Save handler writes the line, adds the restart note when Bench changed, and writes the AI reviewer badge.",
              ST + "const r = await api(\"PUT\", \"/api/config\", body)"),
            S("browser", "llmWord() turns the internal name into the plain name used in both places.", M + "export const llmWord = (n) =>"),
            S("screen", "The message line, and the sidebar's AI reviewer badge with the same plain name."),
        ],
        "example": "On the scratch copy: \"saved · the AI reviewer now in use: Anthropic claude-haiku-5-5\", badge \"Anthropic "
                   "claude-haiku-5-5\" before and after; with Bench changed to hook the line ended \"· the Bench change takes effect "
                   "after a restart of the application\" and the lab device badge stayed \"simulated device\".",
    },
    {
        "id": "st-note", "screen": "ST", "group": "Save",
        "label": "API keys are read from the named environment variable and never stored. In the production environment put the final API URL and model name here.",
        "kind": "display", "selector": "#page-settings p.help",
        "what": "A fixed note under the Save button.",
        "why": "Tells the operator where the key comes from and what must be set for production.",
        "when": "",
        "chain": [
            S("files", "Written in the page.", IX + "API keys are read from the named environment variable"),
            S("server", "get_config() never contains a key, only the variable name.", "py:app/api/config_api.py::get_config"),
            S("screen", "The note at the bottom of the Settings card."),
        ],
        "example": "",
    },

    # ================================================================================================ HP · help
    {
        "id": "hp-page", "screen": "HP", "group": "The page", "label": "What the words on these screens mean", "kind": "display",
        "selector": "#page-help",
        "what": "A page of fixed text inside the application: an introduction, the table of words and the table of chapter letters. It is "
                "part of index.html, loaded with the application; showing it sends no request and runs no page code (its entry in "
                "main.js is empty).",
        "why": "The plain-language rule of the project: every word on the screens is explained inside the application, so an operator "
               "or manager needs no separate document.",
        "when": "Always reachable from the sidebar entry \"What the words mean\" (never locked).",
        "chain": [
            S("you", "You click \"What the words mean\" in the sidebar."),
            S("browser", "show(\"help\") makes the help section visible and sets the title.", M + "export function show(page, arg, step) {"),
            S("files", "app/static/index.html, section page-help.", IX + "<section id=\"page-help\" class=\"page\">"),
            S("screen", "The help page."),
        ],
        "example": "",
    },
    {
        "id": "hp-glossary", "screen": "HP", "group": "The page", "label": "Word / Meaning", "kind": "table",
        "selector": "#page-help table.glossary:nth-of-type(1)",
        "what": "37 rows, in the order the words are met: Defect, Error type, the catalogue, Error family, AI reviewer, Confirmed / "
                "Suspect / Needs evidence, Procedure, Lab run, Reproduced in at least X %, Score, First-level triage limit, Regression "
                "test, Knowledge base, Key results and others. Three rows do not match the code: \"Key results\" describes a list (defects "
                "found, reproduced, tests, still open) that is not what the report's chips show; \"verdict reused from the cache\" says "
                "the same error family was confirmed earlier, while the cache key is error type, rule, family, layer, rule set, "
                "evidence-row sequence, model and prompt version, and non-confirmed verdicts are reused too; \"First-level triage limit\" "
                "is stage 2's time per defect, while the report's chip of that name applies the fixed 600 s to stage 1 per run.",
        "why": "One reference for all terms. The same words are produced by the translation helpers in api.js and decision.js; the two "
               "are kept in step by hand.",
        "when": "",
        "chain": [
            S("files", "Fixed text in app/static/index.html.", IX + "<th style=\"width:26%\">Word</th>"),
            S("browser", "No code; the table is plain page text.", M + "const PAGES = { run, commands, incidents, review, report, settings, help: {} };"),
            S("screen", "The first table of the help page."),
        ],
        "example": "",
    },
    {
        "id": "hp-chapters", "screen": "HP", "group": "The page", "label": "The letter in an error type id", "kind": "table",
        "selector": "#page-help table.glossary:nth-of-type(2)",
        "what": "Ten rows, Letter and Chapter: S, T, D, L, C, X, V, P, M, N with the chapter of the catalogue each letter names; the number "
                "after the letter is only the position inside the chapter.",
        "why": "Error type ids such as T-42 appear on every screen; the letter is the only part with a meaning. The same ten texts are "
               "in CATALOGUE_GROUPS in api.js, which writes \"T-42 · timeouts and time limits\" everywhere; the two copies match today "
               "and must be kept in step by hand.",
        "when": "",
        "chain": [
            S("files", "Fixed text in app/static/index.html.", IX + "<th style=\"width:26%\">Letter</th>"),
            S("browser", "The same texts drive errorTypeShort() and errorTypeFull() on the other screens.", A + "export const CATALOGUE_GROUPS = {"),
            S("screen", "The second table of the help page."),
        ],
        "example": "T = timeouts and time limits",
    },

    # ================================================================================================ KB · /db
    {
        "id": "kb-header", "screen": "KB", "group": "Header and counts",
        "label": "Knowledge base · everything the admin's decisions have built: error types seen, causes, procedures, regression tests (every change is logged and can be undone)",
        "kind": "display", "selector": ".header-bar",
        "what": "The dark bar at the top of the separate Knowledge base page (address /db), which the sidebar opens in a new tab.",
        "why": "The knowledge base is what the loop learns; a page of its own lets it be inspected next to the workflow.",
        "when": "",
        "chain": [
            S("you", "You click \"Knowledge base (opens in a new tab)\" in the sidebar."),
            S("http", "GET /db"),
            S("server", "create_app() serves db.html for /db.", "py:app/server.py::create_app"),
            S("files", "app/static/db.html", DH + "<div class=\"header-bar\">"),
            S("screen", "The Knowledge base page, which loads its counts at once (overview)."),
        ],
        "example": "",
    },
    {
        "id": "kb-back", "screen": "KB", "group": "Header and counts", "label": "← back to the workflow", "kind": "link",
        "selector": ".header-bar a[href=\"/\"]",
        "what": "A link to the workflow page. It opens the start page in this tab; the run that was selected in the other tab is not "
                "carried over, so the workflow starts at Step 1 with no run selected.",
        "why": "A way back when the page was opened by hand or the other tab was closed.",
        "when": "",
        "chain": [
            S("you", "You click the link."),
            S("http", "GET /"),
            S("server", "create_app() serves index.html.", "py:app/server.py::create_app"),
            S("browser", "main.js starts afresh: nothing is selected unless the address names a run.", M + "const wanted = new URLSearchParams"),
            S("screen", "Step 1 · Choose the trace."),
        ],
        "example": "",
    },
] + [
    # ------------------------------------------------------------------ the ten count chips (GET /api/db/overview)
    {
        "id": "kb-chip-" + cid, "screen": "KB", "group": "Header and counts", "label": label, "kind": "display",
        "selector": "#db-chips .chip:nth-child(%d)" % n,
        "what": what, "why": why, "when": "",
        "chain": [
            S("database", db),
            S("engine" if eng.startswith("py:stage2") else "service", engtext, eng),
            S("server", "overview(): collects the counts of the knowledge base, the procedure graph and the verdict cache.", P_OV),
            S("http", "GET /api/db/overview  →  " + key),
            S("browser", "overview() writes the ten chips.", D + "[\"events logged\", k.events]"),
            S("screen", "Chip %d at the top of the page." % n),
        ],
        "example": ex,
    }
    for n, cid, label, what, why, db, eng, engtext, key, ex in [
        (1, "events", "events logged",
         "The number of rows in the event log, everything that ever happened, including undone events and the undo events themselves.",
         "Shows the size of the history every other count is computed from.",
         "db/knowledge.sqlite table event: COUNT(*).", P_KSTATS, "KGDB.stats(): events.", "knowledge.events", "1178"),
        (2, "sigs", "error types seen", "The number of different error types the knowledge base has met (rows of table signature).",
         "How many distinct defects the loop has learned about.",
         "db/knowledge.sqlite table signature.", P_KSTATS, "KGDB.stats(): signatures.", "knowledge.signatures", "5"),
        (3, "causes", "causes", "The number of active causes (table node, kind cause, status active).",
         "Causes are what the admin's feedback is counted against.",
         "db/knowledge.sqlite table node.", P_KSTATS, "KGDB.stats(): cause_nodes.", "knowledge.cause_nodes", "4"),
        (4, "procs", "procedures",
         "The number of active procedure items in the procedure graph: one per proposed procedure, whatever its status (proposed, "
         "failed validation, awaiting approval, approved, replaced, retired).",
         "Shows how many reproductions have been tried and kept on record.",
         "db/knowledge.sqlite table pnode, kind scenario, status active.", P_GSTATS, "ProcGraph.stats(): n_scenario.", "graph.n_scenario", "60"),
        (5, "approved", "approved procedures",
         "Procedures with status admin-approved: validated in the lab and approved by a second admin (four-eyes rule).",
         "Approved procedures are the reference procedures reused for recurring defects.",
         "db/knowledge.sqlite table solution, status admin-approved.", P_KSTATS, "KGDB.stats(): approved_solutions.", "knowledge.approved_solutions", "2"),
        (6, "tests", "regression tests",
         "Active test items in the procedure graph. One is created for every lab check of a procedure, whether or not it passed and "
         "even when the same procedure is checked again, so this is larger than the number of test folders (filed tests) in suite/.",
         "Meant to show how many tests the loop has produced.",
         "db/knowledge.sqlite table pnode, kind test, status active.", P_GSTATS, "ProcGraph.stats(): n_test.", "graph.n_test", "173, while suite/ holds 53 test folders"),
        (7, "lessons", "lessons",
         "Notes recorded about an error type, by the admin or by the lab, that the AI reviewer must read before its next proposal.",
         "Lessons carry what went wrong into the next attempt.",
         "db/knowledge.sqlite table lesson.", P_KSTATS, "KGDB.stats(): lessons.", "knowledge.lessons", "38"),
        (8, "links", "links between causes and procedures",
         "The number of ALL links in the procedure graph, of every kind (error type → cause, cause → procedure, procedure → test, "
         "newer → older version, lesson → item, procedure → firmware context) and in any status. Only the cause → procedure links "
         "(kind REPRODUCED_BY) match the label.",
         "Meant to show how connected the learned knowledge is.",
         "db/knowledge.sqlite table pedge: COUNT(*).", P_GSTATS, "ProcGraph.stats(): pedges.", "graph.pedges",
         "335, of which 61 are cause → procedure links"),
        (9, "cache", "verdicts reused from the cache",
         "\"<entries> (<n> times reused)\": the number of stage-1 second opinions stored in the verdict cache, and how often they were reused.",
         "Shows what the cache holds and what it saved.",
         "db/app.sqlite table verdict_cache: COUNT(*) and SUM(hits).", P_CSTATS, "VerdictCache.stats().", "cache.entries, cache.hits",
         "195 (99 times reused)"),
        (10, "llm", "AI reviewer",
         "The name of the AI reviewer object stage 2 is using right now, in its internal form (the workflow's sidebar translates the "
         "same name into plain words; this page does not).",
         "Says which model and effort the stage-2 proposals are coming from.",
         "Not stored: the running server's AI reviewer object, rebuilt by every Settings Save.", P_RELOAD,
         "Stage2Service.reload_llm() / make_llm() decide which object is in use.", "llm", "anthropic:claude-haiku-5-5:low"),
    ]
] + [
    # ------------------------------------------------------------------ the five tabs
    {
        "id": "kb-tab-signatures", "screen": "KB", "group": "Tabs", "label": "Error types seen & procedures", "kind": "tab",
        "selector": ".tabs button[data-sub=\"signatures\"]",
        "what": "The first tab, open by default: the table of error types on the left and the tree of the chosen error type on the right.",
        "why": "The everyday view: what is known about each error type.",
        "when": "",
        "chain": [
            S("you", "You click the tab."),
            S("browser", "The tab handler shows section sub-signatures; no request (its data came with the overview).",
              D + "document.querySelectorAll(\".tabs button\").forEach(b => b.onclick"),
            S("screen", "The error-types table and the tree."),
        ],
        "example": "",
    },
    {
        "id": "kb-tab-tables", "screen": "KB", "group": "Tabs", "label": "Tables (advanced)", "kind": "tab",
        "selector": ".tabs button[data-sub=\"tables\"]",
        "what": "Shows the raw-table viewer: choose a table, an error type and a row count, then press Load.",
        "why": "For an audit: everything the summaries are built from, exactly as stored.",
        "when": "",
        "chain": [
            S("you", "You click the tab."),
            S("browser", "Shows section sub-tables; nothing is loaded until you press Load.",
              D + "document.querySelectorAll(\".tabs button\").forEach(b => b.onclick"),
            S("screen", "The table picker."),
        ],
        "example": "",
    },
    {
        "id": "kb-tab-events", "screen": "KB", "group": "Tabs", "label": "Event log", "kind": "tab",
        "selector": ".tabs button[data-sub=\"events\"]",
        "what": "Shows the event log with the Undo controls. Clicking the tab reloads the 60 most recent events (the page load showed 25).",
        "why": "Every change of the knowledge base is an event; this is where one can be undone.",
        "when": "",
        "chain": [
            S("you", "You click the tab."),
            S("browser", "Shows section sub-events and calls loadEvents().", D + "document.querySelectorAll(\".tabs button\").forEach(b => b.onclick"),
            S("http", "GET /api/db/table/event?limit=60"),
            S("server", "table() → Stage2Service.db_table(\"event\"), newest first.", P_TABLE),
            S("screen", "The event table."),
        ],
        "example": "",
    },
    {
        "id": "kb-tab-cache", "screen": "KB", "group": "Tabs", "label": "Verdicts reused from the cache", "kind": "tab",
        "selector": ".tabs button[data-sub=\"cache\"]",
        "what": "Shows the stage-1 verdict cache. Each click reloads it.",
        "why": "Shows which second opinions are reused without a model call, and where each was first given.",
        "when": "",
        "chain": [
            S("you", "You click the tab."),
            S("browser", "Shows section sub-cache and calls loadCache().", D + "async function loadCache() {"),
            S("http", "GET /api/db/cache"),
            S("server", "cache(): the cache counts and up to 200 rows, newest first.", "py:app/api/db_api.py::cache"),
            S("screen", "The cache table."),
        ],
        "example": "",
    },
    {
        "id": "kb-tab-llm", "screen": "KB", "group": "Tabs", "label": "AI reviewer usage", "kind": "tab",
        "selector": ".tabs button[data-sub=\"llm\"]",
        "what": "Shows the raw usage counters of the AI reviewer and of stage 2, as loaded with the page (no reload on click).",
        "why": "Cost and activity at a glance for the person who pays for the model.",
        "when": "",
        "chain": [
            S("you", "You click the tab."),
            S("browser", "Shows section sub-llm; its text was written by overview().", D + "$(\"llm-usage\").textContent"),
            S("screen", "The counters as text."),
        ],
        "example": "",
    },
    # ------------------------------------------------------------------ error types table
    {
        "id": "kb-sig-table", "screen": "KB", "group": "Error types seen & procedures",
        "label": "Error types seen (each with its failure signature, the fingerprint of the defect)", "kind": "table",
        "selector": "#sig-table",
        "what": "One row per error type in the knowledge base, most often seen first. Nine columns: Error type, Chapter, Error family, "
                "Times seen, Causes, Procedures, Approved, Tests, Lessons. \"empty - the knowledge base fills as the admin decides\" "
                "when there is none.",
        "why": "The overview of everything learned, per error type.",
        "when": "",
        "chain": [
            S("database", "db/knowledge.sqlite tables signature, node, solution, lesson and pnode."),
            S("engine", "KGDB.all_signatures(), causes(), solutions(), lessons() and ProcGraph.nodes(\"test\", sig).", "py:stage2/kgdb.py::KGDB.all_signatures"),
            S("server", "overview(): one entry per error type, sorted by times seen.", P_OV),
            S("http", "GET /api/db/overview  →  signatures[]"),
            S("browser", "renderSigs() draws the rows.", D + "function renderSigs() {"),
            S("screen", "The table on the left."),
        ],
        "code": [P_OV],
        "example": "T-42: chapter T, family P19, seen 58 times, 1 cause, 43 procedures, 1 approved, 131 tests, 26 lessons.",
    },
] + [
    {
        "id": "kb-col-" + cid, "screen": "KB", "group": "Error types seen & procedures", "label": label, "kind": "display",
        "selector": "#sig-table th:nth-child(%d)" % n, "what": what, "why": why, "when": "",
        "chain": [
            S("database", db),
            S("server", "overview(): " + srv, P_OV),
            S("http", "GET /api/db/overview  →  signatures[]." + key),
            S("browser", brw, bref),
            S("screen", "Column %d of the error-types table." % n),
        ],
        "example": ex,
    }
    for n, cid, label, what, why, db, srv, key, brw, bref, ex in [
        (1, "type", "Error type", "The catalogue id of the error type, in bold.", "The key everything else in the row belongs to.",
         "db/knowledge.sqlite table signature: sig.", "sig.", "sig", "Writes the id.", D + "function renderSigs() {", "T-42"),
        (2, "chapter", "Chapter", "\"<letter> = <chapter>\": the chapter of the catalogue the letter names.",
         "Reads the id for a person who does not know the catalogue.", "Not stored: computed from the id.", "sig.", "sig",
         "chapterOf() uses the chapter list in api.js.", D + "const chapterOf = (sig) =>", "T = timeouts and time limits"),
        (3, "family", "Error family",
         "How the failure shows on the wire, written out with its family number, as stored when the error type was first seen.",
         "The family is what verdicts and procedures are compared on across error types.",
         "db/knowledge.sqlite table signature: pattern.", "pattern.", "pattern", "familyName() writes the family out.",
         A + "export function familyName(p)", "configuration space, power state and reset sequencing (family P19)"),
        (4, "seen", "Times seen",
         "How many times a defect of this error type was looked up in stage 2: each lookup (also \"Look up again\") adds an "
         "incident_seen event and raises the count by one.",
         "Shows which defects recur in the field.", "db/knowledge.sqlite table signature: seen.", "seen.", "seen", "Writes the number.",
         D + "function renderSigs() {", "58"),
        (5, "causes", "Causes", "Active causes recorded for this error type.", "Each cause collects its own feedback and procedures.",
         "db/knowledge.sqlite table node (kind cause, status active).", "len(causes(sig)).", "causes", "Writes the number.",
         D + "function renderSigs() {", "1"),
        (6, "procs", "Procedures", "Every procedure ever proposed for this error type, whatever its status.",
         "Shows how much reproduction work exists for it.", "db/knowledge.sqlite table solution.", "len(solutions(sig)).", "procedures",
         "Writes the number.", D + "function renderSigs() {", "43"),
        (7, "approved", "Approved", "Procedures approved by a second admin.", "The reference procedures for this error type.",
         "db/knowledge.sqlite table solution, status admin-approved.", "solutions with status admin-approved.", "approved",
         "Writes the number.", D + "function renderSigs() {", "1"),
        (8, "tests", "Tests",
         "Test items of this error type: one per lab check of a procedure, filed or not (see the regression tests chip).",
         "Meant to show how well the error type is guarded.", "db/knowledge.sqlite table pnode, kind test.",
         "ProcGraph.nodes(\"test\", sig).", "tests", "Writes the number.", D + "function renderSigs() {", "131"),
        (9, "lessons", "Lessons", "Lessons recorded for this error type (counted up to 50).",
         "What the AI reviewer must read before proposing again.", "db/knowledge.sqlite table lesson.", "len(lessons(sig, 50)).",
         "lessons", "Writes the number.", D + "function renderSigs() {", "26"),
    ]
] + [
    {
        "id": "kb-sig-filter", "screen": "KB", "group": "Error types seen & procedures", "label": "filter by error type, chapter or error family",
        "kind": "field", "selector": "#sig-filter",
        "what": "Typing here hides the rows that do not contain the text. It compares with the error type id, the family NUMBER (for "
                "example P19) and the chapter text; the written-out family name shown in the table (for example \"flow-control credit "
                "stall\") is not searched.",
        "why": "Finds one error type quickly when many are known.",
        "when": "",
        "chain": [
            S("you", "You type, for example T- or timeouts."),
            S("browser", "Each key press redraws the table from the data already loaded; nothing is sent.", D + "$(\"sig-filter\").oninput = renderSigs;"),
            S("browser", "The text compared is id + family number + chapter text, in lower case.", D + "function renderSigs() {"),
            S("screen", "Only the matching rows remain."),
        ],
        "example": "",
    },
    {
        "id": "kb-sig-row", "screen": "KB", "group": "Error types seen & procedures", "label": "(a row of the error-types table)", "kind": "row",
        "selector": "#sig-table tbody tr.click",
        "what": "Clicking a row loads the tree of that error type into the right-hand card: each cause with its ratings, under it each "
                "procedure with its status, numbers, steps, tests and versions, then the lessons.",
        "why": "Shows why the knowledge base proposes what it proposes for this error type.",
        "when": "",
        "chain": [
            S("you", "You click a row."),
            S("browser", "openSig() asks for the error type's tree.", D + "async function openSig(sig) {"),
            S("http", "GET /api/db/signature/<error type>"),
            S("server", "signature(): groups the procedures under their causes and adds tests and version chain to each.", P_SIG),
            S("service", "Stage2Service.procedures(): causes with their text and feedback counts, all procedures, lessons.", P_PROCS),
            S("engine", "ProcGraph.procedures_for(): error type → cause → procedure, with the counts of both links.", P_PFOR),
            S("database", "db/knowledge.sqlite tables node, node_version, edge, pnode, pedge, solution, lesson."),
            S("screen", "The tree on the right."),
        ],
        "code": [P_SIG, P_PROCS, P_PFOR],
        "example": "",
    },
    {
        "id": "kb-tree-title", "screen": "KB", "group": "The tree of one error type", "label": "Select an error type", "kind": "display",
        "selector": "#sig-title",
        "what": "The heading of the right-hand card: \"Select an error type\" until a row is clicked, then the error type written out in full.",
        "why": "Names the error type the tree belongs to in words.",
        "when": "",
        "chain": [
            S("you", "You click a row."),
            S("browser", "openSig() sets the heading.", D + "async function openSig(sig) {"),
            S("browser", "errorTypeFull() writes the id with chapter and entry number.", A + "export function errorTypeFull(card, title)"),
            S("screen", "The heading of the tree card."),
        ],
        "example": "error type T-42 (chapter T = timeouts and time limits, entry 42)",
    },
    {
        "id": "kb-tree-cause", "screen": "KB", "group": "The tree of one error type", "label": "cause", "kind": "display",
        "selector": "#sig-tree .node",
        "what": "One box per active cause: the word cause and the cause's text (its newest version). \"no causes saved for this error "
                "type yet\" when there is none.",
        "why": "Procedures hang under causes: the same error type can have several causes, each reproduced differently.",
        "when": "",
        "chain": [
            S("database", "db/knowledge.sqlite table node (the cause) and node_version (its text versions)."),
            S("engine", "KGDB.causes() and KGDB.content() (newest version).", "py:stage2/kgdb.py::KGDB.content"),
            S("service", "Stage2Service.procedures(): causes [{id, content, edge}].", P_PROCS),
            S("http", "GET /api/db/signature/<error type>  →  tree[].content"),
            S("browser", "openSig() writes one box per cause.", D + "async function openSig(sig) {"),
            S("screen", "A box in the tree."),
        ],
        "example": "cause \"revised by exercise\" (T-42)",
    },
    {
        "id": "kb-tree-rating", "screen": "KB", "group": "The tree of one error type",
        "label": "admin feedback rating … from … decisions (1 = always judged correct)", "kind": "display",
        "selector": "#sig-tree .node > span:nth-of-type(2)",
        "what": "a ÷ (a + b) of the link from the error type to this cause, with n decisions. a grows with every \"correct\" verdict "
                "and b with every \"not correct\" (both start at 1; each new verdict first shrinks the older counts a little, and "
                "editing the cause's text shrinks them more).",
        "why": "The learned belief that this cause is the right one, from the admins' feedback; it orders the causes.",
        "when": "",
        "chain": [
            S("database", "db/knowledge.sqlite table edge (error type → cause): a, b, n."),
            S("engine", "KGDB._credit(): adds 1 to a for correct, 1 to b for not correct, counts n.", "py:stage2/kgdb.py::KGDB._credit"),
            S("engine", "KGDB.edge() returns the counts.", "py:stage2/kgdb.py::KGDB.edge"),
            S("http", "GET /api/db/signature/<error type>  →  tree[].edge {a, b, n}"),
            S("browser", "Computes a ÷ (a + b) with two decimals.", D + "admin feedback rating ${fmt(e.a / (e.a + e.b), 2)}"),
            S("screen", "First line under the cause."),
        ],
        "example": "a = 11.31, b = 1.0, n = 40 → 0.92 from 40 decisions (T-42).",
    },
    {
        "id": "kb-tree-labrel", "screen": "KB", "group": "The tree of one error type", "label": "lab reliability … (1 = always reproduced)",
        "kind": "display", "selector": "#sig-tree .node > span:nth-of-type(2)",
        "what": "ta ÷ (ta + tb) of the same link: ta grows with each lab result that reproduced the defect under this cause, tb with each "
                "that did not (both start at 1).",
        "why": "Separates \"the admins agree\" from \"the lab confirms\": a cause can be believed but hard to reproduce.",
        "when": "",
        "chain": [
            S("database", "db/knowledge.sqlite table edge: ta, tb."),
            S("engine", "KGDB._project(), event verdict with a lab result: ta or tb + 1.", "py:stage2/kgdb.py::KGDB._project::elif kind == \"verdict\"::elif kind == \"ranking\""),
            S("http", "GET /api/db/signature/<error type>  →  tree[].edge {ta, tb}"),
            S("browser", "Computes ta ÷ (ta + tb).", D + "admin feedback rating ${fmt(e.a / (e.a + e.b), 2)}"),
            S("screen", "Same line, after the dot."),
        ],
        "example": "ta = 40, tb = 12 → 0.77 (T-42).",
    },
    {
        "id": "kb-proc-status", "screen": "KB", "group": "The tree of one error type", "label": "awaiting approval by a second admin (status)",
        "kind": "display", "selector": "#sig-tree .proc > .pill",
        "what": "The coloured word at the top of each procedure card: approved by <name> / awaiting approval by a second admin / retired / "
                "replaced by a newer version / proposed / … A status without a translation is shown as stored (for example "
                "failed-validation).",
        "why": "Whether the procedure may be trusted: only approved ones become the reference.",
        "when": "One card per procedure under its cause; \"no procedure yet\" when a cause has none.",
        "chain": [
            S("database", "db/knowledge.sqlite table pnode (kind scenario): props.status."),
            S("engine", "ProcGraph.project() changes the status on solution_propose, _validate, _approve, _deprecate events.",
              "py:stage2/procgraph.py::ProcGraph.project::elif kind == \"solution_propose\"::elif kind == \"lesson\""),
            S("engine", "ProcGraph.procedures_for(): scenario_status.", P_PFOR),
            S("http", "GET /api/db/signature/<error type>  →  tree[].procedures[].scenario_status"),
            S("browser", "procStatus() gives the words.", D + "const procStatus = (status, by) =>"),
            S("screen", "The pill on the procedure card."),
        ],
        "example": "replaced by a newer version (procedure #074e18b2 of T-42)",
    },
    {
        "id": "kb-proc-id", "screen": "KB", "group": "The tree of one error type", "label": "procedure #… (its id in the knowledge base)",
        "kind": "display", "selector": "#sig-tree .proc > span.muted",
        "what": "The first 8 characters of the procedure's fingerprint (a hash of its steps and timing); the explanation in brackets is "
                "written only on the first card.",
        "why": "The same id appears in test names and event details, so a procedure can be followed across the pages.",
        "when": "",
        "chain": [
            S("database", "db/knowledge.sqlite table pnode: id scn::<hash>."),
            S("engine", "ProcGraph.procedures_for(): scenario_id.", P_PFOR),
            S("http", "GET /api/db/signature/<error type>  →  tree[].procedures[].scenario_id"),
            S("browser", "procId() keeps the part after the last separator, 8 characters.", D + "const procId = (id) =>"),
            S("screen", "Next to the status pill."),
        ],
        "example": "procedure #074e18b2",
    },
    {
        "id": "kb-proc-repro", "screen": "KB", "group": "The tree of one error type", "label": "reproduced in at least … % of lab runs",
        "kind": "display", "selector": "#sig-tree .proc",
        "what": "The 95 % lower bound of the reproduction rate measured when the procedure was last validated; \"-\" before any lab run.",
        "why": "A cautious number: the true rate is very unlikely to be lower.",
        "when": "",
        "chain": [
            S("database", "db/knowledge.sqlite table pnode: props.repro_lower95, set by the solution_validate event."),
            S("engine", "ProcGraph.procedures_for(): repro_lower95.", P_PFOR),
            S("http", "GET /api/db/signature/<error type>  →  tree[].procedures[].repro_lower95"),
            S("browser", "Rounds to a whole percent.", D + "reproduced in at least ${pct(p.repro_lower95)}"),
            S("screen", "First line of the procedure card."),
        ],
        "example": "68 % (procedure #074e18b2)",
    },
    {
        "id": "kb-proc-rating", "screen": "KB", "group": "The tree of one error type",
        "label": "admin feedback rating … from … decisions (procedure)", "kind": "display", "selector": "#sig-tree .proc",
        "what": "a ÷ (a + b) of the cause → procedure link, with its n: credited by lab validations (1 when the lower bound is at least "
                "0.5, else 0) and by the admin's feedback on this procedure.",
        "why": "Orders the procedures of a cause by how well they have done.",
        "when": "",
        "chain": [
            S("database", "db/knowledge.sqlite table pedge (kind REPRODUCED_BY): a, b, n."),
            S("engine", "ProcGraph.procedures_for(): edge_post = a ÷ (a + b), edge_n = n.", P_PFOR),
            S("http", "GET /api/db/signature/<error type>  →  tree[].procedures[].edge_post, .edge_n"),
            S("browser", "Writes it with two decimals.", D + "reproduced in at least ${pct(p.repro_lower95)}"),
            S("screen", "End of the first line of the procedure card."),
        ],
        "example": "0.73 from 13 decisions (procedure #074e18b2)",
    },
    {
        "id": "kb-proc-steps", "screen": "KB", "group": "The tree of one error type", "label": "flush → write (steps and timing)",
        "kind": "display", "selector": "#sig-tree .proc > .seq",
        "what": "The procedure's commands joined by arrows, and under them its timing: queue depth, microseconds between commands, block "
                "size in KB, burst length, idle gap in ms and power state.",
        "why": "What the procedure actually does to the drive.",
        "when": "",
        "chain": [
            S("database", "db/knowledge.sqlite table pedge (REPRODUCED_BY): props.procedure (the steps) and props.timing."),
            S("engine", "ProcGraph.procedures_for(): procedure = the link's properties.", P_PFOR),
            S("http", "GET /api/db/signature/<error type>  →  tree[].procedures[].procedure"),
            S("browser", "seq() writes the steps and the timing line.", A + "export function seq(x, diffAgainst = null) {"),
            S("screen", "The steps in monospace and the timing line."),
        ],
        "example": "flush → write · queue depth 8 · 200 µs between commands · 4 KB · burst 16 · idle 1866 ms · power none",
    },
    {
        "id": "kb-proc-tests", "screen": "KB", "group": "The tree of one error type", "label": "regression tests: …", "kind": "display",
        "selector": "#sig-tree .proc > div.small:last-child",
        "what": "One entry per test item of the procedure with a filed / not filed pill, or \"none\". Each entry is written as the "
                "procedure's full 16-character hash, not as a test name, so a procedure checked seven times shows the same hash seven times.",
        "why": "Meant to show which tests guard this procedure.",
        "when": "",
        "chain": [
            S("database", "db/knowledge.sqlite table pedge (kind TESTED_BY) and pnode (kind test, id test::<hash>::<event number>)."),
            S("engine", "ProcGraph.tests_for(): the procedure's test links with the test item.", "py:stage2/procgraph.py::ProcGraph.tests_for"),
            S("server", "signature(): tests = [{id, admitted}] per procedure.", P_SIG),
            S("http", "GET /api/db/signature/<error type>  →  tree[].procedures[].tests"),
            S("browser", "Writes the middle part of each test id and a pill.", D + "regression tests: ${p.tests.length"),
            S("screen", "The last line of the procedure card."),
        ],
        "example": "074e18b2b58a5676 filed (seven times, procedure #074e18b2 of T-42).",
    },
    {
        "id": "kb-proc-chain", "screen": "KB", "group": "The tree of one error type", "label": "versions, newest first: …", "kind": "display",
        "selector": "#sig-tree .proc > div.small:last-child",
        "what": "The procedure's version chain: its own status, then the status of each older version it replaced, joined by ←.",
        "why": "Shows the history of a procedure that was improved over time.",
        "when": "",
        "chain": [
            S("database", "db/knowledge.sqlite table pedge, kind SUPERSEDES (newer → older), written when a new procedure for the same "
                          "error type replaces a saved one."),
            S("engine", "ProcGraph.procedure_chain(): follows the SUPERSEDES links back, up to 50 steps (recursive query).",
              "py:stage2/procgraph.py::ProcGraph.procedure_chain"),
            S("server", "signature(): chain per procedure.", P_SIG),
            S("http", "GET /api/db/signature/<error type>  →  tree[].procedures[].chain"),
            S("browser", "Writes the statuses with procStatus(), joined by ←.", D + "versions, newest first:"),
            S("screen", "End of the last line of the procedure card."),
        ],
        "code": ["py:stage2/procgraph.py::ProcGraph.procedure_chain"],
        "example": "awaiting approval by a second admin ← failed-validation",
    },
    {
        "id": "kb-tree-lessons", "screen": "KB", "group": "The tree of one error type", "label": "Lessons learned", "kind": "display",
        "selector": "#sig-tree h3",
        "what": "The 20 newest lessons of the error type, each \"[recorded by <who>] <text>\".",
        "why": "The notes the AI reviewer must read before its next proposal for this error type.",
        "when": "Only when the error type has lessons.",
        "chain": [
            S("database", "db/knowledge.sqlite table lesson."),
            S("engine", "KGDB.lessons(sig, 20).", "py:stage2/kgdb.py::KGDB.lessons"),
            S("service", "Stage2Service.procedures(): lessons.", P_PROCS),
            S("http", "GET /api/db/signature/<error type>  →  lessons"),
            S("browser", "Writes one line per lesson.", D + "Lessons learned</h3>"),
            S("screen", "Under the causes."),
        ],
        "example": "[recorded by bench] your procedure showed the error in 0 of 6 runs - not enough; the search starts from it",
    },
    # ------------------------------------------------------------------ Tables (advanced)
    {
        "id": "kb-table-select", "screen": "KB", "group": "Tables (advanced)",
        "label": "Table (advanced: the raw table name of the knowledge base is in brackets)", "kind": "select", "selector": "#db-table",
        "what": "Chooses one of nine tables of db/knowledge.sqlite. Only these nine can be read: the server has a fixed list of queries.",
        "why": "An audit can check the summaries against the stored rows.",
        "when": "",
        "chain": [
            S("you", "You choose a table."),
            S("browser", "The value is read when you press Load.", D + "$(\"btn-db-load\").onclick = async () => {"),
            S("server", "Stage2Service.db_table(): a fixed query per table name; any other name answers 404 \"unknown table\".", P_DBT),
            S("screen", "Nothing changes until Load."),
        ],
        "example": "",
    },
] + [
    {
        "id": "kb-table-" + val, "screen": "KB", "group": "Tables (advanced)", "label": label, "kind": "row",
        "selector": "#db-table option[value=\"%s\"]" % val, "what": what, "why": why, "when": "",
        "chain": [
            S("you", "You choose this table and press Load."),
            S("http", "GET /api/db/table/%s?limit=<rows>&sig=<error type>" % val),
            S("service", "Stage2Service.db_table(): " + q, P_DBT),
            S("database", "db/knowledge.sqlite table %s." % val),
            S("screen", "The raw columns in the box under the picker."),
        ],
        "example": ex,
    }
    for val, label, what, why, q, ex in [
        ("event", "Event log (event)",
         "Every event: id, ts (time in seconds), kind, actor (who), payload (details) and undone. The newest first. The error type "
         "filter has no effect on this table.",
         "The source of truth: every other table is computed from it.", "SELECT id, ts, kind, actor, payload, undone, newest first.",
         "1178 rows on 27 Oct 2026"),
        ("signature", "Error types seen (signature)", "sig, pattern (error family), seen (times looked up), first_seen (number of the "
         "event that first saw it).", "Behind the error-types table.", "SELECT sig, pattern, seen, first_seen.", "5 rows"),
        ("node", "Causes and other items (node)", "id (<error type>::<cause>), kind, sig, status (active, deleted, merged), prior_rank.",
         "Behind the cause boxes.", "SELECT id, kind, sig, status, prior_rank.", ""),
        ("edge", "Feedback links between error types and causes (edge)",
         "src (error type), dst (cause), kind, a and b (admin feedback), n (decisions), pl (ranking score), ta and tb (lab results), "
         "status. The error type filter matches src.", "Behind the cause ratings.", "SELECT src, dst, kind, a, b, n, pl, ta, tb, status.",
         "4 rows"),
        ("solution", "Procedures (solution)",
         "vhash (fingerprint), sig, cause, status, repro_lower95, producer (who proposed it), approved_by, context_hash (firmware and "
         "device), supersedes.", "Behind the procedure counts and the approval status.",
         "SELECT vhash, sig, cause, status, repro_lower95, producer, approved_by, context_hash, supersedes.", "60 rows"),
        ("lesson", "Lessons (lesson)", "sig, cause, text, producer, event_id.", "Behind the Lessons learned list.",
         "SELECT sig, cause, text, producer, event_id.", "38 rows"),
        ("pnode", "Procedure-graph items (pnode)",
         "id, kind (signature, cause, scenario = procedure, test, lesson, context), sig, status, a, b, n, pl, ver (version).",
         "Behind the procedure and test counts.", "SELECT id, kind, sig, status, a, b, n, pl, ver.", "281 rows"),
        ("pedge", "Procedure-graph links (pedge)",
         "id, kind (CAUSED_BY, REPRODUCED_BY, TESTED_BY, SUPERSEDES, LESSON_ABOUT, IN_CONTEXT), src, dst, status, a, b, n. The error "
         "type filter matches links whose ends start with it.", "Behind the tree and the links chip.",
         "SELECT id, kind, src, dst, status, a, b, n.", "335 rows"),
        ("artifact", "Files produced (artifact)",
         "id, kind (optimizer_result or script_gate = lab check), sig, cause, event_id. Despite the name it holds lab-check and search "
         "results, not files; the file list stays in the event details.", "Behind the lab history.",
         "SELECT id, kind, sig, cause, event_id.", "173 rows"),
    ]
] + [
    {
        "id": "kb-table-sig", "screen": "KB", "group": "Tables (advanced)", "label": "Error type filter", "kind": "field", "selector": "#db-sig",
        "what": "An optional error type id (for example T-42): only rows of that error type are loaded. It applies to signature, node, "
                "solution, lesson, pnode and artifact (column sig), edge (column src) and pedge (link ends starting with it); it is "
                "ignored for the event log.",
        "why": "Narrows a large table to one error type.",
        "when": "",
        "chain": [
            S("you", "You type an error type id and press Load."),
            S("browser", "Sent as sig=.", D + "$(\"btn-db-load\").onclick = async () => {"),
            S("http", "GET /api/db/table/<name>?limit=<rows>&sig=<error type>"),
            S("service", "Stage2Service.db_table() adds the matching condition.", P_DBT),
            S("screen", "Only that error type's rows."),
        ],
        "example": "",
    },
    {
        "id": "kb-table-limit", "screen": "KB", "group": "Tables (advanced)", "label": "Rows to show", "kind": "field", "selector": "#db-limit",
        "what": "How many rows to load, 200 by default (an empty or non-number value also means 200).",
        "why": "Keeps the page fast on a large database.",
        "when": "",
        "chain": [
            S("you", "You type a number and press Load."),
            S("browser", "Sent as limit=.", D + "$(\"btn-db-load\").onclick = async () => {"),
            S("http", "GET /api/db/table/<name>?limit=<rows>"),
            S("service", "Stage2Service.db_table(): LIMIT ? OFFSET 0.", P_DBT),
            S("screen", "At most that many rows."),
        ],
        "example": "200",
    },
    {
        "id": "kb-table-load", "screen": "KB", "group": "Tables (advanced)", "label": "Load", "kind": "button", "selector": "#btn-db-load",
        "what": "Loads the chosen table with the filter and row count and shows it under the picker, headed \"Advanced view: the raw "
                "columns of the table, exactly as stored.\" Numbers are rounded to 3 decimals and long details cut at 180 characters.",
        "why": "Read-only access to the raw tables for an audit.",
        "when": "",
        "chain": [
            S("you", "You press Load."),
            S("browser", "Asks for the table and draws all columns.", D + "$(\"btn-db-load\").onclick = async () => {"),
            S("http", "GET /api/db/table/<name>?limit=<rows>&sig=<error type>"),
            S("server", "table(): under the stage-2 lock.", P_TABLE),
            S("service", "Stage2Service.db_table(): runs the fixed query, turns the event details back into structured data.", P_DBT),
            S("database", "db/knowledge.sqlite, the chosen table."),
            S("screen", "The table in the box under the picker."),
        ],
        "code": [P_DBT],
        "example": "",
    },
    # ------------------------------------------------------------------ Event log
    {
        "id": "kb-ev-table", "screen": "KB", "group": "Event log", "label": "Event log (most recent first)", "kind": "table",
        "selector": "#ev-rows table",
        "what": "The most recent events: 25 at page load, 60 after a click on the tab or refresh, and redrawn by itself after a "
                "successful Undo (the new undo event on top). Six columns: event number, time, what "
                "happened, who, details, undone. The knowledge base is event-sourced: this append-only list of everything that happened "
                "is the only thing ever written by a decision or a lab result; every other table is computed from it.",
        "why": "Full traceability of who changed what, and the basis of Undo.",
        "when": "",
        "chain": [
            S("database", "db/knowledge.sqlite table event."),
            S("engine", "KGDB.apply_event(): writes the event, then lets the two computed views update their tables.", "py:stage2/kgdb.py::KGDB.apply_event"),
            S("service", "Stage2Service.db_table(\"event\"): newest first.", P_DBT),
            S("http", "GET /api/db/overview  →  recent_events (25)   or   GET /api/db/table/event?limit=60"),
            S("browser", "loadEvents() draws the table.", D + "async function loadEvents(rows) {"),
            S("screen", "The Event log tab."),
        ],
        "code": ["py:stage2/kgdb.py::KGDB.apply_event", "py:stage2/kgdb.py::KGDB.log"],
        "example": "Event 1178 script gate by integration; 1177 solution validate by bench.",
    },
] + [
    {
        "id": "kb-ev-" + cid, "screen": "KB", "group": "Event log", "label": label, "kind": "display",
        "selector": "#ev-rows th:nth-child(%d)" % n, "what": what, "why": why, "when": "",
        "chain": [
            S("database", "db/knowledge.sqlite table event: " + col + "."),
            S("engine", "KGDB.log() writes it.", "py:stage2/kgdb.py::KGDB.log"),
            S("http", "GET /api/db/table/event?limit=60  →  rows[]." + col),
            S("browser", brw, D + "async function loadEvents(rows) {"),
            S("screen", "Column %d of the event log." % n),
        ],
        "example": ex,
    }
    for n, cid, label, col, what, why, brw, ex in [
        (1, "id", "event number", "id", "The event's number, counting up from 1. This is the number to type into Undo event number.",
         "A stable handle for one change.", "Writes the number.", "1178"),
        (2, "time", "time", "ts", "The time of day the event was written (the date is not shown).", "When the change happened.",
         "Writes the local time of day.", "1:00:44 PM for event 1178 (27 Oct 2026; the date is not on the screen)"),
        (3, "kind", "what happened", "kind",
         "The event kind with underscores as spaces, as stored (for example incident seen, impression, admin action, verdict, "
         "solution propose, solution validate, script gate, lesson, undo).",
         "Says which kind of change it was.", "Replaces _ with a space.", "script gate"),
        (4, "who", "who", "actor",
         "Who wrote the event: admin, or a part of the program (detector, presenter, optimizer, composer, bench, integration). The "
         "person's name and the run, defect, device and firmware are inside the details (meta).",
         "Accountability.", "Writes the actor.", "integration"),
        (5, "details", "details (advanced: as stored)", "payload",
         "The event's content as stored, cut at 200 characters, including meta: run, trace, defect, operator, device, firmware and the time.",
         "Everything the event changed, for an audit.", "Writes the first 200 characters of the details.",
         "{\"admitted\":true,\"cause\":\"c0\",\"files\":[\"conftest.py\",\"manifest.json\",\"test_T_T_42_ad4740d9.py\"], …"),
        (6, "undone", "undone", "undone", "A yellow \"undone\" pill when the event has been undone; empty otherwise. Undone events stay in the log.",
         "Shows which changes no longer count.", "Writes the pill when undone = 1.", ""),
    ]
] + [
    {
        "id": "kb-ev-refresh", "screen": "KB", "group": "Event log", "label": "refresh", "kind": "button", "selector": "#btn-ev-refresh",
        "what": "Reloads the 60 most recent events.",
        "why": "Decisions made meanwhile in the workflow tab appear without reloading the whole page.",
        "when": "",
        "chain": [
            S("you", "You press refresh."),
            S("browser", "loadEvents() without rows asks the server.", D + "$(\"btn-ev-refresh\").onclick"),
            S("http", "GET /api/db/table/event?limit=60"),
            S("service", "Stage2Service.db_table(\"event\", 60).", P_DBT),
            S("screen", "The event table, newest first."),
        ],
        "example": "",
    },
    {
        "id": "kb-undo-id", "screen": "KB", "group": "Event log", "label": "Undo event number", "kind": "field", "selector": "#db-undo-id",
        "what": "The number of the event to undo, from the first column.",
        "why": "Undo works on one event, chosen by its number.",
        "when": "",
        "chain": [
            S("you", "You type an event number."),
            S("browser", "Read by the Undo button; empty means nothing happens.", D + "$(\"btn-undo\").onclick = async () => {"),
            S("screen", "The number stays in the field."),
        ],
        "example": "",
    },
    {
        "id": "kb-undo", "screen": "KB", "group": "Event log", "label": "Undo this event & rebuild", "kind": "button", "selector": "#btn-undo",
        "what": "After a confirmation (\"Undo event N and rebuild the knowledge base from the event log?\") the event is undone. Nothing is "
                "deleted: the event is marked undone = 1, a new event of kind undo is added, every computed table is emptied (node, "
                "node_version, edge, case_memory, signature, artifact, solution, lesson and the procedure graph pnode, pnode_version, "
                "pedge) and every other event is replayed in order. The result is exactly as if the undone event had never happened, "
                "including what later events built on it. The search index is then rebuilt. Files outside the knowledge base stay: test "
                "folders in suite/, the run's stage-2 state files and the verdict cache. The person is always recorded as admin; a number "
                "that does not exist still adds an undo event; undoing an undo event changes nothing (there is no redo). After a "
                "successful undo the page shows the message \"event N undone; the knowledge base was rebuilt from the event log\" for "
                "about 6 seconds, and redraws the counts at the top (overview()) and the event list (loadEvents()) at once, with no reload: "
                "the new undo event is at the top of the list and the undone event carries the \"undone\" pill. When the server refuses, "
                "the message says \"undo failed: <reason>\".",
        "why": "Every change must be reversible, without editing the history: an audit can always see what was done and undone.",
        "when": "Asks for confirmation first; nothing happens with an empty number.",
        "chain": [
            S("you", "You type an event number, press the button and confirm."),
            S("browser", "Sends the number; on success it calls toast(\"event N undone; …\"), then overview() and loadEvents().",
              D + "$(\"btn-undo\").onclick = async () => {"),
            S("http", "POST /api/db/undo  {event_id, actor: \"admin\"}"),
            S("server", "undo(): 400 \"event_id required\" without a number, else hands it to the service.", "py:app/api/db_api.py::undo"),
            S("service", "Stage2Service.undo(): under the stage-2 lock; afterwards the search index is rebuilt.", "py:app/stage2_service.py::Stage2Service.undo"),
            S("engine", "KGDB.undo(): marks the event, logs the undo event, then rebuild() empties the computed tables and replays every "
                        "other event through both views.", "py:stage2/kgdb.py::KGDB.undo"),
            S("database", "db/knowledge.sqlite: table event (undone = 1, one new undo row) and all computed tables rebuilt."),
            S("browser", "toast() writes the message into the page's message box (#toast-text) and hides it after 6 s; then overview() "
                         "and loadEvents() ask for the new counts and events.", A + "export function toast(msg"),
            S("http", "GET /api/db/overview   and   GET /api/db/table/event?limit=60"),
            S("screen", "The message, the counts without the undone event, the new undo event on top and the undone event marked "
                        "\"undone\", without a reload."),
        ],
        "code": ["py:stage2/kgdb.py::KGDB.undo", "py:stage2/kgdb.py::KGDB.rebuild", "py:stage2/retrieval_v3.py::HybridIndex.sync"],
        "example": "On a scratch copy (never on the live database): undoing event 3, a lesson, answered {\"undone\": 3}; lessons went from 1 "
                   "to 0 and event 4 (undo, details {\"event_id\": 3}) was added. Pressed in the page (current db.html and db.js) for "
                   "event 8, a lesson: the message \"event 8 undone; the knowledge base was rebuilt from the event log\" appeared and "
                   "hid itself after about 6 s; without a reload the chips went from 8 to 9 events logged and from 1 to 0 lessons, the "
                   "list's top row became event 9 (undo, {\"event_id\":8}) and event 8 showed the \"undone\" pill; no script errors.",
    },
    # ------------------------------------------------------------------ Verdicts reused from the cache
    {
        "id": "kb-cache-summary", "screen": "KB", "group": "Verdicts reused from the cache",
        "label": "… verdicts in the cache, reused … times - a defect with the same error type, rule, error family, layer, rule set and evidence-row sequence (and the same model and prompt version) is confirmed without asking the AI reviewer again.",
        "kind": "display", "selector": "#cache-rows > p.muted",
        "what": "The cache size and total reuses, and the rule for a reuse. Every fresh stage-1 verdict is stored, whatever it says, so "
                "a reused verdict can also be INCONCLUSIVE, not only confirmed.",
        "why": "Explains why some second opinions cost nothing.",
        "when": "",
        "chain": [
            S("service", "run_stage1(): stores each fresh verdict and looks up each defect before asking the model.", P_RUN1),
            S("engine", "pattern_key(): the key from error type, rule, family, layer, rule set, row kinds, model and prompt version.",
              "py:app/pattern_cache.py::pattern_key"),
            S("database", "db/app.sqlite table verdict_cache."),
            S("server", "cache(): stats and rows.", "py:app/api/db_api.py::cache"),
            S("http", "GET /api/db/cache  →  stats {entries, hits}"),
            S("browser", "loadCache() writes the line.", D + "async function loadCache() {"),
            S("screen", "The line above the cache table."),
        ],
        "code": ["py:app/pattern_cache.py::pattern_key", "py:app/pattern_cache.py::VerdictCache.lookup"],
        "example": "195 verdicts in the cache, reused 99 times",
    },
    {
        "id": "kb-cache-table", "screen": "KB", "group": "Verdicts reused from the cache", "label": "Stage-1 verdicts reused from the cache",
        "kind": "table", "selector": "#cache-rows table",
        "what": "Up to 200 cached verdicts, newest first. Eight columns: error type, rule, error family, layer, verdict, model, times "
                "reused, first seen in (run / defect).",
        "why": "Shows exactly which verdict will be reused for which kind of defect, and where it was first given.",
        "when": "Loaded each time the tab is clicked.",
        "chain": [
            S("database", "db/app.sqlite table verdict_cache."),
            S("service", "VerdictCache.rows(): newest first; the verdict is read from the stored record.", "py:app/pattern_cache.py::VerdictCache.rows"),
            S("server", "cache().", "py:app/api/db_api.py::cache"),
            S("http", "GET /api/db/cache  →  rows[]"),
            S("browser", "loadCache() draws the table.", D + "async function loadCache() {"),
            S("screen", "The cache table."),
        ],
        "example": "",
    },
] + [
    {
        "id": "kb-cache-" + cid, "screen": "KB", "group": "Verdicts reused from the cache", "label": label, "kind": "display",
        "selector": "#cache-rows th:nth-child(%d)" % n, "what": what, "why": why, "when": "",
        "chain": [
            S("database", "db/app.sqlite table verdict_cache: " + col + "."),
            S("service", "VerdictCache.rows().", "py:app/pattern_cache.py::VerdictCache.rows"),
            S("http", "GET /api/db/cache  →  rows[]." + key),
            S("browser", brw, bref),
            S("screen", "Column %d of the cache table." % n),
        ],
        "example": ex,
    }
    for n, cid, label, col, key, what, why, brw, bref, ex in [
        (1, "type", "error type", "card", "card", "The error type of the defect that produced the verdict, with its chapter.",
         "First part of the reuse key.", "errorTypeShort() adds the chapter.", A + "export function errorTypeShort(card)",
         "M-039 · timing, evidence-gap and cross-layer failures"),
        (2, "rule", "rule", "rule", "rule", "The analyser rule that fired first (its rule id).", "Part of the reuse key.", "Writes the id.",
         D + "async function loadCache() {", "NVME.CMD_TIMEOUT"),
        (3, "family", "error family", "pattern", "pattern", "The error family, written out.", "Part of the reuse key.",
         "familyName() writes it out.", A + "export function familyName(p)", "configuration space, power state and reset sequencing (family P19)"),
        (4, "layer", "layer", "layer", "layer", "The layer the defect sits in, as stored (for example nvme-cmd, config).", "Part of the reuse key.",
         "Writes it as stored.", D + "async function loadCache() {", "nvme-cmd"),
        (5, "verdict", "verdict", "record", "verdict", "The stored second opinion, as stored (CONFIRMED, INCONCLUSIVE, …), in a coloured pill.",
         "What a matching defect will be told without a model call.", "statusCls() picks the colour.", A + "export const statusCls = (s) =>",
         "INCONCLUSIVE (M-020)"),
        (6, "model", "model", "model", "model", "The model that gave the verdict; a different model never reuses it.", "Part of the reuse key.",
         "Writes it.", D + "async function loadCache() {", "claude-haiku-5-5"),
        (7, "hits", "times reused", "hits", "hits", "How many times the verdict was reused.", "Shows the saving per entry.", "Writes it.",
         D + "async function loadCache() {", "11"),
        (8, "source", "first seen in (run / defect)", "source_run, source_incident", "source_run, .source_incident",
         "The run and the defect whose fresh verdict was stored.", "Lets the reviewer check the original evidence.",
         "defectName() turns INC-0003 into Defect 3.", A + "export function defectName(id) {", "run-20261026-132903-b545 / Defect 3"),
    ]
] + [
    # ------------------------------------------------------------------ AI reviewer usage
    {
        "id": "kb-llm-name", "screen": "KB", "group": "AI reviewer usage",
        "label": "AI reviewer usage and stage-2 counters (advanced: raw counters)  ·  llm", "kind": "display", "selector": "#llm-usage",
        "what": "The first line of the raw text: llm = the internal name of the AI reviewer stage 2 is using now.",
        "why": "Ties the counters below to a model and effort.",
        "when": "",
        "chain": [
            S("service", "Stage2Service.reload_llm() / make_llm() decide which object is in use.", P_MAKE),
            S("server", "overview(): llm = its name.", P_OV),
            S("http", "GET /api/db/overview  →  llm"),
            S("browser", "overview() writes the text block.", D + "$(\"llm-usage\").textContent"),
            S("screen", "The text block of the AI reviewer usage tab."),
        ],
        "example": "anthropic:claude-haiku-5-5:low",
    },
    {
        "id": "kb-llm-usage", "screen": "KB", "group": "AI reviewer usage", "label": "usage", "kind": "display", "selector": "#llm-usage",
        "what": "input_tokens, output_tokens, cache_read, cache_write, cost_usd, errors: the stage-2 model calls of the current AI reviewer "
                "object only. Stage 1's second opinions are not included (they run in the analyser), and the counters start from zero "
                "after a restart and after every Settings Save (a new object is built). null for the stand-in.",
        "why": "What the stage-2 proposals have cost since the server started.",
        "when": "",
        "chain": [
            S("engine", "AnthropicLLM keeps the usage counters of its own calls.", "py:stage2/llm_adapter.py::AnthropicLLM"),
            S("server", "overview(): llm_usage = the object's usage.", P_OV),
            S("http", "GET /api/db/overview  →  llm_usage"),
            S("browser", "overview() writes it as text.", D + "$(\"llm-usage\").textContent"),
            S("screen", "The usage block."),
        ],
        "example": "cost_usd 0.397158, output_tokens 7310, errors 0",
    },
    {
        "id": "kb-llm-counters", "screen": "KB", "group": "AI reviewer usage", "label": "stage2_counters", "kind": "display",
        "selector": "#llm-usage",
        "what": "Stage 2's counters since the server started (in memory, reset by a restart): decisions by kind, lookups and their "
                "seen-before answers (match, new, ambiguous), how searches started (reuse, adapt, generate), confirmed, lab checks run and "
                "passed, optimal, triage timeouts, lab trials, AI reviewer calls and invalid answers.",
        "why": "A quick health check of stage 2 for whoever maintains it.",
        "when": "",
        "chain": [
            S("engine", "Stage2V3 counts as it works.", "py:stage2/stage2_v3.py::Stage2V3.__init__"),
            S("server", "overview(): counters.", P_OV),
            S("http", "GET /api/db/overview  →  counters"),
            S("browser", "overview() writes it as text.", D + "$(\"llm-usage\").textContent"),
            S("screen", "The counters block."),
        ],
        "example": "closed_loop_runs 9, closed_loop_passed 9, trials_total 88, llm_calls 2",
    },
]
