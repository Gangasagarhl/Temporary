#!/usr/bin/env python3
"""Builds docs/APPLICATION_MAP.html: every button and every piece of content of the application, each with what it
is, why it exists, and an arrow chain from the click (or the stored value) through the browser code, the server
address, the Python functions and the database to what the screen shows.

Input: docs/ui_map_src/part_*.py (format: docs/ui_map_src/SCHEMA.md) and the numbered screenshots in
docs/ui_map_images/ (made by docs/shoot_ui_map.py). Every code reference is checked against the current source:
the build stops with a list of problems when a function or marker does not exist.

    python3 docs/build_ui_map.py            # writes docs/APPLICATION_MAP.html
"""
import ast
import glob
import html
import os
import re
import runpy
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
SRC = os.path.join(HERE, "ui_map_src")
OUT = os.path.join(HERE, "APPLICATION_MAP.html")
IMG = "ui_map_images"

SCREENS = [
    ("SB", "Sidebar and top bar", "on every page of the workflow", "SB"),
    ("S1", "Step 1 · Choose the trace", "http://127.0.0.1:8077/#run/choose", "S1"),
    ("S2", "Step 2 · Analyse the trace (stage 1)", "http://127.0.0.1:8077/?run=<run>#run/analyse", "S2"),
    ("S3C", "Step 3 · NVMe commands", "http://127.0.0.1:8077/?run=<run>#commands", "S3C"),
    ("S3", "Step 4 · Defects found", "http://127.0.0.1:8077/?run=<run>#incidents", "S3"),
    ("DP", "The defect page", "http://127.0.0.1:8077/defect?run=<run>&inc=<defect>", "DP"),
    ("S4G", "Step 5 · Start stage 2", "the first visit of step 5 for a run", "S4G"),
    ("S4", "Step 5 · Reproduce and decide: the main screen", "http://127.0.0.1:8077/?run=<run>#review/<defect>", "S4"),
    ("S4D", "Step 5 · All details: candidates, the 26 decisions, editor, history", "the \"All details\" box at the bottom of step 5", "S4D"),
    ("S5", "Step 6 · Report and tests", "http://127.0.0.1:8077/?run=<run>#report", "S5"),
    ("ST", "Settings", "http://127.0.0.1:8077/#settings", "ST"),
    ("HP", "What the words mean", "http://127.0.0.1:8077/#help", "HP"),
    ("KB", "The Knowledge base page", "http://127.0.0.1:8077/db", "KB"),
]
LAYERS = {
    "you": ("You", "what the person does"),
    "browser": ("Browser", "JavaScript in app/static/js"),
    "http": ("Request", "what the browser sends to the server"),
    "server": ("Server address", "Flask route in app/api/*.py"),
    "service": ("Service", "app/services.py, stage2_service.py, jobs.py, stage1_runner.py, report.py"),
    "engine": ("Engine", "the analyser (stage1/pcie_isolate) or the reproduction engine (stage2)"),
    "database": ("Database", "db/knowledge.sqlite or db/app.sqlite: events and tables"),
    "files": ("Files", "files written or read on disk"),
    "screen": ("Screen", "what you see afterwards"),
}
KINDS = {"button", "field", "checkbox", "select", "link", "tab", "display", "table", "key", "row"}


# ------------------------------------------------------------------------------------------------ references
_ast_cache, _src_cache = {}, {}


def _lines(path):
    if path not in _src_cache:
        _src_cache[path] = open(os.path.join(APP, path), encoding="utf-8").read().splitlines(keepends=True)
    return _src_cache[path]


def _find_def(path, qual):
    if path not in _ast_cache:
        _ast_cache[path] = ast.parse("".join(_lines(path)))
    node = _ast_cache[path]
    for part in qual.split("."):
        node = next((c for c in ast.iter_child_nodes(node)
                     if isinstance(c, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and c.name == part), None)
        if node is None:
            raise KeyError("%s not found in %s" % (qual, path))
    return node


def resolve(ref, default_js_lines=14):
    """ref -> (path, first line, list of source lines, title). Raises on anything that does not exist."""
    m = re.match(r"^(py|js):([^:]+)::(.+)$", ref.strip())
    if not m:
        raise ValueError("bad reference format: %r" % ref)
    kind, path, rest = m.groups()
    if not os.path.isfile(os.path.join(APP, path)):
        raise FileNotFoundError("no file %s" % path)
    args = re.split(r"::(?!:)", rest)
    lines = _lines(path)
    if kind == "py":
        node = _find_def(path, args[0])
        first = node.decorator_list[0].lineno if getattr(node, "decorator_list", None) else node.lineno
        seg, off = lines[first - 1:node.end_lineno], first
        if len(args) > 1 and args[1]:
            i = next((k for k, l in enumerate(seg) if args[1] in l), None)
            if i is None:
                raise KeyError("start text %r not in %s %s" % (args[1], path, args[0]))
            seg, off = seg[i:], off + i
        if len(args) > 2 and args[2]:
            j = next((k for k, l in enumerate(seg) if k > 0 and args[2] in l), len(seg))
            seg = seg[:j]
        return path, off, seg, args[0]
    marker = args[0]
    n = int(args[1]) if len(args) > 1 and args[1].strip().isdigit() else default_js_lines
    i = next((k for k, l in enumerate(lines) if marker in l), None)
    if i is None:
        raise KeyError("marker %r not in %s" % (marker, path))
    return path, i + 1, lines[i:i + n], "browser code"


def code_block(ref):
    path, first, seg, title = resolve(ref)
    if len(seg) > 90:
        seg = seg[:90] + ["    … (%d more lines in the file)\n" % (len(seg) - 90)]
    return ('<figure class="code"><figcaption><span class="file">%s</span> line %d · %s</figcaption><pre><code>%s</code></pre></figure>'
            % (html.escape(path), first, html.escape(title), html.escape("".join(seg).rstrip("\n"))))


# ------------------------------------------------------------------------------------------------ loading
def load():
    elements, problems = [], []
    for f in sorted(glob.glob(os.path.join(SRC, "part_*.py"))):
        try:
            els = runpy.run_path(f)["ELEMENTS"]
        except Exception as e:                       # noqa: BLE001
            problems.append("%s: cannot load: %s" % (os.path.basename(f), e))
            continue
        for e in els:
            e["_file"] = os.path.basename(f)
        elements += els
    ids, codes = set(), {s[0] for s in SCREENS}
    for e in elements:
        where = "%s %s" % (e.get("_file"), e.get("id"))
        for k in ("id", "screen", "label", "kind", "what", "why", "chain"):
            if not e.get(k):
                problems.append("%s: missing %s" % (where, k))
        if e.get("id") in ids:
            problems.append("%s: duplicate id" % where)
        ids.add(e.get("id"))
        if e.get("screen") not in codes:
            problems.append("%s: unknown screen %r" % (where, e.get("screen")))
        if e.get("kind") not in KINDS:
            problems.append("%s: unknown kind %r" % (where, e.get("kind")))
        for st in e.get("chain") or []:
            if st.get("layer") not in LAYERS:
                problems.append("%s: unknown layer %r" % (where, st.get("layer")))
            if st.get("ref"):
                try:
                    resolve(st["ref"])
                except Exception as x:               # noqa: BLE001
                    problems.append("%s: ref %s: %s" % (where, st["ref"], x))
        for c in e.get("code") or []:
            try:
                resolve(c)
            except Exception as x:                   # noqa: BLE001
                problems.append("%s: code %s: %s" % (where, c, x))
    return elements, problems


# ------------------------------------------------------------------------------------------------ rendering
def esc(s):
    return html.escape(str(s or ""))


def inline(s):
    """Escape, then render `code` spans."""
    return re.sub(r"`([^`]+)`", r"<code>\1</code>", esc(s))


def ref_label(ref):
    path, first, _, title = resolve(ref)
    return "%s:%d · %s" % (path, first, title)


def chain_html(chain):
    out = ['<ol class="chain">']
    for k, st in enumerate(chain):
        lay = st["layer"]
        name = LAYERS[lay][0]
        ref = ('<div class="ref">%s</div>' % esc(ref_label(st["ref"]))) if st.get("ref") else ""
        out.append('<li class="step l-%s"><span class="lay">%s</span><div class="txt">%s%s</div></li>' % (lay, name, inline(st["text"]), ref))
        if k < len(chain) - 1:
            out.append('<li class="arrow" aria-hidden="true">↓</li>')
    out.append("</ol>")
    return "".join(out)


def element_html(e, num):
    when = ('<p><b>When:</b> %s</p>' % inline(e["when"])) if e.get("when") else ""
    ex = ('<div class="ex"><b>Example from this installation:</b> %s</div>' % inline(e["example"])) if e.get("example") else ""
    code = ""
    if e.get("code"):
        code = '<details class="codebox"><summary>The code behind it (%d excerpt%s)</summary>%s</details>' % (
            len(e["code"]), "" if len(e["code"]) == 1 else "s", "".join(code_block(c) for c in e["code"]))
    return ('<article class="el" id="%s" data-text="%s"><header><span class="num">%s</span><h4>%s</h4><span class="kind">%s</span></header>'
            '<div class="cols"><div class="desc"><p><b>What it is:</b> %s</p><p><b>Why it exists:</b> %s</p>%s%s</div>'
            '<div class="flow"><div class="flowtitle">How it works, step by step</div>%s</div></div>%s</article>') % (
        esc(e["id"]), esc((e["label"] + " " + e["what"] + " " + e["why"]).lower()), num, esc(e["label"]), esc(e["kind"]),
        inline(e["what"]), inline(e["why"]), when, ex, chain_html(e["chain"]), code)


CSS = r"""
:root{--bg:#fff;--bg2:#f6f8fa;--fg:#1f2328;--mut:#57606a;--bd:#d0d7de;--acc:#0969da;--code:#0d1117;--codefg:#e6edf3;
--you:#8250df;--you-bg:#fbefff;--browser:#0969da;--browser-bg:#ddf4ff;--http:#57606a;--http-bg:#eef1f4;--server:#0a7d76;--server-bg:#d8f5f2;
--service:#1a7f37;--service-bg:#dafbe1;--engine:#bc4c00;--engine-bg:#fff1e5;--database:#9a6700;--database-bg:#fff8c5;--files:#6e5494;--files-bg:#f1ecf9;--screen:#bf3989;--screen-bg:#ffeff7}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#0d1117;--bg2:#161b22;--fg:#e6edf3;--mut:#9da7b3;--bd:#30363d;--acc:#4493f8;--code:#010409;
--you-bg:#2a1d3d;--browser-bg:#132a45;--http-bg:#1c2330;--server-bg:#0f2e2c;--service-bg:#12301c;--engine-bg:#3a2210;--database-bg:#2f2510;--files-bg:#241d33;--screen-bg:#3a1530;
--you:#c297ff;--browser:#4493f8;--http:#9da7b3;--server:#39c5bb;--service:#3fb950;--engine:#f0883e;--database:#d29922;--files:#b392f0;--screen:#f778ba}}
:root[data-theme="dark"]{--bg:#0d1117;--bg2:#161b22;--fg:#e6edf3;--mut:#9da7b3;--bd:#30363d;--acc:#4493f8;--code:#010409}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:16px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Noto Sans",Ubuntu,sans-serif}
main{max-width:1180px;margin:0 auto;padding:24px 16px 80px}h1{font-size:32px;line-height:1.25;margin:8px 0}
h2{font-size:25px;margin:56px 0 10px;padding-top:12px;border-top:2px solid var(--bd)}h3{font-size:20px;margin:28px 0 8px}
p,li{max-width:80ch}a{color:var(--acc)}.lead{font-size:18px;color:var(--mut)}.muted{color:var(--mut)}
code{font:13px/1.45 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;background:var(--bg2);border:1px solid var(--bd);border-radius:4px;padding:0 4px;overflow-wrap:anywhere}
nav.toc{background:var(--bg2);border:1px solid var(--bd);border-radius:8px;padding:12px 18px;margin:18px 0}
nav.toc table{width:100%;border-collapse:collapse}nav.toc td{padding:3px 8px;border-bottom:1px solid var(--bd)}
.legend{display:flex;flex-wrap:wrap;gap:8px;margin:10px 0 18px}.legend span{font-size:13px;border-radius:999px;padding:2px 10px;border:1px solid}
.el{border:1px solid var(--bd);border-radius:10px;margin:16px 0;background:var(--bg);scroll-margin-top:12px}
.el header{display:flex;align-items:center;gap:10px;padding:10px 14px;border-bottom:1px solid var(--bd);background:var(--bg2);border-radius:10px 10px 0 0}
.el h4{margin:0;font-size:17px;flex:1}.num{min-width:30px;height:30px;border-radius:50%;background:#cf222e;color:#fff;display:inline-flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;padding:0 6px}
.kind{font-size:12px;color:var(--mut);border:1px solid var(--bd);border-radius:999px;padding:0 8px}
.cols{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.25fr);gap:18px;padding:12px 14px}
.desc p{margin:0 0 10px}.ex{background:var(--bg2);border-left:4px solid var(--acc);padding:8px 10px;border-radius:6px;font-size:14px}
.flowtitle{font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:var(--mut);margin-bottom:6px}
ol.chain{list-style:none;margin:0;padding:0}ol.chain li.step{display:grid;grid-template-columns:118px minmax(0,1fr);gap:8px;align-items:start;border:1px solid;border-radius:8px;padding:6px 8px;font-size:14px}
ol.chain li.arrow{text-align:left;padding-left:48px;color:var(--mut);font-size:18px;line-height:18px;margin:1px 0}
.lay{font-size:11.5px;font-weight:700;text-transform:uppercase;letter-spacing:.03em;border-radius:5px;padding:2px 6px;text-align:center;color:#fff}
ol.chain .txt{min-width:0;overflow-wrap:anywhere}.desc{min-width:0;overflow-wrap:anywhere}nav.toc td{overflow-wrap:anywhere}
.ref{font:11.5px/1.4 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;color:var(--mut);margin-top:3px;overflow-wrap:anywhere}
""" + "".join(".l-%s{border-color:var(--%s);background:var(--%s-bg)} .l-%s .lay{background:var(--%s)}\n" % (l, l, l, l, l) for l in LAYERS) + "".join(
    ".legend .g-%s{border-color:var(--%s);background:var(--%s-bg)}\n" % (l, l, l) for l in LAYERS) + r"""
details.codebox{margin:0 14px 12px}details.codebox summary{cursor:pointer;color:var(--acc);font-size:14px}
figure.code{margin:8px 0;border:1px solid var(--bd);border-radius:8px;overflow:hidden}figure.code figcaption{background:var(--bg2);padding:5px 10px;font-size:12.5px;color:var(--mut)}
figure.code .file{font-weight:700;color:var(--fg)}figure.code pre{margin:0;padding:10px 12px;background:var(--code);color:var(--codefg);overflow-x:auto;max-height:520px;font:12px/1.45 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
figure.code pre code{background:none;border:0;padding:0;color:inherit}
.shot{margin:12px 0 18px;border:1px solid var(--bd);border-radius:8px;overflow:hidden}.shot img{display:block;width:100%;height:auto}.shot figcaption{padding:6px 10px;font-size:14px;color:var(--mut);background:var(--bg2)}
.search{position:sticky;top:0;z-index:5;background:var(--bg);padding:8px 0;border-bottom:1px solid var(--bd)}
.search input{width:100%;font-size:16px;padding:8px 12px;border:1px solid var(--bd);border-radius:8px;background:var(--bg);color:var(--fg)}
.box{border:1px solid var(--bd);border-left:5px solid var(--acc);border-radius:8px;padding:10px 14px;margin:14px 0;background:var(--bg2)}
table.t{border-collapse:collapse;width:100%;font-size:14.5px;margin:8px 0 16px}table.t th,table.t td{border:1px solid var(--bd);padding:6px 9px;text-align:left;vertical-align:top}table.t th{background:var(--bg2)}
svg.dia{width:100%;height:auto;display:block;margin:10px 0 20px}svg.dia rect{stroke-width:1.5}svg.dia text{fill:var(--fg);font-size:13px;font-family:inherit}svg.dia .s{fill:var(--mut);font-size:11.5px}svg.dia .t{font-weight:700;font-size:14px}
svg.dia .ln{stroke:var(--mut);stroke-width:1.6;fill:none}svg.dia .ah{fill:var(--mut)}
pre.cmd{background:var(--code);color:var(--codefg);padding:10px 12px;border-radius:8px;overflow-x:auto;font:13px/1.5 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
@media (max-width:820px){.cols{grid-template-columns:1fr}ol.chain li.step{grid-template-columns:1fr}ol.chain li.arrow{padding-left:12px}h1{font-size:26px}}
"""

def box(x, y, w, h, layer, title, lines):
    t = '<rect x="%d" y="%d" width="%d" height="%d" rx="8" style="fill:var(--%s-bg);stroke:var(--%s)"/>' % (x, y, w, h, layer, layer)
    t += '<text x="%d" y="%d" class="t">%s</text>' % (x + 10, y + 22, esc(title))
    for k, l in enumerate(lines):
        t += '<text x="%d" y="%d" class="s">%s</text>' % (x + 10, y + 42 + 16 * k, esc(l))
    return t


def architecture_svg():
    a = '<svg class="dia" viewBox="0 0 1150 560" role="img" aria-label="How the screens are tied to the backend">'
    a += '<defs><marker id="m" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" class="ah"/></marker></defs>'
    a += box(10, 10, 270, 150, "you", "1  You, in the web browser", ["index.html: the five steps", "defect.html: one defect's record", "db.html: the knowledge base", "you click a button or open a page"])
    a += box(310, 10, 280, 150, "browser", "2  Browser code (JavaScript)", ["main.js: sidebar, locks, which page", "run.js steps 1-2, incidents.js step 3", "review.js + decision.js step 4", "report.js, settings.js, defect.js, db.js", "api.js: api() sends every request"])
    a += box(620, 10, 250, 150, "http", "3  Request (HTTP)", ["GET = read, POST = do,", "PUT = save settings, DELETE = remove", "address + JSON body, e.g.", "POST /api/runs/<run>/incidents/", "     <defect>/act {action, targets}"])
    a += box(900, 10, 240, 150, "server", "4  Server address (Flask)", ["app/api/runs_api.py", "app/api/stage2_api.py", "app/api/db_api.py, misc_api.py,", "config_api.py: one Python", "function per address"])
    a += box(900, 200, 240, 150, "service", "5  Services", ["services.py: runs, paths, device", "jobs.py: background work + timing", "stage1_runner.py: stage 1 steps", "stage2_service.py: stage 2, lock,", "metadata, commit"])
    a += box(560, 200, 310, 150, "engine", "6  Engines", ["stage1/pcie_isolate: the analyser", "  (167 rules, defects, attribution)", "stage2: lookup, decisions → events,", "  search, lab check, test files", "AI reviewer through llm_adapter.py"])
    a += box(560, 390, 310, 150, "database", "7  Databases", ["db/knowledge.sqlite: event log +", "  tables computed from it (causes,", "  procedures, counters, lessons, tests)", "db/app.sqlite: jobs, progress,", "  timings, cached AI verdicts"])
    a += box(900, 390, 240, 150, "files", "8  Files", ["runs/<run>/: incidents.json,", "  isolation.json, stage2/<defect>.json", "suite/<test>/: test_*.py,", "  manifest.json, conftest.py", "config/app_config.json"])
    a += box(10, 390, 520, 150, "screen", "9  The answer comes back up the same way", ["the server function returns JSON → api() receives it →", "the page function (renderView, renderResult, …) redraws;", "long work returns a job id and the page asks", "GET /api/jobs/<job> every 1-2 s (poll) until it is done,", "then draws the result and a message with Undo"])
    for d in ("M280 85H308", "M590 85H618", "M870 85H898", "M1020 160V198", "M900 275H872", "M715 350V388", "M870 465H898", "M560 465H532"):
        a += '<path d="%s" class="ln" marker-end="url(#m)"/>' % d
    return a + "</svg>"


def main():
    elements, problems = load()
    if problems:
        print("REFUSED: %d problem(s)" % len(problems))
        for p in problems:
            print("  -", p)
        return 1
    by = {code: [e for e in elements if e["screen"] == code] for code, *_ in SCREENS}
    imgs = {os.path.basename(p)[:-4] for p in glob.glob(os.path.join(HERE, IMG, "*.jpg"))}
    toc = "".join('<tr><td><a href="#screen-%s">%s</a></td><td class="muted">%s</td><td>%d</td></tr>' % (c, esc(t), esc(u), len(by[c]))
                  for c, t, u, _ in SCREENS if by[c])
    legend = "".join('<span class="g-%s"><b>%s</b> · %s</span>' % (l, n, esc(d)) for l, (n, d) in LAYERS.items())
    body = []
    for code, title, url, shot in SCREENS:
        els = by[code]
        if not els:
            continue
        body.append('<h2 id="screen-%s">%s</h2><p class="muted">Where: %s · %d elements on this screen, numbered in the picture and below.</p>' % (code, esc(title), esc(url), len(els)))
        shots = ([shot] if shot in imgs else []) + sorted((i for i in imgs if shot and i.startswith(shot + "_")), key=lambda x: int(x.rsplit("_", 1)[1]))
        for k, im in enumerate(shots):
            cap = "Each red number marks the element described under the same number below." if k == 0 else \
                  "The same screen with another tab or state open: the numbers continue the same list."
            body.append('<figure class="shot"><img loading="lazy" src="%s/%s.jpg" alt="%s with numbered markers"><figcaption>%s</figcaption></figure>' % (IMG, im, esc(title), cap))
        group = None
        for k, e in enumerate(els, 1):
            if e.get("group") and e["group"] != group:
                group = e["group"]
                body.append("<h3>%s</h3>" % esc(group))
            body.append(element_html(e, "%s%d" % ("" if code in ("SB",) else "", k)))
    n_code = sum(len(e.get("code") or []) for e in elements)
    page = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Application Map</title><style>%s</style></head><body><main>
<h1>Application map: every button and every piece of content, and how it is tied to the backend</h1>
<p class="lead">For each element of the Field-to-Test Loop: what it is, why it exists, when it appears, and an arrow chain that follows it from your click through the browser code, the server address, the Python functions and the database to what the screen shows. Written for a manager who has never seen the application.</p>
<p class="muted">%d elements on %d screens, %d code excerpts. Built %s by <code>docs/build_ui_map.py</code> from <code>docs/ui_map_src/</code>; every file name and line number below was checked against the current source when this page was built. For the background (what the numbers mean, the learning rules, the lab) read <a href="OPERATOR_AND_BACKEND_GUIDE.html">OPERATOR_AND_BACKEND_GUIDE.html</a>.</p>

<h2 id="start">Start the application and follow along</h2>
<pre class="cmd">cd 13_production_app
python3 run_app.py                     # then open http://127.0.0.1:8077 in a browser
python3 run_app.py --standin           # the same, without any AI model calls (deterministic answers)</pre>
<p>The server prints one line per request it answers (for example <code>"POST /api/runs/…/act HTTP/1.1" 200</code>). Keep that terminal visible while you click: every arrow chain below ends in exactly such a line.</p>

<h2 id="how">How the screens are tied to the backend</h2>
%s
<p>Every button follows the same nine boxes. The browser function in box 2 is named in each entry below with its file and line; the server function in box 4, the service in 5 and the engine function in 6 likewise. Nothing on the screen changes the database directly: every change goes through one server address and, in the knowledge base, through one function, <code>KGDB.apply_event</code>, which writes the event first and then updates the tables computed from it.</p>
<div class="box"><b>How to read an entry.</b> The left column says what the element is, why it exists and when it appears. The right column is the arrow chain, top to bottom, each step coloured by where it happens:<div class="legend">%s</div>Under each entry, "The code behind it" opens the real source of the functions named in the chain.</div>

<h2 id="questions">Your two questions, answered first</h2>
<div class="box"><h3 style="margin-top:0">"These many decision tiles: how did they come, why did they come?"</h3>
<p>The server decides which decisions to offer for each defect, in <code>available()</code> in <code>stage2/admin_actions.py</code>: ten are always offered (skip, defer, needs more evidence, record a lesson, add a cause, add a procedure, generate test cases, try nearby variations, restart the search, dispute the finding); fourteen more when the lookup found candidates to judge (accept, reject, rank, merge, link, split, delete, undo …); two more (approve, retire) when the defect was seen before. The list travels with the lookup to the screen, where <code>renderView()</code> in <code>review.js</code> sorts it into six groups (Judge, Order or compare, Tidy the knowledge base, Add what you know, Run more in the lab, Put it aside) and tags each tile with what it needs. Each tile exists because the project statement asks that every kind of admin feedback (correct, wrong, partly right, ranking, new knowledge, clean-up) changes what the system shows next time, without training any model. Full chain: <a href="#s4d-why-tiles">"Why exactly these 26 decision tiles appear"</a>; each tile has its own entry, for example <a href="#s4d-tile-accept">Accept</a>.</p>
<h3>"The long list of earlier decisions: where does it come from?"</h3>
<p>It is read from the event log of the knowledge base: every decision on this error type (from any run), newest first, with the lab result that followed it (<code>Stage2Service.feedback_history</code>, address <code>GET /api/db/feedback/&lt;error type&gt;</code>). On this laptop almost all rows were written by the automated tests (<code>tests/exercise_loop.py</code> and <code>tests/ui_smoke.py</code>), which press the same buttons every few minutes as "admin", with notes such as "exercise: bench silent". A production installation starts with an empty knowledge base and shows only real decisions. Full chain: <a href="#s4d-why-history">"Where the Earlier decisions rows come from"</a>.</p></div>

<nav class="toc"><b>Screens</b><table>%s</table></nav>
<div class="search"><input id="q" type="search" placeholder="Find a button or word on this page (for example: Correct, Undo, lesson, BM25, script_gate)"></div>
%s
<h2 id="differences">Where the screen and the code still differ (known limitations)</h2>
<p>While mapping every element, four reviewers compared each screen text with the code. Mismatches that could be fixed safely were fixed in the code on 27 October 2026 (for example: the second-admin name is no longer reused by a later decision; "also retire it" asks for the second admin; "Look up again" really looks up again; Undo on the Knowledge base page shows its message; the tile texts of Revise, Link, Add a procedure, Undo, Restart and Prefer now say what the code does). These remain, described in their entries:</p>
<table class="t"><tr><th>Where</th><th>What differs</th></tr>
<tr><td>Defect page</td><td>When the AI reviewer picks a lower-ranked error type, the page shows that id with the top candidate's title; steps 2–4 keep the top candidate.</td></tr>
<tr><td>Steps 2/3 vs defect page</td><td>A defect can read "Suspect" in the list and "Confirmed" on its page (the page uses the final isolation record).</td></tr>
<tr><td>Step 1</td><td>Host tool records alone (without dmesg) can make stage 1 fail with "cannot align clocks".</td></tr>
<tr><td>Defect page, section 5</td><td>"What usually fixes it" shows the catalogue's "test to provoke it" text for most error types.</td></tr>
<tr><td>Step 1</td><td>The reuse check ignores name, device, firmware and run label: analysing the same file again opens the old run.</td></tr>
<tr><td>Step 4, history</td><td>Removing, ranking or approving marks the defect "decided"; Defer also counts as decided.</td></tr>
<tr><td>Step 4, Undo</td><td>Undo removes the decision's events, not the procedures and tests a lab job already produced.</td></tr>
<tr><td>Step 4, Link</td><td>A linked procedure stays "proposed"; the lookup does not offer proposed procedures, so it cannot be accepted from the screens yet.</td></tr>
<tr><td>Step 4, Split</td><td>The suggested JSON for Split leaves the old cause's text empty unless you fill it in.</td></tr>
<tr><td>Step 4, older lookups</td><td>A lookup stored before 27 October shows 23 tiles and older seen-before words; "Look up again" refreshes it.</td></tr>
<tr><td>Report and Knowledge base</td><td>"Regression tests" counts every lab check, filed or not; the rules line uses the fixed constants (600 s, 3 in a row), not the Settings values; "links between causes and procedures" counts all graph links.</td></tr>
<tr><td>Knowledge base</td><td>The AI reviewer chip shows the internal model name; the filter does not search family names.</td></tr>
<tr><td>Settings</td><td>Save also stores step 1's firmware label and namespace size; a server started with --standin writes "standin" into the config file.</td></tr>
</table>
<p class="muted" style="margin-top:40px">End of the application map.</p>
</main>
<script>
(function(){var q=document.getElementById('q');if(!q)return;q.addEventListener('input',function(){var v=q.value.trim().toLowerCase();
document.querySelectorAll('article.el').forEach(function(a){a.style.display=(!v||a.getAttribute('data-text').indexOf(v)>=0||a.textContent.toLowerCase().indexOf(v)>=0)?'':'none';});});})();
</script></body></html>""" % (CSS, len(elements), sum(1 for c, *_ in SCREENS if by[c]), n_code, time.strftime("%d %b %Y %H:%M"),
                             architecture_svg(), legend, toc, "\n".join(body))
    open(OUT, "w", encoding="utf-8").write(page)
    print("wrote %s: %d elements, %d code excerpts, %d KB" % (OUT, len(elements), n_code, len(page) // 1024))
    return 0


if __name__ == "__main__":
    sys.exit(main())
