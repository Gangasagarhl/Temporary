# Provenance audit — where every formula, threshold and constant in the pipeline comes from

Date: 2026-10-26. Scope: the production application `13_production_app/` (stage 1 engine in `stage1/pcie_isolate`,
stage 2 in `stage2/`, the app in `app/`). Every number that changes a verdict, a ranking, a search or a test is listed
with its file, what it does and its **source class**:

| Class | Meaning |
|---|---|
| NORMATIVE | a value stated by a specification (PCI Express Base, PCI Bus PM, NVM Express Base / NVMe-over-PCIe / NVM Command Set); the clause is named in the detection spec and the engine record |
| ADVERTISED | a limit the device itself advertises in a register or Identify field (CAP.TO, MTFA, RTD3R, Device Control 2) — read from the capture when present |
| HOST POLICY | an operating-system timeout, not a device rule (Linux `nvme_core.io_timeout` etc.) |
| MODELED / EMPIRICAL | a value the engine chose because the standard gives no number (or gives it in units the capture cannot resolve); recorded as such in every run record |
| STATISTICAL IDENTITY | a textbook result of probability / statistics (no choice involved beyond the confidence level) |
| PAPER | a published method; the citation is given; the *parameter values* may still be an engineering choice and are marked so |
| USER RULE | a rule stated in the project statement or the user's diagram ("> 10 min = fail", "score > 0.9 three times") |
| ENGINEERING CHOICE | a value chosen by this project, with how it was calibrated and what evidence backs it |

No LLM is trained or fine-tuned anywhere; the knowledge-graph learning is counting (events in SQLite). The optional PPO
optimiser (section 4) fits a small policy inside one search and discards it. The LLM is used at five points — stage-1
confirmation per defect (cached by pattern), the optional stage-1 capture check, the stage-2 digest / presentation, the
stage-2 proposal (the seed of the search) and the test composition — all read-and-propose, and code verifies their output. "Verified" below means: the line was read, its source was
identified and, where a paper is cited, the citation was checked against the publisher's or arXiv record on 2026-10-26.

---

## 1. The line you asked about

`stage2/testgen.py`, `test_manifest()`:

```
n_bad = max(3, min(20, ceil( ln(0.05) / ln(1 − p) )))      with p = repro_lower95 clamped to [0.05, 0.95]
```

**What it decides.** How many times the generated regression test re-runs the procedure on known-bad firmware before
it concludes "does not reproduce". The test passes when the stage-1 detector isolates the card in **at least one** of
those runs (the manifest's `verdict_rules.known_bad.min_hits = 1`).

**Derivation (STATISTICAL IDENTITY).** If one run reproduces the defect with probability p and runs are independent,
the probability that n runs all miss is (1 − p)^n. Requiring that probability to be at most 5 % gives
(1 − p)^n ≤ 0.05 ⇔ n ≥ ln(0.05) / ln(1 − p). That is the geometric-distribution tail; it is the same algebra behind
the "rule of three" of Hanley & Lippman-Hand (JAMA 1983, 249:1743–1745: zero events in n trials bound the rate at
≈ 3/n at 95 %). No specification is involved; it is elementary probability.

**Which p.** Not the observed hit rate but its **Wilson 95 % lower bound** measured at generation (Wilson, JASA 1927,
22:209–212). Using the lower bound is conservative: a procedure that reproduced 4 of 6 runs has lower bound 0.30, so
the test is given 9 runs, not the 3 that the point estimate 0.67 would suggest.

**The clamps (ENGINEERING CHOICE, now documented in the code and in the manifest field `derivation`).**
p ∈ [0.05, 0.95] keeps n finite (p = 0 would give infinity); n ∈ [3, 20] bounds bench time: 3 is the smallest count
that still distinguishes "flaky" from "dead", 20 caps a test at 20 lab runs. Values: p = 0.95 → 3, 0.61 → 4, 0.5 → 5,
0.2 → 14, 0.14 → 20. The 95 % level is the usual convention, not a standard.

**What it is not.** It is not a flakiness quorum (the test needs one hit, not a majority — the majority rule lives in
the *validation* step, section 4.4) and it does not come from NVMe or PCIe; those specifications say nothing about
regression-test repetition.

---

## 2. Stage 1 — detection thresholds (engine record `THRESHOLD_SOURCES`, `stage1/pcie_isolate/engine.py`)

Every run writes this table into `run.json` with the value used, so a reviewer can re-judge a finding against the
revision the device implements. Specification baseline (from `10_defect_isolation_engine/PRODUCTION_READINESS.md` §4):
NVM Express Base 2.4, NVMe-over-PCIe Transport 1.4, NVM Command Set 1.3, PCI Express Base 6.x/7.0 semantics (7.0
released June 2025; the atlas cites 7.1), Linux v7.2 host policy.

| Threshold | Value | Class | Source |
|---|---|---|---|
| CTO_PS (completion timeout) | Device Control 2 range **read from the capture**, else 50 ms | ADVERTISED / NORMATIVE | PCIe Base, Completion Timeout ranges (Device Control 2 Completion Timeout Value); atlas T-33 |
| IO_TIMEOUT_PS | 30 s | HOST POLICY | Linux `nvme_core.io_timeout`; atlas T-22 |
| ADMIN_TIMEOUT_PS | 60 s | HOST POLICY | Linux `nvme_core.admin_timeout`; atlas T-23 |
| FLR_WAIT_PS | 100 ms before first access after Function Level Reset | NORMATIVE | PCIe Base, FLR; Linux `pcie_flr`; atlas T-43 |
| D0_WAIT_PS | 10 ms after D3hot → D0 before any access | NORMATIVE | PCI Bus PM Interface 1.2 state-transition recovery time; Linux `PCI_PM_D3HOT_WAIT`; atlas T-42 |
| CRS_LONG_PS | 1 s readiness after Conventional Reset (extendable by RRS/CRS) | NORMATIVE | PCIe Base, Conventional Reset readiness; Linux `PCI_RESET_WAIT`; atlas T-41 |
| RDY budget | CSTS.RDY within CAP.TO × 500 ms | ADVERTISED | NVMe Base, CAP.TO field in 500 ms units; atlas T-02 |
| REPLAY_NUM | 4th replay of one TLP → Recovery | NORMATIVE | PCIe Base, Data Link Layer REPLAY_NUM rollover; atlas T-36 |
| TRAIN_SLOW_PS | 100 ms link-down → Link Up | MODELED | LTSSM substate timeouts are 12–48 ms each; atlas T-39 |
| ACK_LATE_PS | 50 µs Ack latency | EMPIRICAL | the specification gives Ack latency in symbol times per rate/width; atlas T-37 |
| FC_WITHHELD_TLPS | 64 TLPs without UpdateFC while Acks flow | MODELED | specification: UpdateFC at least every 30 µs, 200 µs FC update watchdog; atlas T-38 |
| PME_ACK_PS | 10 ms PME_Turn_Off → PME_TO_Ack | MODELED | no normative number in the capture's resolution |
| PM_REQ_ACK_PS | 100 µs PM_Enter_L1/L23 → PM_Request_Ack | MODELED | idem |
| NOT_FETCHED_PS | 100 ms doorbell → SQE fetch | MODELED | atlas M-001: no normative limit |
| NO_MSIX_PS | 100 µs CQE → MSI-X | MODELED | idem |
| RDY_SLOW_PS | 500 ms CC.EN → CSTS.RDY flagged slow | EMPIRICAL | inside the CAP.TO budget |
| PP_LONG_PS | 1 s CSTS.PP | MODELED | advertised limit is MTFA (100 ms units); atlas T-10 |
| RESUME_SLOW_PS | 100 ms D0 → controller ready | MODELED | advertised value is RTD3R; atlas T-06 |
| RESET_QUIET_PS | 1 s: a host reset is "explained" by a wire defect inside the previous second | MODELED | attribution window |
| LTR_LOW_NS | LTR below 10 µs blocks L1.2 | MODELED | platform thresholds; atlas T-46 |
| SHUTDOWN | CC.SHN → SHST complete within 5 s | HOST POLICY | Linux `shutdown_timeout`; atlas T-05 |
| STORM | 3 Recovery entries within 10 ms | MODELED | storm definition |

**Rule catalog.** `rules.py` holds 167 rules: 46 tier A (stateless row predicate), 36 tier B (keyed state machine /
temporal), 74 tier N (need payload bytes), 8 tier H (host evidence), 3 tier S (statistical); 159 are DEFECT level and
8 are CONTEXT observations used for attribution. The rules themselves are structural ("CQE with SC ≠ 0",
"MRd before the 10 ms window", "UpdateFC absent") and carry no number beyond the table above; the per-card
specification references (named sections of the PCIe Base / NVMe Base / NVM Command Set specifications, e.g. "PCIe
Base Specification, Data Link Layer: AckNak_LATENCY_TIMER", "NVM Express Base Specification: SMART / Health
Information log") are in `08_defect_detection_spec/DEFECT_DETECTION_SPEC_485.md` (one block per card, 485 cards) and
are repeated per card in `docs/FINAL_WORKFLOW_AND_ALGORITHMS.html` section 15.

**What the web check could and could not confirm (2026-10-26).** Secondary sources confirm 10 ms D3hot → D0 (PCI PM
1.2 recovery time), 100 ms FLR, UpdateFC every 30 µs (±50 % per an Intel errata note) and the 200 µs FC timeout
(PCIe 2.0 wording), and CAP.TO in 500 ms units (QEMU/Linux drivers). The specification texts themselves are behind
PCI-SIG / NVM Express membership and were not fetched; the clause pointers above are those recorded by the engine and
the detection spec, which were written from the atlas with the specification at hand.

### 2.1 Stage 1 — statistical tier (approach C, `statistics.py`)

| Item | Value | Class | Note |
|---|---|---|---|
| timing-outlier threshold | `max(k × median, quantile q, physical floor)`; k = 10 for latency series, 4 for L1 exit, count series use floors only | ENGINEERING CHOICE | median-based so a tight healthy distribution does not flag jitter; floors are modeled minimums (50 µs doorbell → fetch, 1 ms media, 2 ms data phase, 20 ms flush, 50 ms admin …); no standard defines "outlier" here |
| rolling change-point | median of 16 consecutive commands ≥ factor × class median | ENGINEERING CHOICE | catches throttling cliffs; the window of 16 is a choice |
| rarity windows | 1024-packet windows; a row token present in ≤ rare_frac of windows is rare | ENGINEERING CHOICE | unsupervised, no labels |

These produce **SUSPECT** findings only; they never confirm a card on their own (tier S rules are verdict SUSPECT in
`rules.py`).

### 2.2 Stage 1 — incident building and atlas matching

| Item | Value | Class | Note |
|---|---|---|---|
| GAP_PKTS | 1000 packets: findings closer than this form one incident | ENGINEERING CHOICE | `incidents.py` |
| MAX_REL_SPAN | 300 000 packets | ENGINEERING CHOICE | a related-row pointer further away does not stretch the incident |
| CONTEXT_ROWS | 15 rows above/below for the reviewer | USER RULE | the project statement asked for ±15 rows of context |
| TASK_ROWS / H_LEAD_PKTS | 1500 / 50 | ENGINEERING CHOICE | host-task description window; host-only cluster joins a wire cluster within 50 packets |
| atlas card score | `s × (0.85 + 0.15 × prior)` | ENGINEERING CHOICE | signature similarity s, 15 % weight on the family prior voted by the findings (`atlas.py`) |
| results | 437/485 wire-only, 483/485 with host evidence, 0 false positives on the 4 GB trace; seed7 calibration 0 FP | measured | `10_defect_isolation_engine/REPORT_defect_isolation.md` |

### 2.3 Stage 1 — LLM confirmation

Claude Haiku 5.5 (`claude-haiku-5-5`), effort low, JSON schema with `rules_confirmed / rules_refuted / root_pkt /
cascade_pkts / hypotheses / needs`; citations restricted to the listed packets and checked by code; verdict cache by
pattern. Measured on 43 stratified incidents: 0 schema errors, 0 unseen citations, 2 genuine disagreements that led
to one engine fix and one prompt fix (`REPORT_defect_isolation.md`). Nothing is trained.

---

## 3. Stage 2 — the knowledge database and the learning rules

| Item | Where | Value / formula | Class | Source and notes |
|---|---|---|---|---|
| prior on every cause edge / procedure node | `kgdb.py`, `procgraph.py` | Beta(a = 1, b = 1) | STATISTICAL IDENTITY | the uniform (Laplace) prior; posterior mean a/(a+b) |
| credit / blame | `kgdb._credit`, `procgraph._credit` | success: a ← a+1; failure: b ← b+1; n ← n+1 | PAPER | Beta–Bernoulli conjugate update — the Thompson-sampling bandit (Thompson, Biometrika 1933; Chapelle & Li, NIPS 2011 "An Empirical Evaluation of Thompson Sampling") |
| localised blame | `admin_actions.py` | only the judged item changes | ENGINEERING CHOICE | measured on the 14-implementation benchmark (`REPORT_final_implementation.md`): Beta counts with localised credit (C2) Exact@1 0.743; the team-literal policy with a ×0.5 penalty on "not" (T1) 0.676; the policy where rankings move weights and weak nodes are removed (T2) 0.624 |
| discount γ | `kgdb.py` p["gamma"] | (a,b) ← 1 + (a−1)(1−γ), γ = 0.02 per verdict on the signature | PAPER (idea) / ENGINEERING CHOICE (value) | discounted statistics for non-stationary bandits: Garivier & Moulines, "On Upper-Confidence Bound Policies for Switching Bandit Problems", ALT 2011 (arXiv 0805.3415); 0.02 chosen so ~35 verdicts halve old evidence |
| cap | p["cap"] = 50 | if a+b > 50 scale both to 50 | ENGINEERING CHOICE | bounded memory so a few new decisions can still move a long-approved item |
| firmware change | p["fw_halve"] = 0.5 | (a,b) ← 1 + (a−1)/2 | ENGINEERING CHOICE | context shift halves evidence |
| content edit | p["edit_shrink"] = 0.7 | (a,b) ← 1 + (a−1)·0.7 | ENGINEERING CHOICE | the claim changed, the history did not vanish |
| technical counts | ta, tb | "lab" verdict: ta/tb ← +1, a/b untouched | ENGINEERING CHOICE | "could not reproduce" ≠ "wrong" |
| ordering rating | `kgdb.py` / `procgraph.py` `proc_rank` | Plackett–Luce: for i in order, for m ≥ i: pl_m += η·((1−p_m) if m = i else −p_m)/K, p_m = e^{pl_m}/Σ_{j≥i} e^{pl_j}, η = 0.3 | PAPER (model) / ENGINEERING CHOICE (η) | Plackett (1975) / Luce (1959) model; the update is the gradient of the listwise log-likelihood as in ListMLE (Xia, Liu, Wang, Zhang, Li, ICML 2008); η = 0.3 and the 1/K normalisation are choices; rankings never count as successes — measured: counting them as successes dropped Exact@1 to 0.624 |
| two-person rules | `admin_actions.py` TWO_PERSON | approver ≠ requester for promote / deprecate / delete_approve | ENGINEERING CHOICE | four-eyes principle (process control), enforced server-side |
| undo | `kgdb.undo` | event marked undone, projections rebuilt | STATISTICAL IDENTITY | event sourcing: exact reversal by replay |

## 4. Stage 2 — retrieval, presentation, search and verification

| Item | Where | Value / formula | Class | Source and notes |
|---|---|---|---|---|
| rank fusion | `retrieval_v3.py` RRF_K = 60 | fused = Σ_channels w_c / (60 + rank) | PAPER | Cormack, Clarke & Büttcher, SIGIR 2009 "Reciprocal rank fusion outperforms Condorcet…", k = 60 as in the paper |
| channel weights | CHANNEL_W struct 1.0, bm25 1.0, trigram 0.7, rows 0.7, dense 0.7 | | ENGINEERING CHOICE | tuned on the 26-suite benchmark; hybrid ≥ C2 on every suite (`REPORT_stage2_v3.md`) |
| BM25 | `_bm25` k1 = 1.2, b = 0.75 | | PAPER | Okapi BM25 (Robertson et al., TREC-3 1994; Robertson & Zaragoza 2009); k1 = 1.2, b = 0.75 are the reference defaults (also Lucene's) |
| hashed trigrams | `trigrams(dims = 2^18)` | character 3-grams into 262 144 buckets | PAPER | feature hashing (Weinberger et al., ICML 2009); the dimension is a choice |
| row-kind similarity | `_rows` | longest common subsequence ratio over packet kinds | STATISTICAL IDENTITY | LCS |
| score with feedback | `final = fused × √(0.5 + 0.5·a/(a+b)) × e^{0.5·tanh(pl)}` | | ENGINEERING CHOICE | bounded factors: counts can at most halve or restore a text match (√0.5 ≈ 0.71 … 1), a rating tilts by at most e^{±0.5}; chosen so no single signal dominates |
| exploration slot | last shown slot = Thompson draw from the remaining candidates | | PAPER | Thompson sampling (above) |
| seen-before: match | T_HI = 0.70 fused and struct ≥ 1.375 (card + context + ≥ 2 of 4 fields) | | ENGINEERING CHOICE | calibrated so a different manifestation of the same card is not a match (fix recorded in `REPORT_stage2_v3.md` §4); T_LO = 0.35 |
| presentation rerank | `presenter.py` Borda count of retrieval rank and LLM rank | | PAPER | Borda count rank aggregation (Dwork, Kumar, Naor, Sivakumar, WWW 2001 "Rank aggregation methods for the Web"); ties to retrieval |
| LLM digest | Haiku 5.5, effort low, JSON schema, citations ⊆ evidence | | ENGINEERING CHOICE | checked by code; 0 invalid JSON, 0 citation violations on 18 incidents |
| search: reward | `optimizer.py` R = stage + closeness, stage ∈ {0..4} | | ENGINEERING CHOICE | stage 3 = target CONFIRMED, 4 = with matching parameters |
| search: operator choice | Beta(1,1) per mutation operator, pick by `betavariate` | | PAPER | Thompson sampling over operators (adaptive operator selection) |
| search: restart | patience 25 non-improving trials, parent = Thompson-sampled archive cell `betavariate(1+3r, 1+(5−r)+0.3n)` | | PAPER (idea) / ENGINEERING CHOICE (values) | Go-Explore archive of cells ("First return, then explore", Ecoffet, Huizinga, Lehman, Stanley, Clune, Nature 2021); the cell prior numbers are choices |
| search: LLM ranges | timing drawn inside the LLM-proposed [lo, hi] with probability 0.7, else ×{¼, ½, 2, 4} or quadratic-biased uniform | | PAPER (idea) / ENGINEERING CHOICE | SLLMBO: LLM-proposed search space as a prior (Mahammadli & Ertekin, arXiv 2410.20302, 2024) |
| search: seeds | LLM proposal; stored procedure; ≤ 2 approved exemplars of the family; the LLM digest's sequence; the family's trigger template (atlas XII.4 wire patterns); one retry from the template when the first search finds nothing | | ENGINEERING CHOICE | templates are the atlas's own "test to provoke it" shapes; the retry uses the next random stream and the same budgets |
| signature score (the diagram's "test score") | `loop_rules.signature_score` | share of 3 yes/no checks passed: same error type isolated, same first rule, verdict CONFIRMED (1.0 / 0.667 / 0.333 / 0) | USER RULE (threshold 0.9, 3 in a row) / no tunable weights | "score > 0.9" is exactly "same error, same rule, confirmed"; the earlier weighted form (0.55/0.20/0.15/0.10 with a closeness term) was removed on 2026-10-27 because the weights had no specification behind them |
| the two rules | `loop_rules.py` SCORE_THRESHOLD 0.9, OPTIMAL_CONSECUTIVE 3, FIRST_LEVEL_TRIAGE_S 600 | | USER RULE | the architecture diagram, verbatim |
| PPO option | `ppo_optimizer.py` clip 0.2, γ 0.9, λ 0.95, lr 0.05, 4 epochs, batch 24, entropy 0.01 | | PAPER (algorithm) / ENGINEERING CHOICE (values) | Schulman, Wolski, Dhariwal, Radford, Klimov (2017) "Proximal Policy Optimization Algorithms", arXiv 1707.06347; GAE: Schulman et al. (2016) arXiv 1506.02438; benchmark on the device model, 24 runs each: PPO 15 confirmed (median 166 trials), bandit 14 (median 156) |
| vulnerability sweep | `sweep.py` ×0.5 / ×2 per timing parameter, every other power state, burst +1, idle 500 ms when the base has none (up to 15 variants), 3 runs per variant, failure-prone = ≥ 2 of 3, top 3 filed | | ENGINEERING CHOICE | "surrounding failure-prone areas"; jammer faults 10⁻⁴ TLP corruption / 500 µs delayed completion / Recovery every 50 ms are the defaults a hardware `inject(spec)` receives (`clear_faults()` after each jammer variant; jammer variants go through the closed loop when `inject` exists, else "hardware bench only") |
| workload artifact import (API only, not on the screens) | `app/workload_import.py` artifact confidence ≥ 0.8 → CONFIRMED else SUSPECT; card = "WL-" + symptom | | ENGINEERING CHOICE | the artifact's own confidence (boot_etl robust-z based) decides the status word |
| KPI leakage | `/api/kpi` | leakage = recurrences re-run on Correct − recurrences re-admitted | ENGINEERING CHOICE | "zero regression leakage for known failure signatures" counted where the stored test was actually re-run |
| search: confirm | a reproducing candidate re-run confirm_n = 8 times; accepted if Wilson lower ≥ 0.5 | | STATISTICAL IDENTITY (bound) / ENGINEERING CHOICE (8, 0.5) | Wilson 1927; "reproduces in the majority with 95 % confidence" |
| search: minimise | ddmin over commands, bisection over timing | | PAPER | delta debugging (Zeller & Hildebrandt, IEEE TSE 28(2), 2002) |
| budgets | 300 trials per search, with one retry from the family template when the first search finds nothing (so up to 600 trials), under one 600 s first-level-triage clock; status `triage_timeout` (the search stops; verification completes) | | USER RULE | the diagram's "> 10 min = fail" |
| regression guard / admin version | 6 runs, kept if k ≥ 3 | | ENGINEERING CHOICE | majority of 6; cheaper than the full confirm step because the procedure already carries evidence |
| closed loop | n_bad = 6 known-bad runs (≥ 1 hit), n_fixed = 3 fixed-firmware runs (0 top-1 hits), decoy neighbour card present | | ENGINEERING CHOICE | asymmetric by design: a false "fixed" is worse than a flaky "bad" |
| optimal | 3 consecutive closed-loop verification runs with signature score > 0.9 (a flag on the verification; the search stops on the Wilson confirmation above) | | USER RULE | the diagram's "score > 0.9 three times" |
| ambiguity group | engine candidates with score ≥ 0.25 (max 3) | | ENGINEERING CHOICE | measured once per card on a synthetic capture |
| test repeats | section 1 | | STATISTICAL IDENTITY + clamps | |
| fixed-firmware repeats | 5, max_hits 0; position tolerance 32 rows (hardware only) | | ENGINEERING CHOICE | `test_manifest` |
| safety deny-list | format, sanitize, fw-download, fw-commit, delete-ns | | NORMATIVE (opcodes) / ENGINEERING CHOICE (list) | NVMe admin opcodes Format NVM 80h, Sanitize 84h, Firmware Commit 10h / Download 11h, Namespace Management 0Dh are never in the vocabulary; `research_notes_v3/llm_test_composition.md` §A6 |
| timing ranges | inter_cmd_us 1–5000, burst 1–128, idle 0–2000 ms, qd 1–256, bs 4–1024 KB | | ENGINEERING CHOICE | lab bounds; the LLM cannot exceed them (clamped by code) |
| composition | ≤ 3 variants, 6 runs each, Wilson ≥ 0.5, never auto-approved | | ENGINEERING CHOICE backed by the research note | "generate many, verify by execution, keep few" (A3 of the note); K ≤ 5 sources |
| likelihood words | ≥ 0.8 very likely, ≥ 0.5 likely, ≥ 0.25 possible | `decision.js` | ENGINEERING CHOICE (IPCC-style calibrated language, thresholds adapted to a lower bound) | words always next to the number |

## 5. What is NOT from any standard, and how it was calibrated

Every row marked ENGINEERING CHOICE above. They were calibrated on this project's data and the evidence is in the
reports: the 15-implementation ranking benchmark (2 GB, 26 edge-case suites; `REPORT_final_implementation.md`), the v3
retrieval benchmark and the 18-incident Haiku run (`REPORT_stage2_v3.md`), the stage-1 calibration seed7/seed11 and the
4 GB run (`REPORT_defect_isolation.md`), and the live exercises on the application (`runs/exercise_report.md`,
`runs/ui_smoke/`). All of them are in `config/app_config.json` or module constants and can be changed without touching
the algorithms. What must be re-measured on real hardware before trusting the numbers: the MODELED / EMPIRICAL stage-1
thresholds (they are placeholders where the standard gives no number), the closed-loop counts (synthetic bench ≠
device physics), and the search budgets (a real bench run takes longer than the synthetic one).

## 6. Citations checked on 2026-10-26

- Wilson, E. B. (1927). Probable inference, the law of succession, and statistical inference. *JASA* 22(158):209–212.
- Hanley, J. A., Lippman-Hand, A. (1983). If nothing goes wrong, is everything all right? *JAMA* 249:1743–1745.
- Thompson, W. R. (1933). On the likelihood that one unknown probability exceeds another. *Biometrika* 25:285–294.
  Chapelle, O., Li, L. (2011). An empirical evaluation of Thompson sampling. *NIPS 24*, 2249–2257.
- Garivier, A., Moulines, E. (2011). On upper-confidence bound policies for switching bandit problems. *ALT 2011*
  (arXiv 0805.3415, 2008 preprint titled "… non-stationary bandit problems").
- Plackett, R. L. (1975). The analysis of permutations. *Applied Statistics* 24:193–202. Luce, R. D. (1959).
  *Individual Choice Behavior*. Xia, F., Liu, T.-Y., Wang, J., Zhang, W., Li, H. (2008). Listwise approach to learning
  to rank: theory and algorithm (ListMLE). *ICML 2008*.
- Cormack, G. V., Clarke, C. L. A., Büttcher, S. (2009). Reciprocal rank fusion outperforms Condorcet and individual
  rank learning methods. *SIGIR 2009*, 758–759 (k = 60).
- Robertson, S., Zaragoza, H. (2009). The probabilistic relevance framework: BM25 and beyond. *Foundations and Trends
  in IR* 3(4); reference defaults k1 = 1.2, b = 0.75 (as in Apache Lucene).
- Weinberger, K., Dasgupta, A., Langford, J., Smola, A., Attenberg, J. (2009). Feature hashing for large scale
  multitask learning. *ICML 2009*.
- Dwork, C., Kumar, R., Naor, M., Sivakumar, D. (2001). Rank aggregation methods for the Web. *WWW 2001* (Borda count).
- Ecoffet, A., Huizinga, J., Lehman, J., Stanley, K. O., Clune, J. (2021). First return, then explore. *Nature*
  590:580–586 (Go-Explore).
- Mahammadli, K., Ertekin, S. B. (2024). Sequential large language model-based hyper-parameter optimization (SLLMBO).
  arXiv 2410.20302.
- Zeller, A., Hildebrandt, R. (2002). Simplifying and isolating failure-inducing input. *IEEE TSE* 28(2):183–200 (ddmin).
- Schulman, J., Wolski, F., Dhariwal, P., Radford, A., Klimov, O. (2017). Proximal Policy Optimization Algorithms. arXiv 1707.06347;
  Schulman, J., Moritz, P., Levine, S., Jordan, M., Abbeel, P. (2016). High-dimensional continuous control using generalized advantage estimation. ICLR 2016 (arXiv 1506.02438).
- LLM test composition sources (TestPilot, TestGen-LLM, ChatAFL, KernelGPT, FuzzGPT, Fuzz4All, Large Language
  Monkeys, in-toto/SLSA): `Database_Implmentation/claude_research_report/stage2_upgrade_research/research_notes_v3/llm_test_composition.md`.
- Specifications: NVM Express Base 2.4 / NVMe-over-PCIe 1.4 / NVM Command Set 1.3 (nvmexpress.org), PCI Express Base
  6.x/7.0 (PCI-SIG, members only), PCI Bus Power Management Interface 1.2; Linux v7.2 host policy — as recorded in
  `PRODUCTION_READINESS.md` §4.


## Added on 2026-10-27: stress ascent (most stressful trigger conditions)

| what | where | provenance |
|---|---|---|
| stress ascent after a confirmed reproduction: each timing value pushed one step in its stressful direction (×0.5 spacing, ×2 queue depth / burst / block size / idle gap), kept while the defect still appears in 2 of 3 lab runs | `stage2/optimizer.py Optimizer.stress_ascent`, `stage2/stage2_v3.py _stress`, `_finish` | own design: a coordinate-wise greedy ascent on the same lab ranges and the same "still fails" check (2 of 3) as `minimize`; the stress ratio is the product of the per-value ratios, the same definition `sweep.stress_of` uses for one value. The step directions are engineering judgement (the directions a drive is least likely to survive), not from any standard. Budget `stage2.stress_trials` = 30 lab runs, inside the first-level triage limit. |

## Removed on 2026-10-27 (operator-facing numbers without a source)

| what | where it was | why removed |
|---|---|---|
| model self-rated confidence (0-1) | stage-1 review schema, stage-2 digest and proposal schemas, every screen | a number the model invents in its answer; no specification or statistic defines it. Only the verdict (agrees / disagrees / not sure) and the cited packets remain |
| stage-1 combined confidence (base 0.35 + weights) | `isolation.py _conf` | hand-picked weights; the status word (Confirmed / Suspect / Needs evidence) comes from the rules alone and is what the screens show |
| weighted signature score | `loop_rules.py` | replaced by the three yes/no checks above |
| retrieval, rating and feedback numbers on the main screens | decision view, review queue, report | kept only inside "All details" and the knowledge-base page, each with a one-line meaning |
