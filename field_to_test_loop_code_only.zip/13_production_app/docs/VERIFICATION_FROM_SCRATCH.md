# Verification from scratch — the mailable package, extracted into an empty folder and run end to end

Date: 2026-10-26 23:12. Package: `field_to_test_loop_production_package_v1.zip` (sha256 in the .SHA256.txt next to it). Machine: this laptop, no GPU.

## 1. Extract

- 3378 entries extracted; the application folder is `/tmp/claude-1000/-home-raghavendra-Desktop-Project-Implmentation/d277da47-de5e-4054-bc2d-c355cbb09a97/scratchpad/fresh_pkg/field_to_test_loop_package/13_production_app`

## 2. Offline tests (`./run_tests.sh`)

```
test_pipeline (__main__.WorkloadArtifactTest.test_pipeline) ... ok

----------------------------------------------------------------------
Ran 4 tests in 75.528s

OK
```
- exit code 0 in 76 s

## 3. Start

- `python3 run_app.py --port 8078` from the extracted folder; database empty at start: {"events": 0, "signatures": 0, "solutions": 0}

## 4. Stage 1 on the 4 GB trace (`pcie_trace_485_errors_4GB.csv`, 4.00 GB)

- companion files found next to the CSV: found: payload, dmesg, events
- job run-20261026-231334-056b: **done** in 335 s; rows read 20706924; findings 6529; incidents 544
- per-step seconds: {"stage1.analyze": 292.091, "stage1.fuse": 0.246, "stage1.isolate": 38.112, "stage1.pattern_cache": 0.197, "stage1.report": 0.422}
- 544 incidents, 544 with an atlas card, 393 distinct cards; status words {"Confirmed": 487, "Needs evidence": 57}
- failure signature of INC-0001: {"all_packet_kinds": ["ACK", "ACK", "ACK", "ACK", "MWr(64)", "MWr(32)", "ACK", "ACK", "UpdateFC-P", "MWr(32)", "ACK", "CfgWr0", "ACK", "Cpl", "ACK", "CfgWr0"], "baseline": null, "card": "T-42", "command": null, "detail": "MMIO read 0x1C 2.000 ms after D3hot->D0", "device": "device 002:00:0, root com

## 5. Stage 2

- gate: HTTP 409 before Start stage 2 (expected 409)
- Start stage 2 prepared 544 defects (database lookup + stand-in proposal) in 10 s: done
- queue counts: {"admitted": 0, "decided": 0, "llm_confirmed": 0, "presented": 544, "total": 544}
- seen-before verdicts on an empty database: {"new": 544}
- LLM switched to anthropic:claude-haiku-5-5:low
- INC-0001 T-42: real-LLM presentation in 20 s (model 20 s): seen=new; headline: CfgWr0 to PMCSR (D3hot→D0) then BAR MMIO read 2.000 ms later returns UR, inside the 10 ms recovery window (T-42 pattern); problems: []
- INC-0003 L-21: real-LLM presentation in 21 s (model 21 s): seen=new; headline: Device upstream 256 B MWr to 0xFB000000 with no owning command (#156818). No stored procedure; ACS P2P is unconfirmed.; problems: ["unknown ops ['read (4 kb, mixed with writes, to reproduce the small-io task pattern)', 'write (4 kb, same lba mix, only to a scratch namespace)', 'get_log (error log check after each burst)']"]
- INC-0001 T-42: Correct -> search + closed loop: status **confirmed**, mode generate, 569 trials, repro lower bound 0.676, closed loop {"known_bad_hits": 6, "known_bad_n": 6, "fixed_hits": 0, "fixed_n": 3}, scores [0.95, 0.95, 0.95, 0.95, 0.95, 0.95] (streak 6, optimal True), admitted True, files ['conftest.py', 'manifest.json', 'test_T_T_42_2a317860.py'], 45 s
- manager view after it: 1 stored sequence(s) for this error; candidates: [('sol::2a31786', 'admin-approved'), ('llm', 'proposal')]
- INC-0001 T-42: Generate test case -> **composed**: 4 variant(s) composed by anthropic:claude-haiku-5-5:low from 1 source(s); [('D3hot entry then BAR read at 2 ms', 0, False), ('Same read trigger at zero idle gap', 0, False), ('ASPM idle then read with L1 state', 0, False), ("adapted by the search from 'D3hot entry ", 8, True)]; files ['conftest.py', 'manifest.json', 'test_T_T_42_bf06eb8d.py']; LLM 15.0 s, lab 0.0 s
- INC-0001 T-42: Sweep the neighbourhood -> **swept**: 14 variants, 42 lab runs, failure-prone ['inter_cmd_us x0.5 (731 -> 366)', 'burst_len x0.5 (16 -> 8)', 'burst_len x2 (16 -> 32)', 'idle_gap_ms x2 (555 -> 1110)', 'qd x0.5 (8 -> 4)', 'qd x2 (8 -> 16)', 'bs_kb x2 (4 -> 8)', 'power_state -> L1', 'power_state -> L1.2', 'power_state -> D3hot', 'power_state -> APST', 'last command doubled (burst)'], filed 3, jammer: hardware bench only: jammer variants need inject() in app/be (50 s)
- workload artifact input: imported 2 abnormalities as defects (['WL-storage.flush.latency', 'WL-filesystem.metadata.latency']) in done
- INC-0001 WL-storage.flush.latency: real-LLM baseline for the ADK abnormality -> **awaiting_hardware_bench**, proposed test ['conftest.py', 'manifest.json', 'test_T_WL_storage_flush_latency_31dabe63.py'] (bench: hardware)
- KPI: rules {"first_level_triage_s": 600, "optimal_consecutive": 3, "score_threshold": 0.9}; 2/2 runs within the triage budget; defects isolated 546/546; known-signature leakage 0; tests on file 6, by hand 0
- database after the run: {"approved_solutions": 1, "artifacts": 6, "cases": 2, "cause_nodes": 2, "deleted_nodes": 0, "edges": 2, "events": 1122, "lessons": 0, "node_versions": 2, "signatures": 395, "solutions": 6}; LLM usage {"cache_read": 18382, "cache_write": 33490, "cost_usd": 0.7955820000000001, "errors": 0, "input_tokens": 18, "output_tokens": 17105}
- generated test suite: 6 test(s) ['T-T-42-2286dc28', 'T-T-42-2a317860', 'T-T-42-ae0f9d52', 'T-T-42-bf06eb8d', 'T-T-42-ce064fb9', 'T-WL-storage.flush.latency-31dabe63']
- `python3 -m pytest suite/T-T-42-2286dc28` with no environment variables: exit 0 in 30 s: 2 passed in 29.30s

## 6. Result

- total wall-clock 675 s. The package that was verified is byte-identical to the one mailed except for this report, which was added afterwards (code unchanged).

## Appendix — the from-scratch runs that led to this report (all on 2026-10-26)

| Run | Outcome | What it found | What was changed |
|---|---|---|---|
| 1 | stage 1 failed at isolate | the packager excluded every folder named `runs`, which dropped `stage1/runs/signature_library.json` | exclusions anchored to the application root |
| 2 | stage 1 544 incidents in 310 s; T-42 confirmed; tests composed; plain pytest failed | stage 2 resolved the engine and generator to the development tree without environment variables | packaged layout found by default |
| 3 | as run 2; plain pytest failed | the generated `conftest.py` looked for `stage2/` only among its ancestors | conftest also looks in an ancestor's `stage2/` |
| 4 | stage 1 identical; T-42 search exhausted 300 trials from the LLM seed alone | the first search on an empty database depended on one model answer | the family trigger template is always a seed, with one retry from it |
| 5 | everything passed (570 trials after the retry, closed loop 6/6 and 0/3, plain pytest 2 passed) | — | — |
| 6 | everything passed, now with the diagram's rule (six consecutive signature scores of 0.95), the neighbourhood sweep, the ADK-artifact input and the KPI report | — | — |
| 7 (this report) | the package after the code review's fixes | — | — |

Stage 1 produced the same 544 incidents / 393 cards / 487 Confirmed + 57 Needs evidence in every run (rows read
20,706,924), in 300–350 s on this laptop. The LLM cost of one run (presentations, one proposal, one composition, one
sweep, one workload baseline) was about $0.65–0.90 at Haiku prices.
