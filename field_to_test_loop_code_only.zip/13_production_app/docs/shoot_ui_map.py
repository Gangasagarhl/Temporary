#!/usr/bin/env python3
"""Numbered screenshots for docs/APPLICATION_MAP.html.

Opens each screen of the running application in a headless Chrome, puts a red numbered marker on every element
listed for that screen in docs/ui_map_src/part_*.py (by its "selector"), and saves docs/ui_map_images/<screen>.jpg.

SAFE FOR A LIVE INSTALLATION: it only loads pages and performs clicks that stay inside the browser (opening the
"All details" box, a tab, the card editor, a decision tile that only shows the confirm step, the report button that
only reads). It never presses Correct, Save, Record, Undo or Start, so nothing is written to the database.

    python3 docs/shoot_ui_map.py [--base http://127.0.0.1:8077] [--run RUN] [--gate-run RUN]
"""
import argparse
import base64
import glob
import io
import json
import os
import runpy
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
OUT = os.path.join(HERE, "ui_map_images")
sys.path.insert(0, os.path.join(APP, "tests"))

MARK_JS = r"""
(function(items){
  document.querySelectorAll('.__mk').forEach(e => e.remove());
  const placed = [];
  items.forEach(([n, sel]) => {
    if (!sel) return;
    let el = null; try { el = document.querySelector(sel); } catch (e) { return; }
    if (!el) return;
    const r = el.getBoundingClientRect(); if (r.width === 0 && r.height === 0) return;
    const box = document.createElement('div'); box.className = '__mk';
    box.style.cssText = `position:absolute;left:${r.left + scrollX - 2}px;top:${r.top + scrollY - 2}px;width:${r.width + 4}px;height:${r.height + 4}px;border:2px solid #cf222e;border-radius:6px;z-index:99998;pointer-events:none`;
    let x = r.left + scrollX - 14, y = r.top + scrollY - 14;
    for (const p of placed) if (Math.abs(p[0] - x) < 26 && Math.abs(p[1] - y) < 26) { x += 28; }
    placed.push([x, y]);
    const b = document.createElement('div'); b.className = '__mk'; b.textContent = n;
    b.style.cssText = `position:absolute;left:${Math.max(0, x)}px;top:${Math.max(0, y)}px;min-width:26px;height:26px;padding:0 5px;border-radius:13px;background:#cf222e;color:#fff;font:700 13px/26px sans-serif;text-align:center;z-index:99999;box-shadow:0 0 0 2px #fff;pointer-events:none`;
    document.body.appendChild(box); document.body.appendChild(b);
  });
  return placed.length;
})(%s)
"""


def elements():
    out = {}
    for f in sorted(glob.glob(os.path.join(HERE, "ui_map_src", "part_*.py"))):
        for e in runpy.run_path(f)["ELEMENTS"]:
            out.setdefault(e["screen"], []).append(e)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="http://127.0.0.1:8077")
    ap.add_argument("--run", default="run-20261026-145008-0220")
    ap.add_argument("--inc", default="INC-0001")
    ap.add_argument("--gate-run", default="run-20261026-224357-fac3")
    ap.add_argument("--commands-run", default=None, help="a run analysed with the commands step (step 3); default: --run")
    ap.add_argument("--port", type=int, default=9470)
    a = ap.parse_args()
    import ui_smoke as U
    from PIL import Image
    os.makedirs(OUT, exist_ok=True)
    els = elements()
    b = U.Browser(port=a.port)
    B, R = a.base, a.run

    seq = [0]
    def go(url, wait=2.5):
        # a unique query value forces a real page load (a change of the #part alone would not reload the page)
        seq[0] += 1
        base, _, frag = url.partition("#")
        url = base + ("&" if "?" in base else "?") + "_shot=%d" % seq[0] + ("#" + frag if frag else "")
        b.send("Page.navigate", {"url": url})
        time.sleep(wait)

    def sel_run(run):
        b.ev("(()=>{const s=document.getElementById('run-select'); if(s){s.value='%s'; } return 1;})()" % run)

    def nav(page, step=None):
        q = '[data-page="%s"]%s' % (page, ('[data-step="%s"]' % step) if step else "")
        b.ev("(()=>{const n=document.querySelector('aside .nav%s'); if(n) n.click(); return 1;})()" % q.replace('"', '\\"'))
        time.sleep(1.5)

    def click(sel, wait=0.8):
        b.ev("(()=>{const n=document.querySelector(%s); if(n) n.click(); return !!n;})()" % json.dumps(sel))
        time.sleep(wait)

    def shoot(code, max_h=12000, suffix=""):
        items = [[k + 1, e.get("selector") or ""] for k, e in enumerate(els.get(code, []))]
        n = b.ev(MARK_JS % json.dumps(items))
        h = int(b.ev("Math.min(%d, document.documentElement.scrollHeight)" % max_h) or 1800)
        b.send("Emulation.setDeviceMetricsOverride", {"width": 1366, "height": h, "deviceScaleFactor": 1, "mobile": False})
        time.sleep(0.6)
        b.ev(MARK_JS % json.dumps(items))                       # re-place after the resize
        shot = b.send("Page.captureScreenshot", {"format": "png", "captureBeyondViewport": True})
        im = Image.open(io.BytesIO(base64.b64decode(shot["data"]))).convert("RGB")
        if im.width > 1400:
            im = im.resize((1400, int(im.height * 1400 / im.width)))
        im.save(os.path.join(OUT, code + suffix + ".jpg"), quality=74, optimize=True)
        b.send("Emulation.setDeviceMetricsOverride", {"width": 1366, "height": 1000, "deviceScaleFactor": 1, "mobile": False})
        print("%-8s %3d of %3d markers placed, %d px tall" % (code + suffix, n or 0, len(items), h))

    b.send("Emulation.setDeviceMetricsOverride", {"width": 1366, "height": 1000, "deviceScaleFactor": 1, "mobile": False})
    # sidebar + step 1 (no run selected)
    go(B + "/#run/choose"); shoot("SB", 1100); shoot("S1", 4200)
    # step 2 and 3 of a finished run
    go(B + "/?run=%s#run/analyse" % R, 3.5)
    b.ev("document.querySelectorAll('#page-run details').forEach(d=>d.open=true)")
    b.ev("(()=>{const d=document.querySelector('#run-results details, #run-inc-list details'); if(d) d.open=true; return 1;})()")
    shoot("S2")
    go(B + "/?run=%s#incidents" % R, 3); shoot("S3")
    # step 3: the errors found under NVMe commands, with the first error row opened
    go(B + "/?run=%s#commands" % (a.commands_run or R), 4)
    b.ev("(()=>{const r=document.querySelector('#cmd-errbody tr.errrow'); if(r) r.click(); return 1;})()")
    time.sleep(2.5)
    shoot("S3C")
    # the defect page
    go(B + "/defect?run=%s&inc=%s" % (R, a.inc), 3); shoot("DP")
    # the stage-2 gate of a run where stage 2 was never started (reading the queue writes nothing)
    go(B + "/?run=%s#review" % a.gate_run, 3); shoot("S4G")
    # step 4 main screen: open the card editor and remove-stub (both stay in the browser until Save is pressed)
    go(B + "/?run=%s#review/%s" % (R, a.inc), 4)
    b.wait("document.querySelector('#sol-list .solcard')", 30)
    click('#sol-list .solcard:not(.stub) button[data-v="partial"]')
    b.ev("(()=>{const c=[...document.querySelectorAll('#sol-list .solcard:not(.stub)')]; if(c.length>1){const x=c[c.length-1].querySelector('button[data-v=\"wrong\"]'); if(x) x.click();} return 1;})()")
    time.sleep(0.8)
    b.ev("(()=>{const m=document.querySelector('#sol-list details.menu'); if(m) m.open=true; return 1;})()")
    shoot("S4")
    # All details: open the box, show the confirm step of one tile (nothing is sent until Record this decision)
    go(B + "/?run=%s#review/%s" % (R, a.inc), 4)
    b.wait("document.querySelector('#sol-list .solcard')", 30)
    b.ev("document.getElementById('r-advanced').open=true"); time.sleep(0.8)
    b.ev("document.querySelector('#ed-box') && (document.querySelector('#ed-box').open=true)")
    click('#a-targets .target input')
    click('#r-actions .atile[data-a="reject"]')
    shoot("S4D", 16000)
    for tab, suf in (("evidence", "_2"), ("result", "_3")):
        click('#page-review .tabs button[data-sub="%s"]' % tab, 1.0); shoot("S4D", 9000, suf)
    # report (the button only reads)
    go(B + "/?run=%s#report" % R, 3); click("#btn-report", 4); shoot("S5")
    go(B + "/?run=%s#settings" % R, 3); b.ev("document.querySelectorAll('#page-settings details').forEach(d=>d.open=true)"); shoot("ST")
    go(B + "/?run=%s#help" % R, 3); shoot("HP")
    go(B + "/db", 3); click("#sig-rows tr, #sig-table tbody tr, table tbody tr", 2.5); shoot("KB", 5000)
    for tab, suf, extra in (("tables", "_2", "#btn-db-load"), ("events", "_3", None), ("cache", "_4", None), ("llm", "_5", None)):
        click('.tabs button[data-sub="%s"]' % tab, 1.5)
        if extra: click(extra, 2.0)                               # Load only reads (GET /api/db/table/...)
        shoot("KB", 5000, suf)
    b.close()


if __name__ == "__main__":
    main()
