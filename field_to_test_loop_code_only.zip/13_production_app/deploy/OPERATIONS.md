# Field-to-Test Loop: day-to-day operations

For whoever runs the service after it was installed with `deploy/AGENT_INSTRUCTIONS.md`. `$APP` = the
`13_production_app` folder (the one with `run_app.py`). The service unit is assumed to be installed from
`deploy/field-to-test-loop.service` under the name `field-to-test-loop` as described in `deploy/DEPLOY.md`; adjust
the name if it was installed differently. **AI reviewer** = the large language model (LLM) that gives a second
opinion; **API** = the web addresses under `/api/...`; **KPI** = the "Key results" on the Report page. The
commands use `${PORT:-8077}`: 8077 is the shipped `server.port`; if yours differs, run `export PORT=<port>` first.
The environment file of the service is `/etc/field-to-test-loop/environment` and the service user is `ftl`
(`deploy/DEPLOY.md`).

The hard rules of `deploy/AGENT_INSTRUCTIONS.md` section 1 apply here too: never delete `db/knowledge.sqlite` (and
never copy or move it without its side files `knowledge.sqlite-wal` and `knowledge.sqlite-shm`), never run two server processes on the same `db/`, keep the server on 127.0.0.1 behind the authenticating proxy, keys
only in environment variables, respect the two-person rule, never train a model, never run format / sanitize /
firmware download / namespace delete on a drive.

---

## 1. Start, stop, status, logs

| Task | Command |
|---|---|
| Start | `sudo systemctl start field-to-test-loop` |
| Stop | `sudo systemctl stop field-to-test-loop` |
| Restart (needed after changing keys or the environment file, `server.*`, `paths.*`, `stage2.bench`, any setting edited in the file, and the keys locked by `server.lock_endpoint`) | `sudo systemctl restart field-to-test-loop` |
| Status | `systemctl status field-to-test-loop` → `active (running)` |
| Server log (requests, Python errors) | `journalctl -u field-to-test-loop -n 200 --no-pager` (`-f` to follow) |
| Is it answering? | `curl -fsS http://127.0.0.1:${PORT:-8077}/api/config >/dev/null && echo up` |
| Without systemd (development only) | `cd $APP && . .venv/bin/activate && python3 run_app.py` — prints `Field-to-Test Loop  ->  http://127.0.0.1:8077   (local only; Ctrl-C to stop)` (add `--port <port>` for another port); stop with Ctrl-C |

Every lookup and every decision is committed to the knowledge base immediately (`app/stage2_service.py`), so a stop
or a crash loses only a job that is still running: it is marked failed with "server restarted while running" at the
next start (`app/jobs.py`) and has to be repeated. Before a stop or restart, check that no job is running:
```bash
curl -fsS "http://127.0.0.1:${PORT:-8077}/api/jobs?limit=20" | python3 -c 'import json,sys; print([(j["kind"], j["status"]) for j in json.load(sys.stdin) if j["status"] in ("queued","running")])'
# expect: []   (otherwise wait, or warn the admins that they will have to repeat that job)
```

Other logs, inside `$APP`:
- `runs/<run>/stage1_app.log` — the full output of every stage-1 step of that run (first place to look when a run fails).
- The **Activity log** of a run on the screens = table `job_event` in `db/app.sqlite` (`GET /api/jobs/<job>/events`).
- `db/stage2_log.jsonl` — one line per stage-2 decision result (audit trail).

## 2. Where the data lives and how big it grows

All runtime data is inside `$APP`; there is no setting to move it (`app/services.py`). To put it on another disk,
place `$APP` there (or ask the owner before using symbolic links).

| Path | Contents | Size seen on the development machine | Growth |
|---|---|---|---|
| `db/knowledge.sqlite` (+ `knowledge.sqlite-wal`, `knowledge.sqlite-shm`) | **the knowledge base** (write-ahead-log mode; the two side files belong to it): table `event` (every decision and lab result, never edited) and the tables computed from it | 1.4 MB for 1,144 events | about 1.2 KB per event on average; one decision with a lab job writes several events |
| `db/app.sqlite` | jobs and their activity lines (tables `job`, `job_event`), AI verdict cache (`verdict_cache`) | 2.5 MB for 190 jobs | per job and per activity line |
| `db/llm_cache.jsonl` | every stage-2 AI answer keyed by the exact question | 0.6 MB | per new question |
| `db/stage2_log.jsonl` | audit line per stage-2 result | 0.65 MB | per decision |
| `runs/<run>/` | one folder per analysed capture: stage-1 outputs, `stage2/<defect>.json`, report | 0.2–29 MB for synthetic captures | grows with the capture size; plan for large folders with multi-gigabyte captures |
| `runs/_bench/` | traces written by the **simulated** lab (one folder per error type) | **561 MB** | grows with every simulated lab run |
| `runs/bench_<error type>/` | work folders of a real bench hook (`app/bench_hook.py`) | — | depends on the hook |
| `suite/<test id>/` | the generated regression tests | 1.4 MB for 51 tests | about 27 KB per test |
| `samples/` | synthetic captures made through `POST /api/samples/generate` | 47 MB | only when someone makes samples |
| `config/app_config.json` | all settings (written by **Save** on the Settings page) | — | — |

Check: `du -sh $APP/db $APP/runs $APP/runs/_bench $APP/suite $APP/samples` and `df -h $APP`.

## 3. Routine backups

What to back up, in order of importance:
1. `db/knowledge.sqlite` with its side files — irreplaceable (the learned knowledge).
2. `suite/` — the regression tests.
3. `config/app_config.json` and, once it is implemented, `app/bench_hook.py` (your bench code).
4. `db/app.sqlite`, `db/llm_cache.jsonl`, `db/stage2_log.jsonl` — run history, caches, audit trail.
5. `runs/` — optional (large); without it old runs cannot be reopened, but the knowledge base is complete.

Use `deploy/backup.sh` (and `deploy/restore.sh`) as described in `deploy/DEPLOY.md` section 9, on a schedule the
owner agrees (daily is a sensible default), to a different disk or machine. `backup.sh` uses the SQLite backup
function and is safe while the server runs. Never copy `knowledge.sqlite` alone with `cp`: the database runs in
write-ahead-log mode (`PRAGMA journal_mode=WAL`, `stage2/kgdb.py`), so recent committed decisions may still be
only in `knowledge.sqlite-wal`; a copy of the main file alone can miss them. If you must copy files by hand, stop
the service and copy the three files together (or the whole `db/` folder). For an ad-hoc copy while the server
runs, use the SQLite online backup:
```bash
sqlite3 $APP/db/knowledge.sqlite ".backup '/backup/knowledge-$(date +%F).sqlite'"
sqlite3 -readonly /backup/knowledge-$(date +%F).sqlite "PRAGMA integrity_check;"     # expect: ok
```

## 4. Monthly restore test

A backup is only proven by a restore. Once a month (and after each upgrade), while production keeps running:
1. Make a scratch copy of the release **without its data** (its own `db/`, so it is not a second server on the
   production `db/`), owned by the service user so it can read the backups:
   ```bash
   sudo -u ftl mkdir -p /tmp/f2t-restore/13_production_app
   sudo -u ftl rsync -a --exclude=/db/ --exclude=/runs/ --exclude=/suite/ --exclude=/samples/ --exclude=/.venv/ \
        --exclude='/pre-restore-*/' /opt/field-to-test-loop/current/ /tmp/f2t-restore/13_production_app/
   ```
2. Restore the latest backup into the copy. `deploy/restore.sh` allows this while the service runs, because the
   target is not the folder the service runs from:
   ```bash
   LATEST=$(sudo -u ftl sh -c 'ls -t /opt/field-to-test-loop/backups/ftl-backup-*.tar.gz | head -1'); echo "$LATEST"
   sudo -u ftl /opt/field-to-test-loop/current/deploy/restore.sh "$LATEST" \
        --app-dir /tmp/f2t-restore/13_production_app --python /opt/field-to-test-loop/current/.venv/bin/python
   ```
   Expect "the service 'field-to-test-loop' is active, but runs from another folder: restoring into the scratch
   copy ...", "knowledge.sqlite integrity=ok events=<n>" and "restored: db suite config ...". A warning that the runs
   were recorded under `/opt/field-to-test-loop/current` is expected for a scratch copy (only the old run list
   lacks its summaries there). Options of the script: `deploy/restore.sh --help`.
3. If the restored `config/app_config.json` has `"bench": "hook"`, set it to `"synthetic"` in the copy: the copy
   must not drive the lab bench. Then start the copy with the **production virtual environment's Python**, the
   copy's own config, another port and no model calls:
   ```bash
   cd /tmp/f2t-restore/13_production_app && sudo -u ftl /opt/field-to-test-loop/current/.venv/bin/python run_app.py --config config/app_config.json --port 8099 --standin
   ```
4. In a second shell, compare with production:
   ```bash
   for p in ${PORT:-8077} 8099; do curl -fsS http://127.0.0.1:$p/api/db/summary | python3 -c 'import json,sys; print(json.load(sys.stdin)["knowledge"])'; done
   ```
   The counts of the restored copy must equal the counts in the archive's manifest (kept in the copy as
   `pre-restore-<time>/RESTORED_FROM_MANIFEST.txt`; production may have more
   events since the backup). Open http://127.0.0.1:8099/db (through a secure shell tunnel on a remote server) and
   look at one error type's tree.
5. Stop the copy (Ctrl-C), delete the scratch folder (`sudo rm -rf /tmp/f2t-restore`), write the date and result into
   the operations log.

Checked on 2026-10-27 on a scratch installation (as an ordinary user, without systemd): `backup.sh` →
`restore.sh --app-dir <copy>` → copy started on another port → both showed the same counts (10 events, 2
procedures).

## 5. Upgrade

Follow `deploy/DEPLOY.md` (upgrade and rollback). The points that matter for this application:
1. Read the new version's change notes (`docs/CHANGES_*.md`).
2. Run a backup (section 3) and check no job is running (section 1).
3. Stop the service.
4. Replace the code (`app/`, `stage1/`, `stage2/`, `data/`, `tests/`, `docs/`, `deploy/`, `run_app.py`,
   `run_tests.sh`), **keeping** `db/`, `runs/`, `suite/`, `samples/`, `config/app_config.json` and your
   `app/bench_hook.py` (replacing `app/` overwrites it — save it first and put it back). Compare the new
   `config/app_config.json` with yours and copy over any new keys.
5. Mail-safe zip: `python3 restore_names.py` (AGENT_INSTRUCTIONS step 2.1).
6. `python3 -m pip install -r deploy/requirements.txt`, `./run_tests.sh`, and the pre-flight check **as the service
   user with the service's environment file loaded** (run as plain `sudo -u ftl ...` the key variable is missing and
   the key check FAILs):
   ```bash
   sudo sh -c 'set -a; . /etc/field-to-test-loop/environment; set +a; cd /opt/field-to-test-loop/current && exec runuser -u ftl -- .venv/bin/python deploy/preflight.py --config config/app_config.json --check-llm'
   ```
   (`runuser -u` keeps the loaded variables; `sudo -u` would drop them.) Expect `0 FAIL`; in production
   `server.lock_endpoint` is PASS and `bench synthetic` stays a WARN until a real bench is connected.
7. Start; check `GET /api/db/summary` shows the same event count as before; open one earlier run.
8. If anything is wrong: roll back per `deploy/DEPLOY.md` (old code + the backup taken in step 2).

## 6. Changing the AI model or key

**On the Settings page** (sidebar "⚙ Settings") you can change "How the AI reviewer is reached (backend)", "Model",
"API base URL", "API key environment variable" and the limits, then press **Save**. This sends `PUT /api/config`
(`app/api/config_api.py`): the values are written to `config/app_config.json` and `Stage2Service.reload_llm`
switches the AI reviewer **without a restart**; the message reads "saved · the AI reviewer now in use: <name>".
Check the name (`anthropic:<model>:<effort>`, `openai-compat:<model>`, or `stand-in` = the model is not reachable).
New stage-1 runs pick the new settings up because each run copies `llm` at its start.

**The lock in production.** `server.lock_endpoint` is `false` in the shipped `config/app_config.json` and `true` in
`deploy/config.production.example.json`. When it is `true`, a **Save** (or `PUT /api/config`) that changes
`llm.backend`, `llm.base_url`, `llm.api_key_env`, `llm.tools` or `paths.allowed_csv_roots` is refused with HTTP 403
"<key> is locked by server.lock_endpoint: stop the service, edit the config file, start it again". So, for those
keys: check no job is running (section 1), `sudo systemctl stop field-to-test-loop`, `sudoedit -u ftl
/opt/field-to-test-loop/current/config/app_config.json`, `sudo systemctl start field-to-test-loop`. The model, the
effort and the stage-1 / stage-2 limits can still be changed on the page.

**What needs the file or a restart:**
- `PUT /api/config` accepts only the sections `llm`, `stage1`, `stage2` and `paths`. `kpi.*` (the manual baselines
  of the Key results) and `server.*` can be changed **only in the file**, with the service stopped (a file edit
  while it runs is overwritten by the next **Save**).
- Read only at start (restart after changing them, even when saved on the page): `stage2.bench`, `paths.*`,
  `server.*`.
- The environment of the running process: a **new key variable name** works without restart only if that variable
  is already in the service environment; for `sdk`, an `llm.base_url` that was once set stays in the process as
  `ANTHROPIC_BASE_URL` until restart; a newly installed package or `claude` command is seen after a restart.
- Settings not on the Settings page (`llm.workers`, `stage2.optimizer`; `llm.tools` when not locked) can be sent with
  `PUT /api/config`, or edited in the file with the service stopped.

Side effects of changing the model: the run cache and the stage-1 verdict cache are keyed by model, so the same
capture is analysed again and patterns are re-confirmed (more model calls and cost for a while). Stage-2 answers are
cached per model as well.

**Rotating the key** (the key lives only in the service environment, see `deploy/DEPLOY.md`):
1. Put the new key into the service's environment file with `sudoedit /etc/field-to-test-loop/environment` (never
   into `config/app_config.json`, never on a command line).
2. `sudo systemctl restart field-to-test-loop` (a running process cannot see a changed environment; for `sdk` the
   key is also copied into `ANTHROPIC_API_KEY` inside the process at first use). Check no job is running first.
3. Check the key as the service sees it — as the service user, with the environment file loaded (plain
   `sudo -u ftl ... preflight.py` has no key variable and its key check FAILs):
   ```bash
   sudo sh -c 'set -a; . /etc/field-to-test-loop/environment; set +a; cd /opt/field-to-test-loop/current && exec runuser -u ftl -- .venv/bin/python deploy/preflight.py --config config/app_config.json --check-llm'
   ```
   Expect the AI reviewer call line PASS and `0 FAIL`; then check `llm_active` on the Settings page.
4. Revoke the old key at the provider only after step 3 passed. Cached answers do not depend on the key.

## 7. Deleting old runs and freeing disk

- On "1 Choose the trace" → "Earlier runs (history)", press **Delete** on a run (or `DELETE /api/runs/<run id>`).
  It removes the run's stage-1 results, stage-2 state files, jobs and activity log (`app/api/runs_api.py`
  `delete_run`). **The knowledge base and the regression tests in `suite/` are kept.** A running run must be
  cancelled first ("the run is still in progress - cancel it first").
- Note: the Key results are computed over the runs that still exist (`GET /api/kpi` reads the job table), so deleting
  runs lowers the run counts there. Export the report first if the numbers are needed (`GET /api/runs/<run>/report?format=md`).
- `runs/_bench/` (simulated lab traces) is not removed by **Delete**. With the service stopped it can be emptied; the
  simulated bench regenerates traces on demand (first lab runs are slower afterwards). Do not delete
  `runs/bench_*` folders of a real bench without asking whoever wrote the hook.
- `samples/` can be emptied when nobody needs the synthetic captures (runs made from them can then not be re-analysed).

## 8. Exporting the regression suite to the company test system

Each folder `suite/<test id>/` (the id is `T-<error type>-<device>-<procedure id>`; it carries the device model when
one was known) holds three files (`stage2/testgen.py` `emit_closed_loop_test`):
- `test_<id>.py` — the test: runs the procedure on known-bad firmware (repeated so a defect with the measured rate
  is seen at least once with 95 % confidence) and checks that the same stage-1 analyser isolates the same error
  type; then checks that fixed firmware stays silent.
- `manifest.json` — what the test is: error type, procedure, timing, device preconditions, the lab check at
  generation (`closed_loop_at_generation`), and for composed or stress tests `composition` / `stress`.
- `conftest.py` — the bench fixtures `bench` and `bench_fixed`.

Rules for exporting:
1. Export only admitted tests: `manifest.json` → `closed_loop_at_generation.passed` must be `true` (a folder can be
   written for a procedure whose lab check failed; it is not admitted). List them:
   ```bash
   cd $APP && for d in suite/*/; do python3 -c "import json,sys; m=json.load(open('$d/manifest.json')); print(m['test_id'], (m.get('closed_loop_at_generation') or {}).get('passed'))"; done
   ```
   or `GET /api/suite`; single files: `GET /api/suite/<test id>/<file>?download=1`.
2. Run a test: `cd $APP/suite/<test id> && python3 -m pytest -q` (needs `pytest`). Inside `$APP` the fixtures find
   `stage2/` by themselves; in a copy elsewhere set `STAGE2_DIR=$APP/stage2` (the analyser and generator are then
   found relative to it).
3. **The fixtures need the bench.** The shipped `conftest.py` returns `GeneratorBench` — the **simulated** drive. In
   the company test system replace the two fixtures with your hardware bench (an object with `run(scenario)` and
   `detect(trace)`, the same interface as `app/bench_hook.py`; see `deploy/BENCH_INTEGRATION.md`). The manifest's
   preconditions name the device model; run the test only on that model.
4. A passing test on the simulated bench proves the pipeline, not the drive.

## 9. Monitoring signals

| Signal | How to read it | Healthy |
|---|---|---|
| Process up | `systemctl status field-to-test-loop`; `curl -fsS http://127.0.0.1:${PORT:-8077}/api/config` | active; HTTP 200 |
| AI reviewer reachable | `llm_active` in `GET /api/config` (sidebar badge) | the intended model, not `stand-in` |
| AI reviewer errors and cost | `GET /api/db/overview` → `llm_usage` (`errors`, `cost_usd`, tokens); stage-1 activity "(N answered, M errors)" | errors not growing; cost as expected |
| Failed jobs | `curl -fsS "http://127.0.0.1:${PORT:-8077}/api/jobs?limit=100"` → `status` / `error` | no unexplained `failed` |
| Leakage | `GET /api/kpi` → `quality.known_signature_leakage` ("slipped past their test (must be 0)") | 0 |
| Triage limit | `GET /api/kpi` → `efficiency.runs_within_triage_budget` vs `efficiency.runs`; results "first-level triage limit (10 min) exceeded" | rare |
| Two-person rule | `sqlite3 -readonly $APP/db/knowledge.sqlite "SELECT vhash FROM solution WHERE status='admin-approved' AND approved_by = producer;"` | empty |
| Database intact | `sqlite3 -readonly $APP/db/knowledge.sqlite "PRAGMA integrity_check;"` | `ok` |
| Disk | `df -h $APP`; `du -sh $APP/runs $APP/runs/_bench` | enough free space for the next captures |
| Server errors | `journalctl -u field-to-test-loop -p err` and Python tracebacks in the journal | none |
| Backups | the backup job's own log; last monthly restore test date | recent |

## 10. Incident response: the knowledge base looks wrong

Symptoms: a procedure is approved that nobody approved, ratings jumped, an error type has a cause it should not have,
tests from a test run appear in production.

1. **Ask the admins to pause decisions** for that error type (new events make the history harder to read). Do not stop
   the service unless the database is damaged (step 5).
2. **Find the event.** Knowledge base page (`/db`) → "Event log (most recent first)" shows id, time, kind, who and
   contents; or the "Earlier decisions on this error type" table on the defect page; or SQL:
   ```bash
   sqlite3 -readonly $APP/db/knowledge.sqlite "SELECT id, datetime(ts,'unixepoch','localtime'), kind, actor, substr(payload,1,200) FROM event WHERE payload LIKE '%\"sig\": \"T-42\"%' ORDER BY id DESC LIMIT 30;"
   ```
   (replace T-42 with the error type). Each event carries `meta` with run, defect, device, firmware and the operator
   name typed at the time.
3. **Undo it.** On the Knowledge base page type the id into "Undo event number" and press **Undo this event &
   rebuild** (confirm "Undo event N and rebuild the knowledge base from the event log?"). This sends
   `POST /api/db/undo`: the event is marked undone and every table is rebuilt from the remaining events
   (`stage2/kgdb.py` `undo`, `rebuild`). Undone events stay visible, marked. Undo the newest wrong event first when
   several belong together (one decision usually wrote several events). Undo cannot be reversed from the screens:
   note every id you undo.
4. **Check**: the rating / status on the error type's tree is back to its earlier value; the two-person SQL query is
   empty; for wrong tests, note that the folders in `suite/` are not removed by an undo — tell the owner which test
   ids are invalid before anyone exports them.
5. **Last resort — restore from backup** (only if the file is damaged, `PRAGMA integrity_check` is not `ok`, or the
   wrong events are too many to undo one by one, and only with the owner's agreement):
   ```bash
   sudo systemctl stop field-to-test-loop
   sudo /opt/field-to-test-loop/current/deploy/restore.sh /opt/field-to-test-loop/backups/ftl-backup-<time>.tar.gz
   sudo systemctl start field-to-test-loop
   curl -fsS http://127.0.0.1:${PORT:-8077}/api/db/summary | python3 -c 'import json,sys; print(json.load(sys.stdin)["knowledge"])'
   ```
   `restore.sh` moves the whole current `db/` folder — `knowledge.sqlite` **together with** `knowledge.sqlite-wal`
   and `knowledge.sqlite-shm` — into `pre-restore-<time>/` (nothing is deleted; it is the evidence and holds the
   events made since the backup). If you ever move it by hand, do it with the service stopped and move the three
   files together, or the whole `db/` folder (`cd /opt/field-to-test-loop/current && sudo -u ftl mv db db.damaged-$(date +%F)`): the `-wal` file can hold
   committed decisions that are not yet in the main file, and a main file moved without it loses them. Every
   decision made after the backup is missing from the restored knowledge base and must be entered again;
   `db/stage2_log.jsonl` and the moved-aside folder show what they were.
6. **Write it up**: what was wrong, which event ids were undone or which backup was restored, who was told.
