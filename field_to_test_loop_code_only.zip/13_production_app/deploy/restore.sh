#!/usr/bin/env bash
# Restore a Field-to-Test Loop backup made by deploy/backup.sh.
#
#   deploy/restore.sh ARCHIVE [--app-dir DIR] [--service NAME|none] [--force] [--python PY]
#
#   ARCHIVE         an ftl-backup-<stamp>.tar.gz file
#   --app-dir DIR   the application folder to restore into                default: /opt/field-to-test-loop/current
#   --service NAME  the systemd service of the live installation          default: field-to-test-loop
#                   "none": skip every service check (a machine without the service)
#   --force         restore even though the target folder is in use (NOT recommended: the running server keeps its
#                   old database open and would overwrite or ignore the restored one)
#   --python PY     Python 3 interpreter used for the checks               default: python3
#
# Two cases:
#   in place      --app-dir is the folder the service runs from (its WorkingDirectory, normally
#                 /opt/field-to-test-loop/current). Refused while the service is active: stop it first.
#   scratch copy  --app-dir is any other folder (for example a second unpacked release, to test a backup). Allowed
#                 while the production service keeps running.
#   In both cases the restore is refused while any process holds <app-dir>/db/knowledge.sqlite open (fuser).
#
# Steps: the checks above; unpack into a temporary folder; check every database (PRAGMA integrity_check) and the
# configuration (valid JSON); move what is about to be replaced into <app-dir>/pre-restore-<stamp>/ (nothing is
# deleted; db/ moves as a whole, so the old knowledge.sqlite-wal/-shm go aside together with knowledge.sqlite and
# no stale write-ahead log is replayed onto the restored file); copy the restored folders in; restore
# app/bench_hook.py when the archive has it (the replaced one is kept too); give everything to the owner of
# <app-dir> when run as root. Folders that are not in the archive are left untouched (runs/ is replaced only when
# the archive contains it).
set -euo pipefail

APP_DIR=${FTL_APP_DIR:-/opt/field-to-test-loop/current}
SERVICE=field-to-test-loop
PY=${FTL_PYTHON:-python3}
FORCE=0
ARCHIVE=""

die() { echo "restore.sh: $*" >&2; exit 1; }

while [ $# -gt 0 ]; do
    case "$1" in
        --app-dir) APP_DIR=${2:?--app-dir needs a value}; shift 2 ;;
        --service) SERVICE=${2:?--service needs a value}; shift 2 ;;
        --python)  PY=${2:?--python needs a value}; shift 2 ;;
        --force)   FORCE=1; shift ;;
        -h|--help) sed -n '2,27p' "$0"; exit 0 ;;
        -*)        die "unknown option: $1 (see --help)" ;;
        *)         [ -z "$ARCHIVE" ] || die "only one archive may be given"; ARCHIVE=$1; shift ;;
    esac
done

[ -n "$ARCHIVE" ] || die "usage: restore.sh ARCHIVE [--app-dir DIR] [--service NAME|none] [--force]"
[ -f "$ARCHIVE" ] || die "archive not found: $ARCHIVE"
ARCHIVE=$(cd "$(dirname "$ARCHIVE")" && pwd -P)/$(basename "$ARCHIVE")
APP_DIR_GIVEN=${APP_DIR%/}
APP_DIR=$(cd "$APP_DIR" 2>/dev/null && pwd -P) || die "application folder not found (create or unpack it first)"
command -v "$PY" >/dev/null 2>&1 || die "python interpreter not found: $PY"
[ -f "$APP_DIR/run_app.py" ] || echo "restore.sh: warning: $APP_DIR has no run_app.py (not an application folder?)" >&2

# ---- 1. is the target the live installation, and is it in use? ----
resolve() { (cd "$1" 2>/dev/null && pwd -P) || true; }
LIVE=0              # 1: --app-dir is the folder the service runs from
SVC_ACTIVE=0
if [ "$SERVICE" != "none" ] && command -v systemctl >/dev/null 2>&1; then
    systemctl is-active --quiet "$SERVICE" 2>/dev/null && SVC_ACTIVE=1
    live_dirs=()
    wd=$(systemctl show -p WorkingDirectory --value "$SERVICE" 2>/dev/null || true)
    [ -n "$wd" ] && live_dirs+=("$(resolve "$wd")")
    pid=$(systemctl show -p MainPID --value "$SERVICE" 2>/dev/null || true)
    if [ -n "$pid" ] && [ "$pid" != "0" ]; then          # the folder the running process really started from
        cwd=$(readlink -f "/proc/$pid/cwd" 2>/dev/null || true)
        [ -n "$cwd" ] && live_dirs+=("$cwd")
    fi
    [ ${#live_dirs[@]} -gt 0 ] || live_dirs+=("$(resolve /opt/field-to-test-loop/current)")   # unit not installed
    for d in "${live_dirs[@]}"; do
        [ -n "$d" ] && [ "$d" = "$APP_DIR" ] && LIVE=1
    done
fi
busy=""
if [ "$LIVE" -eq 1 ] && [ "$SVC_ACTIVE" -eq 1 ]; then
    busy="the service '$SERVICE' is active and runs from $APP_DIR (sudo systemctl stop $SERVICE)"
elif [ "$SVC_ACTIVE" -eq 1 ]; then
    echo "restore.sh: the service '$SERVICE' is active, but runs from another folder: restoring into the scratch copy $APP_DIR"
fi
if [ -z "$busy" ] && [ -f "$APP_DIR/db/knowledge.sqlite" ]; then
    if command -v fuser >/dev/null 2>&1; then
        fuser "$APP_DIR/db/knowledge.sqlite" >/dev/null 2>&1 \
            && busy="a process has $APP_DIR/db/knowledge.sqlite open (fuser -v $APP_DIR/db/knowledge.sqlite)"
    else
        echo "restore.sh: note: fuser not installed; cannot check whether a process has the database open" >&2
    fi
fi
if [ -n "$busy" ]; then
    [ "$FORCE" -eq 1 ] || die "refusing to restore: $busy. Stop it first, or pass --force."
    echo "restore.sh: WARNING: $busy; continuing because of --force" >&2
fi

# ---- 2. unpack and check ----
STAGE=$(mktemp -d "${TMPDIR:-/tmp}/ftl-restore-XXXXXX")
trap 'rm -rf "$STAGE"' EXIT
tar -C "$STAGE" -xzf "$ARCHIVE"
shopt -s nullglob
tops=("$STAGE"/ftl-backup-*)
shopt -u nullglob
[ ${#tops[@]} -eq 1 ] && [ -d "${tops[0]}" ] || die "unexpected archive layout (expected one ftl-backup-<stamp>/ folder)"
SRC=${tops[0]}
[ -f "$SRC/MANIFEST.txt" ] || die "archive has no MANIFEST.txt (not made by backup.sh?)"
[ -d "$SRC/db" ] || die "archive has no db/ folder"
shopt -s nullglob
side=("$SRC"/db/*.sqlite-wal "$SRC"/db/*.sqlite-shm "$SRC"/db/*.sqlite-journal)
shopt -u nullglob
[ ${#side[@]} -eq 0 ] || die "the archive contains SQLite side files (${side[*]##*/}); it was not made by backup.sh"

CHECK='
import json, sqlite3, sys
for p in sys.argv[1:]:
    if p.endswith(".json"):
        json.load(open(p))
        continue
    con = sqlite3.connect("file:%s?mode=ro" % p, uri=True)
    ok = con.execute("PRAGMA integrity_check").fetchone()[0]
    if ok != "ok":
        sys.exit("integrity check failed for %s: %s" % (p, ok))
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type=?", ("table",))}
    extra = (" events=%d" % con.execute("SELECT COUNT(*) FROM event").fetchone()[0]) if "event" in tables else ""
    print("  %s integrity=ok%s" % (p.rsplit("/", 1)[-1], extra))
    if "job" in tables:                      # run folders are recorded with absolute paths: report where they lived
        roots = set()
        for (params,) in con.execute("SELECT params FROM job"):
            rd = (json.loads(params or "{}") or {}).get("run_dir") or ""
            if "/runs/" in rd:
                roots.add(rd.rsplit("/runs/", 1)[0])
        for r in sorted(roots):
            print("RECORDED_ROOT=" + r)
    con.close()
'
shopt -s nullglob
checks=("$SRC"/db/*.sqlite "$SRC"/config/*.json)
shopt -u nullglob
echo "checking the archive:"
check_out=""
if [ ${#checks[@]} -gt 0 ]; then
    check_out=$("$PY" -I -c "$CHECK" "${checks[@]}") || die "the archive failed its checks; nothing was changed"
fi
printf '%s\n' "$check_out" | grep -v '^RECORDED_ROOT=' || true
# The jobs table stores each run folder as an absolute path (the folder run_app.py was started from). Restoring
# into another path leaves the run list without its summaries; restore into the path the service starts from.
while IFS= read -r root; do
    [ -n "$root" ] || continue
    if [ "$root" != "$APP_DIR_GIVEN" ] && [ "$root" != "$APP_DIR" ]; then
        echo "restore.sh: warning: the runs in this backup were recorded under $root, not $APP_DIR_GIVEN." >&2
        echo "restore.sh:          the run list will lack its summaries unless the service starts from $root" >&2
        echo "restore.sh:          (normally /opt/field-to-test-loop/current; see DEPLOY.md, Restore)." >&2
    fi
done < <(printf '%s\n' "$check_out" | sed -n 's/^RECORDED_ROOT=//p')
# The read-only check above may leave -wal/-shm files next to the unpacked databases; they must not be copied into
# db/ (an empty or foreign write-ahead log next to the restored file).
rm -f "$SRC"/db/*.sqlite-wal "$SRC"/db/*.sqlite-shm

# ---- 3. keep what is about to be replaced, then put the restored folders in place ----
STAMP=$(date +%Y%m%d-%H%M%S)
KEEPDIR="$APP_DIR/pre-restore-$STAMP"
mkdir -p "$KEEPDIR"
restored=()
for d in db suite config runs; do
    [ -d "$SRC/$d" ] || continue
    if [ -e "$APP_DIR/$d" ]; then
        # the whole folder moves: for db/ this takes knowledge.sqlite together with its -wal/-shm files
        mv "$APP_DIR/$d" "$KEEPDIR/$d"
    fi
    cp -a "$SRC/$d" "$APP_DIR/$d"
    restored+=("$d")
done
shopt -s nullglob
stale=("$APP_DIR"/db/*.sqlite-wal "$APP_DIR"/db/*.sqlite-shm)
shopt -u nullglob
[ ${#stale[@]} -eq 0 ] || die "unexpected SQLite side files in $APP_DIR/db after the restore: ${stale[*]}"
# the site's bench integration
if [ -f "$SRC/app/bench_hook.py" ]; then
    mkdir -p "$APP_DIR/app"
    if [ -e "$APP_DIR/app/bench_hook.py" ]; then
        mkdir -p "$KEEPDIR/app"
        cp -p "$APP_DIR/app/bench_hook.py" "$KEEPDIR/app/bench_hook.py"
    fi
    cp -p "$SRC/app/bench_hook.py" "$APP_DIR/app/bench_hook.py"
    restored+=("app/bench_hook.py")
fi
cp -p "$SRC/MANIFEST.txt" "$KEEPDIR/RESTORED_FROM_MANIFEST.txt"
echo "$ARCHIVE" > "$KEEPDIR/RESTORED_FROM_ARCHIVE.txt"

if [ "$(id -u)" -eq 0 ]; then
    owner=$(stat -c %U:%G "$APP_DIR")
    for d in "${restored[@]}"; do chown -R "$owner" "$APP_DIR/$d"; done
    chown -R "$owner" "$KEEPDIR"
    echo "ownership set to $owner"
fi

echo "restored: ${restored[*]} into $APP_DIR"
echo "the replaced files are kept in: $KEEPDIR (delete it once the restored installation is confirmed)"
port=$("$PY" -I -c 'import json,sys; print((json.load(open(sys.argv[1])).get("server") or {}).get("port") or 8077)' \
       "$APP_DIR/config/app_config.json" 2>/dev/null || echo 8077)
if [ "$LIVE" -eq 1 ]; then
    echo "next: sudo systemctl start $SERVICE   then   curl -fsS http://127.0.0.1:$port/api/config >/dev/null && echo up"
    echo "      and compare the events count of the restarted service (curl -fsS http://127.0.0.1:$port/api/db/summary) with MANIFEST.txt"
elif [ "$SERVICE" = "none" ]; then
    echo "next: start the application from $APP_DIR as you normally do (run_app.py), then compare the event count with MANIFEST.txt"
else
    echo "this is a scratch copy, not the folder the service '$SERVICE' runs from: do NOT start the service for it."
    echo "next (optional, to look at it): start a separate copy on a free port, as the owner of the folder, e.g."
    py=".venv/bin/python"
    [ -x "$APP_DIR/.venv/bin/python" ] || py="/opt/field-to-test-loop/current/.venv/bin/python"   # the service's venv
    echo "      cd $APP_DIR && $py run_app.py --config config/app_config.json --port 8095 --standin"
    echo "      (any free port other than $port; --standin: no model calls. If config/app_config.json has \"bench\": \"hook\","
    echo "      set it to \"synthetic\" first: the copy must not drive the lab bench.)"
    echo "      compare the events count (curl -fsS http://127.0.0.1:8095/api/db/summary) with MANIFEST.txt, stop it, delete the folder."
fi
