# Connecting a real lab bench

This guide is for the lab engineer, or the AI coding agent, who connects a real drive and a real protocol analyzer to
stage 2 of the application. Stage 2 reproduces a defect that stage 1 found in an analyzer trace. Today every lab run
goes to a **simulated drive**. After this work, lab runs go to your bench.

Read it with three files open:

| File | What it is |
|---|---|
| `app/bench_hook.py` | The interface the application calls. Replace it with your implementation. |
| `deploy/bench_hook_template.py` | A complete template of that interface. It is safe by default and has a dry-run mode. Copy it over `app/bench_hook.py` and fill in the parts marked `SITE-SPECIFIC`. |
| `config/app_config.json` | Section `stage2`. The settings `bench` and `search_on` choose where lab runs go. |

Terms used below, spelled out once:
PCIe = Peripheral Component Interconnect Express (the link between host and drive).
NVMe = Non-Volatile Memory Express (the command set of the drive).
DUT = device under test (the drive on the bench).
CSV = comma-separated values (the analyzer export).
LBA = logical block address.
TLP = transaction layer packet.
ASPM = Active State Power Management (link low-power states L1 and L1.2).
APST = Autonomous Power State Transition (the drive drops its own power state when idle).
D3hot = the PCI device power state "D3, power still applied".
PMCSR = Power Management Control/Status Register (in PCI configuration space).
PDU = power distribution unit (a power strip you can switch from a script).
CC.EN = the Enable bit of the NVMe Controller Configuration register. A controller reset clears it and sets it again.
fio = Flexible I/O tester. nvme-cli = the Linux `nvme` command. SPDK = Storage Performance Development Kit.
BDF = bus:device.function, the PCI address of the drive, for example `0000:01:00.0`.

---

## 1. What one lab run must do

A **procedure** (the code calls it a scenario) is a short list of commands plus timing and a power state:

```json
{"commands": [{"op": "write"}, {"op": "aspm_idle"}, {"op": "read"}],
 "timing": {"qd": 8, "inter_cmd_us": 50, "bs_kb": 4, "burst_len": 16, "idle_gap_ms": 100},
 "power_state": "L1.2"}
```

| Field | Allowed values | Source |
|---|---|---|
| `op` | read, write, flush, trim, write_zeroes, reset, power_cycle, aspm_idle, identify, get_log, set_feature, abort | `stage2/oracle.py:22`, `stage2/llm_adapter.py:39` |
| `qd` (queue depth) | 1 to 256 | `stage2/compose.py:17` |
| `inter_cmd_us` (spacing between commands, microseconds) | 1 to 5000 | same |
| `bs_kb` (block size, KiB) | 4 to 1024 | same |
| `burst_len` (commands per burst) | 1 to 128 | same |
| `idle_gap_ms` (pause after a burst, milliseconds) | 0 to 2000 | same |
| `power_state` | none, L1, L1.2, D3hot, APST | `stage2/compose.py:19` |

Procedures reach the bench already checked by `stage2/compose.py:147 clean_scenario` and `stage2/optimizer.py:110
is_safe`. The bench checks them again (section 7).

For every call of `run(procedure)` the bench must do these steps in order:

1. **Put the drive on the requested firmware.** Use the known-bad firmware, or the fixed firmware when the bench object
   was built with `fixed=True` (section 3).
2. **Prepare the power state** (section 5).
3. **Arm the protocol analyzer** on the PCIe link of the DUT (section 6).
4. **Run the procedure** on a scratch namespace. Each command maps to one tool command line (section 4).
5. **Stop the analyzer and export the capture** as the **113-column CSV**. Use the same columns as the stage-1 input,
   with the DATA column in hex. The first header columns are `Marker,Packet,Link Dir,Ord.Set Type,DLLP Type,TLP Type,...`.
   Compare against any trace under `runs/_bench/`.
6. **Run the same stage-1 analyser** on that CSV, with `testgen.run_engine` and then `testgen.findings_of`.
7. **Return the findings as a result record** (section 2). The search, the lab check and the generated regression tests
   all read it.

The application never looks inside the bench. It only reads what `run()` and `detect()` return.

---

## 2. The exact interface

### 2.1 How the application builds the bench

`app/stage2_service.py:101-104`:

```python
def _bench_factory(self):
    sys.path.insert(0, os.path.join(APP, "app"))
    from bench_hook import HardwareBench
    return lambda sig, family, expected, fixed, decoy, seed: HardwareBench(sig, family, expected, fixed, decoy, seed)
```

The factory is used only when `stage2.bench == "hook"` (`app/stage2_service.py:82`). The arguments are
**positional, in this order**. They must match the constructor in `app/bench_hook.py:38`:

```python
class HardwareBench:
    def __init__(self, sig, family=None, expected_cards=None, fixed=False, decoy=None, seed=0, workdir=None):
```

| Argument | Meaning |
|---|---|
| `sig` | The error type (atlas card id, for example `C-16`) that the run should make the analyser isolate. |
| `family` | The failure family of the card (for example `P13`). Information only. |
| `expected_cards` | The set of error types the analyser cannot tell apart from `sig`, called the ambiguity group. It always contains `sig`. It is stored as `self.expected` and **read by the application** (`stage2/stage2_v3.py:371,485,648,679` and `stage2/testgen.py:466`). |
| `fixed` | `False` = known-bad firmware, `True` = fixed firmware. |
| `decoy` | On the simulated bench, a neighbouring card added to fixed-firmware traces as a negative control. A real bench ignores it. |
| `seed` | Random seed of the simulated bench. A real bench ignores it. |
| `workdir` | Not passed by the factory. The default is `<app>/runs/bench_<sig>`. |

Each defect run builds two objects, one for the known-bad firmware and one for the fixed firmware
(`stage2/stage2_v3.py:207-208`):

```python
bench = self.bench_factory(sig, family, expected, False, None, self.opt_seed)
bench_fixed = self.bench_factory(sig, family, expected, True, decoy, self.opt_seed)
```

The factory does **not** receive the firmware names, the device model or the field rule. The bench must get them from
the site configuration. The template reads them from environment variables.

### 2.2 Attributes the application reads

| Attribute | Read by | Purpose |
|---|---|---|
| `expected` (set) | `stage2_v3.py:371,485,648,679`, `testgen.py:466` | Goes into the test manifest as `expected_cards`. |
| `sig` | `testgen.py:466` (fallback) | The card itself. |
| `calls` (int), `seconds` (float) | `stage2_v3.py:636` (`bench.seconds + bench_fixed.seconds`) | Lab time shown on the result. |
| `inject`, `clear_faults` | `stage2_v3.py:419-471` | Optional jammer (section 6.3). Must stay `None` unless they really work. |

### 2.3 `run(scenario)` and the record it returns

The two methods are declared at `app/bench_hook.py:46` (`run`) and `app/bench_hook.py:59` (`detect`). `run` returns a
**dict**, not a path (the docstring of `app/bench_hook.py`, lines 11-19, lists the keys). The application reads these
keys from that record:

| Key | Type | Read by |
|---|---|---|
| `stage` | int, 0 to 4 | `stage2/optimizer.py:115,139,145` (search reward), `stage2/stage2_v3.py:442` (sweep score) |
| `closeness` | float, 0 to 1 | `stage2/optimizer.py:139,146`, `stage2/stage2_v3.py:442` |
| `reproduced` | bool | `stage2/optimizer.py:190,219,223,229,281`, `stage2/stage2_v3.py:218,232,319,441` |
| `cost_s` | float, seconds of this run | `stage2/optimizer.py:143` (`self.spent_s += res["cost_s"]`). **Required.** A missing key stops the search with a KeyError. |
| `isolated` | list of findings | `stage2/testgen.py:469-471` (`verify_closed_loop`: hit and 3-check score) |
| `isolated_top1` | list of findings | `stage2/testgen.py:477` (fixed-firmware check) |
| `trace` | str, path of the exported CSV | `detect()` and the generated pytest (`bench.detect(bench.run(SCENARIO))`, `stage2/testgen.py:324-325,333`) |

`stage`, `closeness`, `reproduced` and `cost_s` are only needed when `search_on = "bench"`. The lab check
(`verify_closed_loop`) needs `isolated` and `isolated_top1` in both modes. Always return all seven keys. Extra keys are
allowed: the template adds `run_id`, `firmware`, `findings`, `run_dir` and `dry_run`.

The simulated reference is `stage2/testgen.py:139-163` (`GeneratorBench.run`).

### 2.4 `detect(trace)` and the findings

`detect` accepts the CSV path **or** the record that `run` returned (`app/bench_hook.py:60-61`). It returns a list:

```python
[{"card_id": "C-16", "verdict": "CONFIRMED" | "SUSPECT", "closeness": 0.41, "pkt": 1234,
  "incident": "INC-0001", "rule": "R-...", "rank": 1}, ...]
```

These come from `testgen.findings_of(incidents)` (`stage2/testgen.py:91-102`). For each incident, the top atlas
candidate gets the engine's verdict (CONFIRMED). The second and third candidates are SUSPECT.

`testgen.run_engine(csv, out_dir, host_evidence=False)` (`stage2/testgen.py:69-88`) runs
`python -m pcie_isolate.cli run --csv ... --backend dry-run --nsze 0x3A386030` in the stage-1 folder and reads
`incidents.json`. Three points matter on hardware:

* **Namespace size.** `--nsze` is fixed to the simulated namespace size (`testgen.py:49`). Pass the size of your scratch
  namespace instead. The template does this with `BENCH_NSZE` through its own copy of the same command line.
* **Host kernel log.** To give the analyser the host kernel log (`dmesg -x`), add `--dmesg <file>` yourself;
  `run_engine` with `host_evidence=False` does not. The template does this with `BENCH_USE_DMESG=1`.
* **Failed analysis.** When the engine fails, `run_engine` returns `{"error": ..., "incidents": []}`. That looks like
  "nothing isolated". On the fixed firmware it would wrongly count as "silent". The template raises an error instead.
  Keep that behaviour.

### 2.5 Deriving `reproduced`, `stage` and `closeness` from the findings

A real bench has no hidden truth. The only truth is what the analyser finds, so use the same rules as
`GeneratorBench.stage_from_findings` (`stage2/testgen.py:184-192`). The template implements them:

| Analyser result on this run's capture | `stage` | `closeness` |
|---|---|---|
| An expected card (the card or its ambiguity group) CONFIRMED | 3 | that finding's `closeness` (engine score, limited to 0 to 1) |
| An expected card CONFIRMED with the field incident's first rule (only when `bench.field_rule` is set) | 4 | same |
| An expected card SUSPECT only | 2 | that finding's `closeness` |
| Only a card of the same family (same letter prefix, for example `C-xx`) | 1 | 0.5 |
| Nothing relevant | 0 | 0.0 |

The other keys follow from that:

* `reproduced = stage >= 3`. This is the expected card CONFIRMED.
* `isolated = [f for f in findings if f.card_id in expected and f.verdict in (CONFIRMED, SUSPECT)]`. This is the
  positive side of the lab check.
* `isolated_top1 = [f for f in findings if f.card_id == sig and f.verdict == CONFIRMED]`. This is the negative side.
  The fixed firmware fails only when the card itself is the primary isolation.

The **3-check score** (`stage2/loop_rules.py:28-59`) is computed by the application from `isolated`. The bench does not
compute it. For each lab run the three checks are:

1. The same error type was isolated.
2. The same first rule fired.
3. The verdict is CONFIRMED.

"Optimal" means all three checks passed in 3 runs in a row.

Note: the simulated bench mixes a dense signal from its hidden model into `stage` and `closeness` when the defect did not
appear (`testgen.py:150-152`). A real bench cannot do that. With `search_on = "bench"` the search therefore gets a coarser
signal (stage 0, 1, 2 or 3 only). This is one reason to start with `search_on = "model"`.

---

## 3. Known-bad bench and fixed bench

* `fixed=False`: every run must happen on the **known-bad** firmware, the firmware the field trace came from.
* `fixed=True`: every run must happen on the **fixed** firmware. The lab check runs the same procedure there and
  requires that the card is **not** isolated as CONFIRMED in any of the `n_fixed` runs (default 3, `stage2_v3.py:633`,
  `testgen.py:477`).

The manifest records the firmware labels as `firmware.known_bad` and `firmware.fixed`. The fixed label is the known-bad
label with `+fix` appended (`stage2_v3.py:648`). The bench does not receive these labels, so map them to real firmware
revisions in your site configuration (`BENCH_FW_KNOWN_BAD`, `BENCH_FW_FIXED`).

How the lab switches firmware is site-specific. The application expects only this: **when `run()` returns, the run
happened on the requested firmware, and the bench verified it.** The template calls `_switch_firmware(fixed)` before
every run. Options, from most to least robust:

1. **Two identical drives**, one per firmware, selected by a slot switch or a separate host. Nothing is flashed.
2. **Both builds pre-loaded in firmware slots.** The lab activates the right slot outside the procedure. Flashing and
   activation (`fw-download`, `fw-commit`) are denied to every procedure. If your process allows the hook itself to
   activate a slot, keep that code inside `_switch_firmware` only, never in the procedure mapping. Add a power cycle
   afterwards, and verify the result.
3. **Always verify:** read `nvme id-ctrl /dev/nvme0 -o json`, field `fr` (firmware revision), and raise when it does not
   match. A run on the wrong firmware silently corrupts the regression verdict.

`bench` and `bench_fixed` are two objects that may share one physical drive. The lab check runs 6 known-bad runs and
then 3 fixed runs, so a single-drive bench switches firmware at least twice per lab check. The template serializes all
hardware access with one lock (`_HW_LOCK`).

---

## 4. Command to tool mapping

This is based on section C of
`Database_Implmentation/claude_research_report/stage2_upgrade_research/research_notes_v3/closed_loop_test_generation.md`.
The template's `build_step()` holds the same mapping and is marked SITE-SPECIFIC. Check the flag names against your
fio and nvme-cli versions.

`$CTRL=/dev/nvme0` (controller), `$NS=/dev/nvme0n2` (scratch namespace), `$NSID=2`, `$BDF=0000:01:00.0`.

| Command | Tool and example | Timing values used |
|---|---|---|
| read | `fio --name=read --filename=$NS --rw=randread --bs=${bs_kb}k --iodepth=${qd} --number_ios=${burst_len} --direct=1 --ioengine=io_uring --thinktime=${inter_cmd_us} --thinktime_blocks=1 --offset=<scratch start> --size=<scratch bytes> --output-format=json` | bs_kb to `--bs`, qd to `--iodepth`, burst_len to `--number_ios`, inter_cmd_us to `--thinktime` |
| write | same with `--rw=randwrite` (add `--verify=crc32c` for data-integrity cards) | same |
| flush | `nvme flush $NS --namespace-id=$NSID` | none |
| trim | `nvme dsm $NS --namespace-id=$NSID --ad --slbs=<slba> --blocks=<nlb>` | bs_kb and burst_len give the block count |
| write_zeroes | `nvme write-zeroes $NS --namespace-id=$NSID --start-block=<slba> --block-count=<nlb-1>` | same |
| reset | `nvme reset $CTRL` (controller reset, CC.EN 1 to 0 to 1). Alternative: function-level reset with `echo 1 > /sys/bus/pci/devices/$BDF/reset`. `nvme subsystem-reset` stays denied. | none |
| power_cycle | `echo 1 > /sys/bus/pci/devices/$BDF/remove`, then the PDU outlet off, wait, PDU outlet on, then `echo 1 > /sys/bus/pci/rescan` until `$CTRL` reappears. Example PDU command: `snmpset -v2c -c private pdu1 <outlet-oid> i 2` (off) and `... i 1` (on). | none (about 30 s or more per cycle) |
| aspm_idle | No traffic for `max(idle_gap_ms, 50 ms)` while ASPM is enabled, so the link can enter L1 or L1.2 | idle_gap_ms |
| identify | `nvme id-ctrl $CTRL --output-format=json` | none |
| get_log | `nvme error-log $CTRL --log-entries=16` (or `nvme get-log $CTRL --log-id=1 --log-len=64`) | none |
| set_feature | `nvme set-feature $CTRL --feature-id=0x02 --value=0` (power state 0, not saved: no `--save`) | none |
| abort | `nvme admin-passthru $CTRL --opcode=0x08 --cdw10=$(( (cid<<16) \| sqid ))`. The template aborts command id 0 on queue 1, which is harmless when nothing is outstanding. | none |

Across the whole procedure:

* `inter_cmd_us` is the pause between procedure commands, and the fio think time inside a burst.
* `idle_gap_ms` is the pause after every read or write burst, and the idle length of `aspm_idle`.
* `qd`, `bs_kb` and `burst_len` shape every fio burst.

A Python `sleep` resolves to about 0.1 ms. If a defect needs microsecond spacing, generate the whole procedure as one
fio job file, or use SPDK (`nvme_fuzz -j cmds.json` for exact opcode lists). Keep the mapping in `build_step()`.

Keep every write, trim and write-zeroes inside the scratch LBA window (`BENCH_LBA_START`, `BENCH_LBA_COUNT`).

---

## 5. Power-state preparation

Apply the power state before the procedure and undo it afterwards (template function `power_prep()`):

| `power_state` | Prepare | Undo |
|---|---|---|
| none | `echo 0 > /sys/bus/pci/devices/$BDF/link/l1_aspm` and the same for `l1_2_aspm` | none |
| L1 | `echo 1 > .../link/l1_aspm` (or the policy: `echo powersave > /sys/module/pcie_aspm/parameters/policy`) | ASPM off |
| L1.2 | `echo 1 > .../link/l1_aspm` and `echo 1 > .../link/l1_2_aspm` (both ends must support L1 substates) | ASPM off |
| D3hot | `setpci -s $BDF CAP_PM+4.w=0003:0003` (PMCSR to D3hot), short wait, then `setpci -s $BDF CAP_PM+4.w=0000:0003` (back to D0) | none |
| APST | `nvme set-feature $CTRL --feature-id=0x0c --value=1 --data=apst.bin --data-len=256` (APST on, with your transition table) | site-specific |

Warnings:

* Writing PMCSR while the Linux nvme driver is active can hang the controller. Quiesce or unbind the driver first, or use
  runtime power management. This is site-specific.
* The kernel parameter `nvme_core.default_ps_max_latency_us` and the platform BIOS can override APST and ASPM. Record the
  real state with `lspci -vv -s $BDF` (LnkCtl line) in the run folder.

---

## 6. Analyzer capture and the optional jammer

### 6.1 The contract (`_start_capture` and `_stop_and_export_capture`)

* **Trigger:** the start of the stimulus. Use either a packet-pattern trigger on the first command (for example the
  first memory write to the submission-queue doorbell), or an external trigger input that the runner pulses just before
  step 0.
* **Pre-trigger:** about 30 %, so the preparation phase is inside the window.
* **Window:** the stimulus plus 2 s. This is the manifest's `capture` field, `stage2/testgen.py:257`.
* **Export:** the 113-column CSV with hex DATA, the same layout as the stage-1 input. Check the column count and raise on
  an empty or truncated export.
* **Abort safety:** if a run fails half way, still stop the analyzer. The template does this in a `finally` block.

### 6.2 Example for an analyzer driven from the command line (placeholder)

Replace these with your vendor's tool. The names below are placeholders, not a real product.

```python
def _start_capture(self, run_id, rdir):
    subprocess.run(["analyzer-cli", "--host", "lab-analyzer-1", "load-setup", "/etc/pcie-bench/x4_gen4.setup"], check=True, timeout=60)
    subprocess.run(["analyzer-cli", "--host", "lab-analyzer-1", "arm", "--trigger", "ext-in", "--pretrigger", "30",
                    "--buffer-ms", "5000", "--tag", run_id], check=True, timeout=60)
    return run_id

def _stop_and_export_capture(self, handle, out_csv):
    subprocess.run(["analyzer-cli", "--host", "lab-analyzer-1", "stop", "--tag", handle], check=True, timeout=120)
    subprocess.run(["analyzer-cli", "--host", "lab-analyzer-1", "export", "--tag", handle, "--format", "csv",
                    "--columns", "/etc/pcie-bench/113_columns.txt", "--data", "hex", "--out", out_csv], check=True, timeout=600)
    with open(out_csv) as f:
        if len(f.readline().split(",")) != 113:
            raise RuntimeError("analyzer export does not have 113 columns")
    return out_csv
```

### 6.3 Optional jammer (`inject`, `clear_faults`)

A jammer is a protocol fault injector on the link. If your bench has one, implement `_site_inject(spec)` and
`_site_clear_faults()`, then set the class attributes `inject = _site_inject` and `clear_faults = _site_clear_faults`.
The specs come from `stage2/stage2_v3.py:421`:

* `{"kind": "tlp_corrupt", "rate": 1e-4}`
* `{"kind": "delay_completion", "us": 500}`
* `{"kind": "force_recovery", "every_ms": 50}`

Leave both attributes `None` when the bench has no jammer. The sweep then reports the jammer variants as needing a
hardware bench (`stage2_v3.py:425`). Do **not** set them to methods that raise. The sweep catches only the first
`inject` call (`stage2_v3.py:432-436`). The second call, just before the lab check, is not protected
(`stage2_v3.py:469`). `clear_faults()` must disarm everything and must be safe to call when nothing is armed.

---

## 7. Safety

These rules are not optional. The template enforces each one.

1. **Scratch namespace only.** Use a namespace created for the bench that holds no data, never the namespace with the
   operating system or user data. The template refuses to run when the namespace, or a partition of it, is mounted.
2. **Never run on a drive holding data.** Use a bench drive. Treat its contents as destroyed by any write procedure.
3. **Deny list.** No procedure may run format, sanitize, firmware download, firmware commit or activation, namespace
   create, delete, attach or detach, security send, or subsystem reset. The application uses two spellings:
   `optimizer.DENY_OPS = {"format","sanitize","fw_download","fw_commit","ns_delete"}` (`stage2/optimizer.py:21`) and the
   manifest's `["format","sanitize","fw-download","fw-commit","delete-ns"]` (`stage2/testgen.py:269`). The template
   normalizes both to lower case with `_` and refuses either. It also accepts **only** the 12 allowed commands; anything
   else is refused. After building the plan it checks every command line again for denied nvme-cli sub-commands.
   A refusal raises `BenchRefused` before anything is sent to the drive.
4. **Device model precondition.** A generated test belongs to one drive model. When the manifest has
   `preconditions.device_model` (`stage2/testgen.py:236`), the bench must refuse to run on another model. The template
   compares it with `nvme id-ctrl` field `mn`. Set it with `BENCH_DEVICE_MODEL`, or through
   `HardwareBench.for_manifest(manifest)` in a test.
5. **Timeouts.** Every command line has a timeout (`BENCH_STEP_TIMEOUT_S`, default 60 s). The whole run has one too
   (`BENCH_RUN_TIMEOUT_S`, default 300 s), and so does the analysis (`BENCH_ANALYSE_TIMEOUT_S`, default 600 s).
6. **Dry run.** With `DRY_RUN=1` nothing touches hardware. The plan is printed to standard error and saved as
   `plan.json` in the run folder. The result is a well-formed "nothing reproduced" record. Add
   `BENCH_REPLAY_CSV=<capture.csv>` (and `BENCH_REPLAY_CSV_FIXED` for the fixed bench) to run the real analyser on an
   existing capture instead.
7. **Commands never go through a shell.** The only exceptions are the `echo > /sys/...` lines, whose paths and values
   are quoted. The PDU commands come from your configuration, not from the procedure.
8. **Audit trail.** Every executed command line, its exit code and the last 2,000 characters of its output are appended
   to `host_events.jsonl` in the run folder.
9. **Least access.** The service gets only the device and kernel access the bench needs, and only on a bench host
   (section 11).

---

## 8. Bring-up, step by step

### Step 1: implement with dry-run on

```bash
cp app/bench_hook.py app/bench_hook.py.orig
cp deploy/bench_hook_template.py app/bench_hook.py
export DRY_RUN=1 BENCH_CTRL=/dev/nvme0 BENCH_NS=/dev/nvme0n2 BENCH_NSID=2 BENCH_BDF=0000:01:00.0 \
       BENCH_LBA_START=0 BENCH_LBA_COUNT=2097152 BENCH_DEVICE_MODEL="<model from nvme id-ctrl mn>" \
       BENCH_FW_KNOWN_BAD="<fr of known-bad>" BENCH_FW_FIXED="<fr of fixed>" BENCH_NSZE=0x<blocks of the scratch namespace>
python3 app/bench_hook.py --card C-16 --scenario '{"commands":[{"op":"write"},{"op":"reset"},{"op":"read"}],
  "timing":{"qd":8,"inter_cmd_us":50,"bs_kb":4,"burst_len":16,"idle_gap_ms":0},"power_state":"none"}'
```

Read the printed plan line by line. Edit `build_step()` and `power_prep()` until every line is what you would type by
hand. Then implement `_switch_firmware`, `_start_capture` and `_stop_and_export_capture`.

### Step 2: unit-test the hook with a fake device

Subclass the bench and replace everything that touches hardware. This exercises the real (non-dry-run) code path:

```python
class FakeDeviceBench(HardwareBench):
    def _preflight(self): pass
    def _switch_firmware(self, fixed): self.fw = fixed
    def _exec(self, argv, rdir, tag, timeout=None): print("would run", argv)
    def _power_cycle(self, rdir): print("would power-cycle")
    def _start_capture(self, run_id, rdir): return run_id
    def _stop_and_export_capture(self, handle, out_csv):
        return KNOWN_BAD_CSV if not self.fixed else HEALTHY_CSV   # e.g. runs/_bench/bench_C-16/trace_C-16_4.csv / trace_healthy_1.csv
```

Check four things:

* The known-bad record has `reproduced=True`, `stage=3` and a non-empty `isolated`.
* The fixed record has `reproduced=False` and an empty `isolated_top1`.
* A procedure containing `format` raises `BenchRefused`.
* `testgen.verify_closed_loop(bench, bench_fixed, scenario, n_bad=2, n_fixed=1)["passed"]` is `True`.

### Step 3: run one procedure by hand on the real drive

Unset `DRY_RUN`. Run the same command as in step 1, first with a harmless procedure (identify, get_log), then with a
read and write procedure. Run it as the user the service runs as; when the application runs as the systemd service,
first give the service the access listed in section 11, or every nvme-cli, setpci and sysfs line fails. Check four things:

* The run folder `runs/bench_<card>/run_*/` has `plan.json`, `host_events.jsonl` and `capture.csv`.
* The CSV has 113 columns.
* `python3 app/bench_hook.py --card C-16 --scenario '{}' --detect runs/bench_C-16/run_.../capture.csv` prints findings.
* The analyzer capture shows the commands you sent.

### Step 4: `bench = "hook"`, `search_on = "model"`

In `config/app_config.json`:

```json
"stage2": {"bench": "hook", "search_on": "model", ...}
```

Restart the application. `bench` is read only at start-up (`app/stage2_service.py:82`); `search_on` is reloaded live
(`app/stage2_service.py:99`). The same holds when you change **Bench** on the Settings page: the value is saved, and the
page shows a notice that the change takes effect after a restart of the application. Until the restart, lab runs still
go where they went before. The search now runs on the fast device model. Only the lab check runs on your bench:
6 known-bad and 3 fixed runs (`n_bad`, `n_fixed`), plus 6 and 3 more when a most-stressful procedure is filed.

### Step 5: only then `search_on = "bench"`

Every search trial is now a real lab run, up to `opt_budget` (300). This includes the regression guard (6 runs), the
confirmation runs (8), shortening and the most-stressful step (`stress_trials`, 30). A real run takes tens of seconds,
so raise `time_budget_s` (default 600 s, the 10-minute first-level triage limit) or lower `opt_budget`. Otherwise
most searches end with "triage time-out".

### Step 6: acceptance criteria

The bench is accepted when all of these hold:

1. **A known defect reproduces.** Take a defect with a saved procedure, for example from `suite/`. On known-bad firmware
   the lab check gives `known_bad_hits >= 1` of 6, and `optimal` (all 3 checks in 3 runs in a row) at least once.
2. **The fixed firmware stays silent.** Same procedure: `fixed_hits == 0` of 3.
3. **A generated test runs with pytest against the hook.** The generated `suite/<test>/conftest.py` builds the simulated
   bench (`stage2/testgen.py:341-384`). For the lab, replace its two fixtures:

   ```python
   sys.path.insert(0, os.path.join(<app>, "app"))
   from bench_hook import HardwareBench

   @pytest.fixture(scope="module")
   def bench():
       return HardwareBench.for_manifest(MANIFEST, fixed=False)

   @pytest.fixture(scope="module")
   def bench_fixed():
       return HardwareBench.for_manifest(MANIFEST, fixed=True)
   ```

   Then run `python3 -m pytest -q suite/<test>`. Both tests must pass. Note that the application writes `conftest.py`
   again every time it files a test.
4. **A denied command is refused**, and **a wrong device model is refused**.
5. **Dry run touches nothing.** With `DRY_RUN=1` a full lab check runs without any command line reaching the drive.

---

## 9. Troubleshooting

| Symptom | Likely cause | What to do |
|---|---|---|
| `KeyError: 'cost_s'` in the search | `run()` returns no `cost_s` | Return the run's wall-clock seconds (the template does). |
| `KeyError: 'isolated'` in the lab check | `run()` returns only a path | `run()` must return the record dict, not the CSV path. |
| Fixed firmware "passes" but nothing was really analysed | The analyser failed and `run_engine` returned an empty list | Raise on `out["error"]` (the template does). Check the `det_*` folder. |
| Every run is stage 0 | Wrong `--nsze`; capture window misses the stimulus; export lacks hex DATA; wrong link captured | Set `BENCH_NSZE`, check trigger and pre-trigger, compare the CSV header with `runs/_bench/*/trace_*.csv`. |
| Stage 1 only (same family, wrong card) | The procedure triggers a neighbouring defect | This is normal during the search. In the lab check it counts as no hit. |
| Known-bad reproduces once, then never | Drive state (fill level, temperature, APST table) changes between runs | Add a reset or idle settling step in `_switch_firmware`; log `nvme smart-log` per run. |
| Drive disappears after `power_cycle` | Rescan too early, or a hot-plug slot needs `/sys/bus/pci/slots/<n>/power` | Raise `BENCH_ENUM_TIMEOUT_S`; use the slot power file instead of remove and rescan. |
| `BenchRefused: ... is mounted` | The scratch namespace has a file system mounted | Unmount it. Never point `BENCH_NS` at a data namespace. |
| Sweep crashes in jammer variants | `inject` is set but raises | Leave `inject` and `clear_faults` as `None` until the jammer works. |
| Searches end in "triage time-out" with `search_on = "bench"` | Real runs are slow compared with the 600 s budget | Go back to `search_on = "model"`, or raise `time_budget_s`. |

---

## 10. Known gaps between the existing hook and the code

Fixed: the `app/bench_hook.py` docstring used to say that `run()` returns a CSV path and left `cost_s` out of the keys.
It now says `run()` returns a dict and lists all seven keys, `cost_s` included, as does `README.md`. Still true:

* The `NotImplementedError` message in the placeholder `run` (`app/bench_hook.py:47-49`) still says "return the CSV
  path" and its example dict leaves out `cost_s`. Follow the docstring and section 2.3, not that message.
* The ambiguity group (`expected_cards`) is always measured on the **simulated** bench (`stage2_v3.py:561-574`, which
  uses `GeneratorBench.detectability`), even when `bench = "hook"`.
* A jammer variant's fault spec is stored in the saved procedure (`preconditions.jammer`, `stage2_v3.py:458`) but not in
  the generated test's manifest. A generated jammer test does not arm the jammer by itself. Arm it in the conftest if
  you need it.
* `run_engine` always passes the simulated namespace size (`testgen.py:49,76`). A real bench must pass its own.

---

## 11. Access the service needs on a hardware bench

The shipped unit `deploy/field-to-test-loop.service` is hardened for the default synthetic bench. It runs as the user
`ftl` with **no capabilities** (`CapabilityBoundingSet=` empty, so no `CAP_SYS_ADMIN`), with `NoNewPrivileges=yes` (no
`sudo`), with `ProtectKernelTunables=yes` (`/sys` is **read-only**) and with `ProtectKernelLogs=yes` (no kernel log).
It does not set `PrivateDevices`, but it grants no access to `/dev/nvme*` either: the files keep their normal owners
(the controller `/dev/nvme0` is usually `root` only, the namespace `/dev/nvme0n2` `root:disk`). Under that unit, nvme-cli
admin commands, `setpci` and PCI remove and rescan **fail**. `host_events.jsonl` then shows "Permission denied" or
"Operation not permitted", and the run ends with an error.

What each bench operation needs:

| Bench operation (template code) | Needs | Blocked in the default unit by |
|---|---|---|
| `read`, `write` (fio on the scratch namespace `$NS`, for example `/dev/nvme0n2`) | Read and write access to that one block device. Prefer a udev rule that gives `ftl` only that namespace over adding `ftl` to the `disk` group (which opens every disk). | file permissions |
| `flush`, `trim`, `write_zeroes` (nvme-cli on `$NS`) | Write access to `$NS`. These are pass-through commands: older kernels require `CAP_SYS_ADMIN` for them; newer kernels allow I/O commands to a user who opened the device for writing. | file permissions; missing `CAP_SYS_ADMIN` on older kernels |
| `identify`, `get_log`, `set_feature`, `abort`, `reset`, the device-model check and the firmware check (nvme-cli on the controller `$CTRL`, for example `/dev/nvme0`) | Access to the controller character device and `CAP_SYS_ADMIN` (admin commands and the controller reset ioctl). | file permissions, empty capability set |
| `D3hot` power state (`setpci -s $BDF CAP_PM+4.w=...`) | A writable `/sys/bus/pci/devices/$BDF/config` and `CAP_SYS_ADMIN` (writing PCI configuration space, and reading the capability list past the first 64 bytes). | `ProtectKernelTunables=yes`, empty capability set |
| `none`, `L1`, `L1.2` power states (ASPM files `/sys/bus/pci/devices/$BDF/link/l1_aspm`, `l1_2_aspm`) | A writable `/sys` and the right to write root-owned files (run as `root`, or `CAP_DAC_OVERRIDE`). | `ProtectKernelTunables=yes`, user `ftl` |
| `power_cycle`, step 1 and 3 (`/sys/bus/pci/devices/$BDF/remove`, `/sys/bus/pci/rescan`), and the function-level reset file | Same as the ASPM files. | `ProtectKernelTunables=yes`, user `ftl` |
| `power_cycle`, step 2 (PDU outlet off and on, `BENCH_PDU_OFF` / `BENCH_PDU_ON`) | No device access. The PDU tool (for example `snmpset`) installed, the network path to the PDU, and its credentials in the environment file. IPv4 and IPv6 are allowed by the unit. | nothing, if the tool is installed |
| Analyzer capture (`_start_capture`, `_stop_and_export_capture`, your vendor's command-line tool) | Network access to the analyzer (allowed), or the analyzer's USB device under `/dev/bus/usb/` (udev rule for `ftl`). Any folder the vendor tool writes, such as a license or cache folder, must be in `ReadWritePaths` (`ProtectSystem=strict` makes the rest read-only, `ProtectHome=yes` hides `/home`). Another socket type, such as netlink, must be added to `RestrictAddressFamilies`. | depends on the tool |
| Host kernel log (`BENCH_USE_DMESG=1`, `dmesg -x`) | Access to the kernel log (`CAP_SYSLOG` when `kernel.dmesg_restrict=1`). | `ProtectKernelLogs=yes` |
| `lspci -vv -s $BDF` record (section 5) | The full output needs `CAP_SYS_ADMIN`; without it the capability lines are missing. | empty capability set |

How to grant it: **`deploy/DEPLOY.md`, section "Running with a hardware bench"**, gives a systemd drop-in override
(`/etc/systemd/system/field-to-test-loop.service.d/bench.conf`) for exactly these settings. Do not edit the shipped unit itself, and do not add
the drop-in on a host that uses the synthetic bench.

**Warning.** The drop-in widens the service's privileges a lot. `CAP_SYS_ADMIN` plus a writable `/sys` is close to
full control of the machine, and the application has no login of its own: anyone who can reach it can start lab runs.
So:

* Use it only on a dedicated bench host, behind the authenticating reverse proxy, with `server.host` `127.0.0.1` and
  `server.lock_endpoint` `true` (`deploy/DEPLOY.md`).
* The drive under test **must be a scratch drive**: no operating system, no user data, nothing anyone needs. Every write
  procedure destroys what is in the scratch namespace, and a power cycle or a wrong power-state write can lose the
  whole drive. The checks in section 7 (scratch namespace, not mounted, the expected model) stay on.
* Grant access to the one drive under test (its controller, its scratch namespace and its PCI address), not to every
  NVMe device on the host.
