#!/usr/bin/env python3
"""Builds the deployable archive field_to_test_loop_code_only.zip (and its .SHA256.txt) from this project.

    python3 deploy/build_code_zip.py [--out DIR]

The archive unzips to 13_production_app/ and holds the application, the analyser, the knowledge-base engine, the
tests, the install and operations documents (deploy/), the two HTML guides and the data files the analyser needs.
It leaves out the local databases (db/), earlier runs (runs/), samples, virtual environments and caches, so one
archive is the same for every machine.  Run it after the tests pass:

    ./run_tests.sh && python3 deploy/build_code_zip.py
"""
import argparse
import hashlib
import os
import sys
import time
import zipfile

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NAME = "field_to_test_loop_code_only"
ROOT_IN_ZIP = "13_production_app"

# directories copied whole (minus the excluded names) and single files
DIRS = ["app", "config", "data/generator", "deploy", "docs/guide_images", "docs/ui_map_images", "docs/ui_map_src",
        "stage1/pcie_isolate", "stage1/reference", "stage1/runs", "stage1/tests", "stage1/tools", "stage1/vendor",
        "stage2", "tests"]
FILES = ["README.md", "README_CODE_ONLY.md", "README_FIRST.md", "run_app.py", "run_tests.sh",
         "data/DEFECT_DETECTION_SPEC_485.jsonl", "data/atlas_cards_raw.json", "data/final_113_columns.csv",
         "docs/APPLICATION_MAP.html", "docs/OPERATOR_AND_BACKEND_GUIDE.html", "docs/FAQ.html", "docs/CHANGES_2026-10-27.md",
         "docs/PROVENANCE_AUDIT.md", "docs/VERIFICATION_FROM_SCRATCH.md", "docs/build_ui_map.py", "docs/shoot_ui_map.py",
         "stage1/README.md", "stage1/requirements.txt", "stage1/selfcheck.py"]
EXCLUDE_DIRS = {"__pycache__", ".pytest_cache", ".venv", "node_modules"}
EXCLUDE_SUFFIX = (".pyc", ".pyo", ".log", ".tmp")


def walk(rel):
    base = os.path.join(APP, rel)
    for root, dirs, files in os.walk(base):
        dirs[:] = sorted(d for d in dirs if d not in EXCLUDE_DIRS)
        for f in sorted(files):
            if f.endswith(EXCLUDE_SUFFIX):
                continue
            p = os.path.join(root, f)
            yield p, os.path.relpath(p, APP)


def build(out_dir):
    zpath = os.path.join(out_dir, NAME + ".zip")
    n = size = 0
    missing = []
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for rel in FILES:
            p = os.path.join(APP, rel)
            if not os.path.isfile(p):
                missing.append(rel)
                continue
            z.write(p, ROOT_IN_ZIP + "/" + rel)
            n += 1
            size += os.path.getsize(p)
        for d in DIRS:
            if not os.path.isdir(os.path.join(APP, d)):
                missing.append(d + "/")
                continue
            for p, rel in walk(d):
                z.write(p, ROOT_IN_ZIP + "/" + rel)
                n += 1
                size += os.path.getsize(p)
    h = hashlib.sha256()
    with open(zpath, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    with open(os.path.join(out_dir, NAME + ".SHA256.txt"), "w") as f:
        f.write("%s  %s\n" % (h.hexdigest(), NAME + ".zip"))
    print("wrote %s: %d files, %.1f MB uncompressed, %.1f MB zipped, sha256 %s" %
          (zpath, n, size / 1048576, os.path.getsize(zpath) / 1048576, h.hexdigest()[:16]))
    if missing:
        print("WARNING: not found and left out: " + ", ".join(missing))
    return zpath


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.dirname(APP), help="folder for the zip (default: the folder above the app)")
    a = ap.parse_args()
    t0 = time.time()
    build(a.out)
    print("built in %.0f s" % (time.time() - t0))
    sys.exit(0)
