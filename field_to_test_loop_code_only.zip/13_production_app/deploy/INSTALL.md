# Installing the Field-to-Test Loop

For an engineer or an AI coding agent who has received the code-only archive (`field_to_test_loop_code_only.zip`, or
its e-mail variant `field_to_test_loop_code_only_MAIL_SAFE.zip`) and must install it on a fresh Linux server.

Every command below was run, in this order, on a clean unpacked copy of the archive (see "How these instructions were
checked" at the end). Run them from the folder named in each step.

Other documents in this folder:

| Document | Read it for |
|---|---|
| `deploy/AGENT_INSTRUCTIONS.md` | the master runbook: the whole installation and go-live in order |
| `deploy/DEPLOY.md` | running the app as a permanent service, the reverse proxy with sign-in, backups |
| `deploy/BENCH_INTEGRATION.md` | connecting a real lab bench (the device under test) instead of the simulated one |
| `docs/OPERATOR_AND_BACKEND_GUIDE.html` | how to use every screen (included in this archive; open it in a browser) |
| `deploy/OPERATIONS.md` | day-to-day running: start, stop, logs, backups, restore test, upgrades, key rotation |

## 1. What you need

- **Operating system:** 64-bit Linux (tested on Ubuntu with kernel 6.17, x86-64).
- **Python:** 3.10 or newer is recommended (3.9 is the hard minimum; tested with 3.12.7 and 3.13.7). You also need
  the `venv` module. On Debian or Ubuntu the system Python often lacks it; the error says "ensurepip is not
  available". Fix it with `sudo apt install python3-venv` (or `python3.13-venv` for that exact version).
- **Disk:** about 25 MB for the program, about 150 MB for the virtual environment, and space for your work. Each
  analysed trace writes a run folder (about 0.1 MB for a 20 MB trace plus the trace itself if you keep it there).
  The simulated lab bench and the tests write trace files under `runs/_bench/` inside the application folder (about
  166 MB after one test run; it may be deleted when no server runs from the folder).
  Keep at least 5 GB free; `deploy/preflight.py` warns below that.
- **Network:** access to the Python package index (or a folder of downloaded packages, see 3b), and, while the app
  runs, access to the AI model endpoint you configure (the Anthropic application programming interface (API), a
  company gateway, or an OpenAI-compatible endpoint). The tests and the stand-in mode need no network.
- **Google Chrome or Chromium:** only for the optional browser smoke test (`tests/ui_smoke.py`). The app itself is
  used from any browser.

## 2. Unpack

Normal archive:

```
mkdir -p /opt/f2t && cd /opt/f2t
unzip field_to_test_loop_code_only.zip
cd 13_production_app
```

E-mail variant (`*_MAIL_SAFE.zip`): mail providers block archives that contain JavaScript, so the 10 browser
scripts in `app/static/js/` are stored as `name.js.txt`. Rename them back once, right after unpacking:

```
unzip field_to_test_loop_code_only_MAIL_SAFE.zip
cd 13_production_app
python3 restore_names.py          # prints "restored 10 JavaScript file(s)" and deletes itself
```

Without this step the web page stays blank. The pre-flight check reports it as a FAIL ("files still named .js.txt").

The `deploy/` folder (this file, `requirements.txt`, `preflight.py` and the other deployment documents) must sit
inside `13_production_app/`. If it came separately, copy it there.

The archive does not contain `db/`, `runs/`, `suite/` or `samples/`. The app creates them, empty, on first start.

## 3. Create a virtual environment and install the packages

A virtual environment is a private copy of Python for this app, so its packages do not mix with the system's.

```
cd /opt/f2t/13_production_app
python3 -m venv .venv
. .venv/bin/activate              # every later command in this guide assumes this is active
python3 -m pip install -r deploy/requirements.txt
```

`deploy/requirements.txt` lists:

| Package | Needed for |
|---|---|
| `flask` (3.0.3 or newer) | required: the web server and API |
| `numpy` (2.0.2 or newer) | required: the stage-1 defect analyser |
| `anthropic` (1.8.0 or newer) | required when `llm.backend` is `sdk`; optional otherwise (see the note below) |
| `pytest`, `websocket-client` | optional: tests only |

Note on `anthropic` (the Anthropic software development kit, SDK): both stages import the installed package first
and fall back to the copy shipped in `stage1/vendor/` (`stage2/llm_adapter.py`). That copy imports only where its
compiled dependency matches: it was built for CPython 3.13 on x86-64 Linux. With `llm.backend` set to `sdk`, the
package missing and any other Python, stage 2 quietly falls back to the stand-in (no model). Install it from
`deploy/requirements.txt` whenever you use `sdk`. Which backends give stage 1 a model at all: only `auto`, `sdk` and
`cli`; with `standin`, `ollama` and `openai-compat` stage 1 runs its review without a model
(`app/stage1_runner.py`).

### 3b. Installing without internet on the server

On a machine with internet and the **same Python version and processor type** as the server:

```
python3 -m pip download -r deploy/requirements.txt -d wheels
```

Copy the `wheels/` folder to the server, then, inside the virtual environment:

```
python3 -m pip install --no-index --find-links wheels -r deploy/requirements.txt
```

## 4. Run the pre-flight check

```
python3 deploy/preflight.py
```

It prints one line per check and ends with a count. `PASS` means fine, `WARN` means it works but read the note,
and `FAIL` means fix it before going live. The exit code is 1 when any line is FAIL. It changes nothing in the
installation and never prints a key. It checks:
- the Python version and the packages;
- the shipped data files: the signature library, the rule definitions, the 113-column header and the atlas cards;
- the browser scripts;
- that the configuration parses;
- that the allowed trace folders exist;
- that `db/`, `runs/`, `suite/` and `samples/` are writable, and the free disk space;
- that the port is free and the address is local;
- that the AI model backend is set up: the `claude` command for `cli`; the key variable and address for `sdk` and
  `openai-compat`;
- the lab bench setting.

Options:

```
python3 deploy/preflight.py --config config/app_config.json   # another configuration file
python3 deploy/preflight.py --port 8091                       # check the port you will start on
python3 deploy/preflight.py --check-llm                       # also make ONE tiny real call to the model and time it
```

On the shipped configuration (`llm.backend: "cli"`, `stage2.bench: "synthetic"`, `server.lock_endpoint: false`),
with port 8077 free and `claude` installed, the last line is:

```
25 PASS, 2 WARN, 0 FAIL  ->  ready to start (read every WARN line)
```

The two WARN lines:
- `WARN  server.lock_endpoint  -  off: anyone who reaches the Settings page can point llm.base_url at another server
  and receive the API key; set it to true for production (deploy/config.production.example.json)`. For production,
  start from `deploy/config.production.example.json`, which sets `server.lock_endpoint: true` (the line then reads
  PASS). With the lock on, the Settings page refuses changes to `llm.backend`, `llm.base_url`, `llm.api_key_env`,
  `llm.tools` and `paths.allowed_csv_roots` (HTTP 403); they are changed in the file, followed by a restart.
- `WARN  bench synthetic  -  lab runs are simulated ...`: expected until a real bench is connected
  (`deploy/BENCH_INTEGRATION.md`).

Other results you may see:
- `FAIL backend cli` if the Claude Code command-line tool (`claude`) is not installed and logged in for this user.
  Either install it, or set `llm.backend` to `sdk` (Anthropic API key in the variable named by `llm.api_key_env`) or
  to `openai-compat`. For the tests and the first-run check below you can use the stand-in, which needs no model.
- A WARN on the port if something already listens on 8077; check the port you will use with `--port`.
- Run as the service user of a production installation, the key check FAILs unless the service's environment file
  is loaded; `deploy/OPERATIONS.md` section 5 gives the command.

## 5. Run the functional tests

The tests always use the stand-in model and the simulated bench: no model calls, no network, about 90–110 seconds.
They use their own temporary database and test folders, but the simulated bench writes about 166 MB of trace files
into `runs/_bench/` of the application folder; delete that folder afterwards if you need the space
(`rm -rf runs/_bench`, with no server running from the folder).

```
./run_tests.sh
```

Expected end of the output:

```
test_pipeline (__main__.AppTest.test_pipeline) ... ok
test_stage1_engine_fixtures (__main__.ComponentTests.test_stage1_engine_fixtures) ... skipped 'stage-1 fixture traces are not shipped in the code-only package'
test_stage2_unit_tests (__main__.ComponentTests.test_stage2_unit_tests) ... ok
test_pipeline (__main__.WorkloadArtifactTest.test_pipeline) ... ok
Ran 4 tests in 93.488s
OK (skipped=1)
```

The one skip is expected. The stage-1 fixture traces (sample analyser exports that check the analyser rule by rule)
are part of the full package, not the code-only one.

You can run the same tests through pytest (a Python test runner):

```
python3 -m pytest tests/test_app.py -q          # 3 passed, 1 skipped
```

The stage-2 unit tests (the knowledge base, retrieval and search) can also be run on their own:

```
cd stage2 && python3 tests_v3.py && python3 tests_v4.py && cd ..     # "Ran 16 tests ... OK", "Ran 8 tests ... OK"
```

## 6. First start

```
python3 run_app.py                    # uses config/app_config.json: http://127.0.0.1:8077
python3 run_app.py --port 8091        # another port
python3 run_app.py --standin          # no AI model: deterministic stand-in (demo, first-run check)
```

The commands below use the shell variable `PORT`; it defaults to 8077 (the shipped `server.port`). If you started on
another port, set it first in every shell, for example `export PORT=8091`.

It prints `Field-to-Test Loop  ->  http://127.0.0.1:8077   (local only; Ctrl-C to stop)`. Flask also prints a
"development server" warning; for a permanent installation follow `deploy/DEPLOY.md`. The app listens on this
machine only (`server.host` 127.0.0.1) and has no sign-in. Do not change `server.host` to reach it from other
machines; put an authenticating reverse proxy in front instead (`deploy/DEPLOY.md`).

Check that it answers. On a new installation the list of runs is empty:

```
curl http://127.0.0.1:${PORT:-8077}/api/runs             # []
```

Open `http://127.0.0.1:8077/` (or your port) in a browser (on a remote server, use a secure shell (SSH) tunnel:
`ssh -L ${PORT:-8077}:127.0.0.1:${PORT:-8077} user@server`). The first screen is step 1, **"Choose the trace"**. It has a field for
the analyser CSV path, plus fields for your name, the device, the namespace size, the firmware label and a run
label. The knowledge base is empty: no runs, no stored procedures, no tests. The database page is at `/db`.

Stop the app with Ctrl-C. If you started it in the background, stop only that process by its process number (PID):
find it with `ps -eo pid,args | grep "run_app.py"` and run `kill <PID>`.

**Caution with `--standin`:** the stand-in choice is kept in memory. If you then save anything on the Settings
screen, the app writes the whole configuration back to `config/app_config.json`, including `"backend": "standin"`.
Check `llm.backend` in the file after a stand-in session.

## 7. Five-minute first-run check with a synthetic sample

This checks the whole chain (trace, then analyser, then defects, then stage 2) without a real capture. Start the app
with `python3 run_app.py --standin` (or with your configured model; then the AI reviewer step also runs and costs a
few model calls).

1. Make a synthetic trace with two known defects (atlas cards T-42 and L-21), about 2 seconds:

   ```
   curl -s -X POST -H 'Content-Type: application/json' \
        -d '{"cards":"T-42,L-21","seed":5}' http://127.0.0.1:${PORT:-8077}/api/samples/generate
   ```

   Answer:

   ```
   {"cards":["T-42","L-21"],"csv_path":"/opt/f2t/13_production_app/samples/sample_T-42_L-21_seed5.csv",
    "host_evidence":{},"nsze":"0x3A386030","rows":36575}
   ```

   The file (about 20 MB) is in `samples/`. It needs no configuration beyond the shipped `data/generator/` and
   `data/atlas_cards_raw.json`. `host_evidence` is empty in the code-only package: the host-log simulator
   (`stage1/tools/`) is not shipped. This is expected. Because of that, and because the analyser judges the packets
   rather than the plan, a sample may show error types that were not planted and miss planted ones (for example
   `{"cards":"T-42,L-21,C-16","seed":11}` gives T-42, M-020 and C-16). The sample of this section was checked.
2. In the browser, step 1:
   - paste the `csv_path` into "Analyzer CSV path";
   - type your name;
   - enter `0x3A386030` as the namespace size;
   - press **Analyse the trace (stage 1)**.

   The analysis takes about 6 seconds with the stand-in. `samples/` is inside the application folder, which is
   always allowed. Your own traces must be under one of `paths.allowed_csv_roots`.
3. Expect one defect, `INC-0001`, error type T-42, status **Confirmed**. The device is "Synthetic NVMe SSD 1TB",
   read from the trace. L-21 is not reported, because it needs the host log this package does not simulate.
   Continue to stage 2 to see the proposal and the decision options. `docs/OPERATOR_AND_BACKEND_GUIDE.html`
   explains each screen. On a fresh installation with the stand-in there may be no procedure card to press
   **Correct** on yet; the complete loop through a decision (stage 2, the lab check on known-bad and fixed
   firmware, the regression test in `suite/`, the report) is a copy-paste API walk-through in
   `deploy/AGENT_INSTRUCTIONS.md` step 2.6 A (verified on a fresh copy of this archive).

The same check without a browser (this is what was verified):

```
curl -s -X POST -H 'Content-Type: application/json' \
     -d '{"csv_path":"/opt/f2t/13_production_app/samples/sample_T-42_L-21_seed5.csv","nsze":"0x3A386030","label":"first-run check","operator":"installer"}' \
     http://127.0.0.1:${PORT:-8077}/api/runs                  # {"job":"stage1-...","reused":false,"run_id":"run-..."}
curl -s http://127.0.0.1:${PORT:-8077}/api/jobs/<job>         # wait until "status": "done"
curl -s http://127.0.0.1:${PORT:-8077}/api/runs/<run_id>/incidents
```

To start clean afterwards (only on a new installation whose knowledge base holds nothing but this check): stop the
app, move the check's database aside instead of deleting it, and remove the sample files:

```
mv db db.first-run-check-$(date +%F)      # the whole folder: knowledge.sqlite with its -wal and -shm files
rm -f samples/sample_* && rm -rf runs/run-* runs/_bench
```

The app creates a new, empty `db/` at the next start. Delete the moved folder when you are sure you do not need it.
On a working installation the rule of `deploy/AGENT_INSTRUCTIONS.md` section 1 applies: never delete
`db/knowledge.sqlite`.

## 8. Where files are written

All inside the application folder. Nothing is written elsewhere except temporary test folders under `/tmp`.

| Path | Contents | Written by |
|---|---|---|
| `db/app.sqlite` | jobs, run list, stage-1 verdict cache | the app |
| `db/knowledge.sqlite` (+ `-wal`, `-shm`) | the knowledge base: causes, procedures, decisions, tests; the two side files belong to it (never copy the main file alone) | stage 2 |
| `db/llm_cache.jsonl`, `db/stage2_log.jsonl` | model answers cache, stage-2 event log | stage 2 |
| `runs/<run-id>/` | per trace: findings, defects, report, `stage2/<defect>.json` decisions | each analysis |
| `runs/_bench/`, `runs/bench_*` | traces of the simulated bench or your bench hook | stage 2 lab runs, tests |
| `suite/<test-id>/` | the generated regression tests (manifest and test scripts) | stage 2 |
| `samples/` | synthetic traces from `POST /api/samples/generate` | first-run check |
| `config/app_config.json` | rewritten when settings are saved on the Settings screen | the app |
| `runs/ui_smoke/` | screenshots of the browser smoke test | `tests/ui_smoke.py` |

Back up `db/`, `suite/` and `config/` with `deploy/backup.sh` (safe while the app runs; `deploy/DEPLOY.md`
section 9). `runs/` can be large; keep it
as long as you need to reopen old runs.

## 9. Uninstall

Uninstalling removes the knowledge base, so **back it up first** (the rule "never delete `db/knowledge.sqlite`" of
`deploy/AGENT_INSTRUCTIONS.md` is for a working installation; removing one is a deliberate decision of the owner).

```
cd /opt/f2t/13_production_app
deploy/backup.sh --app-dir "$PWD" --out-dir /opt/f2t/backups --python .venv/bin/python --with-runs
#   expect: "knowledge.sqlite integrity=ok ..." and "backup written: /opt/f2t/backups/ftl-backup-<time>.tar.gz"
#   (run it as the user that owns the folder, not as root; it refuses root)
```

Keep the archive somewhere safe (it holds `db/`, `suite/`, `config/` and, with `--with-runs`, `runs/`). Then stop the
app (Ctrl-C, or `kill <PID>`, or stop the service as described in `deploy/DEPLOY.md`) and delete the folder:

```
cd /opt/f2t && rm -rf /opt/f2t/13_production_app    # the program, its virtual environment (.venv) and all data
```

Nothing else was installed outside this folder, unless you added a system service or a proxy configuration from
`deploy/DEPLOY.md`; remove those as that document describes.

## How these instructions were checked

On 2026-10-27, the archive `field_to_test_loop_code_only.zip` was unpacked into an empty scratch folder and the
`deploy/` files were copied in. Then:
- a virtual environment was created with Python 3.12.7 (the system Python 3.13 lacked `venv`), once outside the
  folder and once as `.venv` inside it, exactly as in section 3;
- `pip install -r deploy/requirements.txt` was run from the package index (flask 3.1.3, numpy 2.5.4,
  anthropic 2.3.0, pytest 9.1.1, websocket-client 1.9.2);
- the install was repeated without internet from `pip download` packages;
- `deploy/preflight.py` passed through the `cli` backend with `--check-llm` in 3.1 s; re-run with the current
  pre-flight check on the shipped configuration (port free) it reports 25 PASS, 2 WARN (`server.lock_endpoint` off,
  simulated bench), 0 FAIL;
- `./run_tests.sh` passed: 4 tests, 1 skipped, 93 s;
- `python3 -m pytest tests/test_app.py -q` passed;
- `stage2/tests_v3.py` (16 tests) and `stage2/tests_v4.py` (8 tests) passed;
- `python3 run_app.py --port 8091 --standin` was started, and `/api/runs` answered `[]`;
- the sample generator and the analysis of the sample gave one confirmed T-42 defect;
- on a second fresh copy started with `--standin`, the API walk-through of `deploy/AGENT_INSTRUCTIONS.md` step 2.6 A
  ran from the sample to the report in about 45 s: target `sig::T-42`, regression test admitted, 6 of 6 on
  known-bad firmware and 0 of 3 on fixed firmware, two test folders in `suite/`, leakage 0; one generated test
  passed with `python3 -m pytest -q` (2 passed); `deploy/backup.sh` followed by `deploy/restore.sh --app-dir` into
  a scratch copy gave the same knowledge-base counts;
- the mail-safe archive was unpacked, `restore_names.py` was run, and the pre-flight check went from FAIL to PASS on
  the browser scripts.
