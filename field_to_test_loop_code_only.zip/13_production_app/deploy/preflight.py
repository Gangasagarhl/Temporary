#!/usr/bin/env python3
"""Pre-flight check for the Field-to-Test Loop application (standard library only).

Run it from the 13_production_app folder before the first start and after every configuration change:

    python3 deploy/preflight.py                         # uses config/app_config.json
    python3 deploy/preflight.py --config other.json     # another configuration file
    python3 deploy/preflight.py --port 8091             # check a different port (same as run_app.py --port)
    python3 deploy/preflight.py --check-llm             # also make ONE tiny real call to the configured AI model

Prints one line per check:  PASS (fine) / WARN (works, but read the note) / FAIL (fix before going live).
Exit code: 0 when there is no FAIL, 1 otherwise. The script never changes the installation: it creates no folders,
writes only a temporary probe file (deleted at once) inside folders that already exist, and never prints a key.
"""
import argparse
import ast
import importlib
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # the 13_production_app folder
RESULTS = []
KNOWN_BACKENDS = ("cli", "sdk", "http", "openai-compat", "ollama", "standin", "auto")


def report(status, name, detail=""):
    RESULTS.append(status)
    print("%-4s  %s%s" % (status, name, ("  -  " + detail) if detail else ""), flush=True)


def check(name):
    """Decorator: run one check; an unexpected exception becomes a FAIL line instead of a crash."""
    def wrap(fn):
        def run(*a, **kw):
            try:
                return fn(*a, **kw)
            except Exception as e:                       # noqa: BLE001 - one broken check must never stop the others
                report("FAIL", name, "the check itself crashed: %s: %s" % (type(e).__name__, str(e)[:200]))
                return None
        return run
    return wrap


def rel(p):
    try:
        return os.path.relpath(p, ROOT)
    except ValueError:
        return p


def pkg_version(dist):
    try:
        from importlib import metadata
        return metadata.version(dist)
    except Exception:                                    # noqa: BLE001
        return "unknown version"


# ---------------------------------------------------------------------------------------------- Python
@check("Python version")
def check_python():
    v = sys.version_info
    txt = "%d.%d.%d (%s)" % (v[0], v[1], v[2], sys.executable)
    if v < (3, 9):
        report("FAIL", "Python version", txt + "; the code needs Python 3.9 or newer (3.10+ recommended)")
    elif v < (3, 10):
        report("WARN", "Python version", txt + "; 3.9 should work but was not tested; 3.10 or newer is recommended")
    else:
        report("PASS", "Python version", txt)


# ---------------------------------------------------------------------------------------------- packages
def importable(mod):
    try:
        importlib.import_module(mod)
        return True, ""
    except Exception as e:                               # noqa: BLE001 - a broken install raises more than ImportError
        return False, "%s: %s" % (type(e).__name__, str(e)[:150])


@check("required packages")
def check_packages(cfg):
    for mod, dist, why in (("flask", "flask", "web server and API"), ("numpy", "numpy", "stage-1 analyser")):
        ok, err = importable(mod)
        if ok:
            report("PASS", "package %s" % dist, "%s (%s)" % (pkg_version(dist), why))
        else:
            report("FAIL", "package %s" % dist, "not importable (%s); run: python3 -m pip install -r deploy/requirements.txt" % err)
    backend = ((cfg or {}).get("llm") or {}).get("backend", "auto")
    ok, err = importable("anthropic")
    if ok:
        report("PASS", "package anthropic", "%s (Anthropic software development kit, for llm.backend sdk)" % pkg_version("anthropic"))
    else:
        vendored, verr = vendored_sdk_ok()
        if backend == "sdk":
            if vendored:
                report("PASS", "package anthropic", "not installed, but the copy in stage1/vendor/ imports on this interpreter, so "
                       "stage 1 and stage 2 use it (python3 -m pip install anthropic is still the safer choice)")
            else:
                report("FAIL", "package anthropic", "not installed and the copy in stage1/vendor/ does not import on this interpreter "
                       "(%s; the copy is built for CPython 3.13 x86-64 and is searched after the installed packages, as the app does): "
                       "stage 2 would fall back to the stand-in: "
                       "python3 -m pip install anthropic" % (verr or "no stage1/vendor folder"))
        else:
            report("WARN", "package anthropic", "not installed (optional with llm.backend \"%s\"; the copy in stage1/vendor/ %s "
                   "on this interpreter)" % (backend, "imports" if vendored else "does NOT import"))
    for mod, dist, why in (("pytest", "pytest", "python3 -m pytest and the generated regression tests in suite/"),
                           ("websocket", "websocket-client", "tests/ui_smoke.py browser smoke test")):
        ok, err = importable(mod)
        if ok:
            report("PASS", "package %s" % dist, "%s (optional: %s)" % (pkg_version(dist), why))
        else:
            report("WARN", "package %s" % dist, "not installed (optional, only for %s)" % why)


def vendored_sdk_ok():
    """Can the copy in stage1/vendor/ be imported, the way stage2/llm_adapter.py _import_anthropic (and stage 1) fall back to it?
    Tested in a child process so this process stays clean. Returns (ok, short error text)."""
    vendor = os.path.join(ROOT, "stage1", "vendor")
    if not os.path.isdir(vendor):
        return False, ""
    code = "import sys; sys.path.append(%r); import anthropic" % vendor      # append, exactly as _import_anthropic does
    try:
        r = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, timeout=60, cwd=ROOT)
    except Exception as e:                               # noqa: BLE001
        return False, "%s: %s" % (type(e).__name__, str(e)[:120])
    if r.returncode == 0:
        return True, ""
    last = [ln for ln in (r.stderr or "").strip().splitlines() if ln.strip()]
    return False, (last[-1][:160] if last else "exit code %d" % r.returncode)


# ---------------------------------------------------------------------------------------------- shipped files
@check("shipped files")
def check_files():
    def jsonfile(path, what, test):
        p = os.path.join(ROOT, path)
        if not os.path.isfile(p):
            report("FAIL", what, "missing: %s" % path)
            return
        with open(p, encoding="utf-8") as f:
            d = json.load(f)
        ok, info = test(d)
        report("PASS" if ok else "FAIL", what, "%s (%s)" % (path, info))

    jsonfile("stage1/runs/signature_library.json", "signature library",
             lambda d: (isinstance(d, dict) and "df" in d, "%s cards" % (d.get("n_cards") if isinstance(d, dict) else "?")))
    jsonfile("data/atlas_cards_raw.json", "atlas cards",
             lambda d: (isinstance(d, list) and len(d) > 0, "%d cards" % len(d) if isinstance(d, list) else "not a list"))

    spec = os.path.join(ROOT, "data", "DEFECT_DETECTION_SPEC_485.jsonl")
    if not os.path.isfile(spec):
        report("FAIL", "rule definitions", "missing: data/DEFECT_DETECTION_SPEC_485.jsonl")
    else:
        n = bad = 0
        with open(spec, encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                n += 1
                try:
                    r = json.loads(line)
                    if not all(k in r for k in ("card_id", "title", "detect")):
                        bad += 1
                except ValueError:
                    bad += 1
        report("PASS" if n and not bad else "FAIL", "rule definitions",
               "data/DEFECT_DETECTION_SPEC_485.jsonl (%d rules%s)" % (n, ", %d unreadable" % bad if bad else ""))

    hdr = os.path.join(ROOT, "stage1", "reference", "final_113_columns.csv")
    if not os.path.isfile(hdr):
        report("FAIL", "113-column header", "missing: stage1/reference/final_113_columns.csv (the analyser reads it)")
    else:
        import csv
        with open(hdr, newline="", encoding="utf-8-sig") as f:
            cols = next(csv.reader(f), [])
        report("PASS" if len(cols) == 113 else "FAIL", "113-column header",
               "stage1/reference/final_113_columns.csv (%d columns)" % len(cols))

    need = ["stage1/pcie_isolate/cli.py", "data/generator/generate_synthetic_pcie_trace.py", "app/server.py",
            "app/static/index.html", "app/static/db.html", "app/static/defect.html", "stage2/llm_adapter.py"]
    missing = [p for p in need if not os.path.isfile(os.path.join(ROOT, p))]
    report("FAIL" if missing else "PASS", "program files", ("missing: " + ", ".join(missing)) if missing else "%d key files present" % len(need))

    jsdir = os.path.join(ROOT, "app", "static", "js")
    js = [f for f in os.listdir(jsdir) if f.endswith(".js")] if os.path.isdir(jsdir) else []
    txt = [f for f in os.listdir(jsdir) if f.endswith(".js.txt")] if os.path.isdir(jsdir) else []
    if txt:
        report("FAIL", "browser scripts", "%d files still named .js.txt (mail-safe archive): run  python3 restore_names.py  once" % len(txt))
    elif len(js) < 10:
        report("FAIL", "browser scripts", "only %d .js files in app/static/js (10 expected)" % len(js))
    else:
        report("PASS", "browser scripts", "%d files in app/static/js" % len(js))


# ---------------------------------------------------------------------------------------------- configuration
def load_cfg(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


@check("configuration")
def check_config(path):
    if not os.path.isfile(path):
        report("FAIL", "configuration", "not found: %s" % path)
        return None
    try:
        cfg = load_cfg(path)
    except ValueError as e:
        report("FAIL", "configuration", "%s is not valid JSON: %s" % (rel(path), e))
        return None
    problems, notes = [], []
    for sec in ("server", "paths", "llm", "stage1", "stage2"):          # the code reads these with cfg[...]
        if not isinstance(cfg.get(sec), dict):
            problems.append("section \"%s\" missing" % sec)
    if problems:
        report("FAIL", "configuration", "%s: %s" % (rel(path), "; ".join(problems)))
        return cfg
    port = cfg["server"].get("port", 8077)
    if not isinstance(port, int) or not 1 <= port <= 65535:
        problems.append("server.port must be a whole number 1-65535 (is %r)" % (port,))
    roots = cfg["paths"].get("allowed_csv_roots", ["~"])
    if not isinstance(roots, list) or not all(isinstance(r, str) for r in roots):
        problems.append("paths.allowed_csv_roots must be a list of folder names")
    llm = cfg["llm"]
    if llm.get("backend", "auto") not in KNOWN_BACKENDS:
        problems.append("llm.backend %r is not one of %s" % (llm.get("backend"), ", ".join(KNOWN_BACKENDS)))
    if llm.get("effort", "low") not in ("low", "medium", "high"):
        notes.append("llm.effort %r is not one of the documented values low / medium / high" % (llm.get("effort"),))
    if not llm.get("model"):
        notes.append("llm.model empty (default claude-haiku-5-5 is used)")
    if llm.get("batch") and llm.get("backend") != "sdk":
        notes.append("llm.batch is only used with backend sdk")
    s2 = cfg["stage2"]
    if s2.get("bench", "synthetic") not in ("synthetic", "hook"):
        problems.append("stage2.bench must be synthetic or hook")
    if s2.get("search_on", "model") not in ("model", "bench"):
        problems.append("stage2.search_on must be model or bench")
    if s2.get("optimizer", "bandit") not in ("bandit", "ppo"):
        problems.append("stage2.optimizer must be bandit or ppo")
    for k in ("opt_budget", "time_budget_s", "optimal_consecutive", "n_bad", "n_fixed", "max_rows", "stress_trials"):
        if k in s2 and not (isinstance(s2[k], int) and s2[k] >= 0):
            problems.append("stage2.%s must be a whole number >= 0" % k)
    if problems:
        report("FAIL", "configuration", "%s: %s" % (rel(path), "; ".join(problems)))
    else:
        report("WARN" if notes else "PASS", "configuration", "%s parses; backend=%s, bench=%s, search_on=%s%s" % (
            rel(path), llm.get("backend", "auto"), s2.get("bench", "synthetic"), s2.get("search_on", "model"),
            ("; " + "; ".join(notes)) if notes else ""))
    return cfg


@check("allowed trace folders")
def check_roots(cfg):
    roots = cfg["paths"].get("allowed_csv_roots", ["~"])
    for r in roots:
        p = os.path.expanduser(r)
        if os.path.isdir(p):
            report("PASS", "allowed trace folder %s" % r, os.path.realpath(p))
        else:
            report("WARN", "allowed trace folder %s" % r, "does not exist (%s); traces there cannot be opened" % os.path.realpath(p))


@check("writable folders")
def check_writable():
    for d in ("db", "runs", "suite", "samples"):
        p = os.path.join(ROOT, d)
        if os.path.isdir(p):
            try:
                fd, tmp = tempfile.mkstemp(prefix=".preflight_", dir=p)
                os.close(fd)
                os.remove(tmp)
                report("PASS", "folder %s/" % d, "exists and is writable")
            except OSError as e:
                report("FAIL", "folder %s/" % d, "exists but is not writable: %s" % e)
        elif os.path.exists(p):
            report("FAIL", "folder %s/" % d, "exists but is not a folder")
        elif os.access(ROOT, os.W_OK | os.X_OK):
            report("PASS", "folder %s/" % d, "not there yet; will be created on first start")
        else:
            report("FAIL", "folder %s/" % d, "cannot be created: %s is not writable by this user" % ROOT)
    free = shutil.disk_usage(ROOT).free / 1e9
    report("PASS" if free >= 5 else "WARN", "free disk space", "%.1f GB free under %s%s" % (
        free, ROOT, "" if free >= 5 else " (each analysed trace writes a run folder; keep at least 5 GB free)"))


@check("server address")
def check_port(cfg, port_override):
    host = cfg["server"].get("host", "127.0.0.1")
    port = port_override or cfg["server"].get("port", 8077)
    s = socket.socket(socket.AF_INET6 if ":" in host else socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)          # the same option the Flask server uses
    try:
        s.bind((host, port))
        report("PASS", "port %s:%d" % (host, port), "free")
    except OSError as e:
        report("WARN", "port %s:%d" % (host, port), "cannot be used now (%s): another program (or a running copy of this app) "
               "holds it; stop it or start with  python3 run_app.py --port <other>" % e.strerror)
    finally:
        s.close()
    if host not in ("127.0.0.1", "localhost", "::1"):
        report("WARN", "server.host %s" % host, "the app has no authentication; put it behind an authenticating reverse proxy "
               "(deploy/DEPLOY.md) and keep server.host 127.0.0.1")
    else:
        report("PASS", "server.host %s" % host, "reachable from this machine only")
    if cfg["server"].get("lock_endpoint"):
        report("PASS", "server.lock_endpoint", "the Settings page cannot change the AI endpoint, the key variable, the backend, "
               "the tools list or the readable folders")
        tools = (cfg.get("llm") or {}).get("tools") or []
        if "web_search" in tools:
            report("WARN", "llm.tools web_search", "locked on: trace content may be sent to web search (the model's search queries can "
                   "carry text from the trace); keep it only if that is intended, otherwise set llm.tools to [] in the config file")
        else:
            report("PASS", "llm.tools", "no web search: trace content is sent only to the configured AI endpoint")
    else:
        report("WARN", "server.lock_endpoint", "off: anyone who reaches the Settings page can point llm.base_url at another server "
               "and receive the API key; set it to true for production (deploy/config.production.example.json)")


# ---------------------------------------------------------------------------------------------- AI model backend
def url_problem(url):
    u = urllib.parse.urlparse(url)
    if u.scheme not in ("http", "https") or not u.netloc:
        return "is not a web address of the form https://host[:port][/path]"
    return None


@check("AI model backend")
def check_llm(cfg):
    llm = cfg["llm"]
    b = llm.get("backend", "auto")
    env = llm.get("api_key_env") or ""
    base = (llm.get("base_url") or "").strip()
    if b == "standin":
        report("WARN", "backend standin", "no AI reviewer: stage 1 runs without the model's second opinion and stage 2 proposals come "
               "from fixed templates (fine for tests and demos only)")
        return
    if b == "cli":
        exe = shutil.which("claude")
        if exe:
            report("PASS", "backend cli", "claude command found at %s (it must be logged in for the user running the app)" % exe)
        else:
            report("FAIL", "backend cli", "the claude command is not on PATH for this user; install and log in to the Claude Code "
                   "command-line tool, or switch llm.backend to sdk / openai-compat")
        return
    if b == "sdk":
        names = [n for n in (env, "ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN") if n]
        found = [n for n in names if os.environ.get(n)]
        if found:
            report("PASS", "backend sdk key", "environment variable %s is set (value not shown)" % found[0])
        else:
            report("FAIL", "backend sdk key", "environment variable %s is not set in this shell; export it before starting the app"
                   % (env or "ANTHROPIC_API_KEY"))
        if base:
            p = url_problem(base)
            if p:
                report("FAIL", "backend sdk base_url", "%r %s" % (base, p))
            elif base.rstrip("/").endswith(("/v1", "/v1/messages")):
                report("WARN", "backend sdk base_url", "%s ends in /v1: the Anthropic SDK adds /v1/messages itself; give the address "
                       "without it" % base)
            else:
                report("PASS", "backend sdk base_url", base)
        else:
            report("PASS", "backend sdk base_url", "empty: the default Anthropic endpoint (api.anthropic.com) or ANTHROPIC_BASE_URL is used")
        return
    if b == "openai-compat":
        if not base:
            report("FAIL", "backend openai-compat base_url", "empty; set llm.base_url to the endpoint, e.g. https://host/v1")
        else:
            p = url_problem(base)
            if p:
                report("FAIL", "backend openai-compat base_url", "%r %s" % (base, p))
            elif not base.rstrip("/").endswith("/v1"):
                report("WARN", "backend openai-compat base_url", "%s: the app appends /chat/completions; most endpoints expect the "
                       "address to end in /v1" % base)
            else:
                report("PASS", "backend openai-compat base_url", base)
        if env and os.environ.get(env):
            report("PASS", "backend openai-compat key", "environment variable %s is set (value not shown)" % env)
        else:
            report("WARN", "backend openai-compat key", "environment variable %s is not set; fine only if the endpoint needs no key"
                   % (env or "(llm.api_key_env empty)"))
        report("WARN", "backend openai-compat stage 1", "stage 1 review runs without a model (the analyser has no generic "
               "endpoint, so its review is a dry run); stage 2 uses the endpoint")
        return
    if b == "ollama":
        report("WARN", "backend ollama", "stage 1 review runs without a model (dry run); stage 2 uses ollama at "
               "http://localhost:11434, or the stand-in without a model when it is not reachable at start (run  ollama serve  and "
               "pull llm.model; --check-llm tests it)")
        return
    if b == "auto":
        if os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN") or (env and os.environ.get(env)):
            how = "sdk (an API key is set)"
        elif shutil.which("claude"):
            how = "cli (claude command found)"
        else:
            how = "the stand-in, no model (no key and no claude command)"
        report("WARN", "backend auto", "resolves at start to %s; set the backend explicitly in production" % how)


# ---------------------------------------------------------------------------------------------- lab bench
def run_is_stub(path):
    """True when HardwareBench.run in app/bench_hook.py still only raises NotImplementedError."""
    with open(path, encoding="utf-8") as f:
        tree = ast.parse(f.read())
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == "HardwareBench":
            for fn in node.body:
                if isinstance(fn, ast.FunctionDef) and fn.name == "run":
                    body = [s for s in fn.body if not (isinstance(s, ast.Expr) and isinstance(getattr(s, "value", None), ast.Constant))]
                    if len(body) == 1 and isinstance(body[0], ast.Raise) and "NotImplementedError" in ast.dump(body[0]):
                        return True
                    return False
            return None
    return None


@check("lab bench")
def check_bench(cfg):
    bench = cfg["stage2"].get("bench", "synthetic")
    if bench == "synthetic":
        report("WARN", "bench synthetic", "lab runs are simulated (synthetic device model and trace generator); set stage2.bench to "
               "\"hook\" after implementing app/bench_hook.py (deploy/BENCH_INTEGRATION.md)")
        return
    if bench == "hook":
        p = os.path.join(ROOT, "app", "bench_hook.py")
        if not os.path.isfile(p):
            report("FAIL", "bench hook", "app/bench_hook.py is missing")
            return
        stub = run_is_stub(p)
        if stub is True:
            report("FAIL", "bench hook", "stage2.bench is \"hook\" but HardwareBench.run in app/bench_hook.py is still the "
                   "NotImplementedError placeholder; implement it (deploy/BENCH_INTEGRATION.md) or set bench to \"synthetic\"")
        elif stub is None:
            report("FAIL", "bench hook", "app/bench_hook.py has no HardwareBench class with a run method")
        else:
            report("PASS", "bench hook", "HardwareBench.run is implemented (its behaviour on the device is not tested here)")
        if cfg["stage2"].get("search_on") == "bench":
            report("WARN", "search_on bench", "every search trial runs on the real device: slower; keep stage2.opt_budget small")


# ---------------------------------------------------------------------------------------------- optional live call
@check("live AI model call")
def check_llm_call(cfg):
    """One tiny real call through the app's own adapter (stage2/llm_adapter.py), set up the way app/stage2_service.py
    make_llm does. No cache file is written."""
    c = dict(cfg["llm"])
    b = c.get("backend", "auto")
    model = c.get("model", "claude-haiku-5-5")
    stage2 = os.path.join(ROOT, "stage2")
    if stage2 not in sys.path:
        sys.path.insert(0, stage2)
    from llm_adapter import AnthropicLLM, OllamaLLM, OpenAICompat, StandInLLM   # noqa: E402
    if b == "standin":
        report("WARN", "live AI model call", "backend standin: there is no model to call")
        return
    if b in ("cli", "sdk", "http", "auto"):
        if b in ("sdk", "http") and c.get("base_url"):
            os.environ["ANTHROPIC_BASE_URL"] = c["base_url"]
        if c.get("api_key_env") and os.environ.get(c["api_key_env"]) and not os.environ.get("ANTHROPIC_API_KEY"):
            os.environ["ANTHROPIC_API_KEY"] = os.environ[c["api_key_env"]]
        llm = AnthropicLLM(model, effort=c.get("effort", "low"), cache_path=None, backend=b, timeout=120)
        if not llm.available():
            report("FAIL", "live AI model call", "backend %s is not available here (the app would fall back to the stand-in)" % b)
            return
    elif b == "openai-compat":
        llm = OpenAICompat(model, c.get("base_url", ""), os.environ.get(c.get("api_key_env", ""), ""), None)
    elif b == "ollama":
        llm = OllamaLLM(model, cache_path=None)
        if not llm.available():
            report("FAIL", "live AI model call", "Ollama is not reachable at http://localhost:11434")
            return
    else:
        report("FAIL", "live AI model call", "unknown backend %r" % b)
        return
    schema = {"type": "object", "properties": {"ok": {"type": "boolean"}}, "required": ["ok"]}
    t = time.time()
    try:
        out = llm._generate('Reply with {"ok": true} and nothing else.', schema)
    except Exception as e:                               # noqa: BLE001 - transport errors of any backend
        report("FAIL", "live AI model call", "%s via %s raised %s: %s" % (model, llm.name, type(e).__name__, str(e)[:200]))
        return
    dt = time.time() - t
    if isinstance(out, dict) and "_error" in out:
        report("FAIL", "live AI model call", "%s answered with an error after %.1f s: %s" % (llm.name, dt, str(out["_error"])[:250]))
    elif isinstance(out, dict) and out.get("ok") is True:
        report("PASS", "live AI model call", "%s answered in %.1f s" % (llm.name, dt))
    else:
        report("WARN", "live AI model call", "%s answered in %.1f s but not with the expected JSON: %s" % (llm.name, dt, str(out)[:150]))


# ---------------------------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--config", default=os.path.join("config", "app_config.json"),
                    help="configuration file (default config/app_config.json in the application folder)")
    ap.add_argument("--port", type=int, default=None, help="check this port instead of server.port (as run_app.py --port)")
    ap.add_argument("--check-llm", action="store_true", help="make one tiny real call through the configured AI model backend")
    a = ap.parse_args()
    cfg_path = a.config if os.path.isabs(a.config) or os.path.exists(a.config) else os.path.join(ROOT, a.config)
    cfg_path = os.path.abspath(cfg_path)
    print("Field-to-Test Loop pre-flight check   application folder: %s" % ROOT)
    print("configuration: %s\n" % cfg_path)
    check_python()
    cfg = check_config(cfg_path)
    check_packages(cfg)
    check_files()
    check_writable()
    if cfg and all(isinstance(cfg.get(s), dict) for s in ("server", "paths", "llm", "stage1", "stage2")):
        check_roots(cfg)
        check_port(cfg, a.port)
        check_llm(cfg)
        check_bench(cfg)
        if a.check_llm:
            check_llm_call(cfg)
    else:
        report("FAIL", "configuration-based checks", "skipped: fix the configuration first")
    n = {k: RESULTS.count(k) for k in ("PASS", "WARN", "FAIL")}
    print("\n%d PASS, %d WARN, %d FAIL  ->  %s" % (n["PASS"], n["WARN"], n["FAIL"],
          "NOT ready: fix every FAIL line" if n["FAIL"] else "ready to start (read every WARN line)"))
    return 1 if n["FAIL"] else 0


if __name__ == "__main__":
    sys.exit(main())
