"""Hardware bench hook - ready-to-adapt TEMPLATE (stage 2 lab runs on a real drive).

Copy this file over app/bench_hook.py, fill in the parts marked  SITE-SPECIFIC , then set
"stage2": {"bench": "hook"} in config/app_config.json (first with "search_on": "model", later "bench") and restart the
application: stage2.bench is read only at start-up (the Settings page says so when you change it there).
Read deploy/BENCH_INTEGRATION.md first. Under the hardened service unit (deploy/field-to-test-loop.service) nvme-cli
admin commands, setpci and the sysfs writes below fail: see BENCH_INTEGRATION.md "Access the service needs on a
hardware bench" and DEPLOY.md "Running with a hardware bench". Use a scratch drive only.

What one lab run does (HardwareBench.run):
    1. check the procedure: only the 12 allowed commands, nothing from the deny list (format, sanitize, firmware
       download / commit, namespace delete ...); a denied or unknown command raises BenchRefused before anything runs
    2. build the command plan: every command -> one nvme-cli / fio / sysfs / power-switch command line (SITE_TOOLS)
    3. safety pre-flight: the scratch namespace is not mounted, the drive model is the expected one
    4. put the drive on the requested firmware (known-bad or fixed)             -> _switch_firmware    (site hook)
    5. prepare the power state (none | L1 | L1.2 | D3hot | APST)
    6. arm the protocol analyzer                                                 -> _start_capture      (site hook)
    7. execute the plan with the requested spacing, queue depth, block size, burst length and idle gap
    8. stop the analyzer, export the 113-column CSV                              -> _stop_and_export_capture (site hook)
    9. run the SAME stage-1 analyser on the CSV (testgen.run_engine + testgen.findings_of) and turn its findings into
       the result record the search, the lab check and the generated tests read (same rules as testgen.GeneratorBench)

DRY_RUN=1 (environment variable): steps 3, 4, 6, 7 and 8 are skipped; the plan is printed and a well-formed
"nothing reproduced" record is returned. DRY_RUN=1 plus BENCH_REPLAY_CSV=<capture.csv> (and optionally
BENCH_REPLAY_CSV_FIXED for the fixed bench) runs the analyser on that existing capture instead, to test the analysis
path without hardware.

Standard library + the application's own stage2 modules only.
"""
import json
import os
import shlex
import subprocess
import sys
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)                        # works from <app>/app/ (copied over bench_hook.py) and <app>/deploy/
sys.path.insert(0, os.path.join(APP, "stage2"))
import testgen                                     # noqa: E402
from testgen import findings_of, run_engine        # noqa: E402


# ====================================================================== safety vocabulary (do not loosen)
ALLOWED_OPS = ("read", "write", "flush", "trim", "write_zeroes", "reset", "power_cycle", "aspm_idle", "identify",
               "get_log", "set_feature", "abort")
# Every spelling the app uses (optimizer.DENY_OPS uses fw_download / ns_delete, the test manifest fw-download / delete-ns)
# is normalised to lower case with "_" before the check, so both forms are refused.
DENY_OPS = {"format", "sanitize", "fw_download", "fw_commit", "fw_activate", "fw_image_download", "ns_delete", "delete_ns",
            "ns_create", "create_ns", "ns_attach", "attach_ns", "ns_detach", "detach_ns", "security_send",
            "subsystem_reset", "nssr", "secure_erase"}
# nvme-cli sub-commands that must never appear in a generated command line (second guard on the finished plan)
DENY_NVME_SUBCOMMANDS = {"format", "sanitize", "fw-download", "fw-commit", "fw-activate", "delete-ns", "create-ns",
                         "attach-ns", "detach-ns", "security-send", "subsystem-reset", "ns-rescan"}
POWER_STATES = ("none", "L1", "L1.2", "D3hot", "APST")
TIMING_RANGES = {"inter_cmd_us": (1, 5000), "burst_len": (1, 128), "idle_gap_ms": (0, 2000), "qd": (1, 256),
                 "bs_kb": (4, 1024)}
TIMING_DEFAULTS = {"inter_cmd_us": 50, "burst_len": 16, "idle_gap_ms": 0, "qd": 8, "bs_kb": 4}


class BenchRefused(Exception):
    """The procedure (or the bench state) is not safe to run; nothing was sent to the drive."""


def _env(name, default=None):
    v = os.environ.get(name)
    return v if v not in (None, "") else default


def dry_run():
    return _env("DRY_RUN", "0") not in ("0", "false", "no")


# ====================================================================== SITE-SPECIFIC: the bench description
# Every value can be overridden by the environment variable of the same name. Nothing here is a real default for your
# lab: fill it in. The scratch namespace must hold no data; the LBA window bounds every write / trim / write-zeroes.
SITE = {
    "BENCH_CTRL": _env("BENCH_CTRL", "/dev/nvme0"),                 # NVMe controller character device
    "BENCH_NS": _env("BENCH_NS", "/dev/nvme0n2"),                   # SCRATCH namespace block device (never n1 with data)
    "BENCH_NSID": int(_env("BENCH_NSID", "2")),
    "BENCH_BDF": _env("BENCH_BDF", "0000:01:00.0"),                 # PCI bus:device.function of the drive
    "BENCH_LBA_START": int(_env("BENCH_LBA_START", "0")),           # scratch window (logical blocks)
    "BENCH_LBA_COUNT": int(_env("BENCH_LBA_COUNT", "2097152")),     # 1 GiB at 512-byte blocks
    "BENCH_LBA_BYTES": int(_env("BENCH_LBA_BYTES", "512")),
    "BENCH_DEVICE_MODEL": _env("BENCH_DEVICE_MODEL"),               # expected model name (nvme id-ctrl "mn"); None = not checked
    "BENCH_FW_KNOWN_BAD": _env("BENCH_FW_KNOWN_BAD"),               # firmware revision string ("fr") of the known-bad build
    "BENCH_FW_FIXED": _env("BENCH_FW_FIXED"),                       # firmware revision string of the fixed build
    "BENCH_PDU_OFF": _env("BENCH_PDU_OFF"),                         # shell command: switch the drive's power outlet off
    "BENCH_PDU_ON": _env("BENCH_PDU_ON"),                           # shell command: switch it on again
    "BENCH_POWER_OFF_S": float(_env("BENCH_POWER_OFF_S", "5")),
    "BENCH_ENUM_TIMEOUT_S": float(_env("BENCH_ENUM_TIMEOUT_S", "60")),   # wait for the drive to come back after a cycle
    "BENCH_ASPM_MIN_IDLE_MS": int(_env("BENCH_ASPM_MIN_IDLE_MS", "50")),
    "BENCH_STEP_TIMEOUT_S": float(_env("BENCH_STEP_TIMEOUT_S", "60")),   # one command line
    "BENCH_RUN_TIMEOUT_S": float(_env("BENCH_RUN_TIMEOUT_S", "300")),    # one whole lab run
    "BENCH_ANALYSE_TIMEOUT_S": float(_env("BENCH_ANALYSE_TIMEOUT_S", "600")),
    "BENCH_NSZE": _env("BENCH_NSZE"),           # namespace size for the analyser (hex blocks); None = testgen.NSZE (synthetic)
    "BENCH_USE_DMESG": _env("BENCH_USE_DMESG", "0") == "1",         # hand the host kernel log to the analyser
    "FIO": _env("BENCH_FIO", "fio"),
    "NVME": _env("BENCH_NVME", "nvme"),
    "SETPCI": _env("BENCH_SETPCI", "setpci"),
}

_HW_LOCK = threading.Lock()        # one device: the known-bad and the fixed bench never run at the same time


# ====================================================================== SITE-SPECIFIC: command -> tool mapping
def _io_window(t):
    """Bytes / blocks of one burst, kept inside the scratch LBA window."""
    nbytes = t["bs_kb"] * 1024 * t["burst_len"]
    nlb = max(1, min(SITE["BENCH_LBA_COUNT"], nbytes // SITE["BENCH_LBA_BYTES"]))
    return SITE["BENCH_LBA_START"], nlb


def _fio(rw, t, name):
    """One burst: burst_len I/Os of bs_kb at queue depth qd, inter_cmd_us of think time between I/Os."""
    size = SITE["BENCH_LBA_COUNT"] * SITE["BENCH_LBA_BYTES"]
    return [SITE["FIO"], "--name=" + name, "--filename=" + SITE["BENCH_NS"], "--rw=" + rw, "--bs=%dk" % t["bs_kb"],
            "--iodepth=%d" % t["qd"], "--number_ios=%d" % t["burst_len"], "--direct=1", "--ioengine=io_uring",
            "--offset=%d" % (SITE["BENCH_LBA_START"] * SITE["BENCH_LBA_BYTES"]), "--size=%d" % size,
            "--thinktime=%d" % t["inter_cmd_us"], "--thinktime_blocks=1", "--norandommap", "--output-format=json"]


def build_step(op, t):
    """SITE-SPECIFIC: one procedure command -> {"argv": [...] | None, "action": None | "power_cycle" | "idle", "note"}.
    argv runs as a subprocess (never through a shell). Adjust flags to your tool versions; keep every write inside
    the scratch window and never add a denied sub-command (the plan is re-checked after this function)."""
    ctrl, ns, nsid = SITE["BENCH_CTRL"], SITE["BENCH_NS"], str(SITE["BENCH_NSID"])
    slba, nlb = _io_window(t)
    nvme = SITE["NVME"]
    if op == "read":
        return {"argv": _fio("randread", t, "read"), "note": "fio burst: %d x %d KiB reads, queue depth %d" % (t["burst_len"], t["bs_kb"], t["qd"])}
    if op == "write":
        return {"argv": _fio("randwrite", t, "write"), "note": "fio burst: %d x %d KiB writes, queue depth %d" % (t["burst_len"], t["bs_kb"], t["qd"])}
    if op == "flush":
        return {"argv": [nvme, "flush", ns, "--namespace-id=" + nsid], "note": "NVMe Flush"}
    if op == "trim":
        return {"argv": [nvme, "dsm", ns, "--namespace-id=" + nsid, "--ad", "--slbs=%d" % slba, "--blocks=%d" % nlb],
                "note": "NVMe Dataset Management, deallocate %d blocks" % nlb}
    if op == "write_zeroes":
        return {"argv": [nvme, "write-zeroes", ns, "--namespace-id=" + nsid, "--start-block=%d" % slba,
                         "--block-count=%d" % (min(nlb, 65536) - 1)], "note": "NVMe Write Zeroes (count is 0-based)"}
    if op == "reset":
        return {"argv": [nvme, "reset", ctrl], "note": "controller reset (CC.EN 1 -> 0 -> 1)"}
    if op == "power_cycle":
        return {"argv": None, "action": "power_cycle", "note": "power outlet off/on through the controllable power switch"}
    if op == "aspm_idle":
        return {"argv": None, "action": "idle", "idle_ms": max(t["idle_gap_ms"], SITE["BENCH_ASPM_MIN_IDLE_MS"]),
                "note": "no traffic so the link can enter its low-power state"}
    if op == "identify":
        return {"argv": [nvme, "id-ctrl", ctrl, "--output-format=json"], "note": "Identify Controller"}
    if op == "get_log":
        return {"argv": [nvme, "error-log", ctrl, "--log-entries=16"], "note": "Get Log Page: error information"}
    if op == "set_feature":
        # power-state feature (0x02) to state 0, not saved (no --save): harmless, exercises the admin path
        return {"argv": [nvme, "set-feature", ctrl, "--feature-id=0x02", "--value=0"], "note": "Set Features: power state 0"}
    if op == "abort":
        # Abort of command id 0 on I/O queue 1: the drive answers "command not found" when nothing is outstanding
        return {"argv": [nvme, "admin-passthru", ctrl, "--opcode=0x08", "--cdw10=%d" % ((0 << 16) | 1)],
                "note": "NVMe Abort (admin opcode 0x08)"}
    raise BenchRefused("no tool mapping for command %r" % op)


def power_prep(state):
    """SITE-SPECIFIC: command lines that put the link / drive in the requested power state before the procedure, and
    the ones that undo it afterwards. Returns (prepare_argvs, restore_argvs). sysfs writes are `sh -c "echo V > PATH"`
    with the value and path quoted (the only command lines that go through a shell)."""
    bdf = SITE["BENCH_BDF"]
    link = "/sys/bus/pci/devices/%s/link/" % bdf
    tee = lambda path, val: ["sh", "-c", "echo %s > %s" % (shlex.quote(val), shlex.quote(path))]   # noqa: E731
    off = [tee(link + "l1_aspm", "0"), tee(link + "l1_2_aspm", "0")]
    if state == "none":
        return off, []
    if state == "L1":
        return [tee(link + "l1_aspm", "1")], off
    if state == "L1.2":
        return [tee(link + "l1_aspm", "1"), tee(link + "l1_2_aspm", "1")], off
    if state == "D3hot":
        # PMCSR (power management control/status, capability offset + 4): 3 = D3hot, 0 = D0. Only with the nvme driver
        # quiesced or unbound at your site - writing it under a live driver can hang the controller.
        return [[SITE["SETPCI"], "-s", bdf, "CAP_PM+4.w=0003:0003"], ["sleep", "0.1"],
                [SITE["SETPCI"], "-s", bdf, "CAP_PM+4.w=0000:0003"]], []
    if state == "APST":
        # Autonomous Power State Transition (feature 0x0c) on; the transition table is site-specific (apst.bin, 256 bytes)
        return [[SITE["NVME"], "set-feature", SITE["BENCH_CTRL"], "--feature-id=0x0c", "--value=1",
                 "--data=" + _env("BENCH_APST_TABLE", "/etc/pcie-bench/apst.bin"), "--data-len=256"]], []
    raise BenchRefused("unknown power state %r" % state)


# ====================================================================== the bench
class HardwareBench:
    """Same constructor and methods as app/bench_hook.py; app/stage2_service.py._bench_factory calls
    HardwareBench(sig, family, expected, fixed, decoy, seed) positionally."""

    inject = None            # optional jammer: set inject = _site_inject and clear_faults = _site_clear_faults when the
    clear_faults = None      # bench has a protocol jammer; leave None otherwise (the sweep then skips jammer variants)

    def __init__(self, sig, family=None, expected_cards=None, fixed=False, decoy=None, seed=0, workdir=None):
        self.sig, self.family, self.fixed = sig, family, fixed
        self.decoy, self.seed = decoy, seed       # decoy / seed only steer the synthetic bench; kept for the record
        self.expected = set(expected_cards or [sig])
        self.workdir = workdir or os.path.join(APP, "runs", "bench_" + sig.replace("/", "_") + ("_fixed" if fixed else ""))
        os.makedirs(self.workdir, exist_ok=True)
        self.calls, self.seconds = 0, 0.0
        self.device_model = SITE["BENCH_DEVICE_MODEL"]   # a generated test sets this from manifest preconditions.device_model
        self.field_rule = None                           # optional: the field incident's first rule -> stage 4 on a match
        self.log = []
        self._detections = {}

    @classmethod
    def for_manifest(cls, manifest, fixed=False, workdir=None):
        """Fixture helper for a generated suite/<test>/conftest.py: one bench from the test's manifest."""
        b = cls(manifest["card"], manifest.get("pattern"), manifest.get("expected_cards"), fixed, None, 1, workdir)
        b.device_model = (manifest.get("preconditions") or {}).get("device_model") or b.device_model
        return b

    # ------------------------------------------------------------------ plan
    @staticmethod
    def check_scenario(scenario):
        """Normalise and check a procedure. Raises BenchRefused on a denied or unknown command."""
        ops = []
        for c in (scenario or {}).get("commands") or []:
            op = str(c.get("op") if isinstance(c, dict) else c).strip().lower().replace("-", "_")
            if op in DENY_OPS:
                raise BenchRefused("denied command %r: this bench never runs format / sanitize / firmware / namespace "
                                   "management commands" % op)
            if op not in ALLOWED_OPS:
                raise BenchRefused("unknown command %r (allowed: %s)" % (op, ", ".join(ALLOWED_OPS)))
            ops.append(op)
        if not ops:
            raise BenchRefused("the procedure has no command")
        t_in = (scenario or {}).get("timing") or {}
        timing = {}
        for k, (lo, hi) in TIMING_RANGES.items():
            timing[k] = int(min(hi, max(lo, int(t_in.get(k, TIMING_DEFAULTS[k])))))
        pw = str((scenario or {}).get("power_state") or "none")
        if pw not in POWER_STATES:
            raise BenchRefused("unknown power state %r" % pw)
        return ops, timing, pw

    def plan(self, scenario):
        """The full command plan of one lab run (also what DRY_RUN prints)."""
        ops, t, pw = self.check_scenario(scenario)
        prep, restore = power_prep(pw)
        steps = []
        for i, op in enumerate(ops):
            s = dict(build_step(op, t), i=i, op=op)
            s["pause_after_us"] = t["inter_cmd_us"]                      # spacing between procedure commands
            if op in ("read", "write") and t["idle_gap_ms"]:
                s["pause_after_us"] += t["idle_gap_ms"] * 1000           # idle gap after every burst
            steps.append(s)
        plan = {"card": self.sig, "firmware": "fixed" if self.fixed else "known_bad", "power_state": pw, "timing": t,
                "prepare": prep, "steps": steps, "restore": restore}
        self._check_plan(plan)
        return plan

    @staticmethod
    def _check_plan(plan):
        """Second guard: no denied nvme-cli sub-command anywhere in the finished plan, no write outside the scratch device."""
        argvs = list(plan["prepare"]) + list(plan["restore"]) + [s["argv"] for s in plan["steps"] if s.get("argv")]
        for argv in argvs:
            words = {w.strip().lower() for w in argv}
            bad = words & DENY_NVME_SUBCOMMANDS
            if bad:
                raise BenchRefused("plan contains a denied command line: %s" % " ".join(argv))
            if any(w.startswith("--filename=") and w != "--filename=" + SITE["BENCH_NS"] for w in words):
                raise BenchRefused("fio target is not the scratch namespace: %s" % " ".join(argv))

    def plan_text(self, plan):
        lines = ["# lab run plan: card %s, %s firmware, power state %s" % (plan["card"], plan["firmware"], plan["power_state"])]
        lines += ["prepare: " + " ".join(a) for a in plan["prepare"]]
        for s in plan["steps"]:
            cmd = " ".join(s["argv"]) if s.get("argv") else "[%s %s]" % (s.get("action"), s.get("idle_ms", ""))
            lines.append("%2d %-12s %s    # %s; then pause %d us" % (s["i"], s["op"], cmd, s.get("note", ""), s["pause_after_us"]))
        lines += ["restore: " + " ".join(a) for a in plan["restore"]]
        return "\n".join(lines)

    # ------------------------------------------------------------------ the two methods the app calls
    def run(self, scenario):
        """Execute the procedure on the drive and return the record the search / lab check / tests read:
        {"trace", "stage", "closeness", "reproduced", "cost_s", "isolated", "isolated_top1", ...}."""
        t0 = time.time()
        self.calls += 1
        run_id = "run_%04d_%d" % (self.calls, int(t0))
        plan = self.plan(scenario)                     # refuses denied ops before anything else happens
        rdir = os.path.join(self.workdir, run_id)
        os.makedirs(rdir, exist_ok=True)
        with open(os.path.join(rdir, "plan.json"), "w") as f:
            json.dump(plan, f, indent=1)
        dmesg = None
        if dry_run():
            print(self.plan_text(plan), file=sys.stderr)
            replay = _env("BENCH_REPLAY_CSV_FIXED") if self.fixed else None
            replay = replay or _env("BENCH_REPLAY_CSV")
            trace = replay if (replay and os.path.exists(replay)) else None
        else:
            with _HW_LOCK:
                self._preflight()
                self._switch_firmware(self.fixed)
                handle = None
                try:
                    for argv in plan["prepare"]:
                        self._exec(argv, rdir, "prepare")
                    before = self._dmesg_lines() if SITE["BENCH_USE_DMESG"] else None
                    handle = self._start_capture(run_id, rdir)
                    self._execute_steps(plan, rdir, t0)
                    trace = self._stop_and_export_capture(handle, os.path.join(rdir, "capture.csv"))
                    handle = None
                    if before is not None:
                        dmesg = self._dmesg_since(before, os.path.join(rdir, "dmesg_x.txt"))
                finally:
                    if handle is not None:                 # the run failed half way: never leave the analyzer armed
                        try:
                            self._stop_and_export_capture(handle, os.path.join(rdir, "capture_aborted.csv"))
                        except Exception:              # noqa: BLE001
                            pass
                    for argv in plan["restore"]:
                        try:
                            self._exec(argv, rdir, "restore")
                        except Exception:              # noqa: BLE001
                            pass
        findings = self.detect(trace, dmesg=dmesg) if trace else []
        res = self.result_from_findings(findings, trace)
        res.update(cost_s=round(time.time() - t0, 3), run_id=run_id, firmware=plan["firmware"], dry_run=dry_run(),
                   findings=findings, run_dir=rdir)
        self.seconds += time.time() - t0
        self.log.append({"call": self.calls, "run_id": run_id, "stage": res["stage"], "reproduced": res["reproduced"]})
        return res

    def detect(self, trace, dmesg=None):
        """Run the stage-1 analyser on a capture and return its findings
        [{"card_id", "verdict" (CONFIRMED|SUSPECT), "closeness", "pkt", "incident", "rule", "rank"}].
        trace: the CSV path or the record run() returned."""
        if isinstance(trace, dict):
            trace = trace.get("trace")
        if not trace:
            return []                                  # dry run: no capture, nothing isolated
        if trace in self._detections:
            return self._detections[trace]
        out_dir = os.path.join(self.workdir, "det_" + os.path.basename(os.path.dirname(trace)) + "_"
                               + os.path.basename(trace).replace(".csv", ""))
        if dmesg is None and not SITE["BENCH_NSZE"]:
            out = run_engine(trace, out_dir, timeout=SITE["BENCH_ANALYSE_TIMEOUT_S"], host_evidence=False)
        else:
            out = self._run_engine_site(trace, out_dir, dmesg)
        if out.get("error"):
            # On hardware a failed analysis must never read as "silent" (it would pass the fixed-firmware check)
            raise RuntimeError("stage-1 analyser failed on %s: %s" % (trace, out["error"]))
        self._detections[trace] = findings_of(out["incidents"])
        return self._detections[trace]

    # ------------------------------------------------------------------ findings -> result (same rules as GeneratorBench)
    def stage_from_findings(self, findings):
        """testgen.GeneratorBench.stage_from_findings, plus stage 4 when a field rule is known and matches:
        3 = an expected card CONFIRMED, 2 = an expected card SUSPECT, 1 = a card of the same family, 0 = nothing."""
        best = (0, 0.0)
        for f in findings:
            c = max(0.0, min(1.0, float(f.get("closeness") or 0.0)))
            if f["card_id"] in self.expected and f["verdict"] in ("CONFIRMED", "SUSPECT"):
                s = 3 if f["verdict"] == "CONFIRMED" else 2
                if s == 3 and self.field_rule and f.get("rule") == self.field_rule:
                    s = 4
                best = max(best, (s, c))
            elif f["card_id"].split("-")[0] == self.sig.split("-")[0]:
                best = max(best, (1, 0.5))
        return best

    def result_from_findings(self, findings, trace):
        stage, closeness = self.stage_from_findings(findings)
        return {"trace": trace, "stage": stage, "closeness": round(closeness, 4), "reproduced": stage >= 3,
                "detector_stage": stage, "manifested": stage >= 2,
                # positive side: the card or its ambiguity group isolated (CONFIRMED or SUSPECT)
                "isolated": [f for f in findings if f["card_id"] in self.expected and f["verdict"] in ("CONFIRMED", "SUSPECT")],
                # negative side (fixed firmware): the card itself as the PRIMARY isolation
                "isolated_top1": [f for f in findings if f["card_id"] == self.sig and f["verdict"] == "CONFIRMED"]}

    # ------------------------------------------------------------------ execution helpers
    def _exec(self, argv, rdir, tag, timeout=None):
        r = subprocess.run(argv, capture_output=True, text=True, timeout=timeout or SITE["BENCH_STEP_TIMEOUT_S"])
        with open(os.path.join(rdir, "host_events.jsonl"), "a") as f:
            f.write(json.dumps({"t": time.time(), "tag": tag, "argv": argv, "rc": r.returncode,
                                "stdout": r.stdout[-2000:], "stderr": r.stderr[-2000:]}) + "\n")
        if r.returncode != 0:
            raise RuntimeError("%s failed (rc %d): %s: %s" % (tag, r.returncode, " ".join(argv), r.stderr[-300:]))
        return r

    def _execute_steps(self, plan, rdir, t0):
        for s in plan["steps"]:
            if time.time() - t0 > SITE["BENCH_RUN_TIMEOUT_S"]:
                raise TimeoutError("lab run exceeded %.0f s at step %d" % (SITE["BENCH_RUN_TIMEOUT_S"], s["i"]))
            if s.get("argv"):
                self._exec(s["argv"], rdir, "step %d %s" % (s["i"], s["op"]))
            elif s.get("action") == "power_cycle":
                self._power_cycle(rdir)
            elif s.get("action") == "idle":
                time.sleep(s["idle_ms"] / 1000.0)
            time.sleep(s["pause_after_us"] / 1e6)      # ~0.1 ms resolution; finer spacing belongs in fio / SPDK

    def _power_cycle(self, rdir):
        if not (SITE["BENCH_PDU_OFF"] and SITE["BENCH_PDU_ON"]):
            raise NotImplementedError("power_cycle needs BENCH_PDU_OFF / BENCH_PDU_ON (controllable power switch commands)")
        bdf = SITE["BENCH_BDF"]
        self._exec(["sh", "-c", "echo 1 > %s" % shlex.quote("/sys/bus/pci/devices/%s/remove" % bdf)], rdir, "pci remove")
        self._exec(shlex.split(SITE["BENCH_PDU_OFF"]), rdir, "power off")
        time.sleep(SITE["BENCH_POWER_OFF_S"])
        self._exec(shlex.split(SITE["BENCH_PDU_ON"]), rdir, "power on")
        deadline = time.time() + SITE["BENCH_ENUM_TIMEOUT_S"]
        while not os.path.exists(SITE["BENCH_CTRL"]):
            if time.time() > deadline:
                raise TimeoutError("drive did not come back within %.0f s after the power cycle" % SITE["BENCH_ENUM_TIMEOUT_S"])
            self._exec(["sh", "-c", "echo 1 > /sys/bus/pci/rescan"], rdir, "pci rescan")
            time.sleep(1.0)

    def _preflight(self):
        """Safety before every real run: scratch namespace not mounted, the right drive model."""
        ns = SITE["BENCH_NS"]
        if not ns.startswith("/dev/nvme"):
            raise BenchRefused("BENCH_NS must be an NVMe namespace device, got %r" % ns)
        with open("/proc/mounts") as f:
            if any(line.split()[0].startswith(ns) for line in f if line.strip()):
                raise BenchRefused("%s (or a partition of it) is mounted: the bench only uses an empty scratch namespace" % ns)
        if self.device_model:
            r = subprocess.run([SITE["NVME"], "id-ctrl", SITE["BENCH_CTRL"], "--output-format=json"],
                               capture_output=True, text=True, timeout=SITE["BENCH_STEP_TIMEOUT_S"])
            mn = (json.loads(r.stdout or "{}").get("mn") or "").strip() if r.returncode == 0 else ""
            if mn != self.device_model.strip():
                raise BenchRefused("device model %r is not the expected %r (test precondition device_model)" % (mn, self.device_model))

    def _run_engine_site(self, csv_path, out_dir, dmesg):
        """testgen.run_engine with the site's namespace size and the captured host kernel log."""
        import shutil
        if os.path.isdir(out_dir):
            shutil.rmtree(out_dir)
        os.makedirs(out_dir, exist_ok=True)
        cmd = [sys.executable, "-m", "pcie_isolate.cli", "run", "--csv", csv_path, "--out", out_dir, "--backend", "dry-run",
               "--nsze", SITE["BENCH_NSZE"] or testgen.NSZE]
        if dmesg:
            cmd += ["--dmesg", dmesg]
        r = subprocess.run(cmd, cwd=testgen.ENGINE_DIR, capture_output=True, text=True, timeout=SITE["BENCH_ANALYSE_TIMEOUT_S"])
        p = os.path.join(out_dir, "incidents.json")
        if r.returncode != 0 or not os.path.exists(p):
            return {"error": (r.stderr or r.stdout)[-500:], "incidents": []}
        with open(p) as f:
            return {"error": None, "incidents": json.load(f)}

    @staticmethod
    def _dmesg_lines():
        r = subprocess.run(["dmesg", "-x"], capture_output=True, text=True, timeout=30)
        return r.stdout.splitlines() if r.returncode == 0 else []

    def _dmesg_since(self, before, path):
        after = self._dmesg_lines()
        new = after[len(before):] if after[:len(before)] == before else after
        with open(path, "w") as f:
            f.write("\n".join(new) + ("\n" if new else ""))
        return path

    # ------------------------------------------------------------------ SITE-SPECIFIC hooks (raise until implemented)
    def _switch_firmware(self, fixed):
        """Make sure the drive runs the requested firmware before the run: fixed=False -> the known-bad build,
        fixed=True -> the fixed build. Typical ways: two drives of the same model (one per firmware) selected by a
        switch; or both builds pre-loaded in firmware slots and activated by the LAB (outside this hook, never by a
        procedure). Verify with `nvme id-ctrl` field "fr" against BENCH_FW_KNOWN_BAD / BENCH_FW_FIXED and raise when
        it does not match - a run on the wrong firmware silently corrupts the regression verdict."""
        raise NotImplementedError("SITE-SPECIFIC _switch_firmware(fixed=%s): select / verify the %s firmware "
                                  "(see deploy/BENCH_INTEGRATION.md, 'Known-bad and fixed bench')"
                                  % (fixed, "fixed" if fixed else "known-bad"))

    def _start_capture(self, run_id, rdir):
        """Arm the PCIe protocol analyzer: trigger at the start of the stimulus (or an external trigger pulsed right
        before step 0), about 30 % pre-trigger, window = stimulus + 2 s. Return a handle for _stop_and_export_capture."""
        raise NotImplementedError("SITE-SPECIFIC _start_capture: arm your analyzer (vendor command line or API) and "
                                  "return a handle (see deploy/BENCH_INTEGRATION.md, 'Analyzer capture')")

    def _stop_and_export_capture(self, handle, out_csv):
        """Stop the capture and export it as the 113-column CSV (the same column set and DATA in hex as the stage-1
        input); return out_csv. Raise when the export is empty or has another column count."""
        raise NotImplementedError("SITE-SPECIFIC _stop_and_export_capture: stop the analyzer and export the "
                                  "113-column CSV to %s" % out_csv)

    def _site_inject(self, spec):
        """Optional jammer: arm a fault for the following runs. spec = {"kind": "tlp_corrupt", "rate": 1e-4} |
        {"kind": "delay_completion", "us": 500} | {"kind": "force_recovery", "every_ms": 50}."""
        raise NotImplementedError("SITE-SPECIFIC jammer inject(%r)" % (spec,))

    def _site_clear_faults(self):
        """Optional jammer: disarm every fault."""
        raise NotImplementedError("SITE-SPECIFIC jammer clear_faults()")


# ====================================================================== run one procedure by hand
def _main(argv=None):
    import argparse
    ap = argparse.ArgumentParser(description="Run (or with DRY_RUN=1 only print) one procedure on the bench.")
    ap.add_argument("--card", required=True, help="error type (atlas card id) the run should isolate, e.g. C-16")
    ap.add_argument("--expected", default="", help="comma-separated ambiguity group (default: the card)")
    ap.add_argument("--scenario", required=True, help="procedure as JSON text or a path to a JSON file")
    ap.add_argument("--fixed", action="store_true", help="run on the fixed firmware")
    ap.add_argument("--detect", help="only run the analyser on this capture CSV and print the findings")
    a = ap.parse_args(argv)
    sc = json.load(open(a.scenario)) if os.path.exists(a.scenario) else json.loads(a.scenario)
    b = HardwareBench(a.card, None, [x for x in a.expected.split(",") if x] or None, a.fixed, None, 0)
    if a.detect:
        print(json.dumps(b.detect(a.detect), indent=1))
        return 0
    res = b.run(sc)
    print(json.dumps({k: v for k, v in res.items() if k != "findings"}, indent=1, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(_main())
