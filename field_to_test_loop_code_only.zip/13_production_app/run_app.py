#!/usr/bin/env python3
"""Start the Field-to-Test Loop application on this laptop.

    python3 run_app.py                 # http://127.0.0.1:8077
    python3 run_app.py --port 9000
    python3 run_app.py --config config/app_config.json --standin   # no LLM, deterministic (demo / tests)
"""
import argparse
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "app"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=os.path.join(HERE, "config", "app_config.json"))
    ap.add_argument("--port", type=int, default=None)
    ap.add_argument("--standin", action="store_true", help="force the deterministic stand-in LLM (no model calls)")
    a = ap.parse_args()
    from server import create_app, load_config   # noqa: E402
    cfg = load_config(a.config)
    if a.standin:
        cfg["llm"]["backend"] = "standin"
    port = a.port or cfg["server"].get("port", 8077)
    app = create_app(cfg, HERE)
    print("Field-to-Test Loop  ->  http://%s:%d   (local only; Ctrl-C to stop)" % (cfg["server"].get("host", "127.0.0.1"), port))
    app.run(host=cfg["server"].get("host", "127.0.0.1"), port=port, threaded=True, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
