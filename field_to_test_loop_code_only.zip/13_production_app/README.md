# Field-to-Test Loop - production application (stage 1 + stage 2)

One local full-stack application: give it the path of a 113-column PCIe/NVMe analyzer CSV and it
1. **isolates every defect** in the trace (stage 1: streaming analysis, host-evidence fusion for the silent ones,
   isolation to packets, atlas card, evidence rows) and asks the LLM to **confirm** each isolated defect
   (verdicts of already-seen patterns come from a cache, no model call),
2. for every confirmed defect runs **stage 2**: looks the defect up in the procedural knowledge database and shows the
   admin the **stored procedure (what was saved earlier, with its feedback metadata) next to the LLM-generated
   proposal** - or only the generated one when nothing is stored - then takes the admin's action (accept / revise /
   reject / rerank / promote / ... 26 actions), updates the weights and the graph, searches for the reproducing
   command sequence + timing under the first-level-triage limits, verifies it in the **closed loop** (procedure ->
   capture -> the same stage-1 detector -> same card isolated; fixed firmware must stay silent) and files the
   **regression test**,
3. shows **how long every step took** (per stage-1 step, per incident: retrieval+LLM, search, verification) in the
   report, and lets the admin browse the database (events, causes, procedures, tests, lessons, LLM verdict cache,
   undo).

No LLM is trained or fine-tuned anywhere; learning = counts and events in SQLite (the optional PPO optimiser fits a small
policy inside one search and discards it).

## Read first

`docs/FINAL_WORKFLOW_AND_ALGORITHMS.html` - the final workflow as block diagrams, how an error is recognised from the
packets, how the 485 errors come about (with the real CSV rows of every card next to how it should look), the
knowledge database as the RAG store, retrieval and weight-update formulas, the reproduction search, the test contract,
and three worked examples (visible / partly visible / not visible). `docs/HOW_DEFECTS_ARE_DETECTED.html` is stage 1's own account.

## Run it on your laptop

```bash
cd 13_production_app
python3 run_app.py                 # open http://127.0.0.1:8077
python3 run_app.py --standin       # no LLM at all (deterministic stand-in): demo / tests
python3 tests/test_app.py          # end-to-end + component tests (4 tests, ~90 s, stand-in LLM, no network)
```

Requirements (`deploy/requirements.txt`): Python >= 3.10, `flask`, `numpy` (stage 1), `anthropic` (for `llm.backend = sdk`;
without it stage 2 falls back to the stand-in), `pytest` (only to run the generated regression tests). Install and
deployment: `README_FIRST.md` and `deploy/AGENT_INSTRUCTIONS.md`.
The `claude` CLI (Claude Code login) is enough for the default LLM backend; no API key is needed then.

## Configure the LLM (used at five points, all read-and-propose, all verified by code; never trains)

`config/app_config.json` (or the **Settings** tab; with `server.lock_endpoint: true`, the production setting, `backend`,
`base_url`, `api_key_env` and `tools` can only be changed in the file: stop the service, edit, start):

| field | meaning |
|---|---|
| `llm.backend` | `cli` = local `claude` login (no key) · `sdk` = Anthropic API or a gateway (`base_url`, key from `api_key_env`) · `openai-compat` = any `/v1/chat/completions` endpoint (`base_url`, `model`; stage-1 confirmation then runs without a model) · `standin` = no model · `auto` |
| `llm.model`, `llm.effort` | e.g. `claude-haiku-5-5`, `low` |
| `llm.batch` | stage-1 confirmation through the Message Batches API (sdk only; half price, results within minutes to hours) |
| `llm.capture_check` | one extra call per run: "can this capture show what we are looking for?" |

The five call sites: the stage-1 confirmation per defect (cached by pattern), the stage-1 capture check (optional,
`llm.capture_check`), the stage-2 digest / presentation, the stage-2 proposal (the seed of the search) and the test
composition (*Generate test case*).

1. **Stage 1** - after the engine isolates a defect, the evidence rows and findings go to the model, which answers
   through a JSON schema (verdict, error type, responsible party, cited packets; no self-rated confidence number is used). The `claude` CLI backend runs
   with `--effort low` and a cached static prompt prefix; the SDK backend uses `output_config.effort = low`, prompt
   caching and optionally batches. **Pattern cache:** the verdict is stored under (card, first-abnormal rule,
   pattern, layer, rule set, evidence-row kind sequence, model, prompt version); a later incident with the same key
   gets the stored verdict without a call.
2. **Stage 2** - the admin card's digest (headline, mechanism, decisive packets, recommended sequence, differences
   vs the stored procedure, risks) and, when a search is needed, the proposal (commands, timing, parameter ranges).
   Everything the model emits is checked by code (cited packets exist, commands allowed, ranges). The model never
   changes a ledger status.

In your environment: put the final API URL, model name and key variable in the config file (start from
`deploy/config.production.example.json`; stop the service, edit, start) - nothing else changes.

## The flow (your architecture diagram -> this app)

| Diagram | Here |
|---|---|
| Input trace -> Trace Normaliser -> LLM (abnormalities) | **Run** tab: `analyze` -> `fuse` (dmesg / tool records) -> `isolate` -> pattern cache -> `review` (LLM confirms) -> `report` |
| Procedural Graph Lookup -> return stored data (procedure, params) | **Incident** tab, *Look up database + LLM proposal*: hybrid retrieval over the knowledge graph, "seen before" verdict, stored procedure with timing, feedback posterior, tests, test preview |
| LLM generates the baseline (create params) | the generated column on the same card |
| LLM guidance (RL phase): score > 0.9 three times consecutively = optimal; > 10 min = fail | `stage2.optimal_consecutive` (default 3) and `stage2.time_budget_s` (default 600). The search confirms a reproduction with a Wilson 95 % lower bound >= 0.5 over 8 confirm runs on the device model; the 0.9 x 3 rule is applied on the bench in the closed loop (each verification run gets a signature score; optimal = 3 consecutive runs above 0.9; the result shows the score series). At the 600 s limit only the search stops; verification completes and the result is flagged *triage_timeout* (first-level triage time exceeded). Not evaluated for workload (ADK/PCMark) defects, which the synthetic bench cannot run |
| RL agent (PPO) + hardware test bench | `stage2.optimizer`: the training-free bandit (default; benchmark winner: hill-climb + archive restarts + bandit over mutations, Wilson confirmation, ddmin) or PPO (selectable; neither trains an LLM) + bench (`synthetic` or your hardware through `app/bench_hook.py`) |
| Admin dashboard: +1 -> regression test script, enrich graph, weight up; -1 -> restart, record failed trials, weight down | the action buttons: `accept` credits the path and continues to search / tests; `reject` blames only that item; `revise`, `rerank`, `not_reproducible`, `promote` / `deprecate` / `delete_approve` (second admin), `undo`, ...; `restart_failed` (-1) records the failed trial (b+1 and tb+1 on the cause edge, or r = 0 on the procedure edge, plus a lesson) and restarts the search |

## Phases (what the admin sees, in order)

1. **Run stage 1** - CSV path (+ optional host evidence). While it runs, an animated progress ring fills with the
   percentage, the current step is named in plain words, live counters show rows read of the CSV (with an estimate of
   the total), findings so far, defects isolated and LLM confirmations, and an activity stream lists every event.
   Nothing about stage 2 is shown yet; the other steps in the sidebar are locked (the sidebar shows the stage-1
   percentage, later the stage-2 progress). At 100 % the same page shows **Isolation of defects**: one row per
   defect (card, title, status, LLM verdict); expanding it gives the summary - which of the 485 errors, first
   abnormal packet, the rules that prove it, who caused it, whether outside evidence was needed and from which
   source, what the LLM returned - and *Open the full record* opens a dedicated page (`/defect`) with eight
   sections: which error, where, how it is proven (rules with their rows and the acceptance checks), outside
   evidence (needed? source, why that source), what the LLM returned, why it happens and the fix, stage 2 for this
   defect, and the admin's earlier decisions on this error.
2. **Isolated defects** - unlocked when stage 1 completes: every defect with the engine verdict and the LLM
   confirmation. A *Continue to stage 2* button appears.
3. **Stage 2 review** - opens with a gate that explains what stage 2 does; **Start stage 2** (the admin's explicit
   decision) prepares every defect (database lookup + LLM proposal, cached) and then shows the review queue. Each
   defect is one **manager decision view** (`app/static/js/decision.js`, spec in
   `research_notes_v3/manager_decision_view.md`): a three-line *bottom line* (what the packets showed, what is
   proposed, your decisions so far); *what the packets showed* as a host <-> device flow graph (time top to bottom,
   delta-t per row, first abnormal packet shaded, gaps drawn, "show the full exchange" as the only disclosure);
   *proposed reproductions* as ranked cards - plain-language title, command chips with the spacing, tunable timing
   chips, one provenance line (saved by whom, reproduced in at least X % of lab runs with a likelihood word, judged
   +p/-n, tests on file; or "proposed now by the AI reviewer, fresh model call") and three outcome buttons: **Correct** (runs
   it in the lab, writes the test script), **Needs changes** (Stored vs Your version in place, changes highlighted,
   "Save corrected version" validates it by execution before it is stored under the manager's name), **Not
   correct** (collapses to a stub with Undo and reason chips; optionally retire from the database with a second
   admin). Cards are ranked by drag handle or by the "..." menu (move to top / up / down / bottom - the no-drag
   alternative), which records a ranking signal only. "Save decisions" records removals and ranking together.
   **Generate test case from the stored knowledge**: when the database holds correct / optimised sequences for the
   error, one button asks the LLM to compose up to three test variants from them (robust recreation, timing boundary,
   different path); code validates each, each runs in the lab, only the ones that reproduce go through the closed loop
   and are filed with their sources and rationale (`manifest.json` → `composition`); nothing is auto-approved.
   Everything engineer-level (LLM digest, all 26 actions, candidates, raw rows, history, the JSON editor) is behind
   **All details**. The gate is enforced by the API (409 before stage 1 is done or stage 2 is started);
   `GET /api/runs/<run>/incidents/<inc>/solutions` is the endpoint behind the cards.
4. **Report & tests** - per-stage timings, per-defect results, the generated suite.

## Design rationale (research-backed)

Two notes drive the screens: `claude_research_report/.../research_notes_v3/ux_for_non_technical_admins.md` (progress
indicators and the labour illusion, progressive disclosure, how Sentry / GitHub code scanning / Wireshark present an
alert, review workflows and history panels, confirmation vs undo, steppers) and `visual_design_system.md` (Primer light
palette with every text/background pair measured >= 4.5:1, Carbon type scale 14/20 body - 12/16 caption - 16/24
section - 24/32 title - 32/40 counters with tabular figures, 8 px spacing grid, 256 px sidebar, 320 px list pane,
40 px rows, Material-3 ring proportions, WCAG 2.4.13 focus rings, Carbon motion durations, reduced-motion fallbacks).
What that produced:
- a linear five-step tracker with the live state under each step, later steps locked until the previous phase ends;
- one hero ring with the whole-run percentage (capped at 99 % until the report exists), the step named in plain
  words, a step list with real live counts, an ETA only after 10 % and padded, a staleness guard, cancel with a
  specific confirmation;
- a fixed three-word status vocabulary - Confirmed / Suspect / Needs evidence - always colour + icon + word;
- results as summary tiles + expandable rows + a full-record page in reading order: what this means, where, why it
  was flagged (rule checklist with values), evidence rows on the page, what usually fixes it, related errors,
  stage 2, history;
- the review screen as list-detail with the manager decision view (`manager_decision_view.md`: answer-first
  bottom line, two disclosure levels, Wireshark-style flow graph, outcome-labelled verdict buttons with printed
  shortcuts, WCAG 2.5.7 no-drag ranking alternative, in-place Stored vs Your version editing, removal as an undoable
  stub instead of a dialog, likelihood words next to their numbers), a callout when an earlier decision on the same
  error was negative, nothing pre-selected, a "what happens next" receipt and an undo in the toast.

## What you see in the report

Stage 1: seconds per step (analyze, fuse, isolate, pattern cache, review, report, capture check) and the LLM stats
(reviewed, model calls, from cache, confirmed, cost). Stage 2 per incident: seen-before verdict, stored / generated
present, action, mode (reuse / adapt / generate), status, trials, reproduction bound, closed-loop hits (known-bad vs
fixed), admitted test, optimal flag, and the seconds for retrieval+LLM, search and verification. Totals per stage and
overall. `runs/<run>/report.md` and `report.json`; the engine's own `isolation_report.md` is next to them.

## Layout (modular)

```
run_app.py                 start the server          config/app_config.json   settings (editable in the UI)
app/server.py              Flask app factory, pages / and /db
app/services.py            shared services: jobs, caches, stage-2 service, path safety, run/queue helpers
app/api/config_api.py      /api/config                 app/api/runs_api.py      /api/runs (stage 1, run cache, files)
app/api/stage2_api.py      incidents, review queue, prepare-all, present (cached), act, state
app/api/db_api.py          /api/db/* overview, tables, signature tree, verdict cache, undo
app/api/misc_api.py        jobs, report, test suite, synthetic samples
app/jobs.py                background jobs + timing spans     app/stage1_runner.py  stage 1 as a job
app/pattern_cache.py       LLM verdict cache                  app/stage2_service.py stage 2 service
app/report.py              report builder                     app/bench_hook.py     hardware bench template
app/static/index.html      the workflow (sidebar: Run -> Isolated defects -> Stage 2 review -> Report -> Settings)
app/static/db.html         the database interface (signatures & procedures tree, tables, event log + undo, caches)
app/static/js/             one module per page: main, run, incidents, review, decision, defect, report, settings, db; api.js shared
stage1/                    the defect-isolation engine        stage2/               the stage-2 package
data/                      atlas cards, detection spec, trace generator
db/ runs/ suite/ samples/  runtime data (created on first use)
tests/test_app.py          end-to-end API test + component tests
```

## Caches (nothing already processed is computed twice)

| Cache | Key | Effect |
|---|---|---|
| Run cache | CSV path + size + mtime, host-evidence files, nsze, model/backend/effort | the same capture opens the finished run instead of re-running stage 1 ("re-run even if cached" overrides) |
| Pattern cache | card, first-abnormal rule, pattern, layer, rule set, evidence-row kinds, model, prompt version | stage-1 verdict reused without a model call (shown as *cached* in the tables) |
| Presentation cache | run + incident | the stage-2 card (lookup + LLM digest) is served from disk until the admin acts; *Prepare stage 2 for all* builds them in the background |
| LLM prompt cache | prompt hash | identical prompts never hit the model twice |

## Attaching your hardware bench

Implement `run(scenario)` and `detect(capture) -> findings` in `app/bench_hook.py` and set `stage2.bench = "hook"`
(restart the app after changing it). `run()` returns a dict (trace path, isolated findings, stage, closeness,
reproduced, cost_s), not a path: see the docstring of `app/bench_hook.py`, the template `deploy/bench_hook_template.py`
and the guide `deploy/BENCH_INTEGRATION.md`. With `stage2.search_on = "bench"` every search trial runs on the hardware;
with `"model"` the search runs on the device model and only the verification runs on the bench. Generated scripts are download-only: the app never executes
shell/fio text it produced.

## Safety and limits

- Binds to 127.0.0.1, no authentication of its own (put an authenticating reverse proxy in front, `deploy/DEPLOY.md`).
  CSV paths must lie under `paths.allowed_csv_roots` plus the application folder itself.
- Two-person actions (`promote`, `deprecate`, `delete_approve`) are checked server-side as a comparison of the typed
  names (approver != requester). The app has no login, so the rule is only as strong as access control: run it behind
  an authenticating reverse proxy (`deploy/DEPLOY.md`). Set `server.lock_endpoint: true` in production so the Settings
  page cannot redirect the API key or widen the readable folders.
- The synthetic bench measures the pipeline (hidden trigger model + generator + the real engine), not device physics.
- `stage1/` is a copy of `10_defect_isolation_engine` (unchanged); `stage2/` is a copy of
  `Database_Implmentation/final_implementation` (v3). Research and measured results: `Database_Implmentation/claude_research_report/`.

## Inputs, rules and the admin's acknowledgements (architecture diagram)

- **Input**: the Run step takes a PCIe analyzer CSV. A workload-result artifact (the `boot_etl` ADK pipeline's
  `stage1.json`, or any JSON in the shape documented in `app/workload_import.py` for PCMark) is accepted through the API
  only (`POST /api/runs` with `kind: "workload"`); its abnormalities become defects with a failure signature, stage 2
  looks them up, writes the baseline and files a proposed test for the hardware bench.
- **Failure signature** (`stage1_adapter.signature_of`) on every defect, in the review panel and in every test manifest.
- **The two rules** (`stage2/loop_rules.py`): the search itself confirms a reproduction with a Wilson 95 % lower bound >= 0.5
  over 8 confirm runs on the device model; the diagram's "test score > 0.9 three times consecutively" is applied on the bench
  in the closed loop (each verification run gets a signature score; optimal = 3 consecutive runs above 0.9; the result shows
  the score series). The 10-minute rule bounds each stage-2 search (status `triage_timeout`: the search stops, verification
  completes) and is reported per stage-1 run in the KPI. Neither rule is evaluated for workload (ADK/PCMark) defects because
  the synthetic bench cannot run a workload; they apply once the hardware bench runs it.
- **Negative Ack (−1)**: "Record failed trial (−1) and restart" after a search that found nothing (`restart_failed`). On a
  cause target: b+1 on the cause edge (the ranking weight goes down) and tb+1 (technical count) plus a lesson; on a procedure
  target: r = 0 on the procedure edge; then the search restarts on another random stream.
- **Stress ascent** (every confirmed reproduction): each timing value is pushed in its stressful direction while the
  defect still appears in 2 of 3 lab runs (`Optimizer.stress_ascent`, budget `stage2.stress_trials` = 30); the hardest
  version that still triggers it is checked on known-bad / fixed firmware and filed as a second regression test
  (manifest key `stress`). This is the statement's "most stressful trigger conditions → executable test scripts".
- **Vulnerability sweep**: "Sweep the neighbourhood" around a reproducing procedure (`sweep`): up to 15 variants (10 timing,
  4 power states, 1 burst; an "idle 500 ms" variant when the base has no idle). `app/bench_hook.py` declares optional
  `inject(spec)` and `clear_faults()`: when `inject` exists, jammer variants run through the closed loop (fault armed on the
  known-bad runs, cleared after) and are filed like the other variants; on the synthetic bench they are reported "hardware
  bench only".
- **KPI report**: `/api/kpi` and the Report page (triage rule, automatic isolation, known-signature leakage = 0, tests
  authored automatically, saving against `kpi.manual_triage_minutes_per_run` when you set it).
- **Optimiser**: `stage2.optimizer = "bandit"` (default) or `"ppo"`; **web search for the baseline**: `llm.tools = ["web_search"]`.

## Tests

| Command (from this folder) | Takes | What it proves |
|---|---|---|
| `./run_tests.sh` (runs `tests/test_app.py`) | ~90 s | 4 tests: the end-to-end HTTP test with the stand-in LLM, the workload-artifact test, and two component tests that run the 24 stage-2 unit tests (`stage2/tests_v3.py` 16 + `tests_v4.py` 8) and the stage-1 engine fixtures (14) |
| `python3 tests/exercise_loop.py` (server running) | 10–17 min | live checks with the real LLM: all checks pass; the count grows with the database (60 on the latest run): tests admitted, recurrence reused, every admin signal verified in the database; the final report is `runs/exercise_report.md` |
| `python3 tests/ui_smoke.py` (server running, Chrome installed) | ~10 min | 21 checks (21/21 passed on the last run, 27 Oct 2026, `runs/ui_smoke/ui_smoke_report.md`) driving the real review page: ranking, Not correct, Needs changes (validated by execution), Correct (regression guard, test script), Generate test case (LLM-composed variants), Sweep the neighbourhood; screenshots in `runs/ui_smoke/` |

`README_FIRST.md` is the reading guide (installers and agents: `deploy/AGENT_INSTRUCTIONS.md`; operators and managers:
`docs/OPERATOR_AND_BACKEND_GUIDE.html`). The full documentation package adds `docs/START_HERE.md`, the reading guide
for the whole project.

## Metadata kept with every run and decision

The screen requires the operator's name to analyse a trace (the API accepts an empty name) and records it with the run; each stage-2 decision records the
name in "Your name". Every knowledge-base event carries a timestamp and the run, defect, device and firmware it
belongs to. The device is read from the trace (NVMe Identify Controller: model, serial, firmware revision; PCIe
configuration header: vendor/device id) or typed by the operator. Procedures and regression tests are filed per
device model; the test id carries the device. See docs/CHANGES_2026-10-27.md.
