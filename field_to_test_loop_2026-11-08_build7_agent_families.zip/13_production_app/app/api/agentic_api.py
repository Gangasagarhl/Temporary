"""The agent families' web API (the /agents page).

  GET  /api/agents/state                          settings, projects, open reviews, recent runs
  GET  /api/agents/settings | PUT                 runtime (claude-code | http | standin), model, slices, connectors
  GET  /api/agents/inventory?folder=              the CSVs of a folder, as Family 1's Director sees them
  POST /api/agents/projects                       {admin, name, folder, refs[], rea, upload_id} -> project
  GET  /api/agents/projects/<pid> | PUT
  POST /api/agents/projects/<pid>/family1         start Family 1 (data dictionaries)
  POST /api/agents/projects/<pid>/family2         start Family 2 (hierarchy)
  GET  /api/agents/runs?project=                  runs, newest first
  GET  /api/agents/runs/<rid>                     the run with its steps, reviews, evidence and whether its worker is alive
  POST /api/agents/runs/<rid>/retry | /stop
  GET  /api/agents/reviews?state=open
  POST /api/agents/reviews/<id>/decide            {decision: approve|change|reject, admin, comment, edits}
  POST /api/agents/reviews/<id>/ask               {message, admin} -> an answer about what is being reviewed
  GET  /api/agents/rules                          the sidebar tree: sections, levels, items
  POST /api/agents/rules                          {section, level, name, description, admin, project} -> new item + its first draft run
  GET  /api/agents/rules/<sec>/<lvl>/<id>         the rule, in plain words, its code, its versions, its last run
  POST /api/agents/rules/<sec>/<lvl>/<id>/edit    {message, project} -> a draft run (Rule writer, then review)
  POST /api/agents/rules/<sec>/<lvl>/<id>/proceed {project, upload_id?} -> a run of the approved rule
  GET  /api/agents/file?path=                     an exported file (only under knowledge/exports)
"""
import json
import os
import sys
import threading
import time

from flask import Blueprint, jsonify, request, send_file

from . import svc

APP = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, APP)
from agentic import core, family1, family2, family3   # noqa: E402

bp = Blueprint("agentic", __name__)
_LOCK = threading.Lock()
DEFAULTS = {"runtime": "claude-code", "model": "", "slices": 6, "connectors": {},
            "references": [os.path.join(os.path.dirname(APP), "09_defect_isolation_research", "research_notes")]}


def settings(s):
    a = dict(DEFAULTS)
    a.update({k: v for k, v in (s.cfg.get("agentic") or {}).items() if not k.startswith("_")})
    if not a.get("references"):            # empty in the configuration = the project's own research notes
        a["references"] = DEFAULTS["references"]
    return a


def engine():
    s = svc()
    with _LOCK:
        eng = getattr(s, "agentic_engine", None)
        if eng is None:
            a = settings(s)
            store = core.Store(os.path.join(s.root, "db", "agentic.sqlite"))
            runner = core.AgentRunner(os.path.join(s.root, "runs", "agentic"), runtime=a["runtime"],
                                      llm_getter=lambda: getattr(getattr(s, "s2", None), "llm", None), model=a.get("model") or None,
                                      http_model=(s.cfg.get("llm") or {}).get("model"), claude_path=a.get("claude_path"))
            eng = core.Engine(store, {"family1": family1, "family2": family2, "rule_draft": family3, "rule_run": family3}, runner,
                              services=s, cfg=s.cfg)
            s.agentic_engine = eng
            eng.resume_all()
        return eng


def admin_of(body):
    return (body.get("admin") or "").strip() or "admin"


def _project(pid):
    p = engine().store.one("SELECT * FROM project WHERE id=?", (pid,))
    if p:
        p["refs"] = core.jload(p["refs"], [])
    return p


@bp.get("/api/agents/state")
def state():
    eng = engine()
    s = svc()
    projects = eng.store.all("SELECT * FROM project ORDER BY updated DESC, id DESC LIMIT 50")
    for p in projects:
        p["refs"] = core.jload(p["refs"], [])
    runs = eng.store.all("SELECT id, project, kind, target, state, created, updated, heartbeat, summary FROM run ORDER BY id DESC LIMIT 30")
    for r in runs:
        r["steps"] = eng.store.all("SELECT state, COUNT(*) AS n FROM step WHERE run=? GROUP BY state", (r["id"],))
        r["worker_alive"] = bool(eng.threads.get(r["id"]) and eng.threads[r["id"]].is_alive())
    reviews = eng.store.all("SELECT r.id, r.run, r.title, r.created, run.kind, run.target FROM review r JOIN run ON run.id=r.run WHERE r.state='open' ORDER BY r.id")
    return jsonify({"settings": settings(s), "projects": projects, "runs": runs, "open_reviews": reviews})


@bp.get("/api/agents/settings")
def get_settings():
    a = settings(svc())
    a["claude_found"] = core.AgentRunner.find_claude(a.get("claude_path"))
    return jsonify(a)


@bp.put("/api/agents/settings")
def put_settings():
    s = svc()
    body = request.get_json(force=True) or {}
    a = s.cfg.setdefault("agentic", {})
    if "runtime" in body:
        if body["runtime"] not in core.AgentRunner.ORDER:
            return jsonify({"error": "runtime must be one of %s" % ", ".join(core.AgentRunner.ORDER)}), 400
        a["runtime"] = body["runtime"]
    for k in ("model", "slices", "connectors", "references", "claude_path"):
        if k in body:
            a[k] = body[k]
    path = os.path.join(s.root, "config", "app_config.json")
    try:
        cfg = json.load(open(path))
        cfg["agentic"] = a
        with open(path, "w") as fh:
            json.dump(cfg, fh, indent=2)
    except OSError as e:
        return jsonify({"error": "could not save the configuration: %s" % e}), 500
    eng = engine()
    eng.runner.runtime = a.get("runtime", eng.runner.runtime)
    eng.runner.model = a.get("model") or None
    return jsonify(settings(s))


@bp.get("/api/agents/inventory")
def inventory():
    folder = request.args.get("folder") or ""
    if not os.path.isdir(folder):
        return jsonify({"error": "not a folder: %s" % folder}), 400
    return jsonify({"folder": folder, "files": family1.inventory(folder)})


@bp.post("/api/agents/projects")
def create_project():
    body = request.get_json(force=True) or {}
    folder = (body.get("folder") or "").strip()
    if not os.path.isdir(folder):
        return jsonify({"error": "the input folder does not exist: %s" % folder}), 400
    if not family1.inventory(folder):
        return jsonify({"error": "the folder holds no CSV file: %s" % folder}), 400
    refs = [r.strip() for r in (body.get("refs") or settings(svc())["references"]) if r and r.strip()]
    bad = [r for r in refs if not os.path.isdir(r)]
    if bad:
        return jsonify({"error": "these reference folders do not exist: %s" % ", ".join(bad)}), 400
    t = time.time()
    pid = engine().store.exec("INSERT INTO project (admin, name, folder, refs, rea, upload_id, notes, created, updated) VALUES (?,?,?,?,?,?,?,?,?)",
                              (admin_of(body), (body.get("name") or os.path.basename(folder.rstrip("/"))).strip(), folder, json.dumps(refs),
                               (body.get("rea") or "").strip(), (body.get("upload_id") or "").strip() or None, body.get("notes") or "", t, t))
    return jsonify(_project(pid))


@bp.get("/api/agents/projects/<int:pid>")
def get_project(pid):
    p = _project(pid)
    return jsonify(p) if p else (jsonify({"error": "no such project"}), 404)


@bp.put("/api/agents/projects/<int:pid>")
def put_project(pid):
    body = request.get_json(force=True) or {}
    p = _project(pid)
    if not p:
        return jsonify({"error": "no such project"}), 404
    for k in ("admin", "name", "rea", "upload_id", "notes"):
        if k in body:
            engine().store.exec("UPDATE project SET %s=?, updated=? WHERE id=?" % k, (body[k], time.time(), pid))
    if "refs" in body:
        engine().store.exec("UPDATE project SET refs=?, updated=? WHERE id=?", (json.dumps(body["refs"]), time.time(), pid))
    return jsonify(_project(pid))


def _start(pid, kind, target="", params=None):
    if not _project(pid):
        return jsonify({"error": "no such project"}), 404
    rid = engine().start(pid, kind, target, params or {})
    return jsonify({"run": rid, "view": engine().view(rid)})


@bp.post("/api/agents/projects/<int:pid>/family1")
def start_family1(pid):
    return _start(pid, "family1", "data dictionaries")


@bp.post("/api/agents/projects/<int:pid>/family2")
def start_family2(pid):
    return _start(pid, "family2", "hierarchy")


@bp.get("/api/agents/runs")
def list_runs():
    pid = request.args.get("project")
    q, a = "SELECT id, project, kind, target, state, created, updated, summary FROM run", ()
    if pid:
        q, a = q + " WHERE project=?", (int(pid),)
    return jsonify(engine().store.all(q + " ORDER BY id DESC LIMIT 100", a))


@bp.get("/api/agents/runs/<int:rid>")
def get_run(rid):
    v = engine().view(rid)
    return jsonify(v) if v else (jsonify({"error": "no such run"}), 404)


@bp.post("/api/agents/runs/<int:rid>/retry")
def retry_run(rid):
    engine().retry(rid)
    return jsonify(engine().view(rid))


@bp.post("/api/agents/runs/<int:rid>/stop")
def stop_run(rid):
    engine().stop(rid, admin_of(request.get_json(force=True) or {}))
    return jsonify(engine().view(rid))


@bp.get("/api/agents/reviews")
def list_reviews():
    st = request.args.get("state", "open")
    return jsonify(engine().store.all("SELECT r.*, run.kind, run.target, run.project FROM review r JOIN run ON run.id=r.run WHERE r.state=? ORDER BY r.id", (st,)))


@bp.post("/api/agents/reviews/<int:rv>/decide")
def decide(rv):
    body = request.get_json(force=True) or {}
    try:
        engine().decide(rv, body.get("decision"), admin_of(body), body.get("comment") or "", body.get("edits"))
    except (ValueError, KeyError) as e:
        return jsonify({"error": str(e)}), 400
    r = engine().store.one("SELECT run FROM review WHERE id=?", (rv,))
    return jsonify(engine().view(r["run"]))


ASK_INSTRUCTION = """You are the agent whose work is under the admin's review. Answer the admin's question about it in
plain sentences, using only what is in CONTEXT (the review text, the step's output, the evidence). If CONTEXT does not
hold the answer, say so and say what would be needed."""


@bp.post("/api/agents/reviews/<int:rv>/ask")
def ask(rv):
    body = request.get_json(force=True) or {}
    msg = (body.get("message") or "").strip()
    if not msg:
        return jsonify({"error": "write a question"}), 400
    eng = engine()
    r = eng.store.one("SELECT * FROM review WHERE id=?", (rv,))
    if not r:
        return jsonify({"error": "no such review"}), 404
    step = eng.store.one("SELECT * FROM step WHERE id=?", (r["step"],))
    eng.store.exec("INSERT INTO chat (review, role, text, at) VALUES (?,?,?,?)", (rv, "admin:" + admin_of(body), msg, time.time()))
    history = eng.store.all("SELECT role, text FROM chat WHERE review=? ORDER BY id", (rv,))
    out = core.jload(step["output"], {}) or {}
    data = core.jload(r["data"], {}) or {}
    detail = {}
    # what is under review in full: the dictionary's rows (column, what the data shows, meaning, status, sources), the
    # strategy's joins, the rule draft, the result's first rows; not only the step's summary
    if out.get("dictionary_file") and os.path.exists(out["dictionary_file"]):
        detail["dictionary"] = json.load(open(out["dictionary_file"])).get("columns")
    for k in ("table", "joins", "draft", "strategy", "columns", "head"):
        if data.get(k) and k not in detail:
            detail[k] = data[k]
    ctx = {"review": r["body"], "under_review": detail, "step_output": out, "conversation": history,
           "evidence": eng.store.all("SELECT claim, kind, ref, quote, verified FROM evidence WHERE step=? LIMIT 200", (r["step"],))}
    try:
        ans, producer, _ = eng.runner.ask(r["run"], "ask_review_%d" % rv, ASK_INSTRUCTION + "\n\nQUESTION: " + msg, json.dumps(ctx, default=str)[:150000],
                                          '{"answer": "..."}', "answer",
                                          lambda: {"answer": "Stand-in answer (no model): the review says: " + r["body"][:600]})
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 502
    eng.store.exec("INSERT INTO chat (review, role, text, at) VALUES (?,?,?,?)", (rv, producer, ans["answer"], time.time()))
    return jsonify({"answer": ans["answer"], "producer": producer, "chat": eng.store.all("SELECT role, text, at FROM chat WHERE review=? ORDER BY id", (rv,))})


@bp.get("/api/agents/rules")
def rules_tree():
    return jsonify(family3.tree())


@bp.post("/api/agents/rules")
def add_rule():
    body = request.get_json(force=True) or {}
    sec, lvl, name = body.get("section"), body.get("level"), (body.get("name") or "").strip()
    if sec not in family3.SECTIONS or lvl not in family3.LEVELS or not name:
        return jsonify({"error": "give the section, the level and a name"}), 400
    r = family3.add_item(sec, lvl, name, body.get("description") or "", admin_of(body))
    out = {"rule": r}
    if body.get("project"):
        rid = engine().start(int(body["project"]), "rule_draft", r["name"],
                             {"_kind": "rule_draft", "section": sec, "level": lvl, "id": r["id"], "message": (body.get("description") or name)})
        out["run"] = rid
    return jsonify(out)


def _rule_or_404(sec, lvl, rid):
    try:
        return family3.load_rule(sec, lvl, rid)
    except ValueError:
        return None


@bp.get("/api/agents/rules/<sec>/<lvl>/<rid>")
def get_rule(sec, lvl, rid):
    r = _rule_or_404(sec, lvl, rid)
    if not r:
        return jsonify({"error": "no such item"}), 404
    code, problem = None, None
    try:
        code = family3.compile_rule(r)[0]
    except Exception as e:      # noqa: BLE001 - shown on the page
        problem = str(e)
    runs = engine().store.all("SELECT id, kind, state, created, summary FROM run WHERE kind IN ('rule_draft','rule_run') AND params LIKE ? ORDER BY id DESC LIMIT 10",
                              ('%%"id": "%s"%%' % rid,))
    return jsonify({"rule": r, "in_words": family3.describe(r), "code": code, "code_problem": problem, "runs": runs,
                    "section_label": family3.SECTIONS[sec], "level_label": family3.LEVEL_LABEL[lvl]})


@bp.post("/api/agents/rules/<sec>/<lvl>/<rid>/edit")
def edit_rule(sec, lvl, rid):
    body = request.get_json(force=True) or {}
    r = _rule_or_404(sec, lvl, rid)
    if not r:
        return jsonify({"error": "no such item"}), 404
    if not body.get("project"):
        return jsonify({"error": "open a project first (the start page)"}), 400
    run = engine().start(int(body["project"]), "rule_draft", r["name"],
                         {"_kind": "rule_draft", "section": sec, "level": lvl, "id": rid, "message": (body.get("message") or "").strip()})
    return jsonify({"run": run, "view": engine().view(run)})


@bp.post("/api/agents/rules/<sec>/<lvl>/<rid>/proceed")
def proceed_rule(sec, lvl, rid):
    body = request.get_json(force=True) or {}
    r = _rule_or_404(sec, lvl, rid)
    if not r:
        return jsonify({"error": "no such item"}), 404
    if r.get("status") != "approved":
        return jsonify({"error": "this rule is a draft: edit it, review it and approve it before running it"}), 409
    if not body.get("project"):
        return jsonify({"error": "open a project first (the start page)"}), 400
    run = engine().start(int(body["project"]), "rule_run", r["name"],
                         {"_kind": "rule_run", "section": sec, "level": lvl, "id": rid, "upload_id": body.get("upload_id") or None})
    return jsonify({"run": run, "view": engine().view(run)})


@bp.get("/api/agents/file")
def get_file():
    p = os.path.realpath(request.args.get("path") or "")
    base = os.path.realpath(os.path.join(family1.knowledge_dir(), "exports"))
    if not p.startswith(base + os.sep) or not os.path.isfile(p):
        return jsonify({"error": "not an exported file"}), 404
    return send_file(p, as_attachment=p.endswith(".csv"))
