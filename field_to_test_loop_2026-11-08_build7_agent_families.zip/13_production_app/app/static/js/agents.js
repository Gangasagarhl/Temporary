// The agent families page: start page, Family 1, Family 2, review inbox, the rules sidebar (sections, levels, items), runs.
"use strict";
const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const STATE_WORDS = { waiting: "waiting", running: "running", needs_review: "needs your review", approved: "approved", done: "done",
  skipped: "skipped", failed: "failed", rejected: "rejected", finished: "finished", stopped: "stopped", changes: "changes asked" };
const KIND_WORDS = { family1: "Family 1 · data dictionaries", family2: "Family 2 · hierarchy", rule_draft: "Family 3 · rule draft", rule_run: "Family 3 · rule run" };
let S = { admin: "", project: null, state: null, view: "start", arg: null, poll: null };
try { S.admin = localStorage.getItem("agents.admin") || ""; S.project = Number(localStorage.getItem("agents.project")) || null; } catch (e) { /* private window */ }

async function api(method, url, body) {
  const r = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) });
  const j = await r.json().catch(() => ({ error: "the server answered " + r.status }));
  if (!r.ok) throw new Error(j.error || ("HTTP " + r.status));
  return j;
}
const st = s => `<span class="st ${esc(s)}">${esc(STATE_WORDS[s] || s)}</span>`;
const when = t => t ? new Date(t * 1000).toLocaleString() : "-";

// a small markdown renderer for the review texts (bold, code, tables, lists, code fences)
function md(text) {
  const lines = String(text || "").split("\n"); let out = [], i = 0;
  const inline = s => esc(s).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/`([^`]+)`/g, "<code>$1</code>");
  while (i < lines.length) {
    const l = lines[i];
    if (l.startsWith("```")) { let j = i + 1, buf = []; while (j < lines.length && !lines[j].startsWith("```")) buf.push(lines[j++]); out.push(`<pre>${esc(buf.join("\n"))}</pre>`); i = j + 1; continue; }
    if (l.trim().startsWith("|")) {
      let rows = []; while (i < lines.length && lines[i].trim().startsWith("|")) rows.push(lines[i++]);
      rows = rows.filter(r => !/^\|\s*-/.test(r.trim()));
      out.push(`<div class="tbl"><table>` + rows.map((r, k) => `<tr>${r.trim().replace(/^\||\|$/g, "").split("|").map(c => k === 0 ? `<th>${inline(c.trim())}</th>` : `<td>${inline(c.trim())}</td>`).join("")}</tr>`).join("") + `</table></div>`);
      continue;
    }
    if (l.trim().startsWith("- ")) { let items = []; while (i < lines.length && lines[i].trim().startsWith("- ")) items.push(`<li>${inline(lines[i++].trim().slice(2))}</li>`); out.push(`<ul>${items.join("")}</ul>`); continue; }
    if (l.trim()) out.push(`<p>${inline(l)}</p>`);
    i++;
  }
  return `<div class="md">${out.join("")}</div>`;
}

// ------------------------------------------------------------------ the sidebar
async function renderNav() {
  let tree = [];
  try { tree = await api("GET", "/api/agents/rules"); } catch (e) { tree = []; }
  const n = (S.state && S.state.open_reviews.length) || 0;
  const b = (v, label, arg) => `<button class="nav ${S.view === v && (arg === undefined || S.arg === arg) ? "active" : ""}" data-v="${v}" ${arg !== undefined ? `data-a="${esc(arg)}"` : ""}>${label}</button>`;
  let h = `<div class="group">Work</div>` + b("start", "Start · admin and project") + b("family1", "Family 1 · Data experts") + b("family2", "Family 2 · Hierarchy") +
    b("inbox", `Review inbox ${n ? `<span class="badge">${n}</span>` : ""}`) + b("runs", "All runs") + b("settings", "Settings");
  for (const sec of tree) {
    h += `<div class="group">${esc(sec.label)}</div>`;
    for (const lv of sec.levels) {
      h += `<div class="lvl">${esc(lv.label)} <button class="add" data-add="${sec.section}|${lv.level}" title="add an item to this level">+ add</button></div>`;
      for (const it of lv.items) {
        const key = `${sec.section}/${lv.level}/${it.id}`;
        h += `<button class="item ${S.view === "rule" && S.arg === key ? "active" : ""}" data-rule="${esc(key)}" title="${esc(it.status)}${it.version ? " · version " + it.version : ""}"><span class="dot ${esc(it.status)}"></span>${esc(it.name)}${it.demo ? ' <span class="badge">demo</span>' : ""}</button>`;
      }
    }
  }
  $("nav").innerHTML = h;
  $("nav").querySelectorAll("button[data-v]").forEach(x => x.onclick = () => go(x.dataset.v, x.dataset.a));
  $("nav").querySelectorAll("button[data-rule]").forEach(x => x.onclick = () => go("rule", x.dataset.rule));
  $("nav").querySelectorAll("button[data-add]").forEach(x => x.onclick = () => go("add", x.dataset.add));
}

async function refreshState() {
  try { S.state = await api("GET", "/api/agents/state"); } catch (e) { return; }
  $("who").textContent = "admin: " + (S.admin || "not set");
  const p = S.state.projects.find(x => x.id === S.project);
  $("proj").textContent = p ? "project: " + p.name : "no project";
  const rt = S.state.settings.runtime;
  $("rt").textContent = "agents run on: " + ({ "claude-code": "Claude Code", http: "the model connection", standin: "the stand-in (no model)" }[rt] || rt);
}

function go(view, arg) {
  S.view = view; S.arg = arg; if (S.poll) { clearInterval(S.poll); S.poll = null; }
  renderNav(); render();
}

async function render() {
  const m = $("main");
  try {
    if (S.view === "start") return renderStart(m);
    if (S.view === "family1" || S.view === "family2") return renderFamily(m, S.view);
    if (S.view === "inbox") return renderInbox(m);
    if (S.view === "runs") return renderRuns(m);
    if (S.view === "run") return renderRun(m, Number(S.arg));
    if (S.view === "rule") return renderRule(m, S.arg);
    if (S.view === "add") return renderAdd(m, S.arg);
    if (S.view === "settings") return renderSettings(m);
  } catch (e) { m.innerHTML = `<div class="card err">${esc(e.message)}</div>`; }
}

function needProject(m) {
  if (S.project && S.state && S.state.projects.find(x => x.id === S.project)) return false;
  m.innerHTML = `<div class="card"><h2>No project open</h2><p>Open or create a project on the start page first: the agents need the admin's name, the input folder and the reference documents.</p><button class="b primary" id="to-start">Go to the start page</button></div>`;
  $("to-start").onclick = () => go("start"); return true;
}

// ------------------------------------------------------------------ start page
async function renderStart(m) {
  await refreshState();
  let uploads = [];
  try { uploads = (await api("GET", "/api/hier/uploads")).filter(u => u.status === "loaded"); } catch (e) { uploads = []; }
  const projects = S.state.projects;
  m.innerHTML = `<div class="card"><h2>The admin</h2>
    <p class="muted">The person who starts the application and decides. Every review is addressed to this name ("Admin &lt;name&gt;, need review"), and every decision is stored with it.</p>
    <label>Your name</label><input type="text" id="adm" value="${esc(S.admin)}" placeholder="your name">
    <div class="row"><button class="b primary" id="adm-save">Save</button><span id="adm-msg" class="muted small"></span></div></div>
  <div class="card"><h2>Projects</h2>${projects.length ? `<div class="tbl"><table><tr><th>project</th><th>admin</th><th>input folder</th><th>built data</th><th></th></tr>` +
    projects.map(p => `<tr><td><b>${esc(p.name)}</b></td><td>${esc(p.admin)}</td><td class="small">${esc(p.folder)}</td><td class="small">${esc(p.upload_id || "not built yet")}</td><td><button class="b ${p.id === S.project ? "ok" : ""}" data-open="${p.id}">${p.id === S.project ? "open" : "open this"}</button></td></tr>`).join("") +
    `</table></div>` : `<p class="muted">No project yet.</p>`}</div>
  <div class="card"><h2>New project</h2>
    <label>Name</label><input type="text" id="np-name" placeholder="for example: drive X, capture of 2026-11-07">
    <label>Input folder (the CSVs exported from one .pex file)</label><input type="text" id="np-folder" placeholder="/path/to/the/folder/with/the/five/csvs">
    <div class="row"><button class="b" id="np-check">Look at the folder</button></div><div id="np-inv"></div>
    <label>Reference documents (folders, one per line: LeCroy manuals, specification extracts, notes saved earlier)</label>
    <textarea id="np-refs">${esc((S.state.settings.references || []).join("\n"))}</textarea>
    <label>REA findings (a folder of decompiled code or notes; optional)</label><input type="text" id="np-rea" placeholder="optional">
    <label>Data already loaded on the five-file pages (optional: reuse it instead of loading again)</label>
    <select id="np-up"><option value="">none: Family 2 loads and builds it</option>${uploads.map(u => `<option value="${esc(u.upload_id)}">${esc(u.upload_id)} · ${esc(u.device || "")} · ${esc((u.files || []).join(", ") || "")}</option>`).join("")}</select>
    <div class="row"><button class="b primary" id="np-make">Create the project</button><span id="np-msg" class="small"></span></div></div>`;
  $("adm-save").onclick = () => { S.admin = $("adm").value.trim(); try { localStorage.setItem("agents.admin", S.admin); } catch (e) {} $("adm-msg").textContent = "saved"; refreshState(); };
  m.querySelectorAll("button[data-open]").forEach(b => b.onclick = () => { S.project = Number(b.dataset.open); try { localStorage.setItem("agents.project", S.project); } catch (e) {} go("start"); });
  $("np-check").onclick = async () => {
    try { const r = await api("GET", "/api/agents/inventory?folder=" + encodeURIComponent($("np-folder").value.trim()));
      $("np-inv").innerHTML = `<div class="tbl"><table><tr><th>file</th><th>level</th><th>columns</th><th>size</th></tr>` + r.files.map(f => `<tr><td>${esc(f.name)}</td><td>${esc(f.level_label)}</td><td>${f.columns}</td><td>${(f.bytes / 1e6).toFixed(1)} MB</td></tr>`).join("") + `</table></div>`;
    } catch (e) { $("np-inv").innerHTML = `<p class="err">${esc(e.message)}</p>`; }
  };
  $("np-make").onclick = async () => {
    if (!S.admin) { $("np-msg").innerHTML = `<span class="err">save your name first</span>`; return; }
    try { const p = await api("POST", "/api/agents/projects", { admin: S.admin, name: $("np-name").value, folder: $("np-folder").value.trim(),
        refs: $("np-refs").value.split("\n").map(x => x.trim()).filter(Boolean), rea: $("np-rea").value.trim(), upload_id: $("np-up").value });
      S.project = p.id; try { localStorage.setItem("agents.project", S.project); } catch (e) {} go("family1");
    } catch (e) { $("np-msg").innerHTML = `<span class="err">${esc(e.message)}</span>`; }
  };
}

// ------------------------------------------------------------------ families
const FAMILY_TEXT = {
  family1: ["Family 1 · Data experts", "One sub-family per CSV of the input folder. The Explorer reads the data (a sample from the start and from random places of the file, never all of it in memory), the Grounder finds what each column means in the reference documents, the Manager merges both into a data dictionary and asks for your review. Every claim must quote a value seen in the data or a line of a document; the code checks it."],
  family2: ["Family 2 · Hierarchy", "How the CSVs connect into one tree. If a strategy was approved before for this file format, you are asked whether to proceed with it. Otherwise the REA findings and the references are searched, and the Coder writes the strategy with its evidence for your review. The Builder asks before building, then the Code tester rebuilds 5 to 10 random windows of the real data, the Breaker the hardest windows, and the Independent tester checks the tree with the column meanings only."],
};
async function renderFamily(m, fam) {
  await refreshState(); if (needProject(m)) return;
  const runs = (await api("GET", "/api/agents/runs?project=" + S.project)).filter(r => r.kind === fam);
  const [title, text] = FAMILY_TEXT[fam];
  m.innerHTML = `<div class="card"><h2>${title}</h2><p>${esc(text)}</p><div class="row"><button class="b primary" id="fam-start">Start ${esc(title.split(" · ")[1].toLowerCase())}</button><span id="fam-msg" class="small"></span></div></div>
    <div class="card"><h3>Runs of this project</h3>${runsTable(runs)}</div>`;
  $("fam-start").onclick = async () => { try { const r = await api("POST", `/api/agents/projects/${S.project}/${fam}`); go("run", r.run); } catch (e) { $("fam-msg").innerHTML = `<span class="err">${esc(e.message)}</span>`; } };
  wireRuns(m);
}
function runsTable(runs) {
  if (!runs.length) return `<p class="muted">none yet</p>`;
  return `<div class="tbl"><table><tr><th>run</th><th>what</th><th>state</th><th>started</th><th>summary</th></tr>` + runs.map(r => `<tr><td><button class="b" data-run="${r.id}">open ${r.id}</button></td><td>${esc(KIND_WORDS[r.kind] || r.kind)}${r.target ? " · " + esc(r.target) : ""}</td><td>${st(r.state)}</td><td class="small">${when(r.created)}</td><td class="small">${esc(r.summary || "")}</td></tr>`).join("") + `</table></div>`;
}
function wireRuns(m) { m.querySelectorAll("button[data-run]").forEach(b => b.onclick = () => go("run", Number(b.dataset.run))); }

async function renderRuns(m) { const runs = await api("GET", "/api/agents/runs" + (S.project ? "?project=" + S.project : "")); m.innerHTML = `<div class="card"><h2>All runs</h2>${runsTable(runs)}</div>`; wireRuns(m); }

async function renderInbox(m) {
  await refreshState();
  const rv = S.state.open_reviews;
  m.innerHTML = `<div class="card"><h2>Review inbox</h2>${rv.length ? `<div class="tbl"><table><tr><th>review</th><th>from</th><th>since</th><th></th></tr>` + rv.map(r => `<tr><td><b>${esc(r.title)}</b></td><td>${esc(KIND_WORDS[r.kind] || r.kind)} · run ${r.run}</td><td class="small">${when(r.created)}</td><td><button class="b primary" data-run="${r.run}">open</button></td></tr>`).join("") + `</table></div>` : `<p class="muted">Nothing waits for you.</p>`}</div>`;
  wireRuns(m);
}

// ------------------------------------------------------------------ one run: its steps, its reviews, its evidence
async function renderRun(m, rid) {
  const draw = async () => {
    let v; try { v = await api("GET", "/api/agents/runs/" + rid); } catch (e) { m.innerHTML = `<div class="card err">${esc(e.message)}</div>`; return; }
    const run = v.run, done = v.steps.filter(s => ["done", "approved", "skipped"].includes(s.state)).length;
    const keep = {}; m.querySelectorAll("textarea[data-keep], input[data-keep]").forEach(x => keep[x.dataset.keep] = x.value);
    const live = run.state === "running" ? (v.worker_alive ? `working · last activity ${Math.round(v.seconds_since_heartbeat)} s ago` : "waiting") : "";
    let h = `<div class="card"><h2>${esc(KIND_WORDS[run.kind] || run.kind)}${run.target ? " · " + esc(run.target) : ""} <span class="muted small">run ${run.id}</span></h2>
      <div class="row">${st(run.state)} <span class="muted small">${done} of ${v.steps.length} steps finished · ${esc(live)}</span>
      ${v.steps.some(s => s.state === "failed") ? `<button class="b" id="retry">Run the failed step again</button>` : ""}
      ${run.state === "running" ? `<button class="b bad" id="stop">Stop</button>` : ""}</div>${run.summary ? `<p class="small">${esc(run.summary)}</p>` : ""}
      <progress max="${v.steps.length}" value="${done}" style="width:100%"></progress></div><div class="card"><h3>Steps</h3>`;
    for (const s of v.steps) {
      h += `<div class="step ${esc(s.state)}"><div class="row" style="margin:0">${st(s.state)} <b>${esc(s.title)}</b> <span class="muted small">${esc(s.agent)}${s.producer ? " · answered by " + esc(s.producer) : ""}</span></div>`;
      if (s.note) h += `<div class="small muted">${esc(s.note)}</div>`;
      if (s.error) h += `<div class="err">${esc(s.error.split("\n")[0])}</div>`;
      if (s.output && Object.keys(s.output).length && ["done", "approved", "needs_review"].includes(s.state)) h += `<details><summary class="small">what the step produced</summary><pre>${esc(JSON.stringify(s.output, null, 1).slice(0, 20000))}</pre></details>`;
      for (const r of v.reviews.filter(x => x.step === s.id)) h += reviewHtml(r, keep);
      h += `</div>`;
    }
    h += `</div>`;
    if (v.evidence.length) h += `<div class="card"><h3>Evidence (${v.evidence.length})</h3><div class="tbl"><table class="ev"><tr><th>claim</th><th>source</th><th>checked by the code</th></tr>` +
      v.evidence.slice(0, 300).map(e => `<tr><td>${esc(e.claim)}</td><td class="small">${esc(e.kind)} · ${esc(e.ref)}<br><i>${esc((e.quote || "").slice(0, 200))}</i></td><td class="${e.verified ? "ok" : "no"}">${e.verified ? "verified" : "NOT verified: " + esc(e.why)}</td></tr>`).join("") + `</table></div></div>`;
    m.innerHTML = h;
    if ($("retry")) $("retry").onclick = async () => { await api("POST", `/api/agents/runs/${rid}/retry`); draw(); };
    if ($("stop")) $("stop").onclick = async () => { await api("POST", `/api/agents/runs/${rid}/stop`, { admin: S.admin }); draw(); };
    wireReviews(m, draw);
    const busy = run.state === "running" && !v.steps.some(s => s.state === "needs_review" || s.state === "failed");
    if (busy && !S.poll) S.poll = setInterval(() => { if (S.view === "run" && S.arg === rid) draw(); }, 2500);
    if (!busy && S.poll) { clearInterval(S.poll); S.poll = null; refreshState().then(renderNav); }
  };
  await draw();
}

function reviewHtml(r, keep) {
  const open = r.state === "open";
  const dictTable = r.data && r.data.table ? `<details><summary class="small">the full table (${r.data.table.length} columns)</summary><div class="tbl"><table><tr><th>column</th><th>what the data shows</th><th>meaning</th><th>status</th></tr>` +
    r.data.table.map(t => `<tr><td>${esc(t.column)}</td><td class="small">${esc(t.observed)}</td><td class="small">${esc(t.meaning)}</td><td class="small">${esc(t.status)}</td></tr>`).join("") + `</table></div></details>` : "";
  const files = r.data && r.data.files ? `<div class="row">` + Object.entries(r.data.files).map(([k, p]) => `<a class="b" href="/api/agents/file?path=${encodeURIComponent(p)}" target="_blank">open the ${esc(k.toUpperCase())} export</a>`).join("") + `</div>` : "";
  const isolate = r.data && r.data.section === "errors" && r.data.head && r.data.head.length ? `<h3>Stage 1 and stage 2 for each defect</h3><div class="row">` + r.data.head.slice(0, 30).map(x => `<a class="b" href="/isolate?upload=${encodeURIComponent(r.data.upload_id)}&finding=${x[0]}" target="_blank">defect ${x[0]}</a>`).join("") + `</div>` : "";
  return `<div class="review"><div class="row" style="margin:0"><b>${esc(r.title)}</b> ${st(r.state === "open" ? "needs_review" : r.state)} ${r.decided_by ? `<span class="small muted">by ${esc(r.decided_by)} · ${when(r.decided_at)}${r.comment ? " · “" + esc(r.comment) + "”" : ""}</span>` : ""}</div>
    ${md(r.body)}${dictTable}${files}${isolate}
    <div class="chat">${(r.chat || []).map(c => `<div><span class="who">${esc(c.role)}</span><br>${esc(c.text)}</div>`).join("")}</div>
    ${open ? `<label>Ask about this (the agent answers from what it found)</label><div class="row"><input type="text" data-keep="ask${r.id}" id="ask${r.id}" value="${esc(keep["ask" + r.id] || "")}" placeholder="your question"><button class="b" data-ask="${r.id}">Ask</button></div>
    ${r.data && r.data.table ? `<label>Edits (one per line: column = meaning)</label><textarea data-keep="ed${r.id}" id="ed${r.id}">${esc(keep["ed" + r.id] || "")}</textarea>` : ""}
    <label>Your comment (needed for Change)</label><textarea data-keep="cm${r.id}" id="cm${r.id}">${esc(keep["cm" + r.id] || "")}</textarea>
    <div class="row"><button class="b ok" data-dec="approve" data-r="${r.id}">Approve</button><button class="b" data-dec="change" data-r="${r.id}">Change</button><button class="b bad" data-dec="reject" data-r="${r.id}">Reject</button><span class="small" id="msg${r.id}"></span></div>` : ""}</div>`;
}
function wireReviews(m, redraw) {
  m.querySelectorAll("button[data-dec]").forEach(b => b.onclick = async () => {
    const id = b.dataset.r, dec = b.dataset.dec, comment = ($("cm" + id) || {}).value || "";
    if (!S.admin) { $("msg" + id).innerHTML = `<span class="err">set your name on the start page first</span>`; return; }
    if (dec === "change" && !comment.trim()) { $("msg" + id).innerHTML = `<span class="err">write what to change</span>`; return; }
    let edits; const ed = $("ed" + id);
    if (ed && ed.value.trim()) { edits = {}; ed.value.split("\n").forEach(l => { const i = l.indexOf("="); if (i > 0) edits[l.slice(0, i).trim()] = l.slice(i + 1).trim(); }); }
    b.disabled = true;
    try { await api("POST", `/api/agents/reviews/${id}/decide`, { decision: dec, admin: S.admin, comment, edits }); await refreshState(); renderNav(); redraw(); }
    catch (e) { $("msg" + id).innerHTML = `<span class="err">${esc(e.message)}</span>`; b.disabled = false; }
  });
  m.querySelectorAll("button[data-ask]").forEach(b => b.onclick = async () => {
    const id = b.dataset.ask, q = $("ask" + id).value.trim(); if (!q) return;
    b.disabled = true; $("msg" + id).textContent = "asking…";
    try { await api("POST", `/api/agents/reviews/${id}/ask`, { message: q, admin: S.admin }); $("ask" + id).value = ""; redraw(); }
    catch (e) { $("msg" + id).innerHTML = `<span class="err">${esc(e.message)}</span>`; b.disabled = false; }
  });
}

// ------------------------------------------------------------------ Family 3: one item
async function renderRule(m, key) {
  const [sec, lvl, id] = key.split("/");
  const v = await api("GET", `/api/agents/rules/${sec}/${lvl}/${id}`);
  const r = v.rule, approved = r.status === "approved";
  m.innerHTML = `<div class="card"><h2>${esc(r.name)} ${r.demo ? '<span class="badge">demo</span>' : ""}</h2>
    <p class="muted small">${esc(v.section_label)} · ${esc(v.level_label)} · ${approved ? `version ${r.version}, approved by ${esc(r.approved_by)} on ${when(r.approved_at)}` : "draft: not approved yet"}${r.last_run ? " · last run " + when(r.last_run.at) : ""}</p>
    ${r.description ? `<p>${esc(r.description)}</p>` : ""}
    <h3>The rule</h3><p>${esc(r.definition || "(no definition yet)")}</p>
    <h3>What the code does</h3><p>${esc(v.in_words)}</p>
    ${v.code ? `<details><summary class="small">the code generated from this rule</summary><pre>${esc(v.code)}</pre></details>` : `<p class="err">${esc(v.code_problem || "")}</p>`}
    ${r.source ? `<p class="small muted">source: ${esc(r.source)}</p>` : ""}</div>
    <div class="card"><h3>What do you want to do?</h3>
      <div class="row"><button class="b primary" id="proceed" ${approved ? "" : "disabled"}>Proceed with the current rules</button><span class="small muted">${approved ? "runs the code on the project's data, a tester checks it, the result is exported and shown for review" : "approve a version first (Edit the rules)"}</span></div>
      <label>Edit the rules: say what to change (the Rule writer drafts it, you review it)</label><textarea id="msg" placeholder="for example: count only the I/O commands; or: a read is sequential even with a gap of up to 8 blocks"></textarea>
      <div class="row"><button class="b" id="edit">${approved ? "Edit the rules" : "Write the rules"}</button><span id="rmsg" class="small"></span></div></div>
    <div class="card"><h3>Runs of this item</h3>${runsTable(v.runs)}</div>
    ${r.history && r.history.length ? `<div class="card"><h3>Earlier versions</h3><div class="tbl"><table><tr><th>version</th><th>status</th><th>definition</th><th>approved by</th></tr>` + r.history.slice().reverse().map(x => `<tr><td>${x.version}</td><td>${esc(x.status)}</td><td class="small">${esc((x.definition || "").slice(0, 300))}</td><td>${esc(x.approved_by || "")}</td></tr>`).join("") + `</table></div></div>` : ""}`;
  wireRuns(m);
  $("proceed").onclick = async () => { if (!S.project) { $("rmsg").innerHTML = `<span class="err">open a project first</span>`; return; }
    try { const x = await api("POST", `/api/agents/rules/${sec}/${lvl}/${id}/proceed`, { project: S.project }); go("run", x.run); } catch (e) { $("rmsg").innerHTML = `<span class="err">${esc(e.message)}</span>`; } };
  $("edit").onclick = async () => { if (!S.project) { $("rmsg").innerHTML = `<span class="err">open a project first</span>`; return; }
    try { const x = await api("POST", `/api/agents/rules/${sec}/${lvl}/${id}/edit`, { project: S.project, message: $("msg").value }); go("run", x.run); } catch (e) { $("rmsg").innerHTML = `<span class="err">${esc(e.message)}</span>`; } };
}

async function renderAdd(m, arg) {
  const [sec, lvl] = arg.split("|");
  m.innerHTML = `<div class="card"><h2>Add an item</h2><p class="muted">${sec === "errors" ? "Section 2 · Error roots" : "Section 1 · Data analytics"} · ${esc(lvl.replace("_", " "))}</p>
    <label>Name</label><input type="text" id="an" placeholder="${sec === "errors" ? "the error's name" : "what to analyse"}">
    <label>Describe it in your words (what it means, how it shows in the data, what result you want)</label><textarea id="ad"></textarea>
    <div class="row"><button class="b primary" id="ago">Add and start the conversation</button><span id="amsg" class="small"></span></div></div>`;
  $("ago").onclick = async () => {
    if (!S.project) { $("amsg").innerHTML = `<span class="err">open a project first</span>`; return; }
    try { const x = await api("POST", "/api/agents/rules", { section: sec, level: lvl, name: $("an").value, description: $("ad").value, admin: S.admin, project: S.project });
      renderNav(); go("run", x.run); } catch (e) { $("amsg").innerHTML = `<span class="err">${esc(e.message)}</span>`; }
  };
}

async function renderSettings(m) {
  const a = await api("GET", "/api/agents/settings");
  m.innerHTML = `<div class="card"><h2>Settings</h2>
    <label>The agents run on</label><select id="s-rt"><option value="claude-code">Claude Code (headless; its own settings: ~/.claude/settings.json)</option><option value="http">the model connection of this application</option><option value="standin">the stand-in (no model; for tests)</option></select>
    <p class="small muted">When the chosen one fails the next is used: Claude Code, then the model connection, then the stand-in. Every step records who answered.</p>
    <label>Model (empty = Claude Code's own default)</label><input type="text" id="s-model" value="${esc(a.model || "")}">
    <label>Random windows for the Code tester (5 to 10)</label><input type="text" id="s-sl" value="${esc(a.slices)}">
    <div class="row"><button class="b primary" id="s-save">Save</button><span id="s-msg" class="small"></span></div></div>`;
  $("s-rt").value = a.runtime;
  $("s-save").onclick = async () => { try { await api("PUT", "/api/agents/settings", { runtime: $("s-rt").value, model: $("s-model").value.trim(), slices: Math.max(5, Math.min(10, Number($("s-sl").value) || 6)) }); $("s-msg").textContent = "saved"; refreshState(); } catch (e) { $("s-msg").innerHTML = `<span class="err">${esc(e.message)}</span>`; } };
}

(async () => { await refreshState(); renderNav(); render(); setInterval(async () => { await refreshState(); }, 6000); })();
