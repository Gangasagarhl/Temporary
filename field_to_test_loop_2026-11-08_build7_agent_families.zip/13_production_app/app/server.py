"""Field-to-Test Loop - local full-stack application.

Flask app factory: registers the API blueprints (config, runs, stage 2, database, misc) and serves the two pages
(the workflow at / and the database interface at /db). Binds to 127.0.0.1 only; single admin, no authentication.
"""
import json
import os
import sys

from flask import Flask, send_from_directory

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from services import Services                       # noqa: E402
from api import agentic_api, config_api, db_api, hier_api, isolate_api, misc_api, runs_api, stage2_api   # noqa: E402


def load_config(path):
    with open(path) as f:
        cfg = json.load(f)
    cfg["_path"] = path
    return cfg


def create_app(cfg, root):
    app = Flask("field_to_test_loop", static_folder=os.path.join(HERE, "static"), static_url_path="/static")
    app.config["services"] = Services(cfg, root)
    app.config["JSON_SORT_KEYS"] = False
    for m in (config_api, runs_api, stage2_api, db_api, misc_api, hier_api, isolate_api, agentic_api):
        app.register_blueprint(m.bp)

    @app.get("/")
    def index():
        # Front page (2026-11-02 restructuring): the five-file NVMe hierarchy workflow.
        return send_from_directory(app.static_folder, "hier.html")

    @app.get("/packets")
    def packets_page():
        # The earlier single-CSV packet-level workflow (stage 1 / stage 2), kept as is.
        return send_from_directory(app.static_folder, "index.html")

    @app.get("/db")
    def db_page():
        return send_from_directory(app.static_folder, "db.html")

    @app.get("/defect")
    def defect_page():
        return send_from_directory(app.static_folder, "defect.html")

    @app.get("/hier")
    def hier_page():
        return send_from_directory(app.static_folder, "hier.html")

    @app.get("/isolate")
    def isolate_page():
        # the isolation tab of one defect (?upload=<upload id>&finding=<finding id>), opened by page 3 in a new browser tab
        return send_from_directory(app.static_folder, "isolate.html")

    @app.get("/agents")
    def agents_page():
        # the agent families (2026-11-08): start page, Families 1 and 2, the review inbox, the rules page with its sections
        return send_from_directory(app.static_folder, "agents.html")

    @app.get("/how")
    def how_page():
        # the interactive guide to the whole application (also readable as a file: docs/HOW_THE_APP_WORKS.html)
        return send_from_directory(os.path.join(os.path.dirname(HERE), "docs"), "HOW_THE_APP_WORKS.html")

    @app.after_request
    def no_cache(resp):
        if resp.mimetype in ("text/html", "application/javascript", "text/css"):
            resp.headers["Cache-Control"] = "no-store"
        return resp
    return app
