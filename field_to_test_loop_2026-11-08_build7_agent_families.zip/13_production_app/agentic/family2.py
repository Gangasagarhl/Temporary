"""Family 2 — Hierarchy: how the CSVs connect into one tree, with evidence, approved by the admin, tested, built.

Steps of a run (kind "family2"), in order:
  last_strategy   if a strategy was approved before for this file format: REVIEW "used last time; proceed?"
                  (approve = reuse it and skip the research and the Coder)
  rea             the REA findings the admin gave (decompiled analyzer code, notes): the lines about the join columns
  collect         the Information collector: the reference documents, Family 1's approved dictionaries, and the
                  sources that need a connector (IMS, JIRA, the web), each reported as reachable or not
  coder           the Coder's strategy: for each join, the columns used, the rule in plain words and the evidence.
                  REVIEW "Admin <name>, need review" (approve stores it as the strategy of this file format)
  build_ask       REVIEW "shall I build the hierarchy?" with the sizes and how memory is kept low
  build           the Builder: loads the five files and builds the tree on disk (resumable), or reuses a loaded upload
  slice_test      the Code tester: 5 to 10 random windows of the real data rebuilt on their own; every parent fully
                  inside a window must hold as many children as the analyzer says, and the same children as the full tree
  breaker         the Breaker: the hardest windows (resends after a Nak, rows that joined nothing, the start and end of
                  the file, the busiest moment) through the same test
  independent     the Independent tester: checks the built tree with the column meanings only (same PSN, same
                  requester and tag, address inside the range, same queue and command id) on a sample of every level
"""
import hashlib
import json
import os
import random
import sqlite3
import sys
import time

from . import core, family1

APP = family1.APP
sys.path.insert(0, APP)
sys.path.insert(0, os.path.join(APP, "app"))
from nvme_hier import builder as B, columns as C, loader as L   # noqa: E402

JOIN_TERMS = ["PSN", "AckNak Seq Num", "Ack", "Nak", "RequesterID", "Tag", "Address", "SQID", "CID", "Doorbell",
              "Metrics.# Packets", "Metrics.# LinkTrans", "Metrics.# Link & Split Trans", "Metrics.# NVME Trans"]

# strategy version 1: what the current builder does (nvme_hier/builder.py), written as the admin reviews it
BUILTIN = [
    {"join": "packets -> link transaction", "columns": ["Link Dir", "PSN", "AckNak Seq Num", "Metrics.# Packets"],
     "rule": "A TLP opens the link transaction of its direction and PSN; a resend with the same direction and PSN joins it. "
             "An Ack in the other direction naming that PSN closes it and also closes every earlier open PSN of that direction "
             "(implicitly acknowledged). A Nak acknowledges every TLP up to its number and refuses the later ones, which are resent. "
             "Open exchanges are kept in queues per direction, so many exchanges in flight at once are tracked by PSN, not by time.",
     "check": "the number of packets joined equals the analyzer's Metrics.# Packets",
     "terms": ["PSN", "AckNak Seq Num", "Ack", "Nak"]},
    {"join": "link transactions -> split transaction", "columns": ["RequesterID", "Tag", "Metrics.# LinkTrans"],
     "rule": "A split transaction is a non-posted request and its completions. The request's RequesterID and Tag identify it; "
             "every completion going the other way with the same RequesterID and Tag joins the oldest open split with that key "
             "until the analyzer's count is reached.",
     "check": "the number of link transactions joined equals Metrics.# LinkTrans",
     "terms": ["RequesterID", "Tag"]},
    {"join": "link and split transactions -> NVMe transaction", "columns": ["Address", "Time Stamp", "Metrics.# Link & Split Trans"],
     "rule": "An NVMe transaction names the memory address it is about (a doorbell register, a queue entry, a data page, the "
             "interrupt address) and how many units it holds. The first unassigned posted link transactions or split transactions "
             "at or after its time whose address lies in its range join it. The time only says where to start looking.",
     "check": "the number of units joined equals Metrics.# Link & Split Trans",
     "terms": ["Address", "Doorbell"]},
    {"join": "NVMe transactions -> NVMe command", "columns": ["SQID", "CID", "Doorbell index", "Metrics.# NVME Trans"],
     "rule": "An NVMe transaction carrying a submission queue id and a command id joins the open command with that SQID and CID. "
             "The submission doorbell opens the command whose time stamp equals the doorbell's; the completion-queue head doorbell "
             "closes the oldest completed command of that queue. A heap keeps the open commands in time order.",
     "check": "the number of NVMe transactions joined equals Metrics.# NVME Trans",
     "terms": ["SQID", "CID", "Doorbell"]},
    {"join": "context rows -> NVMe command", "columns": ["Time Stamp"],
     "rule": "Flow-control DLLPs, ordered sets and link events carry no PSN and no address. They are attached as context (never "
             "as members) to the command whose time window holds them.",
     "check": "context rows never change a count check", "terms": ["Ordered Set", "Link Event"]},
]
BUILDER_CODE = os.path.join(APP, "nvme_hier", "builder.py")

COUNT_CHECKS = [("lnk", "n_packets", "pkt", "link"), ("spl", "n_links", "lnk", "split"),
                ("ntx", "n_links_splits", None, "nvme_transaction"), ("cmd", "n_ntx", "ntx", "nvme_command")]


def project_format(project):
    files = family1.inventory(project.get("folder"))
    keys = sorted("%s:%s" % (f["level"], f["format_key"]) for f in files if f["level"])
    return hashlib.sha1("|".join(keys).encode()).hexdigest()[:12], files


def strategy_dir(fmt):
    d = os.path.join(family1.knowledge_dir(), "strategies", fmt)
    os.makedirs(d, exist_ok=True)
    return d


def last_strategy(fmt):
    d = strategy_dir(fmt)
    vs = sorted((int(x[1:-5]), x) for x in os.listdir(d) if x.startswith("v") and x.endswith(".json"))
    return json.load(open(os.path.join(d, vs[-1][1]))) if vs else None


def code_version():
    return hashlib.sha1(open(BUILDER_CODE, "rb").read()).hexdigest()[:12]


def steps(params, project):
    s = [("last_strategy", "Strategy used last time for this file format", "Director", True),
         ("rea", "REA decompiler: what the analyzer's own code says about the joins", "REA decompiler", False),
         ("collect", "Information collector: references, Family 1's dictionaries, IMS, JIRA, web", "Information collector", False),
         ("coder", "Coder: the strategy with its evidence", "Coder", True),
         ("build_ask", "Builder: ask before building", "Builder", True),
         ("build", "Builder: load the files and build the tree on disk", "Builder", False),
         ("slice_test", "Code tester: 5 to 10 random windows of the real data", "Code tester", False),
         ("breaker", "Breaker: the hardest windows of the data", "Breaker", False),
         ("independent", "Independent tester: the tree checked with the column meanings only", "Independent tester", True)]
    return [{"key": k, "title": t, "family": "2", "agent": a, "review": r} for k, t, a, r in s]


def run_step(ctx):
    return globals()["_" + ctx.step["key"]](ctx)


# ---------------------------------------------------------------------------------------------- research and strategy
def _last_strategy(ctx):
    fmt, files = project_format(ctx.project)
    st = last_strategy(fmt)
    if not st:
        return core.Result({"format": fmt}, skip="no strategy was approved before for this file format (%s)" % fmt)
    admin = ctx.project.get("admin") or "admin"
    body = ["**Admin %s, need review.** Strategy version %d was approved by %s on %s for this same file format (five files, same headers)." % (
        admin, st["version"], st.get("approved_by", "?"), time.strftime("%Y-%m-%d %H:%M", time.localtime(st.get("approved_at") or 0))),
        "", "Approve to proceed with it: the research and the Coder are skipped, and the tests and the build use it.",
        "Ask for changes to start the research again."] + _strategy_md(st["joins"])
    return core.Result({"format": fmt, "strategy": st}, review={"title": "Proceed with strategy v%d?" % st["version"], "body": "\n".join(body),
                                                                "data": {"strategy": st}})


def _rea(ctx):
    folder = ctx.project.get("rea") or ""
    if not folder or not os.path.isdir(folder):
        return core.Result({}, skip="no REA findings were given (a folder of decompiled code or notes on the start page)")
    refs = core.References([folder], os.path.join(ctx.engine.runner.sandbox_root, "_pdf_cache"))
    hits = {t: refs.search(t, limit=3) for t in JOIN_TERMS}
    hits = {t: h for t, h in hits.items() if h}
    return core.Result({"folder": folder, "hits": hits}) if hits else core.Result({}, skip="the REA findings name none of the join columns")


def _collect(ctx):
    refs = family1.refs_of(ctx)
    found = {t: refs.search(t, limit=3) for t in JOIN_TERMS} if refs.folders else {}
    found = {t: h for t, h in found.items() if h}
    dicts = {}
    for lv in ("packets", "link", "split", "nvme_transaction", "nvme_command"):
        for d in family1.dictionaries_for_level(lv)[:1]:
            dicts[lv] = {r["column"]: r["meaning"] for r in d["columns"] if any(t.lower() in r["column"].lower() for t in JOIN_TERMS)}
    conn = (ctx.engine.cfg.get("agentic") or {}).get("connectors") or {}
    sources = [{"source": "reference documents", "reachable": bool(refs.folders), "found": len(found)},
               {"source": "Family 1 dictionaries", "reachable": bool(dicts), "found": sum(len(v) for v in dicts.values())}]
    for name in ("IMS", "JIRA", "web"):
        sources.append({"source": name, "reachable": bool(conn.get(name.lower())), "found": 0,
                        "note": "" if conn.get(name.lower()) else "not connected on this machine (set agentic.connectors.%s in the configuration)" % name.lower()})
    return core.Result({"references": found, "dictionaries": dicts, "sources": sources})


def _strategy_md(joins):
    out = []
    for i, j in enumerate(joins, 1):
        out += ["", "**%d. %s** (columns: %s)" % (i, j["join"], ", ".join(j["columns"])), "", j["rule"], "", "Check: " + j["check"]]
        for e in j.get("evidence") or []:
            out.append("- evidence (%s%s): %s — `%s`" % (e["kind"], "" if e.get("verified") else ", NOT VERIFIED", e["quote"][:200], e["ref"]))
    return out


CODER_INSTRUCTION = """You are the Coder of Family 2. You get the current strategy for joining five analyzer CSVs into one
tree (packets -> link transactions -> split transactions -> NVMe transactions -> NVMe commands), the evidence the
collectors found (reference lines, REA lines, Family 1's column meanings) and the admin's comments. Return the strategy
for the admin: for each join, keep or improve the rule in plain words, list the columns it uses (they must be columns of
the files), and attach evidence ONLY by copying a reference line given in CONTEXT (kind "document" or "rea", ref and
quote exactly as given). Address every admin comment in "answers_to_admin"."""
CODER_SHAPE = '{"joins": [{"join": "...", "columns": ["..."], "rule": "...", "check": "...", "evidence": [{"kind": "document", "ref": "<file:line>", "quote": "<copied>"}]}], "answers_to_admin": ["..."]}'


def _coder(ctx):
    rea = ctx.output_of("rea").get("hits") or {}
    col = ctx.output_of("collect")
    refs_hits = col.get("references") or {}
    comments = ctx.input.get("comments") or []
    joins = json.loads(json.dumps(BUILTIN))

    def standin():
        out = []
        for j in joins:
            ev = []
            for t in j["terms"]:
                for h in (refs_hits.get(t) or [])[:1]:
                    ev.append({"kind": "document", "ref": h["ref"], "quote": h["quote"][:200]})
                for h in (rea.get(t) or [])[:1]:
                    ev.append({"kind": "rea", "ref": h["ref"], "quote": h["quote"][:200]})
            out.append(dict(j, evidence=ev[:4]))
        return {"joins": out, "answers_to_admin": ["Noted: %s (the stand-in cannot change the strategy; a model run can)." % c for c in comments if c]}
    ans, producer, _ = ctx.engine.runner.ask(ctx.run["id"], "coder", CODER_INSTRUCTION,
                                             {"strategy": joins, "references": refs_hits, "rea": rea, "dictionaries": col.get("dictionaries"), "admin_comments": comments},
                                             CODER_SHAPE, "joins", standin)
    refs = core.References([x for x in (core.jload(ctx.project.get("refs"), []) or []) + [ctx.project.get("rea") or ""] if x],
                           os.path.join(ctx.engine.runner.sandbox_root, "_pdf_cache"))
    headers = set()
    for f in family1.inventory(ctx.project.get("folder")):
        h, _ = L.sniff(f["path"], 0)
        al = L.align_header(f["level"], h) if f["level"] else None
        headers |= set(al.positions) if al else set(h)
    problems = []
    for j in ans["joins"]:
        claims = core.check_claims([{"text": j["join"], "source": e} for e in j.get("evidence") or []], refs=refs)
        j["evidence"] = [dict(c["source"], verified=c["verified"]) for c in claims]
        ctx.evidence(claims)
        missing = [c for c in j.get("columns") or [] if c not in headers]
        if missing:
            problems.append("%s uses columns that are not in the files: %s" % (j["join"], ", ".join(missing)))
    admin = ctx.project.get("admin") or "admin"
    body = ["**Admin %s, need review.** The strategy for joining the five files, with the evidence found for each join." % admin]
    if problems:
        body += ["", "**Problems found by the code:**"] + ["- " + p for p in problems]
    if ans.get("answers_to_admin"):
        body += ["", "**Answers to your comments:**"] + ["- " + a for a in ans["answers_to_admin"]]
    body += _strategy_md(ans["joins"]) + ["", "The code that applies it: `nvme_hier/builder.py` (version %s)." % code_version()]
    fmt, _ = project_format(ctx.project)
    return core.Result({"joins": ans["joins"], "problems": problems, "format": fmt}, producer=producer,
                       review={"title": "The joining strategy", "body": "\n".join(body), "data": {"joins": ans["joins"]}})


def on_approve(engine, run, step, data, admin):
    out = core.jload(step["output"], {})
    if step["key"] == "last_strategy":
        for k in ("rea", "collect", "coder"):
            engine.store.exec("UPDATE step SET state='skipped', note=? WHERE run=? AND key=?",
                              ("strategy v%d approved again: reused" % out["strategy"]["version"], run["id"], k))
    elif step["key"] == "coder":
        fmt = out["format"]
        d = strategy_dir(fmt)
        n = 1 + len([x for x in os.listdir(d) if x.startswith("v") and x.endswith(".json")])
        st = {"format": fmt, "version": n, "joins": out["joins"], "approved_by": admin, "approved_at": time.time(),
              "code": "nvme_hier/builder.py", "code_version": code_version(), "run": run["id"]}
        with open(os.path.join(d, "v%d.json" % n), "w") as fh:
            json.dump(st, fh, indent=1)


# ---------------------------------------------------------------------------------------------- build
def _build_ask(ctx):
    _fmt, files = project_format(ctx.project)
    up = ctx.project.get("upload_id")
    admin = ctx.project.get("admin") or "admin"
    total = sum(f["bytes"] for f in files)
    body = ["**Admin %s, need review.** Shall I build the hierarchy?" % admin, "",
            "| file | level | size |", "|---|---|---|"] + ["| %s | %s | %s MB |" % (f["name"], f["level_label"], "{:,}".format(f["bytes"] // 1000000)) for f in files] + [
        "", "Total %s MB. The files are read row by row and written to a database on disk; only the open exchanges are kept in "
        "memory, so memory stays low whatever the size. An interrupted build continues from the last finished file or stage." % "{:,}".format(total // 1000000)]
    if up:
        body += ["", "This project is linked to the loaded upload **%s**: if its files are the same, it is reused and nothing is rebuilt." % up]
    return core.Result({"files": files}, review={"title": "Shall I build the hierarchy?", "body": "\n".join(body)})


def _build(ctx):
    from api import hier_api as H          # the application's load job: load, build, rules; resumable
    s = ctx.engine.services
    up = ctx.project.get("upload_id")
    files = {f["level"]: f["path"] for f in family1.inventory(ctx.project.get("folder")) if f["level"]}
    if up:
        d = H.upload_dir(s, up)
        m = H.read_meta(d) if d else None
        if m and m.get("status") == "loaded" and all(m.get("files", {}).get(k) == v for k, v in files.items()):
            return core.Result({"upload_id": up, "reused": True, "build": (m.get("result") or {}).get("build")})
    uid = time.strftime("up-%Y%m%d-%H%M%S-") + hashlib.sha1(str(time.time()).encode()).hexdigest()[:4]
    d = os.path.join(H.uploads_dir(s), uid)
    os.makedirs(d, exist_ok=True)
    meta = {"upload_id": uid, "created": time.time(), "operator": ctx.project.get("admin") or "admin",
            "device": ctx.project.get("name") or "", "trace_name": ctx.project.get("name") or "", "recording_date": "",
            "notes": "built by Family 2, run %s" % ctx.run["id"], "files": files, "status": "loading", "thresholds": {}}
    H.write_meta(d, meta)
    params = {"upload_id": uid, "upload_dir": d, "files": files, "operator": meta["operator"], "device": meta["device"],
              "trace_name": meta["trace_name"], "recording_date": "", "thresholds": {},
              "workers": ((s.cfg.get("pipeline") or {}).get("workers") or 0)}
    jid = s.jobs.submit("hier_load", params, H.run_hier_load)
    meta["job"] = jid
    H.write_meta(d, meta)
    ctx.engine.store.exec("UPDATE project SET upload_id=?, updated=? WHERE id=?", (uid, time.time(), ctx.run["project"]))
    while True:
        j = s.jobs.get(jid) or {}
        pr = j.get("progress") or {}
        ctx.progress("%s %% · %s: %s" % (pr.get("pct"), pr.get("step"), pr.get("detail")))
        if j.get("status") in ("done", "failed", "cancelled"):
            break
        time.sleep(5)
    if j.get("status") != "done":
        raise RuntimeError("the load and build stopped: %s (load it again from the upload page: it continues where it stopped)" % (j.get("error") or j.get("status")))
    return core.Result({"upload_id": uid, "reused": False, "job": jid, "build": ((H.read_meta(d) or {}).get("result") or {}).get("build")})


def _db(ctx):
    from api import hier_api as H
    up = ctx.output_of("build").get("upload_id") or ctx.project.get("upload_id")
    d = H.upload_dir(ctx.engine.services, up) if up else None
    if not d:
        raise RuntimeError("no built upload for this project")
    return os.path.join(d, "hier.sqlite"), up


# ---------------------------------------------------------------------------------------------- tests on real slices
def slice_check(full_db, t0, t1, box, label):
    """Rebuild the rows of [t0, t1] (plus a margin) on their own and compare with the analyzer's counts and with the
    full tree, for the parents that lie fully inside the window."""
    margin = max(5 * 10 ** 9, (t1 - t0) // 5)      # at least 5 ms of rows on each side of the window
    p = os.path.join(box, "slice_%s.sqlite" % label)
    for ext in ("", "-wal", "-shm"):
        if os.path.exists(p + ext):
            os.remove(p + ext)
    w = p.replace(".sqlite", ".work.sqlite")
    if os.path.exists(w):
        os.remove(w)
    src = sqlite3.connect("file:%s?mode=ro" % full_db, uri=True)
    ddl = {r[0]: r[1] for r in src.execute("SELECT name, sql FROM sqlite_master WHERE type='table' AND name IN ('pkt','lnk','spl','ntx','cmd','meta')")}
    src.close()
    con = sqlite3.connect(p)
    for t, sql in ddl.items():
        con.execute(sql)
    con.execute("ATTACH DATABASE ? AS f", (full_db,))
    counts = {}
    for t in ("pkt", "lnk", "spl", "ntx", "cmd"):
        if t in ddl:
            con.execute("INSERT INTO %s SELECT * FROM f.%s WHERE t_ps BETWEEN ? AND ?" % (t, t), (t0 - margin, t1 + margin))
            con.execute("UPDATE %s SET parent=NULL, parent_level=NULL, relation=NULL, dur_ps=NULL" % t)
            counts[t] = con.execute("SELECT COUNT(*) FROM %s" % t).fetchone()[0]
    if "meta" in ddl:
        con.execute("INSERT INTO meta SELECT * FROM f.meta WHERE k IN ('levels_present','load_reports','upload')")
        # the queues in force when the window opens (their last creation before it): without them the window cannot
        # know where a completion queue's slots start, and its head doorbells could not be placed as in the full tree
        ctx = [list(r) for r in con.execute(
            "SELECT t_ps, qid, qsize, prp1 FROM f.cmd c WHERE sqid = 0 AND opc = 5 AND qid IS NOT NULL AND prp1 IS NOT NULL AND t_ps < ? "
            "AND t_ps = (SELECT MAX(t_ps) FROM f.cmd c2 WHERE c2.sqid = 0 AND c2.opc = 5 AND c2.qid = c.qid AND c2.t_ps < ?)", (t0 - margin, t0 - margin))]
        con.execute("INSERT OR REPLACE INTO meta (k, v) VALUES ('cq_context', ?)", (json.dumps(ctx),))
    # the indexes the loader makes (the builder's own count checks and ours look children up by parent and rows up by
    # time: without them every check scans the whole table)
    for t in counts:
        con.execute("CREATE INDEX IF NOT EXISTS ix_%s_parent ON %s (parent_level, parent)" % (t, t))
        con.execute("CREATE INDEX IF NOT EXISTS ix_%s_t ON %s (t_ps)" % (t, t))
    con.commit()
    con.execute("DETACH DATABASE f")
    con.close()
    B.build(p)
    con = sqlite3.connect(p)
    con.execute("ATTACH DATABASE ? AS f", (full_db,))
    res = {"window": [t0, t1], "rows": counts, "count_mismatch": {}, "parent_mismatch": {}, "checked": {}}
    for parent, ncol, child, lvl in COUNT_CHECKS:
        if parent not in counts:
            continue
        # only parents whose whole life lies inside the window are judged: their start and their end (start plus the
        # duration they have in the full tree) are inside [t0, t1], and the copy reaches a margin beyond both ends
        inside = ("p.t_ps BETWEEN ? AND ? AND p.%s IS NOT NULL AND EXISTS (SELECT 1 FROM f.%s fp WHERE fp.rowid_file = p.rowid_file "
                  "AND fp.dur_ps IS NOT NULL AND fp.t_ps + fp.dur_ps <= ?)" % (ncol, parent))
        if child:
            q = ("SELECT p.rowid_file, p.%s, (SELECT COUNT(*) FROM %s c WHERE c.parent_level=? AND c.parent=p.rowid_file AND c.relation='member') "
                 "FROM %s p WHERE %s" % (ncol, child, parent, inside))
            rows = con.execute(q, (lvl, t0, t1, t1)).fetchall()
        else:
            q = ("SELECT p.rowid_file, p.%s, (SELECT COUNT(*) FROM lnk c WHERE c.parent_level=? AND c.parent=p.rowid_file AND c.relation='member') + "
                 "(SELECT COUNT(*) FROM spl c WHERE c.parent_level=? AND c.parent=p.rowid_file AND c.relation='member') "
                 "FROM %s p WHERE %s" % (ncol, parent, inside))
            rows = con.execute(q, (lvl, lvl, t0, t1, t1)).fetchall() if "lnk" in counts and "spl" in counts else []
        bad = [r for r in rows if r[1] != r[2]]
        res["checked"][parent] = len(rows)
        res["count_mismatch"][parent] = {"n": len(bad), "examples": [{"row": r[0], "analyzer": r[1], "joined": r[2]} for r in bad[:3]]}
    for t in ("pkt", "lnk", "spl", "ntx"):
        if t not in counts:
            continue
        ptab = {"pkt": "lnk", "lnk": None, "spl": "ntx", "ntx": "cmd"}[t]
        if t == "lnk":
            # a link transaction's parent is a split transaction or an NVMe transaction: compare it when that parent is whole
            cond = ("EXISTS (SELECT 1 FROM f.spl fp WHERE f.parent_level='split' AND fp.rowid_file=f.parent AND fp.t_ps >= ? AND fp.t_ps + COALESCE(fp.dur_ps, 0) <= ?) "
                    "OR EXISTS (SELECT 1 FROM f.ntx fp WHERE f.parent_level='nvme_transaction' AND fp.rowid_file=f.parent AND fp.t_ps >= ? AND fp.t_ps + COALESCE(fp.dur_ps, 0) <= ?)")
            args = (t0, t1, t0, t1)
        else:
            cond = "EXISTS (SELECT 1 FROM f.%s fp WHERE fp.rowid_file=f.parent AND fp.t_ps >= ? AND fp.t_ps + COALESCE(fp.dur_ps, 0) <= ?)" % ptab
            args = (t0, t1)
        diff = con.execute("SELECT s.rowid_file, s.parent, f.parent FROM %s s JOIN f.%s f ON f.rowid_file=s.rowid_file "
                           "WHERE s.relation='member' AND f.relation='member' AND s.parent IS NOT f.parent AND (%s) LIMIT 1000" % (t, t, cond), args).fetchall()
        res["parent_mismatch"][t] = {"n": len(diff), "examples": [{"row": r[0], "slice": r[1], "full": r[2]} for r in diff[:3]]}
    con.close()
    for ext in ("", "-wal", "-shm"):
        if os.path.exists(p + ext):
            os.remove(p + ext)
    res["passed"] = all(v["n"] == 0 for v in res["count_mismatch"].values()) and all(v["n"] == 0 for v in res["parent_mismatch"].values())
    return res


def _windows(con, n, seed, span_cmds=120):
    cmds = [r[0] for r in con.execute("SELECT t_ps FROM cmd WHERE t_ps IS NOT NULL ORDER BY t_ps")]
    if len(cmds) < 3:
        lo, hi = con.execute("SELECT MIN(t_ps), MAX(t_ps) FROM pkt").fetchone()
        return [(lo, hi)]
    rng = random.Random(seed)
    span = min(span_cmds, max(2, len(cmds) // 3))
    starts = sorted(rng.sample(range(0, max(1, len(cmds) - span)), min(n, max(1, len(cmds) - span))))
    return [(cmds[i], cmds[i + span]) for i in starts]


def _slice_test(ctx):
    db, up = _db(ctx)
    box = ctx.engine.runner.sandbox(ctx.run["id"], "code_tester")
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    n = int((ctx.engine.cfg.get("agentic") or {}).get("slices", 6))
    wins = _windows(con, max(5, min(10, n)), seed=ctx.run["id"])
    con.close()
    results = []
    for i, (t0, t1) in enumerate(wins):
        ctx.progress("window %d of %d" % (i + 1, len(wins)))
        results.append(dict(slice_check(db, t0, t1, box, "w%d" % i), name="random window %d" % (i + 1)))
    passed = sum(1 for r in results if r["passed"])
    return core.Result({"upload_id": up, "windows": results, "passed": passed, "of": len(results)})


def _breaker(ctx):
    db, up = _db(ctx)
    box = ctx.engine.runner.sandbox(ctx.run["id"], "breaker")
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    span = 2 * 10 ** 6       # 2 us around a hard spot (picoseconds)
    wins = []
    try:
        r = con.execute("SELECT f.t_ps FROM finding f WHERE f.rule='lnk.replay' ORDER BY f.t_ps LIMIT 1").fetchone()
        if r and r[0] is not None:
            wins.append(("around a resend after a Nak", r[0] - 50 * span, r[0] + 50 * span))
    except sqlite3.Error:
        pass
    r = con.execute("SELECT t_ps FROM lnk WHERE relation='orphan' AND t_ps IS NOT NULL LIMIT 1").fetchone()
    if r:
        wins.append(("around a link transaction that joined nothing", r[0] - 50 * span, r[0] + 50 * span))
    cm = [x[0] for x in con.execute("SELECT t_ps FROM cmd WHERE t_ps IS NOT NULL ORDER BY t_ps")]
    if len(cm) > 40:
        wins.append(("the start of the recording", cm[0], cm[30]))
        wins.append(("the end of the recording", cm[-31], cm[-1]))
        gaps = [(cm[i + 20] - cm[i], i) for i in range(0, len(cm) - 21)]
        _g, i = min(gaps)
        wins.append(("the busiest moment (20 commands in the shortest time)", cm[i], cm[i + 20]))
    con.close()
    results = []
    for i, (name, t0, t1) in enumerate(wins):
        ctx.progress("%s (%d of %d)" % (name, i + 1, len(wins)))
        results.append(dict(slice_check(db, t0, t1, box, "b%d" % i), name=name))
    if not results:
        return core.Result({}, skip="the data has no hard spot to test")
    return core.Result({"upload_id": up, "windows": results, "passed": sum(1 for r in results if r["passed"]), "of": len(results)})


INVARIANTS = [
    ("a TLP packet carries the PSN and direction of its link transaction",
     "SELECT COUNT(*), SUM(CASE WHEN c.psn = p.psn AND c.dir = p.dir THEN 0 ELSE 1 END) FROM (SELECT * FROM pkt WHERE parent_level='link' AND relation='member' AND tlp_type IS NOT NULL AND psn IS NOT NULL LIMIT 20000) c JOIN lnk p ON p.rowid_file=c.parent", ["PSN", "Link Dir"]),
    ("an Ack or Nak goes the other way and names a PSN at or after its link transaction's",
     "SELECT COUNT(*), SUM(CASE WHEN c.dir != p.dir AND c.acknak >= p.psn THEN 0 ELSE 1 END) FROM (SELECT * FROM pkt WHERE parent_level='link' AND relation='member' AND dllp_type IS NOT NULL AND acknak IS NOT NULL LIMIT 20000) c JOIN lnk p ON p.rowid_file=c.parent", ["AckNak Seq Num", "Link Dir"]),
    ("a link transaction in a split transaction has the split's requester and tag",
     "SELECT COUNT(*), SUM(CASE WHEN c.rid = p.rid AND c.tag = p.tag THEN 0 ELSE 1 END) FROM (SELECT * FROM lnk WHERE parent_level='split' AND relation='member' LIMIT 20000) c JOIN spl p ON p.rowid_file=c.parent", ["RequesterID", "Tag"]),
    ("an NVMe transaction with a queue id and a command id has its command's",
     "SELECT COUNT(*), SUM(CASE WHEN c.sqid = p.sqid AND c.cid = p.cid THEN 0 ELSE 1 END) FROM (SELECT * FROM ntx WHERE parent_level='nvme_command' AND relation='member' AND sqid IS NOT NULL AND cid IS NOT NULL LIMIT 20000) c JOIN cmd p ON p.rowid_file=c.parent", ["SQID", "CID"]),
]


def _independent(ctx):
    db, up = _db(ctx)
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    out = []
    for name, sql, cols in INVARIANTS:
        try:
            n, bad = con.execute(sql).fetchone()
        except sqlite3.Error as e:
            out.append({"check": name, "error": str(e)})
            continue
        meanings = {}
        for d in family1.dictionaries_for_level("packets") + family1.dictionaries_for_level("link") + family1.dictionaries_for_level("split") + \
                family1.dictionaries_for_level("nvme_transaction") + family1.dictionaries_for_level("nvme_command"):
            for r in d["columns"]:
                if r["column"] in cols and r.get("meaning"):
                    meanings.setdefault(r["column"], r["meaning"][:160])
        out.append({"check": name, "rows_checked": n or 0, "violations": bad or 0, "columns": cols, "meanings": meanings})
    con.close()
    st = ctx.output_of("slice_test")
    br = ctx.output_of("breaker")
    admin = ctx.project.get("admin") or "admin"
    body = ["**Admin %s, need review.** The tree of upload **%s** is built and tested." % (admin, up), "",
            "**Code tester:** %s of %s random windows passed." % (st.get("passed", "-"), st.get("of", "-")),
            "**Breaker:** %s of %s hard windows passed." % (br.get("passed", "-"), br.get("of", "-")), "",
            "**Independent tester** (the column meanings only):", "", "| check | rows checked | violations |", "|---|---|---|"] + [
        "| %s | %s | %s |" % (o["check"], "{:,}".format(o.get("rows_checked", 0)), o.get("violations", o.get("error"))) for o in out]
    fails = [w for w in (st.get("windows") or []) + (br.get("windows") or []) if not w["passed"]]
    if fails:
        body += ["", "**Windows that did not pass** (a parent cut by the window edge is excluded; what remains is a real difference):"]
        for w in fails[:8]:
            body.append("- %s: counts %s; parents %s" % (w["name"], {k: v["n"] for k, v in w["count_mismatch"].items() if v["n"]},
                                                           {k: v["n"] for k, v in w["parent_mismatch"].items() if v["n"]}))
    body += ["", "Approve to accept the tree for this project."]
    return core.Result({"upload_id": up, "invariants": out}, review={"title": "The tree is built and tested", "body": "\n".join(body)})


def on_finish(engine, rid):
    view = engine.view(rid)
    ind = next((s for s in view["steps"] if s["key"] == "independent"), None)
    up = ((ind or {}).get("output") or {}).get("upload_id")
    if up:
        engine.store.exec("UPDATE project SET upload_id=?, updated=? WHERE id=?", (up, time.time(), view["run"]["project"]))
    engine.store.exec("UPDATE run SET summary=? WHERE id=?", ("hierarchy ready: upload %s" % up if up else "finished", rid))
