"""Family 3 — Rules: sections, levels and items; one JSON rule file per item; the code is made from the rule.

A rule file (knowledge/rules/<section>/<level>/<id>.json) holds the item's definition in the admin's words, a PLAN
(what to compute, from which table and columns, with which filter), what to export, its version, who approved it and
its history. "Fix the rules, not the code": the code is generated from the plan by a fixed translator (compile_rule),
so the same rule always gives the same code, and a changed rule gives changed code, tied to the rule's version.

Plan kinds:
  distribution    the share of each value (or named value) of one column among the rows of one level
  read_pattern    reads classified as sequential (starting at the block after the previous read of the namespace
                  ended) or random (RndRead), with the first read of each namespace apart
  detection_rule  the defects found by one of the detector's rules (Section 2); stage 1 and stage 2 open from each row
  condition       the rows of one level whose columns meet the written conditions

Runs:
  rule_draft  write   the Rule writer turns the admin's words into a rule (definition + plan + export), the code checks
                      that the plan compiles against the real columns. REVIEW -> approve stores a new version
  rule_run    code    the code is generated from the approved rule version
              run     it runs on the project's built data (read only)
              test    the Tester checks the result independently (totals, percentages, the rows exist, the columns
                      mean what Family 1's dictionary says)
              export  CSV and HTML files
              result  REVIEW the result (approve accepts it; to change it, edit the rule)
"""
import csv
import html
import json
import os
import re
import sqlite3
import sys
import time

from . import core, family1

APP = family1.APP
sys.path.insert(0, APP)
sys.path.insert(0, os.path.join(APP, "app"))
from nvme_hier import columns as C, loader as L, names as N, rules as RL   # noqa: E402

SECTIONS = {"analytics": "Section 1 · Data analytics", "errors": "Section 2 · Error roots"}
LEVELS = ["nvme_command", "nvme_transaction", "link", "split", "packets"]
LEVEL_LABEL = {"nvme_command": "NVMe commands", "nvme_transaction": "NVMe transactions", "link": "Link transactions",
               "split": "Split transactions", "packets": "Packets"}
TABLE = L.TABLE
PREFIX_LEVEL = {"pkt": "packets", "lnk": "link", "spl": "split", "ntx": "nvme_transaction", "cmd": "nvme_command"}
OPS = {"eq": "=", "ne": "!=", "gt": ">", "ge": ">=", "lt": "<", "le": "<="}
KINDS = ("distribution", "read_pattern", "detection_rule", "condition")
RUN_TIMEOUT_S = 900


def rules_root():
    d = os.path.join(family1.knowledge_dir(), "rules")
    os.makedirs(d, exist_ok=True)
    return d


def rule_path(section, level, rid):
    if section not in SECTIONS or level not in LEVELS or not re.match(r"^[A-Za-z0-9_.-]+$", rid or ""):
        raise ValueError("bad rule address")
    return os.path.join(rules_root(), section, level, rid + ".json")


def load_rule(section, level, rid):
    p = rule_path(section, level, rid)
    return json.load(open(p)) if os.path.exists(p) else None


def save_rule(r):
    p = rule_path(r["section"], r["level"], r["id"])
    os.makedirs(os.path.dirname(p), exist_ok=True)
    tmp = p + ".tmp"
    with open(tmp, "w") as fh:
        json.dump(r, fh, indent=1)
    os.replace(tmp, p)


def typed_columns(level):
    """The typed columns of a level's table: (sql name, the file's column name)."""
    seen, out = set(), []
    for cname, sql, _fn in L.KEYS.get(level, []):
        if sql not in seen:
            seen.add(sql)
            out.append((sql, cname))
    return out


# ---------------------------------------------------------------------------------------------- seeds
def seed():
    """The first items, written once (never over an existing file): two analytics items for NVMe commands and the
    detector's rules as Section 2 drafts. Every seed is a DRAFT until the admin approves it."""
    t = time.time()

    def put(r):
        if load_rule(r["section"], r["level"], r["id"]) is None:
            r.setdefault("status", "draft")
            r.setdefault("version", 0)
            r.setdefault("history", [])
            r.setdefault("created", t)
            r.setdefault("export", {"formats": ["csv", "html"]})
            save_rule(r)
    put({"id": "command_type_share", "section": "analytics", "level": "nvme_command", "name": "Command type percentages",
         "description": "What share of all NVMe commands each command type is.",
         "definition": "Every NVMe command of the recording is counted once. Its type is its opcode, named from the NVMe "
                       "specification's lists: admin commands are the ones on queue 0, I/O commands are on the other queues. "
                       "The result is one line per type: how many commands, and what percentage of all commands.",
         "kind": "distribution", "plan": {"table": "cmd", "label": {"expr": "opcode_name"}, "filter": [], "measure": "percent"},
         "family1": {"columns": ["OPC", "SQID"]}, "source": "the owner's statement of 2026-11-07, example 2"})
    put({"id": "read_pattern", "section": "analytics", "level": "nvme_command", "name": "Read vs RndRead vs sequential read",
         "description": "How many reads are sequential and how many are random (RndRead).",
         "definition": "A read is an NVMe Read command (opcode 0x02) on an I/O queue. Reads are taken in time order for each "
                       "namespace. A read is SEQUENTIAL when it starts at the block right after the block where the previous "
                       "read of the same namespace ended (start block = previous start + previous block count; the export's "
                       "NLB is 0-based, so the previous read covers NLB + 1 blocks). Any other read is RANDOM (RndRead). The "
                       "first read of each namespace has no previous read and is counted apart. TO CONFIRM WITH THE ADMIN: "
                       "whether reads on different queues count as one stream, and whether a small gap still counts as sequential.",
         "kind": "read_pattern", "plan": {"opcode": 2, "partition": ["nsid"], "gap_blocks": 0},
         "family1": {"columns": ["OPC", "SQID", "NSID", "SLBA", "NLB", "Time Stamp"]}, "source": "the owner's statement, example 1"})
    names = {}
    try:
        sys.path.insert(0, os.path.join(APP, "app"))
        from api import hier_api as H
        names = getattr(H, "RULE_WORDS", {}) or {}
    except Exception:       # noqa: BLE001 - the words are only labels
        names = {}
    for rule, (kind, text, ref) in RL.BASIS.items():
        lvl = PREFIX_LEVEL.get(rule.split(".")[0])
        if not lvl:
            continue
        demo = rule == "cmd.incomplete"
        put({"id": rule.replace(".", "_"), "section": "errors", "level": lvl,
             "name": "A command that never completed (host timeout)" if demo else (names.get(rule) or text[:80]),
             "description": text, "definition": text + " (basis: %s; %s)" % (kind, ref),
             "kind": "detection_rule", "plan": {"rule": rule}, "demo": demo, "basis": {"kind": kind, "ref": ref},
             "source": "imported from the detector (nvme_hier/rules.py); approve, edit or drop"})


def tree():
    seed()
    out = []
    for sec, label in SECTIONS.items():
        lv = []
        for level in LEVELS:
            d = os.path.join(rules_root(), sec, level)
            items = []
            if os.path.isdir(d):
                for fn in sorted(os.listdir(d)):
                    if fn.endswith(".json"):
                        r = json.load(open(os.path.join(d, fn)))
                        items.append({"id": r["id"], "name": r["name"], "status": r.get("status"), "version": r.get("version", 0),
                                      "demo": r.get("demo", False), "kind": r.get("kind")})
            items.sort(key=lambda x: (not x["demo"], x["status"] != "approved", x["name"].lower()))
            lv.append({"level": level, "label": LEVEL_LABEL[level], "items": items})
        out.append({"section": sec, "label": label, "levels": lv})
    return out


def add_item(section, level, name, description, admin):
    rid = re.sub(r"[^a-z0-9]+", "_", (name or "").lower()).strip("_")[:50] or "item"
    base, n = rid, 2
    while load_rule(section, level, rid):
        rid, n = "%s_%d" % (base, n), n + 1
    r = {"id": rid, "section": section, "level": level, "name": name.strip(), "description": (description or "").strip(),
         "definition": "", "kind": None, "plan": None, "status": "draft", "version": 0, "history": [], "created": time.time(),
         "created_by": admin, "export": {"formats": ["csv", "html"]}, "source": "added by %s" % admin}
    save_rule(r)
    return r


# ---------------------------------------------------------------------------------------------- the translator
def _opcode_case():
    io = " ".join("WHEN %d THEN '%s'" % (k, v.replace("'", "''")) for k, v in sorted(N.IO_OPC.items()))
    ad = " ".join("WHEN %d THEN '%s (admin)'" % (k, v.replace("'", "''")) for k, v in sorted(N.ADMIN_OPC.items()))
    return ("CASE WHEN sqid = 0 THEN CASE opc %s ELSE printf('opcode 0x%%02X (admin)', opc) END "
            "ELSE CASE opc %s ELSE printf('opcode 0x%%02X', opc) END END" % (ad, io))


def _where(table, flt, cols, params):
    out = []
    for f in flt or []:
        c, op, v = f.get("column"), f.get("op"), f.get("value")
        if c not in cols:
            raise ValueError("the column '%s' is not a column of the %s table (%s)" % (c, table, ", ".join(sorted(cols))))
        if op in OPS:
            out.append("%s %s ?" % (c, OPS[op]))
            params.append(v)
        elif op == "in":
            vals = v if isinstance(v, list) else [x.strip() for x in str(v).split(",")]
            out.append("%s IN (%s)" % (c, ",".join("?" * len(vals))))
            params += vals
        elif op == "contains":
            out.append("%s LIKE ?" % c)
            params.append("%%%s%%" % v)
        elif op == "blank":
            out.append("%s IS NULL" % c)
        elif op == "notblank":
            out.append("%s IS NOT NULL" % c)
        else:
            raise ValueError("unknown condition '%s'" % op)
    return " AND ".join(out) or "1"


def compile_rule(r, cols=None):
    """-> (sql, params, population_sql, population_params). cols: the real columns of the table (checked)."""
    k, p = r.get("kind"), r.get("plan") or {}
    if k not in KINDS:
        raise ValueError("the rule has no plan yet (kind %r)" % k)
    if k == "distribution":
        t = p.get("table")
        if t not in TABLE.values():
            raise ValueError("unknown table %r" % t)
        cols = cols or {s for s, _ in typed_columns({v: k2 for k2, v in TABLE.items()}[t])}
        lab = p.get("label") or {}
        if lab.get("expr") == "opcode_name":
            if t != "cmd":
                raise ValueError("opcode names are for the command table")
            label = _opcode_case()
        elif lab.get("column") in cols:
            label = "COALESCE(CAST(%s AS TEXT), '(blank)')" % lab["column"]
        else:
            raise ValueError("the label column %r is not a column of %s" % (lab.get("column"), t))
        params = []
        where = _where(t, p.get("filter"), cols | {"opc", "sqid"}, params)
        base = "SELECT %s AS label FROM %s WHERE %s" % (label, t, where)
        sql = ("WITH base AS (%s)\nSELECT label, COUNT(*) AS count, ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM base), 3) AS percent\n"
               "FROM base GROUP BY label ORDER BY count DESC, label" % base)
        return sql, params, "SELECT COUNT(*) FROM %s WHERE %s" % (t, where), list(params)
    if k == "read_pattern":
        part = [c for c in (p.get("partition") or ["nsid"]) if c in ("nsid", "sqid")] or ["nsid"]
        gap = int(p.get("gap_blocks") or 0)
        labels = [p.get("first_label") or "first read of its namespace", p.get("seq_label") or "sequential read",
                  p.get("rnd_label") or "random read (RndRead)"]
        sql = ("WITH r AS (SELECT slba, nlb, LAG(slba) OVER w AS pslba, LAG(nlb) OVER w AS pnlb FROM cmd\n"
               "  WHERE opc = ? AND sqid != 0 AND slba IS NOT NULL AND nlb IS NOT NULL\n"
               "  WINDOW w AS (PARTITION BY %s ORDER BY t_ps, rowid_file)),\n"
               "l AS (SELECT CASE WHEN pslba IS NULL THEN ? WHEN slba BETWEEN pslba + pnlb + 1 AND pslba + pnlb + 1 + ? THEN ? ELSE ? END AS label FROM r)\n"
               "SELECT label, COUNT(*) AS count, ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM l), 3) AS percent FROM l GROUP BY label ORDER BY count DESC"
               % ", ".join(part))
        params = [int(p.get("opcode", 2)), labels[0], gap, labels[1], labels[2]]
        return sql, params, "SELECT COUNT(*) FROM cmd WHERE opc = ? AND sqid != 0 AND slba IS NOT NULL AND nlb IS NOT NULL", [int(p.get("opcode", 2))]
    if k == "detection_rule":
        rule = p.get("rule")
        if rule not in RL.BASIS:
            raise ValueError("unknown detector rule %r" % rule)
        sql = ("SELECT f.id AS defect, f.level, f.rule, f.name, f.severity, f.row_n AS row_number, f.t_ps, f.cmd_rowid AS command_row\n"
               "FROM finding f WHERE f.rule = ? ORDER BY f.id")
        return sql, [rule], "SELECT COUNT(*) FROM finding WHERE rule = ?", [rule]
    t = p.get("table")
    if t not in TABLE.values():
        raise ValueError("unknown table %r" % t)
    level = {v: k2 for k2, v in TABLE.items()}[t]
    cols = cols or {s for s, _ in typed_columns(level)}
    show = [c for c in (p.get("columns") or []) if c in cols] or ["n", "t_ps"]
    params = []
    where = _where(t, p.get("filter"), cols, params)
    sql = "SELECT rowid_file AS row, %s FROM %s WHERE %s ORDER BY rowid_file" % (", ".join(show), t, where)
    return sql, params, "SELECT COUNT(*) FROM %s WHERE %s" % (t, where), list(params)


def describe(r):
    """The plan in plain words, for the admin."""
    k, p = r.get("kind"), r.get("plan") or {}
    if k == "distribution":
        lab = p.get("label") or {}
        what = "the command type (opcode name)" if lab.get("expr") == "opcode_name" else "the column %s" % lab.get("column")
        f = "; only rows where " + ", ".join("%s %s %s" % (x["column"], x["op"], x.get("value", "")) for x in p["filter"]) if p.get("filter") else ""
        return "Count the rows of the %s table by %s%s, and give each value's share of all of them in percent." % (p.get("table"), what, f)
    if k == "read_pattern":
        return ("Take the Read commands (opcode 0x%02X) on I/O queues in time order per %s. A read is sequential when it starts "
                "within %d block(s) after the end of the previous read; otherwise random (RndRead). The first read of each stream "
                "is counted apart." % (int(p.get("opcode", 2)), " and ".join(p.get("partition") or ["nsid"]), int(p.get("gap_blocks") or 0) + 1))
    if k == "detection_rule":
        return "List every defect the detector's rule %s found in the data; each row opens stage 1 (isolation) and stage 2 (test case)." % p.get("rule")
    if k == "condition":
        return "List the rows of the %s table where %s." % (p.get("table"), ", ".join("%s %s %s" % (x["column"], x["op"], x.get("value", "")) for x in p.get("filter") or []) or "(no condition)")
    return "No plan yet: describe the item in the chat."


# ---------------------------------------------------------------------------------------------- the runs
def steps(params, project):
    kind = params.get("_kind")
    if kind == "rule_draft":
        return [{"key": "write", "title": "Rule writer: the rule from the admin's words", "family": "3", "agent": "Rule writer", "review": True}]
    out = [{"key": "code", "title": "Code from the approved rule", "family": "3", "agent": "Coder"},
           {"key": "run", "title": "Run on the project's data", "family": "3", "agent": "Runner"},
           {"key": "test", "title": "Tester: check the result independently", "family": "3", "agent": "Tester"},
           {"key": "export", "title": "Export the result", "family": "3", "agent": "Runner"},
           {"key": "result", "title": "The result, for review", "family": "3", "agent": "Manager", "review": True}]
    return out


def run_step(ctx):
    return globals()["_" + ctx.step["key"]](ctx)


def _rule(ctx):
    p = ctx.params
    r = load_rule(p["section"], p["level"], p["id"])
    if r is None:
        raise RuntimeError("no such item")
    return r


WRITER_INSTRUCTION = """You are the Rule writer of Family 3. Turn the admin's words into a rule for one item of the
analysis. A rule has: "definition" (plain sentences, in the admin's terms, saying exactly what is counted or found and
how), "kind" (one of: distribution, read_pattern, detection_rule, condition), "plan" (see PLAN SHAPES), and "questions"
(what you still need the admin to decide; empty when nothing is open). Use ONLY the columns listed in COLUMNS (sql
names). Keep everything the admin did not ask to change. Answer every admin message in "answers"."""
WRITER_SHAPE = """{"definition": "...", "kind": "distribution|read_pattern|detection_rule|condition", "plan": {...}, "questions": ["..."], "answers": ["..."]}
PLAN SHAPES:
 distribution:   {"table": "<cmd|ntx|spl|lnk|pkt>", "label": {"column": "<sql column>"} or {"expr": "opcode_name"}, "filter": [{"column": "...", "op": "eq|ne|gt|ge|lt|le|in|contains|blank|notblank", "value": ...}], "measure": "percent"}
 read_pattern:   {"opcode": 2, "partition": ["nsid"] or ["nsid","sqid"], "gap_blocks": 0}
 detection_rule: {"rule": "<one of the detector's rule ids>"}
 condition:      {"table": "...", "filter": [...], "columns": ["<sql columns to show>"]}"""


def _write(ctx):
    r = _rule(ctx)
    msgs = [m for m in [ctx.params.get("message")] + (ctx.input.get("comments") or []) if m]
    level = r["level"]
    cols = typed_columns(level)
    dicts = family1.dictionaries_for_level(level)
    meanings = {}
    if dicts:
        file_of = {cname: sql for sql, cname in cols}
        for row in dicts[0]["columns"]:
            if row["column"] in file_of and row.get("meaning"):
                meanings[file_of[row["column"]]] = row["meaning"][:200]

    def standin():
        out = {"definition": r.get("definition") or "", "kind": r.get("kind"), "plan": r.get("plan"), "questions": [], "answers": []}
        for m in msgs:
            low = m.lower()
            hit = next((sql for sql, cname in cols if re.search(r"\b(by|per)\s+%s\b" % re.escape(cname.lower()), low) or re.search(r"\b(by|per)\s+%s\b" % re.escape(sql), low)), None)
            if any(w in low for w in ("percent", "share", "distribution", "how many")) and hit:
                out["kind"], out["plan"] = "distribution", {"table": TABLE[level], "label": {"column": hit}, "filter": [], "measure": "percent"}
                out["answers"].append("Made a distribution of the %s table by %s." % (TABLE[level], hit))
            out["definition"] = (out["definition"] + "\nThe admin's words: " + m).strip()
        if not out["kind"]:
            out["questions"].append("Which column, and what should be counted or found? (the stand-in needs words like 'percentage by <column>'; a model run understands more)")
        return out
    ans, producer, _ = ctx.engine.runner.ask(ctx.run["id"], "rule_writer_" + r["id"], WRITER_INSTRUCTION,
                                             {"item": {k: r.get(k) for k in ("name", "description", "definition", "kind", "plan")},
                                              "admin_messages": msgs, "COLUMNS": [{"sql": s, "file_column": c, "meaning": meanings.get(s, "")} for s, c in cols],
                                              "detector_rules": sorted(RL.BASIS) if r["section"] == "errors" else []},
                                             WRITER_SHAPE, "definition", standin)
    draft = dict(r, definition=ans.get("definition") or r.get("definition"), kind=ans.get("kind") or r.get("kind"), plan=ans.get("plan") or r.get("plan"))
    problem, sql = "", ""
    try:
        sql, params, _ps, _pp = compile_rule(draft)
    except Exception as e:      # noqa: BLE001 - shown to the admin
        problem, params = str(e), []
    admin = ctx.project.get("admin") or "admin"
    body = ["**Admin %s, need review.** The rule of **%s** (%s, %s)." % (admin, r["name"], SECTIONS[r["section"]], LEVEL_LABEL[level]), "",
            "**Definition:** " + (draft.get("definition") or "(none)"), "", "**What the code will do:** " + describe(draft)]
    if ans.get("answers"):
        body += ["", "**Answers to you:**"] + ["- " + a for a in ans["answers"]]
    if ans.get("questions"):
        body += ["", "**Still to decide:**"] + ["- " + q for q in ans["questions"]]
    if problem:
        body += ["", "**The code cannot be made from this plan yet:** " + problem]
    else:
        body += ["", "The code that will be generated:", "", "```sql", sql, "```"]
    body += ["", "Approve to store it as version %d. Ask for changes to keep talking." % (int(r.get("version") or 0) + 1)]
    return core.Result({"draft": {k: draft.get(k) for k in ("definition", "kind", "plan")}, "problem": problem, "questions": ans.get("questions") or []},
                       producer=producer, review={"title": "Rule: %s" % r["name"], "body": "\n".join(body), "data": {"draft": draft, "problem": problem}})


def on_approve(engine, run, step, data, admin):
    params = core.jload(run["params"], {})
    if step["key"] == "write":
        out = core.jload(step["output"], {})
        if out.get("problem"):
            raise ValueError("the rule cannot be approved while its code cannot be made: %s" % out["problem"])
        r = load_rule(params["section"], params["level"], params["id"])
        r["history"].append({k: r.get(k) for k in ("version", "status", "definition", "kind", "plan", "approved_by", "approved_at")})
        r.update(out["draft"])
        r["version"] = int(r.get("version") or 0) + 1
        r["status"], r["approved_by"], r["approved_at"] = "approved", admin, time.time()
        save_rule(r)


def _code(ctx):
    r = _rule(ctx)
    if r.get("status") != "approved":
        raise RuntimeError("the rule '%s' is not approved yet: edit it, review it and approve it first" % r["name"])
    sql, params, psql, pparams = compile_rule(r)
    d = os.path.join(family1.knowledge_dir(), "rules_code", r["section"], r["level"])
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, "%s.v%d.sql" % (r["id"], r["version"]))
    with open(path, "w") as fh:
        fh.write("-- generated from the rule %s/%s/%s version %d (approved by %s)\n-- %s\n-- parameters: %s\n%s\n" % (
            r["section"], r["level"], r["id"], r["version"], r.get("approved_by"), describe(r), json.dumps(params), sql))
    return core.Result({"sql": sql, "params": params, "population_sql": psql, "population_params": pparams, "file": path, "version": r["version"]})


def _upload_db(ctx):
    from api import hier_api as H
    up = ctx.params.get("upload_id") or ctx.project.get("upload_id")
    d = H.upload_dir(ctx.engine.services, up) if up else None
    if not d or not os.path.exists(os.path.join(d, "hier.sqlite")):
        raise RuntimeError("the project has no built data: run Family 2 (or link a loaded upload on the start page)")
    return os.path.join(d, "hier.sqlite"), up


def _ro(db):
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    t0 = time.time()
    con.set_progress_handler(lambda: 1 if time.time() - t0 > RUN_TIMEOUT_S else 0, 100000)
    return con


def _run(ctx):
    code = ctx.output_of("code")
    db, up = _upload_db(ctx)
    ctx.progress("running the generated code on upload %s" % up)
    con = _ro(db)
    try:
        cur = con.execute(code["sql"], code["params"])
        cols = [d[0] for d in cur.description]
        rows = cur.fetchall()
    finally:
        con.close()
    box = ctx.engine.runner.sandbox(ctx.run["id"], "runner")
    path = os.path.join(box, "result.json")
    with open(path, "w") as fh:
        json.dump({"columns": cols, "rows": rows}, fh)
    return core.Result({"upload_id": up, "columns": cols, "rows": len(rows), "result_file": path, "head": rows[:200]})


def _test(ctx):
    r = _rule(ctx)
    code, res = ctx.output_of("code"), ctx.output_of("run")
    db, _up = _upload_db(ctx)
    data = json.load(open(res["result_file"]))
    rows, cols = data["rows"], data["columns"]
    checks = []
    con = _ro(db)
    try:
        population = con.execute(code["population_sql"], code["population_params"]).fetchone()[0]
        if r["kind"] in ("distribution", "read_pattern"):
            total = sum(x[1] for x in rows)
            checks.append({"check": "every row is counted once (sum of the counts = the rows the rule looks at)", "ok": total == population,
                           "detail": "%s counted, %s rows" % ("{:,}".format(total), "{:,}".format(population))})
            pct = sum(x[2] for x in rows)
            checks.append({"check": "the percentages add up to 100", "ok": abs(pct - 100.0) < 0.01 * max(1, len(rows)) or population == 0, "detail": "%.3f" % pct})
            blank = sum(x[1] for x in rows if x[0] in (None, "(blank)"))
            checks.append({"check": "rows without a value", "ok": True, "detail": "%s rows" % "{:,}".format(blank)})
        elif r["kind"] == "detection_rule":
            checks.append({"check": "every defect the detector filed is listed", "ok": len(rows) == population, "detail": "%d of %d" % (len(rows), population)})
            missing = 0
            for x in rows[:5000]:
                lvl, rowid = x[1], x[5]
                t = TABLE.get(lvl)
                if t and rowid is not None and con.execute("SELECT 1 FROM %s WHERE n=? OR rowid_file=? LIMIT 1" % t, (rowid, rowid)).fetchone() is None:
                    missing += 1
            checks.append({"check": "every listed defect points to a row that exists", "ok": missing == 0, "detail": "%d missing" % missing})
            if (r.get("plan") or {}).get("rule") == "cmd.incomplete" and rows:
                with_cqe = con.execute("SELECT COUNT(*) FROM finding f WHERE f.rule='cmd.incomplete' AND EXISTS (SELECT 1 FROM ntx n WHERE n.parent_level='nvme_command' "
                                       "AND n.parent=f.cmd_rowid AND n.type LIKE '%Completion Queue Entry%')").fetchone()[0]
                checks.append({"check": "none of these commands has a completion entry in the tree (the definition holds in the data)", "ok": with_cqe == 0,
                               "detail": "%d with a completion entry" % with_cqe})
        else:
            checks.append({"check": "the listed rows are all the rows that meet the condition", "ok": len(rows) == population, "detail": "%d of %d" % (len(rows), population)})
    finally:
        con.close()
    dicts = family1.dictionaries_for_level(r["level"])
    used = (r.get("family1") or {}).get("columns") or []
    if dicts:
        known = {x["column"]: x for x in dicts[0]["columns"]}
        for c in used:
            m = known.get(c)
            checks.append({"check": "Family 1 knows the column %s" % c, "ok": bool(m and m.get("meaning")),
                           "detail": (m or {}).get("meaning", "not in the approved dictionary")[:200]})
    else:
        checks.append({"check": "Family 1's dictionary of this level", "ok": True, "detail": "not approved yet: the columns' meanings are not checked (run Family 1 to add this check)"})
    return core.Result({"checks": checks, "passed": all(c["ok"] for c in checks), "columns": cols})


def _export(ctx):
    r = _rule(ctx)
    res = ctx.output_of("run")
    test = ctx.output_of("test")
    data = json.load(open(res["result_file"]))
    d = os.path.join(family1.knowledge_dir(), "exports", r["section"], r["level"], r["id"])
    os.makedirs(d, exist_ok=True)
    stem = "%s_v%d_run%d" % (r["id"], r["version"], ctx.run["id"])
    files = {}
    if "csv" in (r.get("export") or {}).get("formats", ["csv"]):
        p = os.path.join(d, stem + ".csv")
        with open(p, "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(data["columns"])
            w.writerows(data["rows"])
        files["csv"] = p
    if "html" in (r.get("export") or {}).get("formats", ["html"]):
        p = os.path.join(d, stem + ".html")
        links = r["section"] == "errors"
        rows_html = []
        for x in data["rows"][:20000]:
            cells = "".join("<td>%s</td>" % html.escape("" if v is None else str(v)) for v in x)
            if links:
                cells += '<td><a href="/isolate?upload=%s&finding=%s">stage 1 and 2</a></td>' % (html.escape(str(res["upload_id"])), x[0])
            rows_html.append("<tr>%s</tr>" % cells)
        with open(p, "w") as fh:
            fh.write("<!doctype html><meta charset=utf-8><title>%s</title><style>body{font-family:system-ui,sans-serif;margin:24px}"
                     "table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:3px 8px;font-size:13px}th{background:#f2f2f2}</style>"
                     "<h1>%s</h1><p>%s · %s · rule version %d (approved by %s) · upload %s · %s</p><p><b>Definition:</b> %s</p><p><b>Checks:</b> %s</p>"
                     "<table><tr>%s%s</tr>%s</table>" % (
                         html.escape(r["name"]), html.escape(r["name"]), SECTIONS[r["section"]], LEVEL_LABEL[r["level"]], r["version"],
                         html.escape(r.get("approved_by") or "?"), html.escape(str(res["upload_id"])), time.strftime("%Y-%m-%d %H:%M"),
                         html.escape(r.get("definition") or ""),
                         "; ".join(html.escape("%s: %s (%s)" % (c["check"], "ok" if c["ok"] else "NOT OK", c["detail"])) for c in test.get("checks") or []),
                         "".join("<th>%s</th>" % html.escape(c) for c in data["columns"]), "<th>open</th>" if links else "", "".join(rows_html)))
        files["html"] = p
    return core.Result({"files": files})


def _result(ctx):
    r = _rule(ctx)
    res, test, exp = ctx.output_of("run"), ctx.output_of("test"), ctx.output_of("export")
    admin = ctx.project.get("admin") or "admin"
    head = res.get("head") or []
    cols = res.get("columns") or []
    body = ["**Admin %s, need review.** %s (rule version %d) on upload %s: %s rows." % (admin, r["name"], r["version"], res.get("upload_id"), "{:,}".format(res.get("rows", 0))),
            "", "**Tester:** " + ("all checks passed" if test.get("passed") else "SOME CHECKS FAILED"), ""] + [
        "- %s %s: %s" % ("✔" if c["ok"] else "✘", c["check"], c["detail"]) for c in test.get("checks") or []]
    if head:
        body += ["", "| %s |" % " | ".join(cols), "|%s" % ("---|" * len(cols))] + ["| %s |" % " | ".join("" if v is None else str(v) for v in x) for x in head[:25]]
        if len(head) > 25:
            body.append("… %s more rows in the export" % "{:,}".format(res.get("rows", 0) - 25))
    body += ["", "Exported: " + ", ".join(os.path.basename(p) for p in (exp.get("files") or {}).values()),
             "", "Approve to accept the result. To change what is computed, edit the rule (the code follows the rule)."]
    return core.Result({"rows": res.get("rows"), "files": exp.get("files")},
                       review={"title": "Result: %s" % r["name"], "body": "\n".join(body),
                               "data": {"columns": cols, "head": head[:200], "files": exp.get("files"), "upload_id": res.get("upload_id"), "section": r["section"]}})


def on_finish(engine, rid):
    run = engine.store.one("SELECT params FROM run WHERE id=?", (rid,))
    p = core.jload(run["params"], {})
    r = load_rule(p.get("section"), p.get("level"), p.get("id")) if p.get("id") else None
    if r and p.get("_kind") == "rule_run":
        r["last_run"] = {"run": rid, "at": time.time(), "upload_id": p.get("upload_id")}
        save_rule(r)
