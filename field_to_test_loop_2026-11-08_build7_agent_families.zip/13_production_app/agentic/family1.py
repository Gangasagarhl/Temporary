"""Family 1 — Data Experts: one sub-family per CSV of the input folder (Explorer, Grounder, Manager) -> one approved
data dictionary per CSV.

Steps of a run (kind "family1"), in order:
  director              lists the CSVs of the folder and what each one looks like (its level, its size, its header)
  explore:<csv>         the Explorer profiles the CSV by code (a sample read from the start and from random places of
                        the file, never the whole file in memory), then reads the profile and says what the data shows
  ground:<csv>          the Grounder looks every column and keyword up in the reference documents and says what it
                        means there, quoting the line
  manager:<csv>         the Manager merges both into the data dictionary: every column, what the data shows, what it
                        means, the source, and any disagreement (the data wins; a disagreement is shown to the admin).
                        REVIEW: "Admin <name>, need review" -> approve (with edits) / change / reject
Every claim is checked by code (core.check_claims): a data claim must quote a value seen in that column, a document
claim must quote a line of that document.
"""
import csv
import hashlib
import io
import json
import os
import random
import re
import sys
import time
from collections import Counter

from . import core

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
from nvme_hier import columns as C, loader as L   # noqa: E402

SAMPLE_HEAD = 3000
SAMPLE_SPOTS = 4
SAMPLE_SPOT_ROWS = 1000
BATCH = 120


def knowledge_dir():
    d = os.path.join(APP, "knowledge")
    os.makedirs(d, exist_ok=True)
    return d


# ---------------------------------------------------------------------------------------------- the inventory
def inventory(folder):
    out = []
    if not folder or not os.path.isdir(folder):
        return out
    for fn in sorted(os.listdir(folder)):
        p = os.path.join(folder, fn)
        if not (os.path.isfile(p) and fn.lower().endswith(".csv")):
            continue
        try:
            header, _rows = L.sniff(p, 0)
        except (OSError, UnicodeDecodeError):
            continue
        level = L.guess_level(header)
        out.append({"name": fn, "path": p, "bytes": os.path.getsize(p), "level": level,
                    "level_label": C.LEVEL_LABEL.get(level) if level else "not one of the five analyzer levels",
                    "columns": len(header), "format_key": format_key(level, header)})
    return out


def format_key(level, header):
    """The file format: the level and its header cells. The same key = the same export layout."""
    cells = [re.sub(r"^\d+(\.\d+)?$|^\d+ (warning|error)\(s\)$", "<value>", (h or "").strip()) for h in header]
    return hashlib.sha1(("%s|%s" % (level, "|".join(cells))).encode()).hexdigest()[:12]


# ---------------------------------------------------------------------------------------------- the profile (code)
_INT = re.compile(r"^-?\d+$")
_HEX = re.compile(r"^(0x)?[0-9A-Fa-f]+$")
_TIME = re.compile(r"^\d+\.\d+\s*s$")
_DUR = re.compile(r"^\d+(\.\d+)?\s*(ps|ns|us|µs|ms|s)$")


def _type_of(values):
    vals = [v.strip() for v in values if v.strip()]
    if not vals:
        return "empty"
    for name, rx in (("integer", _INT), ("time stamp", _TIME), ("time span", _DUR), ("hex", _HEX)):
        if all(rx.match(v) for v in vals[:500]):
            return name
    return "text"


def sample_rows(path):
    """The first SAMPLE_HEAD rows and SAMPLE_SPOTS blocks of SAMPLE_SPOT_ROWS rows from random places (fixed seed:
    the same file gives the same sample). Returns (header, rows, rows_estimate)."""
    size = os.path.getsize(path)
    rows = []
    with open(path, "rb") as fb:
        head = fb.readline()
        header = next(csv.reader(io.StringIO(head.decode("utf-8-sig", errors="replace"))), [])
        start = fb.tell()
        lines = []
        for _ in range(SAMPLE_HEAD):
            ln = fb.readline()
            if not ln:
                break
            lines.append(ln)
        used = sum(len(x) for x in lines)
        rng = random.Random(size)
        spots = sorted(rng.randrange(start, size) for _ in range(SAMPLE_SPOTS)) if size > start + used * 4 else []
        for off in spots:
            fb.seek(off)
            fb.readline()                     # finish the line we landed in
            for _ in range(SAMPLE_SPOT_ROWS):
                ln = fb.readline()
                if not ln:
                    break
                lines.append(ln)
    text = b"".join(lines).decode("utf-8", errors="replace")
    rows = list(csv.reader(io.StringIO(text)))
    avg = (sum(len(x) for x in lines) / len(lines)) if lines else 1
    return header, rows, int((size - start) / max(1, avg))


def profile(path, level):
    header, rows, est = sample_rows(path)
    al = L.align_header(level, header) if level else None
    named = sorted(al.positions.items(), key=lambda kv: kv[1]) if al else [((h or "column %d" % (i + 1)), i) for i, h in enumerate(header)]
    if al:
        named += [(h, i) for i, h in al.unknown]
    cols = []
    data_values = {}
    for name, idx in named:
        vals = [r[idx] for r in rows if idx < len(r)]
        filled = [v for v in vals if v.strip()]
        cnt = Counter(filled)
        top = cnt.most_common(6)
        examples = list(dict.fromkeys(filled))[:40]
        data_values[name] = [v for v, _ in top] + examples
        cols.append({"column": name, "position": idx, "header_cell": header[idx] if idx < len(header) else "",
                     "type": _type_of(filled), "filled_pct": round(100.0 * len(filled) / max(1, len(vals)), 1),
                     "distinct_in_sample": len(cnt), "top_values": [{"value": v[:80], "count": c} for v, c in top]})
    return {"path": path, "level": level, "columns_in_file": len(header), "rows_estimate": est, "rows_sampled": len(rows),
            "header_format": al.header_format if al else "unknown", "columns": cols}, data_values


# ---------------------------------------------------------------------------------------------- stand-ins (no model)
def _standin_explore(batch):
    out = []
    for c in batch:
        tv = c["top_values"]
        observed = "%s; filled in %s%% of the sampled rows; %s" % (
            c["type"], c["filled_pct"], ("values such as " + ", ".join(v["value"] for v in tv[:4])) if tv else "no value in the sample")
        guess = C.PLAIN.get(c["column"]) or ""
        claims = [{"text": "%s holds values such as %s" % (c["column"], tv[0]["value"]),
                   "source": {"kind": "data", "ref": c["column"], "quote": tv[0]["value"]}}] if tv else []
        out.append({"column": c["column"], "observed": observed, "meaning_guess": guess, "claims": claims})
    return {"columns": out}


def _standin_ground(items):
    out = []
    for it in items:
        if not it["snippets"]:
            continue
        s = it["snippets"][0]
        out.append({"column": it["column"], "meaning": s["quote"][:240],
                    "claims": [{"text": "%s is described in %s" % (it["column"], os.path.basename(s["ref"].rpartition(":")[0])),
                                "source": {"kind": "document", "ref": s["ref"], "quote": s["quote"][:160]}}]})
    return {"columns": out}


EXPLORE_INSTRUCTION = """You are the Data Explorer of one CSV exported by a Teledyne LeCroy PCIe/NVMe protocol analyzer.
For every column in CONTEXT, say in one plain sentence what the DATA shows (its type, how full it is, its typical
values) and, separately, your best guess of what the column means. Every factual claim must quote a value that
appears in that column's top_values, with source kind "data" and ref = the column name. Do not invent values."""
EXPLORE_SHAPE = '{"columns": [{"column": "...", "observed": "...", "meaning_guess": "...", "claims": [{"text": "...", "source": {"kind": "data", "ref": "<column>", "quote": "<a value seen>"}}]}]}'

GROUND_INSTRUCTION = """You are the Data Grounder. For each column in CONTEXT you get what the data shows and the lines of
the reference documents that name it. Say what the column means ACCORDING TO THOSE LINES ONLY, and quote the line you
used (source kind "document", ref exactly as given, quote copied from the snippet). If the snippets do not say what the
column means, leave meaning empty. If what a document says contradicts what the data shows, set disagreement to a short
sentence saying how."""
GROUND_SHAPE = '{"columns": [{"column": "...", "meaning": "...", "disagreement": "", "claims": [{"text": "...", "source": {"kind": "document", "ref": "<file:line as given>", "quote": "<copied from the snippet>"}}]}]}'


# ---------------------------------------------------------------------------------------------- the run
def steps(params, project):
    files = inventory(project.get("folder"))
    out = [{"key": "director", "title": "Director: list the CSVs of the folder and what each one is", "family": "1", "agent": "Director"}]
    for f in files:
        n = f["name"]
        out += [
            {"key": "explore:" + n, "title": "Explorer: read %s (%s)" % (n, f["level_label"]), "family": "1", "agent": "Data Explorer", "input": {"file": f}},
            {"key": "ground:" + n, "title": "Grounder: find what the columns of %s mean in the reference documents" % n, "family": "1", "agent": "Data Grounder", "input": {"file": f}},
            {"key": "manager:" + n, "title": "Manager: the data dictionary of %s" % n, "family": "1", "agent": "Manager", "review": True, "input": {"file": f}},
        ]
    return out


def refs_of(ctx):
    p = ctx.project
    folders = [x for x in (core.jload(p.get("refs"), []) or []) if x]
    return core.References(folders, os.path.join(ctx.engine.runner.sandbox_root, "_pdf_cache"))


def run_step(ctx):
    key = ctx.step["key"]
    if key == "director":
        files = inventory(ctx.project.get("folder"))
        if not files:
            raise RuntimeError("no CSV file in the folder %s" % ctx.project.get("folder"))
        return core.Result({"files": files, "references": core.jload(ctx.project.get("refs"), [])})
    kind, _, name = key.partition(":")
    f = ctx.input["file"]
    if kind == "explore":
        return _explore(ctx, f)
    if kind == "ground":
        return _ground(ctx, f)
    if kind == "manager":
        return _manager(ctx, f)
    raise RuntimeError("unknown step %s" % key)


def _explore(ctx, f):
    ctx.progress("profiling %s by code: the first %d rows and %d blocks from random places" % (f["name"], SAMPLE_HEAD, SAMPLE_SPOTS))
    prof, values = profile(f["path"], f["level"])
    box = ctx.engine.runner.sandbox(ctx.run["id"], "explorer_" + f["name"])
    with open(os.path.join(box, "profile.json"), "w") as fh:
        json.dump(prof, fh, indent=1)
    with open(os.path.join(box, "values.json"), "w") as fh:
        json.dump(values, fh)
    filled = [c for c in prof["columns"] if c["filled_pct"] > 0]
    empty = [c["column"] for c in prof["columns"] if c["filled_pct"] == 0]
    answers, producers = [], set()
    for i in range(0, len(filled), BATCH):
        batch = filled[i:i + BATCH]
        ctx.progress("Explorer reading columns %d to %d of %d filled columns" % (i + 1, i + len(batch), len(filled)))
        ans, producer, _ = ctx.engine.runner.ask(ctx.run["id"], "explorer_" + f["name"], EXPLORE_INSTRUCTION,
                                                 {"file": f["name"], "level": f["level_label"], "columns": batch}, EXPLORE_SHAPE, "columns",
                                                 lambda b=batch: _standin_explore(b))
        producers.add(producer)
        answers += ans.get("columns") or []
    known = {c["column"] for c in filled}
    cols = []
    for a in answers:
        if a.get("column") not in known:
            continue
        a["claims"] = core.check_claims(a.get("claims"), data_values=values)
        ctx.evidence(a["claims"])
        cols.append(a)
    return core.Result({"profile_file": os.path.join(box, "profile.json"), "values_file": os.path.join(box, "values.json"),
                        "rows_estimate": prof["rows_estimate"], "rows_sampled": prof["rows_sampled"], "header_format": prof["header_format"],
                        "columns": cols, "empty_in_sample": empty}, producer=", ".join(sorted(producers)))


def _terms(column, top_values, typ):
    terms = [column]
    leaf = column.partition(".")[2]
    if leaf:
        terms.append(leaf)
    if typ == "text":
        terms += [v["value"] for v in top_values[:3] if 2 <= len(v["value"]) <= 40]
    return list(dict.fromkeys(t for t in terms if t))


def _ground(ctx, f):
    ex = ctx.output_of("explore:" + f["name"])
    prof = json.load(open(ex["profile_file"]))
    refs = refs_of(ctx)
    if not refs.folders:
        return core.Result({"columns": []}, skip="no reference documents were given for this project (add a folder of manuals or notes on the start page)")
    items = []
    for c in prof["columns"]:
        if c["filled_pct"] == 0:
            continue
        snips = []
        for t in _terms(c["column"], c["top_values"], c["type"]):
            snips += refs.search(t, limit=2)
        if snips:
            items.append({"column": c["column"], "type": c["type"], "top_values": [v["value"] for v in c["top_values"][:4]], "snippets": snips[:4]})
    if not items:
        return core.Result({"columns": []}, skip="the reference documents name none of the columns of %s" % f["name"])
    answers, producers = [], set()
    for i in range(0, len(items), BATCH):
        batch = items[i:i + BATCH]
        ctx.progress("Grounder: columns %d to %d of %d with a line in the documents" % (i + 1, i + len(batch), len(items)))
        ans, producer, _ = ctx.engine.runner.ask(ctx.run["id"], "grounder_" + f["name"], GROUND_INSTRUCTION, {"columns": batch},
                                                 GROUND_SHAPE, "columns", lambda b=batch: _standin_ground(b))
        producers.add(producer)
        answers += ans.get("columns") or []
    out = []
    for a in answers:
        a["claims"] = core.check_claims(a.get("claims"), refs=refs)
        if a.get("meaning") and not any(c["verified"] for c in a["claims"]):
            a["meaning_unverified"] = a.pop("meaning")
        ctx.evidence(a["claims"])
        out.append(a)
    return core.Result({"columns": out, "with_snippets": len(items)}, producer=", ".join(sorted(producers)))


def _manager(ctx, f):
    ex = ctx.output_of("explore:" + f["name"])
    gr = ctx.output_of("ground:" + f["name"])
    edits = (ctx.input.get("edits") or {})
    by_g = {g["column"]: g for g in (gr.get("columns") or [])}
    rows = []
    for e in ex.get("columns") or []:
        g = by_g.get(e["column"], {})
        meaning = g.get("meaning") or ""
        if meaning:
            status = "disagreement" if g.get("disagreement") else "confirmed by a document"
        elif e.get("meaning_guess"):
            status = "guess from the data and the project's notes: to confirm"
            meaning = e["meaning_guess"]
        else:
            status = "unknown: to describe"
        if e["column"] in edits:
            meaning, status = edits[e["column"]], "given by the admin"
        rows.append({"column": e["column"], "observed": e.get("observed", ""), "meaning": meaning, "status": status,
                     "disagreement": g.get("disagreement", ""),
                     "sources": [c["source"] for c in (g.get("claims") or []) + (e.get("claims") or []) if c.get("verified")]})
    dictionary = {"file": f["name"], "level": f["level"], "format_key": f["format_key"], "made": time.time(),
                  "rows_estimate": ex.get("rows_estimate"), "columns": rows, "empty_in_sample": ex.get("empty_in_sample", [])}
    box = ctx.engine.runner.sandbox(ctx.run["id"], "manager_" + f["name"])
    path = os.path.join(box, "dictionary.json")
    with open(path, "w") as fh:
        json.dump(dictionary, fh, indent=1)
    counts = Counter(r["status"] for r in rows)
    admin = ctx.project.get("admin") or "admin"
    lines = ["**Admin %s, need review.** The data dictionary of **%s** (%s level, about %s rows)." % (
        admin, f["name"], f["level_label"], "{:,}".format(ex.get("rows_estimate") or 0)),
        "", "%d columns hold values in the sample; %d are empty in the sample." % (len(rows), len(ex.get("empty_in_sample", []))),
        "", "| status | columns |", "|---|---|"] + ["| %s | %d |" % (k, v) for k, v in counts.most_common()]
    dis = [r for r in rows if r["status"] == "disagreement"]
    if dis:
        lines += ["", "**Disagreements (the data is taken as the truth until you decide):**"] + ["- %s: %s" % (r["column"], r["disagreement"]) for r in dis[:30]]
    lines += ["", "Approve to store it as the dictionary of this file format. To change a meaning, give it in the edit box (one line per column: `column = meaning`)."]
    return core.Result({"dictionary_file": path, "counts": dict(counts)},
                       review={"title": "Data dictionary of %s" % f["name"], "body": "\n".join(lines), "data": {"dictionary_file": path, "table": rows[:400]}})


def on_approve(engine, run, step, data, admin):
    if not step["key"].startswith("manager:"):
        return
    out = core.jload(step["output"], {})
    d = json.load(open(out["dictionary_file"]))
    edits = data.get("edits") or {}
    for r in d["columns"]:
        if r["column"] in edits:
            r["meaning"], r["status"] = edits[r["column"]], "given by the admin"
    d["approved_by"], d["approved_at"] = admin, time.time()
    folder = os.path.join(knowledge_dir(), "dictionaries", d["format_key"])
    os.makedirs(folder, exist_ok=True)
    n = 1 + len([x for x in os.listdir(folder) if x.startswith(os.path.splitext(d["file"])[0] + ".v")])
    d["version"] = n
    base = os.path.splitext(d["file"])[0]
    with open(os.path.join(folder, "%s.v%d.json" % (base, n)), "w") as fh:
        json.dump(d, fh, indent=1)
    with open(os.path.join(folder, "%s.current.json" % base), "w") as fh:
        json.dump(d, fh, indent=1)


def approved_dictionary(format_key, file_name):
    p = os.path.join(knowledge_dir(), "dictionaries", format_key, "%s.current.json" % os.path.splitext(file_name)[0])
    return json.load(open(p)) if os.path.exists(p) else None


def dictionaries_for_level(level):
    """Every approved dictionary of a level (any format), newest first."""
    out = []
    root = os.path.join(knowledge_dir(), "dictionaries")
    if not os.path.isdir(root):
        return out
    for fk in os.listdir(root):
        for fn in os.listdir(os.path.join(root, fk)):
            if fn.endswith(".current.json"):
                d = json.load(open(os.path.join(root, fk, fn)))
                if d.get("level") == level:
                    out.append(d)
    out.sort(key=lambda d: d.get("approved_at") or 0, reverse=True)
    return out
