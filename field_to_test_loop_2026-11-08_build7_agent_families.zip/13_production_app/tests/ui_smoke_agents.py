"""Browser check of the agent families page (/agents) in headless Chrome (port 9333).

    python3 tests/ui_smoke_agents.py

The page loads without a script error or a failed request; the sidebar shows the work views and both sections with
their five levels; every view opens (start, Family 1, Family 2, inbox, runs, settings, one Section 1 item, one Section 2
item, the add form). Read-only: nothing is created.
"""
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from ui_smoke_hier import Chrome   # noqa: E402
import socket   # noqa: E402


def port_busy(port):
    with socket.socket() as sk:
        return sk.connect_ex(("127.0.0.1", port)) == 0

BASE = "http://127.0.0.1:8077"
R = {"pass": 0, "fail": 0}


def check(name, ok, detail=""):
    R["pass" if ok else "fail"] += 1
    print("%s  %s%s" % ("PASS" if ok else "FAIL", name, ("  | " + str(detail)[:200]) if detail != "" else ""), flush=True)


def main():
    if port_busy(9333):
        sys.exit("port 9333 is busy (another headless Chrome)")
    c = Chrome()
    try:
        c.goto(BASE + "/agents?v=%d" % int(time.time()))
        time.sleep(2.5)
        check("the page loads with its title", c.js("document.title") == "Agent families")
        groups = c.js("[...document.querySelectorAll('nav .group')].map(x => x.innerText)") or []
        g = [x.lower() for x in groups]
        check("the sidebar shows Work and both sections", g and "work" in g[0] and any("section 1" in x for x in g) and any("section 2" in x for x in g), groups)
        check("each section shows its five levels with an add button", (c.js("document.querySelectorAll('nav .lvl').length") or 0) == 10 and (c.js("document.querySelectorAll('nav .lvl .add').length") or 0) == 10)
        check("the seeded items are listed (the two analytics items and the detector's rules)", (c.js("document.querySelectorAll('nav .item').length") or 0) >= 42)
        check("the runtime badge says where the agents run", "agents run on" in (c.js("document.getElementById('rt').innerText") or ""))
        for view, probe in (("start", "New project"), ("family1", ""), ("family2", ""), ("inbox", "Review inbox"), ("runs", "All runs"), ("settings", "The agents run on")):
            c.js("document.querySelector('nav button[data-v=%s]').click()" % view)
            time.sleep(1.2)
            txt = c.js("document.getElementById('main').innerText") or ""
            ok = (probe in txt) if probe else ("Family" in txt or "No project open" in txt)
            check("the %s view opens" % view, ok, txt[:80].replace("\n", " "))
        c.js("[...document.querySelectorAll('nav .item')].find(x => x.innerText.includes('Command type percentages')).click()")
        time.sleep(1.5)
        txt = c.js("document.getElementById('main').innerText") or ""
        check("a Section 1 item shows its rule, the code in words, and Edit / Proceed", "The rule" in txt and "What the code does" in txt and "Proceed with the current rules" in txt and "rules" in txt, txt[:100])
        c.js("[...document.querySelectorAll('nav .item')].find(x => x.innerText.includes('never completed')).click()")
        time.sleep(1.5)
        txt = c.js("document.getElementById('main').innerText") or ""
        check("the Section 2 demo item opens", "never completed" in txt and "demo" in txt, txt[:100])
        c.js("document.querySelector('nav .lvl .add').click()")
        time.sleep(1)
        check("the add form opens for a level", "Add an item" in (c.js("document.getElementById('main').innerText") or ""))
        print("screenshot:", c.shot("agents_page"))
        check("no script error and no failed request", not c.errors, c.errors[:3])
    finally:
        c.close()
    print("%d checks, %d failed" % (R["pass"] + R["fail"], R["fail"]))
    sys.exit(1 if R["fail"] else 0)


if __name__ == "__main__":
    main()
