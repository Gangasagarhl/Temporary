"""End-to-end test of the agent families (/agents) against the running server.

    python3 tests/test_agentic.py [--base http://127.0.0.1:8077] [--real]

Without --real every agent answers through the stand-in (deterministic, no model). With --real a few agent calls also go
through Claude Code headless (the key and model of ~/.claude/settings.json): one Family 1 run on one CSV, one question
in a review, one rule conversation. Everything the test creates (projects, runs, uploads, dictionaries, strategies,
rule versions, exports) is removed at the end; the seeded rules are put back as they were.
"""
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import time
import urllib.error
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
BASE = "http://127.0.0.1:8077"
if "--base" in sys.argv:
    BASE = sys.argv[sys.argv.index("--base") + 1]
REAL = "--real" in sys.argv
S08_SRC = os.path.join(ROOT, "samples", "five_level", "S08")
S08 = os.path.join(ROOT, "uploads", "_agentic_test_S08")       # a clean folder: only the five exports (the sample folder also holds the generator's answer key)
FIVE = ["packets.csv", "link.csv", "split.csv", "NVME_Transactions.csv", "nvme_command.csv"]
BIG_UPLOAD = "up-20261102-210717-2895"
KNOW = os.path.join(ROOT, "knowledge")
ADMIN = "agentic-test"
RESULTS = {"pass": 0, "fail": 0}
CREATED = {"projects": [], "uploads": [], "dirs": [], "rule_backups": {}}


def check(name, ok, detail=""):
    RESULTS["pass" if ok else "fail"] += 1
    print("%s  %s%s" % ("PASS" if ok else "FAIL", name, ("  | " + str(detail)[:300]) if detail != "" else ""), flush=True)
    return ok


class ApiError(Exception):
    def __init__(self, code, body):
        super().__init__("HTTP %s: %s" % (code, body))
        self.code, self.body = code, body


def api(method, path, body=None, timeout=120):
    req = urllib.request.Request(BASE + path, data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Content-Type": "application/json"}, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            return json.loads(raw) if raw[:1] in (b"{", b"[") else raw
    except urllib.error.HTTPError as e:
        raw = e.read().decode(errors="replace")
        try:
            raw = json.loads(raw)
        except ValueError:
            pass
        raise ApiError(e.code, raw)


def wait(rid, until, timeout=600, label=""):
    t0 = time.time()
    while time.time() - t0 < timeout:
        v = api("GET", "/api/agents/runs/%d" % rid)
        if until(v):
            return v
        if v["run"]["state"] in ("stopped", "finished") and not until(v):
            return v
        if any(s["state"] == "failed" for s in v["steps"]):
            return v
        time.sleep(1.5)
    print("      (timed out waiting for %s)" % label)
    return api("GET", "/api/agents/runs/%d" % rid)


def open_review(v):
    return next((r for r in v["reviews"] if r["state"] == "open"), None)


def has_open(v):
    return open_review(v) is not None


def finished(v):
    return v["run"]["state"] in ("finished", "stopped")


def step(v, key):
    return next((s for s in v["steps"] if s["key"] == key), None)


def decide(rv, decision, comment="", edits=None):
    return api("POST", "/api/agents/reviews/%d/decide" % rv["id"], {"decision": decision, "admin": ADMIN, "comment": comment, "edits": edits})


def backup_rule(sec, lvl, rid):
    p = os.path.join(KNOW, "rules", sec, lvl, rid + ".json")
    if p not in CREATED["rule_backups"]:
        CREATED["rule_backups"][p] = open(p).read() if os.path.exists(p) else None


# ---------------------------------------------------------------------------------------------- 0. settings
def t_settings():
    print("\n-- 0. settings")
    s0 = api("GET", "/api/agents/settings")
    CREATED["settings"] = {k: s0.get(k) for k in ("runtime", "model", "slices")}
    check("settings name the runtime (Claude Code by default, from ~/.claude/settings.json)", s0.get("runtime") in ("claude-code", "http", "standin"), s0.get("runtime"))
    try:
        api("PUT", "/api/agents/settings", {"runtime": "nonsense"})
        check("an unknown runtime is refused", False)
    except ApiError as e:
        check("an unknown runtime is refused", e.code == 400, e.body)
    s1 = api("PUT", "/api/agents/settings", {"runtime": "standin", "slices": 6})
    check("the runtime can be switched (to the stand-in for this test)", s1["runtime"] == "standin")


# ---------------------------------------------------------------------------------------------- 1. project
def t_project():
    print("\n-- 1. start page: project")
    for bad, why in (({"admin": ADMIN, "folder": "/nonexistent"}, "a missing folder"), ({"admin": ADMIN, "folder": HERE}, "a folder without CSV files"),
                     ({"admin": ADMIN, "folder": S08, "refs": ["/nonexistent/refs"]}, "a missing reference folder")):
        try:
            api("POST", "/api/agents/projects", bad)
            check("refused: %s" % why, False)
        except ApiError as e:
            check("refused: %s" % why, e.code == 400, e.body)
    inv = api("GET", "/api/agents/inventory?folder=" + urllib.request.quote(S08))
    levels = sorted(str(f["level"]) for f in inv["files"])
    check("the Director's inventory sees the five CSVs and their levels", levels == sorted(["packets", "link", "split", "nvme_transaction", "nvme_command"]), levels)
    p = api("POST", "/api/agents/projects", {"admin": ADMIN, "name": "agentic test S08", "folder": S08})
    CREATED["projects"].append(p["id"])
    check("a project is created with the default reference folder", p["folder"] == S08 and p["refs"] and os.path.isdir(p["refs"][0]), p["refs"])
    return p


# ---------------------------------------------------------------------------------------------- 2. Family 1
def t_family1(p):
    print("\n-- 2. Family 1: one sub-family per CSV, reviews")
    r = api("POST", "/api/agents/projects/%d/family1" % p["id"])
    rid = r["run"]
    keys = [s["key"] for s in r["view"]["steps"]]
    check("the run has the Director and 3 steps per CSV (Explorer, Grounder, Manager) = 16 steps", len(keys) == 16 and keys[0] == "director", len(keys))
    v = wait(rid, has_open, 300, "the first dictionary review")
    rv = open_review(v)
    check("the run stops at the first Manager review", rv is not None and step(v, rv and next(s["key"] for s in v["steps"] if s["id"] == rv["step"]))["state"] == "needs_review" if rv else False)
    if not rv:
        return None
    check("the review is addressed to the admin by name", ("Admin %s, need review" % ADMIN) in rv["body"], rv["body"][:120])
    ex = next(s for s in v["steps"] if s["key"].startswith("explore:"))
    check("the Explorer profiled the file by code (rows estimated, columns read)", ex["output"].get("rows_estimate", 0) > 0 and len(ex["output"].get("columns") or []) > 3,
          (ex["output"].get("rows_estimate"), len(ex["output"].get("columns") or [])))
    ev = v["evidence"]
    data_ok = [e for e in ev if e["kind"] == "data" and e["verified"]]
    doc_ok = [e for e in ev if e["kind"] == "document" and e["verified"]]
    check("evidence was recorded and checked: data claims verified against the values seen", len(data_ok) > 0, "%d verified data claims" % len(data_ok))
    check("document claims verified against the reference lines", len(doc_ok) > 0, "%d verified document claims" % len(doc_ok))
    # a hallucinated claim is caught by the code
    sys.path.insert(0, ROOT)
    from agentic import core
    refs = core.References(p["refs"], "/tmp/agentic_test_pdf_cache")
    bad = core.check_claims([{"text": "x", "source": {"kind": "document", "ref": doc_ok[0]["ref"] if doc_ok else "nofile:1", "quote": "a sentence that is in no document at all 4711"}},
                             {"text": "y", "source": {"kind": "data", "ref": "PSN", "quote": "999999999"}}, {"text": "z", "source": {"kind": "model", "ref": "", "quote": "trust me"}}],
                            refs=refs, data_values={"PSN": ["1", "2"]})
    check("a quote found in no document, a value not in the data, and a claim with no source are all marked NOT verified", not any(c["verified"] for c in bad), [c["why"] for c in bad])
    # ask
    a = api("POST", "/api/agents/reviews/%d/ask" % rv["id"], {"message": "Which columns are empty in the sample?", "admin": ADMIN}, timeout=300)
    check("the admin can ask about a review and gets an answer (with who answered)", bool(a.get("answer")) and a.get("producer"), a.get("producer"))
    # change with a comment: the step runs again and comes back for review
    decide(rv, "change", "please look again")
    v = wait(rid, lambda x: any(r2["state"] == "open" for r2 in x["reviews"]), 300, "the review after a change")
    rv2 = open_review(v)
    check("Change sends the step back; it runs again and asks for review again", rv2 is not None and rv2["id"] != rv["id"] and rv2["step"] == rv["step"])
    table = (rv2 or {}).get("data", {}).get("table") or []
    col = table[0]["column"] if table else None
    decide(rv2, "approve", "", {col: "set by the test admin"} if col else None)
    n_approved = 1
    while True:
        v = wait(rid, lambda x: has_open(x) or finished(x), 300, "the next dictionary review")
        rv = open_review(v)
        if not rv:
            break
        decide(rv, "approve")
        n_approved += 1
    check("all five dictionaries were reviewed and approved and the run finished", v["run"]["state"] == "finished" and n_approved == 5, (v["run"]["state"], n_approved))
    fmt_dirs = set()
    for s in v["steps"]:
        if s["key"].startswith("manager:"):
            d = json.load(open(s["output"]["dictionary_file"]))
            fmt_dirs.add(os.path.join(KNOW, "dictionaries", d["format_key"]))
    CREATED["dirs"] += sorted(fmt_dirs)
    stored = [f for d in fmt_dirs if os.path.isdir(d) for f in os.listdir(d) if f.endswith(".current.json")]
    check("an approved dictionary is stored per CSV (current and versioned)", len(stored) == 5, stored)
    if col:
        found = False
        for d in fmt_dirs:
            for f in os.listdir(d):
                if f.endswith(".current.json"):
                    j = json.load(open(os.path.join(d, f)))
                    found = found or any(c["column"] == col and c["meaning"] == "set by the test admin" and c["status"] == "given by the admin" for c in j["columns"])
        check("the admin's edit is in the stored dictionary", found, col)
    return rid


# ---------------------------------------------------------------------------------------------- 3. Family 2
def t_family2(p):
    print("\n-- 3. Family 2: strategy, build, tests")
    r = api("POST", "/api/agents/projects/%d/family2" % p["id"])
    rid = r["run"]
    v = wait(rid, has_open, 300, "the strategy review")
    ls = step(v, "last_strategy")
    check("no strategy was approved before for this format: the 'used last time' step is skipped with the reason", ls["state"] == "skipped", ls.get("note"))
    rv = open_review(v)
    check("the Coder's strategy is up for review, with the five joins and evidence", rv and "packets -> link transaction" in rv["body"] and "evidence" in rv["body"], (rv or {}).get("title"))
    coder = step(v, "coder")
    check("every column the strategy uses exists in the files (no problem found by the code)", coder["output"].get("problems") == [], coder["output"].get("problems"))
    col = step(v, "collect")
    srcs = {s["source"]: s for s in col["output"].get("sources") or []}
    check("the collector reports IMS, JIRA and the web as not connected on this machine, with how to connect them", all(not srcs[k]["reachable"] and "not connected" in srcs[k]["note"] for k in ("IMS", "JIRA", "web")))
    check("the collector used Family 1's approved dictionaries", srcs.get("Family 1 dictionaries", {}).get("reachable") is True)
    decide(rv, "approve")
    fmt = coder["output"]["format"]
    CREATED["dirs"].append(os.path.join(KNOW, "strategies", fmt))
    v = wait(rid, has_open, 120, "the build question")
    rv = open_review(v)
    check("the Builder asks before building", rv and "Shall I build" in rv["title"], (rv or {}).get("title"))
    decide(rv, "approve")
    v = wait(rid, has_open, 900, "the test review")
    b = step(v, "build")
    up = b["output"].get("upload_id")
    if up:
        CREATED["uploads"].append(up)
    check("the Builder loaded and built the five files (a new upload)", b["state"] == "done" and up and b["output"].get("reused") is False, b["output"])
    st = step(v, "slice_test")
    check("the Code tester rebuilt 5 to 10 random windows of the real data", 5 <= st["output"].get("of", 0) <= 10, st["output"].get("of"))
    check("every random window agrees with the analyzer's counts and with the full tree", st["output"].get("passed") == st["output"].get("of"),
          [w["name"] for w in st["output"].get("windows", []) if not w["passed"]])
    br = step(v, "breaker")
    check("the Breaker tried the hard windows (start, end, busiest moment ...)", br["state"] in ("done", "skipped") and (br["output"].get("of", 0) >= 3 or br["state"] == "skipped"), br["output"].get("of"))
    check("every hard window passed", br["state"] == "skipped" or br["output"].get("passed") == br["output"].get("of"),
          [(w["name"], {k: x["n"] for k, x in w["count_mismatch"].items() if x["n"]}, {k: x["n"] for k, x in w["parent_mismatch"].items() if x["n"]}) for w in br["output"].get("windows", []) if not w["passed"]])
    ind = step(v, "independent")
    inv = ind["output"].get("invariants") or []
    check("the Independent tester checked every join with the column meanings: no violation", inv and all(x.get("violations") == 0 and x.get("rows_checked", 0) > 0 for x in inv),
          [(x["check"][:40], x.get("rows_checked"), x.get("violations")) for x in inv])
    decide(open_review(v), "approve")
    v = wait(rid, finished, 60, "the end of the run")
    pj = api("GET", "/api/agents/projects/%d" % p["id"])
    check("the run finished and the project is linked to its built data", v["run"]["state"] == "finished" and pj["upload_id"] == up, (v["run"]["state"], pj["upload_id"]))
    # the second time: the stored strategy is offered
    r = api("POST", "/api/agents/projects/%d/family2" % p["id"])
    rid2 = r["run"]
    v = wait(rid2, has_open, 120, "the 'used last time' review")
    rv = open_review(v)
    check("the second time, the strategy used last time is offered: proceed?", rv and "Proceed with strategy v1" in rv["title"], (rv or {}).get("title"))
    decide(rv, "approve")
    v = wait(rid2, has_open, 120, "the build question (second time)")
    check("approving it skips the research and the Coder", all(step(v, k)["state"] == "skipped" for k in ("rea", "collect", "coder")), [step(v, k)["state"] for k in ("rea", "collect", "coder")])
    decide(open_review(v), "approve")
    v = wait(rid2, has_open, 600, "the test review (second time)")
    check("the Builder reuses the data already built (nothing rebuilt)", step(v, "build")["output"].get("reused") is True, step(v, "build")["output"])
    decide(open_review(v), "reject", "test of reject")
    v = api("GET", "/api/agents/runs/%d" % rid2)
    check("Reject stops the run, with who and why", v["run"]["state"] == "stopped" and ADMIN in (v["run"]["summary"] or ""), v["run"]["summary"])
    return up


# ---------------------------------------------------------------------------------------------- 4. Family 3
def run_rule(p, sec, lvl, rid, upload_id=None, approve=True):
    r = api("POST", "/api/agents/rules/%s/%s/%s/proceed" % (sec, lvl, rid), {"project": p["id"], "upload_id": upload_id})
    v = wait(r["run"], has_open, 600, "the result review of %s" % rid)
    rv = open_review(v)
    if rv and approve:
        decide(rv, "approve")
    return r["run"], v, rv


def approve_draft(p, sec, lvl, rid, message="as written"):
    backup_rule(sec, lvl, rid)
    r = api("POST", "/api/agents/rules/%s/%s/%s/edit" % (sec, lvl, rid), {"project": p["id"], "message": message})
    v = wait(r["run"], has_open, 300, "the rule review of %s" % rid)
    rv = open_review(v)
    if rv:
        decide(rv, "approve")
    return v, rv


def t_family3(p, up):
    print("\n-- 4. Family 3: the rules page, edit, proceed, add")
    tree = api("GET", "/api/agents/rules")
    secs = {s["section"]: s for s in tree}
    check("the sidebar has the two sections with the five levels each", set(secs) == {"analytics", "errors"} and all(len(s["levels"]) == 5 for s in tree))
    cmd_items = {i["id"]: i for i in secs["analytics"]["levels"][0]["items"]}
    check("Section 1 has the command type percentages and the read pattern items", {"command_type_share", "read_pattern"} <= set(cmd_items), list(cmd_items))
    n_err = sum(len(l["items"]) for l in secs["errors"]["levels"])
    check("Section 2 has the detector's rules as items (drafts to approve, edit or drop)", n_err >= 40, n_err)
    demo = [i for l in secs["errors"]["levels"] for i in l["items"] if i["demo"]]
    check("the demo error is marked: a command that never completed (host timeout)", len(demo) == 1 and demo[0]["id"] == "cmd_incomplete", demo)
    g = api("GET", "/api/agents/rules/analytics/nvme_command/command_type_share")
    check("an item shows its rule, what the code does in words, and the generated code", g["rule"]["definition"] and g["in_words"] and "SELECT" in (g["code"] or ""), g["in_words"][:80])
    backup_rule("analytics", "nvme_command", "command_type_share")
    if g["rule"]["status"] != "approved":
        try:
            api("POST", "/api/agents/rules/analytics/nvme_command/command_type_share/proceed", {"project": p["id"]})
            check("Proceed is refused while the rule is a draft", False)
        except ApiError as e:
            check("Proceed is refused while the rule is a draft", e.code == 409, e.body)
    # edit -> review shows the code -> change -> again -> approve
    r = api("POST", "/api/agents/rules/analytics/nvme_command/command_type_share/edit", {"project": p["id"], "message": "keep it as written"})
    v = wait(r["run"], has_open, 300, "rule review")
    rv = open_review(v)
    check("the Rule writer's draft is up for review with the definition and the code it will generate", rv and "```sql" in rv["body"] and "Definition" in rv["body"], (rv or {}).get("title"))
    decide(rv, "change", "count admin and I/O commands together, as written")
    v = wait(r["run"], lambda x: any(q["state"] == "open" for q in x["reviews"]), 300, "rule review after change")
    rv2 = open_review(v)
    check("Change on a rule draft: the Rule writer answers and the draft comes back", rv2 is not None and "count admin and I/O commands together" in rv2["body"], (rv2 or {}).get("body", "")[:100])
    decide(rv2, "approve")
    g = api("GET", "/api/agents/rules/analytics/nvme_command/command_type_share")
    check("approval stores a new version, with who approved it and the history", g["rule"]["status"] == "approved" and g["rule"]["version"] >= 1 and g["rule"]["approved_by"] == ADMIN and g["rule"]["history"],
          (g["rule"]["status"], g["rule"]["version"]))
    rid, v, rv = run_rule(p, "analytics", "nvme_command", "command_type_share", up)
    code = step(v, "code")
    check("the code is generated from the approved rule version and stored with it", os.path.exists(code["output"]["file"]) and ("v%d.sql" % g["rule"]["version"]) in code["output"]["file"])
    test = step(v, "test")
    check("the Tester's checks pass (every command counted once, percentages add up to 100)", test["output"].get("passed") is True, [(c["check"][:50], c["ok"], c["detail"]) for c in test["output"].get("checks") or []])
    files = step(v, "export")["output"]["files"]
    check("the result is exported as CSV and HTML", os.path.exists(files.get("csv", "")) and os.path.exists(files.get("html", "")), files)
    db = os.path.join(ROOT, "uploads", up, "hier.sqlite")
    con = sqlite3.connect(db)
    n_cmd = con.execute("SELECT COUNT(*) FROM cmd").fetchone()[0]
    reads = con.execute("SELECT COUNT(*) FROM cmd WHERE opc=2 AND sqid!=0").fetchone()[0]
    rows = list(__import__("csv").reader(open(files["csv"])))[1:]
    check("independently: the exported counts add up to the commands of the upload", sum(int(x[1]) for x in rows) == n_cmd, (sum(int(x[1]) for x in rows), n_cmd))
    read_row = next((x for x in rows if x[0] == "Read"), None)
    check("independently: the Read line equals the Read commands counted straight from the data", read_row and int(read_row[1]) == reads, (read_row, reads))
    f = api("GET", "/api/agents/file?path=" + urllib.request.quote(files["csv"]))
    check("the export can be downloaded from the page", isinstance(f, bytes) and f.startswith(b"label,count,percent"))
    try:
        api("GET", "/api/agents/file?path=/etc/passwd")
        check("a file outside the exports is refused", False)
    except ApiError as e:
        check("a file outside the exports is refused", e.code == 404)
    # read pattern: independent recount in Python
    approve_draft(p, "analytics", "nvme_command", "read_pattern")
    rid, v, rv = run_rule(p, "analytics", "nvme_command", "read_pattern", up)
    res = {x[0]: int(x[1]) for x in list(__import__("csv").reader(open(step(v, "export")["output"]["files"]["csv"])))[1:]}
    last, seq, rnd, first = {}, 0, 0, 0
    for nsid, slba, nlb in con.execute("SELECT nsid, slba, nlb FROM cmd WHERE opc=2 AND sqid!=0 AND slba IS NOT NULL AND nlb IS NOT NULL ORDER BY t_ps, rowid_file"):
        if nsid not in last:
            first += 1
        elif slba == last[nsid][0] + last[nsid][1] + 1:
            seq += 1
        else:
            rnd += 1
        last[nsid] = (slba, nlb)
    check("independently: sequential and random reads recounted in Python match the generated code",
          res.get("sequential read", 0) == seq and res.get("random read (RndRead)", 0) == rnd and res.get("first read of its namespace", 0) == first, (res, seq, rnd, first))
    # Section 2 on this upload
    sec2 = next((rule for rule in ("ntx_interrupt_before_completion", "cmd_status_error")
                 if con.execute("SELECT COUNT(*) FROM finding WHERE rule=?", (rule.replace("_", ".", 1),)).fetchone()[0]), None)
    con.close()
    if sec2:
        lvl = "nvme_transaction" if sec2.startswith("ntx") else "nvme_command"
        approve_draft(p, "errors", lvl, sec2)
        rid, v, rv = run_rule(p, "errors", lvl, sec2, up, approve=False)
        check("a Section 2 item lists its defects and each opens stage 1 and stage 2 (the isolation tab)", rv and rv["data"].get("section") == "errors" and rv["data"].get("head"), (rv or {}).get("title"))
        check("the Section 2 tester finds every listed defect's row", step(v, "test")["output"].get("passed") is True, step(v, "test")["output"].get("checks"))
        html = open(step(v, "export")["output"]["files"]["html"]).read()
        check("the HTML export links every defect to /isolate", "/isolate?upload=%s&finding=" % up in html)
        decide(rv, "approve")
    # add a new item
    a = api("POST", "/api/agents/rules", {"section": "analytics", "level": "link", "name": "agentic test link TLP types", "description": "percentage by tlp_type", "admin": ADMIN, "project": p["id"]})
    CREATED["rule_backups"][os.path.join(KNOW, "rules", "analytics", "link", a["rule"]["id"] + ".json")] = None
    v = wait(a["run"], has_open, 300, "the new item's first draft")
    rv = open_review(v)
    check("Add creates the item and starts the conversation; the draft is a distribution by tlp_type", rv and "tlp_type" in rv["body"], (rv or {}).get("body", "")[:200])
    decide(rv, "approve")
    rid, v, rv = run_rule(p, "analytics", "link", a["rule"]["id"], up)
    check("the new item runs and its tester passes", step(v, "test")["output"].get("passed") is True)
    tree = api("GET", "/api/agents/rules")
    names = [i["name"] for s in tree for l in s["levels"] for i in l["items"]]
    check("the new item is in the sidebar", "agentic test link TLP types" in names)


def t_demo_big(p_big):
    print("\n-- 5. the Section 2 demo on the 4.3 GB data: a command that never completed")
    approve_draft(p_big, "errors", "nvme_command", "cmd_incomplete", "as written")
    rid, v, rv = run_rule(p_big, "errors", "nvme_command", "cmd_incomplete", BIG_UPLOAD, approve=False)
    res = step(v, "run")["output"]
    test = step(v, "test")["output"]
    check("the demo error is found on the 4.3 GB recording", res.get("rows", 0) > 0, res.get("rows"))
    check("the tester confirms the definition in the data: none of these commands has a completion entry in the tree",
          any("none of these commands has a completion entry" in c["check"] and c["ok"] for c in test.get("checks") or []), test.get("checks"))
    if rv:
        decide(rv, "approve")


# ---------------------------------------------------------------------------------------------- 6. failure, retry, resume
def t_retry_resume(p):
    print("\n-- 6. a failed step is retried; a run survives a server restart")
    p2 = api("POST", "/api/agents/projects", {"admin": ADMIN, "name": "agentic test no data", "folder": S08})
    CREATED["projects"].append(p2["id"])
    r = api("POST", "/api/agents/rules/analytics/nvme_command/command_type_share/proceed", {"project": p2["id"]})
    v = wait(r["run"], lambda x: any(s["state"] == "failed" for s in x["steps"]), 60, "the failure")
    fs = next((s for s in v["steps"] if s["state"] == "failed"), None)
    check("a step that cannot work fails with a plain reason, and the run waits", fs and "no built data" in (fs["error"] or ""), (fs or {}).get("error", "").split("\n")[0][:120])
    api("PUT", "/api/agents/projects/%d" % p2["id"], {"upload_id": p["upload_id"]})
    api("POST", "/api/agents/runs/%d/retry" % r["run"])
    v = wait(r["run"], has_open, 300, "the review after retry")
    check("'run the failed step again' continues the run from that step", has_open(v), [s["state"] for s in v["steps"]])
    decide(open_review(v), "approve")
    # resume after a restart of the server
    r = api("POST", "/api/agents/projects/%d/family1" % p2["id"])
    time.sleep(1.0)
    subprocess.run(["systemctl", "--user", "restart", "f2t-app"], check=False)
    for _ in range(60):
        try:
            api("GET", "/api/agents/state")
            break
        except Exception:       # noqa: BLE001 - the server is restarting
            time.sleep(1)
    v = wait(r["run"], has_open, 300, "the review after the restart")
    check("a run interrupted by a server restart continues by itself from its first unfinished step", has_open(v), [s["state"] for s in v["steps"]][:5])
    api("POST", "/api/agents/runs/%d/stop" % r["run"], {"admin": ADMIN})
    check("Stop stops a run", api("GET", "/api/agents/runs/%d" % r["run"])["run"]["state"] == "stopped")


# ---------------------------------------------------------------------------------------------- 7. real agents (Claude Code)
def t_real(p):
    print("\n-- 7. real agents through Claude Code (the key and model of ~/.claude/settings.json)")
    api("PUT", "/api/agents/settings", {"runtime": "claude-code"})
    one = os.path.join("/tmp", "agentic_test_one_csv")
    shutil.rmtree(one, ignore_errors=True)
    os.makedirs(one)
    shutil.copy(os.path.join(S08, "split.csv"), one)
    CREATED["dirs"].append(one)
    p3 = api("POST", "/api/agents/projects", {"admin": ADMIN, "name": "agentic test real split", "folder": one})
    CREATED["projects"].append(p3["id"])
    r = api("POST", "/api/agents/projects/%d/family1" % p3["id"])
    v = wait(r["run"], has_open, 1200, "the real dictionary review")
    ex, gr = step(v, "explore:split.csv"), step(v, "ground:split.csv")
    check("the Explorer was answered by Claude Code", "Claude Code" in (ex.get("producer") or ""), ex.get("producer"))
    check("the Grounder was answered by Claude Code", "Claude Code" in (gr.get("producer") or "") or gr["state"] == "skipped", gr.get("producer"))
    ev = [e for e in v["evidence"] if e["step"] in (ex["id"], gr["id"])]
    check("Claude Code's claims were checked by the code (verified ones kept, others marked)", ev and any(e["verified"] for e in ev),
          "%d claims, %d verified" % (len(ev), sum(1 for e in ev if e["verified"])))
    rv = open_review(v)
    if rv:
        a = api("POST", "/api/agents/reviews/%d/ask" % rv["id"], {"message": "In one sentence: what does the Tag column hold?", "admin": ADMIN}, timeout=600)
        check("a question in a review is answered by Claude Code", "Claude Code" in a.get("producer", ""), (a.get("producer"), a.get("answer", "")[:160]))
        check("the answer is about the column asked for (the review's table is in the agent's context)", "tag" in a.get("answer", "").lower() and "doesn't say" not in a.get("answer", "").lower() and "does not say" not in a.get("answer", "").lower(), a.get("answer", "")[:200])
        api("PUT", "/api/agents/settings", {"runtime": "http"})
        a2 = api("POST", "/api/agents/reviews/%d/ask" % rv["id"], {"message": "In one sentence: what does the RequesterID column hold?", "admin": ADMIN}, timeout=600)
        check("the same question through the application's own model connection is answered too", "model connection" in a2.get("producer", ""), (a2.get("producer"), a2.get("answer", "")[:160]))
        check("that answer is about the column asked for too", "requester" in a2.get("answer", "").lower() and "does not say" not in a2.get("answer", "").lower(), a2.get("answer", "")[:200])
        api("PUT", "/api/agents/settings", {"runtime": "claude-code"})
        decide(rv, "approve")
        for d in os.listdir(os.path.join(KNOW, "dictionaries")):
            pth = os.path.join(KNOW, "dictionaries", d)
            if any(f.startswith("split.") for f in os.listdir(pth)) and pth not in CREATED["dirs"]:
                CREATED["dirs"].append(pth)
    backup_rule("analytics", "nvme_command", "command_type_share")
    r = api("POST", "/api/agents/rules/analytics/nvme_command/command_type_share/edit",
            {"project": p["id"], "message": "Instead of the command type, count the commands per submission queue (the sqid column)."})
    v = wait(r["run"], has_open, 900, "the real rule draft")
    rv = open_review(v)
    w = step(v, "write")
    check("the Rule writer was answered by Claude Code and its plan compiles", "Claude Code" in (w.get("producer") or "") and not w["output"].get("problem"), (w.get("producer"), w["output"].get("problem")))
    check("Claude Code turned the admin's words into a distribution by sqid", (w["output"].get("draft") or {}).get("plan", {}).get("label", {}).get("column") == "sqid", w["output"].get("draft"))
    if rv:
        decide(rv, "reject", "test only")
    api("PUT", "/api/agents/settings", {"runtime": "standin"})


def cleanup():
    print("\n-- clean-up")
    s = CREATED.get("settings")
    if s:
        try:
            api("PUT", "/api/agents/settings", s)
        except Exception:       # noqa: BLE001
            pass
    for up in CREATED["uploads"]:
        try:
            api("DELETE", "/api/hier/uploads/%s" % up)
        except Exception:       # noqa: BLE001
            pass
    for d in CREATED["dirs"]:
        shutil.rmtree(d, ignore_errors=True)
    for p, content in CREATED["rule_backups"].items():
        if content is None:
            if os.path.exists(p):
                os.remove(p)
        else:
            with open(p, "w") as fh:
                fh.write(content)
    for sec in ("analytics", "errors"):
        d = os.path.join(KNOW, "exports", sec)
        for base, _dirs, files in os.walk(d):
            for fn in files:
                if any(("_run%d." % rid) in fn for rid in CREATED.get("runs", [])):
                    os.remove(os.path.join(base, fn))
    db = os.path.join(ROOT, "db", "agentic.sqlite")
    con = sqlite3.connect(db, timeout=30)
    for pid in CREATED["projects"]:
        runs = [r[0] for r in con.execute("SELECT id FROM run WHERE project=?", (pid,))]
        for rid in runs:
            for t in ("step", "review", "evidence"):
                con.execute("DELETE FROM %s WHERE run=?" % t, (rid,))
            shutil.rmtree(os.path.join(ROOT, "runs", "agentic", "run_%d" % rid), ignore_errors=True)
            for base, _dirs, files in os.walk(os.path.join(KNOW, "exports")):
                for fn in files:
                    if ("_run%d." % rid) in fn:
                        os.remove(os.path.join(base, fn))
            for base, _dirs, files in os.walk(os.path.join(KNOW, "rules_code")):
                pass
        con.execute("DELETE FROM chat WHERE review NOT IN (SELECT id FROM review)")
        con.execute("DELETE FROM run WHERE project=?", (pid,))
        con.execute("DELETE FROM project WHERE id=?", (pid,))
    con.commit()
    con.close()
    print("      removed %d project(s), %d upload(s), %d folder(s); %d rule file(s) put back" % (
        len(CREATED["projects"]), len(CREATED["uploads"]), len(CREATED["dirs"]), len(CREATED["rule_backups"])))


def _set_aside_knowledge():
    """The test must not see, nor change, the dictionaries and strategies the admin approved: they are moved aside for
    the test and put back at the end."""
    keep = os.path.join(ROOT, "runs", "_agentic_test_kept_knowledge")
    shutil.rmtree(keep, ignore_errors=True)
    os.makedirs(keep)
    for d in ("dictionaries", "strategies"):
        src = os.path.join(KNOW, d)
        if os.path.isdir(src):
            shutil.move(src, os.path.join(keep, d))
    CREATED["kept_knowledge"] = keep


def _restore_knowledge():
    keep = CREATED.get("kept_knowledge")
    if not keep:
        return
    for d in ("dictionaries", "strategies"):
        shutil.rmtree(os.path.join(KNOW, d), ignore_errors=True)
        if os.path.isdir(os.path.join(keep, d)):
            shutil.move(os.path.join(keep, d), os.path.join(KNOW, d))
    shutil.rmtree(keep, ignore_errors=True)
    print("      the admin's own dictionaries and strategies are back in place")


def main():
    t0 = time.time()
    _set_aside_knowledge()
    shutil.rmtree(S08, ignore_errors=True)
    os.makedirs(S08)
    for f in FIVE:
        shutil.copy(os.path.join(S08_SRC, f), S08)
    CREATED["dirs"].append(S08)
    try:
        t_settings()
        p = t_project()
        t_family1(p)
        up = t_family2(p)
        p = api("GET", "/api/agents/projects/%d" % p["id"])
        t_family3(p, up)
        if os.path.isdir(os.path.join(ROOT, "uploads", BIG_UPLOAD)):
            pb = api("POST", "/api/agents/projects", {"admin": ADMIN, "name": "agentic test 4.3 GB", "folder": S08, "upload_id": BIG_UPLOAD})
            CREATED["projects"].append(pb["id"])
            t_demo_big(pb)
        t_retry_resume(p)
        if REAL:
            t_real(p)
    except Exception as e:      # noqa: BLE001 - reported as a failed check
        import traceback
        traceback.print_exc()
        check("the suite ran to the end", False, e)
    finally:
        cleanup()
        _restore_knowledge()
    print("\n%d checks, %d failed, %.0f s" % (RESULTS["pass"] + RESULTS["fail"], RESULTS["fail"], time.time() - t0))
    sys.exit(1 if RESULTS["fail"] else 0)


if __name__ == "__main__":
    main()
