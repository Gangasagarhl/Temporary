#!/usr/bin/env python3
"""Tests for the NVMe-level hierarchy package (nvme_hier): parsers, header alignment, SQLite staging.

Run: python3 tests/test_nvme_hier.py   (no network, no LLM, a few seconds)
"""
import csv
import os
import random
import sqlite3
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
from nvme_hier import columns as C, loader as L, parse as P   # noqa: E402

SEPARATORS = {"packets": 0, "link": 18, "split": 9, "nvme_transaction": 63, "nvme_command": 129}


def test_parsers():
    assert P.time_stamp_ps("0000.161897042000s") == 161897042000
    assert P.time_stamp_ps("0001.5") == 10 ** 12 + 5 * 10 ** 11
    assert P.delta_ps("150.398 us") == 150398000
    assert P.delta_ps("43 ms") == 43 * 10 ** 9
    assert P.delta_ps("0.5 s") == 5 * 10 ** 11
    assert P.delta_ps("12 ps") == 12
    assert P.int_value("0x1A") == 26 and P.int_value("26") == 26 and P.int_value("2 (Read)") == 2
    assert P.int_value("") is None and P.int_value("abc") is None
    assert P.address("0x00000000FCE01008") == 0xFCE01008 and P.address("FCE01008") == 0xFCE01008
    assert P.data_bytes("256 B") == 256 and P.data_bytes("4 KB") == 4096 and P.data_bytes("00 1F 2A") == 3
    assert P.data_is_expanded("00 1F 2A") and not P.data_is_expanded("4 KB")
    assert P.fmt_ps(43 * 10 ** 9) == "43 ms" and P.fmt_ps(150398000) == "150.398 us"
    assert P.direction("upstream") == "Upstream" and P.direction("Downstream") == "Downstream"


def make_files(tmp, seed=3):
    """Five small CSVs with the customer's separator counts, a separator placed right before every label-less
    column (the ambiguous case), and three rows each. Returns (paths, truth positions)."""
    rng = random.Random(seed)
    paths, truth = {}, {}
    for key, nsep in SEPARATORS.items():
        names = C.original_names(key)
        ll = set(C.label_less_positions(key))
        hdr, pos = [], []
        for i in range(len(names)):
            if nsep and (i in ll or (rng.random() < nsep / len(names) and len(hdr) - len(pos) < nsep - len(ll))):
                hdr.append("")
            pos.append(len(hdr))
            hdr.append("" if i in ll else names[i])
        while len(hdr) - len(pos) < nsep:
            hdr.append("")
        truth[key] = pos
        canon = C.canonical_names(key)
        cpos = {canon[i]: pos[i] for i in range(len(names))}
        p = os.path.join(tmp, key + ".csv")
        paths[key] = p
        with open(p, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(hdr)
            for r in range(3):
                row = [""] * len(hdr)

                def put(name, val):
                    row[cpos[name]] = val
                if key == "link":
                    put("Link Tra", str(r + 1)); put("Link Dir", "Upstream"); put("Link Speed", "16.0"); put("PSN", str(100 + r))
                    if r == 2:
                        put("Cpl.TLP Type", "CplD"); put("Cpl.Length", "16")
                    else:
                        put("Mem.TLP Type", "MRd(64)"); put("Mem.Length", "16")
                    put("RequesterID", "002:00:0"); put("Tag", str(r)); put("Address", "0x00000004800A0000")
                    put("Metrics.# Packets", "2"); put("Time Delta", "1.5 us"); put("Time Stamp", "0001.%012ds" % (r * 1000))
                    put("Link Tra Error", "Nak received" if r == 1 else "")
                elif key == "split":
                    put("Split Tra", str(r + 1)); put("Link Dir", "Upstream"); put("Link Speed", "16.0"); put("Mem.TLP Type", "MRd(64)")
                    put("RequesterID", "002:00:0"); put("Tag", str(r)); put("Cpl Status", "SC"); put("Metrics.# LinkTrans", "2")
                    put("Time Delta", "43.1 ms" if r == 1 else "900 ns"); put("Time Stamp", "0001.%012ds" % (r * 1000))
                elif key == "nvme_transaction":
                    put("NVMe", str(r + 1)); put("Link Dir", "Downstream"); put("Device ID", "002:00:0"); put("QID", "3")
                    put("SQID", "3"); put("CID", str(70 + r)); put("Type", "Doorbell" if r == 0 else "Data")
                    put("Metrics.# Link & Split Trans", "1"); put("Time Stamp", "0001.%012ds" % (r * 1000))
                    put("Errors", "Incomplete sub-transaction" if r == 2 else ""); put("Warnings", "late" if r == 0 else "")
                elif key == "nvme_command":
                    put("NVMe Cmd", str(r + 1)); put("Link Dir", "Downstream"); put("OPC", "0x01"); put("SQID", "3"); put("CQID", "3")
                    put("CID", str(70 + r)); put("SLBA", "4096"); put("NLB", "7"); put("ST.SCT", "0"); put("ST.SC", "4" if r == 1 else "0")
                    put("Metrics.# NVME Trans", "26"); put("Time Delta", "2.2 ms"); put("Time Stamp", "0001.%012ds" % (r * 1000))
                    put("Errors", "2 error(s)" if r == 1 else ""); put("Warnings", "1 warning(s)" if r == 0 else "")
                    put("RNG 0.SLBA", "100"); put("AD", "1" if r == 2 else ""); put("Errors#2", "1 error(s)" if r == 2 else "")
                else:
                    put("Packet", str(r)); put("Link Dir", "Upstream"); put("TLP Type", "MRd(64)"); put("PSN", str(r))
                    put("RequesterID", "002:00:0"); put("Tag", str(r)); put("Address", "0x00000004800A0000"); put("Length", "16")
                    put("Time Delta", "150.398 us"); put("Time Stamp", "0000.161897042000s"); put("DATA", "64 B")
                w.writerow(row)
    return paths, truth


def test_alignment_and_load():
    with tempfile.TemporaryDirectory() as tmp:
        paths, truth = make_files(tmp)
        for key in SEPARATORS:
            hdr, _ = L.sniff(paths[key])
            assert L.guess_level(hdr) == key, (key, L.guess_level(hdr))
            al = L.align_header(key, hdr, L.prescan_values(paths[key], L.ambiguous_columns(key, hdr)))
            canon = C.canonical_names(key)
            bad = [(canon[i], al.positions.get(canon[i]), truth[key][i]) for i in range(len(canon))
                   if al.positions.get(canon[i]) != truth[key][i]]
            assert not bad, (key, bad[:5])
            assert len(al.separators) == SEPARATORS[key], (key, len(al.separators))
        db = os.path.join(tmp, "hier.sqlite")
        rep = L.load_upload(db, paths)
        for k, r in rep.items():
            assert r["rows"] == 3 and r["found_named_columns"] == r["expected_named_columns"], (k, r)
            assert not r["missing_columns"] and not r["unknown_columns"] and not r["unreadable_cells"], (k, r)
        con = sqlite3.connect(db)
        assert con.execute("SELECT tlp_type, length FROM lnk WHERE n = 3").fetchone() == ("CplD", 16)
        assert con.execute("SELECT delta_ps FROM spl WHERE n = 2").fetchone()[0] == 43100000000
        assert con.execute("SELECT errors FROM ntx WHERE n = 3").fetchone()[0] == "Incomplete sub-transaction"
        assert con.execute("SELECT sc, errors, warnings, errors2, ad FROM cmd WHERE n = 2").fetchone() == (4, "2 error(s)", None, None, None)
        assert con.execute("SELECT errors2, ad FROM cmd WHERE n = 3").fetchone() == ("1 error(s)", 1)
        assert con.execute("SELECT addr, nbytes FROM pkt WHERE n = 1").fetchone() == (0x4800A0000, 64)
        assert L.get_meta(con, "levels_present") == C.LEVEL_ORDER
        con.close()


def test_unknown_and_missing_columns():
    hdr = ["Link Tra", "Link Dir", "", "Link Tra Error", "Mystery", "PSN"] + C.canonical_names("link")[5:]
    al = L.align_header("link", hdr, {2})
    assert al.unknown == [(4, "Mystery")] and not al.missing and al.positions["PSN"] == 5
    hdr2 = ["Link Tra", "Link Dir", "", "PSN"] + C.canonical_names("link")[5:]
    al2 = L.align_header("link", hdr2, {2})
    assert al2.missing == ["Link Tra Error"] and al2.positions["PSN"] == 3



# ---------------------------------------------------------------------------------------------- builder + rules on a generated set
def _generated_set(tmp):
    """Generate a small capture with the app's generator, export the five levels, return the file map and truth path."""
    import subprocess
    gen = os.path.join(ROOT, "data", "generator", "generate_synthetic_pcie_trace.py")
    exp = os.path.join(ROOT, "data", "generator", "export_levels.py")
    out = os.path.join(tmp, "t.csv")
    subprocess.run([sys.executable, gen, "--only", "T-42,S-01,C-16,L-21", "--output", out, "--seed", "11", "--data-format", "hex",
                    "--cards", os.path.join(ROOT, "data", "atlas_cards_raw.json"), "--target-bytes", "0"], check=True, capture_output=True, timeout=600)
    lv = os.path.join(tmp, "levels")
    subprocess.run([sys.executable, exp, "--csv", out, "--out", lv], check=True, capture_output=True, timeout=600)
    files = {"packets": os.path.join(lv, "packets.csv"), "link": os.path.join(lv, "link.csv"), "split": os.path.join(lv, "split.csv"),
             "nvme_transaction": os.path.join(lv, "NVME_Transactions.csv"), "nvme_command": os.path.join(lv, "nvme_command.csv")}
    return files, os.path.join(lv, "truth_packet.csv")


def test_builder_matches_truth_and_rules_fire():
    from nvme_hier import builder, rules
    with tempfile.TemporaryDirectory() as tmp:
        files, truth_path = _generated_set(tmp)
        db = os.path.join(tmp, "hier.sqlite")
        rep = L.load_upload(db, files)
        for k, r in rep.items():
            assert r["found_named_columns"] == r["expected_named_columns"] and not r["missing_columns"], (k, r)
        b = builder.build(db)
        ch = b["checks"]
        assert ch["link_rows_whose_packet_count_differs"] == 0 and ch["split_rows_whose_link_count_differs"] == 0
        assert ch["ntx_rows_whose_unit_count_differs"] == 0 and ch["command_rows_whose_transaction_count_differs"] == 0
        con = sqlite3.connect(db)
        truth = list(csv.DictReader(open(truth_path)))
        lnk_n = {r[0]: r[1] for r in con.execute("SELECT rowid_file, n FROM lnk")}
        ntx_n = {r[0]: r[1] for r in con.execute("SELECT rowid_file, n FROM ntx")}
        cmd_n = {r[0]: r[1] for r in con.execute("SELECT rowid_file, n FROM cmd")}
        tp = {int(r["packet"]): r for r in truth if r["packet"]}
        bad = 0
        for n, pl, par in con.execute("SELECT n, parent_level, parent FROM pkt"):
            t = tp.get(n)
            if t and t["link"] and not (pl == "link" and par and lnk_n[par] == int(t["link"])):
                bad += 1
        assert bad == 0, "packet->link mismatches: %d" % bad
        nt = {}
        for r in truth:
            if r["ntx"] and int(r["ntx"]) not in nt:
                nt[int(r["ntx"])] = r
        bad_ntx = [(n, typ, qid, dbi) for n, pl, par, typ, qid, dbi in con.execute("SELECT n, parent_level, parent, type, qid, db_index FROM ntx")
                   if n in nt and (cmd_n.get(par) if par else None) != (int(nt[n]["cmd"]) if nt[n]["cmd"] else None)]
        # the only allowed differences: completion-queue head doorbells the generator rings twice with the same head value.
        # Such a doorbell acknowledges several completion entries at once (NVMe: the head pointer moves past all of them);
        # which of those commands it hangs under in a tree is a modelling choice. The builder uses the specification's rule
        # (the entry read last sits in slot head - 1, in the queue as it was created at that moment); the generator pairs
        # them in completion order. Every difference must be such a shared-head doorbell, nothing else.
        heads = {}
        for qid, dbi in con.execute("SELECT qid, db_index FROM ntx WHERE type LIKE 'Completion Queue Head Doorbell'"):
            heads[(qid, dbi)] = heads.get((qid, dbi), 0) + 1
        assert all(typ == "Completion Queue Head Doorbell" and heads.get((qid, dbi), 0) >= 2 for _, typ, qid, dbi in bad_ntx), bad_ntx[:5]
        rr = rules.apply(db, {"split": {"ps": 43 * 10 ** 9, "source": "platform rule"}})
        assert rr["by_rule"].get("cmd.status_error", 0) >= 1, rr      # S-01: invalid opcode
        assert rr["by_rule"].get("spl.cpl_ur", 0) >= 1, rr            # T-42: register read answered UR
        assert rr["limits"]["split"]["set_by_admin"] and rr["limits"]["split"]["text"] == "43 ms"
        row = con.execute("SELECT role, cause_level FROM cmd WHERE n_findings > 0").fetchone()
        assert row and row[0].startswith("root"), row
        con.close()


def test_signature_store_and_optimiser():
    from nvme_hier import signature as G, store as S, optimise as O
    sig = G.compute({"dev": "X", "fw": "1", "lvl": "split", "err": "spl.latency_over_limit", "cmd": "io.Write", "part": "data", "cause": "lnk.replay", "st": "sct0.sc04", "dnr": 0})
    same = G.compute({"dev": " x ", "fw": "1", "lvl": "split", "err": "SPL.latency_over_limit", "cmd": "io.Write", "part": "data", "cause": "lnk.replay", "st": "sct0.sc04", "dnr": "0"})
    other = G.compute({"dev": "Y", "fw": "2", "lvl": "split", "err": "spl.latency_over_limit", "cmd": "io.Write", "part": "data", "cause": "lnk.replay", "st": "sct0.sc04", "dnr": 1})
    assert sig["fine"] == same["fine"] and sig["fine"] != other["fine"] and sig["coarse"] == other["coarse"]
    with tempfile.TemporaryDirectory() as tmp:
        st = S.Store(os.path.join(tmp, "k.sqlite"))
        st.touch_signature(sig)
        r = st.signal(sig["fine"], None, "correct", "a", proposal_steps=[{"step": 1, "command": "Write"}], proposal_text="t")
        pid = r["new_procedure_id"]
        r2 = st.signal(sig["fine"], pid, "correct_with_edits", "a", edited_steps=[{"step": 1, "command": "Write"}, {"step": 2, "command": "Flush"}])
        k = st.lookup(sig)
        assert [p["id"] for p in k["exact"]] == [r2["new_procedure_id"]], k["exact"]      # the old version is superseded
        assert k["exact"][0]["supersedes"] == pid and k["exact"][0]["version"] == 2
        st.reorder(sig["fine"], [r2["new_procedure_id"]], "a")
        assert st.lookup(sig)["exact"][0]["ordered_by"] == "the admin's order"
    rows = [
        {"rowid_file": 1, "position": "above", "opc": 1, "sqid": 3, "cid": 1, "nsid": 1, "slba": 0, "nlb": 7, "t_ps": 0, "dur_ps": 10 ** 6, "raw": {}},
        {"rowid_file": 2, "position": "above", "opc": 1, "sqid": 3, "cid": 2, "nsid": 1, "slba": 5000, "nlb": 7, "t_ps": 10 ** 6, "dur_ps": 10 ** 6, "raw": {}},
        {"rowid_file": 3, "position": "above", "opc": 0, "sqid": 3, "cid": 3, "nsid": 1, "t_ps": 2 * 10 ** 6, "dur_ps": 10 ** 6, "raw": {}},
        {"rowid_file": 4, "position": "fault", "opc": 2, "sqid": 3, "cid": 4, "nsid": 1, "slba": 4, "nlb": 7, "t_ps": 3 * 10 ** 6, "dur_ps": 10 ** 6, "raw": {}, "findings": [{"name": "slow"}]},
        {"rowid_file": 5, "position": "below", "opc": 2, "sqid": 3, "cid": 5, "nsid": 1, "slba": 4, "nlb": 0, "t_ps": 3.5 * 10 ** 6, "dur_ps": 10 ** 6, "raw": {}},
        {"rowid_file": 6, "position": "below", "opc": 2, "sqid": 4, "cid": 6, "nsid": 1, "slba": 9000, "nlb": 0, "t_ps": 9 * 10 ** 6, "dur_ps": 10 ** 6, "raw": {}},
    ]
    o = O.optimise(rows)
    kept = [r["rowid_file"] for r in o["rows"] if r["keep"]]
    assert 1 in kept and 3 in kept and 5 in kept and 6 not in kept and 2 not in kept, kept
    assert o["steps"][-1]["position"] == "below" and o["steps"][0]["command"] == "Write"


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
            print("ok", name)
    print("all passed")


def test_real_export_header_layout():
    """The customer's analyzer export of 2026-11-03 (header_diff/*.csv): label-less header cells hold the first row's
    text ("16.0", "1 warning(s)"), sub-columns are bare after their group cell ("ST" then "SCT"), the second of two
    same-named columns has no "#2" (CSI, CSI; Log Page Identifier Supported.IOS#2 -> IOS), underscores replace
    spaces (AckNak_Seq_Num), blank separator columns are absent, link.csv lacks Cpl.TLP Type, Cpl.Length,
    Msg.TLP Type and Msg.Length and carries nine extra columns, split.csv carries five extra columns (a Cfg group).
    Every known column present must be found, the absent ones reported missing, the extras kept and named."""
    import re
    LINK_ABSENT = ["Cpl.TLP Type", "Cpl.Length", "Msg.TLP Type", "Msg.Length"]
    LINK_EXTRA = ["Implicit ACK", "No-Snoop", "No-Snoop Requirement", "No-Snoop Scale", "No-Snoop Value", "Snoop", "Cfg", "DeviceID", "Register"]
    SPLIT_EXTRA = ["Split Tra Error", "Cfg", "TLP Type", "DeviceID", "Register"]
    for key in C.LEVEL_ORDER:
        known = C.canonical_names(key)
        orig = C.original_names(key)
        label_less = set(C.label_less_positions(key))
        known_set = set(known)
        hdr, kept = [], []
        for i, name in enumerate(known):
            if key == "link" and name in LINK_ABSENT:
                continue
            if i in label_less:
                cell = orig[i]                                    # "16.0", "1 warning(s)", ...
            elif "." in name and name.partition(".")[0] in known_set:
                cell = name.partition(".")[2]                     # bare sub-column name
            else:
                cell = name.replace(" ", "_") if name == "AckNak Seq Num" else name
            cell = re.sub(r"#\d+$", "", cell)                     # the export never numbers duplicates
            hdr.append(cell)
            kept.append(name)
        if key == "link":
            hdr = hdr[:28] + LINK_EXTRA[:6] + hdr[28:] + LINK_EXTRA[6:]   # extras in the middle and at the end
        if key == "split":
            hdr = hdr + SPLIT_EXTRA
        al = L.align_header(key, hdr)
        r = al.report(key)
        assert not r["unknown_columns"], (key, r["unknown_columns"][:5])
        assert r["found_named_columns"] == len(kept), (key, r["found_named_columns"], len(kept), r["missing_columns"][:5])
        assert r["missing_columns"] == (LINK_ABSENT if key == "link" else []), (key, r["missing_columns"][:8])
        assert len(set(al.positions.values())) == len(al.positions), key
        for name in kept:                                          # every kept name sits on the cell made for it
            assert hdr[al.positions[name]] == re.sub(r"#\d+$", "", (orig[known.index(name)] if known.index(name) in label_less else (name.partition(".")[2] if "." in name and name.partition(".")[0] in known_set else name.replace(" ", "_") if name == "AckNak Seq Num" else name))), (key, name)
        if key == "link":
            assert r["extra_columns_kept"] == ["Implicit ACK", "No-Snoop", "No-Snoop Requirement", "No-Snoop Scale", "No-Snoop Value", "Snoop", "Cfg", "Cfg.DeviceID", "Cfg.Register"], r["extra_columns_kept"]
        elif key == "split":
            assert r["extra_columns_kept"] == ["Split Tra Error", "Cfg", "Cfg.TLP Type", "Cfg.DeviceID", "Cfg.Register"], r["extra_columns_kept"]
        else:
            assert r["extra_columns_kept"] == [], (key, r["extra_columns_kept"])
    # the synthetic layout (blank label-less cells, dotted names, separators) is unchanged
    hdr = ["Link Tra", "Link Dir", "", "", "", "Link Tra Error", "PSN", "Mem", "", "Mem.TLP Type"]
    al = L.align_header("link", hdr, {2})
    assert al.positions["Link Speed"] == 2 and al.positions["Mem.TLP Type"] == 9 and al.header_format == "single row"
    assert al.report("link")["extra_columns_kept"] == []


def test_stored_real_header_fast_path(tmp_path, monkeypatch):
    """A header that equals one of the customer's stored real headers (data/lecroy_real_headers.json) is aligned from
    the stored table: every cell already known by its position, no matching logic. Label-less text (16.0, 1 warning(s))
    may differ in value between recordings and still matches."""
    hdr = ["Link Tra", "Link Dir", "16.0", "Link Tra Error", "PSN", "Mem", "TLP Type", "Attributes", "Length", "RequesterID", "Tag", "Address",
           "1st BE", "Last BE", "Data", "VC ID", "Metrics", "# Packets", "Time Delta", "Time Stamp", "Cpl", "CompleterID", "Cpl Status", "BCM",
           "Byte Cnt", "Lwr Addr", "Explicit ACK", "Msg", "Msg Routing", "Message Code", "Implicit ACK", "No-Snoop", "No-Snoop Requirement",
           "No-Snoop Scale", "No-Snoop Value", "Snoop", "Cfg", "DeviceID", "Register"]
    C._REAL = {}                                              # no stored table: the matching logic aligns it
    al0 = L.align_header("link", hdr)
    assert al0.report("link")["found_named_columns"] == 30 and al0.report("link")["missing_columns"] == ["Cpl.TLP Type", "Cpl.Length", "Msg.TLP Type", "Msg.Length"]
    entry = {"name": "unit test", "header": hdr, "columns": {str(i): n for n, i in al0.positions.items()}, "separators": [], "absent": al0.missing}
    monkeypatch.setattr(C, "_REAL", {"link": [entry]})
    al = L.align_header("link", hdr)
    assert al.header_format.startswith("the customer's stored header") and al.positions == al0.positions and al.missing == [] and al.report("link")["found_named_columns"] == al.report("link")["expected_named_columns"] == 39
    hdr2 = list(hdr); hdr2[2] = "32.0"                      # another link speed in the label-less cell: still the stored header
    al2 = L.align_header("link", hdr2)
    assert al2.header_format.startswith("the customer's stored header") and al2.positions["Link Speed"] == 2 and al2.renamed["Link Speed"] == "32.0"
    hdr3 = list(hdr); hdr3[6] = "TLP_Type"                   # a different spelling: not the stored header, the matching logic takes over
    al3 = L.align_header("link", hdr3)
    assert not al3.header_format.startswith("the customer's stored header") and al3.positions["Mem.TLP Type"] == 6
    monkeypatch.setattr(C, "_REAL", None)


def test_customer_real_headers_table():
    """data/lecroy_real_headers.json (the customer's 1st_pex export of 2026-11-03, 2,378 cells): every stored header is
    aligned from the table, every known column of the file is mapped (link.csv lacks four by design), nothing is unknown,
    and the matching logic alone reaches the same mapping."""
    import json
    d = json.load(open(C.REAL_HEADERS_JSON, encoding="utf-8"))
    assert set(d["files"]) == set(C.FILE_KEYS.values())
    for fname, entries in d["files"].items():
        key = next(k for k, v in C.FILE_KEYS.items() if v == fname)
        e = entries[-1]
        C._REAL = None
        al = L.align_header(key, e["header"])
        r = al.report(key)
        assert al.header_format.startswith("the customer's stored header"), (fname, al.header_format)
        # the customer's own header is the expected list: everything found, nothing missing, nothing extra
        assert r["found_named_columns"] == r["expected_named_columns"] == len(e["columns"]), (fname, r)
        assert not r["unknown_columns"] and not r["missing_columns"] and not r["extra_columns_kept"], (fname, r)
        assert (key != "link") or ("one TLP Type column" in r["absent_note"]), (fname, r["absent_note"])
        assert len(al.positions) + len(al.separators) == len(e["header"]), (fname, len(al.positions), len(al.separators), len(e["header"]))
        C._REAL = {}
        al2 = L.align_header(key, e["header"])
        C._REAL = None
        assert al2.positions == al.positions and sorted(al2.separators) == sorted(al.separators), (fname, "matching logic differs from the stored table")


def test_every_column_is_kept(tmp_path):
    """Nothing of the file is dropped (owner's rule 2026-11-03): a value under a blank spacer header cell is stored in the
    row's raw cells under the column's position, next to the named and the unknown columns."""
    import sqlite3, json
    hdr = ["Split Tra", "Link Dir", "", "", "", "Mem", "", "Mem.TLP Type", "", "RequesterID", "CompleterID", "Tag", "TC", "VC ID", "Address", "Cpl Status", "Data", "Metrics", "", "Metrics.# LinkTrans", "", "Time Delta", "Time Stamp", "", "", ""]
    row = ["1", "Upstream", "16.0", "", "", "", "SURPRISE", "MRd(64)", "", "002:00:0", "000:02:4", "151", "0", "0", "0x480420800", "SC", "64 bytes", "", "", "2", "", "1.000 us", "0000.594954223120s", "", "", ""]
    p = tmp_path / "split.csv"
    with open(p, "w", newline="") as f:
        import csv; w = csv.writer(f); w.writerow(hdr); w.writerow(row)
    con = sqlite3.connect(str(tmp_path / "t.sqlite"))
    L.create_tables(con, "split")
    L.load_file(con, "split", str(p))
    raw = json.loads(con.execute("SELECT raw FROM spl").fetchone()[0])
    assert raw.get("column 7") == "SURPRISE", raw            # the value under the blank header cell at position 7 is kept
    assert raw.get("Mem.TLP Type") == "MRd(64)" and raw.get("Link Speed") == "16.0", raw


def test_huge_values_never_stop_a_load(tmp_path):
    """The customer's load of 2026-11-03 stopped with 'Python int too large to convert to SQLite INTEGER'. A cell whose
    number does not fit 64 bits (a data dump, a serial, a 32-digit hex string) is counted as unreadable with its example,
    the row is kept with all its cells, and the load goes on, at every level and in every typed column."""
    import csv, json, sqlite3
    huge = {"dec": "99999999999999999999999", "hex": "0x" + "F" * 32, "barehex": "A" * 40, "split": "FFFFFFFFF:FFFFFFFF"}
    for key in C.LEVEL_ORDER:
        hdr = list(C.canonical_names(key))
        orig = C.original_names(key); ll = set(C.label_less_positions(key))
        hdr = [orig[i] if i in ll else h for i, h in enumerate(hdr)]
        for bad in huge.values():
            row = [bad] * len(hdr)
            p = tmp_path / ("%s_%s.csv" % (key, len(bad)))
            with open(p, "w", newline="") as f:
                w = csv.writer(f); w.writerow(hdr); w.writerow(row); w.writerow(row)
            con = sqlite3.connect(str(tmp_path / "h.sqlite"))
            L.create_tables(con, key)
            rep = L.load_file(con, key, str(p))
            assert con.execute("SELECT COUNT(*) FROM %s" % L.TABLE[key]).fetchone()[0] == 2, (key, bad[:12])
            raw = json.loads(con.execute("SELECT raw FROM %s" % L.TABLE[key]).fetchone()[0])
            assert all(v == bad for v in raw.values()), (key, "cells lost")
            for v in con.execute("SELECT * FROM %s" % L.TABLE[key]).fetchone():
                assert not isinstance(v, int) or -2 ** 63 <= v < 2 ** 63
            con.close()


def test_parallel_load_is_identical_to_serial(tmp_path):
    """The multi-core loader (2026-11-03) gives exactly the serial result: every table row, every count, every
    unreadable cell, with many small chunks so that many chunk boundaries are exercised."""
    import glob, hashlib, json
    # the data is generated here (the generator ships with the application; the sample folders do not)
    gen_files, _truth = _generated_set(str(tmp_path / "gen"))
    L.PARALLEL_MIN_BYTES, L.CHUNK_BYTES = 0, 128 * 1024
    try:
        results = {}
        for workers in (1, 3):
            db = str(tmp_path / ("w%d.sqlite" % workers))
            con = L.open_db(db); L.WORKERS = workers
            out = {}
            for key in C.LEVEL_ORDER:
                p = gen_files[key]
                L.create_tables(con, key)
                rep = L.load_file(con, key, p)
                m = hashlib.sha256()
                cols = [r[1] for r in con.execute("PRAGMA table_info(%s)" % L.TABLE[key])]
                for row in con.execute("SELECT %s FROM %s ORDER BY rowid_file" % (", ".join(cols), L.TABLE[key])):
                    m.update(repr(row).encode())
                out[key] = (rep["rows"], m.hexdigest(), json.dumps(rep["unreadable_cells"], sort_keys=True), json.dumps(rep["blank_key_cells"], sort_keys=True))
                if workers == 3:
                    assert rep.get("parallel") and rep["parallel"]["chunks"] >= 1, (key, rep.get("parallel"))
            con.close()
            results[workers] = out
        assert results[1] == results[3], {k: (results[1][k][:2], results[3][k][:2]) for k in results[1] if results[1][k] != results[3][k]}
    finally:
        L.PARALLEL_MIN_BYTES, L.CHUNK_BYTES, L.WORKERS = 64 * 1024 * 1024, 4 * 1024 * 1024, None
