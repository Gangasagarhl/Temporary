#!/usr/bin/env bash
# All tests: end-to-end API (stand-in LLM), stage-2 unit tests, stage-1 engine fixtures.
set -e
cd "$(dirname "$0")"
python3 -W ignore tests/test_app.py   # includes stage2/tests_v3.py + tests_v4.py and the stage-1 fixtures
python3 tests/test_nvme_hier.py || exit 1    # five-level hierarchy: loader, builder vs ground truth, rules, store, optimiser
# five-level hierarchy end to end through the HTTP API (needs the running server on :8077; one model call when a model is configured)
if curl -sf -m 5 http://127.0.0.1:8077/api/hier/uploads >/dev/null 2>&1; then
    python3 tests/test_hier_e2e.py --cleanup-store || exit 1    # --cleanup-store: otherwise its procedures pile up in the store and later runs see duplicates
    python3 tests/test_isolate.py --cleanup-store || exit 1      # the isolation tab: window, stateful chat, memory, evidence loop, test case, summary
    python3 tests/test_agentic.py || exit 1                      # the agent families (/agents), with the stand-in; add --real for real Claude Code calls
else
    echo "skipped tests/test_hier_e2e.py: the application does not answer on http://127.0.0.1:8077 (start it to run the end-to-end suite)"
fi
