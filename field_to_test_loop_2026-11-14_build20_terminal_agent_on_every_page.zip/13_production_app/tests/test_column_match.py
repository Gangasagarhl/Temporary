"""Which column holds this kind of data? (agentic/column_match.py; owner, 2026-11-14: "if there is a column name is not
available, it doesn't mean that the column itself might not be present ... other column might be having the same kind of
data ... do multiple parallel requests").

What must hold:
  1. the short list is made by code from what Family 1 knows, ranked by containment (shared / wanted), never Jaccard;
  2. counters numbered from 1, 0/1 flags and words every column shares are not support by themselves;
  3. the exact count reads each file once, counts rows and lines, and says when it stopped at its cap;
  4. the model picks from the short list only: a name outside it is dropped; "none of these" is an answer;
  5. the level of support is decided by code: the values match / the kind of data matches / only the name is alike;
  6. the result is the same with 1 call at a time and with 8;
  7. the route for the pages answers with the same cards and refuses a request of the wrong shape in words.
No model: the "model" is a function written here."""
import csv
import json
import os
import random
import sys
import threading
import time

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from agentic import column_match as CM  # noqa: E402


def make_file(folder, name, header, rows, meanings=None, keep=40):
    """A CSV with its data dictionary and Explorer memory, counted here as the Data Explorer counts."""
    path = os.path.join(folder, name)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        w.writerows(rows)
    cols, mem = [], []
    for i, h in enumerate(header):
        seen = {}
        for n, r in enumerate(rows, 1):
            v = r[i] if i < len(r) else ""
            if v != "":
                seen.setdefault(v, []).append(n)
        if not seen:
            continue
        nums = [int(v) for v in seen if v.lstrip("-").isdigit()]
        typ = "integer" if len(nums) == len(seen) else "text"
        top = sorted(seen.items(), key=lambda kv: (-len(kv[1]), kv[0]))[:keep]
        m = {"column": h, "position": i, "type": typ, "rows_with_value": sum(len(x) for x in seen.values()), "distinct": len(seen),
             "distinct_more_than_counted": False, "top_values": [{"value": v, "count": len(x), "rows": x[:3]} for v, x in top]}
        if typ == "integer":
            m.update(min=min(nums), max=max(nums))
        mem.append(m)
        cols.append({"column": h, "type": typ, "rows_with_value": m["rows_with_value"], "distinct": len(seen), "observed": "%d rows hold a value" % m["rows_with_value"],
                     "meaning": (meanings or {}).get(h, ""), "status": "from a reference document" if (meanings or {}).get(h) else "no meaning found",
                     "source": {"kind": "document", "ref": "reference.pdf page 3", "quote": "x"} if (meanings or {}).get(h) else None, "keywords": []})
    mpath = os.path.join(folder, name + ".memory.json")
    with open(mpath, "w", encoding="utf-8") as fh:
        json.dump({"path": path, "columns": mem}, fh)
    return {"name": name, "path": path, "dictionary": {"file": name, "path": path, "rows": len(rows), "columns": cols, "explorer_memory": mpath}}


class Model:
    """The stand-in for the model: answers per file from a function, records what it was shown."""

    CALLS_MOST = 8

    def __init__(self, answer=None, slow=False):
        self.answer = answer or (lambda ctx: {"choices": [], "none_of_these": True, "note": ""})
        self.seen, self.slow, self.lock, self.together, self.most = [], slow, threading.Lock(), 0, 0

    def ask(self, run_id, agent, instruction, context, schema_text, must_have, standin, **kw):
        ctx = json.loads(context)
        with self.lock:
            self.together += 1
            self.most = max(self.most, self.together)
            self.seen.append((agent, ctx, instruction))
        if self.slow:
            time.sleep(random.uniform(0.01, 0.08))
        with self.lock:
            self.together -= 1
        ans = self.answer(ctx)
        return (standin(), "stand-in (no model)", "") if ans == "standin" else (ans, "the model (written by the test)", "")


CITIES = ["Pune", "Goa", "Delhi", "Agra", "Kochi", "Indore", "Surat", "Patna", "Nagpur", "Bhopal", "Mysuru", "Shimla", "Ranchi", "Raipur", "Jaipur", "Kanpur",
          "Nashik", "Rajkot", "Meerut", "Madurai", "Vadodara", "Thane", "Howrah", "Gwalior", "Jodhpur", "Guwahati", "Hubli", "Tiruchi", "Salem", "Warangal"]


@pytest.fixture
def files(tmp_path):
    d = str(tmp_path)
    visits = make_file(d, "visits.csv", ["Row", "Town", "Minutes", "Flag", "Tag"],
                       [[str(i), CITIES[i % len(CITIES)], str(3 + i % 17), str(i % 2), "0x%04X" % (4096 + i)] for i in range(1, 301)],
                       meanings={"Town": "the city where the visit took place", "Minutes": "how long the visit lasted, in whole minutes",
                                 "Row": "the number of the record, counted from 1", "Flag": "1 when the visitor came back", "Tag": "the tag of the visit, 16 bits"}, keep=400)
    shops = make_file(d, "shops.csv", ["Shop", "Area", "TagRef", "Minute"],
                      [["s%d" % i, ["Pune", "Camp", "Fort", "Dock"][i % 4], "0x%04X" % (4096 + 2 * i), str(i)] for i in range(1, 41)],
                      meanings={"Area": "the part of town of the shop", "TagRef": "the visit this shop record belongs to"}, keep=400)
    return [visits, shops]


# ---------------------------------------------------------------------------------------------- the pieces
def test_the_shape_of_a_value_and_its_words():
    assert CM.shape("0x02 (Read)") == "0xH (A)" and CM.shape("12.5 ms") == "9.9 A" and CM.shape("2026-11-14") == "9-9-9" and CM.shape(" Pune ") == "A"
    assert CM.shape_words("0xH (A)") == '0x and hexadecimal digits, a space, "(", letters, ")"' and CM.shape_words("") == "not known"
    assert CM.name_alike("Link Tra", "Link Tra#") > 0.9 and CM.name_alike("SQID", "sqid") == 1.0 and CM.name_alike("City", "Minutes") < CM.NAME_ALIKE


def test_one_signature_per_column_from_what_family_1_knows(files):
    sigs, none = CM.signatures(files + [{"name": "new.csv", "path": "x", "dictionary": None}])
    assert none == ["new.csv"] and [(s["file"], s["column"]) for s in sigs][:5] == [("shops.csv", "Shop"), ("shops.csv", "Area"), ("shops.csv", "TagRef"), ("shops.csv", "Minute"), ("visits.csv", "Row")]
    by = {(s["file"], s["column"]): s for s in sigs}
    row, flag, tag, town = by[("visits.csv", "Row")], by[("visits.csv", "Flag")], by[("visits.csv", "Tag")], by[("visits.csv", "Town")]
    assert row["counter_like"] and row["min"] == 1 and row["max"] == 300 and not row["flag_like"]
    assert flag["flag_like"] and not flag["counter_like"]
    assert tag["shape"] == "0xH" and tag["known_is_all"] and town["meaning"].startswith("the city") and town["source"] == "reference.pdf page 3"
    assert town["known"]["pune"]["lines"] and town["distinct"] == 30


# ---------------------------------------------------------------------------------------------- 1. containment, not Jaccard
def test_the_column_that_holds_the_wanted_values_ranks_first_even_when_a_small_column_shares_one(files):
    wanted = CM.wanted_of("City", "visits.csv", "the city of a visit", CITIES[:14], CM.signatures(files)[0])
    short = CM.shortlist(wanted, CM.signatures(files)[0])
    first, by = short[0], {(c["sig"]["file"], c["sig"]["column"]): c for c in short}
    assert (first["sig"]["file"], first["sig"]["column"]) == ("visits.csv", "Town") and first["containment"] == 1.0
    area = by[("shops.csv", "Area")]
    # Jaccard would prefer the small column (1 shared of 17 in all = 0.06 against 14 of 30 = 0.47 here it does not, so the
    # numbers are checked the other way round: containment of Area is 1/14, far below Town's 14/14, whatever its size)
    assert area["containment"] == round(1 / 14.0, 4) and area["shared"] == ["pune"]
    assert len(short) <= CM.SHORT_LIST


def test_values_of_a_same_named_column_in_another_file_are_the_examples_when_none_were_given(files):
    files[1]["dictionary"]["columns"].append({"column": "Town", "type": "text", "rows_with_value": 3, "distinct": 3, "meaning": "", "keywords": [
        {"value": "Pune", "count": 1, "rows": [1]}, {"value": "Goa", "count": 1, "rows": [2]}, {"value": "Delhi", "count": 1, "rows": [3]}]})
    wanted = CM.wanted_of("Town", "third.csv", "", None, CM.signatures(files)[0])
    assert wanted["values"] == ["pune", "goa", "delhi"] and wanted["values_from"].startswith("the values the Data Explorer kept of shops.csv column Town")


# ---------------------------------------------------------------------------------------------- 2. inclusion alone is not support
def test_a_counter_and_a_flag_that_include_the_wanted_values_are_not_proposed(files):
    r = CM.propose(Model(), 1, files, column="Queue", file="visits.csv", description="", values=[str(i) for i in range(1, 21)], use_model=False)
    assert r["none"] and [p for p in r["proposals"] if p["level"] != CM.NAME_ONLY] == []
    rows = next(x for x in r["not_supported"] if x["column"] == "Row")
    assert rows["overlap"]["found"] == 20 and rows["overlap"]["share_percent"] == 100.0           # every value is in the counter ...
    assert any("not support by themselves" in a and "small whole numbers" in a for a in rows["against"])     # ... and that proves nothing
    assert "No column of the 2 files looked at holds" in r["answer"] and "Read the new files" in r["answer"]
    flags = CM.propose(Model(), 1, files, column="Present", description="", values=["0", "1"], use_model=False)
    flag = next(x for x in flags["not_supported"] if x["column"] == "Flag")
    assert flags["none"] and any("words many columns share" in a for a in flag["against"])
    # the same two values WITH a second, independent sign (the meaning names the wanted data) are support, and the card says what it rests on
    back = CM.propose(Model(), 1, files, column="Came back", description="", values=["0", "1"], use_model=False)
    top = back["proposals"][0]
    assert (top["column"], top["level"]) == ("Flag", CM.VALUES_MATCH) and any("counts here together with the meaning" in a for a in top["against"])
    assert CM.by_chance(["enabled", "reserved"], {}) != "" and CM.by_chance(["0x%04x" % i for i in range(4096, 4196)], {}) == ""


# ---------------------------------------------------------------------------------------------- 3. the exact count
def test_the_exact_count_reads_each_file_once_and_says_its_cap(files, monkeypatch):
    opened = []
    real = open

    def spy(path, *a, **k):
        if str(path).endswith(".csv"):
            opened.append(os.path.basename(str(path)))
        return real(path, *a, **k)
    monkeypatch.setattr("builtins.open", spy)
    tags = ["0x%04X" % (4096 + i) for i in range(1, 61)]
    r = CM.propose(Model(), 1, files, column="VisitTag", file="shops.csv", description="the tag of a visit", values=tags, use_model=False)
    assert sorted(opened) == ["shops.csv", "visits.csv"]                                    # one pass per file, for all its candidates
    top = r["proposals"][0]
    assert (top["file"], top["column"], top["level"]) == ("visits.csv", "Tag", CM.VALUES_MATCH)
    o = top["overlap"]
    assert o["found"] == 60 and o["wanted_values"] == 60 and o["rows_holding_a_wanted_value"] == 60 and o["lines"] == [2, 3, 4, 5, 6]
    assert o["basis"] == "counted in the file: 300 records read"
    ref = next(p for p in r["proposals"] + r["not_supported"] if p["column"] == "TagRef")
    assert ref["overlap"]["found"] == 30 and ref["overlap"]["share_percent"] == 50.0       # every second tag: counted, not estimated
    # the cap: only the first 100 records are read, and the card says so
    capped = CM.propose(Model(), 1, files, column="VisitTag", description="the tag of a visit", values=tags, use_model=False, rows_most=100)
    o = next(p for p in capped["proposals"] + capped["not_supported"] if p["column"] == "Tag")["overlap"]
    assert o["found"] == 60 and "the file is longer: only the first 100 were read" in o["basis"]
    tiny = CM.propose(Model(), 1, files, column="VisitTag", description="the tag of a visit", values=tags, use_model=False, rows_most=10)
    assert next(p for p in tiny["proposals"] + tiny["not_supported"] if p["column"] == "Tag")["overlap"]["found"] == 10


# ---------------------------------------------------------------------------------------------- 4. the model picks from the list
def test_a_column_the_model_names_outside_the_list_is_dropped_and_none_of_these_is_an_answer(files):
    def answer(ctx):
        if ctx["FILE"] == "visits.csv":
            return {"choices": [{"column": "Duration", "why": "invented"}, {"column": "Minutes", "why": "its meaning is how long the visit lasted"}], "none_of_these": False}
        return {"choices": [], "none_of_these": True, "note": "no column of this file holds a duration"}
    m = Model(answer)
    r = CM.propose(m, 7, files, column="Minutes", file="orders.csv", description="how long a visit lasted")
    assert sorted(a for a, _c, _i in m.seen) == ["column_match_shops.csv", "column_match_visits.csv"]         # one call per file that has candidates
    shown = next(c for a, c, _i in m.seen if a.endswith("visits.csv"))
    assert shown["WANTED"]["column_named_by_the_rule"] == "Minutes" and "Minutes" in [c["column"] for c in shown["CANDIDATES"]]
    assert all(set(c) >= {"column", "meaning", "rows_with_a_value", "shape_of_its_values", "some_values"} for c in shown["CANDIDATES"])
    assert "Column matcher" in m.seen[0][2] and "used by:" not in m.seen[0][2]              # the prompt document, without its notes for people
    top = r["proposals"][0]
    assert (top["file"], top["column"], top["model_picked"]) == ("visits.csv", "Minutes", True) and top["level"] in (CM.VALUES_MATCH, CM.KIND_MATCH)
    assert top["model_reason"].startswith("its meaning is how long") and top["meaning_source"] == "reference.pdf page 3"
    assert "Duration (visits.csv)" in r["looked_at"]["dropped_by_the_program"] and all(p["column"] != "Duration" for p in r["proposals"] + r["not_supported"])
    assert r["looked_at"]["model_notes"] == ["shops.csv: no column of this file holds a duration"] and r["looked_at"]["model_calls"] == 2
    assert not r["none"] and r["answer"].startswith("1 column could stand for")
    minute = next(p for p in r["proposals"] if (p["file"], p["column"]) == ("shops.csv", "Minute"))
    assert minute["level"] == CM.NAME_ONLY and any("lies outside the range of the wanted values" in a for a in minute["against"])


def test_the_models_choice_never_raises_the_level(files):
    m = Model(lambda ctx: {"choices": [{"column": c["column"], "why": "I am sure"} for c in ctx["CANDIDATES"]], "none_of_these": False})
    r = CM.propose(m, 1, files, column="Queue", description="", values=[str(i) for i in range(1, 21)])
    assert r["none"] and all(p["level"] == CM.NAME_ONLY for p in r["proposals"])
    assert any(x["column"] == "Row" and x["model_picked"] and x["level"] is None for x in r["not_supported"])


# ---------------------------------------------------------------------------------------------- 5. the three levels
def test_the_three_levels_of_support_are_decided_by_code(files):
    tags = ["0x%04X" % (4096 + i) for i in range(1, 61)]
    values = CM.propose(Model(), 1, files, column="VisitTag", description="", values=tags, use_model=False)
    assert values["proposals"][0]["level"] == CM.VALUES_MATCH and values["proposals"][0]["column"] == "Tag"
    kind = CM.propose(Model(), 1, files, column="duration", description="how long the visit lasted", use_model=False)
    assert [(p["column"], p["level"]) for p in kind["proposals"]][0] == ("Minutes", CM.KIND_MATCH) and kind["proposals"][0]["overlap"] is None
    name = CM.propose(Model(), 1, files, column="Minutes", file="orders.csv", description="", use_model=False)
    lv = {(p["file"], p["column"]): p["level"] for p in name["proposals"]}
    assert lv[("shops.csv", "Minute")] == CM.NAME_ONLY                                      # alike by name, no meaning, no values compared
    assert lv[("visits.csv", "Minutes")] == CM.VALUES_MATCH                                 # the column of that very name in another file: its values are the examples
    with pytest.raises(ValueError, match="say what is looked for"):
        CM.propose(Model(), 1, files)
    nothing = CM.propose(Model(), 1, files, column="Voltage", description="the supply voltage in millivolts", use_model=False)
    assert nothing["none"] and nothing["proposals"] == [] and "No column of the 2 files looked at holds" in nothing["answer"]


def test_a_file_without_a_dictionary_is_said_not_silently_skipped(files):
    r = CM.propose(Model(), 1, files + [{"name": "new.csv", "path": "/nowhere/new.csv", "dictionary": None}], column="Voltage", description="the supply voltage", use_model=False)
    assert r["looked_at"]["files_without_a_dictionary"] == ["new.csv"] and "a data dictionary is not approved yet for new.csv" in r["answer"]


# ---------------------------------------------------------------------------------------------- 6. the same with 1 call and with 8
def test_the_result_does_not_depend_on_how_many_calls_run_at_once(tmp_path):
    d = str(tmp_path)
    many = [make_file(d, "f%02d.csv" % i, ["Id", "Town", "Stay"], [[str(k), CITIES[(k + i) % len(CITIES)], str(k % 9)] for k in range(1, 40)],
                      meanings={"Town": "the city where the visit took place", "Stay": "how long the visit lasted"}) for i in range(8)]
    answer = lambda ctx: {"choices": [{"column": "Town", "why": "the city"}] if int(ctx["FILE"][1:3]) % 2 else [], "none_of_these": False}      # noqa: E731
    out = []
    for most in (1, 8):
        m = Model(answer, slow=True)
        m.CALLS_MOST = most
        out.append((CM.propose(m, 1, many, column="City", description="the city of a visit", values=CITIES[:20]), m.most))
    (one, most1), (eight, most8) = out
    assert most1 == 1 and most8 > 1
    assert json.dumps(one, sort_keys=True) == json.dumps(eight, sort_keys=True)
    assert [p["file"] for p in one["proposals"] if p["level"] == CM.VALUES_MATCH][:4] == ["f01.csv", "f03.csv", "f05.csv", "f07.csv"]    # the model's picks first, then by file


# ---------------------------------------------------------------------------------------------- 7. the route
def test_the_route_answers_with_the_cards_and_refuses_a_wrong_request_in_words(tmp_path, monkeypatch):
    import fuzz_app as F
    from agentic import family1
    if not os.path.isdir(F.BASE):
        pytest.skip("the S08 sample recording is not on this machine (the code-only zip carries no samples)")
    root = str(tmp_path / "app")
    os.makedirs(root)
    app, c, _k, _r = F.setup(root)
    folder = str(tmp_path / "rec")
    os.makedirs(folder)
    f = make_file(folder, "visits.csv", ["Town", "Minutes"], [[CITIES[i % 5], str(i)] for i in range(1, 30)], meanings={"Minutes": "how long the visit lasted, in whole minutes"})
    inv = family1.inventory(folder)[0]
    monkeypatch.setattr(family1, "approved_dictionary", lambda fmt, name: f["dictionary"] if (fmt, name) == (inv["format_key"], "visits.csv") else None)
    s = app.config["services"]
    with app.app_context():
        from api import agentic_api as A
        eng = A.engine()
    pid = eng.store.exec("INSERT INTO project (admin, name, folder, refs, created, updated) VALUES (?,?,?,?,?,?)", ("t", "p", folder, "[]", time.time(), time.time()))
    r = c.post("/api/agents/projects/%d/substitute" % pid, json={"column": "duration", "file": "visits.csv", "description": "how long a visit lasted", "admin": "t"})
    assert r.status_code == 200, r.get_json()
    j = r.get_json()
    assert j["proposals"][0]["column"] == "Minutes" and j["proposals"][0]["level"] == CM.KIND_MATCH and j["looked_at"]["columns"] == 2
    assert c.post("/api/agents/projects/%d/substitute" % pid, json={}).status_code == 400
    assert c.post("/api/agents/projects/%d/substitute" % pid, json={"column": 7}).status_code == 400
    assert c.post("/api/agents/projects/%d/substitute" % pid, json={"column": "x", "values": "not a list"}).status_code == 400
    assert c.post("/api/agents/projects/999999/substitute", json={"column": "x"}).status_code == 404
    assert s is not None
