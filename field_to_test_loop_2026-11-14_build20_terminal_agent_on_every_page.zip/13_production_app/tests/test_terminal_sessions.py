"""The opencode terminal as the way to a model, with held sessions (owner, 2026-11-13).

Offline: the program is tests/fake_opencode.py, which speaks the real program's commands and event lines (the event
lines in REAL_LINES were copied from opencode 1.19.4 on 2026-11-13).
"""
import json
import os
import sys
import threading
import time

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

from agentic import core, opencode_cli as oc           # noqa: E402
from agentic.sessions import Sessions                   # noqa: E402

FAKE = os.path.join(HERE, "fake_opencode.py")
if os.name == "nt":      # the stand-in program is a script started by its first line, which Windows does not do
    pytestmark = pytest.mark.skip(reason="the stand-in opencode program of these tests is started as a script; not on Windows")
elif not os.access(FAKE, os.X_OK):
    os.chmod(FAKE, 0o755)       # a zip unpacked without file modes

REAL_LINES = "\n".join([
    '{"type":"step_start","timestamp":1794549207998,"sessionID":"ses_e2c885de2ffeGcRMd8gbBEx5U3","part":{"id":"prt_1","messageID":"msg_1","sessionID":"ses_e2c885de2ffeGcRMd8gbBEx5U3","type":"step-start"}}',
    '{"type":"tool_use","timestamp":1794549208100,"sessionID":"ses_e2c885de2ffeGcRMd8gbBEx5U3","part":{"type":"tool","tool":"read","state":{"status":"completed","input":{"filePath":"note.txt"},"output":"color: teal"}}}',
    '{"type":"step_finish","timestamp":1794549208200,"sessionID":"ses_e2c885de2ffeGcRMd8gbBEx5U3","part":{"reason":"tool-calls","type":"step-finish","tokens":{"total":1757,"input":1513,"output":90,"reasoning":154,"cache":{"write":0,"read":0}}}}',
    '{"type":"step_start","timestamp":1794549208300,"sessionID":"ses_e2c885de2ffeGcRMd8gbBEx5U3","part":{"type":"step-start"}}',
    '{"type":"text","timestamp":1794549208351,"sessionID":"ses_e2c885de2ffeGcRMd8gbBEx5U3","part":{"type":"text","text":"{\\"ok\\": true}","time":{"start":1,"end":2}}}',
    '{"type":"step_finish","timestamp":1794549208351,"sessionID":"ses_e2c885de2ffeGcRMd8gbBEx5U3","part":{"reason":"stop","type":"step-finish","tokens":{"total":11324,"input":179,"output":9,"reasoning":0,"cache":{"write":0,"read":11136}},"cost":0}}',
])
REAL_ERROR = '{"type":"error","timestamp":1794549490457,"sessionID":"ses_e2c83f6b5ffezixTvOOYCil5KI","error":{"name":"UnknownError","data":{"message":"Unexpected server error. Check server logs for details.","ref":"err_6129d827"}}}'


@pytest.fixture()
def box(tmp_path, monkeypatch):
    home = tmp_path / "fake_home"
    home.mkdir()
    monkeypatch.setenv("FAKE_OPENCODE_HOME", str(home))
    monkeypatch.delenv("FAKE_OPENCODE_ANSWER", raising=False)
    monkeypatch.delenv("FAKE_OPENCODE_SLEEP", raising=False)
    oc.forget_models()
    yield tmp_path
    oc.forget_models()


def runner(tmp, model="fake/beta-paid", **kw):
    r = core.AgentRunner(str(tmp / "sandbox"), runtime="opencode", opencode_path=FAKE, opencode_model=model,
                         sessions=Sessions(str(tmp / "sessions.sqlite")), timeout=30, web=kw.pop("web", False), **kw)
    r.TERMINAL_WAITS = (0.05, 0.05)
    r._http = lambda *a, **k: (_ for _ in ()).throw(AssertionError("the Model connection must never be used with opencode"))
    r._claude_code = lambda *a, **k: (_ for _ in ()).throw(AssertionError("Claude Code must never be started with opencode"))
    return r


def calls(tmp):
    p = tmp / "fake_home" / "calls.jsonl"
    return [json.loads(x) for x in p.read_text(encoding="utf-8").splitlines()] if p.exists() else []


def ask(r, run=1, agent="grounder", text="HOW MANY TURNS", **kw):
    return r.ask(run, agent, text, "ctx", '{"ok": true}', "ok", lambda: {"ok": "stand-in"}, **kw)


# ------------------------------------------------------------------------------------------- the program's own words
def test_the_model_list_is_read_with_limits_effort_levels_and_cost():
    with open(FAKE, encoding="utf-8") as f:
        text = f.read().split('MODELS = """', 1)[1].split('"""', 1)[0]
    got = oc.parse_models(text)
    assert [m["id"] for m in got] == ["fake/alpha-free", "fake/beta-paid", "other/gamma"]
    a, b, g = got
    assert a["name"] == "Alpha Free" and a["context"] == 2000 and a["output"] == 500 and a["variants"] == ["low", "high", "max"] and a["free"] is True
    assert b["free"] is False and b["cost_in"] == 2 and b["cost_out"] == 10 and b["variants"] == []
    assert g["provider"] == "other" and g["free"] is True
    # a list without the facts (the plain `opencode models`) still names the models, and claims nothing about cost
    plain = oc.parse_models("opencode/big-pickle\nanthropic/claude-x\n")
    assert [m["id"] for m in plain] == ["opencode/big-pickle", "anthropic/claude-x"]
    assert plain[0]["free"] is False and plain[0]["cost_known"] is False and plain[0]["context"] is None
    assert oc.parse_models("") == [] and oc.parse_models("no model here") == []


def test_an_effort_level_is_one_the_model_has():
    assert oc.variant_for("xhigh", ["low", "high", "max"]) == "max"
    assert oc.variant_for("high", ["low", "high", "max"]) == "high"
    assert oc.variant_for("medium", ["low", "high", "max"]) == "high"
    assert oc.variant_for("max", ["low", "medium"]) == "medium"
    assert oc.variant_for("high", []) is None and oc.variant_for(None, ["high"]) is None and oc.variant_for("odd", ["high"]) is None


def test_the_event_lines_of_the_real_program_are_read():
    r = oc.read_events(REAL_LINES)
    assert r["session"] == "ses_e2c885de2ffeGcRMd8gbBEx5U3" and r["text"] == '{"ok": true}' and r["error"] == ""
    assert r["tools"] == [{"tool": "read", "status": "completed"}]
    assert oc.size_now(r["tokens"]) == 11324
    e = oc.read_events(REAL_ERROR)
    assert e["error"].startswith("Unexpected server error") and e["text"] == "" and e["session"].startswith("ses_")
    odd = oc.read_events("a notice, not JSON\n[1, 2]\n" + REAL_LINES + "\n")
    assert odd["text"] == '{"ok": true}' and odd["other"] == ["a notice, not JSON"]
    assert oc.read_events("")["text"] == "" and oc.read_events(None)["session"] is None
    assert oc.read_events('{"type":"error","error":{"data":{"message":"Rate limit reached, try later"}}}')["too_many"] is True


def test_the_agents_of_a_call_may_only_read_their_own_folder():
    cfg = json.loads(oc.config_content())
    plain, web = cfg["agent"][oc.AGENT]["permission"], cfg["agent"][oc.AGENT_WEB]["permission"]
    assert list(plain)[0] == "*" and plain["*"] == "deny" and plain["external_directory"] == "deny"
    assert {k for k, v in plain.items() if v == "allow"} == {"read", "grep", "glob", "list"}
    assert {k for k, v in web.items() if v == "allow"} == {"read", "grep", "glob", "list", "webfetch", "websearch"}
    assert "bash" not in plain and "edit" not in plain and "write" not in plain
    assert cfg["share"] == "disabled"
    env = oc.environment({"PATH": "/usr/bin"}, exe="/opt/x/bin/opencode")
    assert env["PATH"].split(os.pathsep)[0] == "/opt/x/bin" and env["OPENCODE_DISABLE_CLAUDE_CODE"] == "1" and env["OPENCODE_DISABLE_PROJECT_CONFIG"] == "1"


def test_a_session_name_is_safe_as_a_command_argument():
    assert oc.safe_title('run 3 · explore "link.csv" & del *') == "run 3 explore link.csv del"
    assert oc.safe_title("") == "session" and len(oc.safe_title("x" * 500)) == 120
    cmd = oc.command("oc", "p/m", title="a|b", web=True, variant="max")
    assert cmd == ["oc", "run", "--pure", "--agent", "f2t-web", "--format", "json", "-m", "p/m", "--title", "a b", "--variant", "max"]
    assert oc.command("oc", "p/m", session="ses_1")[-2:] == ["-s", "ses_1"]


# ------------------------------------------------------------------------------------------- the application's record
def test_the_store_keeps_names_numbers_and_every_turn(tmp_path):
    S = Sessions(str(tmp_path / "s.sqlite"))
    sid = S.begin("run:7", "manager", "run 7 · manager", "opencode", "p/m", "/box")
    assert S.open_for("run:7", "manager", "opencode", "p/m") is None            # not held before the program gave its number
    S.set_terminal(sid, "ses_abc")
    held = S.open_for("run:7", "manager", "opencode", "p/m")
    assert held["id"] == sid and held["terminal_id"] == "ses_abc" and held["name"] == "run 7 · manager"
    assert S.open_for("run:7", "manager", "opencode", "p/other") is None and S.open_for("run:8", "manager", "opencode", "p/m") is None
    long = "é" * 500000
    assert S.add_turn(sid, "first question", '{"a": 1}', seconds=1.5, tokens={"total": 10}, size_tokens=10) == 1
    assert S.add_turn(sid, long, "", ok=False, problem="the model wrote nothing") == 2
    conv = S.conversation(sid)
    assert [t["n"] for t in conv] == [1, 2] and conv[0]["asked"] == "first question" and conv[0]["answered"] == '{"a": 1}' and conv[0]["ok"]
    assert conv[1]["ok"] is False and conv[1]["problem"] == "the model wrote nothing"
    assert conv[1]["asked"].startswith("é" * 100) and "more characters not kept" in conv[1]["asked"] and conv[1]["asked_chars"] < 500000
    assert S.conversation(sid, max_chars=5)[0]["asked"] == "first" and S.conversation(sid, max_chars=5)[0]["asked_cut"] is True
    assert S.get(sid)["turns"] == 2 and S.get(sid)["size_tokens"] == 10
    # opened again (a server started again): everything is there
    S2 = Sessions(str(tmp_path / "s.sqlite"))
    assert S2.open_for("run:7", "manager", "opencode", "p/m")["terminal_id"] == "ses_abc" and len(S2.conversation(sid)) == 2
    assert S2.counts() == {"sessions": 1, "turns": 2, "open": 1}
    S2.close(sid, "full")
    assert S2.open_for("run:7", "manager", "opencode", "p/m") is None and S2.get(sid)["why_closed"] == "full"
    assert S2.delete_scope("run:7") == ["ses_abc"] and S2.listing() == [] and S2.conversation(sid) == []


# ------------------------------------------------------------------------------------------- the runner
def test_an_agent_holds_one_session_and_its_next_question_continues_it(box):
    r = runner(box)
    a1, who1, _ = ask(r)
    a2, who2, _ = ask(r, text="HOW MANY TURNS now")
    assert a1["turns_before"] == 0 and a2["turns_before"] == 1          # the program had the first turn when the second came
    c = calls(box)
    assert "--title" in c[0]["args"] and c[0]["args"][c[0]["args"].index("--title") + 1] == "run 1 grounder"
    assert "-s" in c[1]["args"] and "--title" not in c[1]["args"]
    assert c[0]["args"][:4] == ["run", "--pure", "--agent", "f2t"] and c[0]["cwd"] == os.path.join(str(box / "sandbox"), "run_1", "grounder")
    assert "turn 1" in who1 and "turn 2" in who2 and "opencode in a terminal" in who1 and "Beta Paid" in who1 and 'session "run 1 · grounder"' in who2
    rows = r.sessions.listing("run:1")
    assert len(rows) == 1 and rows[0]["turns"] == 2 and rows[0]["state"] == "open" and rows[0]["terminal_id"].startswith("ses_fake")
    conv = r.sessions.conversation(rows[0]["id"])
    assert conv[0]["asked"].startswith("HOW MANY TURNS\n\nANSWER: one JSON object only") and json.loads(conv[1]["answered"])["turns_before"] == 1
    # another agent, and another run, have sessions of their own
    assert ask(r, agent="manager")[0]["turns_before"] == 0 and ask(r, run=2)[0]["turns_before"] == 0
    assert len(r.sessions.listing()) == 3


def test_a_server_started_again_continues_the_held_session(box):
    assert ask(runner(box))[0]["turns_before"] == 0
    again = runner(box)                                 # a new runner over the same file, as after a restart
    assert ask(again)[0]["turns_before"] == 1
    assert len(again.sessions.listing("run:1")) == 1 and again.sessions.listing("run:1")[0]["turns"] == 2


def test_another_model_starts_a_new_session_and_the_earlier_one_is_kept_to_read(box):
    r = runner(box)
    ask(r)
    r.opencode_model = "other/gamma"
    assert ask(r)[0]["turns_before"] == 0
    rows = r.sessions.listing("run:1")
    assert [(x["model"], x["state"], x["part"]) for x in rows] == [("fake/beta-paid", "closed", 1), ("other/gamma", "open", 2)]
    assert "another model" in rows[0]["why_closed"] and len(r.sessions.conversation(rows[0]["id"])) == 1
    assert rows[1]["name"] == "run 1 · grounder · part 2"


def test_a_full_session_goes_on_as_its_next_part(box):
    r = runner(box, model="fake/alpha-free")            # reads 2,000 tokens: a session is continued up to 95 % of that, 1,900
    big = "HOW MANY TURNS " + "x" * 700                 # about 400 tokens a question, by the 2-characters rule
    seen = [ask(r, text=big)[0]["turns_before"] for _ in range(7)]
    rows = r.sessions.listing("run:1")
    assert seen[0] == 0 and seen[1] == 1 and 0 in seen[2:], seen
    assert len(rows) >= 2 and rows[0]["state"] == "closed" and rows[0]["why_closed"].startswith("full:") and "95% of that" in rows[0]["why_closed"]
    assert rows[-1]["state"] == "open" and rows[-1]["part"] == len(rows)
    assert sum(len(r.sessions.conversation(x["id"])) for x in rows) == 7       # no turn is lost from the record


def test_a_session_the_program_lost_is_replaced_once_and_the_question_is_still_answered(box):
    r = runner(box)
    ask(r)
    os.remove(str(box / "fake_home" / "state.json"))    # opencode's own store was cleared
    a, who, _ = ask(r)
    assert a["turns_before"] == 0 and "turn 1" in who
    rows = r.sessions.listing("run:1")
    assert [x["state"] for x in rows] == ["closed", "open"] and "a turn failed in it (Session not found" in rows[0]["why_closed"]
    failed = r.sessions.conversation(rows[0]["id"])[-1]
    assert failed["ok"] is False and failed["problem"].startswith("Session not found") and failed["asked"].startswith("HOW MANY TURNS")


def test_too_many_calls_is_waited_for_and_asked_again(box):
    r = runner(box)
    (box / "fake_home" / "fail.json").write_text(json.dumps({"times": 2, "message": "Rate limit exceeded (429)"}))
    before = r.slots.refused
    a, who, _ = ask(r)
    assert a["ok"] is True and "stand-in" not in who
    assert r.slots.refused == before + 2 and len(calls(box)) == 3
    conv = [t for x in r.sessions.listing("run:1") for t in r.sessions.conversation(x["id"])]
    assert [t["ok"] for t in conv] == [False, False, True] and "Rate limit" in conv[0]["problem"]


def test_a_failing_terminal_ends_in_the_stand_in_never_in_the_model_connection(box, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test-not-a-key")
    r = runner(box)
    (box / "fake_home" / "fail.json").write_text(json.dumps({"times": 9, "message": "Unexpected server error."}))
    a, who, _ = ask(r)
    assert a == {"ok": "stand-in"} and who.startswith("stand-in (no model) (after: opencode failed: Unexpected server error.")
    assert core.AgentRunner.ORDER["opencode"] == ["opencode", "standin"]
    # nothing written comes back as a failure too
    r2 = runner(box)
    (box / "fake_home" / "fail.json").write_text(json.dumps({"times": 0}))
    a, who, _ = ask(r2, run=5, text="WRITE NOTHING")
    assert a == {"ok": "stand-in"} and "the model wrote nothing" in who
    assert len([c for c in calls(box) if "WRITE NOTHING" in c["asked"]]) == r2.TERMINAL_TRIES


def test_a_model_the_program_does_not_offer_is_said_before_anything_is_started(box):
    r = runner(box, model="fake/no-such-model")
    a, who, _ = ask(r)
    assert a == {"ok": "stand-in"} and "opencode does not offer the model fake/no-such-model" in who and "choose another in Settings" in who
    assert calls(box) == []
    r = runner(box, model=None)
    assert "no model is chosen for opencode" in ask(r)[1]
    r = core.AgentRunner(str(box / "sb"), runtime="opencode", opencode_path=str(box / "nothing_here"), opencode_model="fake/beta-paid")
    if oc.find(str(box / "nothing_here")) is None:      # only where no real opencode is installed
        assert "the opencode program was not found" in ask(r)[1]


def test_web_and_effort_reach_the_program_as_its_own_options(box):
    r = runner(box, model="fake/alpha-free", web=True)
    ask(r, web=True, effort="xhigh")
    ask(r, agent="coder", http_effort="high")
    ask(r, agent="plain")
    c = calls(box)
    def after(args, name):
        return args[args.index(name) + 1]
    assert after(c[0]["args"], "--agent") == "f2t-web" and after(c[0]["args"], "--variant") == "max"
    assert after(c[1]["args"], "--agent") == "f2t" and after(c[1]["args"], "--variant") == "high"
    assert "--variant" not in c[2]["args"]
    cfg = json.loads(c[0]["config"])
    assert cfg["agent"]["f2t"]["permission"]["*"] == "deny" and "OPENCODE_DISABLE_CLAUDE_CODE" in c[0]["switches"]
    assert "THE WEB: you may also search the web" in c[0]["asked"] and r.can_search_web()


def test_the_same_agent_asked_from_many_threads_keeps_one_ordered_conversation(box):
    r = runner(box)
    out, errs = [], []

    def one():
        try:
            out.append(ask(r)[0]["turns_before"])
        except Exception as e:      # noqa: BLE001
            errs.append(e)
    ts = [threading.Thread(target=one) for _ in range(6)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    assert not errs and sorted(out) == [0, 1, 2, 3, 4, 5]
    rows = r.sessions.listing("run:1")
    assert len(rows) == 1 and rows[0]["turns"] == 6 and [t["n"] for t in r.sessions.conversation(rows[0]["id"])] == [1, 2, 3, 4, 5, 6]


def test_stop_ends_the_terminal_call_and_the_run_asks_nothing_more(box, monkeypatch):
    monkeypatch.setenv("FAKE_OPENCODE_SLEEP", "20")
    r = runner(box)
    got = {}

    def one():
        try:
            ask(r, run=9)
        except Exception as e:      # noqa: BLE001
            got["e"] = str(e)
    t = threading.Thread(target=one)
    t.start()
    for _ in range(100):
        if r.procs.get(9):
            break
        time.sleep(0.05)
    t0 = time.time()
    r.cancel(9)
    t.join(15)
    assert not t.is_alive() and time.time() - t0 < 10 and got.get("e") == "the run was stopped"
    with pytest.raises(RuntimeError, match="the run was stopped"):
        ask(r, run=9)


def test_how_many_calls_at_once_counts_opencode_as_a_program_per_call(box):
    r = runner(box)
    n, why = r.calls_auto()
    assert r.path_now() == "opencode" and 2 <= n <= 16 and "opencode call" in why


def test_a_refusal_the_program_only_logs_ends_the_call_at_once_with_the_services_own_words(box):
    r = runner(box)
    assert ask(r, text="HOW MANY TURNS first")[0]["turns_before"] == 0
    (box / "fake_home" / "fail.json").write_text(json.dumps({
        "times": 1, "silent": True, "message": "Free usage limit reached. Free models work in OpenCode (https://opencode.ai)"}))
    t0 = time.time()
    a, who, _ = ask(r, text="HOW MANY TURNS second")
    assert time.time() - t0 < 20, "the call waited for the silent program"
    assert a["turns_before"] == 0 and "stand-in" not in who and 'part 2", turn 1' in who     # answered by a new session
    rows = r.sessions.listing("run:1")
    assert [x["state"] for x in rows] == ["closed", "open"] and "Free usage limit reached" in rows[0]["why_closed"]
    refused = r.sessions.conversation(rows[0]["id"])[-1]
    assert refused["ok"] is False and refused["problem"].startswith("the model's service refused the call: Free usage limit reached.")
    assert r.slots.refused >= 1
    # the new session was given the earlier turn from the application's own record, and that is what was written down
    sent = r.sessions.conversation(rows[1]["id"])[0]["asked"]
    assert sent.startswith("EARLIER IN THIS CONVERSATION (kept by the application")
    assert "ASKED (shortened): HOW MANY TURNS first" in sent and '"turns_before": 0' in sent and "THE QUESTION NOW:\nHOW MANY TURNS second" in sent
    assert "CONTEXT:\nctx" in sent.split("THE QUESTION NOW:")[1] and "CONTEXT" not in sent.split("THE QUESTION NOW:")[0]


def test_a_limit_that_stays_is_said_as_it_is(box):
    r = runner(box)
    (box / "fake_home" / "fail.json").write_text(json.dumps({"times": 9, "silent": True, "message": "Free usage limit reached. Subscribe to keep going"}))
    t0 = time.time()
    a, who, _ = ask(r)
    assert a == {"ok": "stand-in"} and "the model's service refused the call: Free usage limit reached. Subscribe to keep going" in who
    assert time.time() - t0 < 30 and len(calls(box)) == r.TERMINAL_TRIES
    assert all(x["state"] == "closed" for x in r.sessions.listing("run:1"))


def test_the_programs_folder_is_the_agents_own_folder(box, monkeypatch):
    monkeypatch.setenv("PWD", "/somewhere/else")
    r = runner(box)
    seen = {}
    real = r._run_watched

    def spy(cmd, prompt, cwd, timeout, env, refused, on_line=None):
        seen.update(cwd=cwd, pwd=env.get("PWD"), cmd=cmd)
        return real(cmd, prompt, cwd, timeout, env, refused, on_line)
    r._run_watched = spy
    ask(r)
    assert seen["pwd"] == seen["cwd"] == os.path.join(str(box / "sandbox"), "run_1", "grounder")
    assert seen["cmd"][-3:] == ["--print-logs", "--log-level", "ERROR"]


def test_the_services_words_are_read_from_the_log():
    line = ('timestamp=2026-11-13T06:17:10.556Z level=ERROR run=9273145b message="stream error" providerID=opencode modelID=deepseek-v4.1-flash-free '
            'session.id=ses_x small=false agent=f2t mode=primary error.error="AI_APICallError: Free usage limit reached. Free models work in '
            'OpenCode (https://opencode.ai); subscribe to OpenCode Go to keep going: https://opencode.ai/go"')
    assert oc.service_refused(line) is True
    assert oc.service_said(line + "\n").startswith("Free usage limit reached. Free models work in OpenCode")
    assert oc.service_refused('level=INFO message="rate limit table loaded"') is False
    assert oc.service_refused('level=ERROR message="stream error" error.error="AI_APICallError: Internal server error"') is False
    assert oc.service_said("") == "" and oc.service_said('level=ERROR message="could not open the store"') == "could not open the store"


def test_a_new_run_never_inherits_the_sessions_of_an_earlier_run_of_its_number(box):
    import types
    r = runner(box)
    store = core.Store(str(box / "agentic.sqlite"))
    eng = core.Engine(store, {"k": types.SimpleNamespace(steps=lambda params, project: [])}, r)
    pid = store.exec("INSERT INTO project (name, admin, created) VALUES (?,?,?)", ("p", "a", "t"))
    first = eng.start(pid, "k")
    assert ask(r, run=first)[0]["turns_before"] == 0 and len(r.sessions.listing("run:%s" % first)) == 1
    store.exec("DELETE FROM run WHERE id=?", (first,))          # deleted without its sessions (an older version, a crash)
    second = eng.start(pid, "k")
    assert second == first, "the database gave the number again"
    assert r.sessions.listing("run:%s" % second) == [] and r.sessions.recent_turns("run:%s" % second, "grounder") == []
    assert ask(r, run=second)[0]["turns_before"] == 0


def test_a_turn_that_did_not_reach_the_service_is_asked_again_in_the_same_session(box):
    r = runner(box)
    assert ask(r)[0]["turns_before"] == 0
    (box / "fake_home" / "fail.json").write_text(json.dumps({"times": 2, "message": "getaddrinfo EAI_AGAIN opencode.ai"}))
    before = r.slots.refused
    a, who, _ = ask(r)
    assert a["turns_before"] == 1 and "stand-in" not in who         # the held session answered, with its earlier turn
    rows = r.sessions.listing("run:1")
    assert len(rows) == 1 and rows[0]["state"] == "open" and r.slots.refused == before
    assert [t["ok"] for t in r.sessions.conversation(rows[0]["id"])] == [True, False, False, True]
    assert oc.network_trouble("getaddrinfo EAI_AGAIN opencode.ai") and not oc.network_trouble("Session not found: ses_1")
    # the network stays away: said as it is, and the session is kept for later
    (box / "fake_home" / "fail.json").write_text(json.dumps({"times": 9, "message": "getaddrinfo EAI_AGAIN opencode.ai"}))
    a, who, _ = ask(r)
    assert a == {"ok": "stand-in"} and "getaddrinfo EAI_AGAIN" in who and r.sessions.listing("run:1")[0]["state"] == "open"


def test_the_investigation_agent_reads_one_data_folder_runs_python_only_and_reports_what_it_does(box):
    cfg = json.loads(oc.config_content(read_dirs=["/data/analysis one"]))
    inv = cfg["agent"][oc.AGENT_INVESTIGATE]["permission"]
    assert list(inv)[0] == "*" and inv["*"] == "deny" and inv["edit"] == "allow"
    assert list(inv["bash"])[0] == "*" and inv["bash"]["*"] == "deny" and inv["bash"]["python3 *"] == "allow" and "rm *" not in inv["bash"] and "curl *" not in inv["bash"]
    assert list(inv["external_directory"])[0] == "*" and inv["external_directory"]["*"] == "deny"
    assert inv["external_directory"]["/data/analysis one"] == "allow" and inv["external_directory"]["/data/analysis one/*"] == "allow"
    assert "webfetch" not in inv and "websearch" not in inv
    assert json.loads(oc.config_content())["agent"][oc.AGENT_INVESTIGATE]["permission"]["external_directory"] == {"*": "deny"}
    assert json.loads(oc.config_content(read_dirs=["/data"]))["agent"][oc.AGENT]["permission"]["external_directory"] == "deny"    # the other agents gain nothing
    # the event lines become words for the page
    say = oc.event_words
    assert say('{"type":"tool_use","part":{"tool":"read","state":{"status":"completed","input":{"filePath":"/d/link.csv"}}}}') == "reading link.csv"
    assert say('{"type":"tool_use","part":{"tool":"bash","state":{"status":"completed","input":{"command":"python3  count.py"}}}}') == "running: python3 count.py"
    assert say('{"type":"tool_use","part":{"tool":"bash","state":{"status":"error","error":"The user has specified a rule","input":{"command":"id -u"}}}}').startswith("running: id -u (refused or failed:")
    assert say(json.dumps({"type": "text", "part": {"text": "I will count\n the rows."}})) == "the agent: I will count the rows."
    assert say("not json") == "" and say('{"type":"step_start"}') == ""
    # a turn with the agent's own name, its folder access and live lines
    r = runner(box)
    lines = []
    out = r.terminal_turn("WRITE A REPORT", str(box), "analysis:5", "investigation", "analysis 5 · investigation", want_json=False,
                          oc_agent=oc.AGENT_INVESTIGATE, read_dirs=[str(box / "data")], on_line=lines.append)
    c = calls(box)[-1]
    assert c["args"][c["args"].index("--agent") + 1] == oc.AGENT_INVESTIGATE and out["text"] == '{"ok": true}' and out["answer"] is None
    assert json.loads(c["config"])["agent"][oc.AGENT_INVESTIGATE]["permission"]["external_directory"][str(box / "data") + "/*"] == "allow"
    assert any('"type": "text"' in x or '"type":"text"' in x for x in lines)
