#!/usr/bin/env python3
"""Deep attacks: real flows driven by a random admin, and exact checks of the arithmetic (owner, 2026-11-09: "try to break the application by every chance").

    python3 tests/fuzz_deep.py [iterations] [first seed]       default 100 from seed 9000; FUZZ_ONLY=flow|store|parse|script|signature|usual picks one class

  flow       a real flow on a throw-away root (agents answered by the program's stand-in), decided by a random admin: approve, change, reject, stop, double presses,
             a second flow while one runs, a rule deleted under the run. No server error, no stuck step, no inconsistent state, and every failed step is explained.
  store      a random history on the graph against an independent model of its rules: every weight, every count, every choice must be exactly as defined
  parse      hostile text through every parser of the recordings: never an exception, and time stamps must survive a round trip
  script     generated test files from incomplete and odd steps: must compile and skip cleanly
  signature  the key of a failure ignores what must not matter and changes with what must
  usual      the "slower than usual" rule: scale, order, ties, outliers, extreme values
"""
import itertools
import json
import math
import os
import random
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import fuzz_app as F  # noqa: E402  (sets up the import paths)
from nvme_hier import names as N, parse as P, rules as RL, signature as SG, store as ST, testcase as TC  # noqa: E402

ONLY = os.environ.get("FUZZ_ONLY")


# ------------------------------------------------------------------------------------------------ flows with a random admin
def edits_for(key, d, r):
    if key in ("coder", "last_strategy") and d.get("joins"):
        need = list((d.get("needs_check") or {}).keys())
        return {"verified": need if r.random() < 0.85 else r.sample(need, r.randint(0, len(need))), "accept_reason": "accepted by the test" if d.get("must_explain") else ""}
    if key == "independent":
        return {"accept_reason": "accepted by the test"} if d.get("must_explain") and r.random() < 0.8 else None
    if key == "f3_plan":
        items = [i["key"] for i in d.get("items") or []]
        return {"selected": r.sample(items, r.randint(1, min(4, len(items))))} if items else None
    if key.endswith(":result") and key.startswith("f3:errors/"):
        head = d.get("head") or []
        return {"defect": r.choice(head)[0]} if head else None
    if key.endswith(":isolate") and d.get("isolation"):
        # stage 1 (2026-11-11): the isolation is confirmed and the defect named: an existing one, or a new name
        known = d.get("known_defects") or []
        if known and r.random() < 0.5:
            return {"defect_name": r.choice(known)["id"]}
        return {"defect_name": "new", "name": d.get("proposed_name") or "a defect named by the test"}
    if key.endswith(":cause"):
        causes = (d.get("graph") or {}).get("causes") or []
        if causes and r.random() < 0.6:
            return {"cause": r.choice(causes)["id"]}
        return {"cause": "new", "side": r.choice(["host", "device", "interrupt", "link"]),
                "header": (d.get("proposed_cause") or {}).get("header") or "the drive answered late"}
    if key.endswith(":solution"):
        sols = d.get("solutions") or []
        if d.get("first") or not sols:
            return {"solution": "new", "optimized": "\n".join(d.get("optimized") or []) or "raise the host's I/O timeout above the drive's slowest read"}
        x = r.choice(sols)
        kind = r.choice(["correct", "correct", "correct_with_edits", "wrong_with_edits"])
        e = {"solution": x["id"], "signal": kind}
        if kind.endswith("_with_edits"):
            other = [s_["step"] for s_ in x["error_seq"] if s_.get("position") != "fault"]
            e["drop"] = r.sample(other, r.randint(0, len(other))) if other else []
            e["optimized"] = "\n".join((x.get("optimized") or []) + ["(edited by the test)"])
        return e
    if key.endswith(":isolate"):
        seq = d.get("sequence") or []
        other = [s["step"] for s in seq if s.get("position") != "fault"]
        kind = r.choice(["correct", "correct", "correct_with_edits", "wrong_with_edits"])
        if "edits" in kind and other:
            return {"signal": kind, "drop": r.sample(other, r.randint(1, len(other)))}
        return {"signal": "correct"}
    if key.endswith(":code") and d.get("f4_open"):
        # Family 4 · Coding research (2026-11-14): each requirement the program could not show to hold is decided before approval
        return {"req_decisions": {x["id"]: "accept" for x in d["f4_open"]}}
    return None


def attack_flow(x, seed, r):
    bad = []
    c = x.app.test_client()

    def call(method, url, **kw):
        F.LAST_ERROR[0] = None
        resp = c.open(url, method=method, **kw)
        if resp.status_code >= 500:
            bad.append("%s %s -> %d %s" % (method, url, resp.status_code, F.LAST_ERROR[0]))
        return resp
    p = call("POST", "/api/agents/projects", json={"admin": "fuzz", "name": "flow %d" % seed, "folder": F.BASE}).get_json() or {}
    if not p.get("id"):
        return bad + ["no project: %s" % p]
    resp = call("POST", "/api/agents/projects/%d/flow" % p["id"], json={"admin": "fuzz"})
    rid = (resp.get_json() or {}).get("run")
    if not rid:
        return bad + ["no run: %s" % resp.get_data()[:160]]
    t0 = time.time()
    seen, retries = {}, 0
    budget = 160
    while time.time() - t0 < budget:
        v = call("GET", "/api/agents/runs/%d" % rid).get_json() or {}
        run = v.get("run") or {}
        if run.get("state") != "running":
            break
        failed = [s for s in v["steps"] if s["state"] == "failed"]
        if failed:
            why = (failed[0].get("error") or "")[:240].replace("\n", " ")
            bad.append("step failed: %s: %s" % (failed[0]["key"], why))
            if retries >= 1 or r.random() < 0.5:
                call("POST", "/api/agents/runs/%d/stop" % rid, json={"admin": "fuzz"})
            else:
                retries += 1
                call("POST", "/api/agents/runs/%d/retry" % rid, json={"admin": "fuzz"})
            time.sleep(0.5)
            continue
        rv = next((q for q in v["reviews"] if q["state"] == "open"), None)
        if rv is None:
            time.sleep(0.4)
            continue
        st = next(s for s in v["steps"] if s["id"] == rv["step"])
        n = seen.get(st["key"], 0)
        seen[st["key"]] = n + 1
        d = rv.get("data") or {}
        roll = r.random()
        url = "/api/agents/reviews/%d/decide" % rv["id"]
        if roll < 0.04:
            call("POST", url, json={"decision": "reject", "admin": "fuzz", "comment": "no"})
        elif roll < 0.08:
            call("POST", "/api/agents/runs/%d/stop" % rid, json={"admin": "fuzz"})
        elif roll < 0.14:
            again = call("POST", "/api/agents/projects/%d/flow" % p["id"], json={"admin": "fuzz"})
            if again.status_code != 409:
                bad.append("a second flow on a running project answered %d" % again.status_code)
            continue
        elif roll < 0.18 and st["key"].startswith("f3:"):
            sec, lvl, rid_item = st["key"].split(":")[1].split("#")[0].split("/")
            call("DELETE", "/api/agents/rules/%s/%s/%s" % (sec, lvl, rid_item), json={"admin": "fuzz"})
            continue
        elif roll < 0.30 and n < 2:
            edits = {"signal": "wrong"} if st["key"].endswith(":isolate") else None
            call("POST", url, json={"decision": "change", "admin": "fuzz", "comment": "again, please", "edits": edits})
        else:
            first = call("POST", url, json={"decision": "approve", "admin": "fuzz", "comment": r.choice(["", "looks right", "测试 <b>"]), "edits": edits_for(st["key"], d, r)})
            if first.status_code == 400:           # the application refused this approval: the admin asks for a change, as on the page
                call("POST", url, json={"decision": "change", "admin": "fuzz", "comment": "fix it"})
            elif r.random() < 0.2:
                twice = call("POST", url, json={"decision": "approve", "admin": "fuzz"})
                if twice.status_code == 200:
                    bad.append("a second press on the same review counted")
    else:
        call("POST", "/api/agents/runs/%d/stop" % rid, json={"admin": "fuzz"})
        cur = next((s for s in (call("GET", "/api/agents/runs/%d" % rid).get_json() or {}).get("steps", []) if s["state"] == "running"), None)
        if cur:
            bad.append("no end in %d s; running: %s: %s" % (budget, cur["key"], (cur.get("note") or "")[:100]))
    time.sleep(0.6)
    v = call("GET", "/api/agents/runs/%d" % rid).get_json() or {}
    if (v.get("run") or {}).get("state") != "running":
        stuck = [s["key"] for s in v["steps"] if s["state"] == "running"]
        for _ in range(40):
            if not stuck:
                break
            time.sleep(0.5)
            v = call("GET", "/api/agents/runs/%d" % rid).get_json() or {}
            stuck = [s["key"] for s in v["steps"] if s["state"] == "running"]
        if stuck:
            bad.append("the run ended with steps still running: %s" % stuck[:3])
        if [q["id"] for q in v["reviews"] if q["state"] == "open"]:
            bad.append("the run ended with reviews still open")
        if [q["id"] for q in v["reviews"] if q["state"] == "deciding"]:
            bad.append("a review was left half decided")
    return bad


# ------------------------------------------------------------------------------------------------ the graph against an independent model
class Model:
    """The rules of the graph, written from their definition, separately from the store."""

    def __init__(self):
        self.p, self.signals = {}, []

    def active(self):
        return [k for k, v in self.p.items() if v["status"] == "active"]

    def add(self, pid, a=2.0, b=1.0, supersedes=None):
        self.p[pid] = {"a": a, "b": b, "status": "active", "pos": 0, "neg": 0, "supersedes": supersedes}

    def signal(self, kind, pid, new):
        if pid is None:
            if new is not None and kind.startswith("correct"):      # stored with the judgement counted: Beta(1, 1) + one correct
                self.add(new)
                self.p[new]["pos"] += 1
            elif new is not None:                                   # the admin's steps after Wrong: the neutral start, not yet judged
                self.add(new, 1.0, 1.0)
            self.signals.append(kind)
            return
        for k in self.active():
            v = self.p[k]
            v["a"], v["b"] = 1 + (v["a"] - 1) * 0.98, 1 + (v["b"] - 1) * 0.98
        v = self.p[pid]
        good = kind.startswith("correct")
        if good:
            v["a"] += 1
            v["pos"] += 1
        else:
            v["b"] += 1
            v["neg"] += 1
        if kind == "correct_with_edits":
            v["status"] = "superseded"
            self.add(new, 1 + 0.7 * (v["a"] - 1), 1 + 0.7 * (v["b"] - 1), pid)
            self.p[new]["pos"] += 1
        elif kind == "wrong_with_edits":
            v["status"] = "superseded"
            self.add(new, 1.0, 1.0, pid)
        if v["a"] + v["b"] > 50:
            k_ = 50 / (v["a"] + v["b"])
            v["a"], v["b"] = v["a"] * k_, v["b"] * k_
        self.signals.append(kind)


def attack_store(x, seed, r):
    st = ST.Store(os.path.join(x.root, "m%d" % seed, "db", "k.sqlite"))
    s = {"fine": "f", "coarse": "c", "display": "d", "fields": {"lvl": "cmd", "err": "e", "cmd": "io.Write", "cause": "self", "alg": "v1"}}
    st.touch_signature(s, "D", upload_id="u", finding_id=1)
    m = Model()
    bad = []
    seq = lambda: [{"step": 1, "command": "c%d" % r.randrange(10 ** 9), "position": "fault"}]      # noqa: E731
    for i in range(r.randint(20, 90)):
        kind = r.choice(ST.SIGNALS)
        act = m.active()
        pid = r.choice(act) if act and r.random() < 0.8 else None
        if pid is None and kind == "correct_with_edits" and r.random() < 0.5:
            kind = "correct"
        res = st.signal("f", pid, kind, "x", proposal_steps=seq(), proposal_text="t", edited_steps=seq() if "edits" in kind else None, edited_text="e")
        m.signal(kind, pid, res.get("new_procedure_id"))
        if i % 7 == 0 or i < 3:
            v = st.graph_view("f")
            nodes = {n["id"]: n for n in v["nodes"]}
            edges = {e["id"]: e for e in v["edges"]}
            for k, w in m.p.items():
                n = nodes.get("proc::%d" % k)
                if n is None:
                    bad.append("procedure %d is missing from the graph" % k)
                    continue
                if abs(n["a"] - w["a"]) > 1e-6 or abs(n["b"] - w["b"]) > 1e-6:
                    bad.append("step %d: node %d is a=%.6f b=%.6f; the rules give a=%.6f b=%.6f" % (i, k, n["a"], n["b"], w["a"], w["b"]))
                ed = next(e for e in edges.values() if e["kind"] == "REPRODUCED_BY" and e["to"] == n["label"])
                ea, eb = 1.0 + w["pos"], 1.0 + w["neg"]
                if ea + eb > 50:
                    ea, eb = ea * 50 / (ea + eb), eb * 50 / (ea + eb)
                if abs(ed["a"] - ea) > 1e-6 or abs(ed["b"] - eb) > 1e-6:
                    bad.append("step %d: edge of %d is a=%.3f b=%.3f; the rules give a=%.3f b=%.3f" % (i, k, ed["a"], ed["b"], ea, eb))
            pos = sum(1 for g in m.signals if g.startswith("correct"))
            neg = sum(1 for g in m.signals if g == "wrong")
            ca, cb = 1.0 + pos, 1.0 + neg
            if ca + cb > 50:
                ca, cb = ca * 50 / (ca + cb), cb * 50 / (ca + cb)
            cau = next(e for e in edges.values() if e["kind"] == "CAUSED_BY")
            if abs(cau["a"] - ca) > 1e-6 or abs(cau["b"] - cb) > 1e-6:
                bad.append("step %d: the cause edge is a=%.3f b=%.3f; the rules give a=%.3f b=%.3f" % (i, cau["a"], cau["b"], ca, cb))
            paths = st.graph_paths("f")
            if sorted(p["procedure_id"] for p in paths) != sorted(m.active()):
                bad.append("step %d: the paths are not the active procedures" % i)
            total = sum(w["pos"] + w["neg"] for k, w in m.p.items() if k in m.active())
            for p in paths:
                w = m.p[p["procedure_id"]]
                ea, eb = 1.0 + w["pos"], 1.0 + w["neg"]
                expect = (ca / (ca + cb) * ea / (ea + eb) * w["a"] / (w["a"] + w["b"])) ** (1 / 3.0)
                if abs(p["weight"] - expect) > 1e-6:
                    bad.append("step %d: path weight %.6f; the rules give %.6f" % (i, p["weight"], expect))
            ch = st.graph_choice("f")
            usable = [p for p in paths if p["node_weight"] >= 0.5]
            if bool(ch) != bool(usable):
                bad.append("step %d: choice %s with %d usable procedures" % (i, bool(ch), len(usable)))
            if ch and ch["procedure_id"] != usable[0]["procedure_id"]:
                bad.append("step %d: the choice is not the first usable path" % i)
    shutil.rmtree(os.path.join(x.root, "m%d" % seed), ignore_errors=True)
    return sorted(set(bad))[:4]


# ------------------------------------------------------------------------------------------------ parsers
EVIL = F.EVIL_TEXT + F.EVIL_CELL + [None, 0, -1, 2 ** 70, 1.5, True, [], {}, b"\xff\xfe", "0000.", ".5s", "12:34", "1e999 us", "-0 ms", "9" * 400 + " ns"]


def attack_parse(x, seed, r):
    bad = []
    fns = [("time_stamp_ps", P.time_stamp_ps), ("delta_ps", P.delta_ps), ("int_value", P.int_value), ("address", P.address), ("data_bytes", P.data_bytes), ("direction", P.direction), ("text", P.text), ("fmt_ps", P.fmt_ps),
           ("data_is_expanded", P.data_is_expanded), ("tlp_class", N.tlp_class), ("part_key", N.part_key), ("cycle_step", RL.cycle_step), ("status_key", lambda v: SG.status_key(v, v)), ("cmd_key", lambda v: SG.cmd_key(v, 1)),
           ("opcode_name", lambda v: N.opcode_name(v, 1)), ("link_answer", lambda v: RL.link_answer(v, v))]
    only_text = {"time_stamp_ps", "delta_ps", "int_value", "address", "data_bytes", "direction", "text", "data_is_expanded", "cycle_step", "tlp_class", "part_key", "cmd_key", "link_answer"}      # these only ever receive text: a CSV cell or a text column
    only_numbers = {"fmt_ps", "status_key", "opcode_name"}             # these only ever receive a number read from the database
    for name, fn in fns:
        pool = [v for v in EVIL if name not in only_text or v is None or isinstance(v, str)]
        if name in only_numbers:
            pool = [None, 0, -1, 2 ** 70, 1, 10 ** 12, 255, 256]
        for v in r.sample(pool, min(len(pool), 18)):
            try:
                fn(v)
            except Exception as e:              # noqa: BLE001
                bad.append("%s(%r) raised %s: %s" % (name, v if not isinstance(v, str) else v[:30], type(e).__name__, str(e)[:60]))
    for _ in range(200):
        ps = r.randrange(0, 10 ** 16)
        text = "%04d.%012ds" % (ps // 10 ** 12, ps % 10 ** 12)
        if P.time_stamp_ps(text) != ps:
            bad.append("the time stamp %s reads as %s" % (text, P.time_stamp_ps(text)))
    return sorted(set(bad))[:8]


# ------------------------------------------------------------------------------------------------ the script generator on incomplete steps
def attack_script(x, seed, r):
    d = os.path.join(x.root, "g%d" % seed)
    os.makedirs(d)
    pick = lambda *a: r.choice(a)                       # noqa: E731
    steps = []
    n = r.randint(1, 6)
    fault = r.randint(1, n)
    for i in range(1, n + 1):
        s = {"step": i, "command": pick("Read", "Write", "Flush", "Write Zeroes", "Dataset Management", "Identify (admin)", "Abort (admin)", "opcode 0xC1", "Write Uncorrectable"), "position": "fault" if i == fault else pick("above", "below")}
        if r.random() < 0.8:
            s["parameters"] = pick({}, {"slba": 0, "nlb": 7}, {"slba": 2 ** 40, "nlb": 0}, {"ranges": [[0, 8]]}, {"nsid": 1})
        if r.random() < 0.8:
            s["gap_us"] = pick(0, 1, 10 ** 9)
        if r.random() < 0.5:
            s["admin"] = "admin" in s["command"]
        steps.append(s)
    rule = pick("cmd.timeout", "cmd.read_failure", "cmd.status_error", "cmd.incomplete", "lnk.replay", "spl.incomplete", "cmd.deallocate_readback", "cmd.bytes_short", "made.up")
    f = {"rule": rule, "level": pick("nvme_command", "link", None), "id": pick(1, None), "name": pick("x", None), "detail": pick({}, {"SCT": 2, "SC": 129}, {"SCT": None}), "limit_ps": pick(None, 0, 10 ** 12)}
    exp = pick(None, [], [{"step": fault}], [{"step": "x"}, {"step": fault, "timing_us": "soon", "status_code": ["a"]}], [{"step": fault, "status_code": [0, 0], "timing_us": 10}])
    out = pick(None, {}, {"observed": None, "expected": None}, {"observed": "o", "expected": {"status": None}})
    text = TC.generate(f, steps, pick({}, {"display": None}, {"display": "d"}), pick(None, "s"), pick("u", None), version=pick(1, None), device=pick(None, "D"), firmware=pick(None, "F"), nsid=pick(1, 2), name="t.py", outcome=out, limit_us=pick(None, 0, 100), expected_after=exp)
    p = os.path.join(d, "test_g.py")
    open(p, "w").write(text)
    bad = []
    try:
        compile(text, p, "exec")
    except SyntaxError as e:
        return ["the file does not compile: %s" % e]
    res = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", p], capture_output=True, text=True, cwd=d, timeout=60, env=dict(os.environ, NVME_DEV="/dev/nvme-absent"))
    if "skipped" not in res.stdout:
        bad.append("does not skip cleanly without a drive (exit %s): %s %s" % (res.returncode, res.stdout.strip()[-200:], res.stderr.strip()[-200:]))
    shutil.rmtree(d, ignore_errors=True)
    return bad


# ------------------------------------------------------------------------------------------------ the key of a failure
def attack_signature(x, seed, r):
    base = {"dev": "D1", "fw": "F1", "lvl": "nvme_command", "err": "cmd.timeout", "cmd": "io.Write", "part": "cqe", "cause": "self", "st": "sct0.sc00", "dnr": "0"}
    bad = []
    keys = list(base)
    r.shuffle(keys)
    a = SG.compute(base)
    if SG.compute({k: base[k] for k in keys})["fine"] != a["fine"]:
        bad.append("the order of the fields changed the key")
    if SG.compute(dict(base, dev="  d1 "))["fine"] != a["fine"]:
        bad.append("spelling of the device changed the key")
    for field, other in (("dev", "D2"), ("fw", "F2"), ("dnr", "1")):
        b = SG.compute(dict(base, **{field: other}))
        if b["fine"] == a["fine"] or b["coarse"] != a["coarse"]:
            bad.append("%s must change the exact key and not the family key" % field)
    for field, other in (("err", "cmd.read_failure"), ("cmd", "io.Read"), ("st", "sct2.sc81"), ("lvl", "link")):
        b = SG.compute(dict(base, **{field: other}))
        if b["fine"] == a["fine"] or b["coarse"] == a["coarse"]:
            bad.append("%s must change both keys" % field)
    for evil in F.EVIL_ANY:
        try:
            SG.compute(dict(base, cmd=evil if isinstance(evil, str) else "io.Write", dev=evil, part=evil if isinstance(evil, str) else "none", cause=evil))
        except Exception as e:         # noqa: BLE001
            bad.append("a hostile field raised %s: %s" % (type(e).__name__, str(e)[:80]))
    return sorted(set(bad))[:6]


# ------------------------------------------------------------------------------------------------ slower than usual
def attack_usual(x, seed, r):
    bad = []
    n = r.randint(20, 400)
    v = [int(r.lognormvariate(math.log(6e7), r.choice([0.05, 0.2, 0.4]))) for _ in range(n)]
    a = RL.usual_bar(v)
    if a is None:
        return ["no usual time for %d commands" % n]
    b = list(v)
    r.shuffle(b)
    if RL.usual_bar(b) != a:
        bad.append("the order of the commands changed the result")
    k = RL.usual_bar([t * 1000 for t in v])
    if abs(k["bar_ps"] - a["bar_ps"] * 1000) > 1000:
        bad.append("the unit changed the result: %s against %s" % (k["bar_ps"], a["bar_ps"] * 1000))
    out = RL.usual_bar(v + [int(max(v) * 1000)])
    if out["bar_ps"] >= int(max(v) * 1000) or out["bar_ps"] < a["bar_ps"] * 0.2:
        bad.append("one command 1,000 x slower was not set apart: limit %s, top %s" % (out["bar_ps"], max(v)))
    if RL.usual_bar(v[:19]) is not None:
        bad.append("a usual time was given for 19 commands")
    same = RL.usual_bar([7000] * n)
    if same["bar_ps"] != 21000:
        bad.append("identical times gave the limit %s" % same["bar_ps"])
    RL.usual_bar([0, -5, None] * 30 + v)
    RL.usual_bar([2 ** 62] * 30 + [1] * 30)
    two = [r.randint(10, 15) * 10 ** 6 for _ in range(n)] + [r.randint(80, 110) * 10 ** 6 for _ in range(n)]
    tw = RL.usual_bar(two)
    if sum(1 for t in two if t > tw["bar_ps"]):
        bad.append("two normal groups (fast and slow reads): %d healthy commands were called slow" % sum(1 for t in two if t > tw["bar_ps"]))
    return bad


def main():
    import signal
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 100
    first = int(sys.argv[2]) if len(sys.argv) > 2 else 9000
    signal.signal(signal.SIGALRM, F._alarm)

    class X:
        pass
    x = X()
    x.root = tempfile.mkdtemp(prefix="fuzz_app_deep_")
    from agentic import core
    kick = core.Engine.kick
    t0 = time.time()
    x.app, x.c, _k, _r = F.setup(x.root)
    core.Engine.kick = kick                 # real runs: the agents answer by the stand-in
    classes = ["flow"] * 6 + ["store"] * 6 + ["parse"] * 3 + ["script"] * 4 + ["signature"] * 2 + ["usual"] * 4
    fns = {"flow": attack_flow, "store": attack_store, "parse": attack_parse, "script": attack_script, "signature": attack_signature, "usual": attack_usual}
    seen, count, crashes = {}, {}, 0
    for seed in range(first, first + n):
        r = random.Random(seed)
        kind = ONLY or classes[(seed - first) % len(classes)]
        count[kind] = count.get(kind, 0) + 1
        try:
            bad = fns[kind](x, seed, r)
        except Exception as e:              # noqa: BLE001
            crashes += 1
            tb = traceback.extract_tb(e.__traceback__)
            f = next((y for y in reversed(tb) if APP in y.filename and "tests/" not in y.filename), tb[-1])
            bad = ["%s: %s at %s:%d" % (type(e).__name__, str(e)[:130], os.path.basename(f.filename), f.lineno)]
        for b in bad:
            key = __import__("re").sub(r"\d+", "#", b)[:130]
            if key not in seen:
                print("[%s seed %d] %s" % (kind, seed, b[:420]), flush=True)
            seen[key] = seen.get(key, 0) + 1
    keep = os.path.join(APP, "runs", "kpi_proof")
    os.makedirs(keep, exist_ok=True)
    json.dump({"iterations": n, "first_seed": first, "by_class": count, "distinct_problems": len(seen), "problems": sorted(seen.items(), key=lambda kv: -kv[1])[:60], "seconds": round(time.time() - t0)}, open(os.path.join(keep, "fuzz_deep_%d.json" % first), "w"), indent=1)
    shutil.rmtree(x.root, ignore_errors=True)
    print("\n%d iterations %s: %d distinct problems, %d crashes; %d s" % (n, count, len(seen), crashes, time.time() - t0), flush=True)
    return 1 if seen else 0


if __name__ == "__main__":
    sys.exit(main())
