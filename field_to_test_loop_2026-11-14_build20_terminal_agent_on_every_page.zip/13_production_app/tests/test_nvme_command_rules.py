"""The NVMe command rules page (owner, 2026-11-12): only the rules that find an error at the NVMe command level.

What must hold:
  1. every rule of the page is one of the detector's own rules, names only real columns of the export, and says where it
     rests on the NVMe specification, or says that the statement is not verified, never a section that was not read;
  2. the errors of a recording are the detector's, counted here a second time straight from the CSV file with other code;
  3. a recording loaded from the NVMe command file alone works (it failed before 2026-11-12): the rules that need the
     NVMe transactions say "cannot be checked on this recording" and why; nothing is skipped silently;
  4. a column that is not in the file makes its rules "cannot be checked ... column X is not in the NVMe command file";
  5. odd files do not break anything: an empty file, a header alone, cells that are not numbers, a number far too large,
     the other header layout of the real export;
  6. "check again" files the same errors under the same numbers, removes what does not belong, and the stores follow a
     number that moves; every error has its line in the file and opens on the one-error page.

No server and no model. Every recording is built in a temporary folder with the application's own loader and rules.
The check of the specification places runs when the text is on the computer (F2T_NVME_SPEC_TEXT, as for
tests/test_nvme_command_errors.py); the text is not shipped.

    python3 -m pytest -q -p no:cacheprovider tests/test_nvme_command_rules.py
"""
import csv
import json
import os
import re
import shutil
import sqlite3
import sys
import tempfile
import time
import types
from decimal import Decimal

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(HERE)
for p in (APP_DIR, os.path.join(APP_DIR, "app")):
    if p not in sys.path:
        sys.path.insert(0, p)
from nvme_hier import builder as B, columns as C, defect_graph as DG, loader as L, rules as RL   # noqa: E402
from nvme_hier import nvme_command_rules as NR   # noqa: E402

S17 = os.path.join(APP_DIR, "samples", "clean_five_files", "S17_io_timeout_abort_reset")
CMD_CSV, NTX_CSV = os.path.join(S17, "nvme_command.csv"), os.path.join(S17, "NVME_Transactions.csv")
SPEC_DIR = os.environ.get("F2T_NVME_SPEC_TEXT") or ""
SPEC_TXT = {NR.BASE["document"]: os.path.join(SPEC_DIR, "nvme_base_specification_2.1.txt"),
            NR.NVM["document"]: os.path.join(SPEC_DIR, "nvme_nvm_command_set_specification_1.1.txt")}
HOST_ABORT = {(0, 7), (0, 8), (3, 0x71)}
NOT_TIMED_ADMIN = {0x80, 0x84, 0x14, 0x10, 0x11, 0x0C}
ERR_CELL = re.compile(r"^\d+ error\(s\)$")


@pytest.fixture
def tmp():
    base = os.environ.get("F2T_TEST_TMP") or None
    if base:
        os.makedirs(base, exist_ok=True)
    d = tempfile.mkdtemp(prefix="nvme_rules_", dir=base)
    yield d
    shutil.rmtree(d, ignore_errors=True)


def recording(folder, files, uid="up-1"):
    """A recording loaded the way the application loads it: the files, the tree, the rules. -> its database."""
    d = os.path.join(folder, "uploads", uid)
    os.makedirs(d, exist_ok=True)
    db = os.path.join(d, "hier.sqlite")
    L.load_upload(db, files)
    B.build(db)
    RL.apply(db)
    with open(os.path.join(d, "meta.json"), "w", encoding="utf-8") as fh:
        json.dump({"upload_id": uid, "created": time.time(), "operator": "t", "device": "D", "trace_name": "test recording", "recording_date": "",
                   "notes": "", "files": files, "status": "loaded", "thresholds": {}}, fh)
    return db


def read_csv(path=CMD_CSV):
    with open(path, newline="", encoding="utf-8") as fh:
        rows = list(csv.reader(fh))
    return rows[0], rows[1:]


def write_csv(path, header, rows):
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        w.writerows(rows)
    return path


def num(cell):
    """A cell as a number, read here with other code than the loader: '0x0007 (…)' and '7' are 7; '' is None."""
    cell = (cell or "").strip()
    if not cell:
        return None
    first = cell.split()[0]
    return int(first, 16) if first.lower().startswith("0x") else int(first)


def by_hand(header, rows):
    """The errors of the command rows, counted without the application's parsers: {rule: set of file lines}."""
    i = {n: header.index(n) for n in ("OPC", "SQID", "ST.SCT", "ST.SC", "Time Stamp")}
    ps = lambda cell: int(Decimal(cell.rstrip("s")) * 10 ** 12)           # noqa: E731
    end = max(ps(r[i["Time Stamp"]]) for r in rows)
    err_col = min(k for r in rows for k, c in enumerate(r) if ERR_CELL.match(c))
    out = {"cmd.status_error": set(), "cmd.read_failure": set(), "cmd.timeout": set(), "cmd.analyzer_error": set(), "no status": set()}
    for n, r in enumerate(rows):
        line = n + 2                                                       # line 1 is the header
        opc, sqid, sct, sc = num(r[i["OPC"]]), num(r[i["SQID"]]), num(r[i["ST.SCT"]]), num(r[i["ST.SC"]])
        if sct or sc:
            out["cmd.status_error"].add(line)
            if opc == 2 and sqid != 0 and (sct or 0, sc or 0) not in HOST_ABORT:
                out["cmd.read_failure"].add(line)
        if ERR_CELL.match(r[err_col]):
            out["cmd.analyzer_error"].add(line)
        if sqid == 0 and opc in NOT_TIMED_ADMIN:
            continue
        if sct is None and sc is None:
            out["no status"].add(line)
            if end - ps(r[i["Time Stamp"]]) >= (60 if sqid == 0 else 30) * 10 ** 12:
                out["cmd.timeout"].add(line)
        elif (sct or 0, sc or 0) in HOST_ABORT:
            out["cmd.timeout"].add(line)
    return out


def lines_of(db, rule):
    got, offset = set(), 0
    while True:
        j = NR.errors(db, rule, offset=offset)
        got |= {e["line"] for e in j["errors"]}
        offset += len(j["errors"])
        if not j["has_more"]:
            return got


def rule_of(st, rid):
    return next(r for r in st["rules"] if r["id"] == rid)


# ---- 1. the rules themselves

def test_every_rule_is_the_detectors_and_names_only_real_columns():
    assert len(set(NR.RULE_IDS)) == len(NR.RULE_IDS) and all(r.startswith("cmd.") for r in NR.RULE_IDS)
    detector = {r for r in RL.BASIS if r.startswith("cmd.")}
    assert set(NR.RULE_IDS) == detector, "the page and the detector must hold the same command rules: %s" % (set(NR.RULE_IDS) ^ detector)
    names = {fk: set(C.canonical_names(fk)) for fk in ("nvme_command", "nvme_transaction", "packets")}
    groups = {g["id"] for g in NR.groups()}
    for r in NR.rules():
        assert r["group"] in groups and r["name"] and r["checks"] and r["how"] and r["found_as"] and r["reads"]
        assert r["columns"], r["id"]
        for c in r["columns"]:
            assert c["column"] in names[c["file"]], "%s names %s, which is not a column of %s" % (r["id"], c["column"], c["file"])
            assert c["use"] and c["file_words"]
        assert any(c["needed"] for c in r["columns"]), r["id"]
    assert {"cmd.timeout", "cmd.read_failure"} == {r["id"] for r in NR.rules() if r["kept_by_the_owner"]} == set(RL.COMMAND_RULES)


def test_no_place_is_named_without_having_been_read():
    for r in NR.RULES:
        assert r["basis"], r["id"]
        for b in r["basis"]:
            if b["verified"]:
                assert b["phrase"] and len(b["phrase"].split()) <= 30, (r["id"], b["place"])      # a few words, never a page of the document
                assert b["document"] in SPEC_TXT, "only the two NVMe specifications are checked against their text: %s" % b["document"]
            else:
                assert b["phrase"] is None
                assert not re.search(r"section \d|Figure \d", b["place"]), "an unverified statement must not name a section: %s" % b["place"]
    spec_rules = [r for r in NR.RULES if r["group"] == "specification"]
    assert spec_rules and all(any(b["verified"] for b in r["basis"]) for r in spec_rules)


@pytest.mark.skipif(not all(os.path.exists(p) for p in SPEC_TXT.values()),
                    reason="the text of the two NVMe specifications is not on this computer (set F2T_NVME_SPEC_TEXT to its folder)")
def test_every_place_is_in_the_specification_text():
    def norm(t):
        for a, b in (("’", "'"), ("‘", "'"), ("“", '"'), ("”", '"'), ("®", "")):
            t = t.replace(a, b)
        return re.sub(r"\s+", " ", t)
    text = {doc: norm(open(p, encoding="utf-8", errors="replace").read()) for doc, p in SPEC_TXT.items()}
    checked = 0
    for r in NR.RULES:
        for b in r["basis"]:
            if not b["verified"]:
                continue
            assert norm(b["phrase"]) in text[b["document"]], "%s: these words are not in %s: %s" % (r["id"], b["document"], b["phrase"])
            for sec in re.findall(r"section (\d+(?:\.\d+)+)", b["place"]):
                # the place itself: named in the document as a heading or by a cross-reference
                assert re.search(r"(section %s\b|(^| )%s [A-Z])" % (re.escape(sec), re.escape(sec)), text[b["document"]]), (r["id"], sec)
            for fig in re.findall(r"Figure (\d+)", b["place"]):
                assert "Figure %s:" % fig in text[b["document"]], (r["id"], fig)
            checked += 1
    assert checked >= 15


# ---- 2. the errors of a recording, counted twice

def test_the_sample_recording_from_the_command_file_alone(tmp):
    db = recording(tmp, {"nvme_command": CMD_CSV})
    header, rows = read_csv()
    truth = by_hand(header, rows)
    assert (len(truth["cmd.status_error"]), len(truth["cmd.analyzer_error"]), len(truth["cmd.timeout"]), len(truth["no status"])) == (1, 6, 7, 6)
    st = NR.status(db)
    assert st["command_file_loaded"] and st["commands"] == len(rows) == 608 and st["checked"] and not st["tree"]
    assert st["files_loaded"] == ["the NVMe command file"] and st["command_file"] == CMD_CSV
    for rid in ("cmd.status_error", "cmd.read_failure", "cmd.timeout", "cmd.analyzer_error"):
        r = rule_of(st, rid)
        assert r["can_be_checked"] and r["found"] == len(truth[rid]), (rid, r["found"], len(truth[rid]))
        assert lines_of(db, rid) == truth[rid], rid
        assert r["first_line"] == (min(truth[rid]) if truth[rid] else None)
    # the rules that read the command's NVMe transactions say so; none of them shows a count
    for rid in ("cmd.incomplete", "cmd.not_fetched", "cmd.doorbell_missing", "cmd.no_interrupt"):
        r = rule_of(st, rid)
        assert not r["can_be_checked"] and r["found"] is None, rid
        assert r["why_not"].startswith("cannot be checked on this recording: the NVMe transactions file is not loaded"), r["why_not"]
    assert st["rules_that_cannot_be_checked"] == 4
    # the timeout rule is checked, and says which of its four cases it could not judge
    lim = rule_of(st, "cmd.timeout")["limited"]
    assert "Without that file only Never completed and Aborted by the host are judged" in lim and "The NVMe transactions file is not loaded" in lim
    assert st["errors_found"] == sum(r["found"] or 0 for r in st["rules"]) == 14


def test_with_the_transactions_the_tree_rules_are_checked_too(tmp):
    db = recording(tmp, {"nvme_command": CMD_CSV, "nvme_transaction": NTX_CSV})
    header, rows = read_csv()
    truth = by_hand(header, rows)
    st = NR.status(db)
    assert st["tree"] and st["rules_that_cannot_be_checked"] == 0
    inc = rule_of(st, "cmd.incomplete")
    assert inc["can_be_checked"] and inc["found"] == len(truth["no status"]) == 6 and lines_of(db, "cmd.incomplete") == truth["no status"]
    assert rule_of(st, "cmd.timeout")["limited"] == "" and lines_of(db, "cmd.timeout") >= truth["cmd.timeout"]
    assert rule_of(st, "cmd.status_error")["found"] == 1 and lines_of(db, "cmd.status_error") == {145}
    # line 145 of the file is the Read the host aborted: command number 144, status 0x0007
    e = NR.errors(db, "cmd.status_error")["errors"][0]
    assert (e["line"], e["command_number"], e["command"], e["kind"]) == (145, 144, "Read", "error") and "Command Abort Requested" in e["what"]
    assert rows[e["line"] - 2][0] == "144" and "0x0007" in rows[e["line"] - 2][header.index("ST")]


# ---- 3. and 4. what cannot be checked is said, with the column

def test_a_column_that_is_not_in_the_file(tmp):
    header, rows = read_csv()
    k = header.index("ST.SC")
    path = write_csv(os.path.join(tmp, "nvme_command.csv"), header[:k] + header[k + 1:], [r[:k] + r[k + 1:] for r in rows])
    db = recording(tmp, {"nvme_command": path})
    st = NR.status(db)
    col = next(c for c in st["columns"] if c["column"] == "ST.SC")
    assert col["file_loaded"] and col["present"] is False
    assert next(c for c in st["columns"] if c["column"] == "ST.SCT")["present"] is True
    for rid in ("cmd.status_error", "cmd.read_failure", "cmd.timeout", "cmd.bytes_short", "cmd.write_zeroes_readback"):
        r = rule_of(st, rid)
        assert not r["can_be_checked"] and r["found"] is None and r["by_kind"] == {}, rid
        assert r["why_not"] == "cannot be checked on this recording: column ST.SC is not in the NVMe command file", r["why_not"]
    ok = rule_of(st, "cmd.analyzer_error")                      # a rule that does not read the status is still checked
    assert ok["can_be_checked"] and ok["found"] == 6


def test_a_column_that_is_not_required_does_not_stop_a_rule(tmp):
    header, rows = read_csv()
    k = header.index("NLB")
    path = write_csv(os.path.join(tmp, "nvme_command.csv"), header[:k] + header[k + 1:], [r[:k] + r[k + 1:] for r in rows])
    st = NR.status(recording(tmp, {"nvme_command": path}))
    t = rule_of(st, "cmd.timeout")
    assert t["can_be_checked"] and t["found"] == 7 and t["columns_not_in_the_file_but_not_needed"] == ["NLB"]
    assert not rule_of(st, "cmd.bytes_short")["can_be_checked"]         # NLB is what that rule compares


def test_a_recording_without_its_command_file(tmp):
    db = recording(tmp, {"nvme_transaction": NTX_CSV})
    st = NR.status(db)
    assert not st["command_file_loaded"] and st["commands"] in (0, None) and st["rules_that_cannot_be_checked"] == len(NR.RULES)
    assert all(r["why_not"].startswith("cannot be checked on this recording: the NVMe command file is not loaded") and r["found"] is None for r in st["rules"])
    with pytest.raises(RuntimeError, match="without its NVMe command file"):
        NR.check(db)


# ---- 5. odd files

def test_a_header_alone_and_an_empty_file(tmp):
    header, _rows = read_csv()
    db = recording(tmp, {"nvme_command": write_csv(os.path.join(tmp, "nvme_command.csv"), header, [])})
    st = NR.status(db)
    assert st["commands"] == 0 and st["errors_found"] == 0 and all(r["found"] in (0, None) for r in st["rules"])
    assert NR.errors(db, "cmd.timeout") == {"errors": [], "total": 0, "offset": 0, "has_more": False}
    assert NR.export_csv(db, os.path.join(tmp, "out.csv")) == 0
    empty = os.path.join(tmp, "empty.csv")
    open(empty, "w").close()
    st = NR.status(recording(tmp, {"nvme_command": empty}, uid="up-empty"))      # a file with nothing in it is not a loaded command file
    assert not st["command_file_loaded"] and st["errors_found"] == 0
    assert all(not r["can_be_checked"] and r["found"] is None and "the NVMe command file is not loaded" in r["why_not"] for r in st["rules"])


def test_cells_that_are_not_what_they_should_be(tmp):
    header, rows = read_csv()
    i = {n: header.index(n) for n in ("OPC", "SQID", "ST", "ST.SCT", "ST.SC", "NLB", "SLBA", "Time Stamp", "NVMe Cmd")}
    good = next(k for k, r in enumerate(rows) if num(r[i["OPC"]]) == 2 and num(r[i["SQID"]]) != 0 and num(r[i["ST.SC"]]) == 0)
    def change(k, **cells):
        r = list(rows[k])
        for name, v in cells.items():
            r[i[name.replace("_", " ").replace("ST SCT", "ST.SCT").replace("ST SC", "ST.SC")]] = v
        return r
    odd = [change(good, ST_SCT="abc", ST_SC="not a number"),                         # no status can be read
           change(good, ST_SCT="2", ST_SC="0x0081 (Unrecovered Read Error)", ST="0x0281 (Unrecovered Read Error)"),
           change(good, ST_SC="99999999999999999999999999999999"),                  # a number far too large for the database
           change(good, NLB="99999999999999999999999999999999", SLBA="-5"),
           change(good, Time_Stamp="yesterday"),
           change(good, NVMe_Cmd="٣", OPC="<script>alert(1)</script>")]
    path = write_csv(os.path.join(tmp, "nvme_command.csv"), header, rows + odd)
    db = recording(tmp, {"nvme_command": path})
    st = NR.status(db)
    json.dumps(st)                                                                   # everything the page gets can be sent
    assert st["commands"] == len(rows) + len(odd)
    line = len(rows) + 2 + 1                                                         # the second odd row: a Read with Unrecovered Read Error
    assert line in lines_of(db, "cmd.read_failure") and line in lines_of(db, "cmd.status_error")
    e = next(x for x in NR.errors(db, "cmd.read_failure")["errors"] if x["line"] == line)
    assert "Unrecovered Read Error" in e["what"]
    # the rows whose cells cannot be read are never counted as an error status
    assert lines_of(db, "cmd.status_error") == {145, line}
    out = os.path.join(tmp, "errors.csv")
    n = NR.export_csv(db, out)
    with open(out, newline="", encoding="utf-8") as fh:
        got = list(csv.reader(fh))
    assert got[0] == NR.EXPORT_COLUMNS and len(got) == n + 1 == st["errors_found"] + 1 and not os.path.exists(out + ".%d.part" % os.getpid())


def test_the_other_header_layout_of_the_real_export(tmp):
    """The customer's export writes the status columns bare after their group cell (ST, SCT, SC): the same rules, the same errors."""
    real = (C.real_headers().get("nvme_command") or [None])[0]
    if real is None:
        pytest.skip("no real header of the NVMe command file is stored")
    header, rows = read_csv()
    assert "SCT" in real["header"] and "ST.SCT" not in real["header"]
    src = L.align_header("nvme_command", header).positions
    dst = L.align_header("nvme_command", real["header"]).positions
    shared = [n for n in src if n in dst]
    assert {"ST.SCT", "ST.SC", "OPC", "SQID", "Time Stamp", "Errors"} <= set(shared)
    out_rows = []
    for r in rows:
        new = [""] * len(real["header"])
        for n in shared:
            new[dst[n]] = r[src[n]] if src[n] < len(r) else ""
        out_rows.append(new)
    db = recording(tmp, {"nvme_command": write_csv(os.path.join(tmp, "nvme_command.csv"), real["header"], out_rows)})
    st = NR.status(db)
    truth = by_hand(header, rows)
    assert all(c["present"] for c in st["columns"] if c["file"] == "nvme_command" and c["column"] in ("ST.SCT", "ST.SC", "OPC", "SQID", "Errors"))
    for rid in ("cmd.status_error", "cmd.timeout", "cmd.analyzer_error"):
        assert rule_of(st, rid)["can_be_checked"] and lines_of(db, rid) == truth[rid], rid


# ---- 6. check again; the numbers; the graph

def _findings(db):
    con = sqlite3.connect(db)
    try:
        return con.execute("SELECT id, rule, rowid, name, severity FROM finding ORDER BY id").fetchall()
    finally:
        con.close()


def test_check_again_files_the_same_errors_under_the_same_numbers(tmp):
    db = recording(tmp, {"nvme_command": CMD_CSV, "nvme_transaction": NTX_CSV})
    before = _findings(db)
    seen = []
    out = {}
    res = NR.check(db, progress=lambda step, detail="": seen.append((step, detail)), out=out)
    assert _findings(db) == before and out["renumbered"] == {}
    assert res["before"] == res["after"] and res["errors"] == sum(res["after"].values()) and seen
    st = NR.status(db)
    assert st["checked_again_at"] and st["errors_found"] == sum(1 for f in before if f[1] in NR.RULE_IDS)
    # something that does not belong (a stale error of a command rule) is gone after a check; other levels' errors stay
    con = sqlite3.connect(db)
    top = con.execute("SELECT MAX(id) FROM finding").fetchone()[0]
    con.execute("INSERT INTO finding (id, level, rule, name, severity, table_name, rowid, row_n, t_ps, cmd_rowid, part) VALUES (?, 'nvme_command', 'cmd.status_error', 'stale', 'error', 'cmd', 3, 3, 1, 3, 'cqe')", (top + 1,))
    con.commit()
    con.close()
    assert NR.status(db)["errors_found"] == st["errors_found"] + 1
    out = {}
    NR.check(db, out=out)
    after = _findings(db)
    assert [f[1:] for f in after] == [f[1:] for f in before] and not any(f[3] == "stale" for f in after)


def test_every_error_has_its_line_and_a_number_the_one_error_page_knows(tmp):
    db = recording(tmp, {"nvme_command": CMD_CSV})
    header, rows = read_csv()
    ids = {f[0] for f in _findings(db)}
    for rid in NR.RULE_IDS:
        for e in NR.errors(db, rid)["errors"]:
            assert e["finding"] in ids and e["line"] >= 2
            assert str(e["command_number"]) == rows[e["line"] - 2][header.index("NVMe Cmd")]
    with pytest.raises(ValueError):
        NR.errors(db, "pkt.bad_lcrc")
    assert NR.errors(db, "cmd.timeout", offset=10 ** 9)["errors"] == [] and NR.errors(db, "cmd.timeout", offset=-5, limit=10 ** 9)["total"] == 7


def test_what_the_procedural_graph_holds_for_each_rule_and_numbers_that_move(tmp):
    path = os.path.join(tmp, "hier_knowledge.sqlite")
    assert all(v["defects"] == 0 for v in NR.graph_memory(path).values())               # no store yet: no numbers, no failure
    g = DG.DefectGraph(path)
    did, _new = g.add_defect("Read timeout: the host gave up", "cmd.timeout", "nvme_command", "a Read was aborted by the host", "ada")
    cid, _new = g.add_cause(did, "device", "the drive stopped answering", "ada")
    occ = g.record_occurrence(did, cid, "up-1", 10, "D", "fw1", {}, "ada")
    sid, _rev = g.add_solution(cid, [{"command": "Write"}, {"command": "Read"}], ["send the Read again"], "a note", "admin", "ada", origin_upload="up-1", origin_finding=10)
    g.verdict(sid, "correct", "ada")
    g.verdict(sid, "wrong", "ada")
    m = NR.graph_memory(path)
    assert m["cmd.timeout"] == {"defects": 1, "causes": 1, "solutions": 1, "seen": 1, "judgements": 2, "by_signal": {"correct": 1, "wrong": 1}}
    assert m["cmd.read_failure"]["defects"] == 0
    # two errors swap their numbers: what is stored for them follows, and nothing collides
    g.record_occurrence(did, cid, "up-1", 11, "D", "fw1", {}, "ada")
    assert g.remap_findings("up-1", {10: 11, 11: 10}) >= 2 and g.remap_findings("up-1", {}) == 0
    con = sqlite3.connect(path)
    assert sorted(r[0] for r in con.execute("SELECT finding_id FROM dg_occurrence WHERE upload_id='up-1'")) == [10, 11]
    assert con.execute("SELECT origin_finding FROM dg_solution WHERE id=?", (sid,)).fetchone()[0] == 11
    con.close()
    assert occ is not None


# ---- the routes and the page

@pytest.fixture
def client(tmp):
    from flask import Flask
    from api import misc_api, nvme_errors_api as A
    from jobs import JobManager
    os.makedirs(os.path.join(tmp, "db"), exist_ok=True)
    app = Flask(__name__)
    app.config["services"] = types.SimpleNamespace(cfg={}, root=tmp, jobs=JobManager(os.path.join(tmp, "db", "jobs.sqlite")))
    app.register_blueprint(A.bp)
    app.register_blueprint(misc_api.bp)
    return app.test_client()


def test_routes(client, tmp):
    r = client.get("/api/hier/nvme_command_rules")
    j = r.get_json()
    assert r.status_code == 200 and len(j["rules"]) == len(NR.RULES) and len(j["groups"]) == 4 and len(j["documents"]) == 2
    assert client.get("/api/hier/nvme_command_rules/no-such").status_code == 404
    os.makedirs(os.path.join(tmp, "uploads", "up-nothing"))
    assert client.get("/api/hier/nvme_command_rules/up-nothing").status_code == 409
    recording(tmp, {"nvme_command": CMD_CSV, "nvme_transaction": NTX_CSV}, uid="up-7")
    r = client.get("/api/hier/nvme_command_rules/up-7")
    j = r.get_json()
    assert r.status_code == 200 and j["upload_id"] == "up-7" and j["commands"] == 608 and j["check_job"] is None
    assert set(j["graph"]) == set(NR.RULE_IDS) and j["trace_name"] == "test recording"
    r = client.get("/api/hier/nvme_command_rules/up-7/errors?rule=cmd.timeout")
    assert r.status_code == 200 and r.get_json()["total"] >= 7
    for bad in ("?rule=pkt.bad_lcrc", "?rule=", "", "?rule=cmd.timeout%27%3B%20DROP%20TABLE%20finding"):
        assert client.get("/api/hier/nvme_command_rules/up-7/errors" + bad).status_code == 400, bad
    assert client.get("/api/hier/nvme_command_rules/up-7/errors?rule=cmd.timeout&offset=abc").status_code == 400
    assert client.get("/api/hier/nvme_command_rules/up-7/errors?rule=cmd.timeout&offset=%d" % 10 ** 30).status_code == 400
    r = client.get("/api/hier/nvme_command_rules/up-7/errors.csv")
    body = r.get_data(as_text=True)
    assert r.status_code == 200 and r.mimetype == "text/csv" and body.splitlines()[0].startswith("rule,what was found")
    assert len(body.splitlines()) == j["errors_found"] + 1
    r.close()


def test_route_check_again_is_a_job_with_its_percentage(client, tmp):
    db = recording(tmp, {"nvme_command": CMD_CSV, "nvme_transaction": NTX_CSV}, uid="up-9")
    before = _findings(db)
    r = client.post("/api/hier/nvme_command_rules/up-9/check", json={})
    assert r.status_code == 200, r.get_json()
    jid = r.get_json()["job"]
    end = time.time() + 60
    while time.time() < end:
        j = client.get("/api/jobs/%s" % jid).get_json()
        if j["status"] in ("done", "failed", "cancelled"):
            break
        time.sleep(0.1)
    assert j["status"] == "done", j.get("error")
    assert j["result"]["before"] == j["result"]["after"] and j["result"]["error_numbers_that_moved"] == 0 and j["progress"]["pct"] == 100
    assert _findings(db) == before
    assert client.get("/api/hier/nvme_command_rules/up-9").get_json()["checked_again_at"]
    # a recording that is still loading, and one without its command file, are refused in words
    meta = os.path.join(tmp, "uploads", "up-9", "meta.json")
    m = json.load(open(meta))
    m["status"] = "loading"
    json.dump(m, open(meta, "w"))
    r = client.post("/api/hier/nvme_command_rules/up-9/check", json={})
    assert r.status_code == 409 and "still loading" in r.get_json()["error"]
    recording(tmp, {"nvme_transaction": NTX_CSV}, uid="up-ntx")
    r = client.post("/api/hier/nvme_command_rules/up-ntx/check", json={})
    assert r.status_code == 409 and "without its NVMe command file" in r.get_json()["error"]
    assert client.post("/api/hier/nvme_command_rules/no-such/check", json={}).status_code == 404


def test_the_page_and_its_links():
    static = os.path.join(APP_DIR, "app", "static")
    page = open(os.path.join(static, "nvme_command_rules.html"), encoding="utf-8").read()
    js = open(os.path.join(static, "js", "nvme_command_rules.js"), encoding="utf-8").read()
    assert "/static/js/nvme_command_rules.js" in page and "cannot be checked on this recording" in page
    assert '<option value="">No recording chosen' in page and "selected" not in page                # nothing is chosen for the user
    assert "/api/hier/nvme_command_rules" in js and "/isolate?upload=" in js and "&finding=" in js and "/errors.csv" in js
    assert "not verified against the specification" in js and "Line of the NVMe command file" in js
    server = open(os.path.join(APP_DIR, "app", "server.py"), encoding="utf-8").read()
    assert '"/nvme-rules"' in server and "nvme_command_rules.html" in server
    assert "nvme_command_rules.html" in open(os.path.join(static, "nvme_command_errors.html"), encoding="utf-8").read()
    for rid in NR.RULE_IDS:                                             # a rule's own id never reaches the screen as its name
        assert rid not in page
