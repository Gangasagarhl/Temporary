"""The four joins of the tree build and the window of link rows AS THEY WERE before 2026-11-14, kept word for word.

On 2026-11-14 the joins were changed to look rows up instead of asking the database or walking a list for every row
(nvme_hier/builder.py: LinkStream with its dictionary by PSN, the complete open links an Ack closes, the split rows and
the units read ahead into lists, the slot of a waiting completion entry kept in memory, the unit table copied by the
database). tests/test_tree_build_lookups.py runs both on the same data and wants the same scratch tables and the same
report from each. Nothing in the application uses this file.
"""
import heapq
import time
from collections import defaultdict, deque

from nvme_hier import loader as L
from nvme_hier import names as N
from nvme_hier.builder import BATCH, LOOKAHEAD_LINKS, MAX_QUEUE_SLOTS, PROGRESS_EVERY, Build, Sink, _other   # noqa: F401


class LinkStreamBefore:
    """The link rows of one direction in row order, read LOOKAHEAD_LINKS rows ahead at most. The PSN search looks
    into this window only; the rows it skips are consumed with the match and never revisited (as before)."""

    def __init__(self, con, d, look=LOOKAHEAD_LINKS):
        self.look = look
        self.cur = con.execute("SELECT rowid_file, psn, n_packets, t_ps FROM lnk WHERE dir=? ORDER BY rowid_file", (d,))
        self.win = deque()
        self.done = False
        self.consumed = 0

    def fill(self):
        while len(self.win) < self.look and not self.done:
            r = self.cur.fetchone()
            if r is None:
                self.done = True
                break
            self.win.append((r[0], r[1], r[2] or 1, r[3]))

    def find(self, psn, t_ps):
        """Index in the window of the link row this TLP belongs to, or None."""
        self.fill()
        w = self.win
        if w and w[0][1] == psn:
            return 0
        for j in range(len(w)):
            if w[j][1] == psn and (w[j][3] is None or t_ps is None or w[j][3] == t_ps):
                return j
        return None

    def take(self, j):
        """Consume the window up to and including j; returns (row, rows skipped)."""
        for _ in range(j):
            self.win.popleft()
        row = self.win.popleft()
        self.consumed += j + 1
        return row, j

    def close(self):
        self.cur.close()


class BuildBefore(Build):
    # ------------------------------------------------------------------ 1 packets -> links
    def packets_to_links(self):
        t0 = time.time()
        con = self.con
        pkt_sink = self.sink["pkt"]
        dur_lnk = self.dur["lnk"]
        links = {"Upstream": LinkStreamBefore(con, "Upstream", self.settings["look_links"]), "Downstream": LinkStreamBefore(con, "Downstream", self.settings["look_links"])}
        total = {d: 0 for d in links}
        for d, k in con.execute("SELECT dir, COUNT(*) FROM lnk GROUP BY dir"):
            if d in total:
                total[d] = k
        open_ = {"Upstream": {}, "Downstream": {}}      # psn -> [link rowid, attached, needed, first_t, last_t]
        unmatched_tlp = 0
        unmatched_ack = 0
        replays = 0
        n = 0
        skipped_links = 0
        tlp_packets = ack_nak_packets = 0
        for rowid, _pn, d, tlp_type, dllp_type, psn, acknak, t_ps in con.execute(
                "SELECT rowid_file, n, dir, tlp_type, dllp_type, psn, acknak, t_ps FROM pkt ORDER BY rowid_file"):
            n += 1
            if n % PROGRESS_EVERY == 0:
                self.progress("tree: packets to link transactions", "{:,} packets".format(n))
            if tlp_type and d in links:
                tlp_packets += 1
                st = open_[d].get(psn)
                if st is not None:
                    st[1] += 1
                    st[4] = t_ps
                    replays += 1
                    pkt_sink.add((rowid, "link", st[0], "member", t_ps))
                    if st[1] >= st[2]:
                        open_[d].pop(psn, None)
                    continue
                stream = links[d]
                found = stream.find(psn, t_ps)
                if found is None:
                    unmatched_tlp += 1
                    continue
                (lrow, _, needed, _t_first), skipped = stream.take(found)
                skipped_links += skipped
                pkt_sink.add((rowid, "link", lrow, "member", t_ps))
                if needed > 1:
                    open_[d][psn] = [lrow, 1, needed, t_ps, t_ps]
                else:
                    dur_lnk.add((lrow, 0))
            elif dllp_type and (dllp_type.upper() in ("ACK", "NAK")) and acknak is not None and d in links:
                ack_nak_packets += 1
                td = _other(d)
                seq = acknak
                kind = dllp_type.upper()
                st = open_[td].get(seq)
                if kind == "ACK":
                    if st is not None:
                        st[1] += 1
                        pkt_sink.add((rowid, "link", st[0], "member", t_ps))
                        if st[3] is not None and t_ps is not None:
                            dur_lnk.add((st[0], t_ps - st[3]))
                        if st[1] >= st[2]:
                            open_[td].pop(seq, None)
                    else:
                        unmatched_ack += 1
                        pkt_sink.add((rowid, "link", None, "context", t_ps))
                    # links the Ack covers implicitly close
                    for psn2 in [x for x in open_[td] if ((seq - x) & 0xFFF) < 2048 and x != seq]:
                        s2 = open_[td][psn2]
                        if s2[1] >= s2[2]:
                            open_[td].pop(psn2, None)
                else:
                    # NAK: it names the last TLP received correctly (PCIe Data Link Layer retry rules), so it acknowledges
                    # every open TLP up to that number and refuses the later ones. Which link transaction the analyzer
                    # counts the Nak packet in is not documented: follow its own count (Metrics.# Packets). The link the
                    # Nak names gets it if that link still needs a packet; otherwise the first refused link that does.
                    named = open_[td].get(seq)
                    later = sorted((x for x in open_[td] if ((x - seq) & 0xFFF) < 2048 and x != seq), key=lambda x: (x - seq) & 0xFFF)
                    target = named if (named is not None and named[1] < named[2]) else next((open_[td][x] for x in later if open_[td][x][1] < open_[td][x][2]), None)
                    if target is not None:
                        target[1] += 1
                        pkt_sink.add((rowid, "link", target[0], "member", t_ps))
                    else:
                        unmatched_ack += 1
                        pkt_sink.add((rowid, "link", None, "context", t_ps))
                    for psn2 in [x for x in open_[td] if ((seq - x) & 0xFFF) < 2048]:    # psn <= seq: acknowledged by the Nak
                        s2 = open_[td][psn2]
                        if s2[1] >= s2[2]:
                            if s2[3] is not None and t_ps is not None:
                                dur_lnk.add((s2[0], t_ps - s2[3]))
                            open_[td].pop(psn2, None)
            else:
                pkt_sink.add((rowid, None, None, "context", t_ps))
        self._flush()
        for s in links.values():
            s.close()
        # links still open: every one with fewer packets than the analyzer counted
        short = sum(1 for d in open_ for st in open_[d].values() if st[1] < st[2])
        total_links = sum(total.values())
        remaining = sum(total[d] - links[d].consumed for d in links)
        self.report["steps"]["packets_to_links"] = {
            "packets": n, "tlp_packets": tlp_packets, "ack_nak_packets": ack_nak_packets, "link_rows": total_links, "link_rows_matched": total_links - skipped_links - remaining,
            "link_rows_skipped": skipped_links + remaining,
            "replays_seen": replays, "tlp_without_link_row": unmatched_tlp, "ack_nak_without_open_link": unmatched_ack,
            "links_with_fewer_packets_than_counted": short, "seconds": round(time.time() - t0, 2)}

    # ------------------------------------------------------------------ 2 links -> splits
    def links_to_splits(self):
        t0 = time.time()
        con = self.con
        lnk_sink = self.sink["lnk"]
        dur_spl = self.dur["spl"]
        # the not-yet-consumed split rows, by (dir, rid, tag) in row order; a consumed row is deleted
        con.execute("CREATE TABLE w.spl_q (rowid INTEGER PRIMARY KEY, dir TEXT, rid TEXT, tag INTEGER, n_links INTEGER, t INTEGER)")
        con.execute("INSERT INTO w.spl_q SELECT rowid_file, dir, rid, tag, CASE WHEN n_links IS NULL OR n_links = 0 THEN 2 ELSE n_links END, t_ps FROM spl ORDER BY rowid_file")
        con.execute("CREATE INDEX w.ix_spl_q ON spl_q (dir, rid, tag, rowid)")
        con.commit()
        n_splits = con.execute("SELECT COUNT(*) FROM w.spl_q").fetchone()[0]
        q_sql = "SELECT rowid, n_links, t FROM w.spl_q WHERE dir IS ? AND rid IS ? AND tag IS ? ORDER BY rowid LIMIT %d" % self.settings["look_splits"]
        open_ = defaultdict(deque)     # (req dir, rid, tag) -> deque of [split rowid, attached, needed, req_t, first_cpl_t]
        matched_req = 0
        unmatched_req = 0
        unmatched_cpl = 0
        completions = 0
        n = 0
        for rowid, d, tlp_type, rid, tag, t_ps in con.execute("SELECT rowid_file, dir, tlp_type, rid, tag, t_ps FROM lnk ORDER BY rowid_file"):
            n += 1
            if n % PROGRESS_EVERY == 0:
                self.progress("tree: link to split transactions", "{:,} link transactions".format(n))
            cls = N.tlp_class(tlp_type)
            if cls == "non-posted":
                key = (d, rid, tag)
                q = con.execute(q_sql, key).fetchall()
                if q and (q[0][2] is None or t_ps is None or q[0][2] == t_ps):
                    srow, needed, t_req = q[0]
                elif q:
                    # the split's time stamp is its request's: look a few ahead for the exact time
                    hit = None
                    for k in range(len(q)):
                        if q[k][2] == t_ps:
                            hit = k
                            break
                    if hit is None:
                        unmatched_req += 1
                        lnk_sink.add((rowid, "split", None, "orphan"))
                        continue
                    srow, needed, t_req = q[hit]
                else:
                    unmatched_req += 1
                    lnk_sink.add((rowid, "split", None, "orphan"))
                    continue
                con.execute("DELETE FROM w.spl_q WHERE rowid=?", (srow,))
                matched_req += 1
                lnk_sink.add((rowid, "split", srow, "member"))
                if needed > 1:
                    open_[key].append([srow, 1, needed, t_ps, None])
            elif cls == "completion":
                completions += 1
                key = (_other(d), rid, tag)
                q = open_.get(key)
                if not q:
                    unmatched_cpl += 1
                    lnk_sink.add((rowid, "split", None, "orphan"))
                    continue
                st = q[0]
                st[1] += 1
                if st[4] is None:
                    st[4] = t_ps
                    if st[3] is not None and t_ps is not None:
                        dur_spl.add((st[0], t_ps - st[3]))
                lnk_sink.add((rowid, "split", st[0], "member"))
                if st[1] >= st[2]:
                    q.popleft()
            # posted / other classes: no split; units_to_ntx may claim them, else they are orphans at write time
        self._flush()
        still_open = sum(len(q) for q in open_.values())
        con.execute("DROP TABLE w.spl_q")
        con.commit()
        self.report["steps"]["links_to_splits"] = {
            "split_rows": n_splits, "requests_matched": matched_req, "requests_without_split_row": unmatched_req,
            "completions": completions, "completions_without_open_split": unmatched_cpl, "splits_with_fewer_completions_than_counted": still_open,
            "seconds": round(time.time() - t0, 2)}

    # ------------------------------------------------------------------ 3 units -> NVMe transactions
    def units_to_ntx(self):
        t0 = time.time()
        con = self.con
        lnk_sink, spl_sink, dur_ntx = self.sink["lnk"], self.sink["spl"], self.dur["ntx"]
        # units: posted links (not completions, not non-posted) and split rows, keyed by page and time; a unit an
        # NVMe transaction takes is deleted, so "the first unassigned unit at or after the time" is one index seek
        con.execute("CREATE TABLE w.unit (seq INTEGER PRIMARY KEY, page INTEGER, t INTEGER, level TEXT, rowid INTEGER)")
        unit_sink = Sink(con, "INSERT INTO w.unit (seq, page, t, level, rowid) VALUES (?,?,?,?,?)")
        seq = 0
        for rowid, tlp_type, addr, t_ps in (con.execute("SELECT rowid_file, tlp_type, addr, t_ps FROM lnk ORDER BY rowid_file") if "lnk" in self.tables else ()):
            if addr is not None and N.tlp_class(tlp_type) == "posted":
                seq += 1
                unit_sink.add((seq, addr >> 12, t_ps or 0, "link", rowid))
        for rowid, addr, t_ps in (con.execute("SELECT rowid_file, addr, t_ps FROM spl ORDER BY rowid_file") if "spl" in self.tables else ()):
            if addr is not None:
                seq += 1
                unit_sink.add((seq, addr >> 12, t_ps or 0, "split", rowid))
        unit_sink.flush()
        n_units = seq
        con.execute("CREATE INDEX w.ix_unit ON unit (page, t, seq)")
        con.commit()
        head_sql = "SELECT t, seq, level, rowid FROM w.unit WHERE page=? AND t>=? ORDER BY t, seq LIMIT ?"
        used = 0
        n_ntx = 0
        short = 0
        empty = 0
        for nrow, addr, nbytes, n_ls, t_ps in con.execute("SELECT rowid_file, addr, nbytes, n_links_splits, t_ps FROM ntx ORDER BY rowid_file"):
            n_ntx += 1
            if n_ntx % PROGRESS_EVERY == 0:
                self.progress("tree: units to NVMe transactions", "{:,} transactions".format(n_ntx))
            need = n_ls or 1
            if addr is None:
                empty += 1
                continue
            lo = addr >> 12
            hi = (addr + max(nbytes or 4, 4) - 1) >> 12
            t_min = t_ps or 0
            taken = []
            if lo == hi:
                taken = con.execute(head_sql, (lo, t_min, need)).fetchall()
            else:
                # merge the pages in (time, seq) order: the heap holds the first usable unit of each page
                heads = []
                for pg in range(lo, hi + 1):
                    h = con.execute(head_sql, (pg, t_min, 1)).fetchone()
                    if h:
                        heapq.heappush(heads, (h, pg))
                while heads and len(taken) < need:
                    h, pg = heapq.heappop(heads)
                    taken.append(h)
                    con.execute("DELETE FROM w.unit WHERE seq=?", (h[1],))
                    nxt = con.execute(head_sql, (pg, t_min, 1)).fetchone()
                    if nxt:
                        heapq.heappush(heads, (nxt, pg))
            if taken:
                if lo == hi:
                    con.executemany("DELETE FROM w.unit WHERE seq=?", [(u[1],) for u in taken])
                used += len(taken)
                first_t = last_t = None
                for t, _seq, level, rowid in taken:
                    (lnk_sink if level == "link" else spl_sink).add((rowid, "nvme_transaction", nrow, "member"))
                    first_t = t if first_t is None else min(first_t, t)
                    last_t = t if last_t is None else max(last_t, t)
                dur_ntx.add((nrow, last_t - first_t))
            if len(taken) < need:
                short += 1
        self._flush()
        con.execute("DROP TABLE w.unit")
        con.commit()
        self.report["steps"]["units_to_ntx"] = {
            "units": n_units, "ntx_rows": n_ntx, "ntx_without_address": empty,
            "ntx_with_fewer_units_than_counted": short, "units_assigned": used,
            "seconds": round(time.time() - t0, 2)}

    # ------------------------------------------------------------------ 4 NVMe transactions -> commands
    def ntx_to_cmds(self):
        t0 = time.time()
        con = self.con
        ntx_sink = self.sink["ntx"]
        # the command queue on disk: rowid order is file order; opened / attached / completion time / slot per row
        con.execute("CREATE TABLE w.cmdq (rowid INTEGER PRIMARY KEY, sqid INTEGER, cqid INTEGER, cid INTEGER, need INTEGER, "
                    "t INTEGER, attached INTEGER, cqe_t INTEGER, opened INTEGER, slot INTEGER)")
        con.execute("INSERT INTO w.cmdq SELECT rowid_file, sqid, COALESCE(cqid, sqid), cid, CASE WHEN n_ntx IS NULL OR n_ntx = 0 THEN 1 ELSE n_ntx END, t_ps, 0, NULL, 0, NULL "
                    "FROM cmd ORDER BY rowid_file")
        con.execute("CREATE INDEX w.ix_cmdq_t ON cmdq (sqid, t, rowid)")
        con.commit()
        # completion queue bases and sizes: Create I/O CQ commands (PRP1 = base, QID, QSIZE); the admin queue's
        # base is the address of its first completion entry (slot 0) when no register value is available
        # A queue can be deleted and created again (after a reset, or by the test that recorded the trace), each time at
        # a new address: the base in force is the one of the latest Create I/O CQ before the row being placed, never
        # one base for the whole recording (found by the Code tester on 2026-11-08: with the last base used everywhere the
        # slot of every completion entry was wrong and the head doorbells drifted to older commands).
        cq_base, cq_size = {}, {}
        creates = deque((t, qid, qsize, prp1) for t, qid, qsize, prp1 in con.execute(
            "SELECT t_ps, qid, qsize, prp1 FROM cmd WHERE sqid = 0 AND opc = 5 AND qid IS NOT NULL AND prp1 IS NOT NULL AND t_ps IS NOT NULL ORDER BY t_ps, rowid_file"))
        # a part of a recording (a test window) may start after its queues were created: the queues in force are then
        # given in meta 'cq_context' as [t, qid, qsize, base] and come first
        for t, qid, qsize, prp1 in reversed(sorted(L.get_meta(con, "cq_context", []) or [])):
            creates.appendleft((t, qid, qsize, prp1))
        next_row = con.execute("SELECT COALESCE(MIN(rowid), 1) FROM w.cmdq").fetchone()[0]
        open_ = {}                    # (sqid, cid) -> command rowid, while fewer than Metrics.# NVME Trans are attached
        pending_cq = defaultdict(deque)   # cqid -> command rowids whose completion entry was written, doorbell not yet rung
        # cqid -> command rowids whose entry a doorbell has passed (one doorbell can acknowledge several entries; it hangs under the last of them). They are
        # no longer looked at by slot: after the queue wrapped, a doorbell found the passed command of the lap before in its slot, and every doorbell read
        # all of them again (2026-11-12: 8,000 commands with one doorbell for every 4 entries took 61 s in this pass). Never more than a queue can hold.
        passed_cq = defaultdict(lambda: deque(maxlen=MAX_QUEUE_SLOTS))
        last_cqe = None
        last_cqe_irq = False          # the command of the last completion entry already has its interrupt
        n_rows = 0
        orphan = 0
        matched = 0
        by_t_sql = "SELECT rowid, sqid, cid FROM w.cmdq WHERE sqid IS ? AND t IS ? AND opened=0 ORDER BY rowid LIMIT 1"
        next_sql = ("SELECT rowid, sqid, cid FROM w.cmdq WHERE rowid >= ? AND rowid < ? AND opened=0 AND sqid IS ? "
                    "AND (? IS NULL OR cid IS ?) AND (? IS NULL OR t IS NULL OR t <= ?) ORDER BY rowid LIMIT 1")

        def mark_open(row):
            nonlocal next_row
            con.execute("UPDATE w.cmdq SET opened=1 WHERE rowid=?", (row[0],))
            open_[(row[1], row[2])] = row[0]
            if row[0] == next_row:
                r = con.execute("SELECT MIN(rowid) FROM w.cmdq WHERE rowid > ? AND opened=0", (row[0],)).fetchone()[0]
                next_row = r if r is not None else row[0] + 1

        def open_next(sqid, cid, t):
            row = con.execute(next_sql, (next_row, next_row + self.settings["look_cmds"], sqid, cid, cid, t, t)).fetchone()
            if row is None:
                return None
            mark_open(row)
            return row[0]

        def attach(crow, ntx_rowid, is_entry=False):
            r = con.execute("UPDATE w.cmdq SET attached = attached + 1 WHERE rowid=? RETURNING attached, need, sqid, cid, cqid, cqe_t", (crow,)).fetchone()
            ntx_sink.add((ntx_rowid, "nvme_command", crow, "member"))
            # a command stays open until it has its completion entry, whatever the count says: a late entry must find its command
            # (a command that never gets one is replaced here when its queue and number are used again: mark_open)
            if r[0] >= r[1] and (is_entry or r[5] is not None) and open_.get((r[2], r[3])) == crow:
                open_.pop((r[2], r[3]), None)
            return r[4]

        for nrow, typ, qid, sqid, cid, t_ps, db_index, addr in con.execute(
                "SELECT rowid_file, type, qid, sqid, cid, t_ps, db_index, addr FROM ntx ORDER BY rowid_file"):
            while creates and t_ps is not None and creates[0][0] <= t_ps:
                _t, cq_q, cq_n, cq_p = creates.popleft()
                cq_base[cq_q], cq_size[cq_q] = cq_p, cq_n
                pending_cq.pop(cq_q, None)      # a new queue: what waited on the old one will never be rung for
                passed_cq.pop(cq_q, None)
            n_rows += 1
            if n_rows % PROGRESS_EVERY == 0:
                self.progress("tree: NVMe transactions to commands", "{:,} transactions".format(n_rows))
            part = N.part_key(typ)
            crow = None
            if part == "dbl":
                tl = (typ or "").lower()
                is_cq = "completion" in tl or "cq" in tl.replace("sq", "") and "head" in tl
                if is_cq:
                    q, passed = pending_cq[qid], passed_cq[qid]
                    if q or passed:
                        # the doorbell value is the new head: the entry it consumed last sits in slot value-1
                        want = None
                        if db_index is not None and qid in cq_base:
                            size = cq_size.get(qid)
                            want = (db_index - 1) % size if size else db_index - 1
                        hit = None
                        if want is not None:
                            for k, j in enumerate(q):
                                slot = con.execute("SELECT slot FROM w.cmdq WHERE rowid=?", (j,)).fetchone()[0]
                                if slot == want:
                                    hit = k
                                    break
                        if hit is not None:
                            for _ in range(hit):            # the older entries this doorbell acknowledged with it
                                passed.append(q.popleft())
                            crow = q.popleft()
                        else:
                            # no entry waits in that slot: the oldest completed command of the queue, a passed one first (it is the older)
                            crow = passed.popleft() if passed else q.popleft()
                else:
                    # the submission doorbell opens the command with the same time stamp on that queue
                    row = con.execute(by_t_sql, (qid, t_ps)).fetchone()
                    if row is not None:
                        mark_open(row)
                        crow = row[0]
                    if crow is None:
                        crow = open_next(qid, None, t_ps)
            elif sqid is not None and cid is not None:
                crow = open_.get((sqid, cid))
                if crow is None:
                    crow = open_next(sqid, cid, t_ps)
            elif part == "irq":
                # an interrupt announces the completion entry written before it: one interrupt per entry. A second
                # interrupt with no new entry belongs to no command (it is left outside, where it is reported) instead of
                # being counted inside the last command (found on the 4.3 GB set, 2026-11-08)
                crow = last_cqe if not last_cqe_irq else None
            if crow is None:
                orphan += 1
                ntx_sink.add((nrow, "nvme_command", None, "orphan"))
                continue
            matched += 1
            cq = attach(crow, nrow, part == "cqe")
            if part == "cqe":
                if addr is not None:
                    if cq not in cq_base:
                        cq_base[cq] = addr          # first completion entry of this queue = slot 0
                    # the command ends at its FIRST completion entry; a second one for it is a fault of its own (2026-11-09)
                    con.execute("UPDATE w.cmdq SET cqe_t=COALESCE(cqe_t, ?), slot=? WHERE rowid=?", (t_ps, (addr - cq_base[cq]) // 16, crow))
                else:
                    con.execute("UPDATE w.cmdq SET cqe_t=COALESCE(cqe_t, ?) WHERE rowid=?", (t_ps, crow))
                pending_cq[cq].append(crow)
                last_cqe = crow
                last_cqe_irq = False
            elif part == "irq":
                last_cqe_irq = True
        self._flush()
        con.execute("INSERT INTO w.cmd_dur SELECT rowid, cqe_t - t FROM w.cmdq WHERE cqe_t IS NOT NULL AND t IS NOT NULL")
        n_cmds, opened, fewer = con.execute("SELECT COUNT(*), SUM(opened), SUM(attached < need) FROM w.cmdq").fetchone()
        con.execute("DROP TABLE w.cmdq")
        con.commit()
        self.report["steps"]["ntx_to_cmds"] = {
            "ntx_rows": n_rows, "ntx_matched": matched, "ntx_outside_any_command": orphan, "command_rows": n_cmds,
            "commands_opened": opened or 0, "commands_with_fewer_transactions_than_counted": fewer or 0,
            "seconds": round(time.time() - t0, 2)}


# ---------------------------------------------------------------------------------------------- the flow's window test
# agentic/family2.py slice_check as it was before 2026-11-14 (its comparison with the full tree went through the members
# of the whole full table for every window). It runs in family2's own names, so that everything else it uses is today's.
_SLICE_CHECK_BEFORE = r'''
def slice_check(full_db, t0, t1, box, label):
    """Rebuild the rows of [t0, t1] (plus a margin) on their own and compare with the analyzer's counts and with the
    full tree, for the parents that lie fully inside the window."""
    margin = max(5 * 10 ** 9, (t1 - t0) // 5)      # at least 5 ms of rows on each side of the window
    p = os.path.join(box, "slice_%s.sqlite" % label)
    for ext in ("", "-wal", "-shm"):
        if os.path.exists(p + ext):
            OSF.remove(p + ext)
    w = p.replace(".sqlite", ".work.sqlite")
    if os.path.exists(w):
        OSF.remove(w)
    src = sqlite3.connect("file:%s?mode=ro" % full_db, uri=True)
    ddl = {r[0]: r[1] for r in src.execute("SELECT name, sql FROM sqlite_master WHERE type='table' AND name IN ('pkt','lnk','spl','ntx','cmd','meta')")}
    src.close()
    con = sqlite3.connect(p)
    for t, sql in ddl.items():
        con.execute(sql)
    con.execute("ATTACH DATABASE ? AS f", (full_db,))
    counts = {}
    for t in ("pkt", "lnk", "spl", "ntx", "cmd"):
        if t in ddl:
            con.execute("INSERT INTO %s SELECT * FROM f.%s WHERE t_ps BETWEEN ? AND ?" % (t, t), (t0 - margin, t1 + margin))
            con.execute("UPDATE %s SET parent=NULL, parent_level=NULL, relation=NULL, dur_ps=NULL" % t)
            counts[t] = con.execute("SELECT COUNT(*) FROM %s" % t).fetchone()[0]
    if "meta" in ddl:
        con.execute("INSERT INTO meta SELECT * FROM f.meta WHERE k IN ('levels_present','load_reports','upload')")
        # the queues in force when the window opens (their last creation before it): without them the window cannot
        # know where a completion queue's slots start, and its head doorbells could not be placed as in the full tree
        ctx = [list(r) for r in con.execute(
            "SELECT t_ps, qid, qsize, prp1 FROM f.cmd c WHERE sqid = 0 AND opc = 5 AND qid IS NOT NULL AND prp1 IS NOT NULL AND t_ps < ? "
            "AND t_ps = (SELECT MAX(t_ps) FROM f.cmd c2 WHERE c2.sqid = 0 AND c2.opc = 5 AND c2.qid = c.qid AND c2.t_ps < ?)", (t0 - margin, t0 - margin))]
        con.execute("INSERT OR REPLACE INTO meta (k, v) VALUES ('cq_context', ?)", (json.dumps(ctx),))
    # the indexes the loader makes (the builder's own count checks and ours look children up by parent and rows up by
    # time: without them every check scans the whole table)
    for t in counts:
        con.execute("CREATE INDEX IF NOT EXISTS ix_%s_parent ON %s (parent_level, parent)" % (t, t))
        con.execute("CREATE INDEX IF NOT EXISTS ix_%s_t ON %s (t_ps)" % (t, t))
    con.commit()
    con.execute("DETACH DATABASE f")
    con.close()
    try:                        # the window is built with the settings the full tree was built with, so the two can be compared
        full_settings = json.loads((sqlite3.connect("file:%s?mode=ro" % full_db, uri=True).execute("SELECT v FROM meta WHERE k='build'").fetchone() or ["{}"])[0]).get("settings")
    except (sqlite3.Error, ValueError, TypeError):
        full_settings = None
    B.build(p, settings=full_settings)
    con = sqlite3.connect(p)
    con.execute("ATTACH DATABASE ? AS f", (full_db,))
    res = {"window": [t0, t1], "rows": counts, "count_mismatch": {}, "parent_mismatch": {}, "checked": {}}
    for parent, ncol, child, lvl in COUNT_CHECKS:
        if parent not in counts:
            continue
        # only parents whose whole life lies inside the window are judged: their start and their end (start plus the
        # duration they have in the full tree) are inside [t0, t1], and the copy reaches a margin beyond both ends
        inside = ("p.t_ps BETWEEN ? AND ? AND p.%s IS NOT NULL AND EXISTS (SELECT 1 FROM f.%s fp WHERE fp.rowid_file = p.rowid_file "
                  "AND fp.dur_ps IS NOT NULL AND fp.t_ps + fp.dur_ps <= ?)" % (ncol, parent))
        if child:
            q = ("SELECT p.rowid_file, p.%s, (SELECT COUNT(*) FROM %s c WHERE c.parent_level=? AND c.parent=p.rowid_file AND c.relation='member') "
                 "FROM %s p WHERE %s" % (ncol, child, parent, inside))
            rows = con.execute(q, (lvl, t0, t1, t1)).fetchall()
        else:
            q = ("SELECT p.rowid_file, p.%s, (SELECT COUNT(*) FROM lnk c WHERE c.parent_level=? AND c.parent=p.rowid_file AND c.relation='member') + "
                 "(SELECT COUNT(*) FROM spl c WHERE c.parent_level=? AND c.parent=p.rowid_file AND c.relation='member') "
                 "FROM %s p WHERE %s" % (ncol, parent, inside))
            rows = con.execute(q, (lvl, lvl, t0, t1, t1)).fetchall() if "lnk" in counts and "spl" in counts else []
        bad = [r for r in rows if r[1] != r[2]]
        res["checked"][parent] = len(rows)
        res["count_mismatch"][parent] = {"n": len(bad), "examples": [{"row": r[0], "analyzer": r[1], "joined": r[2]} for r in bad[:3]]}
    for t in ("pkt", "lnk", "spl", "ntx"):
        if t not in counts:
            continue
        ptab = {"pkt": "lnk", "lnk": None, "spl": "ntx", "ntx": "cmd"}[t]
        if t == "lnk":
            # a link transaction's parent is a split transaction or an NVMe transaction: compare it when that parent is whole
            cond = ("EXISTS (SELECT 1 FROM f.spl fp WHERE f.parent_level='split' AND fp.rowid_file=f.parent AND fp.t_ps >= ? AND fp.t_ps + COALESCE(fp.dur_ps, 0) <= ?) "
                    "OR EXISTS (SELECT 1 FROM f.ntx fp WHERE f.parent_level='nvme_transaction' AND fp.rowid_file=f.parent AND fp.t_ps >= ? AND fp.t_ps + COALESCE(fp.dur_ps, 0) <= ?)")
            args = (t0, t1, t0, t1)
        else:
            cond = "EXISTS (SELECT 1 FROM f.%s fp WHERE fp.rowid_file=f.parent AND fp.t_ps >= ? AND fp.t_ps + COALESCE(fp.dur_ps, 0) <= ?)" % ptab
            args = (t0, t1)
        diff = con.execute("SELECT s.rowid_file, s.parent, f.parent FROM %s s JOIN f.%s f ON f.rowid_file=s.rowid_file "
                           "WHERE s.relation='member' AND f.relation='member' AND s.parent IS NOT f.parent AND (%s) LIMIT 1000" % (t, t, cond), args).fetchall()
        res["parent_mismatch"][t] = {"n": len(diff), "examples": [{"row": r[0], "slice": r[1], "full": r[2]} for r in diff[:3]]}
    con.close()
    for ext in ("", "-wal", "-shm"):
        if os.path.exists(p + ext):
            OSF.remove(p + ext)
    res["passed"] = all(v["n"] == 0 for v in res["count_mismatch"].values()) and all(v["n"] == 0 for v in res["parent_mismatch"].values())
    return res
'''


def slice_check_before(full_db, t0, t1, box, label):
    from agentic import family2
    names = dict(vars(family2))
    exec(compile(_SLICE_CHECK_BEFORE, "family2.slice_check as it was", "exec"), names)
    return names["slice_check"](full_db, t0, t1, box, label)
