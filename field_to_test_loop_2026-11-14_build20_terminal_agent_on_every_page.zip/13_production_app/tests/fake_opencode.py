#!/usr/bin/env python3
"""A stand-in for the opencode program in the tests: the same commands and the same event lines, no network.

It keeps its sessions in $FAKE_OPENCODE_HOME/state.json (as the real program keeps them in its own store) and writes
every call it received to $FAKE_OPENCODE_HOME/calls.jsonl, so a test can see what the application really started.

What it answers, in this order:
  - the file $FAKE_OPENCODE_HOME/answers.json, when there: {"<words found in the question>": <the answer text>, ...}
    (the first key found in the question wins);
  - a question holding HOW MANY TURNS: {"ok": true, "turns_before": n, "asked_before": [first 60 characters of each]};
  - otherwise the text of $FAKE_OPENCODE_ANSWER, or {"ok": true}.
Failures on request: $FAKE_OPENCODE_HOME/fail.json = {"times": n, "message": "..."} fails the next n turns with that
message (an error event, exit code 1); with "silent": true the message goes to the log on standard error as the real
program writes it (level=ERROR ... error.error="...") and the program then waits 60 s without a word, as the real one
does; a question holding WRITE NOTHING gives a turn without text.
"""
import json
import os
import sys
import time

HOME = os.environ.get("FAKE_OPENCODE_HOME") or os.path.dirname(os.path.abspath(__file__))
STATE = os.path.join(HOME, "state.json")

MODELS = """fake/alpha-free
{
  "id": "alpha-free",
  "name": "Alpha Free",
  "limit": { "context": 2000, "output": 500 },
  "cost": { "input": 0, "output": 0 },
  "variants": { "low": {}, "high": {}, "max": {} }
}
fake/beta-paid
{
  "id": "beta-paid",
  "name": "Beta Paid",
  "limit": { "context": 100000, "output": 8000 },
  "cost": { "input": 2, "output": 10 },
  "variants": {}
}
other/gamma
{
  "id": "gamma",
  "name": "Gamma",
  "limit": { "context": 50000, "output": 4000 },
  "cost": { "input": 0, "output": 0 }
}
"""


def load():
    try:
        with open(STATE, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {"n": 0, "sessions": {}}


def save(st):
    tmp = STATE + ".%d.tmp" % os.getpid()
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(st, f)
    os.replace(tmp, STATE)


def locked(fn):
    """One writer at a time over the state file (the tests start several at once)."""
    lock = STATE + ".lock"
    for _ in range(600):
        try:
            fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.close(fd)
            break
        except FileExistsError:
            time.sleep(0.01)
    try:
        return fn()
    finally:
        try:
            os.remove(lock)
        except OSError:
            pass


def emit(kind, sid, **part):
    sys.stdout.write(json.dumps({"type": kind, "timestamp": int(time.time() * 1000), "sessionID": sid, **part}) + "\n")


def opt(args, name, default=None):
    return args[args.index(name) + 1] if name in args and args.index(name) + 1 < len(args) else default


def main():
    args = sys.argv[1:]
    os.makedirs(HOME, exist_ok=True)
    if args[:1] == ["--version"]:
        print("9.9.9-fake")
        return 0
    if args[:1] == ["models"]:
        sys.stdout.write(MODELS)
        return 0
    if args[:2] == ["session", "delete"]:
        def drop():
            st = load()
            had = st["sessions"].pop(args[2], None) is not None
            save(st)
            return had
        return 0 if locked(drop) else 1
    if args[:1] != ["run"]:
        sys.stderr.write("unknown command\n")
        return 2
    asked = sys.stdin.read()
    model, sid, title = opt(args, "-m"), opt(args, "-s"), opt(args, "--title")
    with open(os.path.join(HOME, "calls.jsonl"), "a", encoding="utf-8") as f:
        f.write(json.dumps({"args": args, "cwd": os.getcwd(), "asked": asked[:2000], "asked_chars": len(asked),
                            "config": os.environ.get("OPENCODE_CONFIG_CONTENT", ""), "pid": os.getpid(),
                            "switches": sorted(k for k in os.environ if k.startswith("OPENCODE_DISABLE_"))}) + "\n")
    if os.environ.get("FAKE_OPENCODE_SLEEP"):
        time.sleep(float(os.environ["FAKE_OPENCODE_SLEEP"]))
    known = {m.strip() for m in MODELS.splitlines() if "/" in m and not m.startswith((" ", "{"))}

    def turn():
        st = load()
        if sid:
            if sid not in st["sessions"]:
                return None, None, "Session not found: %s" % sid
            s, the_id = st["sessions"][sid], sid
        else:
            st["n"] += 1
            the_id = "ses_fake%06d" % st["n"]
            s = st["sessions"][the_id] = {"title": title, "model": model, "turns": [], "cwd": os.getcwd()}
        fail_file = os.path.join(HOME, "fail.json")
        if os.path.isfile(fail_file):
            with open(fail_file, encoding="utf-8") as f:
                fail = json.load(f)
            if fail.get("times", 0) > 0:
                fail["times"] -= 1
                with open(fail_file, "w", encoding="utf-8") as f:
                    json.dump(fail, f)
                save(st)
                if fail.get("silent"):
                    return the_id, None, "SILENT:" + (fail.get("message") or "Free usage limit reached.")
                return the_id, None, fail.get("message") or "Unexpected server error."
        if model not in known:
            save(st)
            return the_id, None, "Unexpected server error. Check server logs for details."
        before = [t[0][:60] for t in s["turns"]]
        answer = None
        ans_file = os.path.join(HOME, "answers.json")
        if os.path.isfile(ans_file):
            with open(ans_file, encoding="utf-8") as f:
                for words, text in json.load(f).items():
                    if words in asked:
                        answer = text if isinstance(text, str) else json.dumps(text)
                        break
        if answer is None and "HOW MANY TURNS" in asked:
            answer = json.dumps({"ok": True, "turns_before": len(before), "asked_before": before})
        if answer is None and "WRITE NOTHING" in asked:
            answer = ""
        if answer is None:
            answer = os.environ.get("FAKE_OPENCODE_ANSWER") or '{"ok": true}'
        s["turns"].append([asked, answer])
        size = sum(len(a) + len(b) for a, b in s["turns"]) // 2
        save(st)
        return the_id, (answer, size), None

    the_id, got, problem = locked(turn)
    if problem and problem.startswith("SILENT:"):
        sys.stderr.write('timestamp=2026-11-13T06:17:10.556Z level=ERROR run=fake message="stream error" providerID=fake session.id=%s '
                         'error.error="AI_APICallError: %s"\n' % (the_id, problem[7:]))
        sys.stderr.flush()
        time.sleep(60)
        return 0
    if problem:
        sys.stdout.write(json.dumps({"type": "error", "timestamp": int(time.time() * 1000), "sessionID": the_id,
                                     "error": {"name": "UnknownError", "data": {"message": problem}}}) + "\n")
        return 1
    answer, size = got
    emit("step_start", the_id, part={"type": "step-start"})
    if answer:
        emit("text", the_id, part={"type": "text", "text": answer})
    emit("step_finish", the_id, part={"type": "step-finish", "reason": "stop",
                                      "tokens": {"total": size, "input": size - 5, "output": 5, "reasoning": 0, "cache": {"write": 0, "read": 0}}})
    return 0


if __name__ == "__main__":
    sys.exit(main())
