"""The investigation agent after Family 1 (owner, 2026-11-14): one held terminal session per analysis, its name kept, the
status of a working question shown, CSV files exported and added to the analysis. The terminal program is the tests'
stand-in (tests/fake_opencode.py); the application is a temporary copy."""
import json
import os
import shutil
import sys
import tempfile
import time

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

FAKE = os.path.join(HERE, "fake_opencode.py")
if os.name == "nt":
    pytestmark = pytest.mark.skip(reason="the stand-in opencode program of these tests is started as a script; not on Windows")
NAMES = ("FAKE_OPENCODE_HOME", "FAKE_OPENCODE_ANSWER", "FAKE_OPENCODE_SLEEP")


@pytest.fixture
def site():
    import fuzz_app as F
    from agentic import opencode_cli as oc
    if not os.path.isdir(F.BASE):
        pytest.skip("the S08 sample recording is not on this machine (the code-only zip carries no samples)")
    was = {k: os.environ.get(k) for k in NAMES}
    d = tempfile.mkdtemp(prefix="investigate_%d_" % os.getpid())
    os.environ["FAKE_OPENCODE_HOME"] = os.path.join(d, "fake_home")
    os.environ["FAKE_OPENCODE_ANSWER"] = "**Answer**: link.csv holds 51,935 link transactions."
    os.environ.pop("FAKE_OPENCODE_SLEEP", None)
    oc.forget_models()
    root = os.path.join(d, "app")
    os.makedirs(root)
    app, c, _k, _r = F.setup(root)
    s = app.config["services"]
    s.cfg["agentic"].update(runtime="standin", opencode_path=FAKE, opencode_model="fake/beta-paid")      # the agents on the stand-in: the investigation still uses the terminal
    data = os.path.join(d, "data")
    shutil.copytree(F.BASE, data)
    with app.app_context():
        from api import agentic_api as A
        eng = A.engine()
    eng.runner.runtime, eng.runner.opencode_path, eng.runner.opencode_model = "standin", FAKE, "fake/beta-paid"   # the engine may exist already
    pid = eng.store.exec("INSERT INTO project (admin, name, folder, refs, created, updated) VALUES (?,?,?,?,?,?)", ("Sagar", "S08", data, "[]", time.time(), time.time()))
    try:
        yield app, c, s, eng, pid, data, d
    finally:
        oc.forget_models()
        for k, v in was.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        shutil.rmtree(d, ignore_errors=True)


def wait_done(c, pid, limit=60):
    t0 = time.time()
    while time.time() - t0 < limit:
        d = c.get("/api/agents/projects/%d/investigate" % pid).get_json()
        if not d["running"]:
            return d
        time.sleep(0.2)
    raise AssertionError("the question did not end in %d s" % limit)


def fake_calls(d):
    p = os.path.join(d, "fake_home", "calls.jsonl")
    return [json.loads(x) for x in open(p, encoding="utf-8")] if os.path.exists(p) else []


def test_a_question_goes_to_the_analysis_own_terminal_session_and_the_next_one_continues_it(site):
    app, c, s, eng, pid, data, d = site
    st = c.get("/api/agents/projects/%d/investigate" % pid).get_json()
    assert st["ready"] is True and st["name"] == "analysis %d · investigation" % pid and st["session"] is None and st["conversation"] == [] and st["model"] == "Beta Paid"
    r = c.post("/api/agents/projects/%d/investigate" % pid, json={"question": "Where are the link transaction numbers?", "admin": "Sagar"})
    assert r.status_code == 200 and r.get_json()["started"] is True
    st = wait_done(c, pid)
    assert st["last_error"] is None and len(st["conversation"]) == 1
    t = st["conversation"][0]
    assert t["asked"] == "Where are the link transaction numbers?" and t["answered"].startswith("**Answer**: link.csv") and t["ok"] is True
    assert st["session"]["name"] == "analysis %d · investigation" % pid and st["session"]["turns"] == 1 and st["session"]["terminal_id"].startswith("ses_fake")
    call = fake_calls(d)[-1]
    args = call["args"]
    assert args[args.index("--agent") + 1] == "f2t-investigate" and "--title" in args and args[args.index("--title") + 1] == "analysis %d investigation" % pid
    box = os.path.join(eng.runner.sandbox_root, "investigation_p%d" % pid)
    assert call["cwd"] == box
    perm = json.loads(call["config"])["agent"]["f2t-investigate"]["permission"]
    assert perm["external_directory"][data + "/*"] == "allow" and perm["bash"]["*"] == "deny" and perm["bash"]["python3 *"] == "allow"
    assert call["asked"].startswith("# Investigation agent") and "THE ADMINISTRATOR ASKS:\nWhere are the link" in open(os.path.join(d, "fake_home", "state.json")).read().replace("\\n", "\n")
    # what the application knows is in the agent's folder
    text = open(os.path.join(box, "ANALYSIS.md"), encoding="utf-8").read()
    assert "Data folder (read only): `%s`" % data in text and "`link.csv`" in text and "`packets.csv`" in text
    # the second question continues the same session
    c.post("/api/agents/projects/%d/investigate" % pid, json={"question": "And the split transactions?", "admin": "Sagar"})
    st = wait_done(c, pid)
    assert [x["asked"] for x in st["conversation"]] == ["Where are the link transaction numbers?", "And the split transactions?"]
    assert st["session"]["turns"] == 2 and "-s" in fake_calls(d)[-1]["args"]
    # the agents' own runtime was the stand-in all along: the investigation is the one place that always uses the terminal
    assert eng.runner.runtime == "standin"


def test_after_a_restart_the_same_session_is_opened_again(site):
    app, c, s, eng, pid, data, d = site
    c.post("/api/agents/projects/%d/investigate" % pid, json={"question": "first", "admin": "Sagar"})
    first = wait_done(c, pid)["session"]["terminal_id"]
    s.agentic_engine = None                         # the application started again: a new engine over the same files
    with app.app_context():
        from api import agentic_api as A
        A.engine()
    st = c.get("/api/agents/projects/%d/investigate" % pid).get_json()
    assert st["session"]["terminal_id"] == first and st["conversation"][0]["asked"] == "first"
    c.post("/api/agents/projects/%d/investigate" % pid, json={"question": "second", "admin": "Sagar"})
    st = wait_done(c, pid)
    assert st["session"]["terminal_id"] == first and st["session"]["turns"] == 2
    last = fake_calls(d)[-1]["args"]
    assert last[last.index("-s") + 1] == first


def test_while_it_works_the_page_gets_what_it_is_doing_and_one_question_at_a_time(site):
    app, c, s, eng, pid, data, d = site
    os.environ["FAKE_OPENCODE_SLEEP"] = "3"
    c.post("/api/agents/projects/%d/investigate" % pid, json={"question": "a slow one", "admin": "Sagar"})
    st = c.get("/api/agents/projects/%d/investigate" % pid).get_json()
    assert st["running"] and st["running"]["question"] == "a slow one" and st["running"]["by"] == "Sagar"
    r = c.post("/api/agents/projects/%d/investigate" % pid, json={"question": "another", "admin": "Sagar"})
    assert r.status_code == 400 and "still working" in r.get_json()["error"]
    st = wait_done(c, pid)
    assert st["conversation"][-1]["asked"] == "a slow one"
    from agentic import investigate as INV
    with INV._lock:
        lines = [x["text"] for x in INV._jobs[pid]["lines"]]
    assert any(x.startswith("the agent: **Answer**") for x in lines), lines


def test_stop_ends_the_question_and_says_so(site):
    app, c, s, eng, pid, data, d = site
    os.environ["FAKE_OPENCODE_SLEEP"] = "30"
    c.post("/api/agents/projects/%d/investigate" % pid, json={"question": "a very slow one", "admin": "Sagar"})
    for _ in range(100):
        if eng.runner.procs.get("investigation_p%d" % pid):
            break
        time.sleep(0.05)
    t0 = time.time()
    assert c.post("/api/agents/projects/%d/investigate/stop" % pid, json={}).get_json()["stopped"] is True
    st = wait_done(c, pid, 15)
    assert time.time() - t0 < 12 and st["last_error"] == "stopped by the admin"
    os.environ.pop("FAKE_OPENCODE_SLEEP")
    c.post("/api/agents/projects/%d/investigate" % pid, json={"question": "after the stop", "admin": "Sagar"})
    assert wait_done(c, pid)["conversation"][-1]["asked"] == "after the stop"       # a stopped question does not block the next one


def test_exported_files_are_listed_saved_and_added_to_the_analysis_without_replacing_anything(site):
    app, c, s, eng, pid, data, d = site
    from agentic import investigate as INV
    box = INV.workspace(eng, pid)
    with open(os.path.join(box, "exports", "io_commands.csv"), "w") as f:
        f.write("Command,Count\nRead,7\n")
    with open(os.path.join(box, "exports", "notes.txt"), "w") as f:
        f.write("x")
    ex = c.get("/api/agents/projects/%d/investigate" % pid).get_json()["exports"]
    assert [e["name"] for e in ex] == ["io_commands.csv", "notes.txt"] and "path" not in ex[0]
    r = c.get("/api/agents/projects/%d/investigate/exports/io_commands.csv" % pid)
    assert r.status_code == 200 and r.data == b"Command,Count\nRead,7\n"
    for bad in ("..%2Fpacket.csv", ".hidden", "nothing.csv"):
        assert c.get("/api/agents/projects/%d/investigate/exports/%s" % (pid, bad)).status_code == 404
    r = c.post("/api/agents/projects/%d/investigate/exports/io_commands.csv/add" % pid, json={})
    assert r.status_code == 200 and open(os.path.join(data, "io_commands.csv")).read() == "Command,Count\nRead,7\n" and "Read the new files" in r.get_json()["next"]
    r = c.post("/api/agents/projects/%d/investigate/exports/io_commands.csv/add" % pid, json={})
    assert r.status_code == 400 and "already has a file named io_commands.csv" in r.get_json()["error"]
    assert c.post("/api/agents/projects/%d/investigate/exports/notes.txt/add" % pid, json={}).status_code == 400
    shutil.copy(os.path.join(data, "link.csv"), os.path.join(box, "exports", "link.csv"))
    assert c.post("/api/agents/projects/%d/investigate/exports/link.csv/add" % pid, json={}).status_code == 400      # the recording's own file is never replaced


def test_refusals_are_said_in_words(site):
    app, c, s, eng, pid, data, d = site
    assert c.get("/api/agents/projects/999999/investigate").status_code == 404
    assert c.post("/api/agents/projects/%d/investigate" % pid, json={"question": "  "}).get_json()["error"] == "write the question first"
    assert c.post("/api/agents/projects/%d/investigate" % pid, json={"question": 5}).status_code == 400
    assert c.post("/api/agents/projects/%d/investigate" % pid, json=[1]).status_code == 400
    s.cfg["agentic"]["opencode_model"] = ""
    eng.runner.opencode_model = None
    st = c.get("/api/agents/projects/%d/investigate" % pid).get_json()
    assert st["ready"] is False and "no model is chosen for opencode" in st["problem"]
    r = c.post("/api/agents/projects/%d/investigate" % pid, json={"question": "x"})
    assert r.status_code == 400 and "choose one in Settings" in r.get_json()["error"]


# ---------------------------------------------------------------------------------------------- the terminal agent from every page
# (owner, 2026-11-14: "each and every page should have communication with the terminal agent")
def wait_place(c, query, limit=60):
    t0 = time.time()
    while time.time() - t0 < limit:
        d = c.get("/api/agents/terminal" + query).get_json()
        if not d["running"]:
            return d
        time.sleep(0.2)
    raise AssertionError("the question did not end in %d s" % limit)


def prompt_sent(d):
    """Everything the stand-in terminal program was given, as text."""
    return open(os.path.join(d, "fake_home", "state.json"), encoding="utf-8").read().replace("\\n", "\n")


def test_the_place_follows_what_the_page_shows(site):
    app, c, s, eng, pid, data, d = site
    st = c.get("/api/agents/terminal").get_json()
    assert st["place"] == "application" and st["project"] == "app" and st["name"] == "application · terminal agent" and st["ready"] is True
    st = c.get("/api/agents/terminal?pid=%d" % pid).get_json()
    assert st["place"] == "analysis" and st["project"] == pid and st["name"] == "analysis %d · investigation" % pid and st["analysis_name"] == "S08"
    r = c.get("/api/agents/terminal?pid=999999")
    assert r.status_code == 404 and r.get_json()["error"] == "no such analysis"         # never silently the application
    assert c.get("/api/agents/terminal?pid=abc").status_code == 400
    assert c.post("/api/agents/terminal", json={"pid": True, "question": "x"}).status_code == 400
    assert c.post("/api/agents/terminal", json={"pid": [1], "question": "x"}).status_code == 400
    # a page that shows a recording: the analysis the recording belongs to; a recording of no analysis: the application
    assert c.get("/api/agents/terminal?upload=up-of-nobody").get_json()["place"] == "application"
    eng.store.exec("UPDATE project SET upload_id=? WHERE id=?", ("up-of-s08", pid))
    st = c.get("/api/agents/terminal?upload=up-of-s08").get_json()
    assert st["place"] == "analysis" and st["project"] == pid
    # the same session as the analysis's own route: one question asked here is in both
    c.post("/api/agents/terminal", json={"upload": "up-of-s08", "question": "from the tree page", "admin": "Sagar"})
    wait_place(c, "?upload=up-of-s08")
    assert [t["asked"] for t in c.get("/api/agents/projects/%d/investigate" % pid).get_json()["conversation"]] == ["from the tree page"]


def test_a_page_without_an_analysis_asks_the_applications_session_and_says_where_the_admin_is(site):
    from agentic import family1
    app, c, s, eng, pid, data, d = site
    page = {"path": "/nvme-rules", "address": "/nvme-rules?x=1#top", "title": "NVMe command rules", "heading": "Command\ntimeout\x07 rule " + "z" * 400,
            "upload": "", "finding": "", "item": {"not": "text"}, "unknown": "left out"}
    r = c.post("/api/agents/terminal", json={"question": "Which rules read the tree?", "admin": "Sagar", "page": page})
    assert r.status_code == 200 and r.get_json()["started"] is True and r.get_json()["place"] == "application"
    st = wait_place(c, "")
    assert st["last_error"] is None and st["session"]["name"] == "application · terminal agent" and st["session"]["turns"] == 1
    t = st["conversation"][0]
    assert t["asked"] == "Which rules read the tree?" and t["ok"] is True and t["page"].startswith("Page: /nvme-rules — the page of the rules that find an error")
    call = fake_calls(d)[-1]
    args = call["args"]
    box = os.path.join(eng.runner.sandbox_root, "investigation_app")
    assert call["cwd"] == box and args[args.index("--agent") + 1] == "f2t-investigate" and args[args.index("--title") + 1] == "application terminal agent"
    perm = json.loads(call["config"])["agent"]["f2t-investigate"]["permission"]["external_directory"]
    assert perm[family1.knowledge_dir() + "/*"] == "allow" and perm[os.path.join(APP, "docs") + "/*"] == "allow" and perm["*"] == "deny"
    assert not any(k.startswith(data) for k in perm), "the application's place was given an analysis's data folder"
    sent = prompt_sent(d)
    assert "WHERE THE ADMINISTRATOR IS NOW" in sent and "Address in the browser: /nvme-rules?x=1#top." in sent and "Title of the page: NVMe command rules." in sent
    assert "Heading on the screen: Command timeout rule zzz" in sent and "z" * 201 not in sent and "left out" not in sent      # one short line each, known names only
    assert sent.index("WHERE THE ADMINISTRATOR IS NOW") < sent.index("THE ADMINISTRATOR ASKS:\nWhich rules read the tree?")
    text = open(os.path.join(box, "ANALYSIS.md"), encoding="utf-8").read()
    assert text.startswith("# The application: no analysis is open on the page") and "| %d | S08 | `%s` | no |" % (pid, data) in text and "rules/" in text
    # a page that is not a set of named fields is refused; a file of the application's place cannot be added to an analysis
    assert c.post("/api/agents/terminal", json={"question": "x", "page": "the start page"}).status_code == 400
    os.makedirs(os.path.join(box, "exports"), exist_ok=True)
    with open(os.path.join(box, "exports", "list.csv"), "w", encoding="utf-8") as fh:
        fh.write("a\n1\n")
    assert [e["name"] for e in c.get("/api/agents/terminal").get_json()["exports"]] == ["list.csv"]
    assert c.get("/api/agents/terminal/exports/list.csv").data == b"a\n1\n" and c.get("/api/agents/terminal/exports/..%2Fx").status_code == 404
    r = c.post("/api/agents/terminal/exports/list.csv/add", json={})
    assert r.status_code == 400 and "no analysis is open on this page" in r.get_json()["error"]
    # the two places keep their conversations apart
    assert c.get("/api/agents/terminal?pid=%d" % pid).get_json()["conversation"] == []


def test_a_page_that_shows_a_built_tree_gives_the_agent_the_tree(site):
    import sqlite3
    from agentic import procedures as PR
    app, c, s, eng, pid, data, d = site
    up = "up-tree-of-s08"
    folder = PR.upload_folder(up)
    os.makedirs(folder)
    con = sqlite3.connect(os.path.join(folder, "hier.sqlite"))
    con.execute('CREATE TABLE nvme_command (id INTEGER, sqid INTEGER, "Cmd Status" TEXT)')
    con.execute("CREATE TABLE link_txn (id INTEGER, psn INTEGER)")
    con.commit()
    con.close()
    with open(os.path.join(folder, "meta.json"), "w", encoding="utf-8") as fh:
        json.dump({"status": "loaded", "files": {}}, fh)
    try:
        # no tree named by the page or kept with the analysis: no note, only the data folder
        c.post("/api/agents/terminal", json={"pid": pid, "question": "first", "admin": "Sagar", "page": {"path": "/"}})
        wait_place(c, "?pid=%d" % pid)
        box = os.path.join(eng.runner.sandbox_root, "investigation_p%d" % pid)
        perm = json.loads(fake_calls(d)[-1]["config"])["agent"]["f2t-investigate"]["permission"]["external_directory"]
        assert not os.path.exists(os.path.join(box, "TREE.md")) and folder + "/*" not in perm and perm[data + "/*"] == "allow"
        # the page of one error of that recording
        c.post("/api/agents/terminal", json={"pid": pid, "question": "why did this error happen?", "admin": "Sagar",
                                             "page": {"path": "/isolate", "address": "/isolate?upload=%s&finding=38" % up, "upload": up, "finding": "38"}})
        st = wait_place(c, "?pid=%d" % pid)
        assert st["last_error"] is None and st["conversation"][-1]["page"].startswith("Page: /isolate — the page of one error")
        note = open(os.path.join(box, "TREE.md"), encoding="utf-8").read()
        assert os.path.join(folder, "hier.sqlite") in note and "mode=ro" in note and "- `nvme_command`: `id`, `sqid`, `Cmd Status`" in note and "- `link_txn`: `id`, `psn`" in note
        perm = json.loads(fake_calls(d)[-1]["config"])["agent"]["f2t-investigate"]["permission"]["external_directory"]
        assert perm[folder + "/*"] == "allow" and perm[data + "/*"] == "allow"
        sent = prompt_sent(d)
        assert "Error on the page (finding number): 38." in sent and "The tree of the recording %s is built: read `TREE.md`" % up in sent
        # kept with the analysis: the tree is given from any page of it
        eng.store.exec("UPDATE project SET upload_id=? WHERE id=?", (up, pid))
        os.remove(os.path.join(box, "TREE.md"))
        c.post("/api/agents/terminal", json={"pid": pid, "question": "third", "admin": "Sagar"})
        wait_place(c, "?pid=%d" % pid)
        assert os.path.exists(os.path.join(box, "TREE.md"))
        # an upload number that is not a plain name names no tree
        from agentic import investigate as INV
        assert INV.tree_of({}, {"upload": "../../etc"}) == (None, None) and INV.tree_of({}, {"upload": ["x"]}) == (None, None)
    finally:
        shutil.rmtree(folder, ignore_errors=True)


def test_where_the_admin_is_is_made_of_short_lines_only():
    from agentic import investigate as INV
    assert INV.page_words(None) == "" and INV.page_words("a page") == "" and INV.page_words({}) == ""
    w = INV.page_words({"path": "/isolate", "finding": 38, "heading": "  3 ·\tIsolation\r\nof the defect  ", "title": "x" * 500})
    assert w.split("\n") == ["Page: /isolate — the page of one error (the commands around it, isolation of the defect, the procedural graph, the solution, the test case).",
                             "Title of the page: %s." % ("x" * 160), "Heading on the screen: 3 · Isolation of the defect.", "Error on the page (finding number): 38."]
    assert INV.page_words({"path": "/somewhere/else"}) == "Page: /somewhere/else."
