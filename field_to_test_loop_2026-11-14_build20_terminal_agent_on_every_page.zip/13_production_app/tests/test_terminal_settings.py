"""Settings: "opencode in a terminal" with the model chosen from the program's own list, for every part of the
application; the held sessions and their conversations over the API (owner, 2026-11-13). The program is the tests' own
stand-in (tests/fake_opencode.py); every test works in a temporary copy of the application."""
import json
import os
import shutil
import sys
import tempfile
import urllib.request

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

FAKE = os.path.join(HERE, "fake_opencode.py")
if os.name == "nt":      # the stand-in program is a script started by its first line, which Windows does not do
    pytestmark = pytest.mark.skip(reason="the stand-in opencode program of these tests is started as a script; not on Windows")
elif not os.access(FAKE, os.X_OK):
    os.chmod(FAKE, 0o755)       # a zip unpacked without file modes
NAMES = ("ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", "FAKE_OPENCODE_HOME", "FAKE_OPENCODE_ANSWER")


@pytest.fixture
def site(monkeypatch):
    import fuzz_app as F
    from agentic import opencode_cli as oc
    if not os.path.isdir(F.BASE):
        pytest.skip("the S08 sample recording is not on this machine (the code-only zip carries no samples)")
    was = {k: os.environ.get(k) for k in NAMES}
    d = tempfile.mkdtemp(prefix="term_set_%d_" % os.getpid())
    os.environ["FAKE_OPENCODE_HOME"] = os.path.join(d, "fake_home")
    os.environ["FAKE_OPENCODE_ANSWER"] = '{"ok": "yes"}'
    oc.forget_models()
    root = os.path.join(d, "app")
    os.makedirs(root)
    app, c, _k, _r = F.setup(root)
    s = app.config["services"]
    s.cfg.setdefault("agentic", {}).update(runtime="http", opencode_path=FAKE)
    s.cfg["agentic"].pop("opencode_model", None)
    s.cfg.setdefault("llm", {})["backend"] = "http"
    s.cfg.setdefault("server", {})["lock_endpoint"] = False

    def no_network(*a, **k):
        raise AssertionError("a model address was called while opencode is chosen")
    try:
        yield app, c, s, root, no_network
    finally:
        oc.forget_models()
        for k, v in was.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        shutil.rmtree(d, ignore_errors=True)


def saved(root):
    return json.load(open(os.path.join(root, "config", "app_config.json"), encoding="utf-8"))


def test_settings_offer_the_programs_own_models_and_choose_none(site):
    _app, c, _s, _root, _ = site
    o = c.get("/api/agents/settings").get_json()["opencode"]
    assert o["found"] == FAKE and o["version"] == "9.9.9-fake" and o["problem"] == "" and o["model"] == "" and o["model_offered"] is False
    assert [m["id"] for m in o["models"]] == ["fake/alpha-free", "fake/beta-paid", "other/gamma"]
    assert o["models"][0]["free"] is True and o["models"][1]["cost_in"] == 2 and o["models"][0]["variants"] == ["low", "high", "max"]
    assert c.get("/api/agents/opencode/models?refresh=1").get_json()["models"][2]["provider"] == "other"


def test_opencode_needs_a_model_of_the_list_and_a_refusal_changes_nothing(site):
    _app, c, s, root, _ = site
    r = c.put("/api/agents/settings", json={"runtime": "opencode"})
    assert r.status_code == 400 and "choose the model opencode should use" in r.get_json()["error"]
    assert s.cfg["agentic"]["runtime"] == "http"
    r = c.put("/api/agents/settings", json={"runtime": "opencode", "opencode_model": "fake/not-there"})
    assert r.status_code == 400 and "does not offer the model fake/not-there" in r.get_json()["error"]
    assert s.cfg["agentic"]["runtime"] == "http" and s.cfg["llm"]["backend"] == "http"
    assert c.put("/api/agents/settings", json={"runtime": "nonsense"}).status_code == 400
    assert c.put("/api/agents/settings", json={"opencode_model": 7}).status_code == 400


def test_choosing_opencode_moves_every_part_to_the_terminal_and_back(site, monkeypatch):
    app, c, s, root, no_network = site
    from api import hier_api as H
    from nvme_hier import isolate as ISO
    with app.app_context():
        from api import agentic_api as A
        A.engine()
    r = c.put("/api/agents/settings", json={"runtime": "opencode", "opencode_model": "fake/beta-paid"})
    assert r.status_code == 200, r.get_json()
    body = r.get_json()
    assert body["runtime"] == "opencode" and body["opencode_model"] == "fake/beta-paid" and body["opencode"]["model_offered"] is True
    assert body["calls"]["path"] == "opencode"
    disk = saved(root)
    assert disk["agentic"]["runtime"] == "opencode" and disk["agentic"]["opencode_model"] == "fake/beta-paid"
    assert disk["llm"]["backend"] == "opencode" and disk["llm"]["opencode_model"] == "fake/beta-paid"
    run = s.agentic_engine.runner
    assert run.runtime == "opencode" and run.opencode_model == "fake/beta-paid" and run.sessions is not None
    assert s.s2.llm.name == "opencode:fake/beta-paid" and ISO.is_model(s.s2.llm)
    assert c.get("/api/hier/model").get_json()["active"] == "opencode:fake/beta-paid"
    # Save and test: both parts answer through the program; no model address is called by the application
    monkeypatch.setattr(urllib.request, "urlopen", no_network)
    os.environ["ANTHROPIC_API_KEY"] = "sk-test-not-a-key"
    t = c.post("/api/hier/model/test", json={}).get_json()
    assert t["ok"] is True and t["producer"] == "opencode:fake/beta-paid", t
    assert t["agents"]["ok"] is True and t["agents"]["runtime"] == "opencode" and "Beta Paid" in t["agents"]["words"] and "is kept" in t["agents"]["words"]
    assert t["address"].startswith("the opencode program in a terminal")
    # the isolation pages' call goes the same way, and its answer is the program's
    got, who = ISO.call_model(H.svc and s.s2.llm, "Say yes.", {"type": "object", "properties": {"ok": {"type": "string"}}, "required": ["ok"]}, "ok")
    assert got == {"ok": "yes"} and who == "opencode:fake/beta-paid"
    # every one of these questions is a named session with its question and its answer
    lst = c.get("/api/agents/sessions").get_json()
    assert lst["counts"]["sessions"] == 3 and lst["counts"]["turns"] == 3
    names = sorted(x["name"].split(" 20")[0] for x in lst["sessions"])
    assert names == ["connection test", "model connection", "model connection"]
    one = c.get("/api/agents/sessions/%d" % lst["sessions"][0]["id"]).get_json()
    assert one["conversation"][0]["ok"] is True and one["conversation"][0]["answered"] == '{"ok": "yes"}' and one["terminal_id"].startswith("ses_fake")
    assert c.get("/api/agents/sessions/99999").status_code == 404
    # another model: the other pages follow at once
    assert c.put("/api/agents/settings", json={"opencode_model": "other/gamma"}).status_code == 200
    assert s.s2.llm.name == "opencode:other/gamma" and saved(root)["llm"]["opencode_model"] == "other/gamma"
    # back to the Model connection: the other pages go back too
    assert c.put("/api/agents/settings", json={"runtime": "http"}).status_code == 200
    assert saved(root)["llm"]["backend"] == "http" and s.cfg["llm"]["backend"] == "http" and not s.s2.llm.name.startswith("opencode")
    assert s.agentic_engine.runner.runtime == "http"


def test_a_failing_program_is_said_with_its_reason_and_a_hint(site):
    _app, c, _s, root, _ = site
    assert c.put("/api/agents/settings", json={"runtime": "opencode", "opencode_model": "fake/beta-paid"}).status_code == 200
    os.makedirs(os.environ["FAKE_OPENCODE_HOME"], exist_ok=True)
    with open(os.path.join(os.environ["FAKE_OPENCODE_HOME"], "fail.json"), "w") as f:
        json.dump({"times": 99, "silent": True, "message": "Free usage limit reached. Subscribe to keep going"}, f)
    from agentic import core
    old = core.AgentRunner.TERMINAL_WAITS
    core.AgentRunner.TERMINAL_WAITS = (0.05, 0.05)
    try:
        t = c.post("/api/hier/model/test", json={}).get_json()
    finally:
        core.AgentRunner.TERMINAL_WAITS = old
    assert t["ok"] is False and "Free usage limit reached" in t["error"] and "free use is used up" in t["hint"]
    assert t["agents"]["ok"] is False and "Free usage limit reached" in t["agents"]["words"] and "choose another model" in t["agents"]["hint"]


def test_with_the_endpoint_locked_the_way_to_the_model_is_not_switched_in_settings(site):
    _app, c, s, _root, _ = site
    s.cfg["server"]["lock_endpoint"] = True
    r = c.put("/api/agents/settings", json={"runtime": "opencode", "opencode_model": "fake/beta-paid"})
    assert r.status_code == 403 and "locked by server.lock_endpoint" in r.get_json()["error"] and s.cfg["agentic"]["runtime"] == "http"
    assert c.put("/api/agents/settings", json={"opencode_path": "/tmp/other"}).status_code == 403
    s.cfg["agentic"].update(runtime="opencode", opencode_model="fake/beta-paid")       # set in the configuration file by the operator
    assert c.put("/api/agents/settings", json={"opencode_model": "other/gamma"}).status_code == 200    # choosing among its models stays open
    assert c.put("/api/agents/settings", json={"runtime": "http"}).status_code == 403


def test_a_deleted_analysis_takes_its_sessions_with_it_and_a_new_run_inherits_none(site):
    app, c, s, _root, _ = site
    assert c.put("/api/agents/settings", json={"runtime": "opencode", "opencode_model": "fake/beta-paid"}).status_code == 200
    eng = s.agentic_engine
    S = eng.runner.sessions
    pid = eng.store.exec("INSERT INTO project (name, admin, created) VALUES (?,?,?)", ("to delete", "tester", "2026-11-13"))
    rid = eng.store.exec("INSERT INTO run (project, kind, target, params, state, created, updated, heartbeat) VALUES (?,?,?,?,?,?,?,?)",
                         (pid, "flow", "", "{}", "finished", "t", "t", "t"))
    a, who, _ = eng.runner.ask(rid, "coder", "HOW MANY TURNS", "ctx", '{"ok": true}', "ok", lambda: {"ok": "stand-in"})
    eng.runner.ask("chat_p%d" % pid, "chat_data", "HOW MANY TURNS", "ctx", '{"ok": true}', "ok", lambda: {"ok": "stand-in"})
    assert "opencode in a terminal" in who and len(S.listing("run:%s" % rid)) == 1 and len(S.listing("run:chat_p%d" % pid)) == 1
    assert c.get("/api/agents/sessions?run=%d" % rid).get_json()["sessions"][0]["name"] == "run %d · coder" % rid
    r = c.delete("/api/agents/projects/%d" % pid, json={"admin": "tester"})
    assert r.status_code == 200, r.get_json()
    assert S.listing("run:%s" % rid) == [] and S.listing("run:chat_p%d" % pid) == []
    # a session left behind under a run number (an older version, a crash) is not inherited by the run that gets the number
    sid = S.begin("run:%d" % rid, "coder", "old", "opencode", "fake/beta-paid")
    S.set_terminal(sid, "ses_fake000001")
    S.add_turn(sid, "old question", "old answer")
    S2 = eng.runner.sessions
    S2.delete_scope("run:%d" % rid)
    assert S.recent_turns("run:%d" % rid, "coder") == []


# ------------------------------------------------------------------------------------------- API calls switched off
# (owner, 2026-11-13: "Api calls are strictly not allowed. So need to modify the program to use only the terminal sessions call")
@pytest.fixture
def strict(site, monkeypatch):
    app, c, s, root, no_network = site
    s.cfg["server"]["api_calls"] = False
    s.cfg["agentic"].update(runtime="claude-code", opencode_model="fake/beta-paid")       # a configuration of an earlier version
    s.cfg["llm"]["backend"] = "http"
    s.agentic_engine = None             # built again under the switch, as at a start
    s.s2.reload_llm()
    os.environ["ANTHROPIC_API_KEY"] = "sk-test-not-a-key"
    monkeypatch.setattr(urllib.request, "urlopen", no_network)
    return app, c, s, root


def test_api_calls_are_on_unless_the_configuration_file_says_false():
    from agentic import policy
    assert policy.api_allowed({}) is True and policy.api_allowed(None) is True and policy.api_allowed({"server": {}}) is True
    assert policy.api_allowed({"server": {"api_calls": True}}) is True and policy.api_allowed({"server": {"api_calls": "false"}}) is True
    assert policy.api_allowed({"server": {"api_calls": False}}) is False
    off = {"server": {"api_calls": False}}
    assert policy.runtime_for(off, "claude-code") == "opencode" and policy.runtime_for(off, "http") == "opencode"
    assert policy.runtime_for(off, "standin") == "standin" and policy.runtime_for({}, "http") == "http"
    shipped = json.load(open(os.path.join(APP, "config", "app_config.json"), encoding="utf-8"))
    assert shipped["server"]["api_calls"] is True, "the owner's word of 2026-11-13 (night): API calls are fine"


def test_with_api_calls_off_every_part_runs_through_the_terminal_whatever_the_configuration_says(strict):
    app, c, s, root = strict
    from nvme_hier import isolate as ISO
    st = c.get("/api/agents/settings").get_json()
    assert st["api_calls"] is False and st["runtime"] == "opencode"                 # claude-code in the file is run as opencode
    assert c.get("/api/hier/model").get_json()["api_calls"] is False
    with app.app_context():
        from api import agentic_api as A
        eng = A.engine()
    r = eng.runner
    assert r.api_allowed is False and r.runtime == "opencode" and r.path_now() == "opencode"
    assert s.s2.llm.name == "opencode:fake/beta-paid"                                # http in the file is run as opencode
    # the agents, the other pages and the connection test: all answered by the program, and no model address was called
    a, who, _ = r.ask(77, "coder", "HOW MANY TURNS", "ctx", '{"ok": true}', "ok", lambda: {"ok": "stand-in"})
    assert "opencode in a terminal" in who
    got, who2 = ISO.call_model(s.s2.llm, "Say yes.", {"type": "object", "properties": {"ok": {"type": "string"}}, "required": ["ok"]}, "ok")
    assert got == {"ok": "yes"} and who2.startswith("opencode:")
    t = c.post("/api/hier/model/test", json={}).get_json()
    assert t["ok"] is True and t["agents"]["ok"] is True and t["agents"]["runtime"] == "opencode", t
    # a caller that names another runtime gets the terminal too
    a, who, _ = r.ask(77, "other", "x", "ctx", '{"ok": true}', "ok", lambda: {"ok": "stand-in"}, runtime="http")
    assert "opencode in a terminal" in who
    a, who, _ = r.ask(77, "third", "x", "ctx", '{"ok": true}', "ok", lambda: {"ok": "stand-in"}, runtime="standin")
    assert who == "stand-in (no model)"
    # the application's key never reaches the program
    import fake_opencode  # noqa: F401  (only to find its folder)
    calls = [json.loads(x) for x in open(os.path.join(os.environ["FAKE_OPENCODE_HOME"], "calls.jsonl"), encoding="utf-8")]
    assert calls and all("ANTHROPIC" not in json.dumps(x.get("switches")) for x in calls)
    from agentic import opencode_cli as oc
    env = oc.environment({"ANTHROPIC_API_KEY": "k", "ANTHROPIC_AUTH_TOKEN": "t", "ANTHROPIC_BASE_URL": "u", "PATH": "/usr/bin"})
    assert not any(k.startswith("ANTHROPIC") for k in env)


def test_with_api_calls_off_nothing_in_the_application_can_switch_them_on(strict):
    _app, c, s, root = strict
    from agentic import policy
    for rt in ("http", "claude-code"):
        r = c.put("/api/agents/settings", json={"runtime": rt})
        assert r.status_code == 400 and r.get_json()["error"] == policy.NOT_ALLOWED, r.get_json()
    assert c.put("/api/agents/settings", json={"runtime": "standin"}).status_code == 200
    assert c.put("/api/agents/settings", json={"runtime": "opencode"}).status_code == 200
    assert saved(root)["agentic"]["runtime"] == "opencode" and saved(root)["llm"]["backend"] == "opencode"
    r = c.put("/api/hier/model", json={"base_url": "https://gateway.example.test", "model": "m", "key": "sk-test-key-abcdefgh1234"})
    assert r.status_code == 403 and "API calls are not allowed" in r.get_json()["error"]
    assert os.environ.get("ANTHROPIC_BASE_URL") != "https://gateway.example.test" and s.cfg["llm"].get("base_url") != "https://gateway.example.test"
    r = c.put("/api/config", json={"llm": {"backend": "http"}})
    assert r.status_code == 403 and s.cfg["llm"]["backend"] == "opencode"
    assert c.put("/api/config", json={"server": {"api_calls": True}}).status_code == 200 and s.cfg["server"]["api_calls"] is False    # not a section Settings can write
    assert c.put("/api/agents/settings", json={"api_calls": True}).status_code == 200 and policy.api_allowed(s.cfg) is False
    assert "api_calls" not in saved(root)["agentic"]
    # leaving opencode for the stand-in does not put the other pages on the Model connection
    assert c.put("/api/agents/settings", json={"runtime": "standin"}).status_code == 200 and s.cfg["llm"]["backend"] == "opencode"


def test_the_kept_api_code_refuses_when_the_switch_is_off(tmp_path, monkeypatch):
    from agentic import core, policy
    import stage1_runner as R

    def no_network(*a, **k):
        raise AssertionError("a model address was called")
    monkeypatch.setattr(urllib.request, "urlopen", no_network)
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test-not-a-key")
    r = core.AgentRunner(str(tmp_path / "sb"), runtime="http", http_model="m", api_allowed=False, opencode_path=str(tmp_path / "none"), opencode_model=None)
    with pytest.raises(RuntimeError, match="API calls are not allowed"):
        r._http_call("x")
    with pytest.raises(RuntimeError, match="API calls are not allowed"):
        r._claude_code("x", str(tmp_path))
    a, who, _ = r.ask(1, "a", "x", "ctx", '{"ok": true}', "ok", lambda: {"ok": "stand-in"})
    assert a == {"ok": "stand-in"} and "http" not in who.split("(after:")[1].split("opencode failed")[0] and "opencode failed" in who
    assert R.llm_backend({"backend": "http", "api_calls": False}) == "dry-run" and R.llm_backend({"backend": "sdk", "api_calls": False}) == "dry-run"
    assert R.llm_backend({"backend": "cli", "api_calls": False}) == "dry-run"
    assert policy.NOT_ALLOWED.startswith("API calls are not allowed in this application")
