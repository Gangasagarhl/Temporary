"""Stage 2 as a choice, any CSV as input, REA read once, and a finished analysis opened again (owner, 2026-11-12).

What must hold:
  1. any CSV files can be analysed: a folder without the analyzer's five exports is accepted; the fixed joining strategy
     is an option, refused with its reason when it cannot build the files, and never chosen for the admin when it cannot;
  2. "go on without stage 2" skips Family 2 and the flow goes to the rules; a rule that reads the tree cannot run there
     and is never run quietly; "go to stage 2" starts Family 2;
  3. REA is not a step of the flow (since 14 November 2026): a flow has no REA step, and one left in an earlier run is
     passed over at once (the REA agent of the start page is tested in tests/test_rea_agent.py);
  4. a flow that is not working can be opened again at a stage: the decisions from there on are asked again, what was
     computed is kept (the tree's tests while the tree is the same; an item while its rule, code and data are the same),
     and only what is new runs.

No server and no model: an engine on its own store in a temporary folder."""
import json
import os
import sys
import time
import types

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from agentic import admin_ask, core, family1, family2, family3, pipeline, procedures as PR  # noqa: E402
from test_admin_ask import COMMANDS, PACKETS, Flow, _inventory  # noqa: E402


def decide(flow, decision="approve", edits=None, comment=""):
    flow.eng.decide(flow.review["id"], decision, "Sagar", comment, edits)


def gate_out(flow):
    return json.loads(flow.step()["output"])


def f2(flow):
    return [s for s in flow.steps() if s["family"] == "2"]


@pytest.fixture
def flow(tmp_path, monkeypatch):
    return Flow(tmp_path, monkeypatch)


@pytest.fixture
def plain(tmp_path, monkeypatch):
    """An analysis of CSV files that are not analyzer exports at all."""
    return Flow(tmp_path, monkeypatch, files={"lab_notes.csv": PACKETS, "bench_log.csv": COMMANDS})


# ---------------------------------------------------------------------------------------------- 1. any CSV; the fixed strategy is an option
def test_a_folder_without_the_five_exports_is_an_analysis(plain):
    files = _inventory(plain.folder)
    assert family1.input_problem(files) is None                       # it can be analysed
    assert "none of the CSV files" in family1.folder_problem(files)    # ... it only cannot be built into the tree
    s2 = json.loads(plain.review["data"])["stage2"]
    assert s2["fixed_possible"] is False and "none of the CSV files" in s2["fixed_problem"]
    assert s2["levels_here"] == [] and sorted(s2["other_files"]) == ["bench_log.csv", "lab_notes.csv"]
    assert "cannot build these files" in plain.review["body"] and "Go on without stage 2" in plain.review["body"]


def test_two_files_of_one_kind_are_still_refused(tmp_path):
    files = [{"name": "packets.csv", "level": "packets"}, {"name": "run2_packets.csv", "level": "packets"}, {"name": "notes.csv", "level": None}]
    assert "more than one file of the same kind" in family1.input_problem(files)
    assert family1.input_problem([{"name": "a.csv", "level": None}, {"name": "b.csv", "level": None}]) is None


def test_the_fixed_strategy_is_never_chosen_when_it_cannot_build_the_files(plain):
    for edits in (None, {}, {"stage2": "fixed"}):
        with pytest.raises(ValueError) as e:
            decide(plain, "approve", edits)
        assert "cannot build these files into a tree" in str(e.value)
        assert plain.step()["state"] == "needs_review" and plain.store.one("SELECT state FROM review WHERE id=?", (plain.review["id"],))["state"] == "open"
    assert all(s["state"] == "waiting" for s in f2(plain))
    with pytest.raises(ValueError):
        decide(plain, "approve", {"stage2": "whatever"})


def test_going_on_without_stage_2_skips_family_2_and_reaches_the_rules(plain):
    decide(plain, "approve", {"stage2": "skip"})
    assert all(s["state"] == "skipped" and s["note"] == admin_ask.F2_SKIP_NOTE for s in f2(plain))
    assert gate_out(plain)["stage2"] == "skipped" and gate_out(plain)["stage2_by"] == "Sagar"
    assert plain.next_step() == "f3_plan"


def test_go_to_stage_2_starts_family_2(flow):
    s2 = json.loads(flow.review["data"])["stage2"]
    assert s2["fixed_possible"] is True and [x["level"] for x in s2["levels_here"]] == ["packets", "nvme_command"]
    assert len(s2["levels_missing"]) == 3 and any("link" in x.lower() for x in s2["levels_missing"])
    decide(flow, "approve", {"stage2": "fixed"})
    assert flow.next_step() == "last_strategy" and gate_out(flow)["stage2"] == "fixed"
    assert all(s["state"] == "waiting" for s in f2(flow))


def test_an_approval_that_names_no_choice_means_the_tree_when_it_can_be_built(flow):
    decide(flow, "approve")                 # a request made before the choice existed
    assert flow.next_step() == "last_strategy" and gate_out(flow)["stage2"] == "fixed"


def test_the_card_counts_the_rules_that_read_the_tree(flow):
    s2 = json.loads(flow.review["data"])["stage2"]
    r = s2["rules"]
    assert len(r["read_the_tree"]) >= 1                                 # the detector's items walk the tree
    assert "read the tree" in flow.review["body"] or "reads the tree" in flow.review["body"]


# ---------------------------------------------------------------------------------------------- 2. without a tree: what can run
def run_plan(flow):
    run = flow.store.one("SELECT * FROM run WHERE id=?", (flow.rid,))
    flow.eng._run_step(run, flow.step("f3_plan"))
    st = flow.step("f3_plan")
    assert st["state"] == "needs_review", st.get("error")
    return flow.store.one("SELECT * FROM review WHERE run=? AND state='open' ORDER BY id DESC", (flow.rid,))


def test_without_a_tree_an_item_that_reads_the_tree_is_blocked_and_never_run_quietly(flow):
    decide(flow, "approve", {"stage2": "skip"})
    rv = run_plan(flow)
    items = json.loads(rv["data"])["items"]
    blocked = [i for i in items if i["blocked"]]
    assert blocked and all(not i["selected"] for i in blocked)
    assert any(i["section"] == "errors" for i in blocked)               # the detector's error rules need the tree
    assert "This analysis has no tree" in rv["body"]
    with pytest.raises(ValueError) as e:
        flow.eng.decide(rv["id"], "approve", "Sagar", "", {"selected": [blocked[0]["key"]]})
    assert "reads the tree" in str(e.value)
    assert not [k for k in flow.keys() if k.startswith("f3:")]           # nothing of it was planned


def test_a_procedure_may_name_any_csv_of_the_folder_but_never_a_path():
    ok = {"source_data": [{"file": "bench_log.csv", "columns": ["Latency"]}], "steps": ["count the rows"], "output": {"columns": ["count"], "order": ""}}
    assert PR.validate(ok)["source_data"][0]["file"] == "bench_log.csv"
    for bad in ("../bench_log.csv", "a/b.csv", "C:\\x.csv", "notes.txt", ".hidden.csv", "", None, 7):
        with pytest.raises(ValueError):
            PR.validate(dict(ok, source_data=[{"file": bad, "columns": ["x"]}]))


def test_the_files_of_an_analysis_without_a_tree_are_the_folders_own(plain):
    paths = PR.recording_paths(None, plain.folder)
    assert sorted(paths) == ["bench_log.csv", "lab_notes.csv"] and PR.TREE not in paths
    assert all(os.path.dirname(p) == plain.folder for p in paths.values())
    assert "other" in family3.LEVELS and family3.ANALYZER_LEVELS == [lv for lv in family3.LEVELS if lv != "other"]
    assert [lv["level"] for lv in family3.tree()[0]["levels"]][-1] == "other"


def test_the_rule_writer_is_told_of_the_other_files_with_family_1s_meanings(plain):
    plain.approve_before("bench_log.csv")
    told = family3.other_files(plain.folder, PR.recording_paths(None, plain.folder))
    by = {f["file"]: f for f in told}
    assert set(by) == {"bench_log.csv", "lab_notes.csv"}
    assert {"name": "Command", "meaning": "the NVMe command the host sent"}.items() <= {k: v for k, v in by["bench_log.csv"]["columns"][0].items() if k != "real_values_seen"}.items()
    assert by["lab_notes.csv"]["columns"] == [] and "no data dictionary approved yet" in by["lab_notes.csv"]["level"]


# ---------------------------------------------------------------------------------------------- 3. REA: not a step of the flow
# (owner, 2026-11-14: "let's keep the rea out, because it is going to consume a lot of time") the REA agent on the start
# page reads the findings; its own tests are in tests/test_rea_agent.py
def test_the_flow_has_no_rea_step_and_family_2_never_reads_the_findings(flow, monkeypatch):
    assert not any(s["key"] in ("rea", "rea_search") for s in flow.steps())
    assert [s["key"] for s in f2(flow)][:3] == ["last_strategy", "collect", "coder"]
    assert "rea" not in [s["key"] for s in family2.steps({}, {})]


def test_a_rea_step_of_an_earlier_run_is_passed_over_at_once(flow, monkeypatch):
    rea = os.path.join(flow.root, "rea_findings")
    os.makedirs(rea)
    with open(os.path.join(rea, "decompiled_link.c.txt"), "w", encoding="utf-8") as fh:
        fh.write("if (pkt->PSN == expected_PSN) { join(link, pkt); }\n")
    flow.store.exec("UPDATE project SET rea=? WHERE id=?", (rea, flow.pid))
    last = max(s["idx"] for s in flow.steps())
    flow.store.exec("INSERT INTO step (run, idx, key, title, family, agent, state, needs_review, input) VALUES (?,?,?,?,?,?,?,?,?)",
                    (flow.rid, last + 1, "rea", "REA decompiler", "2", "REA decompiler", "waiting", 1, "{}"))

    def no_reading(*a, **k):
        raise AssertionError("the REA findings were read inside the flow")
    monkeypatch.setattr(core.References, "search", no_reading)
    monkeypatch.setattr(core.References, "docs", no_reading)
    run = flow.store.one("SELECT * FROM run WHERE id=?", (flow.rid,))
    flow.eng._run_step(run, flow.step("rea"))
    st = flow.step("rea")
    assert st["state"] == "skipped" and "not a step of the flow any more" in st["note"] and "start page" in st["note"]
    assert flow.store.one("SELECT COUNT(*) AS n FROM review r JOIN step s ON s.id = r.step WHERE s.key='rea'")["n"] == 0     # nobody is asked
    assert family2.rea_done(rea) is None                                    # ... and nothing was read


# ---------------------------------------------------------------------------------------------- 4. opened again
def finish(flow):
    flow.store.exec("UPDATE review SET state='approved' WHERE run=? AND state='open'", (flow.rid,))
    for s in flow.steps():
        if s["state"] not in ("done", "approved", "skipped"):
            flow.store.exec("UPDATE step SET state=? WHERE id=?", ("approved" if s["needs_review"] else "done", s["id"]))
    flow.store.exec("UPDATE run SET state='finished' WHERE id=?", (flow.rid,))


def states(flow):
    return {s["key"]: s["state"] for s in flow.steps()}


def test_a_working_flow_cannot_be_opened_again(flow):
    with pytest.raises(ValueError) as e:
        pipeline.reopen(flow.eng, flow.rid, "data", "Sagar")
    assert "still open" in str(e.value)
    finish(flow)
    with pytest.raises(ValueError):
        pipeline.reopen(flow.eng, flow.rid, "everything", "Sagar")


def test_opened_again_at_the_report_only_the_report_is_written_again(flow):
    finish(flow)
    back = pipeline.reopen(flow.eng, flow.rid, "report", "Meera")
    st = states(flow)
    assert [k for k, v in st.items() if v == "waiting"] == ["report"] and len(back) == 1
    run = flow.store.one("SELECT * FROM run WHERE id=?", (flow.rid,))
    params = json.loads(run["params"])
    assert run["state"] == "running" and params["reopened"][-1]["stage"] == "report" and params["started_by"] == "Meera"


def test_opened_again_at_the_data_the_step_after_family_1_asks_again_and_family_2_is_kept(flow):
    decide(flow, "approve", {"stage2": "fixed"})
    finish(flow)
    pipeline.reopen(flow.eng, flow.rid, "data", "Sagar")
    st = states(flow)
    assert st[admin_ask.GATE] == "waiting" and st["f3_plan"] == "waiting" and st["report"] == "waiting"
    assert all(st[s["key"]] in ("done", "approved") for s in f2(flow))             # the tree's steps are not put back
    assert all(v != "waiting" for k, v in st.items() if k.startswith(("explore:", "ground:", "manager:")))   # no file is read again
    assert flow.next_step() == admin_ask.GATE
    # the step asks again; what was asked on it before is still its conversation
    flow.open_gate()
    assert flow.review["state"] == "open"


def test_opened_again_at_the_tree_family_2_asks_again_and_the_earlier_choice_no_longer_holds(flow):
    decide(flow, "approve", {"stage2": "skip"})
    finish(flow)
    assert gate_out(flow)["stage2"] == "skipped"
    pipeline.reopen(flow.eng, flow.rid, "tree", "Sagar")
    st = states(flow)
    assert all(st[s["key"]] == "waiting" for s in f2(flow)) and st[admin_ask.GATE] == "approved"
    assert gate_out(flow)["stage2"] == "fixed" and flow.next_step() == "last_strategy"


def test_the_tree_stage_cannot_be_opened_for_files_the_fixed_strategy_cannot_build(plain):
    decide(plain, "approve", {"stage2": "skip"})
    finish(plain)
    with pytest.raises(ValueError) as e:
        pipeline.reopen(plain.eng, plain.rid, "tree", "Sagar")
    assert "cannot build these files" in str(e.value)
    assert plain.store.one("SELECT state FROM run WHERE id=?", (plain.rid,))["state"] == "finished"       # nothing changed


def test_a_flow_made_before_the_step_existed_gets_it_when_opened_again_at_the_data(flow):
    finish(flow)
    flow.store.exec("DELETE FROM step WHERE run=? AND key=?", (flow.rid, admin_ask.GATE))
    pipeline.reopen(flow.eng, flow.rid, "data", "Sagar")
    keys = flow.keys()
    g = keys.index(admin_ask.GATE)
    assert keys[g - 1].startswith("manager:") and keys[g + 1] == "last_strategy" and states(flow)[admin_ask.GATE] == "waiting"
    idx = [s["idx"] for s in flow.steps()]
    assert idx == sorted(set(idx))                                      # one place each, in order


def test_going_to_stage_2_again_keeps_the_tree_when_it_is_still_the_tree_of_these_files(flow, monkeypatch):
    decide(flow, "approve", {"stage2": "fixed"})
    finish(flow)
    flow.store.exec("UPDATE step SET output=? WHERE run=? AND key='build'", (json.dumps({"upload_id": "up-1", "reused": False}), flow.rid))
    facts = admin_ask.stage2_facts
    monkeypatch.setattr(admin_ask, "stage2_facts", lambda e, r, p: dict(facts(e, r, p), built_before={"upload_id": "up-1", "at": 1794000000.0}))
    pipeline.reopen(flow.eng, flow.rid, "data", "Sagar")
    flow.open_gate()
    decide(flow, "approve", {"stage2": "fixed"})
    assert all(s["state"] in ("done", "approved") for s in f2(flow))          # same tree: Family 2 is not run again
    assert flow.next_step() == "f3_plan"
    # ... but when the files' tree is another one now (a file was added or changed), Family 2 runs again
    finish(flow)
    monkeypatch.setattr(admin_ask, "stage2_facts", lambda e, r, p: dict(facts(e, r, p), built_before=None))
    pipeline.reopen(flow.eng, flow.rid, "data", "Sagar")
    flow.open_gate()
    decide(flow, "approve", {"stage2": "fixed"})
    assert all(s["state"] == "waiting" for s in f2(flow)) and flow.next_step() == "last_strategy"


def test_a_test_of_the_tree_is_kept_while_the_tree_is_the_same(monkeypatch):
    ran = []
    monkeypatch.setattr(family2, "_slice_test", lambda ctx: ran.append("slice_test") or core.Result({"upload_id": "up-2", "passed": 6, "of": 6}))
    old = {"upload_id": "up-1", "passed": 5, "of": 5}

    def ctx(build, comments=None):
        return types.SimpleNamespace(step={"key": "slice_test", "output": json.dumps(old)}, input={"comments": comments or []},
                                     output_of=lambda k: build if k == "build" else {})
    res = family2.run_step(ctx({"upload_id": "up-1", "reused": True}))
    assert res.skip.startswith("kept: the tree is the one this test checked before") and res.output == old and ran == []
    for build in ({"upload_id": "up-1", "reused": False}, {"upload_id": "up-2", "reused": True}, {}):     # built anew, or another tree
        ran.clear()
        assert family2.run_step(ctx(build)).skip is None and ran == ["slice_test"]


# ---- the rules: an item is kept while its rule, its code and the data are the same
def item_with_code(flow, name="rows per command"):
    r = family3.add_item("analytics", "nvme_command", name, "how many rows each command has", "Sagar")
    proc = {"source_data": [{"file": "nvme_command.csv", "columns": ["A"]}], "steps": ["count the rows of each A value"], "output": {"columns": ["A", "count"], "order": "count"}}
    r, _ = PR.store(r, proc, "Sagar")
    code = os.path.join(flow.root, "code_%s.py" % r["id"])
    with open(code, "w", encoding="utf-8") as fh:
        fh.write("def run(sources, out_csv):\n    pass\n")
    r["code"] = {"path": code, "procedure_sha": PR.sha(PR.procedure_of(r)), "procedure_version": r["procedure"]["version"], "verified_by": "Sagar", "verified_at": time.time()}
    family3.save_rule(r)
    return r, pipeline.item_key("analytics", "nvme_command", r["id"])


def ran_once(flow, r, k):
    """The item ran in this flow: its steps are there, finished, with an approved result."""
    plan = pipeline.item_steps("analytics", "nvme_command", r["id"], r["name"], False)
    flow.eng.insert_steps(flow.rid, flow.step("f3_plan")["idx"], plan)
    for s in plan:
        out = {"kind": "python", "upload_id": None, "procedure_version": r["procedure"]["version"], "code_file": r["code"]["path"], "rows": 3} if s["key"].endswith(":run") else {}
        flow.store.exec("UPDATE step SET state=?, output=?, started=? WHERE run=? AND key=?",
                        ("approved" if s.get("review") else "done", json.dumps(out), time.time() + 5, flow.rid, s["key"]))


def test_an_item_whose_rule_code_and_data_are_the_same_is_not_computed_again(flow):
    decide(flow, "approve", {"stage2": "skip"})
    r, k = item_with_code(flow)
    ran_once(flow, r, k)
    run = flow.store.one("SELECT * FROM run WHERE id=?", (flow.rid,))
    before = flow.keys()
    data = {"edits": {"selected": [k]}}
    plan, sel = pipeline._plan_steps(flow.eng, data, "Sagar", run=run)
    assert plan == [] and sel == [k] and "not computed again" in data["kept"][k]
    assert flow.keys() == before
    # the admin writes a change for it: a new round, with the Rule writer first
    data = {"edits": {"selected": [k], "edit": {k: "count only the Read commands"}}}
    plan, _ = pipeline._plan_steps(flow.eng, data, "Sagar", run=run)
    assert plan and all("#2:" in s["key"] for s in plan) and plan[0]["key"].endswith(":write") and data["kept"] == {}
    # its rule changed since it ran: it runs again (no Rule writer: the rule is already written)
    r2, _ = PR.store(family3.load_rule("analytics", "nvme_command", r["id"]), dict(PR.procedure_of(r), steps=["count the rows of each A value, blanks apart"]), "Sagar")
    family3.save_rule(r2)
    data = {"edits": {"selected": [k]}}
    plan, _ = pipeline._plan_steps(flow.eng, data, "Sagar", run=run)
    assert plan and all("#2:" in s["key"] for s in plan) and not plan[0]["key"].endswith(":write") and data["kept"] == {}


def test_an_item_runs_again_when_the_file_it_read_changed(flow):
    decide(flow, "approve", {"stage2": "skip"})
    r, k = item_with_code(flow)
    ran_once(flow, r, k)
    run = flow.store.one("SELECT * FROM run WHERE id=?", (flow.rid,))
    later = time.time() + 60
    os.utime(os.path.join(flow.folder, "nvme_command.csv"), (later, later))       # the file was written after the item read it
    data = {"edits": {"selected": [k]}}
    plan, _ = pipeline._plan_steps(flow.eng, data, "Sagar", run=run)
    assert plan and data["kept"] == {}


def test_an_item_new_to_the_flow_gets_its_first_round_beside_a_kept_one(flow):
    decide(flow, "approve", {"stage2": "skip"})
    r, k = item_with_code(flow)
    ran_once(flow, r, k)
    r_new, k_new = item_with_code(flow, "rows per queue")
    run = flow.store.one("SELECT * FROM run WHERE id=?", (flow.rid,))
    data = {"edits": {"selected": [k, k_new]}}
    plan, _ = pipeline._plan_steps(flow.eng, data, "Sagar", run=run)
    assert list(data["kept"]) == [k] and plan and all(s["key"].startswith("f3:%s:" % k_new) for s in plan)


# ---------------------------------------------------------------------------------------------- a run number that comes back
def test_a_new_run_is_not_refused_because_a_deleted_run_of_the_same_number_was_stopped(tmp_path, monkeypatch):
    """The database gives the number of a deleted last run to the next run. Stop + Delete of an analysis, then a new flow:
    the new run got the old number, and every model call of it was refused with "the run was stopped" (found 2026-11-13)."""
    monkeypatch.setattr(core.Engine, "kick", lambda eng, rid: None)
    monkeypatch.setattr(family1, "inventory", _inventory)
    store = core.Store(str(tmp_path / "db" / "agentic.sqlite"))
    runner = core.AgentRunner(str(tmp_path / "runs"), runtime="standin", web=False)
    eng = core.Engine(store, {"flow": pipeline}, runner)
    folder = tmp_path / "rec"
    folder.mkdir()
    (folder / "nvme_command.csv").write_text("A,B\n1,2\n")
    pid = store.exec("INSERT INTO project (name, folder, created) VALUES (?,?,?)", ("p", str(folder), time.time()))
    rid = eng.start(pid, "flow")
    eng.stop(rid, "Sagar")
    assert rid in runner.cancelled
    store.exec("DELETE FROM step WHERE run=?", (rid,))
    store.exec("DELETE FROM run WHERE id=?", (rid,))                    # the analysis is deleted
    again = eng.start(pid, "flow")
    assert again == rid                                                 # the number came back
    ans, producer, _ = runner.ask(again, "a", "i", {}, "{}", "x", lambda: {"x": 1})
    assert ans == {"x": 1}                                              # ... and the new run's call is answered, not refused
