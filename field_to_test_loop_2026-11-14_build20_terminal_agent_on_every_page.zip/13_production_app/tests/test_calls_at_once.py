"""Model calls at the same time, and which kind of row fills which column (owner, 2026-11-11: "look at the number of cores in the
laptop and do the calls simultaneously ... a Read command fills only the columns it needs, a Write only its own ... that special
status is also needed when extracting").

1. the places: how many calls run together comes from Settings or, when Settings leave it automatic, from the processor cores; a
   model service that answers "too many calls" (HTTP 429) gets half as many, and the number climbs back when calls go well again;
   a stopped run does not keep waiting for a place.
2. the kinds of row: code finds the column whose word says what kind of row a row is (nothing about the file is assumed) and
   counts, on every row, which kinds fill each column.
3. the reference documents: the fast search gives exactly the lines the line-by-line search gave.
No real model is called."""
import csv
import json
import os
import re
import stat
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from agentic import core, family1  # noqa: E402


# ---------------------------------------------------------------------------------------------- 1. the places
def test_the_places_halve_when_the_service_says_too_many_calls_and_climb_back():
    s = core.Slots(8)
    assert (s.ceiling, s.limit) == (8, 8)
    s.too_many()
    assert s.limit == 4 and s.refused == 1
    s.too_many()                                    # refusals that arrive together are one cut, not one each
    assert s.limit == 4 and s.refused == 2
    s._cut_at -= core.Slots.CUT_APART + 1           # ... a later one cuts again
    s.too_many()
    assert s.limit == 2
    for _ in range(2):                              # as many good calls in a row as it allows at once: one more
        s.went_well()
    assert s.limit == 3
    for _ in range(3 + 4 + 5 + 6 + 7):
        s.went_well()
    assert s.limit == 8                             # back at what Settings or the computer allow, never above
    s.went_well()
    assert s.limit == 8
    for _ in range(20):                             # never below one call
        s._cut_at = 0
        s.too_many()
    assert s.limit == 1


def test_the_number_can_change_while_calls_wait_and_a_lowered_one_stays_lowered():
    s = core.Slots(1)
    s.take()
    got = []
    t = threading.Thread(target=lambda: (s.take(), got.append(time.time())), daemon=True)
    t.start()
    time.sleep(0.3)
    assert not got and s.active == 1                # the second call waits for the only place
    s.set(2)                                        # Settings raise the number: the waiting call goes on at once
    t.join(3)
    assert got and s.active == 2 and s.most == 2
    s.give(), s.give()
    assert s.active == 0
    s.set(16)
    s.too_many()
    assert s.limit == 8
    s.set(32)                                       # a new number from Settings does not undo what the service's refusals lowered
    assert (s.ceiling, s.limit) == (32, 8)
    s.set(4)
    assert (s.ceiling, s.limit) == (4, 4)


def _fake_claude(tmp_path):
    exe = tmp_path / "claude"
    exe.write_text("#!/bin/sh\necho '{}'\n")
    os.chmod(exe, os.stat(exe).st_mode | stat.S_IEXEC)
    return str(exe)


def test_the_automatic_number_comes_from_the_processor_cores(monkeypatch, tmp_path):
    monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://127.0.0.1:9/company")            # a company address: the Model connection
    for cores, want in ((1, 4), (2, 4), (8, 16), (12, 24), (64, 32)):                # 2 per core, 4 to 32
        monkeypatch.setattr(core.os, "cpu_count", lambda c=cores: c)
        r = core.AgentRunner(str(tmp_path / "runs"), runtime="http", http_model="m")
        assert r.path_now() == "http" and r.calls_auto()[0] == want and r.calls_at_once() == want, (cores, r.calls_facts())
        assert "2 per processor core" in r.calls_auto()[1]
    monkeypatch.delenv("ANTHROPIC_BASE_URL")                                          # Claude Code: a program per call, 1 per core, 2 to 16
    exe = _fake_claude(tmp_path)
    monkeypatch.setattr(core, "_free_memory", lambda: 64 * 1024 ** 3)
    for cores, want in ((1, 2), (8, 8), (64, 16)):
        monkeypatch.setattr(core.os, "cpu_count", lambda c=cores: c)
        r = core.AgentRunner(str(tmp_path / "runs"), runtime="claude-code", claude_path=exe)
        assert r.path_now() == "claude-code" and r.calls_at_once() == want, (cores, r.calls_facts())
    monkeypatch.setattr(core, "_free_memory", lambda: 3 * core.AgentRunner.CLAUDE_CODE_BYTES * 2)      # room for 3 in half of the free memory
    r = core.AgentRunner(str(tmp_path / "runs"), runtime="claude-code", claude_path=exe)
    assert r.calls_at_once() == 3 and "free memory" in r.calls_auto()[1]
    monkeypatch.setattr(core, "_free_memory", lambda: None)                           # where free memory cannot be told (Windows): the cores decide
    monkeypatch.setattr(core.os, "cpu_count", lambda: 8)
    assert core.AgentRunner(str(tmp_path / "runs"), runtime="claude-code", claude_path=exe).calls_at_once() == 8


def test_a_number_in_settings_wins_over_the_automatic_one(monkeypatch, tmp_path):
    monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://127.0.0.1:9/company")
    monkeypatch.setattr(core.os, "cpu_count", lambda: 8)
    r = core.AgentRunner(str(tmp_path / "runs"), runtime="http", http_model="m", calls_at_once=6)
    assert r.calls_at_once() == 6 and r.calls_facts()["wanted"] == 6 and r.calls_facts()["auto"] == 16
    assert r.set_calls(40) == 40 and r.set_calls(1000) == core.AgentRunner.CALLS_MOST          # never above the most Settings accept
    assert r.set_calls(0) == 16 and r.set_calls("nonsense") == 16 and r.set_calls(None) == 16   # automatic again
    assert r.set_calls(-3) == 16


class _Service:
    """A stand-in Messages API: answers {"ok": "yes"} after a pause; the first `refuse` calls get HTTP 429 (too many calls)."""

    def __init__(self, pause=0.0, refuse=0):
        self.calls, self.now, self.most = 0, 0, 0
        lock, me = threading.Lock(), self

        class H(BaseHTTPRequestHandler):
            def do_POST(self):
                n = int(self.headers.get("content-length") or 0)
                body = json.loads(self.rfile.read(n) or b"{}")
                with lock:
                    me.calls += 1
                    me.now += 1
                    me.most = max(me.most, me.now)
                    no = me.calls <= refuse
                try:
                    if no:
                        data, code = b'{"type": "error", "error": {"type": "rate_limit_error", "message": "too many requests"}}', 429
                    else:
                        time.sleep(pause)
                        data, code = json.dumps({"id": "m", "type": "message", "role": "assistant", "model": body.get("model"),
                                                 "content": [{"type": "text", "text": '{"ok": "yes"}'}], "stop_reason": "end_turn",
                                                 "usage": {"input_tokens": 1, "output_tokens": 1}}).encode(), 200
                    self.send_response(code)
                    self.send_header("content-type", "application/json")
                    self.send_header("content-length", str(len(data)))
                    if no:
                        self.send_header("retry-after", "0")
                    self.end_headers()
                    self.wfile.write(data)
                finally:
                    with lock:
                        me.now -= 1

            def log_message(self, *a):
                pass

        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = "http://127.0.0.1:%d" % self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()


def _runner(monkeypatch, tmp_path, svc, calls):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test-calls-0000")
    monkeypatch.setenv("ANTHROPIC_BASE_URL", svc.url)
    monkeypatch.delenv("ANTHROPIC_AUTH_TOKEN", raising=False)
    return core.AgentRunner(str(tmp_path / "runs"), runtime="http", http_model="company-model-1", web=False, calls_at_once=calls, timeout=20)


def _ask(r, run=1, agent="a", on_start=None):
    return r.ask(run, agent, "say ok", {}, '{"ok": "yes"}', "ok", lambda: {"ok": "stand-in"}, on_start=on_start)


def test_a_service_that_says_too_many_calls_gets_fewer_calls_at_once_and_the_answer_still_comes(monkeypatch, tmp_path):
    svc = _Service(refuse=1)
    try:
        r = _runner(monkeypatch, tmp_path, svc, 8)
        ans, producer, _box = _ask(r)
        assert ans == {"ok": "yes"} and "company-model-1" in producer               # asked again after the refusal, by the same call
        assert r.slots.refused == 1 and r.slots.limit == 4 and r.calls_at_once() == 4 and r.calls_facts()["refused"] == 1
        for i in range(3):                                                          # four good calls in a row (the one above was the first)
            _ask(r, agent="b%d" % i)
        assert r.slots.limit == 5 and r.slots.ceiling == 8
    finally:
        svc.srv.shutdown()


def test_no_more_calls_run_together_than_the_number_and_each_says_when_it_starts(monkeypatch, tmp_path):
    svc = _Service(pause=0.3)
    try:
        r = _runner(monkeypatch, tmp_path, svc, 3)
        started, t0 = [], time.time()
        ts = [threading.Thread(target=_ask, args=(r, 1, "a%d" % i, lambda: started.append(time.time() - t0))) for i in range(12)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        assert svc.calls == 12 and 1 < svc.most <= 3 and r.slots.most == 3
        assert len(started) == 12 and sorted(started)[-1] > 0.6                     # the last ones started only when a place was free
    finally:
        svc.srv.shutdown()


def test_a_stopped_run_does_not_keep_waiting_for_a_place(monkeypatch, tmp_path):
    svc = _Service(pause=3.0)
    try:
        r = _runner(monkeypatch, tmp_path, svc, 1)
        out = {}
        a = threading.Thread(target=lambda: out.update(a=_ask(r, 1, "first")[0]))
        a.start()
        time.sleep(0.5)                                                             # run 1 holds the only place

        def second():
            t0 = time.time()
            try:
                _ask(r, 2, "second")
                out["b"] = "answered"
            except RuntimeError as e:
                out["b"], out["b_after"] = str(e), time.time() - t0
        b = threading.Thread(target=second)
        b.start()
        time.sleep(0.5)
        r.cancel(2)                                                                 # Stop: the waiting call leaves the queue
        b.join(5)
        assert out.get("b") == "the run was stopped" and out["b_after"] < 2.5, out
        a.join(10)
        assert out.get("a") == {"ok": "yes"} and svc.calls == 1                     # the stopped run never reached the model
    finally:
        svc.srv.shutdown()


# ---------------------------------------------------------------------------------------------- 2. which kind of row fills a column
def _commands_csv(path):
    """85 rows of four kinds. Read and Write fill the address and the length, Identify its own field, Flush none of them; a second
    data pointer is on half of the Read rows only; the command id and the status are on every row."""
    rows = []
    for i in range(85):
        kind = "Read" if i % 17 < 8 else "Write" if i % 17 < 14 else "Identify" if i % 17 < 16 else "Flush"
        io = kind in ("Read", "Write")
        reads = sum(1 for r in rows if r[1] == "Read")
        rows.append([str(i), kind, str(100 + i), "0x%08X" % (i * 8) if io else "", "8" if io else "", "0x01" if kind == "Identify" else "",
                     "0x%X" % (4096 * i) if kind == "Read" and reads % 2 == 0 else "", "Success"])
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["Index", "OPC", "CID", "SLBA", "NLB", "CNS", "PRP2", "Status"])
        w.writerows(rows)
    return rows


def test_the_kind_of_row_is_found_by_code_and_every_column_says_which_kinds_fill_it(tmp_path):
    path = str(tmp_path / "commands.csv")
    rows = _commands_csv(path)
    n = {k: sum(1 for r in rows if r[1] == k) for k in ("Read", "Write", "Identify", "Flush")}
    assert n == {"Read": 40, "Write": 30, "Identify": 10, "Flush": 5}
    prof = family1.full_profile(path, None)
    kind = prof["kind_of_row"]
    assert kind and kind["columns"] == ["OPC"], kind                               # found, not told: nothing names OPC in the code
    assert [(k["value"], k["rows"]) for k in kind["kinds"]] == [("Read", 40), ("Write", 30), ("Identify", 10), ("Flush", 5)]
    assert "The kind of each row is named by OPC: Read (40 rows), Write (30 rows), Identify (10 rows), Flush (5 rows)" in kind["text"]
    by = {c["column"]: c for c in prof["columns"]}
    assert by["SLBA"]["filled_for"]["text"] == "filled only on rows where OPC is Read (40 of 40 rows), Write (30 of 30 rows); never on the other 15 rows"
    assert by["NLB"]["filled_for"]["text"] == by["SLBA"]["filled_for"]["text"]
    assert by["NLB"]["filled_for"]["rows"] == by["SLBA"]["filled_for"]["rows"]      # the same kinds: asked together by the Grounder
    assert by["CNS"]["filled_for"]["text"] == "filled only on rows where OPC is Identify (10 of 10 rows); never on the other 75 rows"
    assert by["PRP2"]["filled_for"]["text"] == "filled only on rows where OPC is Read (20 of 40 rows); never on the other 45 rows"   # counted, not rounded up
    for name in ("Index", "OPC", "CID", "Status"):                                  # filled on every row: no special status
        assert not by[name].get("filled_for"), name
    assert prof["columns_with_special_status"] == 4
    assert all(c["rows_with_value"] == sum(1 for r in rows if r[i]) for i, c in enumerate(prof["columns"]))   # the usual counts are untouched


def test_a_file_whose_rows_are_all_of_one_shape_has_no_kind_of_row(tmp_path):
    path = str(tmp_path / "flat.csv")
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["Index", "Name", "Value", "Unit"])
        for i in range(200):
            w.writerow([i, "T%d" % (i % 7), i * 3, "ms"])
    prof = family1.full_profile(path, None)
    assert prof["kind_of_row"] is None and prof["columns_with_special_status"] == 0
    assert not any(c.get("filled_for") for c in prof["columns"])


def test_a_column_of_numbers_or_of_free_text_is_never_taken_as_the_kind_of_row(tmp_path):
    """A length that happens to be empty exactly where another column is empty must not be called the kind of the row."""
    path = str(tmp_path / "numbers.csv")
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["Index", "Length", "A", "B", "C"])
        for i in range(300):
            big = i % 3 == 0
            w.writerow([i, 4096 if big else 512, "x" if big else "", "y" if big else "", "" if big else "z"])
    prof = family1.full_profile(path, None)
    assert prof["kind_of_row"] is None, prof["kind_of_row"]


S17 = os.path.join(APP, "samples", "clean_five_files", "S17_io_timeout_abort_reset")


@pytest.mark.skipif(not os.path.isdir(S17), reason="the S17 sample recording is not on this machine (the code-only zip carries no samples)")
def test_on_the_sample_recording_read_and_write_fill_their_own_columns():
    prof = family1.full_profile(os.path.join(S17, "nvme_command.csv"), "nvme_command")
    assert prof["kind_of_row"]["columns"] == ["OPC"]
    kinds = {k["value"]: k["rows"] for k in prof["kind_of_row"]["kinds"]}
    assert kinds["Read"] == 360 and kinds["Write"] == 179 and sum(kinds.values()) == prof["rows"] == 608
    by = {c["column"]: c for c in prof["columns"]}
    assert by["SLBA"]["filled_for"]["text"] == "filled only on rows where OPC is Read (360 of 360 rows), Write (179 of 179 rows); never on the other 69 rows"
    # packets.csv has no single column for it: the kind is the one of a few type columns that is filled (never two on a row)
    prof = family1.full_profile(os.path.join(S17, "packets.csv"), "packets")
    assert len(prof["kind_of_row"]["columns"]) > 1 and "never two on the same row" in prof["kind_of_row"]["text"]
    by = {c["column"]: c for c in prof["columns"]}
    assert by["PSN"]["filled_for"]["text"].startswith("filled only on rows that have a TLP Type (")
    assert by["AckNak Seq Num"]["filled_for"]["text"].startswith("filled only on rows where DLLP Type is ACK (")


# ---------------------------------------------------------------------------------------------- 3. the reference search
def _line_by_line(docs, term, limit=3, context=1):
    """The search as it was before the fast one: every line of every document checked for the whole word."""
    rx = re.compile(r"(?<![A-Za-z0-9_])%s(?![A-Za-z0-9_])" % re.escape(term), re.I)
    hits = []
    for p, lines in docs.items():
        for i, line in enumerate(lines):
            if rx.search(line):
                lo, hi = max(0, i - context), min(len(lines), i + context + 1)
                hits.append({"ref": "%s:%d" % (p, i + 1), "quote": " ".join(x.strip() for x in lines[lo:hi] if x.strip())[:400]})
                if len(hits) >= limit * 4:
                    break
        if len(hits) >= limit * 4:
            break
    hits.sort(key=lambda h: len(h["quote"]))
    return hits[:limit]


def test_the_fast_reference_search_gives_the_same_lines_as_the_line_by_line_one(tmp_path):
    words = ["ACK", "Nak", "UpdateFC-P", "Sequence Number", "PSN", "MWr(64)", "CplD", "TLP Type", "ack", "İstanbul", "Größe", "LBA", "C++", "a.b", "DLLP"]
    folder = tmp_path / "refs"
    folder.mkdir()
    for d in range(3):
        lines = []
        for i in range(400):
            w = words[(i * 7 + d) % len(words)]
            lines.append(["%s is a field of the packet (%d)." % (w, i), "", "see the table: %s | %s | %d" % (w.lower(), words[(i + 3) % len(words)].upper(), i),
                          "nothing here %d" % i, "x%sx is no whole word, %s_1 neither" % (w, w), "İ and ß before %s on one line" % w][i % 6])
        (folder / ("doc%d.md" % d)).write_text("\n".join(lines), encoding="utf-8")
    refs = core.References([str(folder)], str(tmp_path / "cache"))
    docs = refs.docs()
    assert len(docs) == 3
    for term in words + ["sequence number", "table", "nothing", "no such word", "x", "(64)", "é"]:
        for limit, context in ((2, 1), (3, 1), (1, 0), (5, 2)):
            want = _line_by_line(docs, term, limit, context) if len(term.strip()) >= 2 else []
            assert refs.search(term, limit=limit, context=context) == want, (term, limit, context)
            assert refs.search(term, limit=limit, context=context) == want                # the second time from the kept answer: the same
    got = refs.search("ACK", limit=2)
    got[0]["quote"] = "changed by the caller"
    assert refs.search("ACK", limit=2)[0]["quote"] != "changed by the caller"         # the kept answer is not the caller's to change


# ---------------------------------------------------------------- the Settings page
def test_the_settings_page_shows_the_number_sets_it_at_once_and_refuses_a_wrong_one(monkeypatch, tmp_path):
    """Settings -> More settings -> "Model calls at the same time": the page is told the number in use and why; a number that is
    saved is used by the running agents at once and kept for the next start; a number outside 0 to 64 changes nothing."""
    import copy
    import shutil
    monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://127.0.0.1:9")           # restored after the test, whatever the application sets
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test-calls-0000")
    root = str(tmp_path / "app")
    os.makedirs(os.path.join(root, "config"))
    os.makedirs(os.path.join(root, "knowledge"))
    cfg = copy.deepcopy(json.load(open(os.path.join(APP, "config", "app_config.json"))))
    cfg["_path"] = os.path.join(root, "app_config.json")
    cfg["llm"].update(base_url="http://127.0.0.1:9", backend="http")
    cfg["agentic"].update(runtime="http", web=False)
    cfg.setdefault("server", {})["api_calls"] = True     # this test is about the Model connection's path (an address that answers nothing)
    cfg["agentic"].pop("calls_at_once", None)
    json.dump({k: v for k, v in cfg.items() if k != "_path"}, open(os.path.join(root, "config", "app_config.json"), "w"))
    from api import config_api, hier_api
    monkeypatch.setattr(config_api, "save_config", lambda c: None)
    monkeypatch.setattr(hier_api, "ENV_FILE", os.path.join(root, "env"))     # never the real key file
    monkeypatch.setattr(family1, "knowledge_dir", lambda: os.path.join(root, "knowledge"))
    monkeypatch.setattr(core.Engine, "kick", lambda self, rid: None)
    from server import create_app
    app = create_app(cfg, root)
    c = app.test_client()
    try:
        g = c.get("/api/agents/settings").get_json()["calls"]
        cores = os.cpu_count() or 4
        assert g["wanted"] == 0 and g["path"] == "http" and g["auto"] == max(4, min(32, 2 * cores))     # automatic: 2 per processor core
        assert g["now"] == g["ceiling"] == g["auto"] and g["cores"] == (os.cpu_count() or 0) and g["most"] == 64 and "processor core" in g["why"]
        eng = app.config["services"].agentic_engine
        r = c.put("/api/agents/settings", json={"calls_at_once": 3})
        assert r.status_code == 200, r.get_json()
        assert (r.get_json()["calls"]["wanted"], r.get_json()["calls"]["now"], r.get_json()["calls_at_once"]) == (3, 3, 3)
        assert eng.runner.calls_at_once() == 3 and eng.runner.slots.ceiling == 3               # the running agents use it at once
        assert json.load(open(os.path.join(root, "config", "app_config.json")))["agentic"]["calls_at_once"] == 3    # and the next start too
        for wrong in (65, -1, 1000):
            r = c.put("/api/agents/settings", json={"calls_at_once": wrong})
            assert r.status_code == 400 and "1 to 64" in r.get_json()["error"], (wrong, r.get_json())
            assert eng.runner.calls_at_once() == 3
            assert json.load(open(os.path.join(root, "config", "app_config.json")))["agentic"]["calls_at_once"] == 3
        r = c.put("/api/agents/settings", json={"calls_at_once": "many"})
        assert r.status_code == 400 and eng.runner.calls_at_once() == 3
        r = c.put("/api/agents/settings", json={"calls_at_once": 0})                             # empty on the page: automatic again
        assert r.status_code == 200 and r.get_json()["calls"]["wanted"] == 0 and r.get_json()["calls"]["now"] == g["auto"]
        assert eng.runner.slots.ceiling == g["auto"]
    finally:
        shutil.rmtree(root, ignore_errors=True)
