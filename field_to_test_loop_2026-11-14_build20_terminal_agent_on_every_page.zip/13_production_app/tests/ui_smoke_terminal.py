"""Browser check: every page of the application can reach the terminal agent (headless Chrome, port 9333). Read-only:
no question is asked, so no terminal program is started.

    python3 tests/ui_smoke_terminal.py

(owner, 2026-11-14: "each and every page should have communication with the terminal agent".) On each page: the button is
there and can be seen, a click opens the panel, the panel says which session the questions of this page go to (the
analysis the page shows, the analysis the recording on it belongs to, or the application), the question box is there with
its line saying what is sent, Escape closes the panel, and the page has no script error from it.
"""
import json
import os
import socket
import sys
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from ui_smoke_hier import Chrome   # noqa: E402

BASE = "http://127.0.0.1:8077"
R = {"pass": 0, "fail": 0}


def check(name, ok, detail=""):
    R["pass" if ok else "fail"] += 1
    print("%s  %s%s" % ("PASS" if ok else "FAIL", name, ("  | " + str(detail)[:220]) if detail != "" else ""), flush=True)


def get(path):
    with urllib.request.urlopen(BASE + path, timeout=30) as r:
        return json.loads(r.read())


def main():
    with socket.socket() as sk:
        if sk.connect_ex(("127.0.0.1", 9333)) == 0:
            sys.exit("port 9333 is busy (another headless Chrome)")
    projects = get("/api/agents/state").get("projects") or []
    linked = next((p for p in projects if p.get("upload_id")), None)
    first = projects[0] if projects else None
    # (address, what it is, the place its questions must go to: "application", or the analysis number)
    pages = [("/#/", "the start page", "application"), ("/#/library", "the rules library", None), ("/packets", "the packet workflow", "application"),
             ("/db", "the stored data", "application"), ("/defect", "the defect page", "application"), ("/hier", "the tree pages", "application"),
             ("/nvme-errors", "the NVMe command errors", "application"), ("/nvme-rules", "the NVMe command rules", "application"),
             ("/how", "the guide", "application"), ("/static/how_joins.html", "how the joins work", "application"),
             ("/static/how_files.html", "how the files are read", "application"), ("/static/how_grouping.html", "how grouping works", "application"),
             ("/static/how_isolate.html", "how isolation works", "application"), ("/static/how_rules.html", "how the rules work", "application")]
    if first:
        pages.append(("/#/p/%d" % first["id"], "a page of analysis %d" % first["id"], first["id"]))
    if linked:
        pages.append(("/isolate?upload=%s&finding=1" % linked["upload_id"], "the page of one error of analysis %d's recording" % linked["id"], linked["id"]))
        pages.append(("/hier?upload=%s" % linked["upload_id"], "the tree page of analysis %d's recording" % linked["id"], linked["id"]))
    c = Chrome()
    try:
        for address, what, place in pages:
            c.errors.clear()
            c.goto(BASE + address)
            time.sleep(2.0)
            btn = c.js("(() => { const b = document.getElementById('ta-btn') || document.getElementById('inv-btn'); if (!b) return null; const r = b.getBoundingClientRect(); "
                       "return {id: b.id, text: b.innerText.trim(), hidden: b.hidden, w: r.width, h: r.height, in: r.right <= innerWidth + 1 && r.bottom <= innerHeight + 1 && r.left >= 0 && r.top >= 0}; })()")
            check("%s (%s): the Terminal agent button is there and can be seen" % (what, address),
                  bool(btn) and not btn["hidden"] and btn["w"] > 20 and btn["h"] > 20 and btn["in"] and "Terminal agent" in btn["text"], btn)
            if not btn:
                continue
            before = c.js("document.documentElement.scrollWidth") or 0        # a page may be wider than the window by itself (a wide table)
            c.js("document.getElementById('%s').click()" % btn["id"])
            text = ""
            for _ in range(40):
                time.sleep(0.25)
                text = c.js("(document.getElementById('ta-body') || {}).innerText") or ""
                if "Your question" in text or "not ready" in text:
                    break
            says = ("This page shows no single analysis" in text) if place == "application" else ("This page belongs to analysis %s" % place in text) if place else \
                ("This page shows no single analysis" in text or "This page belongs to analysis" in text)
            check("%s: the panel opens and says which session the questions go to" % what, says, text[:160])
            box = c.js("(() => { const q = document.getElementById('ta-q'), w = document.querySelector('#ta-panel .ta-why'); "
                       "return {box: !!q, why: w ? w.innerText.length : 0, send: !!document.getElementById('ta-send'), wide: document.documentElement.scrollWidth <= Math.max(innerWidth, %d) + 1}; })()" % before) or {}
            check("%s: the question box, its line saying what is sent, and the Ask button are there; the panel does not make the page wider" % what,
                  box.get("box") and box.get("why", 0) > 40 and box.get("send") and box.get("wide"), box)
            ctx = c.js("JSON.stringify(window.F2TTerminal.context())")
            ctx = json.loads(ctx) if ctx else {}
            check("%s: the page says where the admin is (path and address)" % what, ctx.get("path") == address.split("?")[0].split("#")[0] and ctx.get("address", "").startswith(ctx.get("path", "?")), ctx)
            c.js("document.dispatchEvent(new KeyboardEvent('keydown', {key: 'Escape'}))")
            time.sleep(0.2)
            check("%s: Escape closes the panel" % what, c.js("!document.getElementById('ta-panel')") is True)
            mine = [e for e in c.errors if "terminal" in e.lower() or "ta-" in e]
            check("%s: no script error or failed request from the terminal agent" % what, not mine, mine[:2])
        c.goto(BASE + "/packets")
        time.sleep(1.5)
        c.js("document.getElementById('ta-btn').click()")
        time.sleep(1.5)
        print("screenshot:", c.shot("terminal_agent_panel"))
    finally:
        c.close()
    print("%d checks, %d failed" % (R["pass"] + R["fail"], R["fail"]))
    sys.exit(1 if R["fail"] else 0)


if __name__ == "__main__":
    main()
