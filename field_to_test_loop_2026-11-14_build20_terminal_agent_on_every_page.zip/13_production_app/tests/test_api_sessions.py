"""The Model connection with a held conversation per agent, saved on disk, compacted when nearly full
(owner, 2026-11-14: "when you are making many different agent calls, it should be stateful. You should be able to save
that in the disk ... next time if I am opening it, those states need to come back to the agents ... auto compact when it
reaches 95%"). The service is a stand-in on this computer that records every request body."""
import json
import os
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

from agentic import core, prompts          # noqa: E402
from agentic.sessions import Sessions       # noqa: E402


class Service:
    """Answers {"ok": true, "turns_before": <assistant turns in the request>}; a compaction request gets a summary."""

    def __init__(self, refuse_cache=False, fail_compaction=False):
        seen = self.seen = []
        me = self

        class H(BaseHTTPRequestHandler):
            def do_GET(self):
                me.gets.append(self.path)
                body = json.dumps({"id": "m", "max_input_tokens": me.context}).encode() if me.context else b"{}"
                self.send_response(200 if me.context else 404)
                self.send_header("content-type", "application/json")
                self.send_header("content-length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers.get("content-length") or 0)).decode())
                seen.append(body)
                if refuse_cache and "cache_control" in body:
                    return self._send(400, {"type": "error", "error": {"message": "cache_control: Extra inputs are not permitted"}})
                last = body["messages"][-1]["content"]
                if last.startswith("You are closing one part"):
                    if fail_compaction:
                        return self._send(500, {"type": "error", "error": {"message": "boom"}})
                    text = json.dumps({"summary": '1. the task: count rows. 3. exact values: column "PSN", limit 43 ms.'})
                else:
                    text = json.dumps({"ok": True, "turns_before": sum(1 for m in body["messages"] if m["role"] == "assistant")})
                size = sum(len(m["content"]) for m in body["messages"]) // 2
                self._send(200, {"content": [{"type": "text", "text": text}], "stop_reason": "end_turn",
                                 "usage": {"input_tokens": size, "output_tokens": 5, "cache_read_input_tokens": 0, "cache_creation_input_tokens": 0}})

            def _send(self, code, obj):
                data = json.dumps(obj).encode()
                self.send_response(code)
                self.send_header("content-type", "application/json")
                self.send_header("content-length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def log_message(self, *a):
                pass
        self.gets, self.context = [], None
        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = "http://127.0.0.1:%d" % self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def close(self):
        self.srv.shutdown()


@pytest.fixture()
def site(tmp_path, monkeypatch):
    made = []

    def make(**kw):
        svc = Service(**kw)
        made.append(svc)
        monkeypatch.setenv("ANTHROPIC_BASE_URL", svc.url)
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test-not-a-key")
        return svc
    yield tmp_path, make
    for s in made:
        s.close()


def runner(tmp, context_limit=100000, **kw):
    r = core.AgentRunner(str(tmp / "sandbox"), runtime="http", http_model="company-model", web=False,
                         sessions=Sessions(str(tmp / "sessions.sqlite")), **kw)
    r.context_limit = context_limit
    return r


def ask(r, run=1, agent="coder", text="question A", ctx="ctx"):
    return r.ask(run, agent, text, ctx, '{"ok": true}', "ok", lambda: {"ok": "stand-in"})


def test_an_agent_asked_again_has_its_earlier_turns_and_they_are_on_disk(site):
    tmp, make = site
    svc = make()
    r = runner(tmp)
    a1, who1, _ = ask(r, text="question A")
    a2, who2, _ = ask(r, text="question B")
    assert a1["turns_before"] == 0 and a2["turns_before"] == 1
    first, second = svc.seen
    assert len(first["messages"]) == 1 and "cache_control" not in first            # a first turn is the request it always was
    assert [m["role"] for m in second["messages"]] == ["user", "assistant", "user"]
    assert second["messages"][0]["content"] == first["messages"][0]["content"] and json.loads(second["messages"][1]["content"]) == a1
    assert second["cache_control"] == {"type": "ephemeral"}                         # what was sent before is read from the cache
    assert who1 == "company-model (model connection)" and who2.endswith('(conversation "run 1 · coder", turn 2)')
    row = r.sessions.listing("run:1")[0]
    assert row["program"] == "api" and row["turns"] == 2 and row["state"] == "open" and row["size_tokens"] > 0
    conv = r.sessions.conversation(row["id"])
    assert conv[0]["asked"].startswith("question A") and json.loads(conv[1]["answered"])["turns_before"] == 1
    # another agent and another run start their own conversation
    assert ask(r, agent="tester")[0]["turns_before"] == 0 and ask(r, run=2)[0]["turns_before"] == 0


def test_after_a_restart_the_conversation_comes_back(site):
    tmp, make = site
    make()
    ask(runner(tmp), text="question A")
    again = runner(tmp)                                   # a new runner over the same file
    assert ask(again, text="question B")[0]["turns_before"] == 1
    assert again.sessions.listing("run:1")[0]["turns"] == 2


def test_a_step_run_again_with_the_same_question_does_not_send_it_twice(site):
    tmp, make = site
    svc = make()
    r = runner(tmp)
    ask(r, text="question A")
    assert ask(r, text="question A")[0]["turns_before"] == 0
    assert len(svc.seen[1]["messages"]) == 1
    # both runs of question A are turns the agent answered: a later, different question has them both
    assert ask(r, text="question B")[0]["turns_before"] == 2
    assert [m["content"][:10] for m in svc.seen[2]["messages"] if m["role"] == "user"] == ["question A", "question A", "question B"]


def test_a_nearly_full_conversation_is_compacted_and_goes_on_as_its_next_part(site):
    tmp, make = site
    svc = make()
    r = runner(tmp, context_limit=4000)                   # reads 4,000 tokens: compaction at 3,800
    big = "x" * 3000                                      # about 1,500 tokens a question
    assert ask(r, text="first " + big)[0]["turns_before"] == 0
    assert ask(r, text="second " + big)[0]["turns_before"] == 1
    a, who, _ = ask(r, text="third " + big)
    assert a["turns_before"] == 0 and who.endswith('(conversation "run 1 · coder · part 2", turn 1, after compaction)')
    comp = [b for b in svc.seen if b["messages"][-1]["content"].startswith("You are closing one part")]
    assert len(comp) == 1 and len(comp[0]["messages"]) == 5                       # the whole conversation, then the compaction document
    assert comp[0]["messages"][-1]["content"] == prompts.load("compaction").strip() or comp[0]["messages"][-1]["content"].startswith(prompts.load("compaction")[:200])
    sent = svc.seen[-1]["messages"]
    assert len(sent) == 1 and sent[0]["content"].startswith("SUMMARY OF THIS CONVERSATION SO FAR (written by you when it had filled 95%")
    assert 'column "PSN", limit 43 ms' in sent[0]["content"] and "THE QUESTION NOW:\nthird " in sent[0]["content"]
    rows = r.sessions.listing("run:1")
    assert [(x["state"], x["part"]) for x in rows] == [("closed", 1), ("open", 2)]
    assert rows[0]["why_closed"].startswith("compacted: it held") and "95% of that" in rows[0]["why_closed"] and "The model's summary starts the next part." in rows[0]["why_closed"]
    assert len(r.sessions.conversation(rows[0]["id"])) == 2                       # the full text stays in the record
    assert ask(r, text="fourth")[0]["turns_before"] == 1                           # and the new part is continued


def test_when_no_summary_can_be_made_the_last_turns_start_the_next_part(site):
    tmp, make = site
    svc = make(fail_compaction=True)
    r = runner(tmp, context_limit=4000)
    core.AgentRunner.RETRY_WAIT_LIMIT, old = 0, core.AgentRunner.RETRY_WAIT_LIMIT
    big = "x" * 3000
    ask(r, text="first " + big)
    ask(r, text="second " + big)
    import time as _t
    real = _t.sleep
    _t.sleep = lambda s: None                              # the retries of the failing compaction call do not wait in a test
    try:
        a, who, _ = ask(r, text="third " + big)
    finally:
        _t.sleep = real
        core.AgentRunner.RETRY_WAIT_LIMIT = old
    assert a["ok"] is True and "after compaction" in who
    sent = svc.seen[-1]["messages"][0]["content"]
    assert sent.startswith("EARLIER IN THIS CONVERSATION (kept by the application") and "THE QUESTION NOW:\nthird " in sent
    assert "No summary could be made" in r.sessions.listing("run:1")[0]["why_closed"]


def test_an_address_that_does_not_take_the_caching_field_is_asked_without_it_and_remembered(site):
    tmp, make = site
    svc = make(refuse_cache=True)
    r = runner(tmp)
    ask(r, text="question A")
    a, who, _ = ask(r, text="question B")
    assert a["turns_before"] == 1
    assert ["cache_control" in b for b in svc.seen] == [False, True, False]
    ask(r, text="question C")
    assert "cache_control" not in svc.seen[-1] and len(svc.seen) == 4
    # the refused try is not a turn of the conversation
    assert [t["ok"] for t in r.sessions.conversation(r.sessions.listing("run:1")[0]["id"])] == [True, True, True]


def test_a_failed_call_is_written_down_and_is_not_part_of_what_the_agent_said(site, monkeypatch):
    tmp, make = site
    svc = make()
    r = runner(tmp)
    ask(r, text="question A")
    monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://127.0.0.1:9")       # nothing answers there
    import time as _t
    monkeypatch.setattr(_t, "sleep", lambda s: None)
    a, who, _ = ask(r, text="question B")
    assert a == {"ok": "stand-in"} and "http failed" in who
    monkeypatch.setenv("ANTHROPIC_BASE_URL", svc.url)
    assert ask(r, text="question C")[0]["turns_before"] == 1
    conv = r.sessions.conversation(r.sessions.listing("run:1")[0]["id"])
    assert [t["ok"] for t in conv] == [True, False, True] and conv[1]["problem"]


def test_what_the_model_reads_comes_from_the_service_then_the_name_then_the_fallback(site):
    tmp, make = site
    svc = make()
    r = runner(tmp)
    r.context_limit = None
    assert r.context_tokens() == core.AgentRunner.CONTEXT_FALLBACK and svc.gets == ["/v1/models/company-model"]
    assert r.context_tokens() == core.AgentRunner.CONTEXT_FALLBACK and len(svc.gets) == 1          # asked once
    svc.context = 640000
    r2 = runner(tmp)
    r2.context_limit = None
    assert r2.context_tokens() == 640000
    r3 = runner(tmp)
    r3.context_limit, r3.http_model = None, "claude-sonnet-5-5"
    svc.context = None
    assert r3.context_tokens() == 1000000
    assert core.AgentRunner.SESSION_FILL == 0.95


def test_a_runner_without_a_record_asks_as_before(site):
    tmp, make = site
    svc = make()
    r = core.AgentRunner(str(tmp / "sb"), runtime="http", http_model="company-model", web=False)
    ask(r, text="question A")
    ask(r, text="question B")
    assert all(len(b["messages"]) == 1 and "cache_control" not in b for b in svc.seen)


def test_the_same_agent_from_many_threads_keeps_one_ordered_conversation(site):
    tmp, make = site
    make()
    r = runner(tmp)
    out = []
    ts = [threading.Thread(target=lambda i=i: out.append(ask(r, text="question %d" % i)[0]["turns_before"])) for i in range(6)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    assert sorted(out) == [0, 1, 2, 3, 4, 5] and r.sessions.listing("run:1")[0]["turns"] == 6
