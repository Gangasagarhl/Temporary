"""Family 4 - Coding (owner, 2026-11-12): requirements with the admin and Family 1, then code and test in rounds.

What must hold:
  1. "Code it" has two steps of Family 4, the requirements review and the code review; inside the flow they stand where the
     single Coder call stood, and the flow's own hooks reach them;
  2. the Requirements agent's kinds of data all go to Family 1 (the Manager of every file): found (with the dictionary's rows
     and lines), not found (the build does not start unless the admin says so in words), cannot tell (an open point); a name
     the model invents is dropped and never counted as found; a file or a tree that is not there blocks the code;
  3. the admin's answers come back to the agent with their questions, as often as needed;
  4. the rounds stop on a clean round, at the number the admin set (bounded), or when the Coder returns the same code and
     objects to nothing; what failed reaches the Coder of the next round; a stopped run makes no further model call;
  5. a wrong expectation of the Tester is recorded as a disagreement for the admin and the code is not bent to it;
  6. model answers of the wrong shape, no code, and code the program refuses never run and never stop the loop;
  7. approving stores the verified code; verified code is used again without any model call; a change with a comment starts
     the rounds again from the last code, with the comment.

No server and no model: an engine on its own store in a temporary folder; the agents' answers are written here. The code the
"Coder" gives really runs, in the same confinement as in the application (procedures.run_code)."""
import json
import os
import sys
import time

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from agentic import core, family1, family3, family4, pipeline, procedures as PR  # noqa: E402

CSV = "City,Visitor,Minutes\nPune,a,10\nPune,b,5\nGoa,c,7\n Pune ,d,3\nGoa,e,1\nDelhi,f,9\n"
PROC = {"source_data": [{"file": "visits.csv", "columns": ["City", "Minutes"]}],
        "steps": ["Read visits.csv row by row with Python's csv reader.",
                  "City: the cell with the spaces at both ends removed; letter case is not changed; an empty cell counts as \"(blank)\".",
                  "Count the rows of each city in a hash map: key = the city, value = the number of rows.",
                  "Output one line per city: City, count; the largest count first, then the city by name."],
        "output": {"columns": ["City", "count"], "order": "count, largest first; then City"}}
GOOD = '''import csv


def run(sources, out_csv):
    # step 1: read visits.csv row by row
    counts, n = {}, 0
    with open(sources["visits.csv"], newline="", encoding="utf-8-sig") as fh:
        rd = csv.reader(fh)
        head = next(rd)
        i = head.index("City")
        for row in rd:
            n += 1
            # step 2: spaces removed; empty -> "(blank)"
            v = (row[i].strip() if i < len(row) else "") or "(blank)"
            # step 3: hash map city -> rows
            counts[v] = counts.get(v, 0) + 1
    # step 4: largest count first, then by name
    with open(out_csv, "w", newline="", encoding="utf-8") as out:
        w = csv.writer(out)
        w.writerow(["City", "count"])
        for v, k in sorted(counts.items(), key=lambda x: (-x[1], x[0])):
            w.writerow([v, k])
    return {"rows_read": n, "rows_written": len(counts), "total": n}
'''
BAD = GOOD.replace('(row[i].strip() if i < len(row) else "")', '(row[i] if i < len(row) else "")')        # the spaces are not removed
SPACES = {"name": "spaces around the city", "why": "step 2: the spaces at both ends are removed, so ' Pune ' and 'Pune' are one city",
          "files": {"visits.csv": [{"City": " Pune "}, {"City": "Pune"}, {"City": "Goa"}]}, "expected_rows": [["Pune", 2], ["Goa", 1]], "order_matters": True}
WRONG_CLAIM = {"name": "two cities once each", "why": "step 4", "files": {"visits.csv": [{"City": "Pune"}, {"City": "Goa"}]},
               "expected_rows": [["Pune", 2], ["Goa", 1]], "order_matters": True}                              # the right rows are Goa 1, Pune 1
DICT_COLUMNS = [{"column": "City", "rows_with_value": 6, "distinct": 3, "meaning": "the city of the visit", "where": "visits.csv line 2, 3, 4",
                 "keywords": [{"value": "Pune", "count": 3, "rows": [1, 2, 4], "meaning": "a city"}, {"value": "Goa", "count": 2, "rows": [3, 5], "meaning": "a city"}]},
                {"column": "Minutes", "rows_with_value": 6, "distinct": 6, "meaning": "how long the visit lasted, in minutes", "where": "visits.csv line 2, 3, 4", "keywords": []}]


def req_answer(extra=(), questions=()):
    return {"requirements": ["Read visits.csv.", "Count the rows of each city.", "Write City, count."],
            "data_needed": [{"what": "the city of a visit", "file": "visits.csv", "column": "City", "why": "step 2"},
                            {"what": "how long a visit lasted", "file": "visits.csv", "column": "Minutes", "why": "named by the procedure"}] + list(extra),
            "definitions": [{"term": "city", "exact": "the City cell without the spaces at its ends", "from": "the procedure, step 2"}],
            "questions": [{"question": q, "why": "it changes the count"} for q in questions], "answers": []}


class Lab:
    """One analysis on a folder with one plain CSV (not an analyzer export), one item with a procedure, and a "Code it" run."""

    def __init__(self, tmp_path, monkeypatch, proc=PROC, kinds=None, dictionary=True):
        self.root = str(tmp_path)
        self.folder = os.path.join(self.root, "recording")
        os.makedirs(self.folder)
        with open(os.path.join(self.folder, "visits.csv"), "w", encoding="utf-8") as fh:
            fh.write(CSV)
        self.know = os.path.join(self.root, "knowledge")
        monkeypatch.setattr(family1, "knowledge_dir", lambda: self.know)
        monkeypatch.setattr(core.Engine, "kick", lambda eng, rid: None)       # no background thread: the steps are run here
        family3._SECTIONS_SEEN[0] = None
        if dictionary:
            f = family1.inventory(self.folder)[0]
            d = os.path.join(self.know, "dictionaries", f["format_key"])
            os.makedirs(d)
            with open(os.path.join(d, "visits.current.json"), "w", encoding="utf-8") as fh:
                json.dump({"path": f["path"], "level": None, "version": 1, "approved_at": 1.0, "approved_by": "Sagar", "rows": 6, "columns": DICT_COLUMNS}, fh)
        self.store = core.Store(os.path.join(self.root, "db", "agentic.sqlite"))
        self.runner = core.AgentRunner(os.path.join(self.root, "runs"), runtime="http", web=False)
        self.eng = core.Engine(self.store, kinds or {"rule_code": family4}, self.runner, cfg={})
        self.pid = self.store.exec("INSERT INTO project (name, folder, created) VALUES (?,?,?)", ("p", self.folder, time.time()))
        r = family3.add_item("analytics", "other", "Visits per city", "how many visits each city had", "Sagar")
        r, _ = PR.store(r, proc, "Sagar")
        family3.save_rule(r)
        self.item = r["id"]
        self.calls, self.seen = [], []
        self.req = lambda ctx, n: req_answer()
        self.coder = lambda ctx, n: {"notes": ["count each city"], "code": GOOD, "how": ["step 1: csv.reader"]}
        self.tester = lambda ctx, n: {"notes": ["the spaces"], "cases": [SPACES], "remarks": [], "replies": [], "nothing_more": True}
        self.managers = lambda file, kinds: [{"kind": k["kind"], "present": "yes", "matches": k["named_in_the_question"] or [{"column": "City", "keyword": ""}]} for k in kinds]
        self.second = lambda ctx, n: "standin"            # no second program unless a test writes one (as without a model)
        self.research = lambda ctx, n: "standin"          # the Data researcher adds nothing unless a test writes its answer
        self.cover = lambda ctx, n: "standin"             # the Tester's coverage pass (data sets for requirements nothing tests yet)
        self.settle_hidden = True                         # the Requirements agent of these tests says its first requirement settles every hidden decision
        self.matcher = lambda ctx, n: {"choices": [], "none_of_these": True, "note": ""}      # the column matcher's model
        self.agents = []
        self.runner.ask = self.ask
        self.rid = None

    def ask(self, run_id, agent, instruction, context, schema_text, must_have, standin, **kw):
        self.runner._local.run = run_id
        self.runner._stopped()
        ctx = json.loads(context) if isinstance(context, str) else context
        role = "match" if agent.startswith("column_match_") else next(x for x in ("requirements", "coder", "tester", "asks", "second", "research", "cover") if agent.startswith("f4_" + x))
        n = sum(1 for a, _c, _k in self.seen if a == role)
        self.seen.append((role, ctx, kw))
        self.calls.append(role)
        self.agents.append(agent)
        ans = self.managers(ctx["file"], ctx["kinds"]) if role == "asks" else {"requirements": self.req, "coder": self.coder, "tester": self.tester, "research": self.research,
                                                                               "cover": self.cover, "second": self.second, "match": self.matcher}[role](ctx, n)
        if role == "asks":
            ans = {"answers": ans}
        if role == "requirements" and self.settle_hidden and isinstance(ans, dict) and ans.get("requirements") and isinstance(ctx, dict) and ctx.get("HIDDEN_DECISIONS"):
            first = ans["requirements"][0]
            ans = dict(ans, requirements=[{"text": first if isinstance(first, str) else first.get("text"), "settles": [h["id"] for h in ctx["HIDDEN_DECISIONS"]]}] + list(ans["requirements"][1:]))
        if ans == "standin":
            return standin(), "stand-in (no model)", ""
        if ans == "unreadable":     # the model answered and the answer was not JSON: the runner gives the stand-in's and names the failure
            return standin(), "stand-in (no model) (after: http failed: Expecting ',' delimiter: line 1 column 1560)", ""
        return ans, "the model (written by the test)", ""

    def rule(self):
        return family3.load_rule("analytics", "other", self.item)

    def start(self):
        self.rid = self.eng.start(self.pid, "rule_code", "Code it", {"_kind": "rule_code", "section": "analytics", "level": "other", "id": self.item, "started_by": "Sagar"})
        return self

    def steps(self):
        return self.store.all("SELECT * FROM step WHERE run=? ORDER BY idx", (self.rid,))

    def step(self, key):
        return next(s for s in self.steps() if s["key"] == key or s["key"].endswith(":" + key))

    def work(self):
        """The next waiting step runs to its end (a review, done, skipped or failed). The data research, which needs no
        decision, is passed through: the step after it is the one returned."""
        while True:
            s = next(x for x in self.steps() if x["state"] == "waiting")
            self.eng._run_step(self.store.one("SELECT * FROM run WHERE id=?", (self.rid,)), s)
            s = self.store.one("SELECT * FROM step WHERE id=?", (s["id"],))
            if not (s["key"] == "research" or s["key"].endswith(":research")) or s["state"] == "failed":
                return s

    def review(self):
        r = self.store.one("SELECT * FROM review WHERE run=? AND state='open' ORDER BY id DESC LIMIT 1", (self.rid,))
        if r:
            r["data"] = json.loads(r["data"])
        return r

    def decide(self, decision, comment="", edits=None, accept_open=True):
        """accept_open: on the code card, the requirements the program could not show to hold are each accepted as they are
        (the admin's own choice on the page), unless the test gives its own decisions."""
        rv = self.review()
        open_ = (rv.get("data") or {}).get("f4_open") or []
        if decision == "approve" and open_ and accept_open and "req_decisions" not in (edits or {}):
            edits = dict(edits or {}, req_decisions={x["id"]: "accept" for x in open_})
        self.eng.decide(rv["id"], decision, "Sagar", comment, edits)

    def to_code_review(self, rounds=None):
        """Requirements approved (nothing open), then the rounds run: -> the code step."""
        self.work()
        self.decide("approve", edits={"rounds": rounds} if rounds else None)
        return self.work()

    def out(self, key):
        return json.loads(self.step(key)["output"] or "{}")

    def of(self, role):
        return [c for a, c, _k in self.seen if a == role]


@pytest.fixture
def lab(tmp_path, monkeypatch):
    return Lab(tmp_path, monkeypatch).start()


# ---------------------------------------------------------------------------------------------- 1. its place
def test_code_it_is_two_steps_of_family_4_and_the_flow_puts_them_where_the_coder_stood(lab):
    ss = lab.steps()
    assert [(s["key"], s["family"], s["agent"], s["needs_review"]) for s in ss] == [("research", "4", "Data researcher", 0), ("req", "4", "Requirements agent", 1), ("code", "4", "Coder", 1)]
    plan = pipeline.item_steps("analytics", "other", lab.item, "Visits per city", True, "words")
    assert [s["key"].rsplit(":", 1)[1] for s in plan] == ["write", "research", "req", "code", "run", "test", "export", "result"]
    assert [s["family"] for s in plan] == ["3", "4", "4", "4", "3", "3", "3", "3"]
    assert pipeline.FAMILY_LABEL["4"] == "Family 4 · Coding research"


# ---------------------------------------------------------------------------------------------- 2. the data, asked of Family 1
def test_every_kind_of_data_goes_to_family_1_and_found_shows_the_dictionarys_rows_and_lines(lab):
    lab.managers = lambda file, kinds: [{"kind": k["kind"], "present": "yes", "matches": [{"column": "City" if "city" in k["question"] else "Minutes", "keyword": "", "rows": 98765}]}
                                        for k in kinds]
    st = lab.work()
    assert st["state"] == "needs_review"
    asked = lab.of("asks")
    assert len(asked) == 1 and asked[0]["file"] == "visits.csv"                              # one call for the file, all kinds in it
    assert [k["question"] for k in asked[0]["kinds"]] == ["Is this kind of data present in the recording: the city of a visit?",
                                                           "Is this kind of data present in the recording: how long a visit lasted?"]
    out, rv = lab.out("req"), lab.review()
    assert [k["status"] for k in out["data_needed"]] == ["found", "found"] and out["data_needed"][0]["named"]["rows"] == 6
    line = next(l for l in rv["body"].split("\n") if l.startswith("| the city of a visit"))
    assert "**found**" in line and "visits.csv: City" in line and "6 rows" in line and "lines 2, 3, 4" in line and "the city of the visit" in line
    assert "98765" not in rv["body"]                                                       # a count a model gives is never shown
    assert "Nothing is open" in rv["body"] and rv["data"]["f4_req"] and rv["data"]["open"] == 0 and rv["data"]["not_found"] == []
    lab.decide("approve")
    assert json.loads(lab.step("code")["input"])["rounds"] == 10                           # 10 rounds unless the admin sets another number
    kept = lab.rule()["coding"]["requirements"]
    assert kept["approved_by"] == "Sagar" and kept["procedure_sha"] == PR.sha(lab.rule()["procedure"]) and len(kept["data_needed"]) == 2


def test_a_kind_of_data_found_in_no_file_blocks_the_build_until_the_admin_says_so_in_words(lab):
    lab.req = lambda ctx, n: req_answer(extra=[{"what": "the visitor's age", "file": "", "column": "", "why": "the admin asks for visits by age"}])
    lab.managers = lambda file, kinds: [{"kind": k["kind"], "present": "no" if "age" in k["question"] else "yes",
                                         "matches": [] if "age" in k["question"] else [{"column": "City", "keyword": ""}]} for k in kinds]
    lab.work()
    out, rv = lab.out("req"), lab.review()
    assert [k["status"] for k in out["data_needed"]] == ["found", "found", "not found"] and rv["data"]["not_found"] == ["the visitor's age"]
    assert "**Not found in any file (1): the visitor's age.**" in rv["body"] and "Read the new files" in rv["body"] and lab.folder in rv["body"]
    with pytest.raises(ValueError, match="not found in any file"):
        lab.decide("approve")
    with pytest.raises(ValueError, match="not found in any file"):
        lab.decide("approve", edits={"accept_open": True})                                 # a tick is not words
    assert lab.review() is not None and lab.step("code")["state"] == "waiting" and "coder" not in lab.calls
    lab.decide("approve", comment="go on without the age: this count does not use it")
    kept = lab.rule()["coding"]["requirements"]
    assert kept["not_found_accepted"] == ["the visitor's age"] and "does not use it" in kept["accepted_because"]


def test_family_1_cannot_tell_is_an_open_point_and_so_is_a_file_without_a_dictionary(tmp_path, monkeypatch):
    lab = Lab(tmp_path / "a", monkeypatch).start()
    lab.req = lambda ctx, n: req_answer(extra=[{"what": "the visitor's age", "file": "", "column": "", "why": "x"}])
    lab.managers = lambda file, kinds: [{"kind": k["kind"], "present": "cannot_tell" if "age" in k["question"] else "yes",
                                         "matches": [] if "age" in k["question"] else [{"column": "City", "keyword": ""}],
                                         "could_not_check": "the visitor column holds ids, not ages" if "age" in k["question"] else ""} for k in kinds]
    lab.work()
    assert lab.out("req")["data_needed"][2]["status"] == "cannot tell" and lab.review()["data"]["open"] == 1
    assert "**Family 1 cannot tell: the visitor's age.**" in lab.review()["body"] and "ids, not ages" in lab.review()["body"]
    with pytest.raises(ValueError, match="1 point is still open"):
        lab.decide("approve")
    lab.decide("approve", edits={"accept_open": True})
    # no dictionary approved for the file: nobody to ask, so a kind without a column is "cannot tell", never "not found"
    lab2 = Lab(tmp_path / "b", monkeypatch, dictionary=False).start()
    lab2.req = lab.req
    lab2.work()
    k = lab2.out("req")["data_needed"]
    assert [x["status"] for x in k] == ["found", "found", "cannot tell"] and "asks" not in lab2.calls
    assert k[0]["named"]["in_family_1_dictionary"] is False and "no data dictionary is approved yet for visits.csv" in lab2.review()["body"]


def test_a_name_the_model_invents_is_dropped_and_never_counts_as_found(lab):
    lab.req = lambda ctx, n: req_answer(extra=[{"what": "the visitor's age", "file": "visits.csv", "column": "Age", "why": "x"}])
    lab.managers = lambda file, kinds: [{"kind": k["kind"], "present": "yes", "matches": [{"column": "Age", "keyword": ""}, {"column": "Visitor", "keyword": "old"}]
                                         if "age" in k["question"] else [{"column": "City", "keyword": ""}]} for k in kinds]
    lab.work()
    age = lab.out("req")["data_needed"][2]
    assert age["status"] != "found" and age["file"] == "" and age["column"] == "" and age["named"] is None and age["family_1"]["found"] == []
    body = lab.review()["body"]
    assert "visits.csv: Age" in body and "dropped and are not counted as found" in body        # the agent's invented column
    assert "Names a Manager gave that are not in its file were dropped: Age (visits.csv)" in body
    with pytest.raises(ValueError):
        lab.decide("approve")


def test_a_file_or_a_tree_that_is_not_there_blocks_the_code(tmp_path, monkeypatch):
    lab = Lab(tmp_path / "a", monkeypatch, proc=dict(PROC, source_data=[{"file": "orders.csv", "columns": ["City"]}])).start()
    lab.work()
    rv = lab.review()
    assert rv["data"]["blocking"] and "this analysis has no file orders.csv" in rv["body"] and "Read the new files" in rv["body"]
    with pytest.raises(ValueError, match="cannot be made yet"):
        lab.decide("approve", comment="go on", edits={"accept_open": True})
    tree = Lab(tmp_path / "b", monkeypatch, proc=dict(PROC, source_data=[{"file": "the tree", "columns": ["nvme_command: OPC"]}])).start()
    tree.work()
    assert "this rule needs the tree: stage 2 was not built for this analysis" in tree.review()["body"]
    col = Lab(tmp_path / "c", monkeypatch, proc=dict(PROC, source_data=[{"file": "visits.csv", "columns": ["City", "Country"]}])).start()
    col.work()
    assert "visits.csv has no column Country (its header was read by code)" in col.review()["body"]


# ---------------------------------------------------------------------------------------------- 3. the admin's answers
def test_the_admins_answers_go_back_with_their_questions_until_nothing_is_open(lab):
    lab.req = lambda ctx, n: req_answer(questions=["Does a city written in another letter case count as the same city?"] if not ctx["ADMIN_SAID"]["answers"] else [])
    lab.work()
    rv = lab.review()
    assert rv["data"]["questions"][0]["question"].startswith("Does a city") and "Questions to you (1)" in rv["body"]
    with pytest.raises(ValueError, match="still open"):
        lab.decide("approve")
    with pytest.raises(ValueError, match="write your answers first"):
        lab.decide("change", comment="", edits={"answers": {"0": "   "}})
    lab.decide("change", comment=family4.ANSWERS_NOTE, edits={"answers": {"0": "No: Pune and pune are two cities."}})
    lab.work()
    said = lab.of("requirements")[1]["ADMIN_SAID"]
    assert said["answers"] == [{"question": "Does a city written in another letter case count as the same city?", "answer": "No: Pune and pune are two cities.", "by": "Sagar"}]
    assert said["comments"] == []                                                          # the note the page sends with the boxes is not a comment
    rv = lab.review()
    assert rv["data"]["open"] == 0 and "Your answers so far" in rv["body"] and "two cities" in rv["body"]
    lab.decide("approve")
    lab.work()
    assert lab.of("coder")[0]["REQUIREMENTS"]["the_admins_answers"][0]["answer"].startswith("No: Pune")    # the Coder is given the answers


def test_a_decision_of_the_wrong_shape_is_refused_in_words(lab):
    lab.work()
    for edits in ({"rounds": 0}, {"rounds": 21}, {"rounds": "many"}, {"rounds": True}, {"rounds": 2.5}, {"rounds": [3]}):
        with pytest.raises(ValueError, match="whole number from 1 to 20"):
            lab.decide("approve", edits=edits)
    with pytest.raises(ValueError):
        lab.decide("change", edits=["x"])
    lab.decide("approve", edits={"rounds": "3"})
    assert json.loads(lab.step("code")["input"])["rounds"] == 3


# ---------------------------------------------------------------------------------------------- 4. the rounds
def test_a_clean_first_round_ends_the_rounds_and_the_trail_keeps_the_thinking(lab):
    st = lab.to_code_review()
    out, rv = lab.out("code"), lab.review()
    assert st["state"] == "needs_review" and lab.calls.count("coder") == 1 and lab.calls.count("tester") == 1
    assert out["rounds_used"] == 1 and out["rounds_most"] == 10 and out["clean"] and not out["problems"] and not out["failing"] and "rows" not in out
    assert "round 1 was clean" in out["stopped_because"] and all(c["ok"] for c in out["checks"])
    assert next(k for a, _c, k in lab.seen if a == "coder")["effort"] == "xhigh"              # the Coder thinks at the highest effort
    assert "```python" in rv["body"] and "**The last round was clean.**" in rv["body"] and "The code ran on the whole of visits.csv" in rv["body"]
    assert os.path.realpath(out["code_file"]).startswith(os.path.realpath(os.path.join(lab.know, "rules_code")) + os.sep)
    trail = json.load(open(out["trail_file"], encoding="utf-8"))
    r1 = trail["rounds"][0]
    assert r1["coder"]["notes"] == ["count each city"] and r1["tester"]["notes"] == ["the spaces"] and r1["clean"]
    names = {c["name"]: c for c in r1["cases"]}
    assert set(names) == {"the header only, no record", "one record with every cell empty", "one record cut short after its first cell", "spaces around the city"}
    assert all(c["status"] == "passed" for c in r1["cases"]) and names["spaces around the city"]["by"] == "the Tester"
    assert r1["sample"]["ok"] and r1["sample"]["lines"] == 3                                 # Pune 4, Goa 2, Delhi 1 on the real file's records
    assert rv["data"]["f4_trail"][0]["coder"]["notes"] == ["count each city"] and rv["data"]["f4"]["clean"]
    assert "%" in lab.step("code")["note"] and "round 1 of 10" in lab.step("code")["note"]    # the progress line


def test_what_failed_reaches_the_coder_of_the_next_round(lab):
    lab.coder = lambda ctx, n: {"notes": ["first try"] if n == 0 else ["the Tester is right: step 2 removes the spaces"], "code": BAD if n == 0 else GOOD,
                                "changed": [] if n == 0 else ["the City cell is stripped"]}
    lab.to_code_review()
    out = lab.out("code")
    assert out["rounds_used"] == 2 and out["clean"] and lab.calls.count("coder") == 2
    second = lab.of("coder")[1]
    assert second["YOUR_LAST_CODE"] == BAD and second["ROUND"] == "2 of at most 10"
    f = next(x for x in second["WHAT_FAILED"] if "spaces around the city" in x["found_by"])
    assert f["expected_rows"] == [["Pune", 2], ["Goa", 1]] and f["the_code_wrote"] == [[" Pune ", "1"], ["Goa", "1"], ["Pune", "1"]] and "Tester's claim" in f["note"]
    trail = json.load(open(out["trail_file"], encoding="utf-8"))["rounds"]
    assert [x["clean"] for x in trail] == [False, True] and trail[0]["failing"] == ["spaces around the city"] and trail[1]["coder"]["changed"] == ["the City cell is stripped"]
    assert out["code_file"].endswith(".r2.py") and open(out["code_file"], encoding="utf-8").read() == GOOD
    body = lab.review()["body"]
    assert "after **2 rounds of at most 10**" in body and "| 1 |" in body and "| 2 |" in body


def test_the_rounds_end_at_the_number_the_admin_set_and_an_unsettled_code_needs_his_reason(lab):
    lab.coder = lambda ctx, n: {"notes": ["try %d" % (n + 1)], "code": BAD + "# try %d\n" % (n + 1)}
    lab.to_code_review(rounds=3)
    out = lab.out("code")
    assert out["rounds_used"] == 3 and out["rounds_most"] == 3 and not out["clean"] and out["failing"] == ["spaces around the city"]
    assert out["stopped_because"] == "the 3 rounds are used up" and lab.calls.count("coder") == 3 and lab.calls.count("tester") == 3
    assert not out["problems"]                                                              # the program itself refused nothing: the claim is the Tester's
    body = lab.review()["body"]
    assert "**It is not clean:**" in body and "**Still failing (1):**" in body and "the Tester's claim, not a proven result" in body
    with pytest.raises(ValueError, match="1 data set is not settled"):
        lab.decide("approve")
    lab.decide("approve", comment="the spaces are wanted here: accepted as it is")
    c = lab.rule()["code"]
    assert c["verified_by"] == "Sagar" and c["clean"] is False and c["accepted_with_open"] == ["spaces around the city"] and "accepted as it is" in c["accepted_because"]


def test_the_same_code_again_without_an_objection_ends_the_rounds(lab):
    lab.coder = lambda ctx, n: {"notes": ["nothing to change"], "code": BAD}
    lab.to_code_review()
    out = lab.out("code")
    assert out["rounds_used"] == 2 and "returned the same code again and objected to nothing" in out["stopped_because"] and lab.calls.count("coder") == 2


def test_a_stopped_run_makes_no_further_model_call(lab):
    lab.coder = lambda ctx, n: {"notes": ["try"], "code": BAD + "# %d\n" % n}

    def tester(ctx, n):
        lab.eng.stop(lab.rid, "Sagar", "enough")              # the admin presses Stop while the Tester works
        return {"cases": [SPACES], "remarks": [], "replies": []}
    lab.tester = tester
    st = lab.to_code_review()
    assert lab.calls.count("coder") == 1 and lab.calls.count("tester") == 1
    assert st["state"] == "stopped" and lab.review() is None and lab.store.one("SELECT state FROM run WHERE id=?", (lab.rid,))["state"] == "stopped"
    with pytest.raises(RuntimeError, match="the run was stopped"):
        lab.runner.ask(lab.rid, "f4_coder_x", "", {}, "", "code", dict)


# ---------------------------------------------------------------------------------------------- 5. the Tester's claim is a claim
def test_a_wrong_expectation_is_set_aside_for_the_admin_and_the_code_is_not_bent_to_it(lab):
    lab.coder = lambda ctx, n: {"notes": ["count"], "code": GOOD, "objections": [] if n == 0 else
                                [{"case": "two cities once each", "why": "step 3 counts rows: each city is met once, so Goa 1 and Pune 1"}]}
    lab.tester = lambda ctx, n: {"cases": [WRONG_CLAIM] if n == 0 else [], "remarks": [],
                                 "replies": [{"case": o["case"], "keep": True, "why": "I read step 3 as counting visitors"} for o in ctx.get("OBJECTIONS") or []]}
    lab.to_code_review()
    out = lab.out("code")
    assert out["rounds_used"] == 2 and out["set_aside"] == ["two cities once each"] and out["failing"] == [] and out["clean"]
    files = sorted(f for f in os.listdir(os.path.dirname(out["code_file"])) if f.endswith(".py"))
    assert len(files) == 2 and all(open(os.path.join(os.path.dirname(out["code_file"]), f), encoding="utf-8").read() == GOOD for f in files)    # the code never changed
    assert lab.of("tester")[1]["OBJECTIONS"][0]["the_coder_says"].startswith("step 3 counts rows") and lab.of("tester")[1]["OBJECTIONS"][0]["the_code_wrote"] == [["Goa", "1"], ["Pune", "1"]]
    body = lab.review()["body"]
    assert "**For you to judge (1): the Coder and the Tester disagree, and neither is proven.**" in body
    assert "the Coder objects: step 3 counts rows" in body and "I read step 3 as counting visitors" in body
    with pytest.raises(ValueError, match="not settled"):
        lab.decide("approve")                                                               # the admin judges: his reason is needed
    lab.decide("approve", comment="the Coder is right: rows are counted")
    assert lab.rule()["code"]["verified_by"] == "Sagar"


def test_the_tester_can_withdraw_its_data_set_after_the_objection(lab):
    lab.coder = lambda ctx, n: {"code": GOOD, "objections": [] if n == 0 else [{"case": "two cities once each", "why": "each city is met once"}]}
    lab.tester = lambda ctx, n: {"cases": [WRONG_CLAIM] if n == 0 else [], "replies": [{"case": o["case"], "keep": False, "why": "my expectation was wrong"} for o in ctx.get("OBJECTIONS") or []]}
    lab.to_code_review()
    out = lab.out("code")
    assert out["clean"] and out["set_aside"] == [] and out["failing"] == []
    assert next(c for c in out["cases"] if c["name"] == "two cities once each")["status"] == "withdrawn"
    lab.decide("approve")                                                                   # nothing is open: no reason is asked for


# ---------------------------------------------------------------------------------------------- 6. answers that cannot be used
def test_no_code_and_refused_code_are_never_run_and_wrong_shapes_do_not_stop_the_loop(lab):
    refused = "import os\n\n\ndef run(sources, out_csv):\n    return {\"rows_read\": len(os.listdir(\".\")), \"rows_written\": 0, \"total\": None}\n"
    answers = [{"code": 123, "notes": "not a list"}, {"code": refused, "notes": [{"x": 1}, 7]}, {"code": GOOD, "objections": "none", "remarks_answered": [3]}]
    lab.coder = lambda ctx, n: answers[min(n, 2)]
    lab.tester = lambda ctx, n: {"cases": [{"name": "a column the file does not have", "files": {"visits.csv": [{"Country": "IN"}]}, "expected_rows": []},
                                           {"name": "another file", "files": {"orders.csv": [{}]}, "expected_rows": None},
                                           {"name": "rows of the wrong width", "files": {"visits.csv": [{"City": "Goa"}]}, "expected_rows": [["Goa", 1, "x"]]},
                                           "not a data set", {"name": ""}], "remarks": 5, "replies": {"x": 1}, "notes": None}
    lab.to_code_review()
    out = lab.out("code")
    trail = json.load(open(out["trail_file"], encoding="utf-8"))["rounds"]
    assert trail[0]["static"] == ["the Coder gave no code"] and trail[0]["sample"] is None and trail[0]["tester"] is None
    assert any("imports os" in p for p in trail[1]["static"]) and trail[1]["sample"] is None and trail[1]["cases"] == []        # refused before it could run
    assert not os.path.exists(os.path.join(lab.runner.sandbox(lab.rid, "family4_" + lab.item), "r2"))                          # no data set ran on it
    assert "the program's check of the code text" in lab.of("coder")[2]["WHAT_FAILED"][0]["found_by"]
    assert out["rounds_used"] == 3 and out["clean"] and lab.calls.count("tester") == 1                                          # the Tester is asked only about code that may run
    assert len(trail[2]["tester"]["refused"]) == 5 and "which the header of visits.csv does not have" in trail[2]["tester"]["refused"][0]
    assert [c["name"] for c in out["cases"] if c["by"] == "the Tester"] == []


def test_without_a_model_the_stand_in_gives_a_fixed_path(lab):
    lab.req = lab.coder = lab.tester = lambda ctx, n: "standin"
    lab.managers = None
    real = lab.ask

    def ask(run_id, agent, instruction, context, schema_text, must_have, standin, **kw):
        if agent.startswith("f4_asks"):
            lab.calls.append("asks")
            return standin(), "stand-in (no model)", ""
        return real(run_id, agent, instruction, context, schema_text, must_have, standin, **kw)
    lab.runner.ask = ask
    lab.work()
    assert [k["status"] for k in lab.out("req")["data_needed"]] == ["found", "found"] and lab.review()["data"]["open"] == 0
    lab.decide("approve")
    lab.work()
    out = lab.out("code")
    # the stand-in has code only for the seeded procedures and for the share of one column: here it has none, and says so after one round
    assert out["rounds_used"] == 1 and out["problems"] == ["the Coder gave no code"] and "no model is connected" in out["stopped_because"]
    with pytest.raises(ValueError, match="cannot become the verified code"):
        lab.decide("approve", comment="x")


# ---------------------------------------------------------------------------------------------- 7. approve, reuse, feedback
def test_approved_code_is_the_verified_code_and_is_used_again_without_any_model_call(lab):
    lab.to_code_review()
    code_file = lab.out("code")["code_file"]
    lab.decide("approve")
    c = lab.rule()["code"]
    assert c["path"] == code_file and c["verified_by"] == "Sagar" and c["clean"] is True and c["rounds_used"] == 1 and c["trail"].endswith(".trail.json")
    assert PR.code_state(lab.rule())["verified"]
    lab.calls.clear()
    lab.start()                                                                            # Code it again: nothing is asked, nothing is coded
    assert lab.work()["state"] == "skipped" and lab.work()["state"] == "done" and lab.calls == []
    assert lab.out("code") == {"kind": "python", "verified": True, "code_file": code_file, "procedure_version": 1, "verified_by": "Sagar", "reused": True}


def test_approved_requirements_are_used_again_for_the_same_procedure(lab):
    lab.work()
    lab.decide("approve", edits={"rounds": 2})
    lab.eng.stop(lab.rid, "Sagar")
    lab.runner.resume(lab.rid)
    lab.calls.clear()
    lab.start()
    st = lab.work()
    assert st["state"] == "skipped" and "requirements approved before" in st["note"] and "requirements" not in lab.calls
    lab.work()
    assert lab.out("code")["rounds_most"] == 2 and lab.of("coder")[-1]["REQUIREMENTS"]["requirements"][0] == {"id": "R1", "text": "Read visits.csv."}


def test_a_change_with_a_comment_starts_the_rounds_again_from_the_last_code(lab):
    lab.to_code_review()
    first = lab.out("code")
    lab.decide("change", comment="write the count before the city? no: keep the order, but name the code's variables in full words")
    lab.calls.clear()
    lab.work()
    again = lab.of("coder")[-1]
    assert again["YOUR_LAST_CODE"] == GOOD and again["ADMIN_FEEDBACK"][0].startswith("write the count before") and again["ROUND"] == "1 of at most 10"
    out = lab.out("code")
    trail = json.load(open(out["trail_file"], encoding="utf-8"))["rounds"]
    assert [x["round"] for x in trail] == [1, 2] and trail[1]["after_the_admins_feedback"].startswith("write the count before")
    assert out["code_file"] != first["code_file"] and out["code_file"].endswith(".r2.py")
    assert [c["name"] for c in out["cases"]].count("spaces around the city") == 1          # the data sets made before are kept and run again
    assert lab.review()["data"]["f4"]["rounds_used"] == 1


def test_inside_the_flow_the_same_steps_run_and_the_flows_hooks_reach_family_4(tmp_path, monkeypatch):
    lab = Lab(tmp_path, monkeypatch, kinds={"flow": pipeline, "rule_code": family4})
    t = time.time()
    lab.rid = lab.store.exec("INSERT INTO run (project, kind, target, params, state, created, updated, heartbeat) VALUES (?,?,?,?,?,?,?,?)",
                             (lab.pid, "flow", "", json.dumps({"started_by": "Sagar"}), "running", t, t, t))
    lab.eng.insert_steps(lab.rid, -1, pipeline.item_steps("analytics", "other", lab.item, "Visits per city", False))
    lab.req = lambda ctx, n: req_answer(questions=["Count empty cities?"] if not ctx["ADMIN_SAID"]["answers"] else [])
    key = "f3:analytics/other/%s:" % lab.item
    assert lab.work()["key"] == key + "req" and lab.review()["title"] == "Requirements: Visits per city"
    lab.decide("change", comment=family4.ANSWERS_NOTE, edits={"answers": {"0": "yes, as (blank)"}})
    assert json.loads(lab.step("req")["input"])["qa"][0]["answer"] == "yes, as (blank)"
    lab.work()
    lab.decide("approve", edits={"rounds": 4})
    assert json.loads(lab.step("code")["input"])["rounds"] == 4
    st = lab.work()
    assert st["key"] == key + "code" and st["state"] == "needs_review" and lab.out("code")["rounds_most"] == 4
    lab.decide("approve")
    assert PR.code_state(lab.rule())["verified"] and lab.step("code")["state"] == "approved"


# ---------------------------------------------------------------------------------------------- the pieces
def test_compare_reads_numbers_by_value_and_says_the_first_difference():
    cols = ["City", "count"]
    assert family4.compare([["Pune", 2], ["Goa", "1.0"]], True, cols, [["Pune", "2"], ["Goa", "1"]], cols) == ""
    assert family4.compare([["Goa", 1], ["Pune", 2]], False, cols, [["Pune", "2"], ["Goa", "1"]], cols) == ""
    assert "line 1: expected ['Goa', '1'], the code wrote ['Pune', '2']" in family4.compare([["Goa", 1], ["Pune", 2]], True, cols, [["Pune", "2"], ["Goa", "1"]], cols)
    assert family4.compare([["Pune", 2]], True, cols, [["Pune", "2"], ["Goa", "1"]], cols).startswith("expected 1 line, the code wrote 2")
    assert "header" in family4.compare(None, False, ["city", "count"], [], cols) and family4.compare(None, False, cols, [["x", "1"]], cols) == ""
    assert family4.compare([["01", "x"]], True, cols, [["1", "x"]], cols) == "" and family4.compare([["a ", ""]], True, cols, [["a", ""]], cols) == ""


TREE_PROC = {"source_data": [{"file": "the tree", "columns": ["nvme_command: OPC", "nvme_transaction: Type"]}],
             "steps": ["For each NVMe command of the tree, in file order: count the NVMe transactions directly under it.",
                       "Output one line per command: its row number, its OPC cell as it is, the number of its NVMe transactions."],
             "output": {"columns": ["command row", "OPC", "transactions"], "order": "the command's row number"}}
TREE_CODE = '''import csv


def run(tree, out_csv):
    n = 0
    with open(out_csv, "w", newline="", encoding="utf-8") as out:
        w = csv.writer(out)
        w.writerow(["command row", "OPC", "transactions"])
        # step 1: each command and the transactions directly under it
        for cmd in tree.rows("nvme_command"):
            n += 1
            # step 2: one line per command
            w.writerow([cmd.row, cmd.get("OPC", ""), len(tree.children("nvme_command", cmd.row, "nvme_transaction"))])
    return {"rows_read": n, "rows_written": n, "total": None}
'''


def test_a_procedure_on_the_tree_is_tested_on_small_trees_given_by_their_parent_links(tmp_path, monkeypatch):
    lab = Lab(tmp_path, monkeypatch)
    r = family3.add_item("analytics", "nvme_command", "Transactions per command", "how many NVMe transactions each command has", "Sagar")
    r, _ = PR.store(r, TREE_PROC, "Sagar")
    family3.save_rule(r)
    db = os.path.join(lab.root, "tree.sqlite")                                             # the "tree of the analysis": three commands, four transactions
    family4.tiny_tree(db, {"nvme_command": [{"row": i, "cells": {"OPC": "0x02 (Read)"}} for i in (1, 2, 3)],
                           "nvme_transaction": [{"row": i, "cells": {"Type": "x"}, "parent": ["nvme_command", p]} for i, p in ((1, 1), (2, 1), (3, 2), (4, 3))]},
                      None, {"nvme_command": ["OPC"], "nvme_transaction": ["Type"]})
    monkeypatch.setattr(family3, "recording", lambda ctx: (db, None, {PR.TREE: db}))
    lab.item = r["id"]
    lab.rid = lab.eng.start(lab.pid, "rule_code", "Code it", {"_kind": "rule_code", "section": "analytics", "level": "nvme_command", "id": r["id"]})
    lab.req = lambda ctx, n: {"requirements": ["Count."], "data_needed": [{"what": "the opcode", "file": "the tree", "column": "nvme_command: OPC", "why": "step 2"}]}
    lab.coder = lambda ctx, n: {"notes": ["children of each command"], "code": TREE_CODE}
    case = {"name": "a command without a transaction, and a transaction without a parent", "why": "step 1 counts only the transactions under the command",
            "tree": {"nvme_command": [{"row": 1, "cells": {"OPC": "0x01 (Write)"}}, {"row": 2, "cells": {"OPC": ""}}],
                     "nvme_transaction": [{"row": 1, "cells": {"Type": "a"}, "parent": ["nvme_command", 1]}, {"row": 2, "cells": {"Type": "b"}, "parent": None}]},
            "expected_rows": [[1, "0x01 (Write)", 1], [2, "", 0]], "order_matters": True}
    lab.tester = lambda ctx, n: {"cases": [case, {"name": "a level that is not one", "tree": {"commands": []}, "expected_rows": None}], "nothing_more": True}
    lab.work()
    assert lab.out("req")["data_needed"][0]["status"] == "found" and "TREE" not in lab.review()["body"]
    lab.decide("approve")
    st = lab.work()
    out = lab.out("code")
    assert st["state"] == "needs_review" and out["clean"] and out["rounds_used"] == 1, (st.get("error"), out.get("problems"))
    r1 = json.load(open(out["trail_file"], encoding="utf-8"))["rounds"][0]
    assert {c["name"]: c["status"] for c in r1["cases"]} == {"an empty tree": "passed", "one row per level, every cell empty, no parent": "passed",
                                                             "a command without a transaction, and a transaction without a parent": "passed"}
    assert r1["sample"]["on"] == "the tree of this analysis" and r1["sample"]["lines"] == 3 and "which is not a level" in r1["tester"]["refused"][0]
    assert "DATA_SHAPE" in lab.of("tester")[0] and "parent links" in lab.of("tester")[0]["DATA_SHAPE"]


# ---------------------------------------------------------------------------------------------- the effort over the Model connection
def test_the_effort_goes_over_the_model_connection_and_is_left_out_when_the_address_refuses_it(tmp_path, monkeypatch):
    """With a company URL every call goes over the Model connection: "think harder" must hold there too (http_effort).
    An address that refuses the field gets the same call once more without it, and is not asked for it again."""
    from agentic import core as C
    r = C.AgentRunner(str(tmp_path), runtime="http", web=False)
    calls = []

    def taken(prompt, web=False, effort=None):
        calls.append(effort)
        return {"a": 1}, "m (model connection)"
    monkeypatch.setattr(r, "_http_call", taken)
    ans, producer = r._http("p", False, "xhigh")
    assert calls == ["xhigh"] and producer.endswith(", effort xhigh") and ans == {"a": 1}
    del calls[:]
    assert r._http("p", False, None)[1] == "m (model connection)" and calls == [None]         # nothing said: as before

    def refused(prompt, web=False, effort=None):
        calls.append(effort)
        if effort:
            raise RuntimeError("HTTP 400: output_config: Extra inputs are not permitted")
        return {"a": 1}, "m (model connection)"
    monkeypatch.setattr(r, "_http_call", refused)
    del calls[:]
    ans, producer = r._http("p", False, "xhigh")
    assert calls == ["xhigh", None] and "did not take the effort setting" in producer
    ans, producer = r._http("p", False, "xhigh")
    assert calls == ["xhigh", None, None] and "did not take the effort setting" in producer   # remembered: not asked again

    def no_credit(prompt, web=False, effort=None):
        raise RuntimeError("HTTP 402: no credit")
    monkeypatch.setattr(r, "_http_call", no_credit)
    r.effort_refused = ""
    with pytest.raises(RuntimeError, match="402"):
        r._http("p", False, "xhigh")                    # never retried as if the effort were the reason


def test_the_request_over_the_model_connection_carries_the_effort_only_when_asked(tmp_path, monkeypatch):
    import io
    import urllib.request
    from agentic import core as C
    r = C.AgentRunner(str(tmp_path), runtime="http", web=False, http_model="claude-sonnet-5-5")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key-not-real")
    monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
    sent = []

    class Resp(io.BytesIO):
        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

    def urlopen(req, timeout=None):
        sent.append(json.loads(req.data.decode()))
        return Resp(json.dumps({"content": [{"type": "text", "text": "{\"a\": 1}"}], "stop_reason": "end_turn"}).encode())
    monkeypatch.setattr(urllib.request, "urlopen", urlopen)
    r._http_call("p", False, "xhigh")
    r._http_call("p", False)
    assert sent[0]["output_config"] == {"effort": "xhigh"} and "output_config" not in sent[1]


# ---------------------------------------------------------------------------------------------- 8. a column under another name
# (owner, 2026-11-14: "if there is a column name is not available, it doesn't mean that the column itself might not be present")
DUR_PROC = {"source_data": [{"file": "visits.csv", "columns": ["City", "Duration"]}],
            "steps": ["Read visits.csv row by row with Python's csv reader.",
                      "Duration: how long the visit lasted, in whole minutes, read as a whole number; a row with an empty cell is left out.",
                      "For each City: the sum of Duration.",
                      "Output one line per city: City, minutes; the city by name."],
            "output": {"columns": ["City", "minutes"], "order": "City"}}


def dur_lab(tmp_path, monkeypatch):
    lab = Lab(tmp_path, monkeypatch, proc=DUR_PROC).start()
    lab.req = lambda ctx, n: {"requirements": ["Sum the minutes of each city."], "data_needed": [{"what": "the city of a visit", "file": "visits.csv", "column": "City", "why": "step 3"}]}
    return lab


def test_a_column_missing_under_its_name_is_looked_for_and_the_admins_choice_lifts_the_block(tmp_path, monkeypatch):
    lab = dur_lab(tmp_path, monkeypatch)
    lab.matcher = lambda ctx, n: {"choices": [{"column": "Minutes", "why": "its meaning is how long the visit lasted"}, {"column": "Length", "why": "invented"}], "none_of_these": False}
    lab.work()
    out, rv = lab.out("req"), lab.review()
    assert out["blocking"] == ["visits.csv has no column Duration (its header was read by code)"]
    q = rv["data"]["questions"][0]
    assert q["kind"] == "substitute" and q["wanted_column"] == "Duration" and q["choices"] == ["use", "not_same", "add_file"]
    p0 = q["proposals"][0]
    assert (p0["file"], p0["column"], p0["level"], p0["model_picked"]) == ("visits.csv", "Minutes", "the kind of data matches", True)
    assert all(p["column"] != "Length" for p in q["proposals"])                               # a name the model invents is never proposed
    shown = lab.of("match")[0]
    assert shown["WANTED"]["column_named_by_the_rule"] == "Duration" and "how long the visit lasted" in shown["WANTED"]["what_it_should_hold"]
    assert "The rule needs the column Duration of visits.csv" in rv["body"] and "**visits.csv: Minutes** (the kind of data matches)" in rv["body"]
    assert "means: how long the visit lasted, in minutes" in rv["body"] and rv["data"]["open"] == 1
    with pytest.raises(ValueError, match="cannot be made yet"):
        lab.decide("approve", edits={"accept_open": True})                                   # nothing is substituted without the admin's choice
    with pytest.raises(ValueError, match="say which of the columns shown"):
        lab.decide("change", comment=family4.ANSWERS_NOTE, edits={"choices": {"0": {"choice": "use"}}})
    lab.decide("change", comment=family4.ANSWERS_NOTE, edits={"choices": {"0": {"choice": "use", "proposal": 0}}, "answers": {"0": "use visits.csv: Minutes"}})
    dec = json.loads(lab.step("req")["input"])["substitutes"]
    assert [(d["choice"], d["file"], d["column"], d["wanted_column"], d["by"]) for d in dec] == [("use", "visits.csv", "Minutes", "Duration", "Sagar")]
    lab.work()
    out, rv = lab.out("req"), lab.review()
    assert out["blocking"] == [] and rv["data"]["open"] == 0 and rv["data"]["questions"] == [] and lab.calls.count("match") == 1      # not searched again
    assert "**visits.csv column Minutes** stands for it, as Sagar chose" in rv["body"]
    said = lab.of("requirements")[1]
    assert said["SUBSTITUTES"] == [{"needed": "the column Duration of visits.csv, which the procedure names", "the_admin_chose": "use visits.csv column Minutes for it"}]
    assert said["ADMIN_SAID"]["answers"][0]["answer"] == "use visits.csv column Minutes for it (the kind of data matches)"
    assert next(c for c in said["DATA"][0]["columns"] if c["name"] == "Duration")["stands_for_it"] == "Minutes"
    lab.coder = lambda ctx, n: {"notes": ["Minutes stands for Duration"], "code": GOOD.replace('head.index("City")', 'head.index("City")').replace('["City", "count"]', '["City", "minutes"]')}
    lab.tester = lambda ctx, n: {"cases": [], "nothing_more": True}
    lab.decide("approve")
    lab.work()
    coder = lab.of("coder")[0]
    assert coder["REQUIREMENTS"]["columns_that_stand_for_others"] == [{"the_procedure_names": "visits.csv: Duration", "read_instead": "visits.csv: Minutes",
                                                                       "chosen_by": "Sagar", "support": "the kind of data matches"}]
    assert next(c for c in coder["FILES"][0]["COLUMNS"] if c["name"] == "Duration")["real_values_seen"][:2] == ["10", "5"]       # the real values of the column that is read
    assert lab.rule()["coding"]["requirements"]["substitutes"][0]["column"] == "Minutes"


def test_not_the_same_and_i_will_add_the_file_are_kept_and_not_asked_again(tmp_path, monkeypatch):
    lab = dur_lab(tmp_path / "a", monkeypatch)
    lab.work()
    assert lab.review()["data"]["questions"][0]["kind"] == "substitute"
    lab.decide("change", comment=family4.ANSWERS_NOTE, edits={"choices": {"0": {"choice": "not_same"}}, "answers": {"0": "none of these"}})
    lab.work()
    rv = lab.review()
    assert rv["data"]["questions"] == [] and rv["data"]["blocking"] and "you said of 1 that they are not the same" in rv["body"]
    assert lab.of("requirements")[1]["SUBSTITUTES"][0]["the_admin_chose"] == "visits.csv column Minutes is not the same"
    with pytest.raises(ValueError, match="cannot be made yet"):
        lab.decide("approve", comment="go on")
    lab2 = dur_lab(tmp_path / "b", monkeypatch)
    lab2.work()
    lab2.decide("change", comment=family4.ANSWERS_NOTE, edits={"choices": {"0": {"choice": "add_file"}}})
    lab2.work()
    rv = lab2.review()
    assert rv["data"]["questions"] == [] and "said the file that holds it will be added" in rv["body"] and "Read the new files" in rv["body"] and rv["data"]["blocking"]
    assert lab2.calls.count("match") == 1                                                   # after "I will add the file" nothing is searched again


def test_a_kind_of_data_family_1_did_not_find_is_looked_for_by_its_meaning(lab):
    lab.req = lambda ctx, n: req_answer(extra=[{"what": "how long the visit lasted in minutes", "file": "", "column": "", "why": "x"}])
    lab.managers = lambda file, kinds: [{"kind": k["kind"], "present": "no" if "how long the visit lasted in" in k["question"] else "yes",
                                         "matches": [] if "how long the visit lasted in" in k["question"] else [{"column": "City", "keyword": ""}]} for k in kinds]
    lab.work()
    out, rv = lab.out("req"), lab.review()
    assert out["data_needed"][2]["status"] == "not found" and rv["data"]["questions"][0]["kind"] == "substitute"
    assert rv["data"]["questions"][0]["proposals"][0]["column"] == "Minutes"
    lab.decide("change", comment=family4.ANSWERS_NOTE, edits={"choices": {"0": {"choice": "use", "proposal": 0}}})
    lab.work()
    k = lab.out("req")["data_needed"][2]
    assert k["status"] == "found" and k["named"]["column"] == "Minutes" and k["named"]["chosen_by_the_admin"] is True and lab.review()["data"]["not_found"] == []
    lab.decide("approve")                                                                   # nothing is open any more


# ---------------------------------------------------------------------------------------------- 9. two programs: a real doubt is a question
EMPTY_DROPPED = GOOD.replace('v = (row[i].strip() if i < len(row) else "") or "(blank)"', 'v = row[i].strip() if i < len(row) else ""\n            if not v:\n                continue')
assert EMPTY_DROPPED != GOOD


def test_two_programs_that_agree_ask_nothing_and_the_tester_never_sees_the_code(lab):
    lab.second = lambda ctx, n: {"notes": ["my own reading"], "code": GOOD + "# written independently\n"}
    lab.to_code_review()
    out = lab.out("code")
    assert out["clean"] and out["rounds_used"] == 1 and "doubt" not in out and out["second_program"] is True
    assert lab.calls.count("second") == 1 and lab.calls.count("coder") == 1
    assert "f4_second_" + lab.item in lab.agents and "YOUR_LAST_CODE" not in lab.of("second")[0] and "ADMIN_FEEDBACK" not in lab.of("second")[0]
    t = lab.of("tester")[0]
    assert "THE_CODE" not in t and "def run(" not in json.dumps(t)                           # the Tester works from the requirements alone
    assert next(k for a, _c, k in lab.seen if a == "second")["effort"] == "xhigh"
    r1 = json.load(open(out["trail_file"], encoding="utf-8"))["rounds"][0]
    assert r1["second_program"]["usable"] is True and r1["doubts"] == [] and os.path.exists(r1["second_program"]["code_file"])
    assert "working from the requirements alone" in out["stopped_because"]


def test_two_programs_that_differ_become_one_question_with_the_rows_and_the_answer_goes_on(lab):
    lab.second = lambda ctx, n: {"code": EMPTY_DROPPED if n == 0 else GOOD}
    st = lab.to_code_review()
    out, rv = lab.out("code"), lab.review()
    assert st["state"] == "needs_review" and out["doubt"] is True and rv["title"] == "Which result is meant: Visits per city"
    assert rv["data"]["f4_doubt"] and rv["data"]["f4_req"] and len(rv["data"]["questions"]) == 2        # the empty record, and the record cut after its first cell
    q = rv["data"]["questions"][0]
    assert q["kind"] == "doubt" and q["first"] == [["(blank)", "1"]] and q["second"] == [] and q["choices"] == ["first", "second", "neither"]
    assert "one record with every cell empty" in q["question"] and q["data"] == {"visits.csv": [{}]}
    assert "the first program wrote: [[\"(blank)\", \"1\"]]" in rv["body"] and "the second program wrote: []" in rv["body"] and "the rule can be read in two ways" in rv["body"]
    with pytest.raises(ValueError, match="say first which result is meant"):
        lab.decide("approve", comment="fine")                                               # no code is approved while the rule is read two ways
    with pytest.raises(ValueError, match="say first which result is meant"):
        lab.decide("change", comment="", edits={"choices": {}})
    lab.decide("change", comment=family4.ANSWERS_NOTE, edits={"choices": {"0": {"choice": "first"}, "1": {"choice": "first"}}, "answers": {"0": "the first is meant"}})
    inp = json.loads(lab.step("code")["input"])
    assert inp["doubt_turns"] == 1 and inp["doubts_answered"][0]["choice"] == "first" and inp["doubts_answered"][0]["rows"] == [["(blank)", "1"]] and len(inp["doubts_answered"]) == 2
    lab.work()
    out = lab.out("code")
    assert out.get("doubt") is None and out["clean"] and lab.calls.count("second") == 2      # asked again with the answer: now the two agree
    again = lab.of("coder")[1]
    assert again["YOUR_LAST_CODE"] == GOOD and "the first result is meant" in again["ADMIN_FEEDBACK"][0]
    assert again["REQUIREMENTS"]["the_admins_answers"][-2]["answer"].startswith("the first result is meant: [[\"(blank)\", \"1\"]]")
    case = next(c for c in out["cases"] if c["name"] == "one record with every cell empty")
    assert case["by"] == "the admin's answer" and case["expected_rows"] == [["(blank)", "1"]] and case["status"] == "passed"
    lab.decide("approve")
    assert lab.rule()["code"]["verified_by"] == "Sagar"


def test_when_the_second_result_is_meant_its_program_is_the_start(lab):
    lab.coder = lambda ctx, n: {"code": EMPTY_DROPPED if n == 0 else ctx["YOUR_LAST_CODE"]}
    lab.second = lambda ctx, n: {"code": GOOD}
    lab.to_code_review()
    assert lab.out("code")["doubt"] is True
    lab.decide("change", comment=family4.ANSWERS_NOTE, edits={"choices": {"0": {"choice": "second"}, "1": {"choice": "second"}}})
    lab.work()
    assert lab.of("coder")[1]["YOUR_LAST_CODE"] == GOOD and lab.out("code")["clean"]          # the round went on from the program whose result is meant


def test_the_admin_is_asked_which_is_meant_three_times_at_most(lab):
    lab.second = lambda ctx, n: {"code": EMPTY_DROPPED}
    lab.to_code_review()
    for turn in (1, 2):
        assert lab.out("code")["doubt"] is True
        lab.decide("change", comment="neither: an empty city is counted under the name (none)", edits={})
        lab.work()
    assert lab.out("code")["doubt"] is True and "this is time 3" in lab.review()["body"]
    lab.decide("change", comment="still neither", edits={})
    lab.work()
    out = lab.out("code")
    assert out.get("doubt") is None and lab.calls.count("second") == 3                       # the fourth build writes no second program and asks no more


def test_an_expectation_both_programs_contradict_is_set_aside_not_failed(lab):
    lab.second = lambda ctx, n: {"code": GOOD + "# second\n"}
    lab.tester = lambda ctx, n: {"cases": [WRONG_CLAIM] if n == 0 else [], "nothing_more": True}
    lab.to_code_review()
    out, body = lab.out("code"), lab.review()["body"]
    assert out["rounds_used"] == 1 and out["failing"] == [] and out["set_aside"] == ["two cities once each"] and out["clean"]
    case = next(c for c in out["cases"] if c["name"] == "two cities once each")
    assert case["expectation_doubted"] is True and "the expectation may be wrong" in case["detail"] and 'both wrote [["Goa", "1"], ["Pune", "1"]]' in case["detail"]
    assert "the expectation may be wrong" in body and "a second program, written independently" in body
    with pytest.raises(ValueError, match="not settled"):
        lab.decide("approve")                                                               # the admin judges it, in words


# ---------------------------------------------------------------------------------------------- 10. a fresh program after three repairs
def test_after_three_rounds_on_one_program_the_coder_starts_a_fresh_one_in_a_new_conversation(lab):
    lab.coder = lambda ctx, n: {"notes": ["try %d" % (n + 1)], "code": BAD + "# try %d\n" % (n + 1)}
    lab.to_code_review(rounds=5)
    out = lab.out("code")
    coders = [a for a in lab.agents if a.startswith("f4_coder_")]
    assert coders == ["f4_coder_" + lab.item] * 3 + ["f4_coder_%s_fresh2" % lab.item] * 2
    fourth, fifth = lab.of("coder")[3], lab.of("coder")[4]
    assert "FRESH_START" in fourth and "YOUR_LAST_CODE" not in fourth and "spaces around the city" in json.dumps(fourth["WHAT_FAILED"])
    assert "program 2" in fourth["FRESH_START"] and "FRESH_START" not in fifth and fifth["YOUR_LAST_CODE"].endswith("# try 4\n")
    trail = json.load(open(out["trail_file"], encoding="utf-8"))["rounds"]
    assert [(x["program"], x["fresh_program"]) for x in trail] == [(1, False), (1, False), (1, False), (2, True), (2, False)]
    assert out["programs_written"] == 2 and out["rounds_used"] == 5


def test_with_a_kept_conversation_a_later_round_carries_only_what_is_new(lab):
    lab.runner.sessions = object()                       # the runner keeps a conversation per agent (AgentRunner.api_turn)
    lab.coder = lambda ctx, n: {"code": BAD if n == 0 else GOOD}
    lab.to_code_review()
    first, second = lab.of("coder")
    assert "PROCEDURE" in first and "FILES" in first
    assert "PROCEDURE" not in second and "FILES" not in second and "REQUIREMENTS" not in second and "ABOVE_IN_THIS_CONVERSATION" in second
    assert second["YOUR_LAST_CODE"] == BAD and second["WHAT_FAILED"] and lab.out("code")["clean"]


# ---------------------------------------------------------------------------------------------- 11. Family 2 is asked about the tree
def test_family_2_says_what_it_knows_of_the_tree_the_rule_reads(tmp_path, monkeypatch):
    import sqlite3
    lab = Lab(tmp_path, monkeypatch)
    r = family3.add_item("analytics", "nvme_command", "Transactions per command 2", "how many NVMe transactions each command has", "Sagar")
    r, _ = PR.store(r, TREE_PROC, "Sagar")
    family3.save_rule(r)
    db = os.path.join(lab.root, "tree.sqlite")
    family4.tiny_tree(db, {"nvme_command": [{"row": i, "cells": {"OPC": "0x02 (Read)"}} for i in (1, 2, 3)],
                           "nvme_transaction": [{"row": i, "cells": {"Type": "x"}, "parent": ["nvme_command", p] if p else None} for i, p in ((1, 1), (2, 1), (3, 2), (4, None))]},
                      None, {"nvme_command": ["OPC"], "nvme_transaction": ["Type"]})
    con = sqlite3.connect(db)
    con.execute("CREATE TABLE meta (k TEXT PRIMARY KEY, v TEXT)")
    con.execute("INSERT INTO meta VALUES ('build', ?)", (json.dumps({"steps": {"ntx_to_cmds": {"ntx_rows": 4, "ntx_matched": 3, "ntx_outside_any_command": 1, "seconds": 0.2}}}),))
    con.commit()
    con.close()
    monkeypatch.setattr(family3, "recording", lambda ctx: (db, None, {PR.TREE: db}))
    lab.item = r["id"]
    lab.rid = lab.eng.start(lab.pid, "rule_code", "Code it", {"_kind": "rule_code", "section": "analytics", "level": "nvme_command", "id": r["id"]})
    lab.req = lambda ctx, n: {"requirements": ["Count."], "data_needed": [{"what": "the opcode", "file": "the tree", "column": "nvme_command: OPC", "why": "step 2"}]}
    lab.work()
    out, body = lab.out("req"), lab.review()["body"]
    assert "**Family 2 was asked about the tree this rule reads:**" in body
    assert any("1 of them are not joined to a row of the level above" in x and "NVME_Transactions" in x for x in out["family_2"]), out["family_2"]
    assert any(x.startswith("Join ntx to cmds, as the build counted it: ntx rows 4; ntx matched 3; ntx outside any command 1") for x in out["family_2"])
    assert lab.of("requirements")[0]["THE_TREE"]["what_family_2_reports"] == out["family_2"]
    lab.coder = lambda ctx, n: {"code": TREE_CODE}
    lab.tester = lambda ctx, n: {"cases": [], "nothing_more": True}
    lab.decide("approve")
    lab.work()
    assert lab.of("coder")[0]["REQUIREMENTS"]["what_family_2_reports_about_the_tree"] == out["family_2"]


def test_the_instructions_are_documents_and_ask_for_no_reasoning():
    from agentic import prompts
    for name in ("f4_requirements", "f4_coder", "f4_tester", "f4_family1", "column_match"):
        text = prompts.load(name, questions_most=8, cases_per_round=5)
        assert text and "{{" not in text and "last change:" not in text, name               # the notes for people are not sent; every place is filled
        assert "reasoning" not in text.lower() and "chain of thought" not in text.lower(), name
    assert "have not seen the program" in family4.tester_instruction() and "THE_CODE" not in family4.tester_instruction()
    assert family4.coder_instruction(False).rstrip().endswith(PR.CODER_INSTRUCTION.split("THE CODE MUST:", 1)[1].rstrip())
    assert '"property"' in family4.TESTER_SHAPE_FILES and "reasoning" not in family4.CODER_SHAPE


def test_inside_the_flow_the_answer_to_which_result_is_meant_reaches_family_4(tmp_path, monkeypatch):
    lab = Lab(tmp_path, monkeypatch, kinds={"flow": pipeline, "rule_code": family4})
    t = time.time()
    lab.rid = lab.store.exec("INSERT INTO run (project, kind, target, params, state, created, updated, heartbeat) VALUES (?,?,?,?,?,?,?,?)",
                             (lab.pid, "flow", "", json.dumps({"started_by": "Sagar"}), "running", t, t, t))
    lab.eng.insert_steps(lab.rid, -1, pipeline.item_steps("analytics", "other", lab.item, "Visits per city", False))
    lab.second = lambda ctx, n: {"code": EMPTY_DROPPED if n == 0 else GOOD}
    lab.work()
    lab.decide("approve")
    st = lab.work()
    assert st["key"].endswith(":code") and lab.out("code")["doubt"] is True and lab.review()["data"]["f4_doubt"]
    with pytest.raises(ValueError, match="say first which result is meant"):
        lab.decide("approve")
    lab.decide("change", comment=family4.ANSWERS_NOTE, edits={"choices": {"0": {"choice": "first"}, "1": {"choice": "first"}}})
    assert json.loads(lab.step("code")["input"])["doubt_turns"] == 1
    lab.work()
    assert lab.out("code").get("doubt") is None and lab.out("code")["clean"]
    lab.decide("approve")
    assert PR.code_state(lab.rule())["verified"]
