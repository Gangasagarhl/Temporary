"""The joins of the tree build look rows up instead of asking the database, or walking a list, for every row
(2026-11-14; owner: "don't involve that big of n square kind of lookup"). What they decide must be exactly what the
joins decided before.

tests/joins_as_they_were.py holds the four joins and the window of link rows as they were, word for word. Here both run
on the same data and must leave the same scratch tables and the same report:
  * on generated recordings made to be awkward (link rows no packet names, a PSN twice inside the window, TLPs with no
    link row, Acks that each acknowledge several TLPs, Naks, split rows whose time is not their request's, units on
    several memory pages and before the transaction's time, completion entries without a doorbell, queues made again),
    with small windows, and with the read-ahead lists made so small that they are let go and read again all the time;
  * on a whole sample recording, through the build itself.
"""
import json
import os
import random
import shutil
import sqlite3
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from nvme_hier import builder as B, loader as L          # noqa: E402
import joins_as_they_were as WAS                          # noqa: E402

LEVELS = ("nvme_command", "nvme_transaction", "split", "link", "packets")
SCRATCH = ("pkt_parent", "lnk_parent", "spl_parent", "ntx_parent", "lnk_dur", "spl_dur", "ntx_dur", "cmd_dur")
DIRS = ("Upstream", "Downstream")
TLP = ["MWr(64)", "MWr(32)", "MRd(64)", "MRd(32)", " MRd(64) ", "CplD", "Cpl", "Msg", "CfgRd0", "Odd", None, ""]
NTX_TYPES = ["SQ Tail Doorbell", "CQ Head Doorbell", "Completion Queue Head Doorbell", "Submission Queue Entry", "Completion Queue Entry",
             "Data Transfer", "PRP List", "MSI-X Interrupt", "Interrupt", "Controller Register", None, "Something else"]


def insert(con, table, cols, rows):
    con.executemany("INSERT INTO %s (rowid_file, %s) VALUES (%s)" % (table, ", ".join(cols), ", ".join("?" * (len(cols) + 1))),
                    [(i + 1,) + tuple(r) for i, r in enumerate(rows)])


def recording(path, seed):
    """A small recording of five tables, built by chance from `seed` so that every branch of the joins is met often."""
    rng = random.Random(seed)
    con = L.open_db(path)
    for k in LEVELS:
        L.create_tables(con, k)
    span = rng.choice([8, 16, 64, 4096])                    # how many sequence numbers there are before they come round again
    coalesce = rng.choice([1.0, 1.0, 0.6, 0.25, 0.0])       # the share of TLPs that get an Ack of their own
    links, packets, t = [], [], 1000
    psn = {d: rng.randrange(span) for d in DIRS}
    for _ in range(rng.randrange(40, 260)):
        d = rng.choice(DIRS)
        other = DIRS[1 - DIRS.index(d)]
        t += rng.randrange(1, 50)
        p = psn[d]
        psn[d] = (p + rng.choice([1, 1, 1, 1, 0, 2])) % span
        typ = rng.choice(TLP)
        lt = None if rng.random() < 0.04 else t
        links.append((d if rng.random() > 0.02 else None, p if rng.random() > 0.02 else None, rng.choice([None, 1, 2, 2, 2, 3]), lt, typ,
                      rng.choice(["00:01.0", "00:02.0", None]), rng.choice([0, 1, 2, 3, None]),
                      rng.choice([None, 0x1000, 0x1004, 0x1FFC, 0x2000, 0x3008, 0x50000, 0x7FFFF000]) if rng.random() < 0.8 else None))
        if rng.random() < 0.12:                             # a link row no packet names
            continue
        pt = lt if rng.random() > 0.06 else rng.choice([None, t + 1])
        packets.append((d, "MWr(64)", None, p, None, pt))
        if rng.random() < 0.08:
            packets.append((d, "MWr(64)", None, p, None, t + 2))            # the same TLP again
        if rng.random() < coalesce:
            packets.append((other, None, rng.choice(["Ack", "ACK", "ack"]), None, p, t + 3))
        elif rng.random() < 0.3:
            packets.append((other, None, "Ack", None, (p + rng.randrange(0, 4)) % span, t + 3))     # an Ack for a later number
        if rng.random() < 0.07:
            packets.append((other, None, rng.choice(["Nak", "NAK"]), None, (p + rng.choice([-2, -1, 0, 1, 3])) % span, t + 4))
        if rng.random() < 0.1:
            packets.append((rng.choice([d, None, "Sideways"]), None, rng.choice(["UpdateFC", "Ack", None, ""]), None, None if rng.random() < 0.7 else p, t + 5))
        if rng.random() < 0.06:
            packets.append((d, "MWr(64)", None, (p + rng.randrange(5, 4000)) % max(span, 4096), None, t + 6))    # a TLP whose link row is far away, or nowhere
    for _ in range(len(packets) // 6):                      # neighbours change places here and there
        i = rng.randrange(max(1, len(packets) - 1))
        packets[i:i + 2] = packets[i:i + 2][::-1]
    insert(con, "lnk", ("dir", "psn", "n_packets", "t_ps", "tlp_type", "rid", "tag", "addr"), links)
    insert(con, "pkt", ("dir", "tlp_type", "dllp_type", "psn", "acknak", "t_ps"), packets)
    # split rows: one for most requests (its own time, or another), some for no request, in an order that is nearly the links'
    splits = []
    for d, _p, _n, lt, typ, rid, tag, addr in links:
        if B.N.tlp_class(typ) == "non-posted" and rng.random() < 0.85:
            splits.append((d, rid, tag, rng.choice([None, 0, 1, 2, 2, 3]), lt if rng.random() > 0.15 else rng.choice([None, (lt or 0) + 7]), addr))
    for _ in range(rng.randrange(0, 6)):
        splits.append((rng.choice(DIRS), "00:09.0", rng.randrange(4), 2, rng.randrange(1000, t + 1), 0x9000))
    for _ in range(len(splits) // 5):
        i = rng.randrange(max(1, len(splits) - 1))
        splits[i:i + 2] = splits[i:i + 2][::-1]
    insert(con, "spl", ("dir", "rid", "tag", "n_links", "t_ps", "addr"), splits)
    # commands, some of them the creation of a completion queue, and their NVMe transactions
    cmds, ntx, ct = [], [], 1000
    bases = {}
    for _ in range(rng.randrange(8, 60)):
        ct += rng.randrange(1, 400)
        if rng.random() < 0.12:
            q = rng.randrange(1, 4)
            bases[q] = 0x40000 + 0x1000 * rng.randrange(8)
            cmds.append((0, 0, rng.randrange(8), rng.choice([None, 2, 3]), ct, 5, q, rng.choice([None, 4, 8]), bases[q]))
            ntx.append(("SQ Tail Doorbell", 0, None, None, ct, None, None, None, rng.choice([None, 1, 2])))
            continue
        sq = rng.randrange(1, 4)
        cid = rng.randrange(6)
        cmds.append((sq, rng.choice([sq, sq, None]), cid, rng.choice([None, 0, 3, 4, 5]), ct if rng.random() > 0.05 else None, 2, None, None, None))
        mine = [("SQ Tail Doorbell", sq, None, None, ct if rng.random() > 0.1 else ct + 1, None, 0x1000, 4, 1),
                ("Submission Queue Entry", None, sq, cid, ct + 5, None, 0x2000 + 64 * rng.randrange(4), 64, rng.choice([1, 2])),
                ("Data Transfer", None, sq, cid, ct + 9, None, rng.choice([0x50000, 0x50FF0, 0x7FFFF000]), rng.choice([8, 4096, 8192, None]), rng.choice([1, 2, 3, 6]))]
        if rng.random() < 0.9:
            slot = rng.randrange(8)
            mine.append(("Completion Queue Entry", None, sq, cid, ct + 20, None, None if rng.random() < 0.1 else bases.get(sq, 0x60000) + 16 * slot, 16, 1))
            if rng.random() < 0.1:
                mine.append(("Completion Queue Entry", None, sq, cid, ct + 22, None, None if rng.random() < 0.5 else bases.get(sq, 0x60000) + 16 * ((slot + 1) % 8), 16, 1))
            if rng.random() < 0.8:
                mine.append((rng.choice(["Interrupt", "MSI-X Interrupt"]), None, None, None, ct + 25, None, 0xFEE00000, 4, 1))
            if rng.random() < 0.15:
                mine.append(("Interrupt", None, None, None, ct + 26, None, 0xFEE00000, 4, 1))               # a second interrupt, no new entry
            if rng.random() < 0.6:                                                                          # one head doorbell for one or several entries
                mine.append((rng.choice(["CQ Head Doorbell", "Completion Queue Head Doorbell"]), rng.choice([sq, sq, sq, 9]), None, None, ct + 30,
                             rng.choice([None, slot + 1, slot + 1, rng.randrange(9)]), 0x1004, 4, 1))
        if rng.random() < 0.1:
            mine.append((rng.choice(NTX_TYPES), rng.choice([None, sq]), rng.choice([None, sq, 7]), rng.choice([None, cid, 5]), ct + 40, rng.choice([None, 3]),
                         rng.choice([None, 0x3008]), rng.choice([None, 4]), rng.choice([None, 1, 2])))
        ntx += [m for m in mine if rng.random() > 0.05]
    for _ in range(len(ntx) // 8):
        i = rng.randrange(max(1, len(ntx) - 1))
        ntx[i:i + 2] = ntx[i:i + 2][::-1]
    insert(con, "cmd", ("sqid", "cqid", "cid", "n_ntx", "t_ps", "opc", "qid", "qsize", "prp1"), cmds)
    insert(con, "ntx", ("type", "qid", "sqid", "cid", "t_ps", "db_index", "addr", "nbytes", "n_links_splits"), ntx)
    L.set_meta(con, "levels_present", list(LEVELS))
    if rng.random() < 0.2:
        L.set_meta(con, "cq_context", [[500, 1, 8, 0x41000], [600, 2, None, 0x42000]])
    con.commit()
    con.close()
    return {"look_links": rng.choice([1, 2, 3, 5, 16, 256]), "look_splits": rng.choice([1, 2, 3, 8]), "look_cmds": rng.choice([1, 4, 512])}


def decided(db, cls, join, settings, part):
    """Run one join of `cls` on the recording -> (every scratch table in key order, its report without the time)."""
    con = L.open_db(db)
    L.attach_work(con, db, part=part)
    try:
        b = cls(con, None, settings)
        getattr(b, join)()
        b._flush()
        con.commit()
        tables = {t: con.execute("SELECT * FROM w.%s ORDER BY rowid" % t).fetchall() for t in SCRATCH}
        left = sorted(r[0] for r in con.execute("SELECT name FROM w.sqlite_master WHERE type='table'") if r[0] not in SCRATCH)
        rep = {k: v for k, v in b.report["steps"][join].items() if k != "seconds"}
    finally:
        con.close()
        L.drop_work_part(L.work_path(db, part))
    return tables, rep, left


@pytest.fixture
def tight(monkeypatch):
    """The read-ahead lists made tiny: they are filled a row or two at a time and let go again and again."""
    def make(rng):
        monkeypatch.setattr(B, "SPLITS_AHEAD", rng.choice([1, 2, 64]))
        monkeypatch.setattr(B, "SPLITS_KEPT", rng.choice([0, 3, 200000]))
        monkeypatch.setattr(B, "UNITS_AHEAD", rng.choice([1, 2, 64]))
        monkeypatch.setattr(B, "UNITS_KEPT", rng.choice([0, 3, 200000]))
        monkeypatch.setattr(B, "BATCH", rng.choice([1, 7, 20000]))
        monkeypatch.setattr(B.LinkStream, "FETCH", rng.choice([1, 3, 512]))
        monkeypatch.setattr(B.LinkStream, "CUT", rng.choice([1, 5, 4096]))
    return make


@pytest.mark.parametrize("join", ["packets_to_links", "links_to_splits", "units_to_ntx", "ntx_to_cmds"])
def test_a_join_decides_what_it_decided_before(join, tmp_path, tight):
    seen = {"rows": 0, "members": 0}
    for seed in range(300):
        db = str(tmp_path / ("r%d.sqlite" % seed))
        settings = recording(db, seed)
        was = decided(db, WAS.BuildBefore, join, settings, "was")
        tight(random.Random(1000 + seed))
        now = decided(db, B.Build, join, settings, "now")
        assert now[1] == was[1], "seed %d, the report of %s: %s, before: %s" % (seed, join, now[1], was[1])
        for t in SCRATCH:
            assert now[0][t] == was[0][t], "seed %d, table %s after %s: first difference %s" % (
                seed, t, join, next(((a, b) for a, b in zip(now[0][t] + [None], was[0][t] + [None]) if a != b), None))
        assert now[2] == was[2] == [], "seed %d: scratch tables left behind: %s, before: %s" % (seed, now[2], was[2])
        seen["rows"] += sum(len(v) for v in was[0].values())
        seen["members"] += sum(1 for t in SCRATCH[:4] for r in was[0][t] if r[3] == "member")
        for ext in ("", "-wal", "-shm"):
            if os.path.exists(db + ext):
                os.remove(db + ext)
    assert seen["rows"] > 3000 and seen["members"] > 1000, "the generated recordings gave the join too little to decide: %s" % seen


def test_the_window_of_link_rows_finds_what_the_walk_found(tmp_path):
    """The window alone, asked at random: the same row, the same number of rows skipped, the same rows consumed."""
    for seed in range(60):
        rng = random.Random(seed)
        con = sqlite3.connect(":memory:")
        con.execute("CREATE TABLE lnk (rowid_file INTEGER PRIMARY KEY, dir TEXT, psn INTEGER, n_packets INTEGER, t_ps INTEGER)")
        span = rng.choice([3, 8, 4096])
        n = rng.randrange(0, 400)
        con.executemany("INSERT INTO lnk VALUES (?,?,?,?,?)", [(i + 1, "Upstream", rng.choice([None, rng.randrange(span)]) if rng.random() < 0.05 else rng.randrange(span),
                                                               rng.choice([None, 0, 1, 2]), rng.choice([None, 100 + i // 3])) for i in range(n)])
        look = rng.choice([1, 2, 7, 256])
        B.LinkStream.FETCH, B.LinkStream.CUT = rng.choice([1, 3, 512]), rng.choice([1, 5, 4096])
        try:
            now, was = B.LinkStream(con, "Upstream", look), WAS.LinkStreamBefore(con, "Upstream", look)
            for _ in range(600):
                psn, t = rng.choice([None, rng.randrange(span)]) if rng.random() < 0.05 else rng.randrange(span), rng.choice([None, 100 + rng.randrange(n // 3 + 2)])
                a, b = now.find(psn, t), was.find(psn, t)
                assert a == b, (seed, psn, t, a, b)
                if a is not None and rng.random() < 0.8:
                    assert now.take(a) == was.take(b), seed
                assert now.consumed == was.consumed
            assert len(now.rows) <= B.LinkStream.CUT + look + B.LinkStream.FETCH, "the list of the window grew: %d rows" % len(now.rows)
            assert sum(len(v) for v in now.by_psn.values()) == now.inside <= look
        finally:
            B.LinkStream.FETCH, B.LinkStream.CUT = 512, 4096


def test_many_tlps_under_one_ack_do_not_slow_the_acks_down(tmp_path):
    """An Ack acknowledges every TLP up to its number, so most TLPs never get an Ack of their own and their link transactions stay open (as before: up to
    4,096 of them, one for each sequence number). Before, every Ack walked all the open ones; now it looks at the complete ones only, of which there are
    none here. The same links, in a third of the time at most (measured on 2026-11-14 for these 40,000 TLPs: 1.98 s before, 0.33 s now)."""
    import time
    db = str(tmp_path / "acks.sqlite")
    con = L.open_db(db)
    for k in LEVELS:
        L.create_tables(con, k)
    links, packets = [], []
    for i in range(40000):
        links.append(("Upstream", i % 4096, 2, 1000 + 10 * i))
        packets.append(("Upstream", "MWr(64)", None, i % 4096, None, 1000 + 10 * i))
        if i % 4 == 3:
            packets.append(("Downstream", None, "Ack", None, i % 4096, 1005 + 10 * i))
    insert(con, "lnk", ("dir", "psn", "n_packets", "t_ps"), links)
    insert(con, "pkt", ("dir", "tlp_type", "dllp_type", "psn", "acknak", "t_ps"), packets)
    L.set_meta(con, "levels_present", list(LEVELS))
    con.commit()
    con.close()
    t0 = time.time()
    was = decided(db, WAS.BuildBefore, "packets_to_links", None, "was")
    t1 = time.time()
    now = decided(db, B.Build, "packets_to_links", None, "now")
    t2 = time.time()
    assert now[:2] == was[:2]
    assert was[1]["links_with_fewer_packets_than_counted"] >= 500           # the open links did pile up (those still open at the end)
    print("coalesced Acks, 40,000 TLPs: %.2f s before, %.2f s now" % (t1 - t0, t2 - t1))
    assert 3 * (t2 - t1) < (t1 - t0), "the Acks walk the open links again: %.2f s now, %.2f s before" % (t2 - t1, t1 - t0)


def test_a_whole_build_with_the_joins_as_they_were_gives_the_same_tree(tmp_path, monkeypatch):
    sample = os.path.join(APP, "samples", "clean_five_files", "S27_lcrc_nak_replay")
    if not os.path.isdir(sample):
        pytest.skip("the sample recordings are not on this machine (the code-only zip carries none)")
    names = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv", "nvme_command": "nvme_command.csv"}
    monkeypatch.setattr(L, "WORKERS", 1)
    monkeypatch.setattr(B, "JOINS_AT_ONCE_MIN_US", 10 ** 18)        # the joins in this process, so that the class put in below is the one that runs
    db = str(tmp_path / "now.sqlite")
    L.load_upload(db, {k: os.path.join(sample, v) for k, v in names.items()})
    was_db = str(tmp_path / "was.sqlite")
    shutil.copy(db, was_db)
    rep_now = B.build(db)
    monkeypatch.setattr(B, "Build", WAS.BuildBefore)
    rep_was = B.build(was_db)

    def content(path):
        con = sqlite3.connect(path)
        out = {t: con.execute("SELECT rowid_file, parent, parent_level, relation, dur_ps FROM %s ORDER BY rowid_file" % t).fetchall() for t in ("pkt", "lnk", "spl", "ntx", "cmd")}
        con.close()
        return out

    def plain(rep):
        return json.loads(json.dumps({k: ({a: b for a, b in v.items() if a != "seconds"} if isinstance(v, dict) else v) for k, v in rep["steps"].items()})), rep["checks"]
    assert content(db) == content(was_db)
    assert plain(rep_now) == plain(rep_was)
    assert rep_now["steps"]["packets_to_links"]["replays_seen"] > 0, "the sample was chosen for its Naks and resent TLPs"


def test_the_flows_window_test_reports_what_it_reported_before(tmp_path, monkeypatch):
    """agentic/family2.slice_check builds a window of the recording again and compares it with the full tree. It now starts from the window's rows; before, its
    comparison went through the members of the whole full table for every window. On a tree that is right, and on one whose links were spoiled on purpose (so
    that there is something to report), a window must give the same answer as before: the same counts, the same example rows."""
    from agentic import family2 as F2
    sample = os.path.join(APP, "samples", "clean_five_files", "S27_lcrc_nak_replay")
    if not os.path.isdir(sample):
        pytest.skip("the sample recordings are not on this machine (the code-only zip carries none)")
    names = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv", "nvme_command": "nvme_command.csv"}
    monkeypatch.setattr(L, "WORKERS", 1)
    monkeypatch.setattr(B, "JOINS_AT_ONCE_MIN_US", 10 ** 18)
    db = str(tmp_path / "full.sqlite")
    L.load_upload(db, {k: os.path.join(sample, v) for k, v in names.items()})
    B.build(db)
    con = sqlite3.connect(db)
    wins = F2._windows(con, 5, seed=3) + [con.execute("SELECT MIN(t_ps), MAX(t_ps) FROM pkt").fetchone()]
    con.close()
    box = str(tmp_path / "box")
    os.makedirs(box)

    def both(label):
        out = []
        for i, (t0, t1) in enumerate(wins):
            now = F2.slice_check(db, t0, t1, box, "now%s%d" % (label, i))
            was = WAS.slice_check_before(db, t0, t1, box, "was%s%d" % (label, i))
            assert now == was, "window %d (%s): now %s, before %s" % (i, label, json.dumps(now)[:600], json.dumps(was)[:600])
            out.append(now)
        return out
    right = both("right")
    assert all(r["passed"] for r in right) and sum(sum(r["checked"].values()) for r in right) > 100
    # spoil the full tree: every 5th packet, link transaction and NVMe transaction that has a parent hangs under the row before its parent
    con = sqlite3.connect(db)
    for t in ("pkt", "lnk", "ntx"):
        con.execute("UPDATE %s SET parent = parent - 1 WHERE relation='member' AND parent > 1 AND rowid_file %% 5 = 0" % t)
    con.commit()
    con.close()
    spoiled = both("spoiled")
    seen = {t: sum(r["parent_mismatch"].get(t, {}).get("n", 0) for r in spoiled) for t in ("pkt", "lnk", "ntx")}
    assert not any(r["passed"] for r in spoiled) and all(v > 0 for v in seen.values()), seen
    assert max(r["parent_mismatch"]["pkt"]["n"] for r in spoiled) == 1000, "no window met the limit of 1,000 reported rows: %s" % seen
