"""The REA agent of the start page (owner, 2026-11-14: "let's keep the rea out, because it is going to consume a lot of
time ... kept out at the first page itself ... the rea decompiled folder shall be taken or given the path, and what you
want to see ask questions ... Agent from Second family now can talk to the ... rea family").

What must hold:
  - the findings are read once, in one pass (every file opened one time), and never again while no file changes;
  - the lines about the join columns are the ones the earlier term-by-term search found;
  - a question is answered from passages the program found; a quote that is not in its passage is dropped and said so;
    nothing found is said in plain words; the model may ask for other words;
  - the conversation is kept with the findings;
  - Family 2's Coder gets the join lines without any step and without reading the folder, and the tree builder's chat
    agent gets passages from the REA agent.
No server and no model."""
import json
import os
import sys
import time
import types

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from agentic import core, family1, family2, prompts, rea_agent as RA   # noqa: E402

LINK = """// link layer of the analyzer (decompiled)
struct LinkTrans { uint16_t psn; int n_packets; };
static int attach_tlp(LinkTrans *lt, Tlp *tlp) {
    if (tlp->seq == lt->psn) { attach(lt, tlp); return 1; }   // PSN equal: same link transaction
    return 0;
}
// an Ack closes every link transaction up to its AckNak Seq Num
void on_ack(Dllp *d) { close_upto(d->acknak_seq); }
void on_nak(Dllp *d) { replay_from(d->acknak_seq); }   // Nak: resend
"""
SPLIT = """split transactions: a request and its completion belong together when RequesterID and Tag are equal
match_completion(req) { return cpl.RequesterID == req.RequesterID && cpl.Tag == req.Tag; }
the Address of a memory request decides the NVMe transaction it belongs to
"""
NVME = """nvme layer
command_of(sqe) { key = (sqe.SQID << 16) | sqe.CID; }   // SQID and CID identify a command
a Doorbell write to the submission queue tail starts the command
""" + "\n".join("filler line %d of the nvme notes, nothing of interest here" % i for i in range(60)) + """
completion queue entry: status field, SQ head pointer, the CID of the command it completes
"""


@pytest.fixture
def findings(tmp_path, monkeypatch):
    know = str(tmp_path / "knowledge")
    monkeypatch.setattr(family1, "knowledge_dir", lambda: know)
    monkeypatch.setattr(RA, "IDENTITY_KEPT_S", 0)
    folder = tmp_path / "rea_findings"
    folder.mkdir()
    (folder / "LinkTracker.c").write_text(LINK, encoding="utf-8")
    (folder / "split_notes.txt").write_text(SPLIT, encoding="utf-8")
    (folder / "nvme_layer.txt").write_text(NVME, encoding="utf-8")
    (folder / "analyzer.bin").write_bytes(b"MZ\x00\x01\x02\x00binary PSN PSN PSN")
    return str(folder)


class Runner:
    """Stands in for the model: answers with what the test gives, and keeps what it was asked."""

    def __init__(self, answers=None, standin=False):
        self.answers, self.seen, self.standin = list(answers or []), [], standin

    def ask(self, run_id, agent, instruction, context, shape, must_have, standin, **kw):
        ctx = json.loads(context) if isinstance(context, str) else context
        self.seen.append({"run": run_id, "agent": agent, "instruction": instruction, "ctx": ctx})
        if self.standin:
            return standin(), "stand-in (no model)", None
        a = self.answers.pop(0) if self.answers else {"answer": "nothing more", "sources": [], "search_more": []}
        return (a(ctx) if callable(a) else a), "a model (test)", None


def engine(*a, **k):
    return types.SimpleNamespace(runner=Runner(*a, **k))


# ---------------------------------------------------------------------------------------------- reading, once
def test_the_findings_are_read_once_in_one_pass_and_again_only_after_a_change(findings, monkeypatch):
    opened, real = [], RA._lines_of

    def counting(path, cache):
        opened.append(os.path.basename(path))
        return real(path, cache)
    monkeypatch.setattr(RA, "_lines_of", counting)
    notes = []
    out = RA.read(findings, progress=notes.append)
    assert sorted(opened) == ["LinkTracker.c", "analyzer.bin", "nvme_layer.txt", "split_notes.txt"]      # every file one time
    assert out["reused"] is False and out["files"] == 4 and out["read_files"] == 3 and out["skipped"] == {"not text (a binary file)": 1}
    assert out["passages"] >= 4 and notes and notes[-1].startswith("100%")
    assert RA.is_read(findings) and family2.rea_done(findings)["hits"] == out["hits"]
    assert os.path.dirname(family2.rea_file("x")) == os.path.join(family1.knowledge_dir(), "rea")
    del opened[:]
    again = RA.read(findings)
    assert again["reused"] is True and opened == [] and again["hits"] == out["hits"]                      # never read twice
    # a changed file makes them new findings: read again, under another key
    key1 = RA.identity(findings)[0]
    with open(os.path.join(findings, "split_notes.txt"), "a", encoding="utf-8") as fh:
        fh.write("one more line about the Tag\n")
    assert RA.identity(findings)[0] != key1 and RA.done(findings) is None and not RA.is_read(findings)
    third = RA.read(findings)
    assert third["reused"] is False and len(opened) == 4
    with pytest.raises(ValueError, match="not a folder"):
        RA.read(os.path.join(findings, "nothing_here"))


def test_the_join_lines_are_the_ones_the_term_by_term_search_found(findings, tmp_path):
    os.remove(os.path.join(findings, "analyzer.bin"))
    old = core.References([findings], str(tmp_path / "cache"))
    want = {t: old.search(t, limit=3) for t in RA.JOIN_TERMS}
    want = {t: h for t, h in want.items() if h}
    got = RA.read(findings)["hits"]
    assert got == want and {"PSN", "Ack", "Nak", "AckNak Seq Num", "RequesterID", "Tag", "Address", "SQID", "CID", "Doorbell"} <= set(got)
    assert RA.join_hits(findings) == want
    assert family2.JOIN_TERMS is RA.JOIN_TERMS
    st = RA.status(findings)
    assert st["read"] is True and st["files"] == 3 and "PSN" in st["join_terms_found"] and "Metrics.# Packets" in st["join_terms_not_found"]


def test_status_says_what_is_there_before_anything_is_read(findings, tmp_path):
    st = RA.status(findings)
    assert st["exists"] is True and st["read"] is False and st["files"] == 4 and st["why"] == "not read yet" and "passages" not in st
    assert RA.status(str(tmp_path / "missing")) == {"folder": str(tmp_path / "missing"), "exists": False, "read": False,
                                                    "why": "this folder does not exist on this computer"}
    assert RA.status("")["exists"] is False
    assert RA.join_hits(findings) == {} and "have not been read" in RA.note_for_coder(findings) and RA.note_for_coder("") == ""
    with pytest.raises(ValueError, match="have not been read yet"):
        RA.search(findings, ["psn"])


# ---------------------------------------------------------------------------------------------- searching
@pytest.mark.parametrize("fts", [True, False])
def test_passages_are_found_by_their_words_with_file_and_lines(findings, monkeypatch, fts):
    if not fts:
        monkeypatch.setattr(RA, "_fts", False)          # a Python whose SQLite has no full-text search
    elif not RA.has_fts():
        pytest.skip("this Python's SQLite has no FTS5")
    out = RA.read(findings)
    assert out["fts"] is fts
    hits = RA.search(findings, ["RequesterID", "completion"])
    assert hits and hits[0]["file"] == "split_notes.txt" and hits[0]["lines"] == "1-3" and "cpl.Tag == req.Tag" in hits[0]["text"]
    deep = RA.search(findings, "completion queue entry status")
    assert any(h["file"] == "nvme_layer.txt" and h["line_from"] > 24 for h in deep)                       # a passage further down the file
    assert RA.search(findings, ["requester"])[0]["file"] == "split_notes.txt"                             # the start of a name finds it
    assert RA.search(findings, ["zebra", "giraffe"]) == [] and RA.search(findings, ["the", "of"]) == []
    assert RA.words_of("Which field does the analyzer compare, PSN or seq?") == ["field", "analyzer", "compare", "psn", "seq"]


def test_a_quote_is_checked_in_the_one_file_it_names(findings):
    RA.read(findings)
    ref = RA.join_hits(findings)["PSN"][0]["ref"]
    assert RA.has_quote(findings, ref, "if (tlp->seq == lt->psn) { attach(lt, tlp); return 1; }")
    assert RA.has_quote(findings, "LinkTracker.c:4", "tlp->seq == lt->psn")                               # a path inside the findings
    assert not RA.has_quote(findings, ref, "the analyzer sorts by time stamp")
    assert not RA.has_quote(findings, "/etc/hostname:1", "anything") and not RA.has_quote(findings, "../x:1", "x") and not RA.has_quote("", ref, "x")


# ---------------------------------------------------------------------------------------------- asking
def test_an_answer_keeps_only_the_quotes_that_stand_in_their_passage(findings):
    RA.read(findings)

    def answer(ctx):
        n = next(p["n"] for p in ctx["passages"] if p["file"] == "LinkTracker.c")
        return {"answer": "It compares the TLP's sequence number with the PSN.",
                "sources": [{"passage": n, "quote": "if (tlp->seq == lt->psn) { attach(lt, tlp); return 1; }"},
                            {"passage": n, "quote": "the analyzer groups packets by their time stamp"},        # made up
                            {"passage": 99, "quote": "tlp->seq"}, "not a source"],
                "search_more": []}
    eng = engine([answer])
    out = RA.ask(eng, findings, "Which field puts a TLP into a link transaction, the PSN?", by="Sagar")
    assert out["sources"] == [{"file": "LinkTracker.c", "lines": "1-9", "quote": "if (tlp->seq == lt->psn) { attach(lt, tlp); return 1; }"}]
    assert out["dropped"] == 3 and "3 quoted sources the model gave could not be found" in out["answer"] and out["producer"] == "a model (test)"
    asked = eng.runner.seen[0]
    assert asked["agent"] == "rea_agent" and asked["run"] == "rea_" + RA.identity(findings)[0] and asked["instruction"] == prompts.load("rea_agent")
    assert asked["ctx"]["asked_by"] == "admin" and "psn" in asked["ctx"]["searched"] and all(set(p) == {"n", "file", "lines", "text"} for p in asked["ctx"]["passages"])
    # the conversation is kept with the findings and comes back
    turns = RA.chat(findings)
    assert [(t["who"], t["by"]) for t in turns] == [("admin", "Sagar"), ("REA agent", "a model (test)")]
    assert turns[1]["sources"] == out["sources"] and turns[1]["dropped"] == 3 and RA.status(findings)["questions_asked"] == 1
    assert json.load(open(RA.chat_file(RA.identity(findings)[0]), encoding="utf-8")) == turns


def test_the_model_may_ask_for_other_words_twice_and_no_more(findings):
    RA.read(findings)
    eng = engine([{"answer": "looking for the completion entry", "sources": [], "search_more": ["completion", "status"]},
                  {"answer": "still looking", "sources": [], "search_more": ["doorbell"]},
                  lambda ctx: {"answer": "A Doorbell write starts the command.", "search_more": ["never searched"],
                               "sources": [{"passage": next(p["n"] for p in ctx["passages"] if "Doorbell" in p["text"]), "quote": "a Doorbell write to the submission queue tail starts the command"}]}])
    out = RA.ask(eng, findings, "What does the PSN do?")
    assert len(eng.runner.seen) == RA.MAX_ROUNDS == 3
    assert out["searched"] == ["psn", "completion", "status", "doorbell"] and out["dropped"] == 0
    assert out["sources"][0]["file"] == "nvme_layer.txt" and len(eng.runner.seen[2]["ctx"]["passages"]) > len(eng.runner.seen[0]["ctx"]["passages"])
    assert eng.runner.seen[2]["ctx"]["rounds_left_for_search_more"] == 0


def test_nothing_found_is_said_in_plain_words_and_nothing_is_made_up(findings):
    RA.read(findings)
    eng = engine([{"answer": "The analyzer certainly uses a hash table.", "sources": [{"passage": 0, "quote": "hash table"}], "search_more": []}])
    out = RA.ask(eng, findings, "zebra giraffe?")
    assert out["answer"].startswith("The findings do not name any of the words searched for (zebra, giraffe)") and out["sources"] == [] and out["passages_found"] == 0
    with pytest.raises(ValueError, match="write a question first"):
        RA.ask(eng, findings, "   ")


def test_without_a_model_the_passages_found_are_given_and_labelled(findings):
    RA.read(findings)
    out = RA.ask(engine(standin=True), findings, "RequesterID and Tag?")
    assert out["producer"] == "stand-in (no model)" and out["answer"].startswith("No model is connected, so nobody read your question.")
    assert "split_notes.txt, lines 1-3" in out["answer"] and out["sources"] and out["dropped"] == 0


def test_the_prompt_is_a_document_with_its_parts():
    text = prompts.load("rea_agent")
    for part in ("## Who you are", "## What you are given", "## What to do", "## What never to do", "## Answer format"):
        assert part in text
    assert os.path.isfile(prompts.path("rea_agent")) and '"search_more"' in text and "Example." in text


# ---------------------------------------------------------------------------------------------- Family 2 and the REA agent
def test_family_2_gets_passages_with_their_sources_and_the_question_is_written_down(findings):
    project = {"id": 1, "rea": findings}
    assert RA.ask_for_family2(None, {"id": 1}, "x") == {"available": False, "why": "no REA findings were given for this analysis"}
    assert "have not been read yet" in RA.ask_for_family2(None, project, "x")["why"]
    assert "does not exist any more" in RA.ask_for_family2(None, {"rea": findings + "_gone"}, "x")["why"]
    RA.read(findings)
    got = RA.ask_for_family2(None, project, "How does the analyzer match a completion to its request (RequesterID, Tag)?")
    assert got["available"] is True and got["passages"][0]["file"] == "split_notes.txt" and set(got["passages"][0]) == {"file", "lines", "text"}
    turns = RA.chat(findings)
    assert turns[0]["who"] == "Family 2" and turns[1]["who"] == "REA agent" and turns[1]["sources"][0]["file"] == "split_notes.txt"


def test_the_tree_builders_chat_agent_asks_the_rea_agent(findings, monkeypatch):
    from agentic import data_chat as DC
    RA.read(findings)

    def first(ctx):
        assert ctx["rea_findings"]["passages"] and "rea_search" in ctx["rea_findings"]["what"]
        return {"answer": "let me look for the doorbell", "queries": [], "steps": [], "proposal": {"kind": "none"}, "rea_search": ["Doorbell"]}

    def second(ctx):
        assert any("Doorbell" in p["text"] for p in ctx["rea_findings"]["passages"]) and "doorbell" in ctx["rea_findings"]["searched"]
        return {"answer": "The decompiled code starts a command at the Doorbell write (nvme_layer.txt, lines 1-24).", "queries": [], "steps": [], "proposal": {"kind": "none"}}
    eng = engine([first, second])
    project = {"id": 7, "name": "p", "folder": findings, "rea": findings}
    turns = DC.ask(eng, project, None, "builder", "How does the analyzer match a completion to its request?", "Sagar")
    assert len(eng.runner.seen) == 2 and turns[1]["text"].startswith("The decompiled code starts a command")
    assert turns[1]["rea"]["passages"] and "doorbell" in turns[1]["rea"]["searched"]
    # the data agent of Family 1 is not given the findings; and without findings the builder works as before
    eng2 = engine([lambda ctx: {"answer": "ok" if "rea_findings" not in ctx else "leak", "queries": [], "steps": [], "proposal": {"kind": "none"}}] * 2)
    assert DC.ask(eng2, project, None, "data", "a question", "Sagar")[1]["text"] == "ok"
    assert DC.ask(eng2, {"id": 8, "name": "q", "folder": findings}, None, "builder", "a question", "Sagar")[1]["text"] == "ok"


def test_the_coder_gets_the_join_lines_without_a_step_and_without_reading_the_folder(findings, tmp_path, monkeypatch):
    from test_admin_ask import Flow
    os.makedirs(str(tmp_path / "flow"))
    flow = Flow(tmp_path / "flow", monkeypatch)
    monkeypatch.setattr(family1, "knowledge_dir", lambda: flow.know)
    flow.store.exec("UPDATE project SET rea=? WHERE id=?", (findings, flow.pid))
    seen_folders = []
    real_init = core.References.__init__

    def init(self, folders, cache_dir):
        seen_folders.append(list(folders or []))
        real_init(self, folders, cache_dir)
    monkeypatch.setattr(core.References, "__init__", init)

    def coder():
        run = flow.store.one("SELECT * FROM run WHERE id=?", (flow.rid,))
        flow.store.exec("UPDATE step SET state='done', output=? WHERE run=? AND key='collect'", (json.dumps({"references": {}, "dictionaries": {}, "web": {}}), flow.rid))
        flow.store.exec("UPDATE step SET state='waiting' WHERE run=? AND key='coder'", (flow.rid,))
        flow.store.exec("DELETE FROM review WHERE step=?", (flow.step("coder")["id"],))
        flow.eng._run_step(run, flow.step("coder"))
        st = flow.step("coder")
        rv = flow.store.one("SELECT * FROM review WHERE step=? ORDER BY id DESC", (st["id"],))
        return st, json.loads(st["output"] or "{}"), (rv or {}).get("body") or ""
    from agentic import admin_ask
    looked = []
    real_hits = RA.join_hits
    monkeypatch.setattr(RA, "join_hits", lambda folder: (looked.append(folder), real_hits(folder))[1])

    def gate(**more):
        g = flow.step()
        flow.store.exec("UPDATE step SET output=? WHERE id=?", (json.dumps(dict(json.loads(g["output"] or "{}"), **more)), g["id"]))
    # optional (owner, 2026-11-14): read and kept with the analysis, but not asked for at the step before stage 2: not looked at
    RA.read(findings)
    st, out, body = coder()
    assert st["state"] == "needs_review", st.get("error")
    assert "were not asked for at the step before stage 2" in body and "They are optional" in body
    assert not any(e["kind"] == "rea" for j in out["joins"] for e in j["evidence"]) and looked == [""]
    # no findings with the analysis and no tick: the card says nothing about them
    flow.store.exec("UPDATE project SET rea='' WHERE id=?", (flow.pid,))
    st, out, body = coder()
    assert st["state"] == "needs_review" and "REA" not in body.split("Check each rule below")[0]
    flow.store.exec("UPDATE project SET rea=? WHERE id=?", (findings, flow.pid))
    # asked for (the tick): the Coder quotes them, each checked in its own file
    gate(use_rea=True)
    st, out, body = coder()
    rea_ev = [e for j in out["joins"] for e in j["evidence"] if e["kind"] == "rea"]
    assert rea_ev and all(e["verified"] for e in rea_ev) and "not asked for" not in body and "have not been read" not in body
    assert not any(findings in f for f in seen_folders), "the flow read the folder of the findings"
    # asked for, and a file of the findings changed afterwards: the card says they are not read, the strategy is made without
    with open(os.path.join(findings, "LinkTracker.c"), "a", encoding="utf-8") as fh:
        fh.write("// a line added after the reading\n")
    with open(os.path.join(findings, "added_later.txt"), "w", encoding="utf-8") as fh:
        fh.write("a new note\n")
    st, out, body = coder()
    assert st["state"] == "needs_review" and "have not been read" in body and "REA agent on the start page" in body
    assert not any(e["kind"] == "rea" for j in out["joins"] for e in j["evidence"])
    assert "rea" not in flow.keys() and "rea_search" not in flow.keys()


def test_the_tick_for_the_rea_findings_is_optional_and_refused_only_when_they_cannot_be_used(findings, tmp_path, monkeypatch):
    from test_admin_ask import Flow
    from agentic import admin_ask
    os.makedirs(str(tmp_path / "flow"))
    flow = Flow(tmp_path / "flow", monkeypatch)
    monkeypatch.setattr(family1, "knowledge_dir", lambda: flow.know)
    data = json.loads(flow.review["data"])
    assert data["rea"] == {"usable": False, "folder": "", "why": admin_ask.rea_facts({})["why"]}
    assert "The REA findings (optional)" in flow.review["body"] and "goes on without" in flow.review["body"]
    # a tick without findings is refused with the reason, and the card stays open
    with pytest.raises(ValueError, match="no folder with REA findings was given.*Take the tick away"):
        flow.eng.decide(flow.review["id"], "approve", "Sagar", "", {"stage2": "fixed", "use_rea": True})
    assert flow.step()["state"] == "needs_review"
    flow.store.exec("UPDATE project SET rea=? WHERE id=?", (findings, flow.pid))
    with pytest.raises(ValueError, match="have not been read yet"):
        flow.eng.decide(flow.review["id"], "approve", "Sagar", "", {"stage2": "fixed", "use_rea": True})
    # read: the tick is taken, and kept with the step
    RA.read(findings)
    assert admin_ask.rea_facts({"rea": findings}) == {"usable": True, "folder": findings, "why": ""}
    assert "Tick the box below only if" in "\n".join(admin_ask.rea_lines(admin_ask.rea_facts({"rea": findings})))
    flow.eng.decide(flow.review["id"], "approve", "Sagar", "", {"stage2": "fixed", "use_rea": True})
    out = json.loads(flow.step()["output"])
    assert flow.step()["state"] == "approved" and out["stage2"] == "fixed" and out["use_rea"] is True
    assert admin_ask.rea_wanted(out) is True and admin_ask.rea_wanted({}) is False and admin_ask.rea_wanted(None) is False


def test_go_to_stage_2_without_the_tick_never_touches_the_rea_findings(findings, tmp_path, monkeypatch):
    from test_admin_ask import Flow
    os.makedirs(str(tmp_path / "flow"))
    flow = Flow(tmp_path / "flow", monkeypatch)
    monkeypatch.setattr(family1, "knowledge_dir", lambda: flow.know)
    flow.store.exec("UPDATE project SET rea=? WHERE id=?", (findings + "_gone", flow.pid))       # a folder that is not there any more
    for edits in (None, {"stage2": "fixed"}, {"stage2": "fixed", "use_rea": False}):
        flow.store.exec("UPDATE step SET state='needs_review' WHERE id=?", (flow.step()["id"],))
        flow.store.exec("UPDATE review SET state='open' WHERE id=?", (flow.review["id"],))
        flow.eng.decide(flow.review["id"], "approve", "Sagar", "", edits)
        out = json.loads(flow.step()["output"])
        assert flow.step()["state"] == "approved" and out["stage2"] == "fixed" and out["use_rea"] is False


# ---------------------------------------------------------------------------------------------- the start page's routes
def test_the_routes_of_the_start_page(findings, tmp_path, monkeypatch):
    import fuzz_app as F
    if not os.path.isdir(F.BASE):
        pytest.skip("the S08 sample recording is not on this machine (the code-only zip carries no samples)")
    root = str(tmp_path / "app")
    os.makedirs(root)
    app, c, _k, _r = F.setup(root)                      # its own knowledge folder; the agents on the stand-in
    monkeypatch.setattr(RA, "IDENTITY_KEPT_S", 0)
    q = "?folder=" + findings
    st = c.get("/api/agents/rea/status" + q).get_json()
    assert st["exists"] is True and st["read"] is False and st["job"] is None and st["files"] == 4
    assert c.get("/api/agents/rea/status?folder=" + findings + "_none").get_json()["why"] == "this folder does not exist on this computer"
    for body, words in (({}, "give the folder"), ({"folder": findings + "_none"}, "does not exist on this computer"), ({"folder": 7}, "must be text")):
        r = c.post("/api/agents/rea/read", json=body)
        assert r.status_code == 400 and words in (r.get_json() or {}).get("error", r.get_data(as_text=True)), r.get_data(as_text=True)
    r = c.post("/api/agents/rea/ask", json={"folder": findings, "question": "PSN?"})
    assert r.status_code == 400 and "have not been read yet" in r.get_json()["error"]
    r = c.post("/api/agents/rea/read", json={"folder": findings, "admin": "Sagar"})
    assert r.status_code == 200 and r.get_json()["job"]["state"] in ("running", "done") and r.get_json()["job"]["by"] == "Sagar"
    for _ in range(200):
        st = c.get("/api/agents/rea/status" + q).get_json()
        if st["job"]["state"] != "running":
            break
        time.sleep(0.05)
    assert st["job"]["state"] == "done" and st["job"]["note"].startswith("100%") and st["read"] is True and "PSN" in st["join_terms_found"]
    again = c.post("/api/agents/rea/read", json={"folder": findings}).get_json()            # read before: nothing is read again
    for _ in range(200):
        st = c.get("/api/agents/rea/status" + q).get_json()
        if st["job"]["state"] != "running":
            break
        time.sleep(0.05)
    assert again["read"] is True and "used again" in st["job"]["note"]
    r = c.post("/api/agents/rea/ask", json={"folder": findings, "question": "RequesterID and Tag?", "admin": "Sagar"})
    out = r.get_json()
    assert r.status_code == 200 and out["producer"].startswith("stand-in") and out["sources"] and len(out["turns"]) == 2
    assert c.get("/api/agents/rea/chat" + q).get_json()["turns"] == out["turns"]
    assert c.post("/api/agents/rea/ask", json={"folder": findings, "question": "  "}).status_code == 400
    assert c.post("/api/agents/rea/ask", json={"folder": findings, "question": "x" * 4001}).status_code == 400
    # an analysis is created with the folder, and a folder that is not there is refused in plain words
    r = c.post("/api/agents/projects", json={"admin": "Sagar", "name": "rea test bad", "folder": F.BASE, "rea": findings + "_none"})
    assert r.status_code == 400 and "folder of the REA findings does not exist" in r.get_json()["error"]
    r = c.post("/api/agents/projects", json={"admin": "Sagar", "name": "rea test", "folder": F.BASE, "rea": findings})
    assert r.status_code == 200 and r.get_json()["rea"] == findings
