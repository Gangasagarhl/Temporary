"""Family 4 as the coding RESEARCH family (owner, 2026-11-14: "the research will be on the content of the data, columns of
the data ... first you need to check the family one, family two, and family three's admin's input. And then finally code
... everything has to meet the requirements. Based on the data").

What must hold:
  1. the data research record is measured by code in one pass over the file: every spelling of "nothing", numbers written
     as text, where the rule's own words are stored (or that they are in no column, with the nearest spelling), and every
     fact says whether it is exact or of the first rows only;
  2. the ledger marks each line established / to decide / guess, with its source (Family 1, Family 2, the admin);
  3. the facts of a parent-child link are counted in the tree;
  4. conflicts are found by code, with the fixed priority; one the priority does not settle is a question to the admin;
  5. a column the Data researcher names that the file does not have is dropped;
  6. a decision the rule leaves open becomes a requirement or a question: nothing is assumed in silence;
  7. a data set that cannot fail is marked as not testing its requirement;
  8. the program runs on the WHOLE file and its accounting is checked without an expected answer;
  9. a program that reads a column that is in no file of the rule is refused;
 10. the verdict of each requirement (met, not met, not exercised, could not be checked) is decided by code, and the admin
     decides each requirement that was not shown to hold; nothing is chosen for him;
 11. the repair feedback carries the failing check with the program's own numbers.
No server and no model: the agents' answers are written here; the code really runs (procedures.run_code)."""
import json
import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from agentic import family1, family3, family4, f4_research as RS, procedures as PR  # noqa: E402
import test_family4 as T  # noqa: E402

BENCH = ('Command,Queue,Latency_us,Result\n'
         'Read,1,120,ok\n'
         'Write,2,50000,timeout\n'
         'Read,1,"1,200",ok\n'
         'Read,,900,ok\n'
         'Flush,2,N/A,timeout\n'
         'Write,1,60000,timeout\n'
         'Read,3,44000,timeout\n'
         'Read, 3 ,,ok\n')
WORDS = 'Per queue, count the commands that "timed out" and took more than 43 ms.'
PROC = {"source_data": [{"file": "bench.csv", "columns": ["Queue", "Result", "Latency_us"]}],
        "steps": ["Read bench.csv row by row with Python's csv reader.",
                  "Keep the rows whose Result is timeout and whose Latency_us is more than 43 ms.",
                  "Count the kept rows of each Queue.",
                  "Output one line per queue: Queue, count; the largest count first, then the queue."],
        "output": {"columns": ["Queue", "count"], "order": "count, largest first; then Queue"}}
DICT = [{"column": "Command", "type": "text", "rows_with_value": 8, "distinct": 3, "meaning": "the NVMe command", "source": {"kind": "document", "ref": "manual p. 3"}, "keywords": []},
        {"column": "Queue", "type": "integer", "rows_with_value": 7, "distinct": 3, "meaning": "the submission queue", "source": {"kind": "document", "ref": "manual p. 4"}, "keywords": []},
        {"column": "Latency_us", "type": "integer", "rows_with_value": 7, "distinct": 7, "meaning": "time from submission to completion",
         "status": "from the model's knowledge (no source to check)", "source": {"kind": "model", "ref": "model knowledge"}, "keywords": []},
        {"column": "Result", "type": "text", "rows_with_value": 8, "distinct": 2, "meaning": "how the command ended", "source": {"kind": "document", "ref": "manual p. 9"},
         "keywords": [{"value": "ok", "count": 4, "rows": [1, 3, 4, 8]}, {"value": "timeout", "count": 4, "rows": [2, 5, 6, 7]}]}]
REQS = ["Read bench.csv row by row.", "Keep only the rows whose Result is timeout.",
        "Keep only the rows whose Latency_us, read as a number of microseconds, is more than 43000; a row whose Latency_us is not a number is left out.",
        "Count the kept rows of each Queue, the spaces at its ends removed; an empty Queue counts as (blank).", "A row whose Result is empty is left out.",
        "Output Queue, count; the largest count first, then the queue."]
CODE = '''import csv


def run(sources, out_csv):
    # step 1: read bench.csv row by row
    counts, n, kept = {}, 0, 0
    left = {"R2": [0, []], "R3": [0, []], "R5": [0, []]}
    with open(sources["bench.csv"], newline="", encoding="utf-8-sig") as fh:
        rd = csv.reader(fh)
        head = next(rd)
        iq, ir, il = head.index("Queue"), head.index("Result"), head.index("Latency_us")
        for line, row in enumerate(rd, 2):
            n += 1
            res = row[ir].strip() if ir < len(row) else ""
            lat = (row[il].strip() if il < len(row) else "").replace(",", "")
            # step 2: Result is timeout, Latency_us more than 43 ms = 43000 us
            why = "R5" if res == "" else "R2" if res != "timeout" else "R3" if not lat.isdigit() or int(lat) <= 43000 else None
            if why:
                left[why][0] += 1
                if len(left[why][1]) < 20:
                    left[why][1].append(line)
                continue
            kept += 1
            # step 3: count per queue
            q = (row[iq].strip() if iq < len(row) else "") or "(blank)"
            counts[q] = counts.get(q, 0) + 1
    # step 4: largest count first, then the queue
    with open(out_csv, "w", newline="", encoding="utf-8") as out:
        w = csv.writer(out)
        w.writerow(["Queue", "count"])
        for q, k in sorted(counts.items(), key=lambda x: (-x[1], x[0])):
            w.writerow([q, k])
    return {"rows_read": n, "rows_written": len(counts), "total": kept,
            "accounting": {"rows_read": n, "rows_kept": KEPT, "rows_not_evaluated": 0, "groups": len(counts), "count_column": "count",
                           "ordered_by": {"column": "count", "descending": True},
                           "rows_left_out": [{"requirement": k, "reason": {"R2": "Result is not timeout", "R3": "Latency_us is not more than 43000, or not a number",
                                                                           "R5": "Result is empty"}[k], "rows": v[0], "lines": v[1]} for k, v in left.items()]}}
'''
GOOD = CODE.replace("KEPT", "kept")
LOSES_A_ROW = CODE.replace("KEPT", "kept - 1")                 # its accounting does not add up
NO_FILTER = GOOD.replace('"R2" if res != "timeout" else ', "")  # ignores R2: rows that are not timeout are counted
ONLY_TIMEOUT = {"name": "one ok and one timeout", "property": "a row whose Result is not timeout is not counted", "why": "step 2", "requirements": ["R2"],
                "files": {"bench.csv": [{"Queue": "1", "Result": "ok", "Latency_us": "50000"}, {"Queue": "1", "Result": "timeout", "Latency_us": "50000"}]},
                "expected_rows": [["1", 1]], "without_it_rows": [["1", 2]], "order_matters": True}
CANNOT_FAIL = {"name": "two queues", "property": "the largest count comes first", "why": "step 4", "requirements": ["R6"],
               "files": {"bench.csv": [{"Queue": "1", "Result": "timeout", "Latency_us": "50000"}]}, "expected_rows": [["1", 1]], "without_it_rows": [["1", 1]], "order_matters": True}


def bench(tmp_path, monkeypatch, start=True):
    lab = T.Lab(tmp_path, monkeypatch, proc=PROC)
    with open(os.path.join(lab.folder, "bench.csv"), "w", encoding="utf-8") as fh:
        fh.write(BENCH)
    f = next(x for x in family1.inventory(lab.folder) if x["name"] == "bench.csv")
    d = os.path.join(lab.know, "dictionaries", f["format_key"])
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "bench.current.json"), "w", encoding="utf-8") as fh:
        json.dump({"path": f["path"], "level": None, "version": 2, "approved_at": 100.0, "approved_by": "Sagar", "rows": 8, "columns": DICT}, fh)
    r = lab.rule()
    r["description"] = WORDS
    family3.save_rule(r)
    lab.req = lambda ctx, n: {"requirements": list(REQS), "data_needed": [], "definitions": [], "questions": [], "answers": []}
    lab.coder = lambda ctx, n: {"notes": ["count per queue"], "code": GOOD, "how": ["step 1"]}
    lab.tester = lambda ctx, n: {"notes": [], "cases": [ONLY_TIMEOUT, CANNOT_FAIL], "remarks": [], "replies": [], "nothing_more": True}
    return lab.start() if start else lab


def record_of(lab):
    return lab.out("research")["record"]


# ------------------------------------------------------------------------------------------- 1. the one pass
def test_one_pass_counts_every_spelling_of_nothing_and_how_numbers_are_written(tmp_path):
    p = tmp_path / "bench.csv"
    p.write_text(BENCH, encoding="utf-8")
    m = RS.measure(str(p), ["Queue", "Latency_us", "Result", "Nowhere"])
    assert m["rows"] == 8 and m["basis"] == "exact: all 8 rows" and m["exact"] is True and m["absent"] == ["Nowhere"]
    lat = m["columns"]["Latency_us"].block(m["rows"], m["basis"], declared="integer")
    assert lat["rows_with_a_value"] == 6
    assert {x["spelling"]: (x["rows"], x["first_lines"]) for x in lat["nothing"]} == {'the text "N/A"': (1, [6]), "an empty cell": (1, [9])}
    assert lat["written_as"] == {"plain": 5, "thousands": 1} and lat["numbers"] == 6 and lat["not_numbers"] == 0
    assert lat["range"] == [120.0, 60000.0] and lat["unit"] == "us" and lat["unit_from"] == "from its name" and lat["distinct_is_exact"] is True
    assert lat["sample_rows"][0] == {"line": 2, "value": "120"} and len(lat["sample_rows"]) == 3
    q = m["columns"]["Queue"].block(m["rows"], m["basis"])
    assert q["values_with_spaces_at_an_end"] == 1 and q["nothing"][0]["spelling"] == "an empty cell" and q["nothing"][0]["first_lines"] == [5]
    assert [x["value"] for x in m["columns"]["Result"].block(8, m["basis"])["most_frequent"]] == ["ok", "timeout"]
    first = RS.measure(str(p), ["Result"], row_cap=3)
    assert first["rows"] == 3 and first["basis"] == "the first 3 rows" and first["exact"] is False


def test_the_spellings_of_nothing_and_the_literals_of_a_rule():
    assert RS.nothing_spelling("") == "an empty cell" and RS.nothing_spelling("  ") == "only spaces" and RS.nothing_spelling("n/a") == 'the text "n/a"'
    assert RS.nothing_spelling("0xFFFF") == "the all-F value 0xFFFF" and RS.nothing_spelling("0xFF") is None and RS.nothing_spelling("0") is None
    lit = RS.literals_of(WORDS, "whose Latency_us is more than 43 ms")
    assert [(x["text"], x["kind"]) for x in lit] == [("timed out", "quoted"), ("43 ms", "number")] and lit[1]["value"] == 43.0 and lit[1]["unit"] == "ms"
    assert RS.unit_of_column("Latency_us") == ("us", "from its name") and RS.unit_of_column("Delay", "in milliseconds")[0] == "ms" and RS.unit_of_column("Queue") == (None, "")
    assert "timed out" in RS.phrases_of("commands that timed out") and "the" not in RS.phrases_of("the commands")


def test_the_rules_word_is_found_or_said_to_be_nowhere_with_the_nearest_spelling(tmp_path, monkeypatch):
    lab = bench(tmp_path, monkeypatch)
    lab.work()
    rec = record_of(lab)
    word = next(w for w in rec["words"] if w["text"] == "timed out")
    assert word["found"] == [] and word["in_quotation_marks"] is True
    assert word["nearest"] == [{"file": "bench.csv", "column": "Result", "spelling": "timeout", "rows": 4}]
    got = next(w for w in rec["words"] if w["text"] == "timeout")              # the procedure's own spelling is in the data
    assert got["found"][0]["column"] == "Result" and got["found"][0]["rows"] == 4 and got["found"][0]["basis"] == "counted now"
    f = rec["files"][0]
    assert f["file"] == "bench.csv" and f["rows"] == 8 and f["basis"] == "exact: all 8 rows" and [c["column"] for c in f["columns"]] == ["Command", "Queue", "Latency_us", "Result"]
    assert [b["column"] for b in f["touched"]] == ["Queue", "Result", "Latency_us"]            # the whole dictionary by file, a block only for what the rule touches
    assert any("Latency_us" in s and "N/A" in s and "line 6" in s for s in rec["surprises"]) and all("always" not in s and "never" not in s for s in rec["surprises"])
    assert os.path.exists(lab.out("research")["record_file"])


# ------------------------------------------------------------------------------------------- 2. the ledger
def test_the_ledger_marks_every_line_and_names_its_source(tmp_path, monkeypatch):
    lab = bench(tmp_path, monkeypatch)
    lab.work()
    led = {x["what"]: x for x in record_of(lab)["ledger"]}
    assert led["bench.csv column Queue"]["state"] == RS.ESTABLISHED and "Family 1's dictionary of bench.csv" in led["bench.csv column Queue"]["source"]
    assert led["bench.csv column Latency_us"]["state"] == RS.GUESS and "model" in led["bench.csv column Latency_us"]["source"]
    assert led["the rule's word “timed out”"]["state"] == RS.TO_DECIDE and "timeout" in led["the rule's word “timed out”"]["detail"]
    assert led["the rule's word “timeout”"]["state"] == RS.ESTABLISHED and "4 rows" in led["the rule's word “timeout”"]["source"]
    assert led["the rule's limit 43 ms"]["state"] == RS.TO_DECIDE
    items = record_of(lab)["admin_items"]
    assert items[0]["kind"] == "the rule's words" and items[0]["text"] == WORDS and items[1]["kind"] == "the procedure"


def test_a_column_that_is_not_in_the_file_is_a_line_to_decide(tmp_path, monkeypatch):
    proc = dict(PROC, source_data=[{"file": "bench.csv", "columns": ["Queue", "Outcome"]}])
    lab = T.Lab(tmp_path, monkeypatch, proc=proc)
    with open(os.path.join(lab.folder, "bench.csv"), "w", encoding="utf-8") as fh:
        fh.write(BENCH)
    lab.start()
    lab.work()
    led = {x["what"]: x for x in record_of(lab)["ledger"]}
    assert led["bench.csv column Outcome"]["state"] == RS.TO_DECIDE and "no column of that name" in led["bench.csv column Outcome"]["source"]
    assert led["bench.csv column Queue"]["state"] == RS.TO_DECIDE and "no meaning" in led["bench.csv column Queue"]["source"]      # no dictionary of this file


# ------------------------------------------------------------------------------------------- 3. the links
def test_the_facts_of_a_link_are_counted_in_the_tree(tmp_path):
    db = str(tmp_path / "tree.sqlite")
    family4.tiny_tree(db, {"nvme_command": [{"row": 1, "cells": {}}, {"row": 2, "cells": {}}, {"row": 3, "cells": {}}],
                           "nvme_transaction": [{"row": 1, "cells": {}, "parent": ["nvme_command", 1]}, {"row": 2, "cells": {}, "parent": ["nvme_command", 1]},
                                                {"row": 3, "cells": {}, "parent": ["nvme_command", 2]}, {"row": 4, "cells": {}}]}, [], {})
    (k,) = RS.link_facts(db, ["nvme_transaction", "nvme_command"])
    assert (k["child"], k["parent"], k["child_rows"], k["children_under_this_parent"], k["children_without_a_parent"]) == ("nvme_transaction", "nvme_command", 4, 3, 1)
    assert k["parent_rows"] == 3 and k["parents_without_a_child"] == 1 and k["children_per_parent"] == {"least": 1, "most": 2, "average": 1.5}
    assert k["children_whose_parent_row_is_missing"] == 0 and k["basis"].startswith("exact")
    line = RS.link_lines([k])[0]
    assert "1 have no parent" in line and "1 of the 3 rows have no row" in line
    hid = RS.hidden_decisions([], [k], [], "", {"steps": [], "output": {}})
    assert [h["kind"] for h in hid] == ["rows without a parent", "parents without a child"] and hid[0]["id"] == "H1" and "1 of the 4 rows have no parent" in hid[0]["because"]
    assert RS.link_facts(db, ["nvme_command"]) == [] and RS.link_facts("", ["nvme_command", "nvme_transaction"]) == []


# ------------------------------------------------------------------------------------------- 4. the conflicts
def test_conflicts_are_found_by_code_and_the_priority_is_fixed(tmp_path, monkeypatch):
    lab = bench(tmp_path, monkeypatch)
    lab.work()
    con = record_of(lab)["conflicts"]
    word = next(c for c in con if "“timed out”" in c["what"])
    assert word["kind"] == "the rule against the data" and word["settled"] is False and "timeout" in word["question"] and word["priority"] == "the rule against the data goes to the admin"
    unit = next(c for c in con if "43 ms" in c["what"])
    assert unit["settled"] is False and "43000 us" in unit["question"] and "from its name" in unit["what"]
    # the dictionary against the measured content: the measured count stands
    blocks = [{"file": "f.csv", "column": "N", "in_the_file": True, "declared_type": "integer", "not_numbers": 2, "not_number_examples": ["abc"], "basis": "exact: all 9 rows", "numbers": 7}]
    (c,) = RS.conflicts_of([], blocks, [], [])
    assert c["kind"] == "the dictionary against the measured content" and c["settled"] is True and c["priority"] == "a measured count stands over a description"
    # two answers of the admin: the latest dated one stands
    items = [{"kind": "an answer", "question": "Does exactly 43 ms count?", "text": "no", "by": "Sagar", "at": 10.0},
             {"kind": "an answer", "question": "does exactly 43 ms  count?", "text": "yes", "by": "Sagar", "at": 20.0}]
    (c,) = RS.answer_conflicts(items)
    assert c["settled"] is True and c["stands"] == "yes" and c["a"]["at"] == 20.0 and c["priority"] == "the admin's latest dated answer stands"
    assert RS.answer_conflicts(items[:1]) == []


def test_the_program_asks_about_a_word_only_when_the_data_offers_another_spelling():
    """Found 2026-11-14 on the shipped command type item: its steps name what the output writes ("opcode 0xNN") and a name that
    is inside longer values ("Read" in "0x02 (Read)"); the program asked the admin about both and no flow could go on."""
    class Col:
        overflow = False

        def __init__(self, values):
            self.values = values
    measured = {"nvme_command.csv": {"OPC": Col({"0x02 (Read)": 40, "0x01 (Write)": 9}), "Result": Col({"timeout": 3, "ok": 46})}}
    lits = RS.literals_of('2 on an I/O queue is "Read". An unknown opcode is "opcode 0xNN". Count the "timed out" ones.')
    words = {w["text"]: w for w in RS.find_words(lits, [], measured, {}, ["OPC", "Result"])}
    assert words["Read"]["found"] == [] and words["Read"]["part_of"] == [{"file": "nvme_command.csv", "column": "OPC", "spelling": "0x02 (Read)", "rows": 40}]
    assert words["opcode 0xNN"]["found"] == [] and words["opcode 0xNN"]["nearest"] == [] and words["opcode 0xNN"]["part_of"] == []
    assert words["timed out"]["nearest"][0]["spelling"] == "timeout"
    con = RS.conflicts_of(list(words.values()), [], lits, [])
    assert len(con) == 1 and "“timed out”" in con[0]["what"] and "timeout" in con[0]["question"]
    # both are still said in the record: one is inside longer values (established), the other is a line to decide
    ledger = {x["what"]: x for x in RS.ledger_of([], list(words.values()), [], [], [], lits, con)}
    assert ledger["the rule's word “Read”"]["state"] == RS.ESTABLISHED and "inside longer values" in ledger["the rule's word “Read”"]["source"]
    assert ledger["the rule's word “opcode 0xNN”"]["state"] == RS.TO_DECIDE and "a name the output writes" in ledger["the rule's word “opcode 0xNN”"]["detail"]


def test_a_conflict_the_priority_does_not_settle_is_a_question_on_the_requirements_card(tmp_path, monkeypatch):
    lab = bench(tmp_path, monkeypatch)
    lab.work()
    rv = lab.review()
    qs = rv["data"]["questions"]
    assert [q["kind"] for q in qs[:2]] == ["conflict", "conflict"] and "“timed out”" in qs[0]["question"] and "43 ms" in qs[1]["question"]
    assert "Conflicts between what was said and what was measured (2), found by the program" in rv["body"] and "**for you to decide**" in rv["body"]
    assert rv["body"].index("What the data research found") < rv["body"].index("The requirements, numbered")
    assert rv["data"]["f4_research"]["conflicts"] and rv["data"]["f4_research"]["ledger"] and rv["data"]["open"] == 2
    with pytest.raises(ValueError, match="2 points are still open"):
        lab.decide("approve")
    lab.decide("change", edits={"answers": {"0": "timeout is meant", "1": "compare with 43000 us"}})
    lab.work()
    rv = lab.review()
    assert rv["data"]["open"] == 0 and [x["answer"] for x in lab.out("req")["qa"]] == ["timeout is meant", "compare with 43000 us"]
    assert lab.calls.count("research") == 1                                 # the files were read once: the answers do not start the research again


# ------------------------------------------------------------------------------------------- 5. the Data researcher
def test_a_column_the_data_researcher_invents_is_dropped_and_its_decision_is_added(tmp_path, monkeypatch):
    lab = bench(tmp_path, monkeypatch, start=False)
    lab.research = lambda ctx, n: {"matters": [{"column": "Latency_us", "what": "the limit is in another unit"}, {"column": "Duration", "what": "invented"}],
                                   "hidden_decisions": [{"column": "Queue", "kind": "empty groups", "decision": "is a queue with no slow command written with 0?"},
                                                        {"column": "Nowhere", "kind": "other", "decision": "something about a column that is not there"}], "doubts": ["none"]}
    lab.start()
    lab.work()
    rs = record_of(lab)["researchers"]["bench.csv"]
    assert [m["column"] for m in rs["matters"]] == ["Latency_us"] and rs["dropped"] == ["Duration", "Nowhere"] and len(rs["hidden"]) == 1
    hid = record_of(lab)["hidden"]
    assert hid[-1]["decision"] == "is a queue with no slow command written with 0?" and "no count" in hid[-1]["because"] and hid[-1]["by"] == "the model (written by the test)"
    ctx = lab.of("research")[0]
    assert ctx["FILE"] == "bench.csv" and [c["column"] for c in ctx["ALL_COLUMNS_OF_THE_FILE"]] == ["Command", "Queue", "Latency_us", "Result"] and ctx["RULE"]["the_admins_words"] == WORDS
    # the researcher is told what the program raised already, so the admin is not asked the same thing twice
    raised = ctx["ALREADY_RAISED_BY_THE_APPLICATION"]
    assert raised and all(h["decision"] in raised for h in hid if h["by"] == "the program") and all(c["what"] in raised for c in record_of(lab)["conflicts"])


# ------------------------------------------------------------------------------------------- 6. nothing is assumed in silence
def test_a_hidden_decision_becomes_a_requirement_or_a_question(tmp_path, monkeypatch):
    lab = bench(tmp_path, monkeypatch, start=False)
    lab.settle_hidden = False
    lab.start()
    lab.work()
    hid = record_of(lab)["hidden"]
    kinds = [h["kind"] for h in hid]
    assert "empty values" in kinds and "equality at a limit" in kinds and "spaces around a value" in kinds and "numbers written in more than one way" in kinds
    rv = lab.review()
    asked = [q for q in rv["data"]["questions"] if q.get("kind") == "hidden"]
    assert len(asked) == len(hid) and asked[0]["about"] == [hid[0]["id"]] and asked[0]["question"].startswith("The rule does not say ")
    assert [h["id"] for h in lab.of("requirements")[0]["HIDDEN_DECISIONS"]] == [h["id"] for h in hid]
    # a requirement that names a decision settles it, and a question of the agent about one is not asked twice
    first, second = hid[0]["id"], hid[1]["id"]
    lab.req = lambda ctx, n: {"requirements": [{"text": REQS[0], "settles": [first]}] + REQS[1:], "data_needed": [], "definitions": [],
                              "questions": [{"question": "What about the second one?", "why": "open", "about": [second]}], "answers": []}
    lab.decide("change", comment="please settle them")
    lab.work()
    out = lab.out("req")
    left = [q["about"][0] for q in lab.review()["data"]["questions"] if q.get("kind") == "hidden"]
    assert first not in left and second not in left and len(left) == len(hid) - 2
    assert out["requirement_ids"] == ["R1", "R2", "R3", "R4", "R5", "R6"] and out["requirement_settles"]["R1"] == [first]
    assert "- **R1** %s *(settles %s)*" % (REQS[0], first) in lab.review()["body"]


# ------------------------------------------------------------------------------------------- 7-11. the proof
def to_code(lab, answers=True):
    lab.work()
    if answers:
        lab.decide("change", edits={"answers": {"0": "timeout is meant", "1": "compare with 43000 us"}})
        lab.work()
    lab.decide("approve")
    return lab.work()


def test_the_requirements_are_proved_one_by_one_on_small_data_and_on_the_whole_file(tmp_path, monkeypatch):
    lab = bench(tmp_path, monkeypatch)
    st = to_code(lab)
    out, rv = lab.out("code"), lab.review()
    assert st["state"] == "needs_review" and out["clean"] is True and out["not_met"] == []
    rows = {x["id"]: x for x in out["proof"]["rows"]}
    assert rows["R2"]["verdict"] == RS.MET and "1 data set that can fail passed" in rows["R2"]["why"] and "in the whole file 4 rows met its condition" in rows["R2"]["why"]
    assert rows["R6"]["verdict"] == RS.NOT_CHECKED and "cannot fail" in rows["R6"]["why"] and rows["R6"]["evidence"][0]["result"] == "does not test R6"
    assert rows["R3"]["verdict"] == RS.NOT_CHECKED and "in the whole file 1 row met its condition" in rows["R3"]["why"] and rows["R3"]["evidence"][0]["lines"] == [6]
    assert rows["R5"]["verdict"] == RS.NOT_EXERCISED and "0 rows met its condition" in rows["R5"]["why"]
    assert rows["R1"]["verdict"] == RS.NOT_CHECKED and rows["R1"]["why"] == "no data set that can fail tests it"
    assert [x["verdict"] for x in out["proof"]["rows"]] == sorted([x["verdict"] for x in out["proof"]["rows"]], key=RS.VERDICT_ORDER.index)      # not met first
    # the whole file, without an expected answer
    whole = out["whole_file"]
    assert whole["on"] == "the whole of bench.csv" and whole["rows"] == {"bench.csv": 8} and whole["accounting"]["rows_read"] == 8 and whole["accounting"]["rows_kept"] == 3
    checks = {c["check"]: c for c in whole["checks"]}
    assert checks["every row of the file is accounted for exactly once (read = kept + left out + could not be evaluated)"]["ok"] is True
    assert checks["every row of the file is accounted for exactly once (read = kept + left out + could not be evaluated)"]["detail"] == "read 8 = kept 3 + left out 5 + could not be evaluated 0"
    assert checks["the rows the program says it read are the rows of the file, counted by the application"]["ok"] is True
    assert checks["the counts of the output add up to the rows kept"]["ok"] is True and checks["the output is in the stated order (count, largest first)"]["ok"] is True
    assert "The code ran on the whole of bench.csv" in rv["body"] and "Decided by the program from what ran, not by a model" in rv["body"] and "%" not in rv["body"].split("Decided by the program")[1].split("\n")[0]
    # the Tester and the Coder were given the research and the numbered requirements; the Tester was asked once more for what nothing tests
    t = lab.of("tester")[0]
    assert t["REQUIREMENTS"]["requirements"][1] == {"id": "R2", "text": REQS[1]} and t["REQUIREMENTS_WITHOUT_A_DATA_SET_THAT_CAN_FAIL"] == ["R1", "R2", "R3", "R4", "R5", "R6"]
    assert "DATA_RESEARCH" in t and "code" not in json.dumps(t).lower().split('"data_research"')[0]
    assert list(lab.of("coder")[0])[2] == "DATA_RESEARCH" and lab.of("coder")[0]["DATA_RESEARCH"]["FILES"][0]["ALL_COLUMNS"][0]["column"] == "Command"
    assert lab.calls.count("cover") == 1 and lab.of("cover")[0]["REQUIREMENTS_WITHOUT_A_DATA_SET_THAT_CAN_FAIL"] == ["R1", "R3", "R4", "R5", "R6"]


def test_the_admin_decides_each_requirement_that_was_not_shown_to_hold(tmp_path, monkeypatch):
    lab = bench(tmp_path, monkeypatch)
    to_code(lab)
    rv = lab.review()
    open_ = rv["data"]["f4_open"]
    assert [x["id"] for x in open_] == ["R1", "R3", "R4", "R6", "R5"] and {x["verdict"] for x in open_} == {RS.NOT_CHECKED, RS.NOT_EXERCISED}
    with pytest.raises(ValueError, match="decide each requirement the program could not show to hold \\(R1, R3, R4, R6, R5\\)"):
        lab.decide("approve", accept_open=False)                              # nothing is chosen for him
    with pytest.raises(ValueError, match="decide each requirement"):
        lab.decide("approve", edits={"req_decisions": {"R1": "accept", "R3": "yes"}}, accept_open=False)
    asks = dict({x["id"]: "accept" for x in open_}, R5="check")
    with pytest.raises(ValueError, match="you asked for a check or a change for R5: send the code back"):
        lab.decide("approve", edits={"req_decisions": asks}, accept_open=False)
    lab.decide("approve", edits={"req_decisions": {x["id"]: "accept" for x in open_}}, accept_open=False)
    kept = lab.rule()["code"]["requirement_decisions"]
    assert [d["id"] for d in kept] == ["R1", "R3", "R4", "R6", "R5"] and kept[-1]["decision"] == "accepted as it is" and kept[-1]["by"] == "Sagar" and kept[-1]["verdict"] == RS.NOT_EXERCISED


def rounds_of(out):
    with open(out["trail_file"], encoding="utf-8") as fh:
        return json.load(fh)["rounds"]


def test_a_tester_answer_that_cannot_be_read_is_asked_for_a_second_time(tmp_path, monkeypatch):
    lab = bench(tmp_path, monkeypatch)
    real = lab.tester
    lab.tester = lambda ctx, n: "unreadable" if n == 0 else real(ctx, n)
    to_code(lab)
    out = lab.out("code")
    asked = [a for a in lab.agents if a.startswith("f4_tester_")]
    assert asked[0] == "f4_tester_" + lab.item and asked[1] == "f4_tester_" + lab.item + "_again"
    assert "asked a second time: the first answer could not be read" in rounds_of(out)[0]["tester"]["by"] and rounds_of(out)[0]["tester"]["new_data_sets"]
    assert out["proof"] and any(x["verdict"] == RS.MET for x in out["proof"]["rows"])


def test_a_round_whose_tester_never_answered_is_not_called_clean_and_every_requirement_is_the_admins_to_decide(tmp_path, monkeypatch):
    """Found by the real check of 2026-11-14: one answer of the Tester that was not JSON made the stand-in the Tester; the round
    was called clean, the table was hidden and the code could be approved with no data set of the Tester and no decision."""
    lab = bench(tmp_path, monkeypatch)
    lab.tester = lambda ctx, n: "unreadable"
    to_code(lab)
    out, rv = lab.out("code"), lab.review()
    assert out["clean"] is False and out["rounds_used"] == 1 and lab.calls.count("coder") == 1 and lab.calls.count("tester") == 2 and lab.calls.count("cover") == 0
    assert "the Tester's answer could not be read, twice (http failed: Expecting ',' delimiter" in out["stopped_because"] and "no new data set of the Tester" in out["stopped_because"]
    assert rounds_of(out)[0]["tester"]["could_not_be_read"].startswith("http failed") and rounds_of(out)[0]["clean"] is False
    assert out["proof"] and all(x["verdict"] in (RS.NOT_CHECKED, RS.NOT_EXERCISED) for x in out["proof"]["rows"])
    assert [x["id"] for x in rv["data"]["f4_open"]] and "**It is not clean:**" in rv["body"] and "could not be checked" in rv["body"]
    with pytest.raises(ValueError, match="decide each requirement the program could not show to hold"):
        lab.decide("approve", comment="accepted", accept_open=False)


def test_ask_for_a_check_goes_back_to_the_tester_with_the_admins_words(tmp_path, monkeypatch):
    lab = bench(tmp_path, monkeypatch)
    to_code(lab)
    lab.decide("change", comment="show me that an empty Result is left out", edits={"req_decisions": {"R5": "check"}})
    lab.work()
    fb = lab.of("coder")[-1]["ADMIN_FEEDBACK"]
    assert fb[0] == "show me that an empty Result is left out" and fb[-1] == "The admin asks for a check that can fail for R5: the Tester makes a data set for each."


def test_a_failing_data_set_makes_its_requirement_not_met_and_the_rows_go_back_to_the_coder(tmp_path, monkeypatch):
    lab = bench(tmp_path, monkeypatch)
    lab.coder = lambda ctx, n: {"notes": [], "code": NO_FILTER if n == 0 else GOOD, "how": []}
    to_code(lab)
    first, second = lab.of("coder")
    failed = second["WHAT_FAILED"][0]
    assert failed["requirements_it_tests"] == ["R2"] and failed["expected_rows"] == [["1", 1]] and failed["the_code_wrote"] == [["1", "2"]] and "bench.csv" in failed["the_data"]
    trail = json.load(open(lab.out("code")["trail_file"], encoding="utf-8"))["rounds"]
    r1 = {x["id"]: x for x in trail[0]["proof"]["rows"]}
    assert r1["R2"]["verdict"] == RS.NOT_MET and r1["R2"]["class"].startswith("the code is wrong") and trail[0]["proof"]["rows"][0]["id"] == "R2" and trail[0]["whole_file"] is None
    assert "not met: R2" in trail[0]["said"] and trail[0]["clean"] is False
    assert {x["id"]: x["verdict"] for x in lab.out("code")["proof"]["rows"]}["R2"] == RS.MET and lab.out("code")["rounds_used"] == 2


def test_an_accounting_that_does_not_add_up_is_not_clean_and_its_numbers_go_back(tmp_path, monkeypatch):
    lab = bench(tmp_path, monkeypatch)
    lab.coder = lambda ctx, n: {"notes": [], "code": LOSES_A_ROW if n == 0 else GOOD, "how": []}
    to_code(lab)
    second = lab.of("coder")[1]
    bad = next(x for x in second["WHAT_FAILED"] if x["found_by"] == "the application, on the whole of bench.csv")
    assert bad["what"].startswith("every row of the file is accounted for exactly once") and "1 row unaccounted" in bad["what"]
    assert bad["your_accounting"]["rows_kept"] == 2 and bad["the_files_rows_counted_by_the_application"] == {"bench.csv": 8}
    trail = json.load(open(lab.out("code")["trail_file"], encoding="utf-8"))["rounds"]
    assert trail[0]["clean"] is False and "DOES NOT HOLD" in trail[0]["said"] and trail[1]["clean"] is True
    assert "on the whole of bench.csv every check that needs no expected answer held" in lab.out("code")["stopped_because"]


def test_a_program_without_an_accounting_is_said_to_give_none(tmp_path, monkeypatch):
    lab = bench(tmp_path, monkeypatch)
    lab.coder = lambda ctx, n: {"notes": [], "code": GOOD.replace('"accounting": {', '"not_an_accounting": {'), "how": []}
    to_code(lab)
    out = lab.out("code")
    (c,) = out["whole_file"]["checks"]
    assert c["ok"] is None and c["detail"] == "the program gave no accounting of its rows" and out["clean"] is True
    assert out["proof"]["whole_file"][0]["verdict"] == RS.NOT_CHECKED and "could not be checked" in lab.review()["body"]


def test_a_program_that_reads_a_column_of_no_file_of_the_rule_is_refused(tmp_path, monkeypatch):
    lab = bench(tmp_path, monkeypatch)
    lab.coder = lambda ctx, n: {"notes": [], "code": GOOD.replace('head.index("Latency_us")', 'head.index("Duration")') if n == 0 else GOOD, "how": []}
    to_code(lab)
    trail = json.load(open(lab.out("code")["trail_file"], encoding="utf-8"))["rounds"]
    assert trail[0]["static"] == ["the program reads the column “Duration”, which is not a column of bench.csv (the header was read by the application)"] and trail[0]["sample"] is None
    assert "Duration" in lab.of("coder")[1]["WHAT_FAILED"][0]["what"] and lab.out("code")["clean"] is True
    read, unknown = RS.columns_read_by('i = head.index("Queue"); j = head.index(\'Nope\'); x = row["Result"]', {"bench.csv": ["Queue", "Result"]})
    assert read == {"Queue", "Result"} and unknown == {"Nope"}


def test_the_four_verdicts_are_decided_by_code_and_no_percentage_is_made():
    reqs = [("R1", "a"), ("R2", "b"), ("R3", "c"), ("R4", "d"), ("R5", "e")]
    cases = [{"name": "p", "by": "the Tester", "tests": ["R1"], "status": "passed"}, {"name": "f", "by": "the Tester", "tests": ["R2"], "status": "failed", "detail": "line 1"},
             {"name": "p2", "by": "the Tester", "tests": ["R2"], "status": "passed"}, {"name": "w", "by": "the Tester", "does_not_test": ["R4"], "status": "passed"},
             {"name": "free", "by": "the Tester", "status": "passed"}]
    whole = {"on": "the whole of f.csv", "checks": [{"check": "every row", "ok": False, "detail": "2 rows unaccounted"}],
             "accounting": {"rows_left_out": [{"requirement": "R3", "reason": "empty", "rows": 0, "lines": []}, {"requirement": "R5", "reason": "x", "rows": 7, "lines": [2, 3]}]}}
    t = RS.proof_table(reqs, cases, whole)
    assert [(x["id"], x["verdict"]) for x in t["rows"]] == [("R2", RS.NOT_MET), ("R4", RS.NOT_CHECKED), ("R5", RS.NOT_CHECKED), ("R3", RS.NOT_EXERCISED), ("R1", RS.MET)]
    assert t["without_a_check"] == 3 and t["checks_tied_to_no_requirement"] == 2 and t["whole_file"][0]["verdict"] == RS.NOT_MET
    assert RS.not_met(t) == ["R2", "the whole file: every row"] and [x["id"] for x in RS.open_requirements(t)] == ["R4", "R5", "R3"]
    assert "percent" not in json.dumps(t) and "%" not in "\n".join(RS.table_body(t))
    assert RS.requirement_ids({"requirements": ["x", "y"]}) == [("R1", "x"), ("R2", "y")]                 # a record made before the identifiers existed
    assert RS.proof_table([], [], None)["rows"] == [] and RS.table_body(None) == []


def test_a_data_set_can_fail_only_when_ignoring_the_requirement_changes_its_rows():
    cmp_ = family4.compare
    base = {"expected_rows": [["1", 1]], "order_matters": True, "_want_cols": ["Queue", "count"]}
    assert RS.can_fail(dict(base, without_it_rows=[["1", 2]]), cmp_) is True
    assert RS.can_fail(dict(base, without_it_rows=[["1", "1.0"]]), cmp_) is False             # the same rows, written another way
    assert RS.can_fail(dict(base, without_it_rows=None), cmp_) is False and RS.can_fail(dict(base, expected_rows=None, without_it_rows=[["1", 2]]), cmp_) is False
    assert RS.can_fail(dict(base, without_it_rows=[["1"]]), cmp_) is False                     # not the output's columns


def test_an_item_from_before_the_research_existed_still_goes_through(tmp_path, monkeypatch):
    lab = T.Lab(tmp_path, monkeypatch).start()
    lab.store.exec("UPDATE step SET state='skipped', output='{}' WHERE run=? AND key='research'", (lab.rid,))      # as a run made by the earlier version
    st = lab.work()
    assert st["key"] == "req" and st["state"] == "needs_review" and lab.out("req")["research"] is None and lab.out("req")["requirement_ids"] == ["R1", "R2", "R3"]
    lab.decide("approve")
    assert lab.work()["state"] == "needs_review" and "DATA_RESEARCH" not in lab.of("coder")[0]
    lab.decide("approve")
    assert lab.rule()["code"]["verified_by"] == "Sagar"


def test_the_research_is_kept_while_the_files_do_not_change(tmp_path, monkeypatch):
    lab = bench(tmp_path, monkeypatch)
    lab.work()
    lab.store.exec("UPDATE step SET state='waiting' WHERE run=? AND key='research'", (lab.rid,))
    s = next(x for x in lab.steps() if x["key"] == "research")
    lab.eng._run_step(lab.store.one("SELECT * FROM run WHERE id=?", (lab.rid,)), s)
    again = next(x for x in lab.steps() if x["key"] == "research")
    assert again["state"] == "skipped" and "did not change" in again["note"] and lab.calls.count("research") == 1 and lab.out("research")["record"]["files"][0]["rows"] == 8


def test_the_new_instructions_are_documents_and_ask_for_no_reasoning():
    from agentic import prompts
    text = prompts.load("f4_data_research")
    for part in ("## Who you are", "## What you are given", "## What to do", "## What you do not do, and why", "## How to answer"):
        assert part in text
    assert "reasoning" not in text.lower() and "used by:" not in text and "MUST" not in text
    assert "accounting" in prompts.load("f4_coder") and "without_it_rows" in prompts.load("f4_tester", cases_per_round=5) and "settles" in prompts.load("f4_requirements", questions_most=8)
