// Which column holds this kind of data? (owner, 2026-11-14: "a column name is missing ... is there any way that I can substitute the
// same column name with the other column name? Because ... other column might be having the same kind of data")
// window.f2tSubstitute(pid, mountElement) draws a small form (the missing column, where it was expected, what it should hold) and, after
// the search, one card per column that could stand for it: what the program counted, what speaks against it, and the level of support
// the program gives it. Nothing is applied here: the cards are for reading, and for choosing on the requirements card of a rule.
(function () {
  const E = s => String(s === null || s === undefined ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const N = n => (n === null || n === undefined || n === "") ? "not counted" : Number(n).toLocaleString("en-US");
  async function post(url, body) {
    const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => ({ error: "the server answered " + r.status }));
    if (!r.ok) throw new Error(j.error || ("the server answered " + r.status));
    return j;
  }
  const LEVEL_WORDS = {
    "the values match": "the wanted values were counted in this column",
    "the kind of data matches": "no values could be compared; the meaning recorded for this column names the wanted data",
    "only the name is alike": "nothing but the name: not offered as a substitute unless you say so",
  };
  function card(p) {
    const o = p.overlap;
    return `<div class="card" style="margin:8px 0;padding:12px 14px">
      <div><b><code>${E(p.file)}</code> column <code>${E(p.column)}</code></b> <span class="pill">${E(p.level || "not supported")}</span></div>
      <div class="small muted">${E(LEVEL_WORDS[p.level] || "looked at closely; nothing the program counted supports it")}</div>
      <div class="small" style="margin-top:6px">
        ${p.meaning ? `<div><b>What it means, from the data dictionary:</b> ${E(p.meaning)}${p.meaning_source ? ` <span class="muted">(source: ${E(p.meaning_source)})</span>` : ""}</div>` : `<div class="muted">The data dictionary records no meaning for this column.</div>`}
        <div><b>What it holds:</b> ${N(p.rows_with_a_value)} rows with a value, ${N(p.distinct_values)} distinct${p.shape ? `; its values look like ${E(p.shape)}` : ""}${(p.some_values || []).length ? `, for example ${p.some_values.slice(0, 4).map(v => `<code>${E(v)}</code>`).join(", ")}` : ""}</div>
        ${o ? `<div><b>Counted:</b> ${N(o.found)} of the ${N(o.wanted_values)} wanted values are in it (${E(o.share_percent)} %), ${E(o.basis)}${o.rows_holding_a_wanted_value !== null && o.rows_holding_a_wanted_value !== undefined ? `; ${N(o.rows_holding_a_wanted_value)} rows hold one` : ""}${(o.lines || []).length ? `; seen at line${o.lines.length === 1 ? "" : "s"} ${o.lines.map(E).join(", ")}` : ""}</div>` : ""}
        ${p.model_reason ? `<div><b>The model's reading:</b> ${E(p.model_reason)}</div>` : ""}
        ${(p.against || []).length ? `<div class="err"><b>Against it:</b> ${p.against.map(E).join("; ")}</div>` : ""}
      </div></div>`;
  }
  function result(r) {
    const l = r.looked_at || {}, w = r.wanted || {};
    const head = `<p><b>${E(r.answer)}</b></p>
      <p class="small muted">Looked at: ${N(l.columns)} column${l.columns === 1 ? "" : "s"} of ${N(l.files)} file${l.files === 1 ? "" : "s"}; ${N(l.on_the_short_list)} went on to the exact count and to the model (${N(l.model_calls)} call${l.model_calls === 1 ? "" : "s"}, one per file, at the same time).
        ${(l.files_without_a_dictionary || []).length ? `Not looked at, because the data experts have not read them yet: ${l.files_without_a_dictionary.map(E).join(", ")}. ` : ""}
        ${w.values_from ? `The example values are ${E(w.values_from)}. ` : ""}${(l.dropped_by_the_program || []).length ? `Names the model gave that were not on the list were dropped: ${l.dropped_by_the_program.map(E).join("; ")}. ` : ""}
        ${(l.model_notes || []).length ? `The model on what would be needed: ${l.model_notes.map(E).join("; ")}.` : ""}</p>`;
    const props = (r.proposals || []).map(card).join("");
    const rest = (r.not_supported || []).length ? `<details class="more"><summary>Looked at closely and not supported (${r.not_supported.length})</summary>${r.not_supported.map(card).join("")}</details>` : "";
    return head + props + rest;
  }
  window.f2tSubstitute = function (pid, mount) {
    if (!mount) return;
    const id = "sub" + pid;
    mount.innerHTML = `<div class="lbl2">Find the column that holds a kind of data</div>
      <p class="small muted" style="margin:2px 0 8px">A rule names a column that is missing or empty. Every column of every file of this analysis is compared with what is wanted: by its values, their shape, and the meaning the data experts recorded. You get the few columns that could stand for it, each with what was counted. Nothing is changed.</p>
      <label class="f" for="${id}-col">The missing column <span class="hint">· its name as the rule writes it</span></label><input type="text" id="${id}-col" placeholder="for example SQID">
      <label class="f" for="${id}-file">The file it was expected in <span class="hint">· not needed</span></label><input type="text" id="${id}-file" placeholder="for example nvme_command.csv">
      <label class="f" for="${id}-desc">What it should hold, in your words</label><input type="text" id="${id}-desc" placeholder="for example: the identifier of the submission queue of a command">
      <label class="f" for="${id}-vals">Some of its values <span class="hint">· not needed · one per line or separated by commas</span></label><textarea id="${id}-vals" style="min-height:44px" placeholder="for example 0x0001, 0x0002"></textarea>
      <div class="row" style="gap:10px;align-items:center;margin-top:8px"><button type="button" class="btn small primary" id="${id}-go">Look for it</button><span class="small" id="${id}-msg"></span></div>
      <div id="${id}-out" style="margin-top:10px"></div>`;
    const $ = x => mount.querySelector("#" + id + "-" + x);
    $("go").onclick = async () => {
      const values = $("vals").value.split(/[\n,]+/).map(v => v.trim()).filter(Boolean);
      if (!$("col").value.trim() && !$("desc").value.trim() && !values.length) { $("msg").innerHTML = `<span class="err">say what is looked for: the name of the missing column, what it should hold, or some of its values</span>`; return; }
      $("go").disabled = true;
      $("msg").textContent = "comparing every column, then asking the model about the few that could fit…";
      $("out").innerHTML = "";
      try {
        const r = await post(`/api/agents/projects/${pid}/substitute`, { column: $("col").value.trim(), file: $("file").value.trim(), description: $("desc").value.trim(), values });
        $("msg").textContent = "";
        $("out").innerHTML = result(r);
      } catch (e) { $("msg").innerHTML = `<span class="err">${E(e.message)}</span>`; }
      $("go").disabled = false;
    };
  };
})();
