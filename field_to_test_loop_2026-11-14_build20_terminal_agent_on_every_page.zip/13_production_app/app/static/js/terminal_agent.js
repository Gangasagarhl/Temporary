/* The terminal agent, on every page of the application.

   (owner, 2026-11-14: "each and every page should have communication with the terminal agent because the agent families
   that has been implemented are limited or not having such capacity as like full harness like opencode")

   The agent families answer one question from what the program hands them. The terminal agent (the opencode program in a
   terminal at the backend) can open files, search folders, run small Python programs and write a CSV. This script puts
   one button on the page and one panel: the question goes to the backend's held terminal session, the panel shows what
   the agent is doing while it works, and the conversation is there again the next time.

   Which session: the analysis the page shows; else the analysis the recording on the page belongs to; else the session of
   the application (start page, Settings, rules library, ...). The backend decides (agentic/investigate.place_for).

   It uses no helper of any page, so the same file is loaded by every page. */
(function () {
  if (window.F2TTerminal) return;
  const T = { open: false, timer: null, draft: "", pid: null, data: null };
  const esc = v => String(v == null ? "" : v).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const el = id => document.getElementById(id);
  const ago = s => s < 60 ? `${s} s` : `${Math.floor(s / 60)} min ${String(s % 60).padStart(2, "0")} s`;
  const num = n => n == null ? "-" : Number(n).toLocaleString("en-US");

  // ---- where the admin is
  function pagePid() {
    if (T.pid) return T.pid;
    try { if (typeof sidePid === "function") return sidePid() || null; } catch (e) { /* not the flow page */ }
    return null;
  }
  function pageUpload() {
    try { const q = new URLSearchParams(location.search).get("upload"); if (q) return q; } catch (e) { /* old browser */ }
    const m = /up-\d{8}-\d{6}-[0-9a-f]{4}/.exec(location.href);
    return m ? m[0] : null;
  }
  function pageContext() {
    let heading = "", item = "";
    for (const h of document.querySelectorAll("h1, h2")) {
      if (h.closest("#ta-panel") || !h.offsetParent) continue;
      heading = (h.innerText || "").trim(); if (heading) break;
    }
    try { if (typeof sidePage === "function") { const p = sidePage() || {}; item = [p.title, p.item].filter(Boolean).join(" · "); } } catch (e) { /* not the flow page */ }
    let finding = "";
    try { finding = new URLSearchParams(location.search).get("finding") || ""; } catch (e) { /* old browser */ }
    return { path: location.pathname, address: location.pathname + location.search + location.hash, title: document.title, heading, upload: pageUpload() || "", finding, item };
  }
  const placeQuery = () => { const q = new URLSearchParams(); const pid = pagePid(), up = pageUpload(); if (pid) q.set("pid", pid); else if (up) q.set("upload", up); return q.toString(); };
  const placeBody = more => { const b = Object.assign({}, more || {}); const pid = pagePid(), up = pageUpload(); if (pid) b.pid = pid; else if (up) b.upload = up; return b; };
  function adminName() { try { return localStorage.getItem("agents.admin") || ""; } catch (e) { return ""; } }

  async function call(method, url, body) {
    const r = await fetch(url, { method, headers: body ? { "Content-Type": "application/json" } : {}, body: body ? JSON.stringify(body) : undefined });
    let d = null;
    try { d = await r.json(); } catch (e) { d = null; }
    if (!r.ok) throw new Error((d && d.error) || `the application answered ${r.status}`);
    return d;
  }

  // ---- the look: its own colours, light or dark by the page it sits on
  function css() {
    if (el("ta-style")) return;
    const s = document.createElement("style"); s.id = "ta-style";
    s.textContent = `
.ta-root{--ta-bg:#ffffff;--ta-fg:#1a2028;--ta-muted:#5a6572;--ta-line:#d3d9e0;--ta-soft:#f3f5f8;--ta-accent:#1f5fbf;--ta-on:#ffffff;--ta-err:#b3261e;font:14px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:var(--ta-fg)}
.ta-root.ta-dark{--ta-bg:#161b22;--ta-fg:#e6eaf0;--ta-muted:#9aa5b1;--ta-line:#343c47;--ta-soft:#1f2630;--ta-accent:#6ea8ff;--ta-on:#0d1117;--ta-err:#ff8a80}
#ta-btn{position:fixed;right:max(16px,env(safe-area-inset-right,0px));bottom:max(16px,env(safe-area-inset-bottom,0px));z-index:70;display:flex;gap:8px;align-items:center;padding:10px 14px;border-radius:999px;border:1px solid var(--ta-line);background:var(--ta-bg);color:var(--ta-fg);font:inherit;font-weight:600;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.18)}
#ta-btn:hover{border-color:var(--ta-accent)}
#ta-btn .dot{width:8px;height:8px;border-radius:50%;background:var(--ta-muted)}
#ta-btn.busy .dot{background:var(--ta-accent);animation:ta-pulse 1.2s infinite}
@keyframes ta-pulse{50%{opacity:.25}}
@media (prefers-reduced-motion: reduce){#ta-btn.busy .dot{animation:none}}
#ta-scrim{position:fixed;inset:0;background:rgba(8,14,20,.45);z-index:80}
#ta-panel{position:fixed;top:0;right:0;bottom:0;width:min(640px,100vw);z-index:81;background:var(--ta-bg);border-left:1px solid var(--ta-line);display:flex;flex-direction:column;box-shadow:-8px 0 24px rgba(0,0,0,.2)}
#ta-panel .ta-head{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:14px 16px;border-bottom:1px solid var(--ta-line)}
#ta-panel h2{margin:0;font-size:17px;color:var(--ta-fg)}
#ta-panel h3{margin:16px 0 4px;font-size:14px;color:var(--ta-fg)}
#ta-body{padding:12px 16px 20px;overflow:auto;flex:1;min-height:0}
#ta-panel p{margin:0 0 8px}
#ta-panel .ta-small{font-size:12.5px}
#ta-panel .ta-muted{color:var(--ta-muted)}
#ta-panel .ta-err{color:var(--ta-err)}
#ta-panel .ta-why{font-size:12.5px;color:var(--ta-muted);margin:2px 0 6px}
#ta-panel label{display:block;font-weight:600;margin-top:12px}
#ta-panel textarea{width:100%;box-sizing:border-box;margin-top:4px;padding:8px 10px;border:1px solid var(--ta-line);border-radius:8px;background:var(--ta-bg);color:var(--ta-fg);font:inherit;resize:vertical}
#ta-panel .ta-b{padding:7px 12px;border-radius:8px;border:1px solid var(--ta-line);background:var(--ta-soft);color:var(--ta-fg);font:inherit;cursor:pointer;text-decoration:none;display:inline-block}
#ta-panel .ta-b.pri{background:var(--ta-accent);border-color:var(--ta-accent);color:var(--ta-on);font-weight:600}
#ta-panel .ta-b:disabled{opacity:.5;cursor:default}
#ta-panel .ta-b.sm{padding:4px 9px;font-size:12.5px}
#ta-panel .ta-acts{display:flex;gap:8px;justify-content:flex-end;align-items:center;flex-wrap:wrap;margin-top:8px}
#ta-panel .ta-turn{margin:12px 0;padding:10px 12px;border:1px solid var(--ta-line);border-radius:10px}
#ta-panel .ta-q{white-space:pre-wrap;font-weight:600;margin:4px 0 8px;overflow-wrap:anywhere}
#ta-panel .ta-a{white-space:pre-wrap;overflow-wrap:anywhere}
#ta-panel .ta-work{margin:12px 0;padding:10px 12px;border:1px solid var(--ta-accent);border-radius:10px}
#ta-panel ol{margin:4px 0 0 18px;padding:0;max-height:180px;overflow:auto}
#ta-panel .ta-tbl{overflow-x:auto}
#ta-panel table{border-collapse:collapse;width:100%}
#ta-panel th,#ta-panel td{text-align:left;padding:5px 8px;border-bottom:1px solid var(--ta-line);vertical-align:top}
#ta-panel code{background:var(--ta-soft);padding:1px 4px;border-radius:4px;overflow-wrap:anywhere}`;
    document.head.appendChild(s);
  }
  function isDark() {
    const m = /rgba?\(([^)]+)\)/.exec(getComputedStyle(document.body).backgroundColor || "");
    if (m) {
      const p = m[1].split(",").map(Number);
      if (p.length < 4 || p[3] > 0.1) return (0.2126 * p[0] + 0.7152 * p[1] + 0.0722 * p[2]) < 110;
    }
    return !!(window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches);
  }
  const paint = node => node.classList.toggle("ta-dark", isDark());

  // ---- the panel
  function turnHtml(t) {
    return `<div class="ta-turn">
      <div class="ta-small ta-muted">Question ${esc(t.n)} · ${esc(t.at || "")}${t.seconds != null ? " · answered in " + esc(ago(Math.round(t.seconds))) : ""}${t.page ? " · asked from: " + esc(t.page.replace(/^Page: /, "").replace(/\.$/, "")) : ""}</div>
      <div class="ta-q">${esc(t.asked)}</div>
      ${t.ok ? `<div class="ta-a">${esc(t.answered)}</div>` : `<div class="ta-err">Not answered: ${esc(t.problem || "no reason was given")}</div>`}</div>`;
  }
  function view(d) {
    const s = d.session, run = d.running, an = d.place === "analysis";
    const place = an
      ? `<p class="ta-small ta-muted">This page belongs to analysis ${esc(d.project)}${d.analysis_name ? " (" + esc(d.analysis_name) + ")" : ""}. Your questions go to that analysis's own terminal session, the same one from every page of the analysis. The agent reads the data dictionaries and the CSV files of the analysis and, when the tree was built, the tree; it runs small Python programs to count and compare, and it can write a new CSV file. It cannot change the data files.</p>`
      : `<p class="ta-small ta-muted">This page shows no single analysis, so your questions go to the application's terminal session. The agent there reads the rules library, the stored data dictionaries, the joining strategies and the documents of the application. For a question about the data of one analysis, open that analysis and ask from there.</p>`;
    const head = !d.ready
      ? `<p class="ta-err">${esc(d.problem || "The terminal program is not ready.")} The terminal agent works through the opencode program at the backend; its model is chosen in Settings, under “opencode in a terminal”.</p>`
      : `<p class="ta-small ta-muted">Session “${esc(d.name)}” · model ${esc(d.model || "")}${s ? ` · ${esc(num(s.turns))} question${s.turns === 1 ? "" : "s"} so far · it holds ${esc(num(s.holds_tokens))} tokens of what the model can read (a token is about 2 to 4 characters) · opencode's number for it: ${esc(s.terminal_id || "")}` : " · no question asked yet: the first one starts the session"}. Every question continues this same session, also after the application was started again.</p>`;
    const earlier = (d.earlier_sessions || []).length ? `<p class="ta-small ta-muted">Earlier parts of this conversation, kept to read: ${d.earlier_sessions.map(x => `${esc(x.name)} (${esc(num(x.turns))} questions; closed: ${esc(x.why_closed || "")})`).join("; ")}.</p>` : "";
    const status = run ? `<div class="ta-work">
        <div><b>Working</b> for ${esc(ago(run.seconds))} on: <span style="white-space:pre-wrap">${esc(run.question)}</span></div>
        <div class="ta-small ta-muted" style="margin-top:6px">What it is doing in the terminal, newest last:</div>
        <ol class="ta-small" id="ta-lines">${(run.lines || []).map(l => `<li>${esc(l.text)}</li>`).join("") || "<li>starting the terminal program…</li>"}</ol>
        <div style="margin-top:8px"><button type="button" class="ta-b sm" id="ta-stop">Stop this question</button></div></div>` : "";
    const err = !run && d.last_error ? `<p class="ta-err">The last question ended without an answer: ${esc(d.last_error)}</p>` : "";
    const q = placeQuery();
    const files = (d.exports || []).length ? `<h3>Files the agent wrote</h3><div class="ta-tbl"><table><thead><tr><th>File</th><th>Size</th><th></th></tr></thead><tbody>${d.exports.map(e =>
      `<tr><td>${esc(e.name)}</td><td>${esc(e.size)}</td><td><a class="ta-b sm" href="/api/agents/terminal/exports/${encodeURIComponent(e.name)}${q ? "?" + q : ""}">Save</a>
        ${an && /\.csv$/i.test(e.name) ? `<button type="button" class="ta-b sm" data-ta-add="${esc(e.name)}" title="copies the file into the analysis's folder; then press Read the new files on the card after Family 1 and only this file gets its three agents">Add to the analysis</button>` : ""}</td></tr>`).join("")}</tbody></table></div>
      <p class="ta-small ta-muted" id="ta-add-msg" style="margin-top:4px">They are in <code>${esc(d.folder)}/exports</code> on the computer that runs the application.</p>` : "";
    const sub = an && window.f2tSubstitute ? `<button type="button" class="ta-b" id="ta-sub-btn" title="asks the data experts of every file at the same time; no terminal is used for this">Find a substitute for a missing column</button>` : "";
    return `${place}${head}${earlier}
      <div id="ta-conv">${(d.conversation || []).map(turnHtml).join("")}</div>
      ${status}${err}
      <div id="ta-sub"></div>
      <label for="ta-q">Your question</label>
      <div class="ta-why">It goes to the terminal agent together with where you are now: this page, its address and its heading. So “this error” or “this rule” means the one on the page.</div>
      <textarea id="ta-q" rows="4" placeholder="what should it find out, check in the files, or write as a CSV?" ${run || !d.ready ? "disabled" : ""}>${esc(T.draft)}</textarea>
      <div class="ta-acts"><span class="ta-small" id="ta-msg"></span>${sub}<button type="button" class="ta-b pri" id="ta-send" ${run || !d.ready ? "disabled" : ""}>Ask the terminal agent</button></div>
      ${files}`;
  }

  async function load(keepScroll) {
    if (!T.open) return;
    const body = el("ta-body");
    let d;
    try { d = await call("GET", "/api/agents/terminal" + (placeQuery() ? "?" + placeQuery() : "")); }
    catch (e) { if (body) body.innerHTML = `<p class="ta-err">${esc(e.message)}</p>`; return; }
    if (!T.open || !body) return;
    T.data = d;
    const q = el("ta-q");
    if (q && !q.disabled) T.draft = q.value;
    const hadFocus = document.activeElement && document.activeElement.id === "ta-q", caret = hadFocus ? q.selectionStart : null;
    const linesEl = el("ta-lines"), atEnd = !linesEl || linesEl.scrollTop + linesEl.clientHeight >= linesEl.scrollHeight - 8, top = body.scrollTop;
    const sub = el("ta-sub"), subKeep = sub && sub.childNodes.length ? sub : null;
    body.innerHTML = view(d);
    if (subKeep) el("ta-sub").replaceWith(subKeep);
    if (keepScroll) body.scrollTop = top;
    const l2 = el("ta-lines"); if (l2 && atEnd) l2.scrollTop = l2.scrollHeight;
    const q2 = el("ta-q");
    if (q2) {
      q2.addEventListener("keydown", e => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); send(); } });
      if (hadFocus && !q2.disabled) { q2.focus(); try { q2.setSelectionRange(caret, caret); } catch (e) { /* not a text field */ } }
    }
    if (el("ta-send")) el("ta-send").onclick = send;
    if (el("ta-stop")) el("ta-stop").onclick = async () => { const m = el("ta-msg"); try { await call("POST", "/api/agents/terminal/stop", placeBody()); if (m) m.textContent = "stopping…"; } catch (e) { if (m) m.innerHTML = `<span class="ta-err">${esc(e.message)}</span>`; } };
    if (el("ta-sub-btn")) el("ta-sub-btn").onclick = () => { const m = el("ta-sub"); if (!m.childNodes.length) window.f2tSubstitute(d.project, m); m.scrollIntoView({ block: "nearest" }); };
    document.querySelectorAll("[data-ta-add]").forEach(b => b.onclick = async () => {
      const msg = el("ta-add-msg");
      try { const r = await call("POST", `/api/agents/terminal/exports/${encodeURIComponent(b.dataset.taAdd)}/add`, placeBody()); msg.className = "ta-small"; msg.textContent = `Copied to ${r.to}. Next: ${r.next}.`; }
      catch (e) { msg.className = "ta-small ta-err"; msg.textContent = e.message; }
    });
    busy(!!d.running);
    clearTimeout(T.timer);
    if (d.running) T.timer = setTimeout(() => load(true), 2000);
  }

  async function send() {
    const q = el("ta-q").value.trim(), msg = el("ta-msg");
    if (!q) { msg.innerHTML = `<span class="ta-err">write the question first</span>`; return; }
    el("ta-send").disabled = true; msg.textContent = "starting…";
    try {
      await call("POST", "/api/agents/terminal", placeBody({ question: q, admin: adminName(), page: pageContext() }));
      T.draft = ""; el("ta-q").value = "";
      await load(false);
      const b = el("ta-body"); if (b) b.scrollTop = b.scrollHeight;
    } catch (e) { msg.innerHTML = `<span class="ta-err">${esc(e.message)}</span>`; el("ta-send").disabled = false; }
  }

  function busy(on) { const b = el("ta-btn"); if (b) b.classList.toggle("busy", on); }

  function close() {
    const q = el("ta-q"); if (q && !q.disabled) T.draft = q.value;
    T.open = false; clearTimeout(T.timer);
    for (const id of ["ta-panel", "ta-scrim"]) { const n = el(id); if (n) n.remove(); }
    const b = el("ta-btn") || el("inv-btn"); if (b) b.focus();
  }

  function open(pid) {
    const want = pid ? Number(pid) || null : null;
    if (want !== T.pid) { T.draft = ""; T.pid = want; }
    if (T.open) { load(false); return; }
    css();
    T.open = true;
    const scrim = document.createElement("div"); scrim.id = "ta-scrim"; scrim.onclick = close;
    const panel = document.createElement("aside"); panel.id = "ta-panel"; panel.className = "ta-root";
    panel.setAttribute("role", "dialog"); panel.setAttribute("aria-label", "Terminal agent");
    panel.innerHTML = `<div class="ta-head"><h2>Terminal agent</h2><button type="button" class="ta-b sm" id="ta-close">Close</button></div><div id="ta-body"><p class="ta-muted">reading…</p></div>`;
    paint(panel);
    document.body.appendChild(scrim); document.body.appendChild(panel);
    el("ta-close").onclick = close;
    load(false);
  }
  document.addEventListener("keydown", e => { if (e.key === "Escape" && T.open) close(); });

  // ---- the button: the flow page has one in its top bar (#inv-btn); every other page gets one at the lower right corner
  function button() {
    css();
    const top = el("inv-btn");
    if (top) {
      top.hidden = false;
      top.title = "the terminal agent: it can open the files, run small programs and write a CSV; on a page of an analysis it works on that analysis";
      top.addEventListener("click", () => open(null));
      return;
    }
    if (el("ta-btn")) return;
    const b = document.createElement("button"); b.type = "button"; b.id = "ta-btn"; b.className = "ta-root";
    b.title = "ask the terminal agent at the backend: it can open the files, run small programs and write a CSV";
    b.innerHTML = `<span class="dot" aria-hidden="true"></span>Terminal agent`;
    paint(b);
    b.addEventListener("click", () => open(null));
    document.body.appendChild(b);
  }
  // a button of the flow page that names its analysis ("Investigate first" on the card after Family 1)
  document.addEventListener("click", e => { const b = e.target.closest && e.target.closest("[data-investigate]"); if (b) open(Number(b.dataset.investigate) || null); });

  window.F2TTerminal = { open, close, context: pageContext };
  window.openInvestigation = pid => open(pid);          // the name the flow page used before
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", button); else button();
})();
