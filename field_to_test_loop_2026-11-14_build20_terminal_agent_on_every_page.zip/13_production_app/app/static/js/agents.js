// The flow, as pages: home (start or open a project), then one page per stage of the flow
//   1 Understand the data (Family 1) -> 2 One tree (Family 2) -> 3 Rules, defects and test cases (Family 3) -> 4 Report
// Each page shows only what belongs to that moment: the decision that waits for you, what is working now, then the steps.
// The rules library, the history of runs and the settings open only where they are needed.
"use strict";
const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const DONE = ["done", "approved", "skipped"];
const STAGES = [
  { id: "data", fam: "1", n: 1, short: "Understand the data", who: "Family 1 · Data experts", title: "Understand the data",
    text: "One sub-family per file, three agents with separate memories: the Data Explorer reads every row by code (the data only: columns, keywords, counts, lines), the Data Grounder finds what each column and keyword means (documents, the web, model knowledge), and the Manager puts both together for you and answers your questions. After the last dictionary you can ask all the Managers whether a kind of data is in the files, have CSV files that were added to the folder read, and choose whether stage 2 (the tree) is needed." },
  { id: "tree", fam: "2", n: 2, short: "One tree", who: "Family 2 · Hierarchy", title: "Connect the five files into one tree",
    text: "A choice you make after the data: the tree is not needed for every input. The fixed joining strategy joins packets, link and split transactions, NVMe transactions and commands, with its evidence. After your approval the tree is built on disk and tested three ways. When you went on without stage 2, its steps are shown here as skipped." },
  { id: "rules", fam: "3", n: 3, short: "Rules, defects, test cases", who: "Family 3 · Rules, Family 4 · Coding research", title: "Rules, defects and test cases",
    text: "You choose which analytics (Section 1) and which errors (Section 2) to run, on the tree or, without one, on the files as they are. Family 4, the coding research family, then makes each item's code. It first researches the data the rule reads: what Families 1 and 2 hold, what you said for this rule, and what the content of the columns shows, counted by the program. It agrees the numbered requirements with you, writes and tests the code in rounds (10 unless you set another number), runs it on the whole file, and shows for each requirement whether the code meets it on the data. Each error is then taken through its own page: stage 1, isolating the defect; stage 2, the procedural graph (its cause and the solution); then the test case that makes it happen again." },
  { id: "report", fam: "R", n: 4, short: "Report", who: "Admin Agent", title: "Report",
    text: "What every family produced, in one place, with links to every export and test file." },
];
const STAGE_OF_FAM = { "1": "data", "2": "tree", "3": "rules", "4": "rules", R: "report" };       // Family 4 · Coding research works inside the rules stage
const STATE_WORDS = { waiting: "not started", running: "working", needs_review: "needs your decision", approved: "approved by you", done: "done",
  skipped: "skipped", failed: "failed", rejected: "stopped by you", finished: "finished", stopped: "stopped" };
const IC = {
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16"/><path d="M10 11v6M14 11v6"/><path d="M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12"/><path d="M9 7V4h6v3"/></svg>',
  skip: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M6 12h12"/></svg>',
  alert: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M12 6v7"/><path d="M12 17.5h.01"/></svg>',
  x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M7 7l10 10M17 7L7 17"/></svg>',
  chev: '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>',
  left: '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 6l-6 6 6 6"/></svg>',
  play: '<svg class="i" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5.5v13l11-6.5z"/></svg>',
  ext: '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 4h6v6"/><path d="M20 4l-9 9"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>',
  book: '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 19V5"/></svg>',
  plus: '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
};
let S = { admin: "", project: null, state: null, poll: null, ui: {}, toastT: null, busy: false };
try { S.admin = localStorage.getItem("agents.admin") || ""; S.project = Number(localStorage.getItem("agents.project")) || null; } catch (e) { /* private window */ }

async function api(method, url, body) {
  const r = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) });
  const j = await r.json().catch(() => ({ error: "the server answered " + r.status }));
  if (!r.ok) { const er = new Error(j.error || ("HTTP " + r.status)); er.data = j; er.status = r.status; throw er; }
  return j;
}
const when = t => t ? new Date(t * 1000).toLocaleString([], { dateStyle: "medium", timeStyle: "short" }) : "-";
const fileHref = p => "/api/agents/file?path=" + encodeURIComponent(p);
const nf = n => (n === null || n === undefined || n === "") ? "-" : Number(n).toLocaleString();
function toast(t) { const el = $("toast"); el.textContent = t; el.classList.add("on"); clearTimeout(S.toastT); S.toastT = setTimeout(() => el.classList.remove("on"), 2600); }
function setAdmin(n) { S.admin = (n || "").trim(); try { localStorage.setItem("agents.admin", S.admin); } catch (e) { /* private window */ } paintTop(); }
function setProject(id) { S.project = Number(id) || null; try { localStorage.setItem("agents.project", S.project || ""); } catch (e) { /* private window */ } }
const nav = h => { if (location.hash === h) render(); else location.hash = h; };
// the tree page opened from the flow: only the hierarchy, its summary and filters (the flow loaded the files and handles the defects)
const treeHref = up => `/hier?upload=${encodeURIComponent(up)}&from=flow${S.project ? "&project=" + S.project : ""}`;

// a small markdown renderer for the agents' texts (bold, italics, code, tables, lists, code fences)
function md(text) {
  const lines = String(text || "").split("\n"); let out = [], i = 0;
  const inline = s => esc(s).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/(^|\s)\*([^*]+)\*/g, "$1<i>$2</i>").replace(/`([^`]+)`/g, "<code>$1</code>");
  while (i < lines.length) {
    const l = lines[i];
    if (l.startsWith("```")) { let j = i + 1, buf = []; while (j < lines.length && !lines[j].startsWith("```")) buf.push(lines[j++]); out.push(`<pre>${esc(buf.join("\n"))}</pre>`); i = j + 1; continue; }
    if (l.trim().startsWith("|")) {
      let rows = []; while (i < lines.length && lines[i].trim().startsWith("|")) rows.push(lines[i++]);
      rows = rows.filter(r => !/^\|\s*-/.test(r.trim()));
      out.push(`<div class="tbl"><table>` + rows.map((r, k) => `<tr>${r.trim().replace(/^\||\|$/g, "").split("|").map(c => k === 0 ? `<th>${inline(c.trim())}</th>` : `<td>${inline(c.trim())}</td>`).join("")}</tr>`).join("") + `</table></div>`);
      continue;
    }
    if (l.trim().startsWith("- ")) { let items = []; while (i < lines.length && lines[i].trim().startsWith("- ")) items.push(`<li>${inline(lines[i++].trim().slice(2))}</li>`); out.push(`<ul>${items.join("")}</ul>`); continue; }
    if (l.trim()) out.push(`<p>${inline(l)}</p>`);
    i++;
  }
  return `<div class="md">${out.join("")}</div>`;
}
// the review text starts with "Admin X, need review." - the card already says it is your decision
const bodyOf = r => String(r.body || "").replace(/^\*\*Admin [^*]*need review\.\*\*\s*/, "");

// ------------------------------------------------------------------ progress, the same everywhere (owner, 2026-11-09)
// A running step's note says "37% · <what> · 2.2 GB of 6.0 GB read · 1 min 10 s so far · about 2 min left": the bar is drawn
// from its percentage; a note without one gets a moving bar and the time so far (from the step's start).
const fmtSecs = s => { s = Math.max(0, Math.round(s)); return s < 60 ? `${s} s` : s < 3600 ? `${Math.floor(s / 60)} min ${String(s % 60).padStart(2, "0")} s` : `${Math.floor(s / 3600)} h ${String(Math.floor(s % 3600 / 60)).padStart(2, "0")} min`; };
function progressView(st, fallback) {
  const note = (st && st.note) || "", m = /(\d+(?:\.\d+)?)\s*%/.exec(note), pct = m ? Math.min(100, +m[1]) : null;
  const so = st && st.started && !/so far/.test(note) ? ` · ${fmtSecs(Date.now() / 1000 - st.started)} so far` : "";
  const text = note.replace(/^running the verified code · /, "") || fallback || "working";
  return `<div class="rb-bar ${pct === null ? "indet" : ""}" role="progressbar" aria-valuemin="0" aria-valuemax="100" ${pct === null ? "" : `aria-valuenow="${Math.floor(pct)}"`}><div class="rb-fill" style="${pct === null ? "" : `width:${Math.max(2, pct)}%`}"></div></div>
    <div class="note">${esc(text)}${so}</div>`;
}
// who answered a step, in words: "the model" (Claude Code or the model connection), "the stand-in" (no model); the extras kept
const plainProducer = p => {
  const x = String(p || ""), extra = [/with web search/.test(x) ? "with web search" : "", /effort (\w+)/.test(x) ? "effort " + /effort (\w+)/.exec(x)[1] : ""].filter(Boolean).join(", ");
  const who = /stand-in/i.test(x) ? "the stand-in (no model)" : /claude code|model connection|opencode in a terminal|haiku|sonnet|opus|claude-/i.test(x) ? "the model" : x;
  return who + (extra && who === "the model" ? ` (${extra})` : "");
};
// ------------------------------------------------------------------ a sound when a decision waits (owner, 2026-11-08)
// Browsers play sound only after the person has clicked the page once: the first click anywhere unlocks it.
S.sound = (() => { try { return localStorage.getItem("agents.sound") !== "off"; } catch (e) { return true; } })();
S.notify = (() => { try { return localStorage.getItem("agents.notify") === "on"; } catch (e) { return false; } })();
let AC = null;
function unlockSound() { try { AC = AC || new (window.AudioContext || window.webkitAudioContext)(); if (AC.state === "suspended") AC.resume(); } catch (e) { AC = null; } }
document.addEventListener("pointerdown", unlockSound, true);
document.addEventListener("keydown", unlockSound, true);
window.__chimes = 0;
function chime() {
  window.__chimes++;
  if (!AC) return false;
  try {
    const t = AC.currentTime;
    // a big, deep chime: three low notes (G3, C4, G4), each a warm triangle tone with a sine one octave below for depth,
    // long and loud, through a limiter so the louder sound never crackles
    const lim = AC.createDynamicsCompressor();
    lim.threshold.value = -6; lim.knee.value = 6; lim.ratio.value = 12; lim.attack.value = 0.003; lim.release.value = 0.25;
    const master = AC.createGain(); master.gain.value = 1.0;
    master.connect(lim); lim.connect(AC.destination);
    [[196, 0], [262, 0.28], [392, 0.56]].forEach(([f, d]) => {
      [["triangle", f, 0.9], ["sine", f / 2, 0.6]].forEach(([type, freq, peak]) => {
        const o = AC.createOscillator(), g = AC.createGain();
        o.type = type; o.frequency.value = freq;
        g.gain.setValueAtTime(0.0001, t + d); g.gain.exponentialRampToValueAtTime(peak, t + d + 0.03);
        g.gain.exponentialRampToValueAtTime(0.0001, t + d + 1.1);
        o.connect(g); g.connect(master); o.start(t + d); o.stop(t + d + 1.15);
      });
    });
    return true;
  } catch (e) { return false; }
}
let seenReviews = null;
function announce() {
  const open = (S.state && S.state.open_reviews) || [];
  document.title = (open.length ? "(" + open.length + ") " : "") + "Field-to-Test flow";
  const ids = new Set(open.map(r => r.id));
  if (seenReviews !== null) {
    const fresh = open.filter(r => !seenReviews.has(r.id));
    if (fresh.length) {
      if (S.sound) chime();
      if (S.notify && "Notification" in window && Notification.permission === "granted") {
        try { new Notification("A decision waits for you", { body: fresh[0].title, tag: "f2t-review-" + fresh[0].id }); } catch (e) { /* not allowed here */ }
      }
    }
  }
  seenReviews = ids;
}

// ------------------------------------------------------------------ top bar
async function refreshState() {
  try { S.state = await api("GET", "/api/agents/state"); } catch (e) { return; }
  paintTop();
  announce();
}
function paintTop() {
  const a = $("avatar"); a.textContent = S.admin ? S.admin.split(/\s+/).map(x => x[0]).join("").slice(0, 2).toUpperCase() : "?";
  a.title = S.admin ? `you are ${S.admin} (click to change)` : "set your name";
  const n = S.state ? S.state.open_reviews.length : 0, b = $("needs");
  b.classList.toggle("on", n > 0);
  b.innerHTML = `<span class="dot"></span>${n === 1 ? "1 decision waits for you" : n + " decisions wait for you"}`;
  // what runs now (owner, 2026-11-09: "give the status, how much percentage, so the admin can do other things")
  const busy = ((S.state && S.state.runs) || []).filter(r => r.state === "running" && r.now), w = $("working");
  if (w) {
    w.classList.toggle("on", busy.length > 0);
    if (busy.length) {
      const r = busy[0], m = /(\d+)%/.exec(r.now.note || "");
      w.dataset.run = r.id;
      w.title = `${r.target}: ${r.now.title}${r.now.note ? " · " + r.now.note : ""} (click to see it)`;
      w.innerHTML = `<span class="spin" style="width:11px;height:11px;border-width:2px"></span>${esc((r.target || "").replace(/^(Run|Code it): /, ""))}${m ? ` · <b>${m[1]}%</b>` : ""}${busy.length > 1 ? ` <span class="muted">+${busy.length - 1}</span>` : ""}`;
    }
  }
}
if ($("working")) $("working").onclick = () => { const id = $("working").dataset.run; if (id) nav(`#/run/${id}`); };
$("needs").onclick = () => {
  const r = S.state && S.state.open_reviews[0]; if (!r) return;
  const run = (S.state.runs || []).find(x => x.id === r.run);
  if (r.kind === "flow" && run) { setProject(run.project); nav(`#/p/${run.project}`); } else nav(`#/run/${r.run}`);
};
$("avatar").onclick = () => openSettings(true);
$("open-settings").onclick = () => openSettings(false);
$("scrim").onclick = closeModal;
document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });
function openModal(html) { $("modal-body").innerHTML = html; $("modal").classList.add("on"); $("scrim").classList.add("on"); }
function closeModal() { $("modal").classList.remove("on"); $("scrim").classList.remove("on"); $("modal-body").innerHTML = ""; }

// (owner, 2026-11-11) the model connection is set here, for every part: the URL, the model name and the API key (kept in a private file
// on this computer, loaded by run_app.py at start, never shown back: only its last 4 characters and where it came from)
function connSection(m, a) {
  // (owner, 2026-11-13: "Api calls are strictly not allowed") with API calls off there is no URL, model name or key to set
  if (a && a.api_calls === false) return `<h3 style="margin:18px 0 2px">How the model is reached</h3>
    <p class="small muted" style="margin:4px 0 0">API calls are switched off in this application: it calls no model address, and there is no URL and no API key to set. Every model call of every part (the agents, stage 2, the error pages, the chats) goes through the opencode program in a terminal, with the model you choose below. The switch is <code>server.api_calls</code> in the configuration file; nothing on this page changes it.</p>`;
  if (!m) return `<p class="small err">The model connection could not be read; reload the page.</p>`;
  const lock = m.locked ? `<p class="small err">Locked (server.lock_endpoint is on): the URL and the key are changed in the configuration file and the key file, then the application is started again.</p>` : "";
  return `<h3 style="margin:18px 0 2px">Model connection <span class="hint">· used by every part: the agents, stage 1 and 2, the error pages</span></h3>
    <label class="f" for="set-url">URL <span class="hint">· empty = Anthropic (https://api.anthropic.com); otherwise your company's gateway address</span></label>
    <input type="text" id="set-url" value="${esc(m.base_url || "")}" placeholder="empty = https://api.anthropic.com" ${m.locked ? "disabled" : ""}>
    <p class="small muted" style="margin:4px 0 0">With an address of your own, every call goes there: the agents then run through this connection (not Claude Code, which has its own Anthropic login). Give the base address only; /v1/messages is added by the application.</p>
    <label class="f" for="set-llm-model">Model name <span class="hint">· for example claude-haiku-5-5</span></label>
    <input type="text" id="set-llm-model" value="${esc(m.model || "")}">
    <label class="f" for="set-key">API key <span class="hint">· never shown; type a key only to replace the one in use</span></label>
    <input type="password" id="set-key" autocomplete="new-password" ${m.locked ? "disabled" : ""}
      placeholder="${esc(m.key_present ? `a key is in use${m.key_end ? " (ending …" + m.key_end + ")" : ""}: ${m.key_source}` : "no key yet: paste your API key")}">
    <p class="small muted">The key is kept in <code>${esc(m.env_file || "")}</code> on this computer (only you can read it), never in the configuration file; the application loads it every time it starts.</p>${lock}
    <div class="row" style="margin:6px 0 0;align-items:center"><button type="button" class="btn small" id="set-test">Save and test the connection</button><span class="small" id="set-test-msg"></span></div>`;
}
async function saveConn(m) {
  if (!m || !$("set-llm-model")) return null;
  const body = {}, url = ($("set-url") || {}).value, model = $("set-llm-model").value.trim(), key = (($("set-key") || {}).value || "").trim();
  if (url !== undefined && !m.locked && url.trim() !== (m.base_url || "")) body.base_url = url.trim();
  if (model && model !== (m.model || "")) body.model = model;
  if (key && !m.locked) body.key = key;
  if (!Object.keys(body).length) return m;
  const r = await api("PUT", "/api/hier/model", body);
  if ($("set-key")) { $("set-key").value = ""; $("set-key").placeholder = r.key_present ? `a key is in use${r.key_end ? " (ending …" + r.key_end + ")" : ""}: ${r.key_source}` : "no key yet: paste your API key"; }
  Object.assign(m, r);
  return r;
}
// (owner, 2026-11-11: "look at the number of cores and do the calls simultaneously") how many model calls run at the same time:
// empty = worked out from this computer; the line under it says the number in use now and where it comes from
function callsField(a) {
  const c = a.calls || {}, where = c.path === "claude-code" ? "Claude Code" : c.path === "opencode" ? "opencode in a terminal" : c.path === "standin" ? "the stand-in (no model)" : "the Model connection";
  return `<label class="f">Model calls at the same time <span class="hint">· empty = automatic · or a number from 1 to ${esc(c.most || 64)}</span></label>
      <input type="text" id="set-calls" value="${a.calls_at_once ? esc(a.calls_at_once) : ""}" placeholder="automatic: ${esc(c.auto || "")}">
      <p class="small muted">In use now: up to ${esc(c.now || "")} calls at the same time, over ${where}. Automatic on this computer is ${esc(c.auto || "")} (${esc(c.why || "")}; it has ${esc(c.cores || "?")} processor cores).
      ${c.started_per_second_at_most ? `However many may run together, at most ${esc(c.started_per_second_at_most)} calls are started in any one second (the figure the owner gave for the model service on 12 November 2026). ` : ""}${c.refused ? `The model service answered "too many calls" ${esc(c.refused)} time${c.refused === 1 ? "" : "s"} since the application started: the number was halved each time and climbs back by itself. ` : ""}A long step (the Data Grounder, the Data Explorer) is cut into this many parts and asks them together. A higher number is faster only up to what the model service allows: when it answers "too many calls", the application halves the number by itself.</p>
      <label class="f">Family 4 · Coding research: rounds of code and test at most <span class="hint">· a whole number from 1 to 20 · 10 unless you set another</span></label>
      <input type="text" id="set-rounds" value="${esc(a.coding_rounds || 10)}">
      <p class="small muted">The Coder writes the code and the Tester tests it on small data sets, round after round. The rounds end earlier when a round is clean. You can also set the number for one item on its requirements card.</p>`;
}
// (owner, 2026-11-13: "redirect from api calling to terminal with holding sessions ... at settings there shall be model options to be
// given, so that i can chose the model i want") the opencode program in a terminal: the list is the program's own, read on this
// computer; nothing is chosen for the admin
const ocWhose = p => p === "opencode" ? "opencode's own service (no key of yours)" : `${p} (through the login stored in opencode on this computer)`;
const ocCost = m => m.free ? "free" : m.cost_known ? `paid: ${m.cost_in} and ${m.cost_out} US dollars per million tokens read and written` : "cost not listed";
const ocNum = n => n == null ? "not listed" : Number(n).toLocaleString("en-US");
function ocOptions(o) {
  const groups = {};
  (o.models || []).forEach(m => { (groups[m.provider] = groups[m.provider] || []).push(m); });
  const gone = o.model && !o.model_offered ? `<option value="${esc(o.model)}" selected>${esc(o.model)} (saved, but opencode does not offer it now)</option>` : "";
  return `<option value="">choose a model…</option>${gone}` + Object.keys(groups).map(p => `<optgroup label="${esc(ocWhose(p))}">${groups[p].map(m =>
    `<option value="${esc(m.id)}" ${m.id === o.model ? "selected" : ""}>${esc(m.name)} · ${esc(m.free ? "free" : m.cost_known ? "paid" : "cost not listed")} · reads up to ${esc(ocNum(m.context))} tokens</option>`).join("")}</optgroup>`).join("");
}
function ocFacts(o, id) {
  const m = (o.models || []).find(x => x.id === id);
  if (!m) return id ? "opencode does not offer this model now: choose another." : "No model is chosen yet.";
  return `${m.name} (${m.id}): ${ocCost(m)}; it reads up to ${ocNum(m.context)} tokens in one conversation and writes up to ${ocNum(m.output)} (a token is the model's unit of text, about 2 to 4 characters); ` +
    (m.variants && m.variants.length ? `effort levels it has: ${m.variants.join(", ")} (a step that asks to think harder gets the nearest one)` : "it has no effort levels") +
    (m.free ? ". A free model has a use limit set by opencode's service: when it is reached, the step says so in the service's own words." : ".");
}
const ocUse = rt => rt === "opencode" ? "· every agent and every page asks the model through it" : "· used by the terminal agent, which every page can ask (the button Terminal agent); the agent families themselves run on what is chosen above";
function ocSection(a) {
  const o = a.opencode || {}, s = o.sessions || {};
  return `<div id="set-oc" style="margin-top:10px;padding:12px 14px;border:1px solid var(--line);border-radius:10px">
    <p class="small" style="margin:0 0 6px"><b>opencode in a terminal</b> <span class="muted" id="set-oc-use">${esc(ocUse(a.runtime))}</span></p>
    <p class="small ${o.found ? "muted" : "err"}" style="margin:0 0 6px">${o.found ? `The opencode program: <code>${esc(o.found)}</code>${o.version ? ", version " + esc(o.version) : ""}.` : esc(o.problem || "The opencode program was not found on this computer.")}</p>
    <label class="f" for="set-oc-model" style="margin-top:4px">Model <span class="hint">· the list is opencode's own, read on this computer just now</span></label>
    <div class="row" style="gap:8px;align-items:center"><select id="set-oc-model" style="flex:1;min-width:0">${ocOptions(o)}</select><button type="button" class="btn small" id="set-oc-refresh">Read the list again</button></div>
    <p class="small ${o.found && o.problem ? "err" : "muted"}" id="set-oc-facts" style="margin:6px 0 0">${esc(o.found && o.problem ? o.problem : ocFacts(o, o.model))}</p>
    <p class="small muted" style="margin:6px 0 0">Every agent holds a session of its own in opencode, under a name such as “run 12 · coder”: its next question continues the same conversation. The application keeps each session's name, opencode's number for it and every question and answer, so a restart continues where it stopped. No call goes to the Model connection above while opencode is chosen; the other pages (stage 2, the error pages, the chats) go through opencode too, each question in a named session of its own.</p>
  </div>
  <details class="more" id="set-oc-sessions"><summary>${IC.chev}Conversations kept: ${esc(ocNum(s.sessions || 0))} (${esc(ocNum(s.open || 0))} open), ${esc(ocNum(s.turns || 0))} question${s.turns === 1 ? "" : "s"} asked in them</summary>
    <p class="small muted" style="margin:8px 0 0">Every agent's conversation with the model is kept on this computer: over the Model connection, and in opencode's terminal sessions. An agent that is asked again gets its earlier questions and answers back, also after the application was started again. A conversation that fills ${esc(Math.round(((a.compact_at || 0.95)) * 100))} % of what the model can read is summarised by the model and goes on from the summary.</p>
    <div id="set-oc-list" class="small muted" style="margin-top:8px">…</div></details>`;
}
async function ocShowSessions() {
  const box = $("set-oc-list"); if (!box) return;
  try {
    const r = await api("GET", "/api/agents/sessions");
    if (!r.sessions.length) { box.textContent = "No conversation yet: the first question an agent asks starts one."; return; }
    box.innerHTML = `<p style="margin:0 0 6px">The ${r.sessions.length} used last, newest first.</p><div class="tbl"><table><thead><tr><th>Session</th><th>Questions asked</th><th>State</th><th></th></tr></thead><tbody>${r.sessions.map(x =>
      `<tr><td><b>${esc(x.name)}</b><div class="muted">${x.program === "api" ? "over the Model connection" : "in an opencode terminal session"} · model: ${esc(x.model)}</div>${x.program === "api" ? "" : `<div class="muted" style="word-break:break-all">opencode's number: ${esc(x.terminal_id || "none yet")}</div>`}</td><td>${esc(x.turns)}</td><td>${x.state === "open" ? "open: its next question continues it" : "closed" + (x.why_closed ? ": " + esc(x.why_closed) : "")}<div class="muted">last used ${esc(x.updated)}</div></td><td><button type="button" class="btn small" data-oc-conv="${esc(x.id)}">Conversation</button></td></tr><tr hidden data-oc-row="${esc(x.id)}"><td colspan="4"></td></tr>`).join("")}</tbody></table></div>`;
    box.querySelectorAll("[data-oc-conv]").forEach(b => b.onclick = async () => {
      const row = box.querySelector(`[data-oc-row="${b.dataset.ocConv}"]`), cell = row.firstElementChild;
      if (!row.hidden) { row.hidden = true; return; }
      row.hidden = false; cell.textContent = "reading…";
      try {
        const one = await api("GET", "/api/agents/sessions/" + b.dataset.ocConv);
        cell.innerHTML = one.conversation.length ? one.conversation.map(t => `<div style="margin:6px 0"><b>Question ${esc(t.n)}</b> <span class="muted">· ${esc(t.at)}${t.seconds != null ? " · " + esc(t.seconds) + " s" : ""}${t.ok ? "" : " · not answered: " + esc(t.problem || "")}</span>
          <pre style="white-space:pre-wrap;max-height:180px;overflow:auto;margin:4px 0">${esc(t.asked)}${t.asked_cut ? "\n[… the question is " + esc(ocNum(t.asked_chars)) + " characters long; the first 6,000 are shown]" : ""}</pre>
          ${t.ok ? `<b>Answer</b><pre style="white-space:pre-wrap;max-height:180px;overflow:auto;margin:4px 0">${esc(t.answered)}${t.answered_cut ? "\n[… cut at 6,000 characters]" : ""}</pre>` : ""}</div>`).join("") : "No question was asked in this session.";
      } catch (e) { cell.textContent = e.message; }
    });
  } catch (e) { box.textContent = e.message; }
}
async function openSettings(nameOnly) {
  const a = await api("GET", "/api/agents/settings");
  let conn = null;
  if (!nameOnly) { try { conn = await api("GET", "/api/hier/model"); } catch (e) { conn = null; } }
  const strict = a.api_calls === false;
  const rt = [["opencode", "opencode in a terminal", strict ? "the opencode program on this computer, with the model you choose below" : "the opencode program on this computer, with the model you choose below; no call goes to the Model connection"], ["claude-code", "Claude Code", "headless, with its own settings (~/.claude/settings.json)"], ["http", "Model connection", "this application's own model connection"], ["standin", "Stand-in", "no model; for tests"]]
    .filter(x => !strict || x[0] === "opencode" || x[0] === "standin");
  const rtHint = k => (rt.find(x => x[0] === k) || rt[1])[2] + (k === "opencode" ? ". When opencode does not answer, the stand-in answers and the step says so; every step says who answered, in which session." : ". When it fails, the next one answers; every step says who answered. Stage 1 and stage 2 use the model connection.");
  openModal(`<div class="mhead"><h2>${nameOnly ? "Your name" : "Settings"}</h2><button class="btn quiet small" data-act="close">Close</button></div>
    <label class="f">Your name <span class="hint">· every decision is stored with it, and every review is addressed to it</span></label>
    <input type="text" id="set-name" value="${esc(S.admin)}" placeholder="your name">
    ${nameOnly ? "" : connSection(conn, a)}
    ${nameOnly ? "" : `<label class="f" style="margin-top:16px">The agents run on</label><div class="seg" id="set-rt">${rt.map(([k, l]) => `<button type="button" data-rt="${k}" class="${a.runtime === k ? "on" : ""}">${l}</button>`).join("")}</div>
    <p class="small muted" id="set-rt-hint">${esc(rtHint(a.runtime))}</p>
    ${ocSection(a)}
    ${strict ? `<div class="row" style="margin:8px 0 0;align-items:center"><button type="button" class="btn small" id="set-test">Save and test</button><span class="small" id="set-test-msg"></span></div>` : ""}
    <label class="chk" style="display:flex;gap:10px;align-items:flex-start;margin-top:16px;font-weight:600"><input type="checkbox" id="set-sound" ${S.sound ? "checked" : ""} style="margin-top:3px"> <span>Play a sound when a decision waits for you<div class="why" style="font-weight:400;margin-top:2px">A deep three-note chime as soon as a review opens, and the count in the tab's title. Browsers allow sound only after you have clicked the page once.</div></span></label>
    <div class="row" style="margin:4px 0 0 28px"><button type="button" class="btn small" id="set-test-sound">Test the sound</button><button type="button" class="btn small" id="set-notify">${S.notify && "Notification" in window && Notification.permission === "granted" ? "Desktop notifications: on" : "Also show a desktop notification"}</button><span class="small muted" id="set-sound-msg"></span></div>
    <label class="chk" style="display:flex;gap:10px;align-items:flex-start;margin-top:16px;font-weight:600"><input type="checkbox" id="set-web" ${a.web === false ? "" : "checked"} style="margin-top:3px"> <span>The agents may also search the web<div class="why" style="font-weight:400;margin-top:2px">After the reference documents, the agents look on the web (specifications, the LeCroy site) for what the documents do not say. Every page they quote is fetched by this application, and the quote must be on it; otherwise the claim is shown as not verified.</div></span></label>
    <details class="more"><summary>${IC.chev}More settings</summary>
      ${strict ? "" : `<label class="f">A different model for the agents <span class="hint">· empty = the model name above (recommended)</span></label><input type="text" id="set-model" value="${esc(a.model || "")}">`}
      <label class="f">Random windows the Code tester rebuilds <span class="hint">· 5 to 10</span></label><input type="text" id="set-sl" value="${esc(a.slices)}">
      ${callsField(a)}
      <p class="small muted">${strict ? "" : `Claude Code found at: ${esc(a.claude_found || "not found")}. `}opencode found at: ${esc((a.opencode || {}).found || "not found")}.</p></details>`}
    <div class="actions"><span class="msg" id="set-msg"></span><button class="btn quiet" data-act="close">Cancel</button><button class="btn primary" id="set-save">Save</button></div>`);
  let runtime = a.runtime;
  if ($("set-test-sound")) $("set-test-sound").onclick = () => { unlockSound(); setTimeout(() => { $("set-sound-msg").textContent = chime() ? "played: if you heard nothing, check the computer's sound output and volume" : "sound is not available in this browser"; }, 60); };
  if ($("set-notify")) $("set-notify").onclick = async () => {
    if (!("Notification" in window)) { $("set-sound-msg").textContent = "this browser has no desktop notifications"; return; }
    const p = Notification.permission === "granted" ? "granted" : await Notification.requestPermission();
    S.notify = p === "granted"; try { localStorage.setItem("agents.notify", S.notify ? "on" : "off"); } catch (e) { /* private window */ }
    $("set-notify").textContent = S.notify ? "Desktop notifications: on" : "Also show a desktop notification";
    $("set-sound-msg").textContent = S.notify ? "a notification will also appear when a decision waits" : "the browser did not allow notifications";
  };
  document.querySelectorAll("#set-rt button").forEach(b => b.onclick = () => { runtime = b.dataset.rt; document.querySelectorAll("#set-rt button").forEach(x => x.classList.toggle("on", x === b)); $("set-rt-hint").textContent = rtHint(runtime); if ($("set-oc-use")) $("set-oc-use").textContent = ocUse(runtime); });
  if ($("set-oc-model")) {
    $("set-oc-model").onchange = () => { $("set-oc-facts").className = "small muted"; $("set-oc-facts").textContent = ocFacts(a.opencode || {}, $("set-oc-model").value); };
    $("set-oc-refresh").onclick = async () => {
      const keep = $("set-oc-model").value; $("set-oc-facts").textContent = "asking opencode for its models…";
      try {
        a.opencode = await api("GET", "/api/agents/opencode/models?refresh=1");
        $("set-oc-model").innerHTML = ocOptions(Object.assign({}, a.opencode, { model: keep, model_offered: (a.opencode.models || []).some(m => m.id === keep) }));
        $("set-oc-facts").className = "small " + (a.opencode.problem ? "err" : "muted");
        $("set-oc-facts").textContent = a.opencode.problem || `${(a.opencode.models || []).length} models read from opencode just now. ` + ocFacts(a.opencode, keep);
      } catch (e) { $("set-oc-facts").className = "small err"; $("set-oc-facts").textContent = e.message; }
    };
    $("set-oc-sessions").addEventListener("toggle", () => { if ($("set-oc-sessions").open) ocShowSessions(); });
  }
  const ocChoice = () => $("set-oc-model") && ($("set-oc-model").value || runtime === "opencode") ? { opencode_model: $("set-oc-model").value } : {};
  document.querySelectorAll('#modal [data-act="close"]').forEach(b => b.onclick = closeModal);
  if ($("set-test")) $("set-test").onclick = async () => {
    const msg = $("set-test-msg"); msg.innerHTML = "saving and asking the model…";
    try {
      await saveConn(conn);
      if (runtime === "opencode" || a.runtime === "opencode") { await api("PUT", "/api/agents/settings", Object.assign({ runtime }, ocChoice())); a.runtime = runtime; }
      msg.innerHTML = runtime === "opencode" ? "saved; asking the model through opencode, once for the agents and once for the other pages (about 20 seconds each)…" : "saved; asking the model connection and the agents (when the address does not answer, this can take up to 2 minutes)…";
      const t = await api("POST", "/api/hier/model/test", {}), g = t.agents || {};
      const hint = x => x.hint ? `<div class="small"><b>What it means:</b> ${esc(x.hint)}</div>` : "";
      msg.innerHTML = `<div class="small muted">${runtime === "opencode" ? "asked through" : "called"}: <code>${esc(t.address || "")}</code></div>
        <div>${t.ok ? `<span class="ok-t">✔ ${runtime === "opencode" ? "The other pages (stage 2, the error pages), through opencode" : "Model connection (stage 1 and 2, the error pages)"}: it answered, ${esc(t.producer)}, in ${esc(t.seconds)} s</span>`
          : `<span class="err">✘ ${runtime === "opencode" ? "The other pages (stage 2, the error pages)" : "Model connection"}: no answer: ${esc(t.error || "unknown")}</span>${hint(t)}`}</div>
        <div>${g.ok ? `<span class="ok-t">✔ The agents (${esc(g.runtime || "")}): ${esc(g.words || "")}${g.seconds != null ? ", in " + esc(g.seconds) + " s" : ""}</span>`
          : `<span class="err">✘ The agents${g.runtime ? " (" + esc(g.runtime) + ")" : ""}: ${esc(g.words || "not tested")}</span>${hint(g)}`}</div>`;
    } catch (e) { msg.innerHTML = `<span class="err">${esc(e.message)}</span>`; }
  };
  $("set-save").onclick = async () => {
    setAdmin($("set-name").value);
    if (!nameOnly) { try { await saveConn(conn); } catch (e) { $("set-msg").innerHTML = `<span class="err">${esc(e.message)}</span>`; return; } }
    if ($("set-sound")) { S.sound = $("set-sound").checked; try { localStorage.setItem("agents.sound", S.sound ? "on" : "off"); } catch (e) { /* private window */ } }
    if (!nameOnly) {
      try { await api("PUT", "/api/agents/settings", Object.assign({ runtime, web: $("set-web").checked, slices: Math.max(5, Math.min(10, Number($("set-sl").value) || 6)),
        calls_at_once: $("set-calls") ? Math.max(0, Math.min(64, Math.floor(Number($("set-calls").value) || 0))) : 0,
        coding_rounds: $("set-rounds") ? Math.max(1, Math.min(20, Math.floor(Number($("set-rounds").value) || 10))) : 10 }, $("set-model") ? { model: $("set-model").value.trim() } : {}, ocChoice())); }
      catch (e) { $("set-msg").innerHTML = `<span class="err">${esc(e.message)}</span>`; return; }
    }
    closeModal(); toast("Saved"); render();
  };
}

// (owner, 2026-11-11: "Stop means stop") one press stops the run, no dialog; deleting is permanent, so it is asked once, briefly
async function stopRun(rid, b) {
  if (b) b.disabled = true;
  try { await api("POST", `/api/agents/runs/${rid}/stop`, { admin: S.admin }); toast("Stopped"); render(true); }
  catch (e) { if (b) b.disabled = false; toast(e.message); }
}
function confirmDelete(pid, name) {
  openModal(`<div class="mhead"><h2>Delete “${esc(name)}”?</h2></div>
    <p>Its runs and decisions go from the list.</p>
    <div class="actions"><span class="msg" id="del-msg"></span><button class="btn quiet" data-act="close">Cancel</button><button class="btn danger" id="del-go">Delete</button></div>`);
  document.querySelectorAll('#modal [data-act="close"]').forEach(x => x.onclick = closeModal);
  $("del-go").onclick = async () => {
    try { await api("DELETE", `/api/agents/projects/${pid}`, { admin: S.admin }); closeModal(); toast("Deleted"); await refreshState(); nav("#/"); render(true); }
    catch (e) { $("del-msg").innerHTML = `<span class="err">${esc(e.message)}</span>`; }
  };
}

// who is starting this flow: asked every time a flow starts (its reviews are addressed to that person)
function askStarter(pid) {
  openModal(`<div class="mhead"><h2>Who is starting this flow?</h2><button class="btn quiet small" data-act="close">Close</button></div>
    <label class="f" for="st-name">Your name <span class="req">required</span></label>
    <div class="why">Every review of this flow is addressed to you ("Admin &lt;your name&gt;, need review"), and every decision is stored with your name.${S.admin ? " Filled in with the last name used on this computer: change it if someone else is starting." : ""}</div>
    <input type="text" id="st-name" value="${esc(S.admin)}" placeholder="your name" autocomplete="name">
    <div class="actions"><span class="msg" id="st-msg"></span><button class="btn quiet" data-act="close">Cancel</button><button class="btn primary" id="st-go">${IC.play}Start the flow</button></div>`);
  document.querySelectorAll('#modal [data-act="close"]').forEach(x => x.onclick = closeModal);
  const go = async () => {
    const who = $("st-name").value.trim();
    if (!who) { $("st-msg").innerHTML = `<span class="err">write your name</span>`; $("st-name").focus(); return; }
    $("st-go").disabled = true;
    try { await api("POST", `/api/agents/projects/${pid}/flow`, { admin: who }); setAdmin(who); closeModal(); toast(`The flow started, by ${who}`); S.shown = null; nav(`#/p/${pid}`); render(); }
    catch (er) { $("st-msg").innerHTML = `<span class="err">${esc(er.message)}</span>`; $("st-go").disabled = false; }
  };
  $("st-go").onclick = go;
  $("st-name").addEventListener("keydown", e => { if (e.key === "Enter") go(); });
  setTimeout(() => { $("st-name").focus(); $("st-name").select(); }, 50);
}

// ------------------------------------------------------------------ routing
function route() { return location.hash.replace(/^#\/?/, "").split("/").filter(Boolean).map(decodeURIComponent); }
window.addEventListener("hashchange", () => { S.shown = null; render(); window.scrollTo(0, 0); });
// what the page shows of a run: the states of its steps and reviews, the progress note, the conversation length
function sigOf(v) {
  if (!v) return "none";
  return v.run.state + "|" + v.steps.map(s => s.id + s.state + (s.state === "running" ? s.note : "")).join(",") + "|" + v.reviews.map(r => r.id + r.state + (r.chat || []).length).join(",");
}
// the watcher: every 2.5 s, the run on the screen is read again; the page is redrawn only when it changed
async function watch() {
  const sh = S.shown, r = route();
  if (!sh || S.watching || (r[0] !== "p" && r[0] !== "run")) return;
  if (document.activeElement && ["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement.tagName) && document.activeElement.value) return;  // never redraw under your typing
  S.watching = true;
  try {
    let v = null;
    if (sh.rid) v = await api("GET", "/api/agents/runs/" + sh.rid);
    if (r[0] === "p" && sh.pid) { const fl = (await api("GET", "/api/agents/runs?project=" + sh.pid)).filter(x => x.kind === "flow")[0]; if ((fl ? fl.id : null) !== sh.rid) { render(true); return; } }
    if (sigOf(v) !== sh.sig) { render(true); refreshState(); }
  } catch (e) { /* the next tick tries again */ } finally { S.watching = false; }
}
function stopPoll() { /* the watcher replaces start/stop polling */ }
function crumb(html) { $("crumb").innerHTML = html ? `<a class="home" href="#/" title="your analyses, and a new one">Home</a><span>/</span>${html}` : `<b>Home</b><span class="muted small">your analyses</span>`; }   // a plain way back (owner, 2026-11-10: "where is the home page?")

async function render(quiet) {
  const r = route(), m = $("main");
  S.tok = (S.tok || 0) + 1;
  try {
    if (!S.state) await refreshState();
    if (!quiet) setTimeout(() => { if (typeof sideShow === "function") sideShow(); }, 0);       // the side panel follows the page
    if (r[0] === "p" && r[1] && r[2] === "errors") return await renderErrorsPage(m, Number(r[1]), r[3], quiet);
    if (r[0] === "p" && r[1]) return await renderProject(m, Number(r[1]), r[2], quiet);
    if (r[0] === "run" && r[1]) return await renderRunPage(m, Number(r[1]), quiet);
    if (r[0] === "history") return await renderHistory(m);
    if (r[0] === "library") return await renderLibrary(m, r.slice(1));
    return await renderHome(m);
  } catch (e) { m.innerHTML = `<div class="card"><h2>Something went wrong</h2><p class="err">${esc(e.message)}</p><a class="btn" href="#/">Back to the start</a></div>`; }
}

// keep what the admin typed or ticked, and which details were open, across a redraw
function captureUi(m) {
  const k = {}; m.querySelectorAll("[data-keep]").forEach(x => k[x.dataset.keep] = x.type === "checkbox" ? x.checked : x.value);
  const open = new Set([...m.querySelectorAll("details[data-id]")].filter(d => d.open).map(d => d.dataset.id));
  return { k, open };
}
function restoreUi(m, ui) {
  m.querySelectorAll("[data-keep]").forEach(x => { if (ui.k[x.dataset.keep] !== undefined) { if (x.type === "checkbox") { x.checked = ui.k[x.dataset.keep]; const p = x.closest(".pick"); if (p) p.classList.toggle("on", x.checked); } else x.value = ui.k[x.dataset.keep]; } });
  m.querySelectorAll("details[data-id]").forEach(d => { if (ui.open.has(d.dataset.id)) { d.open = true; if (d.dataset.dtbl) dictFill(d); } });
}

// ------------------------------------------------------------------ home: start a new analysis, or open a project
async function renderHome(m) {
  crumb(""); await refreshState();
  const projects = S.state.projects, runs = S.state.runs || [], open = S.state.open_reviews || [];
  const projState = p => {
    const fr = runs.filter(r => r.project === p.id && r.kind === "flow")[0];
    if (!fr) return `<span class="pill">not started</span>`;
    if (open.some(r => r.run === fr.id)) return `<span class="pill warn"><span class="dot"></span>needs your decision</span>`;
    if (fr.state === "running") return fr.steps.some(s => s.state === "failed") ? `<span class="pill bad">a step failed</span>` : `<span class="pill run"><span class="spin" style="width:10px;height:10px;border-width:2px"></span>working</span>`;
    return fr.state === "finished" ? `<span class="pill ok">finished</span>` : `<span class="pill">${esc(STATE_WORDS[fr.state] || fr.state)}</span>`;
  };
  m.innerHTML = `<div class="hero"><div><h1>From a capture to a test case</h1>
      <p>Give the folder with the CSV files exported from one recording. Three families of agents work through it, step by step, and stop to ask you at every decision.</p>
      <div class="path"><span class="s">1 · Understand the data</span>${IC.chev}<span class="s">2 · One tree</span>${IC.chev}<span class="s">3 · Rules, defects, test cases</span>${IC.chev}<span class="s">4 · Report</span></div></div></div>
    <div class="grid2">
      <section class="card"><h2>New analysis</h2><p class="small muted" style="margin:0">Three fields. Everything else is asked when it is needed.</p>
        <label class="f" for="adm">Your name <span class="req">required</span></label>
        <div class="why">The person starting this analysis. Every review of its flow is addressed to you ("Admin &lt;your name&gt;, need review"), and every decision is stored with your name, so it is always known who started what and who approved what.${S.admin ? " It is filled in with the last name used on this computer: change it if someone else is starting." : ""}</div>
        <input type="text" id="adm" value="${esc(S.admin)}" placeholder="your name" autocomplete="name">
        <label class="f" for="np-name">Name of this analysis <span class="req">required · unique</span></label>
        <div class="why">It is how this analysis is recognised later. Start the same name on the same folder again and this analysis opens: its data dictionaries, its joining strategy and the tree already built are used again, so nothing is computed twice. One name belongs to one folder.</div>
        <input type="text" id="np-name" placeholder="for example: drive X, field return of 7 November" data-keep="np-name" autocomplete="off">
        <div id="np-name-hint" class="small" aria-live="polite"></div>
        <label class="f" for="np-folder">Folder with the exported CSV files <span class="req">required</span></label>
        <div class="why">The CSV files exported from one recording (one .pex file, up to five levels). The agents read them here and build the tree from them; they stay where they are and nothing is copied. <b>Check</b> shows which levels are there.</div>
        <div class="row" style="flex-wrap:nowrap"><input type="text" id="np-folder" placeholder="/path/to/the/folder" data-keep="np-folder"><button class="btn" id="np-check" data-act="check-folder">Check</button></div>
        <div id="np-inv"></div>
        <details class="more" data-id="np-more"><summary>${IC.chev}More options: reference documents (optional)</summary>
          <label class="f" for="np-refs">Reference documents <span class="hint">· optional; folders, one per line; leave it empty to start without any</span></label>
          <div class="why">Where the agents look first: the Grounder for what each column means, the Coder for evidence for the joining strategy (LeCroy manuals, specification extracts, notes saved earlier; the project's own research notes are added when they are next to the application). When these documents do not say it, or when you give none, the agents also search the web${S.state && S.state.settings && S.state.settings.web === false ? " (now off in Settings)" : ""}. Either way a meaning is accepted only when its quote is found: on a line of these documents, or on the web page, which the program fetches itself.</div>
          <textarea id="np-refs" data-keep="np-refs">${esc((S.state.settings.references || []).join("\n"))}</textarea>
          <label class="f" for="np-rea">Folder with the REA findings <span class="hint">· optional; the analyzer's decompiled code as text files</span></label>
          <div class="why">Kept with this analysis. Nothing in the flow needs it, waits for it or reads it: the <b>REA agent</b> below reads the findings once. Family 2 uses them only if you tick the box for it at the step where you choose stage 2. Leave it empty to start without.</div>
          <input type="text" id="np-rea" placeholder="/path/to/the/REA/findings" data-keep="np-rea" autocomplete="off">
          <p class="small muted">Not asked here: a tree built before from these same files is found and used again by itself.</p>
        </details>
        <div class="actions"><span class="msg" id="np-msg"></span><button class="btn primary big" id="np-make" data-act="make">${IC.play}Start the flow</button></div>
      </section>
      <section class="card"><h2>Your analyses</h2>
        ${projects.length ? projects.map(p => { const fr = runs.filter(r => r.project === p.id && r.kind === "flow")[0];
          return `<div class="proj"><div class="grow"><div class="nm">${esc(p.name)}</div><div class="meta">${esc(p.folder)} · ${fr && fr.started_by ? "last flow started by " + esc(fr.started_by) : "created by " + esc(p.admin)}</div></div>${projState(p)}<a class="btn small" href="#/p/${p.id}" data-open="${p.id}">Open</a><button class="btn small quiet danger" data-act="del-proj" data-pid="${p.id}" data-name="${esc(p.name)}">Delete</button></div>`; }).join("")
          : `<div class="empty">No analysis yet. Start one on the left.</div>`}
      </section>
      <section class="card" id="rea-card"><h2>REA agent <span class="hint">· optional</span></h2>
        <p class="small muted" style="margin:0 0 6px">REA (Reverse Engineer Anything) decompiles the analyzer's own program; its output is a folder of decompiled code and notes as text. This agent reads that folder once and answers your questions from it, with the file and the lines. It is not a step of the flow: nothing in a flow waits for it.</p>
        <div id="rea-box">${reaInner()}</div>
      </section></div>`;
}
// ------------------------------------------------------------------ the REA agent on the start page
// (owner, 2026-11-14: "let's keep the rea out ... kept out at the first page itself ... the rea decompiled folder shall be taken or given
// the path, and what you want to see ask questions") The folder is read once (a bar shows how far it is); questions are answered from
// passages the program found, every quote checked by code; the conversation is kept with the findings and comes back.
const REA = { folder: "", st: null, turns: [], busy: "", msg: "", timer: null, asked: false };
try { REA.folder = localStorage.getItem("agents.rea") || ""; } catch (e) { /* private window */ }
const reaDate = t => t ? new Date(t * 1000).toLocaleString() : "an earlier time";
const reaCount = (n, one, many) => `${Number(n || 0).toLocaleString("en-US")} ${n === 1 ? one : many}`;
function reaTurn(t) {
  const who = t.who === "REA agent" ? `REA agent <span class="muted" title="${esc(t.by || "")}">· ${esc(/stand-in|nobody|the program/.test(t.by || "") ? t.by : "the model's answer")}</span>`
    : t.who === "Family 2" ? "Family 2 <span class=\"muted\">· the tree builder's agent asked</span>" : `You <span class="muted">· ${esc(t.by || "admin")}</span>`;
  const src = (t.sources || []).length ? `<div class="small" style="margin-top:6px"><b>Where it stands in the findings</b><ul style="margin:4px 0 0 18px;padding:0">${t.sources.map(x =>
    `<li><code>${esc(x.file)}</code>, lines ${esc(x.lines)}: “${esc(x.quote)}”</li>`).join("")}</ul></div>` : "";
  const looked = t.who === "REA agent" && (t.searched || []).length ? `<div class="small muted" style="margin-top:4px">Words looked for in the findings: ${t.searched.map(esc).join(", ")}</div>` : "";
  return `<div style="margin:8px 0;padding:8px 10px;border:1px solid var(--line);border-radius:10px"><div class="small" style="font-weight:600">${who} <span class="muted" style="font-weight:400">· ${esc(reaDate(t.at))}</span></div>
    <div style="white-space:pre-wrap;margin-top:4px">${esc(t.text || "")}</div>${src}${looked}</div>`;
}
function reaInner() {
  const st = REA.st, job = st && st.job;
  if (REA.folder && !st && !REA.asked) { REA.asked = true; setTimeout(() => reaCheck(true), 0); }
  let state = "";
  if (st && !st.exists) state = st.folder ? `<p class="small err">${esc(st.why || "this folder does not exist on this computer")}</p>` : "";
  else if (st) {
    if (job && job.state === "running") state = progressView({ note: job.note, started: job.started }, "reading the REA findings");
    else if (job && job.state === "failed") state = `<p class="small err">The findings could not be read: ${esc(job.error || "unknown")}</p>`;
    if (!(job && job.state === "running")) {
      const skipped = Object.entries(st.skipped || {}).map(([why, n]) => `${reaCount(n, "file", "files")} ${esc(why)}`).join("; ");
      state += st.read
        ? `<p class="small" style="margin:6px 0 0"><span class="ok-t">Read on ${esc(reaDate(st.read_at))}.</span> ${reaCount(st.read_files, "file", "files")} of the ${reaCount(st.files, "file", "files")} in the folder hold text, in ${reaCount(st.passages, "passage", "passages")}${skipped ? ` (left out: ${skipped})` : ""}. They are read again only when a file of the folder changes.</p>
           <p class="small muted" style="margin:4px 0 0">${(st.join_terms_found || []).length ? `They name these join columns, which the Coder of Family 2 can quote: ${st.join_terms_found.map(esc).join(", ")}.` : "They name none of the join columns."}${(st.join_terms_not_found || []).length ? ` Not named: ${st.join_terms_not_found.map(esc).join(", ")}.` : ""}</p>`
        : `<p class="small" style="margin:6px 0 0">${reaCount(st.files, "file", "files")} in this folder. ${esc(st.why === "not read yet" ? "Not read yet." : (st.why || "Not read yet."))}</p>`;
    }
  }
  const canAsk = st && st.read && !(job && job.state === "running");
  const chat = canAsk ? `<label class="f" for="rea-q" style="margin-top:12px">Ask the REA agent <span class="hint">· it answers only from the decompiled files</span></label>
    <div class="why">Your question is answered from the decompiled files only. Every answer names the file, the lines and the words it quotes, and a quote that is not in that passage is left out.</div>
      <div class="row" style="flex-wrap:nowrap"><input type="text" id="rea-q" placeholder="for example: which field does the analyzer compare to put a packet into a link transaction?" autocomplete="off"><button class="btn primary" data-act="rea-ask" ${REA.busy === "ask" ? "disabled" : ""}>${REA.busy === "ask" ? "asking…" : "Ask"}</button></div>
      <div id="rea-chat">${REA.turns.length ? REA.turns.slice().reverse().map(reaTurn).join("") : `<p class="small muted" style="margin:8px 0 0">No question yet. The questions and answers are kept with these findings and are here again the next time.</p>`}</div>` : "";
  return `<label class="f" for="rea-folder">Folder with the decompiled findings</label>
    <div class="why">The folder on this computer that holds the analyzer's decompiled code and notes as text files. The REA agent reads every file in it once; it is read again only when a file in it changes.</div>
    <div class="row" style="flex-wrap:nowrap"><input type="text" id="rea-folder" value="${esc(REA.folder)}" placeholder="/path/to/the/REA/findings" autocomplete="off"><button class="btn" data-act="rea-check">Check</button>
      <button class="btn" data-act="rea-read" ${st && st.exists && !(job && job.state === "running") && !st.read ? "" : "disabled"}>Read the findings</button></div>
    ${REA.msg ? `<p class="small err" style="margin:6px 0 0">${esc(REA.msg)}</p>` : ""}${state}${chat}`;
}
function reaPaint() {
  const b = $("rea-box"); if (!b) return;
  const q = $("rea-q"), keepQ = q ? q.value : "", f = $("rea-folder"), keepF = f ? f.value : REA.folder, hadFocus = document.activeElement && document.activeElement.id;
  b.innerHTML = reaInner();
  if ($("rea-folder")) $("rea-folder").value = keepF;
  if ($("rea-q")) { $("rea-q").value = keepQ; $("rea-q").onkeydown = e => { if (e.key === "Enter") { e.preventDefault(); reaAsk(); } }; }
  if (hadFocus && $(hadFocus) && (hadFocus === "rea-q" || hadFocus === "rea-folder")) $(hadFocus).focus();
}
async function reaCheck(quiet) {
  const f = $("rea-folder") ? $("rea-folder").value.trim() : REA.folder;
  REA.msg = "";
  if (!f) { if (!quiet) { REA.msg = "give the folder that holds the REA findings"; reaPaint(); } return; }
  if (f !== REA.folder) { REA.turns = []; REA.st = null; }
  REA.folder = f; try { localStorage.setItem("agents.rea", f); } catch (e) { /* private window */ }
  try {
    REA.st = await api("GET", "/api/agents/rea/status?folder=" + encodeURIComponent(f));
    if (REA.st.read) REA.turns = (await api("GET", "/api/agents/rea/chat?folder=" + encodeURIComponent(f))).turns || [];
    if (REA.st.job && REA.st.job.state === "running") reaPoll();
  } catch (e) { REA.msg = e.message; }
  reaPaint();
}
function reaPoll() {
  clearTimeout(REA.timer);
  REA.timer = setTimeout(async () => {
    try { REA.st = await api("GET", "/api/agents/rea/status?folder=" + encodeURIComponent(REA.folder)); } catch (e) { REA.msg = e.message; reaPaint(); return; }
    if (REA.st.job && REA.st.job.state === "running") { reaPaint(); reaPoll(); return; }
    if (REA.st.read) { try { REA.turns = (await api("GET", "/api/agents/rea/chat?folder=" + encodeURIComponent(REA.folder))).turns || []; } catch (e) { /* shown on the next check */ } }
    reaPaint();
  }, 1000);
}
async function reaRead() {
  await reaCheck(true);
  if (!REA.st || !REA.st.exists || REA.st.read) return;
  try { REA.st = await api("POST", "/api/agents/rea/read", { folder: REA.folder, admin: S.admin }); reaPaint(); reaPoll(); }
  catch (e) { REA.msg = e.message; reaPaint(); }
}
async function reaAsk() {
  const q = $("rea-q") ? $("rea-q").value.trim() : "";
  if (!q || REA.busy) return;
  REA.busy = "ask"; REA.msg = ""; reaPaint();
  try { const r = await api("POST", "/api/agents/rea/ask", { folder: REA.folder, question: q, admin: S.admin }); REA.turns = r.turns || []; if ($("rea-q")) $("rea-q").value = ""; }
  catch (e) { REA.msg = e.message; }
  REA.busy = ""; reaPaint();
}

// as the name and the folder are typed: say whether Start opens an existing analysis or makes a new one
function nameHint() {
  const el = $("np-name-hint"); if (!el) return;
  const nm = ($("np-name").value || "").replace(/\s+/g, " ").trim().toLowerCase(), fd = ($("np-folder").value || "").trim().replace(/\/+$/, "");
  const same = (S.state ? S.state.projects : []).find(p => (p.name || "").replace(/\s+/g, " ").trim().toLowerCase() === nm);
  const ofFolder = (S.state ? S.state.projects : []).filter(p => (p.folder || "").replace(/\/+$/, "") === fd && fd);
  if (nm && same && (!fd || same.folder.replace(/\/+$/, "") === fd)) {
    el.innerHTML = `<span class="ok-t">This analysis exists (folder ${esc(same.folder)}): Start opens it, and what was approved and built for it is used again.</span>`;
    if (!fd) { $("np-folder").value = same.folder; }
  } else if (nm && same) el.innerHTML = `<span class="err">This name is already used for another folder (${esc(same.folder)}): choose another name.</span>`;
  else if (ofFolder.length) el.innerHTML = `<span class="muted">This folder was analysed before as ${ofFolder.map(p => `“${esc(p.name)}”`).join(", ")}. Give the same name to open it; a new name makes a new analysis (a tree built from these same files is still used again).</span>`;
  else el.innerHTML = nm ? `<span class="muted">A new analysis.</span>` : "";
}

async function checkFolder() {
  const f = $("np-folder").value.trim(); if (!f) return;
  $("np-inv").innerHTML = `<p class="small muted">looking…</p>`;
  try {
    const r = await api("GET", "/api/agents/inventory?folder=" + encodeURIComponent(f));
    const lv = r.files.filter(x => x.level).length;
    $("np-inv").innerHTML = `<div class="files">${r.files.map(x => `<div class="file ${x.level ? "" : "bad"}"><b>${esc(x.name)}</b><span class="muted">${esc(x.level ? x.level_label : "not an analyzer level")} · ${(x.bytes / 1e6).toFixed(1)} MB</span></div>`).join("")}</div>
      <p class="small ${lv === 5 ? "muted" : "err"}">${lv === 5 ? "All five levels are there." : lv ? lv + " of the five levels found: the flow uses what is there and never makes up a missing level." : "None of these is one of the analyzer's five exports. They can still be analysed: every file gets its data dictionary, and the rules read the files as they are. No tree can be built from them (stage 2 is a choice after stage 1)."}</p>${r.problem ? `<p class="err">${esc(r.problem)}</p>` : ""}`;
  } catch (e) { $("np-inv").innerHTML = `<p class="err">${esc(e.message)}</p>`; }
}
async function makeProject() {
  const who = ($("adm") ? $("adm").value : "").trim();
  if (!who) { $("np-msg").innerHTML = `<span class="err">write your name: the one who starts the analysis</span>`; $("adm").focus(); return; }
  setAdmin(who);
  const folder = $("np-folder").value.trim();
  if (!$("np-name").value.trim()) { $("np-msg").innerHTML = `<span class="err">give the analysis a name</span>`; $("np-name").focus(); return; }
  if (!folder) { $("np-msg").innerHTML = `<span class="err">give the folder</span>`; $("np-folder").focus(); return; }
  $("np-msg").textContent = "creating…";
  try {
    const p = await api("POST", "/api/agents/projects", { admin: S.admin, name: $("np-name").value.trim(), folder,
      refs: ($("np-refs") ? $("np-refs").value : "").split("\n").map(x => x.trim()).filter(Boolean), rea: ($("np-rea") ? $("np-rea").value : "").trim() });
    setProject(p.id);
    let started = false;
    // an analysis that exists is opened as it stands, with everything of its last flow (owner, 2026-11-12: stateful); a new flow starts only for
    // a new analysis, or one that never had a flow
    const had = p.reused ? (await api("GET", "/api/agents/runs?project=" + p.id)).some(r => r.kind === "flow") : false;
    if (!had) try { await api("POST", `/api/agents/projects/${p.id}/flow`, { admin: who }); started = true; } catch (e) { /* its flow is already running: it is opened */ }
    await refreshState();
    toast(p.reused ? `This folder was analysed before as "${p.name}": opened it${started ? " and started a new flow" : ""}` : started ? "The flow started" : "Created");
    nav(`#/p/${p.id}`);
  } catch (e) { $("np-msg").innerHTML = `<span class="err">${esc(e.message)}</span>`; }
}

// ------------------------------------------------------------------ one project: the stepper and one page per stage
function stagesOf(v) {
  const out = {};
  let reachedLast = 0;
  STAGES.forEach((st, i) => {
    const ss = v ? v.steps.filter(s => STAGE_OF_FAM[s.family || ""] === st.id) : [];
    const d = ss.filter(s => DONE.includes(s.state)).length;
    let state = "waiting";
    if (ss.some(s => s.state === "failed")) state = "fail";
    else if (ss.some(s => s.state === "needs_review")) state = "need";
    else if (ss.length && d === ss.length) state = "done";
    else if (ss.some(s => s.state === "running") || (d > 0)) state = "active";
    if (state !== "waiting") reachedLast = i;
    out[st.id] = { st, ss, d, state };
  });
  STAGES.forEach((st, i) => { out[st.id].reached = i <= reachedLast; });
  return out;
}
function autoStage(stg, v) {
  if (!v) return "data";
  const first = v.steps.find(s => !DONE.includes(s.state));
  return first ? STAGE_OF_FAM[first.family] || "data" : "report";
}
// what the stage tile says while a step runs: counts, not only a percentage (owner, 2026-11-10: "how many rows and columns are read out of this")
function tileProgress(st) {
  const n = st.note || "", pm = /(\d+(?:\.\d+)?)\s*%/.exec(n), pct = pm ? `${Math.floor(+pm[1])}% · ` : "";
  let m = /([\d,]+) of about ([\d,]+) lines/.exec(n);
  if (m) { const c = /\(([\d,]+) columns\)/.exec(n); return `${pct}${m[1]} of ~${m[2]} lines${c ? ` · ${c[1]} columns` : ""}`; }
  if ((m = /all ([\d,]+) lines read/.exec(n))) { const c = /columns (\d+) to (\d+) of the (\d+)/.exec(n); return `${pct}all ${m[1]} lines read${c ? ` · columns ${c[1]}–${c[2]} of ${c[3]}` : ""}`; }
  if ((m = /columns (\d+) to (\d+) of (\d+)/.exec(n))) { const f = /(\S+\.csv)/i.exec(st.title || ""); return `columns ${m[1]}–${m[2]} of ${m[3]}${f ? " · " + f[1] : ""}`; }
  return pm ? `${pct}${st.agent || "working"}` : "working…";
}
function stepper(pid, stg, cur) {
  return `<nav class="stepper" aria-label="the flow's stages">` + STAGES.map(st => {
    const x = stg[st.id];
    const run = x.ss.find(s => s.state === "running");
    // a tree the admin chose not to build is not "done": it says so (2026-11-13)
    const notBuilt = st.id === "tree" && x.ss.length && x.ss.every(s => s.state === "skipped" && (s.note || "").startsWith("not built"));
    const sub = { done: notBuilt ? "not built: your choice" : "done", need: "needs your decision", fail: "a step failed", active: run ? esc(tileProgress(run)) : `${x.d} of ${x.ss.length} steps`, waiting: "not yet" }[x.state];
    const num = x.state === "done" ? IC.check : x.state === "need" ? "!" : x.state === "fail" ? IC.x : x.state === "active" && x.ss.some(s => s.state === "running") ? `<span class="spin"></span>` : st.n;
    return `<button class="stg ${x.state} ${st.id === cur ? "cur" : ""}" data-act="stage" data-pid="${pid}" data-stage="${st.id}" ${x.reached ? "" : "disabled"} title="${esc(st.who)}"><span class="num">${num}</span><span class="txt"><div class="t">${st.n} · ${esc(st.short)}</div><div class="s">${esc(sub)}</div></span></button>`;
  }).join("") + `</nav>`;
}

async function renderProject(m, pid, wanted, quiet) {
  setProject(pid);
  const tok = S.tok;
  const ui = quiet ? captureUi(m) : null, y = window.scrollY;
  await refreshState();
  const p = S.state.projects.find(x => x.id === pid);
  if (!p) { m.innerHTML = `<div class="card"><h2>No such analysis</h2><a class="btn" href="#/">Back to the start</a></div>`; return; }
  crumb(`<b>${esc(p.name)}</b>`);
  const flows = (await api("GET", "/api/agents/runs?project=" + pid)).filter(r => r.kind === "flow");
  const run = flows[0];
  const v = run ? await api("GET", "/api/agents/runs/" + run.id) : null;
  if (v) await loadErrStatus(v);
  const stg = stagesOf(v);
  const cur = wanted && stg[wanted] && stg[wanted].reached ? wanted : autoStage(stg, v);
  const st = STAGES.find(x => x.id === cur);
  const state = v ? v.run.state : null;
  const hasFail = v && v.steps.some(s => s.state === "failed");
  const by = run && run.started_by ? ` · this flow started by <b>${esc(run.started_by)}</b> on ${when(run.created)}` : "";
  let h = `<div class="phead"><div><h1>${esc(p.name)}</h1><div class="meta">${esc(p.folder)}${p.upload_id ? ` · <a href="${treeHref(p.upload_id)}" target="_blank" title="the five files of this recording joined into one tree: commands, their steps, and the PCIe traffic under them">open the recording's tree</a>` : ""}${by}</div></div>
    <div class="row">${v ? `<span class="pill ${state === "finished" ? "ok" : state === "running" ? (hasFail ? "bad" : "run") : ""}">${state === "running" ? (hasFail ? "a step failed" : "flow running") : "flow " + esc(STATE_WORDS[state] || state)}</span>` : ""}
      ${state === "running" ? `<button class="btn small quiet danger" data-act="stop" data-rid="${v.run.id}">Stop</button>` : ""}
      ${v && state !== "running" ? `<button class="btn small" data-act="start-flow" data-pid="${pid}" title="a new flow from the first step; dictionaries, the strategy and the tree approved or built before are offered again">${IC.play}Run the flow again</button>` : ""}</div></div>`;
  if (v && state !== "running") h += reopenBar(v);
  h += stepper(pid, stg, cur);
  if (!v) h += startPanel(pid);
  else h += stagePage(st, stg[cur], v, p);
  if (tok !== S.tok) return;            // a newer draw started meanwhile: it writes the page, not this one
  m.innerHTML = h;
  if (ui) restoreUi(m, ui);
  if (quiet) window.scrollTo(0, y);
  S.shown = { pid, rid: v ? v.run.id : null, sig: sigOf(v) };
}

/* ---- the errors page (owner, 2026-11-11): every errors pattern of this flow is a section with all the errors it found; each error opens its
   own page (/isolate) where stage 1 (the isolation of the defect), stage 2 (the procedural graph: cause, solution) and its test are done; then
   back here. Page 3 shows only where each error stands. Before its isolation it is an error; it is called a defect only after stage 1. */
const ERR_WORDS = { new: "not isolated yet", isolated: "stage 1 done", cause: "stage 1 done; cause named", solved: "stage 1 and stage 2 done", tested: "stage 1 and stage 2 done; test approved" };
function errorLists(v) {
  if (!v) return [];
  const own = v.steps.filter(s => s.key.endsWith(":errors") && s.output && (s.output.errors || []).length);
  // a flow made before 2026-11-11 has no list of its own: the errors come from its errors patterns' results
  const have = new Set(own.map(s => s.key.slice(3, -":errors".length)));
  const older = v.steps.filter(s => s.key.startsWith("f3:errors/") && s.key.endsWith(":run") && s.output && (s.output.head || []).length && !have.has(s.key.slice(3, -":run".length)))
    .map(s => { const p = plainDefects(s.output.columns, s.output.head) || [];
      return { key: s.key.slice(0, -":run".length) + ":errors", title: s.title, output: { upload_id: s.output.upload_id, total: s.output.rows, pattern: s.title.split(" · ")[0],
        errors: p.map(x => ({ finding: x.no, what: x.what, where: x.where, when: x.when, serious: x.sev, level: x.level, row: x.row })) } }; });
  return own.concat(older);
}
async function loadErrStatus(v) {
  S.errStatus = S.errStatus || {};
  for (const st of errorLists(v)) {
    const o = st.output;
    try { const r = await api("GET", `/api/dg/status?upload=${encodeURIComponent(o.upload_id)}&findings=${o.errors.map(e => e.finding).join(",")}`); S.errStatus[o.upload_id] = Object.assign(S.errStatus[o.upload_id] || {}, r.status || {}); }
    catch (e) { /* the page shows "not isolated yet" */ }
  }
}
const errStat = (up, fid) => ((S.errStatus || {})[up] || {})[fid] || { state: "new", words: "not isolated yet" };
const errHref = (pid, up, fid) => `/isolate?upload=${encodeURIComponent(up)}&finding=${fid}&back=${encodeURIComponent(`/#/p/${pid}/errors`)}`;
function errCounts(st) {
  const o = st.output, xs = o.errors.map(e => errStat(o.upload_id, e.finding).state);
  return { n: o.total || xs.length, s1: xs.filter(x => x !== "new").length, s2: xs.filter(x => x === "solved" || x === "tested").length, t: xs.filter(x => x === "tested").length };
}
function errorsStatus(item, v) {
  const st = errorLists(v).find(s => s.key === `f3:${item}:errors`);
  if (!st || !st.output || !(st.output.errors || []).length) return "";
  const c = errCounts(st), pid = v.run.project;
  return `<div class="winbox" style="margin:8px 0 4px;padding:10px 12px;border:1px solid var(--line);border-radius:10px"><div class="row" style="justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap">
    <div><b>${nf(c.n)} error${c.n === 1 ? "" : "s"} found</b> · stage 1 done: ${c.s1} · stage 2 done: ${c.s2} · test files approved: ${c.t}</div>
    <a class="btn small primary" href="#/p/${pid}/errors/${encodeURIComponent(item)}">Open the errors page ${IC.chev}</a></div></div>`;
}
function errorsOverview(v) {
  const ls = errorLists(v); if (!ls.length) return `<p class="small muted">No pattern found an error.</p>`;
  return ls.map(st => { const c = errCounts(st); return `<div class="small"><b>${esc(st.output.pattern || st.title.split(" · ")[0])}</b>: ${nf(c.n)} error${c.n === 1 ? "" : "s"} · stage 1 done: ${c.s1} · stage 2 done: ${c.s2} · test files approved: ${c.t}</div>`; }).join("")
    + `<div class="row" style="margin:10px 0"><a class="btn primary" href="#/p/${v.run.project}/errors">Open the errors page ${IC.chev}</a>`
    + `<a class="btn" href="/static/nvme_command_errors.html" target="_blank" title="Every result an NVMe command can end with, from the NVMe specifications, and how many commands of a recording ended with each">Every NVMe command error that is possible</a>`
    + `<a class="btn" href="/static/nvme_command_rules.html" target="_blank" title="Only the rules that find an error at the NVMe command level: what each rests on in the NVMe specification, the columns of the NVMe command file it reads, the errors found in a recording, and from each error the way to its isolation">The rules for errors at the NVMe command level</a></div>`;
}
async function loadFlow(pid) {
  await refreshState();
  const p = S.state.projects.find(x => x.id === pid);
  const run = p ? (await api("GET", "/api/agents/runs?project=" + pid)).filter(r => r.kind === "flow")[0] : null;
  return { p, v: run ? await api("GET", "/api/agents/runs/" + run.id) : null };
}
async function renderErrorsPage(m, pid, item, quiet) {
  setProject(pid);
  const tok = S.tok, ui = quiet ? captureUi(m) : null, y = window.scrollY;
  const { p, v } = await loadFlow(pid);
  if (!p) { m.innerHTML = `<div class="card"><h2>No such analysis</h2><a class="btn" href="#/">Back to the start</a></div>`; return; }
  await loadErrStatus(v);
  crumb(`<a href="#/p/${pid}/rules">${esc(p.name)}</a><span>/</span><b>errors</b>`);
  const ls = errorLists(v), gate = v ? v.reviews.find(r => r.state === "open" && (r.data || {}).errors_overview) : null;
  let h = `<div class="phead"><div><h1>The errors</h1><div class="meta">${esc(p.name)} · ${ls.length} pattern${ls.length === 1 ? "" : "s"} found errors in this recording</div></div>
    <div class="row"><a class="btn" href="#/p/${pid}/rules">${IC.left}Back to page 3</a></div></div>
    <p class="muted" style="max-width:85ch">Each error is taken through the stages on <b>its own page</b>: <b>stage 1</b>, the isolation of the defect; <b>stage 2</b>, the procedural graph (is this defect stored? its cause; the solution); then <b>its test case</b>. It is called a defect only after its isolation. Open one, finish it, and come back here for the next.</p>`;
  if (!ls.length) h += `<div class="card"><h2>No errors yet</h2><p class="muted">The errors of a pattern are listed here when its result is accepted on page 3.</p></div>`;
  for (const st of ls) {
    const o = st.output, c = errCounts(st), it = st.key.slice(3, -":errors".length);
    h += `<section class="card" id="sec-${esc(it)}"><div class="row" style="justify-content:space-between;align-items:baseline;flex-wrap:wrap;gap:8px"><h2 style="margin:0">${esc(o.pattern || st.title.split(" · ")[0])}</h2>
      <span class="small muted">${nf(c.n)} error${c.n === 1 ? "" : "s"}${o.total > o.errors.length ? ` (the first ${o.errors.length} are listed)` : ""} · stage 1 done: ${c.s1} · stage 2 done: ${c.s2} · tests approved: ${c.t}</span></div>
      <div class="tbl" style="margin-top:8px"><table><tr><th>What was found</th><th>Where in the files</th><th>When</th><th>Where it stands</th><th></th></tr>
      ${o.errors.map(e => { const x = errStat(o.upload_id, e.finding);
        return `<tr><td>${esc(e.what)}</td><td>${e.level && e.row != null ? `<a href="#" data-rowcard="${esc(o.upload_id)}" data-level="${esc(e.level)}" data-row="${esc(e.row)}" data-fid="${esc(e.finding)}">${esc(e.where)}</a>` : esc(e.where)}</td>
          <td>${esc(e.when)}</td><td class="${x.state === "tested" ? "" : x.state === "new" ? "muted" : ""}">${esc(x.words || ERR_WORDS[x.state] || x.state)}</td>
          <td><a class="btn small ${x.state === "new" ? "primary" : ""}" href="${errHref(pid, o.upload_id, e.finding)}">${x.state === "new" ? "Isolate this error" : x.state === "tested" ? "Open" : "Continue"}</a></td></tr>`; }).join("")}</table></div></section>`;
  }
  if (gate) h += `<section class="card"><div class="row" style="justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><div><b>Finished with the errors?</b><div class="small muted">The report (page 4) is written next; it says where each error stands.</div></div>
      <span class="msg" id="msg${gate.id}"></span><button class="btn primary" data-act="dec" data-r="${gate.id}" data-dec="approve" data-sig="done">Done: write the report</button></div></section>`;
  if (tok !== S.tok) return;
  m.innerHTML = h;
  if (ui) restoreUi(m, ui);
  if (quiet) window.scrollTo(0, y);
  else if (item) { const sec = document.getElementById("sec-" + item); if (sec) sec.scrollIntoView(); }
  S.shown = { pid, rid: v ? v.run.id : null, sig: sigOf(v) };
}

// a flow that is finished or stopped can be opened again at any stage (owner, 2026-11-12): the decisions from there on are asked again, and
// only what is new is computed
function reopenBar(v) {
  const has = fam => v.steps.some(s => s.family === fam);
  const b = (stage, t, d, ok) => `<button class="btn act2" data-act="reopen" data-rid="${v.run.id}" data-stage="${stage}" ${ok ? "" : "disabled"}><span class="t">${t}</span><span class="d">${d}</span></button>`;
  return `<section class="card" id="reopen"><h2>Open this analysis again at a stage</h2>
    <p class="small muted">Everything of this flow is kept: the dictionaries, the tree, the results, and what you asked and were answered on every card. Opening it again asks you the decisions from that stage on. Nothing that was computed is computed again; only what is new is: a CSV file added to the folder, a changed rule, changed data.</p>
    <div class="actions" style="justify-content:flex-start;flex-wrap:wrap">
    ${b("data", "1 · The data", "ask the Managers again, read CSV files added to the folder, choose stage 2 or not", has("1"))}
    ${b("tree", "2 · The tree", "the strategy and the tree: used again when the files are the same, built when they are not", has("2"))}
    ${b("rules", "3 · The rules", "choose items again: an item whose rule, code and data are the same keeps its result", has("3"))}
    ${b("report", "4 · The report", "write the report again", v.steps.some(s => s.key === "report"))}</div><div class="msg" id="reopen-msg"></div></section>`;
}
async function reopenAt(b) {
  if (!S.admin) { openSettings(true); return; }
  const msg = $("reopen-msg");
  try {
    await api("POST", `/api/agents/runs/${b.dataset.rid}/reopen`, { stage: b.dataset.stage, admin: S.admin });
    toast("Opened again"); await refreshState();
    const rt = route(); nav(`#/p/${rt[1]}/${b.dataset.stage}`); render(true);
  } catch (e) { if (msg) msg.innerHTML = `<span class="err">${esc(e.message)}</span>`; }
}

function startPanel(pid) {
  return `<section class="card" style="text-align:center;padding:40px 24px"><h2 style="font-size:22px">Ready to start</h2>
    <p class="muted" style="max-width:60ch;margin:8px auto 20px">The agents read the files first, then build the tree, then run the rules you choose. The flow stops whenever your decision is needed, and continues on its own after a restart.</p>
    <button class="btn primary big" data-act="start-flow" data-pid="${pid}">${IC.play}Start the flow</button></section>`;
}

function stagePage(st, x, v, p) {
  const open = v.reviews.find(r => r.state === "open");
  const openStep = open ? v.steps.find(s => s.id === open.step) : null;
  const openStage = openStep ? STAGE_OF_FAM[openStep.family] : null;
  let h = `<div class="stitle"><div><div class="who">${esc(st.who)}</div><h2>${st.n} · ${esc(st.title)}</h2><p>${esc(st.text)}</p></div>
    ${st.id === "rules" ? `<a class="btn small" href="#/library">${IC.book}Rules library</a>` : ""}</div><div class="stack">`;
  if (open && openStage === st.id) h += decisionCard(open, openStep, v);
  else if (open) { const os = STAGES.find(s => s.id === openStage); h += `<div class="banner"><span>Your decision is needed on page ${os.n} · ${esc(os.short)}: ${esc(open.title)}</span><button class="btn small" data-act="stage" data-pid="${p.id}" data-stage="${os.id}">Go there ${IC.chev}</button></div>`; }
  const failed = x.ss.find(s => s.state === "failed");
  if (failed) h += `<div class="banner bad"><span>${esc(failed.title)} failed: ${esc((failed.error || "").split("\n")[0].slice(0, 300))}</span><button class="btn small" data-act="retry" data-rid="${v.run.id}">Run it again</button></div>`;
  const running = x.ss.find(s => s.state === "running");
  if (running) h += `<div class="working"><span class="spin"></span><div class="grow"><b>${esc(running.title)}</b>${progressView(running, running.agent + " is working")}${v.worker_alive && v.seconds_since_heartbeat > 30 ? `<div class="note">last activity ${Math.round(v.seconds_since_heartbeat)} s ago</div>` : ""}</div></div>`;
  if (!x.ss.length) h += `<div class="card empty">This page fills in when the flow gets here.</div>`;
  else h += ({ data: dataPage, tree: treePage, rules: rulesPage, report: reportPage })[st.id](x, v, p);
  h += `</div>`;
  const i = STAGES.indexOf(st), prev = STAGES[i - 1], next = STAGES[i + 1];
  const stg = stagesOf(v);
  h += `<div class="navfoot">${prev ? `<button class="btn" data-act="stage" data-pid="${p.id}" data-stage="${prev.id}">${IC.left}${prev.n} · ${esc(prev.short)}</button>` : "<span></span>"}
    ${next ? `<button class="btn ${stg[next.id].reached ? "primary" : ""}" data-act="stage" data-pid="${p.id}" data-stage="${next.id}" ${stg[next.id].reached ? "" : "disabled"}>${next.n} · ${esc(next.short)} ${IC.chev}</button>` : ""}</div>`;
  return h;
}

// ---- one step as a line of a timeline
const iconOf = s => ({ done: IC.check, approved: IC.check, skipped: IC.skip, needs_review: IC.alert, failed: IC.x, rejected: IC.x, running: '<span class="spin"></span>' }[s] || "");
function stepLinks(s) {
  const o = s.output || {}, out = [];
  if ((s.key === "build" || s.key === "independent") && o.upload_id) out.push(`<a class="btn small" href="${treeHref(o.upload_id)}" target="_blank">${IC.ext}Open the tree</a>`);
  if (s.key.endsWith(":isolate") && o.finding !== undefined && o.upload_id) out.push(`<a class="btn small" href="/isolate?upload=${encodeURIComponent(o.upload_id)}&finding=${o.finding}" target="_blank">${IC.ext}Open this error in the isolation tab</a>`);
  if (s.key.endsWith(":errors") && S.project && (o.errors || []).length) out.push(`<a class="btn small" href="#/p/${S.project}/errors/${encodeURIComponent(s.key.slice(3, -":errors".length))}">${IC.ext}Open the errors page</a>`);
  if (s.key.endsWith(":export") && o.files) for (const [k, p] of Object.entries(o.files)) out.push(`<a class="btn small" href="${fileHref(p)}" target="_blank">${IC.ext}${esc(k.toUpperCase())} export</a>`);
  if (s.key === "report" && o.files && o.files.html) out.push(`<a class="btn small" href="${fileHref(o.files.html)}" target="_blank">${IC.ext}Open the flow report</a>`);
  let h = out.length ? `<div class="links">${out.join("")}</div>` : "";
  if (s.key.endsWith(":testcase") && o.path) h += `<div class="mt">test file <code>${esc(o.path.split(/[\\/]/).pop())}</code> · run here without the drive: <b>${esc(o.pytest || "")}</b></div>`;
  if (s.key.endsWith(":summary") && o.lines) h += `<div class="mt" style="margin-top:6px">${o.lines.map(l => `<div>${esc(l)}</div>`).join("")}</div>`;
  return h;
}
function stepRow(s, v, strip) {
  const title = strip && s.title.includes(" · ") ? s.title.split(" · ").slice(1).join(" · ") : s.title;
  const meta = [STATE_WORDS[s.state] || s.state, s.producer ? "answered by " + plainProducer(s.producer) : (s.state === "waiting" ? "" : s.agent), s.note && s.state !== "running" ? s.note : ""].filter(Boolean).join(" · ");
  const revs = v.reviews.filter(r => r.step === s.id && r.state !== "open");
  const det = (s.output && Object.keys(s.output).length && DONE.includes(s.state)) || revs.length;
  return `<div class="ti ${esc(s.state)}"><div class="ic ${esc(s.state)}">${iconOf(s.state)}</div><div>
    <div class="tt">${esc(title)}</div><div class="mt">${esc(meta)}</div>
    ${DONE.includes(s.state) ? stepLinks(s) : ""}
    ${det ? `<details data-id="st${s.id}"><summary>Details</summary>${revs.map(r => `<div class="mt" style="margin:6px 0"><b>${esc(r.title)}</b> · ${esc(STATE_WORDS[r.state] || r.state)} by ${esc(r.decided_by || "")} · ${when(r.decided_at)}${r.comment ? ` · “${esc(r.comment)}”` : ""}${r.data && r.data.edits && r.data.edits.signal ? " · signal: " + esc(r.data.edits.signal.replace(/_/g, " ")) : ""}</div>${md(bodyOf(r))}${chatOf(r)}`).join("")}
      ${s.output && Object.keys(s.output).length ? `<pre class="out">${esc(JSON.stringify(s.output, null, 1).slice(0, 15000))}</pre>` : ""}</details>` : ""}
  </div></div>`;
}
// what was asked and answered on a card that is decided: kept with it and shown again whenever the analysis is opened
function chatOf(r) {
  const c = r.chat || []; if (!c.length) return "";
  return `<div class="sectionhead" style="margin-top:8px">Questions and answers on this card (${c.filter(x => x.role.startsWith("admin:")).length} asked)</div><div class="chat">${c.map(x => `<div class="m ${x.role.startsWith("admin:") ? "me" : ""}"><div class="who">${esc(x.role.startsWith("admin:") ? x.role.slice(6) : x.role)} · ${when(x.at)}</div><div>${md(x.text)}</div></div>`).join("")}</div>`;
}
const track = ss => `<span class="track">${ss.map(s => `<span class="k ${esc(s.state)}" title="${esc(s.title)}: ${esc(STATE_WORDS[s.state] || s.state)}"></span>`).join("")}</span>`;

// ---- page 1: the data
function dataPage(x, v) {
  const head = x.ss.filter(s => s.key === "director" || s.key === "f1_last");
  const files = [...new Set(x.ss.filter(s => s.key.includes(":")).map(s => s.key.split(":").slice(1).join(":")))];
  let h = `<section class="card"><div class="tl">${head.map(s => stepRow(s, v)).join("")}</div></section>`;
  if (files.length) h += `<div class="sectionhead">One sub-family per file</div>` + files.map(f => {
    const ss = x.ss.filter(s => s.key.split(":").slice(1).join(":") === f);
    const man = ss.find(s => s.key.startsWith("manager:")) || {};
    const lvl = ((ss[0] || {}).input || {}).file || {};
    const pill = man.state === "approved" ? `<span class="pill ok">dictionary approved</span>` : ss.every(s => s.state === "skipped") ? `<span class="pill acc">approved before: reused</span>` : man.state === "needs_review" ? `<span class="pill warn">needs your decision</span>` : ss.some(s => s.state === "running") ? `<span class="pill run">reading</span>` : `<span class="pill">waiting</span>`;
    return `<details class="group" data-id="f-${esc(f)}"><summary class="ghead"><span><span class="gt">${esc(f)}</span> <span class="gs">${esc(lvl.level_label || "")}${lvl.columns ? " · " + lvl.columns + " columns" : ""}</span></span><span class="row">${track(ss)}${pill}</span></summary><div class="tl">${ss.map(s => stepRow(s, v)).join("")}</div></details>`;
  }).join("");
  const gate = x.ss.filter(s => s.key === "f1_gate");      // flows started before 2026-11-12 have no such step
  if (gate.length) h += `<div class="sectionhead">Ask all the Managers · then stage 2, or not</div><section class="card"><div class="tl">${gate.map(s => stepRow(s, v)).join("")}</div></section>`;
  return h;
}

// ---- page 2: the tree
function treePage(x, v) {
  const o = k => ((x.ss.find(s => s.key === k) || {}).output) || {};
  const sl = o("slice_test"), br = o("breaker"), ind = o("independent"), b = o("build");
  const viol = (ind.invariants || []).reduce((a, i) => a + (i.violations || 0), 0);
  let h = "";
  if (b.upload_id || sl.of) h += `<div class="tiles">
      ${b.upload_id ? `<div class="tile"><div class="l">The tree</div><div class="v" style="font-size:18px;margin:6px 0">${b.reused ? "reused" : "built"}</div><a class="btn small" href="${treeHref(b.upload_id)}" target="_blank">${IC.ext}Open the tree</a></div>` : ""}
      ${sl.of ? `<div class="tile"><div class="v">${sl.passed} / ${sl.of}</div><div class="l">random windows rebuilt alone match the full tree (Code tester)</div></div>` : ""}
      ${br.of ? `<div class="tile"><div class="v">${br.passed} / ${br.of}</div><div class="l">hardest windows pass (Breaker)</div></div>` : ""}
      ${ind.invariants ? `<div class="tile"><div class="v">${nf(viol)}</div><div class="l">violations of the column meanings (Independent tester)</div></div>` : ""}</div>`;
  h += joinRulesPanel(x, v, ind);
  h += `<section class="card"><div class="tl">${x.ss.map(s => stepRow(s, v)).join("")}</div></section>`;
  return h;
}

// ---- page 3: rules, defects, test cases
function rulesPage(x, v) {
  const plan = x.ss.find(s => s.key === "f3_plan");
  let h = plan ? `<section class="card"><div class="tl">${stepRow(plan, v)}</div></section>` : "";
  const items = [];
  for (const s of x.ss) {
    if (!s.key.startsWith("f3:")) continue;
    const it = s.key.slice(3).split(":").slice(0, -1).join(":");
    if (it.includes("@")) continue;            // an error's own steps: on that error's page
    let g = items.find(g => g.it === it); if (!g) items.push(g = { it, ss: [] }); g.ss.push(s);
  }
  if (!items.length) return h;
  const sec = it => it.startsWith("errors/") ? "errors" : "analytics";
  for (const [k, label] of [["analytics", "Section 1 · Data analytics"], ["errors", "Section 2 · Errors: stage 1 and stage 2"]]) {
    const gs = items.filter(g => sec(g.it) === k); if (!gs.length) continue;
    h += `<div class="sectionhead">${label}</div>` + gs.map(g => {
      const name = g.ss[0].title.split(" · ")[0];
      const o = key => ((g.ss.find(s => s.key.endsWith(":" + key)) || {}).output) || {};
      const run = o("run"), test = o("test"), iso = o("isolate"), tc = o("testcase");
      const lvl = g.it.split("/")[1].replace("_", " ");
      const res = g.ss.find(s => s.key.endsWith(":result")) || {};
      const facts = [run.rows !== undefined ? `${nf(run.rows)} rows` : "", test.checks ? (test.passed ? "tester: all checks passed" : "tester: NOT all checks passed") : "",
        iso.finding !== undefined ? "one error isolated in the flow (made before 2026-11-11)" : "", tc.path ? "test file written" : ""].filter(Boolean).join(" · ");
      const el = errorLists(v).find(s => s.key === `f3:${g.it}:errors`), ec = el ? errCounts(el) : null;    // where its errors stand (owner, 2026-11-11)
      const errLine = ec ? `<div class="small" style="margin-top:2px"><b>${nf(ec.n)} error${ec.n === 1 ? "" : "s"}</b> · stage 1 done: ${ec.s1} · stage 2 done: ${ec.s2} · test files approved: ${ec.t}</div>` : "";
      const errBtn = ec ? `<a class="btn small primary" href="#/p/${v.run.project}/errors/${encodeURIComponent(g.it)}">Open the errors page</a>` : "";
      const pill = g.ss.some(s => s.state === "needs_review") ? `<span class="pill warn">needs your decision</span>` : g.ss.some(s => s.state === "running") ? `<span class="pill run">working</span>` :
        g.ss.every(s => DONE.includes(s.state)) ? (res.state === "skipped" ? `<span class="pill">changed: see the next round</span>` : `<span class="pill ok">done</span>`) : `<span class="pill">waiting</span>`;
      return `<details class="group" data-id="i-${esc(g.it)}"><summary class="ghead"><span><span class="gt">${esc(name)}</span> <span class="gs">${esc(lvl)}${facts ? " · " + esc(facts) : ""}</span>${errLine}</span><span class="row">${errBtn}${track(g.ss)}${pill}</span></summary><div class="tl">${g.ss.map(s => stepRow(s, v, true)).join("")}</div></details>`;
    }).join("");
  }
  return h;
}

// ---- page 4: the report
function reportPage(x, v, p) {
  const rep = (x.ss.find(s => s.key === "report") || {}).output || {};
  const all = v.steps, o = k => ((all.find(s => s.key === k) || {}).output) || {};
  const dicts = all.filter(s => s.key.startsWith("manager:")).length, sl = o("slice_test");
  const tcs = all.filter(s => s.key.endsWith(":testcase") && s.output && s.output.path);
  const items = new Set(all.filter(s => s.key.startsWith("f3:")).map(s => s.key.slice(3).split(":")[0].split("#")[0]));
  const inline = all.filter(s => s.key.endsWith(":isolate") && s.output && s.output.finding !== undefined).length;     // runs made before 2026-11-11
  const exports = all.filter(s => s.key.endsWith(":export") && s.output && s.output.files);
  // where the errors stand, from the procedural graph (owner, 2026-11-11: stage 1 completed, stage 2 completed, test files created)
  const ec = errorLists(v).map(errCounts).reduce((a, c) => ({ n: a.n + c.n, s1: a.s1 + c.s1, s2: a.s2 + c.s2, t: a.t + c.t }), { n: 0, s1: 0, s2: 0, t: 0 });
  let h = `<div class="tiles"><div class="tile"><div class="v">${dicts}</div><div class="l">data dictionaries</div></div>
    <div class="tile"><div class="v">${sl.of ? sl.passed + " / " + sl.of : "-"}</div><div class="l">tree windows matching</div></div>
    <div class="tile"><div class="v">${items.size}</div><div class="l">rules run (on the tree, or on the files when no tree was built)</div></div>
    <div class="tile"><div class="v">${nf(ec.n)}</div><div class="l">errors found</div></div>
    <div class="tile"><div class="v">${ec.s1 + inline}</div><div class="l">isolated (stage 1 done)</div></div>
    <div class="tile"><div class="v">${ec.s2}</div><div class="l">stage 2 done</div></div>
    <div class="tile"><div class="v">${ec.t + tcs.length}</div><div class="l">test files approved or written</div></div></div>`;
  if (ec.n) h += `<div class="row" style="margin:6px 0 12px"><a class="btn" href="#/p/${v.run.project}/errors">Open the errors page ${IC.chev}</a></div>`;
  h += `<section class="card"><h2>The report</h2><p class="small muted">${rep.files ? "Everything every family produced, in one page." : "Written when the last step finishes."}</p>
    <div class="links">${rep.files && rep.files.html ? `<a class="btn primary" href="${fileHref(rep.files.html)}" target="_blank">${IC.ext}Open the flow report</a><a class="btn" href="${fileHref(rep.files.json)}" target="_blank">The report as JSON</a>` : ""}
    ${p.upload_id ? `<a class="btn" href="${treeHref(p.upload_id)}" target="_blank">${IC.ext}Open the tree</a>` : ""}</div>
    ${exports.length ? `<div class="sectionhead">Exports</div><div class="links">${exports.map(s => Object.entries(s.output.files).map(([k, f]) => `<a class="btn small" href="${fileHref(f)}" target="_blank">${esc(s.title.split(" · ")[0])} · ${esc(k.toUpperCase())}</a>`).join("")).join("")}</div>` : ""}
    ${tcs.length ? `<div class="sectionhead">Test files</div>${tcs.map(s => `<div class="mt"><code>${esc(s.output.path)}</code> · ${esc(s.output.pytest || "")}</div>`).join("")}` : ""}</section>`;
  h += `<section class="card"><div class="tl">${x.ss.map(s => stepRow(s, v)).join("")}</div></section>`;
  return h;
}

// ------------------------------------------------------------------ Family 4 · Coding (owner, 2026-11-12)
// The requirements card: one answer box per question of the Requirements agent, the number of rounds, and "go on with the open points".
// (owner, 2026-11-14: "the coding family is the coding research family ... it's all about the data") what was measured before the requirements
function f4Research(r) {
  const x = (r.data || {}).f4_research;
  if (!x) return "";
  const led = x.ledger || [], n = st => led.filter(l => l.state === st).length;
  const col = b => `<tr><td><code>${esc(b.file)}</code>: <b>${esc(b.column)}</b>${b.meaning_from_family_1 ? `<div class="muted">${esc(b.meaning_from_family_1)}</div>` : ""}</td>
      <td>${nf(b.rows_with_a_value)} of ${nf(b.rows)} rows hold a value<div class="muted">${esc(b.basis || "")}</div></td>
      <td>${(b.nothing || []).length ? b.nothing.map(k => `${esc(k.spelling)}: ${nf(k.rows)} (first at line ${(k.first_lines || []).map(esc).join(", ")})`).join("<br>") : `<span class="muted">none found</span>`}</td>
      <td>${(b.shapes || []).slice(0, 3).map(k => `${esc(k.shape)} (${nf(k.rows)})`).join("<br>")}${b.range ? `<div class="muted">from ${esc(b.range[0])} to ${esc(b.range[1])}${b.unit ? " " + esc(b.unit) : ""}</div>` : ""}</td>
      <td>${(b.most_frequent || []).slice(0, 5).map(k => `<code>${esc(k.value)}</code> (${nf(k.rows)})`).join(", ")}</td></tr>`;
  const blocks = (x.files || []).flatMap(f => f.touched || []);
  return `${blocks.length ? `<details class="more" data-id="f4rs${r.id}"><summary>${IC.chev}The columns the rule reads, as the program measured them (${blocks.length})</summary>
      <div class="tbl"><table><thead><tr><th>Column</th><th>Rows with a value</th><th>Spellings of nothing</th><th>How the values look</th><th>Most frequent values (rows)</th></tr></thead><tbody>${blocks.map(col).join("")}</tbody></table></div></details>` : ""}
    ${led.length ? `<details class="more" data-id="f4rl${r.id}"><summary>${IC.chev}The ledger: everything the rule needs, with its source (${n("established")} established, ${n("to decide") + n("to measure")} to decide, ${n("guess")} a guess)</summary>
      <div class="tbl"><table><thead><tr><th>What the rule needs</th><th>State</th><th>Source</th><th>What is known</th></tr></thead><tbody>${led.map(l =>
        `<tr><td>${esc(l.what)}</td><td>${l.state === "established" ? "established" : `<b>${esc(l.state)}</b>`}</td><td>${esc(l.source || "")}</td><td>${esc(l.detail || "")}</td></tr>`).join("")}</tbody></table></div></details>` : ""}`;
}
// the requirement-by-check table on the code card: for each requirement the program could not show to hold, the admin decides (nothing is chosen for them)
function f4Proof(r) {
  const open = (r.data || {}).f4_open || [];
  if (!open.length) return "";
  const was = (id, v) => { const x = document.querySelector(`input[name="f4d${r.id}_${id}"]:checked`); return x && x.value === v ? " checked" : ""; };
  const pick = (x, v, words) => `<label class="chk small" style="display:flex;gap:6px;align-items:center;margin:2px 0"><input type="radio" name="f4d${r.id}_${esc(x.id)}" value="${v}"${was(x.id, v)}> ${words}</label>`;
  return `<div class="lbl2" style="margin-top:12px">Your decision on each requirement the program could not show to hold</div>
    ${open.map(x => `<div class="card" style="margin:6px 0;padding:10px 12px"><div><b>${esc(x.id)}</b> ${esc(x.requirement)}</div>
      <div class="small muted" style="margin:2px 0 6px">${esc(x.verdict)}: ${esc(x.why)}</div>
      ${pick(x, "accept", "Accept it as it is")}${pick(x, "check", "Ask for a check: the Tester makes a data set that can fail for it (then press Ask for changes, with your comment)")}${pick(x, "change", "The requirement must change: I say how in the comment box (then press Ask for changes)")}</div>`).join("")}`;
}
function f4ProofEdits(r) {
  const open = (r.data || {}).f4_open || [];
  if (!open.length) return undefined;
  const out = {};
  open.forEach(x => { const c = document.querySelector(`input[name="f4d${r.id}_${x.id}"]:checked`); if (c) out[x.id] = c.value; });
  return { req_decisions: out };
}
function f4ReqForm(r) {
  const d = r.data || {}, qs = d.questions || [], most = d.rounds_most || 20;
  // the page is drawn again while the admin reads: the choice already made is taken from the page as it stands (nothing is chosen for them)
  const was = (i, v) => { const x = document.querySelector(`input[name="f4c${r.id}_${i}"]:checked`); return x && x.value === v ? " checked" : ""; };
  const rowsOf = x => (x || []).length ? x.map(row => esc(JSON.stringify(row))).join("<br>") : "<span class=\"muted\">no output line</span>";
  // (owner, 2026-11-14) a column that could stand for a missing one: what the program counted, what speaks against it; the admin chooses, nothing is pre-selected
  const proposal = (p, i, j) => {
    const o = p.overlap;
    return `<div class="card" style="margin:6px 0;padding:10px 12px">
      <label class="chk" style="display:flex;gap:8px;align-items:flex-start;font-weight:600"><input type="radio" name="f4c${r.id}_${i}" value="use:${j}"${was(i, `use:${j}`)} style="margin-top:3px">
        <span>Use <code>${esc(p.file)}</code> column <code>${esc(p.column)}</code> for it <span class="pill">${esc(p.level)}</span></span></label>
      <div class="small" style="margin:4px 0 0 26px">
        ${p.meaning ? `<div><b>What it means, from Family 1:</b> ${esc(p.meaning)}${p.meaning_source ? ` <span class="muted">(source: ${esc(p.meaning_source)})</span>` : ""}</div>` : `<div class="muted">Family 1 recorded no meaning for this column.</div>`}
        <div><b>What it holds:</b> ${nf(p.rows_with_a_value)} rows with a value, ${nf(p.distinct_values)} distinct${p.shape ? `; its values look like ${esc(p.shape)}` : ""}${(p.some_values || []).length ? `, for example ${p.some_values.slice(0, 4).map(v => `<code>${esc(v)}</code>`).join(", ")}` : ""}</div>
        ${o ? `<div><b>Counted:</b> ${nf(o.found)} of the ${nf(o.wanted_values)} wanted values are in it (${esc(o.share_percent)} %), ${esc(o.basis)}${(o.lines || []).length ? `; seen at line${o.lines.length === 1 ? "" : "s"} ${o.lines.map(esc).join(", ")}` : ""}</div>` : `<div class="muted">No values could be compared: this rests on the meaning${p.name_alike ? " and the name" : ""}.</div>`}
        ${p.model_reason ? `<div><b>The model's reading:</b> ${esc(p.model_reason)}</div>` : ""}
        ${(p.against || []).length ? `<div class="err"><b>Against it:</b> ${p.against.map(esc).join("; ")}</div>` : ""}
      </div></div>`;
  };
  const one = (q, i) => {
    const head = `<label class="f">${i + 1}. ${esc(q.question)}${q.why ? ` <span class="hint">· ${q.kind ? "" : "why it is asked: "}${esc(q.why)}</span>` : ""}</label>`;
    if (q.kind === "substitute") return `${head}${(q.proposals || []).map((p, j) => proposal(p, i, j)).join("")}
      <label class="chk small" style="display:flex;gap:8px;align-items:center;margin:4px 0"><input type="radio" name="f4c${r.id}_${i}" value="not_same"${was(i, "not_same")}> None of these is the same kind of data</label>
      <label class="chk small" style="display:flex;gap:8px;align-items:center;margin:4px 0"><input type="radio" name="f4c${r.id}_${i}" value="add_file"${was(i, "add_file")}> I will add the CSV file that holds it (then press Read the new files at the step after Family 1)</label>
      <textarea id="f4a${r.id}_${i}" data-keep="f4a${r.id}_${i}" style="min-height:36px" placeholder="anything to add, in your own words (not needed)"></textarea>`;
    if (q.kind === "doubt") return `${head}
      ${q.data ? `<div class="small"><b>The data:</b> ${Object.keys(q.data).map(f => `<code>${esc(f)}</code>: ${(q.data[f] || []).length ? q.data[f].slice(0, 8).map(x => esc(JSON.stringify(x))).join(" · ") : "no record"}`).join("; ")}</div>` : `<div class="small muted">The data are the first records of the real file.</div>`}
      <label class="chk small" style="display:flex;gap:8px;align-items:flex-start;margin:6px 0"><input type="radio" name="f4c${r.id}_${i}" value="first"${was(i, "first")} style="margin-top:3px"> <span><b>The first result is meant:</b><br>${rowsOf(q.first)}</span></label>
      <label class="chk small" style="display:flex;gap:8px;align-items:flex-start;margin:6px 0"><input type="radio" name="f4c${r.id}_${i}" value="second"${was(i, "second")} style="margin-top:3px"> <span><b>The second result is meant:</b><br>${rowsOf(q.second)}</span></label>
      <label class="chk small" style="display:flex;gap:8px;align-items:center;margin:6px 0"><input type="radio" name="f4c${r.id}_${i}" value="neither"${was(i, "neither")}> Neither: I write below what the result should be</label>
      ${q.expected ? `<div class="small muted">The Tester expected ${rowsOf(q.expected)}; neither program wrote that.</div>` : ""}
      <textarea id="f4a${r.id}_${i}" data-keep="f4a${r.id}_${i}" style="min-height:36px" placeholder="in your own words: what the result should be, and why"></textarea>`;
    return `${head}<textarea id="f4a${r.id}_${i}" data-keep="f4a${r.id}_${i}" style="min-height:44px" placeholder="your answer"></textarea>`;
  };
  return `${f4Research(r)}${qs.length ? `<div class="lbl2" style="margin-top:12px">Your answers</div>${qs.map(one).join("")}` : ""}
    ${d.f4_doubt ? "" : `<div class="row" style="align-items:center;margin-top:12px;gap:14px;flex-wrap:wrap">
      <label class="small">Rounds of code and test at most <input type="number" id="f4n${r.id}" data-keep="f4n${r.id}" min="1" max="${esc(most)}" value="${esc(d.rounds || 10)}" style="width:70px"> <span class="muted">(1 to ${esc(most)}; the rounds end earlier when a round is clean; after 3 rounds on one program the Coder starts a fresh one)</span></label>
      ${d.open ? `<label class="chk small" style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="f4o${r.id}" data-keep="f4o${r.id}"> go on with the ${esc(d.open)} open point${d.open === 1 ? "" : "s"} as ${d.open === 1 ? "it is" : "they are"}</label>` : ""}
    </div>`}
    ${(d.not_found || []).length ? `<p class="small muted">Not found in any file: ${(d.not_found || []).map(esc).join("; ")}. To have the code made without it, say why in the comment box, in your own words.</p>` : ""}`;
}
function f4ReqEdits(r) {
  const d = r.data || {}, answers = {}, choices = {};
  (d.questions || []).forEach((q, i) => {
    const t = $(`f4a${r.id}_${i}`), picked = document.querySelector(`input[name="f4c${r.id}_${i}"]:checked`);
    let words = t && t.value.trim() ? t.value.trim() : "";
    if (picked) {
      const v = picked.value;
      if (v.startsWith("use:")) { const j = Number(v.slice(4)), p = (q.proposals || [])[j] || {}; choices[i] = { choice: "use", proposal: j }; words = words || `use ${p.file}: ${p.column}`; }
      else { choices[i] = { choice: v }; words = words || ({ not_same: "none of these is the same", add_file: "I will add the file that holds it", first: "the first result is meant", second: "the second result is meant", neither: "neither result is meant" }[v] || v); }
    }
    if (words) answers[i] = words;
  });
  const n = $("f4n" + r.id), o = $("f4o" + r.id);
  return { answers, choices, rounds: n && n.value !== "" ? Number(n.value) : null, accept_open: !!(o && o.checked) };
}
// The code card: the chain of thought, round by round: what the Coder noted and changed, the program's checks, each small data set with
// what was expected and what the code wrote, and what the Tester tried. A round that was not clean is open.
function f4Trail(r) {
  const d = r.data || {}, t = d.f4_trail || [], f = d.f4 || {};
  if (!t.length) return f4Proof(r);
  const li = xs => (xs || []).length ? `<ul>${xs.map(x => `<li>${esc(typeof x === "string" ? x : JSON.stringify(x))}</li>`).join("")}</ul>` : "";
  const rows = x => (x || []).map(row => esc(JSON.stringify(row))).join("<br>");
  const who = a => `<span class="hint">· ${esc(plainProducer(a.by))}${a.seconds ? `, ${fmtSecs(a.seconds)}` : ""}</span>`;
  const round = x => {
    const c = x.coder || {}, te = x.tester, cs = x.cases || [], ran = cs.filter(k => k.status === "passed" || k.status === "failed");
    return `<details class="more" data-id="f4r${r.id}_${x.round}"${x.clean ? "" : " open"}><summary>${IC.chev}Round ${esc(x.round)}${x.after_feedback ? " · after your comment" : ""}${x.fresh_program ? ` · a fresh program (number ${esc(x.program)})` : ""} · ${x.clean ? "clean" : "not clean"} <span class="hint">· ${esc(x.said || "")}</span></summary>
      ${x.fresh_program ? `<p class="small muted">The program before this one was repaired three times and still failed, so the Coder wrote a new one from the requirements and what had failed.</p>` : ""}
      ${x.second_program ? `<p class="small muted">${x.second_program.usable ? `A second program was written independently from the same requirements and run on the same data: ${x.doubts ? `its result differs on ${esc(x.doubts)} data set${x.doubts === 1 ? "" : "s"}, so you were asked which is meant.` : "where both ran, the results agree."}` : `No second program could be used (${esc(x.second_program.why || "none was written")}).`}</p>` : ""}
      <div class="lbl2">The Coder's notes: what it understood and decided ${who(c)}</div>${li(c.notes || c.thinking) || '<p class="small muted">none given</p>'}
      ${(c.changed || []).length ? `<div class="lbl2">What it changed</div>${li(c.changed)}` : ""}
      ${(c.objections || []).length ? `<div class="lbl2">Its objections to what a data set expects</div>${li(c.objections.map(o => `${o.case}: ${o.why}`))}` : ""}
      ${(c.remarks_answered || []).length ? `<div class="lbl2">Its answers to the Tester's remarks</div>${li(c.remarks_answered.map(o => `${o.remark}: ${o.answer}`))}` : ""}
      ${(c.questions || []).length ? `<div class="lbl2">The Coder asks</div>${li(c.questions)}` : ""}
      ${(x.static || []).length ? `<p class="err small">The program refused this code before running it: ${esc(x.static.join("; "))}</p>` : ""}
      ${x.whole_file ? `<p class="small">On ${esc(x.whole_file.on)}: ${(x.whole_file.checks || []).map(k => `${k.ok === true ? "holds" : k.ok === false ? "<b>does not hold</b>" : "could not be checked"}: ${esc(k.check)} (${esc(k.detail)})`).join("; ")}</p>` : ""}
      ${x.proof && (x.proof.rows || []).some(k => k.verdict === "not met") ? `<p class="err small">Not met in this round: ${x.proof.rows.filter(k => k.verdict === "not met").map(k => `${esc(k.id)} (${esc(k.why)})`).join("; ")}</p>` : ""}
      ${x.sample ? `<p class="small">On ${esc(x.sample.on)}: ${x.sample.not_finished ? "not finished in the time of a try (not counted against the code)" : x.sample.ok ? `it ran to the end, ${nf(x.sample.lines || 0)} output line${x.sample.lines === 1 ? "" : "s"}` : `it failed: ${esc(x.sample.error || "its output did not pass the program's checks")}`}</p>` : ""}
      ${te ? `<div class="lbl2">The Tester's notes: what it chose to check, from the requirements alone (it is not shown the code) ${who(te)}</div>${li(te.notes || te.thinking) || '<p class="small muted">none given</p>'}
        ${(te.remarks || []).length ? `<div class="lbl2">The Tester's remarks (not shown with a data set)</div>${li(te.remarks.map(m => `${m.where ? m.where + ": " : ""}${m.what}${m.why ? " (" + m.why + ")" : ""}`))}` : ""}
        ${(te.refused || []).length ? `<p class="small muted">Data sets of the Tester the program could not use: ${esc(te.refused.join("; "))}</p>` : ""}` : ""}
      ${cs.length ? `<div class="lbl2">The small data sets <span class="hint">· ${ran.filter(k => k.status === "passed").length} of ${ran.length} passed</span></div><div class="tbl"><table><tr><th>data set</th><th>made by</th><th>why it was made</th><th>result</th></tr>${cs.map(k =>
        `<tr><td><b>${esc(k.name)}</b>${k.new ? " · new in this round" : ""}</td><td>${esc(k.by)}</td><td class="small">${k.property ? `<b>${esc(k.property)}</b><br>` : ""}${esc(k.why || "")}</td><td class="small"><b>${esc(k.status || "")}</b>${k.detail ? ": " + esc(k.detail) : ""}${k.status !== "passed" && k.expected_rows ? `<br>expected (the Tester's claim): ${rows(k.expected_rows)}<br>the code wrote: ${rows(k.got)}` : ""}${k.objection ? `<br>the Coder objects: ${esc(k.objection)}` : ""}${k.tester_reply ? `<br>the Tester: ${esc(k.tester_reply)}` : ""}</td></tr>`).join("")}</table></div>` : ""}
    </details>`;
  };
  return `${f4Proof(r)}<div class="lbl2" style="margin-top:12px">The chain of thought, round by round <span class="hint">· ${esc(f.rounds_used)} round${f.rounds_used === 1 ? "" : "s"} of at most ${esc(f.rounds_most)} · why they ended: ${esc(f.stopped_because || "")}</span></div>${t.map(round).join("")}`;
}

// ------------------------------------------------------------------ the decision card
function decisionCard(r, s, v) {
  const d = r.data || {}, key = s.key;
  const isDict = key.startsWith("manager:") && d.summary !== undefined;     // a data dictionary of the new sub-family
  const isGate = key === "f1_gate";       // after Family 1 (owner, 2026-11-12): ask all the Managers; read the new files; go to stage 2, or not
  const st = STAGES.find(x => x.id === STAGE_OF_FAM[s.family]);
  const srcOf = t => (t.sources || []).filter(x => x.kind === "document" || x.kind === "web").slice(0, 2).map(x => x.kind === "web"
    ? `<a href="${esc(x.ref)}" target="_blank" rel="noopener">${esc((x.ref.split("/")[2] || x.ref))}</a>` : esc((x.ref || "").split("/").pop())).join("<br>");
  const dictTable = d.table ? `<details class="more" data-id="dt${r.id}"><summary>${IC.chev}The full dictionary (${d.table.length} columns)</summary><div class="tbl"><table><tr><th>column</th><th>what the data shows</th><th>meaning</th><th>status</th><th>source</th></tr>` +
    d.table.map(t => `<tr><td><b>${esc(t.column)}</b></td><td>${esc(t.observed)}</td><td>${esc(t.meaning)}</td><td>${esc(t.status)}</td><td class="small">${srcOf(t)}</td></tr>`).join("") + `</table></div></details>` : "";
  const files = d.files ? `<div class="links">` + Object.entries(d.files).map(([k, p]) => `<a class="btn small" href="${fileHref(p)}" target="_blank">${IC.ext}${esc(k.toUpperCase())} export</a>`).join("") + `</div>` : "";
  const isErrResult = key.endsWith(":result") && (d.defects || d.section === "errors") && (d.head || []).length;
  let form = "";
  if (d.f4_req) form = f4ReqForm(r);           // Family 4: the answers to the Requirements agent, the number of rounds
  else if (d.f4_trail) form = f4Trail(r);      // Family 4: the chain of thought of the rounds, under the code
  else if (key === "f3_plan") form = planForm(r);
  else if (isErrResult && !d.errors_page) form = defectForm(r);
  else if (d.errors_overview) form = errorsOverview(v);
  else if (d.isolation) form = isolationForm(r) + windowForm(r);
  else if (d.graph) form = causeForm(r);
  else if (d.first || d.judge) form = solutionForm(r);
  else if (d.signals) form = windowForm(r) + sequenceForm(r);
  else if (d.outcomes) form = outcomesForm(r);
  else if (d.testfile) form = testfileForm(r);
  else if (isGate && d.rea && d.rea.usable && d.stage2 && d.stage2.fixed_possible)       // (owner, 2026-11-14) the REA findings are optional for Family 2: used only when ticked here
    form = `<label class="chk" for="rea-use${r.id}" style="display:flex;gap:8px;align-items:center;margin-top:12px;font-weight:500"><input type="checkbox" id="rea-use${r.id}" data-keep="rea-use${r.id}"> Also give the REA findings to Family 2 <span class="hint">· optional; only with Go to stage 2</span></label>
      <div class="why">Family 2 does not need the REA findings. With the tick, its Coder also quotes lines of the analyzer's decompiled code (${esc(d.rea.folder)}) as evidence for the joins, each line checked in its own file. Without the tick the findings are not looked at. It matters only when the joining strategy is researched, not when a strategy approved before is used again.</div>`;
  else if (d.ask_rea) form = `<label class="f">Folder with the REA findings</label><input type="text" id="rea${r.id}" data-keep="rea${r.id}" placeholder="/path/to/the/REA/output">`;
  else if (key === "build_ask" && d.reuse) form = `<label class="chk" style="display:flex;gap:8px;align-items:center;margin-top:12px;font-weight:500"><input type="checkbox" id="rb${r.id}" data-keep="rb${r.id}"> Build it again anyway</label>`;
  else if (isDict) {          // (owner, 2026-11-10: what does it do, where is it saved, which button?)
    const known = {}; (d.table || []).forEach(c => { known[c.column] = (c.keywords || []).map(k => k.value); }); (d.empty || []).forEach(n => { if (!(n in known)) known[n] = []; });
    const c0 = (d.table || [])[0], k0 = (d.table || []).find(c => (c.keywords || []).length);
    const eg = (c0 ? `${c0.column} = what this column holds` : "column = meaning") + (k0 ? `\n${k0.column}: ${k0.keywords[0].value} = what this word means` : "");
    form = `<details class="more" data-id="ed-${r.id}"><summary>${IC.chev}Change a meaning yourself (optional)</summary>
      <label class="f">One per line: <code>column = meaning</code>, or for a keyword <code>column: keyword = meaning</code>. A column with no value here can be given one too.</label>
      <textarea id="ed${r.id}" data-keep="ed${r.id}" data-dict='${esc(JSON.stringify(known))}' placeholder="${esc(eg)}"></textarea>
      <div class="small" id="edchk${r.id}"></div>
      <p class="small muted">Nothing is saved until you press <b>Approve the dictionary</b> at the bottom of this card. Then each line replaces that meaning, marked “given by you”, and the dictionary is kept as a new version in <code>knowledge/dictionaries/</code>. The next steps of this flow use it (the joining strategy, the rules, your questions), and so does any later analysis of files with the same headers. The CSV file itself is never changed.</p></details>`;
  }
  else if (d.table) form = `<label class="f">Correct a meaning <span class="hint">· optional; one per line: column = meaning</span></label><textarea id="ed${r.id}" data-keep="ed${r.id}" placeholder="SQID = the submission queue the command was placed on"></textarea>`;
  let buttons;
  if (d.judge) buttons = `<p class="small muted" style="margin:10px 0 4px">Your signal is about the solution you chose above; it changes only how this cause's solutions are ranked the next time.</p><div class="choices">
      <button class="choice plus" data-act="dec" data-r="${r.id}" data-dec="approve" data-sig="correct"><span class="sc">+1</span><span><b>Correct</b><span class="d">it is right for this cause; its error sequence goes to the test</span></span></button>
      <button class="choice plus" data-act="dec" data-r="${r.id}" data-dec="approve" data-sig="correct_with_edits"><span class="sc">+1</span><span><b>Correct with my edits</b><span class="d">right, and your edits become its next version</span></span></button>
      <button class="choice minus" data-act="dec" data-r="${r.id}" data-dec="change" data-sig="wrong"><span class="sc">−1</span><span><b>Wrong</b><span class="d">it moves down; the list is shown again so you can choose another</span></span></button>
      <button class="choice minus" data-act="dec" data-r="${r.id}" data-dec="approve" data-sig="wrong_with_edits"><span class="sc">−1</span><span><b>Wrong, keep my edits</b><span class="d">it moves down; your edits are stored as a new solution</span></span></button>
      <button class="choice" data-act="dec" data-r="${r.id}" data-dec="approve" data-sig="store"><span class="sc">+</span><span><b>Store this recording's sequence as a new solution</b><span class="d">none of the stored ones fits; uses the sequence and lines you opened below the list</span></span></button></div>
    <div class="actions"><span class="msg" id="msg${r.id}"></span><button class="btn quiet danger" data-act="dec" data-r="${r.id}" data-dec="reject">Stop</button></div>`;
  else if (d.signals) buttons = `<div class="choices">
      <button class="choice plus" data-act="dec" data-r="${r.id}" data-dec="approve" data-sig="correct"><span class="sc">+1</span><span><b>Correct</b><span class="d">store this sequence as the procedure for this kind of defect</span></span></button>
      <button class="choice plus" data-act="dec" data-r="${r.id}" data-dec="approve" data-sig="correct_with_edits"><span class="sc">+1</span><span><b>Correct with my edits</b><span class="d">store it without the steps you unticked</span></span></button>
      <button class="choice minus" data-act="dec" data-r="${r.id}" data-dec="change" data-sig="wrong"><span class="sc">−1</span><span><b>Wrong: try again</b><span class="d">run the isolation again, with your comment as a hint</span></span></button>
      <button class="choice minus" data-act="dec" data-r="${r.id}" data-dec="approve" data-sig="wrong_with_edits"><span class="sc">−1</span><span><b>Wrong, keep my edited steps</b><span class="d">your edited sequence is stored instead</span></span></button></div>
    <div class="actions"><span class="msg" id="msg${r.id}"></span><button class="btn quiet danger" data-act="dec" data-r="${r.id}" data-dec="reject">Stop</button></div>`;
  else if (d.ask_rea) buttons = `<div class="actions"><span class="msg" id="msg${r.id}"></span><button class="btn quiet danger" data-act="dec" data-r="${r.id}" data-dec="reject">Stop</button>
      <button class="btn" data-act="dec" data-r="${r.id}" data-dec="approve" data-norea="1">Continue without</button><button class="btn primary" data-act="dec" data-r="${r.id}" data-dec="approve">${IC.check.replace("<svg", '<svg class="i"')}Use these findings</button></div>`;
  else if (isGate) buttons = `<div class="actions"><span class="msg" id="msg${r.id}"></span>
      <button class="btn quiet danger" data-act="dec" data-r="${r.id}" data-dec="reject">Stop</button>
      <button type="button" class="btn act2" data-investigate="${r.project || S.project || ""}"><span class="t">Investigate first</span><span class="d">ask the investigation agent (a terminal agent with its own session for this analysis) to look into the files, find where a kind of data is, or write a CSV</span></button>
      <button class="btn act2" data-act="dec" data-r="${r.id}" data-dec="change" data-readnew="1"><span class="t">Read the new files</span><span class="d">only the CSV files added to the folder get their three agents; the files already read are not read again; then this question comes back</span></button>
      <button class="btn act2" data-act="dec" data-r="${r.id}" data-dec="approve" data-stage2="skip"><span class="t">Go on without stage 2</span><span class="d">no tree is built: the rules read the CSV files as they are. Rules that read the tree cannot run; you can open the analysis again at stage 2 later</span></button>
      <button class="btn primary act2" data-act="dec" data-r="${r.id}" data-dec="approve" data-stage2="fixed" ${d.stage2 && !d.stage2.fixed_possible ? `disabled title="${esc("not possible for these files: " + (d.stage2.fixed_problem || ""))}"` : ""}><span class="t">${IC.check.replace("<svg", '<svg class="i"')}Go to stage 2</span><span class="d">${d.stage2 && !d.stage2.fixed_possible ? "not possible for these files: " + esc(d.stage2.fixed_problem || "") : d.stage2 && d.stage2.built_before ? "the tree built before from these same files is used again; nothing is built twice" : "Family 2 connects the analyzer's exports into one tree with the fixed joining strategy"}</span></button></div>`;
  else {
    const isCode = key === "code" || key.endsWith(":code"), isWrite = key === "write" || key.endsWith(":write"), isReq = !!d.f4_req;
    const ok = { f3_plan: "Run the chosen rules", f1_last: "Use them again", last_strategy: "Use it again", build_ask: d.reuse ? "Use the tree built before" : "Build the tree" }[key]
      || (isReq ? "The requirements are complete: write the code" : key === "errors_done" ? "Done: write the report" : d.isolation ? "This isolation is right" : d.graph ? "Use this cause" : d.first ? "Store this solution" : d.testfile ? "Approve this test" : d.outcomes ? "Verified: write the test file" : isCode ? "Approve: make it the verified code" : isWrite ? "Approve the procedure" : key.endsWith(":result") ? "Accept the result" : isDict ? "Approve the dictionary" : "Approve");
    const okWhat = { f3_plan: "the ticked items go on: coded where needed (you review the code), then run on the whole recording, checked and exported",
      f1_last: "the dictionaries approved before are used and their files are not read again; a file without one is read", last_strategy: "the joining strategy approved last time is used",
      build_ask: d.reuse ? "the tree already built from these same files is used; nothing is built again" : "the five files are loaded and joined into one tree" }[key]
      || (isReq ? "the Coder writes the code and the Tester tests it on small data sets, round after round; then you review the final code" : key === "errors_done" ? "the report of the whole analysis is written (page 4); it says where each error stands" : d.isolation ? "the defect is kept under the name you chose; next: what the procedural graph holds for it" : d.graph ? "this occurrence is stored under that cause (one count, with this device); next: the cause's solutions"
        : d.first ? "stored under the cause: the error sequence and the optimized sequence; next: the test file from the error sequence"
        : d.testfile ? "it becomes the regression test of this kind of defect, kept with your name and the file's fingerprint" : d.outcomes ? "the test file is written from these answers" : isCode ? "this code becomes the verified code of the procedure; Run uses it"
        : isWrite ? "this procedure is stored as the item's new version" : key.endsWith(":result") ? ((d.defects || d.section === "errors") && (d.head || []).length ? (d.errors_page ? "the result is kept; its errors go to the errors page, each with its own page" : "the result is kept, and the error you picked goes to stage 1") : "the result is kept")
        : isDict ? "this dictionary is stored; the next steps use its meanings" : "the flow goes on to its next step");
    const ch = { f1_last: "Read the files again", last_strategy: "Research again" }[key] || (isReq ? "Send my answers" : d.testfile ? "Write it again" : d.isolation ? "Isolate again with my comment" : d.first ? "Propose again with my comment" : "Send back with my comment");
    const chWhat = { f1_last: "the Data Explorer and the Grounder read every file again", last_strategy: "the research starts again from the start" }[key]
      || (isReq ? "the Requirements agent reads them and asks again only what is still open" : d.testfile ? "the model writes the plan again, with your comment" : isCode && d.f4 ? "the Coder and the Tester start their rounds again from this code, with your comment" : isCode ? "the Coder writes the code again, using your comment" : isWrite ? "the Rule writer writes the procedure again, using your comment" : "the agent does this step again, using your comment");
    const noChange = key === "f3_plan" || key === "errors_done";          // the plan is changed with the ticks and Add an item, not by sending it back
    buttons = `<div class="actions"><span class="msg" id="msg${r.id}"></span>
      <button class="btn quiet danger" data-act="dec" data-r="${r.id}" data-dec="reject">Stop</button>
      ${noChange ? "" : `<button class="btn act2" data-act="dec" data-r="${r.id}" data-dec="change"><span class="t">${esc(ch)}</span><span class="d">${esc(chWhat)}</span></button>`}
      <button class="btn primary act2" data-act="dec" data-r="${r.id}" data-dec="approve"${isReq || d.f4 ? ' data-confirmed="1"' : ""}><span class="t">${IC.check.replace("<svg", '<svg class="i"')}${esc(ok)}</span><span class="d">${esc(okWhat)}</span></button></div>`;
  }
  let body = bodyOf(r), extra = "";
  if (isDict) { body = ""; extra = dictionaryView(r); }
  else if (key === "f3_plan") body = "";      // the opening is written by planForm from the recording's facts
  else if (d.signals || d.outcomes) body = stripTables(body).split("\n").filter(l => !l.startsWith("Your signal:")).join("\n");
  else if (d.testfile) body = body.replace(/; a deallocate range or a measured rate given below goes into the plan\./, ".")
    .replace(/the old firmware's reproduction rate is not measured yet; run EXPECT=fault NVME_MEASURE=1 on it in the lab and give k of n here, so EXPECT=fixed knows how many clean runs prove a fix\./, "the old firmware's reproduction rate is not measured yet.");
  else if (isErrResult && plainDefects(d.columns, d.head)) {          // the defects as people read them (owner, 2026-11-10), for cards made before too
    body = stripTables(body).split("\n").filter(l => !l.startsWith("- **No.**") && !l.startsWith("- **Defect no.**") && !l.startsWith("- **Where") && !l.startsWith("- **When") && !l.startsWith("- **How serious") && l !== "How to read the table:" && !l.startsWith("Every defect below") && !l.startsWith("… ")).join("\n");
    extra = defectsTable(plainDefects(d.columns, (d.head || []).slice(0, 25)), (d.head || []).length > 25 ? (d.head || []).length : null, d.upload_id);
  }
  const joins = d.joins || (d.strategy && d.strategy.joins);
  const whyBox = !d.must_explain ? "" : `<label class="f">${key === "coder" ? "Why go on although the files lack these columns?" : "Why do you accept this tree although these rules were not followed?"} <span class="hint">· needed to approve; kept with your decision</span>
      <textarea id="why${r.id}" data-keep="why${r.id}" style="min-height:60px"></textarea></label>`;
  if ((key === "coder" || key === "last_strategy") && joins) {
    const ls = body.split("\n"), i = ls.findIndex(l => /^\*\*\d+\. /.test(l)), j = ls.findIndex(l => l.startsWith("The code that applies it"));
    const pid = v && v.run ? v.run.project : null, fresh = jrData(pid);     // the rules with the settings this analysis builds with now (they can change on this card)
    const shown = fresh ? fresh.joins.map(j => { const o = joins.find(x => x.id === j.id) || {}; return Object.assign({}, j, { evidence: o.evidence || j.evidence, agent_note: o.agent_note || j.agent_note }); }) : joins;
    const again = key === "last_strategy" && fresh;
    extra = joinsView(shown, { id: r.id, need: again ? fresh.needs_check : (d.needs_check || {}), verified: again ? fresh.verified : (d.verified || {}) }, pid) + (j >= 0 ? md(ls[j]) : "") + whyBox;
    body = (i >= 0 ? ls.slice(0, i) : ls).join("\n");
  }
  if (key === "independent" && d.join_checks) {
    body = body.replace(/\*\*How the rules for combining[\s\S]*?(?=\n\n\*\*Windows|\n\nApprove to accept)/, "");
    extra = joinChecksView(d.join_checks) + whyBox;
  }
  // who answered, in words: "The agent" for a model's answer (the program that ran it is in the tooltip)
  const whoOf = role => role.startsWith("admin:") ? "You (" + role.slice(6) + ")" : /claude code|model connection|opencode in a terminal|stand-in|haiku|sonnet|opus|claude-/i.test(role) ? "The model's answer" : role;
  // answers in this stage given before 2026-11-09 02:24 saw only the review's first text (the older design): they say so
  const rulesStage = key === "f3_plan" || key.startsWith("f3:") || key === "code" || key === "write";
  const older = c => rulesStage && !c.role.startsWith("admin:") && c.at && c.at < 1794171241
    ? `<p class="small muted" style="margin-top:6px">This answer was written from the review's first text, before the items had procedures and code: it describes the earlier way. Ask again for an answer from the current state.</p>` : "";
  // stateful (owner, 2026-11-12: "the context and message chats all should be loaded again"): what was asked and answered on this step before, in
  // every earlier round of it, stays on the card
  const said = v && v.reviews ? v.reviews.filter(x => x.step === r.step).sort((a, b) => a.id - b.id).flatMap(x => x.chat || []) : (r.chat || []);
  const chat = `<div class="chat">${said.map(c => `<div class="m ${c.role.startsWith("admin:") ? "me" : ""}"><div class="who" title="${esc(c.role.startsWith("admin:") ? "" : "answered by " + c.role)}">${esc(whoOf(c.role))}</div>${c.role.startsWith("admin:") ? esc(c.text) : md(c.text)}${older(c)}</div>`).join("")}</div>`;
  const askBox = isGate
    ? `<div class="askmgr"><div class="lbl2">Ask all the Managers</div><p class="why">Your question goes to the Admin Agent. It puts it to the Manager of every file at the same time; each Manager answers from its own data dictionary. The code then checks every column and keyword a Manager names against the data, and takes the row counts and line numbers from the Data Explorer's count of every row. Asking changes nothing in the flow.</p>${chat}
       <div class="row" style="flex-wrap:nowrap"><input type="text" id="ask${r.id}" data-keep="ask${r.id}" placeholder="for example: is there any command that timed out in this data?"><button class="btn primary" style="white-space:nowrap" data-act="ask" data-r="${r.id}" data-wait="the Managers are answering…">Ask all the Managers</button></div></div>`
    : isDict
    ? `<div class="askmgr"><div class="lbl2">Ask the Manager</div><p class="why">The Manager asks the Data Explorer about the data (it answers with counts and the lines where to see them) and the Data Grounder about meanings (it answers with where each meaning comes from).</p>${chat}
       <div class="row" style="flex-wrap:nowrap"><input type="text" id="ask${r.id}" data-keep="ask${r.id}" placeholder="for example: which rows have DLLP Type = NAK?   or: what does TLP Type mean?"><button class="btn primary" style="white-space:nowrap" data-act="ask" data-r="${r.id}">Ask the Manager</button></div></div>`
    : `<details class="more" data-id="ask${r.id}"><summary>${IC.chev}Ask the model about this decision <span class="hint" style="font-weight:400">· it only answers; nothing changes</span></summary>
      <p class="why">Behind it: your question and what this card shows${key === "f3_plan" || key.startsWith("f3:") || key === "code" || key === "write" ? ", with each chosen item's procedure and code state," : ""} are sent to the model (Haiku). It answers from them alone, below. Asking does not approve, change or stop anything.</p>${chat}
      <div class="row" style="flex-wrap:nowrap"><input type="text" id="ask${r.id}" data-keep="ask${r.id}" placeholder="${esc(key === "f3_plan" ? "for example: what happens to an item after I press Run the chosen rules?" : key === "code" || key.endsWith(":code") ? "for example: how does this code read the OPC column?" : "for example: where does this come from?")}"><button class="btn" style="white-space:nowrap" data-act="ask" data-r="${r.id}">Ask the model</button></div></details>`;
  return `<section class="decide review" id="rv${r.id}" data-review="${r.id}"><div class="lbl">Your decision · ${esc(st ? st.short : "")}</div><h3>${esc(key === "f3_plan" ? "What to look for in this recording" : r.title)}</h3>
    ${body ? md(body) : ""}${isDict ? extra.split("<!--ask-->")[0] + askBox + extra.split("<!--ask-->")[1] : extra}${isDict ? "" : dictTable}${files}${form}
    ${isDict ? "" : askBox}
    <label class="f">${d.signals ? "Your comment" : key === "f3_plan" || isGate ? "A note for the record" : "Your comment to the agent"} <span class="hint">· ${d.signals ? "the hint for the next try when you say Wrong" : key === "f3_plan" || isGate ? "optional; kept with your decision" : "needed for 'Send back with my comment'; optional otherwise"}</span></label>
    <textarea id="cm${r.id}" data-keep="cm${r.id}" style="min-height:60px"></textarea>${buttons}</section>`;
}

// stage 2: the test file, for the admin's approval (owner, 2026-11-10: "the final test script ... once it is approved")
function testfileForm(r) {
  const t = (r.data || {}).testfile || {};
  /* (owner, 2026-11-11) the "add to the plan" box (deallocate range, k of n) is gone: it confused more than it helped */
  return `<details class="more" data-id="tf-${r.id}"><summary>${IC.chev}The whole test file <span class="hint">· ${esc(t.name || "")}</span></summary>
      <p class="small muted">Saved at <code>${esc(t.path || "")}</code>, with the fixed replay library <code>f2t_nvme.py</code> beside it${(t.library || {}).version ? ` (fingerprint ${esc(t.library.version)})` : ""}. The file is the plan as data and a readable header; everything it does on a drive is in the library.</p>
      <pre style="max-height:440px;overflow:auto;font-size:12px;background:var(--surface-2);padding:10px;border-radius:8px;white-space:pre">${esc(t.text || "")}</pre></details>`;
}

/* ---- the procedural graph (owner, 2026-11-11): error -> isolation of the defect -> defect, its causes, their solutions -> test case.
   Stage 1 confirms the isolation and the defect's standard name; stage 2 shows what is stored for the defect (open a cause to see its
   solutions, open a solution to see its sequences, versions, tests and judgements) and asks for the cause, then the solution. */
const POS_WORDS = { above: "before the error", fault: "THE ERROR", below: "after the error" };
function dgSeqTable(seq, tickKey) {
  return `<div class="tbl"><table><tr>${tickKey ? "<th>keep</th>" : ""}<th>step</th><th>command</th><th>where</th><th>wait before it</th><th>why</th></tr>${(seq || []).map(x => {
    const why = Array.isArray(x.why) ? x.why.join("; ") : (x.why || "");
    const tick = tickKey ? `<td><input type="checkbox" data-dgseq="${esc(tickKey)}" data-step="${esc(x.step)}" ${x.position === "fault" ? "checked disabled" : "checked"}></td>` : "";
    return `<tr${x.position === "fault" ? ' style="background:var(--warn-soft, rgba(200,140,0,.12))"' : ""}>${tick}<td>${esc(x.step)}</td><td><b>${esc(x.command || "")}</b></td><td>${esc(POS_WORDS[x.position] || x.position || "")}</td><td>${x.gap_us != null ? nf(Math.round(x.gap_us)) + " µs" : ""}</td><td class="small">${esc(String(why).slice(0, 200))}</td></tr>`;
  }).join("")}</table></div>`;
}
function dgSolutionBlock(x, opts) {
  const o = opts || {}, first = (x.optimized || [])[0] || "no optimized sequence yet";
  const devs = (x.devices || []).map(d => `${esc(d.device)}: ${esc(d.words)}`).join("; ");
  const editor = o.edit ? `<div class="lbl2" style="margin-top:8px">Your edits (used with “with my edits”)</div>
      <p class="small muted">Untick error-sequence steps it does not need; change the optimized sequence below, one action per line.</p>
      ${dgSeqTable(x.error_seq, o.edit + "-" + x.id)}
      <textarea class="seqbox" id="dgo${esc(o.edit)}-${x.id}" data-keep="dgo${esc(o.edit)}-${x.id}">${esc((x.optimized || []).join("\n"))}</textarea>` : "";
  return `<details class="rec" data-id="dgsol-${esc(o.edit || "v")}-${x.id}" style="margin:6px 0 6px ${o.indent ? 14 : 0}px"><summary>${IC.chev}<b>Solution ${x.rank || ""}</b> · ${esc(first.slice(0, 120))} <span class="hint">· ${esc(x.judged_words)} · version ${esc(x.version)}</span></summary>
    <div style="padding:6px 0 6px 18px">
      <p class="small muted">Stored ${esc(x.created)} by ${esc(x.created_by || "")} (${esc(x.producer || "")})${x.last_judged ? `; last judged ${esc(x.last_judged)}` : ""}${devs ? `; on devices: ${devs}` : ""}.</p>
      <div class="lbl2">Error sequence · recreates the error; the test case is written from it</div>${dgSeqTable(x.error_seq)}
      <div class="lbl2" style="margin-top:8px">Optimized sequence · the solution to the problem for this cause</div>
      ${(x.optimized || []).length ? `<ol class="small">${x.optimized.map(l => `<li>${esc(l)}</li>`).join("")}</ol>` : `<p class="small muted">none written yet</p>`}
      ${x.note ? `<p class="small">${esc(x.note)}</p>` : ""}
      <p class="small muted">Versions: ${(x.versions || []).map(v => `${esc(v.version)} (${esc(v.at)}, ${esc(v.by || "")}${v.test_path ? `, test <code>${esc(v.test_path.split(/[\\/]/).pop())}</code>` : ""})`).join("; ") || "1"}.
        ${(x.verdicts || []).length ? `Judgements: ${x.verdicts.map(v => `${esc(v.signal)} by ${esc(v.by)} on ${esc(v.at)}${v.device ? ` (${esc(v.device)})` : ""}`).join("; ")}.` : "Not judged yet."}</p>
      ${editor}</div></details>`;
}
function dgOutline(view) {
  if (!view || !(view.causes || []).length) return `<p class="small muted">Nothing is stored for this defect yet: this is its first finding.</p>`;
  return `<div class="lbl2">What the procedural graph holds for “${esc(view.name)}” · open a cause, then a solution</div>` + view.causes.map(c =>
    `<details class="rec" data-id="dgc-${view.id}-${c.id}" style="margin:6px 0"><summary>${IC.chev}<b>${c.rank}. ${esc(c.header)}</b> <span class="hint">· ${esc(c.side_words)} · ${esc(c.chosen_words)} · ${c.solutions.length} solution${c.solutions.length === 1 ? "" : "s"}</span></summary>
      <div style="padding:4px 0 4px 14px">${c.solutions.length ? c.solutions.map(x => dgSolutionBlock(x, { indent: true })).join("") : `<p class="small muted">no solution stored under this cause yet</p>`}</div></details>`).join("")
    + `<p class="small muted">${esc(view.order || "")}</p>`;
}
function isolationForm(r) {
  const d = r.data || {}, id = r.id, known = d.known_defects || [];
  return `<div class="winbox" style="margin:10px 0;padding:10px 12px;border:1px solid var(--line);border-radius:10px">
    <div class="lbl2">The defect's standard name</div>
    <label class="f" style="margin:0 0 6px">This defect is<select id="dgd${id}" data-keep="dgd${id}"><option value="">choose…</option>${known.map(k => `<option value="${k.id}">${esc(k.name)} (seen ${k.seen} time${k.seen === 1 ? "" : "s"}, ${k.causes} cause${k.causes === 1 ? "" : "s"} stored)</option>`).join("")}<option value="new">a new defect, with the name below</option></select></label>
    <label class="f" style="margin:0">New standard name <span class="hint">· used only for “a new defect”; the model proposed it, edit it</span><input type="text" id="dgdn${id}" data-keep="dgdn${id}" value="${esc(d.proposed_name || "")}"></label>
    <p class="small muted" style="margin-top:6px">The name is the defect's key in the procedural graph: name it by what was observed, not by its cause or the device, so the same defect on another device or with another cause is found under it. ${known.length ? "Choose an existing name when it is the same defect." : "No defect is stored yet."}</p></div>`;
}
function causeForm(r) {
  const d = r.data || {}, id = r.id, view = d.graph || {}, pc = d.proposed_cause || {}, sides = d.sides || {};
  return dgOutline(view) + `<div class="winbox" style="margin:10px 0;padding:10px 12px;border:1px solid var(--line);border-radius:10px">
    <div class="lbl2">The cause of this occurrence</div>
    <label class="f" style="margin:0 0 6px">It is<select id="dgc${id}" data-keep="dgc${id}"><option value="">choose…</option>${(view.causes || []).map(c => `<option value="${c.id}">${esc(c.header)} (${esc(c.side)})</option>`).join("")}<option value="new">a new cause, written below</option></select></label>
    <div class="row" style="gap:10px;flex-wrap:wrap;align-items:flex-end">
      <label class="f" style="margin:0">Side of the new cause<select id="dgcs${id}" data-keep="dgcs${id}"><option value="">choose…</option>${Object.entries(sides).map(([k, w]) => `<option value="${k}" ${k === pc.side && pc.header ? "" : ""}>${esc(w)}</option>`).join("")}</select></label>
      <label class="f" style="margin:0;flex:1;min-width:260px">The new cause in one line<input type="text" id="dgch${id}" data-keep="dgch${id}" value="${esc(pc.header || "")}"></label></div>
    <p class="small muted" style="margin-top:6px">The side and the line are used only for “a new cause”. The isolation proposed: ${esc(pc.side || "")}: ${esc(pc.header || "")}.</p></div>`;
}
function solutionForm(r) {
  const d = r.data || {}, id = r.id;
  const mine = `${dgSeqTable(d.sequence, id + "-new")}
      <label class="f">The optimized sequence <span class="hint">· the solution, one action per line; ${d.optimized_by ? `proposed by ${esc(d.optimized_by)}, ` : ""}edit it before you store it</span></label>
      <textarea class="seqbox" id="dgo${id}-new" data-keep="dgo${id}-new">${esc((d.optimized || []).join("\n"))}</textarea>`;
  if (d.first) return `<div class="lbl2">The error sequence · this recording's commands that recreate the error (untick what it does not need)</div>${mine}`;
  const sols = d.solutions || [];
  return `<div class="lbl2">Stored solutions for “${esc((d.cause || {}).header || "")}”, best judged first</div>
    ${sols.map(x => dgSolutionBlock(x, { edit: String(id) })).join("")}
    <label class="f">The solution you judge<select id="dgsel${id}" data-keep="dgsel${id}"><option value="">choose…</option>${sols.map(x => `<option value="${x.id}">Solution ${x.rank}: ${esc(((x.optimized || [])[0] || "").slice(0, 90))} (${esc(x.judged_words)})</option>`).join("")}</select></label>
    <details class="more" data-id="dgnew${id}"><summary>${IC.chev}Or store this recording's sequence as a new solution <span class="hint">· then press the last button below</span></summary>${mine}</details>`;
}

// stage 1: how far to look (owner, 2026-11-10: "n number of lines from the point of x ... the admin will keep on looking at it, and he might change the values of n")
function windowForm(r) {
  const w = (r.data || {}).window || {}, c = w.counts || {};
  const lv = [["nvme_transaction", "NVMe transactions"], ["split", "split transactions"], ["link", "link transactions"], ["packets", "packets"]].filter(([k]) => c[k]).map(([k, t]) => `${nf(c[k])} ${t}`);
  const d = r.data || {}, chosen = d.chosen_by_admin === true;
  /* the defect being isolated: the one the admin chose, never one chosen for them (owner, 2026-11-11) */
  const pick = (d.defects || []).length ? `<label class="f" style="margin:0 0 8px">The defect being isolated<select id="dfi${r.id}" data-keep="dfi${r.id}">${chosen ? "" : `<option value="" selected>choose the defect…</option>`}${d.defects.map(([i, w]) => `<option value="${esc(i)}" ${chosen && String(i) === String(d.finding) ? "selected" : ""}>${esc(String(w).slice(0, 160))}</option>`).join("")}</select></label>
    ${chosen ? "" : `<p class="err small" style="margin:0 0 8px">You did not choose this defect: an earlier version of the app took the first one in the list. Choose the defect, then press Look again. No signal is stored until you do.</p>`}` : "";
  return `<div class="winbox" style="margin:10px 0;padding:10px 12px;border:1px solid var(--line);border-radius:10px">
    ${pick}
    <div class="lbl2">How far to look</div>
    <div class="row" style="gap:12px;align-items:flex-end;flex-wrap:wrap">
      <label class="f" style="margin:0">Commands above the defect (n)<input type="number" min="0" max="100" id="wn${r.id}" data-keep="wn${r.id}" value="${w.n ?? 15}" style="max-width:120px"></label>
      <label class="f" style="margin:0">Commands below it (m)<input type="number" min="0" max="100" id="wm${r.id}" data-keep="wm${r.id}" value="${w.m ?? 15}" style="max-width:120px"></label>
      <button class="btn" data-act="win" data-r="${r.id}">Look again with these numbers</button></div>
    <p class="small muted" style="margin-top:6px">${w.source ? `Now: ${esc(w.n)} above and ${esc(w.m)} below (${esc(w.source)}). ` : ""}${c.commands ? `The window holds ${nf(c.commands)} commands${c.from_history ? ` (${nf(c.from_history)} of them from earlier in the recording, kept for a stated reason)` : ""}${lv.length ? `, with ${lv.join(", ")} under them` : ""}. ` : ""}
      Looking again reads the window again from the tree, every level under these commands, adds the earlier commands the failing one depends on, and proposes again. It is not a signal: the procedural graph is not changed. Your numbers are remembered for this kind of defect.</p></div>`;
}
async function windowAgain(b) {
  const id = b.dataset.r, n = Number(($("wn" + id) || {}).value), m = Number(($("wm" + id) || {}).value), msg = $("msg" + id);
  if (!Number.isInteger(n) || !Number.isInteger(m) || n < 0 || m < 0 || n > 100 || m > 100) { msg.innerHTML = `<span class="err">above and below: whole numbers from 0 to 100</span>`; return; }
  const pk = $("dfi" + id), fid = pk ? pk.value : null;
  if (pk && fid === "") { msg.innerHTML = `<span class="err">choose the defect first: no defect is chosen for you</span>`; return; }
  if (!S.admin) { openSettings(true); return; }
  b.disabled = true; b.textContent = "looking again…";
  const edits = { window: { n, m } }; if (pk) edits.defect = Number(fid);
  try { await api("POST", `/api/agents/reviews/${id}/decide`, { decision: "change", admin: S.admin, comment: `look again: ${n} above, ${m} below`, edits }); toast(`Looking again: ${n} above, ${m} below`); await render(true); }
  catch (e) { msg.innerHTML = `<span class="err">${esc(e.message)}</span>`; b.disabled = false; b.textContent = "Look again with these numbers"; }
}

// a data dictionary: what the file is (Data Explorer), what it means (Data Grounder), where to see it (file and line)
// the colour of a status. A quote that was not found is red whatever else its words name (until 2026-11-12 "document quote not found: not
// trusted" was shown green); a meaning that rests on the model alone is set apart; a meaning with a checked source, or approved before, is green
const STATUS_CLASS = t => { t = String(t ?? ""); return /not trusted/.test(t) ? "bad" : /approved dictionary/.test(t) ? "ok" : /model/.test(t) ? "acc" : /document|web page \(checked\)|admin|contents \(checked/.test(t) ? "ok" : ""; };
// the order of the status counts, by what the words say and not by their exact text (a tool's name, a file and a day are part of some): what was
// not trusted first, then from the strongest source to the weakest, "no meaning found" last; "kept from an earlier run: …" comes right after the
// same status of this run
function statusRank(t) {
  t = String(t ?? "");
  const base = /not trusted/.test(t) ? 0 : /approved dictionary/.test(t) ? 1 : /no meaning/.test(t) ? 9
    : /model/.test(t) ? (/when the reference document was prepared/.test(t) ? 6 : 7)
    : /document/.test(t) ? 2 : /web page/.test(t) ? 3 : /admin/.test(t) ? 4 : /contents/.test(t) ? 5 : 8;
  return base + (/^kept from an earlier run: /.test(t) ? 0.5 : 0);
}
function srcText(src) {
  if (!src || !src.kind) return "";
  // (owner, 2026-11-11: "if it is taken from the web, mention that it is from the web, and store the meaning") the page and its words
  if (src.kind === "web") {
    const u = String(src.ref || ""), q = (src.quote || "").trim(), short = u.replace(/^https?:\/\//, "").replace(/\/$/, "");
    return `<b>From the web:</b> <a href="${esc(u)}" target="_blank" rel="noopener">${esc(short.length > 60 ? short.slice(0, 60) + "…" : short)}</a>` +
      (q ? `<div class="tiny muted">the page says: “${esc(q.length > 160 ? q.slice(0, 160) + "…" : q)}”</div>` : "");
  }
  if (src.kind === "data") return `<b>From its contents:</b> the column holds “${esc(String(src.quote || "").slice(0, 60))}”`;
  if (src.kind === "model") return "From the model's knowledge";
  if (src.kind === "document") {
    const w = src.where, q = (src.quote || "").trim(), o = w && w.original && w.original.title ? w.original : null;
    // a line of this application's own reference document of a tool: the public document its words were taken from is named too
    const from = !o ? "" : `<br>taken from ${/^https?:\/\//.test(o.address || "") ? `<a href="${esc(o.address)}" target="_blank" rel="noopener">${esc(o.title)}</a>` : esc(o.title)}${o.version ? `, ${esc(o.version)}` : ""}${o.where ? ` · ${esc(o.where)}` : ""}`;
    const cites = w && w.cites && w.cites.length ? "<br>cites " + esc(w.cites.join("; ")) : o ? "" : "<br>names no specification at this line";
    return `<span title="${esc(q)}">${esc(String(src.ref || "").split(/[\\/]/).pop())}</span>` + (w ? `<div class="tiny muted">${esc(w.kind)}${w.section ? ` · under “${esc(w.section)}”` : ""}${from}${cites}</div>` : "") +
      (q ? `<div class="tiny muted">“${esc(q.length > 140 ? q.slice(0, 140) + "…" : q)}”</div>` : "");
  }
  if (src.kind === "admin") return "you";
  return "model knowledge";
}
// every column of the file is accounted for by name (owner, 2026-11-10): the ones without a value, the blank spacers, the ones without a meaning
function columnsLeftOut(r, rows) {
  const d = r.data || {}, empty = d.empty || [], spacers = d.spacers || [], noMeaning = rows.filter(c => !c.meaning).map(c => c.column);
  const names = xs => `<div class="small" style="line-height:1.9">${xs.map(n => `<code>${esc(n)}</code>`).join(" · ")}</div>`;
  let h = "";
  if (noMeaning.length) h += `<div class="banner"><span>${noMeaning.length} column${noMeaning.length > 1 ? "s hold" : " holds"} a value but ${noMeaning.length > 1 ? "have" : "has"} no meaning yet: ${noMeaning.map(esc).join(", ")}. You can give one below.</span></div>`;
  if (empty.length) h += `<details class="more" data-id="empty${r.id}"><summary>${IC.chev}The ${empty.length} columns with no value in this recording</summary>
      <p class="small muted">The analyzer exports these columns, but no row of this recording fills them, so the dictionary does not describe them. If you know what one holds, give it a meaning below: it is kept with the dictionary, marked as yours.</p>${names(empty)}</details>`;
  if (spacers.length) {
    const read = rows.some(c => /^column \d+$/.test(c.column)) || empty.some(n => /^column \d+$/.test(n));
    const withValue = spacers.filter(p => rows.some(c => c.column === "column " + p));
    h += `<details class="more" data-id="spacer${r.id}"><summary>${IC.chev}The ${spacers.length} columns with no header in the file${read ? ` (${withValue.length} of them hold a value)` : ""}</summary>
      <p class="small muted">${read ? `Each is named by its position (1 = first column). ${withValue.length ? `Those that hold a value are in the table above as ${withValue.map(p => "“column " + p + "”").join(", ")}; the others are empty spacers the analyzer puts between groups of columns.` : "None of them holds a value: they are the spacers the analyzer puts between groups of columns."}` :
        "This dictionary was made before columns with no header were read, so what they hold is not described here. Their positions (1 = first column) are below; choose “Read the files again” to have them read."}</p>${names(spacers.map(p => "column " + p))}</details>`;
  }
  return h;
}
// (2026-11-12) a wide export has about 1,600 columns and 32,000 keywords: the rows of the two tables are built when their section is first
// opened, DICT_PAGE rows at a time; a table longer than that gets a box that narrows it. The counts in the headings come from the data.
const DICT_PAGE = 400;
const DICT = {};            // review id -> { d, rows, kws, at, cols: { n, q }, kw: { n, q } }: what the tables are built from, when the card was drawn, how far each is shown, what narrows it
function dictionaryView(r) {
  const d = r.data, f = d.facts || {}, rows = d.table || [];
  const nKw = rows.reduce((n, c) => n + (c.keywords || []).length, 0);
  const st = DICT[r.id] || (DICT[r.id] = { cols: { n: DICT_PAGE, q: "" }, kw: { n: DICT_PAGE, q: "" } });
  st.d = d; st.rows = rows; st.kws = null; st.at = Date.now();
  // the data of a card that left the page is let go: it was not drawn in the last minute and none of its sections is on the page
  const gone = Object.keys(DICT).filter(k => DICT[k] !== st && st.at - (DICT[k].at || 0) > 60000);
  if (gone.length) { const on = new Set([...document.querySelectorAll("details[data-dtbl]")].map(x => x.dataset.r)); gone.filter(k => !on.has(k)).forEach(k => { delete DICT[k]; }); }
  const counts = Object.entries(d.counts || {}).sort((a, b) => statusRank(a[0]) - statusRank(b[0]) || b[1] - a[1]);
  return `<div class="filebox"><div class="lbl2">What this file is</div><p class="sum">${esc(d.summary || "")}</p>
      <div class="facts"><span class="pill">${nf(f.rows)} rows</span><span class="pill">${nf(f.columns_with_values)} of ${nf(f.columns_in_file)} columns hold values</span><span class="pill">${nf(f.keywords)} special keywords</span>${f.level ? `<span class="pill">${esc(f.level)} level</span>` : ""}</div>
      <div class="mt">Every row was read by code${f.seconds_reading !== undefined ? ` (${f.seconds_reading} s)` : ""} · the file: <code>${esc(d.path || "")}</code></div>
      ${d.kind_of_row && d.kind_of_row.text ? `<div class="mt" style="margin-top:6px"><b>The kinds of row.</b> ${esc(d.kind_of_row.text)} A column that only some kinds of row fill says so in the table below ("Which rows fill it"), counted on every row.</div>` : ""}</div>
    <div class="facts" style="margin:12px 0 4px">${counts.map(([k, n]) => `<span class="pill ${STATUS_CLASS(k)}">${n} · ${esc(k)}</span>`).join("")}</div>
    <!--ask-->
    <details class="more" data-id="cols${r.id}" data-dtbl="cols" data-r="${r.id}"><summary>${IC.chev}The ${rows.length} columns that hold values: what the data holds, what it means</summary><div data-dbox></div></details>
    ${columnsLeftOut(r, rows)}
    ${nKw ? `<details class="more" data-id="kw${r.id}" data-dtbl="kw" data-r="${r.id}"><summary>${IC.chev}The ${nKw} special keywords (the words the columns hold) and what each means</summary><div data-dbox></div></details>` : ""}
    <details class="more" data-id="mem${r.id}"><summary>${IC.chev}Where the agents keep what they know</summary>
      <div class="mt" style="margin-top:6px">Data Explorer (the data): <code>${esc((d.memories || {}).explorer || "")}</code><br>Data Grounder (the meanings): <code>${esc((d.memories || {}).grounder || "")}</code><br>Manager (the dictionary): <code>${esc((d.memories || {}).dictionary || "")}</code></div></details>`;
}
// the rows of one of the two tables ("cols": the columns, "kw": the keywords) as far as it is shown now, and what is left under it
function dictRowsHtml(id, which) {
  const st = DICT[id]; if (!st || !st.rows) return "";
  const d = st.d || {}, u = st[which], lineOf = w => esc((w || "").replace(d.path + " ", ""));
  if (which === "kw" && !st.kws) st.kws = st.rows.flatMap(c => (c.keywords || []).map(k => Object.assign({ column: c.column }, k)));
  const all = which === "cols" ? st.rows : st.kws, what = which === "cols" ? "columns" : "keywords";
  const q = all.length > DICT_PAGE ? String(u.q || "").trim() : "", ql = q.toLowerCase();
  const has = x => (which === "cols" ? [x.column, x.meaning, x.status] : [x.column, x.value, x.meaning]).some(t => String(t ?? "").toLowerCase().includes(ql));
  const hit = q ? all.filter(has) : all, shown = hit.slice(0, u.n), left = hit.length - shown.length;
  const head = which === "cols" ? `<tr><th>column</th><th>in the data (Data Explorer)</th><th>what it means (Data Grounder)</th><th>from</th><th>see it at</th></tr>` : `<tr><th>column</th><th>keyword</th><th>what it means</th><th>from</th><th>first at</th></tr>`;
  const row = which === "cols"
    ? c => `<tr><td><b>${esc(c.column)}</b></td><td>${esc(c.observed)}${c.filled_for ? `<div class="small muted" style="margin-top:4px"><b>Which rows fill it:</b> ${esc(c.filled_for)}</div>` : ""}</td><td>${esc(c.meaning || "—")}<div class="tiny"><span class="pill ${STATUS_CLASS(c.status)}">${esc(c.status)}</span></div></td><td class="small">${srcText(c.source)}</td><td class="small"><code>${lineOf(c.where)}</code></td></tr>`
    : k => `<tr><td>${esc(k.column)}</td><td><b>${esc(k.value)}</b></td><td>${esc(k.meaning || "—")}</td><td class="small">${k.meaning ? srcText(k.source) : ""}</td><td class="small"><code>${lineOf(k.where)}</code></td></tr>`;
  const said = q ? `${nf(hit.length)} of the ${nf(all.length)} ${what} hold “${esc(q)}”${left ? `; the first ${nf(shown.length)} are shown` : ""}.` : left ? `The first ${nf(shown.length)} of the ${nf(hit.length)} ${what} are shown.` : "";
  const more = left ? `<button class="btn small" data-act="dict-more" data-r="${esc(id)}" data-t="${which}">Show ${nf(Math.min(DICT_PAGE, left))} more</button><button class="btn small quiet" data-act="dict-more" data-r="${esc(id)}" data-t="${which}" data-all="1">Show all ${nf(hit.length)}</button>` : "";
  return (shown.length ? `<div class="tbl"><table>${head}${shown.map(row).join("")}</table></div>` : "") + (said || more ? `<div class="row small muted" style="margin:6px 0 2px"><span>${said}</span>${more}</div>` : "");
}
function dictFill(det) {
  const box = det.querySelector("[data-dbox]"), id = det.dataset.r, which = det.dataset.dtbl, st = DICT[id];
  if (!box || box.dataset.built || !st || !st.rows || !st[which]) return;
  const n = which === "cols" ? st.rows.length : st.rows.reduce((k, c) => k + (c.keywords || []).length, 0);
  const find = n > DICT_PAGE ? `<input type="text" data-dq="${which}" data-r="${esc(id)}" value="${esc(st[which].q)}" style="margin-top:8px" placeholder="${which === "cols"
    ? "show only the columns that hold these letters in the name, in the meaning or in where the meaning comes from" : "show only the keywords that hold these letters in the column name, in the keyword or in its meaning"}">` : "";
  box.innerHTML = find + `<div data-dbody>${dictRowsHtml(id, which)}</div>`;
  box.dataset.built = "1";
}
function dictMore(b) {
  const st = DICT[b.dataset.r], u = st ? st[b.dataset.t] : null, body = b.closest("[data-dbody]"); if (!u || !body) return;
  u.n = b.dataset.all ? Infinity : u.n + DICT_PAGE;
  body.innerHTML = dictRowsHtml(b.dataset.r, b.dataset.t);
}
// the rows are built just before the section opens (a click or a key on its heading), and at the latest when it has opened
document.addEventListener("click", e => { const s = e.target && e.target.closest ? e.target.closest("summary") : null, d = s ? s.parentElement : null; if (d && d.dataset && d.dataset.dtbl && !d.open) dictFill(d); }, true);
document.addEventListener("toggle", e => { const d = e.target; if (d && d.dataset && d.dataset.dtbl && d.open) dictFill(d); }, true);
document.addEventListener("input", e => {
  const x = e.target; if (!x || !x.dataset || !x.dataset.dq) return;
  const st = DICT[x.dataset.r], u = st ? st[x.dataset.dq] : null, box = x.closest("[data-dbox]"), body = box ? box.querySelector("[data-dbody]") : null; if (!u || !body) return;
  u.q = x.value; u.n = DICT_PAGE;
  body.innerHTML = dictRowsHtml(x.dataset.r, x.dataset.dq);
});
function stripTables(text) { return String(text || "").split("\n").filter(l => !l.trim().startsWith("|")).join("\n"); }
// The rules that combine the five files. With rv the admin is deciding: each rule that needs it has a tick. Without it the list is for reading.
function joinsView(joins, rv, pid) {
  const wbd = pid && S.jr && S.jr.pid === pid ? S.jr.data : null;
  const day = t => new Date((t || 0) * 1000).toLocaleDateString();
  return `<div class="joins">` + joins.map((jn, i) => {
    const ev = jn.evidence || [], ok = ev.filter(e => e.verified).length, map = jn.column_map, c = jn.code;
    const v = rv && rv.verified ? rv.verified[jn.id] : null, why = rv && rv.need ? rv.need[jn.id] : null;
    const tick = !jn.id || !rv ? "" : rv.id && (why || !v)
      ? `<label class="jcheck"><input type="checkbox" data-jr="${rv.id}" value="${esc(jn.id)}"> I checked this rule${why && v ? ` <span class="hint">· ${esc(why)}</span>` : ""}</label>`
      : v && !why ? `<div class="jok">${IC.check.replace("<svg", '<svg class="i"')} Checked by ${esc(v.by)} on ${day(v.at)}</div>` : `<div class="jno">${esc(why || "Not checked yet")}</div>`;
    return `<div class="join"><div class="jn">${i + 1}</div><div class="jb"><div class="jt">${esc(jn.title || jn.join.replace("->", "→"))}</div>
      ${jn.from ? `<div class="mt">${jn.from.map(f => `<code>${esc(f)}</code>`).join(" and ")} into <code>${esc(jn.to)}</code></div>` : ""}
      ${map ? `<div class="jcols">${Object.entries(map).map(([f, cs]) => `<div><span class="mt">${esc(f)}</span> ${cs.map(x => `<span class="colchip">${esc(x)}</span>`).join("")}</div>`).join("")}</div>`
            : `<div class="cols">${(jn.columns || []).map(x => `<span class="colchip">${esc(x)}</span>`).join("")}</div>`}
      ${jn.steps ? `<ol class="jsteps">${jn.steps.map(x => `<li>${esc(x)}</li>`).join("")}</ol>` : `<p>${esc(jn.rule)}</p>`}
      <div class="mt"><b>Check:</b> ${esc(jn.check || "")}</div>
      ${jn.when_broken ? `<div class="jwhen"><b>If a row does not follow this rule</b><ul>${jn.when_broken.map(x => `<li>${esc(x)}</li>`).join("")}</ul></div>` : ""}
      ${jn.agent_note ? `<div class="jnote"><b>The agent's doubt:</b> ${esc(jn.agent_note)}</div>` : ""}
      ${c ? `<div class="mt">The code: <code>${esc(c.file)}</code> lines ${c.first} to ${c.last}, function <code>${esc(c.function)}</code></div>` : ""}
      ${ev.length ? `<details class="more" style="margin-top:4px"><summary>${IC.chev}Evidence (${ev.length}, ${ok} checked by the code)</summary><ul class="ev">${ev.map(e => `<li><span class="pill ${e.verified ? "ok" : "warn"}">${esc(e.kind)}${e.verified ? "" : ", not verified"}</span> ${esc(e.quote || "")} <span class="mt">${esc((e.ref || "").split("/").pop())}</span></li>`).join("")}</ul></details>` : ""}
      ${wbd ? yourVersion(jn, pid, wbd) : ""}
      ${tick}
      ${wbd ? jwBlock(jn, pid, wbd) : ""}
    </div></div>`;
  }).join("") + `</div>`;
}
// page 2's rules for one analysis, fetched once and kept (they change when the admin changes a setting, keeps a note or asks)
function jrData(pid) {
  if (!pid) return null;
  if (!S.jr || S.jr.pid !== pid) {
    S.jr = { pid, data: null };
    api("GET", `/api/agents/projects/${pid}/join_rules`).then(d => { if (S.jr && S.jr.pid === pid) { S.jr.data = d; render(); } }).catch(() => {});
  }
  return S.jr.data;
}
// the admin's own wording of a rule, and the editor (owner, 2026-11-10: "these rules can be edited and saved properly"; then: Save seemed to go
// "back to the program's version"). The fixes: Save is off until something changed, and says what changed; nothing moves when it saves (your version is
// drawn under the editor); going back is a separate, confirmed step; the saved file is named.
function jwLines(v) { return String(v || "").split("\n").map(x => x.trim()).filter(Boolean); }
function jwBaseOf(jn, t) { return t ? { steps: t.steps || [], check: t.check || "", when_broken: t.when_broken || [], what: `your version ${t.v}` }
                                    : { steps: jn.steps || [], check: jn.check || "", when_broken: jn.when_broken || [], what: "the program's version" }; }
// what the editor changes against the version it was opened on, in words
function jwChanges(base, now) {
  const out = [], pl = (n, w) => `${n} ${w}${n > 1 ? "s" : ""}`;
  const added = now.steps.filter(x => !base.steps.includes(x)), gone = base.steps.filter(x => !now.steps.includes(x));
  const re = Math.min(added.length, gone.length);              // a step changed in place counts once, as reworded
  if (re) out.push(`${pl(re, "step")} reworded`);
  if (added.length > re) out.push(`${pl(added.length - re, "new step")}`);
  if (gone.length > re) out.push(`${pl(gone.length - re, "step")} taken out`);
  if (!added.length && !gone.length && now.steps.join("\n") !== base.steps.join("\n")) out.push("the order of the steps");
  if (now.check.trim() !== String(base.check || "").trim()) out.push("the check");
  if (now.when_broken.join("\n") !== (base.when_broken || []).join("\n")) out.push("what happens to a row that does not follow");
  return out;
}
function jwEditorNow(k) { return { steps: jwLines(($("jwt-" + k) || {}).value), check: (($("jwc-" + k) || {}).value || "").trim(), when_broken: jwLines(($("jwb-" + k) || {}).value) }; }
// the live line under the editor and the Save button follow every key press
function jwEditCheck(k) {
  const base = (S.jwBase || {})[k], out = $("jwd-" + k), btn = document.querySelector(`[data-act="jw-text"][data-k="${CSS.escape(k)}"]`);
  if (!base || !out || !btn) return;
  const now = jwEditorNow(k), ch = jwChanges(base, now);
  const why = !now.steps.length ? `<span class="err">Write at least one step.</span>`
    : ch.length ? `<span class="okc">Changed against ${esc(base.what)}: ${ch.map(esc).join("; ")}.</span>`
    : `<span class="muted">Nothing changed yet against ${esc(base.what)}. Change a step, the check or a line, then save.</span>`;
  out.innerHTML = why;
  btn.disabled = !now.steps.length || !ch.length || !!S.jwBusy;
}
function yourVersion(jn, pid, d) {
  const t = (d.texts || {})[jn.id], n = (d.text_versions || {})[jn.id] || 0, k = `${pid}-${jn.id}`, kk = `${k}-v${n}`;   // the version count in the keep names: after a save or going back, the editor opens on what is in force
  const base = jwBaseOf(jn, t); (S.jwBase = S.jwBase || {})[k] = base;
  const prog = jn.steps || [], paths = d.paths || {}, folder = (paths.rules || {})[jn.id], code = (paths.code || {})[jn.id];
  const saved = (S.jwSaved || {})[k];
  const state = t
    ? `<div class="jstate"><b>Your version ${t.v} is saved</b> <span class="hint">· by ${esc(t.by || "?")}, ${new Date(t.at * 1000).toLocaleString()}</span><br>
        <span class="small">The tree is still built by the program's code${jn.code ? ` (<code>${esc(jn.code.file)}</code> lines ${jn.code.first} to ${jn.code.last})` : ""}: code for your version is not written yet.</span></div>`
    : `<div class="jstate"><b>In force: the program's version</b> <span class="hint">· ${n ? `${n} version${n > 1 ? "s" : ""} of yours kept, none in force` : "no version of yours yet"}</span><br>
        <span class="small">The tree is built by the program's code${jn.code ? ` (<code>${esc(jn.code.file)}</code> lines ${jn.code.first} to ${jn.code.last})` : ""}.</span></div>`;   // two lines either way, so nothing below moves when a version is saved
  const diff = t ? `<div class="jnote"><b>Your version ${t.v}, against the program's</b>${t.why ? ` <span class="hint">· ${esc(t.why)}</span>` : ""}
      <ol class="jsteps">${(t.steps || []).map(x => `<li${prog.includes(x) ? "" : ' class="okc"'}>${esc(x)}${prog.includes(x) ? "" : ' <span class="hint">· yours</span>'}</li>`).join("")}</ol>
      ${prog.filter(x => !(t.steps || []).includes(x)).map(x => `<div class="small muted" style="text-decoration:line-through">${esc(x)}</div>`).join("")}
      ${(t.check || "") !== (jn.check || "") ? `<div class="mt"><b>Your check:</b> ${esc(t.check)}</div>` : ""}${(t.when_broken || []).join("\n") !== (jn.when_broken || []).join("\n") ? `<div class="jwhen"><b>Your lines for a row that does not follow</b><ul>${(t.when_broken || []).map(x => `<li>${esc(x)}</li>`).join("")}</ul></div>` : ""}</div>` : "";
  const box = `<details class="more" data-id="jwe-${esc(k)}"><summary>${IC.chev}Edit this rule's words${n ? ` <span class="hint">· ${n} version${n > 1 ? "s" : ""} kept</span>` : ""}</summary>
      <p class="small muted">You are editing ${esc(base.what)}. Saving keeps a new numbered version with your name and the time; nothing is overwritten.</p>
      <label class="f">The steps, one per line (IF … THEN …)</label><textarea id="jwt-${esc(k)}" data-jwed="${esc(k)}" data-keep="jwt-${esc(kk)}" style="min-height:140px">${esc(base.steps.join("\n"))}</textarea>
      <label class="f">The check (how a row is known to follow the rule)</label><input type="text" id="jwc-${esc(k)}" data-jwed="${esc(k)}" data-keep="jwc-${esc(kk)}" value="${esc(base.check)}">
      <label class="f">What happens to a row that does not follow it, one per line</label><textarea id="jwb-${esc(k)}" data-jwed="${esc(k)}" data-keep="jwb-${esc(kk)}" style="min-height:70px">${esc(base.when_broken.join("\n"))}</textarea>
      <label class="f">Why you change it <span class="hint">· kept with this version</span></label><input type="text" id="jwy-${esc(k)}" data-keep="jwy-${esc(kk)}" placeholder="for example: a TLP can be far ahead of its link row when the analyzer dropped rows">
      <div class="small" id="jwd-${esc(k)}" style="margin-top:6px"></div>
      <div class="actions" style="justify-content:flex-start"><button class="btn small primary" data-act="jw-text" data-k="${esc(k)}" data-pid="${pid}" data-rule="${esc(jn.id)}" disabled>Save as version ${n + 1}</button>
        <span class="msg" id="jwtm-${esc(k)}">${saved ? `<span class="okc">${esc(saved)}</span>` : ""}</span></div>
      ${folder ? `<p class="small muted">Your versions are kept in <code>${esc(folder)}/</code>: one file per version (<code>v1.json</code>, <code>v2.json</code> …) and <code>current.json</code> for the one in force.${code ? ` Code written for a version will go in <code>${esc(code)}/</code>.` : ""}</p>` : ""}
      <div class="lbl2" style="margin-top:8px">What a saved version does</div>
      <ol class="small" style="margin:4px 0 0;padding-left:18px">
        <li>Your words are kept, and they go to the research (Research again) and to the Coder, beside the program's.</li>
        <li>The tree is still built by the program's code${jn.code ? ` in <code>${esc(jn.code.file)}</code>, function <code>${esc(jn.code.function)}</code>` : ""}. Words alone do not change how the files are joined.</li>
        <li>To change the joining itself, code must be written for your version, tried on this recording and approved by you. Until then the program's code stays in force.</li></ol>
      ${diff}
      ${t ? `<div class="actions" style="justify-content:flex-start;margin-top:10px;border-top:1px solid var(--line, #ddd);padding-top:8px"><span class="small muted">Your version ${t.v} is not wanted any more?</span>
        <button class="btn small quiet" data-act="jw-text-reset" data-k="${esc(k)}" data-v="${t.v}" data-pid="${pid}" data-rule="${esc(jn.id)}">Go back to the program's version…</button></div>` : ""}
    </details>`;
  setTimeout(() => jwEditCheck(k), 0);
  return state + box;
}
// going back is asked once more, and says what stays
function confirmBack(pid, rule, k, v) {
  openModal(`<div class="mhead"><h2>Go back to the program's version of this rule?</h2><button class="btn quiet small" data-act="close">Close</button></div>
    <p>Your version ${esc(v)} stops being the one in force. It is not deleted: every version stays in its file, and going back is kept as a version too.</p>
    <div class="actions"><span class="msg" id="back-msg"></span><button class="btn quiet" data-act="close">Keep my version</button><button class="btn danger" id="back-go">Go back to the program's version</button></div>`);
  document.querySelectorAll('#modal [data-act="close"]').forEach(x => x.onclick = closeModal);
  $("back-go").onclick = async () => {
    $("back-go").disabled = true;
    try { S.jr = { pid: +pid, data: await api("PUT", `/api/agents/projects/${pid}/join_rules/${rule}/text`, { steps: [], why: "back to the program's version", admin: S.admin }) };
          (S.jwSaved = S.jwSaved || {})[k] = `Back to the program's version. Your version ${v} is still kept.`; closeModal(); toast("The program's version is in force again"); render(true); }
    catch (e) { $("back-msg").innerHTML = `<span class="err">${esc(e.message)}</span>`; $("back-go").disabled = false; }
  };
}
// one rule: change its settings, try them on this recording, keep a note on its logic, ask an agent that can look at the data (owner, 2026-11-10)
function jwBlock(jn, pid, d) {
  const sets = jn.settings || [], chat = (d.chat || {})[jn.id] || [], note = (d.notes || {})[jn.id], job = d.try_job, tree = d.tree;
  const busy = job && (job.status === "running" || job.status === "queued");
  const tr = (d.tries || []).slice(-1)[0], k = `${pid}-${jn.id}`;
  const setForm = sets.length ? sets.map(s => `<label class="f">${esc(s.label)} <span class="hint">· now ${nf(s.value)}; the program's default ${nf(s.default)}; from ${nf(s.min)} to ${nf(s.max)} ${esc(s.unit)}</span></label>
      <input type="number" min="${s.min}" max="${s.max}" value="${s.value}" data-jwset="${esc(k)}" data-key="${esc(s.key)}" data-keep="jwv-${esc(k)}-${esc(s.key)}" style="max-width:180px">
      <p class="small muted">${esc(s.why)}</p>`).join("")
    : `<p class="small muted">This rule has no number to change: what it joins is program code. If its logic should change, write it in the note below.</p>`;
  const tried = tr && tr.after && tr.after[jn.id] ? (() => {
    const b = (tr.before || {})[jn.id] || { checks: [] }, a = tr.after[jn.id];
    return `<div class="lbl2" style="margin-top:8px">The last try, by ${esc(tr.by || "?")}, with ${Object.entries(tr.settings || {}).map(([x, y]) => esc(x) + " " + nf(y)).join(", ")}</div>
      <div class="tbl"><table><tr><th>what was checked</th><th>before: did not follow</th><th>after: did not follow</th><th>of</th></tr>${a.checks.map((c, i) => { const p = (b.checks || [])[i] || {};
        return `<tr><td>${esc(c.words)}</td><td>${nf(p.broke)}</td><td><b>${nf(c.broke)}</b></td><td>${nf(c.of)}</td></tr>`; }).join("")}</table></div>
      <p class="small muted">The tree of this recording is now built with these settings. Approving the strategy keeps them; to go back, put back the old numbers and try again.</p>`; })() : "";
  const jobLine = busy ? `<div class="small" style="margin-top:6px">${progressView({ note: (job.progress || {}).detail || "starting", started: null }, "trying…")}</div>`
    : job && job.status === "failed" ? `<div class="err">The last try failed: ${esc(job.error || "")}</div>` : "";
  const talk = chat.map(m => m.who === "admin" ? `<div class="msg me"><b>${esc(m.by || "you")}:</b> ${esc(m.text)}</div>`
    : `<div class="msg"><b>Agent</b> <span class="hint">· ${esc(plainProducer(m.by))}</span><div>${esc(m.text)}</div>
        ${(m.queries || []).length ? `<details class="more"><summary>${IC.chev}The ${m.queries.length} quer${m.queries.length > 1 ? "ies" : "y"} it ran on this recording</summary>${m.queries.map(q => `<div class="mt"><code>${esc(q.sql)}</code></div>${q.error ? `<div class="err small">${esc(q.error)}</div>` : `<div class="tbl"><table><tr>${(q.columns || []).map(c => `<th>${esc(c)}</th>`).join("")}</tr>${(q.rows || []).slice(0, 12).map(r => `<tr>${r.map(v => `<td>${esc(v === null ? "" : String(v))}</td>`).join("")}</tr>`).join("")}</table></div>${q.more_rows || (q.rows || []).length > 12 ? `<div class="small muted">more rows not shown</div>` : ""}`}`).join("")}</details>` : ""}
        ${m.proposed_settings && Object.keys(m.proposed_settings).length ? `<div class="mt">It proposes: ${Object.entries(m.proposed_settings).map(([x, y]) => `<code>${esc(x)} = ${nf(y)}</code>`).join(", ")} <button class="btn small" data-act="jw-use" data-pid="${pid}" data-rule="${esc(jn.id)}" data-set='${esc(JSON.stringify(m.proposed_settings))}'>Put these in the settings</button></div>` : ""}
        ${m.logic_change ? `<div class="jnote"><b>A change to the logic it suggests:</b> ${esc(m.logic_change)}</div>` : ""}</div>`).join("");
  return `<details class="more jw" data-id="jw-${esc(k)}"><summary>${IC.chev}Change, try and discuss this rule</summary>
    <div class="lbl2" style="margin-top:6px">Settings</div>${setForm}
    ${sets.length ? `<div class="actions" style="justify-content:flex-start"><span class="msg" id="jwm-${esc(k)}"></span>
      <button class="btn small" data-act="jw-save" data-pid="${pid}" data-rule="${esc(jn.id)}" ${busy ? "disabled" : ""}>Keep these settings</button>
      <button class="btn small primary" data-act="jw-try" data-pid="${pid}" data-rule="${esc(jn.id)}" ${busy || !tree ? "disabled" : ""} title="${tree ? "builds this recording's tree again with these settings and compares" : "no tree of this recording yet"}">Try them on this recording</button></div>
      ${!tree ? `<p class="small muted">There is no tree of these files yet: the try is offered once the tree is built (later on this page). Settings kept now are used for that build.</p>` : `<p class="small muted">A try builds the tree of these files again with these settings${tree.own ? "" : " (the tree built before from these same files, which this analysis then uses)"} and shows, for each check, how many rows did not follow before and after. A changed setting asks for this rule to be checked again.</p>`}` : ""}
    ${jobLine}${tried}
    <div class="lbl2" style="margin-top:10px">Ask an agent about this rule</div>
    <p class="small muted">It sees the rule, the code that applies it and how it held, and ${tree ? `it may run read-only queries on the tree of these files${tree.own ? "" : " built before from the same files"} (at most 3 rounds of 3) before it answers` : "no tree of these files exists yet, so it answers from the rule and the code only"}. It can propose settings; it changes nothing itself.</p>
    <div class="chat">${talk}</div>
    <div class="row" style="flex-wrap:nowrap;gap:8px"><input type="text" id="jwq-${esc(k)}" data-keep="jwq-${esc(k)}" placeholder="for example: how far apart are a TLP and its row in link.csv on this recording?"><button class="btn small" data-act="jw-ask" data-pid="${pid}" data-rule="${esc(jn.id)}">Ask the agent</button></div>
    <div class="lbl2" style="margin-top:10px">Your note on this rule's logic</div>
    <p class="small muted">For a change the settings cannot make (what is joined to what). It is kept with this analysis, given to the research when you choose "Research again", and is for the developer of <code>nvme_hier/builder.py</code>: the logic itself does not change by itself.</p>
    <textarea id="jwn-${esc(k)}" data-keep="jwn-${esc(k)}" style="min-height:54px" placeholder="what should this rule do differently, and why">${esc(note ? note.text : "")}</textarea>
    <div class="actions" style="justify-content:flex-start"><button class="btn small" data-act="jw-note" data-pid="${pid}" data-rule="${esc(jn.id)}">Keep my note</button>${note ? `<span class="hint">kept by ${esc(note.by || "?")} on ${new Date(note.at * 1000).toLocaleString()}</span>` : ""}</div>
  </details>`;
}
async function jwAct(act, b) {
  const pid = b.dataset.pid, rule = b.dataset.rule, k = `${pid}-${rule}`, msg = $("jwm-" + k);
  const said = t => { if (msg) msg.innerHTML = t; else toast(t.replace(/<[^>]+>/g, "")); };
  const settings = {}; document.querySelectorAll(`[data-jwset="${k}"]`).forEach(x => { settings[x.dataset.key] = x.value; });
  try {
    if (act === "jw-use") { const p = JSON.parse(b.dataset.set || "{}"); Object.entries(p).forEach(([x, y]) => { const el = document.querySelector(`[data-jwset="${k}"][data-key="${x}"]`); if (el) el.value = y; }); toast("Put in the settings: press Keep or Try"); return; }
    if (act === "jw-save") { S.jr = { pid: +pid, data: await api("PUT", `/api/agents/projects/${pid}/join_rules/settings`, { settings, admin: S.admin }) }; toast("Kept: this rule asks to be checked again"); render(true); return; }
    if (act === "jw-try") { b.disabled = true; const x = await api("POST", `/api/agents/projects/${pid}/join_rules/try`, { settings, admin: S.admin }); S.jr = { pid: +pid, data: x.view }; render(true); jwPoll(+pid); return; }
    if (act === "jw-text-reset") return confirmBack(pid, rule, k, b.dataset.v);
    if (act === "jw-text") {
      if (S.jwBusy) return;                                   // one save at a time: a second press while the first is on its way does nothing
      const now = jwEditorNow(k), ch = jwChanges((S.jwBase || {})[k] || now, now), tm = $("jwtm-" + k);
      if (!now.steps.length || !ch.length) { jwEditCheck(k); return; }
      S.jwBusy = true; b.disabled = true; b.textContent = "saving…";
      try {
        const x = await api("PUT", `/api/agents/projects/${pid}/join_rules/${rule}/text`, Object.assign(now, { why: ($("jwy-" + k) || {}).value || "", admin: S.admin }));
        const v = (x.text_versions || {})[rule];
        (S.jwSaved = S.jwSaved || {})[k] = `Saved as your version ${v} (${ch.join("; ")}) in ${x.saved || "its file"}.`;
        S.jr = { pid: +pid, data: x }; toast(`Saved as your version ${v}`);
      } catch (e) { if (tm) tm.innerHTML = `<span class="err">${esc(e.message)}</span>`; S.jwBusy = false; b.textContent = `Save as version ${((S.jr && S.jr.data && S.jr.data.text_versions) || {})[rule] + 1 || 1}`; jwEditCheck(k); return; }
      finally { S.jwBusy = false; }
      render(true); return;
    }
    if (act === "jw-note") { const text = ($("jwn-" + k) || {}).value || ""; S.jr = { pid: +pid, data: await api("PUT", `/api/agents/projects/${pid}/join_rules/${rule}/note`, { text, admin: S.admin }) }; toast(text.trim() ? "Note kept" : "Note removed"); render(true); return; }
    if (act === "jw-ask") {
      const q = ($("jwq-" + k) || {}).value || ""; if (!q.trim()) { $("jwq-" + k).focus(); return; }
      const label = b.textContent; b.disabled = true; b.textContent = "the agent is looking at the data…";
      try { const x = await api("POST", `/api/agents/projects/${pid}/join_rules/${rule}/ask`, { message: q, admin: S.admin }); if (S.jr && S.jr.data) S.jr.data.chat[rule] = x.chat; $("jwq-" + k).value = ""; render(true); }
      finally { b.disabled = false; b.textContent = label; }
    }
  } catch (e) { said(`<span class="err">${esc(e.message)}</span>`); b.disabled = false; }
}
function jwPoll(pid) {
  if (S.jwPoll) return;
  S.jwPoll = setInterval(async () => {
    try {
      const d = await api("GET", `/api/agents/projects/${pid}/join_rules`); S.jr = { pid, data: d }; render(true);
      if (!d.try_job || !["running", "queued"].includes(d.try_job.status)) { clearInterval(S.jwPoll); S.jwPoll = null; toast(d.try_job && d.try_job.status === "failed" ? "The try failed" : "The try is done: compare before and after"); }
    } catch (e) { clearInterval(S.jwPoll); S.jwPoll = null; }
  }, 2000);
}
// How each rule held on this recording, with example rows of what did not follow it
function joinChecksView(c) {
  const lab = { followed: ["ok", "followed"], few: ["warn", "a few rows did not follow"], broken: ["bad", "NOT followed"], not_run: ["", "no such file"] };
  return `<div class="jchecks"><div class="lbl2">How the rules for combining the files held on this recording</div>
    <p class="why">${esc(c.summary)} Above ${c.limit_percent}% of the rows a rule counts as not followed: that limit is a project setting, not a number from a specification.</p>` + c.rules.map(r => {
    const [cls, word] = lab[r.verdict] || lab.not_run;
    return `<details class="more" data-id="jc-${esc(r.id)}" ${r.verdict === "broken" ? "open" : ""}><summary>${IC.chev}<span class="pill ${cls}">${esc(word)}</span> ${esc(r.title)}</summary>
      <div class="tbl"><table><tr><th>what was checked</th><th>did not follow</th><th>of</th><th>share</th></tr>${r.checks.map(k => `<tr><td>${esc(k.words)}${k.information_only ? ' <span class="hint">· for information</span>' : ""}</td><td>${nf(k.broke)}</td><td>${nf(k.of)}</td><td>${k.percent}%</td></tr>`).join("")}</table></div>
      ${r.checks.filter(k => (k.examples || []).length).map(k => `<div class="mt" style="margin-top:6px"><b>Examples in <code>${esc(k.file)}</code>:</b> ${esc(k.words)}</div><div class="tbl"><table><tr>${Object.keys(k.examples[0]).map(n => `<th>${esc(n)}</th>`).join("")}</tr>${k.examples.map(e => `<tr>${Object.values(e).map(x => `<td>${esc(x === null ? "" : x)}</td>`).join("")}</tr>`).join("")}</table></div>`).join("")}
      ${r.verdict === "followed" ? "" : `<div class="jwhen"><b>What the tree did with those rows</b><ul>${(r.when_broken || []).map(x => `<li>${esc(x)}</li>`).join("")}</ul></div>`}</details>`;
  }).join("") + `</div>`;
}
// Page 2, always: the rules, who checked them, and how they held on this recording
function joinRulesPanel(x, v, ind) {
  const pid = v.run.project;
  const d = jrData(pid);
  if (!d) return "";
  const open = Object.keys(d.needs_check || {}).length > 0;
  return `<section class="card"><details class="more" data-id="joinrules" ${open ? "open" : ""}><summary>${IC.chev}<b>How the five files are combined</b> <span class="hint">· ${d.joins.length} rules, ${d.joins.length - Object.keys(d.needs_check || {}).length} checked by the admin</span></summary>
    <p class="why">The tree is built by these rules and nothing else. Each one is what the code does, and each is checked by the admin when the strategy is reviewed.</p>
    ${joinsView(d.joins, { verified: d.verified || {}, need: d.needs_check || {} }, pid)}</details>
    ${ind && ind.join_checks ? joinChecksView(ind.join_checks) : ""}</section>`;
}
// ------------------------------------------------------------------ the rules browser (owner, 2026-11-09)
// A sidebar of sections, each with its levels: one click shows the items of one level. Sections are data: the admin adds
// one with what it is for and whether its items find defects. Opening an item shows its evidence, each part from its own
// source: what it checks (the rule file), where the rule comes from (specification, analyzer manual, admin's limit), the
// file columns it reads with Family 1's meanings and where each meaning comes from, how it decides, the lines of the
// code that decide, and what it found in this data with the exact cells it read. Used by the plan review (with ticks)
// and by the rules library (without).
const RB = {};
const rbState = id => RB[id] || (RB[id] = { tree: null, levels: {}, note: "", counts: {}, sel: null, open: null, ticks: null, ex: {}, up: null, mode: "plan", q: "", loading: false });
const rbKey = (sec, lvl, rid) => `${sec}/${lvl}/${rid}`;
function rbTreeFromReview(d) {
  const LV = ["nvme_command", "nvme_transaction", "link", "split", "packets", "other"];      // "other": CSV files that are not analyzer exports
  return Object.entries(d.sections || {}).map(([sec, label], i) => ({ section: sec, label, name: label.replace(/^Section \d+ · /, ""), about: "", defects: sec === "errors", number: i + 1,
    levels: LV.map(l => ({ level: l, label: (d.levels || {})[l] || l, items: (d.items || []).filter(it => it.section === sec && it.level === l).map(it => ({ id: it.key.split("/")[2], name: it.name, status: it.status, version: it.version, demo: it.demo, kind: it.kind, blocked: it.blocked || "" })) })) }));
}
async function rbLoad(id, focus) {
  const st = rbState(id);
  if (st.loading) return;
  st.loading = true;
  try {
    const [tree, secs, counts, rec, gone] = await Promise.all([api("GET", "/api/agents/rules"), api("GET", "/api/agents/rules/sections"),
      st.up ? api("GET", `/api/agents/rules/counts?upload=${encodeURIComponent(st.up)}`).catch(() => ({})) : Promise.resolve({}),
      st.up && !st.rec ? api("GET", `/api/agents/rules/recording?upload=${encodeURIComponent(st.up)}`).catch(() => null) : Promise.resolve(st.rec),
      api("GET", "/api/agents/rules/deleted").catch(() => [])]);
    st.deleted = gone || [];
    st.rec = rec && rec.name ? rec : st.rec;
    st.tree = tree; st.counts = counts || {}; st.note = secs.levels_note || ""; st.rulesFolder = secs.rules_folder || st.rulesFolder;
    (secs.levels || []).forEach(l => st.levels[l.id] = l.about);
    if (st.ticks) {
      const live = new Set();
      // an item the plan did not know yet (added after the plan was made) starts ticked when it is chosen by default
      tree.forEach(s => s.levels.forEach(l => l.items.forEach(i => { const k = rbKey(s.section, l.level, i.id); live.add(k); if (!(k in st.ticks)) st.ticks[k] = !!i.default; })));
      Object.keys(st.ticks).forEach(k => { if (!live.has(k)) delete st.ticks[k]; });     // deleted: not chosen any more
    }
    if (st.view === "deleted" && !st.deleted.length) st.view = null;
    if (focus) { st.sel = { sec: focus.sec, lvl: focus.lvl }; st.open = null; if (focus.key && st.ticks) st.ticks[focus.key] = true; }
  } catch (e) { toast("Could not read the rules: " + e.message); }
  st.loading = false; st.loaded = true;
  rbRedraw(id);
  if (focus && focus.key) rbOpen(id, focus.key);
}
// after an add: the form is emptied and closed (the redraw would otherwise put the typed words back)
function rbClearForm(id, ids, details) {
  ids.forEach(i => { const x = $(i + id); if (x) x.value = ""; });
  const d = document.querySelector(`[data-id="${details}${id}"]`); if (d) d.open = false;
}
function rbFirstSel(st) {
  for (const s of st.tree) for (const l of s.levels) if (l.items.some(i => st.ticks && st.ticks[rbKey(s.section, l.level, i.id)])) return { sec: s.section, lvl: l.level };
  for (const s of st.tree) for (const l of s.levels) if (l.items.length) return { sec: s.section, lvl: l.level };
  return { sec: (st.tree[0] || {}).section, lvl: "nvme_command" };
}
function rbItemRow(id, st, sec, lvl, it, where) {
  const key = rbKey(sec, lvl, it.id), open = st.open === key, on = st.ticks && st.ticks[key];

  const tick = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
  return `<div class="rb-item ${on ? "on" : ""} ${open ? "open" : ""}" data-key="${esc(key)}" data-sec="${esc(sec)}" data-lvl="${esc(lvl)}">
      ${st.ticks ? `<label class="rb-tick" title="use this item on this data"><input type="checkbox" data-plan="${id}" data-key="${esc(key)}" ${on && !it.blocked ? "checked" : ""} ${it.blocked ? "disabled" : ""}><span class="box">${tick}</span></label>` : ""}
      <button type="button" class="rb-open" data-act="rb-open" data-rb="${id}" data-key="${esc(key)}" aria-expanded="${open}">
        <span class="rb-nm">${esc(it.name)}${it.demo ? ' <span class="pill acc" style="font-size:11px">demo</span>' : ""}${it.blocked ? ` <span class="pill warn" style="font-size:11px" title="${esc(it.blocked)}">cannot run here: it reads the tree, and this analysis has none</span>` : ""}</span>
        ${where ? `<span class="rb-meta">${esc(where)}</span>` : ""}<span class="rb-badges">${rbMeta(st, key, it)}</span>
        <span class="rb-chev">${IC.chev}</span></button>
      <button type="button" class="rb-rowdel ${st.delAsk === key ? "on" : ""}" data-act="rb-del" data-rb="${id}" data-key="${esc(key)}" title="takes this item out of the list; Deleted items can restore it" aria-label="Delete ${esc(it.name)}">${IC.trash}<span>Delete</span></button></div>
    ${st.delAsk === key ? rbDelAsk(id, st, key, it) : ""}
    ${open ? `<div class="rb-detail" id="rbd-${id}">${rbDetail(id, key)}</div>` : ""}`;
}
// the confirmation under the row: what deleting does, an optional why, Delete it / Keep it
function rbDelAsk(id, st, key, it) {
  const ui = rbUi(st, key), x = st.ex[key] || {};
  return `<div class="rb-panel bad rb-delask"><b>Delete “${esc(it.name)}”?</b>
      <p class="small" style="margin:6px 0 0">It leaves this list: it is not offered or run any more${st.ticks ? ", and it is unticked here" : ""}.${it.code === "detector" ? " The detector itself is not changed: the tree page still shows what it finds." : ""}${ui.coding ? " The code being written for it (or waiting for your review) is stopped." : ""}
      Nothing is destroyed: its rule file moves to ${esc((x.rules_folder || st.rulesFolder || "knowledge/rules") + "/_deleted")}, and <b>Deleted items</b> (under the sections list) can restore it as it was.</p>
      <label class="f">Why <span class="hint">· optional; kept with the deleted item</span></label><input type="text" id="rbdw-${id}" data-keep="rbdw-${id}" placeholder="for example: the same check as another item">
      <div class="row" style="margin-top:8px"><button class="btn small primary rb-delgo" data-act="rb-delgo" data-rb="${id}" data-key="${esc(key)}">Delete it</button><button class="btn small" data-act="rb-delno" data-rb="${id}" data-key="${esc(key)}">Keep it</button><span class="msg small" id="rbdm-${id}"></span></div></div>`;
}
function rbInner(id) {
  const st = rbState(id), tree = st.tree || [];
  if (!tree.length) return `<div class="rb-main"><p class="muted">Reading the rules…</p></div>`;
  if (!st.sel || !tree.some(s => s.section === st.sel.sec)) st.sel = rbFirstSel(st);
  const sec = tree.find(s => s.section === st.sel.sec) || tree[0], lvl = sec.levels.find(l => l.level === st.sel.lvl) || sec.levels[0];
  const side = tree.map(s => `<div class="rb-sec ${s.section === sec.section ? "cur" : ""}"><div class="rb-sname">${esc(s.label)}</div>
      <div class="rb-sabout">${s.defects ? "finds defects" : "results only"}</div>
      ${s.levels.map(l => {
        const n = l.items.length, k = st.ticks ? l.items.filter(i => st.ticks[rbKey(s.section, l.level, i.id)]).length : 0, on = s.section === sec.section && l.level === lvl.level && !st.q && st.view !== "deleted";
        return `<button type="button" class="rb-lvl ${on ? "on" : ""} ${n ? "" : "empty"}" data-act="rb-pick" data-rb="${id}" data-sec="${esc(s.section)}" data-lvl="${esc(l.level)}" title="${n} item${n === 1 ? "" : "s"}${st.ticks ? `, ${k} chosen` : ""}"><span>${esc(l.label)}</span><span class="rb-cnt">${st.ticks && k ? `<b>${k}</b> / ` : ""}${n}</span></button>`;
      }).join("")}</div>`).join("") +
    ((st.deleted || []).length ? `<button type="button" class="rb-lvl rb-delnav ${st.view === "deleted" && !st.q ? "on" : ""}" data-act="rb-deleted" data-rb="${id}" title="items deleted from the list; Restore brings one back"><span>Deleted items</span><span class="rb-cnt">${st.deleted.length}</span></button>` : "") +
    `<details class="more rb-addsec" data-id="addsec${id}"><summary>${IC.plus}Add a section</summary>
      <label class="f">Name</label><input type="text" id="asn${id}" data-keep="asn${id}" placeholder="for example: Timing checks">
      <label class="f">What it is for</label><textarea id="asa${id}" data-keep="asa${id}" style="min-height:54px" placeholder="what its items look for, and why"></textarea>
      <label class="f">What happens to its items</label>
      <label class="rb-radio"><input type="radio" name="asd${id}" value="0" checked> results only, like Data analytics</label>
      <label class="rb-radio"><input type="radio" name="asd${id}" value="1"> each item finds defects that go on to stage 1 (their cause) and stage 2 (a test), like Error roots</label>
      <div class="row" style="margin-top:8px"><button type="button" class="btn small primary" data-act="rb-addsec" data-rb="${id}">Add the section</button><span class="msg small" id="asm${id}"></span></div></details>
`;
  let list, head;
  if (st.q) {
    const q = st.q.toLowerCase(), hits = [];
    tree.forEach(s => s.levels.forEach(l => l.items.forEach(i => { if (i.name.toLowerCase().includes(q)) hits.push([s, l, i]); })));
    head = `<div class="rb-head"><div class="who">Search</div><h4>${hits.length} item${hits.length === 1 ? "" : "s"} match “${esc(st.q)}”</h4></div>`;
    list = hits.map(([s, l, i]) => rbItemRow(id, st, s.section, l.level, i, `${s.name || s.label} › ${l.label}`)).join("");
  } else if (st.view === "deleted") {
    const secName = sid => { const t = tree.find(z => z.section === sid); return t ? (t.name || t.label) : sid; };
    const lvlName = l => ((tree[0] || { levels: [] }).levels.find(v => v.level === l) || {}).label || l;
    head = `<div class="rb-head"><div class="who">Deleted items</div></div><p class="small muted" style="margin:6px 2px 0">Deleted items are not offered or run. Their rule files are kept in ${esc(((st.deleted[0] || {}).file || "").replace(/\/_deleted\/.*/, "/_deleted"))}; Restore puts one back where it was, as it was.</p>`;
    list = (st.deleted || []).map(d => `<div class="rb-item rb-gone"><div class="rb-open" style="cursor:default"><span class="rb-nm">${esc(d.name || d.id)}</span>
        <span class="rb-meta">${esc(secName(d.section))} › ${esc((lvlName(d.level)))} · deleted by ${esc(d.by || "?")}, ${when(d.at)}${d.why ? ` · why: “${esc(d.why)}”` : ""}</span>
        <span class="rb-badges"><button type="button" class="btn small" data-act="rb-restore" data-rb="${id}" data-sec="${esc(d.section)}" data-lvl="${esc(d.level)}" data-rid="${esc(d.id)}" title="puts it back in ${esc(secName(d.section))} › ${esc(lvlName(d.level))}, with its procedure and code">Restore</button></span></div></div>`).join("")
      || `<p class="muted small" style="margin:8px 2px">No deleted item.</p>`;
  } else {
    head = `<div class="rb-head"><div class="who">${esc(sec.label)} › ${esc(lvl.label)}</div></div>`;
    list = lvl.items.map(i => rbItemRow(id, st, sec.section, lvl.level, i)).join("") || `<p class="muted small" style="margin:8px 2px">No item here yet. Add one below: say in your words what to look for.</p>`;
  }
  const add = st.q || st.view === "deleted" ? "" : `<details class="more" data-id="additem${id}"><summary>${IC.plus}Add an item to ${esc(sec.name || sec.label)} › ${esc(lvl.label)}</summary>
      <label class="f">Name</label><input type="text" id="ain${id}" data-keep="ain${id}" placeholder="what to analyse, or the error's name">
      <label class="f">In your words <span class="hint">· what it means, how it shows in the data (which file and which columns), what result you want</span></label><textarea id="aid${id}" data-keep="aid${id}"></textarea>
      <p class="why">The Rule writer turns your words into a rule (the file, the columns, the test) and shows it to you before anything runs.</p>
      <div class="row"><button type="button" class="btn small primary" data-act="rb-additem" data-rb="${id}">${st.ticks ? "Add it and tick it" : "Add it"}</button><span class="msg small" id="aim${id}"></span></div></details>`;
  return `<aside class="rb-side"><input type="text" class="rb-q" id="${st.mode === "lib" ? "lib-q" : "rbq" + id}" data-rbq="${id}" placeholder="search all items" value="${esc(st.q)}">${side}</aside>
    <div class="rb-main">${head}<div class="rb-list" id="picks${id}">${list}</div>${add}</div>`;
}
function rbRedraw(id) {
  const el = document.querySelector(`.rb[data-rb="${id}"]`); if (!el) return;
  const intro = $("rbi" + id); if (intro) intro.innerHTML = rbIntro(id);
  const a = document.activeElement, q = a && a.dataset && a.dataset.rbq === String(id);
  const typing = a && el.contains(a) && a.id && /^(TEXTAREA|INPUT)$/.test(a.tagName) && !q
    ? { id: a.id, s: a.selectionStart, e: a.selectionEnd, top: a.scrollTop, left: a.scrollLeft } : null;
  const keep = captureUi(el), stt = rbState(id);
  el.classList.toggle("editing", !!(stt.open && rbUi(stt, stt.open).edit));   // the editor and the code get the whole width
  el.innerHTML = rbInner(id);
  restoreUi(el, keep);
  if (q) { const i = el.querySelector(".rb-q"); i.focus(); i.setSelectionRange(i.value.length, i.value.length); }
  if (typing) { const t = document.getElementById(typing.id); if (t) { t.focus({ preventScroll: true }); try { t.setSelectionRange(typing.s, typing.e); } catch (e) { /* number inputs */ } t.scrollTop = typing.top; t.scrollLeft = typing.left; } }
  planSummary(id);
}
async function rbOpen(id, key) {
  const st = rbState(id);
  st.open = st.open === key ? null : key;
  rbRedraw(id);
  if (st.open) await rbRefreshItem(id, key);
}
// ---- one item (owner, 2026-11-09): Source data · Rules or procedure (numbered) · the code · Edit rule/procedure,
// Code it / Verified code, Run, Export CSV. The procedure is a JSON the admin edits; Code it has the Coder write Python
// from it, the program checks and tries it, and the admin reviews it here (the chime sounds); Run uses only verified code.
const rbUi = (st, key) => (st.ui || (st.ui = {}))[key] || (st.ui[key] = {});
function rbMeta(st, key, it) {
  if (it.code === "detector") {
    const c = st.up ? st.counts[key] : null;
    return c && c.found ? `<span class="rb-badge hit">${nf(c.found)} found</span>` : `<span class="rb-badge">0 found</span>`;
  }
  if (it.code === "verified") return `<span class="rb-badge ok">verified code</span>`;
  if (it.code === "needs code") return `<span class="rb-badge warn">needs code</span>`;
  return `<span class="rb-badge">no procedure</span>`;
}
async function rbRefreshItem(id, key) {
  const st = rbState(id);
  try { st.ex[key] = await api("GET", `/api/agents/rules/${key.split("/").map(encodeURIComponent).join("/")}/explain${st.up ? "?upload=" + encodeURIComponent(st.up) : ""}`); }
  catch (e) { st.ex[key] = { error: e.message }; }
  const it = rbFindItem(st, key), x = st.ex[key], u = rbUi(st, key);
  if (u.edit && u.draft === undefined && x && x.procedure_info) u.editBase = x.procedure_info.sha;
  if (it && x && x.code) { it.code = x.code.kind === "python" ? (x.code.verified ? "verified" : "needs code") : x.code.kind; it.procedure_version = (x.procedure_info || {}).version || it.procedure_version; }
  rbRedraw(id);
  rbWatch(id, key);
}
function rbFindItem(st, key) {
  const [sec, lvl, rid] = key.split("/");
  const s = (st.tree || []).find(t => t.section === sec), l = s && s.levels.find(v => v.level === lvl);
  return l && l.items.find(i => i.id === rid);
}
// Code it / Run in progress: the run is read every 2 s while the item is open, until it waits for the admin or ends
function rbWatch(id, key) {
  const st = rbState(id), x = st.ex[key], ui = rbUi(st, key);
  if (!x || x.error || st.open !== key) return;
  const act = x.activity || {};
  const jobs = [["coding", ui.codeRun || (act.coding && act.coding.run)], ["running", ui.execRun || (act.running && act.running.run)]];
  jobs.forEach(([slot, rid]) => {
    if (!rid || ui[slot + "Done"] === rid || ui[slot + "Timer"]) return;
    const tick = async () => {
      ui[slot + "Timer"] = null;
      if (st.open !== key || !document.querySelector(`.rb[data-rb="${id}"]`)) return;
      const mine = slot === "coding" ? ui.codeRun : ui.execRun;
      if (mine && mine !== rid) return;
      let v;
      try { v = await api("GET", `/api/agents/runs/${rid}`); } catch (e) { return; }
      const prev = JSON.stringify(ui[slot]);
      ui[slot] = { run: rid, state: v.run.state, steps: v.steps.map(s => ({ key: s.key, title: s.title, state: s.state, error: s.error, note: s.note, started: s.started })), review: (v.reviews || []).find(r => r.state === "open") || null };
      const ended = ["finished", "stopped", "rejected"].includes(v.run.state);
      const failed = ui[slot].steps.some(s => s.state === "failed");
      if (JSON.stringify(ui[slot]) !== prev) rbRedraw(id);
      if (ended) { ui[slot + "Done"] = rid; ui[slot] = null; await rbRefreshItem(id, key); if (slot === "running") rbLoad(id); return; }
      if (!ui[slot].review && !failed) ui[slot + "Timer"] = setTimeout(tick, 2000);
    };
    tick();
  });
}
function rbJob(id, key, slot) {
  const ui = rbUi(rbState(id), key), j = ui[slot];
  if (!j) return "";
  const failed = j.steps.find(s => s.state === "failed");
  if (failed) return `<div class="rb-panel bad"><b>${esc(failed.title)}</b> failed: <span class="small">${esc((failed.error || "").split("\n")[0])}</span>
    <div class="row" style="margin-top:8px"><button class="btn small" data-act="rb-retry" data-rb="${id}" data-key="${esc(key)}" data-run="${j.run}">Try again</button></div></div>`;
  if (slot === "coding" && j.review) {
    const r = j.review, isReq = !!(r.data && r.data.f4_req);       // Family 4: first the requirements, then the code
    return `<div class="rb-panel review"><div class="lbl2">Family 4 · Coding research: ${isReq ? "the data research and the requirements" : "the code and the proof"}, for your review</div>${md(bodyOf(r))}${isReq ? f4ReqForm(r) : f4Trail(r)}
      <label class="f">${isReq ? "Your words to the Requirements agent" : "Your comment to the Coder"} <span class="hint">· ${isReq ? "your answers all together, or anything else it should know" : "needed for 'Send back to the Coder': say what is wrong"}</span></label><textarea id="rbc-${id}" data-keep="rbc-${id}" style="min-height:54px"></textarea>
      ${isReq ? "" : rbTry(id, key, r)}
      <div class="actions"><span class="msg" id="rbcm-${id}"></span><button class="btn act2" data-act="rb-dec" data-dec="change" data-rb="${id}" data-key="${esc(key)}" data-review="${r.id}"><span class="t">${isReq ? "Send my answers" : "Send back to the Coder"}</span><span class="d">${isReq ? "the Requirements agent reads them and asks again only what is still open" : "the Coder and the Tester start their rounds again from this code, with your comment"}</span></button>
      <button class="btn primary act2" data-act="rb-dec" data-dec="approve" data-rb="${id}" data-key="${esc(key)}" data-review="${r.id}"><span class="t">${IC.check.replace("<svg", '<svg class="i"')}${isReq ? "The requirements are complete: write the code" : "Approve: make it the verified code"}</span><span class="d">${isReq ? "the Coder writes the code and the Tester tests it on small data sets, round after round" : "Run then uses this code on the whole recording"}</span></button></div></div>`;
  }
  const cur = j.steps.find(s => s.state === "running") || j.steps.find(s => s.state === "waiting");
  const m = cur && /(\d+)%/.exec(cur.note || ""), pct = m ? +m[1] : null;
  const note = cur && cur.note ? cur.note.replace(/^running the verified code · /, "") : "";
  if (slot === "coding") return `<div class="rb-panel"><div class="rb-prog-h">Family 4 · Coding research${cur ? ": " + esc(cur.title) : ""}${pct !== null ? ` <b>${pct}%</b>` : ""}</div>
      <div class="small">${progressView(cur, "starting…")}</div>
      <p class="small muted" style="margin-top:6px">First the requirements, for your review. Then the Coder writes the code and the Tester tests it on small data sets, round after round; the code is never run on the whole recording here. The chime sounds when a decision waits for you.</p></div>`;
  return `<div class="rb-panel"><div class="rb-prog-h">Running${cur ? ": " + esc(cur.title) : ""}${pct !== null ? ` <b>${pct}%</b>` : ""}</div>
      <div class="small">${progressView(cur, "starting…")}</div>
      <p class="small muted" style="margin-top:6px">It runs on the server: you can leave this page and do other things. The top bar shows how far it is; the result and Export CSV appear here when it ends.</p></div>`;
}
// Source data: the recording's folder once, then each file with the columns it gives (owner, 2026-11-09: the same long
// folder written out for every file read as the same thing twice)
function rbSources(srcs) {
  const dirOf = p => p.slice(0, p.lastIndexOf("/")), groups = [];
  srcs.forEach(s => { const d = s.path ? dirOf(s.path) : null, g = groups.find(x => x.dir === d); if (g) g.files.push(s); else groups.push({ dir: d, files: [s] }); });
  return groups.map(g => `<div class="rb-src">${g.dir ? `<code>${esc(g.dir)}/</code><div class="small">the recording's folder${g.files.length > 1 ? `: ${g.files.length} files of it are read` : ""}</div>` : `<div class="small">not in the recording:</div>`}
      <ul class="rb-files">${g.files.map(s => `<li><code>${esc(s.file)}</code>${s.columns.length ? ` · columns used: ${s.columns.map(k => `<b>${esc(k)}</b>`).join(", ")}` : ""}</li>`).join("")}</ul></div>`).join("");
}
function rbDetail(id, key) {
  const st = rbState(id), x = st.ex[key], ui = rbUi(st, key);
  if (!x) return `<p class="muted small"><span class="spin" style="width:12px;height:12px;border-width:2px"></span> Reading the item…</p>`;
  if (x.error) return `<p class="err">${esc(x.error)}</p>`;
  const p = x.procedure, info = x.procedure_info || {}, c = x.code || {}, last = x.last_result;
  const src = (x.sources || []).length ? rbSources(x.sources) : `<p class="muted">Not named yet.</p>`;
  const steps = p ? `<ol class="rb-steps">${p.steps.map(s => `<li>${esc(s)}</li>`).join("")}</ol>
      <p class="rb-out"><b>Output:</b> ${esc(p.output.columns.join(", "))}${p.output.order ? ` · ${esc(p.output.order)}` : ""}</p>
      ${(p.open_questions || []).length ? `<div class="rb-q"><b>Still to decide</b><ul>${p.open_questions.map(q => `<li>${esc(q)}</li>`).join("")}</ul></div>` : ""}`
    : `<p class="muted">No procedure yet.${x.admin_words ? ` Your words: “${esc(x.admin_words)}”.` : ""} Write it with <b>Edit rule/procedure</b>.</p>`;
  const seeded = !info.edited_by || /^seed/.test(info.edited_by) || /^written from the owner/.test(info.edited_by);
  const who = info.from_detector ? "" : info.version ? `version ${info.version}${seeded ? "" : ` · ${esc(info.edited_by)}, ${when(info.edited_at)}`}` : "";
  let code = "";
  const ranges = (c.lines || []).map(([a, b]) => a === b ? a : `${a}–${b}`).join(", ");
  if (c.kind === "detector") code = `<p class="rb-okw">✔ Verified code: the detector, ${esc(c.path)}, lines ${ranges}. It is part of the application and tested with it.</p>`;
  else if (c.verified) code = `<p class="rb-okw">✔ Verified code: approved by ${esc(c.verified_by || "")} on ${when(c.verified_at)}, for procedure version ${c.procedure_version}.</p>`;
  else if (c.kind === "python") code = `<p class="rb-warnw">No verified code for procedure version ${c.procedure_version}${c.verified_by && c.for_this_version === false ? " (the code approved before was made for an earlier version)" : ""}. Press <b>Code it</b>.</p>`;
  else code = `<p class="muted">The procedure comes first.</p>`;
  const showCode = ui.showCode && !ui.edit ? (c.kind === "detector" ? (c.snippets || []).map(s => `<pre class="out rb-code">${s.text.split("\n").map((l, i) => `<span class="ln">${s.from + i}</span>${esc(l)}`).join("\n")}</pre>`).join("")
    : c.text ? `<pre class="out rb-code">${c.text.split("\n").map((l, i) => `<span class="ln">${i + 1}</span>${esc(l)}`).join("\n")}</pre>` : "") : "";
  const busy = !!(ui.coding || ui.running);
  const codingNow = ui.coding ? (ui.coding.review ? "The code of the current text waits for your review (beside this editor)" : "The Coder is writing the code of the current text now") : "";
  const editor = ui.edit ? `<div class="rb-editor"><p class="small muted">The sections list is hidden while you edit, so the text and the code sit side by side; it comes back when you close the editor.</p><label class="f">The procedure (JSON) <span class="hint">· source_data: the file(s) and the exact column names · steps: one sentence per step, saying how each cell is read, the hash map, the formulas · output: the columns and their order · open_questions: what is still to decide</span></label>
      <textarea class="rb-json" id="rbj-${id}" data-rbj="${id}" data-key="${esc(key)}" spellcheck="false">${esc(ui.draft !== undefined ? ui.draft : rbProcText(x))}</textarea>
      <p class="why">${c.kind === "detector" ? "This is the detector's procedure. Saving a change makes it a rule of its own, with its own code; its rows cannot go to stage 1, which isolates the detector's defects. " : ""}${codingNow ? `${codingNow}: you can keep editing. Saving a change replaces that code with code for your text. ` : ""}<b>Save and code it</b> saves your text as a new version and the Coder starts its code at once (checked, not run; you review it here). <b>Save only</b> keeps the text; press Code it when you are ready.</p>
      <div class="row"><button class="btn small primary" data-act="rb-save" data-code="1" data-rb="${id}" data-key="${esc(key)}" ${ui.running ? "disabled title='wait for the run to end'" : ""}>Save and code it</button><button class="btn small" data-act="rb-save" data-rb="${id}" data-key="${esc(key)}">Save only</button>${ui.conflict ? `<button class="btn small" data-act="rb-reload" data-rb="${id}" data-key="${esc(key)}" title="drops your text in the editor and shows the procedure as it is now">Load the current text</button>` : ""}<button class="btn small" data-act="rb-cancel" data-rb="${id}" data-key="${esc(key)}" title="closes the editor; text not saved is dropped">Close the editor</button><span class="msg small" id="rbjm-${id}">${ui.saveMsg || ""}</span></div></div>` : "";
  // beside the editor: the code being made (or its review), else the code as it is now, so the text and the code are seen together
  const sideCode = !ui.edit || ui.coding ? "" : c.kind === "detector" ? `<div class="rb-panel"><div class="lbl2">The code now · the detector</div>${(c.snippets || []).map(z => `<pre class="out rb-code">${z.text.split("\n").map((l, i) => `<span class="ln">${z.from + i}</span>${esc(l)}`).join("\n")}</pre>`).join("")}</div>`
    : c.text ? `<div class="rb-panel"><div class="lbl2">The code now · ${c.verified ? `verified, for version ${c.procedure_version}` : `not verified for this version`}</div><pre class="out rb-code">${c.text.split("\n").map((l, i) => `<span class="ln">${i + 1}</span>${esc(l)}`).join("\n")}</pre></div>`
    : `<div class="rb-panel"><div class="lbl2">The code now</div><p class="small muted">No code yet. <b>Save and code it</b> has the Coder write it from your text; it appears here for your review.</p></div>`;
  const result = last && last.columns ? `<div class="rb-result"><div class="lbl2">The last run on this recording · ${when(last.at)} · ${nf(last.rows)} line${last.rows === 1 ? "" : "s"}${last.procedure_version ? ` · procedure version ${last.procedure_version}` : ""}</div>
      ${plainDefects(last.columns, last.head) ? defectsTable(plainDefects(last.columns, (last.head || []).slice(0, 15)), null, last.upload_id) : `<div class="tbl"><table><tr>${last.columns.map(k => `<th>${esc(k)}</th>`).join("")}</tr>${(last.head || []).slice(0, 15).map(r => `<tr>${r.map(v => `<td>${esc(v === null ? "" : String(v))}</td>`).join("")}</tr>`).join("")}</table></div>`}
      ${last.rows > 15 ? `<p class="small muted">The first 15 lines; Export CSV gives all ${nf(last.rows)}.</p>` : ""}</div>` : "";
  return `<div class="rb-d">
    <h4>Source data</h4>${src}
    <h4>Rules or procedure${who ? ` <span class="rb-ver">${who}</span>` : ""}</h4>
    <div class="rb-src"><code>${esc(x.rule_file || "")}</code><div class="small">the rule file of this item${info.from_detector ? ": its steps above are written from the detector's code below" : ": Edit rule/procedure changes it"}</div></div>${steps}
    <h4>Code</h4>${x.code_file ? `<div class="rb-src"><code>${esc(x.code_file)}</code><div class="small">${c.kind === "detector" ? "the detector's code, part of the application" : c.verified ? "the verified code of this procedure version" : "the code made earlier (not verified for this version)"}</div></div>` : ""}${code}${showCode}
    <div class="rb-actions">
      <button class="btn small ${ui.edit ? "on" : ""}" data-act="rb-edit" data-rb="${id}" data-key="${esc(key)}" ${ui.running ? "disabled title='wait for the run to end'" : ""}>Edit rule/procedure</button>
      ${c.kind === "detector" || c.verified ? `<button class="btn small" data-act="rb-showcode" data-rb="${id}" data-key="${esc(key)}">${IC.check.replace("<svg", '<svg class="i"')}Verified code${ui.showCode ? " ▴" : " ▾"}</button>`
        : `<button class="btn small primary" data-act="rb-code" data-rb="${id}" data-key="${esc(key)}" ${!ui.running && (ui.edit || (c.kind === "python" && !ui.coding)) ? "" : "disabled"} title="${ui.edit ? "your changes in the editor are saved first (if any); then the Coder writes the Python code of that text, and you review it" : "the Coder writes the Python code from the procedure; you review it"}">Code it</button>`}
      <button class="btn small ${c.kind === "detector" || c.verified ? "primary" : ""}" data-act="rb-run" data-rb="${id}" data-key="${esc(key)}" ${(c.kind === "detector" || c.verified) && !busy && st.up ? "" : "disabled"} title="${st.up ? "runs the verified code on this recording" : "open an analysis first"}">Run</button>
      ${last && last.csv ? `<a class="btn small" href="${fileHref(last.csv)}" download>Export CSV</a>` : `<button class="btn small" disabled title="run it first">Export CSV</button>`}
      <button class="btn small ${ui.samples ? "on" : ""}" data-act="rb-samples" data-rb="${id}" data-key="${esc(key)}" ${(x.sources || []).some(z => z.path) ? "" : "disabled"} title="records of the source data, as they are in the file">Samples</button>
    </div>
    ${ui.samples ? rbSamples(id, key, x) : ""}${ui.edit ? `<div class="rb-pair">${editor}<div class="rb-codeside">${rbJob(id, key, "coding")}${sideCode}</div></div>` : rbJob(id, key, "coding")}${rbJob(id, key, "running")}${result}
    ${st.mode === "lib" ? `<details class="more"><summary>${IC.chev}Or say in words what to change (the Rule writer edits the procedure for you)</summary><textarea id="lib-msg" placeholder="for example: count only the I/O commands"></textarea>
      <div class="actions"><span class="msg" id="lib-out"></span><button class="btn" data-act="lib-edit" data-addr="${esc(key)}">Ask the Rule writer</button></div></details>` : ""}</div>`;
}
// Try on a sample: the code waiting for review, run on the first records only (seconds on any size); nothing is stored
function rbTry(id, key, r) {
  const ui = rbUi(rbState(id), key), t = ui.tryRes, n = ui.tryN || 1000;
  const res = !t ? "" : t.busy ? `<p class="small"><span class="spin" style="width:11px;height:11px;border-width:2px"></span> Trying it on the first ${nf(n)} records…</p>`
    : t.error ? `<p class="err small">${esc(t.error)}</p>`
    : `<p class="small">On the first ${nf(t.records)} records (${t.seconds} s): ${nf(t.rows)} output line${t.rows === 1 ? "" : "s"}. ${t.checks.map(c => `${c.ok ? "✔" : "✘"} ${esc(c.check)}`).join(" · ")}</p>
       <div class="tbl rb-sample"><table><tr>${t.columns.map(c => `<th>${esc(c)}</th>`).join("")}</tr>${t.head.slice(0, 20).map(row => `<tr>${row.map(v => `<td>${esc(String(v))}</td>`).join("")}</tr>`).join("")}</table></div>
       <p class="small muted">A sample only: the counts are not the recording's. Run gives the whole result.</p>`;
  return `<div class="rb-try"><div class="row" style="align-items:center"><button class="btn small" data-act="rb-try" data-rb="${id}" data-key="${esc(key)}" data-review="${r.id}">Try on a sample</button>
      <label class="small">first <input type="number" min="1" max="100000" value="${n}" data-rbs="${id}" data-key="${esc(key)}" data-f="tryN" style="width:100px"> records</label>
      <span class="small muted">optional: the code is not run on the whole recording until you press Run</span></div>${res}</div>`;
}
// Samples (owner, 2026-11-09): records of the item's source data as they are in the file, from a line on, shown and exported
function rbSamples(id, key, x) {
  const st = rbState(id), ui = rbUi(st, key), srcs = (x.sources || []).filter(z => z.path);
  const sf = ui.sf || (srcs[0] || {}).file, sl = ui.sl || 2, sc = ui.sc || 20, res = ui.sres;
  const table = res && res.busy ? `<div class="small" style="margin-top:8px">${progressView(null, `reading ${sf} up to line ${nf(sl)}: on a large file this can take a while; you can do other things`)}</div>`
    : res && res.error ? `<p class="err">${esc(res.error)}</p>` : res ? `<div class="tbl rb-sample"><table><tr>${res.header.map(h => `<th>${esc(h)}</th>`).join("")}</tr>${res.rows.map(r => `<tr>${r.map((v, i) => `<td${i === 0 ? ' class="muted"' : ""}>${esc(String(v))}</td>`).join("")}</tr>`).join("")}</table></div>
      <p class="small muted">${res.rows.length ? `Lines ${res.rows[0][0]} to ${res.rows[res.rows.length - 1][0]} of ${esc(res.file)}` : "No record from that line on"}${res.next_line ? "" : " · the end of the file"}.</p>
      ${res.next_line ? `<button class="btn small" data-act="rb-snext" data-rb="${id}" data-key="${esc(key)}">Next ${nf(sc)} records</button>` : ""}` : "";
  return `<div class="rb-samples"><div class="lbl2">Samples of the source data</div>
    <div class="rb-sform">
      ${srcs.length > 1 ? `<label class="f">File<select data-rbs="${id}" data-key="${esc(key)}" data-f="sf">${srcs.map(z => `<option ${z.file === sf ? "selected" : ""}>${esc(z.file)}</option>`).join("")}</select></label>` : `<label class="f">File<span class="rb-sfile">${esc(sf || "")}</span></label>`}
      <label class="f">From line<input type="number" min="2" value="${sl}" data-rbs="${id}" data-key="${esc(key)}" data-f="sl"></label>
      <label class="f">Records<input type="number" min="1" max="100000" value="${sc}" data-rbs="${id}" data-key="${esc(key)}" data-f="sc"></label>
      <label class="rb-radio"><input type="checkbox" ${ui.sa ? "checked" : ""} data-rbs="${id}" data-key="${esc(key)}" data-f="sa"> all columns in the export (the page shows the columns used)</label>
    </div>
    <p class="why">Line 1 of the file is its header, so the first record is line 2. The page shows up to 200 records; the export takes up to 100,000.</p>
    <div class="row"><button class="btn small primary" data-act="rb-sshow" data-rb="${id}" data-key="${esc(key)}">Show</button><button class="btn small" data-act="rb-sexport" data-rb="${id}" data-key="${esc(key)}">Export CSV</button></div>
    ${table}</div>`;
}
function rbSampleUrl(id, key, csv) {
  const st = rbState(id), ui = rbUi(st, key), x = st.ex[key], srcs = (x.sources || []).filter(z => z.path);
  const q = new URLSearchParams({ upload: st.up || "", file: ui.sf || (srcs[0] || {}).file || "", from: ui.sl || 2, count: ui.sc || 20 });
  if (csv && ui.sa) q.set("all", "1");
  return `/api/agents/rules/${key.split("/").map(encodeURIComponent).join("/")}/samples${csv ? ".csv" : ""}?${q}`;
}
// the procedure's JSON in the card's order (source data, steps, output, still to decide), not the server's alphabetical one
function rbProcText(x) {
  const p = x.procedure_json || {}, first = ["source_data", "steps", "output", "open_questions"], o = {};
  first.concat(Object.keys(p).filter(k => !first.includes(k))).forEach(k => { if (p[k] !== undefined) o[k] = p[k]; });
  return JSON.stringify(o, null, 2);
}
const rbCanon = v => JSON.stringify(v, (k, val) => val && typeof val === "object" && !Array.isArray(val) ? Object.keys(val).sort().reduce((o, kk) => (o[kk] = val[kk], o), {}) : val);
// the editor holds text that differs from the saved procedure
function rbDraftChanged(st, key) {
  const ui = rbUi(st, key), x = st.ex[key];
  if (ui.draft === undefined || !x) return false;
  try { return rbCanon(JSON.parse(ui.draft)) !== rbCanon(x.procedure_json); } catch (e) { return true; }
}
// a Code it or Run run becomes the item's: the watch of an earlier one is dropped and this one is watched
function rbStartJob(id, key, slot, run) {
  const ui = rbUi(rbState(id), key);
  clearTimeout(ui[slot + "Timer"]); ui[slot + "Timer"] = null;
  if (slot === "coding") ui.codeRun = run; else ui.execRun = run;
  ui[slot + "Done"] = null; ui[slot] = { run, state: "running", steps: [], review: null };
  rbRedraw(id); rbWatch(id, key);
}
// Save only / Save and code it (owner, 2026-11-09: "Edit rule/procedure and code should work simultaneously"): the editor stays
// open; code being made for the earlier text is replaced; with code, the Coder starts on the saved text in the same request
async function rbSave(id, key, code) {
  const st = rbState(id), ui = rbUi(st, key), x0 = st.ex[key] || {}, addr = key.split("/").map(encodeURIComponent).join("/");
  const t = $("rbj-" + id), text = t ? t.value : ui.draft !== undefined ? ui.draft : rbProcText(x0);
  let proc;
  try { proc = JSON.parse(text); } catch (e) { ui.draft = text; ui.saveMsg = `<span class="err">This is not valid JSON: ${esc(e.message)}</span>`; rbRedraw(id); return; }
  if (code && !S.project) { toast("Open an analysis first: the code is made for its recording"); return; }
  const m = $("rbjm-" + id); if (m) m.textContent = code ? "saving, then starting the Coder…" : "saving…";
  try {
    const x = await api("PUT", `/api/agents/rules/${addr}/procedure`, { procedure: proc, admin: S.admin, upload_id: st.up, base_sha: ui.editBase || (x0.procedure_info || {}).sha, code: !!code, project: S.project });
    st.ex[key] = x; delete ui.draft; ui.conflict = null; ui.editBase = (x.procedure_info || {}).sha;
    const v = (x.procedure_info || {}).version, stopped = (x.stopped_coding || []).length;
    ui.saveMsg = x.changed ? `Saved as version ${v} · ${new Date().toLocaleTimeString([], { timeStyle: "short" })}` : "Nothing changed in the text";
    const it = rbFindItem(st, key); if (it) { it.code = x.code.kind === "python" ? (x.code.verified ? "verified" : "needs code") : x.code.kind; it.procedure_version = v; }
    if (x.run) rbStartJob(id, key, "coding", x.run);
    else { if (stopped) { clearTimeout(ui.codingTimer); ui.codingTimer = null; ui.codingDone = ui.codeRun || null; ui.coding = null; } rbRedraw(id); rbWatch(id, key); }
    toast(x.changed ? `Saved as procedure version ${v}` + (x.run ? `; the Coder is writing its code${stopped ? " (the code of the earlier text was stopped)" : ""}`
        : code ? `; ${x.coding_note}` : stopped ? "; the code being made for the earlier text was stopped: press Code it for this text" : ": press Code it to make its code")
      : x.run ? (x.coding_note ? "Nothing changed: code is already being made for this text" : "Nothing changed in the text; the Coder is writing its code") : code ? `Nothing changed: ${x.coding_note}` : "Nothing changed");
  } catch (e) {
    ui.draft = text;
    if (e.data && e.data.conflict) { ui.conflict = true; ui.editBase = e.data.current_sha; }   // saving again now replaces the newer text, knowingly
    ui.saveMsg = `<span class="err">${esc(e.message)}</span>`; rbRedraw(id);
  }
}
async function rbAct(b) {
  const id = b.dataset.rb, key = b.dataset.key, st = rbState(id), ui = rbUi(st, key), act = b.dataset.act, addr = key.split("/").map(encodeURIComponent).join("/");
  if (act === "rb-edit") { ui.edit = !ui.edit; ui.saveMsg = ""; ui.conflict = null; ui.editBase = ((st.ex[key] || {}).procedure_info || {}).sha; if (!ui.edit) delete ui.draft; rbRedraw(id); if (ui.edit) { const t = $("rbj-" + id); if (t) t.focus(); } return; }
  if (act === "rb-cancel") { ui.edit = false; delete ui.draft; ui.saveMsg = ""; ui.conflict = null; rbRedraw(id); return; }
  if (act === "rb-reload") { delete ui.draft; ui.conflict = null; ui.saveMsg = ""; await rbRefreshItem(id, key); ui.editBase = ((st.ex[key] || {}).procedure_info || {}).sha; rbRedraw(id); return; }
  if (act === "rb-showcode") { ui.showCode = !ui.showCode; rbRedraw(id); return; }
  if (act === "rb-del") { st.delAsk = st.delAsk === key ? null : key; if (st.delAsk && st.open === key) st.open = null; rbRedraw(id); if (st.delAsk) { const w = $("rbdw-" + id); if (w) w.focus(); } return; }
  if (act === "rb-delno") { st.delAsk = null; rbRedraw(id); return; }
  if (act === "rb-samples") { ui.samples = !ui.samples; rbRedraw(id); return; }
  if (act === "rb-sshow" || act === "rb-snext") {
    if (act === "rb-snext" && ui.sres && ui.sres.next_line) ui.sl = ui.sres.next_line;
    ui.sres = { busy: true }; rbRedraw(id);
    try { ui.sres = await api("GET", rbSampleUrl(id, key, false)); } catch (e) { ui.sres = { error: e.message }; }
    rbRedraw(id); return;
  }
  if (act === "rb-try") {
    ui.tryRes = { busy: true }; rbRedraw(id);
    try { ui.tryRes = await api("POST", `/api/agents/rules/${addr}/try`, { review: +b.dataset.review, records: ui.tryN || 1000, upload_id: st.up }); }
    catch (e) { ui.tryRes = { error: e.message }; }
    rbRedraw(id); return;
  }
  if (act === "rb-sexport") { window.location.href = rbSampleUrl(id, key, true); toast("Exporting the samples as CSV"); return; }
  if (!S.admin) { openSettings(true); return; }
  if (act === "rb-save") return rbSave(id, key, !!b.dataset.code);
  if (act === "rb-delgo") {
    const why = ($("rbdw-" + id) || {}).value || "", m = $("rbdm-" + id);
    if (m) m.textContent = "deleting…";
    try {
      const x = await api("DELETE", `/api/agents/rules/${addr}`, { admin: S.admin, why });
      clearTimeout(ui.codingTimer); clearTimeout(ui.runningTimer);
      delete st.ui[key]; delete st.ex[key]; st.open = null; st.delAsk = null; if (st.ticks) delete st.ticks[key];
      st.deleted = x.deleted_items || [];
      await rbLoad(id);
      toast(`Deleted “${x.deleted.name}”: Deleted items, under the sections list, can restore it`);
    } catch (e) { if (m) m.innerHTML = `<span class="err">${esc(e.message)}</span>`; }
    return;
  }
  if (act === "rb-code" && ui.edit && rbDraftChanged(st, key)) return rbSave(id, key, true);
  if (act === "rb-code" && ui.coding) { toast("Code is already being made for this text: its review appears here"); return; }
  if (act === "rb-code" || act === "rb-run") {
    if (!S.project) { toast("Open an analysis first"); return; }
    try {
      const x = await api("POST", `/api/agents/rules/${addr}/${act === "rb-code" ? "code" : "run"}`, { project: S.project, admin: S.admin });
      rbStartJob(id, key, act === "rb-code" ? "coding" : "running", x.run);
    } catch (e) { toast(e.message); }
    return;
  }
  if (act === "rb-retry") { await api("POST", `/api/agents/runs/${b.dataset.run}/retry`); ui.coding = ui.coding && { ...ui.coding, steps: [] }; rbRedraw(id); rbWatch(id, key); return; }
  if (act === "rb-dec") {
    let comment = ($("rbc-" + id) || {}).value || "";
    const rvw = (ui.coding || {}).review, isReq = !!(rvw && rvw.data && rvw.data.f4_req && String(rvw.id) === String(b.dataset.review));
    const edits = isReq ? f4ReqEdits(rvw) : f4ProofEdits(rvw);       // Family 4: the answers to the questions and the number of rounds, or the decisions on the requirements
    if (isReq && b.dataset.dec === "change" && !comment.trim() && Object.keys(edits.answers).length) comment = "answers to the questions";
    if (b.dataset.dec === "change" && !comment.trim()) { $("rbcm-" + id).innerHTML = `<span class="err">${isReq ? "write your answers first: in the boxes of the questions, or in the comment box" : "say what is wrong in the comment"}</span>`; return; }
    try {
      await api("POST", `/api/agents/reviews/${b.dataset.review}/decide`, { decision: b.dataset.dec, admin: S.admin, comment, edits });
      toast(isReq ? (b.dataset.dec === "approve" ? "The requirements are complete: the Coder starts" : "The Requirements agent reads your answers")
        : b.dataset.dec === "approve" ? "Approved: this is now the verified code of the procedure" : "The Coder and the Tester start again");
      ui.coding = { run: ui.codeRun || (ui.coding || {}).run, state: "running", steps: [], review: null };
      if (b.dataset.dec === "approve" && !isReq) { ui.coding = null; ui.codingDone = null; }
      const cm = $("rbc-" + id); if (cm) cm.value = "";
      await rbRefreshItem(id, key);
      if (b.dataset.dec !== "approve" || isReq) rbWatch(id, key);
    } catch (e) { $("rbcm-" + id).innerHTML = `<span class="err">${esc(e.message)}</span>`; }
  }
}

async function rbAddSection(id) {
  const st = rbState(id), label = ($("asn" + id).value || "").trim(), about = ($("asa" + id).value || "").trim();
  const defects = (document.querySelector(`input[name="asd${id}"]:checked`) || {}).value === "1";
  if (!label) { $("asm" + id).innerHTML = `<span class="err">give it a name</span>`; return; }
  if (!S.admin) { openSettings(true); return; }
  try {
    const x = await api("POST", "/api/agents/rules/sections", { label, about, defects, admin: S.admin });
    toast(`Section added: ${x.section.title}`);
    rbClearForm(id, ["asn", "asa"], "addsec");
    await rbLoad(id, { sec: x.section.id, lvl: "nvme_command" });
  } catch (e) { $("asm" + id).innerHTML = `<span class="err">${esc(e.message)}</span>`; }
}
async function rbAddItem(id) {
  const st = rbState(id), name = ($("ain" + id).value || "").trim(), description = ($("aid" + id).value || "").trim();
  if (!name) { $("aim" + id).innerHTML = `<span class="err">give it a name</span>`; return; }
  if (!S.admin) { openSettings(true); return; }
  const { sec, lvl } = st.sel;
  try {
    const lib = st.mode === "lib" && S.project;
    const x = await api("POST", "/api/agents/rules", { section: sec, level: lvl, name, description, admin: S.admin, project: lib ? S.project : undefined });
    if (lib && x.run) { nav(`#/run/${x.run}`); return; }
    toast(st.ticks ? "Added and ticked: the Rule writer drafts it when the flow runs" : "Added");
    rbClearForm(id, ["ain", "aid"], "additem");
    await rbLoad(id, { sec, lvl, key: rbKey(sec, lvl, x.rule.id) });
  } catch (e) { $("aim" + id).innerHTML = `<span class="err">${esc(e.message)}</span>`; }
}
// the opening of the plan card: which recording, what happens to a ticked item, how to choose (owner, 2026-11-09: the
// earlier line "Family 3 will use these rules on the tree of upload <id>" said nothing to a reader)
const REC_LABEL = { nvme_command: "NVMe commands", nvme_transaction: "NVMe transactions", split: "split transactions", link: "link transactions", packets: "packets" };
function rbIntro(id) {
  const st = rbState(id), rec = st.rec, p = ((S.state && S.state.projects) || []).find(x => x.id === S.project) || {};
  const n = rec && rec.rows && rec.rows.nvme_command;
  return `<p><b>Recording:</b> ${esc((rec && rec.name) || p.name || "")}${rec && rec.folder ? ` · folder <b>${esc(rec.folder)}</b>` : ""}${n !== undefined && n !== null ? ` · ${nf(n)} NVMe commands` : ""}. Tick the items to run; open one to see its source data and procedure, edit it, or delete it.</p>`;
}
function planForm(r) {
  const st = rbState(r.id);
  st.mode = "plan";
  if (r.data.recording && !st.rec) st.rec = r.data.recording;
  if (!st.ticks) { st.ticks = {}; (r.data.items || []).forEach(i => st.ticks[i.key] = !!i.selected); }
  st.up = r.data.upload_id || ((S.state.projects || []).find(p => p.id === S.project) || {}).upload_id || null;
  if (!st.tree) st.tree = rbTreeFromReview(r.data);
  if (!st.loaded) setTimeout(() => rbLoad(r.id), 0);
  return `<div class="rb-intro" id="rbi${r.id}">${rbIntro(r.id)}</div><div class="rb" data-rb="${r.id}">${rbInner(r.id)}</div><div class="summary-line" id="sum${r.id}"></div>`;
}
function planSummary(id) {
  const st = RB[id], el = $("sum" + id); if (!st || !st.ticks || !el) return;
  const on = Object.keys(st.ticks).filter(k => st.ticks[k]), tree = st.tree || [];
  const per = tree.map(s => [s, on.filter(k => k.split("/")[0] === s.section).length]).filter(([, n]) => n);
  const toStages = per.filter(([s]) => s.defects).reduce((a, [, n]) => a + n, 0);
  el.textContent = on.length ? `${on.length} chosen: ${per.map(([s, n]) => `${n} from ${s.name || s.label}`).join(", ")}.${!toStages ? "" : toStages === 1 ? " The one that finds defects goes on to stage 1 and stage 2." : ` The ${toStages} that find defects go on to stage 1 and stage 2.`}` : "Nothing chosen yet: tick at least one item.";
}

// a list of defects as people read it (owner, 2026-11-10: "nobody is going to understand what is the meaning of that particular defect column")
// The same view as family3.plain_defects on the server: what was found first, where in the files, when, how serious, and what each column is.
const DETECTOR_COLS = ["defect", "level", "rule", "what was found", "severity", "number in its file", "time stamp (ps)", "command's file row"];
const LEVEL_NUMBER = { nvme_command: "NVMe Cmd", nvme_transaction: "NVMe Trans", split: "Split Trans", link: "Link Tra", packets: "Packet" };
const SEVERITY_WORDS = { error: "error", warning: "warning", check: "to check" };
function secsOf(ps) { const v = Number(ps); return Number.isFinite(v) ? (v / 1e12).toFixed(6).replace(/0+$/, "").replace(/\.$/, "") + " s" : ""; }
function plainDefects(cols, head) {
  if (!cols || DETECTOR_COLS.some((c, i) => cols[i] !== c)) return null;
  return (head || []).map(x => {
    const [fid, level, , name, sev, rowN, tps, cmdRow, dataRow] = x;
    const file = REC_FILE[level] || level || "its file", row = dataRow != null ? dataRow : rowN;
    const own = rowN != null && dataRow != null && rowN !== dataRow ? ` (${LEVEL_NUMBER[level] || "number"} ${nf(rowN)})` : "";
    let where = `row ${nf(row)} of ${file}${own}`;
    if (level !== "nvme_command") where += cmdRow ? `, inside the command in row ${nf(cmdRow)} of nvme_command.csv` : ", outside any command";
    return { no: fid, what: name, where, when: secsOf(tps), sev: SEVERITY_WORDS[sev] || sev, rule: x[2], level, row, cmdRow };
  });
}
function defectsTable(rows, more, uid) {
  if (!rows) return "";
  return `<div class="small" style="margin:6px 0"><b>How to read this table</b><ul class="small" style="margin:2px 0 0;padding-left:18px">
      <li><b>Where in the files:</b> the row of the CSV file where the defect shows. Row 144 is the 144th row under the file's header (a spreadsheet shows it on line 145). In brackets, the number the analyzer itself gave that row (its NVMe Cmd, Link Tra or Packet number), when it differs. <b>Click it</b> to open that row: every cell with its meaning, and why it is a defect.</li>
      <li><b>When:</b> the row's Time Stamp, in seconds from the start of the recording.</li>
      <li><b>How serious:</b> <i>error</i>, the rule's condition for a failure is met; <i>warning</i>, the analyzer's own warning, or a link event worth a look; <i>to check</i>, a person has to decide.</li></ul></div>
    <div class="tbl"><table><tr><th>What was found</th><th title="the row of the CSV file where it shows">Where in the files</th><th title="seconds from the start of the recording">When</th><th>How serious</th></tr>
      ${rows.map(r => `<tr><td>${esc(r.what)}</td><td>${uid && r.level && r.row != null ? `<a href="#" data-rowcard="${esc(uid)}" data-level="${esc(r.level)}" data-row="${esc(r.row)}" data-fid="${esc(r.no)}">${esc(r.where)}</a>` : esc(r.where)}</td><td style="white-space:nowrap">${esc(r.when)}</td><td>${esc(r.sev)}</td></tr>`).join("")}</table></div>
    ${more ? `<p class="small muted">The first ${rows.length} of ${nf(more)}; the export has all of them.</p>` : ""}`;
}

// a defect's whole record, from its command down to the packets (owner, 2026-11-10: "I want to see the records too, the whole records from nvme to packet level")
const REC_LEVELS = "nvme_transaction,split,link,packets";
const REC_FILE = { nvme_command: "nvme_command.csv", nvme_transaction: "NVME_Transactions.csv", split: "split.csv", link: "link.csv", packets: "packets.csv" };
async function loadRecords(rid, uid, fid) {
  const box = $("recs" + rid); if (!box) return;
  if (fid === "" || fid === "none" || fid == null) { box.innerHTML = `<p class="small muted">choose a defect above to see its records</p>`; return; }
  S.recs = S.recs || {};
  const key = uid + "/" + fid;
  if (!S.recs[key]) {
    box.innerHTML = `<p class="small muted">reading this defect's rows from the tree…</p>`;
    try { S.recs[key] = await api("GET", `/api/isolate/${encodeURIComponent(uid)}/${fid}/window?n=0&m=0&levels=${REC_LEVELS}&per=2000`); }
    catch (e) { box.innerHTML = `<p class="err">${esc(e.message)}</p>`; return; }
  }
  // (owner, 2026-11-10: "if I press 138 it is going for 261") two answers can arrive out of order: draw only the defect still chosen
  const sel = $("df" + rid), now = $("recs" + rid);
  if (!now || (sel && String(sel.value) !== String(fid))) return;
  now.innerHTML = recordsView(S.recs[key]);
}
function recordsView(w) {
  const cmd = (w.commands || []).find(c => c.position === "fault") || (w.commands || [])[0];
  if (!cmd) return `<p class="small muted">no command row for this defect</p>`;
  const under = cmd.under || {}, kids = {};
  Object.entries(under).forEach(([lv, blk]) => (blk.rows || []).forEach(x => { const k = (x.parent_level || "?") + ":" + x.parent_rowid; (kids[k] = kids[k] || []).push(x); }));
  const red = x => (x.findings || []).length ? `<span class="err"> · ${(x.findings || []).map(f => esc(f.name || f.rule)).join("; ")}</span>` : "";
  const line = x => `<b>${esc(x.label || x.level)}</b> · row ${nf(x.rowid)} of <code>${esc(REC_FILE[x.level] || "")}</code>${x.n != null && x.n !== x.rowid ? ` (${esc(LEVEL_NUMBER[x.level] || "number")} ${nf(x.n)})` : ""} · ${esc(x.summary || "")}${x.t ? ` · at ${esc(x.t)}` : ""}${x.dur ? ` · took ${esc(x.dur)}` : ""}${x.gap ? ` · wait to the next row ${esc(x.gap)}` : ""}${x.relation === "context" ? " · context" : ""}${red(x)}`;
  const node = (x, depth) => {
    const ch = (kids[x.level + ":" + x.rowid] || []);
    const open = depth < 1 || (x.findings || []).length ? "open" : "";
    return ch.length ? `<details class="rec" ${open} style="margin-left:${depth ? 14 : 0}px"><summary>${IC.chev}${line(x)} <span class="hint">· ${ch.length} below</span></summary>${ch.map(c => node(c, depth + 1)).join("")}</details>`
      : `<div class="rec small" style="margin-left:${depth ? 14 + 16 : 16}px;padding:2px 0">${line(x)}</div>`;
  };
  const plural = { nvme_transaction: "NVMe transactions", split: "split transactions", link: "link transactions", packets: "packets" };
  const counts = ["nvme_transaction", "split", "link", "packets"].filter(lv => under[lv]).map(lv => { const blk = under[lv]; return `${nf(blk.count)} ${blk.count === 1 ? esc(blk.label || lv) : plural[lv]}${blk.shown < blk.count ? ` (${nf(blk.shown)} shown)` : ""}`; }).join(", ");
  const top = Object.assign({}, cmd, { level: "nvme_command", label: "NVMe command" });
  return `<p class="small muted">Under this command: ${counts || "nothing"}. Every row names its row in its own CSV file; a red note is a finding on that row. Open a row to see the rows under it.</p>${node(top, 0)}`;
}
function defectForm(r) {
  const head = r.data.head || [];
  const uid = r.data.upload_id;
  const recs = uid && head.length ? `<details class="more" data-id="recd${r.id}" data-recs="${r.id}" data-uid="${esc(uid)}" style="margin-top:8px"><summary>${IC.chev}Show its records, from the NVMe command down to the packets</summary>
      <div id="recs${r.id}"><p class="small muted">opens the defect chosen above</p></div></details>` : "";
  /* nothing is chosen for the admin (owner, 2026-11-11: "you are showing the defect number by default. Who gave you that"): the list starts empty */
  return `<label class="f">The defect to take to stage 1 and stage 2</label><select id="df${r.id}" data-keep="df${r.id}"><option value="">choose the defect…</option>${head.slice(0, 200).map(x => `<option value="${x[0]}">${esc(((plainDefects(r.data.columns, [x]) || [{}])[0].where || "") + " · " + String(x[3] || "").slice(0, 110))}</option>`).join("")}<option value="none">none: keep the result, isolate no defect</option></select>
    <p class="small muted" style="margin-top:4px">Nothing is chosen for you: pick the defect you want isolated, or “none”.</p>` + recs;
}
// the records panel loads when it is opened, again when another defect is chosen, and after a redraw (owner, 2026-11-10)
document.addEventListener("toggle", e => {
  const d = e.target; if (!d || !d.dataset || !d.dataset.recs || !d.open) return;
  const sel = $("df" + d.dataset.recs); if (sel) loadRecords(d.dataset.recs, d.dataset.uid, sel.value);
}, true);
document.addEventListener("change", e => {
  const x = e.target; if (!x || !x.id || !x.id.startsWith("df")) return;
  const d = document.querySelector(`details[data-recs="${x.id.slice(2)}"]`); if (d && d.open) loadRecords(x.id.slice(2), d.dataset.uid, x.value);
});
function sequenceForm(r) {
  const seq = r.data.sequence || [];
  const where = { above: "before the defect", fault: "THE DEFECT", below: "after the defect" };
  return `<details class="more" data-id="seq${r.id}" open><summary>${IC.chev}The steps to keep <span class="hint muted" style="font-weight:400">· untick a step to give your edits; the defect's own step always stays</span></summary>
    <div class="tbl seqtbl"><table><tr><th>keep</th><th>step</th><th>command</th><th>where</th><th>wait before it</th><th>why</th></tr>${seq.map(s => `<tr class="${s.position === "fault" ? "fault" : ""}"><td><input type="checkbox" data-seq="${r.id}" data-step="${s.step}" data-keep="sq${r.id}_${s.step}" ${s.position === "fault" ? "checked disabled" : "checked"}></td><td>${s.step}</td><td><b>${esc(s.command)}</b></td><td>${esc(where[s.position] || s.position)}</td><td>${nf(s.gap_us)} µs</td><td class="small muted">${esc([].concat(s.why || []).join("; ").slice(0, 160))}</td></tr>`).join("")}</table></div></details>`;
}
function outcomesForm(r) {
  const outs = r.data.outcomes || [];
  return `<label class="f">Check each line, and correct it if needed <span class="hint">· hover a line for where it comes from</span></label><div class="tbl"><table><tr><th>step</th><th>command</th><th>expected status</th><th>time limit</th><th>the check</th></tr>` +
    outs.map(o => `<tr title="${esc(o.basis || "")}"><td>${o.step}</td><td><b>${esc(o.command)}</b></td><td><input type="text" data-out="${r.id}" data-step="${o.step}" data-f="status" data-orig="${esc(o.status)}" data-keep="os${r.id}_${o.step}" value="${esc(o.status)}"></td><td class="small">${esc(o.timing_text || "")}</td><td><input type="text" data-out="${r.id}" data-step="${o.step}" data-f="check" data-orig="${esc(o.check)}" data-keep="oc${r.id}_${o.step}" value="${esc(o.check)}"></td></tr>`).join("") + `</table></div>`;
}
function editsOf(r, s, b) {
  const id = r.id, d = r.data || {};
  if (d.f4_req) return f4ReqEdits(r);       // Family 4: the answers to the questions, the number of rounds
  if ((d.f4_open || []).length) return f4ProofEdits(r);      // Family 4: the admin's decision on each requirement that was not shown to hold
  if (s.key === "f1_gate") return b.dataset.readnew ? { read_new: true } : b.dataset.stage2 ? { stage2: b.dataset.stage2, use_rea: b.dataset.stage2 === "fixed" && !!($("rea-use" + id) && $("rea-use" + id).checked) } : {};
  if (s.key === "f3_plan") {
    const st = RB[id];
    const selected = st && st.ticks ? Object.keys(st.ticks).filter(k => st.ticks[k]) : [...document.querySelectorAll(`input[data-plan="${id}"]`)].filter(x => x.checked).map(x => x.dataset.key);
    return { selected, new: [] };
  }
  if (d.ask_rea) return b.dataset.norea ? {} : { rea: ($("rea" + id).value || "").trim() };
  if (s.key === "build_ask" && $("rb" + id)) return { rebuild: $("rb" + id).checked };
  if (d.isolation && s.key.endsWith(":isolate")) return { defect_name: ($("dgd" + id) || {}).value || "", name: ($("dgdn" + id) || {}).value || "" };
  if (d.graph && s.key.endsWith(":cause")) return { cause: ($("dgc" + id) || {}).value || "", side: ($("dgcs" + id) || {}).value || "", header: ($("dgch" + id) || {}).value || "" };
  if ((d.first || d.judge) && s.key.endsWith(":solution")) {
    const unt = k => [...document.querySelectorAll(`input[data-dgseq="${id}-${k}"]`)].filter(x => !x.checked && !x.disabled).map(x => Number(x.dataset.step));
    if (d.first || b.dataset.sig === "store") return { solution: "new", drop: unt("new"), optimized: ($("dgo" + id + "-new") || {}).value || "" };
    const sid = ($("dgsel" + id) || {}).value || "", withEd = (b.dataset.sig || "").endsWith("_with_edits");
    return { solution: sid, signal: b.dataset.sig, drop: sid && withEd ? unt(sid) : [], optimized: sid && withEd ? (($("dgo" + id + "-" + sid) || {}).value || "") : null };
  }
  if (s.key.endsWith(":result") && $("df" + id)) { const v = $("df" + id).value; return { defect: v === "" ? null : v === "none" ? "none" : Number(v) }; }
  if (d.signals) return { signal: b.dataset.sig, drop: [...document.querySelectorAll(`input[data-seq="${id}"]`)].filter(x => !x.checked && !x.disabled).map(x => Number(x.dataset.step)) };
  if (d.testfile) {
    const e = {}, v = id2 => (($(id2 + id) || {}).value || "").trim();
    if (v("tfs") !== "" && v("tfn") !== "") e.deallocate_range = { slba: Number(v("tfs")), blocks: Number(v("tfn")) };
    if (v("tfk") !== "" && v("tfr") !== "") e.known_rate = { k: Number(v("tfk")), n: Number(v("tfr")) };
    return e;
  }
  if (d.outcomes) {
    const outs = {};
    document.querySelectorAll(`input[data-out="${id}"]`).forEach(x => { if (x.value.trim() !== (x.dataset.orig || "").trim()) (outs[x.dataset.step] = outs[x.dataset.step] || {})[x.dataset.f] = x.value.trim(); });
    return { outcomes: outs };
  }
  if (s.key === "coder" || s.key === "last_strategy" || s.key === "independent") {
    return { verified: [...document.querySelectorAll(`input[data-jr="${id}"]`)].filter(x => x.checked).map(x => x.value), accept_reason: (($("why" + id) || {}).value || "").trim() };
  }
  const ed = $("ed" + id);
  if (ed && ed.value.trim()) { const e = {}; ed.value.split("\n").forEach(l => { const i = l.indexOf("="); if (i > 0) e[l.slice(0, i).trim()] = l.slice(i + 1).trim(); }); return e; }   // "column" or "column: keyword" -> meaning
  return undefined;
}

async function decide(b) {
  const id = Number(b.dataset.r), dec = b.dataset.dec;
  const rv = (await api("GET", "/api/agents/reviews?state=open")).find(x => x.id === id);
  if (!rv) { toast("This was already decided"); render(); return; }
  const v = await api("GET", "/api/agents/runs/" + rv.run);
  const r = v.reviews.find(x => x.id === id), s = v.steps.find(x => x.id === r.step);
  const msg = $("msg" + id);
  let comment = ($("cm" + id) || {}).value || "";
  if (!S.admin) { openSettings(true); return; }
  if (dec === "change" && b.dataset.sig === "wrong" && !comment.trim()) comment = "the proposal was judged wrong";
  if (dec === "change" && b.dataset.readnew && !comment.trim()) comment = "new CSV files were added to the folder";
  if (dec === "change" && r.data && r.data.f4_req && !comment.trim() && Object.keys(f4ReqEdits(r).answers).length) comment = "answers to the questions";
  if (dec === "change" && !comment.trim()) { msg.innerHTML = `<span class="err">${r.data && r.data.f4_req ? "write your answers first: in the boxes of the questions, or in the comment box" : "write in the comment box what to change"}</span>`; $("cm" + id).focus(); return; }
  const edBox = $("ed" + id);
  if (dec === "approve" && edBox && edBox.dataset.dict) {       // a meaning for something this file does not have is never saved quietly
    const bad = meaningCheck(edBox).bad;
    if (bad.length) { msg.innerHTML = `<span class="err">Not in this file, so not saved: ${bad.map(esc).join("; ")}. Correct or remove these lines, then approve.</span>`; edBox.focus(); return; }
  }
  // (owner, 2026-11-10: a question typed in the comment box was recorded as an approval) words in the comment box and Approve: ask first
  if (dec === "approve" && comment.trim() && !b.dataset.sig && !b.dataset.norea && !b.dataset.confirmed) {
    msg.innerHTML = `<span class="err">You wrote something in the comment box. Approving keeps it only as a note: nothing reads it. To have the agent act on it, use the other button; to ask a question, use "Ask the model" above.</span>
      <button class="btn small" data-act="dec" data-r="${id}" data-dec="approve" data-confirmed="1"${b.dataset.stage2 ? ` data-stage2="${esc(b.dataset.stage2)}"` : ""}>${b.dataset.stage2 === "skip" ? "Go on without stage 2" : b.dataset.stage2 === "fixed" ? "Go to stage 2" : "Approve"}, and keep my words as a note</button>`;
    return;
  }
  const edits = editsOf(r, s, b);
  if (dec === "approve" && r.data && r.data.ask_rea && !b.dataset.norea && !edits.rea) { msg.innerHTML = `<span class="err">give the folder, or choose Continue without</span>`; $("rea" + id).focus(); return; }
  const card = $("rv" + id); card.querySelectorAll("button").forEach(x => x.disabled = true); msg.textContent = "recording your decision…";
  try {
    await api("POST", `/api/agents/reviews/${id}/decide`, { decision: dec, admin: S.admin, comment, edits });
    S.jr = null;
    toast(dec === "approve" ? "Recorded. The flow continues." : dec === "change" ? (b.dataset.readnew ? "Recorded. The new files are being read." : "Recorded. The agent works on it again.") : "Stopped");
    await refreshState();
    const rt = route();
    if (rt[0] === "p") nav(`#/p/${rt[1]}`); else render(true);
  } catch (e) { msg.innerHTML = `<span class="err">${esc(e.message)}</span>`; card.querySelectorAll("button").forEach(x => x.disabled = false); }
}
// the meanings the admin typed, checked against the file's columns and keywords as they are typed
function meaningCheck(box) {
  let known = {}; try { known = JSON.parse(box.dataset.dict || "{}"); } catch (e) { known = {}; }
  const ok = [], bad = [];
  box.value.split("\n").map(l => l.trim()).filter(Boolean).forEach(l => {
    const i = l.indexOf("=");
    if (i <= 0 || !l.slice(i + 1).trim()) { bad.push(`“${l.slice(0, 60)}” (write it as column = meaning)`); return; }
    const left = l.slice(0, i).trim(), j = left.indexOf(":"), col = j > 0 ? left.slice(0, j).trim() : left, kw = j > 0 ? left.slice(j + 1).trim() : null;
    if (!(col in known)) bad.push(`column “${col}”`);
    else if (kw !== null && !known[col].includes(kw)) bad.push(`keyword “${kw}” in ${col}`);
    else ok.push(kw !== null ? `${col}: ${kw}` : col);
  });
  return { ok, bad };
}
document.addEventListener("input", e => { const x = e.target; if (x && x.dataset && x.dataset.jwed) jwEditCheck(x.dataset.jwed); });
document.addEventListener("input", e => {
  const box = e.target; if (!box || !box.dataset || !box.dataset.dict) return;
  const out = $("edchk" + box.id.slice(2)); if (!out) return;
  const { ok, bad } = meaningCheck(box);
  out.innerHTML = (ok.length ? `<span class="okc">Will be saved when you approve: ${ok.map(esc).join("; ")}.</span> ` : "") + (bad.length ? `<span class="err">Not in this file, so not saved: ${bad.map(esc).join("; ")}.</span>` : "");
});

async function ask(b) {
  const id = b.dataset.r, q = $("ask" + id).value.trim(); if (!q) return;
  const label = b.textContent; b.disabled = true; b.textContent = b.dataset.wait || "the model is answering…";
  try { await api("POST", `/api/agents/reviews/${id}/ask`, { message: q, admin: S.admin }); $("ask" + id).value = ""; await render(true); }
  catch (e) { $("msg" + id).innerHTML = `<span class="err">${esc(e.message)}</span>`; b.disabled = false; b.textContent = label; }
}

// ------------------------------------------------------------------ a run that is not a flow (one family alone, one rule alone)
const KIND_WORDS = { flow: "The flow", family1: "Family 1 alone", family2: "Family 2 alone", rule_draft: "Procedure", rule_run: "Rule run", rule_code: "Code it", rule_exec: "Run" };
async function renderRunPage(m, rid, quiet) {
  const ui = quiet ? captureUi(m) : null, y = window.scrollY, tok = S.tok;
  const v = await api("GET", "/api/agents/runs/" + rid);
  if (tok !== S.tok) return;
  if (v.run.kind === "flow") { location.replace(`#/p/${v.run.project}`); return; }
  crumb(`<b>${esc(KIND_WORDS[v.run.kind] || v.run.kind)} · ${esc(v.run.target || "")}</b>`);
  const open = v.reviews.find(r => r.state === "open");
  const running = v.steps.find(s => s.state === "running");
  m.innerHTML = `<div class="phead"><div><h1>${esc(KIND_WORDS[v.run.kind] || v.run.kind)}: ${esc(v.run.target || "")}</h1><div class="meta">run ${v.run.id} · ${when(v.run.created)}${v.run.summary ? " · " + esc(v.run.summary) : ""}</div></div><span class="pill ${v.run.state === "finished" ? "ok" : v.run.state === "running" ? "run" : ""}">${esc(STATE_WORDS[v.run.state] || v.run.state)}</span></div>
    <div class="stack">${open ? decisionCard(open, v.steps.find(s => s.id === open.step), v) : ""}
    ${running ? `<div class="working"><span class="spin"></span><div class="grow"><b>${esc(running.title)}</b>${progressView(running)}</div></div>` : ""}
    <section class="card"><div class="tl">${v.steps.map(s => stepRow(s, v)).join("")}</div></section></div>`;
  if (ui) restoreUi(m, ui);
  if (quiet) window.scrollTo(0, y);
  S.shown = { rid, sig: sigOf(v) };
}

// ------------------------------------------------------------------ history
async function renderHistory(m) {
  crumb("<b>History</b>"); await refreshState();
  const runs = await api("GET", "/api/agents/runs"), pn = Object.fromEntries(S.state.projects.map(p => [p.id, p.name]));
  m.innerHTML = `<div class="stitle"><div><h2>Every run</h2><p>The flows and the single runs of every analysis, newest first.</p></div></div>
    <section class="card">${runs.length ? `<div class="tbl" style="border:0"><table><tr><th>run</th><th>analysis</th><th>what</th><th>state</th><th>started by</th><th>started</th><th></th></tr>${runs.map(r => `<tr><td>${r.id}</td><td>${esc(pn[r.project] || "-")}</td><td>${esc(KIND_WORDS[r.kind] || r.kind)}${r.kind !== "flow" && r.target ? " · " + esc(r.target) : ""}</td><td><span class="pill ${r.state === "finished" ? "ok" : r.state === "running" ? "run" : ""}">${esc(STATE_WORDS[r.state] || r.state)}</span></td><td>${esc(r.started_by || "-")}</td><td class="small">${when(r.created)}</td><td><a class="btn small" href="${r.kind === "flow" ? "#/p/" + r.project : "#/run/" + r.id}">Open</a></td></tr>`).join("")}</table></div>` : `<div class="empty">No run yet.</div>`}</section>`;
}

// ------------------------------------------------------------------ the rules library (Family 3), opened from page 3
async function renderLibrary(m, addr) {
  crumb("<b>Rules library</b>");
  const st = rbState("lib");
  st.mode = "lib"; st.ticks = null;
  st.up = S.project ? (((S.state && S.state.projects) || []).find(p => p.id === S.project) || {}).upload_id || null : null;
  if (addr.length === 3) { st.sel = { sec: addr[0], lvl: addr[1] }; st.open = null; }
  m.innerHTML = `<div class="stitle"><div><div class="who">Family 3</div><h2>Rules library</h2><p>Every section, level and item the agents know. Pick a level on the left and open an item to see its rule: what it checks, where the rule comes from, the file columns it reads, how it decides with the code, and what it finds in ${st.up ? "the open analysis" : "an analysis (open one to see that part)"}.</p></div>
      <div class="row">${S.project ? `<a class="btn small" href="#/p/${S.project}/rules">${IC.left}Back to the flow</a>` : ""}</div></div>
    <div class="rb rb-lib" data-rb="lib">${rbInner("lib")}</div>`;
  await rbLoad("lib");
  if (addr.length === 3) rbOpen("lib", addr.join("/"));
  if (S.prefill) setTimeout(applyPrefill, 100);          // a rule drafted in the side panel fills the library's own form
}

// ------------------------------------------------------------------ one listener for every action on the page
$("main").addEventListener("click", async e => {
  const b = e.target.closest("[data-act]"); if (!b || b.disabled) return;
  const act = b.dataset.act;
  if (act === "stage") { nav(`#/p/${b.dataset.pid}/${b.dataset.stage}`); return; }
  if (act === "go") { nav(b.dataset.href); return; }
  if (act === "check-folder") return checkFolder();
  if (act === "rea-check") return reaCheck();
  if (act === "rea-read") return reaRead();
  if (act === "rea-ask") return reaAsk();
  if (act === "make") return makeProject();
  if (act === "start-flow") return askStarter(b.dataset.pid);
  if (act === "stop") return stopRun(b.dataset.rid, b);
  if (act === "del-proj") return confirmDelete(b.dataset.pid, b.dataset.name);
  if (act === "retry") { await api("POST", `/api/agents/runs/${b.dataset.rid}/retry`); toast("Running the step again"); render(true); return; }
  if (act === "reopen") return reopenAt(b);
  if (act === "dec") return decide(b);
  if (act && act.startsWith("jw-")) return jwAct(act, b);
  if (act === "win") return windowAgain(b);
  if (act === "ask") return ask(b);
  if (act === "dict-more") return dictMore(b);
  if (act === "rb-pick") { const st = rbState(b.dataset.rb); st.sel = { sec: b.dataset.sec, lvl: b.dataset.lvl }; st.open = null; st.q = ""; st.view = null; st.delAsk = null; rbRedraw(b.dataset.rb); return; }
  if (act === "rb-deleted") { const st = rbState(b.dataset.rb); st.view = "deleted"; st.open = null; st.q = ""; rbRedraw(b.dataset.rb); return; }
  if (act === "rb-restore") {
    if (!S.admin) { openSettings(true); return; }
    const id = b.dataset.rb, st = rbState(id); b.disabled = true;
    try {
      const x = await api("POST", `/api/agents/rules/${[b.dataset.sec, b.dataset.lvl, b.dataset.rid].map(encodeURIComponent).join("/")}/restore`, { admin: S.admin });
      st.deleted = x.deleted_items || []; st.view = null;            // the restored item is shown in its place
      await rbLoad(id, { sec: b.dataset.sec, lvl: b.dataset.lvl });
      toast(`Restored “${x.restored.name}” to its place${st.ticks ? " (not ticked: tick it to run it)" : ""}`);
    } catch (e) { b.disabled = false; toast(e.message); }
    return;
  }
  if (act === "rb-open") return rbOpen(b.dataset.rb, b.dataset.key);
  if (act === "rb-addsec") return rbAddSection(b.dataset.rb);
  if (["rb-edit", "rb-cancel", "rb-reload", "rb-save", "rb-del", "rb-delno", "rb-delgo", "rb-showcode", "rb-code", "rb-run", "rb-retry", "rb-dec", "rb-samples", "rb-sshow", "rb-snext", "rb-sexport", "rb-try"].includes(act)) return rbAct(b);
  if (act === "rb-additem") return rbAddItem(b.dataset.rb);
  if (act === "lib-edit" || act === "lib-proceed") {
    if (!S.project) { $("lib-out").innerHTML = `<span class="err">open an analysis first</span>`; return; }
    try {
      const x = act === "lib-edit" ? await api("POST", `/api/agents/rules/${b.dataset.addr}/edit`, { project: S.project, message: $("lib-msg").value })
        : await api("POST", `/api/agents/rules/${b.dataset.addr}/proceed`, { project: S.project });
      nav(`#/run/${x.run}`);
    } catch (er) { $("lib-out").innerHTML = `<span class="err">${esc(er.message)}</span>`; }
  }
});
$("main").addEventListener("change", e => {
  const x = e.target;
  if (x.dataset && x.dataset.rbs) { const u = rbUi(rbState(x.dataset.rbs), x.dataset.key), f = x.dataset.f; u[f] = f === "sa" ? x.checked : f === "sf" ? x.value : Math.max(f === "sl" ? 2 : 1, parseInt(x.value, 10) || 0); return; }
  if (x.matches && x.matches("input[data-plan]")) { const st = rbState(x.dataset.plan); if (st.ticks) st.ticks[x.dataset.key] = x.checked; rbRedraw(x.dataset.plan); }
});
$("main").addEventListener("keydown", e => { if (e.target.id === "np-folder" && e.key === "Enter") { e.preventDefault(); checkFolder(); } });
$("main").addEventListener("input", e => {
  if (e.target.id === "np-name" || e.target.id === "np-folder") nameHint();
  if (e.target.dataset && e.target.dataset.rbj) rbUi(rbState(e.target.dataset.rbj), e.target.dataset.key).draft = e.target.value;
  if (e.target.dataset && e.target.dataset.rbs) { const u = rbUi(rbState(e.target.dataset.rbs), e.target.dataset.key), f = e.target.dataset.f; u[f] = f === "sa" ? e.target.checked : f === "sf" ? e.target.value : Math.max(f === "sl" ? 2 : 1, parseInt(e.target.value, 10) || 0); }   // sl, sc, tryN
  const q = e.target.dataset && e.target.dataset.rbq;
  if (q) { rbState(q).q = e.target.value.trim(); clearTimeout(S.qT); S.qT = setTimeout(() => rbRedraw(q), 200); }
});
// after a draw, the plan summary is filled in
new MutationObserver(() => document.querySelectorAll(".rb[data-rb]").forEach(p => planSummary(p.dataset.rb))).observe($("main"), { childList: true });

(async () => {
  await refreshState();
  if (!location.hash || location.hash === "#") { if (S.project && S.state && S.state.projects.find(p => p.id === S.project)) location.replace(`#/p/${S.project}`); }
  render();
  setInterval(refreshState, 6000);
  setInterval(watch, 2500);
})();

// ------------------------------------------------------------------ the side panel: talk to the data (owner, 2026-11-10: "keep a separate agent at the side
// ... I can talk to the data expert agents and builder agents ... ask the database directly ... then add the rules"; research: reports/Data chat agent for
// rule authoring.md). Beside the page, never inside a card; it says what it is connected to and what it cannot do; every answer shows how it was
// answered, the rows of each query and the query itself; a rule it proposes only fills the rules library's own forms.
S.side = { open: (() => { try { return localStorage.getItem("agents.side") === "1"; } catch (e) { return false; } })(), agent: "data", data: {}, busy: false };
const SIDE_ORDER = ["data", "builder", "rules"];
function sidePid() { const r = route(); if (r[0] === "p" && r[1]) return Number(r[1]); if (r[0] === "library" || r[0] === "run") return S.project || null; return null; }
function sidePage() {
  const r = route();
  if (r[0] === "p") { const cur = document.querySelector(".stg.cur"), st = STAGES.find(s => s.id === ((cur && cur.dataset.stage) || r[2])) || null; /* the stage the page shows */ return { title: st ? `${st.n} · ${st.title}` : "the analysis", stage: st ? st.id : "", url: location.hash }; }
  if (r[0] === "library") { const st = rbState("lib"); return { title: "Rules library", item: st.open || "", url: location.hash }; }
  if (r[0] === "run") return { title: "run " + r[1], url: location.hash };
  return { title: "", url: location.hash };
}
function sideShow() {
  const pid = sidePid(), btn = $("side-btn"), side = $("side");
  btn.hidden = !pid;
  btn.classList.toggle("on", !!(pid && S.side.open));
  const open = !!(pid && S.side.open);
  side.hidden = !open;
  document.body.classList.toggle("side-open", open);
  const top = document.querySelector("header.top"); if (top) side.style.top = top.offsetHeight + "px";
  if (open && (S.side.pid !== pid || !S.side.data[S.side.agent])) { S.side.pid = pid; S.side.data = {}; sideLoad(); }
  else if (open) sideDraw();
}
async function sideLoad() {
  const pid = S.side.pid, ag = S.side.agent;
  try { S.side.data[ag] = await api("GET", `/api/agents/projects/${pid}/chat?agent=${ag}`); } catch (e) { S.side.data[ag] = { error: e.message, turns: [] }; }
  sideDraw(true);
}
function sideRows(q) {
  if (q.error) return `<div class="err small">${esc(q.error)}</div>`;
  if (!(q.rows || []).length) return `<div class="small muted">no rows</div>`;
  return `<div class="tbl"><table><tr>${(q.columns || []).map(c => `<th>${esc(c)}</th>`).join("")}</tr>${q.rows.slice(0, 12).map(r => `<tr>${r.map(v => `<td>${esc(v === null ? "" : String(v))}</td>`).join("")}</tr>`).join("")}</table></div>
    ${q.rows.length > 12 || q.more_rows ? `<div class="small muted">${q.more_rows ? "more rows than shown: the query was cut at its limit" : `the first 12 of ${q.rows.length}`}</div>` : ""}`;
}
function sideTurn(t, i, agents) {
  if (t.who === "admin") return `<div class="sm me"><div class="who">${esc(t.by || "you")}${(t.page || {}).title ? ` · on ${esc(t.page.title)}` : ""}</div><div class="stext">${esc(t.text)}</div></div>`;
  const qs = t.queries || [], a = agents[t.agent] || {};
  const steps = (t.steps || []).map(s => `<li>${esc(s.say)}${s.query != null && qs[s.query] ? ` <a href="#" data-sact="rows" data-k="${i}-${s.query}">the rows</a>` : ""}</li>`).join("");
  const qhtml = qs.map((q, k) => `<details data-id="sq-${i}-${k}" id="sq-${i}-${k}"><summary>Query ${k + 1}: ${q.error ? "did not run" : `${nf((q.rows || []).length)}${q.more_rows ? "+" : ""} row${(q.rows || []).length === 1 ? "" : "s"}${q.seconds != null ? `, ${q.seconds} s` : ""}`}</summary>
      ${sideRows(q)}<details><summary>Show the query</summary><pre>${esc(q.sql || "")}</pre></details></details>`).join("");
  const num = t.numbers ? (t.numbers.ok ? `<div class="note-ok">Every number in the answer is in a query result, or in your question.</div>`
    : `<div class="note-warn">These numbers are in no query result: ${t.numbers.missing.map(esc).join(", ")}. Check them before you use them.</div>`) : "";
  const p = t.proposal;
  const canEdit = p && ((t.page || {}).item || (route()[0] === "library" && rbState("lib").open));
  const prop = p ? `<div class="sprop"><div class="lbl2">${p.kind === "edit_rule" ? "A change to the open item, from this conversation" : "A rule from this conversation"}</div>
      <div><b>${esc(p.name || "(no name yet)")}</b>${p.section ? ` · ${esc(p.section === "errors" ? "Errors" : "Data analytics")} › ${esc(LEVEL_LABELS[p.level] || p.level || "")}` : ""}</div>
      <div class="small" style="white-space:pre-wrap">${esc(p.in_words)}</div>${(p.open_questions || []).length ? `<div class="small muted">Still to decide: ${p.open_questions.map(esc).join(" · ")}</div>` : ""}
      <div class="row" style="margin-top:6px;gap:6px;flex-wrap:wrap"><button class="btn small primary" data-sact="add" data-t="${i}">Add it as a new item…</button>${canEdit ? `<button class="btn small" data-sact="edit" data-t="${i}">Use it to change the open item…</button>` : ""}</div>
      <p class="small muted" style="margin:4px 0 0">This opens the rules library's own form, filled in. Nothing is saved until you press its button; then Save and code it works as always.</p></div>` : "";
  return `<div class="sm"><div class="who">${esc(a.name || t.agent)} <span title="${esc(t.by || "")}">· ${esc(/stand-in|nobody/.test(t.by || "") ? t.by : "the model's answer")}</span></div><div class="stext">${esc(t.text)}</div>
    ${steps ? `<div class="lbl2" style="margin-top:6px">How it was answered</div><ol class="small">${steps}</ol>` : ""}${qhtml}${num}${prop}</div>`;
}
const LEVEL_LABELS = { nvme_command: "NVMe commands", nvme_transaction: "NVMe transactions", split: "split transactions", link: "link transactions", packets: "packets" };
function sideDraw(scroll) {
  const side = $("side"); if (side.hidden) return;
  const d = S.side.data[S.side.agent] || {}, agents = d.agents || {}, c = d.connected || {}, page = sidePage();
  const keep = ($("side-q") || {}).value || "";
  const tabs = SIDE_ORDER.map(k => `<button data-sact="agent" data-agent="${k}" class="${k === S.side.agent ? "on" : ""}" title="${esc((agents[k] || {}).knows || "")}">${esc((agents[k] || {}).name || k)}</button>`).join("");
  const me = agents[S.side.agent] || {};
  side.innerHTML = `<div class="sh"><h3>Ask the data <span class="sp"></span><button class="btn small quiet" data-sact="clear" title="start a new conversation with this agent">New conversation</button><button class="btn small quiet" data-sact="close">Close</button></h3>
      <div class="tabs">${tabs}</div>
      ${me.knows ? `<div class="conn"><b>${esc(me.name)}</b> (${esc(me.family)}) knows ${esc(me.knows)}.</div>` : ""}
      <div class="conn">Connected to: ${esc(c.words || "…")}${c.rows ? ` (${Object.entries(c.rows).map(([f, n]) => `${nf(n)} rows of ${f}`).join(", ")})` : ""}${(c.dictionaries || []).length ? `; the approved meanings of ${c.dictionaries.length} file${c.dictionaries.length === 1 ? "" : "s"}` : "; no approved column meanings yet"}.
        It only reads: it cannot change the recording, the tree or a rule. ${d.limits ? `Each query gives at most ${d.limits.rows} rows and stops after ${d.limits.seconds} s.` : ""}</div>
      <div class="chips">It sees: <span>${esc(page.title || "this page")}</span>${page.item ? `<span>the open item: ${esc(page.item.split("/").pop().replace(/_/g, " "))}</span>` : ""}<span>the conversation with this agent</span></div></div>
    <div class="sb" id="side-body">${d.error ? `<p class="err">${esc(d.error)}</p>` : ""}${(d.turns || []).map((t, i) => sideTurn(t, i, agents)).join("") || `<p class="small muted">Ask about this recording: for example “how many writes never completed, and on which queues?”, “what does the Link Tra Error column hold?”, or “which link transactions are under command 155?”.</p>`}</div>
    <div class="sf"><textarea id="side-q" placeholder="ask ${esc(me.name || "the agent")} about this recording">${esc(keep)}</textarea>
      <div class="row" style="gap:8px;align-items:center"><button class="btn small primary" data-sact="send" ${S.side.busy ? "disabled" : ""}>${S.side.busy ? "looking at the data…" : "Ask"}</button><span class="small muted" id="side-msg"></span></div></div>`;
  if (scroll) { const b = $("side-body"); if (b) b.scrollTop = b.scrollHeight; }
}
async function sideSend() {
  const q = (($("side-q") || {}).value || "").trim(); if (!q || S.side.busy) return;
  if (!S.admin) { openSettings(true); return; }
  S.side.busy = true; sideDraw();
  try { const x = await api("POST", `/api/agents/projects/${S.side.pid}/chat`, { agent: S.side.agent, message: q, admin: S.admin, page: sidePage() });
        S.side.data[S.side.agent].turns = x.turns; $("side-q").value = ""; }
  catch (e) { S.side.busy = false; sideDraw(); $("side-msg").innerHTML = `<span class="err">${esc(e.message)}</span>`; return; }
  S.side.busy = false; sideDraw(true);
}
function sideEvidence(t) {
  const steps = (t.steps || []).map(s => "- " + s.say).join("\n"), qs = (t.queries || []).filter(q => !q.error).map(q => "- " + q.sql).join("\n");
  return `\n\nFrom the conversation with the ${(S.side.data[S.side.agent].agents[t.agent] || {}).name || t.agent} on ${new Date(t.at * 1000).toLocaleString()}:\n${t.text}${steps ? "\nHow it was answered:\n" + steps : ""}${qs ? "\nThe queries:\n" + qs : ""}`;
}
async function sideAct(b) {
  const act = b.dataset.sact, d = S.side.data[S.side.agent] || {};
  if (act === "close") { S.side.open = false; try { localStorage.setItem("agents.side", "0"); } catch (e) { /* private window */ } sideShow(); return; }
  if (act === "agent") { S.side.agent = b.dataset.agent; if (!S.side.data[S.side.agent]) await sideLoad(); else sideDraw(true); return; }
  if (act === "send") return sideSend();
  if (act === "clear") { await api("POST", `/api/agents/projects/${S.side.pid}/chat/clear`, { agent: S.side.agent }); d.turns = []; sideDraw(); return; }
  if (act === "rows") { const det = document.getElementById("sq-" + b.dataset.k); if (det) { det.open = true; det.scrollIntoView({ block: "nearest" }); } return; }
  const t = (d.turns || [])[Number(b.dataset.t)]; if (!t || !t.proposal) return;
  const p = t.proposal;
  if (act === "add") { S.prefill = { kind: "add", sec: p.section || "errors", lvl: p.level || "nvme_command", name: p.name || "", words: p.in_words + sideEvidence(t) }; if (route()[0] === "library") applyPrefill(); else nav("#/library"); return; }
  if (act === "edit") { const key = (t.page || {}).item || rbState("lib").open; S.prefill = { kind: "edit", key, words: p.in_words + sideEvidence(t) }; if (route()[0] === "library") applyPrefill(); else nav("#/library/" + key); return; }
}
// the rules library's own forms, filled from the panel; the admin presses their buttons
async function applyPrefill() {
  const f = S.prefill; if (!f) return; S.prefill = null;
  const st = rbState("lib");
  if (f.kind === "add") {
    st.sel = { sec: f.sec, lvl: f.lvl }; st.open = null; rbRedraw("lib");
    await new Promise(r => setTimeout(r, 50));
    const det = document.querySelector('details[data-id="additemlib"]'); if (det) det.open = true;
    if ($("ainlib")) $("ainlib").value = f.name; if ($("aidlib")) $("aidlib").value = f.words;
    if (det) det.scrollIntoView({ block: "center" });
    toast("Filled in from the conversation: read it, change it if needed, then press Add it");
  } else if (f.kind === "edit" && f.key) {
    if (st.open !== f.key) rbOpen("lib", f.key);
    await new Promise(r => setTimeout(r, 400));
    const box = $("lib-msg"); if (box) { box.value = f.words; const det = box.closest("details"); if (det) det.open = true; box.scrollIntoView({ block: "center" }); }
    toast("Filled in from the conversation: read it, then ask the Rule writer to make the change");
  }
}
$("side-btn").addEventListener("click", () => { S.side.open = !S.side.open; try { localStorage.setItem("agents.side", S.side.open ? "1" : "0"); } catch (e) { /* private window */ } sideShow(); });
$("side").addEventListener("click", e => { const b = e.target.closest("[data-sact]"); if (!b || b.disabled) return; e.preventDefault(); sideAct(b); });
$("side").addEventListener("keydown", e => { if (e.target.id === "side-q" && e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); sideSend(); } });
window.addEventListener("hashchange", () => setTimeout(sideShow, 0));
window.addEventListener("resize", () => sideShow());
setTimeout(sideShow, 300);

// one row of a file, opened from "Where in the files" (owner, 2026-11-10: "when someone clicks ... it has to show by opening the particular file:
// this is the place, this is the meaning of the error")
async function openRowCard(a) {
  let x;
  try { x = await api("GET", `/api/hier/uploads/${encodeURIComponent(a.dataset.rowcard)}/rowcard?level=${encodeURIComponent(a.dataset.level)}&rowid=${encodeURIComponent(a.dataset.row)}`); }
  catch (e) { toast(e.message); return; }
  const def = (x.defects || []).map(f => `<div class="jnote" style="margin-top:6px"><b>${esc(f.name)}</b><div class="small" style="margin-top:4px">The rule: ${esc(f.rule_words)}.${f.why ? " " + esc(f.why) : ""}</div>${f.source ? `<div class="small muted">${esc(f.source)}</div>` : ""}</div>`).join("");
  const picker = document.querySelector(`select[id^=df] option[value="${CSS.escape(a.dataset.fid || "")}"]`);
  openModal(`<div class="mhead"><h2>Row ${nf(x.row)} of ${esc(x.file)}</h2><button class="btn quiet small" data-act="close">Close</button></div>
    <p class="small">The file: <code>${esc(x.path || x.file)}</code><br>Row ${nf(x.row)} under the header: a spreadsheet shows it on line ${nf(x.spreadsheet_line)}${x.analyzer_number != null && x.analyzer_number !== x.row ? `; the analyzer's own number for it is ${nf(x.analyzer_number)}` : ""}.</p>
    ${def ? `<div class="lbl2">Why it is a defect</div>${def}` : `<p class="small muted">No rule found a defect on this row.</p>`}
    <div class="lbl2" style="margin-top:10px">Every cell of this row</div><p class="small muted">Meanings: ${esc(x.meanings_from)}.</p>
    <div class="tbl" style="max-height:44vh;overflow:auto"><table><tr><th>column</th><th>value</th><th>what it means</th></tr>${(x.cells || []).map(c => `<tr><td><b>${esc(c.column)}</b></td><td>${esc(c.value)}</td><td class="small">${esc(c.meaning || "no meaning approved yet")}${c.source ? `<div class="tiny muted">${esc(c.source)}</div>` : ""}</td></tr>`).join("")}</table></div>
    <div class="actions">${picker ? `<button class="btn" id="rc-tree">Show it under its command, down to the packets</button>` : ""}<button class="btn quiet" data-act="close">Close</button></div>`);
  document.querySelectorAll('#modal [data-act="close"]').forEach(b => b.onclick = closeModal);
  if (picker && $("rc-tree")) $("rc-tree").onclick = () => {
    const sel = picker.closest("select"); sel.value = a.dataset.fid; sel.dispatchEvent(new Event("change", { bubbles: true }));
    const d = document.querySelector(`details[data-recs="${sel.id.slice(2)}"]`); closeModal();
    if (d) { d.open = true; d.scrollIntoView({ block: "start" }); }
  };
}
document.addEventListener("click", e => { const a = e.target.closest("a[data-rowcard]"); if (!a) return; e.preventDefault(); openRowCard(a); });
