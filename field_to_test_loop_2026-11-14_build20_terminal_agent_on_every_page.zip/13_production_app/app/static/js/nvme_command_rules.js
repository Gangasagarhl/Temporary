/* The NVMe command rules page (owner, 2026-11-12). The rules come from /api/hier/nvme_command_rules (the detector's own
   command rules, with the places in the NVMe specification and the columns of the NVMe command file each one reads); what
   one recording holds from /api/hier/nvme_command_rules/<upload>. Nothing is chosen until the user chooses a recording.
   Every error opens on the one-error page (/isolate), where the procedural graph takes the four signals. */
(function () {
  "use strict";
  const $ = id => document.getElementById(id);
  const esc = s => String(s === null || s === undefined ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const nf = n => Number(n || 0).toLocaleString("en-US");
  const many = (n, one, more) => `${nf(n)} ${Number(n) === 1 ? one : (more || one + "s")}`;
  const state = { cat: null, rec: null, upload: "", shown: {}, timer: null };
  const SIGNALS = [["correct", "correct"], ["correct_with_edits", "correct with edits"], ["wrong", "wrong"], ["wrong_with_edits", "wrong with edits"]];
  const KIND = { error: "error", warning: "warning", check: "to check" };

  async function ask(method, url) {
    const r = await fetch(url, { method, headers: { Accept: "application/json", "Content-Type": "application/json" }, body: method === "GET" ? undefined : "{}" });
    let body = null;
    try { body = await r.json(); } catch (e) { body = null; }
    if (!r.ok) {
      const e = new Error((body && (body.error || body.description)) || (r.status === 404
        ? "this part of the application is not running yet: it starts with the next start of the application"
        : `the application answered with a problem (HTTP ${r.status})`));
      e.status = r.status; throw e;
    }
    return body;
  }
  const status = (text, bad) => { const s = $("status"); s.textContent = text; s.className = "status" + (bad ? " bad" : ""); };
  const recRule = id => (state.rec ? state.rec.rules.find(x => x.id === id) : null);

  function basisLine(b) {
    const mark = b.verified
      ? `<span class="chip ok" title="A few words of this place were looked up in the text of the document itself">read in the document on 12 November 2026</span>`
      : `<span class="chip warn" title="This statement could not be read in the specification text, so no section is named for it">not verified against the specification</span>`;
    return `<li><b>${esc(b.document)}</b>, ${esc(b.revision)}: ${esc(b.place)}. ${esc(b.says)} ${mark}</li>`;
  }

  function columnChip(c, rr) {
    const mine = rr ? rr.columns.find(x => x.file === c.file && x.column === c.column) : null;
    let cls = "", word = "";
    if (mine) {
      if (!mine.file_loaded) { cls = c.needed ? " bad" : " warn"; word = `: ${c.file_words} is not loaded`; }
      else if (mine.present === false) { cls = c.needed ? " bad" : " warn"; word = ": not in the file"; }
      else if (mine.present) { cls = " ok"; word = ": in the file"; }
    }
    return `<span class="chip${cls}" title="${esc(c.use)}. ${c.needed ? "The rule cannot be checked without it." : "Used when it is there; the rule is checked without it."}">${esc(c.column)} (${esc(c.file_words)})${esc(word)}${c.needed ? "" : " · not required"}</span>`;
  }

  function graphLine(id) {
    const g = state.rec && state.rec.graph ? state.rec.graph[id] : null;
    if (!g) return "";
    if (!g.defects && !g.judgements && !g.seen) {
      return `<p class="src">The procedural graph (defect, cause, solution) holds nothing for this rule yet. It starts with the first error of this rule that you isolate and judge on its own page.</p>`;
    }
    const sig = SIGNALS.map(([k, w]) => `${w} ${nf((g.by_signal || {})[k] || 0)}`).join(", ");
    return `<p class="src">The procedural graph holds for this rule, from every recording judged so far: ${many(g.defects, "defect")} stored under ${g.defects === 1 ? "its name" : "their names"}, ${many(g.causes, "cause")}, ${many(g.solutions, "solution")}; seen ${many(g.seen, "time")}; ${many(g.judgements, "judgement")} by the admin (${sig}). These judgements order what is shown first the next time such a defect is isolated.</p>`;
  }

  function forRecording(r) {
    const rr = recRule(r.id);
    if (!rr) return "";
    if (!rr.can_be_checked) return `<div class="for-rec"><span class="cannot">In this recording: ${esc(rr.why_not)}.</span></div>`;
    const kinds = Object.keys(rr.by_kind || {}).map(k => `${nf(rr.by_kind[k])} ${KIND[k] || k}`).join(", ");
    const found = rr.found === null
      ? `<span class="found">The rules have not run on this recording yet.</span>`
      : `<span class="found">${rr.found ? `Found ${many(rr.found, "time")}` : "Checked: found 0 times"}</span>${rr.found && Object.keys(rr.by_kind).length > 1 ? ` (${esc(kinds)})` : ""}${rr.first_line ? ` · first at line ${nf(rr.first_line)} of the NVMe command file` : ""}`;
    const limited = rr.limited ? `<div class="src">${esc(rr.limited)}</div>` : "";
    const opt = (rr.columns_not_in_the_file_but_not_needed || []).length ? `<div class="src">Not in the file, and not required by this rule: ${esc(rr.columns_not_in_the_file_but_not_needed.join(", "))}.</div>` : "";
    const btn = rr.found ? ` <button class="small" data-show="${esc(r.id)}">${state.shown[r.id] ? "Hide the errors" : "Show the errors"}</button>` : "";
    return `<div class="for-rec">In this recording: ${found}${btn}${limited}${opt}<div class="errs" id="errs-${esc(r.id)}">${state.shown[r.id] ? errorsTable(r.id) : ""}</div>${graphLine(r.id)}</div>`;
  }

  function errorsTable(id) {
    const e = state.shown[id];
    if (!e) return "";
    if (e.problem) return `<div class="status bad">The errors could not be read: ${esc(e.problem)}</div>`;
    const back = encodeURIComponent(`/static/nvme_command_rules.html?upload=${state.upload}`);
    const rows = e.rows.map(x => `<tr>
      <td>${esc(x.what)}</td>
      <td class="n">${x.command_number === null || x.command_number === undefined ? "not numbered" : nf(x.command_number)}</td>
      <td class="n">${x.line ? nf(x.line) : ""}</td>
      <td class="n">${esc(x.time || "no time stamp")}</td>
      <td>${esc(x.kind_words)}</td>
      <td><a class="open" href="/isolate?upload=${encodeURIComponent(state.upload)}&finding=${encodeURIComponent(x.finding)}&back=${back}" target="_blank" rel="noopener">Isolate this defect</a></td></tr>`).join("");
    const more = e.has_more ? `<div class="row"><button class="small" data-more="${esc(id)}">Show the next ${nf(state.cat.shown_at_once)}</button><span class="src">${nf(e.rows.length)} of ${nf(e.total)} shown, in the order of the file</span></div>` : `<div class="src">${nf(e.rows.length)} of ${nf(e.total)} shown, in the order of the file.</div>`;
    return `<div class="tablewrap"><table><tr><th>What was found</th><th>NVMe command number (column NVMe Cmd)</th><th>Line of the NVMe command file (line 1 is the header)</th><th>Time from the start of the recording</th><th>How serious</th><th>The defect's own page: isolation, causes, solutions, your four signals</th></tr>${rows}</table></div>${more}`;
  }

  function ruleCard(r) {
    const rr = recRule(r.id);
    const kept = r.kept_by_the_owner ? `<span class="chip" title="The owner chose two NVMe command rules for the flow on 9 November 2026; this is one of them">one of the two rules chosen for the flow</span>` : "";
    return `<div class="rule" id="rule-${esc(r.id)}">
      <h3>${esc(r.name)} ${kept}</h3>
      <p>${esc(r.checks)}</p>
      <div class="lbl">How the code decides</div><p>${esc(r.how)}</p>
      <div class="lbl">What it rests on</div><ul>${r.basis.map(basisLine).join("")}</ul>
      <div class="lbl">Columns it reads</div><div class="cols">${r.columns.map(c => columnChip(c, rr)).join("")}</div>
      <div class="src">Reads ${esc(r.reads.join(" and "))}.${r.partly ? " " + esc(r.partly) : ""}${r.bytes_need && r.bytes_need.length ? ` The returned bytes are read from ${esc(r.bytes_need.join(", "))}.` : ""} What it files: ${esc(r.found_as)}.</div>
      ${forRecording(r)}</div>`;
  }

  function renderColumns() {
    const k = state.rec, box = $("columns");
    if (!k) { box.innerHTML = ""; return; }
    const said = c => !c.file_loaded ? `<span class="chip warn">${esc(c.file_words)} is not loaded</span>` : (c.present ? `<span class="chip ok">in the file</span>` : `<span class="chip bad">not in the file</span>`);
    const filled = c => (c.rows_with_a_value === null || c.rows_with_a_value === undefined || !c.present) ? "" : `${nf(c.rows_with_a_value)} of ${nf(c.rows)} rows`;
    box.innerHTML = `<section><h2>The columns these rules read, and whether this recording carries them</h2>
      <p>Read from the header of each file when the recording was loaded. Rows that hold a value were counted by the loader on every row${k.command_file ? `; the NVMe command file is ${esc(k.command_file)}` : ""}.</p>
      <div class="tablewrap"><table><tr><th>File</th><th>Column</th><th>What the rules use it for</th><th>In this recording</th><th>Rows that hold a value</th></tr>
      ${k.columns.map(c => `<tr><td>${esc(c.file_words)}</td><td><b>${esc(c.column)}</b></td><td>${esc(c.use)}</td><td>${said(c)}</td><td class="n">${filled(c)}</td></tr>`).join("")}</table></div></section>`;
  }

  function render() {
    const c = state.cat; if (!c) return;
    $("sections").innerHTML = c.groups.map(g => {
      const rs = c.rules.filter(r => r.group === g.id);
      return rs.length ? `<section><h2>${esc(g.name)}</h2><p>${esc(g.about)}</p>${rs.map(ruleCard).join("")}</section>` : "";
    }).join("");
    const k = state.rec, box = $("totals");
    $("check").hidden = !k || !k.command_file_loaded; $("csv").hidden = !k || !k.checked;
    if (k) $("csv").href = `/api/hier/nvme_command_rules/${encodeURIComponent(state.upload)}/errors.csv`;
    if (!k) { box.hidden = true; renderColumns(); return; }
    box.hidden = false;
    box.innerHTML = `<div><b>${k.commands === null ? "none" : nf(k.commands)}</b><span>NVMe commands in this recording (rows of the NVMe command file)</span></div>
      <div><b>${nf(k.errors_found)}</b><span>findings of the rules of this page (errors, warnings and things to check; one command can have several)</span></div>
      <div><b>${nf(k.rules_that_cannot_be_checked)} of ${nf(k.rules.length)}</b><span>rules that cannot be checked on this recording (each says why)</span></div>
      <div><b>${esc(k.files_loaded.length)}</b><span>files loaded for this recording: ${esc(k.files_loaded.join(", ") || "none")}</span></div>`;
    renderColumns();
  }

  async function loadErrors(id, more) {
    const cur = state.shown[id];
    const offset = more && cur && cur.rows ? cur.rows.length : 0;
    try {
      const j = await ask("GET", `/api/hier/nvme_command_rules/${encodeURIComponent(state.upload)}/errors?rule=${encodeURIComponent(id)}&offset=${offset}`);
      state.shown[id] = { rows: (more && cur && cur.rows ? cur.rows : []).concat(j.errors), total: j.total, has_more: j.has_more };
    } catch (e) { state.shown[id] = { problem: e.message, rows: [] }; }
    render();
  }

  function onClick(ev) {
    const b = ev.target.closest("button"); if (!b) return;
    if (b.dataset.show) {
      const id = b.dataset.show;
      if (state.shown[id]) { delete state.shown[id]; render(); } else loadErrors(id, false);
    } else if (b.dataset.more) loadErrors(b.dataset.more, true);
  }

  function follow(jid) {
    clearInterval(state.timer);
    $("progress").hidden = false; $("check").disabled = true;
    const tick = async () => {
      let j; try { j = await ask("GET", `/api/jobs/${encodeURIComponent(jid)}`); } catch (e) { return; }
      const p = j.progress || {};
      $("bar").style.width = `${Math.max(1, Math.min(100, Number(p.pct) || 1))}%`;
      $("progress-text").textContent = p.detail || "starting…";
      if (j.status === "done" || j.status === "failed" || j.status === "cancelled") {
        clearInterval(state.timer); $("check").disabled = false; $("progress").hidden = true;
        if (j.status === "done") {
          const r = j.result || {};
          state.shown = {};
          await choose(true);
          status(`Checked again in ${Number(r.seconds || 0).toLocaleString("en-US")} seconds: ${many(r.errors, "finding")} of the rules of this page${r.error_numbers_that_moved ? `; ${many(r.error_numbers_that_moved, "error number")} moved and were followed in the stores` : ""}.`);
        } else status(`The check did not finish: ${(j.error || "it was stopped").split("\n")[0]}`, true);
      }
    };
    state.timer = setInterval(tick, 1500); tick();
  }

  async function check() {
    if (!state.upload) return;
    status("Starting the check…");
    try {
      const j = await ask("POST", `/api/hier/nvme_command_rules/${encodeURIComponent(state.upload)}/check`);
      follow(j.job);
    } catch (e) { status(`The check could not start: ${e.message}`, true); }
  }

  async function choose(quiet) {
    state.upload = $("rec").value; state.rec = null;
    if (quiet !== true) state.shown = {};
    if (!state.upload) { status(`${many(state.cat.rules.length, "rule")} for the NVMe command level. No recording is chosen.`); render(); return; }
    if (quiet !== true) status("Reading what the recording holds…");
    try {
      state.rec = await ask("GET", `/api/hier/nvme_command_rules/${encodeURIComponent(state.upload)}`);
      const k = state.rec;
      if (!k.command_file_loaded) status("This recording was loaded without its NVMe command file: no rule of this page can be checked on it.", true);
      else if (quiet !== true) status(k.checked
        ? `The rules ran on this recording${k.checked_again_at ? `; checked again on ${new Date(k.checked_again_at * 1000).toLocaleString()}` : " when it was loaded"}: ${many(k.errors_found, "finding")} in ${many(k.commands, "command")}.`
        : "The rules have not run on this recording yet.");
      if (k.check_job) follow(k.check_job);
    } catch (e) { status(`The recording could not be read: ${e.message}`, true); }
    render();
  }

  async function start() {
    try { state.cat = await ask("GET", "/api/hier/nvme_command_rules"); }
    catch (e) { status(`The rules could not be read: ${e.message}`, true); return; }
    $("sources").innerHTML = `The specification places named on this page are from: ${state.cat.documents.map(d => `${esc(d.document)}, ${esc(d.revision)}`).join("; ")} (public, at <a href="${esc(state.cat.documents[0].address)}" target="_blank" rel="noopener">${esc(state.cat.documents[0].address)}</a>). The rules themselves are the detector's: the same code decides what an error is on every page of the application.`;
    try {
      const ups = await ask("GET", "/api/hier/uploads");
      for (const u of ups) {
        if (u.status !== "loaded") continue;
        const o = document.createElement("option"); o.value = u.upload_id;
        o.textContent = [u.trace_name || "recording without a name", u.device ? `device ${u.device}` : "", u.recording_date ? `recorded ${u.recording_date}` : "", `loaded as ${u.upload_id}`].filter(Boolean).join(" · ");
        $("rec").appendChild(o);
      }
    } catch (e) { /* the rules alone are still shown */ }
    const want = new URLSearchParams(location.search).get("upload");       // a link from another page may name the recording
    if (want && [...$("rec").options].some(o => o.value === want)) $("rec").value = want;
    $("rec").addEventListener("change", () => choose());
    $("check").addEventListener("click", check);
    $("sections").addEventListener("click", onClick);
    choose();
  }
  start();
})();
