"""The NVMe command errors page (owner, 2026-11-12): every completion status an NVMe command can end with, from the two
public specifications, and how many commands of one loaded recording ended with each. No time limit lives here: those
come from the values the owner gives.

  GET /api/hier/nvme_command_errors            the catalogue (status code types, every entry, the documents)
  GET /api/hier/nvme_command_errors/<upload>   the same question asked of one loaded recording: commands per status

The NVMe command rules page (owner, 2026-11-12, later the same day): only the rules that find an error at the NVMe
command level, what each one rests on in the NVMe specification, the columns of the NVMe command file it reads and
whether the chosen recording carries them, the errors it found, and from each error the way to the one-error page
(/isolate), where the procedural graph takes the four signals. The rules are the detector's own (nvme_hier/rules.py);
what the page says of them is in nvme_hier/nvme_command_rules.py.

  GET  /api/hier/nvme_command_rules                    the rules, their groups and the documents
  GET  /api/hier/nvme_command_rules/<upload>           one loaded recording: the columns, what can be checked, the errors found per rule,
                                                       what the procedural graph holds for each rule
  GET  /api/hier/nvme_command_rules/<upload>/errors    ?rule=<rule>&offset=<n>: the errors of one rule, 200 at a time, in file order
  POST /api/hier/nvme_command_rules/<upload>/check     run the command rules again on the recording (a job with its percentage)
  GET  /api/hier/nvme_command_rules/<upload>/errors.csv   every error of these rules as a CSV file
"""
import os
import re
import sqlite3
import threading
import time

from flask import Blueprint, jsonify, request, send_file

from . import svc, whole, as_text
from . import hier_api as H
from nvme_hier import nvme_command_errors as NE
from nvme_hier import nvme_command_rules as NR

bp = Blueprint("nvme_errors", __name__)


@bp.get("/api/hier/nvme_command_errors")
def nvme_command_errors():
    return jsonify({"summary": NE.summary(), "types": NE.types(), "entries": NE.catalogue(),
                    "keys": {NE.key(e): i for i, e in enumerate(NE.catalogue()) if e["scope"] == "pcie"}})


@bp.get("/api/hier/nvme_command_errors/<uid>")
def nvme_command_errors_of(uid):
    s = svc()
    d = H.upload_dir(s, uid)
    if not d:
        return jsonify({"error": "no such upload: this recording is not among the loaded ones"}), 404
    db = H.db_of(d)
    meta = H.read_meta(d) or {}
    if not os.path.exists(db):
        return jsonify({"error": "this recording has not been loaded yet, so its NVMe commands cannot be counted"}), 409
    try:
        got = NE.count(db)
    except sqlite3.Error as e:
        return jsonify({"error": "the NVMe commands of this recording cannot be read (%s): load the recording again" % e}), 409
    got.update({"upload_id": uid, "trace_name": meta.get("trace_name"), "device": meta.get("device"),
                "recording_date": meta.get("recording_date"), "status": meta.get("status")})
    return jsonify(got)


# ---------------------------------------------------------------------------------------------- the NVMe command rules page
_CHECKS = {}                    # upload id -> the job that is checking it now
_CHECKS_LOCK = threading.Lock()


def _graph_db(s):
    return os.path.join(s.root, "db", "hier_knowledge.sqlite")


def _recording(uid):
    """(services, folder, database, meta) of a loaded recording, or (None, answer) when it cannot be used."""
    s = svc()
    d = H.upload_dir(s, uid)
    if not d:
        return None, (jsonify({"error": "no such upload: this recording is not among the loaded ones"}), 404)
    db = H.db_of(d)
    if not os.path.exists(db):
        return None, (jsonify({"error": "this recording has not been loaded yet, so its NVMe commands cannot be checked"}), 409)
    return (s, d, db, H.read_meta(d) or {}), None


def _check_running(s, uid):
    """The job that is checking this recording now, or None."""
    with _CHECKS_LOCK:
        jid = _CHECKS.get(uid)
        if not jid:
            return None
        j = s.jobs.get(jid) or {}
        if j.get("status") in ("done", "failed", "cancelled") or not j:
            _CHECKS.pop(uid, None)
            return None
        return jid


@bp.get("/api/hier/nvme_command_rules")
def nvme_command_rules():
    return jsonify({"groups": NR.groups(), "rules": NR.rules(), "documents": NR.documents(), "shown_at_once": NR.SHOWN_AT_ONCE,
                    "status_list": "/nvme-errors"})


@bp.get("/api/hier/nvme_command_rules/<uid>")
def nvme_command_rules_of(uid):
    got, bad = _recording(uid)
    if bad:
        return bad
    s, _d, db, meta = got
    try:
        out = NR.status(db)
    except sqlite3.Error as e:
        return jsonify({"error": "the NVMe commands of this recording cannot be read (%s): load the recording again" % e}), 409
    out.update({"upload_id": uid, "trace_name": meta.get("trace_name"), "device": meta.get("device"), "recording_date": meta.get("recording_date"),
                "status": meta.get("status"), "loaded_at": meta.get("loaded_at"), "check_job": _check_running(s, uid),
                "graph": NR.graph_memory(_graph_db(s))})
    return jsonify(out)


@bp.get("/api/hier/nvme_command_rules/<uid>/errors")
def nvme_command_rule_errors(uid):
    got, bad = _recording(uid)
    if bad:
        return bad
    _s, _d, db, _meta = got
    rule = as_text(request.args.get("rule"), "rule")
    if rule not in NR.BY_ID:
        return jsonify({"error": "no such rule: choose one of the rules of this page"}), 400
    offset = whole(request.args.get("offset", 0), "offset")
    try:
        return jsonify(NR.errors(db, rule, offset=offset))
    except sqlite3.Error as e:
        return jsonify({"error": "the errors of this recording cannot be read (%s): load the recording again" % e}), 409


def _run_check(jid, params, mgr):
    """The job: the command rules again, with how far they are; then the moved error numbers are followed in the stores."""
    from agentic import core
    from .dg_api import graph as _dg
    s, uid, db = params["_services"], params["upload_id"], params["db"]
    total, t0 = max(1, params.get("commands") or 1), time.time()

    def progress(step, detail=""):
        m = re.search(r"([\d,]+) rows", detail or "")
        if "roll-up" in step:
            pct, what = 90, "the errors are numbered by time and counted per command"
        elif m:
            done = int(m.group(1).replace(",", ""))
            pct, what = 5 + 80.0 * min(done, total) / total, "%s of %s commands read" % ("{:,}".format(done), "{:,}".format(total))
        else:
            pct, what = 5, "reading the commands"
        mgr.progress(jid, "checking the NVMe commands", core.progress_text(pct, t0, what), round(pct, 1))
    out = {}
    try:
        res = NR.check(db, dict(params.get("thresholds") or {}), progress=progress, out=out)
        moved = out.get("renumbered") or {}
        if moved and "_count" not in moved:
            H.knowledge(s).remap_findings(uid, moved)
            _dg(s).remap_findings(uid, moved)
        con = sqlite3.connect(db)
        try:
            H.ensure_indexes(con)
        finally:
            con.close()
        res["error_numbers_that_moved"] = len(moved) if "_count" not in moved else moved["_count"]
        return res
    finally:
        with _CHECKS_LOCK:
            if _CHECKS.get(uid) == jid:
                _CHECKS.pop(uid, None)


@bp.post("/api/hier/nvme_command_rules/<uid>/check")
def nvme_command_rules_check(uid):
    got, bad = _recording(uid)
    if bad:
        return bad
    s, _d, db, meta = got
    if meta.get("status") == "loading":
        return jsonify({"error": "this recording is still loading: check it when the load has finished"}), 409
    if meta.get("status") != "loaded":
        return jsonify({"error": "this recording was not loaded completely (%s): load it again, then check it" % (meta.get("status") or "no state recorded")}), 409
    running = _check_running(s, uid)
    if running:
        return jsonify({"job": running, "already_running": True})
    try:
        st = NR.status(db)
    except sqlite3.Error as e:
        return jsonify({"error": "the NVMe commands of this recording cannot be read (%s): load the recording again" % e}), 409
    if not st["command_file_loaded"]:
        return jsonify({"error": "this recording was loaded without its NVMe command file: there is no command to check"}), 409
    params = {"upload_id": uid, "db": db, "thresholds": meta.get("thresholds") or {}, "commands": st["commands"]}
    with _CHECKS_LOCK:
        jid = s.jobs.create("nvme_command_rules", params)
        _CHECKS[uid] = jid
    s.jobs.start(jid, lambda j, p, mgr: _run_check(j, dict(p, _services=s), mgr))
    return jsonify({"job": jid})


@bp.get("/api/hier/nvme_command_rules/<uid>/errors.csv")
def nvme_command_rule_errors_csv(uid):
    got, bad = _recording(uid)
    if bad:
        return bad
    _s, d, db, _meta = got
    path = os.path.join(d, "nvme_command_rule_errors.csv")
    try:
        NR.export_csv(db, path)
    except (sqlite3.Error, OSError) as e:
        return jsonify({"error": "the file could not be written (%s)" % e}), 409
    return send_file(path, mimetype="text/csv", as_attachment=True, download_name="nvme_command_errors_%s.csv" % uid, max_age=0)
