"""The investigation agent's routes (agentic/investigate.py): the admin's questions to a held terminal session of the
analysis, what the agent is doing now, and the CSV files it exported."""
from flask import Blueprint, jsonify, request, send_file

from . import svc, as_text
from .agentic_api import engine, admin_of
from agentic import investigate as INV   # noqa: E402

bp = Blueprint("investigate", __name__)


def _project(pid):
    return engine().store.one("SELECT * FROM project WHERE id=?", (pid,))


@bp.get("/api/agents/projects/<int:pid>/investigate")
def investigate_state(pid):
    p = _project(pid)
    if not p:
        return jsonify({"error": "no such analysis"}), 404
    return jsonify(INV.state(engine(), p))


@bp.post("/api/agents/projects/<int:pid>/investigate")
def investigate_ask(pid):
    p = _project(pid)
    if not p:
        return jsonify({"error": "no such analysis"}), 404
    body = request.get_json(force=True, silent=True) or {}
    if not isinstance(body, dict):
        return jsonify({"error": "the request must be a set of named fields"}), 400
    try:
        out = INV.ask(engine(), p, as_text(body.get("question"), "question"), admin_of(body))
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify(dict(INV.state(engine(), p), **out))


@bp.post("/api/agents/projects/<int:pid>/investigate/stop")
def investigate_stop(pid):
    p = _project(pid)
    if not p:
        return jsonify({"error": "no such analysis"}), 404
    return jsonify(INV.stop(engine(), p))


@bp.get("/api/agents/projects/<int:pid>/investigate/exports/<name>")
def investigate_export(pid, name):
    p = _project(pid)
    path = INV.export_path(engine(), pid, name) if p else None
    if not path:
        return jsonify({"error": "no such exported file"}), 404
    return send_file(path, as_attachment=True, download_name=name)


@bp.post("/api/agents/projects/<int:pid>/investigate/exports/<name>/add")
def investigate_add(pid, name):
    p = _project(pid)
    if not p:
        return jsonify({"error": "no such analysis"}), 404
    try:
        dst = INV.add_to_analysis(engine(), p, name)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"added": name, "to": dst, "next": "press Read the new files on the card after Family 1: only this file gets its three agents"})


# ---- the terminal agent from every page (owner, 2026-11-14: "each and every page should have communication with the
# terminal agent"): the same agent and the same sessions; the place is the analysis the page shows (pid), else the analysis
# the recording on the page belongs to (upload), else the application
def _place(src):
    src = src if isinstance(src, dict) else {}
    pid, up = src.get("pid"), src.get("upload")
    if isinstance(pid, bool) or not isinstance(pid, (str, int, type(None))) or not isinstance(up, (str, type(None))):
        return None, "pid must be the analysis number and upload the recording's upload number"
    return INV.place_for(engine(), pid, up)


def _refused(problem):
    return jsonify({"error": problem}), 404 if problem == "no such analysis" else 400


@bp.get("/api/agents/terminal")
def terminal_state():
    place, problem = _place(request.args.to_dict())
    return _refused(problem) if problem else jsonify(INV.state(engine(), place))


@bp.post("/api/agents/terminal")
def terminal_ask():
    """body: {pid?, upload?, question, admin, page?: {path, address, title, heading, upload, finding, item}}."""
    body = request.get_json(force=True, silent=True) or {}
    if not isinstance(body, dict):
        return jsonify({"error": "the request must be a set of named fields"}), 400
    place, problem = _place(body)
    if problem:
        return _refused(problem)
    page = body.get("page")
    if page is not None and not isinstance(page, dict):
        return jsonify({"error": "page must be a set of named fields"}), 400
    try:
        out = INV.ask(engine(), place, as_text(body.get("question"), "question"), admin_of(body), page)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify(dict(INV.state(engine(), place), **out))


@bp.post("/api/agents/terminal/stop")
def terminal_stop():
    place, problem = _place(request.get_json(force=True, silent=True) or {})
    return _refused(problem) if problem else jsonify(INV.stop(engine(), place))


@bp.get("/api/agents/terminal/exports/<name>")
def terminal_export(name):
    place, problem = _place(request.args.to_dict())
    path = None if problem else INV.export_path(engine(), place["id"], name)
    if not path:
        return jsonify({"error": "no such exported file"}), 404
    return send_file(path, as_attachment=True, download_name=name)


@bp.post("/api/agents/terminal/exports/<name>/add")
def terminal_add(name):
    place, problem = _place(request.get_json(force=True, silent=True) or {})
    if problem:
        return _refused(problem)
    try:
        dst = INV.add_to_analysis(engine(), place, name)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"added": name, "to": dst, "next": "press Read the new files on the card after Family 1: only this file gets its three agents"})


# ---- which column holds this kind of data? (agentic/column_match.py)
@bp.post("/api/agents/projects/<int:pid>/substitute")
def substitute(pid):
    """body: {column?, file?, description?, values?: [text], admin}. A column a rule names is missing or empty: the
    columns of every file of the analysis that could hold the same kind of data, each with the evidence the program
    counted and one of three levels of support decided by code. Nothing is applied."""
    from agentic import column_match as CM
    p = _project(pid)
    if not p:
        return jsonify({"error": "no such analysis"}), 404
    body = request.get_json(force=True, silent=True) or {}
    if not isinstance(body, dict):
        return jsonify({"error": "the request must be a set of named fields"}), 400
    values = body.get("values")
    if values is not None and not (isinstance(values, list) and all(isinstance(v, (str, int, float)) and not isinstance(v, bool) for v in values)):
        return jsonify({"error": "values must be a list of values (text or numbers)"}), 400
    try:
        out = CM.for_analysis(engine(), p, as_text(body.get("column"), "column"), as_text(body.get("file"), "file"),
                              as_text(body.get("description"), "description"), [str(v) for v in values or []])
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify(out)
