#!/usr/bin/env python3
"""Start the Field-to-Test Loop application on this laptop.

    python3 run_app.py                 # http://127.0.0.1:8077
    python3 run_app.py --port 9000
    python3 run_app.py --config config/app_config.json --standin   # no LLM, deterministic (demo / tests)
"""
import argparse
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "app"))


def utf8_on_windows():
    """Windows reads and writes text files and pipes in the local code page (cp1252) unless Python runs in its UTF-8 mode, and that code page cannot
    hold the arrows and quotes the application's texts use. Start this program again in UTF-8 mode; every Python program it starts is in it too.
    Linux and macOS: nothing happens here."""
    if os.name != "nt" or sys.flags.utf8_mode:
        return
    import subprocess
    os.environ["PYTHONUTF8"] = "1"
    p = subprocess.Popen([sys.executable, "-X", "utf8", os.path.abspath(__file__)] + sys.argv[1:])
    while True:
        try:
            raise SystemExit(p.wait())
        except KeyboardInterrupt:        # Ctrl-C reaches both programs: wait for the application to end
            continue


def port_taken_on_windows(host, port):
    """Windows lets a second program listen on a port that is already in use, so a second copy of the application would start on the same
    database folder without any error. True when the port cannot be had exclusively. Linux and macOS refuse the second start by themselves."""
    if os.name != "nt":
        return False
    import socket
    try:
        s = socket.socket(socket.AF_INET6 if ":" in host else socket.AF_INET, socket.SOCK_STREAM)
    except OSError:
        return False
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        s.bind((host, port))
        return False
    except OSError:
        return True
    except AttributeError:
        return False
    finally:
        s.close()


def main():
    utf8_on_windows()
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=os.path.join(HERE, "config", "app_config.json"))
    ap.add_argument("--port", type=int, default=None)
    ap.add_argument("--standin", action="store_true", help="force the deterministic stand-in LLM (no model calls)")
    a = ap.parse_args()
    from server import create_app, load_config   # noqa: E402
    cfg = load_config(a.config)
    if a.standin:
        cfg["llm"]["backend"] = "standin"
    port = a.port or cfg["server"].get("port", 8077)
    import model_env   # noqa: E402   (the Settings page's URL, model and key decide for every part; owner, 2026-11-11)
    if (cfg.get("server") or {}).get("api_calls", True) is False:
        # (owner, 2026-11-13: "Api calls are strictly not allowed") the key file is not read and no key stays in this process
        for name in ("ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN", "ANTHROPIC_BASE_URL"):
            os.environ.pop(name, None)
        app = create_app(cfg, HERE)
        print("API calls are off (server.api_calls): every model call goes through opencode in a terminal, model %s  (choose it in Settings)" % (
            (cfg.get("agentic") or {}).get("opencode_model") or "not chosen yet"))
        return serve(app, cfg, port)
    key = model_env.load(cfg)
    app = create_app(cfg, HERE)
    print("Model connection: %s, model %s, key %s%s  (change them in Settings -> Model connection)" % (
        (cfg.get("llm") or {}).get("base_url") or "Anthropic (https://api.anthropic.com)", (cfg.get("llm") or {}).get("model") or "-",
        key["source"], (" ending ..." + key["end"]) if key.get("end") else ""))
    serve(app, cfg, port)


def serve(app, cfg, port):
    print("Field-to-Test Loop  ->  http://%s:%d   (local only; Ctrl-C to stop)" % (cfg["server"].get("host", "127.0.0.1"), port))
    if port_taken_on_windows(cfg["server"].get("host", "127.0.0.1"), port):
        raise SystemExit("Port %d is already in use: the application is probably running already (one copy only; a second one would work on the same files). "
                         "Stop the other one, or start this one with --port <another number>." % port)
    app.run(host=cfg["server"].get("host", "127.0.0.1"), port=port, threaded=True, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
