"""The procedural graph as the owner defined it (2026-11-11):

    defect  (its standard name, confirmed by the admin; keyed without the device)
      └ cause  (a one-line header and its side: the host, the driver, the device, the interrupt path, the link, PCIe)
          └ solution  (versions of: the error sequence, which recreates the error and becomes the test case, and the
                       optimized sequence, which solves the problem; the first one given or edited by the admin)

"First the error is found (the admin's pattern), then the defect is isolated (the model, from the window of 15 commands above and
15 below), then the graph is checked: is this defect, this cause already present? If not, store it at the right place; else
present what is stored to the admin." The admin's four signals (correct, correct with edits, wrong, wrong with edits) only change
the ranking of what is retrieved and shown next time ("the reinforcement should be applied for the retrieval").

The weights are the judgements themselves, read from the verdict log (rows are only ever added):
  - a cause:    "chosen as the cause in n of N occurrences of this defect" (one count per occurrence, only from the admin);
  - a solution: "judged correct s of n times" (Beta(1, 1), the standard neutral start; ranked by the lower bound of the share
                judged correct, so one lucky judgement does not outrank a long good record).
Device and firmware are stored with each occurrence and each verdict: a solution is shared among devices, and the page says on
which devices it was judged. Research: reports/Procedural graph causes and solutions.md, reports/Defect isolation and solution memory.md.

Everything here is plain SQLite in db/hier_knowledge.sqlite (tables dg_*), next to the older signature store.
"""
import json
import math
import re
import sqlite3
import time

SIDES = {"host": "the host (the computer: its timers, its settings)",
         "driver": "the driver or the admin software",
         "device": "the device (its controller or firmware)",
         "interrupt": "the interrupt path (MSI-X, coalescing)",
         "link": "the link (replays, retraining, power states)",
         "pcie": "PCIe transactions (completions, credits, errors)",
         "other": "outside this list"}
SIGNALS = ("correct", "correct_with_edits", "wrong", "wrong_with_edits")
SIGNAL_SAID = {"correct": "Correct", "correct_with_edits": "Correct with edits", "wrong": "Wrong", "wrong_with_edits": "Wrong, with edits"}
Z = 1.645          # one-sided 95 %: the lower bound used for the ranking

SCHEMA = """
CREATE TABLE IF NOT EXISTS dg_defect (id INTEGER PRIMARY KEY, key TEXT UNIQUE, name TEXT, rule TEXT, level TEXT, what TEXT, created REAL, created_by TEXT);
CREATE TABLE IF NOT EXISTS dg_cause (id INTEGER PRIMARY KEY, defect_id INTEGER, key TEXT, side TEXT, header TEXT, created REAL, created_by TEXT,
  UNIQUE (defect_id, key));
CREATE TABLE IF NOT EXISTS dg_solution (id INTEGER PRIMARY KEY, cause_id INTEGER, status TEXT DEFAULT 'active', created REAL, created_by TEXT,
  producer TEXT, origin_upload TEXT, origin_finding INTEGER, parent INTEGER);
CREATE TABLE IF NOT EXISTS dg_revision (id INTEGER PRIMARY KEY, solution_id INTEGER, version INTEGER, error_seq TEXT, optimized TEXT, note TEXT,
  created REAL, created_by TEXT, test_path TEXT);
CREATE TABLE IF NOT EXISTS dg_occurrence (id INTEGER PRIMARY KEY, defect_id INTEGER, cause_id INTEGER, upload_id TEXT, finding_id INTEGER,
  device TEXT, firmware TEXT, isolation TEXT, admin TEXT, at REAL, UNIQUE (upload_id, finding_id));
CREATE TABLE IF NOT EXISTS dg_verdict (id INTEGER PRIMARY KEY, solution_id INTEGER, revision_id INTEGER, signal TEXT, admin TEXT, at REAL,
  occurrence_id INTEGER, device TEXT, firmware TEXT, edits TEXT, new_solution_id INTEGER, new_revision_id INTEGER);
CREATE TABLE IF NOT EXISTS dg_isolation (upload_id TEXT, finding_id INTEGER, card_hash TEXT, version TEXT, data TEXT, at REAL,
  PRIMARY KEY (upload_id, finding_id, card_hash, version));
CREATE TABLE IF NOT EXISTS dg_occurrence_log (id INTEGER PRIMARY KEY, occurrence_id INTEGER, defect_id INTEGER, cause_id INTEGER, admin TEXT, at REAL);
CREATE INDEX IF NOT EXISTS ix_dg_cause ON dg_cause (defect_id);
CREATE INDEX IF NOT EXISTS ix_dg_solution ON dg_solution (cause_id);
CREATE INDEX IF NOT EXISTS ix_dg_revision ON dg_revision (solution_id);
CREATE INDEX IF NOT EXISTS ix_dg_verdict ON dg_verdict (solution_id);
"""


def _id(x):
    """A stored row's id or an error's number, refused in words when it is not a whole number SQLite can hold (found by the parameter
    fuzz on 2026-11-11: a 22-digit id gave a server error instead of a refusal)."""
    try:
        v = int(x)
    except (TypeError, ValueError):
        raise ValueError("not a valid number: %r" % (x,))
    if not -(1 << 63) <= v < (1 << 63):
        raise ValueError("not a valid number: %s" % x)
    return v


def norm_key(text):
    """The lookup key of a name: lower case, words only. "Read  timeout: host gave up" and "read timeout host gave up" are the same."""
    return " ".join(re.sub(r"[^0-9a-z]+", " ", str(text or "").lower()).split())


def lower_bound(s, n, z=Z):
    """Wilson lower bound of the share judged correct (0 when nothing is judged)."""
    if n <= 0:
        return 0.0
    p = s / n
    den = 1 + z * z / n
    return max(0.0, (p + z * z / (2 * n) - z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))) / den)


def judged_words(s, n, edits=0):
    if n <= 0:
        return "not yet judged"
    return "judged correct %d of %d time%s%s" % (s, n, "" if n == 1 else "s", (" (%d with edits)" % edits) if edits else "")


def _when(t):
    return time.strftime("%Y-%m-%d %H:%M", time.localtime(t or 0))


def clean_steps(steps):
    """An error sequence as stored: a list of steps, each a dict with at least a command, renumbered from 1."""
    out = []
    for s in steps or []:
        if not isinstance(s, dict) or not str(s.get("command") or "").strip():
            raise ValueError("every step of an error sequence needs its command")
        x = {k: v for k, v in s.items() if k in ("command", "position", "gap_us", "parameters", "source_row", "why", "opc", "qid", "expected", "admin")}
        out.append(x)
    for i, x in enumerate(out):
        x["step"] = i + 1
    return out


def clean_lines(lines):
    """An optimized sequence as stored: its lines (one action each), as the admin wrote or approved them."""
    if isinstance(lines, str):
        lines = lines.splitlines()
    out = [" ".join(str(x).split()) for x in lines or []]
    return [x for x in out if x]


class DefectGraph:
    def __init__(self, path):
        self.path = path
        con = self._con()
        con.close()

    def _con(self):
        con = sqlite3.connect(self.path, timeout=30)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA journal_mode=WAL")
        con.executescript(SCHEMA)
        if "test_path" not in [r[1] for r in con.execute("PRAGMA table_info(dg_occurrence)")]:
            con.execute("ALTER TABLE dg_occurrence ADD COLUMN test_path TEXT")     # each error's own approved test (2026-11-11)
            con.commit()
        return con

    def remap_findings(self, upload_id, mapping):
        """The error numbers of one recording moved (a rule was run again and the errors were numbered anew by time): the
        occurrences, the kept isolations and the origins of the solutions that name them follow, so nothing stored here points
        at another error. Two steps through negative numbers, so two errors that swap their numbers do not collide.
        -> how many stored rows were moved."""
        if not mapping:
            return 0
        con = self._con()
        n = 0
        try:
            for table, up, col in (("dg_occurrence", "upload_id", "finding_id"), ("dg_isolation", "upload_id", "finding_id"),
                                   ("dg_solution", "origin_upload", "origin_finding")):
                for old, new in mapping.items():
                    n += con.execute("UPDATE %s SET %s = ? WHERE %s = ? AND %s = ?" % (table, col, up, col), (-_id(new), upload_id, _id(old))).rowcount
                con.execute("UPDATE %s SET %s = -%s WHERE %s = ? AND %s < 0" % (table, col, col, up, col), (upload_id,))
            con.commit()
        finally:
            con.close()
        return n

    # ------------------------------------------------------------------ defects
    def defects(self, rule=None):
        """Every stored defect (those of this rule first), with how often it was seen and how many causes it has."""
        con = self._con()
        try:
            rows = [dict(r) for r in con.execute(
                "SELECT d.*, (SELECT COUNT(*) FROM dg_occurrence o WHERE o.defect_id=d.id) AS seen, "
                "(SELECT COUNT(*) FROM dg_cause c WHERE c.defect_id=d.id) AS causes FROM dg_defect d")]
        finally:
            con.close()
        rows.sort(key=lambda r: (r["rule"] != rule, -r["seen"], r["name"].lower()))
        return rows

    def find_defect(self, name=None, term_key=None):
        con = self._con()
        try:
            r = con.execute("SELECT * FROM dg_defect WHERE key=?", (("term:" + term_key) if term_key else norm_key(name),)).fetchone()
            return dict(r) if r else None
        finally:
            con.close()

    def defect(self, defect_id):
        con = self._con()
        try:
            r = con.execute("SELECT * FROM dg_defect WHERE id=?", (_id(defect_id),)).fetchone()
            return dict(r) if r else None
        finally:
            con.close()

    def add_defect(self, name, rule, level, what, by, term_key=None):
        """The defect under its term (the dictionary's fixed key, made by code; nvme_hier/terms.py) or, for defects named before 2026-11-11,
        its standard name; an existing one with the same key is returned, never a copy. (id, created?)"""
        key = ("term:" + term_key) if term_key else norm_key(name)
        if not key:
            raise ValueError("the defect needs a standard name")
        con = self._con()
        try:
            r = con.execute("SELECT id FROM dg_defect WHERE key=?", (key,)).fetchone()
            if r:
                return r["id"], False
            cur = con.execute("INSERT INTO dg_defect (key, name, rule, level, what, created, created_by) VALUES (?,?,?,?,?,?,?)",
                              (key, " ".join(str(name).split()), rule, level, what, time.time(), by))
            con.commit()
            return cur.lastrowid, True
        finally:
            con.close()

    # ------------------------------------------------------------------ causes
    def add_cause(self, defect_id, side, header, by, keyword=None):
        """A cause under a defect: one fixed keyword of the dictionary (nvme_hier/terms.py) or, before 2026-11-11, a written line."""
        if side not in SIDES:
            raise ValueError("the side of a cause is one of: %s" % ", ".join(SIDES))
        key = ("kw:" + keyword) if keyword else norm_key(header)
        if not key:
            raise ValueError("the cause needs its one-line header")
        con = self._con()
        try:
            r = con.execute("SELECT id FROM dg_cause WHERE defect_id=? AND key=?", (_id(defect_id), key)).fetchone()
            if r:
                return r["id"], False
            cur = con.execute("INSERT INTO dg_cause (defect_id, key, side, header, created, created_by) VALUES (?,?,?,?,?,?)",
                              (_id(defect_id), key, side, " ".join(str(header).split()), time.time(), by))
            con.commit()
            return cur.lastrowid, True
        finally:
            con.close()

    def cause(self, cause_id):
        con = self._con()
        try:
            r = con.execute("SELECT * FROM dg_cause WHERE id=?", (_id(cause_id),)).fetchone()
            return dict(r) if r else None
        finally:
            con.close()

    # ------------------------------------------------------------------ occurrences
    def record_occurrence(self, defect_id, cause_id, upload_id, finding_id, device, firmware, isolation, admin):
        """One occurrence of the defect, with the cause the admin named for it: one count for that cause. The same error of the same
        recording judged again replaces its own occurrence (it is still one occurrence)."""
        con = self._con()
        try:
            r = con.execute("SELECT id, defect_id, cause_id FROM dg_occurrence WHERE upload_id=? AND finding_id=?", (upload_id, finding_id)).fetchone()
            cid = _id(cause_id) if cause_id else None
            if r and cid is None and r["cause_id"] and r["defect_id"] == _id(defect_id):
                cid = r["cause_id"]          # naming the defect again keeps the cause already chosen (audit 2026-11-11: it was set back to none)
            vals = (_id(defect_id), cid, device, firmware, json.dumps(isolation or {}), admin, time.time())
            if r:
                con.execute("UPDATE dg_occurrence SET defect_id=?, cause_id=?, device=?, firmware=?, isolation=?, admin=?, at=? WHERE id=?", vals + (r["id"],))
                oid = r["id"]
            else:
                oid = con.execute("INSERT INTO dg_occurrence (defect_id, cause_id, device, firmware, isolation, admin, at, upload_id, finding_id) "
                                  "VALUES (?,?,?,?,?,?,?,?,?)", vals + (upload_id, finding_id)).lastrowid
            if not r or r["defect_id"] != _id(defect_id) or r["cause_id"] != cid:       # every change of its defect or cause is kept
                con.execute("INSERT INTO dg_occurrence_log (occurrence_id, defect_id, cause_id, admin, at) VALUES (?,?,?,?,?)", (oid, _id(defect_id), cid, admin, time.time()))
            con.commit()
            return oid
        finally:
            con.close()

    def occurrence(self, oid):
        con = self._con()
        try:
            r = con.execute("SELECT * FROM dg_occurrence WHERE id=?", (_id(oid),)).fetchone()
            return dict(r) if r else None
        finally:
            con.close()

    # ------------------------------------------------------------------ solutions
    def add_solution(self, cause_id, error_seq, optimized, note, producer, by, origin_upload=None, origin_finding=None, parent=None):
        steps, lines = clean_steps(error_seq), clean_lines(optimized)
        if not steps:
            raise ValueError("a solution needs its error sequence (the steps that recreate the error)")
        con = self._con()
        try:
            sid = con.execute("INSERT INTO dg_solution (cause_id, status, created, created_by, producer, origin_upload, origin_finding, parent) VALUES (?,?,?,?,?,?,?,?)",
                              (_id(cause_id), "active", time.time(), by, producer, origin_upload, origin_finding, parent)).lastrowid
            rid = con.execute("INSERT INTO dg_revision (solution_id, version, error_seq, optimized, note, created, created_by) VALUES (?,?,?,?,?,?,?)",
                              (sid, 1, json.dumps(steps), json.dumps(lines), note or "", time.time(), by)).lastrowid
            con.commit()
            return sid, rid
        finally:
            con.close()

    def _current(self, con, sid):
        return con.execute("SELECT * FROM dg_revision WHERE solution_id=? ORDER BY version DESC LIMIT 1", (sid,)).fetchone()

    def revise(self, con, sid, error_seq, optimized, note, by):
        cur = self._current(con, sid)
        steps = clean_steps(error_seq if error_seq is not None else json.loads(cur["error_seq"]))
        lines = clean_lines(optimized if optimized is not None else json.loads(cur["optimized"]))
        return con.execute("INSERT INTO dg_revision (solution_id, version, error_seq, optimized, note, created, created_by) VALUES (?,?,?,?,?,?,?)",
                           (sid, cur["version"] + 1, json.dumps(steps), json.dumps(lines), note if note is not None else cur["note"], time.time(), by)).lastrowid

    def set_test_path(self, revision_id, path, upload_id=None, finding_id=None):
        """The approved test of a version of a solution, and of the error (occurrence) it was written for."""
        con = self._con()
        try:
            if revision_id:
                con.execute("UPDATE dg_revision SET test_path=? WHERE id=?", (path, _id(revision_id)))
            if upload_id is not None and finding_id is not None:
                con.execute("UPDATE dg_occurrence SET test_path=? WHERE upload_id=? AND finding_id=?", (path, upload_id, _id(finding_id)))
            con.commit()
        finally:
            con.close()

    def solution(self, sid):
        con = self._con()
        try:
            return self._solution_view(con, con.execute("SELECT * FROM dg_solution WHERE id=?", (_id(sid),)).fetchone())
        finally:
            con.close()

    def _solution_view(self, con, r):
        if r is None:
            return None
        sid = r["id"]
        revs = [dict(x) for x in con.execute("SELECT * FROM dg_revision WHERE solution_id=? ORDER BY version", (sid,))]
        every = [dict(x) for x in con.execute("SELECT * FROM dg_verdict WHERE solution_id=? ORDER BY id", (sid,))]
        # one judgement per error and admin counts (the latest): pressing Correct three times on the same error is one judgement
        # (audit 2026-11-11); every row is kept and shown; judgements given without an error each count
        last = {}
        for v in every:
            last[(v["occurrence_id"], v["admin"]) if v["occurrence_id"] is not None else ("row", v["id"])] = v["id"]
        keep = set(last.values())
        vs = [v for v in every if v["id"] in keep]
        good = sum(1 for v in vs if v["signal"] in ("correct", "correct_with_edits"))
        n = len(vs)
        edits = sum(1 for v in vs if v["signal"].endswith("_with_edits"))
        cur = revs[-1] if revs else {}
        devices = {}
        for v in vs:
            d = devices.setdefault(v["device"] or "a device not named", {"correct": 0, "n": 0})
            d["n"] += 1
            d["correct"] += 1 if v["signal"] in ("correct", "correct_with_edits") else 0
        return {"id": sid, "cause_id": r["cause_id"], "status": r["status"], "producer": r["producer"], "created_by": r["created_by"], "created": _when(r["created"]),
                "origin_upload": r["origin_upload"], "origin_finding": r["origin_finding"], "parent": r["parent"],
                "version": cur.get("version"), "revision_id": cur.get("id"), "error_seq": json.loads(cur.get("error_seq") or "[]"),
                "optimized": json.loads(cur.get("optimized") or "[]"), "note": cur.get("note") or "", "test_path": cur.get("test_path"),
                "correct": good, "judged": n, "edits": edits, "judged_words": judged_words(good, n, edits), "lower_bound": round(lower_bound(good, n), 4),
                "last_judged": _when(vs[-1]["at"]) if vs else None,
                "devices": [{"device": k, "words": "judged correct %d of %d" % (x["correct"], x["n"])} for k, x in devices.items()],
                "versions": [{"version": x["version"], "by": x["created_by"], "at": _when(x["created"]), "test_path": x["test_path"]} for x in revs],
                "verdicts": [{"signal": SIGNAL_SAID.get(v["signal"], v["signal"]), "by": v["admin"], "at": _when(v["at"]), "device": v["device"],
                              "counted": v["id"] in keep} for v in every[-12:]]}

    def solutions(self, cause_id, con=None):
        """The active solutions of a cause, best first: by the lower bound of the share judged correct; on a tie (for example 0 for a solution
        never judged and 0 for one judged wrong), by the expected share from the neutral start, (correct + 1) / (judged + 2), so a solution judged
        wrong never outranks one not judged yet (fixed 2026-11-11: "judged more often first" had put 0 of 3 above 0 of 0); then by how often judged."""
        own = con is None
        con = con or self._con()
        try:
            out = [self._solution_view(con, r) for r in con.execute("SELECT * FROM dg_solution WHERE cause_id=? AND status='active'", (_id(cause_id),))]
        finally:
            if own:
                con.close()
        out.sort(key=lambda x: (-x["lower_bound"], -(x["correct"] + 1) / (x["judged"] + 2), -x["judged"], x["id"]))
        for i, x in enumerate(out):
            x["rank"] = i + 1
        return out

    # ------------------------------------------------------------------ the view
    def view(self, defect_id):
        """The defect with its causes (most often chosen first) and each cause's solutions (best judged first), for the page."""
        con = self._con()
        try:
            d = con.execute("SELECT * FROM dg_defect WHERE id=?", (_id(defect_id),)).fetchone()
            if d is None:
                return None
            occ = [dict(x) for x in con.execute("SELECT * FROM dg_occurrence WHERE defect_id=? ORDER BY at", (d["id"],))]
            causes = [dict(x) for x in con.execute("SELECT * FROM dg_cause WHERE defect_id=?", (d["id"],))]
            judged = [o for o in occ if o["cause_id"]]
            total = len(judged)
            for c in causes:
                c["chosen"] = sum(1 for o in judged if o["cause_id"] == c["id"])
                c["chosen_words"] = ("chosen as the cause in %d of %d occurrence%s" % (c["chosen"], total, "" if total == 1 else "s")) if total else "no occurrence judged yet"
                c["side_words"] = SIDES.get(c["side"], c["side"])
                c["solutions"] = self.solutions(c["id"], con)
                c["created"] = _when(c["created"])
                best = c["solutions"][0]["lower_bound"] if c["solutions"] else 0
                c["_key"] = (-c["chosen"], -best, c["id"])
            causes.sort(key=lambda c: c.pop("_key"))
            for i, c in enumerate(causes):
                c["rank"] = i + 1
            devices = sorted({o["device"] or "a device not named" for o in occ})
            return {"id": d["id"], "name": d["name"], "rule": d["rule"], "level": d["level"], "what": d["what"], "created": _when(d["created"]), "created_by": d["created_by"],
                    "seen": len(occ), "devices": devices, "first_seen": _when(occ[0]["at"]) if occ else None, "last_seen": _when(occ[-1]["at"]) if occ else None,
                    "causes": causes,
                    "order": "Causes are ordered by how often you chose them for this defect, then by their best solution; solutions by the share judged "
                             "correct (its lower bound, so one lucky judgement does not outrank a long good record); on a tie, a solution not judged yet "
                             "comes before one judged wrong."}
        finally:
            con.close()

    # ------------------------------------------------------------------ one isolation per error (the same evidence gives the same isolation)
    def kept_isolation(self, upload_id, finding_id, card_hash, version):
        con = self._con()
        try:
            r = con.execute("SELECT data, at FROM dg_isolation WHERE upload_id=? AND finding_id=? AND card_hash=? AND version=?",
                            (upload_id, _id(finding_id), card_hash, str(version))).fetchone()
            return (json.loads(r["data"]), r["at"]) if r else (None, None)
        finally:
            con.close()

    def keep_isolation(self, upload_id, finding_id, card_hash, version, data):
        con = self._con()
        try:
            con.execute("INSERT OR REPLACE INTO dg_isolation VALUES (?,?,?,?,?,?)", (upload_id, _id(finding_id), card_hash, str(version), json.dumps(data, default=str), time.time()))
            con.commit()
        finally:
            con.close()

    # ------------------------------------------------------------------ where each error of a recording stands
    def status(self, upload_id, finding_ids):
        """{finding: {"words", "state", "defect", "cause", "solution_id", "test_path"}} for the errors of one recording, for the errors page:
        not opened; isolated (the defect named); its cause named; its solution stored or judged; its test approved."""
        con = self._con()
        try:
            out = {}
            for fid in finding_ids:
                o = con.execute("SELECT * FROM dg_occurrence WHERE upload_id=? AND finding_id=?", (upload_id, _id(fid))).fetchone()
                if o is None:
                    out[_id(fid)] = {"state": "new", "words": "not isolated yet"}
                    continue
                d = con.execute("SELECT name FROM dg_defect WHERE id=?", (o["defect_id"],)).fetchone()
                c = con.execute("SELECT header FROM dg_cause WHERE id=?", (o["cause_id"],)).fetchone() if o["cause_id"] else None
                v = con.execute("SELECT solution_id, COALESCE(new_solution_id, solution_id) AS used, COALESCE(new_revision_id, revision_id) AS rev, signal "
                                "FROM dg_verdict WHERE occurrence_id=? ORDER BY id DESC LIMIT 1", (o["id"],)).fetchone()
                sid = rev = None
                if v and v["signal"] != "wrong":
                    sid, rev = v["used"], v["rev"]
                if sid is None:
                    sol = con.execute("SELECT id FROM dg_solution WHERE origin_upload=? AND origin_finding=? ORDER BY id DESC LIMIT 1", (upload_id, _id(fid))).fetchone()
                    if sol:
                        sid = sol["id"]
                        rev = self._current(con, sid)["id"]
                test = o["test_path"] or (con.execute("SELECT test_path FROM dg_revision WHERE id=?", (rev,)).fetchone()["test_path"] if rev else None)
                state = "tested" if test else "solved" if sid else "cause" if c else "isolated"
                words = {"isolated": "isolated: the defect \u201c%s\u201d; its cause not named yet",
                         "cause": "the defect \u201c%s\u201d; cause: %s; no solution chosen yet",
                         "solved": "the defect \u201c%s\u201d; cause: %s; solution chosen; no test approved yet",
                         "tested": "done: the defect \u201c%s\u201d; cause: %s; its test approved"}[state]
                out[_id(fid)] = {"state": state, "words": words % ((d["name"],) if state == "isolated" else (d["name"], c["header"] if c else "not named")),
                                 "defect": d["name"], "cause": c["header"] if c else None, "solution_id": sid, "test_path": test}
            return out
        finally:
            con.close()

    # ------------------------------------------------------------------ the admin's verdicts
    def verdict(self, solution_id, signal, admin, occurrence_id=None, device=None, firmware=None, error_seq=None, optimized=None, note=None):
        """One of the four signals on a stored solution. Correct and Correct with edits count for it; Wrong and Wrong with edits against it.
        With edits: Correct keeps the solution and stores your edits as its next version; Wrong stores your edits as a new solution under the
        same cause, not yet judged. Returns {"did": [what changed, in words], "new_solution_id", "new_revision_id"}."""
        if signal not in SIGNALS:
            raise ValueError("the signal is one of: %s" % ", ".join(SIGNALS))
        con = self._con()
        try:
            r = con.execute("SELECT * FROM dg_solution WHERE id=?", (_id(solution_id),)).fetchone()
            if r is None or r["status"] != "active":
                raise ValueError("no such stored solution")
            occ = None
            if occurrence_id is not None:
                occ = con.execute("SELECT * FROM dg_occurrence WHERE id=?", (_id(occurrence_id),)).fetchone()
                dz = con.execute("SELECT defect_id FROM dg_cause WHERE id=?", (r["cause_id"],)).fetchone()
                if occ is None:
                    raise ValueError("no such error in the procedural graph (occurrence %s)" % occurrence_id)
                if dz is None or occ["defect_id"] != dz["defect_id"]:
                    raise ValueError("that error is not an occurrence of this solution's defect")
            before = self._solution_view(con, r)
            rank_before = next((x["rank"] for x in self.solutions(r["cause_id"], con) if x["id"] == r["id"]), None)
            cur = self._current(con, r["id"])
            new_sid = new_rid = None
            if signal == "correct_with_edits":
                new_rid = self.revise(con, r["id"], error_seq, optimized, note, admin)
            elif signal == "wrong_with_edits":
                steps = clean_steps(error_seq if error_seq is not None else json.loads(cur["error_seq"]))
                lines = clean_lines(optimized if optimized is not None else json.loads(cur["optimized"]))
                new_sid = con.execute("INSERT INTO dg_solution (cause_id, status, created, created_by, producer, origin_upload, origin_finding, parent) VALUES (?,?,?,?,?,?,?,?)",
                                      (r["cause_id"], "active", time.time(), admin, "admin:%s" % admin,
                                       occ["upload_id"] if occ else r["origin_upload"], occ["finding_id"] if occ else r["origin_finding"], r["id"])).lastrowid
                new_rid = con.execute("INSERT INTO dg_revision (solution_id, version, error_seq, optimized, note, created, created_by) VALUES (?,?,?,?,?,?,?)",
                                      (new_sid, 1, json.dumps(steps), json.dumps(lines), note or "", time.time(), admin)).lastrowid
            con.execute("INSERT INTO dg_verdict (solution_id, revision_id, signal, admin, at, occurrence_id, device, firmware, edits, new_solution_id, new_revision_id) "
                        "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                        (r["id"], cur["id"], signal, admin, time.time(), occurrence_id, device, firmware,
                         json.dumps({"error_seq": error_seq, "optimized": optimized}) if signal.endswith("_with_edits") else None, new_sid, new_rid))
            con.commit()
            after = self._solution_view(con, r)
            ranked = self.solutions(r["cause_id"], con)
            rank_after = next((x["rank"] for x in ranked if x["id"] == r["id"]), None)
            did = ["this solution under this cause: %s → %s" % (before["judged_words"], after["judged_words"])]
            if rank_before and rank_after:
                did.append("its place among the %d solution%s of this cause: %s" % (len(ranked), "" if len(ranked) == 1 else "s",
                                                                                  "unchanged (%d)" % rank_after if rank_before == rank_after else "%d → %d" % (rank_before, rank_after)))
            if signal == "correct_with_edits":
                did.append("your edits are its version %d; earlier versions are kept" % after["version"])
            if new_sid:
                did.append("your edited steps are stored as a new solution under the same cause, not yet judged")
            did.append("nothing else changed")
            return {"did": did, "new_solution_id": new_sid, "new_revision_id": new_rid, "solution": after}
        finally:
            con.close()
