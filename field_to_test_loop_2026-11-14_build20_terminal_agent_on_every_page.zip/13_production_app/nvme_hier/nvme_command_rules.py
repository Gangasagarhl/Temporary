"""The rules that find an error at the NVMe command level, as one list for one page (owner, 2026-11-12).

The owner's request: "another page, containing only the rules for nvme commands, so the error at nvme command level ...
building the rules based on the nvme specification and the columns names are present already check for nvme commands. You
need to check the errors at the nvme level and need to isolate the defect, so that procedural graphs should be used to
carry the reinforcement signals."

What this module is, and is not:
  - The rules themselves are the detector's (nvme_hier/rules.py, the ids that start with "cmd."): one code decides what an
    error is, here and on every other page. This module adds what the page must say of each rule and the detector does
    not hold: the columns of the NVMe command export it reads, whether a recording carries them, and where the NVMe
    specification states what the rule rests on.
  - Every place named in a specification was read in the specification text itself on 12 November 2026 (the two public
    documents from https://nvmexpress.org/specifications/). "phrase" is a few words of that place: the test
    tests/test_nvme_command_rules.py looks each one up when the text is on the computer (F2T_NVME_SPEC_TEXT; the text is
    not shipped: it is copyrighted). A statement that could not be read in the text says so ("verified": False) instead
    of naming a section.
  - A rule whose columns are not in the recording is never skipped silently: status() says "cannot be checked on this
    recording" and names the column.
  - Each error found is a row of the recording's finding table, so it opens on the one-error page (/isolate), where the
    procedural graph (defect, cause, solution) takes the admin's four signals. graph_memory() reads how much the graph
    already holds for the defects of each rule.

Nothing is joined by time stamp here; a row is named by its row in the NVMe command file (line = row + 1: line 1 is the
header).
"""
import csv
import json
import os
import sqlite3
import time

from . import columns as C
from . import loader as L
from . import names as N
from . import nvme_command_errors as NE
from . import osfile as OSF
from . import parse as P
from . import rules as RL

BASE, NVM = NE.BASE, NE.NVM
LINUX = {"document": "Linux kernel, NVMe host driver (drivers/nvme/host/core.c and pci.c)", "revision": "the defaults io_timeout = 30 seconds and admin_timeout = 60 seconds",
         "address": "https://git.kernel.org/pub/scm/linux/kernel/git/torvalds/linux.git/tree/drivers/nvme/host"}
ANALYZER = {"document": "Teledyne LeCroy PCIe protocol analyzer, the export of the NVMe commands", "revision": "the analyzer's own error and warning cells", "address": ""}
CMD_FILE, NTX_FILE = "nvme_command", "nvme_transaction"
FILE_WORDS = {"nvme_command": "the NVMe command file", "nvme_transaction": "the NVMe transactions file", "split": "the split transactions file",
              "link": "the link transactions file", "packets": "the packets file"}
GROUPS = [
    ("specification", "Rules that rest on the NVMe specification",
     "What makes each of these an error is stated in the NVMe specification. The place is named with every rule."),
    ("owner", "The rule the owner set: a command timed out",
     "The NVMe specification names the statuses of an aborted command, but it sets no time by which a command must complete. The limits are the host's."),
    ("analyzer", "What the analyzer itself flagged on a command",
     "These read the analyzer's own error and warning cells of the command row. The analyzer decides them; the specification is not quoted here."),
    ("suspect", "Suspects: something to look at, not a proven error",
     "Each of these has an innocent explanation that the recording cannot rule out. They are shown as suspects, never as errors of the drive."),
]
SEVERITY_WORDS = {"error": "error", "warning": "warning (context, not an error by itself)", "check": "to check with evidence the recording does not hold"}
SHOWN_AT_ONCE = 200          # errors of one rule sent to the page in one answer (the page asks for the next ones)
FOLLOWED_AT_MOST = 200000    # errors of these rules whose numbers are followed one by one through a new check


def _b(doc, place, says, phrase=None, verified=True):
    """One place a rule rests on: the document, the place in it, what it says in plain words, and a few words of the place
    (for the test that reads the text). verified False = this statement could not be read in the specification text."""
    return {"document": doc["document"], "revision": doc["revision"], "address": doc.get("address", ""), "place": place, "says": says,
            "phrase": phrase, "verified": bool(verified)}


def _c(column, use, needed=True, file=CMD_FILE):
    return {"file": file, "column": column, "use": use, "needed": bool(needed)}


STATUS_COLUMNS = [_c("ST.SCT", "the status code type the drive wrote for the command: which family of result"),
                  _c("ST.SC", "the status code the drive wrote for the command: which result inside that family")]
NAME_COLUMNS = [_c("OPC", "the command code: which command it is (Read, Write, Abort and so on)", needed=False),
                _c("SQID", "the submission queue the command was sent on: queue 0 carries the admin commands, every other queue the I/O commands", needed=False)]

RULES = [
    {"id": "cmd.status_error", "group": "specification", "name": "A command ended with an error status",
     "checks": "The drive answers every command with a status: a status code type and a status code. Both are 0 for Successful Completion. "
               "This rule finds every command whose status is anything else, and names the status as the specification names it.",
     "how": "Row by row: an error when ST.SCT or ST.SC holds a value other than 0. A row whose two cells are empty has no status and is not "
            "an error of this rule (see the timeout rule).",
     "basis": [_b(BASE, "section 4.2.3, Status Field Definition", "A status value of 0h means the command completed successfully; any other value names what went wrong.",
                  "A value of 0h for the Status field indicates a successful command completion"),
               _b(BASE, "Figure 101 to Figure 107 (the status tables)", "The name of every status code type and status code. The page Every NVMe command error that is possible lists them all.",
                  "Status Code – Generic Command Status Values"),
               _b(NVM, "Figure 17 to Figure 19", "The statuses the base specification leaves to the NVM Command Set (for example Unrecovered Read Error).", "Unrecovered Read Error")],
     "columns": STATUS_COLUMNS + NAME_COLUMNS, "levels": [CMD_FILE], "found_as": "error"},
    {"id": "cmd.read_failure", "group": "specification", "name": "A Read did not return its data", "kept": True,
     "checks": "A Read command on an I/O queue that ended with an error status: the host did not get the data it asked for. Statuses that mean "
               "the host itself gave the command up (Command Abort Requested, Command Aborted due to SQ Deletion, Command Aborted By Host) "
               "belong to the timeout rule and are not counted here.",
     "how": "Row by row: OPC is 02h (Read), SQID is not 0, and ST.SCT or ST.SC is not 0, the three host-abort statuses aside.",
     "basis": [_b(NVM, "section 3.3.4, Read command, and 3.3.4.1, Command Completion", "A Read returns the data of the blocks it names; when it completes, with success or failure, the drive posts a completion entry with the status.",
                  "When the command is completed with success or failure, the controller shall post a completion queue entry to the associated I/O Completion Queue"),
               _b(BASE, "Figure 106, Media and Data Integrity Error Values", "Status code type 2h, status code 81h is Unrecovered Read Error: the drive could not correct the data it read.",
                  "Status Code – Media and Data Integrity Error Values")],
     "columns": [_c("OPC", "the command code: 02h on an I/O queue is Read"), _c("SQID", "the submission queue: not 0 means an I/O command")] + STATUS_COLUMNS,
     "levels": [CMD_FILE], "found_as": "error"},
    {"id": "cmd.incomplete", "group": "specification", "name": "A command never got a completion entry",
     "checks": "A command is finished for the host only when the drive writes a completion entry for it. This rule finds every command that has "
               "NVMe transactions in the recording (its doorbell, its entry, its data) and no completion entry among them.",
     "how": "Read from the tree: the NVMe transactions joined to the command by identity (queue and command identifier), never by time. An "
            "error when none of them is a completion queue entry.",
     "basis": [_b(BASE, "section 3.4.5, Outstanding Commands", "A command stays outstanding as long as the host has not received a completion for it.",
                  "the host has not received a completion for that command"),
               _b(BASE, "section 3.3.1, Memory-based Transport Queue Model (PCIe)", "A completion entry is posted when the drive writes it into the next free slot of the completion queue.",
                  "A completion queue entry is posted to the Completion Queue when the controller write of that completion queue entry"),
               _b(BASE, "no place", "That a missing completion is an error after a given time: the specification sets no such time. A command still open when the recording ends is not judged by the timeout rule; this rule does not look at time at all.",
                  None, verified=False)],
     "columns": [_c("NVMe Cmd", "the command's number in the export, which the transactions are joined to", needed=False),
                 _c("Type", "what each NVMe transaction of the command is (doorbell, entry, data, completion entry, interrupt)", file=NTX_FILE)],
     "levels": [CMD_FILE, NTX_FILE], "found_as": "error"},
    {"id": "cmd.write_zeroes_readback", "group": "specification", "name": "Blocks cleared by Write Zeroes did not read back as zeros",
     "checks": "After a Write Zeroes command, a Read of the same blocks must return zeros. This rule finds every later Read that overlaps a range "
               "cleared by a successful Write Zeroes and looks at the bytes the drive returned.",
     "how": "Row by row: each successful Write Zeroes (OPC 08h on an I/O queue) with its namespace and block range, then every later Read of that "
            "namespace whose range overlaps it (ranges compared by block address). The returned bytes are read from the packets under the Read "
            "in the tree. When the export holds data sizes and not bytes, the Read is filed as to check, never as an error.",
     "basis": [_b(NVM, "section 3.3.8, Write Zeroes command", "The command clears a range of logical blocks to zero.", "The Write Zeroes command is used to clear a range of logical blocks"),
               _b(NVM, "section 3.3.8, cross-reference", "The section number of the Write Zeroes command.", "Write Zeroes command (refer to section 3.3.8)")],
     "columns": [_c("OPC", "the command code: 08h is Write Zeroes, 02h is Read"), _c("SQID", "the submission queue: not 0 means an I/O command"),
                 _c("NSID", "the namespace the blocks belong to"), _c("SLBA", "the first block of the command"), _c("NLB", "the number of blocks, counted from 0")] + STATUS_COLUMNS
                + [_c("DATA", "the bytes the drive returned for the Read, in the packets under it", needed=False, file="packets")],
     "levels": [CMD_FILE], "bytes_need": [NTX_FILE, "link", "packets"], "found_as": "error when the bytes are not zeros; to check when the bytes were not exported"},
    {"id": "cmd.timeout", "group": "owner", "name": "A command timed out", "kept": True,
     "checks": "Four cases, each named in the error it files. Never completed: the row has no status, and the recording went on for the host's limit "
               "or longer after the command was sent. Aborted by the host: the status is Command Abort Requested, Command Aborted due to SQ Deletion "
               "or Command Aborted By Host. Over the host's limit: it completed, but only after the host's limit. Slower than usual: it took far longer "
               "than the same command of the same size usually takes in this recording.",
     "how": "Row by row. The host's limit is 30 seconds for an I/O command and 60 seconds for an admin command unless the admin set another. The "
            "command's time is from its Time Stamp to its first completion entry, which is read from the tree. Format NVM, Sanitize, Device Self-test, "
            "Firmware Commit, Firmware Image Download and Asynchronous Event Request are never judged for time.",
     "basis": [_b(BASE, "Figure 102, status code 07h Command Abort Requested", "The command was given up because the host sent an Abort (or a Cancel) command that named it.",
                  "an Abort command being received that specified this command"),
               _b(BASE, "Figure 102, status code 08h", "Command Aborted due to SQ Deletion: the host deleted the queue the command was sent on.", "Command Aborted due to SQ Deletion"),
               _b(BASE, "Figure 107, status code type 3h, status code 71h", "Command Aborted By Host.", "Command Aborted By Host"),
               _b(BASE, "section 5.1.1, Abort command", "The host uses the Abort command to ask the drive to give up one command it sent before.",
                  "The Abort command is used to request an abort of a specific command previously submitted"),
               _b(LINUX, "the driver's default timeouts", "30 seconds for an I/O command and 60 seconds for an admin command: the host's limits, not the specification's.", None, verified=False),
               _b(BASE, "no place", "A time by which a command must complete: no such limit was found in the specification, so none is quoted. Slower than usual is the owner's rule of 2026-11-09.",
                  None, verified=False)],
     "columns": STATUS_COLUMNS + [_c("Time Stamp", "when the command was sent, from the start of the recording"),
                                  _c("OPC", "the command code: names the command and tells the long-by-nature commands apart"),
                                  _c("SQID", "the submission queue: queue 0 (admin commands) has the 60 second limit"),
                                  _c("NLB", "the number of blocks: usual time is measured per command and size", needed=False),
                                  _c("Type", "the completion entry of the command, whose time ends the command", needed=False, file=NTX_FILE)],
     "levels": [CMD_FILE],
     "partly": {"needs": [NTX_FILE], "words": "Over the host's limit and Slower than usual need the time of the command's completion entry, which is read from the "
                                               "NVMe transactions. Without that file only Never completed and Aborted by the host are judged."},
     "found_as": "error"},
    {"id": "cmd.analyzer_error", "group": "analyzer", "name": "The analyzer flagged an error on the command",
     "checks": "The analyzer writes its own error cell on a command row when its decoding found something wrong (for example a command without a completion). This rule files every command whose error cell holds something.",
     "how": "Row by row: an error when the Errors cell of the command row is not empty. The cell's text is kept with the error.",
     "basis": [_b(ANALYZER, "the Errors cell of the NVMe command row", "What the analyzer itself decided. Its meaning is the analyzer's, not the specification's.", None, verified=False)],
     "columns": [_c("Errors", "the analyzer's error cell of the command (a header cell without a label in the export: it holds the first row's text)")],
     "levels": [CMD_FILE], "found_as": "error"},
    {"id": "cmd.analyzer_warning", "group": "analyzer", "name": "The analyzer wrote a warning on the command",
     "checks": "The analyzer's warning cell of the command row holds something. A warning is context for the commands around it, not an error by itself.",
     "how": "Row by row: a warning when the Warnings cell of the command row is not empty.",
     "basis": [_b(ANALYZER, "the Warnings cell of the NVMe command row", "What the analyzer itself decided.", None, verified=False)],
     "columns": [_c("Warnings", "the analyzer's warning cell of the command (a header cell without a label in the export)")],
     "levels": [CMD_FILE], "found_as": "warning"},
    {"id": "cmd.latency_over_limit", "group": "suspect", "name": "The wait after a command was at or above the command limit",
     "checks": "The export's Time Delta of a command row (the analyzer's time from this command to the next one) is at or above the command limit: 30 seconds for an I/O command, 60 seconds for an admin command, unless the admin set another.",
     "how": "Row by row: Time Delta compared with the limit. Time Delta is the gap to the next command, not the command's own duration, so this is a suspect.",
     "basis": [_b(LINUX, "the driver's default timeouts", "The limits come from the host's driver. The specification sets no time for a command.", None, verified=False)],
     "columns": [_c("Time Delta", "the analyzer's time from this command to the next command"), _c("SQID", "the submission queue: queue 0 (admin commands) has the 60 second limit")] + NAME_COLUMNS[:1],
     "levels": [CMD_FILE], "found_as": "error (a suspect until the limit is confirmed for the host)"},
    {"id": "cmd.bytes_short", "group": "suspect", "name": "Fewer bytes moved than the command asked for",
     "checks": "A successful Read or Write moved fewer data bytes than its block count asks for, if a block is 512 bytes. The block size of the namespace is not read from the recording, so this is a suspect.",
     "how": "Row by row: for a Read or Write on an I/O queue with status Successful Completion, (NLB + 1) x 512 bytes compared with the Data cell.",
     "basis": [_b(NVM, "the Number of Logical Blocks field of the Read and Write commands", "The number of blocks is a 0's based value: 0 means one block.", "This is a 0's based value"),
               _b(NVM, "no place", "That a block is 512 bytes: the block size is set by the namespace's format and is not in the command row. 512 is this project's assumption.", None, verified=False)],
     "columns": [_c("OPC", "the command code: 01h is Write, 02h is Read"), _c("SQID", "the submission queue: not 0 means an I/O command"),
                 _c("NLB", "the number of blocks, counted from 0"), _c("Data", "the bytes that moved for the command")] + STATUS_COLUMNS,
     "levels": [CMD_FILE], "found_as": "error (a suspect until the block size is confirmed)"},
    {"id": "cmd.deallocate_readback", "group": "suspect", "name": "A Read of blocks that were deallocated before",
     "checks": "After a Dataset Management command that deallocates a range, a Read of those blocks returns what the drive declared for deallocated blocks (zeros or FFh), or anything when it declared nothing. This rule finds every later Read that overlaps a deallocated range.",
     "how": "Row by row: each Dataset Management command (OPC 09h on an I/O queue) with the deallocate attribute set, its ranges, then every later Read of that namespace that overlaps one. An error only when the drive declared a value and the bytes show another; otherwise to check.",
     "basis": [_b(NVM, "section 3.3.3.2.1, Deallocated or Unwritten Logical Blocks", "What a Read of a deallocated block returns: zeros when the drive declared 001b, FFh when it declared 010b.",
                  "all bytes cleared to 0h if the Deallocation Read Behavior (DRB) field in the DLFEAT field is set to 001b"),
               _b(NVM, "section 3.3.3, Dataset Management command", "The command that deallocates ranges of blocks.", "Dataset Management command (refer to section 3.3.3)")],
     "columns": [_c("OPC", "the command code: 09h is Dataset Management, 02h is Read"), _c("SQID", "the submission queue: not 0 means an I/O command"),
                 _c("AD", "the deallocate attribute of the Dataset Management command"), _c("NR", "the number of ranges of the Dataset Management command, counted from 0", needed=False),
                 _c("RNG 0.SLBA", "the first block of the first range (further ranges: RNG 1.SLBA and so on)"),
                 _c("RNG 0.Length LB", "the number of blocks of the first range"), _c("NSID", "the namespace the blocks belong to"),
                 _c("SLBA", "the first block of the Read"), _c("NLB", "the number of blocks of the Read, counted from 0"),
                 _c("DLFEAT.Bits 0-2", "what the drive declared a deallocated block reads as (from its Identify Namespace answer)", needed=False)],
     "levels": [CMD_FILE], "bytes_need": [NTX_FILE, "link", "packets"], "found_as": "error only when the drive declared a value and returned another; otherwise to check"},
    {"id": "cmd.not_fetched", "group": "suspect", "name": "No read of the command's entry by the drive was seen",
     "checks": "The command has NVMe transactions in the recording, and none of them is the drive's read of the submission queue entry. One read can fetch several entries at once, so a missing read of its own is a suspect.",
     "how": "Read from the tree: the NVMe transactions joined to the command by identity. Filed when none of them is the entry.",
     "basis": [_b(BASE, "no place", "The specification does not describe the drive's read of an entry as an event of its own. This is this project's reading of the recording.", None, verified=False)],
     "columns": [_c("Type", "what each NVMe transaction of the command is", file=NTX_FILE)], "levels": [CMD_FILE, NTX_FILE], "found_as": "error (a suspect)"},
    {"id": "cmd.doorbell_missing", "group": "suspect", "name": "The command has no doorbell write of its own",
     "checks": "The host announces new commands by writing the submission queue tail doorbell. The command has no doorbell transaction of its own. One doorbell write may announce several commands, so this is a suspect.",
     "how": "Read from the tree: filed as to check when none of the command's NVMe transactions is a submission queue tail doorbell.",
     "basis": [_b(BASE, "section 3.3.1, Memory-based Transport Queue Model (PCIe)", "One doorbell write may announce one or more commands.",
                  "A Submission Queue Tail Doorbell write may indicate that one or more submission queue entries have been submitted")],
     "columns": [_c("Type", "what each NVMe transaction of the command is", file=NTX_FILE)], "levels": [CMD_FILE, NTX_FILE], "found_as": "to check"},
    {"id": "cmd.no_interrupt", "group": "suspect", "name": "No interrupt followed the completion",
     "checks": "The command has a completion entry and no interrupt after it. The drive may raise an interrupt, and the host may read the queue without one, so this is a suspect.",
     "how": "Read from the tree: filed as to check when the command's NVMe transactions hold a completion entry and no interrupt.",
     "basis": [_b(BASE, "section 3.3.1, Memory-based Transport Queue Model (PCIe)", "The drive may generate an interrupt to say that completion entries were posted: it is allowed, not required.",
                  "The controller may generate an interrupt to the host to indicate that one or more completion queue entries have been posted")],
     "columns": [_c("Type", "what each NVMe transaction of the command is", file=NTX_FILE)], "levels": [CMD_FILE, NTX_FILE], "found_as": "to check"},
]
RULE_IDS = tuple(r["id"] for r in RULES)
BY_ID = {r["id"]: r for r in RULES}
FILED_WITH_THE_COMMANDS = ("ntx.interrupt_before_completion", "ntx.completion_unknown_command")   # the detector's command pass files these two as well


def documents():
    return [BASE, NVM]


def rules():
    """The list for the page: every rule with its group, its words, its places in the documents and its columns."""
    out = []
    for r in RULES:
        k = RL.basis(r["id"])
        out.append({"id": r["id"], "group": r["group"], "name": r["name"], "checks": r["checks"], "how": r["how"], "kept_by_the_owner": bool(r.get("kept")),
                    "basis": r["basis"], "columns": [dict(c, file_words=FILE_WORDS[c["file"]]) for c in r["columns"]],
                    "reads": [FILE_WORDS[lv] for lv in r["levels"]], "partly": (r.get("partly") or {}).get("words"),
                    "bytes_need": [FILE_WORDS[lv] for lv in r.get("bytes_need") or []], "found_as": r["found_as"], "firm": k["firm"]})
    return out


def groups():
    return [{"id": g, "name": n, "about": a} for g, n, a in GROUPS]


def line_of(row):
    """The line of the NVMe command file that holds a row (line 1 is the header; row 1 is line 2)."""
    return int(row) + 1 if row is not None else None


# ---------------------------------------------------------------------------------------------- one recording
def _ro(db):
    con = sqlite3.connect("file:%s?mode=ro" % db.replace("?", "%3f").replace("#", "%23"), uri=True)
    con.row_factory = sqlite3.Row
    return con


def _meta(con, key, default=None):
    try:
        r = con.execute("SELECT v FROM meta WHERE k=?", (key,)).fetchone()
        return json.loads(r[0]) if r and r[0] else default
    except (sqlite3.Error, ValueError, TypeError):
        return default


def _tables(con):
    return {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}


def columns_of(con):
    """Which columns the rules read, and whether this recording carries each one -> {(file, column): {...}}. Read from what
    the loader recorded of each file's header when the recording was loaded (the named columns it did not find)."""
    reports = _meta(con, "load_reports", {}) or {}
    levels = _meta(con, "levels_present", []) or []
    typed = {fk: {name: col for name, col, _fn in L.KEYS[fk]} for fk in (CMD_FILE, NTX_FILE, "packets")}
    out = {}
    for r in RULES:
        for c in r["columns"]:
            key = (c["file"], c["column"])
            if key in out:
                continue
            rep = reports.get(c["file"]) if isinstance(reports.get(c["file"]), dict) else None
            loaded = c["file"] in levels and rep is not None and not rep.get("error")
            e = {"file": c["file"], "file_words": FILE_WORDS[c["file"]], "column": c["column"], "use": c["use"], "file_loaded": loaded,
                 "path": (rep or {}).get("path"), "present": None, "rows": (rep or {}).get("rows") if loaded else None, "rows_with_a_value": None}
            if loaded:
                missing = set(rep.get("missing_columns") or [])
                known = set(C.canonical_names(c["file"])) | set(rep.get("extra_columns_kept") or [])
                e["present"] = c["column"] not in missing and (c["column"] in known or c["column"] in typed[c["file"]])
                blanks = rep.get("blank_key_cells") if isinstance(rep.get("blank_key_cells"), dict) else {}
                sql_col = typed[c["file"]].get(c["column"])
                if e["present"] and sql_col in blanks and isinstance(rep.get("rows"), int):
                    e["rows_with_a_value"] = max(0, rep["rows"] - int(blanks[sql_col] or 0))
            out[key] = e
    return out


def _cap(text):
    """The first letter as a capital, the rest as it is ("the NVMe transactions file" -> "The NVMe transactions file")."""
    return text[:1].upper() + text[1:]


def _cannot(r, cols, levels):
    """Why a rule cannot be checked on this recording, in words; "" when it can."""
    for lv in r["levels"]:
        if lv not in levels:
            return "cannot be checked on this recording: %s is not loaded%s" % (
                FILE_WORDS[lv], "" if lv == CMD_FILE else " (this rule reads the command's NVMe transactions, joined to it in the tree)")
    gone = [c for c in r["columns"] if c["needed"] and c["file"] in levels and cols[(c["file"], c["column"])]["present"] is False]
    if gone:
        return "cannot be checked on this recording: %s not in %s" % (
            ("column %s is" % gone[0]["column"]) if len(gone) == 1 else ("columns %s are" % ", ".join(c["column"] for c in gone)),
            FILE_WORDS[gone[0]["file"]] if len({c["file"] for c in gone}) == 1 else "the files")
    return ""


def status(db):
    """What the page shows of one loaded recording: the columns, and for every rule whether it can be checked and how many
    errors the last check filed. Every number is counted here, from the recording's own tables."""
    con = _ro(db)
    try:
        tables = _tables(con)
        levels = _meta(con, "levels_present", []) or []
        cols = columns_of(con)
        rules_meta = _meta(con, "rules", {}) or {}
        checked = "finding" in tables
        counts = {}
        if checked:
            marks = ",".join("?" * len(RULE_IDS))
            for rule, sev, k, first in con.execute("SELECT rule, severity, COUNT(*), MIN(rowid) FROM finding WHERE rule IN (%s) GROUP BY rule, severity" % marks, RULE_IDS):
                c = counts.setdefault(rule, {"found": 0, "by_kind": {}, "first_row": None})
                c["found"] += k
                c["by_kind"][sev] = k
                if first is not None and (c["first_row"] is None or first < c["first_row"]):
                    c["first_row"] = first
        commands = con.execute("SELECT COUNT(*) FROM cmd").fetchone()[0] if "cmd" in tables else None
        out_rules = []
        for r in RULES:
            why = _cannot(r, cols, levels)
            partly = ""
            if not why and r.get("partly") and any(lv not in levels for lv in r["partly"]["needs"]):
                partly = "%s %s is not loaded for this recording." % (r["partly"]["words"], _cap(" and ".join(FILE_WORDS[lv] for lv in r["partly"]["needs"] if lv not in levels)))
            if not why and r.get("bytes_need") and any(lv not in levels for lv in r["bytes_need"]):
                partly = "The bytes the drive returned are read from the packets under the Read in the tree. %s not loaded for this recording, so an overlap is filed as to check, never as an error." % (
                    _cap(", ".join(FILE_WORDS[lv] for lv in r["bytes_need"] if lv not in levels)) + (" is" if sum(lv not in levels for lv in r["bytes_need"]) == 1 else " are"))
            optional_gone = [c["column"] for c in r["columns"] if not c["needed"] and c["file"] in levels and cols[(c["file"], c["column"])]["present"] is False]
            c = counts.get(r["id"], {"found": 0, "by_kind": {}, "first_row": None})
            out_rules.append({"id": r["id"], "can_be_checked": not why, "why_not": why, "limited": partly,
                              "columns_not_in_the_file_but_not_needed": optional_gone,
                              "found": None if (why or not checked) else c["found"], "by_kind": {} if why else c["by_kind"],
                              "first_line": line_of(c["first_row"]) if not why and c["first_row"] is not None else None,
                              "columns": [{"file": x["file"], "column": x["column"], "needed": x["needed"],
                                           "present": cols[(x["file"], x["column"])]["present"], "file_loaded": cols[(x["file"], x["column"])]["file_loaded"]} for x in r["columns"]]})
        rerun = ((rules_meta.get("rule_rerun") or {}).get("all_command_rules") or {}).get("at")
        cmd_rep = (_meta(con, "load_reports", {}) or {}).get(CMD_FILE) or {}
        return {"command_file_loaded": CMD_FILE in levels, "command_file": cmd_rep.get("path"), "commands": commands,
                "files_loaded": [FILE_WORDS[lv] for lv in C.LEVEL_ORDER if lv in levels],
                "tree": NTX_FILE in levels,
                "checked": checked, "checked_again_at": rerun,
                "columns": sorted(cols.values(), key=lambda e: (C.LEVEL_ORDER.index(e["file"]), e["column"].lower())),
                "rules": out_rules,
                "errors_found": sum(x["found"] or 0 for x in out_rules),
                "rules_that_cannot_be_checked": sum(1 for x in out_rules if not x["can_be_checked"])}
    finally:
        con.close()


def errors(db, rule, offset=0, limit=SHOWN_AT_ONCE):
    """The errors one rule filed on this recording, in the order of the file, at most SHOWN_AT_ONCE at a time."""
    if rule not in BY_ID:
        raise ValueError("no such rule")
    limit = max(1, min(int(limit), SHOWN_AT_ONCE))
    offset = max(0, int(offset))
    con = _ro(db)
    try:
        if "finding" not in _tables(con):
            return {"errors": [], "total": 0, "offset": offset, "has_more": False}
        total = con.execute("SELECT COUNT(*) FROM finding WHERE rule=?", (rule,)).fetchone()[0]
        out = []
        for f in con.execute("SELECT f.id, f.name, f.severity, f.rowid, f.row_n, f.t_ps, c.opc, c.sqid, c.cid FROM finding f LEFT JOIN cmd c ON c.rowid_file = f.rowid "
                             "WHERE f.rule=? ORDER BY f.rowid, f.id LIMIT ? OFFSET ?", (rule, limit, offset)):
            out.append({"finding": f["id"], "what": f["name"], "kind": f["severity"], "kind_words": SEVERITY_WORDS.get(f["severity"], f["severity"]),
                        "command_number": f["row_n"], "line": line_of(f["rowid"]),
                        "command": N.opcode_name(f["opc"], f["sqid"]) if f["opc"] is not None else None,
                        "queue": f["sqid"], "command_identifier": f["cid"],
                        "time": P.fmt_ps(f["t_ps"]) if f["t_ps"] is not None else None})
        return {"errors": out, "total": total, "offset": offset, "has_more": offset + len(out) < total}
    finally:
        con.close()


EXPORT_COLUMNS = ["rule", "what was found", "how serious", "NVMe command number (column NVMe Cmd)", "line of the NVMe command file", "command",
                  "submission queue (SQID)", "command identifier (CID)", "time from the start of the recording (picoseconds)", "number of the error on the one-error page"]


def export_csv(db, out_path):
    """Every error the command rules filed on this recording, as a CSV file, written row by row (nothing is held in
    memory). -> the number of data rows written."""
    con = _ro(db)
    tmp = "%s.%d.part" % (out_path, os.getpid())
    n = 0
    try:
        with open(tmp, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(EXPORT_COLUMNS)
            if "finding" in _tables(con):
                marks = ",".join("?" * len(RULE_IDS))
                for f in con.execute("SELECT f.rule, f.name, f.severity, f.row_n, f.rowid, c.opc, c.sqid, c.cid, f.t_ps, f.id FROM finding f LEFT JOIN cmd c ON c.rowid_file = f.rowid "
                                     "WHERE f.rule IN (%s) ORDER BY f.rowid, f.id" % marks, RULE_IDS):
                    w.writerow([BY_ID[f[0]]["name"], f[1], SEVERITY_WORDS.get(f[2], f[2]), f[3], line_of(f[4]),
                                N.opcode_name(f[5], f[6]) if f[5] is not None else "", f[6], f[7], f[8], f[9]])
                    n += 1
        OSF.replace(tmp, out_path)
    finally:
        con.close()
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass
    return n


# ---------------------------------------------------------------------------------------------- check a recording again
def check(db_path, thresholds=None, progress=None, out=None):
    """Run every NVMe command rule again on a recording already loaded, without loading it again: the errors of these rules
    are taken out and filed anew by the detector's own command pass, then the roll-up (the cause of every command, the
    numbers of the errors by time of occurrence). The rules read the command table row by row; nothing is held in memory.
    out["renumbered"] gets {old number: new number} for the errors whose number moved (the caller follows them in the
    knowledge store). -> the counts before and after."""
    t0 = time.time()
    con = L.open_db(db_path)
    L.attach_work(con, db_path)
    R = None
    try:
        if "finding" not in {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}:
            raise RuntimeError("the rules have not run on this recording yet: load it first")
        R = RL.Rules(con, thresholds, progress, fresh=False)
        if CMD_FILE not in R.levels:
            raise RuntimeError("this recording was loaded without its NVMe command file: there is no command to check")
        gone = RULE_IDS + FILED_WITH_THE_COMMANDS + RL.RETIRED_RULES
        marks = ",".join("?" * len(gone))
        before = {r: k for r, k in con.execute("SELECT rule, COUNT(*) FROM finding WHERE rule IN (%s) GROUP BY rule" % marks, gone)}

        def numbers():
            """Each error of these rules by what it is (its rule, its row, and which one of several on that row) -> its number.
            None when there are too many to hold: then the moved numbers are only counted."""
            if sum(k for k, in con.execute("SELECT COUNT(*) FROM finding WHERE rule IN (%s)" % marks, gone)) > FOLLOWED_AT_MOST:
                return None
            got, nth = {}, {}
            for fid, rule, row in con.execute("SELECT id, rule, rowid FROM finding WHERE rule IN (%s) ORDER BY id" % marks, gone):
                k = nth.get((rule, row), 0)
                nth[(rule, row)] = k + 1
                got[(rule, row, k)] = fid
            return got
        old = numbers()
        old_top = con.execute("SELECT COALESCE(MAX(id), 0) FROM finding").fetchone()[0]
        con.execute("DELETE FROM finding WHERE rule IN (%s)" % marks, gone)
        con.commit()
        R.progress("NVMe command rules", "reading the commands")
        R.cmds()
        R.flush()
        filed = numbers()
        after = {r: R.counts.get(r, 0) for r in RULE_IDS}
        R.progress("NVMe command rules: roll-up", "")
        R.write()
        if out is not None:
            # R.renumber_map says where each row went when the errors were numbered anew by time. An error of these rules was
            # taken out and filed again, so its earlier number is found by what the error is, not by that map
            moved = R.renumber_map
            if "_count" in moved or old is None or filed is None:
                out["renumbered"] = moved if "_count" in moved else {"_count": len(moved)}
            else:
                mine = set(old.values())
                real = {k: v for k, v in moved.items() if k <= old_top and k not in mine}       # the errors of the other levels
                for what, was in old.items():
                    if what in filed:
                        now = moved.get(filed[what], filed[what])
                        if now != was:
                            real[was] = now
                out["renumbered"] = real
                out["no_longer_found"] = sorted(was for what, was in old.items() if what not in filed)
        report = json.loads((con.execute("SELECT v FROM meta WHERE k='rules'").fetchone() or ["{}"])[0] or "{}")
        by_sev = {s: 0 for s in ("error", "warning", "check")}
        for s, k in con.execute("SELECT severity, COUNT(*) FROM finding GROUP BY severity"):
            by_sev[s] = k
        report["findings"] = con.execute("SELECT COUNT(*) FROM finding").fetchone()[0]
        report["by_rule"] = {r: k for r, k in con.execute("SELECT rule, COUNT(*) FROM finding GROUP BY rule ORDER BY rule")}
        report["by_severity"] = by_sev
        report["commands_with_findings"] = con.execute("SELECT COUNT(DISTINCT cmd_rowid) FROM finding WHERE cmd_rowid IS NOT NULL").fetchone()[0]
        report["findings_outside_any_command"] = con.execute("SELECT COUNT(*) FROM finding WHERE cmd_rowid IS NULL").fetchone()[0]
        report["timing"] = R.timing
        report.setdefault("rule_rerun", {})["all_command_rules"] = {"at": time.time(), "seconds": round(time.time() - t0, 2),
                                                                    "before": {r: before.get(r, 0) for r in RULE_IDS}, "after": after}
        con.execute("INSERT OR REPLACE INTO meta (k, v) VALUES ('rules', ?)", (json.dumps(report),))
        con.commit()
        return {"before": {r: before.get(r, 0) for r in RULE_IDS}, "after": after, "seconds": round(time.time() - t0, 2), "errors": sum(after.values())}
    finally:
        if R is not None:
            R.progress.end()
        L.drop_work(con, db_path)
        L.checkpoint(con)
        con.close()


# ---------------------------------------------------------------------------------------------- the procedural graph
def graph_memory(graph_db):
    """How much the procedural graph already holds for the defects of each rule: the defects stored under their names, their
    causes, their solutions, how often they were seen, and the admin's judgements by signal. -> {rule id: {...}}.
    The graph is one store for every recording; a missing or unreadable store gives no numbers, never an error."""
    out = {r: {"defects": 0, "causes": 0, "solutions": 0, "seen": 0, "judgements": 0, "by_signal": {}} for r in RULE_IDS}
    if not graph_db or not os.path.exists(graph_db):
        return out
    try:
        con = _ro(graph_db)
    except sqlite3.Error:
        return out
    try:
        if "dg_defect" not in _tables(con):
            return out
        marks = ",".join("?" * len(RULE_IDS))
        for rule, k in con.execute("SELECT rule, COUNT(*) FROM dg_defect WHERE rule IN (%s) GROUP BY rule" % marks, RULE_IDS):
            out[rule]["defects"] = k
        for rule, k in con.execute("SELECT d.rule, COUNT(*) FROM dg_cause c JOIN dg_defect d ON d.id = c.defect_id WHERE d.rule IN (%s) GROUP BY d.rule" % marks, RULE_IDS):
            out[rule]["causes"] = k
        for rule, k in con.execute("SELECT d.rule, COUNT(*) FROM dg_solution s JOIN dg_cause c ON c.id = s.cause_id JOIN dg_defect d ON d.id = c.defect_id "
                                   "WHERE d.rule IN (%s) GROUP BY d.rule" % marks, RULE_IDS):
            out[rule]["solutions"] = k
        for rule, k in con.execute("SELECT d.rule, COUNT(*) FROM dg_occurrence o JOIN dg_defect d ON d.id = o.defect_id WHERE d.rule IN (%s) GROUP BY d.rule" % marks, RULE_IDS):
            out[rule]["seen"] = k
        for rule, sig, k in con.execute("SELECT d.rule, v.signal, COUNT(*) FROM dg_verdict v JOIN dg_solution s ON s.id = v.solution_id JOIN dg_cause c ON c.id = s.cause_id "
                                        "JOIN dg_defect d ON d.id = c.defect_id WHERE d.rule IN (%s) GROUP BY d.rule, v.signal" % marks, RULE_IDS):
            out[rule]["by_signal"][sig] = k
            out[rule]["judgements"] += k
    except sqlite3.Error:
        pass
    finally:
        con.close()
    return out
