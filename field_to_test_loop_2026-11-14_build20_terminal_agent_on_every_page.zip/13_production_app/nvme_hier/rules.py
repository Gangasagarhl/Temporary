"""Deterministic detection over the built tree. A defect is found by a rule and only by a rule.

Every rule names: its level, a stable id (lower-case 'level.name', the signature's `err` field), the catalogue
entry it corresponds to (data/catalogue/01..03 JSON from the research notes: meaning, defects per domain, spec
section), the source row, the measured value and the limit with its source when a limit is involved.

Findings roll up along the containment chain to the affected command; the lowest level with a finding inside a
command's window is that command's cause ("caused by the link level"), otherwise the command is its own root.
Severity: error (a rule fired) | warning (the analyzer's warning cell, or a link event that is context, not a
defect by itself) | check (something to verify with evidence the trace cannot hold, e.g. a read after a deallocate
when the data bytes were not exported).

Limits (picoseconds) come from the admin per level; when the admin left a level empty the default of research
note 07 applies and its source is shown: link 50 us from the TLP to its Ack or Nak (PCIe Base 3.6.2.1, the replay
timer of the slowest link configuration), NVMe transaction 50 ms from its first packet to its last (PCIe Base 2.8,
the completion timeout), split 50 ms (PCIe Base 2.8 completion timeout default), command 30 s I/O / 60 s admin
(Linux nvme driver), no default for packets. The two page-3 limits (link, NVMe transaction) can also be set to
None by the admin: timing at that level is then not considered and the rule does not run.

Memory: the level tables are streamed in row order and a finding is inserted into the finding table as soon as a
rule fires (batches of BATCH rows); nothing per row is kept in RAM. The containment chain of a row is read from
the parent columns on disk only when a finding needs it (two or three primary-key reads), the per-command
aggregates come from a merge over the NVMe transactions ordered by parent, the deallocate / write-zeroes
read-back checks run over scratch tables in the attached work database, and the roll-up (cause per command,
roles, per-row counts) is SQL over the finding table. n_findings is left NULL on rows without a finding (the
pages treat NULL and 0 alike), so the rules never rewrite the big tables.
"""
import json
import math
import os
import re
import sqlite3
import statistics
import time
from collections import defaultdict

from . import loader as L
from . import names as N
from . import parse as P

BATCH = 20000              # findings per executemany
PROGRESS_EVERY = 2000      # rows between two looks at the clock; the reports themselves are at most one per second
LEVEL_RANK_SQL = "CASE %s WHEN 'packets' THEN 0 WHEN 'link' THEN 1 WHEN 'split' THEN 2 WHEN 'nvme_transaction' THEN 3 WHEN 'nvme_command' THEN 4 END"
FINDING_COLS = ("id", "level", "rule", "name", "severity", "cat_ref", "table_name", "rowid", "row_n", "t_ps", "value_ps", "limit_ps",
                "limit_source", "detail", "cmd_rowid", "part")

HERE = os.path.dirname(os.path.abspath(__file__))
CAT_DIR = os.path.join(os.path.dirname(HERE), "data", "catalogue")
LEVEL_RANK = {"packets": 0, "link": 1, "split": 2, "nvme_transaction": 3, "nvme_command": 4}
TABLE = {"packets": "pkt", "link": "lnk", "split": "spl", "nvme_transaction": "ntx", "nvme_command": "cmd"}
DEFAULT_LIMITS = {
    "link": {"ps": 50 * P.US, "short": "PCIe replay timer",
             "source": "PCIe Base 3.6.2.1: replay timer of the slowest link configuration (x1, 2.5 GT/s, 4 KB payload) \u2248 50 \u00b5s; faster links allow far less"},
    "nvme_transaction": {"ps": 50 * P.MS, "short": "PCIe completion timeout",
                         "source": "PCIe Base 2.8: a requester must give up on a read within 50 ms; the NVMe specification sets no time for a data, entry or PRP transfer"},
    "split": {"ps": 50 * P.MS, "source": "default: PCIe Base 2.8 completion timeout 50 ms; the requester's Device Control 2 range overrides when known"},
    "nvme_command": {"ps": 30 * P.SEC, "source": "default: Linux nvme driver I/O timeout 30 s (the NVMe specification sets no per-command limit)"},
    "nvme_command_admin": {"ps": 60 * P.SEC, "source": "default: Linux nvme driver admin timeout 60 s"},
}
# the two NVMe command rules the owner keeps (2026-11-09): cmd.timeout and cmd.read_failure
# admin commands that are long by nature (the same list as stage1/pcie_isolate/commands.py LONG_BY_NATURE) and the one that
# waits by design (Asynchronous Event Request completes only when an event occurs): never judged for time
LONG_BY_NATURE = {0x80: "Format NVM", 0x84: "Sanitize", 0x14: "Device Self-test", 0x10: "Firmware Commit", 0x11: "Firmware Image Download"}
WAITS_BY_DESIGN = {0x0C: "Asynchronous Event Request"}
NOT_TIMED_SQL = "NOT (c.sqid = 0 AND c.opc IN (%s))" % ", ".join(str(k) for k in sorted(set(LONG_BY_NATURE) | set(WAITS_BY_DESIGN)))
# "Usual": what the attacks of 2026-11-09 showed. Q3 + 2 x IQR called 11 to 50 healthy commands in 1,000 slow under natural noise, and found
# none when 30 % or more of a group was slow. A bell curve does not fit either: reads have two healthy groups (cache hits and flash reads).
# So the rule looks at the sorted times of one command type and size and asks where the normal group ends: at a clear jump.
USUAL_MIN = 20             # fewer completed commands of a type and size than this: no usual time is measured for them
USUAL_JUMP = 3.0           # the next time is at least this many times the one before it: a jump
USUAL_APART = 10.0         # a jump this large separates a slow group of any size up to USUAL_MOST
USUAL_FEW = 0.10           # a jump with at most this share of the commands above it separates them whatever its size
USUAL_MOST = 0.65          # more than this share above a jump is the drive's normal behaviour, not a fault
USUAL_LONE = 2             # at most this many commands above a jump are a lone outlier: the jump must also clear the group's own spread
USUAL_LONE_SPREAD = 1.8    # how many spreads (of the slower half of the normal commands, on a log scale) a lone outlier must clear
USUAL_LONE_ENOUGH = 5.0    # a jump this large clears it whatever the spread: nothing natural stands that far above everything else
USUAL_SAMPLE = 50000       # at most this many times per type and size are kept in memory (evenly spaced in order)
# the host gave up on the command: Command Abort Requested; Command Aborted due to SQ Deletion (the host deleted its queue, the
# reset that follows a timeout); Command Aborted By Host
HOST_ABORT = {(0, 0x07): "07h Command Abort Requested", (0, 0x08): "08h Command Aborted due to SQ Deletion", (3, 0x71): "3h/71h Command Aborted By Host"}
# a command's time ends at its FIRST completion entry: the Admin or I/O Completion Queue Entry joined to it in the tree (by SQID
# and CID, to the newest command with them: a CID is unique only while its command is outstanding); the Completion Queue Head
# Doorbell is the host's write, not the entry; a second completion entry for the same command is a fault of its own
FIRST_CQE_SQL = ("INSERT INTO temp.cmd_end SELECT parent, MIN(t_ps) FROM ntx WHERE parent_level = 'nvme_command' AND parent IS NOT NULL "
                 "AND part_key(type) = 'cqe' AND t_ps IS NOT NULL GROUP BY parent")
CMD_TIME_SQL = "(e.t_end - c.t_ps)"
# "usual" is per command type AND transfer size: a 256-block Write takes longer than an 8-block one (measured on the 10 GB
# upload, 2026-11-09: one group for all Writes put 15.7 % above the bar, one group per size 1.8 %)
BLOCKS_SQL = "(CASE WHEN c.sqid = 0 THEN -1 ELSE COALESCE(c.nlb, -1) END)"
TIMEOUT_USUAL_SQL = ("SELECT (c.sqid = 0) AS adm, c.opc AS opc, " + BLOCKS_SQL + " AS blocks, " + CMD_TIME_SQL + " AS dur_ps "
                     "FROM cmd c JOIN temp.cmd_end e ON e.rid = c.rowid_file WHERE c.t_ps IS NOT NULL AND " + NOT_TIMED_SQL)
TIMEOUT_SQL = ("SELECT c.rowid_file, c.n, c.opc, c.sqid, c.sct, c.sc, " + CMD_TIME_SQL + ", c.t_ps, b.bar_ps, b.median_ps, b.blocks FROM cmd c "
               "LEFT JOIN temp.cmd_end e ON e.rid = c.rowid_file "
               "LEFT JOIN temp.usual b ON b.adm = (c.sqid = 0) AND b.opc = c.opc AND b.blocks = " + BLOCKS_SQL + " WHERE " + NOT_TIMED_SQL +
               " AND ((c.sct IS NULL AND c.sc IS NULL) OR (COALESCE(c.sct, 0) = 0 AND c.sc IN (7, 8)) OR (c.sct = 3 AND c.sc = 113) "
               "OR " + CMD_TIME_SQL + " >= (CASE WHEN c.sqid = 0 THEN ? ELSE ? END) OR " + CMD_TIME_SQL + " > b.bar_ps) ORDER BY c.rowid_file")
# ---- the cycle of one NVMe command over PCIe (the owner, 2026-11-09: "from the start till you get ACK or NAK, it's a whole
# cycle; is that being tracked?"). The official steps, NVMe Base 2.1 section 3.3.1.2 (memory-based transport queue model) and
# 3.4.4: SUBMITTED when the host writes the Submission Queue Tail Doorbell (one write may submit several entries); FETCHED when
# the controller reads the submission queue entry; PRP list and data when the command moves data; COMPLETED when the controller
# writes the completion queue entry (its status is the drive's answer: Successful Completion, or an error); the interrupt
# (optional); CONSUMED when the host writes the Completion Queue Head Doorbell (one write may cover several entries). Every
# packet (TLP) of every step is answered on the link (PCIe Base 3.6.2): ACK (by an ACK naming its sequence number, or a later
# one: ACKs are cumulative; the analyzer's Explicit ACK Yes / No), NAK (the sender replays it; the analyzer writes "Nak
# received, replayed"), or never acknowledged (the analyzer's incomplete). Read from the tree: the command's NVMe transactions
# (joined by identity), their split and link transactions.
CYCLE = [("submitted", "doorbell"), ("fetched", "entry fetched"), ("prp", "PRP list"), ("data", "data"), ("completed", "completion entry"),
         ("interrupt", "interrupt"), ("consumed", "head doorbell")]
CYCLE_STEPS_SQL = "SELECT rowid_file, type, t_ps, sct, sc FROM ntx WHERE parent_level = 'nvme_command' AND parent = ? ORDER BY rowid_file"
# (the split transactions are looked up first, then their link transactions through the (parent_level, parent) index: a join
# here let SQLite read every link row of every split, millions on a large recording, for each step of each command)
CYCLE_LINKS_SQL = ("SELECT explicit_ack, errors FROM lnk WHERE parent_level = 'nvme_transaction' AND parent = ? UNION ALL "
                   "SELECT explicit_ack, errors FROM lnk WHERE parent_level = 'split' AND parent IN "
                   "(SELECT rowid_file FROM spl WHERE parent_level = 'nvme_transaction' AND parent = ?)")


def cycle_step(type_text):
    """The step of the cycle an NVMe transaction is (by the analyzer's Type, lower case), or None (controller registers:
    context, not a step)."""
    t = (type_text or "").lower()
    if "doorbell" in t:
        return "consumed" if ("head" in t or "completion" in t) else "submitted"
    if "entry" in t and "submission" in t:
        return "fetched"
    if "entry" in t and "completion" in t:
        return "completed"
    if "prp" in t or "sgl" in t:
        return "prp"
    if "data" in t:
        return "data"
    if "interrupt" in t or "msi" in t:
        return "interrupt"
    return None


def link_answer(explicit_ack, errors):
    """The link's answer to one TLP: 'ack' (named by an ACK, or covered by a later one), 'nak' (rejected, then replayed) or
    'unacked' (never acknowledged), from the analyzer's own decode."""
    e = (errors or "").lower()
    if "nak" in e or "replay" in e:
        return "nak"
    if "incomplete" in e or "no ack" in e:
        return "unacked"
    return "ack"


def command_cycle(con, cmd_rowid, t0_ps=None):
    """How far one command's cycle got, step by step, with the link's answer to every packet of each step."""
    steps = {k: {"step": k, "name": w, "seen": 0, "first_ps": None, "tlps": 0, "nak": 0, "unacked": 0} for k, w in CYCLE}
    answer = None
    for rid, ty, t, sct, sc in con.execute(CYCLE_STEPS_SQL, (cmd_rowid,)).fetchall():
        k = cycle_step(ty)
        if not k:
            continue
        s = steps[k]
        s["seen"] += 1
        if t is not None and (s["first_ps"] is None or t < s["first_ps"]):
            s["first_ps"] = t
        if k == "completed" and answer is None:
            answer = "positive" if not (sct or sc) else "negative: status %Xh/%02Xh" % (sct or 0, sc or 0)
        try:
            answers = con.execute(CYCLE_LINKS_SQL, (rid, rid)).fetchall()
        except sqlite3.OperationalError:        # a recording exported without its link or split file: the cycle stops at the NVMe transactions
            answers = []
        for ex, err in answers:
            s["tlps"] += 1
            a = link_answer(ex, err)
            if a != "ack":
                s[a] += 1
    reached = [k for k, _w in CYCLE if steps[k]["seen"]]
    tl, nak, un = (sum(steps[k][f] for k in reached) for f in ("tlps", "nak", "unacked"))
    parts = []
    for k in reached:
        s = steps[k]
        at = (" +%s" % P.fmt_ps(s["first_ps"] - t0_ps)) if t0_ps is not None and s["first_ps"] is not None and s["first_ps"] != t0_ps else ""
        parts.append("%s%s%s" % (s["name"], (" x%d" % s["seen"]) if s["seen"] > 1 else "", at))
    link = ("all %d packets ACKed" % tl) if tl and not (nak or un) else ("%d packets: %s" % (tl, ", ".join(x for x in (
        "%d NAKed and replayed" % nak if nak else "", "%d never acknowledged" % un if un else "") if x))) if tl else "no packets under it"
    return {"reached": reached, "completed": bool(steps["completed"]["seen"]), "answer": answer,
            "stopped_after": None if steps["completed"]["seen"] else (dict(CYCLE)[reached[-1]] if reached else None),
            "tlps": tl, "nak": nak, "unacked": un, "steps": [steps[k] for k in reached],
            "words": "%s; %s%s" % (" > ".join(parts) or "no step of it was seen", link,
                                    "" if steps["completed"]["seen"] else "; no completion entry")}


READ_FAILURE_SQL = ("SELECT rowid_file, n, sct, sc, t_ps FROM cmd WHERE opc = 2 AND sqid != 0 AND (COALESCE(sct, 0) != 0 OR COALESCE(sc, 0) != 0) "
                    "AND NOT (COALESCE(sct, 0) = 0 AND sc IN (7, 8)) AND NOT (sct = 3 AND sc = 113) ORDER BY rowid_file")


def usual_bar(times_ps):
    """Where the normal group of one command type and size ends. On the sorted times, from the fastest, the normal group runs up to
    the first jump (the next time is USUAL_JUMP x or more) with few commands above it (USUAL_FEW), or a very large jump (USUAL_APART x)
    with no more than USUAL_MOST above it. One or two commands above a jump must also clear the spread of the group (natural noise makes
    lone outliers). The normal group always holds at least USUAL_FEW of the commands. A smaller jump with many commands above
    it is the drive's second normal group (cache hits and flash reads). The limit is USUAL_JUMP x the slowest normal command, so a command
    is slower than usual only when it stands clear of everything normal. Returns None with fewer than USUAL_MIN times."""
    xs = sorted(v for v in times_ps if v and v > 0)
    n = len(xs)
    if n < USUAL_MIN:
        return None
    cut = None
    for i in range(max(1, math.ceil(n * USUAL_FEW)), n):
        jump = xs[i] / xs[i - 1]
        if jump >= USUAL_JUMP:
            above = (n - i) / n
            if n - i <= max(USUAL_LONE + 1, n * USUAL_FEW) or (jump >= USUAL_APART and above <= USUAL_MOST):
                if n - i <= USUAL_LONE:         # one or two commands above a jump: natural noise also makes those; it must clear this group's spread
                    q50, q90 = xs[(i - 1) // 2], xs[int((i - 1) * 0.9)]
                    if jump < min(USUAL_LONE_ENOUGH, math.exp(USUAL_LONE_SPREAD * math.log(q90 / q50) / 1.2816)):
                        continue
                cut = i
                break
    normal = xs[:cut] if cut else xs
    return {"centre_ps": normal[len(normal) // 2], "top_ps": normal[-1], "normal": len(normal), "bar_ps": int(round(normal[-1] * USUAL_JUMP))}


def group_values(con, sql, keys, value, cap=USUAL_SAMPLE):
    """{group: (n, [values in order])}: one pass over the rows sorted by group and value. A group larger than `cap` keeps evenly spaced
    values below its slowest part and every value of its slowest 1 % (at least 1,000), where the jumps are."""
    gk = ", ".join(keys)
    sql = "SELECT * FROM (%s) WHERE %s IS NOT NULL" % (sql, value)        # a command whose time cannot be read says nothing about usual
    counts = {tuple(r[:-1]): r[-1] for r in con.execute("SELECT %s, COUNT(*) FROM (%s) GROUP BY %s" % (gk, sql, gk))}
    out, cur, i, step, tail_from = {}, None, 0, 1, 0
    for row in con.execute("SELECT %s, %s FROM (%s) ORDER BY %s, %s" % (gk, value, sql, gk, value)):
        g, v = tuple(row[:-1]), row[-1]
        if g != cur:
            n = counts[g]
            cur, i, step, tail_from = g, 0, max(1, n // cap), n - max(1000, n // 100)
            out[g] = (n, [])
        if i % step == 0 or i >= tail_from:
            out[g][1].append(v)
        i += 1
    return out


def group_quantiles(con, sql, keys, value, qs=(0.25, 0.5, 0.75)):
    """{group: (n, {q: value})} for a query with the named group columns `keys` and the numeric column `value`: the counts
    first, then one pass over the rows sorted by group and value, keeping only the few ranks each group needs (any size)."""
    gk = ", ".join(keys)
    counts = {tuple(r[:-1]): r[-1] for r in con.execute("SELECT %s, COUNT(*) FROM (%s) GROUP BY %s" % (gk, sql, gk))}
    out, cur, i, want, got = {}, None, 0, {}, {}

    def close(g):
        n = counts[g]
        out[g] = (n, {q: got[a] + (got[min(a + 1, n - 1)] - got[a]) * f for q, (a, f) in want.items()})
    for row in con.execute("SELECT %s, %s FROM (%s) ORDER BY %s, %s" % (gk, value, sql, gk, value)):
        g, v = tuple(row[:-1]), row[-1]
        if g != cur:
            if cur is not None:
                close(cur)
            cur, i, n = g, 0, counts[g]
            want = {q: (int((n - 1) * q), (n - 1) * q - int((n - 1) * q)) for q in qs}
            got = {}
        if any(i in (a, min(a + 1, counts[cur] - 1)) for a, _f in want.values()):
            got[i] = v
        i += 1
    if cur is not None:
        close(cur)
    return out


def quantiles(con, sql, args=(), qs=(0.25, 0.5, 0.75)):
    """(n, {q: value}) of one numeric column, linear between the two nearest ranks (the usual definition). Streams the
    sorted rows once and keeps only the few it needs, so it works on any size."""
    n = con.execute("SELECT COUNT(*) FROM (%s)" % sql, args).fetchone()[0]
    if not n:
        return 0, {}
    want = {q: (int((n - 1) * q), (n - 1) * q - int((n - 1) * q)) for q in qs}
    need = sorted({i for i, _f in want.values()} | {min(i + 1, n - 1) for i, _f in want.values()})
    got, last = {}, need[-1]
    for i, (v,) in enumerate(con.execute(sql + " ORDER BY 1", args)):
        if i in need:
            got[i] = v
        if i >= last:
            break
    return n, {q: got[i] + (got[min(i + 1, n - 1)] - got[i]) * f for q, (i, f) in want.items()}


LINK_EVENTS = [
    (re.compile(r"recovery", re.I), "pkt.recovery", "link entered Recovery"),
    (re.compile(r"link down|surprise|hot reset|disable", re.I), "pkt.link_down", "link went down or was reset"),
    (re.compile(r"speed|rate", re.I), "pkt.speed_change", "link speed changed"),
    (re.compile(r"width|lane", re.I), "pkt.width_change", "link width changed"),
    (re.compile(r"electrical idle(?! exit)", re.I), "pkt.electrical_idle", "link entered electrical idle"),
]


class Catalogue:
    def __init__(self):
        self.by_name = {}        # lower-case name/alias -> entry (01)
        self.by_id = {}          # S1.. N1.. (02)
        self.by_status = {}      # (sct, sc) -> entry (03)
        self.silent = {}         # lower-case error name -> entry (03 silent)
        for f, kind in (("01_errors_packet_link.json", "pl"), ("02_errors_split_nvmetx.json", "sn"), ("03_errors_nvme_command.json", "cmd")):
            p = os.path.join(CAT_DIR, f)
            if not os.path.exists(p):
                continue
            with open(p, encoding="utf-8") as fh:
                data = json.load(fh)
            for e in data:
                if kind == "pl":
                    self.by_name[e["error"].lower()] = e
                    for a in e.get("aliases") or []:
                        self.by_name[str(a).lower()] = e
                elif kind == "sn":
                    self.by_id[e.get("id")] = e
                else:
                    if e.get("sct") is not None and e.get("sc") is not None:
                        self.by_status[(int(e["sct"]), int(e["sc"]))] = e
                    if e.get("silent"):
                        self.silent[e["error"].lower()] = e

    def packet(self, text):
        t = (text or "").lower()
        if t in self.by_name:
            return self.by_name[t]
        for k, e in self.by_name.items():
            if k and k in t:
                return e
        return None

    def ref(self, entry):
        if not entry:
            return None
        return entry.get("id") or entry.get("error")


def brief(entry):
    """What the screen shows next to a finding: meaning, defects per domain, spec."""
    if not entry:
        return None
    return {"error": entry.get("error"), "meaning": entry.get("meaning") or entry.get("description"),
            "spec": entry.get("spec"), "defects": entry.get("defects") or [],
            "propagates_to": entry.get("propagates_to") or [], "extra_evidence": entry.get("extra_evidence") or []}



# ------------------------------------------------------------------ the basis of every rule (shown with every finding)
# kind: "specification" = the specification says this is wrong (a firm error) · "analyzer" = the analyzer's own flag or
# status (firm) · "admin limit" = over a number the admin chose (a suspect until the limit is confirmed) · "policy" =
# depends on the drive's declared behaviour or on something outside the recording (a suspect to confirm) ·
# "inference" = this project's reading of the export (a suspect until a real export confirms it) · "owner's rule" = the owner
# decided this is a failure; the numbers it uses are measured on the recording or come from the named sources (firm).
BASIS = {
    "pkt.analyzer_error": ("analyzer", "the analyzer flagged the packet in its Errors cell (one of its 72 error kinds)", "Teledyne LeCroy M64 manual 10.2.2.1; Error Summary report"),
    "pkt.bad_lcrc": ("specification", "a TLP whose link CRC does not match is corrupt and must be refused (Nak)", "PCIe Base 3.6.2.1 LCRC"),
    "pkt.bad_ecrc": ("specification", "a TLP whose end-to-end CRC does not match carries corrupt data", "PCIe Base 2.7.1 ECRC"),
    "pkt.bad_crc16": ("specification", "a DLLP whose CRC-16 does not match is discarded", "PCIe Base 3.5.2 DLLP CRC"),
    "pkt.poisoned_tlp": ("specification", "the EP (poison) bit marks the data as known bad", "PCIe Base 2.7.2.2 data poisoning"),
    "pkt.invalid_packet": ("analyzer", "a row the analyzer could not decode: no number, no type (the analyzer flagged it)", "Teledyne LeCroy export behaviour, measured on the real export 2026-10-27"),
    "pkt.link_down": ("analyzer", "the analyzer recorded a Link Down event", "M64 manual link events; PCIe Base 4.2.6 LTSSM"),
    "pkt.electrical_idle": ("analyzer", "the analyzer recorded electrical idle (context, not a fault by itself)", "PCIe Base 4.2.4.3 electrical idle"),
    "pkt.recovery": ("analyzer", "the link went through Recovery (re-training); context", "PCIe Base 4.2.6.4 Recovery"),
    "pkt.speed_change": ("analyzer", "the link speed changed; context", "PCIe Base 4.2.6.4.1 speed change"),
    "pkt.width_change": ("analyzer", "the link width changed; context", "PCIe Base 4.2.6.3 link width"),
    "lnk.incomplete": ("specification", "a TLP that never received an Ack was never accepted by the other side", "PCIe Base 3.6.2 Ack/Nak protocol"),
    "lnk.replay": ("specification", "a Nak means the receiver rejected the TLP; the resend is the retry mechanism (context, counts as a warning)", "PCIe Base 3.6.2.1 Nak and replay"),
    "lnk.response_over_limit": ("admin limit", "the link transaction's Time Delta (the analyzer's wait from this row to the next, written in the export) is at or above the link limit the admin set on page 3 (default 50 µs, the PCIe replay timer): the owner's rule of 2026-11-03; a suspect until the limit is confirmed for this platform", "PCIe Base 3.6.2.1 replay timer; admin's limit on page 3"),
    "lnk.analyzer_error": ("analyzer", "the analyzer's Link Tra Error cell is set", "M64 manual 10.19 link transaction decode"),
    "spl.analyzer_error": ("analyzer", "the analyzer's Split Tra Error cell is set (a column some exports carry; seen 2026-11-03)", "M64 manual 10.19 transaction decode, split transaction error cell"),
    "spl.cpl_ur": ("specification", "completion status Unsupported Request: the completer does not serve the request", "PCIe Base 2.2.9 completion status UR"),
    "spl.cpl_ca": ("specification", "completion status Completer Abort: the completer gave up on a valid request", "PCIe Base 2.2.9 completion status CA"),
    "spl.cpl_crs": ("specification", "Configuration Request Retry Status: the device is not ready yet (a warning)", "PCIe Base 2.3.1 CRS"),
    "spl.incomplete": ("specification", "a non-posted request with no completion at all: the requester's completion timeout applies", "PCIe Base 2.8 completion timeout"),
    "spl.short_data": ("specification", "fewer bytes arrived than the request asked for", "PCIe Base 2.3.1.1 completion data"),
    "spl.latency_over_limit": ("admin limit", "the split transaction's Time Delta (the analyzer's wait to the next row) is at or above the split limit the admin set (default 50 ms, the end of the PCIe completion-timeout range): the owner's rule of 2026-11-03; a suspect until the limit is confirmed", "PCIe Base 2.8 and 7.5.3.16 completion timeout ranges; admin's limit"),
    "ntx.analyzer_error": ("analyzer", "the analyzer's error cell of the NVMe transaction is set", "M64 manual 10.2.3.1 NVMe transaction errors"),
    "ntx.analyzer_warning": ("analyzer", "the analyzer's warning cell is set (context)", "M64 manual 10.2.3.1"),
    "ntx.status_error": ("specification", "the completion entry carries a status other than Successful Completion", "NVMe Base 2.1 section 4.2.3 completion queue entry status"),
    "ntx.phase_wrong": ("specification", "the completion entry's phase bit does not match what the host expects for this queue wrap", "NVMe Base 2.1 section 4.2.3 phase tag"),
    "ntx.over_limit": ("admin limit", "the NVMe transaction's Time Delta (the analyzer's wait to the next row) is at or above the NVMe-transaction limit the admin set on page 3 (default 50 ms, the PCIe completion timeout): the owner's rule of 2026-11-03; a suspect until the limit is confirmed", "PCIe Base 2.8 completion timeout; admin's limit on page 3"),
    "ntx.interrupt_before_completion": ("specification", "the interrupt that announces a completion was written before the completion entry it announces", "NVMe Base 2.1 section 3.3.1.2 (completion then interrupt)"),
    "ntx.completion_unknown_command": ("specification", "a completion entry names a queue id and command id that are not open", "NVMe Base 2.1 section 4.2.3 CID/SQID of a completion"),
    "cmd.status_error": ("specification", "the command's status field is not Successful Completion; the name of the status comes from the specification's status tables", "NVMe Base 2.1 section 4.2.3.1 to 4.2.3.3; NVM Command Set 1.1 figures 17 to 19"),
    "cmd.analyzer_error": ("analyzer", "the analyzer's error cell of the command is set", "M64 manual 10.2.4.1 command errors"),
    "cmd.analyzer_warning": ("analyzer", "the analyzer's warning cell of the command is set (context)", "M64 manual 10.2.4.1"),
    "cmd.incomplete": ("specification", "no completion entry was ever written for the command", "NVMe Base 2.1 section 3.3.1.2 command completion"),
    "cmd.not_fetched": ("policy", "the doorbell was rung but no fetch of the entry was seen: a suspect, because a fetch can be hidden by an earlier combined fetch of several entries", "NVMe Base 2.1 section 3.3.1.2; M64 manual 7.8.6.12"),
    "cmd.doorbell_missing": ("policy", "no submission doorbell write of its own: a suspect, because one doorbell write may announce several commands (coalesced doorbell)", "NVMe Base 2.1 section 3.3.1.2 tail doorbell"),
    "cmd.no_interrupt": ("policy", "no interrupt followed the completion: a suspect, because the host may poll or mask the vector or coalesce interrupts", "NVMe Base 2.1 sections 5.27.1.6 and 3.3.1.2"),
    "cmd.latency_over_limit": ("admin limit", "the command's Time Delta (the analyzer's wait to the next command) is at or above the command limit the admin set (defaults from the Linux driver's 30 s I/O and 60 s admin timeouts): the owner's rule of 2026-11-03; a suspect until the limit is confirmed", "Linux drivers/nvme/host/core.c io_timeout / admin_timeout; admin's limit"),
    "cmd.bytes_short": ("inference", "fewer data bytes moved than the command's block count asks for, assuming 512-byte blocks: a suspect until the block size is confirmed from Identify Namespace", "NVM Command Set 1.1 LBA format (block size); this project's count of data transfers"),
    "cmd.deallocate_readback": ("policy", "a read of a deallocated range: the value is a firm error only when the drive declared (DLFEAT 001b zeros / 010b FFh) a value and returned something else; with DLFEAT not reported the read value is implementation specific and the finding is a suspect", "NVM Command Set 1.1 sections 3.3.3 (deallocate is advisory), 3.3.3.2.1 (read of a deallocated block), 4.1.5.1 DLFEAT"),
    "cmd.write_zeroes_readback": ("specification", "a range cleared by Write Zeroes must read back as zeros", "NVM Command Set 1.1 section 3.3.8 Write Zeroes"),
    "cmd.timeout": ("owner's rule", "an NVMe command timed out: it never completed although the recording went on for the host's limit or "
                    "longer after it was sent, the host aborted it (status 07h Command Abort Requested, 08h Command Aborted due to SQ "
                    "Deletion, or 3h/71h Command Aborted By Host), or it completed only after the host's limit. A command that took longer "
                    "than usual for its command type and size is a failure too (the owner's rule)",
                    "NVMe Base 2.1 (the specification sets no completion time for a command; Abort command; status 07h Command Abort "
                    "Requested); Linux drivers/nvme/host/core.c io_timeout 30 s and admin_timeout 60 s, pci.c nvme_timeout() (Abort, "
                    "then controller reset); the owner's rule of 2026-11-09 (longer than usual is a failure). Usual is measured per command "
                    "type and size in the recording: the sorted times are split where the normal group ends, at a clear jump; a command 3 x or "
                    "more above the slowest normal command is slower than usual"),
    "cmd.read_failure": ("specification", "a Read did not return its data: it completed with an error status. A read error that stays after "
                         "the drive's retries is the most common failure that reaches the host, in Google's field study about 100 times "
                         "more frequent than any other (Schroeder et al., FAST 2016, section 3.1); in NVMe it is mostly Unrecovered Read "
                         "Error, status type 2h code 81h",
                         "NVM Command Set 1.1 Read command; NVMe Base 2.1 status tables (2h Media and Data Integrity Errors, 81h "
                         "Unrecovered Read Error)"),
}


def basis(rule):
    """{kind, text, ref, firm} for a rule id: what makes it an error, and whether it is firm or a suspect."""
    k = BASIS.get(rule)
    if not k:
        return {"kind": "unknown", "text": "no basis recorded for this rule", "ref": "", "firm": False, "words": "Source: none recorded for this rule."}
    return {"kind": k[0], "text": k[1], "ref": k[2], "firm": k[0] in ("specification", "analyzer", "owner's rule"), "words": source_words(k[0], k[2])}


def source_words(kind, ref):
    """One sentence that names where a rule comes from, shown with every finding (owner's request 2026-11-03):
    'Specification: NVMe Base 2.1 section 3.3.1.2 (completion then interrupt).' for a rule that is the specification's
    own words; 'Source: …' for the analyzer's own flags, the admin's limits and this project's readings."""
    ref = (ref or "").strip().rstrip(".")
    if kind == "specification":
        return "Specification: %s." % ref
    if kind == "analyzer":
        return "Source: the analyzer's own flag (%s)." % ref
    if kind == "admin limit":
        import re as _re
        default = _re.sub(r";?\s*admin's limit( on page 3)?$", "", ref).strip().rstrip(";").strip()
        return "Source: the admin's limit on page 3, whose default comes from %s; a suspect until the limit is confirmed." % default
    if kind == "policy":
        return "Source: this project's reading of %s; a suspect, not the specification's own words." % ref
    if kind == "inference":
        return "Source: this project's inference from %s; a suspect." % ref
    if kind == "owner's rule":
        return "Source: %s." % ref
    return "Source: %s." % ref if ref else "Source: none recorded."


class _Pacer:
    """Progress of the rules: a new step at once, the same step at most once a second, and a sign of life during one long SQL statement."""

    def __init__(self, con, report):
        self.report, self.step, self.said = report, None, 0.0
        self.since = time.time()
        self.end = L.heartbeat(con, self.beat)

    def __call__(self, step, detail=""):
        t = time.time()
        if step != self.step or t - self.said >= L.REPORT_SECONDS:
            if step != self.step:
                self.since = t
            self.step, self.said = step, t
            self.report(step, detail)

    def beat(self, secs):
        self.said = time.time()
        self.report(self.step or "rules", "still working on this step, %d s so far" % (self.said - self.since))


class Rules:
    def __init__(self, con, thresholds, progress=None, fresh=True):
        self.con = con
        self.progress = _Pacer(con, progress or (lambda s, d: None))
        L.add_missing_columns(con)
        self.cat = Catalogue()
        self.renumber_map = {}
        self.levels = json.loads(con.execute("SELECT v FROM meta WHERE k='levels_present'").fetchone()[0])
        self.limits = self._limits(thresholds or {})
        self.thresholds = thresholds or {}
        self.timing = None
        self.n_findings = 0
        self.counts = defaultdict(int)
        self._batch = []
        con.create_function("tlp_class", 1, N.tlp_class, deterministic=True)
        con.create_function("part_key", 1, N.part_key, deterministic=True)
        if fresh:
            con.execute("DROP TABLE IF EXISTS finding")
            con.execute("""CREATE TABLE finding (id INTEGER PRIMARY KEY, level TEXT, rule TEXT, name TEXT, severity TEXT, cat_ref TEXT,
                           table_name TEXT, rowid INTEGER, row_n INTEGER, t_ps INTEGER, value_ps INTEGER, limit_ps INTEGER, limit_source TEXT,
                           detail TEXT, cmd_rowid INTEGER, part TEXT, cause_level TEXT, cause_rule TEXT, cause_finding INTEGER)""")
            con.commit()
        else:
            # one rule is re-run in place: the ids continue after the highest one stored
            self.n_findings = con.execute("SELECT COALESCE(MAX(id), 0) FROM finding").fetchone()[0]

    def _limits(self, th):
        out = {}
        for level in ("link", "split", "nvme_transaction", "nvme_command", "packets"):
            v = th.get(level)
            if level in th and v is None:
                continue                      # the admin left the field empty on page 3: timing at this level is not considered
            if v and v.get("ps"):
                out[level] = {"ps": int(v["ps"]), "source": v.get("source") or "set by the admin", "admin": True}
            elif level in DEFAULT_LIMITS:
                out[level] = dict(DEFAULT_LIMITS[level], admin=False)
        out["nvme_command_admin"] = out["nvme_command"] if out.get("nvme_command", {}).get("admin") else dict(DEFAULT_LIMITS["nvme_command_admin"], admin=False)
        return out

    # ------------------------------------------------------------------ chain
    def chain(self, level, rowid):
        """(affected command rowid, part of the command) of a row at any level, read from the parent columns on
        disk: link -> split -> NVMe transaction -> command, or link -> NVMe transaction -> command. The command is
        None when the row is outside any command; the part is the NVMe transaction's Type ("none" without one)."""
        con = self.con
        if level == "nvme_command":
            return rowid, "none"
        if level == "link":
            r = con.execute("SELECT parent_level, parent FROM lnk WHERE rowid_file=?", (rowid,)).fetchone()
            if not r or r[1] is None:
                return None, "none"
            level, rowid = r[0], r[1]
        if level == "split":
            r = con.execute("SELECT parent FROM spl WHERE rowid_file=?", (rowid,)).fetchone()
            if not r or r[0] is None:
                return None, "none"
            level, rowid = "nvme_transaction", r[0]
        if level == "nvme_transaction":
            r = con.execute("SELECT parent, type FROM ntx WHERE rowid_file=?", (rowid,)).fetchone()
            if not r:
                return None, "none"
            return r[0], N.part_key(r[1])
        return None, "none"

    def cmd_of(self, level, rowid):
        """Affected command rowid of a row at any level, through the tree; None when outside any command."""
        return self.chain(level, rowid)[0]

    def part_of(self, level, rowid):
        return self.chain(level, rowid)[1]

    def add(self, level, rule, name, rowid, row_n, t_ps, severity="error", cat=None, value_ps=None, limit=None,
            detail=None, cmd_rowid="auto", part=None):
        if cmd_rowid == "auto" or part is None:
            c, pk = self.chain(level, rowid)
            if cmd_rowid == "auto":
                cmd_rowid = c
            if part is None:
                part = pk
        self.n_findings += 1
        self.counts[rule] += 1
        self._batch.append((self.n_findings, level, rule, name, severity, self.cat.ref(cat), TABLE[level], rowid, row_n, t_ps, value_ps,
                            limit["ps"] if limit else None, limit["source"] if limit else None,
                            json.dumps(detail or {}, default=str), cmd_rowid, part))
        if len(self._batch) >= BATCH:
            self.flush()

    def flush(self):
        if self._batch:
            self.con.executemany("INSERT INTO finding (%s) VALUES (%s)" % (", ".join(FINDING_COLS), ",".join("?" * len(FINDING_COLS))), self._batch)
            self._batch = []
            self.con.commit()

    # ------------------------------------------------------------------ packet rules
    def packets(self):
        con = self.con
        cols = {r[1] for r in con.execute("PRAGMA table_info(pkt)")}
        has_errors = "errors" in cols
        n = 0
        for rowid, pn, tlp_type, dllp_type, os_type, link_event, lcrc, ecrc, crc16, ep, t_ps, parent_level, parent, errors in con.execute(
                "SELECT rowid_file, n, tlp_type, dllp_type, os_type, link_event, lcrc, ecrc, crc16, ep, t_ps, parent_level, parent, errors FROM pkt ORDER BY rowid_file"):
            n += 1
            if n % PROGRESS_EVERY == 0:
                self.progress("rules: packets", "{:,} rows".format(n))
            # which rules fire on this packet, decided from its own cells first. Every TLP carries an LCRC value, so "the cell
            # holds something" is no reason to look further: only a rule that fires needs the command the packet sits in
            flagged = bool(has_errors and errors)
            bad_lcrc = bool(lcrc) and "(Bad)" in lcrc
            bad_ecrc = bool(ecrc) and "(Bad)" in ecrc
            bad_crc16 = bool(crc16) and "(Bad)" in crc16
            undecoded = pn is None and not (tlp_type or dllp_type or os_type or link_event)
            event = next(((rule, text) for rx, rule, text in LINK_EVENTS if rx.search(link_event)), None) if link_event else None
            if not (flagged or bad_lcrc or bad_ecrc or bad_crc16 or ep or undecoded or event):
                continue
            # the command and part this packet sits in: up to three reads by row id, made for these packets only
            if parent_level == "link" and parent is not None:
                cmd, part = self.chain("link", parent)
            elif parent_level == "nvme_command":
                cmd, part = parent, "none"
            else:
                cmd, part = None, "none"
            if flagged:
                e = self.cat.packet(errors)
                self.add("packets", "pkt.analyzer_error", "analyzer error: " + errors, rowid, pn, t_ps,
                         cat=e, detail={"cell": errors}, cmd_rowid=cmd, part=part)
            if bad_lcrc:
                self.add("packets", "pkt.bad_lcrc", "TLP with a bad LCRC (link CRC)", rowid, pn, t_ps,
                         cat=self.cat.packet("TLP: Bad LCRC"), detail={"LCRC": lcrc}, cmd_rowid=cmd, part=part)
            if bad_ecrc:
                self.add("packets", "pkt.bad_ecrc", "TLP with a bad ECRC (end-to-end CRC)", rowid, pn, t_ps,
                         cat=self.cat.packet("TLP: Bad ECRC"), detail={"ECRC": ecrc}, cmd_rowid=cmd, part=part)
            if bad_crc16:
                self.add("packets", "pkt.bad_crc16", "DLLP with a bad CRC-16", rowid, pn, t_ps,
                         cat=self.cat.packet("DLLP: Bad CRC16"), detail={"CRC 16": crc16}, cmd_rowid=cmd, part=part)
            if ep:
                self.add("packets", "pkt.poisoned_tlp", "poisoned TLP (EP bit set): the data in it is known bad", rowid, pn, t_ps,
                         cat=self.cat.by_id.get("S8"), cmd_rowid=cmd, part=part)
            if undecoded:
                self.add("packets", "pkt.invalid_packet", "packet the analyzer could not decode (no number, no type)", rowid, None, t_ps,
                         cat=self.cat.packet("Invalid Packet"), cmd_rowid=cmd, part=part)
            if event:
                self.add("packets", event[0], "%s: %s" % (event[1], link_event), rowid, pn, t_ps,
                         severity="warning", detail={"Link Event": link_event}, cmd_rowid=cmd, part="none")
        self.flush()

    # ------------------------------------------------------------------ link rules
    def links(self):
        lim = self.limits.get("link")
        n = 0
        for rowid, ln, tlp_type, errors, n_packets, delta_ps, t_ps in self.con.execute(
                "SELECT rowid_file, n, tlp_type, errors, n_packets, delta_ps, t_ps FROM lnk ORDER BY rowid_file"):
            n += 1
            if n % PROGRESS_EVERY == 0:
                self.progress("rules: link transactions", "{:,} rows".format(n))
            if errors:
                t = errors.lower()
                rule = "lnk.replay" if ("nak" in t or "replay" in t or "retr" in t) else ("lnk.incomplete" if "incomplete" in t or "no ack" in t else "lnk.analyzer_error")
                self.add("link", rule, "analyzer: " + errors, rowid, ln, t_ps, detail={"cell": errors})
            elif (n_packets or 0) > 2:
                self.add("link", "lnk.replay", "more packets than one TLP and its Ack (%d): the TLP was rejected or resent" % n_packets,
                         rowid, ln, t_ps, detail={"Metrics.# Packets": n_packets})
            if lim and delta_ps is not None and delta_ps >= lim["ps"]:
                self.link_timing(lim, rowid, ln, delta_ps, t_ps)
        self.flush()

    def link_timing(self, lim, rowid, ln, delta_ps, t_ps):
        """The link-level timing error (rule lnk.response_over_limit): the link transaction's duration, from the TLP to
        the Ack or Nak that answered it) is at or above the link limit (the owner's statement of 2026-11-03: >= the admin's
        limit, 50 us by default: the PCIe replay timer). Filed here by the load-time pass and by apply_link_limit alike."""
        self.add("link", "lnk.response_over_limit", "Time Delta of %s, at or above the link limit of %s" % (P.fmt_ps(delta_ps), P.fmt_ps(lim["ps"])),
                 rowid, ln, t_ps, value_ps=delta_ps, limit=lim)

    # ------------------------------------------------------------------ split rules
    def splits(self):
        lim = self.limits.get("split")
        con = self.con
        # the request's Length (dwords) comes from the last non-posted link transaction inside the split
        req = ("(SELECT l.length FROM lnk l WHERE l.parent_level='split' AND l.parent=s.rowid_file AND l.length IS NOT NULL AND l.length != 0 "
               "AND tlp_class(l.tlp_type)='non-posted' ORDER BY l.rowid_file DESC LIMIT 1)") if "link" in self.levels else "NULL"
        n = 0
        for rowid, sn, tlp_type, cpl_status, n_links, delta_ps, t_ps, nbytes, req_len, errors in con.execute(
                "SELECT s.rowid_file, s.n, s.tlp_type, s.cpl_status, s.n_links, s.delta_ps, s.t_ps, s.nbytes, %s, s.errors FROM spl s ORDER BY s.rowid_file" % req):
            n += 1
            if n % PROGRESS_EVERY == 0:
                self.progress("rules: split transactions", "{:,} rows".format(n))
            if errors:
                self.add("split", "spl.analyzer_error", "analyzer: " + errors, rowid, sn, t_ps, detail={"cell": errors})
            st = (cpl_status or "").upper()
            if st == "UR":
                self.add("split", "spl.cpl_ur", "completion status Unsupported Request: the completer does not serve this address", rowid, sn, t_ps, cat=self.cat.by_id.get("S1"))
            elif st == "CA":
                self.add("split", "spl.cpl_ca", "completion status Completer Abort", rowid, sn, t_ps, cat=self.cat.by_id.get("S2"))
            elif st == "CRS":
                self.add("split", "spl.cpl_crs", "completion status Configuration Request Retry: the device is not ready", rowid, sn, t_ps, cat=self.cat.by_id.get("S3"))
            elif st == "INCOMPLETE" or (n_links == 1 and st in ("", "NONE")):
                self.add("split", "spl.incomplete", "request without any completion (completion timeout)", rowid, sn, t_ps, cat=self.cat.by_id.get("S4"))
            if lim and delta_ps is not None and delta_ps >= lim["ps"]:
                self.add("split", "spl.latency_over_limit", "Time Delta of %s, at or above the split limit of %s" % (P.fmt_ps(delta_ps), P.fmt_ps(lim["ps"])),
                         rowid, sn, t_ps, value_ps=delta_ps, limit=lim, cat=self.cat.by_id.get("S5"))
            want = req_len * 4 if req_len else None
            if want and st == "SC" and nbytes is not None and nbytes < want:
                self.add("split", "spl.short_data", "completions carried %d bytes of the %d requested" % (nbytes, want), rowid, sn, t_ps,
                         cat=self.cat.by_id.get("S6"), detail={"requested": want, "received": nbytes})
        self.flush()

    # ------------------------------------------------------------------ NVMe transaction rules
    def phase_bits(self):
        """Completion entries must carry the expected phase bit: it starts at 1 when a completion queue is created
        and flips every time the queue wraps (NVMe Base 4.2 / 3.3). Queue base and size come from the Create I/O CQ
        command (PRP1, QSIZE) that created the queue most recently before the entry; an ACQ register write restarts
        the admin queue, whose base is then its next completion entry. A wrong bit means the host ignores the entry."""
        con = self.con
        events = []      # (t_ps, order, kind, qid, base, size): one per queue creation, bounded by the queue count
        if "nvme_command" in self.levels:
            for qid, qsize, prp1, t_ps in con.execute("SELECT qid, qsize, prp1, t_ps FROM cmd WHERE sqid = 0 AND opc = 5 AND qid IS NOT NULL AND prp1 IS NOT NULL ORDER BY rowid_file"):
                events.append((t_ps or 0, 0, "create", qid, prp1, qsize))
            # the completion queue of the entry's command (CQID, else its SQID), read through a join
            sql = ("SELECT r.rowid_file, r.n, r.type, r.addr, r.phase, r.parent, r.sqid, r.t_ps, c.rowid_file, c.cqid, c.sqid "
                   "FROM ntx r LEFT JOIN cmd c ON c.rowid_file = r.parent WHERE r.phase IS NOT NULL ORDER BY r.t_ps, r.rowid_file")
        else:
            sql = ("SELECT rowid_file, n, type, addr, phase, parent, sqid, t_ps, NULL, NULL, NULL FROM ntx WHERE phase IS NOT NULL ORDER BY t_ps, rowid_file")
        for (t_ps,) in con.execute("SELECT t_ps FROM ntx WHERE type LIKE '%Register%' AND type LIKE '%ACQ%' ORDER BY rowid_file"):
            events.append((t_ps or 0, 0, "acq", 0, None, None))
        events.sort()
        ei = 0
        cq_base, cq_size, expected, last_slot = {}, {}, {}, {}
        for rowid, rn, typ, addr, phase, parent, sqid, t_ps, c_row, c_cqid, c_sqid in con.execute(sql):
            if N.part_key(typ) != "cqe" or addr is None:
                continue
            t = t_ps or 0
            while ei < len(events) and events[ei][0] <= t:
                _, _, kind, q, base, size = events[ei]
                ei += 1
                if kind == "create":
                    cq_base[q], cq_size[q] = base, size
                else:
                    cq_base.pop(q, None)
                expected[q] = 1
                last_slot.pop(q, None)
            if parent is not None and c_row is not None:
                cq = c_cqid if c_cqid is not None else c_sqid
            else:
                cq = sqid
            if cq not in cq_base:
                cq_base[cq] = addr
            slot = (addr - cq_base[cq]) // 16
            size = cq_size.get(cq)
            if size:
                slot %= size
            exp = expected.setdefault(cq, 1)
            if cq in last_slot and slot < last_slot[cq]:      # wrapped to the start: the phase flips
                exp ^= 1
                expected[cq] = exp
            last_slot[cq] = slot
            if phase != exp:
                self.add("nvme_transaction", "ntx.phase_wrong", "completion entry carries phase bit %d, the host expects %d at slot %d of queue %s: the entry is invisible to the host" % (phase, exp, slot, cq),
                         rowid, rn, t_ps, cat=self.cat.by_id.get("N14"), detail={"phase": phase, "expected": exp, "slot": slot, "queue": cq})
        self.flush()

    def ntx(self):
        self.phase_bits()
        lim = self.limits.get("nvme_transaction")
        n = 0
        for rowid, rn, typ, errors, warnings, sct, sc, dnr, dur_ps, delta_ps, t_ps in self.con.execute(
                "SELECT rowid_file, n, type, errors, warnings, sct, sc, dnr, dur_ps, delta_ps, t_ps FROM ntx ORDER BY rowid_file"):
            n += 1
            if n % PROGRESS_EVERY == 0:
                self.progress("rules: NVMe transactions", "{:,} rows".format(n))
            if errors:
                self.add("nvme_transaction", "ntx.analyzer_error", "analyzer flagged this transaction: %s" % errors, rowid, rn, t_ps, detail={"cell": errors})
            if warnings:
                self.add("nvme_transaction", "ntx.analyzer_warning", "analyzer warning: %s" % warnings, rowid, rn, t_ps, severity="warning", detail={"cell": warnings})
            if "nvme_command" not in self.levels and (sct or sc):
                e = self.cat.by_status.get((sct or 0, sc or 0))
                self.add("nvme_transaction", "ntx.status_error", "completion status %s" % ((e or {}).get("error") or "type %s code %s" % (sct, sc)),
                         rowid, rn, t_ps, cat=e, detail={"SCT": sct, "SC": sc, "DNR": dnr})
            if lim and delta_ps is not None and delta_ps >= lim["ps"]:
                self.ntx_timing(lim, rowid, rn, delta_ps, t_ps)
        self.flush()

    def ntx_timing(self, lim, rowid, rn, delta_ps, t_ps):
        """The NVMe-transaction timing error (rule ntx.over_limit): the transaction's duration, from its first packet to its
        last, is at or over the NVMe-transaction limit (50 ms by default, the PCIe completion timeout). Filed here by the
        load-time pass and by apply_ntx_limit alike."""
        self.add("nvme_transaction", "ntx.over_limit", "Time Delta of %s, at or above the NVMe-transaction limit of %s" % (P.fmt_ps(delta_ps), P.fmt_ps(lim["ps"])),
                 rowid, rn, t_ps, value_ps=delta_ps, limit=lim)

    # ------------------------------------------------------------------ command rules
    def cmds(self):
        con = self.con
        have_ntx = "nvme_transaction" in self.levels
        if have_ntx:
            # an interrupt written before the completion entry it announces (the host reads a stale queue): the
            # first interrupt and the first completion entry of every command, in SQL
            for cmd, t, rid, n, cqe_t in con.execute("""
                    WITH f AS (SELECT parent, part_key(type) AS pk, MIN(rowid_file) AS r0 FROM ntx
                               WHERE parent_level='nvme_command' AND parent IS NOT NULL AND part_key(type) IN ('irq', 'cqe') GROUP BY parent, pk)
                    SELECT i.parent, ni.t_ps, ni.rowid_file, ni.n, nc.t_ps FROM f i JOIN f c ON c.parent = i.parent AND c.pk = 'cqe'
                    JOIN ntx ni ON ni.rowid_file = i.r0 JOIN ntx nc ON nc.rowid_file = c.r0 WHERE i.pk = 'irq' ORDER BY i.r0"""):
                if cqe_t is not None and t is not None and t < cqe_t:
                    self.add("nvme_transaction", "ntx.interrupt_before_completion", "interrupt written %s before the completion entry it announces" % P.fmt_ps(cqe_t - t),
                             rid, n, t, cat=self.cat.by_id.get("N20"), detail={"interrupt_t": t, "completion_t": cqe_t}, cmd_rowid=cmd, part="irq")
            # a completion entry that joined no command: unknown or already closed command id
            for rowid, rn, typ, sqid, cid, t_ps in con.execute("SELECT rowid_file, n, type, sqid, cid, t_ps FROM ntx WHERE relation='orphan' ORDER BY rowid_file"):
                if N.part_key(typ) == "cqe" and cid is not None:
                    self.add("nvme_transaction", "ntx.completion_unknown_command", "completion entry for queue %s, command id %s, which is not open (unknown or already completed id)" % (sqid, cid),
                             rowid, rn, t_ps, cat=self.cat.by_id.get("N15"), detail={"sqid": sqid, "cid": cid}, cmd_rowid=None, part="cqe")
        # the read-back checks need the Dataset Management / Write Zeroes commands and the Reads: scratch tables
        con.execute("CREATE TABLE w.dsm (id INTEGER PRIMARY KEY, cmd INTEGER, nsid INTEGER, t0 INTEGER, rng TEXT, n INTEGER)")
        con.execute("CREATE TABLE w.wz (id INTEGER PRIMARY KEY, cmd INTEGER, nsid INTEGER, t0 INTEGER, rng TEXT, n INTEGER)")
        con.execute("CREATE TABLE w.reads (id INTEGER PRIMARY KEY, cmd INTEGER, nsid INTEGER, t INTEGER, t0 INTEGER, slba INTEGER, nlb INTEGER, n INTEGER)")
        con.commit()
        dsm, wz, reads = [], [], []
        # the parts and the completion flags of every command: a merge over the transactions ordered by parent
        parts_cur = con.execute("SELECT parent, part_key(type), sct, sc, dnr, more, crd FROM ntx WHERE parent_level='nvme_command' AND parent IS NOT NULL "
                                "ORDER BY parent, rowid_file") if have_ntx else None
        nxt = parts_cur.fetchone() if parts_cur else None
        n_rows = 0
        for c in con.execute("SELECT rowid_file, n, opc, sqid, cid, nsid, slba, nlb, nbytes, sct, sc, errors, warnings, dur_ps, delta_ps, t_ps, ad, nr, raw FROM cmd ORDER BY rowid_file"):
            (rid, cn, opc, sqid, cid, nsid, slba, nlb, nbytes, sct, sc, errors, warnings, dur_ps, delta_ps, t_ps, ad, nr, raw_text) = c
            n_rows += 1
            if n_rows % PROGRESS_EVERY == 0:
                self.progress("rules: NVMe commands", "{:,} rows".format(n_rows))
            ps = None
            flags = {}
            while nxt is not None and nxt[0] < rid:
                nxt = parts_cur.fetchone()
            while nxt is not None and nxt[0] == rid:
                if ps is None:
                    ps = set()
                ps.add(nxt[1])
                if nxt[1] == "cqe":
                    flags = {"DNR": nxt[4], "M": nxt[5], "CRD": nxt[6]}
                nxt = parts_cur.fetchone()
            opname = N.opcode_name(opc, sqid)
            lim = self.limits.get("nvme_command_admin" if sqid == 0 else "nvme_command")
            if sct or sc:
                e = self.cat.by_status.get((sct or 0, sc or 0))
                self.add("nvme_command", "cmd.status_error", "%s completed with status %s" % (opname, (e or {}).get("error") or "type %s code %s" % (sct, sc)),
                         rid, cn, t_ps, cat=e, detail={"SCT": sct, "SC": sc, "DNR": flags.get("DNR"), "M": flags.get("M"), "opcode": opname}, cmd_rowid=rid, part="cqe")
            if errors:
                self.add("nvme_command", "cmd.analyzer_error", "analyzer flagged this command: %s" % errors, rid, cn, t_ps, detail={"cell": errors}, cmd_rowid=rid, part="none")
            if warnings:
                self.add("nvme_command", "cmd.analyzer_warning", "analyzer warning: %s" % warnings, rid, cn, t_ps, severity="warning", detail={"cell": warnings}, cmd_rowid=rid, part="none")
            if ps is not None:
                if "cqe" not in ps:
                    self.add("nvme_command", "cmd.incomplete", "%s never completed: no completion entry was written" % opname, rid, cn, t_ps,
                             cat=self.cat.silent.get("command never completes") or self.cat.by_id.get("N4"), detail={"parts_seen": sorted(ps)}, cmd_rowid=rid, part="cqe")
                if "entry" not in ps:
                    self.add("nvme_command", "cmd.not_fetched", "%s: the controller never fetched the submission entry" % opname, rid, cn, t_ps,
                             detail={"parts_seen": sorted(ps)}, cmd_rowid=rid, part="entry")
                if "dbl" not in ps:
                    self.add("nvme_command", "cmd.doorbell_missing", "%s has no submission doorbell transaction of its own (implicit doorbell, or missing)" % opname, rid, cn, t_ps,
                             severity="check", cmd_rowid=rid, part="dbl")
                if "cqe" in ps and "irq" not in ps:
                    self.add("nvme_command", "cmd.no_interrupt", "%s completed without an interrupt write (polling, masked vector, or a lost MSI-X)" % opname, rid, cn, t_ps,
                             severity="check", cmd_rowid=rid, part="irq")
            if lim and delta_ps is not None and delta_ps >= lim["ps"]:
                self.add("nvme_command", "cmd.latency_over_limit", "%s: Time Delta of %s, at or above the command limit of %s" % (opname, P.fmt_ps(delta_ps), P.fmt_ps(lim["ps"])),
                         rid, cn, t_ps, value_ps=delta_ps, limit=lim, cmd_rowid=rid, part="cqe")
            if sqid != 0 and opc in (1, 2) and nlb is not None and nbytes is not None and not (sct or sc):
                want = (nlb + 1) * 512
                if nbytes < want:
                    self.add("nvme_command", "cmd.bytes_short", "%s moved %d bytes of the %d requested (512-byte blocks assumed)" % (opname, nbytes, want), rid, cn, t_ps,
                             cat=self.cat.silent.get("bytes transferred smaller than requested"), detail={"requested": want, "moved": nbytes}, cmd_rowid=rid, part="data")
            if sqid != 0 and opc == 9 and ad:
                raw = json.loads(raw_text) if raw_text else {}
                rng = []
                for i in range((nr or 0) + 1):
                    s0, l0 = raw.get("RNG %d.SLBA" % i), raw.get("RNG %d.Length LB" % i)
                    if s0 is not None and l0 is not None:
                        rng.append((P.int_value(s0), P.int_value(l0)))
                if rng:
                    dsm.append((rid, nsid, t_ps, json.dumps(rng), cn))
            if sqid != 0 and opc == 8 and slba is not None and nlb is not None and not (sct or sc):
                wz.append((rid, nsid, t_ps, json.dumps([(slba, nlb + 1)]), cn))
            if sqid != 0 and opc == 2 and slba is not None and nlb is not None:
                reads.append((rid, nsid, t_ps, t_ps or 0, slba, nlb, cn))
            if len(dsm) + len(wz) + len(reads) >= BATCH:
                self._stash(dsm, wz, reads)
                dsm, wz, reads = [], [], []
        if parts_cur:
            parts_cur.close()
        self._stash(dsm, wz, reads)
        self.flush()
        con.execute("CREATE INDEX w.ix_reads ON reads (nsid, t0, id)")
        con.commit()
        self._deallocate_readback()
        self._write_zeroes_readback()
        self.flush()
        self.command_timeout()
        self.read_failures()
        for t in ("dsm", "wz", "reads"):
            con.execute("DROP TABLE w.%s" % t)
        con.commit()

    def command_timeout(self):
        """cmd.timeout, the first of the two rules the owner keeps (2026-11-09). Judged on the NVMe command rows:
        - never completed: the row has no status (ST.SCT and ST.SC empty) and the recording went on for the host's limit or
          longer after the command was sent (the command file's own last Time Stamp); a command sent later than that is
          still open when the recording ends and is not judged;
        - aborted by the host: status 07h Command Abort Requested or 3h/71h Command Aborted By Host (the host's timeout);
        - over the host's limit: its time (its Time Stamp to its FIRST completion entry, joined in the tree) is the host's
          limit or more (the Linux driver's defaults: I/O 30 s, admin 60 s);
        - slower than usual (the owner's rule): its time is above usual_bar() of the completed commands of the same type and size
          in this recording, measured only for types with at least USUAL_MIN of them.
        Long-by-nature admin commands (Format, Sanitize, Self-test, Firmware) and the Asynchronous Event Request (it
        waits for an event by design) are never judged for time."""
        con = self.con
        self.flush()
        io_lim = self.limits.get("nvme_command") or dict(DEFAULT_LIMITS["nvme_command"])
        adm_lim = self.limits.get("nvme_command_admin") or dict(DEFAULT_LIMITS["nvme_command_admin"])
        end_ps = con.execute("SELECT MAX(t_ps) FROM cmd").fetchone()[0]
        info = {}
        con.execute("DROP TABLE IF EXISTS temp.cmd_end")
        con.execute("CREATE TEMP TABLE cmd_end (rid INTEGER PRIMARY KEY, t_end INTEGER)")
        if "nvme_transaction" in self.levels:
            con.execute(FIRST_CQE_SQL)                    # each command's first completion entry, read once from the tree
        con.execute("DROP TABLE IF EXISTS temp.usual")
        con.execute("CREATE TEMP TABLE usual (adm INTEGER, opc INTEGER, blocks INTEGER, n INTEGER, median_ps REAL, bar_ps INTEGER)")
        groups = group_values(con, TIMEOUT_USUAL_SQL, ("adm", "opc", "blocks"), "dur_ps")
        for (adm, opc, blocks), (n, times) in sorted(groups.items(), key=lambda kv: [(x is None, x or 0) for x in kv[0]]):       # a cell that could not be read is None
            within = [v for v in times if v < (adm_lim if adm else io_lim)["ps"]]     # a command over the host's limit is judged already; it says nothing about usual
            u = usual_bar(within) if len(within) >= USUAL_MIN else None
            bar, centre, top = (u["bar_ps"], u["centre_ps"], u["top_ps"]) if u else (None, times[len(times) // 2], None)
            info[(adm, opc, blocks)] = {"command": N.opcode_name(opc, 0 if adm else 1), "admin": bool(adm), "opc": opc, "blocks": blocks + 1 if blocks >= 0 else None,
                                        "n": n, "median_ps": centre, "top_ps": top, "normal": (u or {}).get("normal"), "bar_ps": bar}
            con.execute("INSERT INTO temp.usual VALUES (?,?,?,?,?,?)", (adm, opc, blocks, n, centre, bar))
        open_at_end = 0
        for rid, cn, opc, sqid, sct, sc, dur, t_ps, bar, med, blocks in con.execute(TIMEOUT_SQL, (adm_lim["ps"], io_lim["ps"])):
            lim, what = (adm_lim if sqid == 0 else io_lim), N.opcode_name(opc, sqid)
            if sct is None and sc is None:
                waited = (end_ps or 0) - (t_ps or 0)
                if t_ps is None or waited < lim["ps"]:
                    open_at_end += 1                       # still open when the recording ended: not judged
                    continue
                kind, value, use = "never completed", waited, lim
                name = "%s never completed: no status in its row, and the recording went on %s after it was sent (the host's limit is %s)" % (
                    what, P.fmt_ps(waited), P.fmt_ps(lim["ps"]))
            elif (sct or 0, sc or 0) in HOST_ABORT:
                kind, value, use = "aborted by the host", dur, lim
                name = "%s was aborted by the host%s (status %s): the host gave up waiting for it" % (
                    what, (" after %s" % P.fmt_ps(dur)) if dur is not None else "", HOST_ABORT[(sct or 0, sc or 0)])
            elif dur is not None and dur >= lim["ps"]:
                kind, value, use = "over the host's limit", dur, lim
                name = "%s took %s, at or above the host's limit of %s" % (what, P.fmt_ps(dur), P.fmt_ps(lim["ps"]))
            else:
                g = info[(1 if sqid == 0 else 0, opc, blocks)]
                kind, value = "slower than usual", dur
                sized = "%s of %d blocks" % (what, blocks + 1) if blocks is not None and blocks >= 0 else what
                use = {"ps": bar, "source": "usual time of a %s in this recording: %s, the middle of the %s normal ones of its %s completed ones; the slowest normal one took %s; "
                                            "limit %s = %d x that" % (sized, P.fmt_ps(int(med)), "{:,}".format(g["normal"]), "{:,}".format(g["n"]), P.fmt_ps(int(g["top_ps"])), P.fmt_ps(bar), USUAL_JUMP)}
                name = "%s took %s, longer than usual: %.1f x the usual %s in this recording (%s), above its limit of %s" % (
                    sized, P.fmt_ps(dur), dur / med if med else 0, sized, P.fmt_ps(int(med or 0)), P.fmt_ps(bar))
            # the cycle is read from the command's NVMe transactions. A recording loaded from the NVMe command file alone has
            # none (2026-11-12: such a load failed here with "no such table: ntx"): the command row is then all the rule judges
            cyc = command_cycle(con, rid, t_ps) if "nvme_transaction" in self.levels else None
            if cyc is None:
                pass
            elif kind == "never completed":
                name = "%s never completed: its cycle stopped after the %s (%s), and the recording went on %s after it was sent (the host's limit is %s)" % (
                    what, cyc["stopped_after"] or "start", cyc["words"], P.fmt_ps(value), P.fmt_ps(lim["ps"]))
            else:
                name = "%s · cycle: %s" % (name, cyc["words"])
            self.add("nvme_command", "cmd.timeout", name, rid, cn, t_ps, value_ps=value, limit=use, cmd_rowid=rid, part="cqe",
                     detail={"kind": kind, "host_limit_ps": lim["ps"], "usual_bar_ps": bar, "median_ps": med,
                             "times_median": round(dur / med, 2) if dur and med else None,
                             "cycle": {k: cyc[k] for k in ("reached", "completed", "answer", "stopped_after", "tlps", "nak", "unacked", "words")} if cyc else None})
        self.flush()
        con.execute("DROP TABLE IF EXISTS temp.usual")
        con.execute("DROP TABLE IF EXISTS temp.cmd_end")
        self.timing = {"recording_end_ps": end_ps, "host_io_ps": io_lim["ps"], "host_admin_ps": adm_lim["ps"], "open_at_end": open_at_end,
                       "usual": sorted(info.values(), key=lambda x: (bool(x["admin"]), x["opc"] or 0, x["blocks"] or 0)), "min_for_usual": USUAL_MIN,
                       "not_timed": {**{"admin %02Xh" % k: v for k, v in LONG_BY_NATURE.items()}, **{"admin %02Xh" % k: v for k, v in WAITS_BY_DESIGN.items()}}}

    def read_failures(self):
        """cmd.read_failure, the second rule the owner keeps (2026-11-09): a Read on an I/O queue that completed with an error
        status, read from the command row alone (OPC, SQID, ST.SCT, ST.SC). The host's own aborts belong to cmd.timeout."""
        tree = "nvme_transaction" in self.levels
        for rid, cn, sct, sc, t_ps in self.con.execute(READ_FAILURE_SQL):
            e = self.cat.by_status.get((sct or 0, sc or 0))
            top = (sct or 0, sc or 0) == (2, 0x81)
            cyc = command_cycle(self.con, rid, t_ps) if tree else None
            self.add("nvme_command", "cmd.read_failure", "Read failed: %s (status type %Xh, code %02Xh)%s%s" % (
                (e or {}).get("error") or "an error status", sct or 0, sc or 0, ": the drive could not correct the data, the most common failure in the field" if top else "",
                (" · cycle: %s" % cyc["words"]) if cyc else ""),
                rid, cn, t_ps, cat=e, detail={"SCT": sct, "SC": sc, "unrecovered_read_error": top,
                                              "cycle": {k: cyc[k] for k in ("reached", "completed", "answer", "stopped_after", "tlps", "nak", "unacked", "words")} if cyc else None},
                cmd_rowid=rid, part="cqe")
        self.flush()

    def _stash(self, dsm, wz, reads):
        con = self.con
        con.executemany("INSERT INTO w.dsm (cmd, nsid, t0, rng, n) VALUES (?,?,?,?,?)", dsm)
        con.executemany("INSERT INTO w.wz (cmd, nsid, t0, rng, n) VALUES (?,?,?,?,?)", wz)
        con.executemany("INSERT INTO w.reads (cmd, nsid, t, t0, slba, nlb, n) VALUES (?,?,?,?,?,?,?)", reads)
        con.commit()

    def _reads_after(self, nsid, t0):
        """The Read commands of a namespace after a time, in time order (ties in file order)."""
        return self.con.execute("SELECT cmd, nsid, t, slba, nlb, n FROM w.reads WHERE nsid IS ? AND t0 > ? ORDER BY t0, id", (nsid, t0 or 0))

    def _write_zeroes_readback(self):
        """A Read of a range cleared by Write Zeroes must return zeros (NVM Command Set 3.3.8)."""
        con = self.con
        cat = self.cat.silent.get("write zeroes not applied / deac ignored")
        for rid, nsid, t0, rng_text, n0 in con.execute("SELECT cmd, nsid, t0, rng, n FROM w.wz ORDER BY id").fetchall():
            rng = json.loads(rng_text)
            for r_rid, r_nsid, t1, slba, nlb, n1 in self._reads_after(nsid, t0):
                for s0, l0 in rng:
                    if slba <= s0 + l0 - 1 and s0 <= slba + nlb:
                        verdict, sev, detail = self._read_bytes_verdict(r_rid)
                        if detail.get("pattern") == "ffh":
                            verdict, sev = "the range reads FFh, not zeros: Write Zeroes was not applied", "error"
                        elif detail.get("pattern") == "zeros":
                            verdict, sev = "the range reads zeros, as Write Zeroes requires", "warning"
                        self.add("nvme_command", "cmd.write_zeroes_readback",
                                 "Read of LBA %d (%d blocks) follows Write Zeroes of LBA %d (%d blocks) in command %d: %s" % (slba, nlb + 1, s0, l0, n0, verdict),
                                 r_rid, n1, t1, severity=sev, cat=cat, detail=dict(detail, write_zeroes_command=n0, range=[s0, l0]), cmd_rowid=r_rid, part="data")
                        break

    def _deallocate_readback(self):
        """A Read of a range deallocated earlier must return the DLFEAT-declared value (zeros or FFh); when the bytes
        were exported the check is made here, otherwise it is filed as a check for a host read-back."""
        con = self.con
        cat = self.cat.silent.get("dataset management deallocate did not deallocate")
        for rid, nsid, t0, rng_text, n0 in con.execute("SELECT cmd, nsid, t0, rng, n FROM w.dsm ORDER BY id").fetchall():
            rng = json.loads(rng_text)
            for r_rid, r_nsid, t1, slba, nlb, n1 in self._reads_after(nsid, t0):
                for s0, l0 in rng:
                    if s0 is None or l0 is None:
                        continue
                    if slba <= s0 + l0 - 1 and s0 <= slba + nlb:
                        verdict, sev, detail = self._read_bytes_verdict(r_rid)
                        declared = {1: "zeros", 2: "ffh"}.get(self._dlfeat(nsid))          # what the drive declared for deallocated blocks
                        detail = dict(detail, dlfeat_declared=declared or "not reported")
                        if detail.get("pattern") == "data":
                            if declared:
                                verdict, sev = "the deallocated range returns other data although the drive declared %s (DLFEAT): the deallocate was not applied" % declared, "error"
                            else:
                                verdict, sev = "the deallocated range returns other data; the drive did not declare a read value for deallocated blocks (DLFEAT not reported), so this is a suspect, not a proven error", "check"
                        elif declared and detail.get("pattern") and detail.get("pattern") != declared:
                            verdict, sev = "the deallocated range reads %s but the drive declared %s (DLFEAT)" % (detail.get("pattern"), declared), "error"
                        self.add("nvme_command", "cmd.deallocate_readback",
                                 "Read of LBA %d (%d blocks) follows the deallocate of LBA %d (%d blocks) in command %d: %s" % (slba, nlb + 1, s0, l0, n0, verdict),
                                 r_rid, n1, t1, severity=sev, cat=cat, detail=dict(detail, deallocate_command=n0, range=[s0, l0]), cmd_rowid=r_rid, part="data")
                        break

    def _dlfeat(self, nsid):
        """DLFEAT bits 0-2 from the latest Identify Namespace row of this namespace (None when not exported)."""
        try:
            r = self.con.execute("SELECT dlfeat FROM cmd WHERE dlfeat IS NOT NULL AND (nsid=? OR nsid IS NULL) ORDER BY rowid_file DESC LIMIT 1", (nsid,)).fetchone()
        except Exception:      # noqa: BLE001 - older uploads without the column
            return None
        return int(r[0]) & 7 if r and r[0] is not None else None

    def _read_bytes_verdict(self, cmd_rowid):
        """Looks at the exported data bytes of the read's data transfers (first 64 KB). Returns (text, severity, detail)."""
        if "nvme_transaction" not in self.levels or "packets" not in self.levels or "link" not in self.levels:
            return "data bytes not available at this level; verify with a host read-back", "check", {"bytes_checked": 0}
        con = self.con
        total = 0
        zeros = 0
        ffs = 0
        for r in con.execute("""SELECT p.raw FROM ntx n JOIN lnk l ON l.parent_level='nvme_transaction' AND l.parent=n.rowid_file
                                JOIN pkt p ON p.parent_level='link' AND p.parent=l.rowid_file
                                WHERE n.parent_level='nvme_command' AND n.parent=? AND p.tlp_type LIKE 'MWr%' LIMIT 256""", (cmd_rowid,)):
            raw = json.loads(r[0]) if r[0] else {}
            d = raw.get("DATA") or ""
            if not P.data_is_expanded(d):
                continue
            b = bytes.fromhex(d.replace(" ", ""))
            total += len(b)
            zeros += b.count(0)
            ffs += b.count(0xFF)
            if total >= 65536:
                break
        if total == 0:
            return "the export holds data sizes, not bytes; verify with a host read-back of the range", "check", {"bytes_checked": 0}
        if zeros == total:
            return "the device returned zeros for the deallocated range (as DLFEAT 001b declares)", "warning", {"bytes_checked": total, "pattern": "zeros"}
        if ffs == total:
            return "the device returned FFh for the deallocated range (as DLFEAT 010b declares)", "warning", {"bytes_checked": total, "pattern": "ffh"}
        return "the deallocated range still returns other data: the deallocate was not applied", "error", {"bytes_checked": total, "pattern": "data"}

    # ------------------------------------------------------------------ roll-up and write
    def renumber(self):
        """Defect numbers follow the time of occurrence (owner's rule 2026-11-03): defect 1 is the earliest error of the
        recording, ties go to the lower level first, then the file row. Runs after every filing pass (the build and each
        timing re-run), so the order is one and the same everywhere. Returns {old id: new id} for the ids that moved."""
        con = self.con
        con.execute("DROP TABLE IF EXISTS w.renum")
        # old_id is the PRIMARY KEY so that the UPDATE below finds each row's new number by index, not by a scan
        # (a scan per row made the roll-up take hours on a capture with millions of findings, 2026-11-03)
        con.execute("CREATE TABLE w.renum (old_id INTEGER PRIMARY KEY, new_id INTEGER)")
        con.execute("""INSERT INTO w.renum SELECT id, ROW_NUMBER() OVER (ORDER BY COALESCE(t_ps, 0), %s, rowid, id)
                       FROM finding""" % (LEVEL_RANK_SQL % "level"))
        n_moved = con.execute("SELECT COUNT(*) FROM w.renum WHERE old_id != new_id").fetchone()[0]
        moved = {}
        if n_moved:
            # the map returned to the caller is only needed for the ids the knowledge store may reference (a timing
            # re-run on an upload that has been looked at); it is kept bounded so it never dwarfs the work itself
            if n_moved <= 200000:
                moved = {int(a): int(b) for a, b in con.execute("SELECT old_id, new_id FROM w.renum WHERE old_id != new_id")}
            else:
                moved = {"_count": n_moved}
            con.execute("UPDATE finding SET id = -(SELECT new_id FROM w.renum r WHERE r.old_id = finding.id)")
            con.execute("UPDATE finding SET id = -id WHERE id < 0")
            con.execute("UPDATE finding SET cause_finding = NULL WHERE cause_finding IS NOT NULL")
        con.execute("DROP TABLE w.renum")
        con.commit()
        return moved

    def write(self):
        con = self.con
        self.flush()
        self.progress("rules: roll-up", "numbering the findings by time of occurrence")
        self.renumber_map = self.renumber()
        self.progress("rules: roll-up", "indexing the findings")
        con.execute("CREATE INDEX IF NOT EXISTS ix_finding_cmd ON finding (cmd_rowid)")
        con.execute("CREATE INDEX IF NOT EXISTS ix_finding_level ON finding (level, rule)")
        con.execute("CREATE INDEX IF NOT EXISTS ix_finding_row ON finding (level, rowid, severity)")
        # a second roll-up (apply_link_limit) starts from a clean cause column
        con.execute("UPDATE finding SET cause_level = NULL, cause_rule = NULL, cause_finding = NULL WHERE cause_finding IS NOT NULL")
        # cause per command: the lowest-level error finding inside the command (earliest wins on ties, then the
        # first filed)
        self.progress("rules: roll-up", "the cause of every command")
        con.execute("CREATE TABLE w.cause (cmd INTEGER PRIMARY KEY, id INTEGER, level TEXT, rule TEXT)")
        con.execute("""INSERT INTO w.cause SELECT cmd_rowid, id, level, rule FROM (
                           SELECT cmd_rowid, id, level, rule, ROW_NUMBER() OVER (PARTITION BY cmd_rowid ORDER BY %s, COALESCE(t_ps, 0), id) AS rn
                           FROM finding WHERE severity = 'error' AND cmd_rowid IS NOT NULL) WHERE rn = 1""" % (LEVEL_RANK_SQL % "level"))
        con.execute("""UPDATE finding SET cause_level = c.level, cause_rule = c.rule, cause_finding = c.id FROM w.cause c
                       WHERE c.cmd = finding.cmd_rowid AND c.id != finding.id AND (%s) < (%s)"""
                    % (LEVEL_RANK_SQL % "c.level", LEVEL_RANK_SQL % "finding.level"))
        con.commit()
        # per-row counts (NULL = no error finding at this level; the pages treat NULL as 0) and the command verdicts
        for level, t in TABLE.items():
            if level not in self.levels:
                continue
            self.progress("rules: roll-up", "counting the findings per %s row" % level.replace("_", " "))
            cols = {r[1] for r in con.execute("PRAGMA table_info(%s)" % t)}
            if "n_findings" not in cols:
                con.execute("ALTER TABLE %s ADD COLUMN n_findings INTEGER" % t)
            else:
                con.execute("UPDATE %s SET n_findings = NULL WHERE n_findings IS NOT NULL" % t)
            con.execute("UPDATE %s SET n_findings = (SELECT COUNT(*) FROM finding f WHERE f.level=? AND f.rowid=%s.rowid_file AND f.severity='error') "
                        "WHERE rowid_file IN (SELECT rowid FROM finding WHERE level=? AND severity='error')" % (t, t), (level, level))
            con.commit()
        if "nvme_command" in self.levels:
            self.progress("rules: roll-up", "the verdict of every command")
            cols = {r[1] for r in con.execute("PRAGMA table_info(cmd)")}
            for c in ("n_sub_findings", "cause_level", "cause_rule", "role"):
                if c not in cols:
                    con.execute("ALTER TABLE cmd ADD COLUMN %s %s" % (c, "INTEGER" if c.startswith("n_") else "TEXT"))
            con.execute("UPDATE cmd SET n_sub_findings = (SELECT COUNT(*) FROM finding f WHERE f.cmd_rowid=cmd.rowid_file AND f.level!='nvme_command' AND f.severity='error'), cause_level=NULL, cause_rule=NULL, role=NULL")
            con.execute("""UPDATE cmd SET cause_level = c.level, cause_rule = c.rule, role = CASE
                               WHEN c.level = 'nvme_command' THEN 'root: the fault is in the command itself'
                               WHEN EXISTS (SELECT 1 FROM finding f WHERE f.cmd_rowid = cmd.rowid_file AND f.severity = 'error' AND f.level = 'nvme_command')
                                    THEN 'caused by the ' || replace(c.level, '_', ' ') || ' level'
                               ELSE 'lower-level finding inside this command, the command itself completed' END
                           FROM w.cause c WHERE c.cmd = cmd.rowid_file""")
            con.execute("""UPDATE cmd SET role = 'needs outside evidence' WHERE rowid_file NOT IN (SELECT cmd FROM w.cause)
                           AND EXISTS (SELECT 1 FROM finding f WHERE f.cmd_rowid = cmd.rowid_file AND f.severity = 'check')""")
        con.execute("DROP TABLE w.cause")
        con.commit()

    def summary(self):
        con = self.con
        by_sev = {s: 0 for s in ("error", "warning", "check")}
        for s, k in con.execute("SELECT severity, COUNT(*) FROM finding GROUP BY severity"):
            by_sev[s] = k
        return {"findings": self.n_findings, "by_rule": dict(sorted(self.counts.items())), "by_severity": by_sev, "timing": self.timing,
                "commands_with_findings": con.execute("SELECT COUNT(DISTINCT cmd_rowid) FROM finding WHERE cmd_rowid IS NOT NULL").fetchone()[0],
                "findings_outside_any_command": con.execute("SELECT COUNT(*) FROM finding WHERE cmd_rowid IS NULL").fetchone()[0],
                "limits": {k: {"ps": v["ps"], "text": P.fmt_ps(v["ps"]), "source": v["source"], "set_by_admin": v.get("admin", False)} for k, v in self.limits.items()}}


def apply(db_path, thresholds=None, progress=None):
    t0 = time.time()
    con = L.open_db(db_path)
    L.attach_work(con, db_path)
    R = None
    try:
        R = Rules(con, thresholds, progress)
        lv = set(R.levels)
        if "packets" in lv:
            R.progress("rules: packets", "")
            R.packets()
        if "link" in lv:
            R.progress("rules: link transactions", "")
            R.links()
        if "split" in lv:
            R.progress("rules: split transactions", "")
            R.splits()
        if "nvme_transaction" in lv:
            R.progress("rules: NVMe transactions", "")
            R.ntx()
        if "nvme_command" in lv:
            R.progress("rules: NVMe commands", "")
            R.cmds()
        R.progress("rules: roll-up", "")
        R.write()
        report = R.summary()
        report["seconds"] = round(time.time() - t0, 2)
        con.execute("INSERT OR REPLACE INTO meta (k, v) VALUES ('rules', ?)", (json.dumps(report),))
        con.commit()
    finally:
        if R is not None:
            R.progress.end()         # without this the sign of life went on reporting after the rules had finished
        L.drop_work(con, db_path)
        L.checkpoint(con)
        con.close()
    return report


# the two timing rules of page 3: (level, rule, table, the filer on Rules)
TIMING_RULES = {
    "link": ("lnk.response_over_limit", "lnk", "link_timing"),
    "nvme_transaction": ("ntx.over_limit", "ntx", "ntx_timing"),
}


def _apply_timing_limit(db_path, level, thresholds=None, progress=None, out=None):
    """Re-run ONLY one timing rule of page 3 with the limit in `thresholds` for its level (the admin's entry; None = not
    considered, so the rule's findings are deleted and none are filed; absent = the specification default), in place.
    The other findings stay as they are; the rule's existing findings are deleted, the level's table is read once more
    (duration >= limit), and the roll-up (Rules.write) runs again so the command rows' n_sub_findings, cause and role
    are right. Returns the counts; the 'rules' report in meta is updated (findings, by_rule, by_severity, limits,
    commands_with_findings)."""
    rule, table, filer = TIMING_RULES[level]
    t0 = time.time()
    con = L.open_db(db_path)
    L.attach_work(con, db_path)
    try:
        tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if "finding" not in tables:
            raise RuntimeError("the rules have not run on this upload yet; load it (or save the limits on the settings page) first")
        R = Rules(con, thresholds, progress, fresh=False)
        lim = R.limits.get(level)
        before = con.execute("SELECT COUNT(*) FROM finding WHERE rule=?", (rule,)).fetchone()[0]
        con.execute("DELETE FROM finding WHERE rule=?", (rule,))
        con.commit()
        n = 0
        if level in R.levels and lim:
            R.progress("%s limit: %s rows" % (level, table), "")
            for rowid, rn, delta_ps, t_ps in con.execute("SELECT rowid_file, n, delta_ps, t_ps FROM %s WHERE delta_ps >= ? ORDER BY rowid_file" % table, (lim["ps"],)):
                n += 1
                if n % PROGRESS_EVERY == 0:
                    R.progress("%s limit: %s rows" % (level, table), "{:,} at or over the limit".format(n))
                getattr(R, filer)(lim, rowid, rn, delta_ps, t_ps)
            R.flush()
        R.progress("%s limit: roll-up" % level, "")
        R.write()
        if out is not None:
            out["renumbered"] = R.renumber_map        # defect numbers that moved: the knowledge store's references follow
        report = json.loads((con.execute("SELECT v FROM meta WHERE k='rules'").fetchone() or ["{}"])[0] or "{}")
        by_sev = {s: 0 for s in ("error", "warning", "check")}
        for s, k in con.execute("SELECT severity, COUNT(*) FROM finding GROUP BY severity"):
            by_sev[s] = k
        report["findings"] = con.execute("SELECT COUNT(*) FROM finding").fetchone()[0]
        report["by_rule"] = {r: k for r, k in con.execute("SELECT rule, COUNT(*) FROM finding GROUP BY rule ORDER BY rule")}
        report["by_severity"] = by_sev
        report["commands_with_findings"] = con.execute("SELECT COUNT(DISTINCT cmd_rowid) FROM finding WHERE cmd_rowid IS NOT NULL").fetchone()[0]
        report["findings_outside_any_command"] = con.execute("SELECT COUNT(*) FROM finding WHERE cmd_rowid IS NULL").fetchone()[0]
        report.setdefault("limits", {})
        if lim:
            report["limits"][level] = {"ps": lim["ps"], "text": P.fmt_ps(lim["ps"]), "source": lim["source"], "set_by_admin": lim.get("admin", False)}
        else:
            report["limits"][level] = {"ps": None, "text": "not considered", "source": "the admin left the field empty on page 3", "set_by_admin": True}
        report.setdefault("timing_limit_applied", {})[level] = {"at": time.time(), "seconds": round(time.time() - t0, 2), "before": before, "after": n}
        con.execute("INSERT OR REPLACE INTO meta (k, v) VALUES ('rules', ?)", (json.dumps(report),))
        con.commit()
        return {"level": level, "rule": rule, "before": before, "after": n, "seconds": round(time.time() - t0, 2),
                "limit": report["limits"].get(level), "findings": report["findings"], "by_rule": report["by_rule"]}
    finally:
        L.drop_work(con, db_path)
        L.checkpoint(con)
        con.close()


COMMAND_RULES = ("cmd.timeout", "cmd.read_failure")
RETIRED_RULES = ("cmd.write_slow",)        # replaced by cmd.timeout (2026-11-09): its findings are removed by a re-run


def rerun_command_rules(db_path, thresholds=None, progress=None, out=None):
    """Re-run ONLY the two NVMe command rules (cmd.timeout, cmd.read_failure) on a tree already loaded: their findings (and
    those of retired rules) are deleted and filed again, then the roll-up. No reload of the recording."""
    t0 = time.time()
    con = L.open_db(db_path)
    L.attach_work(con, db_path)
    try:
        tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if "finding" not in tables:
            raise RuntimeError("the rules have not run on this upload yet; load it first")
        R = Rules(con, thresholds, progress, fresh=False)
        gone = COMMAND_RULES + RETIRED_RULES
        before = {r: k for r, k in con.execute("SELECT rule, COUNT(*) FROM finding WHERE rule IN (%s) GROUP BY rule" % ",".join("?" * len(gone)), gone)}
        con.execute("DELETE FROM finding WHERE rule IN (%s)" % ",".join("?" * len(gone)), gone)
        con.commit()
        if "nvme_command" in R.levels:
            R.progress("NVMe command rules: timeout", "")
            R.command_timeout()
            R.progress("NVMe command rules: read failure", "")
            R.read_failures()
        after = {r: R.counts.get(r, 0) for r in COMMAND_RULES}
        R.progress("NVMe command rules: roll-up", "")
        R.write()
        if out is not None:
            out["renumbered"] = R.renumber_map
        report = json.loads((con.execute("SELECT v FROM meta WHERE k='rules'").fetchone() or ["{}"])[0] or "{}")
        by_sev = {s: 0 for s in ("error", "warning", "check")}
        for s, k in con.execute("SELECT severity, COUNT(*) FROM finding GROUP BY severity"):
            by_sev[s] = k
        report["findings"] = con.execute("SELECT COUNT(*) FROM finding").fetchone()[0]
        report["by_rule"] = {r: k for r, k in con.execute("SELECT rule, COUNT(*) FROM finding GROUP BY rule ORDER BY rule")}
        report["by_severity"] = by_sev
        report["commands_with_findings"] = con.execute("SELECT COUNT(DISTINCT cmd_rowid) FROM finding WHERE cmd_rowid IS NOT NULL").fetchone()[0]
        report["findings_outside_any_command"] = con.execute("SELECT COUNT(*) FROM finding WHERE cmd_rowid IS NULL").fetchone()[0]
        report["timing"] = R.timing
        report.pop("write_usual", None)
        report.setdefault("rule_rerun", {})["command_rules"] = {"at": time.time(), "seconds": round(time.time() - t0, 2), "before": before, "after": after}
        con.execute("INSERT OR REPLACE INTO meta (k, v) VALUES ('rules', ?)", (json.dumps(report),))
        con.commit()
        return {"rules": list(COMMAND_RULES), "before": before, "after": after, "seconds": round(time.time() - t0, 2), "timing": R.timing,
                "findings": report["findings"]}
    finally:
        L.drop_work(con, db_path)
        L.checkpoint(con)
        con.close()


def apply_link_limit(db_path, thresholds=None, progress=None, out=None):
    """Page 3's link transaction limit: re-run only lnk.response_over_limit (duration from the TLP to its Ack or Nak >= the
    limit in thresholds["link"]; None = not considered; absent = 50 us, the PCIe replay timer) and the roll-up."""
    return _apply_timing_limit(db_path, "link", thresholds, progress, out)


def apply_ntx_limit(db_path, thresholds=None, progress=None, out=None):
    """Page 3's NVMe transaction limit: re-run only ntx.over_limit (duration from the first packet to the last >= the limit
    in thresholds["nvme_transaction"]; None = not considered; absent = 50 ms, the PCIe completion timeout) and the roll-up."""
    return _apply_timing_limit(db_path, "nvme_transaction", thresholds, progress, out)
