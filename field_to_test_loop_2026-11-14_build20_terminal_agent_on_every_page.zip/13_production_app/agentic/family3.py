"""Family 3 — Rules: sections, levels and items; one JSON rule file per item; the code is made from the rule.

A rule file (knowledge/rules/<section>/<level>/<id>.json) holds the item's definition in the admin's words, a PLAN
(what to compute, from which table and columns, with which filter), what to export, its version, who approved it and
its history. "Fix the rules, not the code": the code is generated from the plan by a fixed translator (compile_rule),
so the same rule always gives the same code, and a changed rule gives changed code, tied to the rule's version.

Plan kinds:
  distribution    the share of each value (or named value) of one column among the rows of one level
  read_pattern    reads classified as sequential (starting at the block after the previous read of the namespace
                  ended) or random (RndRead), with the first read of each namespace apart
  detection_rule  the defects found by one of the detector's rules (Section 2); stage 1 and stage 2 open from each row
  condition       the rows of one level whose columns meet the written conditions

Runs:
  rule_draft  write   the Rule writer turns the admin's words into a rule (definition + plan + export), the code checks
                      that the plan compiles against the real columns. REVIEW -> approve stores a new version
  rule_run    code    the code is generated from the approved rule version
              run     it runs on the project's built data (read only)
              test    the Tester checks the result independently (totals, percentages, the rows exist, the columns
                      mean what Family 1's dictionary says)
              export  CSV and HTML files
              result  REVIEW the result (approve accepts it; to change it, edit the rule)
"""
import csv
import html
import json
import os
import re
import sqlite3
import sys
import time

from . import core, family1

APP = family1.APP
sys.path.insert(0, APP)
sys.path.insert(0, os.path.join(APP, "app"))
from nvme_hier import columns as C, loader as L, names as N, osfile as OSF, rules as RL   # noqa: E402

# Sections are data (owner, 2026-11-09: "there can be many sections ... added by the admin"): the two built-in sections
# first, then the admin's own, kept in knowledge/rules/sections.json. SECTIONS (id -> "Section n · name") and
# SECTION_INFO are the same dict objects everywhere and follow that file (sync_sections). A section either gives results
# only (like Data analytics) or finds DEFECTS, each of which goes on to stage 1 and stage 2 (like Error roots).
BUILTIN_SECTIONS = [
    {"id": "analytics", "label": "Data analytics", "defects": False, "builtin": True,
     "about": "Counts and shares computed from the data, for example what share of the commands are Reads. The result is a table "
              "for you to read; nothing in it goes on to isolation."},
    {"id": "errors", "label": "Error roots", "defects": True, "builtin": True,
     "about": "Rules that find defects in the data. Every defect a rule finds can go on to stage 1 (isolating it: the reason, the "
              "evidence, the shortest sequence) and stage 2 (the test case)."},
]
SECTIONS = {}
SECTION_INFO = {}
_SECTIONS_SEEN = [None]
ANALYZER_LEVELS = ["nvme_command", "nvme_transaction", "link", "split", "packets"]      # the analyzer's five exports: the levels of the tree
# "other" (owner, 2026-11-12: "the input CSV should be agnostic to any of the fixed coding strategies"): a rule on a CSV
# file of the folder that is not one of the five exports. It names its file in its procedure and never reads the tree.
LEVELS = ANALYZER_LEVELS + ["other"]
LEVEL_LABEL = {"nvme_command": "NVMe commands", "nvme_transaction": "NVMe transactions", "link": "Link transactions",
               "split": "Split transactions", "packets": "Packets", "other": "Other CSV files"}
TABLE = L.TABLE
PREFIX_LEVEL = {"pkt": "packets", "lnk": "link", "spl": "split", "ntx": "nvme_transaction", "cmd": "nvme_command"}
OPS = {"eq": "=", "ne": "!=", "gt": ">", "ge": ">=", "lt": "<", "le": "<="}
KINDS = ("distribution", "read_pattern", "detection_rule", "condition")
RUN_TIMEOUT_S = 900


def rules_root():
    d = os.path.join(family1.knowledge_dir(), "rules")
    os.makedirs(d, exist_ok=True)
    return d


def sections_file():
    return os.path.join(rules_root(), "sections.json")


def sync_sections():
    """Reads sections.json again when it changed (or appeared, or went away) and refreshes SECTIONS / SECTION_INFO in place."""
    p = sections_file()
    stamp = (p, os.path.getmtime(p)) if os.path.exists(p) else (p, None)
    if stamp == _SECTIONS_SEEN[0] and SECTIONS:
        return
    extra = []
    if stamp[1] is not None:
        try:
            extra = _read_json(p, []) or []
        except (OSError, ValueError):
            extra = []
    builtin_ids = {b["id"] for b in BUILTIN_SECTIONS}
    every = [dict(b) for b in BUILTIN_SECTIONS] + [x for x in extra if isinstance(x, dict) and x.get("id") and x["id"] not in builtin_ids]
    SECTIONS.clear()
    SECTION_INFO.clear()
    for i, x in enumerate(every, 1):
        SECTIONS[x["id"]] = "Section %d · %s" % (i, x["label"])
        SECTION_INFO[x["id"]] = dict(x, number=i, title=SECTIONS[x["id"]])
    _SECTIONS_SEEN[0] = stamp


def sections():
    sync_sections()
    return [SECTION_INFO[k] for k in SECTIONS]


def goes_to_stages(section):
    """True for a section whose items find defects (each goes on to stage 1 and stage 2), like Error roots."""
    sync_sections()
    return bool((SECTION_INFO.get(section) or {}).get("defects"))


def add_section(label, about, defects, admin):
    """A new section, made by the admin: a name, what it is for, and whether its items find defects."""
    if not isinstance(label or "", str) or not isinstance(about or "", str):
        raise ValueError("the name and the description of a section must be text")
    label = " ".join((label or "").split())
    if not label:
        raise ValueError("give the section a name")
    if len(label) > 60:
        raise ValueError("keep the name under 60 characters")
    sync_sections()
    if any(x["label"].lower() == label.lower() for x in SECTION_INFO.values()):
        raise ValueError("a section named '%s' exists already" % label)
    sid = re.sub(r"[^a-z0-9]+", "_", label.lower()).strip("_")[:40] or "section"
    base, n = sid, 2
    while sid in SECTION_INFO:
        sid, n = "%s_%d" % (base, n), n + 1
    p = sections_file()
    extra = _read_json(p, [])
    extra.append({"id": sid, "label": label, "about": (about or "").strip(), "defects": bool(defects), "builtin": False,
                  "created_by": admin, "created": time.time()})
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(extra, fh, indent=1)
    OSF.replace(tmp, p)
    _SECTIONS_SEEN[0] = None
    sync_sections()
    return SECTION_INFO[sid]


def rule_path(section, level, rid):
    sync_sections()
    if section not in SECTIONS or level not in LEVELS or not re.match(r"^[A-Za-z0-9_.-]+$", rid or ""):
        raise ValueError("bad rule address")
    return os.path.join(rules_root(), section, level, rid + ".json")


def _read_json(p, default):
    """A file of the knowledge folder; a damaged one reads as absent (and says so in the server's log), so one bad file cannot take a page down."""
    if not os.path.exists(p):
        return default
    try:
        with open(p, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError) as e:
        print("cannot read %s: %s" % (p, e), flush=True)
        return default


def load_rule(section, level, rid):
    return _read_json(rule_path(section, level, rid), None)


def save_rule(r):
    p = rule_path(r["section"], r["level"], r["id"])
    os.makedirs(os.path.dirname(p), exist_ok=True)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(r, fh, indent=1)
    OSF.replace(tmp, p)


def typed_columns(level):
    """The typed columns of a level's table: (sql name, the file's column name)."""
    seen, out = set(), []
    for cname, sql, _fn in L.KEYS.get(level, []):
        if sql not in seen:
            seen.add(sql)
            out.append((sql, cname))
    return out


# ---------------------------------------------------------------------------------------------- seeds
# Error roots keeps only these detector rules (the owner, 2026-11-09: "keep only two things: NVMe timeout and NVMe failure, the top one").
KEPT_ERROR_RULES = ("cmd.timeout", "cmd.read_failure")
DEMO_ERROR_RULE = "cmd.timeout"
INSTALL_DELETED_BY = "at installation (the owner's choice of 2026-11-09)"


def seed():
    """The first items, written once (never over an existing file): two analytics items for NVMe commands and the
    detector's rules as Section 2 drafts. Every seed is a DRAFT until the admin approves it."""
    t = time.time()

    gone = {(x["section"], x["level"], x["id"]) for x in deleted_items()}

    def put(r):
        if (r["section"], r["level"], r["id"]) in gone:       # the admin deleted it: a seed does not come back by itself
            return
        if load_rule(r["section"], r["level"], r["id"]) is None:
            r.setdefault("status", "draft")
            r.setdefault("version", 0)
            r.setdefault("history", [])
            r.setdefault("created", t)
            r.setdefault("export", {"formats": ["csv", "html"]})
            save_rule(r)
    put({"id": "command_type_share", "section": "analytics", "level": "nvme_command", "name": "Command type percentages",
         "description": "What share of all NVMe commands each command type is.",
         "definition": "Every NVMe command of the recording is counted once. Its type is its opcode, named from the NVMe "
                       "specification's lists: admin commands are the ones on queue 0, I/O commands are on the other queues. "
                       "The result is one line per type: how many commands, and what percentage of all commands.",
         "kind": "distribution", "plan": {"table": "cmd", "label": {"expr": "opcode_name"}, "filter": [], "measure": "percent"},
         "family1": {"columns": ["OPC", "SQID"]}, "source": "the owner's statement of 2026-11-07, example 2"})
    put({"id": "read_pattern", "section": "analytics", "level": "nvme_command", "name": "Read vs RndRead vs sequential read",
         "description": "How many reads are sequential and how many are random (RndRead).",
         "definition": "A read is an NVMe Read command (opcode 0x02) on an I/O queue. Reads are taken in time order for each "
                       "namespace. A read is SEQUENTIAL when it starts at the block right after the block where the previous "
                       "read of the same namespace ended (start block = previous start + previous block count; the export's "
                       "NLB is 0-based, so the previous read covers NLB + 1 blocks). Any other read is RANDOM (RndRead). The "
                       "first read of each namespace has no previous read and is counted apart. TO CONFIRM WITH THE ADMIN: "
                       "whether reads on different queues count as one stream, and whether a small gap still counts as sequential.",
         "kind": "read_pattern", "plan": {"opcode": 2, "partition": ["nsid"], "gap_blocks": 0},
         "family1": {"columns": ["OPC", "SQID", "NSID", "SLBA", "NLB", "Time Stamp"]}, "source": "the owner's statement, example 1"})
    from . import procedures as PR
    for rid, proc in PR.SEEDS.items():
        r = load_rule("analytics", "nvme_command", rid)
        if r is None:
            continue
        cur = r.get("procedure")
        # never reworded once the Coder used it (its code, verified or waiting for review, belongs to this exact text)
        untouched = (cur and cur.get("edited_by") in (PR.SEED_MARK, "written from the owner's example and the real export's formats")
                     and not r.get("code") and not r.get("coded_from_sha"))
        if not cur or (untouched and PR.sha(cur) != PR.sha(proc)):
            # a seed nobody edited or coded takes the newest wording; an edited or coded procedure is never replaced
            r["procedure"] = dict(proc, version=1, edited_by=PR.SEED_MARK, edited_at=t)
            save_rule(r)
    names = {}
    try:
        sys.path.insert(0, os.path.join(APP, "app"))
        from api import hier_api as H
        names = getattr(H, "RULE_WORDS", {}) or {}
    except Exception:       # noqa: BLE001 - the words are only labels
        names = {}
    known = {(x["section"], x["level"], x["id"]) for x in _register()}
    retired = []
    for rule, (kind, text, ref) in RL.BASIS.items():
        lvl = PREFIX_LEVEL.get(rule.split(".")[0])
        if not lvl:
            continue
        item = {"id": rule.replace(".", "_"), "section": "errors", "level": lvl, "name": names.get(rule) or text[:80],
                "description": text, "definition": text + " (basis: %s; %s)" % (kind, ref),
                "kind": "detection_rule", "plan": {"rule": rule}, "demo": rule == DEMO_ERROR_RULE, "basis": {"kind": kind, "ref": ref},
                "source": "imported from the detector (nvme_hier/rules.py); approve, edit or drop"}
        if rule in KEPT_ERROR_RULES:
            put(item)
        elif ("errors", lvl, item["id"]) not in known and load_rule("errors", lvl, item["id"]) is None:
            retired.append(item)
    if retired:
        _seed_as_deleted(retired, t)


def _seed_as_deleted(items, t):
    """A new installation: the detector's rules the owner did not keep start in Deleted items; Restore brings any of them back."""
    reg = _register()
    for r in items:
        r.update(status="draft", version=0, history=[], created=t, export={"formats": ["csv", "html"]})
        d = os.path.join(rules_root(), "_deleted", r["section"], r["level"])
        os.makedirs(d, exist_ok=True)
        dest = os.path.join(d, "%s.at-installation.json" % r["id"])
        L.write_json_atomic(dest, r, indent=1)
        reg.append({"section": r["section"], "level": r["level"], "id": r["id"], "name": r["name"], "kind": r["kind"], "detector": True,
                    "by": INSTALL_DELETED_BY, "at": t, "why": "Error roots keeps only the NVMe command timeout and the read failure; restore this rule to use it", "file": dest})
    _write_register(reg)


# chosen by default in a plan (the owner's choice of 2026-11-09: the two NVMe command rules, with the two analytics examples)
DEFAULT_CHOSEN = {("analytics", "nvme_command", "command_type_share"), ("analytics", "nvme_command", "read_pattern"),
                  ("errors", "nvme_command", "cmd_timeout"), ("errors", "nvme_command", "cmd_read_failure")}


def tree():
    from . import procedures as PR
    seed()
    out = []
    sync_sections()
    for sec, label in SECTIONS.items():
        lv = []
        for level in LEVELS:
            d = os.path.join(rules_root(), sec, level)
            items = []
            if os.path.isdir(d):
                for fn in sorted(os.listdir(d)):
                    if fn.endswith(".json"):
                        r = _read_json(os.path.join(d, fn), None)
                        if not isinstance(r, dict):
                            continue
                        cs = PR.code_state(r)
                        items.append({"id": r["id"], "name": r["name"], "status": r.get("status"), "version": r.get("version", 0),
                                      "default": (sec, level, r["id"]) in DEFAULT_CHOSEN,
                                      "demo": r.get("demo", False), "kind": r.get("kind"), "code": cs["kind"] if cs["kind"] != "python" else (
                                          "verified" if cs["verified"] else "needs code"), "procedure_version": cs.get("procedure_version")})
            items.sort(key=lambda x: (not x["demo"], x["status"] != "approved", x["name"].lower()))
            lv.append({"level": level, "label": LEVEL_LABEL[level], "items": items})
        info = SECTION_INFO[sec]
        out.append({"section": sec, "label": label, "name": info["label"], "about": info.get("about", ""), "defects": bool(info.get("defects")),
                    "builtin": bool(info.get("builtin")), "number": info["number"], "levels": lv})
    return out


def add_item(section, level, name, description, admin):
    rid = re.sub(r"[^a-z0-9]+", "_", (name or "").lower()).strip("_")[:50] or "item"
    base, n = rid, 2
    gone = {x["id"] for x in deleted_items() if (x["section"], x["level"]) == (section, level)}   # a deleted item keeps its name for Restore
    while load_rule(section, level, rid) or rid in gone:
        rid, n = "%s_%d" % (base, n), n + 1
    r = {"id": rid, "section": section, "level": level, "name": name.strip(), "description": (description or "").strip(),
         "definition": "", "kind": None, "plan": None, "status": "draft", "version": 0, "history": [], "created": time.time(),
         "created_by": admin, "export": {"formats": ["csv", "html"]}, "source": "added by %s" % admin}
    save_rule(r)
    return r


# ---------------------------------------------------------------------------------------------- deleting an item
# Owner, 2026-11-09: "why only multiselect, there can be rules which can be deleted". An item the admin deletes leaves the
# list (it is not offered or run any more). Nothing is destroyed: its rule file moves to rules/_deleted/<section>/<level>/,
# the register rules/deleted.json says who deleted it, when and why, and Restore puts it back. Its code files and results
# stay where they are. A detector item only leaves this list: the detector itself (nvme_hier/rules.py) is not changed.
def deleted_file():
    return os.path.join(rules_root(), "deleted.json")


def _register():
    p = deleted_file()
    try:
        return json.load(open(p, encoding="utf-8")) if os.path.exists(p) else []
    except (OSError, ValueError):
        return []


def _write_register(reg):
    p = deleted_file()
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(reg, fh, indent=1)
    OSF.replace(tmp, p)


def deleted_items():
    """The items deleted and not restored, newest first."""
    return sorted([x for x in _register() if not x.get("restored_at")], key=lambda x: -x.get("at", 0))


def delete_item(section, level, rid, admin, why=""):
    r = load_rule(section, level, rid)
    if r is None:
        raise ValueError("no such item")
    d = os.path.join(rules_root(), "_deleted", section, level)
    os.makedirs(d, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    dest = os.path.join(d, "%s.%s.json" % (rid, stamp))
    n = 2
    while os.path.exists(dest):
        dest, n = os.path.join(d, "%s.%s-%d.json" % (rid, stamp, n)), n + 1
    OSF.replace(rule_path(section, level, rid), dest)
    entry = {"section": section, "level": level, "id": rid, "name": r.get("name"), "kind": r.get("kind"),
             "detector": r.get("kind") == "detection_rule", "by": admin, "at": time.time(), "why": (why or "").strip(),
             "file": dest}
    reg = _register()
    reg.append(entry)
    _write_register(reg)
    return entry


def restore_item(section, level, rid, admin):
    reg = _register()
    live = [x for x in reg if (x["section"], x["level"], x["id"]) == (section, level, rid) and not x.get("restored_at")]
    if not live:
        raise ValueError("this item is not in the deleted items")
    e = live[-1]
    if load_rule(section, level, rid) is not None:
        raise ValueError("an item with the same name is in the list again: delete or rename that one first")
    if not os.path.exists(e["file"]):
        raise ValueError("its saved file is missing: %s" % e["file"])
    saved = json.load(open(e["file"], encoding="utf-8"))
    rule = (saved.get("plan") or {}).get("rule")
    if saved.get("kind") == "detection_rule" and rule not in RL.BASIS:
        raise ValueError("the detector no longer has the rule %s: this item cannot come back" % rule)
    p = rule_path(section, level, rid)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    OSF.replace(e["file"], p)
    for x in live:
        x["restored_by"], x["restored_at"] = admin, time.time()
    _write_register(reg)
    return load_rule(section, level, rid)


# ---------------------------------------------------------------------------------------------- the translator
def _opcode_case():
    io = " ".join("WHEN %d THEN '%s'" % (k, v.replace("'", "''")) for k, v in sorted(N.IO_OPC.items()))
    ad = " ".join("WHEN %d THEN '%s (admin)'" % (k, v.replace("'", "''")) for k, v in sorted(N.ADMIN_OPC.items()))
    return ("CASE WHEN sqid = 0 THEN CASE opc %s ELSE printf('opcode 0x%%02X (admin)', opc) END "
            "ELSE CASE opc %s ELSE printf('opcode 0x%%02X', opc) END END" % (ad, io))


def _where(table, flt, cols, params):
    out = []
    for f in flt or []:
        c, op, v = f.get("column"), f.get("op"), f.get("value")
        if c not in cols:
            raise ValueError("the column '%s' is not a column of the %s table (%s)" % (c, table, ", ".join(sorted(cols))))
        if op in OPS:
            out.append("%s %s ?" % (c, OPS[op]))
            params.append(v)
        elif op == "in":
            vals = v if isinstance(v, list) else [x.strip() for x in str(v).split(",")]
            out.append("%s IN (%s)" % (c, ",".join("?" * len(vals))))
            params += vals
        elif op == "contains":
            out.append("%s LIKE ?" % c)
            params.append("%%%s%%" % v)
        elif op == "blank":
            out.append("%s IS NULL" % c)
        elif op == "notblank":
            out.append("%s IS NOT NULL" % c)
        else:
            raise ValueError("unknown condition '%s'" % op)
    return " AND ".join(out) or "1"


def compile_rule(r, cols=None):
    """-> (sql, params, population_sql, population_params). cols: the real columns of the table (checked)."""
    k, p = r.get("kind"), r.get("plan") or {}
    if k not in KINDS:
        raise ValueError("the rule has no plan yet (kind %r)" % k)
    if k == "distribution":
        t = p.get("table")
        if t not in TABLE.values():
            raise ValueError("unknown table %r" % t)
        cols = cols or {s for s, _ in typed_columns({v: k2 for k2, v in TABLE.items()}[t])}
        lab = p.get("label") or {}
        if lab.get("expr") == "opcode_name":
            if t != "cmd":
                raise ValueError("opcode names are for the command table")
            label = _opcode_case()
        elif lab.get("column") in cols:
            label = "COALESCE(CAST(%s AS TEXT), '(blank)')" % lab["column"]
        else:
            raise ValueError("the label column %r is not a column of %s" % (lab.get("column"), t))
        params = []
        where = _where(t, p.get("filter"), cols | {"opc", "sqid"}, params)
        base = "SELECT %s AS label FROM %s WHERE %s" % (label, t, where)
        sql = ("WITH base AS (%s)\nSELECT label, COUNT(*) AS count, ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM base), 3) AS percent\n"
               "FROM base GROUP BY label ORDER BY count DESC, label" % base)
        return sql, params, "SELECT COUNT(*) FROM %s WHERE %s" % (t, where), list(params)
    if k == "read_pattern":
        part = [c for c in (p.get("partition") or ["nsid"]) if c in ("nsid", "sqid")] or ["nsid"]
        gap = int(p.get("gap_blocks") or 0)
        labels = [p.get("first_label") or "first read of its namespace", p.get("seq_label") or "sequential read",
                  p.get("rnd_label") or "random read (RndRead)"]
        sql = ("WITH r AS (SELECT slba, nlb, LAG(slba) OVER w AS pslba, LAG(nlb) OVER w AS pnlb FROM cmd\n"
               "  WHERE opc = ? AND sqid != 0 AND slba IS NOT NULL AND nlb IS NOT NULL\n"
               "  WINDOW w AS (PARTITION BY %s ORDER BY t_ps, rowid_file)),\n"
               "l AS (SELECT CASE WHEN pslba IS NULL THEN ? WHEN slba BETWEEN pslba + pnlb + 1 AND pslba + pnlb + 1 + ? THEN ? ELSE ? END AS label FROM r)\n"
               "SELECT label, COUNT(*) AS count, ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM l), 3) AS percent FROM l GROUP BY label ORDER BY count DESC"
               % ", ".join(part))
        params = [int(p.get("opcode", 2)), labels[0], gap, labels[1], labels[2]]
        return sql, params, "SELECT COUNT(*) FROM cmd WHERE opc = ? AND sqid != 0 AND slba IS NOT NULL AND nlb IS NOT NULL", [int(p.get("opcode", 2))]
    if k == "detection_rule":
        rule = p.get("rule")
        if rule not in RL.BASIS:
            raise ValueError("unknown detector rule %r" % rule)
        # the column names are the procedure's output columns (procedures.DETECTOR_OUTPUT), in plain words
        sql = ("SELECT f.id AS \"defect\", f.level AS \"level\", f.rule AS \"rule\", f.name AS \"what was found\", f.severity AS \"severity\",\n"
               "  f.row_n AS \"number in its file\", f.t_ps AS \"time stamp (ps)\", f.cmd_rowid AS \"command's file row\", f.rowid AS \"data row in its file\"\n"
               "FROM finding f WHERE f.rule = ? ORDER BY f.id")
        return sql, [rule], "SELECT COUNT(*) FROM finding WHERE rule = ?", [rule]
    t = p.get("table")
    if t not in TABLE.values():
        raise ValueError("unknown table %r" % t)
    level = {v: k2 for k2, v in TABLE.items()}[t]
    cols = cols or {s for s, _ in typed_columns(level)}
    show = [c for c in (p.get("columns") or []) if c in cols] or ["n", "t_ps"]
    params = []
    where = _where(t, p.get("filter"), cols, params)
    sql = "SELECT rowid_file AS row, %s FROM %s WHERE %s ORDER BY rowid_file" % (", ".join(show), t, where)
    return sql, params, "SELECT COUNT(*) FROM %s WHERE %s" % (t, where), list(params)


def describe(r):
    """The plan in plain words, for the admin."""
    k, p = r.get("kind"), r.get("plan") or {}
    if k == "distribution":
        lab = p.get("label") or {}
        what = "the command type (opcode name)" if lab.get("expr") == "opcode_name" else "the column %s" % lab.get("column")
        f = "; only rows where " + ", ".join("%s %s %s" % (x["column"], x["op"], x.get("value", "")) for x in p["filter"]) if p.get("filter") else ""
        return "Count the rows of the %s table by %s%s, and give each value's share of all of them in percent." % (p.get("table"), what, f)
    if k == "read_pattern":
        return ("Take the Read commands (opcode 0x%02X) on I/O queues in time order per %s. A read is sequential when it starts "
                "within %d block(s) after the end of the previous read; otherwise random (RndRead). The first read of each stream "
                "is counted apart." % (int(p.get("opcode", 2)), " and ".join(p.get("partition") or ["nsid"]), int(p.get("gap_blocks") or 0) + 1))
    if k == "detection_rule":
        return "List every defect the detector's rule %s found in the data; each row opens stage 1 (isolation) and stage 2 (test case)." % p.get("rule")
    if k == "python":
        return "Runs the verified Python code of procedure version %s." % ((r.get("procedure") or {}).get("version"))
    if k == "condition":
        return "List the rows of the %s table where %s." % (p.get("table"), ", ".join("%s %s %s" % (x["column"], x["op"], x.get("value", "")) for x in p.get("filter") or []) or "(no condition)")
    return "No plan yet: describe the item in the chat."


# ---------------------------------------------------------------------------------------------- the runs
def steps(params, project):
    kind = params.get("_kind")
    if kind == "rule_draft":
        return [{"key": "write", "title": "Rule writer: the procedure from the admin's words", "family": "3", "agent": "Rule writer", "review": True}]
    if kind == "rule_code":         # Code it: the Coder writes the code of the procedure, the admin reviews it
        return [{"key": "code", "title": "Coder: the Python code of the procedure, for your review", "family": "3", "agent": "Coder", "review": True}]
    if kind == "rule_exec":         # Run: the verified code on the recording, checked and exported (no review)
        return [{"key": "code", "title": "The verified code of the procedure", "family": "3", "agent": "Coder"},
                {"key": "run", "title": "Run on the recording", "family": "3", "agent": "Runner"},
                {"key": "test", "title": "Tester: check the result", "family": "3", "agent": "Tester"},
                {"key": "export", "title": "Export the result (CSV)", "family": "3", "agent": "Runner"}]
    out = [{"key": "code", "title": "Coder: the code of the procedure (verified, or written for your review)", "family": "3", "agent": "Coder", "review": True},
           {"key": "run", "title": "Run on the project's data", "family": "3", "agent": "Runner"},
           {"key": "test", "title": "Tester: check the result independently", "family": "3", "agent": "Tester"},
           {"key": "export", "title": "Export the result", "family": "3", "agent": "Runner"},
           {"key": "result", "title": "The result, for review", "family": "3", "agent": "Manager", "review": True}]
    return out


def run_step(ctx):
    return globals()["_" + ctx.step["key"]](ctx)


def _rule(ctx):
    p = ctx.params
    r = load_rule(p["section"], p["level"], p["id"])
    if r is None:
        raise RuntimeError("no such item")
    return r


WRITER_INSTRUCTION = """You are the Rule writer of Family 3. Turn the admin's words into a PROCEDURE for one item: the exact steps a
program will follow, written so that the admin can check every step and the Coder can code it without guessing.
THE FIVE FILES ARE ALREADY JOINED: Family 2 built them into one tree with the joining rules the admin approved (THE_TREE says how, and how many
rows the joins could not place). Whenever the item looks at more than one level (a command and its transactions, links or packets), the source
is "the tree": {"file": "the tree", "columns": ["<level>: <exact column>", ...]} and the steps walk the tree (a command's NVMe transactions,
a link transaction's packets, the command a packet belongs to). Never join two levels again by Tag, Address, CID, RequesterID or time stamp, and
never guess a parent for a row the joins left without one: say what happens to such rows. Column meanings come from Family 1 (FILES). An item
on one file only may name that file instead. Use only the levels, files and columns in FILES. In the steps,
say for each column how its cell is read (the real formats are in FILES: for example "0x02 (Read)" -> the text before the first
space read as hexadecimal; whether letter case is changed), which hash map is kept (its key and its value), every formula
(for example percent = count / total x 100), and what is output (the columns and their order). Keep everything the admin did
not ask to change. Put what you still need the admin to decide in "open_questions". Answer every admin message in "answers"."""
WRITER_SHAPE = """{"procedure": {"source_data": [{"file": "the tree", "columns": ["<level>: <exact column name>", "..."]}  or  {"file": "<one of the five files>", "columns": ["..."]}],
               "steps": ["<step 1>", "<step 2>", "..."],
               "output": {"columns": ["<output column>", "..."], "order": "<how the lines are sorted>"},
               "open_questions": ["..."]},
 "answers": ["..."]}"""


def _write(ctx):
    """The Rule writer: the procedure of an item from the admin's words (or a change to it) -> REVIEW."""
    from . import procedures as PR
    r = _rule(ctx)
    msgs = [m for m in [ctx.params.get("message")] + (ctx.input.get("comments") or []) if m]
    level = r["level"]
    _db0, up, paths = recording(ctx)
    tree_free = PR.TREE not in paths            # no tree for this analysis: the procedure is written on the files as they are
    files = []
    for lv in ANALYZER_LEVELS:
        fname = PR.FILE_NAME[lv]
        if tree_free and fname not in paths:
            continue                    # an analysis without a tree: only the files that are in its folder
        cols = [c for _s, c in typed_columns(lv)]
        info = PR.columns_info(paths[fname], cols, rows=5000) if fname in paths else {}
        meanings = __import__("agentic.rule_evidence", fromlist=["_meanings"])._meanings(lv)
        files.append({"file": fname, "level": LEVEL_LABEL[lv], "columns": [{"name": c, "real_values_seen": (info.get(c) or {}).get("samples", [])[:6],
                                                                             "meaning": (meanings.get(c) or ("",))[0][:160]} for c in cols]})
    files += other_files(ctx.project.get("folder"), paths)
    current = PR.procedure_of(r)

    def standin():
        out = {"procedure": current, "answers": []}
        for m in msgs:
            low = m.lower()
            hit = next((c for sq, c in typed_columns(level) if re.search(r"\b(by|per)\s+%s\b" % re.escape(c.lower()), low)
                        or re.search(r"\b(by|per)\s+%s\b" % re.escape(sq), low)), None)
            fname = PR.FILE_NAME.get(level)
            if not hit:                 # a file that is not an analyzer export: its columns are the ones Family 1's dictionary lists
                for f in files:
                    c = next((c["name"] for c in f["columns"] if re.search(r"\b(by|per)\s+%s\b" % re.escape(c["name"].lower()), low)), None)
                    if c and (fname is None or f["file"] == fname):
                        hit, fname = c, f["file"]
                        break
            if any(w in low for w in ("percent", "share", "distribution", "how many")) and hit:
                fname = fname or next((f["file"] for f in files), "the file")
                out["procedure"] = {"source_data": [{"file": fname, "columns": [hit]}],
                                    "steps": ["Read %s with Python's csv reader, one row at a time (columns found by their exact header text, first match)." % fname,
                                              "%s: take the cell as it is, spaces at both ends removed; letter case is not changed; an empty cell counts as \"(blank)\"." % hit,
                                              "Count in a hash map (a Python dict): key = the %s value, value = the number of rows." % hit,
                                              "Total = the sum of all the counts; percent = count / total x 100, rounded to 3 decimals.",
                                              "Output one line per value: value, count, percent, largest count first."],
                                    "output": {"columns": [hit, "count", "percent"], "order": "count, largest first"}, "open_questions": []}
                out["answers"].append("A share of each %s value in %s." % (hit, fname))
            else:
                out["answers"].append("The stand-in (no model) keeps the procedure as it is; your words: %s" % m)
        if not out["procedure"]:
            out["procedure"] = {"source_data": [{"file": PR.FILE_NAME.get(level) or next((f["file"] for f in files), "the file.csv"), "columns": []}], "steps": ["(to be written: which column, how, what to count)"],
                                "output": {"columns": ["(to be named)"], "order": ""},
                                "open_questions": ["Which column, and what should be counted or found? (the stand-in understands 'percentage by <column>'; a model understands more)"]}
        return out
    ans, producer, _ = ctx.engine.runner.ask(ctx.run["id"], "rule_writer_" + r["id"], WRITER_INSTRUCTION,
                                             {"item": {"name": r.get("name"), "admin_words": r.get("description"), "current_procedure": current},
                                              "admin_messages": msgs, "FILES": files,
                                              "THE_TREE": PR.tree_facts(paths[PR.TREE]) if PR.TREE in paths else NO_TREE_WORDS if no_tree_chosen(ctx) else "no tree is built for this recording yet: the procedure may still be written on the tree; it is coded and run once the tree exists"},
                                             WRITER_SHAPE, "procedure", standin)
    proc, problem = ans.get("procedure"), ""
    if isinstance(proc, dict) and "answers" in proc:        # a model sometimes puts its answers inside the procedure (seen 2026-11-10): they belong beside it
        moved = proc.pop("answers")
        ans["answers"] = (ans.get("answers") if isinstance(ans.get("answers"), list) else []) + (moved if isinstance(moved, list) else [moved])
    try:
        proc = PR.validate(proc)
        if ans.get("procedure", {}).get("open_questions"):
            proc["open_questions"] = list(ans["procedure"]["open_questions"])
    except ValueError as e:
        problem = str(e)
    admin = ctx.project.get("admin") or "admin"
    body = ["**Admin %s, need review.** The procedure of **%s** (%s, %s), written by the Rule writer." % (admin, r["name"], SECTIONS[r["section"]], LEVEL_LABEL[level]), ""]
    if isinstance(proc, dict) and not problem:
        body += ["**Source data:** " + "; ".join("%s (%s)" % (paths.get(s["file"]) or s["file"], ", ".join(s["columns"])) for s in proc["source_data"]), "",
                 "**Rules or procedure:**"] + ["%d. %s" % (i, s) for i, s in enumerate(proc["steps"], 1)] + [
                 "", "**Output:** %s%s" % (", ".join(proc["output"]["columns"]), " · " + proc["output"]["order"] if proc["output"].get("order") else "")]
        if proc.get("open_questions"):
            body += ["", "**Still to decide:**"] + ["- " + q for q in proc["open_questions"]]
    else:
        body += ["**The procedure is not complete:** " + problem]
    if ans.get("answers"):
        body += ["", "**Answers to you:**"] + ["- " + a for a in ans["answers"]]
    body += ["", "Approve to store it as the procedure; then **Code it** writes the Python code from it, for your review."]
    return core.Result({"procedure": proc if not problem else None, "problem": problem}, producer=producer,
                       review={"title": "Procedure: %s" % r["name"], "body": "\n".join(body), "data": {"procedure": proc, "problem": problem}})


def procedures_of(r):
    """The item's procedure (stored, or the detector's), None when it has none yet."""
    from . import procedures as PR
    return PR.procedure_of(r)


def on_approve(engine, run, step, data, admin):
    from . import procedures as PR
    params = core.jload(run["params"], {})
    out = core.jload(step["output"], {})
    if step["key"] == "write":
        if out.get("problem") or not out.get("procedure"):
            raise ValueError("the procedure cannot be approved while it is not complete: %s" % (out.get("problem") or "no procedure"))
        r = load_rule(params["section"], params["level"], params["id"])
        r, _changed = PR.store(r, out["procedure"], admin, note="written by the Rule writer, approved by %s" % admin)
        save_rule(r)
    elif step["key"] == "code" and out.get("code_file"):
        if out.get("problems"):
            raise ValueError("this code cannot become the verified code: %s. Ask for a change." % "; ".join(out["problems"]))
        r = load_rule(params["section"], params["level"], params["id"])
        proc = PR.procedure_of(r)
        if out.get("new_procedure"):
            if not proc or PR.sha(proc) != out.get("base_sha"):
                raise ValueError("the procedure changed while the code was made: press Code it again")
            r, _ch = PR.store(r, out["new_procedure"], admin, note="changed by the Coder as %s asked: %s" % (admin, "; ".join(out.get("changes") or [])))
            proc = PR.procedure_of(r)
        if not proc or PR.sha(proc) != out.get("procedure_sha"):
            raise ValueError("the procedure changed while the code was made: press Code it again")
        if r.get("code"):
            r.setdefault("history", []).append({"code": r["code"]})
        r["code"] = {"path": out["code_file"], "procedure_sha": out["procedure_sha"], "procedure_version": out.get("procedure_version"),
                     "by": out.get("by"), "verified_by": admin, "verified_at": time.time()}
        save_rule(r)


def _code(ctx):
    """The verified code of the item's procedure, or the Coder writes it (Python), the program checks it and runs it once on
    the recording, and the admin reviews it. A Run (rule_exec) only takes verified code."""
    from . import procedures as PR
    r = _rule(ctx)
    st = PR.code_state(r)
    if st["kind"] == "detector":
        return core.Result({"kind": "detector", "verified": True, "rule": st["rule"], "path": st["path"], "lines": st["lines"]})
    if st["kind"] == "none":
        raise RuntimeError("'%s' has no procedure yet: write it (Edit rule/procedure) first" % r["name"])
    if st["verified"]:
        return core.Result({"kind": "python", "verified": True, "code_file": st["path"], "procedure_version": st.get("procedure_version"),
                            "verified_by": st.get("verified_by")})
    if ctx.params.get("_kind") == "rule_exec":
        raise RuntimeError("'%s' has no verified code for procedure version %s: press Code it and approve the code first" % (r["name"], st.get("procedure_version")))
    proc = PR.procedure_of(r)
    _db, up, paths = recording(ctx)                  # a procedure on files needs no tree; one on "the tree" needs it built
    if PR.uses_tree(proc) and not _db:
        raise RuntimeError(NEEDS_TREE % r["name"])
    missing = [s["file"] for s in proc["source_data"] if s["file"] not in paths]
    if missing:
        raise RuntimeError("the recording has no %s: the code cannot be tried" % ", ".join(missing))
    ctx.progress("the Coder writes the Python code of procedure version %s (high effort)" % proc.get("version", 0))
    r["coded_from_sha"] = PR.sha(proc)               # this text is now the one the code belongs to: a seed is not reworded
    save_rule(r)
    comments = [c for c in ctx.input.get("comments") or [] if c]
    on_tree = PR.uses_tree(proc)
    context = PR.coder_context_tree(r, proc, up) if on_tree else PR.coder_context(r, proc, up, paths=paths)
    if comments:
        context["ADMIN_ASKS"] = comments
        prev = (ctx.step.get("output") and core.jload(ctx.step["output"], {})) or {}
        if prev.get("code_file") and os.path.exists(prev["code_file"]):
            context["YOUR_LAST_CODE"] = open(prev["code_file"], encoding="utf-8").read()

    def standin():
        code = PR.STANDIN_CODE.get(r["id"]) or PR.standin_share_code(proc)
        if not code:
            return {"code": "", "how": [], "questions": ["no model is connected: only the two seeded procedures have stand-in code"]}
        return {"code": code, "how": ["the stand-in's hand-written code of this procedure"], "questions": []}
    ans, producer, box = ctx.engine.runner.ask(ctx.run["id"], "coder_" + r["id"], PR.CODER_INSTRUCTION_TREE if on_tree else PR.CODER_INSTRUCTION, context, PR.CODER_SHAPE, "code", standin,
                                               effort="high")
    code = ans.get("code") or ""
    base_proc, new_proc, proc_problem = proc, None, ""
    if comments and isinstance(ans.get("procedure"), dict):
        # the admin's comment asked for something the procedure says differently: the Coder changed the procedure too
        try:
            cand = PR.validate({k: ans["procedure"].get(k) for k in ("source_data", "steps", "output", "open_questions") if k in ans["procedure"]})
            if PR.sha(cand) != PR.sha(proc):
                new_proc = cand
        except ValueError as e:
            proc_problem = "the changed procedure is not complete: %s" % e
    if new_proc:
        proc = new_proc
    v = int(base_proc.get("version") or 0) + (1 if new_proc else 0)
    d = os.path.join(family1.knowledge_dir(), "rules_code", r["section"], r["level"])
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, "%s.p%d.run%d.py" % (r["id"], v, ctx.run["id"]))
    L.write_text_atomic(path, code)
    problems = PR.check_code(code, tree=PR.uses_tree(new_proc or base_proc)) if code.strip() else ["the Coder gave no code"]
    if proc_problem:
        problems.append(proc_problem)
    # the code is checked, not run (owner, 2026-11-09: "to code just code, do not run": a recording is 6 GB): Try on a sample
    # (the first records only) is the admin's choice in the review, and Run reads the whole recording with its progress shown
    checks = [{"check": "it compiles, imports only the standard library (and the NVMe names list), and defines run(sources, out_csv)",
               "ok": not problems, "detail": "; ".join(problems[:3]) or "yes"},
              {"check": "it writes the procedure's output columns", "ok": all(c in code for c in proc["output"]["columns"]),
               "detail": ", ".join(proc["output"]["columns"])}]
    admin = ctx.project.get("admin") or "admin"
    body = ["**Admin %s, need review.** The Coder wrote the Python code of **%s**, from procedure version %d%s. It is checked, not run: "
            "**Try on a sample** runs it on the first %s records only; **Run** (after you approve) reads the whole recording, with its "
            "progress shown." % (admin, r["name"], v, " (changed as you asked: approving stores it as the new version)" if new_proc else "",
                                 "{:,}".format(PR.TRY_RECORDS)), ""]
    if ans.get("answers"):
        body += ["**Answers to you:**"] + ["- " + a for a in ans["answers"]] + [""]
    if new_proc:
        body += ["**The procedure changes as you asked:**"] + ["- " + c for c in (ans.get("changes") or ["see the steps below"])] + [""]
        old_steps = set(base_proc["steps"])
        body += ["**Rules or procedure (version %d, new):**" % v] + [
            "%d. %s%s" % (i, s, "  ← changed" if s not in old_steps else "") for i, s in enumerate(proc["steps"], 1)]
        body += ["", "**Output:** %s" % ", ".join(proc["output"]["columns"])]
    else:
        body += ["**Rules or procedure (version %d):**" % v] + ["%d. %s" % (i, s) for i, s in enumerate(proc["steps"], 1)]
    body += ["", "**Checks made by the program:**"] + ["- %s %s: %s" % ("✔" if c["ok"] else "✘", c["check"], c["detail"]) for c in checks]
    if problems:
        body += ["", "**Problems:** " + "; ".join(problems)]
    if ans.get("questions"):
        body += ["", "**The Coder asks:**"] + ["- " + q for q in ans["questions"]]
    body += ["", "**The code** (%s):" % os.path.relpath(path, APP), "", "```python", code.rstrip(), "```", "",
             "Approve: this becomes the **verified code** of procedure version %d, and Run uses it. Ask for a change: say what is wrong; "
             "the Coder writes it again." % v]
    return core.Result({"kind": "python", "verified": False, "code_file": path, "procedure_sha": PR.sha(proc), "procedure_version": v, "by": producer,
                        "problems": problems, "checks": checks, "base_sha": PR.sha(base_proc), "new_procedure": new_proc,
                        "changes": ans.get("changes") if new_proc else None, "answers": ans.get("answers")},
                       producer=producer, review={"title": "Code: %s" % r["name"], "body": "\n".join(body),
                                                  "data": {"code_file": path, "checks": checks, "problems": problems, "try": not problems,
                                                           "item": "%s/%s/%s" % (r["section"], r["level"], r["id"])}})


NO_TREE_WORDS = ("NO TREE: the admin went on without stage 2, so the files are NOT joined. Write the procedure on the files of FILES as they "
                 "are, each named by its own file name; never use \"the tree\". If the item cannot be done without joining two files, say so in open_questions.")


def no_tree_chosen(ctx):
    """Did the admin of this flow go on without stage 2 (the step after Family 1)? Always False outside a flow."""
    try:        # read from the run itself: an item's context (pipeline.ItemCtx) answers output_of() for the item's own steps only
        s = ctx.engine.store.one("SELECT output FROM step WHERE run=? AND key='f1_gate'", (ctx.run["id"],))
        return (core.jload((s or {}).get("output"), {}) or {}).get("stage2") == "skipped"
    except Exception:           # noqa: BLE001 - a context without a run (a test's stand-in): no flow, so no such choice
        return False


def recording(ctx):
    """What an item of this run works on -> (the tree's database or None, the upload id or None, {file name: path}).
    With a tree (stage 2 was built, or an upload is linked): the upload's files and "the tree". Without one (the admin went
    on without stage 2, or the folder's files are not analyzer exports): the CSV files of the analysis's folder as they
    are. A procedure on files needs no tree; only a procedure that reads "the tree", and the detector's items, do."""
    from . import procedures as PR
    up = None if no_tree_chosen(ctx) else (ctx.params.get("upload_id") or ctx.project.get("upload_id"))
    paths = PR.recording_paths(up, ctx.project.get("folder"))
    db = paths.get(PR.TREE)
    return db, (up if up and PR.source_paths(up) else None), paths


def other_files(folder, paths):
    """The CSV files of the folder that are not one of the five analyzer exports, as the Rule writer and the Coder are
    told of them: the columns that hold a value, with the meaning Family 1's approved dictionary gives (none when the
    file has no approved dictionary yet) and real values read from the file."""
    from . import procedures as PR
    out = []
    for f in family1.inventory(folder) if folder else []:
        if f.get("level") or f["name"] not in paths:
            continue
        d = family1.approved_dictionary(f["format_key"], f["name"]) or {}
        cols = [c for c in d.get("columns") or [] if isinstance(c, dict) and c.get("column")]
        names = [str(c["column"]) for c in cols][:400]
        info = PR.columns_info(f["path"], names, rows=5000) if names else {}
        out.append({"file": f["name"], "level": "not one of the analyzer's five exports" + ("" if d else "; no data dictionary approved yet: its columns are not known"),
                    "columns": [{"name": str(c["column"]), "real_values_seen": (info.get(str(c["column"])) or {}).get("samples", [])[:6],
                                 "meaning": str(c.get("meaning") or c.get("observed") or "")[:160]} for c in cols[:400]]})
    return out


def needs_tree(r):
    """Does this item read the tree (so it needs stage 2)? The detector's items do (their code walks the tree's
    database), and so does a procedure whose source is "the tree". A procedure on files does not; an item without a
    procedure yet does not either: the Rule writer writes it for what the analysis has."""
    from . import procedures as PR
    if PR.code_state(r)["kind"] == "detector":
        return True
    return PR.uses_tree(PR.procedure_of(r))


def _upload_db(ctx):
    from api import hier_api as H
    up = ctx.params.get("upload_id") or ctx.project.get("upload_id")
    d = H.upload_dir(ctx.engine.services, up) if up else None
    if not d or not os.path.exists(os.path.join(d, "hier.sqlite")):
        raise RuntimeError("the project has no built data: run Family 2 (or link a loaded upload on the start page)")
    return os.path.join(d, "hier.sqlite"), up


def _ro(db):
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    t0 = time.time()
    con.set_progress_handler(lambda: 1 if time.time() - t0 > RUN_TIMEOUT_S else 0, 100000)
    return con


HEAD_ROWS = 200                  # result lines kept for the screen; the whole result stays in its CSV file (streamed)
NEEDS_TREE = ("'%s' reads the tree, and this analysis has none: stage 2 was not built. Open the analysis again at stage 2 and build the "
              "tree, or change the rule so that it reads one file only")


def _run(ctx):
    """Runs the item on the recording: the detector's findings for a detector item, else the VERIFIED Python code of its
    procedure on the recording's files. Streamed: the result is written to a CSV file line by line; only its first lines
    are kept in memory (recordings are several GB)."""
    from . import procedures as PR
    code = ctx.output_of("code")
    db, up, paths = recording(ctx)
    r = _rule(ctx)
    box = ctx.engine.runner.sandbox(ctx.run["id"], "runner_%s_%s" % (ctx.params.get("section"), ctx.params.get("id")))
    out_csv = os.path.join(box, "output.csv")
    if code.get("kind") == "detector":
        if not db:
            raise RuntimeError(NEEDS_TREE % r["name"])
        sql, params, psql, pparams = compile_rule({"kind": "detection_rule", "plan": {"rule": code["rule"]}})
        con = _ro(db)
        t0 = time.time()
        try:
            total = con.execute(psql, pparams).fetchone()[0] or 0
            cur = con.execute(sql, params)
            cols = [d[0] for d in cur.description]
            n, head = 0, []
            with open(out_csv, "w", newline="", encoding="utf-8") as fh:
                w = L.CsvOut(fh)
                w.writerow(cols)
                for batch in iter(lambda: cur.fetchmany(5000), []):
                    for row in batch:
                        if len(head) < HEAD_ROWS:
                            head.append(list(row))
                        w.writerow(row)
                    n += len(batch)
                    if total:
                        ctx.progress(core.progress_text(100.0 * n / total, t0, what="%s of %s defects listed" % ("{:,}".format(n), "{:,}".format(total))))
        finally:
            con.close()
        return core.Result({"upload_id": up, "columns": cols, "rows": n, "output_csv": out_csv, "head": head, "kind": "detector"})
    st = PR.code_state(r)
    if not st["verified"]:
        raise RuntimeError("'%s' has no verified code for its procedure: Code it, and approve the code" % r["name"])
    proc = PR.procedure_of(r)
    files = [s["file"] for s in proc["source_data"]]
    if PR.TREE in files and not db:
        raise RuntimeError(NEEDS_TREE % r["name"])
    if any(f not in paths for f in files):
        raise RuntimeError("the recording has no %s" % ", ".join(f for f in files if f not in paths))
    ctx.progress("running the verified code of procedure version %s on the recording" % proc.get("version"))
    res = PR.run_code(st["path"], {f: paths[f] for f in files}, out_csv, os.path.join(box, "run"),
                      progress=lambda i: ctx.progress("running the verified code · %s" % i["text"]))
    if not res.get("ok"):
        raise RuntimeError("the verified code failed on this recording: %s" % res.get("error"))
    cols, head, n = PR.read_output(out_csv, head=HEAD_ROWS)
    return core.Result({"upload_id": up, "columns": cols, "rows": n, "output_csv": out_csv, "head": head, "kind": "python",
                        "summary": res.get("summary"), "seconds": res.get("seconds"), "procedure_version": proc.get("version"),
                        "code_file": st["path"]})


def _output_rows(res):
    """The result's lines, read from its CSV file one at a time (typed values for a detector's numbers)."""
    with open(res["output_csv"], newline="", encoding="utf-8") as fh:
        rd = csv.reader(fh)
        next(rd, None)
        for row in rd:
            yield row


def _test(ctx):
    """The Tester: the result checked by the program, apart from the code that made it (the result file is streamed)."""
    from . import procedures as PR
    r = _rule(ctx)
    code, res = ctx.output_of("code"), ctx.output_of("run")
    db, up, _paths = recording(ctx)
    cols, n = res.get("columns") or [], res.get("rows") or 0
    checks = []
    if code.get("kind") == "detector" and not db:
        raise RuntimeError(NEEDS_TREE % r["name"])
    if code.get("kind") == "detector":
        _sql, _p, psql, pparams = compile_rule({"kind": "detection_rule", "plan": {"rule": code["rule"]}})
        con = _ro(db)
        try:
            population = con.execute(psql, pparams).fetchone()[0]
            checks.append({"check": "every defect the detector filed is listed", "ok": n == population, "detail": "%d of %d" % (n, population)})
            missing, k = 0, 0
            for x in _output_rows(res):
                k += 1
                if k > 5000:
                    break
                lvl, rowid = x[1], int(x[5]) if x[5] not in ("", None) else None
                t = TABLE.get(lvl)
                if t and rowid is not None and con.execute("SELECT 1 FROM %s WHERE n=? OR rowid_file=? LIMIT 1" % t, (rowid, rowid)).fetchone() is None:
                    missing += 1
            checks.append({"check": "every listed defect points to a row that exists", "ok": missing == 0, "detail": "%d missing (of the first %d)" % (missing, min(k, 5000))})
            if code["rule"] == "cmd.incomplete" and n:
                with_cqe = con.execute("SELECT COUNT(*) FROM finding f WHERE f.rule='cmd.incomplete' AND EXISTS (SELECT 1 FROM ntx n WHERE n.parent_level='nvme_command' "
                                       "AND n.parent=f.cmd_rowid AND n.type LIKE '%Completion Queue Entry%')").fetchone()[0]
                checks.append({"check": "none of these commands has a completion entry in the tree (the definition holds in the data)", "ok": with_cqe == 0,
                               "detail": "%d with a completion entry" % with_cqe})
        finally:
            con.close()
    else:
        proc = PR.procedure_of(r)
        checks += PR.output_checks_file(proc, res["output_csv"], res.get("summary"))
        if n <= 100000 and up and db:      # the independent count reads the tree's database: only when there is one
            x = PR.cross_check(r, up, cols, _output_rows(res))
            if x:
                checks.append(x)
        used = [c for s in proc["source_data"] for c in s["columns"]]
        groups = []
        for s in proc["source_data"]:
            if s["file"] == PR.TREE:                         # columns of the tree are named with their level: check each against its own file's dictionary
                by_lv = {}
                for c in s["columns"]:
                    lv0, col0 = PR.tree_column(c)
                    by_lv.setdefault(lv0, []).append(col0)
                groups += [{"file": PR.FILE_NAME.get(lv0, str(lv0)), "columns": cs} for lv0, cs in by_lv.items()]
            else:
                groups.append(s)
        for s in groups:
            lv = PR.LEVEL_OF_FILE.get(s["file"])
            dicts = family1.dictionaries_for_level(lv) if lv else []
            if not lv:                      # a CSV that is not one of the five exports: its own approved dictionary
                inv = next((f for f in family1.inventory(ctx.project.get("folder")) if f["name"] == s["file"]), None)
                own = family1.approved_dictionary(inv["format_key"], inv["name"]) if inv else None
                dicts = [own] if own else []
            if dicts:
                known = {x["column"]: x for x in dicts[0]["columns"]}
                for c in s["columns"]:
                    m = known.get(c)
                    checks.append({"check": "Family 1 knows the column %s of %s" % (c, s["file"]), "ok": bool(m and m.get("meaning")),
                                   "detail": (m or {}).get("meaning", "not in the approved dictionary")[:200]})
            else:
                checks.append({"check": "Family 1's dictionary of %s" % s["file"], "ok": True,
                               "detail": "not approved yet: the columns' meanings are not checked (%s)" % ", ".join(used)})
    return core.Result({"checks": checks, "passed": all(c["ok"] for c in checks), "columns": cols})


def _export(ctx):
    """The result as CSV (the whole result file, copied as it is) and HTML (its first 20,000 lines), streamed."""
    import shutil
    r = _rule(ctx)
    res = ctx.output_of("run")
    test = ctx.output_of("test")
    d = os.path.join(family1.knowledge_dir(), "exports", r["section"], r["level"], r["id"])
    os.makedirs(d, exist_ok=True)
    stem = "%s_v%d_run%d" % (r["id"], r["version"], ctx.run["id"])
    files = {}
    cols = res.get("columns") or []
    if "csv" in (r.get("export") or {}).get("formats", ["csv"]):
        p = os.path.join(d, stem + ".csv")
        shutil.copyfile(res["output_csv"], p)
        files["csv"] = p
    if "html" in (r.get("export") or {}).get("formats", ["html"]):
        p = os.path.join(d, stem + ".html")
        links = goes_to_stages(r["section"])
        plain = plain_defects(cols, [], r["name"])
        with open(p, "w", encoding="utf-8") as fh:
            fh.write("<!doctype html><meta charset=utf-8><title>%s</title><style>body{font-family:system-ui,sans-serif;margin:24px}"
                     "table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:3px 8px;font-size:13px}th{background:#f2f2f2}</style>"
                     "<h1>%s</h1><p>%s · %s · rule version %d (approved by %s) · upload %s · %s</p><p><b>Definition:</b> %s</p><p><b>Checks:</b> %s</p>"
                     "<table><tr>%s%s</tr>" % (
                         html.escape(r["name"]), html.escape(r["name"]), SECTIONS[r["section"]], LEVEL_LABEL[r["level"]], r["version"],
                         html.escape(r.get("approved_by") or "?"), html.escape(str(res.get("upload_id") or "none: the files of the folder, without a tree")), time.strftime("%Y-%m-%d %H:%M"),
                         html.escape(r.get("definition") or ""),
                         "; ".join(html.escape("%s: %s (%s)" % (c["check"], "ok" if c["ok"] else "NOT OK", c["detail"])) for c in test.get("checks") or []),
                         "".join("<th>%s</th>" % html.escape(c) for c in (plain["columns"] if plain else cols)), "<th>open</th>" if links else ""))
            if plain:
                fh.write("<tr><td colspan=%d><b>How to read the table.</b> %s</td></tr>" % (len(plain["columns"]) + (1 if links else 0),
                                                                                           " ".join(html.escape(re.sub(r"\*", "", x)) for x in plain["legend"])))
            for k, x in enumerate(_output_rows(res)):
                if k >= 20000:
                    fh.write("<tr><td colspan=%d>… %s more lines in the CSV</td></tr>" % (len(cols) + (1 if links else 0), "{:,}".format((res.get("rows") or 0) - 20000)))
                    break
                shown = plain_defects(cols, [x])["rows"][0] if plain else x
                cells = "".join("<td>%s</td>" % html.escape("" if v is None else str(v)) for v in shown)
                if links:
                    cells += '<td><a href="/isolate?upload=%s&finding=%s">stage 1 and 2</a></td>' % (html.escape(str(res["upload_id"])), html.escape(str(x[0])))
                fh.write("<tr>%s</tr>" % cells)
            fh.write("</table>")
        files["html"] = p
    return core.Result({"files": files})


# the detector's result columns (the SQL of compile_rule, detection_rule); procedures.DETECTOR_OUTPUT repeats them for the procedure's
# description and a test keeps the two equal (importing procedures here would be circular: procedures -> rule_evidence -> family3)
PR_DETECTOR_OUTPUT = ("defect", "level", "rule", "what was found", "severity", "number in its file", "time stamp (ps)", "command's file row", "data row in its file")


# ---------------------------------------------------------------------------------------------- a list of defects, as people read it
# (owner, 2026-11-10: "nobody is going to understand what is the meaning of that particular defect column ... either you tell what it is
# properly, otherwise you don't tell"). The stored result keeps its columns (other steps read them by position); every screen and the HTML
# export show this view instead: what was found first, where in the files, when, how serious, and a legend that says what each column is.
LEVEL_FILE = {"nvme_command": "nvme_command.csv", "nvme_transaction": "NVME_Transactions.csv", "split": "split.csv", "link": "link.csv", "packets": "packets.csv"}
LEVEL_NUMBER = {"nvme_command": "NVMe Cmd", "nvme_transaction": "NVMe Trans", "split": "Split Trans", "link": "Link Tra", "packets": "Packet"}
SEVERITY_WORDS = {"error": "error", "warning": "warning", "check": "to check"}
PLAIN_COLUMNS = ["What was found", "Where in the files", "When", "How serious"]      # the checker's own number is not shown (owner, 2026-11-10: "either you take out that number or ...")
PLAIN_LEGEND = [                        # always shown above the table, never behind a click (research: some readers never open a disclosure)
    "**Where in the files:** the row of the CSV file where the error shows. Row 144 is the 144th row under the file's header (a spreadsheet shows it on line 145). "
    "In brackets, the number the analyzer itself gave that row (its NVMe Cmd, Link Tra or Packet number), when it differs. On the page, click it to open that row: "
    "every cell with its meaning, and the reason the rule calls it an error.",
    "**When:** the row's Time Stamp, in seconds from the start of the recording.",
    "**How serious:** *error*, the rule's condition for a failure is met; *warning*, the analyzer's own warning, or a link event worth a look; *to check*, a person has to decide.",
]


def _secs(ps):
    try:
        return ("%.6f" % (int(ps) / 1e12)).rstrip("0").rstrip(".") + " s"
    except (TypeError, ValueError, OverflowError):
        return ""


def _whole(v):
    """A row number as read from the result: an int from the stored head, or text from the CSV the export reads back (found by the agent
    suite on 2026-11-11: '{:,}' on text stopped the export). Empty text is no number; other text is kept as it is."""
    if v is None or v == "":
        return None
    if isinstance(v, int):
        return v
    try:
        return int(str(v).strip())
    except ValueError:
        return v


def _grouped(v):
    return "{:,}".format(v) if isinstance(v, int) else str(v)


def plain_defects(cols, rows, rule_name=None):
    """The detector's list of defects as people read it: {"columns", "rows", "legend", "rule"}; None for another kind of result."""
    cols = list(cols or [])
    if cols[:8] != list(PR_DETECTOR_OUTPUT[:8]):
        return None
    out = []
    for x in rows or []:
        x = list(x) + [None] * (9 - len(x))
        fid, level, _rule, name, sev, row_n, t_ps, cmd_row, data_row = x[:9]
        row_n, cmd_row, data_row = _whole(row_n), _whole(cmd_row), _whole(data_row)
        f = LEVEL_FILE.get(level, level or "its file")
        row = data_row if data_row is not None else row_n
        own = (" (%s %s)" % (LEVEL_NUMBER.get(level, "number"), _grouped(row_n))) if row_n is not None and data_row is not None and row_n != data_row else ""
        where = "row %s of %s%s" % (_grouped(row) if row is not None else "-", f, own)
        if level != "nvme_command":
            where += (", inside the command in row %s of nvme_command.csv" % _grouped(cmd_row)) if cmd_row else ", outside any command"
        out.append([name, where, _secs(t_ps), SEVERITY_WORDS.get(sev, sev)])
    return {"columns": PLAIN_COLUMNS, "rows": out, "legend": PLAIN_LEGEND,
            "rule": ("Every error below was found by the rule *%s*. It is called a defect only after its isolation." % rule_name) if rule_name else ""}


def _md_cell(v):
    return ("" if v is None else str(v)).replace("|", "/").replace("\n", " ")


def _result(ctx):
    r = _rule(ctx)
    res, test, exp = ctx.output_of("run"), ctx.output_of("test"), ctx.output_of("export")
    admin = ctx.project.get("admin") or "admin"
    head = res.get("head") or []
    cols = res.get("columns") or []
    rec = (ctx.project.get("name") or "").strip()
    n_rows = res.get("rows", 0) or 0
    what = ("found %s error%s" % ("{:,}".format(n_rows), "" if n_rows == 1 else "s")) if (res.get("kind") == "detector" or plain_defects(cols, [])) else ("gave %s line%s" % ("{:,}".format(n_rows), "" if n_rows == 1 else "s"))
    body = ["**Admin %s, need review.** The rule *%s* (version %d of its text) %s in this recording%s." % (
        admin, r["name"], r["version"], what, (" (%s; its tree is %s)" % (rec, res.get("upload_id"))) if rec else (" (tree %s)" % res.get("upload_id"))),
            "", "**Tester:** " + ("all checks passed" if test.get("passed") else "SOME CHECKS FAILED"), ""] + [
        "- %s %s: %s" % ("✔" if c["ok"] else "✘", c["check"], c["detail"]) for c in test.get("checks") or []]
    plain = plain_defects(cols, head[:25], r["name"])
    if plain:
        body += ["", plain["rule"], "", "How to read the table:"] + ["- " + x for x in plain["legend"]] + [
            "", "| %s |" % " | ".join(plain["columns"]), "|%s" % ("---|" * len(plain["columns"]))] + ["| %s |" % " | ".join(_md_cell(v) for v in x) for x in plain["rows"]]
        if len(head) > 25:
            body.append("… %s more rows in the export" % "{:,}".format(res.get("rows", 0) - 25))
    elif head:
        body += ["", "| %s |" % " | ".join(cols), "|%s" % ("---|" * len(cols))] + ["| %s |" % " | ".join("" if v is None else str(v) for v in x) for x in head[:25]]
        if len(head) > 25:
            body.append("… %s more rows in the export" % "{:,}".format(res.get("rows", 0) - 25))
    body += ["", "Exported: " + ", ".join(os.path.basename(p) for p in (exp.get("files") or {}).values()),
             "", "Approve to accept the result. To change what is computed, edit the rule (the code follows the rule)."]
    return core.Result({"rows": res.get("rows"), "files": exp.get("files")},
                       review={"title": "Result: %s" % r["name"], "body": "\n".join(body),
                               "data": {"columns": cols, "head": head[:200], "files": exp.get("files"), "upload_id": res.get("upload_id"), "section": r["section"], "defects": goes_to_stages(r["section"]),
                                        "plain": plain_defects(cols, head[:200], r["name"])}})


def on_finish(engine, rid):
    run = engine.store.one("SELECT params FROM run WHERE id=?", (rid,))
    p = core.jload(run["params"], {})
    r = load_rule(p.get("section"), p.get("level"), p.get("id")) if p.get("id") else None
    if r and p.get("_kind") in ("rule_run", "rule_exec"):
        r["last_run"] = {"run": rid, "at": time.time(), "upload_id": p.get("upload_id")}
        exp = engine.store.one("SELECT output FROM step WHERE run=? AND key='export' AND state='done'", (rid,))
        res = engine.store.one("SELECT output FROM step WHERE run=? AND key='run' AND state='done'", (rid,))
        if exp and res:
            eo, ro = core.jload(exp["output"], {}), core.jload(res["output"], {})
            r["last_result"] = {"run": rid, "at": time.time(), "upload_id": ro.get("upload_id"), "rows": ro.get("rows"),
                                "csv": (eo.get("files") or {}).get("csv"), "html": (eo.get("files") or {}).get("html"),
                                "columns": ro.get("columns"), "head": (ro.get("head") or [])[:30], "procedure_version": ro.get("procedure_version"),
                                "plain": plain_defects(ro.get("columns"), (ro.get("head") or [])[:30], r.get("name"))}
        save_rule(r)
