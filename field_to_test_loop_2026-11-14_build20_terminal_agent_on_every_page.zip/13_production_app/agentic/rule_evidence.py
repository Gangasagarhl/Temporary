"""What a Family 3 item reads and how the detector's items decide, from the code itself (owner, 2026-11-09).

  READS     for each detector rule: the columns it reads (level, internal name) and its test in words, with how text is
            compared (lower case, upper case, or exactly as written). tests/test_rule_evidence.py checks every column
            named here against the code that files the rule, so the screen cannot claim a column the code does not use.
  code_of   the lines of nvme_hier/rules.py that file a rule (file and line numbers), shown as the detector's verified code
  explain   what the card shows for one item: the source data with full paths in the recording, the procedure (the
            editable JSON), the code (verified or not, with its text), the last result on this recording
  counts    how often each detector item fired in a recording (for the item list)
  recording the recording in words (name, folder, who loaded it and when, rows per file)
"""
import json
import os
import re
import sqlite3
import sys
import time

from . import family1, family3

APP = family1.APP
sys.path.insert(0, APP)
from nvme_hier import loader as L, rules as RL   # noqa: E402

TABLE = {"packets": "pkt", "link": "lnk", "split": "spl", "nvme_transaction": "ntx", "nvme_command": "cmd"}
FILE_NAME = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv",
             "nvme_command": "nvme_command.csv"}
LEVEL_ABOUT = {
    "nvme_command": "One row per NVMe command: an order the computer gave the drive, such as read or write these blocks (the NVMe command file).",
    "nvme_transaction": "The steps of one command: the doorbell ring, the drive fetching the order, the data moving, the drive's answer "
                        "(the completion entry) and the interrupt (the NVMe transaction file).",
    "split": "A PCIe request and the completions that answer it (the split transaction file).",
    "link": "One TLP on the PCIe wire and the Ack or Nak that answered it (the link transaction file).",
    "packets": "Every packet on the PCIe wire, the smallest unit the analyzer records (the packet file).",
    "other": "A CSV file of the analysis's folder that is not one of the analyzer's five exports. A rule here names its file in "
             "its procedure and reads it as it is; such a file is not part of the tree.",
}
LEVELS_NOTE = ("The levels are the five files the analyzer exports, so they come from the data and are the same for every section. "
               "Sections and items are yours to add.")

# columns the tree build makes (not cells of the file)
DERIVED = {
    "parent": "set when the tree was built: the row of the level above that holds this row, joined by identity (queue and command id, "
              "requester and tag, PSN), never by time",
    "parent_level": "set when the tree was built: the level of that row",
    "relation": "set when the tree was built: part of a command, only in its time window, or belongs to no command",
    "dur_ps": "worked out when the tree was built: from the row's first packet to its last; for a command, from its Time Stamp to "
              "the Time Stamp of its completion entry",
}

# How each detector rule decides: the columns it reads (level, internal name) and the test in words. Written from the
# code of nvme_hier/rules.py; tests/test_rule_evidence.py checks every name against the code that files the rule.
T_CQE = ("its Type is an Admin or I/O Completion Queue Entry: it contains \"completion\" and neither \"doorbell\" nor \"submission\", "
         "compared in lower case (the Completion Queue Head Doorbell is the host's write, not the entry)")
READS = {
    "pkt.analyzer_error": ([("packets", "errors")], "The packet's Errors cell is not empty. The text in it is the analyzer's own error name."),
    "pkt.bad_lcrc": ([("packets", "lcrc")], "The LCRC cell contains \"(Bad)\", exactly as written (letter case as in the export)."),
    "pkt.bad_ecrc": ([("packets", "ecrc")], "The ECRC cell contains \"(Bad)\", exactly as written (letter case as in the export)."),
    "pkt.bad_crc16": ([("packets", "crc16")], "The CRC 16 cell contains \"(Bad)\", exactly as written (letter case as in the export)."),
    "pkt.poisoned_tlp": ([("packets", "ep")], "The EP cell is set."),
    "pkt.invalid_packet": ([("packets", "n"), ("packets", "tlp_type"), ("packets", "dllp_type"), ("packets", "os_type"), ("packets", "link_event")],
                           "The Packet number is empty and none of TLP Type, DLLP Type, Ord.Set Type and Link Event holds a value."),
    "pkt.recovery": ([("packets", "link_event")], "The Link Event cell contains \"recovery\" in any letter case (checked first)."),
    "pkt.link_down": ([("packets", "link_event")], "The Link Event cell contains \"link down\", \"surprise\", \"hot reset\" or \"disable\" (any letter case; checked after Recovery)."),
    "pkt.speed_change": ([("packets", "link_event")], "The Link Event cell contains \"speed\" or \"rate\" (any letter case; checked after Recovery and link down)."),
    "pkt.width_change": ([("packets", "link_event")], "The Link Event cell contains \"width\" or \"lane\" (any letter case; checked after speed)."),
    "pkt.electrical_idle": ([("packets", "link_event")], "The Link Event cell contains \"electrical idle\" but not \"electrical idle exit\", in any letter case (checked last)."),
    "lnk.analyzer_error": ([("link", "errors")], "The Link Tra Error cell is not empty, and (compared in lower case) it names neither a Nak, replay or retry, nor an incomplete or un-acknowledged TLP."),
    "lnk.replay": ([("link", "errors"), ("link", "n_packets")], "The Link Tra Error cell mentions \"nak\", \"replay\" or \"retr\" (compared in lower case); or, with that cell empty, "
                   "Metrics.# Packets is above 2 (one TLP and its Ack make 2)."),
    "lnk.incomplete": ([("link", "errors")], "The Link Tra Error cell mentions \"incomplete\" or \"no ack\" (compared in lower case; and no Nak, replay or retry)."),
    "lnk.response_over_limit": ([("link", "delta_ps")], "Time Delta is at or above the link limit (50 us by default; Time limits per level)."),
    "spl.analyzer_error": ([("split", "errors")], "The Split Tra Error cell is not empty."),
    "spl.cpl_ur": ([("split", "cpl_status")], "Cpl Status is \"UR\" (compared in upper case)."),
    "spl.cpl_ca": ([("split", "cpl_status")], "Cpl Status is \"CA\" (compared in upper case)."),
    "spl.cpl_crs": ([("split", "cpl_status")], "Cpl Status is \"CRS\" (compared in upper case)."),
    "spl.incomplete": ([("split", "cpl_status"), ("split", "n_links")], "Cpl Status is \"Incomplete\" (compared in upper case), or the split holds a single link "
                       "transaction (Metrics.# LinkTrans = 1) and no Cpl Status."),
    "spl.latency_over_limit": ([("split", "delta_ps")], "Time Delta is at or above the split limit (50 ms by default)."),
    "spl.short_data": ([("split", "cpl_status"), ("split", "nbytes"), ("link", "length"), ("link", "tlp_type"), ("link", "parent")],
                       "Cpl Status is \"SC\" and Data (bytes) is less than 4 x the Length (dwords) of the last non-posted request link "
                       "transaction inside the split."),
    "ntx.analyzer_error": ([("nvme_transaction", "errors")], "The Errors cell is not empty."),
    "ntx.analyzer_warning": ([("nvme_transaction", "warnings")], "The Warnings cell is not empty."),
    "ntx.status_error": ([("nvme_transaction", "sct"), ("nvme_transaction", "sc")], "Only when there is no command file: SCT or SC is not 0."),
    "ntx.over_limit": ([("nvme_transaction", "delta_ps")], "Time Delta is at or above the NVMe-transaction limit (50 ms by default; Time limits per level)."),
    "ntx.phase_wrong": ([("nvme_transaction", "type"), ("nvme_transaction", "addr"), ("nvme_transaction", "phase"), ("nvme_transaction", "sqid"),
                         ("nvme_command", "opc"), ("nvme_command", "qid"), ("nvme_command", "qsize"), ("nvme_command", "prp1"), ("nvme_command", "cqid")],
                        "For each completion entry (" + T_CQE + "): its slot is (Address minus the queue's base, the PRP1 of the Create I/O "
                        "Completion Queue command) / 16, modulo QSIZE. The expected phase starts at 1 and flips each time the slot wraps "
                        "to the start. A P cell different from the expected value fires."),
    "ntx.interrupt_before_completion": ([("nvme_transaction", "type"), ("nvme_transaction", "t_ps"), ("nvme_transaction", "parent")],
                                        "For one command: the Time Stamp of its first interrupt (Type contains \"interrupt\" or \"msi\", compared in lower case) is "
                                        "earlier than the Time Stamp of its first completion entry (" + T_CQE + ")."),
    "ntx.completion_unknown_command": ([("nvme_transaction", "type"), ("nvme_transaction", "sqid"), ("nvme_transaction", "cid"), ("nvme_transaction", "relation")],
                                       "A completion entry (" + T_CQE + ") whose SQID and CID joined no open command when the tree was built."),
    "cmd.status_error": ([("nvme_command", "sct"), ("nvme_command", "sc")], "ST.SCT or ST.SC is not 0 (0 and 0 is Successful Completion). "
                         "The status name comes from the specification's status tables."),
    "cmd.analyzer_error": ([("nvme_command", "errors")], "The Errors cell is not empty."),
    "cmd.analyzer_warning": ([("nvme_command", "warnings")], "The Warnings cell is not empty."),
    "cmd.timeout": ([("nvme_command", "opc"), ("nvme_command", "sqid"), ("nvme_command", "nlb"), ("nvme_command", "sct"), ("nvme_command", "sc"),
                     ("nvme_command", "t_ps"), ("nvme_transaction", "type"), ("nvme_transaction", "sct"), ("nvme_transaction", "sc"),
                     ("nvme_transaction", "t_ps"), ("nvme_transaction", "parent"), ("split", "parent"), ("link", "explicit_ack"),
                     ("link", "errors"), ("link", "parent")],
                    # one step per line (the procedure shows each as its own numbered step)
                    "Every command counts, apart from Format NVM, Sanitize, Device Self-test, Firmware Commit and Firmware Image Download "
                    "(long by nature) and Asynchronous Event Request (it waits for an event by design).\n"
                    "Its cycle over PCIe, as NVMe Base 2.1 section 3.3.1.2 defines it, from its rows in NVME_Transactions.csv (joined to the "
                    "command by SQID and CID): submitted (the host's Submission Queue Tail Doorbell write; one write may submit several "
                    "entries) > fetched (the drive reads the submission queue entry) > PRP list and data, when the command moves data > "
                    "completed (the drive writes the completion queue entry; its status is the drive's answer: Successful Completion, or "
                    "an error) > interrupt (optional) > consumed (the host's Completion Queue Head Doorbell write; one write may cover "
                    "several entries).\n"
                    "Every packet (TLP) of every step, in link.csv under its split or NVMe transaction, is answered on the link (PCIe Base "
                    "3.6.2): ACK (Explicit ACK Yes: an ACK named it; No: a later ACK covered it, ACKs are cumulative), NAK (Link Tra Error "
                    "\"Nak received, replayed\": the sender sends it again), or never acknowledged (Link Tra Error incomplete). Each "
                    "finding says how far the cycle got and the link's answer to its packets.\n"
                    "The host's limit: 30 s for a command on an I/O queue, 60 s on the admin queue (SQID 0): the Linux driver's defaults "
                    "(the NVMe specification sets no completion time for a command).\n"
                    "Never completed: the cycle never reached completed: its ST.SCT and ST.SC are empty, and the recording (the last Time "
                    "Stamp of nvme_command.csv) went on for the host's limit or longer after the command's Time Stamp. Sent later than "
                    "that: still open at the end, not judged.\n"
                    "Aborted by the host: the drive's answer is ST.SCT 0 and ST.SC 07h (Command Abort Requested) or 08h (Command Aborted "
                    "due to SQ Deletion: the host deleted its queue), or ST.SCT 3 and ST.SC 71h (Command Aborted By Host).\n"
                    "A command's time = the Time Stamp of its first completion entry (" + T_CQE + ") minus the command's own Time Stamp. "
                    "The entry is joined to the newest command with its SQID and CID: a command ID is unique only while its command is "
                    "outstanding. A second completion entry for the same command is a fault of its own and is not used. Two commands "
                    "outstanding with the same SQID and CID (a fault too) cannot be told apart: their time is not judged.\n"
                    "Over the host's limit: the command's time is the host's limit or more.\n"
                    "Usual time of each command type and size (OPC, admin or I/O, and NLB: a 256-block Write takes longer than an 8-block "
                    "one), measured on this recording. Its times are sorted, fastest first. The normal group runs up to the first jump, a time at "
                    "least 3 x the one before it, with at most 1 command in 10 above it; or a jump of 10 x or more with at most 65 % above it. A smaller "
                    "jump with many commands above it is the drive's second normal group (cache hits and flash reads). One or two commands above a "
                    "jump must also clear the group's own spread (1.8 spreads of its slower half on a log scale, because natural noise makes lone outliers), unless the jump is 5 x or more.\n"
                    "Slower than usual: more than 3 x the slowest normal command. A type and size with fewer than 20 completed commands has "
                    "no usual time."),
    "cmd.read_failure": ([("nvme_command", "opc"), ("nvme_command", "sqid"), ("nvme_command", "sct"), ("nvme_command", "sc")],
                         "Only Reads: OPC 0x02 on an I/O queue (SQID not 0).\n"
                         "Failed: ST.SCT or ST.SC is not 0 (0 and 0 is Successful Completion). The host's own aborts (0/07h, 0/08h, 3/71h) "
                         "are timeouts, not read failures.\n"
                         "The status is named from the specification's status tables; 2h/81h is Unrecovered Read Error: the drive could "
                         "not correct the data.\n"
                         "The finding also shows the Read's cycle (doorbell > entry fetched > data > completion entry with the drive's "
                         "negative answer > interrupt > head doorbell) and the link's ACK or NAK to its packets, read from the tree."),
    "cmd.incomplete": ([("nvme_command", "opc"), ("nvme_command", "sqid"), ("nvme_transaction", "type"), ("nvme_transaction", "parent")], "The command has NVMe transactions in the tree, and none of "
                       "them is a completion entry (" + T_CQE + ")."),
    "cmd.not_fetched": ([("nvme_command", "opc"), ("nvme_command", "sqid"), ("nvme_transaction", "type"), ("nvme_transaction", "parent")], "The command has NVMe transactions in the tree, and none "
                        "of them is the fetch of its submission entry (its Type contains \"submission\", compared in lower case)."),
    "cmd.doorbell_missing": ([("nvme_command", "opc"), ("nvme_command", "sqid"), ("nvme_transaction", "type"), ("nvme_transaction", "parent")], "The command has NVMe transactions in the tree, and "
                             "none of them is a doorbell write (its Type contains \"doorbell\", compared in lower case)."),
    "cmd.no_interrupt": ([("nvme_command", "opc"), ("nvme_command", "sqid"), ("nvme_transaction", "type"), ("nvme_transaction", "parent")], "One of the command's NVMe transactions is a completion "
                         "entry (" + T_CQE + ") and none is an interrupt (Type contains \"interrupt\" or \"msi\", compared in lower case)."),
    "cmd.latency_over_limit": ([("nvme_command", "delta_ps"), ("nvme_command", "sqid")], "Time Delta is at or above the command limit: the admin "
                               "queue's limit when SQID is 0, the I/O limit otherwise (defaults from the Linux driver: 60 s admin, 30 s I/O)."),
    "cmd.bytes_short": ([("nvme_command", "opc"), ("nvme_command", "sqid"), ("nvme_command", "nlb"), ("nvme_command", "nbytes"), ("nvme_command", "sct"),
                         ("nvme_command", "sc")], "A Read or Write (OPC 2 or 1) on an I/O queue (SQID not 0) that completed with status 0, "
                        "whose Data (bytes) is less than (NLB + 1) x 512."),
    "cmd.deallocate_readback": ([("nvme_command", "opc"), ("nvme_command", "ad"), ("nvme_command", "nr"), ("nvme_command", "nsid"), ("nvme_command", "slba"),
                                 ("nvme_command", "nlb"), ("nvme_command", "dlfeat"), ("nvme_command", "t_ps")],
                                "A Dataset Management command (OPC 9) with AD set lists its ranges (RNG i.SLBA and RNG i.Length LB). A later "
                                "Read (OPC 2) of the same NSID that overlaps a range fires. It is an error when the data read differs from what "
                                "DLFEAT declares, and a suspect when DLFEAT is not reported."),
    "cmd.write_zeroes_readback": ([("nvme_command", "opc"), ("nvme_command", "nsid"), ("nvme_command", "slba"), ("nvme_command", "nlb"), ("nvme_command", "sct"),
                                   ("nvme_command", "sc"), ("nvme_command", "t_ps")],
                                  "A Write Zeroes (OPC 8) that completed with status 0, then a later Read (OPC 2) of the same NSID that "
                                  "overlaps its range. The data read must be zeros."),
}
# extra lines worth showing with a rule's own lines: where its input is read
ALSO = {
    "cmd.timeout": ["NOT_TIMED_SQL = ", "CYCLE_STEPS_SQL = ", "CYCLE_LINKS_SQL = (", "def link_answer(", "FIRST_CQE_SQL = (", "BLOCKS_SQL = ",
                    "TIMEOUT_USUAL_SQL = (", "TIMEOUT_SQL = ("],
    "cmd.read_failure": ["READ_FAILURE_SQL = ("],
    "cmd.incomplete": ["parts_cur = con.execute("], "cmd.not_fetched": ["parts_cur = con.execute("], "cmd.doorbell_missing": ["parts_cur = con.execute("],
    "cmd.no_interrupt": ["parts_cur = con.execute("], "spl.short_data": ["req = (\"(SELECT l.length"],
    # the read-back rules gather their commands while the command rows are read, then compare them in their own method
    "cmd.deallocate_readback": ["if sqid != 0 and opc == 9 and ad:", "if sqid != 0 and opc == 2 and slba is not None"],
    "cmd.write_zeroes_readback": ["if sqid != 0 and opc == 8 and slba is not None", "if sqid != 0 and opc == 2 and slba is not None"],
}


# ------------------------------------------------------------------------------------------------ the code of a rule
_SOURCE = {}


def _rules_source():
    """nvme_hier/rules.py as lines (read again only when the file changed)."""
    path = RL.__file__.replace(".pyc", ".py")
    m = os.path.getmtime(path)
    if _SOURCE.get("key") != (path, m):
        _SOURCE.update(key=(path, m), lines=open(path, encoding="utf-8").read().split("\n"))
    return path, _SOURCE["lines"]


def _indent(line):
    return len(line) - len(line.lstrip(" "))


def _statement_end(lines, i):
    """The last line of the statement that starts at line i (brackets balanced)."""
    depth, j = 0, i
    while j < len(lines):
        t = re.sub(r'"(?:[^"\\]|\\.)*"|\'(?:[^\'\\]|\\.)*\'', '""', lines[j])
        depth += t.count("(") + t.count("[") + t.count("{") - t.count(")") - t.count("]") - t.count("}")
        if depth <= 0:
            return j
        j += 1
    return j


def _block_end(lines, k):
    """The last line of the statement at k, and of its block when it opens one (a line ending with a colon)."""
    j = _statement_end(lines, k)
    if not lines[j].rstrip().endswith(":"):
        return j
    ind = _indent(lines[k])
    while j + 1 < len(lines) and (not lines[j + 1].strip() or _indent(lines[j + 1]) > ind):
        j += 1
    while j > k and not lines[j].strip():
        j -= 1
    return j


def _controller(lines, i):
    """The nearest line above i, less indented, that starts an if / elif / for / while / with / def block."""
    ind = _indent(lines[i])
    for j in range(i - 1, -1, -1):
        t = lines[j].strip()
        if t and _indent(lines[j]) < ind and re.match(r"(if|elif|for|while|with|def|else)\b", t):
            return j
    return i


def _enclosing_def(lines, i):
    for j in range(i, -1, -1):
        if re.match(r"\s*def \w+\(", lines[j]):
            return j
    return 0


def _snip(lines, a, b):
    return {"from": a + 1, "to": b + 1, "text": "\n".join(lines[a:b + 1])}


def code_of(rule):
    """The lines of nvme_hier/rules.py that file this rule: [{from, to, text}], the method's name and its source (for the
    tests). The line that names the rule inside self.add(...) or a rule = ... choice, with the condition that leads to it."""
    path, lines = _rules_source()
    q = '"%s"' % rule
    hits = [i for i, l in enumerate(lines) if q in l]
    pick = next((i for i in hits if "self.add(" in lines[i] or re.search(r"\brule = ", lines[i])), None)
    snippets = []
    if pick is None:
        ev = next((i for i in hits if "re.compile" in lines[i]), None)
        if ev is None:
            return None
        # a link-event rule is one line of the LINK_EVENTS list. The lines that file it: the line that looks the packet's
        # Link Event cell up in the list ("name = next(... in LINK_EVENTS ...)") and the "if name:" block that adds the finding
        look = next((i for i, l in enumerate(lines) if re.search(r"\bin LINK_EVENTS\b", l)), None)
        snippets.append(_snip(lines, ev, ev))
        pick = ev
        if look is not None:
            snippets.append(_snip(lines, look, _statement_end(lines, look)))
            pick = look
            name = re.match(r"\s*(\w+) = ", lines[look])
            files = next((i for i in range(look + 1, len(lines)) if re.match(r"\s*if %s:\s*$" % re.escape(name.group(1)), lines[i])), None) if name else None
            if files is not None:
                snippets.append(_snip(lines, files, _block_end(lines, files)))
                pick = files
    else:
        c = _controller(lines, pick)
        if re.match(r"\s*def (\w+)\(", lines[c]):           # the rule sits in its own method: show the call and its condition
            name = re.match(r"\s*def (\w+)\(", lines[c]).group(1)
            call = next((i for i, l in enumerate(lines) if "self.%s(" % name in l and not l.strip().startswith("def ")), None)
            if call is not None:
                cc = _controller(lines, call)
                snippets.append(_snip(lines, cc, _statement_end(lines, call)))
        snippets.append(_snip(lines, c, _statement_end(lines, pick)))
    for needle in ALSO.get(rule, []):
        k = next((i for i, l in enumerate(lines) if needle in l), None)
        if k is not None:
            snippets.insert(len(snippets) - 1, _snip(lines, k, _block_end(lines, k)))
    d = _enclosing_def(lines, pick)
    end = next((j for j in range(d + 1, len(lines)) if re.match(r"\s*def \w+\(", lines[j]) and _indent(lines[j]) <= _indent(lines[d])), len(lines))
    method = re.match(r"\s*def (\w+)\(", lines[d]).group(1) if re.match(r"\s*def (\w+)\(", lines[d]) else ""
    rel = os.path.relpath(path, APP)
    return {"path": rel, "snippets": snippets, "method": method, "method_source": "\n".join(lines[d:end])}


# ------------------------------------------------------------------------------------------------ columns and meanings
def file_columns(level, sql):
    """The analyzer's column names that load into one internal column (the loader's table)."""
    return [c for c, s, _f in L.KEYS.get(level, []) if s == sql]


def _meanings(level):
    """{file column: (meaning, where it comes from)} from Family 1's newest approved dictionary of the level."""
    out = {}
    for d in family1.dictionaries_for_level(level)[:1]:
        for c in d.get("columns") or []:
            src = c.get("source") or {}
            how = c.get("status") or ""
            ref = src.get("ref") or ""
            if src.get("kind") == "document" and ref:
                how = "%s: %s" % (how or "a reference document", os.path.basename(ref))
            elif src.get("kind") == "web" and ref:
                how = "%s: %s" % (how or "a web page", ref)
            out[c.get("column")] = (c.get("meaning") or "", how, d.get("version"), d.get("approved_by"))
    return out


# ------------------------------------------------------------------------------------------------ the upload
def _upload(upload_id):
    if not upload_id or not re.match(r"^[A-Za-z0-9_.-]+$", upload_id):
        return None, {}
    from . import procedures as PR
    d = PR.upload_folder(upload_id)
    if not d:
        return None, {}
    db = os.path.join(d, "hier.sqlite")
    if not os.path.exists(db):
        return None, {}
    files = {}
    try:
        meta = json.load(open(os.path.join(d, "meta.json"), encoding="utf-8"))
        files = {k: os.path.basename(v) for k, v in (meta.get("files") or {}).items() if v}
    except (OSError, ValueError):
        pass
    return db, files


def _ro(db, seconds=5.0):
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    con.row_factory = sqlite3.Row
    t0 = time.time()
    con.set_progress_handler(lambda: 1 if time.time() - t0 > seconds else 0, 20000)
    return con


# ------------------------------------------------------------------------------------------------ the recording, in words
def recording(upload_id):
    """What a reader needs to know about the data the rules run on, instead of its id: the name given to it, the folder
    its five files came from, who loaded it and when, and how many rows each file has."""
    db, files = _upload(upload_id)
    if not db:
        return None
    meta = {}
    try:
        meta = json.load(open(os.path.join(os.path.dirname(db), "meta.json"), encoding="utf-8"))
    except (OSError, ValueError):
        pass
    paths = [v for v in (meta.get("files") or {}).values() if v]
    folder = os.path.basename(os.path.dirname(paths[0])) if paths else ""
    rows = {}
    con = _ro(db)
    try:
        have = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        for level in ("nvme_command", "nvme_transaction", "split", "link", "packets"):
            if TABLE[level] in have:
                rows[level] = con.execute("SELECT COUNT(*) FROM %s" % TABLE[level]).fetchone()[0]
    except sqlite3.Error:
        pass
    finally:
        con.close()
    return {"name": meta.get("trace_name") or meta.get("device") or folder, "folder": folder, "loaded_by": meta.get("operator") or "",
            "loaded_at": meta.get("loaded_at") or meta.get("created"), "rows": rows, "files": files}


# ------------------------------------------------------------------------------------------------ one item, for the card
def explain(section, level, rid, upload_id=None):
    """What the card shows for one item (owner, 2026-11-09): the source data (full paths in the recording), the procedure
    (numbered steps, the editable JSON), the code (verified or not, with its text) and the last result on this recording."""
    from . import procedures as PR
    r = family3.load_rule(section, level, rid)
    if r is None:
        return None
    proc = PR.procedure_of(r)
    paths = PR.source_paths(upload_id)
    st = PR.code_state(r)
    code_text = None
    if st["kind"] == "python" and st.get("path") and os.path.exists(st["path"]):
        code_text = open(st["path"], encoding="utf-8").read()
    editable = {k: proc.get(k) for k in ("source_data", "steps", "output", "open_questions")} if proc else {
        "source_data": [{"file": FILE_NAME.get(level, "(the CSV file's name).csv"), "columns": []}], "steps": [], "output": {"columns": [], "order": ""}, "open_questions": []}
    last = r.get("last_result") or {}
    if upload_id and last.get("upload_id") != upload_id:
        last = {}
    if last.get("csv") and not os.path.exists(last["csv"]):
        last = {}
    out = {"key": "%s/%s/%s" % (section, level, rid), "name": r.get("name"), "admin_words": r.get("description") or "",
           "section": family3.SECTION_INFO.get(section), "level": {"id": level, "label": family3.LEVEL_LABEL[level], "about": LEVEL_ABOUT[level]},
           "upload_id": upload_id, "procedure": proc, "procedure_json": editable,
           "procedure_info": {"version": (proc or {}).get("version", 0), "edited_by": (proc or {}).get("edited_by"), "edited_at": (proc or {}).get("edited_at"),
                              "from_detector": bool((proc or {}).get("from_detector")),
                              # the text the editor starts from: a save names it, so a change made meanwhile is not overwritten
                              "sha": PR.sha(proc) if proc else None},
           "sources": [{"file": x["file"], "path": paths.get(x["file"]), "columns": x["columns"]} for x in (proc or {}).get("source_data", [])],
           "code": dict(st, text=code_text), "last_result": last or None,
           # where the rule and its code are kept (owner, 2026-11-09: "the source path is there, but what about where the rules are")
           "rule_file": family3.rule_path(section, level, rid), "rules_folder": family3.rules_root(),
           "code_file": (os.path.join(APP, st["path"]) if st.get("kind") == "detector" and st.get("path") else st.get("path"))}
    return out


def counts(upload_id):
    """{item key: {found, commands}} for the detector items, from the upload's finding table (for the item list)."""
    db, _files = _upload(upload_id)
    if not db:
        return {}
    con = _ro(db, seconds=5.0)
    try:
        if not con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='finding'").fetchone():
            return {}
        by_rule = {x[0]: (x[1], x[2]) for x in con.execute("SELECT rule, COUNT(*), COUNT(DISTINCT cmd_rowid) FROM finding GROUP BY rule")}
    except sqlite3.Error:
        return {}
    finally:
        con.close()
    out = {}
    for sec in family3.tree():
        for lv in sec["levels"]:
            for it in lv["items"]:
                if it.get("kind") != "detection_rule":
                    continue
                r = family3.load_rule(sec["section"], lv["level"], it["id"]) or {}
                rule = (r.get("plan") or {}).get("rule")
                n, c = by_rule.get(rule, (0, 0))
                out["%s/%s/%s" % (sec["section"], lv["level"], it["id"])] = {"found": n, "commands": c}
    return out
