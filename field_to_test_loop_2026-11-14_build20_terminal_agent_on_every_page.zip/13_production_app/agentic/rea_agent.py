"""The REA agent: what the analyzer's own decompiled program says, asked on the start page.

(owner, 2026-11-14: "let's keep the rea out, because it is going to consume a lot of time. If there is any extra rea to
be found out that shall be kept out at the first page itself ... then the rea decompiled folder shall be taken or given
the path, and what you want to see ask questions ... So from there Agent from Second family now can talk to the ... rea
family, so get more information from rea.")

REA (Reverse Engineer Anything) decompiles the analyzer's program; the findings are a folder of decompiled code and
notes as text. They are not a step of the flow any more. Here:

  read(folder)      every file is read ONCE, in one pass: its text goes into a search index of passages
                    (knowledge/rea/<key>.sqlite, SQLite full-text search; a plain search where that is missing), and in
                    the same pass the lines that name the join columns are collected for Family 2's Coder
                    (knowledge/rea/<key>.json). <key> is made from every file's path, size and time of last change: the
                    same key = the same findings, so they are never read twice (owner, 2026-11-12: "if it is completed,
                    then there is no need ... to start doing REA again").
  status(folder)    exists, files, read or not, when, passages, which join columns it names
  search(folder, words)   passages with file and lines
  ask(engine, folder, question, history, asker)   one question; the model sees only passages the program found, may ask
                    for other search words twice, and every quote it gives is checked against its passage by code
  ask_for_family2(engine, project, question)      Family 2's agents get passages with their sources
  join_hits(folder) what the Coder quotes, without reading anything

Nothing here is called by a step of the flow except join_hits and has_quote, which read what is already on disk.
"""
import hashlib
import json
import os
import re
import sqlite3
import threading
import time

from . import core, family1, prompts

JOIN_TERMS = ["PSN", "AckNak Seq Num", "Ack", "Nak", "RequesterID", "Tag", "Address", "SQID", "CID", "Doorbell",
              "Metrics.# Packets", "Metrics.# LinkTrans", "Metrics.# Link & Split Trans", "Metrics.# NVME Trans"]

PASSAGE_LINES = 24              # lines of one passage of the index
PASSAGE_CHARS = 6000            # a passage is cut here (a decompiled file can have one very long line)
FILE_BYTES_MOST = 200 * 1024 ** 2   # a text file larger than this is not read (said in the status)
FILES_MOST = 200000
HITS_PER_TERM = 3               # what the Coder is given for one join column, as before
PASSAGES_PER_SEARCH = 8
PASSAGE_TEXT_FOR_MODEL = 2400   # characters of one passage in a question to the model
MAX_ROUNDS = 3                  # the first answer and at most two more after "search_more"
CHAT_TURNS_KEPT = 400
HISTORY_TURNS = 3               # the model connection holds the conversation of this agent itself (core.api_turn): only the last lines are repeated
SHAPE = '{"answer": "...", "sources": [{"passage": 0, "quote": "<words copied exactly from that passage>"}], "search_more": ["<another word to look for>"]}'
STOP_WORDS = frozenset("""a an and are as at be but by can could did do does for from had has have how i if in into is it its
of on or that the their them then there these they this to was were what when where which who why will with would you your
me my we our about any all not no yes please tell show give find say says said used use using does""".split())

_locks, _locks_lock = {}, threading.Lock()
_fts = None


def _lock(key):
    with _locks_lock:
        return _locks.setdefault(key, threading.Lock())


def has_fts():
    """True when this Python's SQLite has full-text search (FTS5). Asked once."""
    global _fts
    if _fts is None:
        try:
            c = sqlite3.connect(":memory:")
            c.execute("CREATE VIRTUAL TABLE t USING fts5(x)")
            c.close()
            _fts = True
        except sqlite3.Error:
            _fts = False
    return _fts


# ---------------------------------------------------------------------------------------------- the findings on disk
def _walk(folder):
    """Every file under the folder: [(path relative with /, full path, size, time of last change in ns)], in one fixed order."""
    out = []
    for base, dirs, names in os.walk(folder):
        dirs.sort()
        for n in sorted(names):
            p = os.path.join(base, n)
            try:
                st = os.stat(p)
            except OSError:
                continue
            out.append((os.path.relpath(p, folder).replace(os.sep, "/"), p, st.st_size, st.st_mtime_ns))
            if len(out) >= FILES_MOST:
                return out
    return out


def _key_of(files):
    rows = sorted("%s|%d|%d" % (rel, size, mtime) for rel, _p, size, mtime in files)
    return hashlib.sha1(("\n".join(rows) + "\n" + "|".join(JOIN_TERMS)).encode("utf-8", "replace")).hexdigest()[:16]


IDENTITY_KEPT_S = 2.0           # one question looks at the folder several times: the look of a moment ago is used
_ident, _ident_lock = {}, threading.Lock()


def identity(folder):
    """The findings as they are on disk -> (key, number of files). The same key = the same findings."""
    folder = os.path.abspath(folder)
    with _ident_lock:
        kept = _ident.get(folder)
        if kept and IDENTITY_KEPT_S > 0 and time.time() - kept[0] < IDENTITY_KEPT_S:
            return kept[1], kept[2]
    files = _walk(folder)
    out = (_key_of(files), len(files))
    with _ident_lock:
        if len(_ident) > 64:
            _ident.clear()
        _ident[folder] = (time.time(),) + out
    return out


def _dir():
    d = os.path.join(family1.knowledge_dir(), "rea")
    os.makedirs(d, exist_ok=True)
    return d


def meta_file(key):
    return os.path.join(_dir(), key + ".json")


def index_file(key):
    return os.path.join(_dir(), key + ".sqlite")


def chat_file(key):
    return os.path.join(_dir(), "chat_%s.json" % key)


def done(folder):
    """What was read from these findings before, or None: {"hits", "at", "files", "folder", ...}."""
    try:
        key, n = identity(folder)
        with open(meta_file(key), encoding="utf-8") as fh:
            kept = json.load(fh)
        return kept if isinstance(kept, dict) and isinstance(kept.get("hits"), dict) and kept.get("files") == n else None
    except (OSError, ValueError):
        return None


def _indexed(key):
    return os.path.isfile(index_file(key)) and os.path.getsize(index_file(key)) > 0


def is_read(folder):
    """True when these findings (as they are on disk now) were read into the search index."""
    if not folder or not os.path.isdir(folder):
        return False
    kept = done(folder)
    return bool(kept) and _indexed(identity(folder)[0])


def join_hits(folder):
    """The lines that name the join columns, as read before: {term: [{"ref", "quote"}]}; {} when the findings were not read."""
    if not folder or not os.path.isdir(folder):
        return {}
    kept = done(folder)
    return dict(kept["hits"]) if kept else {}


def note_for_coder(folder):
    """One line for the Coder's card when findings were given but not read, else ""."""
    if not folder:
        return ""
    if not os.path.isdir(folder):
        return "The folder given for the REA findings does not exist any more (%s): the strategy was made without them." % folder
    if done(folder) is None:
        return ("REA findings were given for this analysis (%s) but have not been read: the REA agent on the start page reads them "
                "(\"Read the findings\"). The flow does not wait for that, so the strategy below was made without them." % folder)
    return ""


# ---------------------------------------------------------------------------------------------- reading, once
def _term_patterns():
    one = {t: re.compile(r"(?<![A-Za-z0-9_])%s(?![A-Za-z0-9_])" % re.escape(t), re.I) for t in JOIN_TERMS}
    every = re.compile(r"(?<![A-Za-z0-9_])(?:%s)(?![A-Za-z0-9_])" % "|".join(re.escape(t) for t in sorted(JOIN_TERMS, key=len, reverse=True)), re.I)
    return one, every


def _is_text(path):
    try:
        with open(path, "rb") as fh:
            head = fh.read(8192)
    except OSError:
        return None
    return b"\0" not in head


def _lines_of(path, cache_dir):
    """The lines of one file of the findings, or (None, why it was skipped)."""
    low = path.lower()
    if low.endswith(".pdf"):
        lines = core.References([], cache_dir)._pdf_lines(path)
        return (lines, "") if lines else (None, "a PDF that could not be turned into text")
    try:
        size = os.path.getsize(path)
    except OSError:
        return None, "could not be opened"
    if size > FILE_BYTES_MOST:
        return None, "larger than %d MB" % (FILE_BYTES_MOST // 1024 ** 2)
    text = _is_text(path)
    if text is None:
        return None, "could not be opened"
    if not text:
        return None, "not text (a binary file)"
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            return fh.read().splitlines(), ""
    except OSError:
        return None, "could not be opened"


def read(folder, progress=None, cache_dir=None):
    """Read the findings once. -> {"folder", "files", "hits", "at", "passages", "read_files", "skipped", "reused"}.
    Every file is opened one time; its passages go into the index and its lines that name a join column are kept.
    While no file of the folder changes, a second call reads nothing and returns what the first one found."""
    if not folder or not os.path.isdir(folder):
        raise ValueError("not a folder: %s" % folder)
    folder = os.path.abspath(folder)
    files = _walk(folder)
    key = _key_of(files)
    with _lock(key):
        kept = done(folder)
        if kept is not None and _indexed(key):
            return dict(kept, reused=True)
        t0 = time.time()
        total = sum(size for _r, _p, size, _m in files) or 1
        one, every = _term_patterns()
        found = {t: [] for t in JOIN_TERMS}             # per term: the first lines that name it, in file order (as the search did before)
        skipped, read_files, passages, seen_bytes = {}, 0, 0, 0
        tmp = index_file(key) + ".%d.tmp" % os.getpid()
        if os.path.exists(tmp):
            os.remove(tmp)
        con = sqlite3.connect(tmp)
        try:
            con.execute("PRAGMA journal_mode=OFF")
            con.execute("PRAGMA synchronous=OFF")
            con.execute("CREATE TABLE passage (id INTEGER PRIMARY KEY, file TEXT, line_from INTEGER, line_to INTEGER, text TEXT)")
            con.execute("CREATE TABLE meta (k TEXT PRIMARY KEY, v TEXT)")
            fts = has_fts()
            if fts:
                con.execute("CREATE VIRTUAL TABLE fts USING fts5(text, content='passage', content_rowid='id', tokenize='unicode61')")
            rows, last_say = [], 0.0
            for rel, path, size, _m in files:
                seen_bytes += size
                lines, why = _lines_of(path, cache_dir or os.path.join(_dir(), "_pdf_cache"))
                if lines is None:
                    skipped[why] = skipped.get(why, 0) + 1
                    continue
                read_files += 1
                for i, line in enumerate(lines):        # the join columns, in the same pass
                    if every.search(line):
                        for t, rx in one.items():
                            if len(found[t]) < HITS_PER_TERM * 4 and rx.search(line):
                                lo, hi = max(0, i - 1), min(len(lines), i + 2)
                                found[t].append({"ref": "%s:%d" % (path, i + 1), "quote": " ".join(x.strip() for x in lines[lo:hi] if x.strip())[:400]})
                for a in range(0, len(lines), PASSAGE_LINES):
                    text = "\n".join(lines[a:a + PASSAGE_LINES]).strip("\n")
                    if text.strip():
                        rows.append((rel, a + 1, min(len(lines), a + PASSAGE_LINES), text[:PASSAGE_CHARS]))
                if len(rows) >= 2000:
                    con.executemany("INSERT INTO passage (file, line_from, line_to, text) VALUES (?,?,?,?)", rows)
                    passages += len(rows)
                    rows = []
                if progress and time.time() - last_say >= 0.5:
                    last_say = time.time()
                    progress(core.progress_text(95.0 * seen_bytes / total, t0, "reading the REA findings: %s of %s files" % ("{:,}".format(read_files), "{:,}".format(len(files))),
                                                seen_bytes, total))
            if rows:
                con.executemany("INSERT INTO passage (file, line_from, line_to, text) VALUES (?,?,?,?)", rows)
                passages += len(rows)
            if progress:
                progress(core.progress_text(96.0, t0, "making the search index of %s passages" % "{:,}".format(passages)))
            if fts:
                con.execute("INSERT INTO fts (rowid, text) SELECT id, text FROM passage")
            con.execute("INSERT INTO meta (k, v) VALUES ('fts', ?)", ("1" if fts else "0",))
            con.commit()
        finally:
            con.close()
        hits = {}
        for t, lst in found.items():                    # short, specific lines first (tables and definitions), as before
            lst = sorted(lst, key=lambda h: len(h["quote"]))[:HITS_PER_TERM]
            if lst:
                hits[t] = lst
        out = {"folder": folder, "files": len(files), "hits": hits, "at": time.time(), "passages": passages, "read_files": read_files,
               "skipped": skipped, "fts": fts, "seconds": round(time.time() - t0, 1)}
        if _key_of(_walk(folder)) != key:               # a file changed while they were read: nothing is kept, the next call reads again
            os.remove(tmp)
            return dict(out, changed_while_reading=True)
        os.replace(tmp, index_file(key))
        with _ident_lock:
            _ident.pop(folder, None)
        from nvme_hier import loader as L
        L.write_json_atomic(meta_file(key), out, indent=1)
        if progress:
            progress("100% · the REA findings are read: {:,} files, {:,} passages".format(read_files, passages))
        return dict(out, reused=False)


def status(folder):
    """What the start page shows about a folder of findings."""
    folder = (folder or "").strip()
    if not folder:
        return {"folder": "", "exists": False, "read": False, "why": "no folder given"}
    if not os.path.isdir(folder):
        return {"folder": folder, "exists": False, "read": False, "why": "this folder does not exist on this computer"}
    key, n = identity(folder)
    kept = done(folder)
    read_ = bool(kept) and _indexed(key)
    out = {"folder": os.path.abspath(folder), "exists": True, "files": n, "read": read_, "questions_asked": sum(1 for t in chat(folder) if t.get("who") != "REA agent")}
    if kept:
        out.update(read_at=kept.get("at"), passages=kept.get("passages"), read_files=kept.get("read_files"), skipped=kept.get("skipped") or {},
                   join_terms_found=[t for t in JOIN_TERMS if t in kept["hits"]], join_terms_not_found=[t for t in JOIN_TERMS if t not in kept["hits"]],
                   seconds=kept.get("seconds"))
        if not read_:
            out["why"] = "these findings were read by an earlier version for the join columns only: read them once more to ask questions"
    else:
        out["why"] = "not read yet" if n else "the folder holds no files"
    return out


# ---------------------------------------------------------------------------------------------- searching
def words_of(text, most=12):
    """The words of a question worth looking for: names and identifiers, without the everyday words; in the order given."""
    out = []
    for w in re.findall(r"[A-Za-z0-9]+", str(text or "")):
        low = w.lower()
        if len(low) >= 2 and low not in STOP_WORDS and low not in out:
            out.append(low)
    return out[:most]


def search(folder, words, limit=PASSAGES_PER_SEARCH):
    """Passages of the findings for these words, best first: [{"id", "file", "lines", "line_from", "line_to", "text"}].
    Raises ValueError when the findings were not read."""
    if not is_read(folder):
        raise ValueError("the REA findings in %s have not been read yet: press \"Read the findings\" on the start page" % folder)
    toks = words_of(" ".join(words) if isinstance(words, (list, tuple)) else words, most=24)
    if not toks:
        return []
    key = identity(folder)[0]
    con = sqlite3.connect("file:%s?mode=ro" % index_file(key).replace("?", "%3f"), uri=True)
    try:
        fts = (con.execute("SELECT v FROM meta WHERE k='fts'").fetchone() or ["0"])[0] == "1" and has_fts()
        rows = []
        if fts:
            try:
                rows = con.execute("SELECT p.id, p.file, p.line_from, p.line_to, p.text FROM fts JOIN passage p ON p.id = fts.rowid "
                                   "WHERE fts MATCH ? ORDER BY bm25(fts) LIMIT ?", (" OR ".join("%s*" % t for t in toks), int(limit))).fetchall()
            except sqlite3.Error:
                rows, fts = [], False
        if not fts:
            score = " + ".join("(instr(lower(text), ?) > 0)" for _ in toks)
            rows = con.execute("SELECT id, file, line_from, line_to, text FROM (SELECT id, file, line_from, line_to, text, (%s) AS s FROM passage) "
                               "WHERE s > 0 ORDER BY s DESC, id LIMIT ?" % score, toks + [int(limit)]).fetchall()
    finally:
        con.close()
    return [{"id": r[0], "file": r[1], "lines": "%d-%d" % (r[2], r[3]), "line_from": r[2], "line_to": r[3], "text": r[4]} for r in rows]


def has_quote(folder, ref, quote):
    """True when `quote` stands in the file `ref` ("path:line") of these findings. Only that one file is opened."""
    path, _, line = (ref or "").rpartition(":")
    if not path or not line.isdigit():
        path, line = ref or "", ""
    if not folder or not path:
        return False
    full = path if os.path.isabs(path) else os.path.join(folder, path)
    try:
        root, full = os.path.realpath(folder), os.path.realpath(full)
        if os.path.commonpath([root, full]) != root or not os.path.isfile(full):
            return False
    except (OSError, ValueError):
        return False
    lines, _why = _lines_of(full, os.path.join(_dir(), "_pdf_cache"))
    q = core.norm(quote)[:160]
    if not lines or not q:
        return False
    if line.isdigit():
        i = int(line) - 1
        if q in core.norm(" ".join(lines[max(0, i - 3):i + 4])):
            return True
    return q in core.norm(" ".join(lines))


# ---------------------------------------------------------------------------------------------- the conversation, kept
def chat(folder):
    """The questions and answers about these findings, oldest first (kept on disk; they come back when the page opens)."""
    try:
        with open(chat_file(identity(folder)[0]), encoding="utf-8") as fh:
            d = json.load(fh)
        return d if isinstance(d, list) else []
    except (OSError, ValueError):
        return []


def _say(folder, entries):
    from nvme_hier import loader as L
    key = identity(folder)[0]
    with _lock("chat:" + key):
        turns = chat(folder) + entries
        L.write_json_atomic(chat_file(key), turns[-CHAT_TURNS_KEPT:], indent=1)
        return turns[-CHAT_TURNS_KEPT:]


# ---------------------------------------------------------------------------------------------- asking
def instruction():
    return prompts.load("rea_agent")


def _for_model(passages):
    return [{"n": i, "file": p["file"], "lines": p["lines"], "text": p["text"][:PASSAGE_TEXT_FOR_MODEL]} for i, p in enumerate(passages)]


def _checked(ans, passages):
    """The sources of an answer that really stand in their passage -> (kept, number dropped)."""
    kept, dropped = [], 0
    for s in ans.get("sources") or []:
        if not isinstance(s, dict):
            dropped += 1
            continue
        n, quote = s.get("passage"), str(s.get("quote") or "").strip()
        p = passages[n] if isinstance(n, int) and not isinstance(n, bool) and 0 <= n < len(passages) else None
        if p is None or not core.norm(quote) or core.norm(quote) not in core.norm(p["text"]):
            dropped += 1
            continue
        if not any(k["file"] == p["file"] and k["quote"] == quote for k in kept):
            kept.append({"file": p["file"], "lines": p["lines"], "quote": quote[:600]})
    return kept, dropped


def ask(engine, folder, question, history=None, asker="admin", by=None, save=True):
    """One question about the findings. -> {"answer", "sources": [{"file", "lines", "quote"}], "producer", "searched", "dropped"}.
    The model sees only passages the program found for the question's words; it may ask for other words twice; every
    quote is checked against its passage by code and one that is not there is dropped and said so."""
    question = (question or "").strip()
    if not question:
        raise ValueError("write a question first")
    if not is_read(folder):
        raise ValueError("the REA findings in %s have not been read yet: press \"Read the findings\" on the start page" % folder)
    folder = os.path.abspath(folder)
    key = identity(folder)[0]
    kept = done(folder) or {}
    history = history if history is not None else [{"who": t.get("who"), "text": str(t.get("text") or "")[:1200]} for t in chat(folder)]
    searched = words_of(question)
    passages = search(folder, searched)
    ans, producer = None, "the program (no model was asked)"
    for rnd in range(MAX_ROUNDS):
        ctx = {"question": question, "asked_by": asker, "passages": _for_model(passages), "searched": list(searched),
               "files_in_the_findings": {"files": kept.get("read_files"), "passages": kept.get("passages")},
               "conversation": history[-HISTORY_TURNS:], "rounds_left_for_search_more": MAX_ROUNDS - 1 - rnd}

        def standin():
            if not passages:
                return {"answer": "", "sources": [], "search_more": []}
            lines = ["No model is connected, so nobody read your question. These are the passages the program found for the words %s:" % ", ".join(searched)]
            src = []
            for i, p in enumerate(passages[:5]):
                first = next((x.strip() for x in p["text"].splitlines() if x.strip()), "")
                lines.append("- %s, lines %s: %s" % (p["file"], p["lines"], first[:200]))
                src.append({"passage": i, "quote": first[:200]})
            return {"answer": "\n".join(lines), "sources": src, "search_more": []}
        try:
            ans, producer, _ = engine.runner.ask("rea_%s" % key, "rea_agent", instruction(), json.dumps(ctx, default=str)[:150000], SHAPE, "answer", standin)
        except RuntimeError as e:
            ans, producer = {"answer": "No answer: %s" % e, "sources": []}, "nobody"
            break
        more = [w for w in (ans.get("search_more") or []) if isinstance(w, str) and w.strip()][:6] if isinstance(ans, dict) else []
        new_words = [w for w in words_of(" ".join(more)) if w not in searched]
        if not new_words or rnd == MAX_ROUNDS - 1:
            break
        searched += new_words
        have = {p["id"] for p in passages}
        passages += [p for p in search(folder, new_words) if p["id"] not in have]
    sources, dropped = _checked(ans if isinstance(ans, dict) else {}, passages)
    text = str((ans or {}).get("answer") or "").strip()[:8000]
    if not passages:
        text = ("The findings do not name any of the words searched for (%s), so nothing can be said from them. "
                "Try the names as they stand in the decompiled code (a function, a field, a constant)." % ", ".join(searched))
        sources, dropped = [], 0
    elif not text:
        text = "The model gave no answer. The program found %d passage%s for the words %s." % (len(passages), "" if len(passages) == 1 else "s", ", ".join(searched))
    if dropped:
        text += ("\n\n(%d quoted source%s the model gave could not be found in the passage named and %s left out: "
                 "what rested only on %s is not confirmed by the findings.)" % (dropped, "" if dropped == 1 else "s", "was" if dropped == 1 else "were", "it" if dropped == 1 else "them"))
    out = {"answer": text, "sources": sources, "producer": producer, "searched": searched, "dropped": dropped, "passages_found": len(passages)}
    if save:
        now = time.time()
        _say(folder, [{"who": asker, "by": by or asker, "at": now, "text": question},
                      {"who": "REA agent", "by": producer, "at": time.time(), "text": text, "sources": sources, "searched": searched, "dropped": dropped}])
    return out


def ask_for_family2(engine, project, question, words=None, limit=6):
    """A question of a Family 2 agent to the REA agent. -> {"available", "why"?, "passages": [{"file", "lines", "text"}], "searched"}.
    The passages the program finds are given back with their sources at once (no second model call: the asking agent
    reads them itself); the question is written into the findings' conversation as asked by Family 2."""
    folder = (project or {}).get("rea") or ""
    if not folder:
        return {"available": False, "why": "no REA findings were given for this analysis"}
    if not os.path.isdir(folder):
        return {"available": False, "why": "the folder of the REA findings does not exist any more: %s" % folder}
    if not is_read(folder):
        return {"available": False, "why": "the REA findings in %s have not been read yet (the REA agent on the start page reads them)" % folder}
    searched = words_of(" ".join(words) if words else question, most=16)
    found = search(folder, searched, limit) if searched else []
    passages = [{"file": p["file"], "lines": p["lines"], "text": p["text"][:PASSAGE_TEXT_FOR_MODEL]} for p in found]
    _say(folder, [{"who": "Family 2", "by": "Family 2 (the tree builder's agent)", "at": time.time(), "text": str(question or "")[:2000]},
                  {"who": "REA agent", "by": "the program (passages found by search, read by the asking agent)", "at": time.time(),
                   "text": ("%d passage%s given for the words %s." % (len(passages), "" if len(passages) == 1 else "s", ", ".join(searched))) if passages
                   else "The findings name none of the words %s." % ", ".join(searched),
                   "sources": [{"file": p["file"], "lines": p["lines"], "quote": next((x.strip() for x in p["text"].splitlines() if x.strip()), "")[:200]} for p in passages],
                   "searched": searched, "dropped": 0}])
    return {"available": True, "passages": passages, "searched": searched, "folder": os.path.abspath(folder)}
