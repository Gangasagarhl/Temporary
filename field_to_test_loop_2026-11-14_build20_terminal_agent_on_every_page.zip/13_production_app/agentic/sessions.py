"""The terminal sessions the application holds, and what was said in them.

(owner, 2026-11-13: "terminal with holding sessions and its name as stateful at the backend, storing the previous
session's conversation".) A session is one conversation of one agent with the model through a terminal program. The
program keeps the conversation on its side under a number of its own; here the application keeps, in a file of its own
(db/sessions.sqlite): the session's name, whom it belongs to (scope + agent), the program, the model, the program's
number for it, and EVERY turn: what was asked and what came back, in order. So a server that is started again finds
its sessions and continues them, and the pages can show a conversation without asking the program.

Texts are stored compressed (a question with its context can be 180,000 characters; a wide file has hundreds of them).
"""
import json
import os
import sqlite3
import threading
import time
import zlib

SCHEMA = """
CREATE TABLE IF NOT EXISTS session (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  scope TEXT NOT NULL,            -- whom it serves: "run:<number>" (a run of the agents) or "app:<part>"
  agent TEXT NOT NULL,            -- the agent's own name inside that scope
  name TEXT NOT NULL,             -- the name shown to people and given to the terminal program
  program TEXT NOT NULL,          -- "opencode"
  model TEXT NOT NULL,
  terminal_id TEXT,               -- the program's own number for the session
  folder TEXT,
  part INTEGER NOT NULL DEFAULT 1,-- 1, or 2.. when the conversation went on in a new session
  state TEXT NOT NULL DEFAULT 'open',   -- open | closed
  why_closed TEXT,
  turns INTEGER NOT NULL DEFAULT 0,
  size_tokens INTEGER NOT NULL DEFAULT 0,   -- what the session held after its last turn
  created TEXT NOT NULL,
  updated TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS session_owner ON session (scope, agent, id);
CREATE TABLE IF NOT EXISTS turn (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session INTEGER NOT NULL,
  n INTEGER NOT NULL,
  asked BLOB,
  answered BLOB,
  ok INTEGER NOT NULL DEFAULT 1,
  problem TEXT,
  producer TEXT,
  seconds REAL,
  tokens TEXT,
  at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS turn_session ON turn (session, n);
"""

KEEP_CHARS = 400000             # the longest text kept of one question or one answer


def _now():
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _pack(text):
    t = "" if text is None else str(text)
    cut = len(t) > KEEP_CHARS
    return zlib.compress((t[:KEEP_CHARS] + ("\n[... %d more characters not kept]" % (len(t) - KEEP_CHARS) if cut else "")).encode("utf-8", "replace"), 6)


def _unpack(blob):
    if blob is None:
        return ""
    try:
        return zlib.decompress(blob).decode("utf-8", "replace")
    except (zlib.error, TypeError):
        return ""


class Sessions:
    def __init__(self, path):
        self.path = path
        d = os.path.dirname(os.path.abspath(path))
        os.makedirs(d, exist_ok=True)
        self._locks, self._locks_lock = {}, threading.Lock()
        self._write = threading.Lock()
        with self._conn() as c:
            c.executescript(SCHEMA)

    def _conn(self):
        c = sqlite3.connect(self.path, timeout=30)
        c.row_factory = sqlite3.Row
        return c

    def _all(self, sql, args=()):
        c = self._conn()
        try:
            return [dict(r) for r in c.execute(sql, args).fetchall()]
        finally:
            c.close()

    def _exec(self, sql, args=()):
        with self._write:
            c = self._conn()
            try:
                cur = c.execute(sql, args)
                c.commit()
                return cur.lastrowid
            finally:
                c.close()

    # ---- one conversation at a time per session
    def lock(self, scope, agent):
        """The lock of one agent's conversation: two calls never write into the same session at the same time."""
        with self._locks_lock:
            return self._locks.setdefault((str(scope), str(agent)), threading.Lock())

    # ---- holding
    def open_for(self, scope, agent, program, model):
        """The open session of this agent with this program and model, or None."""
        rows = self._all("SELECT * FROM session WHERE scope=? AND agent=? AND state='open' ORDER BY id DESC", (str(scope), str(agent)))
        for r in rows:
            if r["program"] == program and r["model"] == model and r["terminal_id"]:
                return r
        return None

    def last_part(self, scope, agent):
        r = self._all("SELECT MAX(part) AS p FROM session WHERE scope=? AND agent=?", (str(scope), str(agent)))
        return int((r[0]["p"] if r else 0) or 0)

    def begin(self, scope, agent, name, program, model, folder=None, part=1):
        t = _now()
        return self._exec("INSERT INTO session (scope, agent, name, program, model, folder, part, created, updated) VALUES (?,?,?,?,?,?,?,?,?)",
                          (str(scope), str(agent), str(name)[:200], program, model, folder, int(part), t, t))

    def set_terminal(self, sid, terminal_id):
        self._exec("UPDATE session SET terminal_id=?, updated=? WHERE id=?", (terminal_id, _now(), sid))

    def close(self, sid, why):
        self._exec("UPDATE session SET state='closed', why_closed=?, updated=? WHERE id=?", (str(why)[:300], _now(), sid))

    def close_others(self, scope, agent, keep_id, why):
        """An agent holds one open session: the earlier open ones (another model, another program) are closed, kept to read."""
        self._exec("UPDATE session SET state='closed', why_closed=?, updated=? WHERE scope=? AND agent=? AND state='open' AND id!=?",
                   (str(why)[:300], _now(), str(scope), str(agent), keep_id))

    def add_turn(self, sid, asked, answered, ok=True, problem=None, producer=None, seconds=None, tokens=None, size_tokens=None):
        with self._write:
            c = self._conn()
            try:
                n = (c.execute("SELECT COALESCE(MAX(n), 0) FROM turn WHERE session=?", (sid,)).fetchone()[0] or 0) + 1
                c.execute("INSERT INTO turn (session, n, asked, answered, ok, problem, producer, seconds, tokens, at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                          (sid, n, _pack(asked), _pack(answered), 1 if ok else 0, (str(problem)[:500] if problem else None), producer,
                           seconds, json.dumps(tokens) if tokens is not None else None, _now()))
                if size_tokens is None:
                    c.execute("UPDATE session SET turns=?, updated=? WHERE id=?", (n, _now(), sid))
                else:
                    c.execute("UPDATE session SET turns=?, size_tokens=?, updated=? WHERE id=?", (n, int(size_tokens), _now(), sid))
                c.commit()
                return n
            finally:
                c.close()

    # ---- reading
    def get(self, sid):
        r = self._all("SELECT * FROM session WHERE id=?", (sid,))
        return r[0] if r else None

    def listing(self, scope=None, limit=200):
        if scope is None:
            return self._all("SELECT * FROM session ORDER BY updated DESC, id DESC LIMIT ?", (int(limit),))
        return self._all("SELECT * FROM session WHERE scope=? ORDER BY id LIMIT ?", (str(scope), int(limit)))

    def of_agent(self, scope, agent):
        return self._all("SELECT * FROM session WHERE scope=? AND agent=? ORDER BY id", (str(scope), str(agent)))

    def conversation(self, sid, max_chars=None):
        """Every turn of one session in order: [{n, asked, answered, ok, problem, producer, seconds, tokens, at}]."""
        out = []
        for r in self._all("SELECT * FROM turn WHERE session=? ORDER BY n", (sid,)):
            asked, answered = _unpack(r["asked"]), _unpack(r["answered"])
            row = {"n": r["n"], "asked": asked, "answered": answered, "asked_chars": len(asked), "answered_chars": len(answered),
                   "ok": bool(r["ok"]), "problem": r["problem"], "producer": r["producer"], "seconds": r["seconds"],
                   "tokens": json.loads(r["tokens"]) if r["tokens"] else None, "at": r["at"]}
            if max_chars and len(asked) > max_chars:
                row["asked"], row["asked_cut"] = asked[:max_chars], True
            if max_chars and len(answered) > max_chars:
                row["answered"], row["answered_cut"] = answered[:max_chars], True
            out.append(row)
        return out

    def recent_turns(self, scope, agent, limit=6):
        """The agent's last answered turns over all its sessions, oldest first: [{n, name, asked, answered}]."""
        rows = self._all("SELECT t.n, t.asked, t.answered, s.name FROM turn t JOIN session s ON s.id = t.session "
                         "WHERE s.scope=? AND s.agent=? AND t.ok=1 ORDER BY t.id DESC LIMIT ?", (str(scope), str(agent), int(limit)))
        return [{"n": r["n"], "name": r["name"], "asked": _unpack(r["asked"]), "answered": _unpack(r["answered"])} for r in reversed(rows)]

    def counts(self):
        r = self._all("SELECT COUNT(*) AS sessions, COALESCE(SUM(turns), 0) AS turns, SUM(state='open') AS open FROM session")
        return {"sessions": r[0]["sessions"], "turns": r[0]["turns"], "open": r[0]["open"] or 0}

    # ---- forgetting
    def delete_scope(self, scope):
        """Remove everything of one owner (a deleted run). -> the terminal program's numbers of its sessions."""
        ids = self._all("SELECT id, terminal_id FROM session WHERE scope=?", (str(scope),))
        with self._write:
            c = self._conn()
            try:
                c.execute("DELETE FROM turn WHERE session IN (SELECT id FROM session WHERE scope=?)", (str(scope),))
                c.execute("DELETE FROM session WHERE scope=?", (str(scope),))
                c.commit()
            finally:
                c.close()
        with self._locks_lock:
            for k in [k for k in self._locks if k[0] == str(scope)]:
                self._locks.pop(k, None)
        return [r["terminal_id"] for r in ids if r["terminal_id"]]
