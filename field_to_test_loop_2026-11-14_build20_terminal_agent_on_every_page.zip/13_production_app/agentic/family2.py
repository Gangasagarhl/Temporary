"""Family 2 — Hierarchy: how the CSVs connect into one tree, with evidence, approved by the admin, tested, built.

Steps of a run (kind "family2"), in order:
  last_strategy   if a strategy was approved before for this file format: REVIEW "used last time; proceed?"
                  (approve = reuse it and skip the research and the Coder)
  (REA is not a step since 14 November 2026: the REA agent on the start page reads the decompiled findings once and
   answers questions about them; the Coder below takes what it found about the join columns, without waiting)
  collect         the Information collector: the reference documents, Family 1's approved dictionaries, and the
                  sources that need a connector (IMS, JIRA, the web), each reported as reachable or not
  coder           the Coder's strategy: for each join, the columns used, the rule in plain words and the evidence.
                  REVIEW "Admin <name>, need review" (approve stores it as the strategy of this file format)
  build_ask       REVIEW "shall I build the hierarchy?" with the sizes and how memory is kept low; when a tree was built
                  before from these same files (the same files on disk: device and inode, same size, not changed since),
                  it says so and reuses it (the admin can still ask for a new build)
  build           the Builder: loads the five files and builds the tree on disk (resumable), or reuses that tree
  slice_test      the Code tester: 5 to 10 random windows of the real data rebuilt on their own; every parent fully
                  inside a window must hold as many children as the analyzer says, and the same children as the full tree
  breaker         the Breaker: the hardest windows (resends after a Nak, rows that joined nothing, the start and end of
                  the file, the busiest moment) through the same test
  independent     the Independent tester: checks the built tree with the column meanings only (same PSN, same
                  requester and tag, address inside the range, same queue and command id) on a sample of every level
"""
import hashlib
import json
import os
import random
import sqlite3
import sys
import time

from . import core, family1, join_rules as JR, rea_agent as RA

APP = family1.APP
sys.path.insert(0, APP)
sys.path.insert(0, os.path.join(APP, "app"))
from nvme_hier import builder as B, columns as C, loader as L, osfile as OSF   # noqa: E402

JOIN_TERMS = RA.JOIN_TERMS       # the names of the join columns (kept in the REA agent, which collects their lines in its one pass)

# what the current builder does, rule by rule: written in agentic/join_rules.py, where each rule is tied to the lines of code that apply it
BUILTIN = JR.as_strategy()
BUILDER_CODE = os.path.join(APP, "nvme_hier", "builder.py")

COUNT_CHECKS = [("lnk", "n_packets", "pkt", "link"), ("spl", "n_links", "lnk", "split"),
                ("ntx", "n_links_splits", None, "nvme_transaction"), ("cmd", "n_ntx", "ntx", "nvme_command")]


def project_format(project):
    files = family1.inventory(project.get("folder"))
    keys = sorted("%s:%s" % (f["level"], f["format_key"]) for f in files if f["level"])
    return hashlib.sha1("|".join(keys).encode()).hexdigest()[:12], files


def strategy_dir(fmt):
    d = os.path.join(family1.knowledge_dir(), "strategies", fmt)
    os.makedirs(d, exist_ok=True)
    return d


def last_strategy(fmt):
    try:
        d = strategy_dir(fmt)
        vs = sorted((int(x[1:-5]), x) for x in os.listdir(d) if x.startswith("v") and x.endswith(".json") and x[1:-5].isdigit())
        with open(os.path.join(d, vs[-1][1]), encoding="utf-8") as fh:
            st = json.load(fh) if vs else None
        return st if isinstance(st, dict) else None
    except (OSError, ValueError, IndexError):    # a damaged strategy counts as none: the admin is asked again
        return None


def break_limit(cfg):
    """The share of rows, in percent, above which a rule counts as not followed (a project setting); anything else than a number from 0 to 100 reads as the default."""
    v = ((cfg or {}).get("agentic") or {}).get("join_break_limit_percent") if isinstance((cfg or {}).get("agentic") or {}, dict) else None
    if isinstance(v, bool) or not isinstance(v, (int, float)) or v != v or not 0 <= v <= 100:
        return float(JR.BREAK_LIMIT_PERCENT)
    return float(v)


def merge_answer(code_joins, ans):
    """The rules as the code applies them, with what the agent said about each: only its evidence and its doubt are taken, whatever else its answer holds."""
    given = ans.get("joins") if isinstance(ans, dict) and isinstance(ans.get("joins"), list) else []
    said = {str(j.get("join") or j.get("id")): j for j in given if isinstance(j, dict)}
    out = []
    for c in code_joins:
        a = said.get(c["join"]) or said.get(c["id"]) or {}
        ev = a.get("evidence") if isinstance(a.get("evidence"), list) else []
        out.append(dict(c, evidence=[e for e in ev if isinstance(e, dict)], agent_note=str(a.get("note") or "")[:1500]))
    return out


def written_reason(edits):
    """The admin's written reason, or nothing if what was sent is not words; kept short in the record."""
    r = edits.get("accept_reason") if isinstance(edits, dict) else None
    if not isinstance(r, str) or not any(ch.isalnum() for ch in r):
        return ""
    edits["accept_reason"] = r = r.strip()[:4000]
    return r


def same_code(joins):
    """False when the code that applies a rule changed after this page was made: the admin would be ticking words that no longer describe the program."""
    now = {j["id"]: j["code"]["sha"] for j in JR.as_strategy()}
    return all(not isinstance(j, dict) or (j.get("code") or {}).get("sha") == now.get(j.get("id")) for j in joins or [])


def code_version():
    return hashlib.sha1(open(BUILDER_CODE, "rb").read()).hexdigest()[:12]


def steps(params, project):
    s = [("last_strategy", "Strategy used last time for this file format", "Director", True),
         ("collect", "Information collector: references, Family 1's dictionaries, IMS, JIRA, web", "Information collector", False),
         ("coder", "Coder: the strategy with its evidence", "Coder", True),
         ("build_ask", "Builder: ask before building", "Builder", True),
         ("build", "Builder: load the files and build the tree on disk", "Builder", False),
         ("slice_test", "Code tester: 5 to 10 random windows of the real data", "Code tester", False),
         ("breaker", "Breaker: the hardest windows of the data", "Breaker", False),
         ("independent", "Independent tester: the tree checked with the column meanings only", "Independent tester", True)]
    return [{"key": k, "title": t, "family": "2", "agent": a, "review": r} for k, t, a, r in s]


KEPT_TESTS = ("slice_test", "breaker", "independent")


def run_step(ctx):
    key = ctx.step["key"]
    if key in KEPT_TESTS:
        # an analysis opened again (owner, 2026-11-12: "no need of recomputing the computed again"): a test of the tree is
        # kept when the tree is the one it checked before: the build step used that same upload again, built from the
        # same files on disk, unchanged. A new build, or no earlier result, runs the test.
        old = core.jload(ctx.step.get("output"), {}) or {}
        b = ctx.output_of("build")
        if old.get("upload_id") and b.get("reused") and old["upload_id"] == b.get("upload_id") and not ctx.input.get("comments"):
            return core.Result(old, skip="kept: the tree is the one this test checked before (upload %s, built from the same files, unchanged), so it was not run again" % old["upload_id"])
    return globals()["_" + key](ctx)


# ---------------------------------------------------------------------------------------------- REA: not a step any more
# (owner, 2026-11-14: "let's keep the rea out, because it is going to consume a lot of time") the REA findings are read
# and asked about by the REA agent on the start page (agentic/rea_agent.py). These three names stay for their callers.
def rea_identity(folder):
    return RA.identity(folder)


def rea_file(key):
    return RA.meta_file(key)


def rea_done(folder):
    return RA.done(folder)


# ---------------------------------------------------------------------------------------------- research and strategy
def _last_strategy(ctx):
    fmt, files = project_format(ctx.project)
    st = last_strategy(fmt)
    if not st:
        return core.Result({"format": fmt}, skip="no strategy was approved before for this file format (%s)" % fmt)
    if ctx.input.get("comments"):
        # the admin asked for changes: the research and the Coder run again, with the admin's words
        return core.Result({"format": fmt, "not_reused": st["version"]},
                           skip="strategy v%d not reused: the admin asked for the research again (%s)" % (st["version"], ctx.input["comments"][-1]))
    admin = ctx.project.get("admin") or "admin"
    eff = _eff(ctx.engine, ctx.project)
    joins = _with_notes(st, eff)               # always the rules the code applies now, with the settings this analysis builds with
    need = JR.needs_check(st.get("verified"), eff)
    body = ["**Admin %s, need review.** Strategy version %d was approved by %s on %s for this same file format (five files, same headers)." % (
        admin, st["version"], st.get("approved_by", "?"), time.strftime("%Y-%m-%d %H:%M", time.localtime(st.get("approved_at") or 0))),
        "", "Approve to proceed with it: the research and the Coder are skipped, and the tests and the build use it.",
        "Ask for changes to start the research again."]
    if need:
        body += ["", "**%d of the %d rules need your check** before this strategy can be used again: %s." % (len(need), len(joins), "; ".join("%s (%s)" % (JR.BY_ID[i]["title"], why) for i, why in need.items()))]
    body += _strategy_md(joins)
    return core.Result({"format": fmt, "strategy": st, "joins": joins, "needs_check": need}, review={"title": "Proceed with strategy v%d?" % st["version"], "body": "\n".join(body),
                                                                "data": {"strategy": st, "joins": joins, "needs_check": need, "verified": st.get("verified") or {}}})


def _rea(ctx):
    """A run started before 14 November 2026 can still hold this step: it never stops the flow and reads nothing."""
    return core.Result({}, skip="REA is not a step of the flow any more (14 November 2026): the REA agent is on the start page")


def _rea_search(ctx):
    return _rea(ctx)


def _collect(ctx):
    refs = family1.refs_of(ctx)
    found = {t: refs.search(t, limit=3) for t in JOIN_TERMS} if refs.folders else {}
    found = {t: h for t, h in found.items() if h}
    dicts = {}
    for lv in ("packets", "link", "split", "nvme_transaction", "nvme_command"):
        for d in family1.dictionaries_for_level(lv)[:1]:
            dicts[lv] = {r["column"]: r["meaning"] for r in d["columns"] if any(t.lower() in r["column"].lower() for t in JOIN_TERMS)}
    conn = (ctx.engine.cfg.get("agentic") or {}).get("connectors") or {}
    sources = [{"source": "reference documents", "reachable": bool(refs.folders), "found": len(found)},
               {"source": "Family 1 dictionaries", "reachable": bool(dicts), "found": sum(len(v) for v in dicts.values())}]
    for name in ("IMS", "JIRA"):
        sources.append({"source": name, "reachable": bool(conn.get(name.lower())), "found": 0,
                        "note": "" if conn.get(name.lower()) else "not connected on this machine (set agentic.connectors.%s in the configuration)" % name.lower()})
    # the web: searched by an agent, every page it cites fetched by the program and its quote checked
    runner = ctx.engine.runner
    web_hits, producer = {}, None
    if runner.can_search_web():
        ctx.progress("Information collector: searching the web for how the five levels are joined")
        ans, producer, _ = runner.ask(ctx.run["id"], "collector_web", WEB_COLLECT_INSTRUCTION, {"join_terms": JOIN_TERMS, "joins": [j["join"] for j in BUILTIN]},
                                      WEB_COLLECT_SHAPE, "claims", lambda: {"claims": []}, web=True)
        checked = core.check_claims([{"text": c.get("text", ""), "source": c.get("source") or {}, "term": c.get("term")} for c in ans.get("claims") or []],
                                    web=runner.web_sources())
        ctx.evidence(checked)
        for c in checked:
            if c["verified"] and (c["source"] or {}).get("kind") == "web":
                web_hits.setdefault(c.get("term") or "general", []).append({"ref": c["source"]["ref"], "quote": c["source"]["quote"][:300], "kind": "web"})
        sources.append({"source": "web", "reachable": True, "found": sum(len(v) for v in web_hits.values()),
                        "note": "%d page quote(s) checked by the program, %d not found on their page" % (
                            sum(1 for c in checked if c["verified"]), sum(1 for c in checked if not c["verified"]))})
    else:
        sources.append({"source": "web", "reachable": False, "found": 0,
                        "note": "not used: %s" % ("the agents may not search the web (Settings)" if not runner.web_enabled else
                                                  "the stand-in (no model) cannot search the web")})
    return core.Result({"references": found, "dictionaries": dicts, "sources": sources, "web": web_hits}, producer=producer)


WEB_COLLECT_INSTRUCTION = """You are the Information collector of Family 2. Search the web for how a PCIe / NVMe protocol
analyzer's records connect across levels: packets (TLPs and DLLPs: PSN, Ack/Nak sequence numbers) -> link transactions
-> split transactions (non-posted requests and completions matched by Requester ID and Tag) -> NVMe transactions
(doorbell writes, queue entries at addresses) -> NVMe commands (submission queue id and command id). Prefer the PCI
Express and NVM Express specifications, the Teledyne LeCroy documentation and other authoritative pages. For each fact
give: term (one of CONTEXT's join_terms), text (the fact in one plain sentence) and source (kind "web", ref = the page
URL, quote = words copied exactly from that page). At most 10 facts."""
WEB_COLLECT_SHAPE = '{"claims": [{"term": "<a join term>", "text": "...", "source": {"kind": "web", "ref": "<URL>", "quote": "<copied exactly>"}}]}'


def _eff(engine, project):
    from . import join_workbench as JW
    return JW.effective(engine, project)


def _with_notes(st, settings=None):
    """The rules as the code applies them now, each with what the agent said about it when this strategy was made (an older strategy held the agent's rewording)."""
    old = {j.get("id") or j.get("join"): j for j in (st.get("joins") if isinstance(st.get("joins"), list) else []) if isinstance(j, dict)}
    return [dict(j, evidence=(old.get(j["id"]) or old.get(j["join"]) or {}).get("evidence") or [], agent_note=(old.get(j["id"]) or {}).get("agent_note") or "") for j in JR.as_strategy(settings)]


def _strategy_md(joins):
    out = []
    for i, j in enumerate(joins, 1):
        out += ["", "**%d. %s** (columns: %s)" % (i, j["join"], ", ".join(j["columns"])), "", j["rule"], "", "Check: " + j["check"]]
        if j.get("when_broken"):
            out += ["", "A row that does not follow it: " + " ".join(j["when_broken"])]
        for e in j.get("evidence") or []:
            out.append("- evidence (%s%s): %s — `%s`" % (e["kind"], "" if e.get("verified") else ", NOT VERIFIED", e["quote"][:200], e["ref"]))
    return out


CODER_INSTRUCTION = """You are the Coder of Family 2. You get the current strategy for joining five analyzer CSVs into one
tree (packets -> link transactions -> split transactions -> NVMe transactions -> NVMe commands), the evidence the
collectors found (reference lines, REA lines, web pages already checked, Family 1's column meanings) and the admin's
comments. Each rule is exactly what the tree builder's code does, so you cannot change its wording: a rewritten sentence would
change nothing the code does. For each join, copy its "join" name and attach evidence by copying an item given in CONTEXT (kind
"document", "rea" or "web", ref and quote exactly as given), or a page you found yourself on the web (kind "web", see THE WEB).
If the evidence disagrees with the rule, or a case is not covered, say so plainly in "note": the admin decides. Otherwise leave "note" empty.
Address every admin comment in "answers_to_admin"."""
CODER_SHAPE = '{"joins": [{"join": "...", "note": "<only if the evidence disagrees or a case is not covered>", "evidence": [{"kind": "document", "ref": "<file:line>", "quote": "<copied>"}]}], "answers_to_admin": ["..."]}'


class _RefsWithRea:
    """The reference documents, and for a quote from the REA findings the one file it names (the folder is not read)."""

    def __init__(self, refs, rea_folder):
        self.refs, self.rea_folder = refs, rea_folder

    def has_quote(self, ref, quote):
        return self.refs.has_quote(ref, quote) or bool(self.rea_folder and RA.has_quote(self.rea_folder, ref, quote))


def _coder(ctx):
    # the REA evidence comes from the REA agent's reading of the findings (start page), done once and kept; nothing of the
    # findings is read here. A run of before 14 November 2026 keeps what its own REA step found.
    # They are optional (owner, 2026-11-14: "this should not be the required, but it can be optional"): looked at only when
    # the admin ticked the box at the step before stage 2 ("f1_gate", see admin_ask.rea_wanted); otherwise not at all.
    from . import admin_ask
    kept = ctx.project.get("rea") or ""
    old_hits = ctx.output_of("rea").get("hits") or ctx.output_of("rea_search").get("hits")
    alone = ctx.run.get("kind") == "family2"          # Family 2 started alone has no such step: its start request says it
    wanted = admin_ask.rea_wanted(ctx.output_of(admin_ask.GATE)) or bool((core.jload(ctx.run.get("params"), {}) or {}).get("use_rea"))
    rea_folder = kept if (wanted or old_hits) else ""
    rea = old_hits or RA.join_hits(rea_folder)
    rea_note = "" if rea else RA.note_for_coder(rea_folder)
    if kept and not rea_folder:
        rea_note = ("REA findings are kept with this analysis (%s) but were not asked for %s, so the strategy below was made "
                    "without them. They are optional: to have them quoted, %s." % (
                        kept, "when Family 2 was started" if alone else "at the step before stage 2",
                        "start Family 2 with them" if alone else "open the analysis again at that step and tick the box"))
    col = ctx.output_of("collect")
    refs_hits = col.get("references") or {}
    comments = list(ctx.input.get("comments") or [])
    # what the admin said when declining the strategy used last time is part of what the Coder must answer
    ls = ctx.engine.store.one("SELECT input FROM step WHERE run=? AND key='last_strategy'", (ctx.run["id"],))
    comments += [c for c in (core.jload((ls or {}).get("input"), {}) or {}).get("comments") or [] if c and c not in comments]
    joins = JR.as_strategy(_eff(ctx.engine, ctx.project))
    from . import join_workbench as JW            # what the admin wrote about a rule's logic on page 2 is part of what the Coder must answer
    notes = JW.load(ctx.engine, ctx.project["id"])["notes"]
    comments += ["About the rule '%s': %s" % (JR.BY_ID[k]["title"], v.get("text")) for k, v in notes.items() if k in JR.BY_ID and isinstance(v, dict) and v.get("text")]
    for k in JR.BY_ID:                              # the admin's own wording of a rule: the research answers whether the data supports it
        t = JW.current_text(ctx.project, k)
        if t:
            comments.append("The admin's version %d of the rule '%s' (%s): %s Check: %s" % (t["v"], JR.BY_ID[k]["title"], t.get("why") or "no reason given", " ".join(t["steps"]), t.get("check") or ""))

    web_hits = col.get("web") or {}

    def standin():
        out = []
        for j in joins:
            ev = []
            for t in j["terms"]:
                for h in (refs_hits.get(t) or [])[:1]:
                    ev.append({"kind": "document", "ref": h["ref"], "quote": h["quote"][:200]})
                for h in (rea.get(t) or [])[:1]:
                    ev.append({"kind": "rea", "ref": h["ref"], "quote": h["quote"][:200]})
                for h in (web_hits.get(t) or [])[:1]:
                    ev.append({"kind": "web", "ref": h["ref"], "quote": h["quote"][:200]})
            out.append(dict(j, evidence=ev[:4]))
        return {"joins": out, "answers_to_admin": ["Noted: %s (the stand-in cannot change the strategy; a model run can)." % c for c in comments if c]}
    ans, producer, _ = ctx.engine.runner.ask(ctx.run["id"], "coder", CODER_INSTRUCTION,
                                             {"strategy": joins, "references": refs_hits, "rea": rea, "web": web_hits, "dictionaries": col.get("dictionaries"), "admin_comments": comments},
                                             CODER_SHAPE, "joins", standin, web=ctx.engine.runner.can_search_web())
    refs = _RefsWithRea(core.References([x for x in (core.jload(ctx.project.get("refs"), []) or []) if x],
                                        os.path.join(ctx.engine.runner.sandbox_root, "_pdf_cache")), rea_folder)
    headers = set()
    for f in family1.inventory(ctx.project.get("folder")):
        h, _ = L.sniff(f["path"], 0)
        al = L.align_header(f["level"], h) if f["level"] else None
        headers |= set(al.positions) if al else set(h)
    problems = []
    answer_joins = merge_answer(joins, ans)
    for j in answer_joins:
        claims = core.check_claims([{"text": j["join"], "source": e} for e in j["evidence"]], refs=refs, web=ctx.engine.runner.web_sources())
        j["evidence"] = [dict(c["source"], verified=c["verified"]) for c in claims]
        ctx.evidence(claims)
        missing = [c for c in j.get("columns") or [] if c not in headers]
        if missing:
            problems.append("%s uses columns that are not in the files: %s" % (j["join"], ", ".join(missing)))
    admin = ctx.project.get("admin") or "admin"
    body = ["**Admin %s, need review.** The strategy for joining the five files, with the evidence found for each join." % admin]
    if problems:
        body += ["", "**Problems found by the code:**"] + ["- " + p for p in problems]
    if ans.get("answers_to_admin"):
        body += ["", "**Answers to your comments:**"] + ["- " + a for a in ans["answers_to_admin"]]
    if rea_note:
        body += ["", rea_note]
    body += ["", "Check each rule below. Each one is what the code does, not a summary of it. A rule that is wrong needs a change to `nvme_hier/builder.py`: say so with **Change**, and the rule is then checked again."]
    body += _strategy_md(answer_joins) + ["", "The code that applies it: `nvme_hier/builder.py` (version %s)." % code_version()]
    fmt, _ = project_format(ctx.project)
    need = JR.needs_check(None, _eff(ctx.engine, ctx.project))
    return core.Result({"joins": answer_joins, "problems": problems, "format": fmt, "needs_check": need}, producer=producer,
                       review={"title": "The joining strategy", "body": "\n".join(body), "data": {"joins": answer_joins, "needs_check": need, "problems": problems, "must_explain": bool(problems)}})


def _ticks(edits):
    v = edits.get("verified") if isinstance(edits, dict) else None
    return [x for x in v if isinstance(x, str)] if isinstance(v, list) else []


def on_approve(engine, run, step, data, admin):
    out = core.jload(step["output"], {})
    edits = data.get("edits") or {}
    if step["key"] == "rea":
        # a "REA findings" card of a run started before 14 November 2026: a folder given there is kept with the analysis
        # (the REA agent on the start page reads it); no step is added and nothing is read in the flow
        folder = (edits.get("rea") or "").strip() if isinstance(edits, dict) else ""
        if folder:
            if not os.path.isdir(folder):
                raise ValueError("not a folder: %s" % folder)
            engine.store.exec("UPDATE project SET rea=?, updated=? WHERE id=?", (folder, time.time(), run["project"]))
        return
    if step["key"] == "build_ask":
        engine.set_input(run["id"], "build", rebuild=bool(isinstance(edits, dict) and edits.get("rebuild")),
                         reuse=(out.get("reuse") or {}).get("upload_id"))
        return
    if step["key"] == "independent":
        checks = out.get("join_checks") or {}
        if checks.get("must_explain") and not written_reason(edits):
            raise ValueError("this recording does not follow these rules: %s. Write why you accept the tree anyway, or stop the flow" % "; ".join(checks.get("broken") or []))
        return
    if step["key"] == "last_strategy":
        st = out.get("strategy") or {}
        if not same_code(out.get("joins")):
            raise ValueError("the code that applies these rules changed since this page was made: press Change to see them again")
        eff = _eff(engine, engine.store.one("SELECT * FROM project WHERE id=?", (run["project"],)) or {"id": run["project"]}) if engine is not None and run.get("project") else None
        verified = JR.record_check(st.get("verified"), _ticks(edits), admin, eff)
        st["verified"], st["settings"] = verified, eff
        L.write_json_atomic(os.path.join(strategy_dir(out["format"]), "v%d.json" % st["version"]), st, indent=1)
        for k in ("rea", "collect", "coder"):
            engine.store.exec("UPDATE step SET state='skipped', note=? WHERE run=? AND key=?",
                              ("strategy v%d approved again: reused" % out["strategy"]["version"], run["id"], k))
    elif step["key"] == "coder":
        if out.get("problems") and not written_reason(edits):
            raise ValueError("the files lack columns these rules read: %s. Write why you go on anyway, or stop the flow" % "; ".join(out["problems"]))
        if not same_code(out.get("joins")):
            raise ValueError("the code that applies these rules changed since this page was made: press Change to see them again")
        eff = _eff(engine, engine.store.one("SELECT * FROM project WHERE id=?", (run["project"],)) or {"id": run["project"]}) if engine is not None and run.get("project") else None
        verified = JR.record_check(None, _ticks(edits), admin, eff)
        fmt = out["format"]
        d = strategy_dir(fmt)
        n = 1 + len([x for x in os.listdir(d) if x.startswith("v") and x.endswith(".json")])
        st = {"format": fmt, "version": n, "joins": out["joins"], "verified": verified, "settings": eff, "approved_by": admin, "approved_at": time.time(),
              "code": "nvme_hier/builder.py", "code_version": code_version(), "run": run["id"]}
        L.write_json_atomic(os.path.join(d, "v%d.json" % n), st, indent=1)


# ---------------------------------------------------------------------------------------------- build
def file_identity(path):
    """The file itself, not its name: the same file on disk (device and inode: a hard link or another path to it counts),
    its size and its last change."""
    st = os.stat(path)
    return {"dev": st.st_dev, "ino": st.st_ino, "size": st.st_size, "mtime_ns": st.st_mtime_ns}


def find_built_tree(services, files, settings=None, any_settings=False):
    """The newest tree already built from these same files: every level's file is the same file on disk, with the same
    size, and was not changed after the tree was built. -> (upload id, meta) or (None, None)."""
    from api import hier_api as H
    try:
        want = {lvl: file_identity(p) for lvl, p in files.items()}
    except OSError:
        return None, None
    base = H.uploads_dir(services)
    best = (0, None, None)
    for name in os.listdir(base):
        d = os.path.join(base, name)
        m = H.read_meta(d) if os.path.isdir(d) else None
        if not m or m.get("status") != "loaded" or set((m.get("files") or {})) != set(files) or not os.path.exists(os.path.join(d, "hier.sqlite")):
            continue
        if not any_settings and JR.settings_of(((m.get("result") or {}).get("build") or {}).get("settings")) != JR.settings_of(settings):
            continue                # built with other settings for the rules: not the tree this analysis would build
        built = m.get("loaded_at") or m.get("created") or 0
        stored = m.get("file_stats") or {}
        ok = True
        for lvl, p in m["files"].items():
            try:
                cur = file_identity(p)
            except OSError:
                ok = False
                break
            w = want[lvl]
            same_file = (cur["dev"], cur["ino"], cur["size"]) == (w["dev"], w["ino"], w["size"])
            unchanged = (stored[lvl].get("size"), stored[lvl].get("mtime_ns")) == (w["size"], w["mtime_ns"]) if stored.get(lvl) else w["mtime_ns"] / 1e9 <= built
            if not (same_file and unchanged):
                ok = False
                break
        if ok and built >= best[0]:
            best = (built, name, m)
    return best[1], best[2]


def _build_ask(ctx):
    _fmt, files = project_format(ctx.project)
    admin = ctx.project.get("admin") or "admin"
    total = sum(f["bytes"] for f in files)
    levels = {f["level"]: f["path"] for f in files if f["level"]}
    up, m = find_built_tree(ctx.engine.services, levels, _eff(ctx.engine, ctx.project))
    reuse = {"upload_id": up, "built": (m or {}).get("loaded_at") or (m or {}).get("created")} if up else None
    if reuse:
        body = ["**Admin %s, need review.** A tree was already built from these same files, so it is used again and nothing is built." % admin, "",
                "Upload **%s**, built on %s. Each of the %d files is the same file on disk, with the same size, and none was changed since." % (
                    up, time.strftime("%Y-%m-%d %H:%M", time.localtime(reuse["built"] or 0)), len(levels)), "",
                "Tick \"build it again\" only if you want a new build anyway."]
        title = "Use the tree built before?"
    else:
        body = ["**Admin %s, need review.** Shall I build the hierarchy?" % admin, "",
                "| file | level | size |", "|---|---|---|"] + ["| %s | %s | %s MB |" % (f["name"], f["level_label"], "{:,}".format(f["bytes"] // 1000000)) for f in files] + [
            "", "Total %s MB. The files are read row by row and written to a database on disk; only the open exchanges are kept in "
            "memory, so memory stays low whatever the size. An interrupted build continues from the last finished file or stage." % "{:,}".format(total // 1000000)]
        title = "Shall I build the hierarchy?"
    return core.Result({"files": files, "reuse": reuse}, review={"title": title, "body": "\n".join(body), "data": {"reuse": reuse}})


def _build(ctx):
    from api import hier_api as H          # the application's load job: load, build, rules; resumable
    s = ctx.engine.services
    found = family1.inventory(ctx.project.get("folder"))
    problem = family1.folder_problem(found)         # the folder can change after the first step
    if problem:
        raise RuntimeError(problem)
    files = {f["level"]: f["path"] for f in found if f["level"]}
    if not ctx.input.get("rebuild"):
        up, m = find_built_tree(s, files, _eff(ctx.engine, ctx.project))
        if up:
            ctx.engine.store.exec("UPDATE project SET upload_id=?, updated=? WHERE id=?", (up, time.time(), ctx.run["project"]))
            return core.Result({"upload_id": up, "reused": True, "build": ((m or {}).get("result") or {}).get("build"),
                                "why": "the same files on disk, unchanged since this tree was built"})
    uid = time.strftime("up-%Y%m%d-%H%M%S-") + hashlib.sha1(str(time.time()).encode()).hexdigest()[:4]
    d = os.path.join(H.uploads_dir(s), uid)
    os.makedirs(d, exist_ok=True)
    meta = {"upload_id": uid, "created": time.time(), "operator": ctx.project.get("admin") or "admin",
            "device": ctx.project.get("name") or "", "trace_name": ctx.project.get("name") or "", "recording_date": "",
            "notes": "built by Family 2, run %s" % ctx.run["id"], "files": files, "status": "loading", "thresholds": {},
            "file_stats": {lvl: file_identity(p) for lvl, p in files.items()}}     # how the next flow recognises the same files
    H.write_meta(d, meta)
    params = {"upload_id": uid, "upload_dir": d, "files": files, "operator": meta["operator"], "device": meta["device"],
              "trace_name": meta["trace_name"], "recording_date": "", "thresholds": {},
              "workers": ((s.cfg.get("pipeline") or {}).get("workers") or 0), "join_settings": _eff(ctx.engine, ctx.project)}
    jid = s.jobs.submit("hier_load", params, H.run_hier_load)
    meta["job"] = jid
    H.write_meta(d, meta)
    ctx.engine.store.exec("UPDATE project SET upload_id=?, updated=? WHERE id=?", (uid, time.time(), ctx.run["project"]))
    t_load = time.time()
    while True:
        j = s.jobs.get(jid) or {}
        pr = j.get("progress") or {}
        st = pr.get("stats") or {}
        ctx.progress(core.progress_text(float(pr.get("pct") or 0), t_load, what="loading and building the tree: %s%s" % (
            pr.get("step") or "starting", ", " + pr["detail"] if pr.get("detail") else ""), done=st.get("bytes_done"), total=st.get("bytes_total")))
        if j.get("status") in ("done", "failed", "cancelled"):
            break
        time.sleep(2)
    if j.get("status") != "done":
        raise RuntimeError("the load and build stopped: %s (load it again from the upload page: it continues where it stopped)" % (j.get("error") or j.get("status")))
    return core.Result({"upload_id": uid, "reused": False, "job": jid, "build": ((H.read_meta(d) or {}).get("result") or {}).get("build")})


def _db(ctx):
    from api import hier_api as H
    up = ctx.output_of("build").get("upload_id") or ctx.project.get("upload_id")
    d = H.upload_dir(ctx.engine.services, up) if up else None
    if not d:
        raise RuntimeError("no built upload for this project")
    return os.path.join(d, "hier.sqlite"), up


# ---------------------------------------------------------------------------------------------- tests on real slices
def slice_check(full_db, t0, t1, box, label):
    """Rebuild the rows of [t0, t1] (plus a margin) on their own and compare with the analyzer's counts and with the
    full tree, for the parents that lie fully inside the window."""
    margin = max(5 * 10 ** 9, (t1 - t0) // 5)      # at least 5 ms of rows on each side of the window
    p = os.path.join(box, "slice_%s.sqlite" % label)
    for ext in ("", "-wal", "-shm"):
        if os.path.exists(p + ext):
            OSF.remove(p + ext)
    w = p.replace(".sqlite", ".work.sqlite")
    if os.path.exists(w):
        OSF.remove(w)
    src = sqlite3.connect("file:%s?mode=ro" % full_db, uri=True)
    ddl = {r[0]: r[1] for r in src.execute("SELECT name, sql FROM sqlite_master WHERE type='table' AND name IN ('pkt','lnk','spl','ntx','cmd','meta')")}
    src.close()
    con = sqlite3.connect(p)
    for t, sql in ddl.items():
        con.execute(sql)
    con.execute("ATTACH DATABASE ? AS f", (full_db,))
    counts = {}
    for t in ("pkt", "lnk", "spl", "ntx", "cmd"):
        if t in ddl:
            con.execute("INSERT INTO %s SELECT * FROM f.%s WHERE t_ps BETWEEN ? AND ?" % (t, t), (t0 - margin, t1 + margin))
            con.execute("UPDATE %s SET parent=NULL, parent_level=NULL, relation=NULL, dur_ps=NULL" % t)
            counts[t] = con.execute("SELECT COUNT(*) FROM %s" % t).fetchone()[0]
    if "meta" in ddl:
        con.execute("INSERT INTO meta SELECT * FROM f.meta WHERE k IN ('levels_present','load_reports','upload')")
        # the queues in force when the window opens (their last creation before it): without them the window cannot
        # know where a completion queue's slots start, and its head doorbells could not be placed as in the full tree
        ctx = [list(r) for r in con.execute(
            "SELECT t_ps, qid, qsize, prp1 FROM f.cmd c WHERE sqid = 0 AND opc = 5 AND qid IS NOT NULL AND prp1 IS NOT NULL AND t_ps < ? "
            "AND t_ps = (SELECT MAX(t_ps) FROM f.cmd c2 WHERE c2.sqid = 0 AND c2.opc = 5 AND c2.qid = c.qid AND c2.t_ps < ?)", (t0 - margin, t0 - margin))]
        con.execute("INSERT OR REPLACE INTO meta (k, v) VALUES ('cq_context', ?)", (json.dumps(ctx),))
    # the indexes the loader makes (the builder's own count checks and ours look children up by parent and rows up by
    # time: without them every check scans the whole table)
    for t in counts:
        con.execute("CREATE INDEX IF NOT EXISTS ix_%s_parent ON %s (parent_level, parent)" % (t, t))
        con.execute("CREATE INDEX IF NOT EXISTS ix_%s_t ON %s (t_ps)" % (t, t))
    con.commit()
    con.execute("DETACH DATABASE f")
    con.close()
    try:                        # the window is built with the settings the full tree was built with, so the two can be compared
        full_settings = json.loads((sqlite3.connect("file:%s?mode=ro" % full_db, uri=True).execute("SELECT v FROM meta WHERE k='build'").fetchone() or ["{}"])[0]).get("settings")
    except (sqlite3.Error, ValueError, TypeError):
        full_settings = None
    B.build(p, settings=full_settings)
    con = sqlite3.connect(p)
    con.execute("ATTACH DATABASE ? AS f", (full_db,))
    res = {"window": [t0, t1], "rows": counts, "count_mismatch": {}, "parent_mismatch": {}, "checked": {}}
    for parent, ncol, child, lvl in COUNT_CHECKS:
        if parent not in counts:
            continue
        # only parents whose whole life lies inside the window are judged: their start and their end (start plus the
        # duration they have in the full tree) are inside [t0, t1], and the copy reaches a margin beyond both ends
        inside = ("p.t_ps BETWEEN ? AND ? AND p.%s IS NOT NULL AND EXISTS (SELECT 1 FROM f.%s fp WHERE fp.rowid_file = p.rowid_file "
                  "AND fp.dur_ps IS NOT NULL AND fp.t_ps + fp.dur_ps <= ?)" % (ncol, parent))
        if child:
            q = ("SELECT p.rowid_file, p.%s, (SELECT COUNT(*) FROM %s c WHERE c.parent_level=? AND c.parent=p.rowid_file AND c.relation='member') "
                 "FROM %s p WHERE %s" % (ncol, child, parent, inside))
            rows = con.execute(q, (lvl, t0, t1, t1)).fetchall()
        else:
            q = ("SELECT p.rowid_file, p.%s, (SELECT COUNT(*) FROM lnk c WHERE c.parent_level=? AND c.parent=p.rowid_file AND c.relation='member') + "
                 "(SELECT COUNT(*) FROM spl c WHERE c.parent_level=? AND c.parent=p.rowid_file AND c.relation='member') "
                 "FROM %s p WHERE %s" % (ncol, parent, inside))
            rows = con.execute(q, (lvl, lvl, t0, t1, t1)).fetchall() if "lnk" in counts and "spl" in counts else []
        bad = [r for r in rows if r[1] != r[2]]
        res["checked"][parent] = len(rows)
        res["count_mismatch"][parent] = {"n": len(bad), "examples": [{"row": r[0], "analyzer": r[1], "joined": r[2]} for r in bad[:3]]}
    for t in ("pkt", "lnk", "spl", "ntx"):
        if t not in counts:
            continue
        ptab = {"pkt": "lnk", "lnk": None, "spl": "ntx", "ntx": "cmd"}[t]
        if t == "lnk":
            # a link transaction's parent is a split transaction or an NVMe transaction: compare it when that parent is whole
            cond = ("EXISTS (SELECT 1 FROM f.spl fp WHERE f.parent_level='split' AND fp.rowid_file=f.parent AND fp.t_ps >= ? AND fp.t_ps + COALESCE(fp.dur_ps, 0) <= ?) "
                    "OR EXISTS (SELECT 1 FROM f.ntx fp WHERE f.parent_level='nvme_transaction' AND fp.rowid_file=f.parent AND fp.t_ps >= ? AND fp.t_ps + COALESCE(fp.dur_ps, 0) <= ?)")
            args = (t0, t1, t0, t1)
        else:
            cond = "EXISTS (SELECT 1 FROM f.%s fp WHERE fp.rowid_file=f.parent AND fp.t_ps >= ? AND fp.t_ps + COALESCE(fp.dur_ps, 0) <= ?)" % ptab
            args = (t0, t1)
        # CROSS JOIN: the window's rows first, each looked up in the full tree by its row number. Left to itself the database went through the members of
        # the FULL table and looked each one up in the window (2026-11-14, a recording of 4.4 million packets: 2 s for the packets and 2 s for the link
        # transactions of every window, also of a window that holds no packet at all). The rows come in row order either way: the same first 1,000.
        diff = con.execute("SELECT s.rowid_file, s.parent, f.parent FROM %s s CROSS JOIN f.%s f "
                           "WHERE f.rowid_file=s.rowid_file AND s.relation='member' AND f.relation='member' AND s.parent IS NOT f.parent AND (%s) "
                           "ORDER BY s.rowid_file LIMIT 1000" % (t, t, cond), args).fetchall()
        res["parent_mismatch"][t] = {"n": len(diff), "examples": [{"row": r[0], "slice": r[1], "full": r[2]} for r in diff[:3]]}
    con.close()
    for ext in ("", "-wal", "-shm"):
        if os.path.exists(p + ext):
            OSF.remove(p + ext)
    res["passed"] = all(v["n"] == 0 for v in res["count_mismatch"].values()) and all(v["n"] == 0 for v in res["parent_mismatch"].values())
    return res


def _windows(con, n, seed, span_cmds=120):
    cmds = [r[0] for r in con.execute("SELECT t_ps FROM cmd WHERE t_ps IS NOT NULL ORDER BY t_ps")]
    if len(cmds) < 3:
        lo, hi = con.execute("SELECT MIN(t_ps), MAX(t_ps) FROM pkt").fetchone()
        return [(lo, hi)]
    rng = random.Random(seed)
    span = min(span_cmds, max(2, len(cmds) // 3))
    starts = sorted(rng.sample(range(0, max(1, len(cmds) - span)), min(n, max(1, len(cmds) - span))))
    return [(cmds[i], cmds[i + span]) for i in starts]


def _slice_test(ctx):
    db, up = _db(ctx)
    box = ctx.engine.runner.sandbox(ctx.run["id"], "code_tester")
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    n = int((ctx.engine.cfg.get("agentic") or {}).get("slices", 6))
    wins = _windows(con, max(5, min(10, n)), seed=ctx.run["id"])
    con.close()
    results = []
    t_all = time.time()
    for i, (t0, t1) in enumerate(wins):
        ctx.progress(core.progress_text(100.0 * i / max(1, len(wins)), t_all, what="testing random window %d of %d" % (i + 1, len(wins))))
        results.append(dict(slice_check(db, t0, t1, box, "w%d" % i), name="random window %d" % (i + 1)))
    passed = sum(1 for r in results if r["passed"])
    return core.Result({"upload_id": up, "windows": results, "passed": passed, "of": len(results)})


def _breaker(ctx):
    db, up = _db(ctx)
    box = ctx.engine.runner.sandbox(ctx.run["id"], "breaker")
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    span = 2 * 10 ** 6       # 2 us around a hard spot (picoseconds)
    wins = []
    try:
        r = con.execute("SELECT f.t_ps FROM finding f WHERE f.rule='lnk.replay' ORDER BY f.t_ps LIMIT 1").fetchone()
        if r and r[0] is not None:
            wins.append(("around a resend after a Nak", r[0] - 50 * span, r[0] + 50 * span))
    except sqlite3.Error:
        pass
    r = con.execute("SELECT t_ps FROM lnk WHERE relation='orphan' AND t_ps IS NOT NULL LIMIT 1").fetchone()
    if r:
        wins.append(("around a link transaction that joined nothing", r[0] - 50 * span, r[0] + 50 * span))
    cm = [x[0] for x in con.execute("SELECT t_ps FROM cmd WHERE t_ps IS NOT NULL ORDER BY t_ps")]
    if len(cm) > 40:
        wins.append(("the start of the recording", cm[0], cm[30]))
        wins.append(("the end of the recording", cm[-31], cm[-1]))
        gaps = [(cm[i + 20] - cm[i], i) for i in range(0, len(cm) - 21)]
        _g, i = min(gaps)
        wins.append(("the busiest moment (20 commands in the shortest time)", cm[i], cm[i + 20]))
    con.close()
    results = []
    t_all = time.time()
    for i, (name, t0, t1) in enumerate(wins):
        ctx.progress(core.progress_text(100.0 * i / max(1, len(wins)), t_all, what="%s (%d of %d)" % (name, i + 1, len(wins))))
        results.append(dict(slice_check(db, t0, t1, box, "b%d" % i), name=name))
    if not results:
        return core.Result({}, skip="the data has no hard spot to test")
    return core.Result({"upload_id": up, "windows": results, "passed": sum(1 for r in results if r["passed"]), "of": len(results)})


INVARIANTS = [
    ("a TLP packet carries the PSN and direction of its link transaction",
     "SELECT COUNT(*), SUM(CASE WHEN c.psn = p.psn AND c.dir = p.dir THEN 0 ELSE 1 END) FROM (SELECT * FROM pkt WHERE parent_level='link' AND relation='member' AND tlp_type IS NOT NULL AND psn IS NOT NULL LIMIT 20000) c JOIN lnk p ON p.rowid_file=c.parent", ["PSN", "Link Dir"]),
    ("an Ack or Nak goes the other way and names a PSN at or after its link transaction's",
     "SELECT COUNT(*), SUM(CASE WHEN c.dir != p.dir AND c.acknak >= p.psn THEN 0 ELSE 1 END) FROM (SELECT * FROM pkt WHERE parent_level='link' AND relation='member' AND dllp_type IS NOT NULL AND acknak IS NOT NULL LIMIT 20000) c JOIN lnk p ON p.rowid_file=c.parent", ["AckNak Seq Num", "Link Dir"]),
    ("a link transaction in a split transaction has the split's requester and tag",
     "SELECT COUNT(*), SUM(CASE WHEN c.rid = p.rid AND c.tag = p.tag THEN 0 ELSE 1 END) FROM (SELECT * FROM lnk WHERE parent_level='split' AND relation='member' LIMIT 20000) c JOIN spl p ON p.rowid_file=c.parent", ["RequesterID", "Tag"]),
    ("an NVMe transaction with a queue id and a command id has its command's",
     "SELECT COUNT(*), SUM(CASE WHEN c.sqid = p.sqid AND c.cid = p.cid THEN 0 ELSE 1 END) FROM (SELECT * FROM ntx WHERE parent_level='nvme_command' AND relation='member' AND sqid IS NOT NULL AND cid IS NOT NULL LIMIT 20000) c JOIN cmd p ON p.rowid_file=c.parent", ["SQID", "CID"]),
]


def _independent(ctx):
    db, up = _db(ctx)
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    out = []
    t_checks = time.time()
    for k_check, (name, sql, cols) in enumerate(INVARIANTS):
        ctx.progress(core.progress_text(100.0 * k_check / len(INVARIANTS), t_checks, what="independent check %d of %d: %s" % (k_check + 1, len(INVARIANTS), name[:70])))
        try:
            n, bad = con.execute(sql).fetchone()
        except sqlite3.Error as e:
            out.append({"check": name, "error": str(e)})
            continue
        meanings = {}
        for d in family1.dictionaries_for_level("packets") + family1.dictionaries_for_level("link") + family1.dictionaries_for_level("split") + \
                family1.dictionaries_for_level("nvme_transaction") + family1.dictionaries_for_level("nvme_command"):
            for r in d["columns"]:
                if r["column"] in cols and r.get("meaning"):
                    meanings.setdefault(r["column"], r["meaning"][:160])
        out.append({"check": name, "rows_checked": n or 0, "violations": bad or 0, "columns": cols, "meanings": meanings})
    con.close()
    st = ctx.output_of("slice_test")
    br = ctx.output_of("breaker")
    admin = ctx.project.get("admin") or "admin"
    body = ["**Admin %s, need review.** The tree of upload **%s** is built and tested." % (admin, up), "",
            "**Code tester:** %s of %s random windows passed." % (st.get("passed", "-"), st.get("of", "-")),
            "**Breaker:** %s of %s hard windows passed." % (br.get("passed", "-"), br.get("of", "-")), "",
            "**Independent tester** (the column meanings only):", "", "| check | rows checked | violations |", "|---|---|---|"] + [
        "| %s | %s | %s |" % (o["check"], "{:,}".format(o.get("rows_checked", 0)), o.get("violations", o.get("error"))) for o in out]
    limit = break_limit(ctx.engine.cfg)
    checks = JR.evaluate(db, limit=limit, progress=lambda text: ctx.progress("how the rules held on this recording: " + text))
    body += ["", "**How the rules for combining the files held on this recording** (limit: %s%% of the rows):" % ("%g" % limit), "", "| rule | result |", "|---|---|"] + [
        "| %s | %s |" % (r["title"], {"followed": "followed", "few": "a few rows did not follow", "broken": "**NOT followed**", "not_run": "no such file"}[r["verdict"]]) for r in checks["rules"]]
    if checks["must_explain"]:
        body += ["", "**%s**" % checks["summary"], "Approving needs your reason. The rows that do not follow are kept in the tree and marked."]
    fails = [w for w in (st.get("windows") or []) + (br.get("windows") or []) if not w["passed"]]
    if fails:
        body += ["", "**Windows that did not pass** (a parent cut by the window edge is excluded; what remains is a real difference):"]
        for w in fails[:8]:
            body.append("- %s: counts %s; parents %s" % (w["name"], {k: v["n"] for k, v in w["count_mismatch"].items() if v["n"]},
                                                           {k: v["n"] for k, v in w["parent_mismatch"].items() if v["n"]}))
    body += ["", "Approve to accept the tree for this project."]
    return core.Result({"upload_id": up, "invariants": out, "join_checks": checks}, review={"title": "The tree is built and tested", "body": "\n".join(body),
                                                                                             "data": {"join_checks": checks, "must_explain": checks["must_explain"]}})


def on_finish(engine, rid):
    view = engine.view(rid)
    ind = next((s for s in view["steps"] if s["key"] == "independent"), None)
    up = ((ind or {}).get("output") or {}).get("upload_id")
    if up:
        engine.store.exec("UPDATE project SET upload_id=?, updated=? WHERE id=?", (up, time.time(), view["run"]["project"]))
    engine.store.exec("UPDATE run SET summary=? WHERE id=?", ("hierarchy ready: upload %s" % up if up else "finished", rid))
