"""Family 4 - Coding (owner, 2026-11-12): from the English of a Family 3 item to code that was written, tested and corrected in rounds.

Family 3 holds the item in the admin's words and as a procedure (numbered steps). Family 4 takes that English and makes the code:

  req    Requirements agent - REVIEW, as often as the admin needs. What the code needs is made exact before a line is written:
         the data (files, levels, columns), the definitions (a limit with its unit, what counts as what), the output. Every
         column is looked up in the file itself by code; Family 1 is asked through its approved data dictionaries (a kind of
         data that no named column holds goes to the Manager of every file, the names checked by code as in admin_ask);
         Family 2 is asked whether the tree is built when the procedure reads the tree. What is not exact comes back as
         questions to the admin; his answers go to the agent again until nothing is open. Then he approves the requirements
         and may set the number of rounds.
  code   Coder and Tester, at most N rounds (10 unless the admin sets another number, 1 to 20), then REVIEW of the final code:
           the Coder (the model at its highest effort) writes or revises the code and keeps a log of what it understood and decided
           -> the program's own checks (it compiles, allowed imports only, run() defined)
           -> the code runs on the first records of the real files only (or on the tree) and its output is checked
           -> every small data set made so far runs again
           -> the Tester, who is not shown the code, makes new small data sets from the requirements, each with the property
              it checks and the output it expects, to find an input on which a program that misread the rule is wrong; they run
           -> what failed goes back to the Coder: the next round.
         Since 2026-11-14 (owner: "keep on asking questions till the doubt is resolved", "strong testers", "deep dive"):
           - req: a column the procedure names that its file does not have, and a kind of data Family 1 did not find under a
             name, are looked for in every file by their values, shape and meaning (agentic/column_match.py); what is found
             goes to the admin as a question with its evidence (use it / not the same / I will add the file). Family 2 is
             asked what it knows of the tree the rule reads.
           - code, round 1: a second program is written at the same time, independently, from the same requirements. Both run
             on the same small data. Where their results differ the rule can be read two ways: the admin is shown the data
             and both results and says which is meant (at most DOUBT_TURNS_MOST times), and that answer becomes part of the
             requirements. Where both contradict a Tester's expectation in the same way, the expectation is set aside for
             the admin instead of failing the code.
           - a program is repaired REPAIRS_PER_PROGRAM rounds at most; then the Coder writes a fresh program, in a new
             conversation, from the requirements and what failed.
           - the instructions of the agents are documents: agentic/prompts/f4_*.md.
         All generated code runs only in the confinement of procedures.run_code (its own process, a memory and time limit, its
         own files only). Nothing a model wrote is ever executed inside the application's process.

When the rounds end (STOP RULE)
  1. a clean round: the program's checks pass, the run on the first real records passes, every data set passes, was withdrawn
     by the Tester or was set aside for the admin, and the Tester added no data set that fails and no remark;
  2. the number of rounds is used up;
  3. the Coder returned the same code again and objected to nothing (another round would not differ);
  4. the run was stopped (no further model call is made).

What is never trusted. A data set's expected output is the Tester's CLAIM. When the code and the claim differ, the Coder either
corrects the code or objects ("the expectation contradicts step 3"); the Tester then withdraws the data set or keeps it. A
data set both sides keep is set aside "for the admin to judge" with both reasons: the code is never bent to an expectation
without the trail saying so. Names of files and columns are checked against the real header by code; rows and counts shown
are counted by code.

The chain of thought is kept: every round's work log of the Coder and of the Tester (what each understood, checked and decided,
in its own words), what changed, each data set with its expected and actual result, and the program's checks, in a trail
file beside the code (knowledge/rules_code/...trail.json), and on the review card as a timeline. These are the notes an agent
writes of its work. The model service does not hand out a model's raw hidden reasoning, and a prompt that asks for it is
refused (seen 2026-11-13 with the first wording of the Coder's instruction), so the instructions ask for a work log. Approving stores the code as the VERIFIED code of that procedure version, exactly as
before (family3.on_approve), so Run uses it. A verified code is used again and never built again.
"""
import csv
import hashlib
import json
import os
import re
import sqlite3
import time
from concurrent.futures import ThreadPoolExecutor

from . import admin_ask, column_match, core, family1, family3, prompts, procedures as PR
from . import f4_research as RS

ROUNDS_DEFAULT = 10          # the rounds of code and test at most (owner: "10 times maximum"); the admin can change it
ROUNDS_MOST = 20             # ... up to this many
CODER_EFFORT = "xhigh"       # the highest effort Claude Code accepts below "max" (checked: claude --effort low|medium|high|xhigh|max)
TESTER_EFFORT = "high"
REQ_EFFORT = "high"
SAMPLE_RECORDS = 200         # "test with very few data": the first records of each real file the code is tried on
CASES_PER_ROUND = 5          # new small data sets the Tester may add in one round
CASES_MOST = 30              # ... and in all
CASE_ROWS_MOST = 80          # records in one small data set
CASE_TIMEOUT_S = 60          # one small data set may run this long
QUESTIONS_MOST = 8
TEXT = 400                   # characters of one sentence kept in the trail
TREE_MISSING = ("this rule needs the tree: stage 2 was not built for this analysis; open the analysis again at stage 2 and "
                "build it (or write the procedure on one file)")
BY_PROGRAM, BY_TESTER, BY_ADMIN = "the program", "the Tester", "the admin's answer"
SET_ASIDE = "for the admin to judge"
# (owner, 2026-11-14: "keep on asking questions till the doubt is resolved", "strong testers", "deep dive")
REPAIRS_PER_PROGRAM = 3      # rounds on one program; then the Coder starts a fresh program from the requirements and what failed
                             # (measured: repair ability falls by 60 to 80 % within 2 to 3 attempts, and a fresh start beats continuing)
DOUBT_TURNS_MOST = 3         # times the admin is asked "which of the two results is meant" for one item
PROPOSALS_PER_NEED = 3       # columns offered to stand for one missing column or kind of data
SUBSTITUTE_QUESTIONS_MOST = 6
USE, NOT_SAME, ADD_FILE = "use", "not_same", "add_file"
FIRST, SECOND, NEITHER = "first", "second", "neither"
WHOLE_TIMEOUT_S = 900        # the program on the whole real file, once per round whose small data sets pass; longer than this is said, not waited for
EXPECTATION_DOUBTED = ("two programs written independently from the requirements give the same rows, and both contradict the expected rows: "
                       "the expectation may be wrong")


def steps(params, project):
    """The plan of a "Code it" run (kind rule_code)."""
    return flow_steps(lambda s: s, "")


def flow_steps(k, tag):
    """Family 4's steps of one item (inside the flow: k makes the item's step keys, tag is the item's name). The data
    research has no review of its own: its record is the first part of the requirements card."""
    return [{"key": k("research"), "title": tag + "Data research: what Families 1, 2 and 3 hold, and what the content of the columns shows, measured before anything is coded",
             "family": "4", "agent": "Data researcher"},
            {"key": k("req"), "title": tag + "Requirements agent: what the code needs, asked from you and checked with Family 1 and Family 2",
             "family": "4", "agent": "Requirements agent", "review": True},
            {"key": k("code"), "title": tag + "Coder and Tester: the code, written and tested in rounds, for your review", "family": "4",
             "agent": "Coder", "review": True}]


def run_step(ctx):
    return {"research": _research, "req": _req, "code": _code}[ctx.step["key"]](ctx)


def rounds_checked(v):
    """The number of rounds as a whole number from 1 to ROUNDS_MOST, or ValueError."""
    ok = isinstance(v, int) and not isinstance(v, bool)
    if isinstance(v, str) and re.fullmatch(r"\s*\d{1,3}\s*", v):
        v, ok = int(v), True
    if isinstance(v, float) and v == int(v):
        v, ok = int(v), True
    if not ok or not 1 <= v <= ROUNDS_MOST:
        raise ValueError("the number of rounds must be a whole number from 1 to %d" % ROUNDS_MOST)
    return v


def rounds_default(engine):
    """The Setting (agentic.coding_rounds), or 10."""
    try:
        return rounds_checked(((getattr(engine, "cfg", None) or {}).get("agentic") or {}).get("coding_rounds"))
    except ValueError:
        return ROUNDS_DEFAULT


def _texts(v, most=12, chars=TEXT):
    """A model's list of sentences, as a list of short strings."""
    if isinstance(v, str):
        v = [v]
    out = []
    for x in v if isinstance(v, list) else []:
        if isinstance(x, (str, int, float)) and str(x).strip():
            out.append(" ".join(str(x).split())[:chars])
    return out[:most]


def _output(step):
    o = (step or {}).get("output")
    return o if isinstance(o, dict) else (core.jload(o, {}) or {})


def _admin(ctx):
    return (ctx.project or {}).get("admin") or "admin"


def _header(path):
    try:
        with open(path, newline="", encoding="utf-8-sig", errors="replace") as fh:
            return list(next(family1.L.read_csv(fh, path), []))
    except OSError:
        return None


# ---------------------------------------------------------------------------------------------- the data, as code finds it
def _dictionaries(folder, paths):
    """{file name: Family 1's approved data dictionary}: the dictionary of the file itself (same header), else the newest
    approved one of its level."""
    inv = {}
    try:
        for f in family1.inventory(folder) if folder else []:
            inv[f["path"]] = f
    except Exception:           # noqa: BLE001 - a folder that cannot be listed has no dictionaries to offer
        inv = {}
    out = {}
    for name, path in paths.items():
        if name == PR.TREE:
            continue
        f = inv.get(path)
        d = family1.approved_dictionary(f["format_key"], f["name"]) if f else None
        if not d and PR.LEVEL_OF_FILE.get(name):
            d = next(iter(family1.dictionaries_for_level(PR.LEVEL_OF_FILE[name])), None)
        if d:
            out[name] = d
    return out


def _meaning(d, column):
    for c in (d or {}).get("columns") or []:
        if isinstance(c, dict) and c.get("column") == column:
            return str(c.get("meaning") or c.get("observed") or "")
    return ""


def data_facts(ctx, proc, stands=None):
    """What the procedure reads, looked up by code: for each source its path, for each column whether the file (or the
    tree) has it, real values, and Family 1's meaning. "blocking": what makes coding impossible now, in plain words.
    stands: {(file, column the procedure names): {"file", "column"}}: the column the admin chose to stand for a column the
    file does not have. In the same file it lifts the block (the code reads that column); in another file the procedure
    itself has to read that file, and the block says so."""
    stands = stands or {}
    db, up, paths = family3.recording(ctx)
    folder = (ctx.project or {}).get("folder")
    dicts = _dictionaries(folder, paths)
    sources, blocking, headers = [], [], {}
    for s in proc["source_data"]:
        if s["file"] == PR.TREE:
            cols = []
            if not db:
                blocking.append(TREE_MISSING)
            else:
                from nvme_hier import tree_api as T
                t = T.Tree(db)
                try:
                    for c in s["columns"]:
                        lv, col = PR.tree_column(c)
                        have = t.columns(lv) if lv in t.present else None
                        headers.setdefault((PR.TREE, lv), have or [])
                        ok = have is not None and col in have
                        vals, filled = PR.tree_samples(db, lv, col) if ok else ([], 0)
                        if have is None:
                            blocking.append("the tree of this analysis has no %s (its file was not loaded)" % PR.FILE_NAME.get(lv, lv))
                        elif not ok:
                            blocking.append("%s has no column %s (the tree's columns were read by code)" % (PR.FILE_NAME.get(lv, lv), col))
                        cols.append({"name": c, "level": lv, "in_the_data": ok, "real_values_seen": vals[:8], "rows_with_value_in_first_5000": filled,
                                     "meaning_from_family_1": _meaning(dicts.get(PR.FILE_NAME.get(lv)), col)})
                finally:
                    t.close()
            sources.append({"file": PR.TREE, "in_this_analysis": bool(db), "columns": cols or [{"name": c, "in_the_data": False} for c in s["columns"]]})
            continue
        path = paths.get(s["file"])
        head = _header(path) if path and os.path.exists(path) else None
        if head is None:
            blocking.append("this analysis has no file %s: put the CSV file into the folder%s and press Read the new files at the step after Family 1; "
                            "then send your answers here again" % (s["file"], " " + folder if folder else ""))
            sources.append({"file": s["file"], "in_this_analysis": False, "columns": [{"name": c, "in_the_data": False} for c in s["columns"]]})
            continue
        headers[s["file"]] = head
        other = [stands[(s["file"], c)]["column"] for c in s["columns"] if c not in head and (s["file"], c) in stands and stands[(s["file"], c)]["file"] == s["file"]]
        info = PR.columns_info(path, list(s["columns"]) + [x for x in other if x in head], rows=5000)
        cols = []
        for c in s["columns"]:
            ok = c in head
            st = stands.get((s["file"], c)) if not ok else None
            read = c
            if st and st["file"] == s["file"] and st["column"] in head:
                read = st["column"]             # the admin's choice: the code reads this column for the one the procedure names
            elif st:
                blocking.append("%s has no column %s; you chose %s column %s to stand for it, which is %s: change the procedure so that it reads that file "
                                "(Edit rule/procedure), then code it" % (s["file"], c, st["file"], st["column"],
                                                                         "in another file" if st["file"] != s["file"] else "not in the file's header any more"))
            elif not ok:
                blocking.append("%s has no column %s (its header was read by code)" % (s["file"], c))
            e = {"name": c, "in_the_data": ok, "position": (info.get(read) or {}).get("position"), "real_values_seen": ((info.get(read) or {}).get("samples") or [])[:8],
                 "rows_with_value_in_scan": (info.get(read) or {}).get("rows_with_value"), "meaning_from_family_1": _meaning(dicts.get(s["file"]), read)}
            if read != c:
                e["stands_for_it"] = read
            cols.append(e)
        sources.append({"file": s["file"], "path": path, "in_this_analysis": True, "header_cells": len(head),
                        "rows_scanned_for_samples": info.get("_rows_scanned"), "columns": cols})
    return {"db": db, "upload_id": up, "paths": paths, "folder": folder, "dicts": dicts, "sources": sources,
            "blocking": list(dict.fromkeys(blocking)), "headers": headers, "on_tree": PR.uses_tree(proc)}


def _has_column(facts, file, column):
    """Is this (file, column) in the data? Read from the file's own header (or the tree's columns), never from a model."""
    file, column = str(file or "").strip(), str(column or "").strip()
    if not file or not column:
        return False
    if file == PR.TREE:
        lv, col = PR.tree_column(column)
        if lv is None or not facts["db"]:
            return False
        if (PR.TREE, lv) not in facts["headers"]:
            from nvme_hier import tree_api as T
            t = T.Tree(facts["db"])
            try:
                facts["headers"][(PR.TREE, lv)] = t.columns(lv) if lv in t.present else []
            finally:
                t.close()
        return col in facts["headers"][(PR.TREE, lv)]
    if file not in facts["headers"]:
        path = facts["paths"].get(file)
        facts["headers"][file] = (_header(path) if path and os.path.exists(path) else None) or []
    return column in facts["headers"][file]


# ---------------------------------------------------------------------------------------------- Family 1 is asked
def f1_instruction():
    return admin_ask.MANAGER_INSTRUCTION + "\n\n" + prompts.load("f4_family1")


F1_SHAPE = '{"answers": [{"kind": 1, "present": "yes|no|cannot_tell", "matches": [{"column": "...", "keyword": "..."}], "could_not_check": "..."}]}'
KINDS_MOST = 12              # kinds of data of one item that are put to Family 1


def analysis_files(facts):
    """The CSV files of the analysis, each once (a file can be known under its own name and under its usual name)."""
    out, seen = [], set()
    for name, path in facts["paths"].items():
        if name != PR.TREE and path not in seen:
            seen.add(path)
            out.append(name)
    return out


def ask_family1(ctx, facts, kinds):
    """(owner, 2026-11-12: "test for the kind of data what they are looking is it available in the data, so need to talk to
    the Agent family 1") Every kind of data the rule needs, put to the Manager of every file of the analysis at the same
    time: one call per file (a large dictionary: several), all kinds in it. A Manager answers from its approved data
    dictionary and only NAMES columns and keywords; admin_ask's check then looks every name up in the dictionary, drops a
    name that is not there, and takes the rows and the lines from the dictionary. The verdict of a kind is admin_ask's:
    yes = a Manager said yes and a name it gave is in the data; no = every file has a dictionary and every Manager said no;
    cannot_tell = anything else (a file without a dictionary, a Manager without an answer, names that were not in the data).
    -> one {"verdict", "found": [{file, column, keyword, rows, lines, meaning}], "asked": [files], "no_dictionary": [files],
            "dropped": [names], "notes": [...]} per kind, in the order of kinds."""
    kinds = [str(k) for k in kinds]
    runner, files, jobs = ctx.engine.runner, [], []
    questions = ["Is this kind of data present in the recording: %s?" % k for k in kinds]
    for name in analysis_files(facts):
        d = facts["dicts"].get(name)
        f = {"file": name, "index": admin_ask._index(d) if d else None, "calls": []}
        files.append(f)
        if f["index"] is None:
            continue
        named = [admin_ask._named(f["index"], q) for q in questions]
        parts = admin_ask._parts([admin_ask._for_model(c) for c in f["index"].values()]) or [[]]
        for i, part in enumerate(parts):
            jobs.append((f, i, len(parts), part, named))

    def one(job):
        f, i, n, part, named = job
        here = {c["column"] for c in part}
        mine = [[m for m in nm if m["column"] in here] for nm in named]

        def standin():
            return {"answers": [{"kind": k + 1, "present": "yes" if mine[k] else "cannot_tell", "matches": mine[k][:admin_ask.MATCHES_ASKED], "could_not_check": ""}
                                for k in range(len(kinds))]}
        ctx_ = {"kinds": [{"kind": k + 1, "question": q, "named_in_the_question": mine[k]} for k, q in enumerate(questions)], "file": f["file"],
                "part_of_the_dictionary": "%d of %d" % (i + 1, n), "columns": part}
        try:
            ans, producer, _ = runner.ask(ctx.run["id"], "f4_asks_%s_%d" % (f["file"], i + 1), f1_instruction(), json.dumps(ctx_, ensure_ascii=False),
                                          F1_SHAPE, "answers", standin)
            return {"answers": ans.get("answers") if isinstance(ans.get("answers"), list) else [], "producer": producer}
        except Exception as e:      # noqa: BLE001 - one Manager without an answer must not lose the others'
            if str(e) == "the run was stopped":
                raise
            return {"problem": " ".join(("%s: %s" % (type(e).__name__, e)).split())[:200]}
    if jobs and kinds:
        with ThreadPoolExecutor(max_workers=max(1, min(len(jobs), getattr(runner, "CALLS_MOST", 8) or 8))) as pool:
            for job, out in zip(jobs, pool.map(one, jobs)):
                job[0]["calls"].append(out)
    answers = []
    for k, q in enumerate(questions):
        results = []
        for f in files:
            r = {"file": f["file"], "index": f["index"], "state": "read" if f["index"] is not None else "new", "question": q, "parts": []}
            if f["index"] is not None:
                for call in f["calls"]:
                    if call.get("problem"):
                        r["parts"].append({"problem": call["problem"]})
                        continue
                    mine = next((a for a in call["answers"] if isinstance(a, dict) and str(a.get("kind")).strip() == str(k + 1)), None)
                    r["parts"].append({"answer": mine} if mine is not None else {"problem": "the Manager gave no answer for this kind of data"})
                admin_ask._settle(r)
            results.append(r)
        asked = [r for r in results if r["index"] is not None]
        found = [{"file": r["file"], "column": m["column"], "keyword": m["keyword"], "rows": m["rows"], "lines": m["lines"], "meaning": str(m["meaning"] or "")[:200]}
                 for r in asked for m in r["matches"][:4]]
        answers.append({"verdict": admin_ask.verdict_of(results) if asked else "cannot_tell", "found": found, "asked": [r["file"] for r in asked],
                        "no_dictionary": [r["file"] for r in results if r["index"] is None],
                        "dropped": ["%s (%s)" % (x, r["file"]) for r in asked for x in r["dropped"]][:8],
                        "notes": ["%s: %s" % (r["file"], n) for r in asked for n in (r["notes"] + r["problems"])][:6]})
    return answers


# ---------------------------------------------------------------------------------------------- the Requirements agent
def req_instruction():
    """agentic/prompts/f4_requirements.md"""
    return prompts.load("f4_requirements", questions_most=QUESTIONS_MOST)


REQ_SHAPE = """{"requirements": [{"text": "...", "settles": ["H1"]}, {"text": "...", "settles": []}], "data_needed": [{"what": "...", "file": "...", "column": "...", "why": "..."}],
 "definitions": [{"term": "...", "exact": "...", "from": "..."}], "questions": [{"question": "...", "why": "...", "about": ["H2"]}], "answers": ["..."]}"""
FOUND, NOT_FOUND, CANNOT_TELL = "found", "not found", "cannot tell"


def _kept_requirements(r, proc):
    k = ((r.get("coding") or {}).get("requirements")) or {}
    return k if k and k.get("procedure_sha") == PR.sha(proc) else None


def _dictionary_entry(facts, file, column):
    """What Family 1's dictionary of a file says of one column -> (rows that hold a value, lines, meaning), or None."""
    lv = PR.tree_column(column)[0] if file == PR.TREE else None
    name, col = (PR.FILE_NAME.get(lv), PR.tree_column(column)[1]) if lv else (file, column)
    d = facts["dicts"].get(name)
    e = admin_ask._index(d).get(str(col).strip().lower()) if d else None
    return (e["rows"], e["lines"], e["meaning"] or e["observed"]) if e else None


# ---------------------------------------------------------------------------------------------- a column that stands for another
def _decisions(inp):
    return [x for x in (inp or {}).get("substitutes") or [] if isinstance(x, dict) and x.get("need")]


def stands_map(decisions):
    """{(file, column the procedure names): {"file", "column"}} from the admin's "use it" choices for missing columns."""
    out = {}
    for d in decisions or []:
        if isinstance(d, dict) and d.get("choice") == USE and d.get("wanted_column") and d.get("wanted_file"):
            out[(d["wanted_file"], d["wanted_column"])] = {"file": d.get("file"), "column": d.get("column")}
    return out


def _latest(decisions, key):
    """The admin's last word on one need: (USE decision | ADD_FILE decision | None, {(file, column)} he said are not the same)."""
    last, refused = None, set()
    for d in decisions:
        if d["need"] != key:
            continue
        if d.get("choice") == NOT_SAME:
            refused.add((d.get("file"), d.get("column")))
            if last is not None and last.get("choice") == USE and (last.get("file"), last.get("column")) in refused:
                last = None
        elif d.get("choice") in (USE, ADD_FILE):
            last = d
    return last, refused


def _proposal_line(p):
    """One proposed column as one line of the card: what the program counted, and what speaks against it."""
    o = p.get("overlap") or {}
    parts = ["**%s: %s** (%s)" % (p["file"], p["column"], p["level"])]
    if p.get("meaning"):
        parts.append("means: %s%s" % (_cell(p["meaning"], 160), " [%s]" % _cell(p["meaning_source"], 60) if p.get("meaning_source") else ""))
    parts.append("%s hold a value, %s distinct" % (_rows(p.get("rows_with_a_value")), "{:,}".format(p["distinct_values"]) if isinstance(p.get("distinct_values"), int) else "not counted"))
    if p.get("shape"):
        parts.append("its values look like: %s (for example %s)" % (p["shape"], ", ".join(str(v) for v in (p.get("some_values") or [])[:3])))
    if o:
        parts.append("%d of the %d wanted values are in it (%s%%), %s%s" % (o["found"], o["wanted_values"], o["share_percent"], o["basis"],
                                                                         "; seen at line%s %s" % ("" if len(o.get("lines") or []) == 1 else "s", ", ".join(str(x) for x in o["lines"])) if o.get("lines") else ""))
    if p.get("model_reason"):
        parts.append("the model's reading: %s" % _cell(p["model_reason"], 200))
    if p.get("against"):
        parts.append("against it: %s" % _cell("; ".join(p["against"]), 400))
    return "; ".join(parts)


def find_substitutes(ctx, facts, proc, kinds, decisions, item_words=""):
    """(owner, 2026-11-14: "if there is a column name is not available, it doesn't mean that the column itself might not be
    present ... go deep dive") For every column the procedure names that its file does not have, and every kind of data
    Family 1 did not find under a name: the admin's earlier choice is applied, or the columns of every file that could
    hold the same kind of data are looked for (column_match: by values, shape and meaning; the model picks from the short
    list, file by file at the same time) and put to the admin as one question each, with the evidence.
    -> (questions, notes for the card). Nothing is substituted without the admin's choice."""
    files = [{"name": n, "path": facts["paths"][n], "dictionary": facts["dicts"].get(n)} for n in analysis_files(facts)]
    needs = []
    for s in facts["sources"]:
        if s["file"] == PR.TREE or not s.get("in_this_analysis"):
            continue
        for c in s["columns"]:
            if not c["in_the_data"]:
                # what the column should hold, in the procedure's own words: the first step that names it (where it is said how it is read)
                said = next((x for x in proc["steps"] if re.search(r"(?<![A-Za-z0-9_])%s(?![A-Za-z0-9_])" % re.escape(c["name"]), x)), "")
                needs.append({"key": "column|%s|%s" % (s["file"], c["name"]), "what": "the column %s of %s, which the procedure names" % (c["name"], s["file"]),
                              "file": s["file"], "column": c["name"], "description": (said or item_words).strip()[:400], "kind": None, "chosen": c.get("stands_for_it")})
    for k in kinds:
        if k["status"] in (NOT_FOUND, CANNOT_TELL) and not k["column"]:
            needs.append({"key": "kind|" + k["what"].lower(), "what": k["what"], "file": "", "column": "", "description": k["what"], "kind": k, "chosen": None})
    questions, notes = [], []
    for need in needs:
        last, refused = _latest(decisions, need["key"])
        if last is not None and last["choice"] == USE:
            if need["kind"] is not None:
                e = _dictionary_entry(facts, last["file"], last["column"]) if _has_column(facts, last["file"], last["column"]) else None
                if _has_column(facts, last["file"], last["column"]):
                    need["kind"].update(status=FOUND, substitute=last, named={"file": last["file"], "column": last["column"], "rows": e[0] if e else None, "lines": e[1] if e else "",
                                                                             "meaning": (e[2] if e else "")[:200], "in_family_1_dictionary": bool(e), "chosen_by_the_admin": True})
            notes.append("%s: **%s column %s** stands for it, as %s chose (%s)." % (_cell(need["what"], 120), last["file"], last["column"], last.get("by") or "the admin", last.get("level") or ""))
            continue
        if last is not None and last["choice"] == ADD_FILE:
            notes.append("%s: %s said the file that holds it will be added. Put it into the folder and press **Read the new files** at the step after Family 1, "
                         "then send your answers here again." % (_cell(need["what"], 120), last.get("by") or "the admin"))
            continue
        if len(questions) >= SUBSTITUTE_QUESTIONS_MOST:
            continue
        try:
            res = column_match.propose(ctx.engine.runner, ctx.run["id"], files, column=need["column"], file=need["file"], description=need["description"])
        except Exception as e:          # noqa: BLE001 - the search is a help: its failure is said, and the card stays as it was
            if str(e) == "the run was stopped":
                raise
            notes.append("%s: the search for another column that holds it could not be made (%s)." % (_cell(need["what"], 120), " ".join(str(e).split())[:160]))
            continue
        props = [p for p in res["proposals"] if (p["file"], p["column"]) not in refused][:PROPOSALS_PER_NEED]
        looked = res["looked_at"]
        if not props:
            notes.append("%s: the program compared %d column%s of %d file%s by their values and meanings and found none that holds it%s." % (
                _cell(need["what"], 120), looked["columns"], "" if looked["columns"] == 1 else "s", looked["files"], "" if looked["files"] == 1 else "s",
                "; you said of %d that they are not the same" % len(refused) if refused else ""))
            continue
        strong = [p for p in props if p["level"] != column_match.NAME_ONLY]
        questions.append({"kind": "substitute", "need": need["key"], "what": need["what"], "wanted_file": need["file"], "wanted_column": need["column"],
                          "question": "The rule needs %s. No column of that name holds it. %s Which is right?" % (
                              need["what"], ("%d other column%s could hold the same kind of data." % (len(strong), "" if len(strong) == 1 else "s")) if strong
                              else "Only by its name, %d column%s alike; nothing the program counted supports it." % (len(props), " is" if len(props) == 1 else "s are")),
                          "why": "the program compared %d columns of %d file%s by their values, their shape and the meanings Family 1 recorded; nothing is used until you choose" % (
                              looked["columns"], looked["files"], "" if looked["files"] == 1 else "s"),
                          "proposals": props, "choices": [USE, NOT_SAME, ADD_FILE], "by": res.get("producer")})
    return questions, notes


def family2_facts(ctx, facts, proc):
    """(owner, 2026-11-14: the Coding family "must talk to the agent 1, agent 2 family") What Family 2 knows of the tree this
    rule reads, in sentences for the card and for the agents: the strategy that built it, the rows of each level the
    procedure reads and how many of them the joins left without a row above, and what the build counted for each join."""
    db = facts.get("db")
    if not db or not facts.get("on_tree"):
        return []
    out = []
    try:
        from . import family2
        st = family2.last_strategy(family2.project_format(ctx.project or {})[0])
        if st:
            out.append("The tree was built with joining strategy version %s, approved by %s." % (st.get("version"), st.get("approved_by") or "the admin"))
    except Exception:           # noqa: BLE001 - facts for the card only
        pass
    try:
        tf = PR.tree_facts(db)
        levels = list(dict.fromkeys(PR.tree_column(c)[0] for s in proc["source_data"] if s["file"] == PR.TREE for c in s["columns"]))
        for lv in levels:
            n = (tf.get("rows_per_level") or {}).get(lv)
            if n is None:
                continue
            lone = (tf.get("rows_without_a_parent") or {}).get(lv)
            out.append("%s: %s%s." % (PR.FILE_NAME.get(lv, lv), _rows(n), "" if lone is None else "; %s of them are not joined to a row of the level above%s" % (
                "{:,}".format(lone), " (the code must say what happens to them)" if lone else ""))) 
    except Exception:           # noqa: BLE001
        pass
    try:
        con = sqlite3.connect(db)
        try:
            row = con.execute("SELECT v FROM meta WHERE k='build'").fetchone()
        finally:
            con.close()
        rep = json.loads(row[0]) if row and row[0] else {}
        for name, st in (rep.get("steps") or {}).items():
            if isinstance(st, dict):
                nums = ["%s %s" % (k.replace("_", " "), "{:,}".format(v)) for k, v in st.items() if isinstance(v, int) and not isinstance(v, bool) and k != "seconds"]
                if nums:
                    out.append("Join %s, as the build counted it: %s." % (name.replace("_", " "), "; ".join(nums[:8])))
    except Exception:           # noqa: BLE001 - a tree without a build report (an older one): the rows above are what is known
        pass
    return out[:12]


def research_path(ctx, r, proc):
    d = os.path.join(family1.knowledge_dir(), "rules_code", r["section"], r["level"])
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "%s.p%d.run%s.research.json" % (r["id"], int(proc.get("version") or 0), ctx.run["id"]))


def _files_stamp(facts, proc):
    """The files the rule reads as they are on disk now (size and last change): a record of them is kept while they stay so."""
    out = {}
    for s in proc["source_data"]:
        names = [PR.FILE_NAME.get(PR.tree_column(c)[0]) for c in s["columns"]] if s["file"] == PR.TREE else [s["file"]]
        for n in names:
            p = facts["paths"].get(n) if n else None
            if p and os.path.exists(p):
                st = os.stat(p)
                out[n] = [st.st_size, st.st_mtime_ns]
    return out


def _research(ctx):
    """(owner, 2026-11-14: "the coding family is the coding research family ... first you need to check the family one, family
    two, and family three's admin's input") Before the requirements: the ledger of what Families 1, 2 and 3 hold for this
    rule, and what the content of the columns it reads shows, measured by code in one pass per file. No review of its
    own: the record opens the requirements card."""
    r = family3._rule(ctx)
    st = PR.code_state(r)
    if st["kind"] == "detector":
        return core.Result({"why_skipped": "detector"}, skip="this item runs the detector's own code, which is part of the application: there is nothing to research or code")
    if st["kind"] == "none":
        raise RuntimeError("'%s' has no procedure yet: write it (Edit rule/procedure) first" % r["name"])
    proc = PR.procedure_of(r)
    if st["verified"] and not ctx.input.get("comments"):
        return core.Result({"why_skipped": "verified"}, skip="the code of procedure version %s is already verified: nothing is researched or coded again" % st.get("procedure_version"))
    if _kept_requirements(r, proc) and not ctx.input.get("comments"):
        return core.Result({"why_skipped": "requirements kept"}, skip="the requirements approved before for this procedure version are used again, with the research they were made from")
    facts = data_facts(ctx, proc, {})
    stamp = _files_stamp(facts, proc)
    old = _output(ctx.step)
    if (old.get("record") or {}).get("procedure_sha") == PR.sha(proc) and old.get("files_stamp") == stamp and not ctx.input.get("comments"):
        return core.Result(old, skip="kept: the files the rule reads did not change since they were researched for this procedure version, so they were not read again")
    f2 = family2_facts(ctx, facts, proc)
    record = RS.build(ctx, r, proc, facts, f2)
    path = research_path(ctx, r, proc)
    family1.L.write_json_atomic(path, record, indent=1)
    by = sorted({x["by"] for x in record["researchers"].values() if x.get("by")})
    return core.Result({"record": record, "record_file": path, "files_stamp": stamp, "procedure_sha": PR.sha(proc)}, producer="; ".join(by) or "the program (counted, no model)")


def research_of(ctx, req=None):
    """The data research record of this item: the research step's, else the file the approved requirements name."""
    try:
        rec = (ctx.output_of("research") or {}).get("record")
    except Exception:               # noqa: BLE001 - a run made before the step existed has none
        rec = None
    if not rec and (req or {}).get("research_file") and os.path.exists(req["research_file"]):
        try:
            with open(req["research_file"], encoding="utf-8") as fh:
                rec = json.load(fh)
        except (OSError, ValueError):
            rec = None
    return rec if isinstance(rec, dict) and rec.get("files") is not None else None


def _fell_back(producer):
    """True when a model was asked and the stand-in answered in its place (the runner names the failure after "after:")."""
    p = str(producer or "").lower()
    return p.startswith("stand-in") and "(after:" in p


def _hidden_question(h):
    return "The rule does not say %s. What should the code do?" % h["decision"]


def _req(ctx):
    """What the code needs, made exact with the admin and checked with Family 1 and Family 2 -> REVIEW (it comes back with
    the admin's answers until nothing is open)."""
    r = family3._rule(ctx)
    st = PR.code_state(r)
    if st["kind"] == "detector":
        return core.Result({"requirements": [], "why_skipped": "detector"}, skip="this item runs the detector's own code, which is part of the application: there is nothing to code")
    if st["kind"] == "none":
        raise RuntimeError("'%s' has no procedure yet: write it (Edit rule/procedure) first" % r["name"])
    proc = PR.procedure_of(r)
    comments = [c for c in ctx.input.get("comments") or [] if c and c != ANSWERS_NOTE]
    qa = [x for x in ctx.input.get("qa") or [] if isinstance(x, dict)]
    said = bool(comments or qa)
    kept = _kept_requirements(r, proc)
    if st["verified"] and not said:
        return core.Result(dict(kept or {}, why_skipped="verified"),
                           skip="the code of procedure version %s is already verified (by %s): it is used again, nothing is asked or coded again" % (
                               st.get("procedure_version"), st.get("verified_by") or "the admin"))
    if kept and not said:
        return core.Result(dict(kept, reused=True), skip="the requirements approved before for this procedure version (by %s) are used again" % (
            kept.get("approved_by") or "the admin"))
    decisions = _decisions(ctx.input)
    facts = data_facts(ctx, proc, stands_map(decisions))
    f2 = family2_facts(ctx, facts, proc)
    research = research_of(ctx)
    hidden = list((research or {}).get("hidden") or [])
    ctx.progress("the Requirements agent reads the procedure, the data research and Family 1's dictionaries")
    others = []
    for s in facts["sources"]:
        names = [PR.FILE_NAME.get(c.get("level")) for c in s["columns"]] if s["file"] == PR.TREE else [s["file"]]
        for name in dict.fromkeys(n for n in names if n):
            d = facts["dicts"].get(name)
            if d:
                cols = [admin_ask._for_model(c) for c in admin_ask._index(d).values()]
                others.append({"file": name, "columns_family_1_knows": [dict(c, keywords=(c.get("keywords") or [])[:12]) if c.get("keywords") else c for c in cols][:120]})
            else:
                others.append({"file": name, "columns_family_1_knows": "no data dictionary of this file is approved yet"})
    context = {"ITEM": {"name": r.get("name"), "admin_words": r.get("description"),
                        "PROCEDURE": {"version": proc.get("version", 0), "source_data": proc["source_data"], "steps": proc["steps"], "output": proc["output"],
                                      "open_questions": proc.get("open_questions") or []}},
               "DATA": [{k: v for k, v in s.items() if k != "path"} for s in facts["sources"]], "OTHER_COLUMNS": others,
               "THE_TREE": {"built": bool(facts["db"]), "rows_per_level": PR.tree_facts(facts["db"]).get("rows_per_level") if facts["db"] else "not built for this analysis",
                            "what_family_2_reports": f2},
               "SUBSTITUTES": [{"needed": d.get("what"), "the_admin_chose": {USE: "use %s column %s for it" % (d.get("file"), d.get("column")), NOT_SAME: "%s column %s is not the same" % (d.get("file"), d.get("column")),
                                                                              ADD_FILE: "the file that holds it will be added"}.get(d.get("choice"))} for d in decisions],
               "ADMIN_SAID": {"answers": qa, "comments": comments}}
    if research:
        # long material first (the research), the rule and what the admin said after it; every hidden decision must be settled
        # by a requirement that names it, or asked of the admin: nothing is assumed in silence
        context = dict({"DATA_RESEARCH": RS.brief_for_agents(research),
                        "HIDDEN_DECISIONS": [{"id": h["id"], "decision": h["decision"], "because": h["because"]} for h in hidden]}, **context)

    def standin():
        return {"requirements": ["Input: %s." % "; ".join("%s (%s)" % (s["file"], ", ".join(s["columns"])) for s in proc["source_data"])]
                + list(proc["steps"]) + ["Output: %s%s." % (", ".join(proc["output"]["columns"]), " · " + proc["output"]["order"] if proc["output"].get("order") else "")],
                "data_needed": [{"what": "the column %s" % c, "file": s["file"], "column": c, "why": "the procedure reads it"} for s in proc["source_data"] for c in s["columns"]],
                "definitions": [], "questions": [], "answers": []}
    ans, producer, _ = ctx.engine.runner.ask(ctx.run["id"], "f4_requirements_" + r["id"], req_instruction(), json.dumps(context, ensure_ascii=False)[:170000],
                                             REQ_SHAPE, "requirements", standin, effort=REQ_EFFORT, http_effort=REQ_EFFORT)
    # every kind of data the agent lists, and every column the procedure itself names; a name that is not in the data is dropped here
    kinds, dropped = [], []
    listed = [n for n in (ans.get("data_needed") if isinstance(ans.get("data_needed"), list) else []) if isinstance(n, dict)]
    listed += [n for n in (ans.get("missing") if isinstance(ans.get("missing"), list) else []) if isinstance(n, dict)]       # an older shape: kinds without a column
    for n in listed:
        what = " ".join(str(n.get("what") or "").split())[:200]
        f, c = str(n.get("file") or "").strip(), str(n.get("column") or "").strip()
        ok = _has_column(facts, f, c)
        if (f or c) and not ok:
            dropped.append(("%s: %s" % (f, c)).strip(": "))
            f = c = ""
        if what and (what.lower(), f, c) not in {(x["what"].lower(), x["file"], x["column"]) for x in kinds}:
            kinds.append({"what": what, "file": f, "column": c, "why": " ".join(str(n.get("why") or "").split())[:240]})
    for s in proc["source_data"]:
        for c in s["columns"]:
            if (s["file"], c) not in {(x["file"], x["column"]) for x in kinds} and _has_column(facts, s["file"], c):
                kinds.append({"what": "the column %s" % c, "file": s["file"], "column": c, "why": "the procedure reads it"})
    kinds = kinds[:KINDS_MOST]
    ctx.progress("Family 1 is asked: the Manager of every file, for each of the %d kinds of data the rule needs" % len(kinds))
    f1 = ask_family1(ctx, facts, [k["what"] for k in kinds]) if kinds else []
    for k, a in zip(kinds, f1):
        named = None
        if k["column"]:                         # the column the agent (or the procedure) names for it: in the file, read by code
            e = _dictionary_entry(facts, k["file"], k["column"])
            named = {"file": k["file"], "column": k["column"], "rows": e[0] if e else None, "lines": e[1] if e else "", "meaning": (e[2] if e else "")[:200],
                     "in_family_1_dictionary": bool(e)}
        k.update(named=named, family_1=a, status=FOUND if (named or a["found"]) else NOT_FOUND if a["verdict"] == "no" else CANNOT_TELL)
    definitions = [{"term": " ".join(str(d.get("term") or "").split())[:120], "exact": " ".join(str(d.get("exact") or "").split())[:300],
                    "from": " ".join(str(d.get("from") or "").split())[:80] or "open"}
                   for d in (ans.get("definitions") if isinstance(ans.get("definitions"), list) else []) if isinstance(d, dict) and d.get("term")][:20]
    answered = {" ".join(str(x.get("question") or "").split()).lower() for x in qa}
    questions = []
    for q in ans.get("questions") if isinstance(ans.get("questions"), list) else []:
        text = " ".join(str(q.get("question") if isinstance(q, dict) else q or "").split())[:400]
        if text and text.lower() not in answered and text not in [x["question"] for x in questions]:
            questions.append({"question": text, "why": " ".join(str(q.get("why") or "").split())[:240] if isinstance(q, dict) else ""})
    questions = questions[:QUESTIONS_MOST]
    # a column that is missing under its name may be there under another: looked for in every file, and put to the admin
    ctx.progress("looking in every file for a column that holds what is missing under its name")
    sub_questions, sub_notes = find_substitutes(ctx, facts, proc, kinds, decisions, " ".join(str(r.get("description") or "").split()))
    questions = sub_questions + questions
    rounds = rounds_default(ctx.engine)
    # the requirements, numbered; each may say which hidden decisions it settles
    req_texts, settles = [], {}
    for x in ans.get("requirements") if isinstance(ans.get("requirements"), list) else []:
        text = " ".join(str(x.get("text") if isinstance(x, dict) else x or "").split())[:600]
        if not text:
            continue
        req_texts.append(text)
        got = [str(h).strip().upper() for h in (x.get("settles") if isinstance(x, dict) and isinstance(x.get("settles"), list) else [])]
        got += re.findall(r"\bH\d{1,2}\b", text)
        settles["R%d" % len(req_texts)] = sorted({h for h in got if h in {y["id"] for y in hidden}})
        if len(req_texts) >= 40:
            break
    req_ids = ["R%d" % i for i in range(1, len(req_texts) + 1)]
    # the conflicts the priority does not settle, and the hidden decisions no requirement settles, go to the admin
    settled = {h for v in settles.values() for h in v}
    asked_about = {str(h).strip().upper() for q in (ans.get("questions") if isinstance(ans.get("questions"), list) else []) if isinstance(q, dict)
                   for h in (q.get("about") if isinstance(q.get("about"), list) else [])}
    extra, left_open = [], []
    for c in (research or {}).get("conflicts") or []:
        if not c.get("settled") and c.get("question") and " ".join(c["question"].split()).lower() not in answered:
            extra.append({"kind": "conflict", "question": c["question"], "why": "found by the program: %s" % c["what"]})
    no_model = "stand-in" in str(producer).lower()
    for h in hidden:
        if h["id"] in settled or h["id"] in asked_about:
            continue
        q = _hidden_question(h)
        if " ".join(q.split()).lower() in answered:
            continue
        if no_model:
            left_open.append(h)             # no model is connected: the stand-in cannot settle it, and the card says so
        else:
            extra.append({"kind": "hidden", "about": [h["id"]], "question": q, "why": h["because"]})
    questions = extra[:10] + questions
    out = {"requirements": req_texts, "requirement_ids": req_ids, "requirement_settles": settles, "hidden": hidden, "hidden_left_open": [h["id"] for h in left_open],
           "research_file": (ctx.output_of("research") or {}).get("record_file") if research else None,
           "research": {k: research.get(k) for k in ("surprises", "conflicts", "words", "ledger", "links", "seconds")} if research else None,
           "data_needed": kinds, "definitions": definitions, "questions": questions,
           "substitutes": [d for d in decisions if d.get("choice") == USE and _latest(decisions, d["need"])[0] is d], "substitute_notes": sub_notes, "family_2": f2,
           "blocking": facts["blocking"], "dropped": dropped[:12], "qa": qa, "comments": comments, "answers": _texts(ans.get("answers")),
           "rounds": rounds, "procedure_sha": PR.sha(proc), "procedure_version": proc.get("version", 0), "by": producer, "tree_built": bool(facts["db"]),
           "folder": facts["folder"], "files": analysis_files(facts)}
    return core.Result(out, producer=producer, review={"title": "Requirements: %s" % r["name"], "body": _req_body(ctx, r, out),
                                                        "data": {"f4_req": True, "questions": questions, "blocking": facts["blocking"],
                                                                 "f4_research": dict(out["research"], hidden=hidden, files=[{"file": f["file"], "rows": f.get("rows"), "basis": f.get("basis"),
                                                                                                                         "touched": f.get("touched")} for f in research.get("files") or []]) if research else None,
                                                                 "not_found": _not_found(out), "rounds": rounds, "rounds_most": ROUNDS_MOST, "open": _open_points(out),
                                                                 "item": "%s/%s/%s" % (r["section"], r["level"], r["id"])}})


def _not_found(out):
    return [k["what"] for k in out.get("data_needed") or [] if k.get("status") == NOT_FOUND]


def _open_points(out):
    """What is still open in a requirements answer: the questions, and the kinds of data Family 1 could not tell about."""
    return len(out.get("questions") or []) + sum(1 for k in out.get("data_needed") or [] if k.get("status") == CANNOT_TELL)


def _cell(t, most=220):
    t = " ".join(str(t if t is not None else "").split()).replace("|", "/")
    return t[:most - 1] + "…" if len(t) > most else t


def _rows(n):
    return "{:,} rows".format(n) if isinstance(n, int) and not isinstance(n, bool) else "not counted"


def _req_body(ctx, r, out):
    body = ["**Admin %s, need review.** What the code of **%s** needs, before the Coder writes a line (procedure version %s). "
            "Nothing is coded until you say the requirements are complete." % (_admin(ctx), r["name"], out["procedure_version"]), ""]
    if out["answers"]:
        body += ["**Answers to you:**"] + ["- " + a for a in out["answers"]] + [""]
    if out["blocking"]:
        body += ["**The code cannot be made yet:**"] + ["- " + b for b in out["blocking"]] + [""]
    rec = out.get("research")
    if rec:
        full = research_of(ctx, out) or {}
        body += RS.record_body(dict(full, **{k: v for k, v in rec.items() if v is not None}) if full else rec)
    ids = out.get("requirement_ids") or []
    settles = out.get("requirement_settles") or {}
    body += ["**The requirements, numbered** (each is checked against the data after the code is written):"] + ([
        "- **%s** %s%s" % (ids[i] if i < len(ids) else "R%d" % (i + 1), s, " *(settles %s)*" % ", ".join(settles[ids[i]]) if i < len(ids) and settles.get(ids[i]) else "")
        for i, s in enumerate(out["requirements"])] or ["(none written)"]) + [""]
    if out.get("hidden_left_open"):
        body += ["No model is connected, so these open decisions are not settled by a requirement: %s. The stand-in's code takes the procedure's most literal reading." % ", ".join(out["hidden_left_open"]), ""]
    if out.get("family_2"):
        body += ["**Family 2 was asked about the tree this rule reads:**"] + ["- " + x for x in out["family_2"]] + [""]
    kinds = out["data_needed"]
    if kinds:
        asked = next((k["family_1"]["asked"] for k in kinds if k.get("family_1")), [])
        body += ["**Is the data there? Family 1 was asked** for each kind of data the rule needs: the Manager of %s. A Manager answers from its approved "
                 "data dictionary; the program looked every column and keyword it named up in the data, and took the rows and lines from the dictionary." % (
                     ", ".join(asked) if asked else "no file (no data dictionary is approved for the files of this analysis)"), "",
                 "| data the rule needs | is it there? | where: file, column (= keyword) | rows that hold it | where to see it | what it means, from Family 1 |", "|---|---|---|---|---|---|"]
        for k in kinds:
            lines, named = [], k.get("named")
            if named:
                lines.append((named["file"], named["column"] + " (named for it; in the file's header, read by code)", _rows(named["rows"]) if named["in_family_1_dictionary"]
                              else "not in Family 1's dictionary", named["lines"] or "", named["meaning"]))
            for x in (k.get("family_1") or {}).get("found") or []:
                if named and (x["file"], x["column"]) == (named["file"], named["column"]) and not x["keyword"]:
                    continue
                lines.append((x["file"], x["column"] + (" = " + x["keyword"] if x["keyword"] else " (the whole column)") + " (found by its Manager)", _rows(x["rows"]), x["lines"] or "", x["meaning"]))
            if not lines:
                lines.append(("", "in no file" if k["status"] == NOT_FOUND else "", "", "", ""))
            for i, (f, c, n, ln, m) in enumerate(lines[:4]):
                body.append("| %s | %s | %s | %s | %s | %s |" % (_cell(k["what"], 120) if i == 0 else "", ("**%s**" % k["status"]) if i == 0 else "",
                                                               _cell((f + ": " if f else "") + c, 160), n, _cell(ln, 60), _cell(m, 160)))
        body.append("")
        nf = [k for k in kinds if k["status"] == NOT_FOUND]
        ct = [k for k in kinds if k["status"] == CANNOT_TELL]
        if nf:
            body += ["**Not found in any file (%d): %s.** Every file of this analysis has a data dictionary, and every Manager said it is not there. "
                     "If another CSV file holds it: put that file into the folder%s and press **Read the new files** at the step after Family 1, then send your "
                     "answers here again. The code is not made without it unless you say so in your own words (the comment box) when you approve."
                     % (len(nf), "; ".join(k["what"] for k in nf), " " + out["folder"] if out.get("folder") else ""), ""]
        for k in ct:
            a = k.get("family_1") or {}
            why = ("no data dictionary is approved yet for %s" % ", ".join(a["no_dictionary"]) if a.get("no_dictionary") else
                   "; ".join(a.get("notes") or []) or "no Manager found it, and not every Manager could rule it out")
            body.append("**Family 1 cannot tell: %s.** %s." % (_cell(k["what"], 160), _cell(why, 400)))
        if ct:
            body.append("")
        drop = [x for k in kinds for x in (k.get("family_1") or {}).get("dropped") or []]
        if drop:
            body += ["Names a Manager gave that are not in its file were dropped: %s." % "; ".join(dict.fromkeys(drop)), ""]
    if out["dropped"]:
        body += ["The Requirements agent named these, which are not in the data, so they were dropped and are not counted as found: %s." % "; ".join(out["dropped"]), ""]
    if out["definitions"]:
        body += ["**The definitions the code will use:**", "", "| term | exact meaning | where it comes from |", "|---|---|---|"]
        body += ["| %s | %s | %s |" % (_cell(d["term"]), _cell(d["exact"], 300), _cell(d["from"])) for d in out["definitions"]]
        body.append("")
    if out.get("substitute_notes"):
        body += ["**Another column for what is missing under its name:**"] + ["- " + x for x in out["substitute_notes"]] + [""]
    if out["questions"]:
        body += ["**Questions to you (%d):**" % len(out["questions"])]
        for i, q in enumerate(out["questions"], 1):
            body.append("%d. %s%s" % (i, q["question"], " *(why: %s)*" % q["why"] if q["why"] else ""))
            for j, pr in enumerate(q.get("proposals") or [], 1):
                body.append("   - %s) %s" % ("abcdefgh"[j - 1], _proposal_line(pr)))
            if q.get("kind") == "substitute":
                body.append("   - Choose below: use one of them, say that none is the same, or say that you will add the file that holds it.")
        body += ["", "Write your answers in the boxes below (or all together in the comment box) and press **Send my answers**: the agent reads them and "
                     "asks again only what is still open.", ""]
    if out["qa"]:
        body += ["**Your answers so far:**"] + ["- %s → **%s**" % (_cell(x.get("question"), 200), _cell(x.get("answer"), 300)) for x in out["qa"]] + [""]
    n_open = _open_points(out)
    body += [("**%d point%s still open.**" % (n_open, "" if n_open == 1 else "s")) if n_open or _not_found(out) or out["blocking"] else "**Nothing is open.**",
             "When the requirements are complete, approve: the Coder writes the code and the Tester looks for an input on which it is wrong, round after "
             "round, at most %d rounds (you can change the number below, 1 to %d). You then review the final code with everything that was tried."
             % (out["rounds"], ROUNDS_MOST)]
    return "\n".join(body)


ANSWERS_NOTE = "answers to the questions"      # the comment the page sends with "Send my answers" when only the boxes were filled


def on_change(engine, run, step, data, admin, comment=""):
    """"Send my answers" on the requirements card: each answered question is kept with its question, so the agent sees them
    together. (A change on the code card needs nothing here: the comment itself is the feedback the loop starts from.)"""
    if step["key"] == "code":
        out_ = _output(step)
        edits_ = data["edits"] if isinstance(data.get("edits"), dict) else {}
        given = edits_.get("req_decisions") if isinstance(edits_.get("req_decisions"), dict) else {}
        if not out_.get("doubt") and given:
            ids = {x["id"] for x in out_.get("open_requirements") or []}
            engine.set_input(run["id"], step.get("full_key") or step["key"], req_decisions={k: v for k, v in given.items() if k in ids and v in (RS.ACCEPT, RS.ASK_CHECK, RS.CHANGE_REQ)})
        return _doubt_answers(engine, run, step, data, admin, comment)
    if step["key"] != "req":
        return
    out = _output(step)
    edits = data["edits"] if isinstance(data.get("edits"), dict) else {}
    answers = edits.get("answers")
    choices = edits.get("choices") if isinstance(edits.get("choices"), dict) else {}
    new, decided = [], []
    for i, q in enumerate(out.get("questions") or []):
        a = answers.get(str(i), answers.get(i)) if isinstance(answers, dict) else None
        ch = choices.get(str(i), choices.get(i))
        if q.get("kind") == "substitute" and isinstance(ch, dict) and ch.get("choice") in (USE, NOT_SAME, ADD_FILE):
            props = q.get("proposals") or []
            base = {"need": q["need"], "what": q.get("what"), "wanted_file": q.get("wanted_file") or "", "wanted_column": q.get("wanted_column") or "", "by": admin, "at": time.time()}
            if ch["choice"] == USE:
                j = ch.get("proposal")
                if not (isinstance(j, int) and not isinstance(j, bool) and 0 <= j < len(props)):
                    raise ValueError("say which of the columns shown stands for %s" % q.get("what"))
                pr = props[j]
                decided.append(dict(base, choice=USE, file=pr["file"], column=pr["column"], level=pr["level"]))
                said = "use %s column %s for it (%s)" % (pr["file"], pr["column"], pr["level"])
            elif ch["choice"] == NOT_SAME:
                decided += [dict(base, choice=NOT_SAME, file=pr["file"], column=pr["column"], level=pr["level"]) for pr in props]
                said = "none of the columns shown is the same (%s)" % "; ".join("%s: %s" % (pr["file"], pr["column"]) for pr in props)
            else:
                decided.append(dict(base, choice=ADD_FILE))
                said = "I will add the file that holds it"
            note = " ".join(a.split())[:600] if isinstance(a, str) and a.strip() and a.strip().lower() != said.lower() else ""
            new.append({"question": q["question"], "answer": said + (" · " + note if note and not note.startswith(("use ", "none of", "I will add")) else ""), "by": admin})
        elif isinstance(a, str) and a.strip():
            new.append({"question": q["question"], "answer": " ".join(a.split())[:1000], "by": admin})
    if not new and not (comment or "").strip():
        raise ValueError("write your answers first: in the boxes of the questions, or in the comment box")
    inp = core.jload(step.get("input"), {}) if not isinstance(step.get("input"), dict) else step["input"]
    qa = [x for x in (inp or {}).get("qa") or [] if isinstance(x, dict)] + new
    engine.set_input(run["id"], step.get("full_key") or step["key"], qa=qa, substitutes=_decisions(inp) + decided)


def _doubt_answers(engine, run, step, data, admin, comment):
    """"Send my answers" on the card that shows two results for the same data: which is meant, per data set. Kept with the
    step, so that the next build has them as the admin's word (and as the expected rows of that data set)."""
    out = _output(step)
    if not out.get("doubt"):
        return
    edits = data["edits"] if isinstance(data.get("edits"), dict) else {}
    answers = edits.get("answers") if isinstance(edits.get("answers"), dict) else {}
    choices = edits.get("choices") if isinstance(edits.get("choices"), dict) else {}
    inp = core.jload(step.get("input"), {}) if not isinstance(step.get("input"), dict) else step["input"]
    turn = int((inp or {}).get("doubt_turns") or 0) + 1
    new = []
    for i, d in enumerate(out.get("doubts") or []):
        ch = choices.get(str(i), choices.get(i))
        ch = ch.get("choice") if isinstance(ch, dict) else ch
        words = answers.get(str(i), answers.get(i))
        words = " ".join(words.split())[:1000] if isinstance(words, str) else ""
        if ch not in (FIRST, SECOND, NEITHER) and not words:
            continue
        ch = ch if ch in (FIRST, SECOND, NEITHER) else NEITHER
        rows = d.get("first") if ch == FIRST else d.get("second") if ch == SECOND else None
        said = ("the %s result is meant" % ch) if rows is not None else "neither result is meant"
        clean = words if not words.lower().startswith(("the first", "the second", "neither")) else ""
        new.append({"on": d.get("on"), "case": d.get("case"), "choice": ch, "rows": rows, "words": clean, "by": admin, "turn": turn,
                    "question": "On %s two programs written from your requirements gave different results. Which is meant?" % d.get("on"),
                    "answer": said + (": %s" % json.dumps(rows) if rows is not None else "") + (" · " + clean if clean else "")})
    if not new and not (comment or "").strip():
        raise ValueError("say first which result is meant: choose for each data set shown, or write it in the comment box")
    old = [x for x in (inp or {}).get("doubts_answered") or [] if isinstance(x, dict)]
    engine.set_input(run["id"], step.get("full_key") or step["key"], doubts_answered=old + new, doubt_turns=turn)


def on_approve(engine, run, step, data, admin):
    """req: the requirements are complete (refused while something blocks the code, or while points are open and the admin
    did not say "go on as they are"); the number of rounds goes to the code step and the requirements are kept with the item.
    code: the final code becomes the verified code of the procedure version (family3 stores it, as before)."""
    params = core.jload(run["params"], {}) or {}
    out = _output(step)
    edits = data.get("edits") if isinstance(data.get("edits"), dict) else {}
    key = step.get("full_key") or step["key"]
    if step["key"] == "req":
        if out.get("blocking"):
            raise ValueError("the code cannot be made yet: %s" % "; ".join(out["blocking"]))
        missing = _not_found(out)
        if missing and not (data.get("comment") or "").strip():
            raise ValueError("%d kind%s of data the rule needs %s not found in any file (%s): put the CSV file that holds it into the folder and press "
                             "Read the new files at the step after Family 1, or write in the comment box, in your own words, why the code should be made without it"
                             % (len(missing), "" if len(missing) == 1 else "s", "was" if len(missing) == 1 else "were", "; ".join(missing[:4])))
        n_open = _open_points(out)
        if n_open and not edits.get("accept_open"):
            raise ValueError("%d point%s still open: answer the questions and press Send my answers, or tick “go on with the open points as they are” "
                             "(the Coder then takes the most literal reading and says so)" % (n_open, " is" if n_open == 1 else "s are"))
        rounds = rounds_checked(edits["rounds"]) if edits.get("rounds") not in (None, "") else int(out.get("rounds") or ROUNDS_DEFAULT)
        engine.set_input(run["id"], key[:-len("req")] + "code", rounds=rounds)
        r = family3.load_rule(params["section"], params["level"], params["id"])
        if r is not None:
            keep = {k: out.get(k) for k in ("requirements", "requirement_ids", "requirement_settles", "hidden", "research_file", "data_needed", "definitions", "questions", "qa",
                                            "comments", "procedure_sha", "procedure_version", "substitutes", "family_2")}
            keep.update(approved_by=admin, approved_at=time.time(), rounds=rounds, open_points_accepted=n_open, not_found_accepted=missing or None,
                        accepted_because=(data.get("comment") or "").strip() or None)
            r.setdefault("coding", {})["requirements"] = keep
            family3.save_rule(r)
        return
    if step["key"] == "code" and out.get("doubt"):
        raise ValueError("say first which result is meant: choose for each data set shown and press Send my answers (or write it in the comment box). "
                         "The code is offered for approval after that")
    if step["key"] == "code" and out.get("code_file"):
        open_ = (out.get("failing") or []) + (out.get("set_aside") or [])
        if open_ and not (data.get("comment") or "").strip():
            raise ValueError("%d data set%s not settled (%s): write in the comment box why you accept the code as it is, or send it back with what to change"
                             % (len(open_), " is" if len(open_) == 1 else "s are", "; ".join(open_[:4]) + (" …" if len(open_) > 4 else "")))
        decided = _requirement_decisions(out, edits)
        if out.get("not_met") and not (data.get("comment") or "").strip():
            raise ValueError("not met: %s. Write in the comment box why you accept the code as it is, or send it back with what to change" % "; ".join(str(x) for x in out["not_met"][:4]))
        family3.on_approve(engine, run, dict(step, key="code"), data, admin)
        r = family3.load_rule(params["section"], params["level"], params["id"])
        if r is not None and (r.get("code") or {}).get("path") == out["code_file"]:
            r["code"].update(requirement_decisions=[dict(d, by=admin, at=time.time()) for d in decided] or None,
                             requirements_not_met_accepted=out.get("not_met") or None)
            r["code"].update(trail=out.get("trail_file"), rounds_used=out.get("rounds_used"), rounds_most=out.get("rounds_most"), clean=out.get("clean"),
                             accepted_with_open=open_ or None, accepted_because=(data.get("comment") or "").strip() or None)
            family3.save_rule(r)


def _requirement_decisions(out, edits):
    """The admin's decision on every requirement the table could not show to hold (nothing is chosen for him). Approval
    takes "accept as it is" for each; "ask for a check" and "the requirement must change" are sent back, not approved."""
    open_ = out.get("open_requirements") or []
    if not open_:
        return []
    given = edits.get("req_decisions") if isinstance(edits.get("req_decisions"), dict) else {}
    missing = [x["id"] for x in open_ if given.get(x["id"]) not in (RS.ACCEPT, RS.ASK_CHECK, RS.CHANGE_REQ)]
    if missing:
        raise ValueError("decide each requirement the program could not show to hold (%s): accept it as it is, ask for a check, or say that the requirement must change"
                         % ", ".join(missing[:8]))
    back = [x["id"] for x in open_ if given[x["id"]] != RS.ACCEPT]
    if back:
        raise ValueError("you asked for a check or a change for %s: send the code back (Ask for changes) with your comment, and the Coder and the Tester go on from it; "
                         "approving takes “accept as it is” for each" % ", ".join(back[:8]))
    return [{"id": x["id"], "requirement": x["requirement"], "verdict": x["verdict"], "decision": "accepted as it is"} for x in open_]


# ---------------------------------------------------------------------------------------------- the Coder and the Tester
def coder_instruction(on_tree):
    """agentic/prompts/f4_coder.md, then the rules of the code itself, which Family 3's Coder shares (procedures.py)."""
    return prompts.load("f4_coder") + (PR.CODER_INSTRUCTION_TREE if on_tree else PR.CODER_INSTRUCTION).split("THE CODE MUST:", 1)[1]


def tester_instruction():
    """agentic/prompts/f4_tester.md"""
    return prompts.load("f4_tester", cases_per_round=CASES_PER_ROUND)


CODER_SHAPE = """{"notes": ["..."], "code": "<the whole Python file>", "how": ["step 1: how the code does it", "..."], "changed": ["..."],
 "objections": [{"case": "...", "why": "..."}], "remarks_answered": [{"remark": "...", "answer": "..."}], "questions": ["..."],
 "procedure": null or {"source_data": [...], "steps": ["..."], "output": {"columns": ["..."], "order": "..."}, "open_questions": ["..."]},
 "changes": ["..."], "answers": ["..."]}"""

TESTER_SHAPE_FILES = """{"notes": ["..."], "cases": [{"name": "...", "property": "...", "why": "...", "files": {"<file name>": [{"<column>": "<cell>", "...": "..."}, {"...": "..."}]},
   "requirements": ["R1"], "expected_rows": [["<cell>", "..."], ["..."]] or null, "without_it_rows": [["<cell>", "..."]] or null, "order_matters": true}],
 "remarks": [{"where": "...", "what": "...", "why": "..."}], "replies": [{"case": "...", "keep": false, "why": "..."}], "nothing_more": false}"""
TESTER_SHAPE_TREE = """{"notes": ["..."], "cases": [{"name": "...", "property": "...", "why": "...",
   "tree": {"<level>": [{"row": 1, "cells": {"<column>": "<cell>"}, "parent": ["<level above>", 1] or null, "relation": "member", "time_ps": 0}]},
   "findings": [{"level": "...", "rule": "...", "name": "...", "severity": "...", "row": 1, "command_row": 1, "time_ps": 0}],
   "requirements": ["R1"], "expected_rows": [["<cell>", "..."], ["..."]] or null, "without_it_rows": [["<cell>", "..."]] or null, "order_matters": true}],
 "remarks": [{"where": "...", "what": "...", "why": "..."}], "replies": [{"case": "...", "keep": false, "why": "..."}], "nothing_more": false}"""
DATA_SHAPE_FILES = ("one object per record under its file's name: {column: cell}; a column you do not give is an empty cell; the file gets the "
                    "real header of the export, so repeated and empty header names are there as in the real file. \"_cut\": n in a record keeps "
                    "only its first n cells (a record cut short). A file you leave out has the header and no record.")
DATA_SHAPE_TREE = ("a small tree given by its rows and their parent links (the program builds it as Family 2's tree is stored, so the code reads "
                   "it through the same calls): per level a list of rows {row (its row number, unique in its level), cells {column: cell}, "
                   "parent [level above, row] or null (a row the joins left without a parent), relation member | context | orphan, time_ps}. "
                   "Levels top down: nvme_command > nvme_transaction > split > link > packets; a link row may hang under a split row or directly "
                   "under an nvme_transaction row. A level you leave out has no rows. \"findings\" fills what tree.findings() returns.")


def _num(v):
    try:
        f = float(str(v).strip().replace(",", "")) if not isinstance(v, bool) else None
    except (TypeError, ValueError, OverflowError):
        return None
    return f if f is not None and f == f and abs(f) != float("inf") else None


def _canon(cell):
    """A cell as it is compared: text without spaces at its ends; a number by its value ("3", "3.0" and 3 are the same)."""
    s = "" if cell is None else str(cell).strip()
    n = _num(s) if s else None
    return ("n", round(n, 6)) if n is not None else ("t", s)


def compare(expected, order_matters, got_cols, got_rows, want_cols):
    """The output of one small data set against what was expected -> "" when they agree, else the first difference in
    words. expected None: only the header is checked."""
    if got_cols != want_cols:
        return "the output's header is %s, the procedure's columns are %s" % (got_cols, want_cols)
    if expected is None:
        return ""
    exp = [[_canon(c) for c in row] for row in expected]
    got = [[_canon(c) for c in row] for row in got_rows]
    if not order_matters:
        exp, got = sorted(exp), sorted(got)
    if exp == got:
        return ""
    show = lambda row: [c[1] if c[0] == "t" else ("%g" % c[1]) for c in row]      # noqa: E731
    if len(exp) != len(got):
        extra = [show(x) for x in got if x not in exp][:2]
        lost = [show(x) for x in exp if x not in got][:2]
        return "expected %d line%s, the code wrote %d%s%s" % (len(exp), "" if len(exp) == 1 else "s", len(got),
                                                               "; not written: %s" % lost if lost else "", "; not expected: %s" % extra if extra else "")
    i = next(k for k, (a, b) in enumerate(zip(exp, got)) if a != b)
    return "line %d%s: expected %s, the code wrote %s" % (i + 1, "" if order_matters else " (both sorted)", show(exp[i]), show(got[i]))


def tiny_tree(path, levels_rows, findings, columns_by_level):
    """A small tree written the way Family 2's tree is stored, as far as nvme_hier.tree_api reads it (per level: the row
    number, the analyzer's number, the cells, the parent link, the relation, the time; and the detector's findings)."""
    from nvme_hier import tree_api as T
    if os.path.exists(path):
        os.remove(path)
    con = sqlite3.connect(path)
    try:
        for lv, t in T.TABLE.items():
            con.execute("CREATE TABLE %s (rowid_file INTEGER PRIMARY KEY, n INTEGER, raw TEXT, parent INTEGER, parent_level TEXT, relation TEXT, t_ps INTEGER)" % t)
            for k, row in enumerate(levels_rows.get(lv) or [], 1):
                cells = {c: "" for c in columns_by_level.get(lv) or []}
                cells.update({str(a): "" if b is None else str(b) for a, b in (row.get("cells") or {}).items()})
                par = row.get("parent") if isinstance(row.get("parent"), (list, tuple)) and len(row["parent"]) == 2 else None
                n = row.get("row") if isinstance(row.get("row"), int) and not isinstance(row.get("row"), bool) else k
                rel = row.get("relation") if row.get("relation") in ("member", "context", "orphan") else ("member" if par else None)
                tps = row.get("time_ps") if isinstance(row.get("time_ps"), int) and not isinstance(row.get("time_ps"), bool) else None
                con.execute("INSERT OR REPLACE INTO %s (rowid_file, n, raw, parent, parent_level, relation, t_ps) VALUES (?,?,?,?,?,?,?)" % t,
                            (n, n, json.dumps(cells), int(par[1]) if par else None, str(par[0]) if par else None, rel, tps))
        con.execute("CREATE TABLE finding (id INTEGER PRIMARY KEY, level TEXT, rule TEXT, name TEXT, severity TEXT, rowid INTEGER, cmd_rowid INTEGER, t_ps INTEGER)")
        for f in findings or []:
            if isinstance(f, dict):
                whole = lambda v: v if isinstance(v, int) and not isinstance(v, bool) else None      # noqa: E731
                con.execute("INSERT INTO finding (level, rule, name, severity, rowid, cmd_rowid, t_ps) VALUES (?,?,?,?,?,?,?)",
                            (str(f.get("level") or ""), str(f.get("rule") or ""), str(f.get("name") or ""), str(f.get("severity") or ""),
                             whole(f.get("row")), whole(f.get("command_row")), whole(f.get("time_ps"))))
        con.commit()
    finally:
        con.close()


class Build:
    """The rounds of one item: Coder -> the program's checks -> the small data sets -> Tester -> what failed -> Coder ..."""

    def __init__(self, ctx, r, proc, facts, req, rounds, feedback=None, before=None, want_second=False, research=None, cover=None):
        self.ctx, self.r, self.proc, self.facts, self.req, self.n = ctx, r, proc, facts, req or {}, rounds
        self.research = research                # the data research record (None for a run made before it existed)
        self.reqs = RS.requirement_ids(self.req)        # [(R1, text), ...]
        self.cover = [x for x in cover or [] if x in {i for i, _t in self.reqs}]      # requirements the admin asked a check for
        self.whole, self.table, self._coverage_asked, self.tester_by = None, None, False, ""
        self.base_proc, self.new_proc, self.changes, self.answers = proc, None, [], []
        self.admin_feedback = [c for c in feedback or [] if c]
        before = before or {}
        self.trail = self._load_trail(before.get("trail_file")) if self.admin_feedback else []
        self.cases = [dict(c) for c in before.get("cases") or [] if isinstance(c, dict)] if self.admin_feedback else []
        self.start_code = ""
        if self.admin_feedback and before.get("code_file") and os.path.exists(before["code_file"]):
            with open(before["code_file"], encoding="utf-8") as fh:
                self.start_code = fh.read()
        self.t0 = time.time()
        self.box = ctx.engine.runner.sandbox(ctx.run["id"], "family4_%s" % r["id"])
        self.sample = None
        self.rounds_used, self.stopped_because, self.best = 0, "", None      # best: the round whose code is offered
        self.by = ""
        self.want_second = bool(want_second)    # round 1: a second program, written independently, to find where the rule can be read two ways
        self.second, self.doubts = None, []
        runner = ctx.engine.runner
        # the Coder's rounds continue one kept conversation when the runner holds one per agent (AgentRunner.api_turn): a later
        # round then carries only what is new
        self.held = getattr(runner, "sessions", None) is not None and callable(getattr(runner, "path_now", None)) and runner.path_now() in ("http", "opencode")

    # ---- small helpers
    @property
    def on_tree(self):
        return PR.uses_tree(self.proc)

    @staticmethod
    def _load_trail(path):
        try:
            with open(path, encoding="utf-8") as fh:
                t = json.load(fh)
            return t.get("rounds") if isinstance(t, dict) and isinstance(t.get("rounds"), list) else []
        except (OSError, ValueError, TypeError):
            return []

    def _alive(self):
        """Stop means stop: a stopped run makes no further model call and runs no further data set."""
        rid = self.ctx.run["id"]
        if rid in getattr(self.ctx.engine.runner, "cancelled", ()):
            raise RuntimeError("the run was stopped")
        store = getattr(self.ctx.engine, "store", None)
        if store is not None:
            run = store.one("SELECT state FROM run WHERE id=?", (rid,))
            if run and run.get("state") not in (None, "running"):
                raise RuntimeError("the run was stopped")

    def say(self, k, part, what):
        self.ctx.progress(core.progress_text(100.0 * (k - 1 + part) / self.n, self.t0, what="round %d of %d: %s" % (k, self.n, what)))

    def _version(self):
        return int(self.base_proc.get("version") or 0) + (1 if self.new_proc else 0)

    def _code_path(self, seq):
        d = os.path.join(family1.knowledge_dir(), "rules_code", self.r["section"], self.r["level"])
        os.makedirs(d, exist_ok=True)
        return os.path.join(d, "%s.p%d.run%d.r%d.py" % (self.r["id"], self._version(), self.ctx.run["id"], seq))

    def trail_path(self):
        d = os.path.join(family1.knowledge_dir(), "rules_code", self.r["section"], self.r["level"])
        os.makedirs(d, exist_ok=True)
        return os.path.join(d, "%s.p%d.run%d.trail.json" % (self.r["id"], self._version(), self.ctx.run["id"]))

    def _columns_by_level(self):
        out = {}
        for s in self.proc["source_data"]:
            if s["file"] == PR.TREE:
                for c in s["columns"]:
                    lv, col = PR.tree_column(c)
                    out.setdefault(lv, []).append(col)
        return out

    # ---- the data sets
    def _program_cases(self):
        """The small data sets the program itself adds, the same for every item: they need no model and expect only that
        the code runs to the end and writes the output's header."""
        if self.on_tree:
            levels = list(self._columns_by_level())
            return [{"name": "an empty tree", "by": BY_PROGRAM, "why": "every level is there and has no row: the code must end and write the header",
                     "tree": {}, "expected_rows": None, "order_matters": False},
                    {"name": "one row per level, every cell empty, no parent", "by": BY_PROGRAM,
                     "why": "empty cells, and rows the joins left without a parent: the code must not stop on them",
                     "tree": {lv: [{"row": 1, "cells": {}}] for lv in levels}, "expected_rows": None, "order_matters": False}]
        files = [s["file"] for s in self.proc["source_data"]]
        return [{"name": "the header only, no record", "by": BY_PROGRAM, "why": "an export without a record: the code must end and write the header",
                 "files": {f: [] for f in files}, "expected_rows": None, "order_matters": False},
                {"name": "one record with every cell empty", "by": BY_PROGRAM, "why": "empty cells in every column the procedure reads",
                 "files": {f: [{}] for f in files}, "expected_rows": None, "order_matters": False},
                {"name": "one record cut short after its first cell", "by": BY_PROGRAM, "why": "a line with fewer cells than the header",
                 "files": {f: [{"_cut": 1}] for f in files}, "expected_rows": None, "order_matters": False}]

    def _case_problem(self, c):
        """Why a Tester's data set cannot be used, or "" (names are checked against the real header by code)."""
        if not isinstance(c, dict) or not str(c.get("name") or "").strip():
            return "it has no name"
        exp = c.get("expected_rows")
        if exp is not None and not (isinstance(exp, list) and all(isinstance(x, list) for x in exp)):
            return "its expected rows are not a list of rows"
        width = len(self.proc["output"]["columns"])
        if exp and any(len(x) != width for x in exp):
            return "an expected row does not have the output's %d columns" % width
        if self.on_tree:
            tree = c.get("tree")
            if not isinstance(tree, dict):
                return "it gives no tree"
            from nvme_hier import tree_api as T
            rows = 0
            for lv, rs in tree.items():
                if lv not in T.TABLE or not isinstance(rs, list) or not all(isinstance(x, dict) for x in rs):
                    return "its tree names %s, which is not a level" % lv if lv not in T.TABLE else "the rows of %s are not a list of rows" % lv
                rows += len(rs)
                for x in rs:
                    par = x.get("parent")
                    if par is not None and not (isinstance(par, list) and len(par) == 2 and par[0] in T.TABLE and isinstance(par[1], int)):
                        return "a row's parent must be [level, row] or null"
                    if not isinstance(x.get("cells") or {}, dict):
                        return "a row's cells must be {column: cell}"
            return "it has more than %d rows" % CASE_ROWS_MOST if rows > CASE_ROWS_MOST else ""
        files = c.get("files")
        if not isinstance(files, dict):
            return "it gives no files"
        own = [s["file"] for s in self.proc["source_data"]]
        for f, rs in files.items():
            if f not in own:
                return "it names the file %s, which the procedure does not read" % f
            if not isinstance(rs, list) or not all(isinstance(x, dict) for x in rs):
                return "the records of %s are not a list of {column: cell}" % f
            if len(rs) > CASE_ROWS_MOST:
                return "%s has more than %d records" % (f, CASE_ROWS_MOST)
            head = self.facts["headers"].get(f) or []
            bad = sorted({str(k) for x in rs for k in x if k != "_cut" and k not in head})
            if bad:
                return "it names %s, which the header of %s does not have" % (", ".join(bad[:4]), f)
        return ""

    def _sources_of(self, case, box):
        """The files (or the tree) of one small data set, written into its own folder -> the sources run_code is given."""
        os.makedirs(box, exist_ok=True)
        if self.on_tree:
            db = os.path.join(box, "tree.sqlite")
            tiny_tree(db, case.get("tree") or {}, case.get("findings"), self._columns_by_level())
            return {PR.TREE: db}
        out = {}
        for s in self.proc["source_data"]:
            head = self.facts["headers"].get(s["file"]) or list(s["columns"])
            dst = os.path.join(box, s["file"])
            with open(dst, "w", newline="", encoding="utf-8") as fh:
                w = csv.writer(fh)
                w.writerow(head)
                for rec in (case.get("files") or {}).get(s["file"]) or []:
                    cells = [""] * len(head)
                    for k, v in rec.items():
                        if k != "_cut" and k in head:
                            cells[head.index(k)] = "" if v is None else str(v)
                    cut = rec.get("_cut")
                    w.writerow(cells[:max(0, cut)] if isinstance(cut, int) and not isinstance(cut, bool) else cells)
            out[s["file"]] = dst
        return out

    def _run_case(self, case, code_path, tag):
        box = os.path.join(self.box, tag, re.sub(r"[^A-Za-z0-9]+", "_", case["name"])[:50] or "case")
        out_csv = os.path.join(box, "out.csv")
        try:
            src = self._sources_of(case, os.path.join(box, "src"))
            res = PR.run_code(code_path, src, out_csv, os.path.join(box, "run"), timeout=CASE_TIMEOUT_S, poll=0.05)
        except Exception as e:      # noqa: BLE001 - a data set that cannot be built or run is a result, not a crash of the loop
            res = {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}
        if not res.get("ok"):
            case.update(status="failed", detail="the code stopped: %s" % " ".join(str(res.get("error") or "").split())[-500:], got=None)
            return
        cols, rows, n = PR.read_output(out_csv, head=CASE_ROWS_MOST * 4)
        diff = compare(case.get("expected_rows"), bool(case.get("order_matters")), cols, rows, self.proc["output"]["columns"])
        case.update(status="failed" if diff else "passed", detail=diff or ("%d line%s, as expected" % (n, "" if n == 1 else "s") if case.get("expected_rows") is not None
                                                                           else "it ran to the end and wrote the header (%d line%s)" % (n, "" if n == 1 else "s")),
                    got=rows[:20])

    def _sample_run(self, code_path, tag):
        """The code on the first records of the real files (or on the tree of this analysis, with the try's time limit)."""
        names = [s["file"] for s in self.proc["source_data"]]
        box = os.path.join(self.box, tag, "real")
        if self.sample is None:
            real = {f: self.facts["paths"][f] for f in names}
            self.sample = PR.sample_sources(real, os.path.join(self.box, "real_sample"), records=SAMPLE_RECORDS)
        out_csv = os.path.join(box, "out.csv")
        res = PR.run_code(code_path, self.sample, out_csv, os.path.join(box, "run"), timeout=PR.TRY_TIMEOUT_S, poll=0.1)
        what = "the tree of this analysis" if self.on_tree else "the first %d records of %s" % (SAMPLE_RECORDS, ", ".join(names))
        if not res.get("ok"):
            slow = self.on_tree and "ran longer" in str(res.get("error"))
            return {"on": what, "ok": slow, "not_finished": slow, "error": " ".join(str(res.get("error") or "").split())[-600:], "checks": []}
        cols, head, n = PR.read_output(out_csv, head=50)
        self._sample_head = head
        checks = [c for c in PR.output_checks(self.proc, cols, head, n, res.get("summary")) if c["check"] != "the code wrote rows"]
        return {"on": what, "ok": all(c["ok"] for c in checks), "lines": n, "seconds": res.get("seconds"), "summary": res.get("summary"), "checks": checks,
                "head": head[:5], "columns": cols}

    # ---- the two agents
    def _data_for_agents(self):
        if self.on_tree:
            return {"THE_TREE": dict(PR.tree_facts(self.facts["db"]), COLUMNS=[c for s in self.facts["sources"] if s["file"] == PR.TREE for c in s["columns"]])}
        return {"FILES": [{"file": s["file"], "path_in_this_analysis": s.get("path"), "header_cells": s.get("header_cells"), "COLUMNS": s["columns"]}
                          for s in self.facts["sources"]]}

    def _requirements_for_agents(self):
        q = self.req
        out = {"requirements": [{"id": i, "text": t} for i, t in self.reqs], "definitions": q.get("definitions") or [], "the_admins_answers": q.get("qa") or [],
               "still_open": [x.get("question") for x in q.get("questions") or []]}
        stands = [{"the_procedure_names": "%s: %s" % (d.get("wanted_file"), d.get("wanted_column")) if d.get("wanted_column") else d.get("what"),
                   "read_instead": "%s: %s" % (d.get("file"), d.get("column")), "chosen_by": d.get("by"), "support": d.get("level")} for d in q.get("substitutes") or []]
        if stands:
            out["columns_that_stand_for_others"] = stands
        if q.get("family_2"):
            out["what_family_2_reports_about_the_tree"] = q["family_2"]
        return out

    def _coder_context(self, k, code, failed, remarks, fresh=None, later_round=False):
        proc = self.proc
        if later_round and self.held:
            # the same conversation holds the procedure, the requirements and the data of the first round
            context = {"item": self.r.get("name"), "ROUND": "%d of at most %d" % (k, self.n),
                       "ABOVE_IN_THIS_CONVERSATION": "the procedure, the requirements and the data are in your first round above and are not repeated"}
        else:
            context = dict({"item": self.r.get("name"), "ROUND": "%d of at most %d" % (k, self.n)},
                           **({"DATA_RESEARCH": RS.brief_for_agents(self.research)} if self.research else {}))
            context.update(dict({"PROCEDURE": {"version": proc.get("version", 0), "source_data": proc["source_data"], "steps": proc["steps"], "output": proc["output"]},
                                 "REQUIREMENTS": self._requirements_for_agents()}, **self._data_for_agents()))
        if self.admin_feedback:
            context["ADMIN_FEEDBACK"] = self.admin_feedback
        if fresh:
            context["FRESH_START"] = ("program %d: the program before this one was repaired %d times and still fails. Write a new program from the requirements; "
                                      "do not repair the old one. WHAT_FAILED lists what it got wrong." % (fresh, REPAIRS_PER_PROGRAM))
        elif code:
            context["YOUR_LAST_CODE"] = code
        if failed:
            context["WHAT_FAILED"] = failed
        if remarks:
            context["REMARKS"] = remarks
        aside = [{"case": c["name"], "the_tester_says": c.get("tester_reply"), "you_said": c.get("objection")} for c in self.cases if c.get("status") == SET_ASIDE]
        if aside:
            context["SET_ASIDE_FOR_THE_ADMIN"] = aside
        return context

    def _coder_standin(self):
        r, proc = self.r, self.proc

        def standin():
            c = PR.STANDIN_CODE.get(r["id"]) or PR.standin_share_code(proc)
            if not c:
                return {"code": "", "notes": ["no model is connected: only the seeded procedures and the share of one column have stand-in code"], "how": [],
                        "questions": ["no model is connected"]}
            return {"code": c, "notes": ["no model is connected: this is the stand-in's hand-written code of this procedure"], "how": [], "changed": []}
        return standin

    def _ask_coder(self, k, code, failed, remarks, fresh=None, later_round=False, program=1):
        """program: 1, or the number of a fresh program (2, 3, ...), which has a conversation of its own so that the old program
        is not in front of it. fresh: that number in the round the fresh program is started."""
        agent = "f4_coder_" + self.r["id"] + ("_fresh%d" % program if program > 1 else "")
        ans, producer, _ = self.ctx.engine.runner.ask(self.ctx.run["id"], agent, coder_instruction(self.on_tree), self._coder_context(k, code, failed, remarks, fresh, later_round),
                                                      CODER_SHAPE, "code", self._coder_standin(), effort=CODER_EFFORT, http_effort=CODER_EFFORT)
        return ans, producer

    def _ask_second(self):
        """The second program of round 1: the same document, the same requirements, a conversation of its own; it is not
        shown the first program. Without a model there is none (the stand-in would only repeat the first)."""
        ctx_ = self._coder_context(1, "", [], [])
        ctx_.pop("ADMIN_FEEDBACK", None)
        ans, producer, _ = self.ctx.engine.runner.ask(self.ctx.run["id"], "f4_second_" + self.r["id"], coder_instruction(self.on_tree), ctx_, CODER_SHAPE, "code",
                                                      lambda: {"code": "", "notes": ["no model is connected: no second program was written"]}, effort=CODER_EFFORT, http_effort=CODER_EFFORT)
        return ans, producer

    def uncovered(self):
        """The requirements no data set that can fail tests yet."""
        tested = {t for c in self.cases if c.get("status") in ("passed", "failed") for t in c.get("tests") or []}
        return [i for i, _t in self.reqs if i not in tested]

    def _ask_tester(self, k, objections, answered, cover=None):
        """The Tester works from the requirements and is not shown the code (a tester that reads the code writes tests that
        follow it: 61.0 % against 87.8 % correct tests in the AgentCoder ablation)."""
        proc = self.proc
        context = dict({"item": self.r.get("name"), "ROUND": "%d of at most %d" % (k, self.n),
                        "PROCEDURE": {"source_data": proc["source_data"], "steps": proc["steps"], "output": proc["output"]},
                        "REQUIREMENTS": self._requirements_for_agents(), "DATA_SHAPE": DATA_SHAPE_TREE if self.on_tree else DATA_SHAPE_FILES,
                        "DATA_SETS_SO_FAR": [{"name": c["name"], "by": c["by"], "property": c.get("property"), "why": c.get("why"), "result": c.get("status"), "detail": c.get("detail"),
                                              "tests": c.get("tests") or [], "does_not_test": c.get("does_not_test") or []} for c in self.cases],
                        "REQUIREMENTS_WITHOUT_A_DATA_SET_THAT_CAN_FAIL": cover if cover is not None else self.uncovered(),
                        "NEW_DATA_SETS_YOU_MAY_ADD": max(0, min(CASES_PER_ROUND, CASES_MOST - sum(1 for c in self.cases if c["by"] == BY_TESTER)))},
                       **self._data_for_agents())
        if self.research:
            context = dict({"DATA_RESEARCH": RS.brief_for_agents(self.research)}, **context)
        if objections:
            context["OBJECTIONS"] = objections
        if answered:
            context["REMARKS_ANSWERED"] = answered
        if cover:
            context["COVER_THESE_REQUIREMENTS"] = ("no data set that can fail tests %s yet: make one small data set for each, with the rows a program that ignored that "
                                                   "requirement would write in without_it_rows" % ", ".join(cover))

        def standin():
            return {"notes": ["no model is connected: only the program's own small data sets were run"], "cases": [], "remarks": [], "replies": [], "nothing_more": True}
        # the coverage pass has a conversation of its own (it asks for data sets for named requirements only)
        def ask(agent):
            return self.ctx.engine.runner.ask(self.ctx.run["id"], agent, tester_instruction(), context, TESTER_SHAPE_TREE if self.on_tree else TESTER_SHAPE_FILES, "cases", standin,
                                              effort=TESTER_EFFORT, http_effort=TESTER_EFFORT)[:2]
        name = ("f4_cover_" if cover else "f4_tester_") + self.r["id"]
        ans, producer = ask(name)
        if _fell_back(producer):
            # the model answered and the answer could not be read (found by the real check of 2026-11-14: one answer that was not
            # JSON made the stand-in the Tester, and the round was called clean with no data set). Asked once more, in a
            # conversation of its own; when that fails too the round says so and is not clean
            first = producer
            ans, producer = ask(name + "_again")
            if _fell_back(producer):
                ans = dict(ans, _could_not_be_read=_cell(first[first.find("(after:") + 7:].strip(" )"), 200))
            else:
                producer += " (asked a second time: the first answer could not be read)"
        return ans, producer

    def _take_cases(self, tans, seq, path):
        """The Tester's new data sets: checked against the real header, tagged with the requirements they test, run.
        A data set whose "without it" rows equal its expected rows cannot tell a program that ignored the requirement from one
        that follows it: it is kept, and marked as not testing that requirement. -> (new data sets, refused, in words)."""
        new, refused = [], []
        names = {c["name"] for c in self.cases}
        ids = {i for i, _t in self.reqs}
        room = CASES_MOST - sum(1 for c in self.cases if c["by"] == BY_TESTER)
        for c in (tans.get("cases") if isinstance(tans.get("cases"), list) else [])[:CASES_PER_ROUND]:
            why_not = self._case_problem(c)
            if why_not or room <= 0:
                refused.append("%s: %s" % (_cell((c or {}).get("name") if isinstance(c, dict) else "(no name)", 60), why_not or "no more data sets are taken"))
                continue
            name = " ".join(str(c["name"]).split())[:80]
            data = c.get("tree") if self.on_tree else c.get("files")
            if any(data == (x.get("tree") if self.on_tree else x.get("files")) and c.get("expected_rows") == x.get("expected_rows") for x in self.cases):
                refused.append("%s: the same data set is already there" % _cell(name, 60))
                continue
            k2 = 2
            while name in names:
                name, k2 = "%s (%d)" % (" ".join(str(c["name"]).split())[:76], k2), k2 + 1
            names.add(name)
            room -= 1
            keep = {"name": name, "by": BY_TESTER, "why": " ".join(str(c.get("why") or "").split())[:TEXT], "expected_rows": c.get("expected_rows"),
                    "property": " ".join(str(c.get("property") or "").split())[:TEXT], "order_matters": bool(c.get("order_matters")), "made_in_round": seq}
            keep.update({"tree": c["tree"], "findings": c.get("findings") if isinstance(c.get("findings"), list) else []} if self.on_tree else {"files": c["files"]})
            claimed = [str(x).strip().upper() for x in (c.get("requirements") if isinstance(c.get("requirements"), list) else []) if str(x).strip().upper() in ids]
            wo = c.get("without_it_rows")
            if claimed:
                probe = dict(keep, without_it_rows=wo, _want_cols=self.proc["output"]["columns"])
                if RS.can_fail(probe, compare):
                    keep.update(tests=claimed, without_it_rows=wo)
                else:
                    keep.update(does_not_test=claimed, without_it_rows=wo if isinstance(wo, list) else None)
            new.append(keep)
        for c in new:
            self._alive()
            self.cases.append(c)
            self._run_case(c, path, "r%d" % seq)
        return new, refused

    def _row_counts(self):
        """The data rows of each real file the procedure reads, counted by the application (the research's exact count when the
        file did not change since, else counted now)."""
        out = {}
        known = {f["file"]: f for f in (self.research or {}).get("files") or [] if f.get("rows") is not None and str(f.get("basis") or "").startswith("exact")}
        for s in self.proc["source_data"]:
            p = self.facts["paths"].get(s["file"])
            if s["file"] == PR.TREE or not p or not os.path.exists(p):
                continue
            out[s["file"]] = known[s["file"]]["rows"] if s["file"] in known else RS.count_rows(p)
        return out

    def _whole_run(self, code_path, tag, k):
        """The program on the WHOLE real file (not its first records), once per round whose small data sets pass: its output
        and its own accounting are checked for what needs no expected answer. For a rule on the tree the round's run on
        the tree is that run. -> {"on", "ok", "checks", "accounting", "rows", "seconds", "error", "not_finished"}."""
        if self.on_tree:
            sm = self.trail[-1].get("sample") or {}
            checks, acc = RS.accounting_checks(sm.get("summary"), {}, None, self.proc)
            return {"on": "the whole tree of this analysis", "ok": not any(c["ok"] is False for c in checks), "checks": checks, "accounting": acc,
                    "lines": sm.get("lines"), "seconds": sm.get("seconds"), "not_finished": bool(sm.get("not_finished"))}
        names = [s["file"] for s in self.proc["source_data"]]
        real = {f: self.facts["paths"][f] for f in names}
        box = os.path.join(self.box, tag, "whole")
        out_csv = os.path.join(box, "out.csv")
        on = "the whole of %s" % ", ".join(names)

        def tell(info):
            self.say(k, 0.93, "the code runs on %s: %s" % (on, (info or {}).get("text") or "reading"))
        try:
            res = PR.run_code(code_path, real, out_csv, os.path.join(box, "run"), timeout=WHOLE_TIMEOUT_S, progress=tell, poll=0.2)
        except Exception as e:      # noqa: BLE001 - a run that cannot start is a result, not a crash of the loop
            res = {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}
        if not res.get("ok"):
            slow = "ran longer" in str(res.get("error"))
            return {"on": on, "ok": slow, "not_finished": slow, "error": " ".join(str(res.get("error") or "").split())[-600:],
                    "checks": [{"check": "the program runs on the whole file", "ok": None if slow else False,
                                "detail": ("it did not finish in %d s: Run reads it all, with its progress shown" % WHOLE_TIMEOUT_S) if slow else " ".join(str(res.get("error") or "").split())[-300:]}],
                    "accounting": None}
        rows = self._row_counts()
        _cols, _head, n = PR.read_output(out_csv, head=5)
        checks, acc = RS.accounting_checks(res.get("summary"), rows, out_csv, self.proc)
        return {"on": on, "ok": not any(c["ok"] is False for c in checks), "checks": checks, "accounting": acc, "rows": rows, "lines": n, "seconds": res.get("seconds")}

    def _proof(self):
        """The requirement-by-check table as it stands now (decided by code)."""
        classify = {}
        for c in self.cases:
            for rid in c.get("tests") or []:
                if c.get("status") == "failed":
                    classify[rid] = "the code is wrong: it goes back to the Coder with the rows"
                elif c.get("status") == SET_ASIDE and rid not in classify:
                    classify[rid] = "the check may be wrong: for you to judge"
        self.table = RS.proof_table(self.reqs, self.cases, self.whole, classify)
        return self.table

    # ---- the second program: where the rule can be read two ways
    def _take_second(self, got, seq):
        """The second program as far as it can be used: written to its own file, checked like the first."""
        if not got:
            return None
        ans, producer = got
        code = ans.get("code") if isinstance(ans.get("code"), str) else ""
        if not code.strip() or PR.check_code(code, tree=self.on_tree):
            return {"usable": False, "by": producer, "why": "it gave no code the program accepts"}
        path = self._code_path(seq)[:-3] + ".second.py"
        family3.L.write_text_atomic(path, code)
        return {"usable": True, "by": producer, "code_file": path, "notes": _texts(ans.get("notes"), most=12)}

    def _second_on(self, case, tag):
        """One data set on the second program -> (status, rows) without touching the data set's own result."""
        c = dict(case)
        self._run_case(c, self.second["code_file"], tag)
        return c.get("status"), c.get("got")

    @staticmethod
    def _same_rows(a, b, order_matters):
        if a is None or b is None:
            return a is None and b is None
        x, y = [[_canon(c) for c in row] for row in a], [[_canon(c) for c in row] for row in b]
        return x == y if order_matters else sorted(x) == sorted(y)

    def _compare_second(self, seq, sample, cases):
        """Both programs ran on the same data. Where they agree, nothing is asked. Where a Tester's expectation is
        contradicted by both in the same way, the expectation is set aside for the admin. Where the two differ and the
        expectation (if any) settles nothing, that is a real doubt about the rule: a question for the admin, with the
        rows. -> the doubts."""
        doubts, tag = [], "r%d_second" % seq
        try:
            box = os.path.join(self.box, tag, "real")
            out_csv = os.path.join(box, "out.csv")
            res = PR.run_code(self.second["code_file"], self.sample, out_csv, os.path.join(box, "run"), timeout=PR.TRY_TIMEOUT_S, poll=0.1)
            if res.get("ok") and sample.get("ok") and not sample.get("not_finished"):
                cols, head, n = PR.read_output(out_csv, head=50)
                if cols == sample.get("columns") and (n != sample.get("lines") or not self._same_rows(head[:50], self._sample_head, bool(self.proc["output"].get("order")))):
                    doubts.append({"on": sample["on"], "case": None, "why": "the real records", "data": None, "first": self._sample_head[:8], "second": head[:8],
                                   "first_lines": sample.get("lines"), "second_lines": n, "expected": None})
        except Exception as e:      # noqa: BLE001 - the second program is a help: when it cannot run on the records, nothing is asked for them
            if str(e) == "the run was stopped":
                raise
        for c in cases:
            if c.get("status") not in ("passed", "failed") or c.get("got") is None:
                continue
            self._alive()
            st2, got2 = self._second_on(c, tag)
            if got2 is None:
                continue                        # the second program stopped on it: that says nothing about the rule
            same = self._same_rows(c["got"], got2, bool(c.get("order_matters")))
            exp = c.get("expected_rows")
            if same:
                if c["status"] == "failed" and exp is not None and c["by"] == BY_TESTER:
                    c.update(status=SET_ASIDE, detail="%s (expected %s; both wrote %s)" % (EXPECTATION_DOUBTED, json.dumps(exp[:6]), json.dumps(c["got"][:6])),
                             objection="a second program, written independently from the same requirements, gives the same rows as the code",
                             tester_reply="", second_got=got2[:20], expectation_doubted=True)
                continue
            if exp is not None and (c["status"] == "passed" or st2 == "passed"):
                continue                        # the expectation agrees with one of the two: the other is simply wrong (a failing first program is repaired as usual)
            doubts.append({"on": "the small data set “%s”" % c["name"], "case": c["name"], "why": c.get("property") or c.get("why"),
                           "data": c.get("tree") if self.on_tree else c.get("files"), "first": c["got"][:12], "second": got2[:12], "expected": exp})
        return doubts[:5]

    def _take_procedure_change(self, ans):
        """The admin's feedback asked for something the procedure says differently: the Coder changed the procedure too."""
        if not self.admin_feedback or not isinstance(ans.get("procedure"), dict):
            return ""
        try:
            cand = PR.validate({k: ans["procedure"].get(k) for k in ("source_data", "steps", "output", "open_questions") if k in ans["procedure"]})
        except ValueError as e:
            return "the changed procedure is not complete: %s" % e
        if PR.sha(cand) != PR.sha(self.proc):
            if [s["file"] for s in cand["source_data"]] != [s["file"] for s in self.base_proc["source_data"]] or any(
                    c not in b["columns"] for a, b in zip(cand["source_data"], self.base_proc["source_data"]) for c in a["columns"]):
                return "the changed procedure reads other files or columns than the approved requirements: change the procedure first (Edit rule/procedure), then code it"
            self.new_proc, self.proc = cand, cand
            self.changes = _texts(ans.get("changes")) or ["see the steps"]
        return ""

    # ---- the rounds
    def run(self):
        code, failed, remarks, answered = self.start_code, [], [], []
        if not self.cases:
            self.cases = self._program_cases()
        last_sha = hashlib.sha256(code.encode()).hexdigest() if code else None
        program_no, on_this_program = 1, 0
        self._sample_head = []
        for k in range(1, self.n + 1):
            self._alive()
            seq = len(self.trail) + 1
            self.rounds_used = k
            # a program is repaired REPAIRS_PER_PROGRAM times at most; then a fresh one is written from the requirements and what failed
            fresh = on_this_program >= REPAIRS_PER_PROGRAM and bool(failed)
            if fresh:
                program_no, on_this_program = program_no + 1, 0
            on_this_program += 1
            with_second = k == 1 and self.want_second
            self.say(k, 0.02, "the Coder %s (the model's highest effort)%s" % (
                "starts a fresh program: the one before was repaired %d times and still fails" % REPAIRS_PER_PROGRAM if fresh else "revises the code" if code else "writes the code",
                "; a second program is written independently at the same time" if with_second else ""))
            t = time.time()
            second_got = None
            if with_second:
                with ThreadPoolExecutor(max_workers=2) as pool:
                    fa = pool.submit(self._ask_coder, k, code, failed, remarks)
                    fb = pool.submit(self._ask_second)
                    ans, producer = fa.result()
                    try:
                        second_got = fb.result()
                    except Exception as e:      # noqa: BLE001 - without a second program the round goes on as before
                        if str(e) == "the run was stopped":
                            raise
            else:
                ans, producer = self._ask_coder(k, "" if fresh else code, failed, remarks, fresh=program_no if fresh else None, later_round=on_this_program > 1, program=program_no)
            self.by = producer
            new_code = ans.get("code") if isinstance(ans.get("code"), str) else ""
            proc_problem = self._take_procedure_change(ans)
            self.answers = _texts(ans.get("answers")) or self.answers
            objections = {}
            for o in ans.get("objections") if isinstance(ans.get("objections"), list) else []:
                if isinstance(o, dict) and str(o.get("case") or "").strip():
                    objections[str(o["case"]).strip()] = " ".join(str(o.get("why") or "").split())[:TEXT]
            answered = [{"remark": " ".join(str(x.get("remark") or "").split())[:200], "answer": " ".join(str(x.get("answer") or "").split())[:TEXT]}
                        for x in (ans.get("remarks_answered") if isinstance(ans.get("remarks_answered"), list) else []) if isinstance(x, dict)][:12]
            sha = hashlib.sha256(new_code.encode()).hexdigest()
            path = self._code_path(seq)
            family3.L.write_text_atomic(path, new_code)
            rec = {"round": seq, "round_of_this_build": k, "of": self.n, "at": time.time(), "after_the_admins_feedback": self.admin_feedback[-1][:TEXT] if self.admin_feedback and k == 1 else None,
                   "coder": {"by": producer, "seconds": round(time.time() - t, 1), "notes": _texts(ans.get("notes") or ans.get("thinking"), most=20), "how": _texts(ans.get("how"), most=30),
                             "changed": _texts(ans.get("changed")), "questions": _texts(ans.get("questions")), "objections": [{"case": a, "why": b} for a, b in objections.items()],
                             "remarks_answered": answered},
                   "code_file": path, "code_lines": len(new_code.splitlines()), "same_code_as_the_round_before": sha == last_sha, "static": [], "sample": None,
                   "cases": [], "tester": None, "clean": False, "program": program_no, "fresh_program": bool(fresh), "second_program": None, "doubts": []}
            same, last_sha, code = sha == last_sha, sha, new_code
            self.trail.append(rec)
            static = (PR.check_code(code, tree=self.on_tree) if code.strip() else ["the Coder gave no code"]) + ([proc_problem] if proc_problem else [])
            if code.strip() and not static and not self.on_tree:
                # the licence check: every column the program reads by name is a column of the files the rule touches (or one the
                # admin chose to stand for another); a name that is in no such file is said, and the round is not clean
                heads = {f: h for f, h in self.facts["headers"].items() if isinstance(f, str) and f in [x["file"] for x in self.proc["source_data"]]}
                _read, unknown = RS.columns_read_by(code, heads)
                static += ["the program reads the column “%s”, which is not a column of %s (the header was read by the application)%s" % (
                    c, ", ".join(heads) or "the files the rule reads", "; the admin chose another column to stand for it: read that one" if any(
                        d.get("wanted_column") == c for d in self.req.get("substitutes") or []) else "") for c in sorted(unknown)[:6]]
            rec["static"] = static
            if static:
                failed = [{"found_by": "the program's check of the code text", "what": p} for p in static]
                remarks = []
                rec["said"] = "the program refused the code before running it: %s" % "; ".join(static[:3])
                if "stand-in" in producer.lower() and not code.strip():
                    self.stopped_because = "no model is connected and the stand-in has no code for this procedure"
                    break
                if same and not objections:
                    self.stopped_because = "the Coder returned the same code again and objected to nothing: another round would not differ"
                    break
                continue
            self._alive()
            self.say(k, 0.45, "the code runs on %s" % ("the tree" if self.on_tree else "the first %d real records" % SAMPLE_RECORDS))
            rec["sample"] = sample = self._sample_run(path, "r%d" % seq)
            # every data set made so far runs again; an objection of the Coder is noted on the data set it is about
            live = [c for c in self.cases if c.get("status") not in ("withdrawn", SET_ASIDE)]
            self.say(k, 0.55, "%d small data set%s run again" % (len(live), "" if len(live) == 1 else "s"))
            for c in live:
                self._run_case(c, path, "r%d" % seq)
                if c["status"] == "failed" and c["name"] in objections:
                    c["objection"] = objections[c["name"]]
                elif c["status"] == "passed":
                    c.pop("objection", None)
            self._alive()
            disputed = [{"case": c["name"], "the_coder_says": c["objection"], "your_reason_was": c.get("why"), "expected_rows": c.get("expected_rows"),
                         "the_code_wrote": c.get("got"), "difference": c.get("detail")} for c in live if c["status"] == "failed" and c.get("objection")]
            self.say(k, 0.6, "the Tester, who has not seen the code, makes small data sets from the requirements to find where it is wrong")
            t = time.time()
            tans, tproducer = self._ask_tester(k, disputed, answered)
            self.tester_by = tproducer
            replies = {str(x.get("case") or "").strip(): x for x in (tans.get("replies") if isinstance(tans.get("replies"), list) else []) if isinstance(x, dict)}
            for c in live:
                if c["status"] == "failed" and c.get("objection"):
                    rp = replies.get(c["name"])
                    c["tester_reply"] = " ".join(str((rp or {}).get("why") or "").split())[:TEXT] or ("the Tester did not answer the objection" if not rp else "")
                    c["status"] = "withdrawn" if rp is not None and rp.get("keep") is False and c["by"] == BY_TESTER else SET_ASIDE
            self.say(k, 0.85, "the Tester's new small data sets run")
            new, refused = self._take_cases(tans, seq, path)
            # a requirement that no data set that can fail tests yet: the Tester is asked once more, for exactly those
            model_tester = "stand-in" not in str(tproducer).lower()
            lacking = self.uncovered()
            if model_tester and lacking and not self._coverage_asked and self.reqs:
                self._coverage_asked = True
                self.say(k, 0.9, "the Tester is asked for a data set that can fail for %s" % ", ".join(lacking[:8]))
                try:
                    tans2, _tp2 = self._ask_tester(k, [], [], cover=lacking)
                    more, refused2 = self._take_cases(tans2, seq, path)
                    new += more
                    refused += refused2
                except Exception as e:      # noqa: BLE001 - the coverage pass is a help: without it the table says what is not checked
                    if str(e) == "the run was stopped":
                        raise
            if with_second:
                # where can the rule be read two ways? the second program answers that with data, not with an opinion
                self.second = self._take_second(second_got, seq)
                rec["second_program"] = {k2: v for k2, v in (self.second or {"usable": False, "why": "none was written"}).items()}
                if self.second and self.second.get("usable"):
                    self.say(k, 0.95, "both programs run on the same data: where their results differ, you are asked which is meant")
                    self.doubts = self._compare_second(seq, sample, live + new)
                    rec["doubts"] = self.doubts
            new_remarks = [{"where": _cell(x.get("where"), 80), "what": _cell(x.get("what"), TEXT), "why": _cell(x.get("why"), TEXT)}
                           for x in (tans.get("remarks") if isinstance(tans.get("remarks"), list) else []) if isinstance(x, dict) and (x.get("what") or x.get("why"))][:8]
            rec["tester"] = {"by": tproducer, "seconds": round(time.time() - t, 1), "notes": _texts(tans.get("notes") or tans.get("thinking"), most=20), "remarks": new_remarks,
                             "new_data_sets": [c["name"] for c in new], "refused": refused, "nothing_more": bool(tans.get("nothing_more"))}
            tester_failed = tans.get("_could_not_be_read") if "stand-in" not in str(producer).lower() else None
            if tester_failed:
                rec["tester"]["could_not_be_read"] = tester_failed
            rec["cases"] = [{"name": c["name"], "by": c["by"], "why": c.get("why"), "property": c.get("property"), "status": c.get("status"), "detail": c.get("detail"), "new": c in new,
                             "objection": c.get("objection"), "tester_reply": c.get("tester_reply"), "expected_rows": (c.get("expected_rows") or [])[:8] if c.get("expected_rows") is not None else None,
                             "got": (c.get("got") or [])[:8] if c.get("status") != "passed" else None,
                             "data": c.get("tree") if self.on_tree else c.get("files")} for c in self.cases]
            failing = [c for c in self.cases if c.get("status") == "failed"]
            sample_bad = not sample["ok"]
            # the whole real file, when the small data passes: what needs no expected answer is checked on every row
            self.whole = None
            if not failing and not sample_bad and "stand-in" not in str(producer).lower():
                self._alive()
                self.say(k, 0.92, "the code runs on the whole %s, and its accounting of every row is checked" % ("tree" if self.on_tree else "file"))
                self.whole = self._whole_run(path, "r%d" % seq, k)
            table = self._proof()
            unmet = RS.not_met(table)
            rec["whole_file"] = {x: (self.whole or {}).get(x) for x in ("on", "ok", "checks", "accounting", "rows", "lines", "seconds", "error", "not_finished")} if self.whole else None
            rec["proof"] = {"rows": [{k2: x.get(k2) for k2 in ("id", "verdict", "why", "class")} for x in table["rows"]], "whole_file": table["whole_file"],
                            "without_a_check": table["without_a_check"]}
            whole_bad = bool(self.whole) and not self.whole["ok"]
            rec["clean"] = not failing and not sample_bad and not new_remarks and not whole_bad and not tester_failed
            rec["failing"] = [c["name"] for c in failing]
            rec["said"] = self._round_words(rec, sample, failing, new_remarks)
            if self.whole:
                rec["said"] += "; on %s: %s" % (self.whole["on"], "; ".join("%s (%s)" % (c["check"], "holds" if c["ok"] is True else "DOES NOT HOLD: " + c["detail"] if c["ok"] is False
                                                                                         else "could not be checked: " + c["detail"]) for c in self.whole["checks"][:4]))
            if unmet:
                rec["said"] += "; not met: %s" % ", ".join(str(x) for x in unmet[:6])
            if self.doubts:
                rec["clean"] = False
                rec["said"] += "; a second program written independently gives another result on %d of them: you are asked which is meant" % len(self.doubts)
                self.stopped_because = ("two programs written independently from your requirements give different results on %d data set%s: the rule can be read two ways, "
                                        "so you are asked which result is meant before the rounds go on" % (len(self.doubts), "" if len(self.doubts) == 1 else "s"))
                break
            if tester_failed and not failing and not sample_bad and not whole_bad:
                rec["said"] += "; the Tester's answer could not be read, twice (%s): no new data set of the Tester checked this code" % tester_failed
                self.stopped_because = ("in round %d the Tester's answer could not be read, twice (%s): the code passed the program's own checks, but no new data set of the Tester "
                                        "checked it. The table below says which requirements nothing checks; Ask for changes starts the rounds again" % (k, tester_failed))
                break
            if rec["clean"]:
                self.stopped_because = ("round %d was clean: the program's checks, the run on real records and every data set passed, and the Tester, working from the requirements alone, added no data set that fails%s"
                                        % (k, "; on %s every check that needs no expected answer held" % self.whole["on"] if self.whole and all(c["ok"] is True for c in self.whole["checks"]) else ""))
                break
            failed = ([{"found_by": "the program: the code on %s" % sample["on"], "what": sample.get("error") or "; ".join("%s: %s" % (c["check"], c["detail"]) for c in sample["checks"] if not c["ok"])}]
                      if sample_bad else [])
            if whole_bad:
                # the proof is the feedback: the failing check with the program's own numbers and the lines it named
                failed += [{"found_by": "the application, on %s" % self.whole["on"], "what": "%s: %s" % (c["check"], c["detail"]), "your_accounting": self.whole.get("accounting"),
                            "the_files_rows_counted_by_the_application": self.whole.get("rows"),
                            "note": "the code is wrong, or its accounting is: every row read must be kept, left out for a stated reason, or counted as not evaluated, exactly once"}
                           for c in self.whole["checks"] if c["ok"] is False]
            failed += [{"found_by": "small data set “%s” (by %s)" % (c["name"], c["by"]), "requirements_it_tests": c.get("tests") or [],
                        "why_it_was_made": c.get("why"), "the_data": c.get("tree") if self.on_tree else c.get("files"),
                        "expected_rows": c.get("expected_rows"), "the_code_wrote": c.get("got"), "difference": c.get("detail"),
                        "note": "the expected rows are the Tester's claim: correct the code, or object when the procedure says otherwise" if c["by"] == BY_TESTER else
                                "the expected rows are the admin's own answer to which result is meant: the code must give them" if c["by"] == BY_ADMIN else
                                "expected: the code runs to the end and writes the header"} for c in failing]
            remarks = new_remarks
            if same and not objections:
                self.stopped_because = "the Coder returned the same code again and objected to nothing: another round would not differ"
                break
        else:
            self.stopped_because = "the %d rounds are used up" % self.n
        if not self.stopped_because:
            self.stopped_because = "the %d rounds are used up" % self.n
        self._offer()
        family1.L.write_json_atomic(self.trail_path(), {"item": "%s/%s/%s" % (self.r["section"], self.r["level"], self.r["id"]), "name": self.r.get("name"),
                                                        "procedure_version": self._version(), "run": self.ctx.run["id"], "rounds_at_most": self.n,
                                                        "stopped_because": self.stopped_because, "requirements": self._requirements_for_agents(),
                                                        "rounds": self.trail, "written_at": time.time()}, indent=1)
        return self

    @staticmethod
    def _round_words(rec, sample, failing, remarks):
        parts = ["the code ran on %s%s" % (sample["on"], "" if sample["ok"] and not sample.get("not_finished") else
                                           " but did not finish in the time of a try (not counted against it)" if sample.get("not_finished") else " and FAILED")]
        done = [c for c in rec["cases"] if c["status"] in ("passed", "failed")]
        parts.append("%d of %d small data sets passed" % (sum(1 for c in done if c["status"] == "passed"), len(done)))
        if failing:
            parts.append("failing: %s" % "; ".join(c["name"] for c in failing[:4]))
        if remarks:
            parts.append("%d remark%s of the Tester" % (len(remarks), "" if len(remarks) == 1 else "s"))
        return "; ".join(parts)

    def _offer(self):
        """The code offered to the admin: the last round's, unless the program refused it or it failed on the real records
        while an earlier round's did not; then the latest such round's, and every data set runs once more on it so that
        what the card says of the data sets is true of the code shown."""
        mine = self.trail[-self.rounds_used:] if self.rounds_used else self.trail[-1:]
        ran = [x for x in mine if not x["static"] and x.get("sample") and x["sample"]["ok"]]
        self.best = ran[-1] if ran else mine[-1]
        if self.best is not mine[-1]:
            for c in self.cases:
                if c.get("status") not in ("withdrawn", SET_ASIDE):
                    self._run_case(c, self.best["code_file"], "offered")
            self.whole = None               # the whole-file run belonged to another round's code
        self._proof()


def _code(ctx):
    """The verified code of the item's procedure (used again, never built again), or the rounds of Coder and Tester and
    then the admin's review of the final code with everything that was tried."""
    r = family3._rule(ctx)
    st = PR.code_state(r)
    if st["kind"] == "detector":
        return core.Result({"kind": "detector", "verified": True, "rule": st["rule"], "path": st["path"], "lines": st["lines"]})
    if st["kind"] == "none":
        raise RuntimeError("'%s' has no procedure yet: write it (Edit rule/procedure) first" % r["name"])
    comments = [c for c in ctx.input.get("comments") or [] if c and c != ANSWERS_NOTE]
    said = [x for x in ctx.input.get("doubts_answered") or [] if isinstance(x, dict)]
    turns = int(ctx.input.get("doubt_turns") or 0)
    if st["verified"] and not comments and not said:
        return core.Result({"kind": "python", "verified": True, "code_file": st["path"], "procedure_version": st.get("procedure_version"),
                            "verified_by": st.get("verified_by"), "reused": True})
    proc = PR.procedure_of(r)
    req = ctx.output_of("req") or {}
    if not req.get("requirements"):
        req = _kept_requirements(r, proc) or {}
    facts = data_facts(ctx, proc, stands_map(req.get("substitutes")))
    if facts["blocking"]:
        raise RuntimeError("the code cannot be made yet: %s" % "; ".join(facts["blocking"]))
    try:
        rounds = rounds_checked(ctx.input.get("rounds") or ctx.params.get("rounds") or req.get("rounds") or rounds_default(ctx.engine))
    except ValueError:
        rounds = rounds_default(ctx.engine)
    r["coded_from_sha"] = PR.sha(proc)               # this text is now the one the code belongs to: a seed is not reworded
    family3.save_rule(r)
    before = _output(ctx.step) if (comments or said) else None
    asked = bool(before and before.get("doubt"))           # the step comes back from "which result is meant"
    feedback = list(comments)
    if said:
        # the admin's word on which result is meant is part of the requirements from now on, and the data set it was said on
        # keeps his rows as its expected rows
        req = dict(req, qa=list(req.get("qa") or []) + [{"question": a.get("question"), "answer": a.get("answer"), "by": a.get("by")} for a in said])
        feedback += ["%s %s" % (a.get("question"), a.get("answer")) for a in said if a.get("turn") == turns]
    if asked:
        now = [a for a in said if a.get("turn") == turns]
        picks = {a.get("choice") for a in now}
        before = dict(before)
        if picks == {SECOND} and before.get("second_code_file") and os.path.exists(before["second_code_file"]):
            before["code_file"] = before["second_code_file"]           # every answer says the second result is meant: its program is the start
        cases = [dict(c) for c in before.get("cases") or []]
        for a in now:
            for c in cases:
                if a.get("case") and c.get("name") == a["case"] and a.get("rows") is not None:
                    c.update(expected_rows=a["rows"], by=BY_ADMIN, status=None, why="%s (the admin said which result is meant)" % (c.get("why") or ""))
        before["cases"] = cases
    # a second program is written when the build starts from the requirements or from an answer to "which is meant", not after a
    # review comment on the final code; and the admin is asked at most DOUBT_TURNS_MOST times
    want_second = turns < DOUBT_TURNS_MOST and (before is None or asked)
    # the admin's decisions on requirements the table could not show to hold: "ask for a check" goes to the Tester, "change the
    # requirement" goes to the Coder in his own words (his comment), both as the feedback this build starts from
    asked_for = ctx.input.get("req_decisions") if isinstance(ctx.input.get("req_decisions"), dict) else {}
    cover = [k for k, v in asked_for.items() if v == RS.ASK_CHECK]
    if comments and cover:
        feedback.append("The admin asks for a check that can fail for %s: the Tester makes a data set for each." % ", ".join(cover))
    if comments and [k for k, v in asked_for.items() if v == RS.CHANGE_REQ]:
        feedback.append("The admin says these requirements must change, as his comment says: %s." % ", ".join(k for k, v in asked_for.items() if v == RS.CHANGE_REQ))
    b = Build(ctx, r, proc, facts, req, rounds, feedback=feedback, before=before, want_second=want_second, research=research_of(ctx, req), cover=cover).run()
    return _doubt_result(ctx, r, b) if b.doubts else _code_result(ctx, r, b)


def _cases_out(b):
    return [{k: c.get(k) for k in ("name", "by", "why", "property", "files", "tree", "findings", "expected_rows", "order_matters", "status", "detail",
                                   "objection", "tester_reply", "made_in_round", "expectation_doubted", "tests", "does_not_test", "without_it_rows") if c.get(k) is not None} for c in b.cases]


def _records_table(data):
    """A small data set as lines of the card (the files' records, or the tree's rows)."""
    out = []
    for name, recs in (data or {}).items():
        out.append("   - %s: %s" % (name, "no record" if not recs else "; ".join(_cell(json.dumps(x, ensure_ascii=False), 160) for x in recs[:8]) + (" …" if len(recs) > 8 else "")))
    return out


def _doubt_result(ctx, r, b):
    """Two programs written independently from the same requirements gave different results on small data: the rule can
    be read two ways. The admin is shown the data and both results and says which is meant; then the rounds go on."""
    rec = b.trail[-1]
    body = ["**Admin %s, your word is needed.** Two programs were written independently from your requirements for **%s**. On %d data set%s they give different results, "
            "so the rule can be read in two ways. Say which result is meant; your answer becomes part of the requirements, and the rounds go on from it."
            % (_admin(ctx), r["name"], len(b.doubts), "" if len(b.doubts) == 1 else "s"), ""]
    questions = []
    for i, d in enumerate(b.doubts, 1):
        body.append("**%d. On %s**%s" % (i, d["on"], " (%s)" % _cell(d["why"], 200) if d.get("why") else ""))
        if d.get("data"):
            body += ["   The data:"] + _records_table(d["data"])
        body.append("   - the first program wrote%s: %s" % (" %s lines, the first ones" % "{:,}".format(d["first_lines"]) if d.get("first_lines") is not None else "", _cell(json.dumps(d["first"]), 500)))
        body.append("   - the second program wrote%s: %s" % (" %s lines, the first ones" % "{:,}".format(d["second_lines"]) if d.get("second_lines") is not None else "", _cell(json.dumps(d["second"]), 500)))
        if d.get("expected") is not None:
            body.append("   - the Tester expected: %s (neither program wrote that)" % _cell(json.dumps(d["expected"]), 300))
        body.append("")
        questions.append({"kind": "doubt", "question": "On %s: which result is meant?" % d["on"], "why": d.get("why") or "", "data": d.get("data"),
                          "first": d["first"], "second": d["second"], "expected": d.get("expected"), "choices": [FIRST, SECOND, NEITHER]})
    turns = int(ctx.input.get("doubt_turns") or 0)
    body += ["Choose for each one below and press **Send my answers**. If neither is meant, say in your own words what the result should be.",
             "You are asked this at most %d times for one item (this is time %d); after that the rounds go on with the first program and what is still unclear is shown on the code card."
             % (DOUBT_TURNS_MOST, turns + 1)]
    out = {"kind": "python", "verified": False, "doubt": True, "doubts": b.doubts, "code_file": rec["code_file"], "second_code_file": (b.second or {}).get("code_file"),
           "procedure_sha": PR.sha(b.proc), "procedure_version": b._version(), "by": b.by, "rounds_used": b.rounds_used, "rounds_most": b.n,
           "stopped_because": b.stopped_because, "trail_file": b.trail_path(), "cases": _cases_out(b)}
    return core.Result(out, producer=b.by, review={"title": "Which result is meant: %s" % r["name"], "body": "\n".join(body),
                                                    "data": {"f4_req": True, "f4_doubt": True, "questions": questions, "open": len(questions), "blocking": [], "not_found": [],
                                                             "item": "%s/%s/%s" % (r["section"], r["level"], r["id"])}})


def _code_result(ctx, r, b):
    rec = b.best
    last = b.trail[-1]
    path = rec["code_file"]
    with open(path, encoding="utf-8") as fh:
        code = fh.read()
    proc, v = b.proc, b._version()
    sample = rec.get("sample") or {}
    problems = list(rec["static"])
    if sample and not sample.get("ok"):
        problems.append("it failed on %s: %s" % (sample.get("on"), sample.get("error") or "; ".join(c["check"] for c in sample.get("checks") or [] if not c["ok"])))
    final_cases = b.cases if not rec["static"] else []           # as they stand for the code shown (code the program refused ran on none)
    failing = [c["name"] for c in final_cases if c.get("status") == "failed"]
    aside = [c for c in b.cases if c.get("status") == SET_ASIDE]
    clean = rec is last and bool(rec.get("clean"))
    checks = [{"check": "it compiles, imports only the standard library (and the NVMe names list), and defines run(%s, out_csv)" % ("tree" if b.on_tree else "sources"),
               "ok": not rec["static"], "detail": "; ".join(rec["static"][:3]) or "yes"}]
    if sample:
        checks.append({"check": "it runs on %s" % sample.get("on"), "ok": bool(sample.get("ok")),
                       "detail": "not finished in the time of a try: Run reads it all, with its progress shown" if sample.get("not_finished") else
                       sample.get("error") or "%s output line%s in %s s" % ("{:,}".format(sample.get("lines") or 0), "" if sample.get("lines") == 1 else "s", sample.get("seconds"))})
        checks += sample.get("checks") or []
    done = [c for c in final_cases if c.get("status") in ("passed", "failed")]
    if done:
        checks.append({"check": "the small data sets (the program's and the Tester's)", "ok": not failing,
                       "detail": "%d of %d passed%s" % (sum(1 for c in done if c["status"] == "passed"), len(done), "; failing: " + "; ".join(failing[:4]) if failing else "")})
    admin = _admin(ctx)
    used = len([x for x in b.trail if x.get("round_of_this_build")][-b.rounds_used:]) if b.rounds_used else 0
    table = b.table or RS.proof_table(b.reqs, final_cases, b.whole)
    # the table is shown whenever a model wrote the code: when the Tester did not answer, every requirement reads "could not be
    # checked" and the admin decides each (2026-11-14: before, a Tester that failed hid the table and the code was called clean)
    proof_by_model = "stand-in" not in str(b.by).lower()
    open_reqs = RS.open_requirements(table) if proof_by_model else []
    unmet = RS.not_met(table)
    clean = clean and not unmet
    body = ["**Admin %s, need review.** The code of **%s**, from procedure version %d%s, after **%d round%s of at most %d** of Coder and Tester. %s"
            % (admin, r["name"], v, " (changed as you asked: approving stores it as the new version)" if b.new_proc else "", used, "" if used == 1 else "s", b.n,
               "**The last round was clean.**" if clean else "**It is not clean:** read what is open below before you approve."), "",
            "Why the rounds ended: %s." % b.stopped_because, ""]
    if b.whole and not b.whole.get("not_finished") and not b.whole.get("error"):
        body += ["The code ran on %s and on the small data sets below: %s output line%s in %s s. **Run** (after you approve) makes the result you keep, with its progress shown."
                 % (b.whole["on"], "{:,}".format(b.whole.get("lines") or 0), "" if b.whole.get("lines") == 1 else "s", b.whole.get("seconds")), ""]
    else:
        body += ["The code was run on small data only: %s, and the small data sets below%s. **Run** (after you approve) reads the whole recording, with its progress shown. "
                 "**Try on a sample** runs it on as many first records as you choose." % (sample.get("on") or "nothing yet",
                 "; on the whole file it did not finish in %d s" % WHOLE_TIMEOUT_S if b.whole and b.whole.get("not_finished") else ""), ""]
    if proof_by_model:
        body += RS.table_body(table)
        if open_reqs:
            body += ["**For you to decide (%d): requirements the program could not show to hold.** For each one choose below: accept it as it is, ask for a check, or say that the "
                     "requirement must change. Nothing is chosen for you." % len(open_reqs)] + ["- **%s** %s: %s (%s)" % (x["id"], _cell(x["requirement"], 200), x["verdict"], _cell(x["why"], 200)) for x in open_reqs] + [""]
    elif b.reqs:
        body += ["No model is connected, so no data set was made for the requirements: nothing here shows that each requirement holds. The stand-in's code is the hand-written code of this procedure.", ""]
    if rec is not last:
        body += ["The code shown is the one of round %d: the program refused the code of the last round, or it failed on the real records. Every data set "
                 "ran once more on the code shown." % rec["round"], ""]
    if b.answers:
        body += ["**Answers to you:**"] + ["- " + a for a in b.answers] + [""]
    if b.new_proc:
        old = set(b.base_proc["steps"])
        body += ["**The procedure changes as you asked:**"] + ["- " + c for c in b.changes] + ["", "**Rules or procedure (version %d, new):**" % v] + [
            "%d. %s%s" % (i, s, "  ← changed" if s not in old else "") for i, s in enumerate(proc["steps"], 1)] + ["", "**Output:** %s" % ", ".join(proc["output"]["columns"]), ""]
    else:
        body += ["**Rules or procedure (version %d):**" % v] + ["%d. %s" % (i, s) for i, s in enumerate(proc["steps"], 1)] + [""]
    body += ["**How it went, round by round** (the whole chain of thought is in `%s`):" % _shown_path(b.trail_path()), "",
             "| round | the Coder | the program's checks and the data sets | the Tester |", "|---|---|---|---|"]
    for x in b.trail[-used:] if used else []:
        t = x.get("tester") or {}
        body.append("| %d | %s | %s | %s |" % (x["round"], _cell("; ".join(x["coder"]["changed"] or x["coder"]["notes"][:2]) or "wrote the code", 260),
                                             _cell(x.get("said") or "", 260),
                                             _cell(("added %d data set%s" % (len(t.get("new_data_sets") or []), "" if len(t.get("new_data_sets") or []) == 1 else "s")
                                                    + ("; %d remark%s" % (len(t["remarks"]), "" if len(t["remarks"]) == 1 else "s") if t.get("remarks") else "")
                                                    + ("; nothing more to try" if t.get("nothing_more") else "")) if t else "not asked: the code was refused before", 200)))
    body.append("")
    if failing:
        body += ["**Still failing (%d):**" % len(failing)]
        for c in final_cases:
            if c.get("status") == "failed":
                body.append("- “%s” (by %s): %s%s" % (c["name"], c["by"], _cell(c.get("detail"), 300),
                                                      " The expected rows are the Tester's claim, not a proven result." if c["by"] == BY_TESTER and c.get("expected_rows") is not None else ""))
        body.append("")
    if aside:
        body += ["**For you to judge (%d): the Coder and the Tester disagree, and neither is proven.** The code was not changed to fit these." % len(aside)]
        for c in aside:
            body += ["- “%s”: %s" % (c["name"], _cell(c.get("detail"), 260)),
                     "- the Tester (%s): %s" % ("why it made the data set" if not c.get("tester_reply") else "keeps it", _cell(c.get("tester_reply") or c.get("why"), 300)),
                     "- the Coder objects: %s" % _cell(c.get("objection"), 300)]
        body.append("")
    body += ["**Checks made by the program:**"] + ["- %s %s: %s" % ("✔" if c["ok"] else "✘", c["check"], c["detail"]) for c in checks]
    if problems:
        body += ["", "**Problems:** " + "; ".join(problems)]
    if last["coder"]["questions"]:
        body += ["", "**The Coder asks:**"] + ["- " + q for q in last["coder"]["questions"]]
    body += ["", "**The code** (%s):" % _shown_path(path), "", "```python", code.rstrip(), "```", "",
             "Approve: this becomes the **verified code** of procedure version %d, and Run uses it. Send it back with your comment: the Coder and the Tester "
             "start again from this code with what you said, again at most %d rounds." % (v, b.n)]
    out = {"kind": "python", "verified": False, "code_file": path, "procedure_sha": PR.sha(proc), "procedure_version": v, "by": b.by, "problems": problems, "checks": checks,
           "base_sha": PR.sha(b.base_proc), "new_procedure": b.new_proc, "changes": b.changes if b.new_proc else None, "answers": b.answers,
           "rounds_used": used, "rounds_most": b.n, "clean": clean, "stopped_because": b.stopped_because, "failing": failing, "set_aside": [c["name"] for c in aside],
           "trail_file": b.trail_path(), "cases": _cases_out(b), "proof": table if proof_by_model else None, "open_requirements": open_reqs, "not_met": unmet,
           "whole_file": {k: (b.whole or {}).get(k) for k in ("on", "ok", "checks", "accounting", "rows", "lines", "seconds", "error", "not_finished")} if b.whole else None,
           "programs_written": max([x.get("program") or 1 for x in b.trail] or [1]), "second_program": (b.second or {}).get("usable") if b.second else None}
    return core.Result(out, producer=b.by, review={"title": "Code: %s" % r["name"], "body": "\n".join(body),
                                                    "data": {"code_file": path, "checks": checks, "problems": problems, "try": not problems,
                                                             "item": "%s/%s/%s" % (r["section"], r["level"], r["id"]),
                                                             "f4": {"rounds_used": used, "rounds_most": b.n, "clean": clean, "failing": failing,
                                                                    "set_aside": [c["name"] for c in aside], "stopped_because": b.stopped_because},
                                                             "f4_proof": table if proof_by_model else None, "f4_open": open_reqs,
                                                             "f4_trail": [_short_round(x) for x in (b.trail[-used:] if used else [])]}})


def _shown_path(path):
    rel = os.path.relpath(path, family3.APP)
    return path if rel.startswith("..") else rel


def _short_round(x):
    """One round as the card's timeline shows it (the trail file holds everything)."""
    t = x.get("tester") or {}
    return {"round": x["round"], "of": x.get("of"), "after_feedback": x.get("after_the_admins_feedback"), "clean": x.get("clean"), "said": x.get("said"),
            "program": x.get("program"), "fresh_program": x.get("fresh_program"), "second_program": x.get("second_program"), "doubts": len(x.get("doubts") or []),
            "coder": {k: x["coder"].get(k) for k in ("by", "seconds", "notes", "changed", "how", "objections", "remarks_answered", "questions")},
            "code_file": x.get("code_file"), "code_lines": x.get("code_lines"), "same_code": x.get("same_code_as_the_round_before"), "static": x.get("static"),
            "sample": {k: (x.get("sample") or {}).get(k) for k in ("on", "ok", "not_finished", "error", "lines", "seconds")} if x.get("sample") else None,
            "tester": {k: t.get(k) for k in ("by", "seconds", "notes", "remarks", "new_data_sets", "refused", "nothing_more")} if t else None,
            "whole_file": x.get("whole_file"), "proof": x.get("proof"),
            "cases": [{k: c.get(k) for k in ("name", "by", "why", "property", "status", "detail", "new", "objection", "tester_reply", "expected_rows", "got")} for c in x.get("cases") or []]}
