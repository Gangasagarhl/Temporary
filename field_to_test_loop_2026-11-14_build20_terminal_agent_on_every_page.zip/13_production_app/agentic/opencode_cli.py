"""opencode: a terminal program as the application's way to a model.

(owner, 2026-11-13: "redirect from api calling to terminal with holding sessions and its name as stateful at the
backend, storing the previous session's conversation. Because api use is not allowed so use opencode ... at settings
there shall be model options to be given, so that i can chose the model i want".)

What is here: finding the program, the list of the models it offers (for Settings), the two confined agents every call
runs as, the command of one turn of a session, and the reading of the program's event lines. What the application
itself holds about a session (its name, its number at opencode, every question and answer) is in agentic/sessions.py.

Measured on opencode 1.19.4 (2026-11-13), not assumed:
  - `opencode run --format json` reads the message from standard input and writes one JSON event per line
    (step_start, text, tool_use, step_finish with the tokens, error); every event carries the session's number.
  - `-s <number>` continues that session: the model has the earlier turns (a word given in turn 1 came back in turn 2).
  - the program's own default agent may run commands and change files. The agents defined here may not: a read of
    /etc/hostname was refused by rule, and the model had no command, write or edit tool at all.
  - an unknown model ends with exit code 1 and an error event that names no reason: the model is checked against the
    program's own list before a call.
"""
import json
import os
import re
import subprocess
import threading
import time

AGENT, AGENT_WEB = "f2t", "f2t-web"
AGENT_INVESTIGATE = "f2t-investigate"    # the investigation agent after Family 1 (agentic/investigate.py)
# what the investigation agent may start in a shell: Python to read and write CSV files, and a few commands that only list
INVESTIGATE_COMMANDS = ("python3 *", "python *", "py *", "ls *", "ls", "dir *", "dir", "head *", "tail *", "wc *")

_RULES = ("You are one agent of an analysis application. Answer the request with exactly what it asks for, in the "
          "format it asks for, and nothing else. You may read the files in the current folder only. You never run "
          "commands and you never change, create or delete files.")
_READ_ONLY = {"*": "deny", "read": "allow", "grep": "allow", "glob": "allow", "list": "allow", "external_directory": "deny"}

EFFORT_ORDER = ["none", "minimal", "low", "medium", "high", "xhigh", "max"]
MODELS_KEPT_FOR = 600           # seconds the program's model list is kept before it is asked again


def config_content(read_dirs=None):
    """The configuration every call is started with (environment variable OPENCODE_CONFIG_CONTENT): the agents of the
    application's own. The last matching rule wins at opencode, so "*": deny first, then what is allowed.

    read_dirs: the folders the investigation agent may read besides its own folder (the analysis's data folder). That
    agent may also write files in its own folder and start Python and a few listing commands (measured 2026-11-14 with
    the real program: the data folder was read, /etc/hostname was refused, `python3` ran, `id` and `cat` were refused)."""
    web = dict(_READ_ONLY, webfetch="allow", websearch="allow")
    web["external_directory"] = "deny"
    outside = {"*": "deny"}
    for d in read_dirs or []:
        d = str(d).rstrip("/\\")
        if d:
            outside[d] = "allow"
            outside[d + "/*"] = "allow"
            if "\\" in d:
                outside[d + "\\*"] = "allow"
    bash = {"*": "deny"}
    bash.update({c: "allow" for c in INVESTIGATE_COMMANDS})
    investigate = {"*": "deny", "read": "allow", "grep": "allow", "glob": "allow", "list": "allow", "edit": "allow", "bash": bash,
                   "external_directory": outside}
    return json.dumps({
        "share": "disabled", "autoupdate": False,
        "agent": {
            AGENT_INVESTIGATE: {"mode": "primary", "description": "Explores the files of one analysis on request and writes CSV exports into its own folder.",
                                "prompt": ("You are the investigation agent of an analysis application. You work in your own folder; the file ANALYSIS.md "
                                           "there says what the analysis is and where its data is. You may read the data, run Python to explore it and write "
                                           "new files into your own folder only. You never change or delete the data files, and you never use the network."),
                                "permission": investigate},
            AGENT: {"mode": "primary", "description": "Answers one request; may only read the files in its own folder.",
                    "prompt": _RULES, "permission": _READ_ONLY},
            AGENT_WEB: {"mode": "primary", "description": "The same, and may also search the web and fetch pages.",
                        "prompt": _RULES + " When the request says so you may search the web and fetch pages.", "permission": web},
        }})


def environment(base=None, exe=None, read_dirs=None):
    """The environment of a call: the confined agents, no update of the program in the middle of a run, and none of the
    instructions, skills or project settings that other tools on this computer keep for themselves."""
    env = dict(base if base is not None else os.environ)
    for k in ("ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN", "ANTHROPIC_BASE_URL"):     # the application's own key and address are not opencode's:
        env.pop(k, None)                                                             # it uses what its own login holds for the chosen model
    env.update(OPENCODE_CONFIG_CONTENT=config_content(read_dirs), OPENCODE_DISABLE_AUTOUPDATE="1", OPENCODE_DISABLE_CLAUDE_CODE="1",
               OPENCODE_DISABLE_EXTERNAL_SKILLS="1", OPENCODE_DISABLE_PROJECT_CONFIG="1", OPENCODE_DISABLE_LSP_DOWNLOAD="1")
    if exe:                     # a service does not inherit the login shell's PATH
        d = os.path.dirname(os.path.abspath(exe))
        if d not in env.get("PATH", "").split(os.pathsep):
            env["PATH"] = d + os.pathsep + env.get("PATH", "")
    return env


def find(configured=None):
    """The opencode program: the configured path, then PATH, then the usual install folders."""
    import glob
    import shutil
    if configured and os.path.isfile(configured):
        return configured
    p = shutil.which("opencode")
    if p:
        return p
    home = os.path.expanduser("~")
    if os.name == "nt":
        cands = [os.path.join(os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming"), "npm", "opencode.cmd"),
                 os.path.join(home, ".opencode", "bin", "opencode.exe"), os.path.join(home, "scoop", "shims", "opencode.exe"),
                 os.path.join(home, ".bun", "bin", "opencode.exe")]
        for c in cands:
            if os.path.isfile(c):
                return c
        return None
    cands = [os.path.join(home, ".opencode", "bin", "opencode"), os.path.join(home, ".npm-global", "bin", "opencode"),
             os.path.join(home, ".local", "bin", "opencode"), os.path.join(home, ".bun", "bin", "opencode"), "/usr/local/bin/opencode",
             "/opt/homebrew/bin/opencode"] + sorted(glob.glob(os.path.join(home, ".nvm", "versions", "node", "*", "bin", "opencode")))
    for c in cands:
        if os.path.isfile(c) and os.access(c, os.X_OK):
            return c
    return None


def _quiet(cmd, timeout, env):
    return subprocess.run(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8",
                          errors="replace", timeout=timeout, env=env, **({"creationflags": 0x08000000} if os.name == "nt" else {}))


_versions = {}


def version(exe):
    """The program's version, asked once per program file as it is now (its path, size and time)."""
    try:
        st = os.stat(exe)
        key = (exe, st.st_size, st.st_mtime_ns)
    except OSError:
        return ""
    if key in _versions:
        return _versions[key]
    try:
        p = _quiet([exe, "--version"], 30, environment(exe=exe))
        v = (p.stdout or "").strip().splitlines()[-1][:40] if p.returncode == 0 and (p.stdout or "").strip() else ""
    except (OSError, subprocess.SubprocessError):
        v = ""
    if v:
        _versions[key] = v
    return v


# ---------------------------------------------------------------------------------------------- the models it offers
def parse_models(text):
    """`opencode models --verbose`: a line "provider/model", then that model's facts as a JSON object. -> list of
    {id, provider, name, context, output, variants, free, cost_in, cost_out} in the program's own order."""
    out, dec, seen = [], json.JSONDecoder(), set()
    for m in re.finditer(r"^([A-Za-z0-9_.-]+/[^\s{]+)[ \t]*\r?$", text or "", re.M):
        mid = m.group(1)
        if mid in seen:
            continue
        seen.add(mid)
        facts = {}
        j = (text or "").find("{", m.end())
        nxt = re.compile(r"^[A-Za-z0-9_.-]+/[^\s{]+[ \t]*\r?$", re.M).search(text, m.end())
        if j >= 0 and (nxt is None or j < nxt.start()):
            try:
                facts, _ = dec.raw_decode(text[j:])
            except ValueError:
                facts = {}
        if not isinstance(facts, dict):
            facts = {}
        limit = facts.get("limit") if isinstance(facts.get("limit"), dict) else {}
        cost = facts.get("cost") if isinstance(facts.get("cost"), dict) else {}
        variants = facts.get("variants")
        cin, cout = cost.get("input"), cost.get("output")
        known = isinstance(cin, (int, float)) and isinstance(cout, (int, float))
        out.append({"id": mid, "provider": mid.split("/", 1)[0], "name": str(facts.get("name") or mid.split("/", 1)[1]),
                    "context": limit.get("context") if isinstance(limit.get("context"), int) else None,
                    "output": limit.get("output") if isinstance(limit.get("output"), int) else None,
                    "variants": [v for v in EFFORT_ORDER if isinstance(variants, dict) and v in variants] + sorted(
                        v for v in (variants if isinstance(variants, dict) else {}) if v not in EFFORT_ORDER),
                    "free": bool(known and cin == 0 and cout == 0), "cost_known": known,
                    "cost_in": cin if known else None, "cost_out": cout if known else None})
    return out


_models = {"at": 0.0, "exe": None, "list": [], "problem": "", "asking": False}
_models_lock = threading.Lock()         # the cache
_ask_lock = threading.Lock()            # one question to the program at a time


def _ask_models(exe, runner=None):
    """Ask the program now. -> (list, problem). The cache is replaced only by a list that has models."""
    with _ask_lock:
        try:
            p = (runner or _quiet)([exe, "models", "--verbose"], 120, environment(exe=exe))
            found = parse_models(p.stdout) if p.returncode == 0 else []
            problem = "" if found else ("opencode listed no model: %s" % ((p.stderr or p.stdout or "").strip()[-200:] or "exit %s" % p.returncode))
        except (OSError, subprocess.SubprocessError) as e:
            found, problem = [], "opencode could not be asked for its models: %s" % str(e)[:200]
        with _models_lock:
            if found:
                _models.update(at=time.time(), exe=exe, list=found, problem="")
            _models["asking"] = False
        return found, problem


def models(exe, refresh=False, runner=None):
    """-> (list, problem in words). The program's own list. Asking it starts a process (measured: 5 to 15 s), so the
    list read last is given at once and, when it is older than 10 minutes, read again in the background; refresh=True
    asks now and waits (Settings' "Read the list again", and before a model is refused as not offered)."""
    if not exe:
        return [], "the opencode program was not found on this computer"
    with _models_lock:
        have = list(_models["list"]) if _models["exe"] == exe else []
        age = time.time() - _models["at"]
        stale = bool(have) and age >= MODELS_KEPT_FOR and not _models["asking"]
        if stale and not refresh:
            _models["asking"] = True
    if have and not refresh:
        if stale:
            threading.Thread(target=_ask_models, args=(exe, runner), daemon=True).start()
        return have, ""
    found, problem = _ask_models(exe, runner)
    if found:
        return list(found), ""
    if have:                            # the list of a moment ago, said as such
        return have, problem + " (showing the list read %d s ago)" % int(age)
    return [], problem


def warm(exe):
    """Read the version and the model list in the background (at the server's start), so Settings open at once."""
    if exe:
        threading.Thread(target=lambda: (version(exe), models(exe)), daemon=True).start()


def forget_models():
    with _models_lock:
        _models.update(at=0.0, exe=None, list=[], problem="", asking=False)


def model_facts(exe, model_id):
    """The facts of one model of the list, or None when the program does not offer it."""
    lst, _ = models(exe)
    for m in lst:
        if m["id"] == model_id:
            return m
    with _models_lock:
        fresh = time.time() - _models["at"] < 60
    if lst and not fresh:               # not in the list read earlier: the program is asked once more before saying no
        for m in models(exe, refresh=True)[0]:
            if m["id"] == model_id:
                return m
    return None


def variant_for(effort, variants):
    """The effort level a call asks for, as one of the levels this model has: the level itself, else the next higher
    one it has, else its highest. None when the model has no levels or nothing was asked."""
    if not effort or not variants:
        return None
    if effort in variants:
        return effort
    if effort not in EFFORT_ORDER:
        return None
    have = [v for v in EFFORT_ORDER if v in variants]
    if not have:
        return None
    i = EFFORT_ORDER.index(effort)
    higher = [v for v in have if EFFORT_ORDER.index(v) > i]
    return higher[0] if higher else have[-1]


# ---------------------------------------------------------------------------------------------- one turn
def safe_title(name):
    """A session's name as a command argument: letters, digits, spaces and a few signs (a .cmd launcher on Windows
    passes arguments through the command interpreter)."""
    t = re.sub(r"[^A-Za-z0-9 ._:#()\[\]-]+", " ", str(name or "")).strip()
    return re.sub(r"\s+", " ", t)[:120] or "session"


def command(exe, model, session=None, title=None, web=False, variant=None, agent=None):
    cmd = [exe, "run", "--pure", "--agent", agent or (AGENT_WEB if web else AGENT), "--format", "json", "-m", model]
    cmd += ["-s", session] if session else ["--title", safe_title(title)]
    if variant:
        cmd += ["--variant", variant]
    return cmd


TOO_MANY_WORDS = ("rate limit", "rate_limit", "too many requests", "429", "overloaded", "quota")


def read_events(stdout):
    """The event lines of one `opencode run --format json`. -> {session, text (the last step's text), texts (every
    text part in order), tokens (of the last step: how full the session is now), tools [{tool, status}], error,
    too_many}. Lines that are not JSON are kept as `other` (a program may print a notice)."""
    session, texts, last_step, tools, tokens, errors, other = None, [], [], [], None, [], []
    for line in (stdout or "").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            e = json.loads(line)
        except ValueError:
            other.append(line[:300])
            continue
        if not isinstance(e, dict):
            continue
        session = e.get("sessionID") or session
        part = e.get("part") if isinstance(e.get("part"), dict) else {}
        kind = e.get("type")
        if kind == "step_start":
            last_step = []
        elif kind == "text":
            t = part.get("text")
            if isinstance(t, str) and t:
                texts.append(t)
                last_step.append(t)
        elif kind in ("tool_use", "tool"):
            st = part.get("state") if isinstance(part.get("state"), dict) else {}
            tools.append({"tool": str(part.get("tool") or ""), "status": str(st.get("status") or "")})
        elif kind == "step_finish":
            if isinstance(part.get("tokens"), dict):
                tokens = part["tokens"]
        elif kind == "error":
            err = e.get("error") if isinstance(e.get("error"), dict) else {}
            data = err.get("data") if isinstance(err.get("data"), dict) else {}
            errors.append(str(data.get("message") or err.get("message") or err.get("name") or "error")[:300])
    low = " ".join(errors + other).lower()
    return {"session": session, "text": "".join(last_step) if last_step else (texts[-1] if texts else ""), "texts": texts,
            "tokens": tokens, "tools": tools, "error": "; ".join(errors), "other": other,
            "too_many": any(w in low for w in TOO_MANY_WORDS)}


LIMIT_WORDS = ("usage limit", "rate limit", "rate_limit", "too many requests", "quota", "status code 429", "statuscode=429")


NETWORK_WORDS = ("eai_again", "enotfound", "econnreset", "econnrefused", "etimedout", "ehostunreach", "enetunreach", "getaddrinfo",
                 "socket hang up", "fetch failed", "network", "unable to connect", "connection error", "connection closed")


def network_trouble(problem):
    """True when a turn failed because this computer did not reach the service (measured 2026-11-13: "getaddrinfo EAI_AGAIN
    opencode.ai" for a few minutes): such a turn is asked again, in the same session."""
    low = str(problem or "").lower()
    return any(w in low for w in NETWORK_WORDS)


def service_said(stderr):
    """The model service's own last words from the program's log lines (`error.error="..."`), or ""."""
    found = re.findall(r'error\.error="((?:[^"\\]|\\.)*)"', stderr or "")
    if not found:
        found = re.findall(r'level=ERROR.*?message="((?:[^"\\]|\\.)*)"', stderr or "")
        found = [f for f in found if f != "stream error"]
    return re.sub(r"^AI_APICallError:\s*", "", found[-1]).strip() if found else ""


def service_refused(line):
    """True for a log line in which the service refuses for a limit: the program would wait and try again in silence."""
    low = (line or "").lower()
    return "level=error" in low and any(w in low for w in LIMIT_WORDS)


def event_words(line):
    """One event line of a running turn as words for a person, or "" for an event that says nothing new: which file
    is read, what is searched, which command runs, what is written, and the agent's own sentences."""
    try:
        e = json.loads(line)
    except ValueError:
        return ""
    if not isinstance(e, dict):
        return ""
    part = e.get("part") if isinstance(e.get("part"), dict) else {}
    kind = e.get("type")
    if kind == "text":
        t = " ".join(str(part.get("text") or "").split())
        return ("the agent: " + t[:300]) if t else ""
    if kind in ("tool_use", "tool"):
        st = part.get("state") if isinstance(part.get("state"), dict) else {}
        inp = st.get("input") if isinstance(st.get("input"), dict) else {}
        tool, status = str(part.get("tool") or ""), str(st.get("status") or "")
        name = os.path.basename(str(inp.get("filePath") or inp.get("path") or "")) or str(inp.get("path") or "")
        what = {"read": "reading %s" % name, "list": "listing %s" % (name or "its folder"), "glob": "looking for files named %s" % inp.get("pattern"),
                "grep": "searching for %s" % str(inp.get("pattern"))[:80], "write": "writing %s" % name, "edit": "changing %s" % name,
                "bash": "running: %s" % " ".join(str(inp.get("command") or "").split())[:160]}.get(tool, "using its tool %s" % tool)
        if status == "error":
            return what + " (refused or failed: %s)" % " ".join(str(st.get("error") or "").split())[:120]
        return what
    if kind == "error":
        err = e.get("error") if isinstance(e.get("error"), dict) else {}
        data = err.get("data") if isinstance(err.get("data"), dict) else {}
        return "the program reported: %s" % str(data.get("message") or err.get("name") or "an error")[:200]
    return ""


def size_now(tokens):
    """How many tokens the session held at the end of a turn (what the next turn sends again), from a step's count."""
    if not isinstance(tokens, dict):
        return 0
    cache = tokens.get("cache") if isinstance(tokens.get("cache"), dict) else {}
    parts = sum(int(tokens.get(k) or 0) for k in ("input", "output", "reasoning")) + int(cache.get("read") or 0) + int(cache.get("write") or 0)
    return max(int(tokens.get("total") or 0), parts)


def delete_sessions(exe, ids, runner=None):
    """Remove sessions from the program's own store (when a run is deleted). Nothing is raised: the application's own
    record is what it relies on."""
    done = 0
    for sid in ids:
        if not (exe and sid and re.fullmatch(r"ses_[A-Za-z0-9]+", str(sid))):
            continue
        try:
            p = (runner or _quiet)([exe, "session", "delete", sid], 60, environment(exe=exe))
            done += 1 if p.returncode == 0 else 0
        except (OSError, subprocess.SubprocessError):
            pass
    return done
