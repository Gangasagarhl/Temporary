"""Family 4, the coding RESEARCH family: what is measured in the data before a line is coded, and how each requirement is
shown to hold on the data afterwards.

(owner, 2026-11-14: "basically the coding family is the coding research family. So the research will be on the content of
the data, columns of the data, it's all about the data. So first you need to check the family one, family two, and family
three's admin's input. And then finally code ... whatever the rule that will be told by the admin in the family 3
everything has to meet the requirements. Based on the data.")

Before the requirements (family4._research):
  the LEDGER       everything the rule needs, each line marked established (with its source), to measure, to decide (the
                   admin) or guess. Sources: Family 1 (the whole data dictionary of every file the rule touches), Family 2
                   (the joining strategy, and the facts of every parent-child link the rule crosses, counted in the built
                   tree), Family 3 (the admin's rule, its earlier versions, his comments and answers, dated, latest first).
  the DATA RESEARCH RECORD
                   measured by code in ONE streaming pass per touched file: for each column the rule touches the shapes of
                   its values, every spelling of "nothing", numbers written as text, the range, the most frequent values,
                   three sample rows, key uniqueness; and where the rule's own words are stored (which column, which
                   spelling, how many rows), or that they are in no column, with the nearest spellings.
  the CONFLICTS    found by code, never by a model: the rule against the data, the dictionary against the measured content,
                   one answer of the admin against another. Fixed priority: a measured count over a description; the
                   admin's latest dated answer over an earlier one; the rule against the data goes to the admin.
  the HIDDEN DECISIONS
                   what the rule leaves open (empty cells, rows without a parent, equality at a limit, units ...), raised
                   by code from what was measured; a Data researcher (the model, one call per touched file, all at once) may
                   add to them. Each becomes a requirement or a question: nothing is assumed in silence.

After the code (family4.Build):
  the REQUIREMENT-BY-CHECK TABLE
                   each numbered requirement with its checks, the evidence and a verdict decided by this code: met, not
                   met, not exercised, or could not be checked. A model never says whether a requirement is met.

Every count here is counted by this program. A fact is written as an observation with its count and its basis ("exact:
all 300 rows" or "the first 5,000 rows"), never as "always" or "never": an observation of one recording is not a rule for
the next (measured elsewhere: rules promoted from one data set raised false alarms on over 90 % of text columns).
"""
import difflib
import json
import os
import re
import sqlite3
import time
from concurrent.futures import ThreadPoolExecutor

from . import admin_ask, column_match, core, family1, prompts, procedures as PR

ESTABLISHED, TO_MEASURE, TO_DECIDE, GUESS = "established", "to measure", "to decide", "guess"
MET, NOT_MET, NOT_EXERCISED, NOT_CHECKED = "met", "not met", "not exercised", "could not be checked"
VERDICT_ORDER = (NOT_MET, NOT_CHECKED, NOT_EXERCISED, MET)
ACCEPT, ASK_CHECK, CHANGE_REQ = "accept", "check", "change"         # the admin's decision on a requirement that is not shown to hold
DISTINCT_CAP = 10000            # distinct values of one column kept while it is read; above it the count is "more than"
KEY_CAP = 2000000               # ... of a column used as a key, so that "is every value there once" stays exact
TOP_VALUES = 10
SAMPLE_ROWS = 3
NEAR = 0.84                     # how alike a value must be to a word of the rule to be shown as its nearest spelling (0 to 1)
HIDDEN_MOST = 12
ROWS_SHOWN = 20                 # rows of the real file shown as evidence of one check
NOTHING = {"n/a": "N/A", "na": "NA", "null": "NULL", "none": "None", "nan": "NaN", "-": "-", "--": "--", "?": "?", "reserved": "Reserved",
           "unknown": "Unknown", "not available": "not available", "(blank)": "(blank)", "nil": "nil", "tbd": "TBD"}
UNITS = {"ps": 1e-12, "ns": 1e-9, "us": 1e-6, "µs": 1e-6, "μs": 1e-6, "ms": 1e-3, "s": 1.0, "sec": 1.0, "second": 1.0, "seconds": 1.0,
         "millisecond": 1e-3, "milliseconds": 1e-3, "microsecond": 1e-6, "microseconds": 1e-6, "nanosecond": 1e-9, "nanoseconds": 1e-9,
         "picosecond": 1e-12, "picoseconds": 1e-12}
UNIT_NAME = {1e-12: "ps", 1e-9: "ns", 1e-6: "us", 1e-3: "ms", 1.0: "s"}
STOP = set("a an and are as at be by each every for from has have how if in into is it its of on or per than that the their then there this to was "
           "were what when where which with within without all any both count counts counted number numbers many list lists row rows column columns "
           "file files value values more less over under after before first last one two three not no only also show output write read".split())
COMPARE = re.compile(r"\b(more than|less than|greater than|later than|earlier than|longer than|shorter than|over|above|below|under|exceeds?|at least|at most|"
                     r"not more than|not less than|up to|within)\b", re.I)


def _n(x):
    return "{:,}".format(x) if isinstance(x, int) and not isinstance(x, bool) else "not counted"


def _plural(n, word):
    return "%s %s%s" % (_n(n), word, "" if n == 1 else "s")


def _num(v):
    try:
        f = float(str(v).strip().replace(",", ""))
    except (TypeError, ValueError, OverflowError):
        return None
    return f if f == f and abs(f) != float("inf") else None


# ---------------------------------------------------------------------------------------------- the rule's own words
def literals_of(*texts):
    """What the rule's words name that must be found in the data: text in quotation marks, and numbers with a unit of
    time. -> [{"text", "kind": "quoted" | "number", "value", "unit"}], each once, in the order of the words."""
    out, seen = [], set()
    for t in texts:
        t = str(t or "")
        for m in re.finditer(r"[\"“”']([^\"“”'\n]{1,60})[\"“”']", t):
            s = " ".join(m.group(1).split())
            if s and s.lower() not in seen and not s.lower().endswith(".csv") and s != "(blank)":
                seen.add(s.lower())
                out.append({"text": s, "kind": "quoted"})
        for m in re.finditer(r"(?<![A-Za-z0-9_.])(\d+(?:[.,]\d+)?)\s*(%s)\b" % "|".join(sorted(map(re.escape, UNITS), key=len, reverse=True)), t):
            key = "%s %s" % (m.group(1), m.group(2).lower())
            if key not in seen:
                seen.add(key)
                out.append({"text": "%s %s" % (m.group(1), m.group(2)), "kind": "number", "value": _num(m.group(1)), "unit": m.group(2).lower()})
    return out


def phrases_of(*texts):
    """The one- to three-word phrases of the rule's words that could be a value stored in the data (lower case; common
    words left out), longest first. A named state such as "timed out" is found this way without quotation marks."""
    out = []
    for t in texts:
        words = re.findall(r"[A-Za-z][A-Za-z0-9_/+-]*", str(t or ""))
        low = [w.lower() for w in words]
        for n in (3, 2, 1):
            for i in range(len(low) - n + 1):
                part = low[i:i + n]
                if part[0] in STOP or part[-1] in STOP or (n == 1 and len(part[0]) < 4):
                    continue
                p = " ".join(part)
                if p not in out:
                    out.append(p)
    return out[:400]


def _squash(s):
    return re.sub(r"[^a-z0-9]+", "", str(s).lower())


def unit_of_column(column, meaning=""):
    """The unit of time a column's name or its meaning from Family 1 states -> ("us", "from its name") or (None, "")."""
    m = re.search(r"(?:^|[_\s(\[])(ps|ns|us|µs|μs|ms|sec|s)(?:$|[\s)\]_])", str(column), re.I)
    if m:
        return UNIT_NAME[UNITS[m.group(1).lower()]], "from its name"
    m = re.search(r"\b(picoseconds?|nanoseconds?|microseconds?|milliseconds?|seconds?|ps|ns|us|µs|ms)\b", str(meaning or ""), re.I)
    if m:
        return UNIT_NAME[UNITS[m.group(1).lower()]], "from the meaning Family 1 recorded"
    return None, ""


# ---------------------------------------------------------------------------------------------- one pass over one file
def nothing_spelling(cell):
    """The spelling of "nothing" a cell holds, or None: an empty cell, only spaces, N/A, NULL, -, Reserved, an all-F value."""
    if cell == "":
        return "an empty cell"
    s = cell.strip()
    if s == "":
        return "only spaces"
    low = s.lower()
    if low in NOTHING:
        return 'the text "%s"' % s
    if re.fullmatch(r"0[xX][fF]{4,}", s):
        return "the all-F value %s" % s
    return None


def _number_kind(s):
    """How a value that is a number is written -> "plain" | "thousands" | "unit" | "hex" | None (not a number)."""
    if re.fullmatch(r"[+-]?\d+(\.\d+)?([eE][+-]?\d+)?", s):
        return "plain"
    if re.fullmatch(r"[+-]?\d{1,3}(,\d{3})+(\.\d+)?", s):
        return "thousands"
    if re.fullmatch(r"0[xX][0-9A-Fa-f]+", s):
        return "hex"
    if re.fullmatch(r"[+-]?\d+(\.\d+)?\s*[A-Za-zµμ%]{1,6}", s):
        return "unit"
    return None


class _Column:
    """What is counted for one column the rule touches while its file is read once."""

    def __init__(self, name, key=False):
        self.name, self.key = name, key
        self.with_value = 0
        self.nothing = {}               # spelling -> [count, first lines]
        self.values = {}                # value -> count, up to the cap
        self.overflow = False
        self.shapes = {}
        self.kinds = {"plain": 0, "thousands": 0, "unit": 0, "hex": 0, "text": 0}
        self.spaces = 0                 # values with spaces at an end
        self.low = self.high = None
        self.len_low = self.len_high = None
        self.samples = []
        self.text_examples = []

    def take(self, cell, line):
        nt = nothing_spelling(cell)
        if nt is not None:
            e = self.nothing.setdefault(nt, [0, []])
            e[0] += 1
            if len(e[1]) < 3:
                e[1].append(line)
            return
        self.with_value += 1
        s = cell.strip()
        if s != cell:
            self.spaces += 1
        cap = KEY_CAP if self.key else DISTINCT_CAP
        if s in self.values:
            self.values[s] += 1
        elif len(self.values) < cap:
            self.values[s] = 1
        else:
            self.overflow = True
        if len(self.shapes) < 200 or column_match.shape(s) in self.shapes:
            sh = column_match.shape(s)
            self.shapes[sh] = self.shapes.get(sh, 0) + 1
        kind = _number_kind(s) or "text"
        self.kinds[kind] += 1
        if kind == "text" and len(self.text_examples) < 3 and s not in self.text_examples:
            self.text_examples.append(s[:60])
        if kind in ("plain", "thousands"):
            v = _num(s)
            if v is not None:
                self.low = v if self.low is None or v < self.low else self.low
                self.high = v if self.high is None or v > self.high else self.high
        n = len(s)
        self.len_low = n if self.len_low is None or n < self.len_low else self.len_low
        self.len_high = n if self.len_high is None or n > self.len_high else self.len_high
        if len(self.samples) < SAMPLE_ROWS:
            self.samples.append({"line": line, "value": s[:120]})

    def block(self, rows, basis, meaning="", meaning_source="", declared=None):
        numbers = self.kinds["plain"] + self.kinds["thousands"] + self.kinds["unit"] + self.kinds["hex"]
        top = sorted(self.values.items(), key=lambda kv: (-kv[1], kv[0]))[:TOP_VALUES]
        shapes = sorted(self.shapes.items(), key=lambda kv: (-kv[1], kv[0]))[:6]
        unit, unit_from = unit_of_column(self.name, meaning)
        out = {"column": self.name, "in_the_file": True, "rows": rows, "basis": basis, "rows_with_a_value": self.with_value,
               "nothing": [{"spelling": k, "rows": v[0], "first_lines": v[1]} for k, v in sorted(self.nothing.items(), key=lambda kv: (-kv[1][0], kv[0]))],
               "distinct_values": len(self.values), "distinct_is_exact": not self.overflow,
               "shapes": [{"shape": column_match.shape_words(sh), "rows": c} for sh, c in shapes],
               "written_as": {k: v for k, v in self.kinds.items() if v}, "values_with_spaces_at_an_end": self.spaces,
               "numbers": numbers, "not_numbers": self.kinds["text"], "not_number_examples": self.text_examples if numbers and self.kinds["text"] else [],
               "range": [self.low, self.high] if self.low is not None else None, "unit": unit, "unit_from": unit_from,
               "length": [self.len_low, self.len_high] if self.len_low is not None else None,
               "most_frequent": [{"value": v[:80], "rows": c} for v, c in top], "sample_rows": self.samples,
               "meaning_from_family_1": meaning, "meaning_source": meaning_source, "declared_type": declared}
        if self.key:
            out["as_a_key"] = {"exact": not self.overflow, "values_held_more_than_once": sum(1 for c in self.values.values() if c > 1) if not self.overflow else None,
                               "rows_in_those": sum(c for c in self.values.values() if c > 1) if not self.overflow else None}
        if top and self.with_value >= 20 and top[0][1] > 0.5 * self.with_value and len(self.values) > 5:
            out["frequent_default"] = {"value": top[0][0][:80], "rows": top[0][1], "share_percent": round(100.0 * top[0][1] / self.with_value, 1)}
        return out


def measure(path, columns, keys=(), row_cap=None, progress=None):
    """One streaming pass over one CSV file (row by row, the application's own reader): everything _Column counts for the
    named columns. -> {"rows", "basis", "seconds", "header", "columns": {name: _Column}, "absent": [names not in the header]}.
    row_cap: only for a first look (the basis then says "the first N rows"); None reads the whole file."""
    t0 = time.time()
    size = os.path.getsize(path) or 1
    with open(path, newline="", encoding="utf-8-sig", errors="replace") as fh:
        rd = family1.L.read_csv(fh, path)
        head = list(next(rd, []))
        idx, cols = {}, {}
        for c in dict.fromkeys(columns):
            if c in head:
                idx[c] = head.index(c)
                cols[c] = _Column(c, key=c in keys)
        pairs = list(idx.items())
        rows, cut = 0, False
        for row in rd:
            rows += 1
            line = rows + 1
            n = len(row)
            for c, i in pairs:
                cols[c].take(row[i] if i < n else "", line)
            if row_cap and rows >= row_cap:
                cut = True
                break
            if progress and rows % 200000 == 0:
                try:
                    pos = fh.buffer.tell()
                except (AttributeError, OSError, ValueError):
                    pos = 0
                progress(core.progress_text(min(99.0, 100.0 * pos / size), t0, what="%s: %s rows read for the data research" % (os.path.basename(path), _n(rows)),
                                            done=pos or None, total=size))
    return {"rows": rows, "basis": "the first %s rows" % _n(rows) if cut else "exact: all %s rows" % _n(rows), "exact": not cut,
            "seconds": round(time.time() - t0, 2), "header": head, "columns": cols, "absent": [c for c in dict.fromkeys(columns) if c not in head]}


# ---------------------------------------------------------------------------------------------- Family 2: the links
def link_facts(db, levels):
    """For every parent-child link between the levels the rule reads, counted exactly in the built tree: the children,
    the children without a parent, the parents, the parents without a child, how many children one parent has, and the
    keys. In the tree a row hangs under its parent by the parent's row number, which is unique by construction."""
    from nvme_hier import tree_api as T
    levels = [lv for lv in T.LEVELS if lv in set(levels)]
    out = []
    if len(levels) < 2 or not db or not os.path.exists(db):
        return out
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    try:
        for child in levels[1:]:
            ct = T.TABLE[child]
            total = con.execute("SELECT COUNT(*) FROM %s" % ct).fetchone()[0]
            lone = con.execute("SELECT COUNT(*) FROM %s WHERE parent IS NULL AND (relation IS NULL OR relation != 'context')" % ct).fetchone()[0]
            context = con.execute("SELECT COUNT(*) FROM %s WHERE relation = 'context'" % ct).fetchone()[0]
            for parent, n in con.execute("SELECT parent_level, COUNT(*) FROM %s WHERE parent IS NOT NULL GROUP BY parent_level" % ct).fetchall():
                if parent not in T.TABLE:
                    continue
                pt = T.TABLE[parent]
                parents = con.execute("SELECT COUNT(*) FROM %s" % pt).fetchone()[0]
                with_child, low, high, avg = con.execute(
                    "SELECT COUNT(*), MIN(c), MAX(c), AVG(c) FROM (SELECT COUNT(*) AS c FROM %s WHERE parent IS NOT NULL AND parent_level=? GROUP BY parent)" % ct, (parent,)).fetchone()
                dangling = con.execute("SELECT COUNT(*) FROM %s c WHERE c.parent IS NOT NULL AND c.parent_level=? AND NOT EXISTS (SELECT 1 FROM %s p WHERE p.rowid_file = c.parent)" % (ct, pt),
                                       (parent,)).fetchone()[0]
                out.append({"child": child, "parent": parent, "child_rows": total, "children_under_this_parent": n, "children_without_a_parent": lone,
                            "context_rows": context, "parent_rows": parents, "parents_without_a_child": parents - (with_child or 0),
                            "children_per_parent": {"least": low, "most": high, "average": round(avg, 2) if avg is not None else None},
                            "children_whose_parent_row_is_missing": dangling, "duplicated_parent_keys": 0,
                            "key": "the parent's row number in its file (one row, one number: the tree was built so)", "basis": "exact: counted in the built tree"})
    finally:
        con.close()
    return out


def link_lines(links):
    out = []
    for k in links:
        c, p = PR.FILE_NAME.get(k["child"], k["child"]), PR.FILE_NAME.get(k["parent"], k["parent"])
        cp = k["children_per_parent"]
        out.append("%s under %s: %s of the %s hang under a row of %s; %s have no parent%s; %s of the %s have no row of %s under them; one parent has %s to %s of them "
                   "(%s on average) (%s)." % (c, p, _n(k["children_under_this_parent"]), _plural(k["child_rows"], "row"), p, _n(k["children_without_a_parent"]),
                                              "; %s are context rows" % _n(k["context_rows"]) if k["context_rows"] else "", _n(k["parents_without_a_child"]),
                                              _plural(k["parent_rows"], "row"), c, _n(cp["least"]), _n(cp["most"]), cp["average"], k["basis"]))
    return out


# ---------------------------------------------------------------------------------------------- Family 3: the admin's input
def admin_items(ctx, r, proc):
    """What the admin gave for this rule, dated, the latest first: the rule's words, the procedure's versions, his
    answers and comments on this item's cards (this analysis, this run and earlier ones), and the columns he chose or
    refused to stand for others."""
    out = []
    when = r.get("edited_at") or r.get("updated") or r.get("created")
    out.append({"kind": "the rule's words", "text": " ".join(str(r.get("description") or "").split())[:1000], "by": r.get("edited_by") or r.get("created_by") or "the admin", "at": when})
    out.append({"kind": "the procedure", "text": "version %s, %d step%s; %d earlier version%s kept" % (
        proc.get("version", 0), len(proc.get("steps") or []), "" if len(proc.get("steps") or []) == 1 else "s", len(r.get("history") or []), "" if len(r.get("history") or []) == 1 else "s"),
        "by": proc.get("edited_by") or "the admin", "at": proc.get("edited_at") or when})
    kept = ((r.get("coding") or {}).get("requirements")) or {}
    for x in kept.get("qa") or []:
        if isinstance(x, dict) and x.get("answer"):
            out.append({"kind": "an answer", "question": str(x.get("question") or "")[:300], "text": str(x.get("answer"))[:600], "by": x.get("by") or kept.get("approved_by"),
                        "at": kept.get("approved_at"), "from": "the requirements approved for procedure version %s" % kept.get("procedure_version")})
    for d in kept.get("substitutes") or []:
        if isinstance(d, dict):
            out.append({"kind": "a column chosen to stand for another", "text": "%s column %s stands for %s" % (d.get("file"), d.get("column"), d.get("what")), "by": d.get("by"), "at": d.get("at")})
    store = getattr(ctx.engine, "store", None)
    if store is not None:
        try:
            item = "%s/%s/%s" % (r["section"], r["level"], r["id"])
            rows = store.all("SELECT v.comment, v.decided_by, v.decided_at, v.title, s.key, s.input FROM review v JOIN step s ON s.id = v.step JOIN run n ON n.id = v.run "
                             "WHERE n.project=? AND (s.key LIKE ? OR n.params LIKE ?) ORDER BY v.id DESC LIMIT 60", (ctx.run["project"], "f3:" + item + "%", '%"id": "' + r["id"] + '"%'))
        except Exception:               # noqa: BLE001 - a store that cannot be asked gives no items; the record says what it has
            rows = []
        seen = set()
        for v in rows:
            c = " ".join(str(v.get("comment") or "").split())
            if c and c != "answers to the questions" and c not in seen:
                seen.add(c)
                out.append({"kind": "a comment", "text": c[:600], "by": v.get("decided_by"), "at": v.get("decided_at"), "from": "the card “%s”" % str(v.get("title") or "")[:80]})
            inp = core.jload(v.get("input"), {}) or {}
            for x in inp.get("qa") or []:
                key = (str(x.get("question")), str(x.get("answer")))
                if isinstance(x, dict) and x.get("answer") and key not in seen:
                    seen.add(key)
                    out.append({"kind": "an answer", "question": str(x.get("question") or "")[:300], "text": str(x.get("answer"))[:600], "by": x.get("by"), "at": v.get("decided_at"),
                                "from": "the card “%s”" % str(v.get("title") or "")[:80]})
    head, rest = out[:2], sorted(out[2:], key=lambda x: -(x.get("at") or 0))
    return head + rest[:30]


def answer_conflicts(items):
    """Two answers of the admin to the same question that differ -> conflicts; the latest dated one stands."""
    by = {}
    for x in items:
        if x.get("kind") == "an answer" and x.get("question"):
            by.setdefault(" ".join(x["question"].lower().split()), []).append(x)
    out = []
    for q, xs in by.items():
        texts = {" ".join(str(x["text"]).lower().split()) for x in xs}
        if len(texts) > 1:
            xs = sorted(xs, key=lambda x: -(x.get("at") or 0))
            out.append({"kind": "two answers of the admin", "what": "the question “%s” was answered in two ways" % xs[0]["question"][:160],
                        "a": {"says": xs[0]["text"][:200], "source": "the admin (%s)" % (xs[0].get("by") or "?"), "at": xs[0].get("at")},
                        "b": {"says": xs[1]["text"][:200], "source": "the admin (%s)" % (xs[1].get("by") or "?"), "at": xs[1].get("at")},
                        "priority": "the admin's latest dated answer stands", "settled": True, "stands": xs[0]["text"][:200], "question": None})
    return out


# ---------------------------------------------------------------------------------------------- the record
def _dict_lines(d):
    """One compact line per column of a file, from Family 1's dictionary (the whole file's columns, none left out)."""
    out = []
    for c in (d or {}).get("columns") or []:
        if isinstance(c, dict) and c.get("column"):
            src = c.get("source") if isinstance(c.get("source"), dict) else {}
            out.append({"column": c["column"], "rows_with_a_value": c.get("rows_with_value"), "distinct": c.get("distinct"), "type": c.get("type"),
                        "meaning": " ".join(str(c.get("meaning") or "").split())[:160], "meaning_status": c.get("status"), "meaning_source": src.get("kind") or None,
                        "values": [str(k.get("value"))[:40] for k in (c.get("keywords") or [])[:3] if isinstance(k, dict)]})
    return out


def _dictionary_values(d):
    """{column: {value in lower case: (value as written, rows)}} from Family 1's dictionary and the Explorer's memory:
    the values Family 1 kept for every column of the file (its keywords and its most frequent values)."""
    out = {}
    try:
        idx = admin_ask._index(d) if d else {}
    except Exception:                   # noqa: BLE001
        idx = {}
    for e in idx.values():
        vals = {}
        for group in (e.get("keywords"), e.get("values")):
            for k, v in (group or {}).items():
                vals.setdefault(k, (v.get("value"), v.get("rows")))
        out[e.get("column") or ""] = vals
    return out


def find_words(literals, phrases, measured, dict_values, column_names):
    """Where the rule's own words are stored. measured: {file: {column: _Column}} (counted now); dict_values: {file:
    {column: {lower: (value, rows)}}} (what Family 1 kept for the other columns). -> one entry per word of the rule that
    is a stored value or that is in quotation marks: {"text", "found": [{"file", "column", "spelling", "rows", "basis"}],
    "nearest": [{"file", "column", "spelling", "rows"}]}."""
    names = {_squash(c) for c in column_names}
    out = []
    wanted = [(x["text"], True) for x in literals if x["kind"] == "quoted"] + [(p, False) for p in phrases]
    taken = set()
    for text, quoted in wanted:
        low, sq = " ".join(text.lower().split()), _squash(text)
        if not sq or low in taken or (not quoted and sq in names):
            continue
        found, near, part = [], [], []
        inside = re.compile(r"(?<![a-z0-9])%s(?![a-z0-9])" % re.escape(low)) if len(sq) >= 2 else None
        for f, cols in measured.items():
            for c, col in cols.items():
                for v, n in col.values.items():
                    if v.lower() != low and inside is not None and len(part) < 4 and inside.search(v.lower()):
                        part.append({"file": f, "column": c, "spelling": v, "rows": n})
                    if v.lower() == low:
                        found.append({"file": f, "column": c, "spelling": v, "rows": n, "basis": "counted now" + ("" if not col.overflow else ", among the first %s distinct values" % _n(len(col.values)))})
                if not found and len(col.values) <= 2000 and len(sq) >= 4:
                    for v, n in col.values.items():
                        vs = _squash(v)
                        if vs and vs != sq and abs(len(vs) - len(sq)) <= 4 and difflib.SequenceMatcher(None, sq, vs).ratio() >= NEAR:
                            near.append({"file": f, "column": c, "spelling": v, "rows": n})
        for f, cols in dict_values.items():
            for c, vals in cols.items():
                if c in (measured.get(f) or {}):
                    continue
                if inside is not None and len(part) < 4 and low not in vals:
                    part += [{"file": f, "column": c, "spelling": v, "rows": n} for k, (v, n) in list(vals.items())[:2000] if inside.search(k)][:4 - len(part)]
                if low in vals:
                    found.append({"file": f, "column": c, "spelling": vals[low][0], "rows": vals[low][1], "basis": "from Family 1's dictionary of %s" % f})
                elif not found and len(sq) >= 4 and len(vals) <= 2000:
                    for k, (v, n) in vals.items():
                        vs = _squash(k)
                        if vs and vs != sq and abs(len(vs) - len(sq)) <= 4 and difflib.SequenceMatcher(None, sq, vs).ratio() >= NEAR:
                            near.append({"file": f, "column": c, "spelling": v, "rows": n})
        if found or quoted or near:
            taken.add(low)
            # part_of: the word is not a whole value anywhere, and it is inside longer values ("Read" inside "0x02 (Read)")
            out.append({"text": text, "in_quotation_marks": quoted, "found": found[:6], "nearest": [] if found else near[:4], "part_of": [] if found else part[:4]})
    # a longer phrase that was found makes its single words no news
    longer = [x["text"].lower() for x in out if " " in x["text"] and (x["found"] or x["nearest"])]
    return [x for x in out if " " in x["text"] or x["in_quotation_marks"] or not any(x["text"].lower() in p.split() for p in longer)][:40]


def conflicts_of(words, blocks, literals, items):
    """The conflicts, found by code. -> [{"kind", "what", "a", "b", "priority", "settled", "stands", "question"}]."""
    out = []
    for w in words:
        # a question is the program's to ask only when it has another spelling from the data to offer ("timed out" in the
        # rule, "timeout" in the file). A quoted text with nothing like it in the data is very often a name the OUTPUT
        # writes ("opcode 0xNN", "(blank)"): it stays a line to decide in the record and goes to the Requirements agent,
        # and the program does not stop the admin for it (found 2026-11-14 on the shipped command type item)
        if not w["found"] and w["nearest"]:
            near = "; ".join("%s column %s holds “%s” (%s)" % (x["file"], x["column"], x["spelling"], _plural(x["rows"], "row") if isinstance(x["rows"], int) else "rows not counted") for x in w["nearest"])
            out.append({"kind": "the rule against the data", "what": "the rule says “%s”, and no column of the files it reads holds that value" % w["text"],
                        "a": {"says": "“%s”" % w["text"], "source": "the rule's words (the admin)", "at": None},
                        "b": {"says": near or "no value like it in the columns the rule reads, nor among the values Family 1 kept", "source": "the data, counted by the program", "at": None},
                        "priority": "the rule against the data goes to the admin", "settled": False, "stands": None,
                        "question": "The rule says “%s”. No column of the files it reads holds that value. %s What should the code look for?" % (
                            w["text"], ("The nearest spelling in the data: %s. Is that what is meant?" % near) if near else "Nothing like it was found.")})
    numbers = [x for x in literals if x["kind"] == "number"]
    for b in blocks:
        if not b.get("in_the_file"):
            continue
        where = "%s column %s" % (b["file"], b["column"])
        if b.get("declared_type") in ("integer", "number", "decimal", "float") and b.get("not_numbers"):
            out.append({"kind": "the dictionary against the measured content", "what": "%s: Family 1's dictionary says %s, and %s are not numbers" % (where, b["declared_type"], _plural(b["not_numbers"], "value")),
                        "a": {"says": "type %s" % b["declared_type"], "source": "Family 1's dictionary of %s" % b["file"], "at": b.get("dictionary_at")},
                        "b": {"says": "%s are not numbers, for example %s" % (_plural(b["not_numbers"], "value"), ", ".join("“%s”" % x for x in b.get("not_number_examples") or [])),
                              "source": "the data, counted by the program (%s)" % b["basis"], "at": None},
                        "priority": "a measured count stands over a description", "settled": True,
                        "stands": "the column holds values that are not numbers: the code must say what happens to them", "question": None})
        if b.get("unit") and b.get("numbers"):
            for num in numbers:
                ru = UNIT_NAME[UNITS[num["unit"]]]
                if ru != b["unit"] and num.get("value") is not None:
                    conv = num["value"] * UNITS[num["unit"]] / UNITS[b["unit"]]
                    out.append({"kind": "the rule against the data", "what": "the rule gives %s; %s holds %s (%s)" % (num["text"], where, b["unit"], b["unit_from"]),
                                "a": {"says": num["text"], "source": "the rule's words (the admin)", "at": None},
                                "b": {"says": "values in %s" % b["unit"], "source": "%s, %s" % (where, b["unit_from"]), "at": None},
                                "priority": "the rule against the data goes to the admin", "settled": False, "stands": None,
                                "question": "The rule gives %s, and %s holds its values in %s (%s). Should the code compare with %s %s (that is %s), or is another column meant?" % (
                                    num["text"], where, b["unit"], b["unit_from"], ("%f" % conv).rstrip("0").rstrip("."), b["unit"], num["text"])})
    return out + answer_conflicts(items)


def hidden_decisions(blocks, links, literals, words_text, proc):
    """What the rule leaves open, raised by code from what was measured (never from an opinion): each is one decision the
    code cannot take on its own. -> [{"id": "H1", "kind", "decision", "because", "by": "the program"}]."""
    out = []

    def add(kind, decision, because):
        if len(out) < HIDDEN_MOST:
            out.append({"id": "H%d" % (len(out) + 1), "kind": kind, "decision": decision, "because": because, "by": "the program"})
    said = " ".join(str(s) for s in (proc.get("steps") or [])).lower() + " " + str(words_text or "").lower()
    for b in blocks:
        if not b.get("in_the_file"):
            continue
        where = "%s column %s" % (b["file"], b["column"])
        if b["nothing"]:
            n = sum(x["rows"] for x in b["nothing"])
            spell = "; ".join("%s in %s" % (x["spelling"], _plural(x["rows"], "row")) for x in b["nothing"][:4])
            add("empty values", "what the code does with a row whose %s holds nothing" % where,
                "%s of the %s hold nothing there (%s; %s)" % (_n(n), _plural(b["rows"], "row"), spell, b["basis"]))
        if b.get("numbers") and b.get("not_numbers"):
            add("values that are not numbers", "what the code does with a row whose %s is not a number" % where,
                "%s are numbers and %s are not, for example %s (%s)" % (_plural(b["numbers"], "value"), _n(b["not_numbers"]), ", ".join("“%s”" % x for x in b["not_number_examples"]), b["basis"]))
        wa = b.get("written_as") or {}
        if sum(1 for k in ("plain", "thousands", "unit", "hex") if wa.get(k)) > 1:
            add("numbers written in more than one way", "how the code reads the numbers of %s" % where,
                "they are written as: %s (%s)" % ("; ".join("%s %s" % (_n(v), {"plain": "plain numbers", "thousands": "with a thousands separator", "unit": "with a unit attached",
                                                                               "hex": "hexadecimal"}[k]) for k, v in wa.items() if k != "text" and v), b["basis"]))
        if b.get("values_with_spaces_at_an_end"):
            add("spaces around a value", "whether the code removes the spaces at the ends of %s before it compares or groups" % where,
                "%s have a space at an end (%s)" % (_plural(b["values_with_spaces_at_an_end"], "value"), b["basis"]))
        k = b.get("as_a_key")
        if k and k.get("values_held_more_than_once"):
            add("a key held more than once", "what the code does when the same %s is in more than one row" % where,
                "%s are held more than once, in %s (%s)" % (_plural(k["values_held_more_than_once"], "value"), _plural(k["rows_in_those"], "row"), b["basis"]))
        if b.get("frequent_default"):
            d = b["frequent_default"]
            add("one value in most rows", "whether “%s” in %s is a real value or stands for nothing" % (d["value"], where),
                "it is in %s%% of the rows that hold a value (%s; %s)" % (d["share_percent"], _plural(d["rows"], "row"), b["basis"]))
    for k in links:
        c, p = PR.FILE_NAME.get(k["child"], k["child"]), PR.FILE_NAME.get(k["parent"], k["parent"])
        if k["children_without_a_parent"]:
            add("rows without a parent", "what the code does with a row of %s that hangs under no row of %s" % (c, p),
                "%s of the %s have no parent (%s)" % (_n(k["children_without_a_parent"]), _plural(k["child_rows"], "row"), k["basis"]))
        if k["parents_without_a_child"]:
            add("parents without a child", "what the code does with a row of %s that has no row of %s under it" % (p, c),
                "%s of the %s have none (%s)" % (_n(k["parents_without_a_child"]), _plural(k["parent_rows"], "row"), k["basis"]))
    if COMPARE.search(said) and any(x["kind"] == "number" for x in literals) and not re.search(r"\b(strictly|or equal|inclusive|exactly at|at least|at most|not more than|not less than)\b", said):
        num = next(x for x in literals if x["kind"] == "number")
        add("equality at a limit", "whether a value of exactly %s counts" % num["text"], "the rule compares with %s and does not say what happens at exactly that value" % num["text"])
    order = str((proc.get("output") or {}).get("order") or "")
    if order and not re.search(r"\bthen\b|,", order):
        add("ties", "the order of two output lines that are equal in “%s”" % order[:80], "the output is ordered by one thing only, and two lines can be equal in it")
    return out


RESEARCH_SHAPE = ('{"matters": [{"column": "<a column of this file, letter for letter>", "what": "<one sentence: what in its content matters for the rule>"}], '
                  '"hidden_decisions": [{"column": "<a column or empty>", "kind": "empty values|unpaired rows|ties|empty groups|equality at a limit|units|other", '
                  '"decision": "<what the rule leaves open, as one question the admin can answer>"}], "doubts": ["..."]}')


def ask_researchers(ctx, r, proc, items, per_file, raised=()):
    """One model call per touched file, all at the same time (the calls-at-once rule of the runner applies): what in this
    file's content matters for the rule, which decisions the rule leaves open, and doubts. A column it names that the file
    does not have is dropped; it gives no count (the record's counts are the program's)."""
    def one(job):
        name, d, blocks, header = job
        context = {"RULE": {"name": r.get("name"), "the_admins_words": r.get("description"), "steps": proc.get("steps"), "output": proc.get("output")},
                   "THE_ADMIN_SAID": [{k: v for k, v in x.items() if k in ("kind", "question", "text", "from")} for x in items[:12]],
                   "FILE": name, "ALL_COLUMNS_OF_THE_FILE": _dict_lines(d) or [{"column": c} for c in header],
                   "MEASURED_NOW": [{k: v for k, v in b.items() if k not in ("file", "meaning_source", "dictionary_at")} for b in blocks],
                   "ALREADY_RAISED_BY_THE_APPLICATION": list(raised)[:30]}
        ans, producer, _ = ctx.engine.runner.ask(ctx.run["id"], "f4_research_%s_%s" % (r["id"], re.sub(r"[^A-Za-z0-9_.-]+", "_", name)[:40]), prompts.load("f4_data_research"),
                                                 json.dumps(context, ensure_ascii=False)[:150000], RESEARCH_SHAPE, "matters", lambda: {"matters": [], "hidden_decisions": [], "doubts": []})
        head, dropped = set(header), []
        matters = []
        for m in ans.get("matters") if isinstance(ans.get("matters"), list) else []:
            if isinstance(m, dict) and str(m.get("column") or "") in head and str(m.get("what") or "").strip():
                matters.append({"column": m["column"], "what": " ".join(str(m["what"]).split())[:300]})
            elif isinstance(m, dict) and m.get("column"):
                dropped.append(str(m["column"])[:60])
        hidden = []
        for h in ans.get("hidden_decisions") if isinstance(ans.get("hidden_decisions"), list) else []:
            if not isinstance(h, dict) or not str(h.get("decision") or "").strip():
                continue
            col = str(h.get("column") or "")
            if col and col not in head:
                dropped.append(col[:60])
                continue
            hidden.append({"kind": " ".join(str(h.get("kind") or "other").split())[:40], "decision": " ".join(str(h["decision"]).split())[:300], "column": col, "file": name})
        doubts = [" ".join(str(x).split())[:300] for x in (ans.get("doubts") if isinstance(ans.get("doubts"), list) else []) if isinstance(x, str) and x.strip()][:6]
        return name, {"matters": matters[:12], "hidden": hidden[:6], "doubts": doubts, "dropped": list(dict.fromkeys(dropped))[:8], "by": producer}
    jobs = sorted(per_file, key=lambda j: j[0])           # a fixed order: the result does not depend on how many calls run at once
    if not jobs:
        return {}
    with ThreadPoolExecutor(max_workers=min(8, len(jobs))) as pool:
        return dict(pool.map(one, jobs))


def build(ctx, r, proc, facts, f2_lines=(), row_cap=None):
    """The ledger and the data research record of one item. facts: family4.data_facts (the files, the headers, Family 1's
    dictionaries, the tree). Nothing here asks a model for a count."""
    t0 = time.time()
    rule_text = " ".join(str(r.get("description") or "").split())
    steps_text = " ".join(str(s) for s in proc.get("steps") or [])
    literals = literals_of(rule_text, steps_text)
    phrases = phrases_of(rule_text, steps_text)
    items = admin_items(ctx, r, proc)
    # the files the rule touches, and in each the columns it names (for the tree: the file of each level it reads)
    touched, on_tree = {}, facts.get("on_tree")
    for s in proc["source_data"]:
        for c in s["columns"]:
            if s["file"] == PR.TREE:
                lv, col = PR.tree_column(c)
                name = PR.FILE_NAME.get(lv)
                if name:
                    touched.setdefault(name, []).append(col)
            else:
                touched.setdefault(s["file"], []).append(c)
    stands = {(d.get("wanted_file"), d.get("wanted_column")): d for d in facts.get("stands_decisions") or []}
    files, blocks, measured, dict_values, jobs, column_names = [], [], {}, {}, [], []
    for name, cols in touched.items():
        path = facts["paths"].get(name)
        d = facts["dicts"].get(name)
        entry = {"file": name, "in_this_analysis": bool(path and os.path.exists(path)), "dictionary": None, "columns": _dict_lines(d), "touched": []}
        if d:
            entry["dictionary"] = {"version": d.get("version"), "approved_by": d.get("approved_by"), "approved_at": d.get("approved_at"), "rows": d.get("rows") or d.get("rows_estimate")}
            dict_values[name] = _dictionary_values(d)
        if not entry["in_this_analysis"]:
            entry["note"] = "this analysis has no file %s: nothing of it could be measured" % name
            for c in dict.fromkeys(cols):
                blocks.append({"file": name, "column": c, "in_the_file": False})
            files.append(entry)
            continue
        extra = [st["column"] for (f, c), st in stands.items() if f == name and st.get("file") == name and st.get("column")]
        ctx.progress("the data research reads %s once, row by row, for the %d column%s the rule touches" % (name, len(set(cols)), "" if len(set(cols)) == 1 else "s"))
        m = measure(path, list(cols) + extra, keys=[], row_cap=row_cap, progress=ctx.progress)
        entry.update(rows=m["rows"], basis=m["basis"], seconds=m["seconds"], header_cells=len(m["header"]))
        if not entry["columns"]:
            entry["columns"] = [{"column": c} for c in m["header"] if c]
        column_names += [c for c in m["header"] if c]
        measured[name] = m["columns"]
        by_col = {x["column"]: x for x in (d or {}).get("columns") or [] if isinstance(x, dict)}
        for c in dict.fromkeys(list(cols) + extra):
            if c not in m["columns"]:
                st = stands.get((name, c))
                blocks.append({"file": name, "column": c, "in_the_file": False, "stands_for_it": "%s column %s" % (st.get("file"), st.get("column")) if st else None})
                continue
            dc = by_col.get(c) or {}
            src = dc.get("source") if isinstance(dc.get("source"), dict) else {}
            b = m["columns"][c].block(m["rows"], m["basis"], meaning=" ".join(str(dc.get("meaning") or "").split())[:240],
                                      meaning_source=(src.get("kind") or "") + (": " + str(src.get("ref"))[:80] if src.get("ref") else "") if dc.get("meaning") else "",
                                      declared=dc.get("type"))
            b.update(file=name, dictionary_at=(d or {}).get("approved_at"), meaning_status=dc.get("status"))
            blocks.append(b)
            entry["touched"].append(b)
        files.append(entry)
        jobs.append((name, d, entry["touched"], m["header"]))
    links = link_facts(facts.get("db"), [PR.tree_column(c)[0] for s in proc["source_data"] if s["file"] == PR.TREE for c in s["columns"]]) if on_tree else []
    words = find_words(literals, phrases, measured, dict_values, column_names)
    conflicts = conflicts_of(words, blocks, literals, items)
    hidden = hidden_decisions(blocks, links, literals, rule_text, proc)
    ctx.progress("the Data researcher reads what was measured in %d file%s, all at the same time" % (len(jobs), "" if len(jobs) == 1 else "s"))
    researchers = ask_researchers(ctx, r, proc, items, jobs, raised=[h["decision"] for h in hidden] + [c["what"] for c in conflicts])
    known = {(" ".join(h["decision"].lower().split())) for h in hidden}
    for name in sorted(researchers):
        for h in researchers[name]["hidden"]:
            key = " ".join(h["decision"].lower().split())
            if key not in known and len(hidden) < HIDDEN_MOST:
                known.add(key)
                hidden.append({"id": "H%d" % (len(hidden) + 1), "kind": h["kind"], "decision": h["decision"], "because": "the Data researcher read it from the rule and the content of %s; no count" % name,
                               "by": researchers[name]["by"]})
    ledger = ledger_of(blocks, words, links, items, f2_lines, literals, conflicts)
    record = {"made_at": time.time(), "seconds": round(time.time() - t0, 1), "item": "%s/%s/%s" % (r["section"], r["level"], r["id"]), "procedure_sha": PR.sha(proc),
              "files": files, "links": links, "family_2": list(f2_lines), "admin_items": items, "literals": literals, "words": words, "conflicts": conflicts,
              "hidden": hidden, "researchers": researchers, "ledger": ledger}
    record["surprises"] = surprises_of(record)
    return record


def ledger_of(blocks, words, links, items, f2_lines, literals, conflicts):
    """Everything the rule needs, one line each, with its state and its source."""
    out = []
    for b in blocks:
        where = "%s column %s" % (b["file"], b["column"])
        if not b.get("in_the_file"):
            out.append({"what": where, "kind": "column", "state": ESTABLISHED if b.get("stands_for_it") else TO_DECIDE,
                        "source": "the admin chose %s to stand for it" % b["stands_for_it"] if b.get("stands_for_it") else "the file's header, read by the program: no column of that name",
                        "detail": ""})
            continue
        if b.get("meaning_from_family_1") and "model" not in str(b.get("meaning_status") or "").lower() and "no meaning" not in str(b.get("meaning_status") or "").lower():
            state, src = ESTABLISHED, "Family 1's dictionary of %s (%s)" % (b["file"], b.get("meaning_source") or b.get("meaning_status") or "its meaning")
        elif b.get("meaning_from_family_1"):
            state, src = GUESS, "Family 1's dictionary of %s: the meaning is %s" % (b["file"], b.get("meaning_status") or "from the model's knowledge, without a source")
        else:
            state, src = TO_DECIDE, "the column is in the file; Family 1 has no meaning for it"
        out.append({"what": where, "kind": "column", "state": state, "source": src,
                    "detail": "%s of %s hold a value (%s)%s" % (_n(b["rows_with_a_value"]), _plural(b["rows"], "row"), b["basis"], "; means: " + b["meaning_from_family_1"] if b.get("meaning_from_family_1") else "")})
    for w in words:
        if w["found"]:
            f = w["found"][0]
            out.append({"what": "the rule's word “%s”" % w["text"], "kind": "word of the rule", "state": ESTABLISHED,
                        "source": "%s column %s holds “%s” in %s (%s)" % (f["file"], f["column"], f["spelling"], _plural(f["rows"], "row") if isinstance(f["rows"], int) else "rows not counted", f["basis"]),
                        "detail": "" if len(w["found"]) == 1 else "also in: " + "; ".join("%s column %s" % (x["file"], x["column"]) for x in w["found"][1:4])})
        elif w.get("part_of"):
            f = w["part_of"][0]
            out.append({"what": "the rule's word “%s”" % w["text"], "kind": "word of the rule", "state": ESTABLISHED,
                        "source": "no value is exactly that; it is inside longer values: %s column %s holds “%s” in %s" % (
                            f["file"], f["column"], f["spelling"], _plural(f["rows"], "row") if isinstance(f["rows"], int) else "rows not counted"),
                        "detail": "" if len(w["part_of"]) == 1 else "also inside: " + "; ".join("“%s”" % x["spelling"] for x in w["part_of"][1:4])})
        else:
            out.append({"what": "the rule's word “%s”" % w["text"], "kind": "word of the rule", "state": TO_DECIDE, "source": "in no column of the files the rule reads",
                        "detail": ("nearest: " + "; ".join("“%s” in %s column %s" % (x["spelling"], x["file"], x["column"]) for x in w["nearest"])) if w["nearest"]
                                  else "nothing like it in the data: a value to look for, or a name the output writes"})
    for x in literals:
        if x["kind"] == "number":
            open_ = any(c["kind"] == "the rule against the data" and x["text"] in c["what"] and not c["settled"] for c in conflicts)
            out.append({"what": "the rule's limit %s" % x["text"], "kind": "limit", "state": TO_DECIDE if open_ else ESTABLISHED, "source": "the rule's words (the admin)",
                        "detail": "its unit differs from the column's: see the conflicts" if open_ else ""})
    for line in f2_lines or []:
        out.append({"what": line, "kind": "Family 2", "state": ESTABLISHED, "source": "Family 2: the approved strategy and the built tree's own counts", "detail": ""})
    for k in links:
        out.append({"what": "the link %s under %s" % (PR.FILE_NAME.get(k["child"], k["child"]), PR.FILE_NAME.get(k["parent"], k["parent"])), "kind": "link", "state": ESTABLISHED,
                    "source": "counted in the built tree by the program", "detail": link_lines([k])[0]})
    for x in items[2:]:
        out.append({"what": "%s%s" % (x["kind"], ": " + x["question"] if x.get("question") else ""), "kind": "the admin", "state": ESTABLISHED,
                    "source": "the admin (%s)%s" % (x.get("by") or "?", ", " + x["from"] if x.get("from") else ""), "detail": x["text"], "at": x.get("at")})
    return out


def surprises_of(record):
    """What the header does not show and the code must know, first: one sentence each, with its count and basis."""
    out = []
    for f in record["files"]:
        if f.get("note"):
            out.append(f["note"])
        for b in f.get("touched") or []:
            where = "%s column %s" % (b["file"], b["column"])
            for x in b["nothing"][:4]:
                out.append("%s: %s in %s of the %s (first at line %s) (%s)." % (where, x["spelling"], _n(x["rows"]), _plural(b["rows"], "row"), ", ".join(str(n) for n in x["first_lines"]), b["basis"]))
            if b.get("numbers") and b.get("not_numbers"):
                out.append("%s: %s are numbers and %s are not, for example %s (%s)." % (where, _plural(b["numbers"], "value"), _n(b["not_numbers"]),
                                                                                       ", ".join("“%s”" % x for x in b["not_number_examples"]), b["basis"]))
            wa = b.get("written_as") or {}
            for k, words in (("thousands", "written with a thousands separator"), ("unit", "written with a unit attached"), ("hex", "hexadecimal")):
                if wa.get(k) and wa.get("plain"):
                    out.append("%s: %s are %s, beside %s plain ones (%s)." % (where, _plural(wa[k], "number"), words, _n(wa["plain"]), b["basis"]))
            if b.get("values_with_spaces_at_an_end"):
                out.append("%s: %s have a space at an end (%s)." % (where, _plural(b["values_with_spaces_at_an_end"], "value"), b["basis"]))
            if (b.get("as_a_key") or {}).get("values_held_more_than_once"):
                out.append("%s: %s are held more than once (%s)." % (where, _plural(b["as_a_key"]["values_held_more_than_once"], "value"), b["basis"]))
    for k in record["links"]:
        if k["children_without_a_parent"] or k["parents_without_a_child"]:
            out.append(link_lines([k])[0])
    for w in record["words"]:
        if not w["found"] and not w.get("part_of") and (w["in_quotation_marks"] or w["nearest"]):
            out.append("The rule's word “%s” is in no column of the files it reads%s." % (w["text"], ("; nearest: " + "; ".join("“%s” in %s column %s (%s)" % (
                x["spelling"], x["file"], x["column"], _plural(x["rows"], "row") if isinstance(x["rows"], int) else "rows not counted") for x in w["nearest"])) if w["nearest"]
                else "; nothing like it was found (a value to look for, or a name the output writes)"))
    return out[:30]


def record_body(record):
    """The record as the first part of the requirements card: surprises and conflicts first, then where the rule's words
    are, then (folded on the page) the ledger."""
    if not record:
        return []
    body = ["**What the data research found, before anything was coded** (counted by the program in one pass over each file the rule reads; %s s):" % record.get("seconds"), ""]
    sur = record.get("surprises") or []
    body += (["**Surprises in the content:**"] + ["- " + s for s in sur] + [""]) if sur else ["Nothing in the content of the columns the rule reads stands out: no empty cells, no text among numbers, no other spelling of nothing.", ""]
    con = record.get("conflicts") or []
    if con:
        body += ["**Conflicts between what was said and what was measured (%d), found by the program:**" % len(con), "", "| what | one side | the other side | which stands |", "|---|---|---|---|"]
        for c in con:
            body.append("| %s | %s (%s) | %s (%s) | %s |" % (_cell(c["what"], 200), _cell(c["a"]["says"], 120), _cell(c["a"]["source"], 80), _cell(c["b"]["says"], 160), _cell(c["b"]["source"], 80),
                                                           _cell(("%s: %s" % (c["priority"], c["stands"])) if c["settled"] else "**for you to decide** (%s)" % c["priority"], 200)))
        body.append("")
    words = [w for w in record.get("words") or [] if w["found"]]
    if words:
        body += ["**Where the rule's own words are stored:**"] + ["- “%s”: %s" % (w["text"], "; ".join("%s column %s holds “%s” in %s (%s)" % (
            f["file"], f["column"], f["spelling"], _plural(f["rows"], "row") if isinstance(f["rows"], int) else "rows not counted", f["basis"]) for f in w["found"][:3])) for w in words[:10]] + [""]
    for f in record.get("files") or []:
        for b in f.get("touched") or []:
            top = ", ".join("“%s” (%s)" % (x["value"], _n(x["rows"])) for x in b["most_frequent"][:5])
            body.append("- **%s column %s**: %s of %s hold a value; %s distinct value%s%s; they look like: %s%s%s. %s" % (
                b["file"], b["column"], _n(b["rows_with_a_value"]), _plural(b["rows"], "row"), _n(b["distinct_values"]), "" if b["distinct_values"] == 1 else "s",
                "" if b["distinct_is_exact"] else " or more (the count stopped there)", "; ".join("%s (%s)" % (s["shape"], _n(s["rows"])) for s in b["shapes"][:3]) or "nothing",
                "; from %s to %s%s" % (("%g" % b["range"][0]), ("%g" % b["range"][1]), " " + b["unit"] if b.get("unit") else "") if b.get("range") else "",
                "; most frequent: " + top if top else "", "(%s)" % b["basis"]))
    if record.get("links"):
        body += [""] + ["- " + x for x in link_lines(record["links"])]
    hid = record.get("hidden") or []
    if hid:
        body += ["", "**What the rule leaves open (%d): each becomes a requirement or a question to you, nothing is assumed:**" % len(hid)]
        body += ["- %s: %s *(%s)*" % (h["id"], h["decision"], h["because"]) for h in hid]
    led = record.get("ledger") or []
    if led:
        n = {s: sum(1 for x in led if x["state"] == s) for s in (ESTABLISHED, TO_MEASURE, TO_DECIDE, GUESS)}
        body += ["", "**The ledger** (everything the rule needs, with its source): %d established, %d to decide, %d a guess. The lines are in the step's details."
                 % (n[ESTABLISHED], n[TO_DECIDE] + n[TO_MEASURE], n[GUESS])]
    body.append("")
    return body


def _cell(t, most=220):
    t = " ".join(str(t if t is not None else "").split()).replace("|", "/")
    return t[:most - 1] + "…" if len(t) > most else t


def brief_for_agents(record):
    """The record as the Coder and the Tester read it: the whole dictionary of each touched file (one line per column,
    none left out), the measured block of each touched column, the links, where the rule's words are, the conflicts with
    what stands, and the admin's items. Long material first; no file the rule does not touch."""
    if not record:
        return None
    return {"FILES": [{"file": f["file"], "rows": f.get("rows"), "basis": f.get("basis"), "ALL_COLUMNS": f.get("columns"),
                       "MEASURED_FOR_THE_COLUMNS_THE_RULE_TOUCHES": [{k: v for k, v in b.items() if k not in ("file", "dictionary_at")} for b in f.get("touched") or []]} for f in record.get("files") or []],
            "LINKS_COUNTED_IN_THE_TREE": record.get("links") or [], "WHERE_THE_RULES_WORDS_ARE": record.get("words") or [],
            "CONFLICTS": [{"what": c["what"], "stands": c["stands"] if c["settled"] else "asked of the admin: see the requirements and his answers"} for c in record.get("conflicts") or []],
            "THE_ADMIN_SAID": [{k: v for k, v in x.items() if k in ("kind", "question", "text", "from")} for x in (record.get("admin_items") or [])[:14]],
            "NOTE": "every count above was counted by the program on this recording; it is an observation of this recording, not a rule for every recording"}


def licensed_columns(record, facts):
    """The columns the program may read: every column of the files the rule touches (the whole dictionary is given, so any
    of them is in the ledger's files), and a column the admin chose to stand for another. -> {file: set of columns}."""
    out = {}
    for f in (record or {}).get("files") or []:
        out[f["file"]] = {c["column"] for c in f.get("columns") or [] if c.get("column")}
    for name, head in (facts.get("headers") or {}).items():
        if isinstance(name, str) and name in out:
            out[name] |= set(head or [])
        elif isinstance(name, str) and name != PR.TREE and not out:
            out[name] = set(head or [])
    return out


def columns_read_by(code, headers):
    """The header texts the program names as text constants -> {column} that are columns of some file of the analysis,
    and {text} that look like a column the program reads (in head.index("...") or row["..."]) and are in no file."""
    known = set()
    for head in headers.values():
        known |= {c for c in head or [] if c}
    named = set(re.findall(r"""\.index\(\s*(["'])(.+?)\1\s*\)""", code))
    named = {b for _a, b in named}
    named |= {b for _a, b in re.findall(r"""\[\s*(["'])([^"'\n]{1,80})\1\s*\]""", code) if b in known}
    return {c for c in named if c in known}, {c for c in named if c not in known}


# ---------------------------------------------------------------------------------------------- the proof
def requirement_ids(req):
    """[(id, text)] of a requirements record: its own identifiers, or R1.. by position for one made before they existed."""
    texts = [str(x) for x in (req or {}).get("requirements") or []]
    ids = (req or {}).get("requirement_ids") or []
    return [((ids[i] if i < len(ids) and ids[i] else "R%d" % (i + 1)), t) for i, t in enumerate(texts)]


def count_rows(path):
    """The data rows of a CSV file, counted by this program (the application's own reader)."""
    with open(path, newline="", encoding="utf-8-sig", errors="replace") as fh:
        rd = family1.L.read_csv(fh, path)
        next(rd, None)
        return sum(1 for _ in rd)


def accounting_checks(summary, rows_by_file, out_csv, proc):
    """What needs no expected answer, checked on the whole real file from the program's own accounting and its output.
    -> (checks [{"check", "ok": True | False | None, "detail"}], the accounting as read). ok None = could not be checked."""
    acc = summary.get("accounting") if isinstance(summary, dict) and isinstance(summary.get("accounting"), dict) else None
    checks = []
    whole = lambda v: v if isinstance(v, int) and not isinstance(v, bool) and v >= 0 else None     # noqa: E731
    first = next(iter(rows_by_file.values()), None) if rows_by_file else None
    if acc is None:
        return [{"check": "every row of the file is accounted for exactly once (read = kept + left out + could not be evaluated)", "ok": None,
                 "detail": "the program gave no accounting of its rows"}], None
    read, kept, cannot = whole(acc.get("rows_read")), whole(acc.get("rows_kept")), whole(acc.get("rows_not_evaluated")) or 0
    left = acc.get("rows_left_out") if isinstance(acc.get("rows_left_out"), list) else []
    left = [x for x in left if isinstance(x, dict) and whole(x.get("rows")) is not None]
    out_n = sum(x["rows"] for x in left)
    if read is None or kept is None:
        checks.append({"check": "every row of the file is accounted for exactly once (read = kept + left out + could not be evaluated)", "ok": None,
                       "detail": "the accounting does not give rows_read and rows_kept as whole numbers"})
    else:
        ok = read == kept + out_n + cannot
        checks.append({"check": "every row of the file is accounted for exactly once (read = kept + left out + could not be evaluated)", "ok": ok,
                       "detail": "read %s = kept %s + left out %s + could not be evaluated %s%s" % (_n(read), _n(kept), _n(out_n), _n(cannot),
                                                                                                  "" if ok else ": %s row%s unaccounted" % (_n(abs(read - kept - out_n - cannot)), "" if abs(read - kept - out_n - cannot) == 1 else "s"))})
        if first is not None:
            checks.append({"check": "the rows the program says it read are the rows of the file, counted by the application", "ok": read == first,
                           "detail": "the program read %s; the file has %s" % (_n(read), _n(first))})
    cols, count_col, order = None, acc.get("count_column"), acc.get("ordered_by") if isinstance(acc.get("ordered_by"), dict) else None
    top_n = whole(acc.get("top_n"))
    if out_csv and os.path.exists(out_csv) and (count_col or order or top_n is not None):
        import csv
        total, n, prev, in_order, bad_at = 0.0, 0, None, True, None
        with open(out_csv, newline="", encoding="utf-8") as fh:
            rd = csv.reader(fh)
            cols = next(rd, [])
            ic = cols.index(count_col) if count_col in cols else None
            io = cols.index(order.get("column")) if order and order.get("column") in cols else None
            for row in rd:
                n += 1
                if ic is not None and ic < len(row):
                    total += _num(row[ic]) or 0.0
                if io is not None and io < len(row):
                    v = _num(row[io])
                    v = v if v is not None else row[io]
                    if prev is not None and type(prev) is type(v):
                        if (v > prev) if order.get("descending") else (v < prev):
                            if in_order:
                                bad_at = n + 1
                            in_order = False
                    prev = v
        if count_col:
            checks.append({"check": "the counts of the output add up to the rows kept", "ok": (abs(total - kept) < 1e-9) if (ic is not None and kept is not None) else None,
                           "detail": "the column %s adds up to %s; rows kept %s" % (count_col, "{:,.0f}".format(total), _n(kept)) if ic is not None else "the output has no column %s" % count_col})
        if top_n is not None:
            checks.append({"check": "the output has at most %s lines" % _n(top_n), "ok": n <= top_n, "detail": "%s written" % _plural(n, "line")})
        if order:
            checks.append({"check": "the output is in the stated order (%s, %s first)" % (order.get("column"), "largest" if order.get("descending") else "smallest"),
                           "ok": in_order if io is not None else None, "detail": "in order" if in_order and io is not None else
                           "line %s is out of order" % bad_at if io is not None else "the output has no column %s" % order.get("column")})
    return checks, {"rows_read": read, "rows_kept": kept, "rows_not_evaluated": cannot,
                    "rows_left_out": [{"requirement": str(x.get("requirement") or "")[:8], "reason": " ".join(str(x.get("reason") or "").split())[:160], "rows": x["rows"],
                                       "lines": [n for n in (x.get("lines") if isinstance(x.get("lines"), list) else []) if isinstance(n, int)][:ROWS_SHOWN]} for x in left][:40],
                    "groups": whole(acc.get("groups"))}


def can_fail(case, compare):
    """Does this data set tell a program that ignores the requirement from one that follows it? The Tester states the rows
    such a program would write ("without_it_rows"); when they differ from the expected rows the data set can fail."""
    exp, wo = case.get("expected_rows"), case.get("without_it_rows")
    if exp is None or not isinstance(wo, list) or not all(isinstance(x, list) for x in wo):
        return False
    width = len(case.get("_want_cols") or [])
    cols = case.get("_want_cols") or list(range(len(exp[0]) if exp else (len(wo[0]) if wo else 0)))
    if width and any(len(x) != width for x in wo):
        return False
    return bool(compare(exp, bool(case.get("order_matters")), cols, wo, cols))


def proof_table(reqs, cases, whole, classify=None):
    """The requirement-by-check table. reqs: [(id, text)]; cases: the data sets as they stand; whole: the whole-file run
    {"on", "ok", "rows", "checks", "accounting", "error"} or None. The verdict of each requirement is decided here, by
    this code:
      not met               a data set that tests it (and can fail) failed, or the whole file contradicts it;
      met                   a data set that tests it and can fail passed, and none failed;
      not exercised         nothing tests it, and in the whole file no row met its condition (the program's own count: 0);
      could not be checked  nothing that can fail tests it.
    -> {"rows": [...], "whole_file": [...], "without_a_check": n, "checks_tied_to_no_requirement": n}; no percentage."""
    acc = (whole or {}).get("accounting") or {}
    left = {}
    for x in acc.get("rows_left_out") or []:
        left.setdefault(x.get("requirement") or "", []).append(x)
    rows = []
    ids = {i for i, _t in reqs}
    for rid, text in reqs:
        mine = [c for c in cases if rid in (c.get("tests") or [])]
        weak = [c for c in cases if rid in (c.get("does_not_test") or [])]
        failed = [c for c in mine if c.get("status") == "failed"]
        passed = [c for c in mine if c.get("status") == "passed"]
        aside = [c for c in mine if c.get("status") not in ("passed", "failed", None)]
        real = left.get(rid) or []
        real_rows = sum(x["rows"] for x in real)
        evidence = []
        for c in mine:
            evidence.append({"kind": "data set", "name": c["name"], "property": c.get("property"), "result": c.get("status"), "detail": c.get("detail"), "can_fail": True})
        for c in weak:
            evidence.append({"kind": "data set", "name": c["name"], "property": c.get("property"), "result": "does not test %s" % rid,
                             "detail": "a program that ignored the requirement would write the same rows on this data", "can_fail": False})
        for x in real:
            evidence.append({"kind": "the whole file", "name": (whole or {}).get("on"), "result": "%s left out: %s" % (_plural(x["rows"], "row"), x["reason"]),
                             "lines": x.get("lines") or [], "can_fail": None})
        if failed:
            verdict, why = NOT_MET, "the data set%s %s failed" % ("" if len(failed) == 1 else "s", "; ".join("“%s”" % c["name"] for c in failed[:3]))
        elif passed:
            verdict, why = MET, "%s that can fail passed%s" % (_plural(len(passed), "data set"), ("; in the whole file %s met its condition" % _plural(real_rows, "row")) if real else "")
        elif real and real_rows == 0:
            verdict, why = NOT_EXERCISED, "no data set tests it, and in the whole file 0 rows met its condition (the program's own count)"
        elif aside:
            verdict, why = NOT_CHECKED, "its data set%s set aside or withdrawn: %s" % (" is" if len(aside) == 1 else "s are", "; ".join("“%s”" % c["name"] for c in aside[:3]))
        elif weak:
            verdict, why = NOT_CHECKED, "the data set%s made for it cannot fail: %s" % ("" if len(weak) == 1 else "s", "; ".join("“%s”" % c["name"] for c in weak[:3]))
        elif real:
            verdict, why = NOT_CHECKED, "no data set tests it; in the whole file %s met its condition, which the program counted itself" % _plural(real_rows, "row")
        else:
            verdict, why = NOT_CHECKED, "no data set that can fail tests it"
        rows.append({"id": rid, "requirement": text, "verdict": verdict, "why": why, "evidence": evidence, "rows_in_the_whole_file": real_rows if real else None,
                     "class": (classify or {}).get(rid)})
    rows.sort(key=lambda x: (VERDICT_ORDER.index(x["verdict"]), int(re.sub(r"\D", "", x["id"]) or 0)))
    tied_to_none = sum(1 for c in cases if c.get("by") == "the Tester" and not [t for t in (c.get("tests") or []) if t in ids] and c.get("status") in ("passed", "failed"))
    wf = [{"check": c["check"], "verdict": MET if c["ok"] is True else NOT_MET if c["ok"] is False else NOT_CHECKED, "detail": c["detail"]} for c in (whole or {}).get("checks") or []]
    return {"rows": rows, "whole_file": wf, "on": (whole or {}).get("on"), "without_a_check": sum(1 for x in rows if not [e for e in x["evidence"] if e.get("can_fail")]),
            "checks_tied_to_no_requirement": tied_to_none}


def table_body(table):
    """The table as lines of the code card: not met first; no overall percentage."""
    if not table or not table.get("rows"):
        return []
    body = ["**Does the code meet each requirement? Decided by the program from what ran, not by a model.** Requirements with no check that can fail: %d. Data sets tied to no requirement: %d."
            % (table["without_a_check"], table["checks_tied_to_no_requirement"]), "",
            "| requirement | what was checked | evidence | result |", "|---|---|---|---|"]
    for x in table["rows"]:
        checks = "; ".join("data set “%s”%s" % (e["name"], " (%s)" % _cell(e["property"], 80) if e.get("property") else "") if e["kind"] == "data set" else "the whole file" for e in x["evidence"][:4]) or "nothing"
        ev = "; ".join(("%s: %s" % (e["result"], _cell(e.get("detail"), 120)) if e["kind"] == "data set" else
                        "%s%s" % (e["result"], " (lines %s)" % ", ".join(str(n) for n in e["lines"][:8]) if e.get("lines") else "")) for e in x["evidence"][:4]) or "none"
        body.append("| **%s** %s | %s | %s | **%s**: %s |" % (x["id"], _cell(x["requirement"], 200), _cell(checks, 240), _cell(ev, 300), x["verdict"], _cell(x["why"], 200)))
    if table.get("whole_file"):
        body += ["", "**On the whole file (%s), without an expected answer:**" % (table.get("on") or "")] + ["- **%s**: %s (%s)" % (c["verdict"], c["check"], c["detail"]) for c in table["whole_file"]]
    body.append("")
    return body


def open_requirements(table):
    """The requirements the admin has to decide: not exercised, or could not be checked."""
    return [{"id": x["id"], "requirement": x["requirement"], "verdict": x["verdict"], "why": x["why"]} for x in (table or {}).get("rows") or [] if x["verdict"] in (NOT_EXERCISED, NOT_CHECKED)]


def not_met(table):
    return [x["id"] for x in (table or {}).get("rows") or [] if x["verdict"] == NOT_MET] + ["the whole file: " + c["check"] for c in (table or {}).get("whole_file") or [] if c["verdict"] == NOT_MET]
