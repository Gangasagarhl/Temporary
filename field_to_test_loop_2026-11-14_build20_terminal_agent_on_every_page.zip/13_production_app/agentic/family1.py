"""Family 1 — Data Experts: one sub-family per CSV of the input folder -> one approved data dictionary per CSV.

The sub-family has three agents, each with its OWN context (owner, 2026-11-08: "I don't want to mess the whole context"):

  Data Explorer   THE DATA, and only the data. Code reads EVERY row of the file (no sample) and records every column:
                  how many rows hold a value, its type, how many different values it has, and every special keyword:
                  the WORDS a column holds ("ACK", "UpdateFC-P", "CplD", "Link Up"; never a number, hex value, address,
                  id, time or the column's own name; see is_keyword), with how many rows hold it and the first rows where
                  it appears (kept in its memory for questions; the keywords themselves are shown by name). The model then only writes a summary
                  of that profile (what one row is, what the file records). The data is the truth: nothing about it is
                  "verified", it is counted. No notes, no meanings: those are the Grounder's.
  Data Grounder   THE MEANINGS, and only the meanings. It gets the column names and the keywords (never the data rows)
                  and finds what each one means: in the reference documents first, then on the web (when allowed), then
                  from the model's own knowledge. Every meaning says where it comes from; a document line and a web page
                  are checked by code (the quote must be there), model knowledge is labelled as such.
  Manager         TALKS TO THE ADMIN. It puts both together into the data dictionary and asks for review: a plain
                  summary of what the file is, then every column and keyword with what the data holds, what it means,
                  where the meaning comes from, and where to see it (file and line). When the admin asks a question, the
                  Manager asks the right helper (the Explorer for the data, with rows; the Grounder for a meaning) and
                  answers with the rows and the path.

Steps of a run (kind "family1"; the same steps inside the flow):
  director              lists the CSVs of the folder and what each one is (its level, its size, its header)
  explore:<csv>         the Data Explorer (code over every row, then the summary) -> runs/<run>/explorer_<csv>/memory.json
  ground:<csv>          the Data Grounder (meanings with sources) -> runs/<run>/grounder_<csv>/memory.json
  manager:<csv>         the Manager's dictionary -> REVIEW "Admin <name>, need review" (approve / change / reject)
"""
import csv
import functools
import glob
import hashlib
import json
import os
import re
import sys
import threading
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed

from . import core
from . import column_knowledge as CK

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
from nvme_hier import columns as C, loader as L   # noqa: E402

BATCH = 120                    # columns per Explorer call at most (one short sentence per column, no web) ...
EXPLORE_LEAST = 20             # ... and at least: the columns are cut into as many parts as calls run at the same time
EXPLORE_BY_CODE_ABOVE = 120    # a file with more filled columns than this: what each column holds is said from the counts, which is all the
                               # model was asked to repeat, and the model writes only the summary of the file (one call, not one per 120 columns)
# (owner, 2026-11-12: "the context of the model is 128k ... take 30 columns along with the keywords under each") What bounds a call is
# not what the model can READ (128,000 tokens) but what it may WRITE in one answer (AgentRunner.MAX_TOKENS = 16,000 tokens) and the
# time it takes to write it. So the Grounder makes two kinds of call, all at the same time:
#   - column meanings: 40 to 79 columns in one call, each given with its 30 most frequent keywords, one meaning per column
#     (column_parts); these are the only calls that may search the web;
#   - keyword meanings: up to 150 in one call (ground_parts), and a column's keywords are never cut in two: with 20 keywords per
#     column that is 7 columns (140 meanings) in a call, never with the web.
GROUND_BATCH = 40              # columns without a meaning in one Grounder call: at least this many whenever that many are open, and fewer
#                                than twice as many (owner, 2026-11-12: "each and every LLM call must have at least 40 column names")
GROUND_KEYWORDS_SHOWN = 30     # the keywords found most often in a column, counted by code on every row, that such a call gives with the
#                                column's name so the model can understand the column (owner: "along with the 30 different highest keywords")
GROUND_BATCH_KNOWN = 60        # columns in one call that asks only for keyword meanings (the column's meaning is known or asked apart)
GROUND_MEANINGS = 150          # keyword meanings in one such call at most ...
GROUND_MEANINGS_LEAST = 30     # ... and at least this many, so that a small file is not cut into many tiny calls
GROUND_KEYWORDS = 20           # keywords per column whose meaning the Grounder is asked for (owner: "the top 20 keywords")
# How much the model thinks before it writes the answer of a Grounder call: Claude Code's effort level, said with every call. Without
# it Claude Code takes the level from the personal settings of the user who runs the server (~/.claude/settings.json), so the same
# file is answered differently on another computer. Measured 2026-11-12, claude-sonnet-5-5, one call of 140 keywords of which 60 were
# made-up words that have no meaning: at xhigh (and with nothing said on the development computer, whose settings say xhigh) all 60
# were left empty, as the instruction asks, in 36 and 39 s; at medium (28 s) and at low (30 s) each of the 60 got a filler sentence
# ("its meaning is not documented"), which the program keeps as a meaning from the model (140 kept instead of 80). So the faster
# levels are not used. The Model connection has no such level (the value changes nothing there); the same call took 28 s over it
# and left the 60 empty. One call per level was measured: a sample, not a proof for every file.
GROUND_EFFORT = "xhigh"        # None: nothing is said (Claude Code's own settings decide)
EFFORT_LEVELS = ("low", "medium", "high", "xhigh", "max")


def ground_effort():
    """The effort level a Grounder call says to Claude Code -> one of EFFORT_LEVELS, or None (nothing said). A value that is
    not a level is never passed on."""
    return GROUND_EFFORT if GROUND_EFFORT in EFFORT_LEVELS else None


SHARED_KEYWORD_COLUMNS = 8    # a keyword that at least this many columns hold (Supported, Enabled, Reserved ...) is asked once for all of them
SHARED_KEYWORDS_PER_ITEM = 20  # such keywords in one question at most
KIND_SAMPLE = 5000             # rows looked at (the start of the file and four other places) to find which column names the kind of each row
KIND_MAX = 60                  # the most different kinds of row counted one by one (beyond: "other values")
GROUND_SLOW_AFTER = 120        # seconds a part may wait for the model before the progress line says which part waits, how long and why
KEYWORD_MAX_DISTINCT = 300     # a text column with at most this many different values holds keywords
DISTINCT_CAP = 2000            # different values counted one by one per column (beyond: "more than 2,000")
ROWS_PER_VALUE = 3             # the first rows where each value appears (where to see it)
TOP_VALUES = 8


def knowledge_dir():
    d = os.path.join(APP, "knowledge")
    os.makedirs(d, exist_ok=True)
    return d


# ---------------------------------------------------------------------------------------------- the inventory
def inventory(folder):
    out = []
    if not folder or not os.path.isdir(folder):
        return out
    for fn in sorted(os.listdir(folder)):
        p = os.path.join(folder, fn)
        if not (os.path.isfile(p) and fn.lower().endswith(".csv")):
            continue
        try:
            header, _rows = L.sniff(p, 0)
        except (OSError, UnicodeDecodeError):
            continue
        level = L.guess_level(header)
        out.append({"name": fn, "path": p, "bytes": os.path.getsize(p), "level": level,
                    "level_label": C.LEVEL_LABEL.get(level) if level else "not one of the five analyzer levels",
                    "columns": len(header), "format_key": format_key(level, header)})
    return out


def folder_problem(files):
    """Why this folder cannot be built into one tree, in words, or None. One folder holds one recording: two files of the same kind are two recordings,
    and quietly using the last one by name would join the packets of one recording to the commands of another (found 2026-11-10)."""
    by = {}
    for f in files:
        if f["level"]:
            by.setdefault(f["level"], []).append(f["name"])
    if not by:
        return "none of the CSV files in this folder is an analyzer export of the five kinds (packets, link, split, NVMe transactions, NVMe commands)"
    two = sorted((k, v) for k, v in by.items() if len(v) > 1)
    if two:
        return "this folder holds more than one file of the same kind: %s. One folder holds one recording: move the other files to a folder of their own, then run again" % (
            "; ".join("%s (%s)" % (C.LEVEL_LABEL.get(k, k), ", ".join(v)) for k, v in two))
    return None


def input_problem(files):
    """Why this folder cannot be one analysis, in words, or None. Any CSV files can be analysed (owner, 2026-11-12: "the
    input CSV should be agnostic to any of the fixed coding strategies"): a folder without analyzer exports of the five
    kinds is fine, it only cannot be built into the tree by the fixed joining strategy (see folder_problem). What stays
    refused is two files of the same kind: they are two recordings, and no rule could tell which one it reads."""
    by = {}
    for f in files:
        if f["level"]:
            by.setdefault(f["level"], []).append(f["name"])
    two = sorted((k, v) for k, v in by.items() if len(v) > 1)
    if two:
        return "this folder holds more than one file of the same kind: %s. One folder holds one recording: move the other files to a folder of their own, then run again" % (
            "; ".join("%s (%s)" % (C.LEVEL_LABEL.get(k, k), ", ".join(v)) for k, v in two))
    return None


def format_key(level, header):
    """The file format: the level and its header cells. The same key = the same export layout."""
    cells = [re.sub(r"^\d+(\.\d+)?$|^\d+ (warning|error)\(s\)$", "<value>", (h or "").strip()) for h in header]
    return hashlib.sha1(("%s|%s" % (level, "|".join(cells))).encode()).hexdigest()[:12]


# ---------------------------------------------------------------------------------------------- the Explorer's code
_INT = re.compile(r"^-?\d+$")
_HEX = re.compile(r"^(0x)?[0-9A-Fa-f]+$")
_TIME = re.compile(r"^\d+\.\d+\s*s$")
_DUR = re.compile(r"^\d+(\.\d+)?\s*(ps|ns|us|µs|ms|s)$")


def _type_of(values):
    vals = [v for v in values if v][:500]
    if not vals:
        return "empty"
    for name, rx in (("integer", _INT), ("time stamp", _TIME), ("time span", _DUR), ("hex", _HEX)):
        if all(rx.match(v) for v in vals):
            return name
    return "text"


_ID = re.compile(r"^\d{1,4}:\d{1,3}[:.]\d{1,2}$")                    # a requester / completer / device id: bus:device.function
_NUMERIC_LIKE = re.compile(r"^[0-9.,:;/_\-+x ]+$", re.I)              # digits and separators only (numbers, ranges, addresses)
_QUANTITY = re.compile(r"^-?\d[\d.,]*\s*(ps|ns|us|µs|ms|s|b|kb|mb|gb|bytes?|dw|dwords?|gt/s|lanes?|%)$", re.I)


def is_keyword(value, column):
    """A special keyword is a WORD: the name of a type, an event, a status (ACK, UpdateFC-P, PM_Request_Ack, CplD, TS1,
    Link Up, Successful Completion). Never a number (a sequence number, a tag, a length), a hex value or an address, a
    bus:device.function id, a time or a quantity with its unit, or the column's own name repeated in a cell."""
    v = value.strip()
    if not v or not re.search(r"[A-Za-z]", v):
        return False
    if _NUMERIC_LIKE.match(v) or _ID.match(v) or _TIME.match(v) or _DUR.match(v) or _QUANTITY.match(v):
        return False
    if _HEX.match(v) and re.search(r"\d", v):          # 1F, 0x2A, 3fe0: a hex number, not a word
        return False
    if v.lower() == (column or "").strip().lower() or v.lower() == (column or "").partition(".")[2].strip().lower():
        return False                                    # the header repeated in the first row ("Marker" under Marker)
    return True


IDENTITY_COLUMNS = {"mn", "sn", "fr", "model number", "serial number", "firmware revision", "subnqn", "nqn"}   # the drive's identity
FLAG_WORDS = {"yes", "no", "true", "false", "on", "off"}                      # a yes/no flag is not a keyword
_CODE_NAME = re.compile(r"^(0x[0-9A-Fa-f]+|\d+)\s*\((.+)\)$")              # "0x02 (Read)" -> Read
_NAME_VALUE = re.compile(r"^([A-Za-z][^:]{0,60}?)\s*:\s*[-+]?\d[\d.,]*\s*[A-Za-z/%µ#]{0,6}$")   # "Speed Change: 16.0 GT/s" -> Speed Change
_COUNT_PHRASE = re.compile(r"^\d[\d,]*\s+[A-Za-z]")                         # "1 error(s)", "3 warnings": a count


def keyword_names(value, column):
    """The special keywords a cell holds, as NAMES: the words (ACK, UpdateFC-P, Read, Successful Completion, Speed Change),
    without the numbers around them. A listed cell ("2.5 GT/s, 5.0 GT/s") is looked at part by part."""
    col = (column or "").strip().lower()
    if col in IDENTITY_COLUMNS or col.partition(".")[2].strip() in IDENTITY_COLUMNS:
        return []
    out = []
    for part in ([x.strip() for x in value.split(",")] if "," in value else [value.strip()]):
        m = _CODE_NAME.match(part)
        if m:
            part = m.group(2).strip()
        m = _NAME_VALUE.match(part)
        if m:
            part = m.group(1).strip()
        if part.lower() in FLAG_WORDS or _COUNT_PHRASE.match(part):
            continue
        if is_keyword(part, column):
            out.append(part)
    return out


SPEC_CITE = re.compile(r"((?:NVMe|NVM Express|PCIe|PCI Express)[^|\n]{0,40}?(?:§\s*[0-9][0-9.]*[0-9]|Section\s+[0-9][0-9.]*[0-9]|Figure\s+[0-9]+|Table\s+[0-9]+)"
                       r"|doc\s+[A-Z]{2,}\s+[0-9][0-9.]*[0-9]|manual\s+v[0-9][0-9.]*[0-9])", re.I)      # specification sections, and the LeCroy manual references the notes use ("doc VSE 5.2.12")


@functools.lru_cache(maxsize=512)
def _source_details(path, line, mtime):
    kind = "project research note" if "research_notes" in path else "LeCroy manual" if "lecroy" in os.path.basename(path).lower() and not path.endswith((".md", ".json")) else \
        "specification" if re.search(r"(nvm.?express|pci.?express|base.?spec)", os.path.basename(path), re.I) else "reference document"
    heading, here = "", ""
    with open(path, encoding="utf-8", errors="replace") as fh:
        for i, text in enumerate(fh, 1):
            if text.lstrip().startswith("#"):
                heading = text.strip().lstrip("#").strip()
            if i == line:
                here = text.strip()
                break
    cites = list(dict.fromkeys(m.strip() for m in SPEC_CITE.findall(here)))
    return {"document": os.path.basename(path), "kind": kind, "section": heading[:120], "cites": cites[:4], "line_text": here[:240]}


@functools.lru_cache(maxsize=256)
def _blank_positions(path, mtime):
    header, _rows = L.sniff(path, 0)
    return [i + 1 for i, h in enumerate(header) if not (h or "").strip()]


def blank_header_positions(path):
    """The positions (1 = first) of the analyzer's blank spacer columns: no header and never a value."""
    try:
        return list(_blank_positions(path, os.path.getmtime(path)))
    except (OSError, UnicodeDecodeError, ValueError):
        return []


def source_details(ref):
    """Where a fact taken from a document comes from, in words for the page (owner, 2026-11-10: "which specification, in that .md file?"): the kind of document (a project
    research note is not a specification), the heading the line sits under, and any specification section named on that very line; none named is said as such."""
    path, _, line = (ref or "").rpartition(":")
    try:
        n = int(line)
        mtime = os.path.getmtime(path)
    except (ValueError, OSError):
        return None
    out = dict(_source_details(path, n, mtime))
    # a line of this application's own reference document of a tool: the page also names the public document the quote was taken from
    original = CK.library().original_of(ref)
    if original:
        out["kind"] = "reference document of %s, prepared for this application" % original.get("tool_name")
        out["original"] = original
    return out


def reading_line(name, lines, done_bytes, size, t0, share=(0.0, 100.0), columns=None):
    """One status line while a file is read: '37% · reading packets.csv: 36,700 of about 99,100 lines, about 62,400 left · 12 s so far · about 20 s to go'.
    The total is estimated from the bytes read so far, so it says "about". share maps the reading onto part of the step's own percentage."""
    frac = min(1.0, done_bytes / float(max(1, size)))
    pct = share[0] + (share[1] - share[0]) * frac
    el = time.time() - t0
    est = int(lines / frac) if frac > 0.001 else None
    cols = " (%s columns)" % "{:,}".format(columns) if columns else ""
    text = "%d%% · reading %s%s: %s of about %s lines, about %s left" % (pct, name, cols, "{:,}".format(lines), "{:,}".format(est), "{:,}".format(max(0, est - lines))) if est else \
        "%d%% · reading %s%s: %s lines so far" % (pct, name, cols, "{:,}".format(lines))
    text += " · %s so far" % core.fmt_secs(el)
    if 0.01 < frac < 1.0:
        togo = el * (1 - frac) / frac
        text += " · about %s to go" % core.fmt_secs(togo) if togo >= 1 else " · almost done"
    return text


def _named_columns(level, header):
    """-> (the header's alignment or None, [(column name, its position in the file)]) for every column of the file."""
    al = L.align_header(level, header) if level else None
    named = sorted(al.positions.items(), key=lambda kv: kv[1]) if al else [((h or "column %d" % (i + 1)), i) for i, h in enumerate(header)]
    if al:
        named += [(h, i) for i, h in al.unknown]
        named += [("column %d" % (i + 1), i) for i in al.separators]     # no header: read too, so a value under a blank header is seen (found 2026-11-10: split.csv column 4 held the link speed); the loader stores them under the same name
    return al, named


# ---- which kind of row fills which column (owner, 2026-11-11: "a Read command fills only the columns it needs, a Write only its
# own ... that special status is also needed when extracting from the model"). Nothing is assumed about the file: the column (or
# the few columns, never filled on the same row) whose WORD says what kind of row a row is, is the one that best decides which other
# columns hold a value. It is looked for in a sample; the counts that are then stated come from every row.
_NO_KIND, _TWO_KINDS, _OTHER_KINDS = (-1, ""), (-2, ""), (-3, "")


def _sample_rows(path, rows=KIND_SAMPLE):
    """-> (header, rows): from the start of the file and, when the file is longer, from four other places in it (a recording often
    starts with one kind of row only)."""
    size = os.path.getsize(path)
    out, head = [], rows * 3 // 5
    with open(path, "r", encoding="utf-8-sig", errors="replace", newline="") as fh:
        rd = L.read_csv(fh, path)
        header = next(rd, [])
        for row in rd:
            out.append(row)
            if len(out) >= head:
                break
        covered = fh.buffer.tell() if hasattr(fh, "buffer") else size
        if covered * 2 >= size:                 # a short file: simply the first rows
            for row in rd:
                out.append(row)
                if len(out) >= rows:
                    break
            return header, out
    width = Counter(len(r) for r in out).most_common(1)[0][0] if out else len(header)
    with open(path, "rb") as fb:
        for frac in (0.3, 0.5, 0.7, 0.9):
            at = int(size * frac)
            if at <= covered:
                continue
            fb.seek(at)
            fb.readline(L.MAX_LINE_CHARS)       # the rest of the line the place fell into
            lines = []
            for _ in range((rows - head) // 4):
                ln = fb.readline(L.MAX_LINE_CHARS)
                if not ln:
                    break
                lines.append(ln.decode("utf-8", errors="replace"))
            try:
                out += [r for r in csv.reader(lines) if len(r) == width]      # a row cut by a line break inside a cell is left out
            except csv.Error:
                pass
    return header, out


def _kind_key(row, places):
    m, key = len(row), None
    for p in places:
        if p < m:
            v = row[p]
            if v and not v.isspace():
                if key is not None:
                    return _TWO_KINDS
                key = (p, v.strip())
    return key or _NO_KIND


def kind_columns(path, level):
    """The column that names the KIND of each row (the command of an NVMe command row, the type of a transaction), or the few
    columns that do it together when each kind of row has its own (a packet has a TLP Type or a DLLP Type or an ordered-set type,
    never two). Candidates are columns of words with at most KIND_MAX different values; the one kept is the one that decides the
    most of the columns that are filled on some rows only (for every kind: filled on all its rows or on none). None when no column
    decides at least two of them and a quarter. -> {"columns": [(name, position)], "decides", "of", "rows_looked_at"}."""
    header, sample = _sample_rows(path)
    _al, named = _named_columns(level, header)
    n, width = len(sample), len(named)
    if n < 20 or width < 3:
        return None
    fill, vals, masks = [0] * width, [dict() for _ in named], []
    for row in sample:
        m, mask = len(row), 0
        for j, (_nm, idx) in enumerate(named):
            if idx < m:
                v = row[idx]
                if v and not v.isspace():
                    fill[j] += 1
                    mask |= 1 << j
                    d = vals[j]
                    if len(d) <= KIND_MAX:
                        v = v.strip()
                        d[v] = d.get(v, 0) + 1
        masks.append(mask)
    partly = 0
    for j in range(width):
        if 0 < fill[j] < n:
            partly |= 1 << j
    if not partly:
        return None
    words = [j for j in range(width) if fill[j] and len(vals[j]) <= KIND_MAX
             and sum(k for v, k in vals[j].items() if keyword_names(v, named[j][0])) >= 0.95 * fill[j]]
    cands = [[j] for j in words if fill[j] >= 0.98 * n and len(vals[j]) >= 2 and n >= 3 * len(vals[j])]
    some = sorted((j for j in words if fill[j] < 0.98 * n), key=lambda j: (-fill[j], j))[:24]
    rows_of = {}
    for j in some:
        idx, bits = named[j][1], 0
        for i, row in enumerate(sample):
            if idx < len(row) and row[idx] and not row[idx].isspace():
                bits |= 1 << i
        rows_of[j] = bits
    seen = set()
    for seed in some[:4]:                       # columns never filled on the same row, which together name nearly every row
        group, union = [seed], rows_of[seed]
        for j in some:
            if j != seed and not (rows_of[j] & union):
                group.append(j)
                union |= rows_of[j]
        key = tuple(sorted(group))
        if len(group) >= 2 and key not in seen and bin(union).count("1") >= 0.98 * n and 2 <= sum(len(vals[j]) for j in group) <= KIND_MAX:
            seen.add(key)
            cands.append(list(key))
    best = None
    for group in cands:
        places = [named[j][1] for j in group]
        both, either = {}, {}
        for row, mask in zip(sample, masks):
            key = _kind_key(row, places)
            if key in both:
                both[key] &= mask
                either[key] |= mask
            else:
                both[key] = either[key] = mask
        undecided, mine = 0, 0
        for key in both:
            undecided |= either[key] & ~both[key]
        for j in group:
            mine |= 1 << j
        decides, of = bin(partly & ~undecided & ~mine).count("1"), bin(partly & ~mine).count("1")
        rank = (decides, -len(both), -group[0])
        if best is None or rank > best[0]:
            best = (rank, group, decides, of)
    if best is None or best[2] < max(2, -(-best[3] // 4)):
        return None
    return {"columns": [named[j] for j in best[1]], "decides": best[2], "of": best[3], "rows_looked_at": n}


def _n(x):
    return "{:,}".format(x)


def _filled_for(j, kinds, members, rows):
    """The special status of column j: which kinds of row fill it, as counted on every row; None when every kind of row fills it
    at least sometimes (then the kind of row says nothing about it)."""
    mine = [k for k in kinds if k["counts"][j]]
    never = sum(k["rows"] for k in kinds if not k["counts"][j])
    if not mine or not never:
        return None
    phrases, short = [], []
    for col in members + [""]:
        ks = sorted((k for k in mine if k["column"] == col), key=lambda k: (-k["counts"][j], k["value"]))
        if not ks:
            continue
        f, r = sum(k["counts"][j] for k in ks), sum(k["rows"] for k in ks)
        if not col:
            phrases.append("rows where %s (%s of %s rows)" % (" or ".join(k["value"] for k in ks), _n(f), _n(r)))
            short.append("rows where %s" % " or ".join(k["value"] for k in ks))
        elif len(members) > 1 and len(ks) == sum(1 for k in kinds if k["column"] == col):
            phrases.append("rows that have a %s (%s of %s rows)" % (col, _n(f), _n(r)))
            short.append("rows that have a %s" % col)
        else:
            shown = ", ".join("%s (%s of %s rows)" % (k["value"], _n(k["counts"][j]), _n(k["rows"])) for k in ks[:5])
            if len(ks) > 5:
                shown += " and %d more (%s of %s rows)" % (len(ks) - 5, _n(sum(k["counts"][j] for k in ks[5:])), _n(sum(k["rows"] for k in ks[5:])))
            phrases.append("rows where %s is %s" % (col, shown))
            short.append("rows where %s is %s" % (col, " or ".join(k["value"] for k in ks[:5]) + (" or %d more" % (len(ks) - 5) if len(ks) > 5 else "")))
    return {"by": [c for c in members if any(k["column"] == c for k in mine)],
            "kinds": [{"column": k["column"], "value": k["value"], "rows_filled": k["counts"][j], "rows": k["rows"]} for k in
                      sorted(mine, key=lambda k: -k["counts"][j])[:12]],
            "kinds_filled": len(mine), "rows_never": never, "rows": "; and ".join(short),
            "text": "filled only on %s; never on the other %s row%s" % ("; and on ".join(phrases), _n(never), "" if never == 1 else "s")}


def full_profile(path, level, progress=None, share=(0.0, 100.0)):
    """EVERY row of the file, every column, by code (no model, no sample): per column how many rows hold a value, its
    type, how many different values, the values with their counts and the first rows where each appears (row n = line
    n + 1 of the file, after the header); and, per kind of row (see kind_columns), how many of its rows fill each column.
    Memory stays low: at most DISTINCT_CAP different values are counted per column."""
    size = os.path.getsize(path)
    try:
        kind = kind_columns(path, level)
    except (OSError, ValueError, L.BadFile):
        kind = None
    with open(path, "r", encoding="utf-8-sig", errors="replace", newline="") as fh:
        rd = L.read_csv(fh, path)
        header = next(rd, [])
        al, named = _named_columns(level, header)
        pairs = [(j, idx) for j, (_n1, idx) in enumerate(named)]
        filled = [0] * len(named)
        counts = [dict() for _ in named]
        first = [dict() for _ in named]
        over = [False] * len(named)
        width = len(named)
        places = [p for _nm, p in kind["columns"]] if kind else []
        by_kind = {}                    # kind of row -> how many of its rows fill each column, and (last) how many rows it has
        bk = [0] * (width + 1)          # no kind column: one list that is never read
        n, t0, bytes_seen, last_report = 0, time.time(), 0, 0.0
        for row in rd:
            n += 1
            m = len(row)
            if places:
                key = None
                for p in places:
                    if p < m:
                        v = row[p]
                        if v and not v.isspace():
                            if key is not None:
                                key = _TWO_KINDS
                                break
                            key = (p, v.strip())
                if key is None:
                    key = _NO_KIND
                bk = by_kind.get(key)
                if bk is None:
                    if len(by_kind) >= KIND_MAX:
                        key = _OTHER_KINDS
                    bk = by_kind.get(key)
                    if bk is None:
                        bk = by_kind[key] = [0] * (width + 1)
                bk[width] += 1
            for j, idx in pairs:
                if idx >= m:
                    continue
                v = row[idx]
                if not v or v.isspace():
                    continue
                v = v.strip()
                filled[j] += 1
                bk[j] += 1
                c = counts[j]
                if v in c:
                    c[v] += 1
                    f = first[j][v]
                    if len(f) < ROWS_PER_VALUE:
                        f.append(n)
                elif len(c) < DISTINCT_CAP:
                    c[v] = 1
                    first[j][v] = [n]
                else:
                    over[j] = True
            if n % 100000 == 0 and hasattr(fh, "buffer"):
                L.drop_file_cache(fh.buffer, 0, fh.buffer.tell())         # every row is read once: the file cache is left to the other programs
            if progress and n % 2000 == 0 and time.time() - last_report >= 1:      # about once a second, in one line: which file, lines read, about how many are left (owner, 2026-11-10)
                last_report = time.time()
                bytes_seen = fh.buffer.tell() if hasattr(fh, "buffer") else 0
                progress(reading_line(os.path.basename(path), n, bytes_seen, size, t0, share, columns=len(header)))
    # the kinds of row, by name: "0x02 (Read)" and "Read" are the same kind
    kinds, members, kind_fact = [], [], None
    if kind and len(by_kind) > 1:
        name_at = {p: nm for nm, p in kind["columns"]}
        members = [nm for nm, _p in kind["columns"]]
        merged = {}
        for key, cnt in by_kind.items():
            if key == _NO_KIND:
                col, value = "", "none of %s holds a value" % ", ".join(members) if len(members) > 1 else "%s holds no value" % members[0]
            elif key == _TWO_KINDS:
                col, value = "", "more than one of %s holds a value" % ", ".join(members)
            elif key == _OTHER_KINDS:
                col, value = "", "%s holds one of the less common values" % " or ".join(members)
            else:
                col = name_at[key[0]]
                value = (keyword_names(key[1], col) or [key[1]])[0][:60]
            have = merged.get((col, value))
            if have is None:
                merged[(col, value)] = {"column": col, "value": value, "rows": cnt[width], "counts": list(cnt[:width])}
            else:
                have["rows"] += cnt[width]
                have["counts"] = [a + b for a, b in zip(have["counts"], cnt[:width])]
        kinds = sorted(merged.values(), key=lambda k: (-k["rows"], k["column"], k["value"]))
        shown = ", ".join("%s (%s rows)" % (k["value"] if len(members) == 1 or not k["column"] else "%s %s" % (k["column"], k["value"]), _n(k["rows"])) for k in kinds[:8])
        kind_fact = {"columns": members, "kinds": [{"column": k["column"], "value": k["value"], "rows": k["rows"]} for k in kinds],
                     "decides": kind["decides"], "of": kind["of"], "rows_looked_at": kind["rows_looked_at"],
                     "text": "The kind of each row is named by %s: %s%s. Found by code, from which columns hold a value on which rows: in the %s rows "
                             "looked at it decides %d of the %d columns that are filled on some rows only. The counts are from every row." % (
                                 members[0] if len(members) == 1 else "one of %s (never two on the same row)" % ", ".join(members), shown,
                                 " and %d more" % (len(kinds) - 8) if len(kinds) > 8 else "", _n(kind["rows_looked_at"]), kind["decides"], kind["of"])}
    cols = []
    for j, (name, idx) in enumerate(named):
        c = counts[j]
        typ = _type_of(list(c.keys()))
        distinct = len(c)
        top = sorted(c.items(), key=lambda kv: (-kv[1], kv[0]))
        agg = {}
        for v, k in top:
            for nm in keyword_names(v, name):
                a = agg.setdefault(nm, {"count": 0, "rows": [], "as_written": []})
                a["count"] += k
                a["rows"] = sorted(set(a["rows"] + first[j][v]))[:ROWS_PER_VALUE]
                if v != nm and len(a["as_written"]) < 3:
                    a["as_written"].append(v[:120])
        words = sorted(agg.items(), key=lambda kv: (-kv[1]["count"], kv[0]))
        keyword_col = 0 < len(words) <= KEYWORD_MAX_DISTINCT and not over[j]
        col = {"column": name, "position": idx, "header_cell": header[idx] if idx < len(header) else "", "type": typ,
               "rows_with_value": filled[j], "filled_pct": round(100.0 * filled[j] / max(1, n), 2),
               "distinct": distinct, "distinct_more_than_counted": over[j],
               "top_values": [{"value": v[:120], "count": k, "rows": first[j][v]} for v, k in top[:TOP_VALUES]]}
        if keyword_col:
            # the keywords are the words only; their counts and first rows stay in the Explorer's memory for questions
            col["keywords"] = [{"value": nm[:120], "count": a["count"], "rows": a["rows"], "as_written": a["as_written"]} for nm, a in words]
        if typ == "integer" and c:
            nums = []
            for v in c:                 # the type is decided from the values counted one by one; a value that is not a whole number is left out
                try:
                    nums.append(int(v))
                except ValueError:
                    pass
            if nums:
                col["min"], col["max"] = min(nums), max(nums)
        if kinds and name not in members and 0 < filled[j] < n:
            ff = _filled_for(j, kinds, members, n)
            if ff:
                col["filled_for"] = ff
        cols.append(col)
    return {"path": path, "level": level, "level_label": C.LEVEL_LABEL.get(level) if level else "", "rows": n, "kind_of_row": kind_fact,
            "columns_with_special_status": sum(1 for x in cols if x.get("filled_for")),
            "columns_in_file": len(header), "columns_with_values": sum(1 for x in cols if x["rows_with_value"]),
            "columns_empty": [x["column"] for x in cols if not x["rows_with_value"]],
            "keyword_columns": sum(1 for x in cols if x.get("keywords")), "keywords": sum(len(x.get("keywords") or []) for x in cols),
            "header_format": al.header_format if al else "unknown", "seconds": round(time.time() - t0, 1), "columns": cols}


def where(path, rows):
    """Where to see it: the file and its line numbers (row n of the data is line n + 1, after the header line)."""
    return "%s line %s" % (path, ", ".join(str(r + 1) for r in rows[:ROWS_PER_VALUE])) if rows else path


# ---------------------------------------------------------------------------------------------- stand-ins (no model)
def _standin_explore(prof, batch, with_summary):
    """What the data holds, said from the counts alone (every number here was counted by code on every row). Used when no model
    answers and, for a file with very many columns, for every column: the counts are all the model was asked to repeat. Nothing
    here says which tool wrote the file unless its header was recognised (prof["exported_by"])."""
    out = {"columns": []}
    rows = prof.get("rows") or 0
    for c in batch:
        kw = [k for k in c.get("keywords") or [] if isinstance(k, dict)]
        tops = [t for t in c.get("top_values") or [] if isinstance(t, dict)]
        different = "{:,}".format(c["distinct"]) if isinstance(c.get("distinct"), int) else ""
        if kw:
            what = "%d keyword%s: %s%s" % (len(kw), "" if len(kw) == 1 else "s", ", ".join(str(k.get("value")) for k in kw[:8]), " ..." if len(kw) > 8 else "")
        elif c.get("type") == "integer" and "min" in c:
            what = "numbers from %s to %s%s" % (c["min"], c.get("max"), " (%s different)" % different if different else "")
        else:
            what = "%s values%s%s" % (c.get("type") or "text",
                                      " (%s different%s)" % (different, " or more" if c.get("distinct_more_than_counted") else "") if different else "",
                                      ", such as " + ", ".join(str(t.get("value")) for t in tops[:3]) if tops else "")
        out["columns"].append({"column": c["column"],
                               "observed": "%s of %s rows hold a value: %s." % ("{:,}".format(c.get("rows_with_value") or 0), "{:,}".format(rows), what)})
    if with_summary:
        busy = sorted([c for c in prof.get("columns") or [] if c.get("keywords")], key=lambda c: -(c.get("rows_with_value") or 0))[:3]
        label, tool = prof.get("level_label") or "", (prof.get("exported_by") or {}).get("name") or ""
        out["summary"] = "This file has %s rows%s%s. %d of its %d columns hold values; %d columns hold special keywords (%d different keywords in all)%s." % (
            "{:,}".format(rows), ", one %s record per row" % label if label else "", ", exported by %s" % tool if tool else "",
            prof.get("columns_with_values") or 0, prof.get("columns_in_file") or 0, prof.get("keyword_columns") or 0, prof.get("keywords") or 0,
            ("; the most used are in " + ", ".join(c["column"] for c in busy)) if busy else "")
    return out


def _contents(c):
    """A column's contents in a few facts that code computed from every row (the Explorer's profile): never the rows themselves."""
    out = {"observed": str(c.get("observed") or "")[:300], "rows_with_value": c.get("rows_with_value")}
    for k in ("distinct", "min", "max"):
        if c.get(k) not in (None, ""):
            out[k] = c[k]
    tops = [{"value": t.get("value"), "count": t.get("count")} for t in (c.get("top_values") or [])[:TOP_VALUES] if isinstance(t, dict)]   # every value the Explorer kept
    if tops:
        out["most_common"] = tops
    return out


def _column_values(c):
    """The values of a column that the Explorer kept (its most common values, its keywords, its smallest and largest value): a
    meaning that says it was read from the data must quote one of these."""
    vals = [str(t["value"]) for t in c.get("top_values") or [] if isinstance(t, dict) and t.get("value") is not None]
    vals += [str(k["value"]) for k in c.get("keywords") or [] if isinstance(k, dict) and k.get("value") is not None]
    return vals + [str(c[k]) for k in ("min", "max") if c.get(k) not in (None, "")]


# ---------------------------------------------------------------------------------------------- what is already known
def exported_by(columns, declared=None):
    """Which tool exported a file with these columns (a profile's columns, the empty ones too) ->
    {"tool": key or None, "name", "domain", "exports", "web_hint", "names", "found", "share", "how"}.
    declared: the tool the admin chose for the project on the start page (a key of the reference library) or None. A chosen
    tool is taken when at least one column name of the file is in that tool's list ("how": "chosen"); a file with none of its
    names there is not that tool's export, whatever was chosen ("how": "chosen, not matching", and "chosen_name" says which).
    Without a choice the header alone decides ("recognised"), and no tool is assumed: a header that matches none of the
    reference library's column lists is a file of an unknown tool ("unknown")."""
    lib = CK.library()
    names = [c.get("column") for c in columns if isinstance(c, dict)]
    key, facts = lib.recognise(names)
    how, extra = ("recognised" if key else "unknown"), {}
    if declared and declared in lib.tools:
        own = lib.names_found(declared, names)
        if own["found"]:
            key, facts, how = declared, own, "chosen"
        elif not key:
            how, extra = "chosen, not matching", {"chosen_name": lib.tools[declared]["name"]}
    d = lib.describe(key) or {}
    return dict({"tool": key, "name": d.get("name") or "", "domain": d.get("domain") or "", "exports": d.get("exports") or "",
                 "web_hint": d.get("web_hint") or "", "how": how}, **dict(facts, **extra))


def _declared_tool(ctx):
    """The tool chosen for the project on the start page (project.source_tool), or None: older projects have none."""
    p = getattr(ctx, "project", None)
    try:
        return (p.get("source_tool") if hasattr(p, "get") else None) or None
    except Exception:
        return None


def exported_sentence(tool):
    """One plain sentence on which tool a file comes from and how that is known (for the Manager's review text)."""
    if not isinstance(tool, dict):
        return ""
    n, found = tool.get("names") or 0, tool.get("found") or 0
    counted = "%d of its %d column name%s are in that tool's reference document" % (found, n, "" if n == 1 else "s")
    if tool.get("tool") and tool.get("how") == "chosen":
        return "An export of **%s**, the tool chosen for this project on the start page: %s." % (tool.get("name") or tool["tool"], counted)
    if tool.get("tool"):
        return "Recognised as an export of **%s**: %s." % (tool.get("name") or tool["tool"], counted)
    if tool.get("how") == "chosen, not matching":
        return ("The project says its recordings come from **%s**, but none of this file's %d column name%s is in that tool's reference "
                "document: the file is handled as the export of an unknown tool." % (
                    tool.get("chosen_name") or "the chosen tool", n, "" if n == 1 else "s"))
    return ("The tool that exported this file was not recognised: its column names match no reference document of the application, "
            "so no meaning could be taken from one.")


def _prompt_words(tool):
    """(how the prompts name the file's origin, which knowledge the model reads names and values with): from the recognised
    tool, and in general words for a file of an unknown tool."""
    if tool.get("tool"):
        return ("exported by %s (%s)" % (tool["name"], tool["exports"]) if tool.get("exports") else "exported by %s" % tool["name"],
                "your knowledge of %s" % (tool.get("domain") or tool["name"]))
    return "whose exporting tool is not known", "your general knowledge of what such names and values point to"


def _web_note(tool):
    """What a Grounder call is told about the web: the tool's own documentation first when the tool is known; for an unknown
    tool the first searches are to find which tool writes such a file (owner, 2026-11-12: "if the CSV is not mentioned ... first
    web search")."""
    if tool.get("tool"):
        first = 'Search the documentation of %s first (search words such as "%s" with the column\'s name), then the official specifications of %s.' % (
            tool["name"], tool.get("web_hint") or tool["name"], tool.get("domain") or "its field")
    else:
        first = ("The tool that exported this file is not known: search several of the column names together first, to find the tool and its "
                 "documentation; then search for the columns that are still open.")
    return "\n\nTHE WEB: you may search the web for what the snippets do not tell. %s At most 5 searches in this call. %s" % (first, core.AgentRunner.WEB_RULES)


def _day(t):
    try:
        return time.strftime("%Y-%m-%d", time.localtime(float(t))) if t else ""
    except (TypeError, ValueError, OverflowError, OSError):
        return ""


def _stored_part(e):
    """Where a remembered meaning was learned (the file, the day) and, when the admin approved it, by whom and when."""
    lf = e.get("learned_from") if isinstance(e.get("learned_from"), dict) else {}
    out = {"file": lf.get("file") or "", "on": _day(lf.get("at"))}
    ap = e.get("approved")
    if isinstance(ap, dict):
        out["approved_by"], out["approved_on"] = ap.get("by") or "the admin", _day(ap.get("at"))
    elif ap:
        out["approved_by"], out["approved_on"] = "the admin", ""
    return out


def _stored_answer(e):
    """A column's meaning as an earlier run understood it (column_knowledge.Store), with its source as it was saved."""
    out = {"meaning": str(e.get("meaning") or "").strip(), "source": e.get("source") or {}, "checked": bool(e.get("checked")), "why": e.get("why") or "",
           "stored": _stored_part(e), "keywords": {}}
    if isinstance(e.get("library"), dict):
        out["library"] = e["library"]
    return out


def _kept_keyword(m):
    out = {"meaning": str(m.get("meaning") or "").strip(), "source": m.get("source") or {}, "checked": bool(m.get("checked")), "why": m.get("why") or "",
           "stored": _stored_part(m)}
    if m.get("asked_once_for"):
        out["asked_once_for"] = m["asked_once_for"]
    return out


def _useful_snippets(snips, lib_doc="", lib_lines=None):
    """The snippets worth a place in a call: each line once, and of the application's own reference document only the lines
    that say something (not a heading, not where the column stands in the export, not a table row)."""
    out, seen = [], set()
    for s in snips:
        ref = s.get("ref")
        if not ref or ref in seen:
            continue
        seen.add(ref)
        path, _, line = str(ref).rpartition(":")
        if lib_doc and lib_lines and path == lib_doc and line.isdigit() and 0 < int(line) <= len(lib_lines):
            t = lib_lines[int(line) - 1].strip()
            if not t or t.startswith(("#", "- In the export:", "- Stands for", "|")):
                continue
        out.append(s)
    return out


def _weight(it):
    """The meanings one entry of a call asks for: the column's own (unless it is known) and one per keyword; never less than 1."""
    return max(1, (0 if it.get("meaning_known") else 1) + len(it.get("keywords") or []))


def _approved_meanings(level):
    """{column: (dictionary, row)} from the approved data dictionaries of this level (knowledge/dictionaries/*/<file>.current.json);
    the newest approval wins. Only rows with a meaning."""
    if not level:
        return {}
    found = []
    for p in glob.glob(os.path.join(knowledge_dir(), "dictionaries", "*", "*.current.json")):
        try:
            d = json.load(open(p, encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if isinstance(d, dict) and d.get("level") == level and d.get("approved_by"):
            found.append(d)
    out = {}
    for d in sorted(found, key=lambda d: d.get("approved_at") or 0):
        for c in d.get("columns") or []:
            if isinstance(c, dict) and c.get("column") and str(c.get("meaning") or "").strip():
                out[c["column"]] = (d, c)
    return out


def _reused_answer(column, known):
    d, c = known
    reused = {"file": d.get("file") or os.path.basename(str(d.get("path") or "")), "by": d.get("approved_by"), "on": _day(d.get("approved_at"))}
    kws = {}
    for k in c.get("keywords") or []:
        if isinstance(k, dict) and (k.get("value") or k.get("keyword")) and str(k.get("meaning") or "").strip():
            kws[k.get("value") or k.get("keyword")] = {"meaning": k["meaning"], "source": k.get("source") or {}, "checked": True, "why": "approved earlier",
                                                         "status": k.get("status") or "", "reused": reused}
    return {"column": column, "meaning": str(c["meaning"]).strip(), "source": c.get("source") or {}, "keyword_map": kws, "reused": reused}


def _plain_problem(why):
    """A failed model call in words (the same meanings as the Settings test)."""
    w = str(why)
    for pat, words in ((r"cut off", "the answer was longer than one call may write; the part is asked again in two halves"),
                       (r"HTTP 402", "HTTP 402: the account behind this key has no credit left or its budget is used up"),
                       (r"HTTP 401", "HTTP 401: the key was refused"), (r"HTTP 403", "HTTP 403: this key may not use this model or address"),
                       (r"HTTP 404|not_found_error|unrecognized_model|issue with the selected model", "the model name or the address was not found"),
                       (r"no API key", "no API key is saved (Settings -> Model connection)"), (r"HTTP 429|rate limit", "too many calls at the moment (HTTP 429)"),
                       (r"HTTP 5\d\d|overloaded", "the model service had a problem or is overloaded"),
                       (r"timed out|timeout|TimeoutExpired", "the call ran out of time"),
                       (r"refused|getaddrinfo|Name or service not known|unreachable|No route", "the address cannot be reached from this computer"),
                       (r"the run was stopped", "the run was stopped")):
        if re.search(pat, w, re.I):
            return words
    return w.strip()[:160] or "no model answered"


def _doc_meaning(it):
    """The last answer when the model gave none: the reference document's own words about the column, if a snippet was found
    for it (a real source); otherwise None, and the column stays without a meaning for the admin (owner, 2026-11-11: no text
    written by code)."""
    if not it.get("snippets"):
        return None
    s = it["snippets"][0]
    return {"column": it["column"], "meaning": s["quote"][:240], "source": {"kind": "document", "ref": s["ref"], "quote": s["quote"][:160]}, "keywords": []}


# The prompts name no tool of their own: {EXPORTED} and {KNOWLEDGE} are filled from the tool the file's header was recognised as
# (see _prompt_words), or in general words when no tool is recognised. They are filled with str.replace, never with %.
EXPLORE_INSTRUCTION = """You are the Data Explorer of one CSV file {EXPORTED}. You know ONLY the data: CONTEXT holds the
profile that code computed from EVERY row of the file (each column's number "n", its type, how many rows hold a value, how
many different values, its top values, and its special keywords: the WORDS the column holds, such as ACK, Link Up, Read,
Enabled; numbers are never keywords). The counts are exact: repeat them as they are, never estimate. Describe only what the
data holds. Do NOT say what a column or a keyword means: another agent (the Grounder) does that. For each column write "n"
(its number, as given; do not repeat its name) and "observed": one plain sentence of what the data holds (for example
"99,088 rows hold a value; keywords: ACK, UpdateFC-P, UpdateFC-NP, PM_Request_Ack"). When CONTEXT asks for a summary, write
"summary": 3 to 5 plain sentences for a reader who has never seen this file: what one row is (file_facts may name the
column that tells the kinds of row apart, with their counts), what the file records, how big it is, which columns carry
most of the information, which keywords stand out."""
EXPLORE_SHAPE = '{"summary": "... (only when asked)", "columns": [{"n": <the column\'s number in CONTEXT>, "observed": "..."}]}'
# a file with very many columns: what each column holds is said from the counts by code, and the model writes the summary only
EXPLORE_SUMMARY_INSTRUCTION = """You are the Data Explorer of one CSV file {EXPORTED}. You know ONLY the data. CONTEXT
holds what code counted from EVERY row of the file: file_facts (the rows, the columns, the keywords, and, when one column
tells the kinds of row apart, those kinds with their counts), column_names (the names of the columns that hold a value) and
columns (the profile of the columns that hold the most keywords). The counts are exact: repeat them as they are, never
estimate. Write "summary": 3 to 5 plain sentences for a reader who has never seen this file: what one row is, what the file
records, how big it is, which columns carry most of the information, which keywords stand out. Do NOT say what a column or
a keyword means: another agent (the Grounder) does that."""
EXPLORE_SUMMARY_COLUMNS = 40   # the columns with the most rows among those that hold keywords, shown to the model for the summary
EXPLORE_SUMMARY_NAMES = 500    # column names shown to the model for the summary at most

GROUND_INSTRUCTION = """You are the Data Grounder of one CSV file {EXPORTED}. CONTEXT gives each column with a number "n",
its name, the special keywords found in it and a summary of its contents that code computed from every row (what the Data
Explorer observed, its most common values with their counts, its smallest and largest value; never the rows themselves).
"filled_on", when a column has it, was counted by code on every row: the only kinds of row (the commands, the packet types,
the transaction types) that hold a value in this column. The column is then a field of exactly those kinds of row: give its
meaning for them and name them; never describe it as a field of every row. Find what each column and each keyword means,
and say where you found it.
Look in this order: (1) the snippets of the reference documents given in CONTEXT: kind "document", ref exactly as given,
quote copied from the snippet; (2) the web, when it is allowed (see THE WEB below): kind "web", ref = the page's address,
quote = words copied from the page; (3) the column's name and contents, read with {KNOWLEDGE}: when the contents decide
it, kind "data", quote = one value from its contents that shows it; otherwise kind "model" (allowed, and shown to the admin
as such). One short plain sentence per meaning: 25 words at most for a column, 15 at most for a keyword. Leave a meaning
empty only when neither documents, the web, the name nor the contents tell it: never invent.
An entry with "keywords_seen" gives the keywords found most often in that column, counted by code on every row, the most
frequent first (30 at most): use them to understand what the column is, and write no meaning for them (the keywords whose
meaning is wanted are asked under "keywords", in this call or in another one).
An entry with "meaning_known" already has its meaning: write no "meaning" for it, only its keywords, each read as a value
of that column. An entry with "held_by" is not a column: its keywords are words that many columns of this file hold
("held_by" says how many, and names some); give the meaning each has as a value of such columns.
THE FORM OF THE ANSWER: one entry per column, known by its number "n" (do not repeat its name). Each keyword is a short
list: the keyword exactly as given, its meaning, the kind; for document and web two more, the ref and the quote. Give
every keyword listed under a column. Write nothing that is not asked for: the answer is read by a program."""
GROUND_RETRY_NOTE = """

THE WEB COULD NOT BE USED for these columns (the first try gave no meaning for them): understand each column from its name
and the data it holds (its most common values with their counts, its smallest and largest value, its keywords, what the Explorer
observed, the kinds of row that fill it), read with {KNOWLEDGE}: kind "data" when the values decide it (quote one of them),
else "model"."""
GROUND_AGAIN_NOTE = """

ASKED AGAIN: the first answer left out the keywords of these entries. Give the meaning of every keyword listed, from the
snippets when one says it, else from the name of its column, the column's known meaning and its contents, read with
{KNOWLEDGE}: kind "data" when the contents decide it, else "model"."""
# the answer's form decides how long a call takes (owner, 2026-11-11: "proper structuring will help in producing the output"): the
# model writes the answer token by token, so nothing is asked twice. A column is named by its number, a keyword is a list and
# not an object with five field names, and "ref" and "quote" are left out where the code knows them (data: the column itself;
# model: none). For 20 columns with 15 keywords each that is about a third of the text of the long form.
GROUND_SHAPE = ('{"columns": [{"n": <the column\'s number in CONTEXT>, "meaning": "... (left out for an entry that has meaning_known)", "kind": "document|web|data|model", '
                '"ref": "<document: file:line as given; web: the address; leave out for data and model>", '
                '"quote": "<document, web: words copied exactly; data: one value of the column; leave out for model>", '
                '"keywords": [["<keyword as given>", "<its meaning>", "<kind>", "<ref: document and web only>", "<quote: document and web only>"]]}]}')
_KINDS = ("document", "web", "data", "model")


def _source(o, column, keyword=None):
    """Where one meaning comes from, read from the short form (kind, ref, quote beside the meaning) or the long one (a "source"
    object). What the code knows is filled in by the code: a "data" meaning points at its own column (and a keyword is its own
    value there); a "model" meaning has no reference and no quote."""
    src = o.get("source") if isinstance(o.get("source"), dict) else o
    kind = str(src.get("kind") or "model").strip().lower()
    if kind not in _KINDS:
        kind = "model"
    ref, quote = str(src.get("ref") or "").strip(), str(src.get("quote") or "").strip()
    if kind == "data":
        ref = column
        if keyword and not quote:
            quote = keyword
    elif kind == "model":
        ref, quote = "model knowledge", ""
    return {"kind": kind, "ref": ref, "quote": quote}


def _read_answers(ans, batch):
    """The model's answer to one call -> {column: {"column", "meaning", "source", "keywords": [{"keyword", "meaning", "source"}]}},
    for the entries of that call only and only those that say something: a column needs a meaning; an entry whose meaning is
    already known ("meaning_known": only its keywords were asked) needs at least one keyword meaning, and whatever meaning the
    model wrote for it is not read ("keywords_only": True). An entry is known by its name when the answer gives it (exactly,
    or without regard to capitals and spacing), else by its number n; a keyword by its name among the entry's own keywords.
    Both forms are read: the short one that is asked for and the long one (objects with a "source")."""
    by_name = {it["column"]: it for it in batch}
    by_norm = {}
    for it in batch:
        by_norm.setdefault(core.norm(it["column"]), it)
    rows = ans.get("columns") if isinstance(ans, dict) else None
    out = {}
    for a in rows if isinstance(rows, list) else []:
        if not isinstance(a, dict):
            continue
        name, it = a.get("column"), None
        if isinstance(name, str) and name.strip():
            it = by_name.get(name) or by_norm.get(core.norm(name))
        if it is None:
            try:
                n = int(a.get("n"))
                it = batch[n - 1] if 1 <= n <= len(batch) else None
            except (TypeError, ValueError, OverflowError):
                it = None
        if it is None or it["column"] in out:
            continue
        col, known = it["column"], bool(it.get("meaning_known"))
        meaning = "" if known else str(a.get("meaning") or "").strip()
        if not known and not meaning:
            continue
        mine = {core.norm(k): k for k in it.get("keywords") or []}
        kws, seen = [], set()
        for k in a.get("keywords") if isinstance(a.get("keywords"), list) else []:
            if isinstance(k, dict):
                word, said, o = k.get("keyword") or k.get("value"), k.get("meaning"), k
            elif isinstance(k, (list, tuple)) and len(k) >= 2:
                word, said = k[0], k[1]
                o = {"kind": k[2] if len(k) > 2 else "", "ref": k[3] if len(k) > 3 else "", "quote": k[4] if len(k) > 4 else ""}
            else:
                continue
            real = mine.get(core.norm(word))
            if real is None or real in seen or not str(said or "").strip():
                continue
            seen.add(real)
            kws.append({"keyword": real, "meaning": str(said).strip(), "source": _source(o, col, real)})
        if known and not kws:
            continue
        out[col] = {"column": col, "meaning": meaning, "source": {} if known else _source(a, col), "keywords": kws}
        if known:
            out[col]["keywords_only"] = True
    return out


def ground_parts(items, at_once, most=None, columns=None):
    """The entries cut into the Grounder's calls -> (parts, the most meanings one part holds). A column whose meaning is asked
    counts 1 and each keyword 1 (see _weight). The work is cut into as many parts as calls may run at the same time, so that
    one round of calls finishes it; a part never holds more than `most` meanings (GROUND_MEANINGS: the model may write 16,000
    tokens in one call, and a longer answer is cut off) or `columns` entries (GROUND_BATCH when no number is given; the
    Grounder gives GROUND_BATCH_KNOWN), and not fewer than GROUND_MEANINGS_LEAST when there is that much. An entry is never cut
    in two, so with 20 keywords per column a part of 150 holds 7 columns. Columns filled on the same kinds of row stay
    together: a new part starts where the kind changes, once the part is half full."""
    most = GROUND_MEANINGS if most is None else most
    columns = GROUND_BATCH if columns is None else columns
    total = sum(_weight(it) for it in items)
    per = max(GROUND_MEANINGS_LEAST, min(most, -(-total // max(1, int(at_once or 1)))))
    parts, cur, w = [], [], 0
    for it in items:
        wi = _weight(it)
        other = bool(cur) and it.get("group") != cur[-1].get("group") and 2 * w >= per
        if cur and (len(cur) >= columns or w + wi > per or other):
            parts.append(cur)
            cur, w = [], 0
        cur.append(it)
        w += wi
    if cur:
        parts.append(cur)
    return parts, per


KEYWORDS_APART = "asked in another call at the same time: read each keyword below as a value of this column, from the column's name and contents"


def column_parts(items, least=None):
    """The columns that have no meaning yet, cut into the Grounder's calls -> parts. Every call holds at least `least` columns
    (GROUND_BATCH, the owner's 40) whenever that many are open and fewer than twice as many, so 2,000 open columns are 50
    calls. Such a call asks one meaning per column (the answer stays far below what one call may write) and gives each column
    with its most frequent keywords; the order of the columns is kept, so columns that the same kinds of row fill stay together."""
    least = max(1, int(GROUND_BATCH if least is None else least))
    n = len(items)
    if not n:
        return []
    k = max(1, n // least)
    size, more = divmod(n, k)
    parts, at = [], 0
    for i in range(k):
        step = size + (1 if i < more else 0)
        parts.append(items[at:at + step])
        at += step
    return parts


def _for_model(n, it):
    """An entry as the Grounder's model gets it: its number in this call and only what holds something. A column has its type
    and the summary of its contents; a column whose meaning is known says so; an entry of words that many columns hold
    ("shared") has neither type nor contents, only how many columns hold each word."""
    if it.get("shared"):
        out = {"n": n, "column": it["column"], "meaning_known": it.get("meaning_known") or "", "keywords": it.get("keywords") or [],
               "held_by": it.get("held_by") or {}}
    else:
        out = {"n": n, "column": it["column"], "type": it.get("type") or "", "keywords": it.get("keywords") or [], "contents": it.get("contents") or {}}
        if "keywords_seen" in it:     # only the column's meaning is asked: its most frequent keywords are given to understand it
            out["keywords_seen"] = it["keywords_seen"]
            if not out["keywords"]:
                del out["keywords"]
        if it.get("meaning_known"):
            out["meaning_known"] = it["meaning_known"]
        if it.get("header_cell") and it["header_cell"] != it["column"]:
            out["header_cell"] = it["header_cell"]
        if it.get("filled_on"):
            out["filled_on"] = it["filled_on"]
    if it.get("snippets"):
        out["snippets"] = it["snippets"]
    return out


# ---------------------------------------------------------------------------------------------- the run
def file_steps(f):
    """The sub-family of one CSV file: its Data Explorer, its Data Grounder and its Manager (f: one entry of inventory())."""
    n = f["name"]
    return [
        {"key": "explore:" + n, "title": "Data Explorer: every row and column of %s (the data)" % n, "family": "1", "agent": "Data Explorer", "input": {"file": f}},
        {"key": "ground:" + n, "title": "Data Grounder: what the columns and keywords of %s mean" % n, "family": "1", "agent": "Data Grounder", "input": {"file": f}},
        {"key": "manager:" + n, "title": "Manager: the data dictionary of %s, for your review" % n, "family": "1", "agent": "Manager", "review": True, "input": {"file": f}},
    ]


def steps(params, project):
    files = inventory(project.get("folder"))
    out = [{"key": "director", "title": "Director: list the CSVs of the folder and what each one is", "family": "1", "agent": "Director"}]
    for f in files:
        out += file_steps(f)
    return out


def refs_of(ctx, tool=None):
    """The reference documents of a run: the project's own folders and, when the file's header was recognised as one tool's
    export, the folder of that tool's reference document in the application's reference library (only that tool's: the
    document of another tool says nothing about this file)."""
    p = ctx.project
    folders = [x for x in (core.jload(p.get("refs"), []) or []) if x]
    doc = (CK.library().tools.get(tool) or {}).get("document") if tool else ""
    if doc and os.path.exists(doc) and os.path.dirname(doc) not in folders:
        folders.append(os.path.dirname(doc))
    return core.References(folders, os.path.join(ctx.engine.runner.sandbox_root, "_pdf_cache"))


def run_step(ctx):
    key = ctx.step["key"]
    if key == "director":
        files = inventory(ctx.project.get("folder"))
        if not files:
            raise RuntimeError("no CSV file in the folder %s" % ctx.project.get("folder"))
        problem = input_problem(files)       # any CSV files are read; whether they can be built into the tree is asked after Family 1
        if problem:
            raise RuntimeError(problem)
        return core.Result({"files": files, "references": core.jload(ctx.project.get("refs"), [])})
    kind, _, name = key.partition(":")
    f = ctx.input["file"]
    if kind == "explore":
        return _explore(ctx, f)
    if kind == "ground":
        return _ground(ctx, f)
    if kind == "manager":
        return _manager(ctx, f)
    raise RuntimeError("unknown step %s" % key)


def _slim(c, k=25):
    """A column as the Explorer's model sees it: the counts, the top values and up to k keywords."""
    return {key: c[key] for key in ("column", "type", "rows_with_value", "filled_pct", "distinct", "distinct_more_than_counted", "min", "max") if key in c} | {
        "top_values": [{"value": t["value"], "count": t["count"]} for t in c["top_values"][:6]],
        "keywords": [t["value"] for t in (c.get("keywords") or [])[:k]]}


def _profile(path, level, progress=None, share=(0.0, 100.0)):
    """The profile of one file. A large file is read on every core of the computer (agentic/profile_parallel.py: the same
    result as full_profile; it goes back to one core by itself for a small file or when a worker cannot be started)."""
    try:
        from . import profile_parallel as PP            # imported here: that module imports this one
    except Exception as e:      # noqa: BLE001  (never a reason to fail the step: one core reads the same)
        sys.stderr.write("family1: %s is read on one core: profile_parallel could not be loaded (%s)\n" % (os.path.basename(str(path)), e))
        return full_profile(path, level, progress=progress, share=share)
    return PP.full_profile_parallel(path, level, progress=progress, share=share)


def _explore(ctx, f):
    ctx.progress("Data Explorer: reading every row of %s by code" % f["name"])
    prof = _profile(f["path"], f["level"], progress=lambda t: ctx.progress(t + " · Data Explorer"), share=(0.0, 70.0))      # reading is the first 70% of this step
    runner = ctx.engine.runner
    box = runner.sandbox(ctx.run["id"], "explorer_" + f["name"])
    tool = exported_by(prof["columns"], _declared_tool(ctx))        # the tool chosen on the start page, else by the header alone (none assumed)
    prof["exported_by"] = tool
    exported = _prompt_words(tool)[0]
    instruction = EXPLORE_INSTRUCTION.replace("{EXPORTED}", exported)
    filled = [c for c in prof["columns"] if c["rows_with_value"]]
    head = {k: prof[k] for k in ("rows", "level_label", "columns_in_file", "columns_with_values", "keyword_columns", "keywords")}
    if prof.get("kind_of_row"):
        head["kind_of_row"] = prof["kind_of_row"]["text"]
    # (owner, 2026-11-11: "do the requests simultaneously") the columns are cut into as many parts as model calls run at the same
    # time, each of EXPLORE_LEAST to BATCH columns, and the parts are asked together; before, one part of 120 after the other.
    # (owner, 2026-11-12: about 2,000 columns in some exports) above EXPLORE_BY_CODE_ABOVE columns the model is not asked to
    # repeat the counts of every column: what each column holds is said from the counts by code (a measurement, not a meaning),
    # and one call writes the summary of the file.
    by_code = len(filled) > EXPLORE_BY_CODE_ABOVE
    at_once = runner.calls_at_once()
    size = max(EXPLORE_LEAST, min(BATCH, -(-len(filled) // max(1, at_once))))
    parts = [[]] if by_code else [filled[i:i + size] for i in range(0, max(1, len(filled)), size)]
    observed, producers, lock, state, t0 = {}, set(), threading.Lock(), {"done": 0, "summary": ""}, time.time()

    def say():
        if by_code:
            what = "what each of the %d columns that hold a value holds is said from the counts; the model writes the summary of the file" % len(filled)
        else:
            what = "the model describes the %d columns that hold a value: %d of %d part%s done, up to %d calls at the same time" % (
                len(filled), state["done"], len(parts), "" if len(parts) == 1 else "s", runner.slots.limit)
        ctx.progress("%d%% · %s: all %s lines read · %s · %s so far · Data Explorer" % (
            70 + 29 * state["done"] // len(parts), f["name"], _n(prof["rows"]), what, core.fmt_secs(time.time() - t0)))

    def summary_only():
        names = [c["column"] for c in filled if not CK.is_separator(c["column"])]
        busy = sorted([c for c in filled if c.get("keywords")], key=lambda c: -c["rows_with_value"])[:EXPLORE_SUMMARY_COLUMNS]
        context = {"file": f["name"], "file_facts": head, "column_names": names[:EXPLORE_SUMMARY_NAMES], "columns": [_slim(c, 12) for c in busy]}
        if len(names) > EXPLORE_SUMMARY_NAMES:
            context["column_names_not_shown"] = len(names) - EXPLORE_SUMMARY_NAMES
        ans, producer, _ = runner.ask(ctx.run["id"], "explorer_%s" % f["name"], EXPLORE_SUMMARY_INSTRUCTION.replace("{EXPORTED}", exported), context,
                                      '{"summary": "..."}', "summary", lambda: {"summary": _standin_explore(prof, [], True)["summary"]})
        with lock:
            producers.add("%s; what each column holds: counted by code" % producer)
            state["done"] += 1
            state["summary"] = str(ans.get("summary") or "").strip()
        say()

    def one(k_batch):
        k, batch = k_batch
        want = k == 0                           # the summary of the file is asked once, with the first part
        ans, producer, _ = runner.ask(ctx.run["id"], "explorer_%s%s" % (f["name"], "" if k == 0 else "_part%d" % (k + 1)), instruction,
                                      {"file": f["name"], "file_facts": head, "write_summary": want, "columns": [dict(_slim(c), n=i + 1) for i, c in enumerate(batch)]},
                                      EXPLORE_SHAPE, "columns", lambda: _standin_explore(prof, batch, want))
        by_name, got = {c["column"]: c for c in batch}, {}
        for a in ans.get("columns") if isinstance(ans.get("columns"), list) else []:
            if not isinstance(a, dict):
                continue
            c = by_name.get(a.get("column")) if isinstance(a.get("column"), str) else None
            if c is None:
                try:
                    n = int(a.get("n"))
                    c = batch[n - 1] if 1 <= n <= len(batch) else None
                except (TypeError, ValueError, OverflowError):
                    c = None
            if c is not None:
                got[c["column"]] = str(a.get("observed") or "")[:400]
        with lock:
            observed.update(got)
            producers.add(producer)
            state["done"] += 1
            if want:
                state["summary"] = str(ans.get("summary") or "").strip()
        say()

    say()
    stop = threading.Event()

    def tick():                                 # the line moves while a call is out (owner: "while running, please show status")
        while not stop.wait(10):
            say()

    threading.Thread(target=tick, daemon=True).start()
    try:
        if by_code:
            summary_only()
        else:
            with ThreadPoolExecutor(max_workers=max(1, min(len(parts), runner.CALLS_MOST))) as pool:
                list(pool.map(one, list(enumerate(parts))))
    finally:
        stop.set()
    summary = state["summary"] or _standin_explore(prof, [], True)["summary"]
    for c in prof["columns"]:
        c["observed"] = observed.get(c["column"]) or (_standin_explore(prof, [c], False)["columns"][0]["observed"] if c["rows_with_value"] else "no row holds a value")
    memory = dict(prof, summary=summary, made=time.time(), agent="Data Explorer")
    path = os.path.join(box, "memory.json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(memory, fh, indent=1)
    return core.Result({"memory_file": path, "rows": prof["rows"], "columns_with_values": prof["columns_with_values"], "columns_in_file": prof["columns_in_file"],
                        "keywords": prof["keywords"], "seconds_reading": prof["seconds"], "summary": summary,
                        "kind_of_row": (prof.get("kind_of_row") or {}).get("text", ""), "columns_with_special_status": prof.get("columns_with_special_status", 0),
                        "exported_by": tool.get("name") or "", "model_parts": len(parts), "seconds_model": round(time.time() - t0, 1)},
                       producer=", ".join(sorted(producers)))


def _terms(column, keywords):
    terms = [column]
    leaf = column.partition(".")[2]
    if leaf:
        terms.append(leaf)
    terms += [k for k in keywords[:3] if 2 <= len(k) <= 40]
    return list(dict.fromkeys(t for t in terms if t))


def _ground(ctx, f):
    """What every column that holds a value means, and what its keywords mean, each with its source. A meaning is looked for in
    this order and the first place that has it wins (owner, 2026-11-12: "if once the column name has been done, it's done ...
    match the already stored content ... not every time by web search"):
      1. a data dictionary of this level that the admin approved, or a remembered meaning that the admin approved;
      2. the reference document of the tool that exported the file (reference_library), when its quote is found there now;
      3. what an earlier run understood (knowledge/column_meanings), when the name, the kind of values and a keyword still fit;
      4. what the model knew when the reference document was prepared (shown as such);
      5. the model: the documents' lines, the web when allowed, then the name and the contents.
    Only what is still open after 1-4 goes to the model, in calls of up to GROUND_BATCH columns and GROUND_MEANINGS meanings
    that run at the same time; a keyword that many columns hold is asked once for all of them. A meaning is never written by
    code, and what the model answers is kept for the next run."""
    ex = ctx.output_of("explore:" + f["name"])
    with open(ex["memory_file"], encoding="utf-8") as fh:
        mem = json.load(fh)
    runner = ctx.engine.runner
    web_ok = runner.can_search_web()
    t0, head = time.time(), "Data Grounder · %s: " % f["name"]
    all_cols = [c for c in mem.get("columns") or [] if isinstance(c, dict) and c.get("column")]
    filled = [c for c in all_cols if c.get("rows_with_value")]
    level = f.get("level")
    tool = exported_by(all_cols, _declared_tool(ctx))
    key, lib = tool["tool"], CK.library()
    refs = refs_of(ctx, key)
    lib_doc = lib.tools[key]["document"] if key else ""
    exported, knowledge = _prompt_words(tool)

    def worded(text):
        return text.replace("{EXPORTED}", exported).replace("{KNOWLEDGE}", knowledge)
    instruction, retry_note, again_note = worded(GROUND_INSTRUCTION), worded(GROUND_RETRY_NOTE), worded(GROUND_AGAIN_NOTE)
    web_note = _web_note(tool)
    store = CK.Store(os.path.join(knowledge_dir(), "column_meanings"), key)
    names = {c["column"] for c in all_cols}

    def scope_of(name):
        """Under which name a column's meaning is remembered: the level for a recognised tool (the same name is the same field in
        every recording of that level), the file's own format for anything else; None when there is neither (nothing is kept)."""
        if key and level and not CK.is_separator(name) and not re.search(r"#\d+$", name) and (name + "#2") not in names:
            return level
        return f.get("format_key") or None

    # ---- 1-4: what is already known, without a call
    approved = _approved_meanings(level)
    before = CK.previous_names(all_cols)
    seen_values = {c["column"]: _column_values(c) for c in filled}      # a "data" quote must be one of the column's own values
    meanings, kept_kw, scopes = {}, {}, {}
    a_cols, b_cols = [], []           # (column, keywords to ask): no meaning yet / meaning known, keywords open
    counts = {"approved": 0, "library": 0, "library_model": 0, "stored": 0}
    said = 0.0
    for i, c in enumerate(filled):
        if time.time() - said >= 1:
            said = time.time()
            ctx.progress("0%% · %staking what is already known (approved dictionaries, the reference document, earlier runs): column %d of %d · %s so far" % (
                head, i + 1, len(filled), core.fmt_secs(time.time() - t0)))
        name = c["column"]
        all_kw = list(dict.fromkeys(str(k["value"]) for k in (c.get("keywords") or []) if isinstance(k, dict) and k.get("value") not in (None, "")))
        kw_set, words, sc = set(all_kw), all_kw[:GROUND_KEYWORDS], scope_of(name)
        if sc:
            scopes[name] = sc
        entry, lib_model = None, None
        if name in approved:
            a = _reused_answer(name, approved[name])
            entry = {"meaning": a["meaning"], "source": a.get("source") or {}, "checked": True, "why": "approved earlier",
                     "reused": a["reused"], "keywords": a.get("keyword_map") or {}}
            counts["approved"] += 1
        else:
            st = store.match(sc, name, c.get("type"), words) if sc else None
            if st and st.get("approved"):
                entry = _stored_answer(st)
                counts["approved"] += 1
            if entry is None and key:
                e, how = lib.lookup(key, level, name, before.get(name))
                if e and e.get("kind") == "document":
                    a = lib.answer(key, e, name, how)
                    cl = core.check_claims([{"text": name, "source": a["source"]}], refs=refs)[0]
                    if cl["verified"] and str(a.get("meaning") or "").strip():      # the quote is in the document as it is on this computer now
                        entry = {"meaning": a["meaning"], "source": cl["source"], "checked": True, "why": cl["why"], "library": a["library"], "keywords": {}}
                        counts["library"] += 1
                elif e and e.get("kind") == "model":
                    lib_model = lib.answer(key, e, name, how)
            if entry is None and st:
                entry = _stored_answer(st)
                counts["stored"] += 1
            if entry is None and lib_model and str(lib_model.get("meaning") or "").strip():
                entry = {"meaning": lib_model["meaning"], "source": lib_model["source"], "checked": False,
                         "why": "no source that the program can check (model)", "library": lib_model["library"], "keywords": {}}
                counts["library_model"] += 1
        kws = {kw: _kept_keyword(m) for kw, m in store.keywords(sc, name).items() if kw in kw_set} if sc else {}
        if entry is not None:
            kws.update(entry.get("keywords") or {})         # what the approved dictionary says of a keyword wins
            entry["keywords"] = kws
        missing = [w for w in words if w not in kws]
        if entry is not None:
            meanings[name] = entry
            if missing:
                b_cols.append((c, missing))
        else:
            a_cols.append((c, missing))
            kept_kw[name] = kws

    def item(c, missing, known=None):
        ff = c.get("filled_for") or {}
        it = {"column": c["column"], "header_cell": c.get("header_cell"), "type": c.get("type") or "", "keywords": list(missing), "snippets": [],
              "contents": _contents(c), "filled_on": ff.get("text") or "", "group": ff.get("rows") or ""}
        if known:
            it["meaning_known"] = known
        return it
    def frequent(c):                  # the keywords found most often in the column, the most frequent first (the Explorer counted them)
        return list(dict.fromkeys(str(k["value"]) for k in (c.get("keywords") or [])
                                  if isinstance(k, dict) and k.get("value") not in (None, "")))[:GROUND_KEYWORDS_SHOWN]
    # a column without a meaning: one call asks its meaning, with at least 40 such columns and the 30 most frequent keywords of
    # each (owner, 2026-11-12); the meanings of its keywords are asked apart, at the same time, so no answer grows too long
    a_items = [dict(item(c, []), keywords_seen=frequent(c)) for c, _missing in a_cols]
    b_items = [item(c, missing, meanings[c["column"]]["meaning"]) for c, missing in b_cols]
    b_items += [dict(item(c, missing, KEYWORDS_APART), apart=True) for c, missing in a_cols if missing]
    apart = {it["column"] for it in b_items if it.get("apart")}

    # ---- a keyword that many columns hold (Supported, Enabled, Reserved ...) is asked once, not once per column
    need = {}
    for it in a_items + b_items:
        for kw in it["keywords"]:
            need.setdefault(kw, []).append(it["column"])
    shared = {kw: cols for kw, cols in need.items() if len(cols) >= SHARED_KEYWORD_COLUMNS}
    pseudo = {}                       # the name of such a question -> the question
    if shared:
        for it in a_items + b_items:
            it["keywords"] = [kw for kw in it["keywords"] if kw not in shared]
        b_items = [it for it in b_items if it["keywords"]]
        ordered = sorted(shared, key=lambda kw: (-len(shared[kw]), kw))
        for n in range(0, len(ordered), SHARED_KEYWORDS_PER_ITEM):
            chunk = ordered[n:n + SHARED_KEYWORDS_PER_ITEM]
            pname = "words that many columns hold (%d)" % (len(pseudo) + 1)
            while pname in names:
                pname += "*"
            pseudo[pname] = {"column": pname, "shared": True, "type": "", "keywords": chunk, "snippets": [], "contents": {}, "filled_on": "", "group": "~shared",
                             "meaning_known": "not a column: each keyword below is a word that many columns of this file hold",
                             "held_by": {kw: "%d columns, such as %s" % (len(shared[kw]), ", ".join(shared[kw][:3])) for kw in chunk}}

    # ---- the documents' lines, only for what goes to the model
    if refs.folders and (a_items or b_items or pseudo):
        lib_lines = refs.docs().get(lib_doc) if lib_doc else None
        todo, said = a_items + b_items + list(pseudo.values()), 0.0
        for i, it in enumerate(todo):
            if time.time() - said >= 1:   # the first look-up reads the documents: the line says what is going on
                said = time.time()
                ctx.progress("0%% · %slooking up the reference documents for column %d of %d · %s so far" % (head, i + 1, len(todo), core.fmt_secs(time.time() - t0)))
            snips = []
            if it.get("meaning_known"):   # only the keywords are open: one line for each of a few of them
                for w in [w for w in it["keywords"] if 2 <= len(w) <= 40][:len(it["keywords"]) if it.get("shared") else 3]:
                    snips += _useful_snippets(refs.search(w, limit=3), lib_doc, lib_lines)[:1]
                it["snippets"] = _useful_snippets(snips)
            else:
                for t in _terms(it["column"], it.get("keywords_seen") or it["keywords"]):
                    snips += _useful_snippets(refs.search(t, limit=4), lib_doc, lib_lines)[:2]
                it["snippets"] = _useful_snippets(snips)[:4]
    t_refs = time.time() - t0

    # ---- the calls: the columns that the same kinds of row fill go together; every part is asked at once and the runner's
    # places (AgentRunner.slots) decide how many are at the model (owner: "allot all the cores")
    def by_group(items):
        order = {}
        for it in items:
            order.setdefault(it["group"], len(order))
        return sorted(items, key=lambda it: order[it["group"]])
    a_items = by_group(a_items)
    b_list = list(pseudo.values()) + by_group(b_items)
    at_once = runner.calls_at_once()
    a_parts = column_parts(a_items)
    a_per = max([len(p) for p in a_parts] or [0])
    b_parts, b_per = ground_parts(b_list, at_once, most=GROUND_MEANINGS, columns=GROUND_BATCH_KNOWN) if b_list else ([], 0)
    parts = [(p, True) for p in a_parts] + [(p, False) for p in b_parts]
    per = max(a_per, b_per) or GROUND_MEANINGS_LEAST
    known_done = len(filled) - len(a_items) - sum(1 for it in b_items if not it.get("apart"))
    total_work = sum(_weight(it) for p, _new in parts for it in p)
    asked_keywords = sum(len(it["keywords"]) for p, _new in parts for it in p)
    state = {"done": 0, "cols": 0, "meant": 0, "work": 0, "retries": 0, "again": 0, "problem": "", "fatal": "", "secs": [], "most": 0}
    lock, stop = threading.Lock(), threading.Event()
    at_model = {}                     # part number -> [since, what it is doing, True once it has its place among the calls]
    collected = []                    # (answers, who answered, columns left without a meaning, True for a part of new columns)
    # the effort level is said to Claude Code only (AgentRunner.ask passes it to no other path); a call with a level, like one
    # with the web, may take twice the runner's time before it gives up
    effort = ground_effort() if runner.path_now() == "claude-code" else None
    limit = runner.timeout * (2 if web_ok or effort else 1)
    kind_text = (mem.get("kind_of_row") or {}).get("text") or ""

    def say(after="", final=False):
        with lock:
            done, cols, meant, work, retries, again, problem = (state[k] for k in ("done", "cols", "meant", "work", "retries", "again", "problem"))
            secs = list(state["secs"])
            # a call that just gave its place back is still listed here for a moment: the runner's own count of the places
            # taken is the upper bound, so the number shown is never above the calls really running
            there = min(sum(1 for c in at_model.values() if c[2]), runner.slots.active)
            waits = [(time.time() - c[0], k, c[1]) for k, c in at_model.items() if c[2]]
        if waits:                     # the part that has waited longest; of parts that started together, the first one
            longest = max(w for w, _k, _what in waits)
            waits = sorted((x for x in waits if x[0] >= longest - 2), key=lambda x: x[1])
        bits = ["%d of %d columns done, %d with a meaning" % (known_done + cols, len(filled), len(meanings) + meant)]
        if counts["approved"]:
            bits.append("%d taken from the approved dictionary" % counts["approved"])
        if counts["library"]:
            bits.append("%d from the reference document of %s" % (counts["library"], tool["name"]))
        if counts["library_model"]:
            bits.append("%d from the model's knowledge when that document was prepared" % counts["library_model"])
        if counts["stored"]:
            bits.append("%d understood in an earlier run" % counts["stored"])
        if shared:
            bits.append("%d keyword%s that many columns hold asked once" % (len(shared), "" if len(shared) == 1 else "s"))
        if parts:
            left, now = len(parts) - done, runner.slots.limit
            bits.append("%d part%s of at most %d meanings: %d done, %d at the model now, %d waiting for a free call" % (
                len(parts), "" if len(parts) == 1 else "s", per, done, there, max(0, left - there)))
            if runner.slots.refused:
                bits.append("the model service said 'too many calls' %d time%s, so now up to %d calls at the same time" % (
                    runner.slots.refused, "" if runner.slots.refused == 1 else "s", now))
            else:
                bits.append("up to %d calls at the same time, at most %d started in one second" % (now, runner.slots.per_second))
            if secs and left > 0:
                avg = sum(secs) / len(secs)
                bits.append("a call takes about %s; about %s left" % (core.fmt_secs(max(1, avg)), core.fmt_secs(max(1, avg * -(-left // max(1, now))))))
        if retries:
            bits.append("%d part%s retried without the web" % (retries, "" if retries == 1 else "s"))
        if again:
            bits.append("%d part%s asked again" % (again, "" if again == 1 else "s"))
        if waits and waits[0][0] >= GROUND_SLOW_AFTER:
            w, k, what = waits[0]
            bits.append("part %d has waited %s for the model (%s); a call gives up after %s and is then tried again" % (k, core.fmt_secs(w), what, core.fmt_secs(limit)))
        if problem:
            bits.append("last problem: " + problem)
        if after:
            bits.append(after)
        pct = 100 if final else min(99, 100 * work // max(1, total_work))        # 100% only when the checks after the answers are done too
        ctx.progress("%d%% · %s%s · %s so far" % (pct, head, " · ".join(bits), core.fmt_secs(time.time() - t0)))

    def tick():
        while not stop.wait(10):
            say()

    def ask(batch, name, web, note="", k=0, what=""):
        """One call -> (the meanings it gave, who answered, the reason when it failed). The stand-in gives nothing here, so a failed
        call is seen as columns without a meaning and is retried. Its time at the model and, when it fails, the reason in words go to
        the status; a refused connection (no credit, key refused, model not found) stops the asking at once."""
        if state["fatal"]:
            return {}, "not asked: " + state["fatal"], ""
        with lock:
            at_model[k] = [time.time(), what, False]

        def started():                # the call has its place: from here it is at the model
            with lock:
                if k in at_model:
                    at_model[k][0], at_model[k][2] = time.time(), True
                state["most"] = max(state["most"], min(sum(1 for c in at_model.values() if c[2]), runner.slots.active))
        context = {"file": f["name"], "level": f.get("level_label"), "columns": [_for_model(i + 1, it) for i, it in enumerate(batch)]}
        if kind_text:
            context["kind_of_row"] = kind_text
        try:
            ans, producer, _ = runner.ask(ctx.run["id"], name, instruction + note, context, GROUND_SHAPE, "columns", lambda: {"columns": []},
                                          web=web, effort=effort, on_start=started, web_note=web_note)
        finally:
            with lock:
                was = at_model.pop(k, None)
                if was and was[2]:
                    state["secs"].append(time.time() - was[0])
        got, why = _read_answers(ans, batch), ""
        if producer.startswith("stand-in"):
            why = producer.split("(after:", 1)[1].rstrip(") ") if "(after:" in producer else "no model answered"
            plain = _plain_problem(why)
            with lock:
                state["problem"] = "part %d: %s" % (k, plain)
                if re.search(r"HTTP 40[1-4]|no API key|unrecognized_model|not_found_error|model .*not found|issue with the selected model", why, re.I):
                    state["fatal"] = plain
            say()
        return got, producer, why

    def halves(seq):
        half = -(-len(seq) // 2)
        return [p for p in (seq[:half], seq[half:]) if p]

    def one(k, batch, is_new):
        name = "grounder_%s_part%d" % (f["name"], k + 1)
        got, used, left = {}, [], 0
        try:
            first = ("first try: documents%s, the names and data" % (", the web" if web_ok else "")) if is_new else "the keywords of columns whose meaning is known"
            more, producer, why = ask(batch, name, web_ok and is_new, "", k + 1, first)
            got.update(more)
            used.append(producer)
            if "cut off" in why and not state["fatal"]:     # the answer was longer than one call may write: the same question in two halves
                for j, part in enumerate(halves(batch)):
                    more, producer, _why = ask(part, "%s_half%d" % (name, j + 1), web_ok and is_new, "", k + 1, "the first answer was too long: asked again in two halves")
                    got.update(more)
                    used.append(producer + " (asked in two halves: the first answer was cut off)")
            missing = [c for c in batch if c["column"] not in got]
            if is_new:
                if missing and not state["fatal"]:   # retry 1 (owner, 2026-11-11): without the web, from each column's name and contents
                    with lock:
                        state["retries"] += 1
                    more, producer, _why = ask(missing, name + "_retry", False, retry_note, k + 1, "retry without the web, from the names and data")
                    got.update(more)
                    used.append(producer + " (retry without the web)")
                    missing = [c for c in batch if c["column"] not in got]
                if len(missing) > 1 and not state["fatal"]:      # retry 2: the same, in two smaller halves
                    for j, part in enumerate(halves(missing)):
                        more, producer, _why = ask(part, "%s_retry%d" % (name, j + 2), False, retry_note, k + 1, "retry in smaller halves")
                        got.update(more)
                        used.append(producer + " (retry in halves)")
                    missing = [c for c in batch if c["column"] not in got]
                if missing:               # last: a reference document's snippet, if one was found for it; never a text written by code
                    for c in missing:     # (owner, 2026-11-11: "it should not be written"): without a source the column stays without a meaning
                        m = _doc_meaning(c)
                        if m:
                            got[c["column"]] = m
                    left = len([c for c in batch if c["column"] not in got])
                    if left:
                        used.append("%d column%s without a meaning after 3 tries" % (left, "" if left == 1 else "s"))
            elif missing and not state["fatal"]:     # keywords only: the entries with no answer are asked once more, then left open
                with lock:
                    state["again"] += 1
                more, producer, why = ask(missing, name + "_again", False, again_note, k + 1, "asked again for the keywords that got no answer")
                got.update(more)
                used.append(producer + " (asked again)")
                if "cut off" in why and len(missing) > 1 and not state["fatal"]:
                    for j, part in enumerate(halves(missing)):
                        more, producer, _why = ask(part, "%s_again%d" % (name, j + 2), False, again_note, k + 1, "asked again in smaller halves")
                        got.update(more)
                        used.append(producer + " (asked again in halves)")
        finally:                      # whatever this part got is kept, also when a later call of it failed
            with lock:
                collected.append((list(got.values()), "; ".join(dict.fromkeys(u for u in used if u)), left, is_new))
                state["done"] += 1
                state["cols"] += sum(1 for it in batch if not it.get("shared") and not it.get("apart"))
                state["work"] += sum(_weight(it) for it in batch)
                if is_new:
                    state["meant"] += len(got)
    answers, producers, failure = [], set(), None
    if parts:
        say()
        ticker = threading.Thread(target=tick, daemon=True)
        ticker.start()
        try:
            with ThreadPoolExecutor(max_workers=max(1, min(len(parts), runner.CALLS_MOST))) as pool:
                futures = [pool.submit(one, k, batch, is_new) for k, (batch, is_new) in enumerate(parts)]
                for fu in as_completed(futures):
                    try:
                        fu.result()
                    except Exception as e:      # one part failed: the others go on and what they bring is kept; the first failure is raised after them
                        failure = failure or e
                    say()                       # the line moves with every part that comes back, besides every 10 s
        finally:
            stop.set()
    without = 0
    for got, producer, left, _new in collected:
        without += left
        for bit in producer.split("; "):        # every way a part was answered, said once (not once per part)
            if bit and not re.match(r"\d+ columns? without a meaning", bit):
                producers.add(bit)
        answers += got
    if without:
        producers.add("%d column%s without a meaning after 3 tries" % (without, "" if without == 1 else "s"))
    if counts["approved"]:
        producers.add("%d meaning%s reused from the approved dictionary" % (counts["approved"], "" if counts["approved"] == 1 else "s"))
    if counts["library"]:
        producers.add("%d meaning%s taken from the reference document of %s" % (counts["library"], "" if counts["library"] == 1 else "s", tool["name"]))
    if counts["library_model"]:
        producers.add("%d meaning%s from the model's knowledge when that reference document was prepared" % (
            counts["library_model"], "" if counts["library_model"] == 1 else "s"))
    if counts["stored"]:
        producers.add("%d meaning%s kept from an earlier run" % (counts["stored"], "" if counts["stored"] == 1 else "s"))

    def build(web):
        """Every column's entry from what was known and what the calls answered, each source checked by the program ->
        (columns, the claims of the model's column meanings, the columns the model answered now, their keywords answered now)."""
        out = {col: dict(m, keywords=dict(m.get("keywords") or {})) for col, m in meanings.items()}
        claims, fresh_cols, fresh_kws, late = [], set(), {}, []

        def check(text, src, values=True):
            return core.check_claims([{"text": text, "source": src or {}}], refs=refs, web=web, data_values=seen_values if values else None)[0]

        def blank(col):
            return {"meaning": "", "source": {}, "checked": False, "why": "", "keywords": dict(kept_kw.get(col) or {})}
        # the columns' own meanings first: the keywords of a column that was asked apart are then added to its entry, whichever
        # of the two calls came back first
        for a in [x for x in answers if not x.get("keywords_only")] + [x for x in answers if x.get("keywords_only")]:
            col = a.get("column")
            if not col:
                continue
            if col in pseudo:                   # the words that many columns hold: after the columns' own answers
                late.append(a)
                continue
            if a.get("keywords_only"):          # the meaning was known or asked in another call: only its keywords were asked
                entry = out.get(col)
                if entry is None and col in apart:      # the column itself got no meaning: its keywords are kept all the same
                    entry = out[col] = blank(col)
                if entry is None:
                    continue
            else:
                cl = check(col, a.get("source"))
                entry = {"meaning": str(a.get("meaning") or "").strip(), "source": cl["source"], "checked": cl["verified"], "why": cl["why"],
                         "keywords": dict(kept_kw.get(col) or {})}
                out[col] = entry
                fresh_cols.add(col)
                if entry["meaning"]:
                    claims.append(cl)
            for k in a.get("keywords") or []:
                kw = k.get("keyword")
                if not kw or not str(k.get("meaning") or "").strip():
                    continue
                kc = check("%s = %s" % (col, kw), k.get("source"))
                entry["keywords"][kw] = {"meaning": str(k["meaning"]).strip(), "source": kc["source"], "checked": kc["verified"], "why": kc["why"]}
                fresh_kws.setdefault(col, set()).add(kw)
        for a in late:
            for k in a.get("keywords") or []:
                kw = k.get("keyword")
                holders = shared.get(kw) or []
                if not kw or not holders or not str(k.get("meaning") or "").strip():
                    continue
                src = k.get("source") or {}
                kind = str(src.get("kind") or "model").lower()
                base = None
                if kind in ("document", "web"):         # one source for all the columns: checked once
                    kc = check(kw, src, values=False)
                    base = {"meaning": str(k["meaning"]).strip(), "source": kc["source"], "checked": kc["verified"], "why": kc["why"]}
                elif kind != "data":
                    base = {"meaning": str(k["meaning"]).strip(), "source": {"kind": "model", "ref": "model knowledge", "quote": ""}, "checked": False,
                            "why": "no source that the program can check (model)"}
                for h in holders:
                    entry = out.get(h)
                    if entry is None:
                        entry = out[h] = blank(h)
                    if kw in entry["keywords"]:
                        continue
                    if base is None:            # read from the data: the word must be among the values of each column that holds it
                        kc = check("%s = %s" % (h, kw), {"kind": "data", "ref": h, "quote": kw})
                        one_kw = {"meaning": str(k["meaning"]).strip(), "source": kc["source"], "checked": kc["verified"], "why": kc["why"]}
                    else:
                        one_kw = dict(base, source=dict(base["source"]))
                    one_kw["asked_once_for"] = len(holders)
                    entry["keywords"][kw] = one_kw
                    fresh_kws.setdefault(h, set()).add(kw)
        for col, kws in kept_kw.items():        # a column that got no meaning keeps the keyword meanings of earlier runs
            if kws and col not in out:
                out[col] = blank(col)
        return out, claims, fresh_cols, fresh_kws

    by_name = {c["column"]: c for c in filled}

    def keep(out, fresh_cols, fresh_kws):
        """What the model answered in this run goes to knowledge/column_meanings, so the next run does not ask it again (the
        store keeps only what is trusted: a quote that was not found is not remembered). -> entries written."""
        if not scopes:
            return 0
        lf = {"file": f["name"], "run": ctx.run["id"], "at": time.time()}
        for col in sorted(set(fresh_cols) | set(fresh_kws)):
            sc, entry = scopes.get(col), out.get(col)
            if not sc or not entry:
                continue
            c = by_name.get(col) or {}
            new_kws = {kw: entry["keywords"][kw] for kw in fresh_kws.get(col, ()) if kw in (entry.get("keywords") or {})}
            part = {"meaning": entry.get("meaning") if col in fresh_cols else "", "source": entry.get("source") or {}, "checked": bool(entry.get("checked")),
                    "why": entry.get("why") or "", "keywords": new_kws}
            values = [str(k["value"]) for k in (c.get("keywords") or []) if isinstance(k, dict) and k.get("value") not in (None, "")][:CK.VALUES_KEPT]
            store.remember(sc, col, part, typ=c.get("type"), values=values, learned_from=lf, level=level)
        return store.save()

    if failure is not None or state["fatal"]:
        # the step stops, but what the parts that did answer brought is kept for "Run it again": those columns are not asked again
        try:
            out, _claims, fresh_cols, fresh_kws = build(None)
            keep(out, fresh_cols, fresh_kws)
        except Exception as e:
            sys.stderr.write("Data Grounder: what was understood before the failure could not be saved (%s)\n" % e)
        if state["fatal"]:            # the model could not be reached at all: the step stops with the reason, for "Run it again" after the fix
            say()
            raise RuntimeError("The Data Grounder could not reach the model: %s. Fix it in Settings -> Model connection (Save and test the connection), "
                               "then press Run it again." % state["fatal"])
        raise failure
    t_calls = time.time() - t0 - t_refs
    # the web pages the answers quote are opened by the program itself, several at the same time; the quotes are then checked on
    # the pages kept
    web, t1 = runner.web_sources(), time.time()
    urls = []
    if web is not None:
        for a in answers:
            for src in [a.get("source") or {}] + [k.get("source") or {} for k in a.get("keywords") or []]:
                if src.get("kind") == "web" and str(src.get("ref") or "").strip():
                    urls.append(str(src["ref"]).strip())
        urls = list(dict.fromkeys(urls))
        if urls:
            def page(u):
                if ctx.run["id"] not in runner.cancelled:
                    web.text(u)
            say("all answers are in; checking the quotes on %d web page%s: 0 opened" % (len(urls), "" if len(urls) == 1 else "s"))
            with ThreadPoolExecutor(max_workers=min(8, len(urls))) as pool:
                for n, _done in enumerate(as_completed([pool.submit(page, u) for u in urls]), 1):
                    say("all answers are in; checking the quotes on %d web page%s: %d opened" % (len(urls), "" if len(urls) == 1 else "s", n))
    out, claims, fresh_cols, fresh_kws = build(web)
    if claims:
        ctx.evidence(claims)          # one write for all of them
    t_web = time.time() - t1
    try:
        keep(out, fresh_cols, fresh_kws)
    except Exception as e:            # the run's own result does not depend on it: said, not fatal
        producers.add("what was understood could not be saved for later runs (%s)" % str(e)[:120])
    if not producers:
        producers.add("no column of this file holds a value" if not filled else "nothing to ask")
    secs = state["secs"]
    timing = {"seconds_total": round(time.time() - t0, 1), "seconds_reference_lookup": round(t_refs, 1), "seconds_model_calls": round(t_calls, 1),
              "seconds_quote_checks": round(t_web, 1), "parts": len(parts), "meanings_per_part_at_most": per, "model_calls": len(secs),
              "calls_at_once_allowed": at_once, "calls_at_once_most": state["most"], "seconds_per_call_average": round(sum(secs) / len(secs), 1) if secs else None,
              "seconds_per_call_longest": round(max(secs), 1) if secs else None, "web_pages_opened": len(urls), "too_many_calls_refusals": runner.slots.refused,
              "columns_with_values": len(filled), "columns_from_the_approved_dictionary": counts["approved"],
              "columns_from_the_reference_document": counts["library"], "columns_from_the_model_when_the_document_was_prepared": counts["library_model"],
              "columns_from_earlier_runs": counts["stored"], "columns_asked": len(a_items), "keyword_meanings_asked": asked_keywords,
              "calls_for_column_meanings": len(a_parts), "columns_per_such_call_at_least": min(GROUND_BATCH, len(a_items)) if a_items else None,
              "columns_per_such_call_most": a_per or None, "frequent_keywords_given_per_column_at_most": GROUND_KEYWORDS_SHOWN,
              "calls_started_per_second_at_most": runner.slots.per_second,
              "shared_keywords_asked_once": len(shared)}
    how_long = "The Data Grounder took %s for %s: %s looking up the reference documents; %s for %d model call%s in %d part%s%s; %s checking the quotes%s." % (
        core.fmt_secs(timing["seconds_total"]), f["name"], core.fmt_secs(t_refs), core.fmt_secs(t_calls), len(secs), "" if len(secs) == 1 else "s",
        len(parts), "" if len(parts) == 1 else "s",
        " (up to %d at the same time, %d at the most; a call took %s on average and %s at the longest)" % (
            at_once, state["most"], core.fmt_secs(max(1, sum(secs) / len(secs))), core.fmt_secs(max(1, max(secs)))) if secs else "",
        core.fmt_secs(t_web), " on %d web page%s" % (len(urls), "" if len(urls) == 1 else "s") if urls else "")
    was_known = [t for t in ("%d from the approved dictionary" % counts["approved"] if counts["approved"] else "",
                             "%d from the reference document of %s" % (counts["library"], tool["name"]) if counts["library"] else "",
                             "%d from the model's knowledge when that document was prepared" % counts["library_model"] if counts["library_model"] else "",
                             "%d from an earlier run" % counts["stored"] if counts["stored"] else "") if t]
    how_long += " Of the %d column%s that hold a value, %s; the model was asked for %d column%s and %d keyword meaning%s%s." % (
        len(filled), "" if len(filled) == 1 else "s",
        ("the meaning of %s was already known" % ", ".join(was_known)) if was_known else "none had a meaning that was already known",
        len(a_items), "" if len(a_items) == 1 else "s", asked_keywords, "" if asked_keywords == 1 else "s",
        " (%d keyword%s that many columns hold asked once for all of them)" % (len(shared), "" if len(shared) == 1 else "s") if shared else "")
    memory = {"agent": "Data Grounder", "file": f["name"], "made": time.time(), "run": ctx.run["id"], "web_allowed": web_ok,
              "reference_folders": refs.folders, "exported_by": tool, "store": {"tool": key or None, "scopes": scopes},
              "timing": timing, "columns": out}
    box = runner.sandbox(ctx.run["id"], "grounder_" + f["name"])
    path = os.path.join(box, "memory.json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(memory, fh, indent=1)
    say(final=True)
    by = Counter(_status(m) for m in out.values())
    return core.Result({"memory_file": path, "columns_asked": len(a_items), "meanings": dict(by), "web_allowed": web_ok, "timing": timing,
                        "how_long": how_long, "exported_by": tool},
                       producer=", ".join(sorted(producers)))


def _status(m):
    """Where a meaning comes from, in words."""
    if not m or not m.get("meaning"):
        return "no meaning found"
    if m.get("reused"):
        r = m["reused"]
        return "from the approved dictionary of %s (approved by %s, %s)" % (r.get("file") or "this file", r.get("by") or "the admin", r.get("on") or "earlier")
    st = m.get("stored") if isinstance(m.get("stored"), dict) else None
    if st and st.get("approved_by"):
        return "from the approved dictionary of %s (approved by %s, %s)" % (st.get("file") or "an earlier file", st["approved_by"], st.get("approved_on") or "earlier")
    kind = (m.get("source") or {}).get("kind")
    lib = m.get("library") if isinstance(m.get("library"), dict) else None
    if kind == "document":
        if m.get("checked"):
            base = "from the reference document of %s" % lib["tool_name"] if lib and lib.get("tool_name") else "from a reference document"
        else:
            base = "document quote not found: not trusted"
    elif kind == "web":
        base = "from a web page (checked)" if m.get("checked") else "web quote not found on the page: not trusted"
    elif kind == "admin":
        base = "given by the admin"
    elif kind == "data":
        base = "from the column's name and contents (checked: the value is in the column)" if m.get("checked") else "from the column's name and contents"
    elif lib:
        base = "from the model's knowledge when the reference document was prepared (no source to check)"
    else:
        base = "from the model's knowledge (no source to check)"
    return ("kept from an earlier run: " + base) if st else base


def _manager(ctx, f):
    ex, gr = ctx.output_of("explore:" + f["name"]), ctx.output_of("ground:" + f["name"])
    emem = json.load(open(ex["memory_file"], encoding="utf-8"))
    gmem = json.load(open(gr["memory_file"], encoding="utf-8")) if gr.get("memory_file") and os.path.exists(gr["memory_file"]) else {"columns": {}}
    edits = ctx.input.get("edits") or {}
    gcols = gmem.get("columns") if isinstance(gmem.get("columns"), dict) else {}
    tool = gmem.get("exported_by") or gr.get("exported_by") or emem.get("exported_by")
    rows = []
    for c in emem.get("columns") or []:
        if not isinstance(c, dict) or not c.get("column") or not c.get("rows_with_value"):
            continue
        g = gcols.get(c["column"]) or {}
        if c["column"] in edits:
            g = dict(g, meaning=edits[c["column"]], source={"kind": "admin", "ref": ctx.project.get("admin") or "admin", "quote": ""}, checked=True)
        kws = []
        for k in c.get("keywords") or []:
            if not isinstance(k, dict) or k.get("value") in (None, ""):
                continue
            gk = (g.get("keywords") or {}).get(k["value"]) or {}
            kws.append({"value": k["value"], "count": k.get("count"), "rows": k.get("rows") or [], "where": where(f.get("path"), k.get("rows") or []),
                        "meaning": gk.get("meaning", ""), "status": _status(gk), "source": gk.get("source")})
        top = c.get("top_values") or []
        first_rows = (top[0].get("rows") or []) if top and isinstance(top[0], dict) else []
        rows.append({"column": c["column"], "type": c.get("type") or "", "rows_with_value": c["rows_with_value"], "distinct": c.get("distinct"),
                     "observed": c.get("observed", ""), "filled_for": (c.get("filled_for") or {}).get("text", ""),
                     "meaning": g.get("meaning", ""), "status": _status(g),
                     "sources": [g["source"]] if g.get("meaning") and g.get("source") and g.get("checked") else [],
                     "source": g.get("source") if g.get("meaning") else None, "where": where(f.get("path"), first_rows), "keywords": kws})
    counts = Counter(r["status"] for r in rows)
    n_rows, in_file = emem.get("rows") or 0, emem.get("columns_in_file") or len(emem.get("columns") or [])
    n_keywords = emem.get("keywords") if isinstance(emem.get("keywords"), int) else sum(len(r["keywords"]) for r in rows)
    empty_cols = list(emem.get("columns_empty") or [])
    dictionary = {"file": f["name"], "path": f.get("path"), "level": f.get("level"), "format_key": f.get("format_key"), "made": time.time(),
                  "rows": n_rows, "rows_estimate": n_rows, "summary": emem.get("summary", ""), "kind_of_row": emem.get("kind_of_row"), "columns": rows,
                  "empty_columns": empty_cols, "exported_by": tool, "explorer_memory": ex["memory_file"], "grounder_memory": gr.get("memory_file")}
    box = ctx.engine.runner.sandbox(ctx.run["id"], "manager_" + f["name"])
    path = os.path.join(box, "dictionary.json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(dictionary, fh, indent=1)
    admin = ctx.project.get("admin") or "admin"
    body = ["**Admin %s, need review.** The data dictionary of **%s**." % (admin, f["name"]), "", emem.get("summary", ""), "",
            "%s rows; %d of %d columns hold values; %d special keywords." % ("{:,}".format(n_rows), len(rows), in_file, n_keywords), ""]
    if exported_sentence(tool):
        body += [exported_sentence(tool), ""]
    special = sum(1 for r in rows if r["filled_for"])
    kind_text = (emem.get("kind_of_row") or {}).get("text") if isinstance(emem.get("kind_of_row"), dict) else ""
    if kind_text and special:
        body += ["%s %d column%s hold a value on some kinds of row only: the table says which, under what the data holds." % (
            kind_text, special, "" if special == 1 else "s"), ""]
    if gr.get("how_long"):
        body += [gr["how_long"], ""]
    body += ["| where the meanings come from | columns |", "|---|---|"] + ["| %s | %d |" % kv for kv in counts.most_common()]
    return core.Result({"dictionary_file": path, "counts": dict(counts)},
                       review={"title": "Data dictionary of %s" % f["name"], "body": "\n".join(body),
                               "data": {"dictionary_file": path, "summary": emem.get("summary", ""), "path": f.get("path"), "kind_of_row": emem.get("kind_of_row"),
                                        "timing": gr.get("timing"), "exported_by": tool,
                                        "facts": {"rows": n_rows, "columns_in_file": in_file, "columns_with_values": len(rows),
                                                  "keywords": n_keywords, "level": f.get("level_label"), "seconds_reading": emem.get("seconds")},
                                        "counts": dict(counts), "table": rows, "empty": empty_cols,
                                        "spacers": blank_header_positions(f["path"]) if f.get("path") else [],
                                        "memories": {"explorer": ex["memory_file"], "grounder": gr.get("memory_file"), "dictionary": path}}})


# ---------------------------------------------------------------------------------------------- the Manager answers the admin
DATA_WORDS = re.compile(r"\b(row|rows|line|lines|how many|count|which|where|show|appear|present|value|values|keyword|keywords|data|hold|holds|contain|contains|find|list)\b", re.I)
MEANING_WORDS = re.compile(r"\b(mean|means|meaning|stand|stands|what is|what are|why|define|definition|purpose|used for)\b", re.I)


def _lookup(path, mem, question):
    """Code first: the columns and keywords the question names, with their counts and the lines where they are."""
    q = question.lower()
    hits = []
    for c in mem["columns"]:
        if not c["rows_with_value"]:
            continue
        named = c["column"].lower() in q or (c["column"].partition(".")[2] or "~").lower() in q
        for k in c.get("keywords") or []:
            if len(k["value"]) >= 2 and re.search(r"(?<![a-z0-9])%s(?![a-z0-9])" % re.escape(k["value"].lower()), q):
                hits.append({"column": c["column"], "keyword": k["value"], "rows_holding_it": k["count"], "where": where(path, k["rows"])})
        if named:
            hits.append({"column": c["column"], "rows_with_value": c["rows_with_value"], "type": c["type"], "distinct": c["distinct"],
                         "observed": c.get("observed"), "filled_only_on": (c.get("filled_for") or {}).get("text") or "",
                         "top_values": [{"value": t["value"], "count": t["count"], "where": where(path, t["rows"])} for t in c["top_values"][:6]],
                         "keywords": [{"value": k["value"], "count": k["count"]} for k in (c.get("keywords") or [])[:30]]})
    return hits[:20]


EXPLORER_ANSWER = """You are the Data Explorer of one CSV file. Answer the admin's question from your memory of the data
(CONTEXT: the summary, the profile counted from every row, and the lines the code found for what the question names).
Use the exact counts; give the file path and line numbers where the admin can see it. Say nothing about what things
mean (that is the Grounder's). If your memory does not hold the answer, say so."""
GROUNDER_ANSWER = """You are the Data Grounder of one CSV file. Answer the admin's question about what a column or a keyword
means, from your memory (CONTEXT: the meanings you found, each with its source). Say where each meaning comes from (the
document and line, the web page, or model knowledge). If your memory does not hold it, say so; you may look it up (see
THE WEB below, when allowed) and cite the page."""


def manager_ask(engine, review, step, question, history):
    """The admin asks the Manager; the Manager asks the right helper: the Explorer for the data (with the lines where it
    is), the Grounder for a meaning (with its source), or both. -> (answer text, producer)."""
    out = core.jload(step["output"], {}) or {}
    d = json.load(open(out["dictionary_file"], encoding="utf-8"))
    emem = json.load(open(d["explorer_memory"], encoding="utf-8"))
    gmem = json.load(open(d["grounder_memory"], encoding="utf-8")) if d.get("grounder_memory") and os.path.exists(d["grounder_memory"]) else {"columns": {}}
    data_q, meaning_q = bool(DATA_WORDS.search(question)), bool(MEANING_WORDS.search(question))
    ask = (["explorer"] if data_q or not meaning_q else []) + (["grounder"] if meaning_q or not data_q else [])
    hits = _lookup(d["path"], emem, question)
    parts, producers = [], []
    runner, run_id = engine.runner, review["run"]
    # one answering agent per file: with a held terminal session, the Manager of one file never continues the
    # conversation about another file
    of_file = re.sub(r"[^A-Za-z0-9_.-]+", "_", os.path.basename(str(d["path"])))[:60]
    if "explorer" in ask:
        ctx = {"question": question, "file": d["path"], "summary": emem.get("summary"), "rows": emem["rows"],
               "what_the_question_names": hits, "columns": [{"column": c["column"], "rows_with_value": c["rows_with_value"], "observed": c.get("observed")}
                                                            for c in emem["columns"] if c["rows_with_value"]][:150], "conversation": history[-6:]}

        def standin():
            if hits:
                return {"answer": "; ".join(("%s = %s: %s rows, see %s" % (h["column"], h["keyword"], "{:,}".format(h["rows_holding_it"]), h["where"])) if "keyword" in h else
                                            ("%s: %s rows hold a value; %s" % (h["column"], "{:,}".format(h["rows_with_value"]), h.get("observed") or "")) for h in hits[:6])}
            return {"answer": "%s (the file %s)" % (emem.get("summary") or "", d["path"])}
        a, prod, _ = runner.ask(run_id, "explorer_answers_" + of_file, EXPLORER_ANSWER, ctx, '{"answer": "..."}', "answer", standin)
        parts.append("**Data Explorer (the data):** " + str(a.get("answer", "")))
        producers.append("Explorer: " + prod)
    if "grounder" in ask:
        names = {h["column"] for h in hits}
        kwn = {(h["column"], h["keyword"]) for h in hits if "keyword" in h}
        mine = {c: m for c, m in gmem["columns"].items() if c in names} or gmem["columns"]
        ctx = {"question": question, "meanings": {c: {"meaning": m.get("meaning"), "status": _status(m), "source": m.get("source"),
                                                      "keywords": {k: v for k, v in (m.get("keywords") or {}).items() if not kwn or (c, k) in kwn}}
                                                  for c, m in list(mine.items())[:80]}, "conversation": history[-6:]}

        def standin():
            got = [("%s: %s (%s)" % (c, m.get("meaning"), _status(m))) for c, m in mine.items() if m.get("meaning")][:6]
            return {"answer": "; ".join(got) if got else "I have no meaning for that yet (no document, web page or model knowledge gave one)."}
        a, prod, _ = runner.ask(run_id, "grounder_answers_" + of_file, GROUNDER_ANSWER, ctx, '{"answer": "..."}', "answer", standin, web=runner.can_search_web())
        parts.append("**Data Grounder (the meanings):** " + str(a.get("answer", "")))
        producers.append("Grounder: " + prod)
    asked = " and ".join({"explorer": "the Data Explorer", "grounder": "the Data Grounder"}[x] for x in ask)
    return "I asked %s.\n\n%s" % (asked, "\n\n".join(parts)), "Manager (%s)" % "; ".join(producers)


def on_approve(engine, run, step, data, admin):
    if not step["key"].startswith("manager:"):
        return
    out = core.jload(step["output"], {})
    d = json.load(open(out["dictionary_file"], encoding="utf-8"))
    edits = data.get("edits") or {}
    if not isinstance(edits, dict):
        edits = {}
    by_col = {r["column"]: r for r in d["columns"]}
    unknown = []
    for key, meaning in edits.items():             # "column" or "column: keyword" (owner, 2026-11-10: keyword meanings too; a name the file does not have is refused, not ignored)
        col, _, kw = str(key).partition(":")
        col, kw = col.strip(), kw.strip()
        r = by_col.get(col) or by_col.get(str(key).strip())
        if r is None:
            unknown.append(str(key))
        elif kw and r is not by_col.get(str(key).strip()):
            k = next((k for k in r.get("keywords") or [] if k.get("value") == kw), None)
            if k is None:
                unknown.append(str(key))
            else:
                k["meaning"], k["status"], k["source"] = str(meaning), "given by the admin", {"kind": "admin", "ref": admin, "quote": ""}
        else:
            r["meaning"], r["status"], r["source"] = str(meaning), "given by the admin", {"kind": "admin", "ref": admin, "quote": ""}
    empty = set(d.get("empty_columns") or [])
    for key in list(unknown):                      # a column with no value in this recording can still be given a meaning: it is kept beside the dictionary
        if key.strip() in empty:
            d.setdefault("empty_meanings", {})[key.strip()] = {"meaning": str(edits[key]), "by": admin, "at": time.time()}
            unknown.remove(key)
    if unknown:
        raise ValueError("not in %s, so not saved: %s. Correct or remove these lines, then approve" % (d.get("file"), "; ".join(unknown)))
    d["approved_by"], d["approved_at"] = admin, time.time()
    folder = os.path.join(knowledge_dir(), "dictionaries", d["format_key"])
    os.makedirs(folder, exist_ok=True)
    n = 1 + len([x for x in os.listdir(folder) if x.startswith(os.path.splitext(d["file"])[0] + ".v")])
    d["version"] = n
    base = os.path.splitext(d["file"])[0]
    L.write_json_atomic(os.path.join(folder, "%s.v%d.json" % (base, n)), d, indent=1)
    L.write_json_atomic(os.path.join(folder, "%s.current.json" % base), d, indent=1)
    try:                               # the dictionary is saved; remembering it column by column must not undo the approval
        _approve_in_store(d, admin)
    except Exception as e:
        sys.stderr.write("Data dictionary of %s: approved and saved, but its meanings could not be remembered for later files (%s)\n" % (d.get("file"), e))


def _approve_in_store(d, admin):
    """An approved dictionary's meanings go to knowledge/column_meanings as approved: a later file of the same tool and level
    (or, for an unknown tool, with the same header) takes them without a call. A meaning keeps the source it had; one the
    admin wrote has the admin as its source. -> entries written."""
    gpath = d.get("grounder_memory")
    if not gpath or not os.path.exists(gpath):
        return 0
    with open(gpath, encoding="utf-8") as fh:
        gm = json.load(fh)
    st = gm.get("store") if isinstance(gm.get("store"), dict) else {}
    scopes = st.get("scopes") if isinstance(st.get("scopes"), dict) else {}
    if not scopes:
        return 0
    gcols = gm.get("columns") if isinstance(gm.get("columns"), dict) else {}
    store = CK.Store(os.path.join(knowledge_dir(), "column_meanings"), st.get("tool"))
    ap = {"by": admin, "at": d.get("approved_at")}
    lf = {"file": d.get("file"), "run": gm.get("run"), "at": d.get("approved_at")}
    why = "approved by %s" % admin

    def part(row, known):
        """A dictionary row (a column or a keyword) as a store entry: the Grounder's source and check when the admin left the
        meaning as it was, the admin as the source when they wrote it."""
        meaning = str(row.get("meaning") or "").strip()
        same = meaning == str(known.get("meaning") or "").strip()
        src = row.get("source") or (known.get("source") if same else None) or {}
        src = {k: v for k, v in src.items() if k != "where"} if isinstance(src, dict) else {}
        checked = True if src.get("kind") == "admin" else (bool(known.get("checked")) if same else False)
        return {"meaning": meaning, "source": src, "checked": checked, "why": why}, same
    for r in d.get("columns") or []:
        col = r.get("column") if isinstance(r, dict) else None
        sc = scopes.get(col) if col else None
        if not sc:
            continue
        ge = gcols.get(col) if isinstance(gcols.get(col), dict) else {}
        entry, same = part(r, ge)
        entry["keywords"] = {}
        for k in r.get("keywords") or []:
            if isinstance(k, dict) and k.get("value") not in (None, "") and str(k.get("meaning") or "").strip():
                gk = (ge.get("keywords") or {}).get(k["value"])
                entry["keywords"][str(k["value"])] = part(k, gk if isinstance(gk, dict) else {})[0]
        if not entry["meaning"] and not entry["keywords"]:
            continue
        values = [str(k["value"]) for k in r.get("keywords") or [] if isinstance(k, dict) and k.get("value") not in (None, "")][:CK.VALUES_KEPT]
        store.remember(sc, col, entry, typ=r.get("type"), values=values, learned_from=lf, approved=ap,
                       library=ge.get("library") if same and isinstance(ge.get("library"), dict) else None, level=d.get("level"))
    return store.save()


def on_reject(engine, run, step, data, admin):
    """The admin rejected a data dictionary: what that run understood of the file and nobody approved is taken out of
    knowledge/column_meanings, so the next run asks it anew instead of taking the rejected meanings as known. -> entries removed."""
    key = str((step or {}).get("key") or "")
    if not key.startswith("manager:"):
        return 0
    since = run.get("created") if isinstance(run.get("created"), (int, float)) else None
    return CK.forget_run(os.path.join(knowledge_dir(), "column_meanings"), run["id"], file=key.partition(":")[2], since=since)


def approved_dictionary(format_key, file_name):
    p = os.path.join(knowledge_dir(), "dictionaries", format_key, "%s.current.json" % os.path.splitext(file_name)[0])
    try:
        return json.load(open(p, encoding="utf-8")) if os.path.exists(p) else None
    except (OSError, ValueError):            # a damaged dictionary counts as none: the data is simply learned again
        return None


def dictionaries_for_level(level):
    """Every approved dictionary of a level (any format), newest first."""
    out = []
    root = os.path.join(knowledge_dir(), "dictionaries")
    if not os.path.isdir(root):
        return out
    for fk in os.listdir(root):
        for fn in os.listdir(os.path.join(root, fk)):
            if fn.endswith(".current.json"):
                try:
                    d = json.load(open(os.path.join(root, fk, fn), encoding="utf-8"))
                except (OSError, ValueError):
                    continue
                if d.get("level") == level:
                    out.append(d)
    out.sort(key=lambda d: d.get("approved_at") or 0, reverse=True)
    return out
