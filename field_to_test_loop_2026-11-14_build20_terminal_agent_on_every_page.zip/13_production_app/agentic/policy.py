"""API calls can be switched off for a site that may not use them.

History: on 2026-11-13 the owner said "Api calls are strictly not allowed ... use only the terminal sessions call", and
the same night: "There is no need of using any terminal call agents, that's fine with the api call ... I want you to do
proper API calls. I don't want you to always use the terminal agents except at the first after the first family."
So API calls are ON unless the configuration file says `server.api_calls: false`. The switch stays for a site where
they are not allowed. While it is false:
  - the agents run through opencode in a terminal (a runtime of "claude-code" or "http" is run as opencode), and
    Settings offer only opencode and the stand-in;
  - the model connection of the other pages is opencode whatever `llm.backend` says (the stand-in stays the stand-in);
  - the URL / model / key of the Model connection cannot be saved, the key file is not loaded at start, and the key is
    taken out of the environment of every opencode call;
  - the old packets analyser runs its model review without a model;
  - the code that could call a model address refuses with NOT_ALLOWED if anything still reaches it.
Nothing in Settings can change the switch.
"""

NOT_ALLOWED = ("API calls are not allowed in this application: every model call goes through opencode in a terminal "
               "(the switch is server.api_calls in the configuration file)")
TERMINAL_ONLY = ("opencode", "standin")


def api_allowed(cfg):
    return ((cfg or {}).get("server") or {}).get("api_calls", True) is not False


def runtime_for(cfg, runtime):
    """The agents' runtime as it is run: with API calls off, only opencode and the stand-in exist."""
    if api_allowed(cfg) or runtime in TERMINAL_ONLY:
        return runtime
    return "opencode"
