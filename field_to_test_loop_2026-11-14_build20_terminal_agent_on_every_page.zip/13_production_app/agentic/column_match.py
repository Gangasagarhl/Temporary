"""Which column holds this kind of data?

(owner, 2026-11-14: "if there is a column name is not available, it doesn't mean that the column itself might not be
present ... is there any way that I can substitute the same column name with the other column name? Because ... other
column might be having the same kind of data. It's an exploration thing ... do multiple parallel requests".)

A column that a rule names is missing or empty. This module looks in every file of the analysis for a column that holds
the same kind of data, and gives the admin a short ranked list with evidence to judge. It never applies a substitute.

How (the order follows what the published work measured; the notes are in research_notes/Four agent families fast and
stateful/column_matching_and_data_exploration.md):

  1. By code, from what Family 1 already knows (the data dictionaries and the Data Explorer's memory): one signature per
     column (rows with a value, distinct values, type, the shape of its values, number range, the values kept). Every
     column of every file is ranked by: how many of the wanted values it holds (shared / wanted: containment, never
     Jaccard, which puts small columns first), the same shape, the same type, the meaning's words, and the name as the
     weakest sign. The best 20 at most go on. No file is opened for this.
  2. By code, exact, only for that short list and only when example values exist: each file with candidates is read
     once, row by row, and the rows holding a wanted value are counted, with the lines where they were seen.
  3. The model, one call per file with candidates, all at the same time: it reads the meanings and picks from the short
     list or says "none of these". A column it names that is not on the list is dropped. What it says is shown as its
     reason; it never changes the level of support.

The level of support of a proposal is decided by code:
  "the values match"            the wanted values were counted in the column, and the inclusion cannot be chance;
  "the kind of data matches"    no values could be compared (or too few to mean anything), but the meaning Family 1
                                gives the column names the wanted data, and the shape does not contradict it;
  "only the name is alike"      nothing but the name: shown, never offered as a substitute without the admin's word.

Inclusion alone is not support. Counters numbered from 1, 0/1 flags and words every enumeration shares (Enabled,
Reserved) are included in one another by chance (Rostin et al., WebDB 2009: 40,415 inclusions in one database, most of
them spurious). For such values a second, independent sign is required, and the card says so.

The result does not depend on how many calls run at the same time: the files are taken in name order, one call per
file, the answers are merged by (file, column), and ties are broken by file and column name.
"""
import difflib
import json
import os
import re
from concurrent.futures import ThreadPoolExecutor

from . import admin_ask, family1, prompts

VALUES_MATCH, KIND_MATCH, NAME_ONLY = "the values match", "the kind of data matches", "only the name is alike"
LEVELS = (VALUES_MATCH, KIND_MATCH, NAME_ONLY)
SHORT_LIST = 20             # candidate columns that go to the exact count and to the model, at most
PER_FILE_FOR_MODEL = 12     # ... of one file in one call
SMALL_SET = 12              # this many distinct values or fewer are included in other columns by chance
OUTSIDE_MOST = 0.5          # numbers: a column with more than this share of its range outside the wanted range is another thing
SHARE_NEEDED = 0.5          # the share of the wanted values that must be in a column for "the values match"
COMMON_SHARE = 0.3          # a word in the meanings of more than this share of the columns (and of 3 or more) is not a sign
NAME_ALIKE = 0.72           # how alike two names must be to count at all (0 to 1, difflib's ratio on the cleaned names)
ROWS_READ_MOST = 5_000_000  # records of one file read for the exact count; the card says when the file is longer
LINES_SHOWN = 5
VALUES_WANTED_MOST = 5000
GENERIC = {"0", "1", "yes", "no", "true", "false", "on", "off", "enabled", "disabled", "reserved", "supported", "not supported",
           "none", "n/a", "na", "null", "unknown", "ok", "error", "success", "fail", "failed", "-", ""}
SHAPE = '{"choices": [{"column": "<a column of CANDIDATES, letter for letter>", "why": "<one sentence>"}], "none_of_these": false, "note": "<what would be needed, when none fits>"}'


# ---------------------------------------------------------------------------------------------- the shape of a value
def shape(value):
    """The shape of one value: "0x" + hexadecimal digits -> 0xH, digits -> 9, letters -> A, everything else as written.
    ("0x02 (Read)" -> "0xH (A)", "12.5 ms" -> "9.9 A", "2026-11-14" -> "9-9-9")."""
    s = str(value).strip()
    out, i = [], 0
    while i < len(s):
        m = re.match(r"0[xX][0-9A-Fa-f]+", s[i:])
        if m:
            out.append("0xH")
            i += m.end()
            continue
        c = s[i]
        if c.isdigit():
            j = i
            while j < len(s) and s[j].isdigit():
                j += 1
            out.append("9")
            i = j
        elif c.isalpha():
            j = i
            while j < len(s) and s[j].isalpha():
                j += 1
            out.append("A")
            i = j
        else:
            out.append(c)
            i += 1
    return "".join(out)


def shape_words(sh):
    """A shape for a person: `0xH (A)` -> "0x and hexadecimal digits, a space, (letters)"."""
    if not sh:
        return "not known"
    words = {"0xH": "0x and hexadecimal digits", "9": "digits", "A": "letters", " ": "a space"}
    parts, i = [], 0
    while i < len(sh):
        if sh.startswith("0xH", i):
            parts.append(words["0xH"])
            i += 3
        elif sh[i] in words:
            parts.append(words[sh[i]])
            i += 1
        else:
            j = i
            while j < len(sh) and not sh.startswith("0xH", j) and sh[j] not in "9A ":
                j += 1
            parts.append('"%s"' % sh[i:j])
            i = j
    return ", ".join(parts)


def _main_shape(values):
    """(the shape most of the values have, the share of the values with it)."""
    count = {}
    for v in values:
        s = shape(v)
        count[s] = count.get(s, 0) + 1
    if not count:
        return "", 0.0
    best = sorted(count.items(), key=lambda kv: (-kv[1], kv[0]))[0]
    return best[0], round(best[1] / float(len(values)), 3)


def _clean_name(name):
    return re.sub(r"[^a-z0-9]+", " ", str(name or "").lower()).strip()


def name_alike(a, b):
    a, b = _clean_name(a), _clean_name(b)
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    return round(difflib.SequenceMatcher(None, a, b).ratio(), 3)


def _words(text):
    return {w for w in re.findall(r"[a-z][a-z0-9]{2,}", str(text or "").lower())
            if w not in {"the", "and", "for", "that", "this", "with", "from", "column", "value", "values", "data", "each", "one", "its", "row", "rows", "file", "holds", "which"}}


def _norm(v):
    return str(v).strip().lower()


def _small_numbers(values):
    """True when the values are small whole numbers: the kind every counter and identifier column holds."""
    vals = [v for v in values if v != ""]
    return bool(vals) and all(re.fullmatch(r"\d{1,5}", v) for v in vals)


def by_chance(wanted, sig):
    """Why an inclusion of the wanted values in this column could be chance, in words, or "" when it could not."""
    w = [v for v in wanted if v not in GENERIC]
    if not w:
        return "the values are words many columns share (yes/no, Enabled, Reserved, 0 and 1)"
    if len(set(wanted)) <= SMALL_SET:
        return "only %d distinct values are compared: so few are found in many columns by chance" % len(set(wanted))
    if _small_numbers(wanted):
        return "the values are small whole numbers: counters and identifiers numbered from 0 or 1 include one another by chance"
    if sig.get("counter_like"):
        return "this column is a counter (every row a new number): it holds any small number by chance"
    if sig.get("flag_like"):
        return "this column holds only one or two values"
    return ""


def outside_share(wanted_values, sig):
    """For numbers: the share of the column's own range that lies outside the range of the wanted values (0 to 1), or
    None when either side is not numbers. A column that holds the wanted numbers and far more besides (a counter from 1 to
    300 against identifiers 1 to 20) is a different thing."""
    nums = [int(v) for v in wanted_values if re.fullmatch(r"-?\d{1,15}", v)]
    lo, hi = sig.get("min"), sig.get("max")
    if not nums or len(nums) != len([v for v in wanted_values if v != ""]) or not isinstance(lo, (int, float)) or not isinstance(hi, (int, float)) or hi < lo:
        return None
    wlo, whi = min(nums), max(nums)
    inside = max(0, min(hi, whi) - max(lo, wlo) + 1)
    return round(1.0 - inside / float(hi - lo + 1), 3)


# ---------------------------------------------------------------------------------------------- signatures
def signatures(files):
    """One signature per column that holds a value, for every file with a data dictionary.
    files: [{"name", "path", "dictionary" (Family 1's, or None)}] -> ([signature], [names of files without a dictionary])."""
    sigs, none = [], []
    for f in sorted(files, key=lambda x: x["name"]):
        d = f.get("dictionary")
        if not d:
            none.append(f["name"])
            continue
        mem = {}
        for c in (admin_ask._load(d.get("explorer_memory") or "") or {}).get("columns") or []:
            if isinstance(c, dict) and c.get("column"):
                mem.setdefault(str(c["column"]), c)
        for c in d.get("columns") or []:
            if not isinstance(c, dict) or not c.get("column") or not c.get("rows_with_value"):
                continue
            name = str(c["column"])
            m = mem.get(name) or {}
            known = {}
            for t in (m.get("top_values") or []):
                if isinstance(t, dict) and t.get("value") not in (None, ""):
                    known[_norm(t["value"])] = {"value": str(t["value"]), "rows": t.get("count"), "lines": [r + 1 for r in (t.get("rows") or [])[:LINES_SHOWN] if isinstance(r, int)]}
            for k in (c.get("keywords") or []) + (m.get("keywords") or []):
                if isinstance(k, dict) and k.get("value") not in (None, ""):
                    known.setdefault(_norm(k["value"]), {"value": str(k["value"]), "rows": k.get("count"),
                                                         "lines": [r + 1 for r in (k.get("rows") or [])[:LINES_SHOWN] if isinstance(r, int)]})
                    for w in k.get("as_written") or []:
                        known.setdefault(_norm(w), {"value": str(w), "rows": None, "lines": []})
            distinct = c.get("distinct") if isinstance(c.get("distinct"), int) else m.get("distinct")
            rows = c.get("rows_with_value")
            typ = str(c.get("type") or m.get("type") or "")
            lo, hi = m.get("min"), m.get("max")
            sh, share = _main_shape([k["value"] for k in known.values()])
            lens = [len(k["value"]) for k in known.values()]
            src = c.get("source") if isinstance(c.get("source"), dict) else {}
            sigs.append({
                "file": f["name"], "path": f.get("path") or d.get("path"), "column": name, "position": m.get("position"),
                "rows": rows, "distinct": distinct, "type": typ, "min": lo, "max": hi,
                "meaning": str(c.get("meaning") or ""), "observed": str(c.get("observed") or ""), "meaning_status": str(c.get("status") or ""),
                "source": str(src.get("ref") or "") if c.get("meaning") else "",
                "known": known, "known_is_all": isinstance(distinct, int) and distinct <= len(known) and not m.get("distinct_more_than_counted"),
                "shape": sh, "shape_share": share, "length": (min(lens), max(lens)) if lens else None,
                "counter_like": typ == "integer" and isinstance(distinct, int) and isinstance(rows, int) and rows > SMALL_SET and distinct == rows,
                "flag_like": isinstance(distinct, int) and distinct <= 2})
    return sigs, none


# ---------------------------------------------------------------------------------------------- step 1: the short list
def wanted_of(column="", file="", description="", values=None, sigs=()):
    """What is looked for, made exact. When no example values were given and another file has a column of that very
    name, its values are the examples (and the card says where they come from)."""
    column, file, description = str(column or "").strip(), str(file or "").strip(), " ".join(str(description or "").split())[:400]
    vals = [str(v).strip() for v in (values or []) if str(v).strip() != ""][:VALUES_WANTED_MOST]
    origin = "typed with the question" if vals else ""
    if not vals and column:
        for s in sigs:
            if s["file"] != file and _clean_name(s["column"]) == _clean_name(column) and s["known"]:
                vals = [k["value"] for k in s["known"].values()]
                origin = "the values the Data Explorer kept of %s column %s (%s)" % (
                    s["file"], s["column"], "all of its values" if s["known_is_all"] else "its most frequent values, not all")
                break
    low = list(dict.fromkeys(_norm(v) for v in vals))
    sh, share = _main_shape(vals)
    return {"column": column, "file": file, "description": description, "values": low, "values_as_written": list(dict.fromkeys(vals))[:40],
            "values_from": origin, "shape": sh, "shape_share": share}


def shortlist(wanted, sigs):
    """Every column ranked from what is already known -> the best SHORT_LIST with the signs found, best first."""
    want_vals = set(wanted["values"])
    want_words = _words(wanted["description"]) | _words(wanted["column"])
    # a word that many columns' meanings share ("visit", "command") says little: only the words few columns have count
    in_how_many = {}
    for s in sigs:
        for w in _words(s["meaning"]):
            in_how_many[w] = in_how_many.get(w, 0) + 1
    common = {w for w, n in in_how_many.items() if n >= 3 and n > COMMON_SHARE * len(sigs)}
    telling = want_words - common
    out = []
    for s in sigs:
        if wanted["column"] and wanted["file"] and s["file"] == wanted["file"] and s["column"] == wanted["column"]:
            continue                                    # the missing column itself (present but empty is not a candidate for itself)
        shared = sorted(want_vals & set(s["known"])) if want_vals else []
        contain = len(shared) / float(len(want_vals)) if want_vals else 0.0
        same_shape = bool(wanted["shape"]) and bool(s["shape"]) and wanted["shape"] == s["shape"]
        meaning_words = sorted(telling & (_words(s["meaning"]) | _words(" ".join(k["value"] for k in list(s["known"].values())[:40]))))
        # the meaning names the wanted data when it shares two telling words, or at least half of them
        if not (len(meaning_words) >= 2 or (meaning_words and 2 * len(meaning_words) >= len(telling))):
            meaning_words = []
        alike = name_alike(wanted["column"], s["column"]) if wanted["column"] else 0.0
        if alike < NAME_ALIKE:
            alike = 0.0
        if not (shared or same_shape or meaning_words or alike):
            continue
        # how informative the shape is: digits alone say little
        strong_shape = same_shape and s["shape"] not in ("9", "A", "")
        out.append({"sig": s, "shared": shared, "containment": round(contain, 4), "same_shape": same_shape, "strong_shape": strong_shape,
                    "meaning_words": meaning_words, "name_alike": alike,
                    "order": (-round(contain, 4), -int(strong_shape), -len(meaning_words), -int(same_shape), -alike, s["file"], s["column"])})
    out.sort(key=lambda c: c["order"])
    return out[:SHORT_LIST]


# ---------------------------------------------------------------------------------------------- step 2: the exact count
def exact_counts(cands, wanted, rows_most=ROWS_READ_MOST):
    """Each file with candidates read once, row by row: for every candidate column the rows that hold a wanted value,
    the wanted values found, and the lines where they were first seen. Nothing is kept in memory but the counts."""
    want = set(wanted["values"])
    if not want:
        return
    by_file = {}
    for c in cands:
        by_file.setdefault(c["sig"]["file"], []).append(c)
    for name in sorted(by_file):
        group = by_file[name]
        path = group[0]["sig"].get("path")
        if not path or not os.path.isfile(path):
            for c in group:
                c["exact"] = {"problem": "the file is not at its place any more: %s" % (path or name)}
            continue
        try:
            with open(path, newline="", encoding="utf-8-sig", errors="replace") as fh:
                rd = family1.L.read_csv(fh, path)
                head = [str(h) for h in next(rd, [])]
                spots = []
                for c in group:
                    pos = c["sig"].get("position")
                    if not (isinstance(pos, int) and 0 <= pos < len(head) and head[pos] == c["sig"]["column"]):
                        pos = head.index(c["sig"]["column"]) if c["sig"]["column"] in head else None
                    spots.append(pos)
                    c["exact"] = {"rows_holding": 0, "found": set(), "lines": [], "rows_read": 0, "capped": False} if pos is not None else {
                        "problem": "the header of %s has no column %s now" % (name, c["sig"]["column"])}
                n = 0
                for row in rd:
                    n += 1
                    if n > rows_most:
                        n -= 1
                        for c in group:
                            if "problem" not in c["exact"]:
                                c["exact"]["capped"] = True
                        break
                    for c, pos in zip(group, spots):
                        if pos is None or pos >= len(row):
                            continue
                        v = row[pos].strip().lower()
                        if v and v in want:
                            e = c["exact"]
                            e["rows_holding"] += 1
                            e["found"].add(v)
                            if len(e["lines"]) < LINES_SHOWN:
                                e["lines"].append(n + 1)
                for c in group:
                    if "problem" not in c["exact"]:
                        c["exact"]["rows_read"] = n
                        c["exact"]["found"] = sorted(c["exact"]["found"])
        except (OSError, UnicodeDecodeError, StopIteration) as e:
            for c in group:
                c["exact"] = {"problem": "the file could not be read: %s" % str(e)[:160]}


# ---------------------------------------------------------------------------------------------- step 3: the model, per file
def _for_model(c, wanted):
    s = c["sig"]
    e = {"column": s["column"], "meaning": (s["meaning"] or s["observed"])[:260], "rows_with_a_value": s["rows"], "distinct_values": s["distinct"],
         "shape_of_its_values": shape_words(s["shape"]), "some_values": [k["value"] for k in list(s["known"].values())[:8]]}
    if isinstance(s.get("min"), (int, float)) and isinstance(s.get("max"), (int, float)):
        e["number_range"] = [s["min"], s["max"]]
    x = c.get("exact") or {}
    if wanted["values"] and "problem" not in x and x:
        e["wanted_values_counted_in_it"] = "%d of %d" % (len(x.get("found") or []), len(wanted["values"]))
    elif wanted["values"]:
        e["wanted_values_among_the_values_kept"] = "%d of %d" % (len(c["shared"]), len(wanted["values"]))
    return e


def ask_model(runner, run_id, cands, wanted):
    """One call per file that has candidates, at the same time. -> {(file, column): the model's reason}, notes, producers."""
    by_file = {}
    for c in cands:
        by_file.setdefault(c["sig"]["file"], []).append(c)
    jobs = [(name, by_file[name][:PER_FILE_FOR_MODEL]) for name in sorted(by_file)]
    instruction = prompts.load("column_match")

    def one(job):
        name, group = job
        listed = {c["sig"]["column"] for c in group}

        def standin():
            return {"choices": [], "none_of_these": False, "note": "no model is connected: the proposals below rest on what the program counted"}
        ctx = {"WANTED": {"column_named_by_the_rule": wanted["column"] or None, "expected_in_file": wanted["file"] or None,
                          "what_it_should_hold": wanted["description"] or None, "example_values": wanted["values_as_written"][:30] or None,
                          "where_the_examples_come_from": wanted["values_from"] or None},
               "FILE": name, "CANDIDATES": [_for_model(c, wanted) for c in group]}
        try:
            ans, producer, _ = runner.ask(run_id, "column_match_%s" % re.sub(r"[^A-Za-z0-9_.-]+", "_", name), instruction,
                                          json.dumps(ctx, ensure_ascii=False), SHAPE, "choices", standin)
        except Exception as e:      # noqa: BLE001 - one file without an answer must not lose the others'
            if str(e) == "the run was stopped":
                raise
            return {"file": name, "picked": {}, "dropped": [], "note": "", "problem": " ".join(str(e).split())[:200], "producer": ""}
        picked, dropped = {}, []
        for ch in ans.get("choices") if isinstance(ans.get("choices"), list) else []:
            col = str((ch or {}).get("column") or "").strip() if isinstance(ch, dict) else ""
            if not col:
                continue
            if col in listed:
                picked.setdefault(col, " ".join(str(ch.get("why") or "").split())[:300])
            else:
                dropped.append(col)            # a name that is not on the list: never shown as a proposal
        return {"file": name, "picked": picked, "dropped": dropped[:6], "note": " ".join(str(ans.get("note") or "").split())[:300],
                "none": bool(ans.get("none_of_these")) and not picked, "producer": producer}
    if not jobs:
        return {}, [], []
    with ThreadPoolExecutor(max_workers=max(1, min(len(jobs), getattr(runner, "CALLS_MOST", 8) or 8))) as pool:
        results = list(pool.map(one, jobs))
    picked = {(r["file"], col): why for r in results for col, why in r["picked"].items()}
    return picked, results, sorted({r["producer"] for r in results if r.get("producer")})


# ---------------------------------------------------------------------------------------------- the level, by code
def level_of(c, wanted):
    """(level or None, what speaks against it) for one candidate: decided from what was counted, never from the model."""
    s, against = c["sig"], []
    x = c.get("exact") or {}
    n_want = len(wanted["values"])
    counted = bool(n_want) and bool(x) and "problem" not in x
    found = len(x.get("found") or []) if counted else len(c["shared"])
    share = found / float(n_want) if n_want else 0.0
    chance = by_chance(wanted["values"], s) if n_want else ""
    second = bool(c["meaning_words"]) or c["name_alike"] >= NAME_ALIKE or c["strong_shape"]
    if n_want and found:
        if chance and not second:
            against.append("the shared values are not support by themselves: %s; nothing else (meaning, name or a telling shape) points to this column" % chance)
        elif chance:
            against.append("an inclusion of these values can be chance (%s); it counts here together with %s" % (
                chance, "the meaning" if c["meaning_words"] else "the name" if c["name_alike"] >= NAME_ALIKE else "the shape of the values"))
    out = outside_share(wanted["values"], s) if n_want else None
    wide = out is not None and out > OUTSIDE_MOST
    if wide and found:
        against.append("%d%% of this column's own number range (%s to %s) lies outside the range of the wanted values: it holds them and much else" % (
            round(100 * out), s.get("min"), s.get("max")))
    if n_want and found < n_want:
        missing = [v for v in wanted["values"] if v not in set((x.get("found") if counted else c["shared"]) or [])][:5]
        against.append("%d of the %d wanted values are not in it (for example %s)" % (n_want - found, n_want, ", ".join(missing)))
    if wanted["shape"] and s["shape"] and not c["same_shape"]:
        against.append("its values have another shape (%s) than the wanted ones (%s)" % (shape_words(s["shape"]), shape_words(wanted["shape"])))
    if x.get("problem"):
        against.append("the exact count could not be made: %s" % x["problem"])
    if n_want and share >= SHARE_NEEDED and (not chance or (second and not wide)) and (counted or s["known_is_all"]):
        return VALUES_MATCH, against
    if c["meaning_words"] and not (wanted["shape"] and s["shape"] and not c["same_shape"] and n_want and not found):
        return KIND_MATCH, against
    if c["strong_shape"] and n_want and found:
        return KIND_MATCH, against
    if c["name_alike"] >= NAME_ALIKE:
        return NAME_ONLY, against
    return None, against


def _card(c, wanted, level, against, why):
    s, x = c["sig"], c.get("exact") or {}
    n_want = len(wanted["values"])
    counted = bool(n_want) and bool(x) and "problem" not in x
    overlap = None
    if n_want:
        found = (x.get("found") if counted else c["shared"]) or []
        overlap = {"wanted_values": n_want, "found": len(found), "share_percent": round(100.0 * len(found) / n_want, 1),
                   "examples_found": [v for v in found[:5]],
                   "basis": ("counted in the file: %s records read%s" % ("{:,}".format(x.get("rows_read") or 0), " (the file is longer: only the first %s were read)" % "{:,}".format(x.get("rows_read") or 0) if x.get("capped") else "")
                             if counted else "among the values the Data Explorer kept of this column (%s)" % ("all of its values" if s["known_is_all"] else "its most frequent values, not all")),
                   "rows_holding_a_wanted_value": x.get("rows_holding") if counted else None,
                   "lines": x.get("lines") if counted else sorted({ln for v in found for ln in (s["known"].get(v) or {}).get("lines") or []})[:LINES_SHOWN]}
    return {"file": s["file"], "column": s["column"], "level": level,
            "meaning": s["meaning"] or "", "meaning_source": (s["source"] or s["meaning_status"]) if s["meaning"] else "",
            "what_the_data_explorer_counted": s["observed"], "rows_with_a_value": s["rows"], "distinct_values": s["distinct"],
            "shape": shape_words(s["shape"]), "same_shape_as_wanted": c["same_shape"] if wanted["shape"] else None,
            "some_values": [k["value"] for k in list(s["known"].values())[:6]],
            "overlap": overlap, "name_alike": c["name_alike"] >= NAME_ALIKE, "meaning_words_shared": c["meaning_words"],
            "against": against, "model_picked": why is not None, "model_reason": why or ""}


# ---------------------------------------------------------------------------------------------- the whole search
def propose(runner, run_id, files, column="", file="", description="", values=None, use_model=True, rows_most=ROWS_READ_MOST):
    """files: [{"name", "path", "dictionary"}]. -> {"wanted", "looked_at", "proposals" (ranked cards), "none", "answer",
    "set_aside" (looked at closely and not supported), "producer"}."""
    sigs, no_dict = signatures(files)
    wanted = wanted_of(column, file, description, values, sigs)
    if not (wanted["column"] or wanted["description"] or wanted["values"]):
        raise ValueError("say what is looked for: the name of the missing column, what it should hold, or some of its values")
    cands = shortlist(wanted, sigs)
    exact_counts(cands, wanted, rows_most)
    picked, results, producers = ask_model(runner, run_id, cands, wanted) if (use_model and cands) else ({}, [], [])
    proposals, aside = [], []
    for c in cands:
        level, against = level_of(c, wanted)
        why = picked.get((c["sig"]["file"], c["sig"]["column"]))
        card = _card(c, wanted, level, against, why)
        (proposals if level else aside).append(card)
    order = {lv: i for i, lv in enumerate(LEVELS)}
    proposals.sort(key=lambda p: (order[p["level"]], -int(p["model_picked"]), -((p["overlap"] or {}).get("share_percent") or 0), p["file"], p["column"]))
    strong = [p for p in proposals if p["level"] in (VALUES_MATCH, KIND_MATCH)]
    what = ('the column "%s"' % wanted["column"] if wanted["column"] else "this kind of data") + (' (%s)' % wanted["description"] if wanted["description"] and wanted["column"] else
                                                                                                      (": " + wanted["description"]) if wanted["description"] else "")
    looked = {"files": len(files) - len(no_dict), "files_without_a_dictionary": no_dict, "columns": len(sigs), "on_the_short_list": len(cands),
              "model_calls": len(results), "dropped_by_the_program": sorted({"%s (%s)" % (d, r["file"]) for r in results for d in r.get("dropped") or []})[:8],
              "model_notes": [("%s: %s" % (r["file"], r["note"])) for r in results if r.get("note")][:6],
              "model_problems": [("%s: %s" % (r["file"], r["problem"])) for r in results if r.get("problem")][:6]}
    if strong:
        answer = "%d column%s could stand for %s. Nothing is used until you choose." % (len(strong), "" if len(strong) == 1 else "s", what)
    else:
        need = ("a data dictionary is not approved yet for %s, so %s not looked at; " % (", ".join(no_dict), "it was" if len(no_dict) == 1 else "they were")) if no_dict else ""
        answer = ("No column of the %d file%s looked at holds %s: %d column%s compared, none with matching values or a matching meaning. %sA CSV file that holds this data "
                  "would be needed: put it into the folder and press Read the new files at the step after Family 1." % (
                      looked["files"], "" if looked["files"] == 1 else "s", what, len(sigs), "" if len(sigs) == 1 else "s", need))
        if proposals:
            answer += " %d column%s only alike by name: see below, not offered as a substitute." % (len(proposals), " is" if len(proposals) == 1 else "s are")
    return {"wanted": {k: wanted[k] for k in ("column", "file", "description", "values_from")} | {"values": wanted["values_as_written"], "shape": shape_words(wanted["shape"]) if wanted["shape"] else ""},
            "looked_at": looked, "proposals": proposals, "not_supported": aside[:10], "none": not strong, "answer": answer,
            "producer": "; ".join(producers) or "the program (no model call was needed)"}


def files_of_analysis(engine, project):
    """The files of an analysis with Family 1's dictionary of each, as propose() takes them."""
    folder = project.get("folder") or ""
    run = engine.store.one("SELECT * FROM run WHERE project=? AND kind='flow' ORDER BY id DESC LIMIT 1", (project["id"],))
    out = []
    for f in (admin_ask.files_now(engine, run["id"], folder) if run else [dict(x, state="new") for x in family1.inventory(folder)]):
        d = admin_ask._dictionary(engine, run["id"], f)[0] if run else None
        if d is None:
            d = family1.approved_dictionary(f["format_key"], f["name"])
        out.append({"name": f["name"], "path": f["path"], "dictionary": d})
    return out


def for_analysis(engine, project, column="", file="", description="", values=None):
    """The search for the pages: the analysis's files, the model through the application's runner."""
    files = files_of_analysis(engine, project)
    if not files:
        raise ValueError("the analysis's folder has no CSV file")
    return propose(engine.runner, "substitute_p%s" % project["id"], files, column, file, description, values)
