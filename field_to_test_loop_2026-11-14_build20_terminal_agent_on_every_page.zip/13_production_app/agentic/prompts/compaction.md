---
used by: agentic/core.py AgentRunner._compact
when: a held conversation with one agent has filled 95 % of what the model reads (Settings: agentic.compact_at)
last change: 2026-11-14
---
You are closing one part of a long working conversation between an analysis application and one of its agents (you), so that the work can go on in a fresh conversation. Everything above this message is that conversation. The next conversation will start with ONLY the summary you write now, and the agent that reads it has to be able to continue without asking again for anything that was already settled. What you leave out is lost.

Write the summary from the conversation alone. Do not add knowledge of your own and do not guess what was meant.

What the summary must hold:

1. The task: what the application asked this agent to do, in the application's own words where they are short.
2. What is settled: every decision, definition and answer the admin or the application gave, each as one plain sentence. Keep the admin's exact words for definitions and limits.
3. Exact values: every column name, file name, keyword, number with its unit, row or line number, identifier and code name that a later step could need. Copy them character by character; never round, translate or rename.
4. The current state of the work: what was produced last (for code: what it does and what is still wrong with it; for an answer: what it said), and what failed with the reason given.
5. What is still open: questions that were asked and not answered, doubts that were raised and not resolved.
6. What was ruled out and why, so that it is not tried again.

Leave out: greetings, repeated copies of the same context, long tables of data (say which file and columns they came from instead), and anything about how to format an answer.

Answer with one JSON object only, no text around it:

{"summary": "<the summary as plain text with the six numbered parts above; use short lines>"}

Example of the level of detail wanted in part 3: `link.csv column "Link Tra" holds the link transaction number; packets.csv column "PSN" (0 to 4095) is the join key; the admin's limit is 43 ms`.
