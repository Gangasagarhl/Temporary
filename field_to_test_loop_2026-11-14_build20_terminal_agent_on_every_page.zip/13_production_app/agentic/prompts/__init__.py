"""The agents' instructions as documents (owner, 2026-11-14: "you must have the proper well scripted documents in
order to create those things and then speak to the agent"). One Markdown file per agent in this folder; `load(name)`
gives its text. A document has the same parts in the same order: who you are, what you are given, what to do, what
never to do, the answer format with one example."""
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
_kept = {}


def path(name):
    return os.path.join(_HERE, name + ".md")


def _body(text):
    """The text the model is given: the file without its front matter (the lines between the first two `---` lines,
    which hold notes for people: who uses the document, when it changed, what was measured)."""
    if text.startswith("---"):
        end = text.find("\n---", 3)
        if end > 0:
            rest = text[end + 4:]
            return rest[rest.index("\n") + 1:] if "\n" in rest else ""
    return text


def load(name, **values):
    """The text of the prompt document `name` (read again when the file changed on disk). `values` fill `{{word}}`
    places; a place without a value stays as written."""
    p = path(name)
    stamp = os.stat(p).st_mtime_ns
    if _kept.get(name, (None, None))[0] != stamp:
        with open(p, encoding="utf-8") as fh:
            _kept[name] = (stamp, _body(fh.read()).strip())
    text = _kept[name][1]
    for k, v in values.items():
        text = text.replace("{{%s}}" % k, str(v))
    return text


def names():
    return sorted(f[:-3] for f in os.listdir(_HERE) if f.endswith(".md"))
