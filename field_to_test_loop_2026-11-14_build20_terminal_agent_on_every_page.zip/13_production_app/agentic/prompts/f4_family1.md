---
used by: agentic/family4.py ask_family1 (appended to admin_ask.MANAGER_INSTRUCTION, the instruction of a file's Manager)
last change: 2026-11-14
---
Here several kinds of data are asked for at once: CONTEXT "kinds" lists them, each with its number and its question. Answer each one separately, by the rules above, one entry per kind and in the order given.
