"""After Family 1: the admin's questions to all the Managers, the new files of the folder, and "go to stage 2" (owner, 2026-11-12).

The flow stops here after the last data dictionary. On the card of this step the admin can do three things:

  ask                 "is this kind of data present?" The Admin Agent puts the question to the Manager of every CSV file
                      at the same time. Each Manager answers from its own data dictionary: every column that holds a
                      value, its meaning, its keywords, with the counts the Data Explorer made on every row.
  read the new files  CSV files put into the folder since the flow read it get their three agents (Data Explorer, Data
                      Grounder, Manager). Only those: a file that was read is not read again. The flow then comes back
                      to this step.
  go to stage 2       Family 2 builds the tree with the fixed joining strategy (made for the analyzer's five exports).
                      Until the admin says so, the flow stays here.
  go on without it    stage 2 is a choice (owner, 2026-11-12: "the second stage is not needed for every input ... the
                      input CSV should be agnostic to any of the fixed coding strategies. That should be given as an
                      option to the admin"): Family 2's steps are skipped and the rules read the CSV files as they are.
                      The card says what stage 2 is needed for and whether these files can be built by the fixed strategy.

What keeps the answer right. A Manager only NAMES columns and keywords; the code then checks every name against the
dictionary. A name that is not in the data is dropped, the row counts and the line numbers are taken from the dictionary
and never from the model, and the code fixes the verdict:

  yes          at least one Manager said yes and at least one thing it named is in the data
  no           every CSV of the folder was read and every Manager said no
  cannot tell  anything else: a file not read yet, a Manager without an answer, names that were not in the data

What it cannot know: a dictionary keeps keywords and the most frequent values, not every number, address or id, so a
question about one exact number is answered only as far as "that column holds values". The answer says so.
"""
import json
import os
import re
import time
from concurrent.futures import ThreadPoolExecutor

from . import core, family1

GATE = "f1_gate"         # the key of the step (no ":" in it: the page lists keys with ":" as files)
PART_CHARS = 90000       # characters of dictionary given to one Manager call at most; a larger dictionary is asked in several
                         # calls, so that no column is left out of the question
MATCHES_ASKED = 12       # columns and keywords one Manager call may name
MATCHES_SHOWN = 6        # ... and how many of one file the answer's table shows (how many more there are is said)
MEANINGS_SHOWN = 40      # keywords of a column that go to the Manager with their meaning (the others: name and count)
STATE_WORDS = {"read": "read in this flow", "reused": "approved before: used again, not read again",
               "reading": "its agents have not finished", "new": "new in the folder: not read yet"}

MANAGER_INSTRUCTION = """You are the Manager of one CSV file of a recording. The admin asks whether a kind of data is present in
the recording. CONTEXT holds the question and your data dictionary of this file ("columns"): every column that holds a
value, with "rows" (the rows that hold a value) and "meaning"; a column of keywords lists each one as
[keyword, rows that hold it, meaning]; another column may list "values" or "most_frequent_values" as [value, rows].
All counts were made by code on every row. "named_in_the_question" is what the code found of the question's own words.

Answer from CONTEXT alone:
- "present": "yes" when at least one column or keyword of CONTEXT is the kind of data the admin asks for. "no" when
  nothing in CONTEXT is that kind of data. "cannot_tell" only when a column of CONTEXT is the very place where this file
  records that kind of data by name, number, address or id, and the answer depends on values of that column that
  CONTEXT does not list one by one (the admin asks for one exact number, address or id).
- A column of raw payload bytes, or of sizes and counts, is not such a place: this file does not show there what the
  bytes mean. When such a column is the only reason for doubt, answer "no" and say in "could_not_check" that the payload
  bytes are not decoded in this file.
- "matches": the columns and keywords that ARE that kind of data, the most direct first, at most %d. Copy "column" and
  "keyword" letter for letter from CONTEXT; leave "keyword" empty when the whole column is the match. Give no match
  when the answer is "no".
- Never name a column or a keyword that CONTEXT does not hold, and never write a count: the code checks every name
  against the data and adds the counts itself.
- "could_not_check": the part of the question CONTEXT cannot answer, in one short sentence without numbers, or "".
A word that only looks alike is not a match: the meaning must fit what the admin asks.""" % MATCHES_ASKED
MANAGER_SHAPE = '{"present": "yes|no|cannot_tell", "matches": [{"column": "...", "keyword": "..."}], "could_not_check": "..."}'


def gate_step():
    return {"key": GATE, "title": "Admin Agent: your questions to all the Managers; then stage 2, or not", "family": "1",
            "agent": "Admin Agent", "review": True}


def _load(path):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError, TypeError):
        return None


def _plain(f):
    return {k: v for k, v in f.items() if k != "state"}


def _n(x):
    return "{:,}".format(x) if isinstance(x, int) and not isinstance(x, bool) else "not counted"


def _day(t):
    return time.strftime("%Y-%m-%d %H:%M", time.localtime(t)) if isinstance(t, (int, float)) and t else "date not recorded"


# ---------------------------------------------------------------------------------------------- the folder, as it is now
def files_now(engine, run_id, folder):
    """Every CSV of the folder as it is now, with what this flow knows of each one ("state"):
    read     its Manager's dictionary was made in this flow
    reused   the dictionary approved before was used again (its three agents were skipped)
    reading  its agents have not finished
    new      in the folder, and no agent of this flow has read it"""
    steps = {s["key"]: s for s in engine.store.all("SELECT key, state FROM step WHERE run=?", (run_id,))}
    out = []
    for f in family1.inventory(folder):
        m = steps.get("manager:" + f["name"])
        state = "new" if m is None else "read" if m["state"] in ("approved", "done") else "reused" if m["state"] == "skipped" else "reading"
        out.append(dict(f, state=state))
    return out


def _dictionary(engine, run_id, f):
    """The data dictionary a file's Manager answers from -> (dictionary or None, where it comes from in words)."""
    kept = family1.approved_dictionary(f["format_key"], f["name"])
    if f["state"] == "read":
        s = engine.store.one("SELECT output FROM step WHERE run=? AND key=?", (run_id, "manager:" + f["name"]))
        mine = _load((core.jload((s or {}).get("output"), {}) or {}).get("dictionary_file") or "")
        if mine:
            # the approved copy of the same dictionary holds the meanings the admin corrected when approving
            return (kept if kept and kept.get("made") == mine.get("made") else mine), "read in this flow"
    if kept and f["state"] in ("read", "reused"):
        other = "" if not kept.get("path") or kept.get("path") == f.get("path") else "; that dictionary was made from %s" % kept["path"]
        return kept, "not read again in this flow: the counts are those of the dictionary approved before (version %s, %s)%s" % (
            kept.get("version") or "?", _day(kept.get("approved_at")), other)
    return None, ""


def _lines(where):
    """'… line 6, 19, 100' -> 'lines 6, 19, 100' (the line numbers of the CSV file; line 1 is the header)."""
    m = re.search(r" line ([\d, ]+)$", str(where or ""))
    if not m:
        return ""
    return ("lines " if "," in m.group(1) else "line ") + m.group(1).strip()


def _index(d):
    """A dictionary as the code checks names against it: each column that holds a value, its keywords with their counts
    and lines, and (for a column without keywords) the most frequent values the Data Explorer kept."""
    path = d.get("path")
    top = {}
    for c in (_load(d.get("explorer_memory") or "") or {}).get("columns") or []:
        if isinstance(c, dict) and c.get("column"):
            top[str(c["column"])] = [t for t in c.get("top_values") or [] if isinstance(t, dict) and t.get("value") not in (None, "")]
    cols = {}
    for c in d.get("columns") or []:
        if not isinstance(c, dict) or not c.get("column") or not c.get("rows_with_value"):
            continue
        name = str(c["column"])
        kws = {}
        for k in c.get("keywords") or []:
            if isinstance(k, dict) and k.get("value") not in (None, ""):
                kws[str(k["value"]).strip().lower()] = {"value": str(k["value"]), "rows": k.get("count"), "meaning": str(k.get("meaning") or ""),
                                                        "lines": _lines(k.get("where") or family1.where(path, k.get("rows") or [])), "kind": "keyword"}
        vals = {}
        for t in top.get(name, []):
            key = str(t["value"]).strip().lower()
            if key not in kws:
                vals[key] = {"value": str(t["value"]), "rows": t.get("count"), "meaning": "",
                             "lines": _lines(family1.where(path, t.get("rows") or [])), "kind": "value"}
        cols[name.strip().lower()] = {"column": name, "rows": c["rows_with_value"], "distinct": c.get("distinct"),
                                      "meaning": str(c.get("meaning") or ""), "observed": str(c.get("observed") or ""),
                                      "lines": _lines(c.get("where")), "keywords": kws, "values": vals}
    return cols


def _for_model(col):
    e = {"column": col["column"], "rows": col["rows"], "meaning": (col["meaning"] or col["observed"])[:220]}
    if col["keywords"]:
        ks = sorted(col["keywords"].values(), key=lambda k: -(k["rows"] or 0))
        e["keywords"] = [[k["value"], k["rows"]] + ([k["meaning"][:70]] if i < MEANINGS_SHOWN and k["meaning"] else []) for i, k in enumerate(ks)]
    elif col["values"]:
        whole = isinstance(col["distinct"], int) and col["distinct"] <= len(col["values"])
        e["values" if whole else "most_frequent_values"] = [[v["value"], v["rows"]] for v in col["values"].values()]
    return e


def _parts(entries, most=PART_CHARS):
    """The columns in as few parts as fit one call each: every column is in exactly one part."""
    parts, cur, size = [], [], 0
    for e in entries:
        n = len(json.dumps(e, ensure_ascii=False)) + 2
        if cur and size + n > most:
            parts.append(cur)
            cur, size = [], 0
        cur.append(e)
        size += n
    if cur:
        parts.append(cur)
    return parts


def _word(needle, hay):
    return re.search(r"(?<![a-z0-9])%s(?![a-z0-9])" % re.escape(needle), hay) is not None


def _named(index, question):
    """Code first: the columns and keywords that the question names with their own words."""
    q = str(question).lower()
    hits = []
    for col in index.values():
        name = col["column"].lower()
        short = name.partition(".")[2]
        if (len(name) >= 3 and _word(name, q)) or (len(short) >= 3 and _word(short, q)):
            hits.append({"column": col["column"], "keyword": ""})
        for k in list(col["keywords"].values()) + list(col["values"].values()):
            v = k["value"].strip().lower()
            if len(v) >= 3 and v not in family1.FLAG_WORDS and not re.fullmatch(r"[\d.,:x\- ]+", v) and _word(v, q):
                hits.append({"column": col["column"], "keyword": k["value"]})
    return hits[:20]


# ---------------------------------------------------------------------------------------------- one Manager, checked by code
def _numbers(text):
    """The words of a text that hold a digit ("4096", "0x1f400", "x4"), lower-cased."""
    return set(re.findall(r"[0-9a-z]*\d[0-9a-z]*", str(text or "").lower()))


def _check(ans, index, question=""):
    """A Manager's answer against its dictionary -> (what it said, the names that are in the data with the dictionary's
    own counts and lines, the names that are not in the data, what it could not check)."""
    ans = ans if isinstance(ans, dict) else {}
    said = str(ans.get("present") or "").strip().lower().replace(" ", "_")
    if said not in ("yes", "no", "cannot_tell"):
        said = "cannot_tell"
    ok, dropped, seen = [], [], set()
    for m in (ans.get("matches") if isinstance(ans.get("matches"), list) else [])[:MATCHES_ASKED * 2]:
        if not isinstance(m, dict):
            continue
        cname, kname = str(m.get("column") or "").strip(), str(m.get("keyword") or "").strip()
        col = index.get(cname.lower())
        if col is None:
            dropped.append(("%s = %s" % (cname, kname)) if kname else cname or "(no name)")
            continue
        if kname:
            k = col["keywords"].get(kname.lower()) or col["values"].get(kname.lower())
            if k is None:
                dropped.append("%s = %s" % (col["column"], kname))
                continue
            item = {"column": col["column"], "keyword": k["value"], "rows": k["rows"], "lines": k["lines"], "kind": k["kind"],
                    "meaning": k["meaning"] or col["meaning"]}
        else:
            item = {"column": col["column"], "keyword": "", "rows": col["rows"], "lines": col["lines"], "kind": "column",
                    "meaning": col["meaning"] or col["observed"]}
        if (item["column"], item["keyword"]) in seen:
            continue
        seen.add((item["column"], item["keyword"]))
        ok.append(item)
    note = " ".join(str(ans.get("could_not_check") or "").split())[:240]
    if _numbers(note) - _numbers(question):
        # a number in a free sentence cannot be checked: the sentence is not shown (None: there was one). A number that
        # the admin's own question holds is not a new one, and stays
        note = None
    return said, ok, dropped, note


def _settle(r):
    """One file's verdict from its Manager's calls (a large dictionary is asked in several)."""
    said, matches, dropped, notes, problems, seen = [], [], [], [], [], set()
    for p in r["parts"]:
        if p.get("problem"):
            problems.append(p["problem"])
            continue
        s, ok, bad, note = _check(p.get("answer"), r["index"], r.get("question"))
        said.append(s)
        dropped += bad
        if note is None:
            r["sentence_not_shown"] = True
        if note and note not in notes:
            notes.append(note)
        if s == "yes":
            for m in ok:
                if (m["column"], m["keyword"]) not in seen:
                    seen.add((m["column"], m["keyword"]))
                    matches.append(m)
    r["present"] = "yes" if matches else "no" if said and not problems and all(s == "no" for s in said) else "cannot_tell"
    r["matches"], r["dropped"], r["notes"], r["problems"] = matches, dropped, notes, problems
    r["said_yes_named_nothing_real"] = "yes" in said and not matches
    return r


def _cell(text, most=150):
    t = " ".join(str(text or "").split()).replace("|", "/")
    return (t[:most - 1] + "…") if len(t) > most else t


# ---------------------------------------------------------------------------------------------- the Admin Agent asks them all
def ask_all(engine, review, step, question, history):
    """The admin's question, put to the Manager of every CSV file of the folder at the same time
    -> (the answer in words with its table, who answered)."""
    run_id = review["run"]
    project = engine.store.one("SELECT p.* FROM project p JOIN run r ON r.project = p.id WHERE r.id=?", (run_id,)) or {}
    folder = project.get("folder")
    runner = engine.runner
    earlier = [str(h.get("text") or "")[:300] for h in (history or [])[:-1] if str(h.get("role") or "").startswith("admin:")][-4:]
    results, jobs = [], []
    for f in files_now(engine, run_id, folder):
        d, basis = _dictionary(engine, run_id, f) if f["state"] in ("read", "reused") else (None, "")
        r = {"file": f["name"], "what": f.get("level_label"), "state": f["state"], "basis": basis, "index": _index(d) if d else None, "parts": [],
             "question": question}
        results.append(r)
        if r["index"] is None:
            continue
        named = _named(r["index"], question)
        parts = _parts([_for_model(c) for c in r["index"].values()]) or [[]]
        for i, part in enumerate(parts):
            jobs.append((r, i, len(parts), part, named))

    def one(job):
        r, i, n, part, named = job
        here = {c["column"] for c in part}
        mine = [m for m in named if m["column"] in here]

        def standin():
            return {"present": "yes" if mine else "cannot_tell", "matches": mine[:MATCHES_ASKED],
                    "could_not_check": "" if mine else "no model is connected: only the question's own words were looked up among the column names and keywords"}
        ctx = {"question": question, "file": r["file"], "what_the_file_is": r["what"], "part_of_the_dictionary": "%d of %d" % (i + 1, n),
               "earlier_questions_of_the_admin": earlier, "named_in_the_question": mine, "columns": part}
        try:
            ans, producer, _ = runner.ask(run_id, "admin_asks_%s_%d" % (r["file"], i + 1), MANAGER_INSTRUCTION,
                                          json.dumps(ctx, ensure_ascii=False), MANAGER_SHAPE, "present", standin)
            return {"answer": ans, "producer": producer}
        except Exception as e:      # noqa: BLE001 - one Manager without an answer must not lose the others' answers
            return {"problem": " ".join(("%s: %s" % (type(e).__name__, e)).split())[:200]}
    if jobs:
        with ThreadPoolExecutor(max_workers=max(1, min(len(jobs), getattr(runner, "CALLS_MOST", 8) or 8))) as pool:
            for job, out in zip(jobs, pool.map(one, jobs)):
                job[0]["parts"].append(out)
    for r in results:
        if r["index"] is not None:
            _settle(r)
    return answer_text(folder, results), "Admin Agent"


def verdict_of(results):
    asked = [r for r in results if r["index"] is not None]
    unread = [r for r in results if r["index"] is None]
    if any(r["present"] == "yes" for r in asked):
        return "yes"
    if asked and not unread and all(r["present"] == "no" for r in asked):
        return "no"
    return "cannot_tell"


def answer_text(folder, results):
    """The Admin Agent's answer: the verdict, one table over all files, what it rests on and what could not be checked.
    Every number in it comes from the dictionaries."""
    asked = [r for r in results if r["index"] is not None]
    unread = [r for r in results if r["index"] is None]
    yes = [r for r in asked if r["present"] == "yes"]
    calls = sum(len(r["parts"]) for r in asked)
    standin = bool(asked) and all(str(p.get("producer") or "").lower().startswith("stand-in") for r in asked for p in r["parts"] if not p.get("problem")) \
        and any(not p.get("problem") for r in asked for p in r["parts"])
    files = lambda n: "%d file%s" % (n, "" if n == 1 else "s")      # noqa: E731
    v = verdict_of(results)
    if not results:
        return "**Cannot tell.** The folder %s holds no CSV file now." % (folder or "(no folder)")
    if not asked:
        head = "**Cannot tell.** No file of the folder has a data dictionary yet, so there is no Manager to ask."
    elif v == "yes":
        head = "**Yes, present.** Found in %d of the %s that were asked: %s." % (len(yes), files(len(asked)), ", ".join(r["file"] for r in yes))
    elif v == "no":
        head = "**No, not found.** None of the %s of the folder holds it, as far as the data dictionaries show." % files(len(asked))
    elif asked and all(r["present"] == "no" for r in asked):
        head = "**Cannot tell for the whole folder.** Not found in the %s that were read, but %s of the folder %s not read yet: %s." % (
            files(len(asked)), files(len(unread)), "was" if len(unread) == 1 else "were", ", ".join(r["file"] for r in unread))
    else:
        no = [r for r in asked if r["present"] == "no"]
        open_ = [r for r in asked if r["present"] != "no"]
        head = "**Cannot tell.** No Manager found it. %s; %s: %s. Why is said below the table." % (
            "%d of the %s that were asked %s no (%s)" % (len(no), files(len(asked)), "says" if len(no) == 1 else "say", ", ".join(r["file"] for r in no)) if no
            else "None of the %s that were asked says no" % files(len(asked)),
            "%s cannot rule it out" % files(len(open_)), ", ".join(r["file"] for r in open_))
    out = [head, ""]
    if asked:
        out += ["The Admin Agent put the question to the Manager%s of %s at the same time (%d call%s)." % (
            "" if len(asked) == 1 else "s", files(len(asked)), calls, "" if calls == 1 else "s"), ""]
    out += ["| file | present? | found as (column = keyword) | what it means, from the data dictionary | rows that hold it | where to see it |", "|---|---|---|---|---|---|"]
    said = {"yes": "yes", "no": "no", "cannot_tell": "cannot tell"}
    for r in results:
        if r["index"] is None:
            out.append("| %s | not asked | %s | | | |" % (_cell(r["file"]), STATE_WORDS.get(r["state"], r["state"])))
            continue
        if not r["matches"]:
            out.append("| %s | %s | nothing | | | |" % (_cell(r["file"]), said[r["present"]]))
            continue
        for i, m in enumerate(r["matches"][:MATCHES_SHOWN]):
            name = ("%s = %s" % (m["column"], m["keyword"])) if m["keyword"] else "%s (the whole column)" % m["column"]
            out.append("| %s | %s | %s | %s | %s | %s |" % (_cell(r["file"]) if i == 0 else "", "yes" if i == 0 else "", _cell(name), _cell(m["meaning"]) or "no meaning in the dictionary",
                                                          (_n(m["rows"]) + " rows") if isinstance(m["rows"], int) else "not counted", m["lines"] or "not kept"))
        if len(r["matches"]) > MATCHES_SHOWN:
            out.append("| | | and %d more columns or keywords of this file | | | |" % (len(r["matches"]) - MATCHES_SHOWN))
    out += ["", "**What this rests on**", ""]
    if asked:
        out += ["- Every column and keyword in the table is in the data: the code checked each name against the file's data dictionary. The row counts and the line numbers are the Data Explorer's, counted on every row; none comes from the model.",
                "- That a column or keyword is the kind of data you asked for is the Manager's reading of its meaning. The meaning is shown so that you can judge it yourself.",
                "- Line numbers are lines of the CSV file as a text editor counts them (line 1 is the header). The files are in %s." % folder]
    if standin:
        out.append("- No model is connected (stand-in): only the question's own words were looked up among the column names and keywords.")
    notes = []
    dropped = [(r["file"], x) for r in asked for x in r["dropped"]]
    if dropped:
        notes.append("%d name%s a Manager gave %s not in its file and %s dropped: %s." % (
            len(dropped), "" if len(dropped) == 1 else "s", "was" if len(dropped) == 1 else "were", "was" if len(dropped) == 1 else "were",
            "; ".join("%s (%s)" % (_cell(x, 80), f) for f, x in dropped[:8]) + (" and %d more" % (len(dropped) - 8) if len(dropped) > 8 else "")))
    for r in asked:
        if r["said_yes_named_nothing_real"]:
            notes.append("%s: its Manager said yes but named nothing that is in the file, so this file counts as cannot tell." % r["file"])
        for p in r["problems"]:
            notes.append("%s: its Manager gave no answer (%s). Ask again." % (r["file"], _cell(p, 160)))
        for n in r["notes"]:
            notes.append("%s, in its Manager's words: %s" % (r["file"], _cell(n, 240)))
        if r.get("sentence_not_shown"):
            notes.append("%s: its Manager also gave a reason in a sentence with a number in it that is not in your question. The code cannot check a number in a free sentence, so that sentence is not shown." % r["file"])
        if r["state"] == "reused" or (r["basis"] and r["basis"] != "read in this flow"):
            notes.append("%s was %s." % (r["file"], r["basis"]))
    for r in unread:
        notes.append("%s has no Manager: %s." % (r["file"], STATE_WORDS.get(r["state"], r["state"])))
    if asked:
        notes.append("A data dictionary keeps keywords and the most frequent values, not every number, address or id. A question about one exact number is answered only as far as “that column holds values”.")
    out += ["", "**What could not be checked**", ""] + ["- " + n for n in notes]
    if v != "yes":
        out += ["", "If the data is in another CSV file: put that file into the folder %s and press **Read the new files**. Only the new file gets its three agents; then ask again." % folder]
    return "\n".join(out)


# ---------------------------------------------------------------------------------------------- the REA findings: only when asked for
# (owner, 2026-11-14: "Family 2 takes its join evidence from that agent, this should not be the required, but it can be
# optional, since the second step is also optional") Family 2's Coder quotes the REA findings only when the admin ticked
# the box at this step; without the tick (and in every flow that never came through this step) it works without them.
def rea_facts(project):
    """Where the REA findings of this analysis stand, for the card: {"usable", "folder", "why"}. Nothing is read here."""
    from . import rea_agent as RA
    folder = (project or {}).get("rea") or ""
    if not folder:
        return {"usable": False, "folder": "", "why": "no folder with REA findings was given for this analysis (the field on the start page)"}
    if not os.path.isdir(folder):
        return {"usable": False, "folder": folder, "why": "the folder given for the REA findings does not exist any more (%s)" % folder}
    if not RA.is_read(folder):
        return {"usable": False, "folder": folder, "why": "the REA findings in %s have not been read yet (the REA agent on the start page reads them: Read the findings)" % folder}
    return {"usable": True, "folder": folder, "why": ""}


def rea_lines(f):
    """The facts of rea_facts as the card says them."""
    if f["usable"]:
        return ["", "**The REA findings (optional).** Findings of the analyzer's decompiled code are kept with this analysis and were read (%s). Family 2 does not need them. "
                "Tick the box below only if its Coder should also quote them as evidence for the joins; without the tick they are not looked at." % f["folder"]]
    return ["", "**The REA findings (optional).** Family 2 does not need them and goes on without: %s." % f["why"]]


def rea_wanted(gate_output):
    """True when the admin ticked the box at the step before stage 2 (the gate step's output)."""
    return bool(isinstance(gate_output, dict) and gate_output.get("use_rea"))


# ---------------------------------------------------------------------------------------------- stage 2: needed or not
FIVE = ["packets", "link", "split", "nvme_transaction", "nvme_command"]


def stage2_facts(engine, run, project):
    """What the admin needs to decide whether stage 2 (the tree) is built, counted by code:
    which of the analyzer's five exports the folder holds, whether the fixed joining strategy can build them (and why
    not), how many items of the rules library read the tree, and whether a tree of these same files exists already."""
    from . import family2, family3, source_tools
    from nvme_hier import columns as C
    files = files_now(engine, run["id"], project.get("folder"))
    have = {f["level"]: f["name"] for f in files if f.get("level")}
    problem = family1.folder_problem([_plain(f) for f in files]) if files else "the folder holds no CSV file"
    if not problem:
        problem = source_tools.no_hierarchy_reason(project) or None
    reads_tree, one_file, no_proc = [], [], []
    try:
        for sec in family3.tree():
            for lv in sec["levels"]:
                for it in lv["items"]:
                    r = family3.load_rule(sec["section"], lv["level"], it["id"]) or {}
                    from . import procedures as PR
                    (reads_tree if family3.needs_tree(r) else one_file if PR.procedure_of(r) else no_proc).append(it["name"])
    except Exception:                   # noqa: BLE001 - the rules library is a fact for the card, not a condition of the step
        pass
    built = None
    try:
        levels = {f["level"]: f["path"] for f in files if f.get("level")}
        if levels and not problem and engine.services is not None:
            up, m = family2.find_built_tree(engine.services, levels, None, any_settings=True)
            if up:
                built = {"upload_id": up, "at": (m or {}).get("loaded_at") or (m or {}).get("created")}
    except Exception:                   # noqa: BLE001 - as above
        built = None
    return {"fixed_possible": not problem, "fixed_problem": problem or "",
            "levels_here": [{"level": lv, "label": C.LEVEL_LABEL.get(lv, lv), "file": have[lv]} for lv in FIVE if lv in have],
            "levels_missing": [C.LEVEL_LABEL.get(lv, lv) for lv in FIVE if lv not in have],
            "other_files": [f["name"] for f in files if not f.get("level")],
            "rules": {"read_the_tree": reads_tree, "read_one_file": one_file, "no_procedure_yet": no_proc}, "built_before": built}


def stage2_lines(f):
    """The facts of stage2_facts as the card says them."""
    n_tree, n_file, n_none = (len(f["rules"][k]) for k in ("read_the_tree", "read_one_file", "no_procedure_yet"))
    out = ["**Stage 2 (one tree from the files): needed or not? You choose.**", "",
           "- **What it is.** The fixed joining strategy connects the analyzer's five exports (packets, link transactions, split transactions, NVMe transactions, NVMe commands) into one tree. It was written for those five files; it is an option, not a condition: any CSV file can be analysed without it.",
           "- **Needed when** a rule looks at more than one of these files at once (a command and the packets under it), for the error rules of the detector, and for the isolation of a defect (stage 1 and stage 2 of an error walk the tree).",
           "- **Not needed when** the rules read one file only. They then read the CSV files as they are."]
    if f["levels_here"]:
        out.append("- **In this folder:** %d of the five exports (%s)%s%s." % (
            len(f["levels_here"]), ", ".join("%s: %s" % (x["label"], x["file"]) for x in f["levels_here"]),
            "; not here: %s" % ", ".join(f["levels_missing"]) if f["levels_missing"] else "",
            "; and %d other CSV file%s (%s), which the tree does not hold" % (len(f["other_files"]), "" if len(f["other_files"]) == 1 else "s", ", ".join(f["other_files"])) if f["other_files"] else ""))
    else:
        out.append("- **In this folder:** none of the analyzer's five exports%s." % (" (%s)" % ", ".join(f["other_files"]) if f["other_files"] else ""))
    out.append("- **The fixed joining strategy** %s" % ("can build these files into a tree." if f["fixed_possible"] else "cannot build these files: %s." % f["fixed_problem"].rstrip(".")))
    if f["built_before"]:
        out.append("- **A tree of these same files was built before** (on %s): going to stage 2 uses it again; nothing is built twice." % _day(f["built_before"]["at"]))
    out.append("- **The rules library** (counted now): %d item%s read%s the tree, %d read%s one file, %d %s no procedure yet (the Rule writer writes it for what this analysis has)." % (
        n_tree, "" if n_tree == 1 else "s", "s" if n_tree == 1 else "", n_file, "s" if n_file == 1 else "", n_none, "has" if n_none == 1 else "have"))
    out.append("- **You can come back.** Without stage 2 now, the analysis can be opened again at stage 2 later; nothing computed is computed again.")
    return out


# ---------------------------------------------------------------------------------------------- the step of the flow
def run_gate(ctx):
    """The step after Family 1: what was read, and the admin's three choices (ask, read the new files, go to stage 2)."""
    folder = ctx.project.get("folder")
    listed = []
    for f in files_now(ctx.engine, ctx.run["id"], folder):
        d = _dictionary(ctx.engine, ctx.run["id"], f)[0] if f["state"] in ("read", "reused") else None
        listed.append({"name": f["name"], "what": f.get("level_label"), "state": f["state"], "rows": (d or {}).get("rows"),
                       "columns_holding_a_value": len([c for c in (d or {}).get("columns") or [] if isinstance(c, dict)]) if d else None})
    known = [x for x in listed if x["state"] in ("read", "reused")]
    new = [x["name"] for x in listed if x["state"] == "new"]
    admin = ctx.project.get("admin") or "admin"
    body = ["**Admin %s, your word is needed.** Family 1 has finished: %d of the %d CSV file%s in the folder %s a data dictionary." % (
        admin, len(known), len(listed), "" if len(listed) == 1 else "s", "has" if len(known) == 1 else "have"), "",
        "| file | what it is | rows | columns that hold a value | data dictionary |", "|---|---|---|---|---|"]
    body += ["| %s | %s | %s | %s | %s |" % (_cell(x["name"]), _cell(x["what"]), _n(x["rows"]) if x["rows"] is not None else "",
                                           x["columns_holding_a_value"] if x["columns_holding_a_value"] is not None else "", STATE_WORDS.get(x["state"], x["state"])) for x in listed]
    if new:
        body += ["", "**%d CSV file%s in the folder %s not read yet: %s.** Press **Read the new files** to give %s the three agents." % (
            len(new), "" if len(new) == 1 else "s", "was" if len(new) == 1 else "were", ", ".join(new), "it" if len(new) == 1 else "them")]
    body += ["", "**Ask about the data.** Write in the box below what you look for, for example whether a kind of data is present. The Admin Agent puts the question to the Manager of every file at the same time and answers yes, present, or no, not found, with the columns, keywords, row counts and lines it rests on.",
             "", "**If it is not there**, put the CSV file that holds it into the folder %s and press **Read the new files**. Only the files that were not read get the three agents (Data Explorer, Data Grounder, Manager); the files already read are not read again. Afterwards the flow comes back to this question." % folder, ""]
    s2 = stage2_facts(ctx.engine, ctx.run, ctx.project)
    body += stage2_lines(s2)
    rea = rea_facts(ctx.project)
    if s2["fixed_possible"]:
        body += rea_lines(rea)
    body += ["", "Press **Go to stage 2** to build the tree with the fixed joining strategy%s, or **Go on without stage 2**. Until you choose, the flow stays here." % (
        "" if s2["fixed_possible"] else " (not possible for these files, see above)")]
    # "csvs", not "files": on a card "files" are export files to open
    return core.Result({"csvs": listed, "new": new, "stage2_facts": s2},
                       review={"title": "Ask about the data. Then: go to stage 2, or not?", "body": "\n".join(body),
                               "data": {"gate": True, "folder": folder, "csvs": listed, "new": new, "stage2": s2, "rea": rea}})


def read_new(engine, run, step, admin):
    """"Read the new files": the CSV files of the folder that this flow has not read get their three agents, placed before
    this step, so the flow reads them and comes back here. Files already read are not touched. -> the new files' names.
    ValueError (the card stays open and shows it) when there is nothing new, or when the new file would make the folder
    hold two recordings."""
    project = engine.store.one("SELECT * FROM project WHERE id=?", (run["project"],)) or {}
    folder = project.get("folder")
    files = files_now(engine, run["id"], folder)
    new = [f for f in files if f["state"] == "new"]
    if not new:
        raise ValueError("no new CSV file in the folder %s: it holds only the %d file%s this flow already knows (%s). Put the new CSV file into this folder, then press Read the new files again" % (
            folder, len(files), "" if len(files) == 1 else "s", ", ".join(f["name"] for f in files) or "none"))
    problem = family1.input_problem([_plain(f) for f in files])
    if problem:
        raise ValueError("nothing was read: %s" % problem)
    plan = []
    for f in new:
        plan += family1.file_steps(_plain(f))
    engine.insert_steps(run["id"], step["idx"] - 1, plan)          # before this step: it is asked again after them
    d = engine.store.one("SELECT id, output FROM step WHERE run=? AND key='director'", (run["id"],))
    if d:                                                           # the list the first step made, kept true
        out = core.jload(d["output"], {}) or {}
        out["files"] = [_plain(f) for f in files]
        engine.store.exec("UPDATE step SET output=? WHERE id=?", (json.dumps(out), d["id"]))
    return [f["name"] for f in new]


F2_SKIP_NOTE = "not built: the admin went on without stage 2 (the tree)"


def before_stage_2(engine, run, step, admin, edits=None):
    """The admin's word at the step after Family 1: edits["stage2"] is "fixed" (go to stage 2: the tree by the fixed joining
    strategy) or "skip" (go on without the tree: Family 2's steps are skipped). With "fixed", edits["use_rea"] true means
    Family 2's Coder may quote the REA findings (optional; refused with the reason when they are not there or not read). A request that says neither means "fixed"
    when these files can be built, and is refused with the reason when they cannot. ValueError keeps the card open.

    "fixed" is refused while an analyzer export put into the folder is not read (Family 2 would join a file that no data
    expert has looked at) and when the fixed strategy cannot build these files. In an analysis opened again, Family 2's
    steps that already ran are kept when the tree they built is still the tree of these files; otherwise they run again."""
    project = engine.store.one("SELECT * FROM project WHERE id=?", (run["project"],)) or {}
    choice = (edits or {}).get("stage2") if isinstance(edits, dict) else None
    if choice not in (None, "", "fixed", "skip"):
        raise ValueError("say whether stage 2 is needed: go to stage 2, or go on without it")
    facts = stage2_facts(engine, run, project)
    if choice in (None, ""):
        if not facts["fixed_possible"]:
            raise ValueError("the fixed joining strategy cannot build these files into a tree: %s. Press Go on without stage 2" % facts["fixed_problem"].rstrip("."))
        choice = "fixed"
    out = core.jload(step.get("output"), {}) or {}
    f2 = engine.store.all("SELECT id, key, state, note FROM step WHERE run=? AND family='2' ORDER BY idx", (run["id"],))
    if choice == "skip":
        for s in f2:
            if s["state"] in ("waiting", "failed", "stopped", "rejected"):
                engine.store.exec("UPDATE step SET state='skipped', note=?, finished=? WHERE id=?", (F2_SKIP_NOTE, time.time(), s["id"]))
        engine.store.exec("UPDATE step SET output=? WHERE id=?", (json.dumps(dict(out, stage2="skipped", stage2_by=admin, stage2_at=time.time())), step["id"]))
        return
    if not facts["fixed_possible"]:
        raise ValueError("the fixed joining strategy cannot build these files into a tree: %s. Go on without stage 2, or put the analyzer's exports into the folder and press Read the new files" % facts["fixed_problem"].rstrip("."))
    unread = [f for f in files_now(engine, run["id"], project.get("folder")) if f["state"] == "new" and f["level"]]
    if unread:
        raise ValueError("%s in the folder %s not read yet: %s. Press Read the new files first, or take %s out of the folder" % (
            "an analyzer file" if len(unread) == 1 else "%d analyzer files" % len(unread), "was" if len(unread) == 1 else "were",
            ", ".join("%s (%s)" % (f["name"], f["level_label"]) for f in unread), "it" if len(unread) == 1 else "them"))
    # an analysis opened again: what Family 2 built is kept only while it is the tree of these same files
    ran = [s for s in f2 if s["state"] in ("done", "approved")]
    skipped_by_choice = [s for s in f2 if s["state"] == "skipped" and (s.get("note") or "") == F2_SKIP_NOTE]
    stale = False
    if ran:
        b = next((s for s in f2 if s["key"] == "build"), None)
        built = core.jload((engine.store.one("SELECT output FROM step WHERE id=?", (b["id"],)) or {}).get("output"), {}) if b else {}
        stale = not built.get("upload_id") or (facts["built_before"] or {}).get("upload_id") != built.get("upload_id")
    # the REA findings: used by Family 2 only when the admin asks for them here, and then they must be there and read
    use_rea = bool(isinstance(edits, dict) and edits.get("use_rea"))
    if use_rea:
        rf = rea_facts(project)
        if not rf["usable"]:
            raise ValueError("the REA findings cannot be given to Family 2: %s. Take the tick away to go to stage 2 without them (they are optional)" % rf["why"])
    if skipped_by_choice or stale:
        engine.store.exec("UPDATE step SET state='waiting', note=NULL, error=NULL WHERE run=? AND family='2'", (run["id"],))
    engine.store.exec("UPDATE step SET output=? WHERE id=?", (json.dumps(dict(out, stage2="fixed", stage2_by=admin, stage2_at=time.time(), use_rea=use_rea)), step["id"]))
