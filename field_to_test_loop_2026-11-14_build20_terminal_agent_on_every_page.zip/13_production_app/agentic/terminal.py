"""The terminal (opencode) for the parts of the application outside the agents' runs.

The agents' runs ask through core.AgentRunner, which holds one session per agent. The other parts (the model connection
of stage 2, the isolation pages, the finding chat, the connection test) send complete questions and keep answers by
question, so an answer there must not depend on an earlier turn: each of their questions is a session of its own, with
a name, kept with its question and answer like every other session (agentic/sessions.py).
"""
import itertools
import os
import threading
import time

from . import core
from .sessions import Sessions

_lock = threading.Lock()
_sessions, _runners = {}, {}
_count = itertools.count(1)


def sessions(root):
    """The one store of sessions of an application folder (db/sessions.sqlite)."""
    path = os.path.join(os.path.abspath(root), "db", "sessions.sqlite")
    with _lock:
        if path not in _sessions:
            _sessions[path] = Sessions(path)
        return _sessions[path]


def _runner(root, cfg):
    a = (cfg or {}).get("agentic") or {}
    with _lock:
        r = _runners.get(os.path.abspath(root))
        if r is None:
            r = _runners[os.path.abspath(root)] = core.AgentRunner(os.path.join(root, "runs", "agentic"), runtime="opencode", timeout=240, web=bool(a.get("web", True)))
    r.sessions = sessions(root)
    r.opencode_path, r.opencode_model = a.get("opencode_path") or None, a.get("opencode_model") or None
    r.web_enabled = bool(a.get("web", True))
    return r


def ready(root, cfg):
    """-> (the chosen model's facts or None, problem in words)."""
    _exe, facts, problem = _runner(root, cfg).opencode_ready()
    return facts, problem


def app_turn(root, cfg, text, purpose="model connection", web=False, effort=None, want_json=True, timeout=None):
    """One question in a session of its own. -> the dict of AgentRunner.terminal_turn (answer, text, producer, ...)."""
    r = _runner(root, cfg)
    box = os.path.join(root, "runs", "agentic", "app_calls")
    os.makedirs(box, exist_ok=True)
    agent = "%s %s #%d" % (purpose, time.strftime("%Y-%m-%d %H:%M:%S"), next(_count))
    r.slots.take(lambda: None)
    try:
        out = r.terminal_turn(text, box, "app:%s" % purpose, agent, agent, web=bool(web and r.web_enabled), effort=effort,
                              want_json=want_json, timeout=timeout)
    finally:
        r.slots.give()
    if out.get("session", {}).get("id") is not None:        # one question, one session: it is kept to read, never continued
        r.sessions.close(out["session"]["id"], "one question, answered")
    return out
