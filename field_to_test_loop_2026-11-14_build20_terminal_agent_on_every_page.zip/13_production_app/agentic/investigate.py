"""The investigation agent: a terminal agent the admin talks to after Family 1.

(owner, 2026-11-14: "there should be investigation agent after the first family ... so that I can ask questions ... make a
connection between the backend's opencode terminal with the proper session names saved for my current running
application, so that if next time I open it, I will be opening the same session again. And if I ask some questions at the
front end, it has to go to the terminal backend, and it should share the status ... when they say export the CSV, then
you must be able to export the CSVs also".)

One held opencode session per analysis, named "analysis <number> · investigation": every question continues it, also after
the application was started again (agentic/sessions.py keeps the name, opencode's number for it and every turn). The agent
works in a folder of its own, runs/agentic/investigation_p<number>/, where the application puts what it already knows:
ANALYSIS.md (the files of the analysis) and dictionaries/ (Family 1's data dictionaries). It may read the analysis's data
folder, run Python, and write result files into exports/ (agentic/opencode_cli.py, the agent f2t-investigate). While it
works, what it is doing (which file it reads, which command runs) is kept for the page.

This is the one place where the application always uses the terminal, whatever "The agents run on" says in Settings.

EVERY PAGE (owner, 2026-11-14: "each and every page should have communication with the terminal agent because the agent
families that has been implemented are limited or not having such capacity as like full harness like opencode"). The
agent families answer one question from what the program hands them; they cannot open a file or run a program. So the
terminal agent is reachable from every page (app/static/js/terminal_agent.js):
  - a page of an analysis, or of a recording that belongs to an analysis  -> that analysis's session (the same one);
  - any other page (start page, Settings, rules library, packets, ...)     -> one session of the application, named
    "application · terminal agent", working in runs/agentic/investigation_app/ with the knowledge folder and the documents.
Each question carries where the admin is (the page, its address, its heading: page_words) and, when the page shows a
recording whose tree was built, where that tree is (TREE.md in the working folder; the agent may read the tree's folder).
"""
import json
import os
import re
import shutil
import threading
import time

from . import admin_ask, core, family1, prompts
from . import opencode_cli as oc

AGENT = "investigation"
APP = "app"                     # the place of the pages that show no analysis
APP_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WHERE = "\n\nWHERE THE ADMINISTRATOR IS NOW (the page the question was asked from):\n"
PAGES = {"/": "the flow pages (the start page, the stage pages of an analysis, Settings, the rules library)",
         "/agents": "the flow pages (the start page, the stage pages of an analysis, Settings, the rules library)",
         "/hier": "the tree pages of one recording (upload, the tree, summary, the defects found, limits)",
         "/isolate": "the page of one error (the commands around it, isolation of the defect, the procedural graph, the solution, the test case)",
         "/packets": "the earlier packet-level workflow on one CSV file (stage 1, stage 2)",
         "/db": "the page of the application's stored data", "/defect": "the page of one defect of the packet-level workflow",
         "/nvme-errors": "the page of every completion status an NVMe command can end with",
         "/nvme-rules": "the page of the rules that find an error at the NVMe command level",
         "/how": "the guide to the application"}
TURN_SECONDS = 1800             # the longest one question may work
STATUS_LINES = 40               # lines of "what it is doing" kept for the page
ASKS = "\n\nTHE ADMINISTRATOR ASKS:\n"

_jobs, _lock = {}, threading.Lock()         # project number -> the question being worked on


def scope(pid):
    return "app:terminal" if pid == APP else "analysis:%s" % pid


def name_of(pid):
    return "application · terminal agent" if pid == APP else "analysis %s · investigation" % pid


def _run_name(pid):
    return "investigation_app" if pid == APP else "investigation_p%s" % pid


def app_place():
    """The place of a page that shows no analysis: shaped like an analysis's row, so that the same code serves both."""
    return {"id": APP, "name": "the application", "folder": ""}


def place_for(engine, pid=None, upload=None):
    """The place a page talks to: the analysis it shows; else the analysis the recording on it belongs to; else the
    application. -> (place, problem). An analysis number that does not exist is a problem, never silently the application."""
    if pid not in (None, "", APP):
        try:
            n = int(pid)
        except (TypeError, ValueError):
            return None, "the analysis number must be a whole number"
        p = engine.store.one("SELECT * FROM project WHERE id=?", (n,))
        return (p, None) if p else (None, "no such analysis")
    if upload and isinstance(upload, str):
        p = engine.store.one("SELECT * FROM project WHERE upload_id=? ORDER BY id DESC LIMIT 1", (upload,))
        if p:
            return p, None
    return app_place(), None


def _one_line(v, most):
    return re.sub(r"\s+", " ", re.sub(r"[\x00-\x1f\x7f]", " ", str(v or ""))).strip()[:most]


def page_words(page):
    """Where the admin is, in a few plain lines, from what the page sent ({"path", "address", "title", "heading", "upload",
    "finding"}): every value cut to one short line, nothing of it is an instruction to the application."""
    if not isinstance(page, dict):
        return ""
    path = _one_line(page.get("path"), 80)
    out = []
    if path:
        out.append("Page: %s%s." % (path, " — " + PAGES[path] if path in PAGES else ""))
    for key, label, most in (("address", "Address in the browser", 300), ("title", "Title of the page", 160), ("heading", "Heading on the screen", 200),
                             ("upload", "Recording on the page (upload number)", 80), ("finding", "Error on the page (finding number)", 40),
                             ("item", "Item open on the page", 200)):
        v = _one_line(page.get(key), most)
        if v:
            out.append("%s: %s." % (label, v.rstrip(".")))
    return "\n".join(out)


def tree_of(place, page):
    """(upload number, the tree's file) of the recording the page shows, else of the analysis; (None, None) without a built tree."""
    from . import procedures as PR
    for up in ((page or {}).get("upload") if isinstance(page, dict) else None, (place or {}).get("upload_id")):
        if up and isinstance(up, str):
            db = PR.source_paths(up).get(PR.TREE)
            if db:
                return up, db
    return None, None


def write_tree_note(box, upload, db):
    """TREE.md in the working folder: where the tree of the recording is and which tables and columns it has (read from
    the file itself, read-only). -> the note's name, or "" when the file could not be read."""
    import sqlite3
    try:
        con = sqlite3.connect("file:%s?mode=ro" % db, uri=True, timeout=5)
        try:
            tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
            cols = {t: [r[1] for r in con.execute('PRAGMA table_info("%s")' % t.replace('"', '""'))] for t in tables}
        finally:
            con.close()
    except sqlite3.Error:
        return ""
    lines = ["# The tree of recording %s" % upload, "",
             "One SQLite file made by the application from the recording's five CSV files (packets, link transactions, split transactions, NVMe transactions, NVMe commands), joined into one tree:",
             "", "`%s`" % db, "",
             "Open it READ-ONLY from Python: `sqlite3.connect(\"file:%s?mode=ro\", uri=True)`. Never write to it: every page of the application reads it." % db,
             "", "## Tables and their columns", ""]
    lines += ["- `%s`: %s" % (t, ", ".join("`%s`" % c for c in cols[t])) for t in tables]
    with open(os.path.join(box, "TREE.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    return "TREE.md"


def workspace(engine, pid):
    d = os.path.join(engine.runner.sandbox_root, _run_name(pid))
    os.makedirs(os.path.join(d, "exports"), exist_ok=True)
    os.makedirs(os.path.join(d, "dictionaries"), exist_ok=True)
    return d


def latest_flow(engine, pid):
    return engine.store.one("SELECT * FROM run WHERE project=? AND kind='flow' ORDER BY id DESC LIMIT 1", (pid,))


def _digest(d):
    """A data dictionary as the agent reads it: every column that holds a value, short."""
    cols = []
    for c in d.get("columns") or []:
        if not isinstance(c, dict) or not c.get("column"):
            continue
        cols.append({"column": c["column"], "type": c.get("type"), "rows_with_value": c.get("rows_with_value"), "distinct": c.get("distinct"),
                     "observed": c.get("observed"), "meaning": c.get("meaning") or "", "meaning_status": c.get("status"),
                     "source": (c.get("source") or {}).get("ref") if isinstance(c.get("source"), dict) else None,
                     "keywords": [{"value": k.get("value"), "rows": k.get("count"), "meaning": k.get("meaning") or ""}
                                  for k in (c.get("keywords") or [])[:30] if isinstance(k, dict)]})
    return {"file": d.get("file"), "path": d.get("path"), "rows": d.get("rows") or d.get("rows_estimate"), "summary": d.get("summary"),
            "columns": cols, "columns_without_any_value": d.get("empty_columns") or []}


def _prepare_app(engine):
    """The application's place: ANALYSIS.md lists the analyses and says where the knowledge and the documents are."""
    box = workspace(engine, APP)
    know, docs = family1.knowledge_dir(), os.path.join(APP_ROOT, "docs")
    lines = ["# The application: no analysis is open on the page", "",
             "The administrator asks from a page that shows no single analysis (the start page, Settings, the rules library, or another page of the application).",
             "", "Your working folder: `%s` (write results into `exports/`)." % box, "",
             "## What you may read", "",
             "- `%s`: the application's knowledge: `rules/` (the rules library: one JSON file per item, with its procedure), `dictionaries/` (the data dictionaries Family 1 made, by file format), `strategies/` (the joining strategies approved for a file format)." % know,
             "- `%s`: the documents of the application (how it works, the record of changes)." % docs,
             "", "You may not read the data folder of an analysis from here: for a question about one analysis's data, say that the administrator should open that analysis and ask there (its own session has the data).",
             "", "## The analyses on this computer", "", "| Number | Name | Data folder | Tree built |", "|---|---|---|---|"]
    rows = engine.store.all("SELECT id, name, folder, upload_id FROM project ORDER BY id")
    lines += ["| %s | %s | `%s` | %s |" % (r["id"], r.get("name") or "", r.get("folder") or "", "yes" if tree_of(r, None)[1] else "no") for r in rows] or ["| (none yet) | | | |"]
    with open(os.path.join(box, "ANALYSIS.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    return box, []


def read_dirs(place):
    """The folders outside its own that the agent may read: the analysis's data, or the application's knowledge and documents."""
    if place["id"] == APP:
        return [d for d in (family1.knowledge_dir(), os.path.join(APP_ROOT, "docs")) if os.path.isdir(d)]
    return [place["folder"]] if place.get("folder") else []


def prepare(engine, project):
    """Write what the application knows into the agent's folder. -> (folder, the files of the analysis)."""
    pid = project["id"]
    if pid == APP:
        return _prepare_app(engine)
    box = workspace(engine, pid)
    folder = project.get("folder") or ""
    run = latest_flow(engine, pid)
    files = admin_ask.files_now(engine, run["id"], folder) if run else [dict(f, state="new") for f in family1.inventory(folder)]
    lines = ["# Analysis %s: %s" % (pid, project.get("name") or ""), "",
             "Data folder (read only): `%s`" % folder, "", "Your working folder: `%s` (write results into `exports/`)." % box, "",
             "## The CSV files of this analysis", "", "| File | Size | Columns | What it is | Dictionary |", "|---|---|---|---|---|"]
    for f in files:
        d, _where = admin_ask._dictionary(engine, run["id"], f) if run else (None, "")
        has = ""
        if d:
            name = re.sub(r"[^A-Za-z0-9_.-]+", "_", f["name"]) + ".json"
            with open(os.path.join(box, "dictionaries", name), "w", encoding="utf-8") as fh:
                json.dump(_digest(d), fh, indent=1, ensure_ascii=False)
            has = "`dictionaries/%s`" % name
        lines.append("| `%s` | %s | %s | %s | %s |" % (f["name"], core.fmt_bytes(f.get("bytes") or 0), f.get("columns"), f.get("level_label") or "",
                                                 has or "not read by the data experts yet"))
    if not files:
        lines.append("| (no CSV file in the folder) | | | | |")
    other = sorted(n for n in (os.listdir(folder) if os.path.isdir(folder) else []) if not n.lower().endswith(".csv"))[:40]
    if other:
        lines += ["", "Other files in the data folder (not CSV; the application does not read them): " + ", ".join("`%s`" % n for n in other)]
    with open(os.path.join(box, "ANALYSIS.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    return box, files


def exports(engine, pid):
    d = os.path.join(workspace(engine, pid), "exports")
    out = []
    for n in sorted(os.listdir(d)):
        p = os.path.join(d, n)
        if os.path.isfile(p):
            st = os.stat(p)
            out.append({"name": n, "bytes": st.st_size, "size": core.fmt_bytes(st.st_size), "changed": st.st_mtime, "path": p})
    return out


def export_path(engine, pid, name):
    """The path of one export, or None: only a plain file name of the exports folder."""
    if not name or name != os.path.basename(name) or name.startswith("."):
        return None
    p = os.path.join(workspace(engine, pid), "exports", name)
    return p if os.path.isfile(p) else None


def add_to_analysis(engine, project, name):
    """Copy one exported CSV into the analysis's data folder, so that "Read the new files" gives it its three agents.
    A file of that name already in the folder is never replaced."""
    if project["id"] == APP:
        raise ValueError("no analysis is open on this page: open the analysis the file belongs to and ask there")
    src = export_path(engine, project["id"], name)
    if not src:
        raise ValueError("no such exported file")
    if not name.lower().endswith(".csv"):
        raise ValueError("only a CSV file can be added to the analysis")
    folder = project.get("folder") or ""
    if not os.path.isdir(folder):
        raise ValueError("the analysis's folder does not exist: %s" % folder)
    dst = os.path.join(folder, name)
    if os.path.exists(dst):
        raise ValueError("the folder already has a file named %s: rename the export first (ask the agent to write it under another name)" % name)
    shutil.copyfile(src, dst)
    return dst


def _question_of(asked):
    i = asked.rfind(ASKS)
    return asked[i + len(ASKS):] if i >= 0 else asked


def _page_of(asked):
    """The page a kept question was asked from (its first line of the WHERE block), or ""."""
    i, j = asked.rfind(WHERE), asked.rfind(ASKS)
    return asked[i + len(WHERE):j].split("\n")[0] if 0 <= i < j else ""


def state(engine, project):
    """Everything the page shows: the session, the conversation, what is being worked on now, the exported files."""
    pid = project["id"]
    S = engine.runner.sessions
    rows = S.of_agent(scope(pid), AGENT) if S is not None else []
    conv = []
    for r in rows:
        for t in S.conversation(r["id"]):
            conv.append({"n": len(conv) + 1, "asked": _question_of(t["asked"]), "answered": t["answered"], "ok": t["ok"], "problem": t["problem"],
                         "seconds": t["seconds"], "at": t["at"], "session": r["name"], "page": _page_of(t["asked"])})
    held = next((r for r in reversed(rows) if r["state"] == "open"), None)
    _exe, facts, problem = engine.runner.opencode_ready()
    with _lock:
        job = dict(_jobs.get(pid) or {})
    running = None
    if job and not job.get("done"):
        running = {"question": job["question"], "since": job["since"], "seconds": round(time.time() - job["since"]), "by": job.get("admin"),
                   "lines": list(job["lines"])[-STATUS_LINES:]}
    return {"project": pid, "place": "application" if pid == APP else "analysis", "analysis_name": None if pid == APP else project.get("name"),
            "name": name_of(pid), "ready": not problem, "problem": problem, "model": facts["name"] if facts else None,
            "model_id": engine.runner.opencode_model,
            "session": {"name": held["name"], "terminal_id": held["terminal_id"], "turns": held["turns"], "holds_tokens": held["size_tokens"],
                        "started": held["created"], "last_used": held["updated"]} if held else None,
            "earlier_sessions": [{"name": r["name"], "turns": r["turns"], "why_closed": r["why_closed"]} for r in rows if r["state"] != "open"],
            "conversation": conv, "running": running, "last_error": job.get("error") if job.get("done") else None,
            "exports": [{k: v for k, v in e.items() if k != "path"} for e in exports(engine, pid)],
            "folder": workspace(engine, pid)}


def ask(engine, project, question, admin, page=None):
    """Start one question in the place's held session; the page then reads state(). One question at a time.
    page: what the asking page sent about itself (see page_words); it goes to the agent before the question."""
    pid = project["id"]
    question = (question or "").strip()
    if not question:
        raise ValueError("write the question first")
    if len(question) > 20000:
        raise ValueError("the question is longer than 20,000 characters")
    _exe, _facts, problem = engine.runner.opencode_ready()
    if problem:
        raise ValueError(problem)
    with _lock:
        cur = _jobs.get(pid)
        if cur and not cur.get("done"):
            raise ValueError("the investigation agent is still working on the question before this one; wait for it, or stop it")
        job = _jobs[pid] = {"question": question, "since": time.time(), "lines": [], "admin": admin, "done": False, "error": None, "run": _run_name(pid),
                            "page": page if isinstance(page, dict) else None}
    threading.Thread(target=_work, args=(engine, project, question, job), name="investigation-%s" % pid, daemon=True).start()
    return {"started": True, "name": name_of(pid)}


def _work(engine, project, question, job):
    pid, r = project["id"], engine.runner
    try:
        box, _files = prepare(engine, project)
        dirs = read_dirs(project)
        where = page_words(job.get("page"))
        up, db = tree_of(project, job.get("page"))
        if db:
            note = write_tree_note(box, up, db)
            if note:
                dirs.append(os.path.dirname(db))
                where += ("\n" if where else "") + "The tree of the recording %s is built: read `%s` in your working folder for where it is and its tables." % (up, note)
        prompt = prompts.load("investigation") + (WHERE + where if where else "") + ASKS + question

        def on_line(line):
            words = oc.event_words(line)
            if words and (not job["lines"] or job["lines"][-1]["text"] != words):
                job["lines"].append({"at": time.time(), "text": words})
                del job["lines"][:-200]
        r._local.run = job["run"]               # so that Stop ends this call (AgentRunner.cancel)
        r.resume(job["run"])
        r.slots.take(r._stopped)
        try:
            r.terminal_turn(prompt, box, scope(pid), AGENT, name_of(pid), want_json=False, timeout=TURN_SECONDS, oc_agent=oc.AGENT_INVESTIGATE,
                            read_dirs=dirs or None, on_line=on_line)
        finally:
            r.slots.give()
    except Exception as e:      # noqa: BLE001 - shown on the page; the failed turn is in the record with its reason
        job["error"] = "stopped by the admin" if str(e) == "the run was stopped" else str(e)[:500]
    finally:
        job["done"] = True
        job["ended"] = time.time()


def stop(engine, project):
    pid = project["id"]
    with _lock:
        job = _jobs.get(pid)
    if not job or job.get("done"):
        return {"stopped": False}
    engine.runner.cancel(job["run"])
    return {"stopped": True}
