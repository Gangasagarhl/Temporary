# Start here — what to read, in which order

This folder is the production application of the **Field-to-Test Loop**: a PCIe/NVMe analyzer CSV — or a workload-result
artifact (JSON) for ADK / PCMark runs — goes in, stage 1 isolates every defect it contains, stage 2 turns each defect into a
reproduced, admin-approved, executable regression test — with the knowledge database as the RAG store and the admin's
decisions as the reinforcement signal. No LLM is trained or fine-tuned anywhere. Paths below are relative to the project
root (the folder that contains
`13_production_app/`); inside the zip only `13_production_app/...` exists.

## The statement and its coverage

- `13_production_app/docs/project_statement.html` — the capstone statement as given; `system_architecture.html` — the
  architecture diagram; `new_statement_explained.html` — the statement explained word by word with the acceptance
  checklist (Part H).
- `13_production_app/docs/REQUIREMENTS_TRACEABILITY.md` — every sentence of it mapped to the implementation, with
  evidence and an honest status (met / met on the synthetic bench / deployment work / not verifiable here), plus the
  architecture diagram box by box and the acceptance checklist H1–H10.

## If you have 20 minutes (manager)

0. `13_production_app/docs/APPLICATION_MAP.html` — open in a browser: every button and piece of content, each with an
   arrow chain from the click through the browser code, server address, Python functions and database to the screen.
   `13_production_app/docs/OPERATOR_AND_BACKEND_GUIDE.html` — open in a browser. Every screen, word and button, which
   Python function runs behind it, what it writes into the database and why, with the real code and a checklist to
   validate it. Rebuild after code changes with `python3 docs/build_operator_guide.py`.

1. `13_production_app/docs/FINAL_WORKFLOW_AND_ALGORITHMS.html` — open in a browser.
   Read section 1 (the whole workflow as one block diagram), section 3 (how an error is recognised from packets),
   **section 8** (how the system learns from the admin: which algorithm, what each button changes, what was tested and
   fixed, and the manager's screen with a screenshot), section 12 (measured results) and section 14 (three worked
   examples: visible on the wire, partly visible, not visible).
2. `13_production_app/README.md` — "What you see" and "The flow" to know what the five steps on the screen are.
3. Run it: `python3 run_app.py`, open http://127.0.0.1:8077/packets for the single-CSV workflow (the main page is the five-file upload, section below), enter the path of an analyzer CSV in step 1 (a synthetic sample can be made with
   `POST /api/samples/generate`, see `deploy/INSTALL.md`), and after stage 1
   press *Continue to stage 2* → *Start stage 2*. The review screen is the manager decision view: Correct / Needs
   changes / Not correct per candidate, drag to rank, "All details" for everything else.

## If you have to understand the errors (engineer)

4. `13_production_app/docs/HOW_DEFECTS_ARE_DETECTED.html` — the detection engine: row classifier, protocol trackers,
   rule tiers, attribution, atlas cards, LLM confirmation, the 4 GB run.
5. `FINAL_WORKFLOW_AND_ALGORITHMS.html` sections 2, 4, 5 and **15** — section 15 lists all 485 errors by family,
   each with the CSV rows observed in the trace next to how the exchange should look and which specification clause
   proves it.
6. `05_reports_and_docs/485_errors_explained.md` (and `.csv`) — one row per atlas card: rule, key rows, the fix.
7. `01_input_files/PEX_Trace_Error_Atlas_Expanded.html` — the atlas of 485 failure episodes the trace was built from;
   `08_defect_detection_spec/DEFECT_DETECTION_SPEC_485.md` — the detection contract per card.
8. `10_defect_isolation_engine/REPORT_defect_isolation.md` and `PRODUCTION_READINESS.md` — stage-1 results
   (437/485 from the wire, 483/485 with host evidence, 0 false positives), thresholds and their provenance, limits.

## If you have to understand stage 2 (database, retrieval, learning, tests)

9. `FINAL_WORKFLOW_AND_ALGORITHMS.html` sections 6–11 and 13 — the knowledge database (RAG store), hybrid retrieval,
   the learning rules (8), the reproduction search (9), the test contract (10), a worked example (11), and the
   stage 1 → stage 2 hand-over with the measured effect of every admin signal (13).
10. `Database_Implmentation/claude_research_report/stage2_upgrade_research/reports/Stage 2 v3 final design.md` and
    `Database_Implmentation/claude_research_report/REPORT_stage2_v3.md` — design and measurements of stage 2 v3.
11. Research notes behind the design, `.../stage2_upgrade_research/research_notes_v3/`: `admin_feedback_actions.md`,
    `retrieval_for_procedural_rag.md`, `procedural_graph_design.md`, `closed_loop_test_generation.md`,
    `full_stack_app_design.md`, `ux_for_non_technical_admins.md`, `visual_design_system.md`,
    **`manager_decision_view.md`** (the stage-2 screen: what managers need, with sources).
12. `Database_Implmentation/claude_research_report/REPORT_final_implementation.md` — the 15-implementation ranking
    benchmark that chose the counting (Beta) policy over trained agents.

## If you have to defend the numbers

- `13_production_app/docs/PROVENANCE_AUDIT.md` — every formula, threshold and constant in stage 1 and stage 2 with its
  source class (normative clause / advertised register / host policy / modeled / statistical identity / paper /
  user rule / engineering choice) and the citations checked on 2026-10-26; starts with the regression-test repeat
  formula `n = ceil(ln 0.05 / ln(1 − p))`.
- `13_production_app/docs/VERIFICATION_FROM_SCRATCH.md` — the mailable package extracted into an empty folder and run
  end to end, including the 4 GB trace, with every number as measured.
- `13_production_app/docs/README_PACKAGE.md` — what is in the package and how to run it in production with a real CSV.

## Tests — run them yourself

| What | Command (from `13_production_app/`) | Takes | Proves |
|---|---|---|---|
| Everything offline | `./run_tests.sh` | ~90 s | runs `tests/test_app.py` (4 tests): stage-1 engine fixtures, 24 stage-2 unit tests (`tests_v3.py` 16 + `tests_v4.py` 8), the end-to-end HTTP test and the workload-artifact test with the stand-in LLM |
| End-to-end through the API | `python3 tests/test_app.py` | ~90 s | the same 4 tests as above; the end-to-end one: synthetic capture → stage 1 → gate → present → manager solutions view → actions → search + closed loop → report → undo |
| Live loop with the real LLM | start `python3 run_app.py`, then `python3 tests/exercise_loop.py` | 10–17 min | all checks pass; the count grows with the database (60 on the latest run): tests admitted, 'generate test case' composed by the LLM from the stored sequences and filed, recurrence recognised and reused, every admin signal verified against the database, pattern cache, run cache; the final report is `runs/exercise_report.md` |
| The screen itself | server running, then `python3 tests/ui_smoke.py` (needs Chrome) | ~10 min | 21 checks (21/21 passed on the last run, 27 Oct 2026, `runs/ui_smoke/ui_smoke_report.md`) driving the real page: bottom line, flow graph, ranking + Save decisions, Not correct → lesson with no weights, Needs changes → validated by execution, Correct → regression guard → test script, Generate test case → composed variants filed, Sweep the neighbourhood → variants filed; screenshots in `runs/ui_smoke/` |
| Stage-2 units only | `cd stage2 && python3 -m unittest tests_v3 tests_v4` | 1 s | 24 tests: every learning rule in section 8.5 (`tests_v3`, 16) plus loop rules, signature, sweep, workload import, actions and PPO (`tests_v4`, 8) |
| A generated regression test | `cd suite/<test_id> && python3 -m pytest -q` | ~30 s | the test reproduces and isolates the defect on known-bad firmware and stays silent on fixed firmware |

## Where things land at run time

`runs/<run>/` (stage-1 outputs, stage-2 states, report), `db/knowledge.sqlite` (the event log and the graph — browse it on
the Database page), `suite/<test_id>/` (generated tests: manifest.json, test_*.py, conftest.py), `samples/` (synthetic
captures made from the UI), `runs/exercise_report.md` and `runs/ui_smoke/` (test reports).

## Words used on the screens

- **Defect 1, Defect 2 …** — the defects of one trace, numbered in the order the analyser met them. The internal record id (INC-0001) never appears on a screen.
- **error type T-42 (chapter T = timeouts and time limits, entry 42)** — an entry of the catalogue of 485 known error types (the "atlas cards" of the engine documents). The letter is the chapter (S status-code errors, T timeouts, D silent failures, L PCIe link/transaction, C controller/host driver, X physical-layer analyzer-only, V protocol rule violations, P performance, M timing/evidence gaps, N outside the probed link); the number is only the position inside the chapter.
- **AI reviewer** — the language model that gives a second opinion on each defect (agrees / disagrees / not sure) and proposes procedures. No self-rated confidence number is shown anywhere; it was removed on 2026-10-27 because no specification defines it.
- **score** — the share of three yes/no checks a lab run passes (same error type, same first rule, Confirmed). Above 0.9 three times in a row = optimal.
- The full list is on the application's "What the words mean" page (sidebar button "?").
- **Your name / Device under test** (Choose-trace page) — the name is required and is recorded with the run and every decision; the device is read from the trace (Identify Controller: model, serial, firmware revision) or typed. Procedure cards show when a procedure was proposed, last reproduced in the lab (on which device and firmware), approved and by whom, and who last judged it. Tests are filed per device model. Details: `docs/CHANGES_2026-10-27.md`.


## Five-level NVMe hierarchy (2026-11-02)

Open http://127.0.0.1:8077 (the main page; `/hier` still works; the earlier single-CSV workflow is at `/packets`). Upload the five per-level exports, read the load report, browse the tree with the filters and the summary, review the defects, use the four signals, and generate the test case. FAQ 55–60 in `docs/FAQ.html` explain every step; the project statement is `../09_defect_isolation_research/research_notes/nvme_app/00_project_statement.md`.

Sizes: a 4.3 GB packets file (8.25 million packets) loads, builds and runs the rules in 24 minutes (measured 2026-11-02) and needs about 300 MB of RAM, because every
step works from disk: the per-upload SQLite file holds the rows, the build and the rules stream through it, and the pages read
200 rows at a time as you scroll (filters are applied by the database). The full synthetic set for such a test is
`samples/five_level_full/` (all 485 error cards; README inside; rebuild commands there). Smaller sets: `samples/five_level/S01..S59`.

The interactive guide `docs/HOW_THE_APP_WORKS.html` (or http://127.0.0.1:8077/how) explains every stage with the real numbers and lets you try the joins, the limits, the four signals and the window rules.

Page 3 (2026-11-03) is the defect table with the link-level limit at its top; clicking a row or an error chip opens the isolation tab in a new browser tab (`/isolate`), where the chat, the signature memory, the evidence loop, the four signals, the test case and the four-line summary live. Tests: `tests/test_hier_e2e.py` and `tests/test_isolate.py` (both need the running server; `--cleanup-store` removes what they write).
