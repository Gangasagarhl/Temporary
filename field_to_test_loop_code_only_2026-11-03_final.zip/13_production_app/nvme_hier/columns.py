"""Canonical column lists of the five per-level exports and the renames of the label-less headers.

The lists come from the customer's COLUMN_NAMES.txt (read in full from photos on 2026-11-02; every file matches
the customer's own counts: packets 113, link 34, split 17, NVMe transactions 402, NVMe commands 1598). They are
stored in data/lecroy_export_columns.json under the names the customer's script produced; four of those names are
not labels but the text of the first row (the header cell was blank): "16.0" is the link speed, "1 warning(s)",
"2 error(s)" and "1 error(s)" are the unit's warning and error cells. This module gives them stable names.

The customer's export of 2026-11-03 (header_diff/*.csv) showed that the analyzer does not always write the names
this way: sub-columns may be bare right after their group cell (ST, then SCT, SC), the second of two same-named
columns is written without the "#2" the customer's script added (CSI, CSI), the label-less cells may hold the
first row's text instead of being blank, underscores may replace spaces (AckNak_Seq_Num), some per-group columns
may be absent (Cpl.TLP Type, Cpl.Length, Msg.TLP Type, Msg.Length: one TLP Type / Length column serves all TLP
kinds) and extra columns may be present (KNOWN_EXTRAS). loader.align_header accepts all of it.
"""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
COLUMNS_JSON = os.path.join(os.path.dirname(HERE), "data", "lecroy_export_columns.json")

# file key -> customer file name in the JSON
FILE_KEYS = {
    "packets": "packets.csv",
    "link": "link.csv",
    "split": "split.csv",
    "nvme_transaction": "NVME_Transactions.csv",
    "nvme_command": "nvme_command.csv",
}
LEVEL_ORDER = ["nvme_command", "nvme_transaction", "split", "link", "packets"]
LEVEL_LABEL = {
    "packets": "packet",
    "link": "link transaction",
    "split": "split transaction",
    "nvme_transaction": "NVMe transaction",
    "nvme_command": "NVMe command",
}

# (file key, name in the customer's list) -> canonical name. Label-less header cells are blank in the CSV; the
# customer's script named them after the first row's text. The loader recognises them by position.
LABEL_LESS = {
    ("link", "16.0"): "Link Speed",
    ("split", "16.0"): "Link Speed",
    ("nvme_command", "1 warning(s)"): "Warnings",
    ("nvme_command", "2 error(s)"): "Errors",
    ("nvme_command", "1 error(s)"): "Errors#2",
    ("nvme_transaction", "1 error(s)"): "Errors",
    ("nvme_transaction", "1 warning(s)"): "Warnings",
}
# Columns a recording may carry that the customer's lists do not have. They depend on what the capture contains
# (a Cfg group appears when configuration TLPs were recorded, No-Snoop fields when the TLP attribute columns were
# exported). Seen on the customer's export of 2026-11-03 (header_diff/extra_columns.csv). They are accepted, kept
# under their own name in the row's raw cells and listed on the page as "extra columns kept"; nothing is refused.
# The packet export sometimes carries an "Errors" column (Export dialog > columns > Errors): same treatment.
KNOWN_EXTRAS = {
    "packets": ["Errors"],
    "link": ["Implicit ACK", "No-Snoop", "No-Snoop Requirement", "No-Snoop Scale", "No-Snoop Value", "Snoop",
             "Cfg", "DeviceID", "Register"],
    "split": ["Split Tra Error", "Cfg", "DeviceID", "Register"],
}
# An extra group cell: the bare names that follow it (TLP Type, DeviceID, Register) belong to it and are kept as
# "Cfg.TLP Type" etc., so they never collide with the Mem group's "TLP Type".
EXTRA_GROUPS = {"Cfg"}

# plain-words meaning of the canonical names the pages show (kept short; the FAQ has the long form)
PLAIN = {
    "Link Speed": "link speed in GT/s",
    "Warnings": "the analyzer's warning cell for this row",
    "Errors": "the analyzer's error cell for this row",
    "Errors#2": "the analyzer's error cell inside the decoded data structure",
    "Split Tra Error": "the analyzer's error cell of the split transaction",
    "Metrics.# Packets": "number of packets in this link transaction",
    "Metrics.# LinkTrans": "number of link transactions in this split transaction",
    "Metrics.# Link & Split Trans": "number of link and split transactions in this NVMe transaction",
    "Metrics.# NVME Trans": "number of NVMe transactions in this command",
    "Time Delta": "time from this row to the next row at this level",
    "Time Stamp": "time of the first packet of this row, from the start of the recording",
}


def _load():
    with open(COLUMNS_JSON, encoding="utf-8") as f:
        return json.load(f)


_DATA = None


def data():
    global _DATA
    if _DATA is None:
        _DATA = _load()
    return _DATA


def original_names(file_key):
    """The customer's list for one file, in file order (label-less names as the customer wrote them)."""
    return list(data()["columns"][FILE_KEYS[file_key]])


def canonical_names(file_key):
    """Same list with the label-less headers renamed."""
    out = []
    for n in original_names(file_key):
        out.append(LABEL_LESS.get((file_key, n), n))
    return out


def label_less_positions(file_key):
    """Indices (within the named list) whose header cell is blank in the CSV."""
    return [i for i, n in enumerate(original_names(file_key)) if (file_key, n) in LABEL_LESS]


def expected_count(file_key):
    return len(original_names(file_key))
