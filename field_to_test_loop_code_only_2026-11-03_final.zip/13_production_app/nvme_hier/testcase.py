"""Python test case from an agreed reproduction sequence (research note 06, test contract).

The generated file is a pytest module that replays the sequence with nvme-cli on Linux (the kernel picks the
submission queue; queue control needs SPDK or the LeCroy exerciser and is noted in the header), measures each
command (status word, latency, read-back bytes) and asserts the SAME deterministic rule the detector used:
  status_error        the command completes with the recorded status (type/code) - or any non-success when
                      the recorded one is not reachable
  latency_over_limit  the measured doorbell-to-completion time exceeds the limit
  incomplete          the command times out (nvme-cli returns the host timeout)
  deallocate_readback the read after the deallocate does not return the DLFEAT value
  bytes_short         the read returns fewer bytes than requested
  default             the command fails (non-zero status) at the fault step
Run with EXPECT=fixed to assert the opposite (fixed firmware must stay silent): the regression form.
The steps after the fault can carry their own expected outcome (status and timing a correct device must produce,
verified by the admin in the isolation tab); each is asserted after the fault step's check.
The test skips cleanly when the device is absent or nvme-cli is not installed. LBAs can be relocated with
NVME_LBA_OFFSET when the original range is in use.
"""
import json
import time

HEADER = '''#!/usr/bin/env python3
"""GENERATED TEST CASE - field-to-test loop, five-level NVMe hierarchy.

scenario        : {scenario}
signature       : {signature}
rule            : {rule} ({level} level)
source          : upload {upload} finding {finding}; window rows {rows}
generated       : {generated}
version         : {version}
device recorded : {device} firmware {firmware}
observed outcome: {observed}
                  (what the recording showed at the fault step)
expected outcome: {expected}
                  (what a correct device must produce for the same input; verified by {verified_by})
pass / fail     : EXPECT=fault  -> passes when the observed outcome appears again (the fault reproduces)
                  EXPECT=fixed  -> passes when the expected outcome appears (the fault is gone); fails otherwise
how to run      : NVME_DEV=/dev/nvme0n1 NVME_NSID=1 python3 -m pytest -q {name}
                  EXPECT=fixed to assert the fault does NOT appear (regression form)
                  NVME_LBA_OFFSET=<blocks> to move the LBA range when the original one is in use
limits          : nvme-cli issues one command at a time and the kernel picks the submission queue; exact queue,
                  command id or PRP control needs SPDK / pynvme, and link-level faults need the analyzer exerciser.
"""
import json
import os
import re
import shutil
import subprocess
import time

import pytest

DEV = os.environ.get("NVME_DEV", "/dev/nvme0n1")
NSID = int(os.environ.get("NVME_NSID", "{nsid}"))
LBA_OFFSET = int(os.environ.get("NVME_LBA_OFFSET", "0"))
EXPECT = os.environ.get("EXPECT", "fault")        # fault = reproduce; fixed = must stay silent
TIMEOUT_S = {timeout_s}
LIMIT_US = {limit_us}
BLOCK = {block}

pytestmark = pytest.mark.skipif(not (os.path.exists(DEV) and shutil.which("nvme")), reason="device %s or nvme-cli not present" % DEV)
STATUS_RE = re.compile(r"NVMe status: *(?P<name>[^(]*)\\((?P<code>0x[0-9a-fA-F]+)\\)")


class Result:
    def __init__(self, rc, out, err, seconds):
        self.rc, self.out, self.err, self.seconds = rc, out, err, seconds
        m = STATUS_RE.search(err or "") or STATUS_RE.search(out or "")
        self.status = int(m.group("code"), 16) if m else (0 if rc == 0 else None)
        self.status_name = m.group("name").strip() if m else ("Successful Completion" if rc == 0 else "no status word")
        self.sct = (self.status >> 8) & 7 if self.status is not None else None
        self.sc = self.status & 0xFF if self.status is not None else None
        self.timed_out = False


def nvme(args, data=None, timeout=TIMEOUT_S):
    t0 = time.time()
    try:
        p = subprocess.run(["nvme"] + [str(a) for a in args], input=data, capture_output=True, timeout=timeout)
        r = Result(p.returncode, p.stdout.decode(errors="replace") if not data else "", p.stderr.decode(errors="replace"), time.time() - t0)
        r.raw = p.stdout
        return r
    except subprocess.TimeoutExpired:
        r = Result(None, "", "host timeout", time.time() - t0)
        r.timed_out = True
        r.raw = b""
        return r


def lba(x):
    return int(x) + LBA_OFFSET


def read(slba, nlb):
    return nvme(["read", DEV, "--namespace-id", NSID, "--start-block", lba(slba), "--block-count", nlb, "--data-size", (nlb + 1) * BLOCK, "--latency"])


def write(slba, nlb, pattern=0xA5):
    return nvme(["write", DEV, "--namespace-id", NSID, "--start-block", lba(slba), "--block-count", nlb, "--data-size", (nlb + 1) * BLOCK, "--latency"],
                data=bytes([pattern]) * ((nlb + 1) * BLOCK))


def flush():
    return nvme(["flush", DEV, "--namespace-id", NSID])


def deallocate(ranges):
    blocks = ",".join(str(n) for _, n in ranges)
    slbas = ",".join(str(lba(s)) for s, _ in ranges)
    return nvme(["dsm", DEV, "--namespace-id", NSID, "--ad", "--slbs", slbas, "--blocks", blocks])


def write_zeroes(slba, nlb):
    return nvme(["write-zeroes", DEV, "--namespace-id", NSID, "--start-block", lba(slba), "--block-count", nlb])


def admin(name):
    table = {{"Identify": ["id-ctrl", DEV], "Get Log Page": ["smart-log", DEV], "Keep Alive": ["admin-passthru", DEV, "--opcode=0x18"]}}
    return nvme(table.get(name, ["id-ctrl", DEV]))


def run_step(step):
    c = step["command"].replace(" (admin)", "")
    p = step.get("parameters", {{}})
    if c == "Read":
        return read(p.get("slba", 0), p.get("nlb", 7))
    if c == "Write":
        return write(p.get("slba", 0), p.get("nlb", 7))
    if c == "Flush":
        return flush()
    if c == "Dataset Management":
        return deallocate(p.get("ranges") or [[p.get("slba", 0), p.get("nlb", 7) + 1]])
    if c == "Write Zeroes":
        return write_zeroes(p.get("slba", 0), p.get("nlb", 7))
    if step.get("admin"):
        return admin(c)
    pytest.skip("command %s is not replayable with nvme-cli; use SPDK/pynvme or the analyzer exerciser" % c)


SEQUENCE = {sequence}
FAULT_STEP = {fault_step}
'''

BODY = '''
OBSERVED = {observed!r}
EXPECTED = {expected!r}
# the expected outcomes of the commands from the fault onward, and of the set-up steps before it when the admin asked for them
# (status and timing a correct device must produce), verified by the admin
EXPECTED_AFTER = {expected_after}


def fault_seen(result):
    """The detector's rule, applied to the measured outcome of the fault step."""
{rule_code}


def test_sequence():
    """Replays the sequence with the recorded gaps; asserts the rule at the fault step (EXPECT=fault) or its absence (EXPECT=fixed)."""
    results = []
    for step in SEQUENCE:
        time.sleep(step.get("gap_us", 10) / 1e6)
        r = run_step(step)
        results.append((step, r))
        if step["step"] < FAULT_STEP:
            assert r.status == 0 or r.status is None, "set-up step %d (%s) failed with %s" % (step["step"], step["command"], r.status_name)
    fault = next(r for s, r in results if s["step"] == FAULT_STEP)
    seen = fault_seen(fault)
    record = {{"expect": EXPECT, "fault_status": fault.status_name, "fault_seconds": round(fault.seconds, 6), "timed_out": fault.timed_out, "seen": seen,
              "observed_in_recording": OBSERVED, "expected_when_fixed": EXPECTED,
              "steps": [{{"step": s["step"], "command": s["command"], "status": r.status_name, "seconds": round(r.seconds, 6)}} for s, r in results]}}
    print("RESULT " + json.dumps(record))
    if EXPECT == "fixed":
        assert not seen, "FAILED: expected %s; got %s after %.3f s (the fault still appears)" % (EXPECTED, fault.status_name, fault.seconds)
    else:
        assert seen, "FAILED: expected the recorded fault (%s) to appear again; got %s after %.3f s" % (OBSERVED, fault.status_name, fault.seconds)
    # the commands after the fault (and the set-up steps before it, when listed): each must produce the outcome a correct device produces (verified by the admin)
    for exp in EXPECTED_AFTER:
        if exp["step"] == FAULT_STEP:
            continue
        r = next((r for s, r in results if s["step"] == exp["step"]), None)
        if r is None:
            continue
        if exp.get("status_code") is not None:
            want = tuple(exp["status_code"])
            assert (r.sct, r.sc) == want or (r.status is None and want == (0, 0)), "FAILED: step %d (%s): expected %s; got %s" % (exp["step"], exp["command"], exp["status"], r.status_name)
        elif exp.get("success", True):
            assert r.status in (0, None) and not r.timed_out, "FAILED: step %d (%s): expected %s; got %s" % (exp["step"], exp["command"], exp["status"], r.status_name)
        if exp.get("timing_us") is not None:
            assert r.seconds * 1e6 <= exp["timing_us"], "FAILED: step %d (%s): expected completion within %s us; took %.0f us" % (exp["step"], exp["command"], exp["timing_us"], r.seconds * 1e6)
'''

RULE_CODE = {
    "cmd.status_error": '''    want = ({sct}, {sc})
    if result.sct is None:
        return False
    return (result.sct, result.sc) == want or (want == (None, None) and result.status != 0)''',
    "cmd.latency_over_limit": '''    return result.timed_out or result.seconds * 1e6 > LIMIT_US''',
    "cmd.incomplete": '''    return result.timed_out''',
    "cmd.not_fetched": '''    return result.timed_out''',
    "spl.latency_over_limit": '''    return result.timed_out or result.seconds * 1e6 > LIMIT_US or (result.status not in (0, None))''',
    "spl.incomplete": '''    return result.timed_out or (result.status not in (0, None))''',
    "cmd.deallocate_readback": '''    data = getattr(result, "raw", b"")
    if not data:
        return result.status not in (0, None)
    zeros, ffs = data.count(0), data.count(0xFF)
    return not (zeros == len(data) or ffs == len(data))     # neither zeros nor FFh: the deallocate was not applied''',
    "cmd.bytes_short": '''    data = getattr(result, "raw", b"")
    want = (SEQUENCE[FAULT_STEP - 1].get("parameters", {}).get("nlb", 7) + 1) * BLOCK
    return len(data) < want or result.status not in (0, None)''',
}
DEFAULT_RULE = '''    return result.timed_out or (result.status not in (0, None))'''


def normalise_expected(expected_after, steps, fault_step):
    """The list of expected outcomes for the steps from the fault onward, as the test file stores it:
    [{step, command, status, status_code [sct, sc] or None, success, timing_us or None, check}]. Steps that are not in the
    sequence are dropped; the fault step itself keeps the EXPECT=fault/fixed form and is listed for the header only."""
    by_step = {s["step"]: s for s in steps}
    out = []
    for e in expected_after or []:
        try:
            st = int(e.get("step"))
        except (TypeError, ValueError):
            continue
        if st not in by_step:
            continue
        code = e.get("status_code")
        if isinstance(code, (list, tuple)) and len(code) == 2 and all(isinstance(x, int) for x in code):
            code = [int(code[0]), int(code[1])]
        else:
            code = None
        timing = e.get("timing_us")
        try:
            timing = int(timing) if timing not in (None, "") else None
        except (TypeError, ValueError):
            timing = None
        status = (e.get("status") or "").strip() or ("Successful Completion" if code in (None, [0, 0]) else "status type %d code %d" % tuple(code))
        success = bool(e.get("success", code in (None, [0, 0])))
        out.append({"step": st, "command": by_step[st].get("command"), "status": status, "status_code": code, "success": success,
                    "timing_us": timing, "check": (e.get("check") or "").strip()})
    out.sort(key=lambda x: x["step"])
    return out


def generate(finding, steps, signature, scenario_name, upload_id, version=1, device=None, firmware=None, limit_us=None, nsid=1, block=512, name="test_case.py", outcome=None,
             expected_after=None):
    fault_step = next((s["step"] for s in steps if s.get("position") == "fault"), len(steps) or 1)
    outcome = outcome or {}
    expected_after = normalise_expected(expected_after, steps, fault_step)
    exp = outcome.get("expected") or {}
    observed = outcome.get("observed") or finding.get("name") or ""
    expected = ("%s; %s; check: %s" % (exp.get("status", ""), exp.get("description", ""), exp.get("check", ""))).strip("; ") if exp else "no finding at the fault step"
    verified_by = outcome.get("verified_by") or "nobody yet"
    rule = finding.get("rule") or ""
    code = RULE_CODE.get(rule, DEFAULT_RULE)
    if rule == "cmd.status_error":
        det = finding.get("detail") or {}
        code = code.format(sct=det.get("SCT") if det.get("SCT") is not None else "None", sc=det.get("SC") if det.get("SC") is not None else "None")
    lim = limit_us if limit_us is not None else ((finding.get("limit_ps") or 0) // 10 ** 6 or 30 * 10 ** 6)
    seq = [{k: v for k, v in s.items() if k in ("step", "command", "parameters", "gap_us", "expected", "admin", "position")} for s in steps]
    head = HEADER.format(observed=observed, expected=expected, verified_by=verified_by, scenario=scenario_name or "(not named)", signature=signature.get("display", ""), rule=rule, level=finding.get("level"),
                         upload=upload_id, finding=finding.get("id"), rows=",".join(str(s.get("source_row")) for s in steps if s.get("source_row")),
                         generated=time.strftime("%Y-%m-%d %H:%M:%S"), version=version, device=device or "unknown", firmware=firmware or "unknown",
                         name=name, nsid=nsid, timeout_s=max(5, int(lim / 1e6) + 5), limit_us=int(lim), block=block,
                         sequence=json.dumps(seq, indent=1), fault_step=fault_step)
    if expected_after:
        head += "\n# EXPECTED OUTCOMES FROM THE FAULT ONWARD (verified by %s):\n" % verified_by
        for e in expected_after:
            head += "#   step %d %s: %s%s%s\n" % (e["step"], e["command"], e["status"], (", within %d us" % e["timing_us"]) if e.get("timing_us") is not None else "",
                                                 ("; check: " + e["check"]) if e.get("check") else "")
    return head + BODY.format(rule_code=code, observed=observed, expected=expected, expected_after=json.dumps(expected_after, indent=1))
