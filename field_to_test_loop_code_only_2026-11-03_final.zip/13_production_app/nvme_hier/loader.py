"""Load the five per-level CSV exports into a SQLite staging database.

What the loader does, per file
  1. Reads the header. Aligns it with the known column list of that file (columns.py): named cells must appear
     in the known order; a blank header cell is either a separator column (the export puts one between field
     groups; dropped) or one of the label-less value columns ("16.0", "1 warning(s)", ...; kept and named).
     Anything that does not align is reported (unknown column kept under its own name, missing column listed).
  2. Streams the rows into one table per level. The typed key columns (times in picoseconds, identifiers as
     integers, data sizes in bytes) become real columns so the builder and the filters can use SQL; every other
     non-empty cell is kept in a compact JSON object (`raw`) so nothing from the file is lost and every number on
     the page can be traced to its file and row.
  3. Counts rows, blank key cells and unreadable cells per column, and keeps the first unreadable example.

The database is one file per upload (uploads/<id>/hier.sqlite) so an upload can be removed as a unit.

Memory: nothing that scales with the file is kept in RAM. Rows are read one at a time from the CSV and inserted in
batches; a transaction is committed every COMMIT_EVERY rows so the write-ahead log stays small; the blank-cell
counts are taken while streaming (no second pass over the table). open_db() sets the bulk PRAGMAs (page cache
~200 MB, synchronous off, temporary files next to the database rather than in /tmp, which is a RAM disk on this
machine) and the builder and the rules keep their own scratch tables in a second file (hier.work.sqlite) that is
attached while they run and removed afterwards, so every lookup table that grows with the capture lives on disk.
"""
import csv
import io
import json
import os
import sqlite3
import sys

from . import columns as C
from . import parse as P

csv.field_size_limit(min(sys.maxsize, 2 ** 31 - 1))

INSERT_BATCH = 5000          # rows per executemany
COMMIT_EVERY = 100000        # rows per transaction (bounds the WAL file during a load)
PROGRESS_EVERY = 500000      # rows between two progress reports
CACHE_KB = 200000            # SQLite page cache per connection, ~200 MB

# Typed key columns per level: canonical column name -> (sql column, parser)
# Several export names map to one sql column where the export splits a field by TLP class (Mem./Cpl./Msg.).
KEYS = {
    "packets": [
        ("Packet", "n", P.int_value), ("Link Dir", "dir", P.direction), ("Ord.Set Type", "os_type", P.text),
        ("DLLP Type", "dllp_type", P.text), ("TLP Type", "tlp_type", P.text), ("Link Event", "link_event", P.text),
        ("PSN", "psn", P.int_value), ("AckNak Seq Num", "acknak", P.int_value), ("VC ID", "vc", P.int_value),
        ("Length", "length", P.int_value), ("RequesterID", "rid", P.text), ("Tag", "tag", P.int_value),
        ("CompleterID", "cplid", P.text), ("Address", "addr", P.address), ("DeviceID", "devid", P.text),
        ("Register", "reg", P.text), ("Cpl Status", "cpl_status", P.text), ("Byte Cnt", "bytecnt", P.int_value),
        ("BCM", "bcm", P.int_value), ("Lwr Addr", "lwr", P.address), ("Message Code", "msgcode", P.text),
        ("EP", "ep", P.int_value), ("LCRC", "lcrc", P.text), ("ECRC", "ecrc", P.text), ("CRC 16", "crc16", P.text),
        ("DATA", "nbytes", P.data_bytes), ("Time Delta", "delta_ps", P.delta_ps), ("Time Stamp", "t_ps", P.time_stamp_ps),
        ("Errors", "errors", P.text), ("Marker", "marker", P.text),
    ],
    "link": [
        ("Link Tra", "n", P.int_value), ("Link Dir", "dir", P.direction), ("Link Speed", "speed", P.text),
        ("Link Tra Error", "errors", P.text), ("PSN", "psn", P.int_value),
        ("Mem.TLP Type", "tlp_type", P.text), ("Cpl.TLP Type", "tlp_type", P.text), ("Msg.TLP Type", "tlp_type", P.text),
        ("Mem.Attributes", "attr", P.text),
        ("Mem.Length", "length", P.int_value), ("Cpl.Length", "length", P.int_value), ("Msg.Length", "length", P.int_value),
        ("RequesterID", "rid", P.text), ("Tag", "tag", P.int_value), ("Address", "addr", P.address),
        ("1st BE", "fbe", P.text), ("Last BE", "lbe", P.text), ("Data", "nbytes", P.data_bytes), ("VC ID", "vc", P.int_value),
        ("Metrics.# Packets", "n_packets", P.int_value), ("Time Delta", "delta_ps", P.delta_ps),
        ("Time Stamp", "t_ps", P.time_stamp_ps), ("CompleterID", "cplid", P.text), ("Cpl Status", "cpl_status", P.text),
        ("BCM", "bcm", P.int_value), ("Byte Cnt", "bytecnt", P.int_value), ("Lwr Addr", "lwr", P.address),
        ("Explicit ACK", "explicit_ack", P.text), ("Msg.Msg Routing", "routing", P.text), ("Message Code", "msgcode", P.text),
    ],
    "split": [
        ("Split Tra", "n", P.int_value), ("Link Dir", "dir", P.direction), ("Link Speed", "speed", P.text),
        ("Split Tra Error", "errors", P.text), ("Mem.TLP Type", "tlp_type", P.text), ("RequesterID", "rid", P.text), ("CompleterID", "cplid", P.text),
        ("Tag", "tag", P.int_value), ("TC", "tc", P.int_value), ("VC ID", "vc", P.int_value), ("Address", "addr", P.address),
        ("Cpl Status", "cpl_status", P.text), ("Data", "nbytes", P.data_bytes),
        ("Metrics.# LinkTrans", "n_links", P.int_value), ("Time Delta", "delta_ps", P.delta_ps),
        ("Time Stamp", "t_ps", P.time_stamp_ps),
    ],
    "nvme_transaction": [
        ("NVMe", "n", P.int_value), ("Link Dir", "dir", P.direction), ("Device ID", "devid", P.text),
        ("QID", "qid", P.int_value), ("QSIZE", "qsize", P.int_value), ("Address", "addr", P.address), ("Type", "type", P.text),
        ("Doorbell index", "db_index", P.int_value), ("SQID", "sqid", P.int_value), ("CID", "cid", P.int_value),
        ("P", "phase", P.int_value), ("DW0", "dw0", P.text), ("ST", "st", P.text), ("SCT", "sct", P.int_value),
        ("SC", "sc", P.int_value), ("CRD", "crd", P.int_value), ("M", "more", P.int_value), ("DNR", "dnr", P.int_value),
        ("MN", "mn", P.text), ("Metrics.# Link & Split Trans", "n_links_splits", P.int_value),
        ("Time Delta", "delta_ps", P.delta_ps), ("Time Stamp", "t_ps", P.time_stamp_ps),
        ("MPTR.Address", "mptr", P.address), ("PRP1.Address", "prp1", P.address), ("PRP2.Address", "prp2", P.address),
        ("SLBA", "slba", P.int_value), ("NLB", "nlb", P.int_value), ("Data", "nbytes", P.data_bytes),
        ("Errors", "errors", P.text), ("Warnings", "warnings", P.text),
    ],
    "nvme_command": [
        ("NVMe Cmd", "n", P.int_value), ("Link Dir", "dir", P.direction), ("OPC", "opc", P.int_value),
        ("SQID", "sqid", P.int_value), ("CQID", "cqid", P.int_value), ("CID", "cid", P.int_value),
        ("Data", "nbytes", P.data_bytes), ("MPTR", "mptr", P.address), ("PRP1", "prp1", P.address), ("PRP2", "prp2", P.address),
        ("SLBA", "slba", P.int_value), ("NLB", "nlb", P.int_value), ("FUA", "fua", P.int_value), ("LR", "lr", P.int_value),
        ("ST", "st", P.text), ("ST.SCT", "sct", P.int_value), ("ST.SC", "sc", P.int_value),
        ("Device ID", "devid", P.text), ("MN", "mn", P.text), ("NSID", "nsid", P.int_value),
        ("Metrics.# NVME Trans", "n_ntx", P.int_value), ("Time Delta", "delta_ps", P.delta_ps),
        ("Time Stamp", "t_ps", P.time_stamp_ps), ("Warnings", "warnings", P.text), ("Errors", "errors", P.text),
        ("Errors#2", "errors2", P.text), ("AD", "ad", P.int_value), ("NR", "nr", P.int_value),
        ("CNS", "cns", P.int_value), ("FID", "fid", P.int_value), ("LID", "lid", P.int_value), ("QID", "qid", P.int_value),
        ("QSIZE", "qsize", P.int_value), ("NUSE", "nuse", P.int_value), ("DLFEAT.Bits 0-2", "dlfeat", P.int_value),
    ],
}
TABLE = {"packets": "pkt", "link": "lnk", "split": "spl", "nvme_transaction": "ntx", "nvme_command": "cmd"}
TEXT_COLS = {"dir", "os_type", "dllp_type", "tlp_type", "link_event", "rid", "cplid", "devid", "reg", "cpl_status",
             "msgcode", "lcrc", "ecrc", "crc16", "errors", "marker", "speed", "attr", "fbe", "lbe", "explicit_ack",
             "routing", "type", "dw0", "st", "mn", "warnings", "errors2"}


class HeaderAlignment:
    """Result of aligning a file header with the known list."""

    def __init__(self):
        self.positions = {}        # canonical name -> column index in the file
        self.separators = []       # column indices dropped
        self.unknown = []          # (index, header text) kept under their own name
        self.missing = []          # canonical names not found
        self.renamed = {}          # canonical name -> what the header cell held ("" for label-less)
        self.header_format = "single row"
        self.known = set()         # the canonical names of this file (to tell known columns from extras)

    def extras(self):
        """Columns kept that are not in the customer's list (known extras and group-named cells), in file order."""
        return [n for n, _ in sorted(self.positions.items(), key=lambda kv: kv[1]) if n not in self.known]

    def report(self, file_key):
        return {
            "expected_named_columns": C.expected_count(file_key),
            "found_named_columns": sum(1 for n in self.positions if n in self.known),
            "extra_columns_kept": self.extras(),
            "separator_columns_dropped": len(self.separators),
            "label_less_columns_named": {k: v for k, v in self.renamed.items() if v == ""},
            "unknown_columns": [{"index": i, "header": h} for i, h in self.unknown],
            "missing_columns": self.missing,
            "header_format": self.header_format,
        }


def _blank_runs(hdr):
    """Runs of consecutive blank header cells: list of (start, end_exclusive)."""
    runs = []
    j = 0
    while j < len(hdr):
        if hdr[j] == "":
            k = j
            while k < len(hdr) and hdr[k] == "":
                k += 1
            runs.append((j, k))
            j = k
        else:
            j += 1
    return runs


import re as _re

_LABEL_LESS_TEXT = _re.compile(r"^(\d+(\.\d+)?|\d+ (warning|error)\(s\))$")


def _norm(cell):
    """Spelling-insensitive form of a header cell: case, underscores and repeated spaces do not matter
    (the analyzer wrote AckNak_Seq_Num in one export and AckNak Seq Num in another)."""
    return " ".join((cell or "").replace("_", " ").split()).lower()


def _looks_label_less(cell):
    """A header cell that holds the first row's text instead of a label: "16.0" (the link speed),
    "1 warning(s)", "2 error(s)". The analyzer writes these in some exports; others leave the cell blank."""
    return bool(_LABEL_LESS_TEXT.match((cell or "").strip()))


def align_header(file_key, header, has_value=None):
    """Walk the known list against the header cells in order (see module docstring).

    has_value: set of header indices known to hold a value in at least one row. It is only consulted for a run
    of blank header cells that must contain both separators and label-less columns; a column with no value
    anywhere is a separator by the customer's own definition.

    Two header layouts are accepted (seen on the customer's analyzer, 2026-11-02 and 2026-11-03):
      A. label-less cells blank, sub-columns written with their group ("ST.SCT", "Metrics.# NVME Trans");
      B. label-less cells holding the first row's text ("16.0", "1 warning(s)"), sub-columns bare ("SCT",
         "# NVME Trans") right after their group cell ("ST", "Metrics"), few or no blank separator columns.
    Names are compared spelling-insensitively (case, underscores, repeated spaces)."""
    known = C.canonical_names(file_key)
    orig = C.original_names(file_key)
    label_less = set(C.label_less_positions(file_key))
    extras = set(C.KNOWN_EXTRAS.get(file_key, []))
    hdr = [(h or "").strip().lstrip("\ufeff") for h in header]
    hn = [_norm(h) for h in hdr]
    has_value = has_value or set()
    al = HeaderAlignment()
    al.known = set(known)
    group_extra = [None]       # an extra group cell just passed ("Cfg"): the bare cells after it belong to it

    def keep_unknown(idx, cell):
        if group_extra[0]:
            al.positions[group_extra[0] + "." + cell] = idx
        else:
            al.unknown.append((idx, cell))

    known_set = set(known)

    def _same(cell, want):
        if not want:
            return False
        if cell == want or _norm(cell) == _norm(want):
            return True
        # the customer's script numbered the second of two same-named columns (CSI, CSI#2); the export does not
        base = _re.sub(r"#\d+$", "", want)
        return base != want and _norm(cell) == _norm(base)

    def _bare(name):
        # "ST.SCT" -> "SCT" when "ST" is itself a column (the group cell) of this file; else None
        prefix, _, sub = name.partition(".")
        return sub if sub and prefix in known_set and name not in C.LABEL_LESS.values() else None

    def _ahead(start, *wants):
        ws = set()
        for w in wants:
            if w:
                ws.add(_norm(w))
                ws.add(_norm(_re.sub(r"#\d+$", "", w)))
        return any(x in ws for x in hn[start:])
    j = 0
    i = 0
    while i < len(known):
        name = known[i]
        if i in label_less:
            # gather the group of consecutive label-less names expected here
            grp = [i]
            while grp[-1] + 1 < len(known) and (grp[-1] + 1) in label_less:
                grp.append(grp[-1] + 1)
            # layout B: the cells hold the first row's text ("16.0", "1 warning(s)") instead of being blank
            k = j
            taken = []
            while len(taken) < len(grp):
                m = k
                while m < len(hdr) and hdr[m] == "":
                    m += 1
                if m < len(hdr) and (hdr[m] == orig[grp[len(taken)]] or _looks_label_less(hdr[m])):
                    al.separators.extend(range(k, m))
                    taken.append(m)
                    k = m + 1
                else:
                    break
            if taken:
                for g, x in zip(grp, taken):
                    al.positions[known[g]] = x
                    al.renamed[known[g]] = hdr[x]
                al.missing.extend(known[g] for g in grp[len(taken):])
                al.header_format = "first-row text in the label-less cells"
                j = k
                i = grp[-1] + 1
                continue
            # layout A: the blank run at the current header position
            while j < len(hdr) and hdr[j] != "":
                # a named cell where blanks were expected: unknown column, keep it
                keep_unknown(j, hdr[j])
                j += 1
            k = j
            while k < len(hdr) and hdr[k] == "":
                k += 1
            run = list(range(j, k))
            if len(run) == len(grp):
                chosen = run
            elif len(run) > len(grp):
                valued = [x for x in run if x in has_value]
                chosen = valued[:len(grp)]
                if len(chosen) < len(grp):          # the rest are empty columns either way
                    rest = [x for x in run if x not in chosen]
                    chosen = sorted(chosen + rest[len(rest) - (len(grp) - len(chosen)):])
                al.separators.extend(x for x in run if x not in chosen)
            else:
                chosen = run
                al.missing.extend(known[g] for g in grp[len(run):])
                grp = grp[:len(run)]
            for g, x in zip(grp, chosen):
                al.positions[known[g]] = x
                al.renamed[known[g]] = ""
            j = k
            i = grp[-1] + 1 if grp else i + 1
            continue
        found = False
        bare = _bare(name)
        while j < len(hdr):
            cell = hdr[j]
            if _same(cell, name) or _same(cell, orig[i]) or _same(cell, bare):
                al.positions[name] = j
                if cell != name:
                    al.renamed[name] = cell
                j += 1
                found = True
                group_extra[0] = None
                break
            if cell == "":
                al.separators.append(j)
                j += 1
                continue
            if cell in extras and cell not in known:
                al.positions[(group_extra[0] + "." + cell) if group_extra[0] and cell not in C.EXTRA_GROUPS else cell] = j
                group_extra[0] = cell if cell in C.EXTRA_GROUPS else group_extra[0]
                j += 1
                continue
            if _ahead(j + 1, name, orig[i], bare):
                keep_unknown(j, cell)
                j += 1
                continue
            break
        if not found:
            al.missing.append(name)
        i += 1
    while j < len(hdr):
        cell = hdr[j]
        if cell == "":
            al.separators.append(j)
        elif cell in extras:
            al.positions[(group_extra[0] + "." + cell) if group_extra[0] and cell not in C.EXTRA_GROUPS else cell] = j
            group_extra[0] = cell if cell in C.EXTRA_GROUPS else group_extra[0]
        else:
            keep_unknown(j, cell)
        j += 1
    # layout B, second pass: a sub-column written bare ("SCT") right after its group cell ("ST") stands for the
    # dotted name ("ST.SCT"). Only cells between the group cell and the next matched column of another group
    # qualify, so the three "Address" cells of MPTR, PRP1 and PRP2 each go to their own group.
    if al.missing and al.unknown:
        known_set = set(known)
        by_idx = {v: k for k, v in al.positions.items()}
        unk = dict(al.unknown)
        still = []
        for name in al.missing:
            prefix, _, sub = name.partition(".")
            p = al.positions.get(prefix) if (sub and prefix in known_set and name not in C.LABEL_LESS.values()) else None
            if p is None:
                still.append(name)
                continue
            limit = min([x for x, n in by_idx.items() if x > p and not n.startswith(prefix + ".")] or [len(hdr)])
            hit = next((x for x in sorted(unk) if p < x < limit and _norm(unk[x]) == _norm(sub)), None)
            if hit is None:
                still.append(name)
                continue
            al.positions[name] = hit
            al.renamed[name] = unk.pop(hit)
            by_idx[hit] = name
            al.header_format = "bare sub-column names after their group cell"
        al.missing = still
        al.unknown = sorted(unk.items())
    return al


def ambiguous_columns(file_key, header):
    """Header indices of blank runs that may hold both separators and label-less columns, with how many
    value-bearing columns must be found in each run before the scan can stop: [(run_indices, needed)]."""
    if not C.label_less_positions(file_key):
        return []
    hdr = [(h or "").strip().lstrip("\ufeff") for h in header]
    known = C.canonical_names(file_key)
    label_less = set(C.label_less_positions(file_key))
    # anchor = the named known column just before each label-less group
    out = []
    i = 0
    while i < len(known):
        if i in label_less:
            grp = [i]
            while grp[-1] + 1 < len(known) and (grp[-1] + 1) in label_less:
                grp.append(grp[-1] + 1)
            prev = known[i - 1] if i > 0 else None
            if prev in hdr:
                j = hdr.index(prev) + 1
                k = j
                while k < len(hdr) and hdr[k] == "":
                    k += 1
                if k - j > len(grp):
                    out.append((list(range(j, k)), len(grp)))
            i = grp[-1] + 1
        else:
            i += 1
    return out


def prescan_values(path, runs, max_rows=None):
    """Read rows until every ambiguous run has shown the needed number of value-bearing columns (or the file
    ends). Returns the set of header indices seen with a value."""
    seen = set()
    if not runs:
        return seen
    need = {tuple(r): n for r, n in runs}
    watch = [x for r, _ in runs for x in r]
    with open(path, "r", encoding="utf-8-sig", newline="") as fh:
        rd = csv.reader(fh)
        next(rd, None)
        for n, row in enumerate(rd, 1):
            for x in watch:
                if x < len(row) and row[x] != "":
                    seen.add(x)
            if all(sum(1 for x in r if x in seen) >= k for r, k in need.items()):
                break
            if max_rows and n >= max_rows:
                break
    return seen


def _schema(file_key):
    cols = []
    seen = set()
    for _, sql, _ in KEYS[file_key]:
        if sql in seen:
            continue
        seen.add(sql)
        cols.append("%s %s" % (sql, "TEXT" if sql in TEXT_COLS else "INTEGER"))
    return cols


def create_tables(con, file_key):
    t = TABLE[file_key]
    con.execute("DROP TABLE IF EXISTS %s" % t)
    con.execute("CREATE TABLE %s (rowid_file INTEGER PRIMARY KEY, %s, parent INTEGER, parent_level TEXT, "
                "relation TEXT, dur_ps INTEGER, raw TEXT)" % (t, ", ".join(_schema(file_key))))
    con.execute("CREATE INDEX ix_%s_parent ON %s (parent_level, parent)" % (t, t))


def load_file(con, file_key, path, limit=None, progress=None):
    """Stream one CSV into its table. Returns the load report (dict)."""
    t = TABLE[file_key]
    keys = KEYS[file_key]
    fb = open(path, "rb")
    with io.TextIOWrapper(fb, encoding="utf-8-sig", newline="") as fh:   # fb.tell() = bytes consumed, for the progress bar
        rd = csv.reader(fh)
        header = next(rd, None)
        if header is None:
            return {"file": file_key, "path": path, "rows": 0, "error": "empty file"}
        has_value = prescan_values(path, ambiguous_columns(file_key, header))
        al = align_header(file_key, header, has_value)
        create_tables(con, file_key)
        # typed columns present in this file
        typed = []
        sql_cols = []
        for cname, sql, fn in keys:
            if cname in al.positions and sql not in sql_cols:
                sql_cols.append(sql)
            if cname in al.positions:
                typed.append((al.positions[cname], sql, fn, cname))
        # every named column (for raw)
        named = sorted(al.positions.items(), key=lambda kv: kv[1])
        named += [(h, i) for i, h in al.unknown]
        ins = "INSERT INTO %s (rowid_file, %s, raw) VALUES (%s)" % (
            t, ", ".join(sql_cols), ", ".join(["?"] * (len(sql_cols) + 2)))
        unread = {}
        blanks = {sql: 0 for sql in sql_cols}
        n = 0
        batch = []
        con.commit()
        for row in rd:
            n += 1
            vals = {}
            for idx, sql, fn, cname in typed:
                cell = row[idx] if idx < len(row) else ""
                if cell == "":
                    if sql not in vals:
                        vals[sql] = None
                    continue
                v = fn(cell)
                if v is None:
                    u = unread.setdefault(cname, {"count": 0, "example": cell[:80]})
                    u["count"] += 1
                if sql in vals and vals[sql] is not None:
                    continue
                vals[sql] = v
            raw = {}
            for cname, idx in named:
                cell = row[idx] if idx < len(row) else ""
                if cell != "":
                    raw[cname] = cell
            typed_vals = [vals.get(s) for s in sql_cols]
            for sql, v in zip(sql_cols, typed_vals):
                if v is None:
                    blanks[sql] += 1
            batch.append([n] + typed_vals + [json.dumps(raw, separators=(",", ":"))])
            if len(batch) >= INSERT_BATCH:
                con.executemany(ins, batch)
                batch = []
                if n % COMMIT_EVERY == 0:
                    con.commit()
                if progress and n % PROGRESS_EVERY == 0:
                    progress(file_key, n, fb.tell())      # the callback may raise to cancel the load
            if limit and n >= limit:
                break
        if batch:
            con.executemany(ins, batch)
        con.commit()
    rep = al.report(file_key)
    rep.update({"file": file_key, "path": path, "rows": n, "unreadable_cells": unread, "blank_key_cells": blanks,
                "typed_columns": sql_cols})
    con.execute("CREATE INDEX IF NOT EXISTS ix_%s_t ON %s (t_ps)" % (t, t))
    if file_key == "packets":
        con.execute("CREATE INDEX IF NOT EXISTS ix_pkt_psn ON pkt (dir, psn)")
        con.execute("CREATE INDEX IF NOT EXISTS ix_pkt_tag ON pkt (rid, tag)")
    if file_key == "link":
        con.execute("CREATE INDEX IF NOT EXISTS ix_lnk_psn ON lnk (dir, psn)")
        con.execute("CREATE INDEX IF NOT EXISTS ix_lnk_tag ON lnk (rid, tag)")
    if file_key == "split":
        con.execute("CREATE INDEX IF NOT EXISTS ix_spl_tag ON spl (rid, tag)")
    if file_key == "nvme_transaction":
        con.execute("CREATE INDEX IF NOT EXISTS ix_ntx_q ON ntx (sqid, cid)")
    if file_key == "nvme_command":
        con.execute("CREATE INDEX IF NOT EXISTS ix_cmd_q ON cmd (sqid, cid)")
    con.commit()
    checkpoint(con)
    if progress:
        progress(file_key, n, os.path.getsize(path))
    return rep


def open_db(path):
    """Connection with the bulk settings: WAL (readers never block the job and the job never blocks the pages),
    no fsync while the job runs, a ~200 MB page cache, sorts and temporary tables spilled to files next to the
    database (not /tmp, which is a RAM disk here), 60 s busy wait."""
    con = sqlite3.connect(path, timeout=60)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=OFF")
    con.execute("PRAGMA temp_store=FILE")
    con.execute("PRAGMA cache_size=-%d" % CACHE_KB)
    con.execute("PRAGMA wal_autocheckpoint=20000")
    d = os.path.dirname(os.path.abspath(path))
    try:
        con.execute("PRAGMA temp_store_directory='%s'" % d.replace("'", "''"))
    except sqlite3.Error:
        pass
    con.execute("CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)")
    return con


def checkpoint(con):
    """Fold the write-ahead log back into the database and truncate it, so the WAL never keeps a copy of a
    whole pass on disk."""
    try:
        con.commit()
        con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    except sqlite3.Error:
        pass


def work_path(db_path):
    return os.path.splitext(db_path)[0] + ".work.sqlite"


def attach_work(con, db_path):
    """Attach the scratch database `w` (hier.work.sqlite next to the staging file). It holds the per-row lookup
    tables of the builder and the rules on disk; it starts empty every time and is deleted by drop_work()."""
    p = work_path(db_path)
    for f in (p, p + "-journal", p + "-wal", p + "-shm"):
        if os.path.exists(f):
            os.remove(f)
    con.commit()
    con.execute("ATTACH DATABASE ? AS w", (p,))
    con.execute("PRAGMA w.journal_mode=OFF")
    con.execute("PRAGMA w.synchronous=OFF")
    return p


def drop_work(con, db_path):
    p = work_path(db_path)
    try:
        con.commit()
        con.execute("DETACH DATABASE w")
    except sqlite3.Error:
        pass
    for f in (p, p + "-journal", p + "-wal", p + "-shm"):
        if os.path.exists(f):
            os.remove(f)


def set_meta(con, key, value):
    con.execute("INSERT OR REPLACE INTO meta (k, v) VALUES (?, ?)", (key, json.dumps(value)))
    con.commit()


def get_meta(con, key, default=None):
    r = con.execute("SELECT v FROM meta WHERE k = ?", (key,)).fetchone()
    return json.loads(r[0]) if r else default


def load_upload(db_path, files, limit=None, progress=None):
    """files: {file_key: path}. Loads every given file; returns {file_key: report}. Missing levels are simply
    absent from the result (the pages say so)."""
    con = open_db(db_path)
    reports = {}
    for key in C.LEVEL_ORDER:
        if key in files and files[key]:
            reports[key] = load_file(con, key, files[key], limit=limit, progress=progress)
    set_meta(con, "load_reports", reports)
    set_meta(con, "levels_present", [k for k in C.LEVEL_ORDER if k in reports])
    checkpoint(con)
    con.close()
    return reports


def sniff(path, n=3):
    """Header and first rows of a file, for the upload page's preview and for guessing which level a file is."""
    with open(path, "r", encoding="utf-8-sig", newline="") as fh:
        rd = csv.reader(fh)
        header = next(rd, [])
        rows = []
        for row in rd:
            rows.append(row)
            if len(rows) >= n:
                break
    return header, rows


def guess_level(header):
    """Which level a file is, from its first named header cells."""
    first = [h.strip() for h in header if h and h.strip()][:3]
    starts = {"packets": "Marker", "link": "Link Tra", "split": "Split Tra", "nvme_transaction": "NVMe",
              "nvme_command": "NVMe Cmd"}
    for key, name in sorted(starts.items(), key=lambda kv: -len(kv[1])):
        if first and first[0] == name:
            return key
    if first and first[0] == "Packet":
        return "packets"
    return None
