"""Sequence optimisation ("regeneration"): from the window of commands around a fault, keep above the fault only
the commands the failing command depends on, and below it only the commands the fault affected, so what remains
with its timing gaps is the minimal reproduction (research note 06, dependency rules D1–D9 and C1–C4).

Input rows are the command-level window rows as the API returns them (position above | fault | below, with
opc, sqid, cid, nsid, slba, nlb, fua, t_ps, dur_ps, raw, findings). Output: the same rows with `keep` (bool) and
`why` (the rule ids), plus `steps`: the ordered reproduction sequence with gaps.
"""
from . import names as N

STATE_CHANGING_ADMIN = {0x00, 0x01, 0x04, 0x05, 0x09, 0x0D, 0x10, 0x15, 0x19, 0x80, 0x81, 0x84, 0x7C}   # delete/create queues, set features, ns mgmt, fw commit, ns attach, directive send, format, security send, sanitize, doorbell buffer
RANGE_OPCS = {0x01, 0x02, 0x04, 0x05, 0x08, 0x09, 0x0C, 0x19}
RESERVATION_OPCS = {0x0D, 0x0E, 0x11, 0x15}
DEFAULT_GAP_US = 10
IDLE_GAP_PS = 100 * 10 ** 9      # a gap of 100 ms or more is kept as measured (idle power states, thermal, queue drain)


def _range(r):
    if r.get("sqid") == 0 or r.get("opc") not in RANGE_OPCS or r.get("slba") is None:
        return None
    nlb = r.get("nlb") if r.get("nlb") is not None else 0
    return (r.get("nsid"), r["slba"], r["slba"] + nlb)


def _dsm_ranges(r):
    """Dataset Management ranges from the raw cells (RNG n.SLBA / Length LB)."""
    out = []
    raw = r.get("raw") or {}
    nr = r.get("nr")
    if nr is None:
        try:
            nr = int(raw.get("NR", 0))
        except (TypeError, ValueError):
            nr = 0
    for i in range(min(64, (nr or 0) + 1)):
        s0, l0 = raw.get("RNG %d.SLBA" % i), raw.get("RNG %d.Length LB" % i)
        try:
            if s0 is not None and l0 is not None:
                out.append((r.get("nsid"), int(s0), int(s0) + int(l0) - 1))
        except ValueError:
            pass
    return out


def _overlaps(a, b):
    return a and b and a[0] == b[0] and a[1] <= b[2] and b[1] <= a[2]


def _ranges_of(r):
    if r.get("opc") == 0x09 and r.get("sqid") != 0:
        return _dsm_ranges(r) or ([_range(r)] if _range(r) else [])
    rg = _range(r)
    return [rg] if rg else []


def _outstanding_at(r, t):
    """True when command r was still open at time t (doorbell before t, completion after t)."""
    t0 = r.get("t_ps")
    if t0 is None or t is None:
        return False
    end = t0 + (r.get("dur_ps") or 0)
    return t0 <= t <= end


def step_of(r, step_no, why=None, gap_us=None):
    """One reproduction step from a command-level window row (also used by the isolation tab's evidence loop, which
    assembles the sequence from the model's chosen rows above the fault and the rows below it copied unchanged)."""
    why = why if why is not None else r.get("why")
    step = {"step": step_no, "command": N.opcode_name(r.get("opc"), r.get("sqid")),
            "opc": r.get("opc"), "admin": r.get("sqid") == 0, "queue": r.get("sqid"),
            "parameters": {k: r.get(k) for k in ("nsid", "slba", "nlb", "fua") if r.get(k) is not None},
            "gap_us": int(gap_us if gap_us is not None else (r.get("gap_us") or DEFAULT_GAP_US)), "source_row": r.get("rowid_file"), "position": r.get("position"),
            "why": why}
    if r.get("opc") == 0x09 and r.get("sqid") != 0:
        step["parameters"]["ranges"] = [[s, e - s + 1] for _, s, e in _dsm_ranges(r)]
        step["parameters"]["deallocate"] = bool(r.get("ad"))
    if r.get("position") == "fault":
        step["expected"] = "the detection rule fires here: " + "; ".join(x.get("name", "") for x in (r.get("findings") or [])) if r.get("findings") else "the fault"
    elif r.get("position") == "below":
        step["expected"] = "affected by the fault (" + "; ".join(why or []) + ")" if why else "as recorded after the fault"
    else:
        step["expected"] = "completes normally (sets up state: " + "; ".join(why or []) + ")"
    return step


def optimise(rows, gap_threshold_ps=IDLE_GAP_PS):
    rows = [dict(r) for r in rows]
    fault = next((r for r in rows if r.get("position") == "fault"), None)
    if fault is None:
        return {"rows": rows, "steps": [], "note": "no fault row in the window"}
    above = [r for r in rows if r.get("position") == "above"]
    below = [r for r in rows if r.get("position") == "below"]
    f_ranges = _ranges_of(fault)
    ft = fault.get("t_ps")
    for r in above:
        why = []
        rg = _ranges_of(r)
        if any(_overlaps(a, b) for a in rg for b in f_ranges):
            why.append("D1 same namespace, overlapping LBA range")
        if r.get("sqid") == fault.get("sqid") and _outstanding_at(r, ft):
            why.append("D2 same queue, still open when the fault was submitted")
        if r.get("sqid") == 0 and r.get("opc") in STATE_CHANGING_ADMIN:
            why.append("D3 admin command that changes controller, queue or feature state")
        if r.get("sqid") != 0 and r.get("opc") == 0x00:
            why.append("D4 flush: ordering barrier")
        if r.get("sqid") != 0 and r.get("opc") == 0x01 and r.get("fua"):
            why.append("D4 write with FUA: ordering barrier")
        raw = r.get("raw") or {}
        if str(raw.get("FUSE", "0")) not in ("0", "", "0x0"):
            why.append("D5 half of a fused pair")
        if r.get("sqid") != 0 and r.get("opc") in RESERVATION_OPCS and r.get("nsid") == fault.get("nsid"):
            why.append("D6 reservation on the same namespace")
        r["keep"] = bool(why)
        r["why"] = why
    # D9 transitive closure: a kept command's own dependencies (one pass, range overlap and barriers)
    kept = [r for r in above if r["keep"]]
    for r in above:
        if r["keep"]:
            continue
        rg = _ranges_of(r)
        if any(_overlaps(a, b) for k in kept for a in rg for b in _ranges_of(k)):
            r["keep"] = True
            r["why"] = ["D9 a kept command depends on it (overlapping range)"]
    # D7 gaps: a long measured gap before a kept command or the fault is kept as measured
    seq = [r for r in above if r["keep"]] + [fault]
    prev_t = None
    for r in seq:
        t = r.get("t_ps")
        gap = (t - prev_t) if (t is not None and prev_t is not None) else None
        if gap is not None and gap >= gap_threshold_ps:
            r.setdefault("why", []).append("D7 long gap before it kept as measured (%d ms)" % (gap // 10 ** 9))
            r["gap_us"] = gap // 10 ** 6
        else:
            r["gap_us"] = DEFAULT_GAP_US if gap is None or gap > DEFAULT_GAP_US * 10 ** 6 else max(1, gap // 10 ** 6)
        prev_t = t
    fault["keep"] = True
    fault["why"] = ["the fault"]
    fault.setdefault("gap_us", DEFAULT_GAP_US)
    for r in below:
        why = []
        if r.get("sqid") == fault.get("sqid") and r.get("t_ps") is not None and ft is not None and r["t_ps"] <= ft + (fault.get("dur_ps") or 0):
            why.append("C1 same queue, queued behind the fault")
        if any(_overlaps(a, b) for a in _ranges_of(r) for b in f_ranges):
            why.append("C2 touches the same LBA range after the fault")
        if r.get("findings"):
            why.append("C3 carries a finding of its own (cascade)")
        if r.get("sqid") == 0 and r.get("opc") in (0x08, 0x00, 0x04):
            why.append("C4 host reaction: abort or queue deletion")
        r["keep"] = bool(why)
        r["why"] = why
        r["gap_us"] = DEFAULT_GAP_US
    steps = []
    for r in [x for x in above if x["keep"]] + [fault] + [x for x in below if x["keep"]]:
        steps.append(step_of(r, len(steps) + 1))
    return {"rows": rows, "steps": steps, "kept_above": sum(1 for r in above if r["keep"]), "dropped_above": sum(1 for r in above if not r["keep"]),
            "kept_below": sum(1 for r in below if r["keep"]), "dropped_below": sum(1 for r in below if not r["keep"])}
