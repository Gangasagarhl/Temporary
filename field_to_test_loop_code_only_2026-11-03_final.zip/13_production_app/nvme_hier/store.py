"""Stored procedures per signature, the admin's order, and the four signals (research note 05).

One SQLite file (db/hier_knowledge.sqlite). Nothing is trained: a procedure carries two counts a and b
(Beta-Bernoulli, prior 1/1) and its score is a / (a + b), shown as "N of 100" with the plain counts. The admin's
explicit order, once given, is used verbatim until the next write to that signature's procedures.

Signals (exactly four):
  correct              a += 1
  correct_with_edits   a += 1 on the old version, which becomes superseded; the edited steps become a new version
                       that inherits 0.7 of the old evidence (a' = 1 + 0.7 (a-1), b' = 1 + 0.7 (b-1))
  wrong                b += 1
  wrong_with_edits     b += 1 on the old version (superseded); the edited steps become a new version with a = 2, b = 1
Before every signal, every active procedure of that signature decays 2 % towards the prior; after it, a + b is
capped at 50. A fresh model proposal that gets 'correct' or 'correct_with_edits' is stored as version 1 with
a = 2, b = 1; 'wrong' stores only a lesson; 'wrong_with_edits' stores the edited steps as version 1.
Every write is also appended to an event log so the history can be read back.
"""
import hashlib
import json
import os
import sqlite3
import time

SIGNALS = ("correct", "correct_with_edits", "wrong", "wrong_with_edits")
DECAY = 0.02
CAP = 50.0
INHERIT = 0.7

SCHEMA = """
CREATE TABLE IF NOT EXISTS signature (fine TEXT PRIMARY KEY, coarse TEXT, display TEXT, fields TEXT, first_seen REAL, seen INTEGER DEFAULT 0,
  device TEXT, scenario_name TEXT, alg TEXT);
CREATE INDEX IF NOT EXISTS ix_sig_coarse ON signature (coarse);
CREATE TABLE IF NOT EXISTS procedure (id INTEGER PRIMARY KEY, fine TEXT, version INTEGER, vhash TEXT, supersedes INTEGER, steps TEXT, text TEXT,
  test_path TEXT, producer TEXT, created REAL, status TEXT, a REAL, b REAL, c_ok INTEGER DEFAULT 0, c_ok_edit INTEGER DEFAULT 0,
  c_wrong INTEGER DEFAULT 0, c_wrong_edit INTEGER DEFAULT 0, scenario_name TEXT, validated_on TEXT, outcome TEXT);
CREATE INDEX IF NOT EXISTS ix_proc_fine ON procedure (fine, status);
CREATE TABLE IF NOT EXISTS procedure_order (fine TEXT PRIMARY KEY, order_json TEXT, valid INTEGER, set_by TEXT, at REAL);
CREATE TABLE IF NOT EXISTS signal (id INTEGER PRIMARY KEY, fine TEXT, procedure_id INTEGER, signal TEXT, admin TEXT, at REAL, edits TEXT,
  new_procedure_id INTEGER, upload_id TEXT, finding_id INTEGER);
CREATE TABLE IF NOT EXISTS lesson (id INTEGER PRIMARY KEY, fine TEXT, text TEXT, producer TEXT, at REAL);
CREATE TABLE IF NOT EXISTS event (id INTEGER PRIMARY KEY, kind TEXT, payload TEXT, at REAL);
CREATE TABLE IF NOT EXISTS chat (id INTEGER PRIMARY KEY, upload_id TEXT, finding_id INTEGER, fine TEXT, role TEXT, text TEXT, data TEXT, at REAL);
"""


def vhash(steps):
    return hashlib.sha256(json.dumps(steps, sort_keys=True, separators=(",", ":")).encode()).hexdigest()[:16]


def score(a, b):
    return a / (a + b) if (a + b) > 0 else 0.5


class Store:
    def __init__(self, path):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)
        con = self._con()
        con.executescript(SCHEMA)
        con.commit()
        con.close()

    def _con(self):
        con = sqlite3.connect(self.path, timeout=30)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA journal_mode=WAL")
        if not getattr(self, "_outcome_col", False) and con.execute("SELECT 1 FROM sqlite_master WHERE name='procedure'").fetchone():
            cols = [r[1] for r in con.execute("PRAGMA table_info(procedure)")]
            if cols and "outcome" not in cols:
                con.execute("ALTER TABLE procedure ADD COLUMN outcome TEXT")      # {observed, expected{status,description,check}, verified_by}
                con.commit()
            # the isolation tab (statement of 2026-11-03, part 6): the error reason in words and the four-line summary
            # live on the signature row, next to the device name and the scenario name
            scols = [r[1] for r in con.execute("PRAGMA table_info(signature)")]
            for col in ("device", "reason", "summary4", "reason_by", "summary_by", "firmware"):
                if scols and col not in scols:
                    con.execute("ALTER TABLE signature ADD COLUMN %s TEXT" % col)
            con.commit()
            self._outcome_col = True
        return con

    def _event(self, con, kind, payload):
        con.execute("INSERT INTO event (kind, payload, at) VALUES (?, ?, ?)", (kind, json.dumps(payload, default=str), time.time()))

    # ------------------------------------------------------------------ signatures
    def touch_signature(self, sig, device=None, upload_id=None, finding_id=None):
        """Register a signature as seen (sig = signature.compute() result). Returns the seen count after this.
        With upload_id + finding_id the sighting is counted once: opening the same defect again does not add."""
        con = self._con()
        con.execute("CREATE TABLE IF NOT EXISTS sighting (fine TEXT, upload_id TEXT, finding_id INTEGER, at REAL, PRIMARY KEY (fine, upload_id, finding_id))")
        r = con.execute("SELECT seen FROM signature WHERE fine=?", (sig["fine"],)).fetchone()
        if upload_id is not None and finding_id is not None:
            already = con.execute("SELECT 1 FROM sighting WHERE fine=? AND upload_id=? AND finding_id=?", (sig["fine"], upload_id, finding_id)).fetchone()
            if already and r is not None:
                con.close()
                return r["seen"]
            con.execute("INSERT OR IGNORE INTO sighting VALUES (?,?,?,?)", (sig["fine"], upload_id, finding_id, time.time()))
        if r is None:
            con.execute("INSERT INTO signature (fine, coarse, display, fields, first_seen, seen, device, alg) VALUES (?,?,?,?,?,1,?,?)",
                        (sig["fine"], sig["coarse"], sig["display"], json.dumps(sig["fields"]), time.time(), device, sig["fields"].get("alg")))
            seen = 1
        else:
            seen = r["seen"] + 1
            con.execute("UPDATE signature SET seen=? WHERE fine=?", (seen, sig["fine"]))
        self._event(con, "signature_seen", {"fine": sig["fine"], "seen": seen})
        con.commit()
        con.close()
        return seen

    def sightings(self, fine):
        """Where this exact signature was seen: [{upload_id, finding_id, at}] (one row per upload and finding)."""
        con = self._con()
        con.execute("CREATE TABLE IF NOT EXISTS sighting (fine TEXT, upload_id TEXT, finding_id INTEGER, at REAL, PRIMARY KEY (fine, upload_id, finding_id))")
        rows = [dict(r) for r in con.execute("SELECT upload_id, finding_id, at FROM sighting WHERE fine=? ORDER BY at", (fine,))]
        con.close()
        return rows

    def set_scenario_name(self, fine, name, producer):
        con = self._con()
        con.execute("UPDATE signature SET scenario_name=? WHERE fine=?", (name, fine))
        self._event(con, "scenario_named", {"fine": fine, "name": name, "producer": producer})
        con.commit()
        con.close()

    def set_reason(self, fine, reason, by):
        """The error reason in words (named by the model, confirmed by the admin), kept on the signature row."""
        con = self._con()
        con.execute("UPDATE signature SET reason=?, reason_by=? WHERE fine=?", (reason, by, fine))
        self._event(con, "reason_set", {"fine": fine, "reason": reason, "by": by})
        con.commit()
        con.close()

    def set_summary(self, fine, text, by):
        """The four-line summary (what happened, where, why, what the test checks), kept on the signature row."""
        con = self._con()
        con.execute("UPDATE signature SET summary4=?, summary_by=? WHERE fine=?", (text, by, fine))
        self._event(con, "summary_set", {"fine": fine, "by": by})
        con.commit()
        con.close()

    def set_device(self, fine, device, firmware=None):
        con = self._con()
        con.execute("UPDATE signature SET device=COALESCE(?, device), firmware=COALESCE(?, firmware) WHERE fine=?", (device, firmware, fine))
        con.commit()
        con.close()

    def lookup(self, sig):
        """{'seen': n, 'first_seen', 'scenario_name', 'reason', 'summary4', 'device', 'exact': [procedures in display order], 'similar': [...]}."""
        con = self._con()
        s = con.execute("SELECT * FROM signature WHERE fine=?", (sig["fine"],)).fetchone()
        exact = self._procedures(con, sig["fine"])
        similar = []
        for r in con.execute("SELECT fine, display, scenario_name, seen, device, reason, summary4 FROM signature WHERE coarse=? AND fine!=?", (sig["coarse"], sig["fine"])):
            procs = self._procedures(con, r["fine"])
            similar.append({"fine": r["fine"], "display": r["display"], "scenario_name": r["scenario_name"], "seen": r["seen"], "procedures": procs,
                            "device": r["device"], "reason": r["reason"], "summary4": r["summary4"]})
        lessons = [dict(r) for r in con.execute("SELECT id, text, producer, at FROM lesson WHERE fine=? ORDER BY at DESC", (sig["fine"],))]
        con.close()
        return {"seen": s["seen"] if s else 0, "first_seen": s["first_seen"] if s else None,
                "scenario_name": s["scenario_name"] if s else None, "reason": s["reason"] if s else None, "summary4": s["summary4"] if s else None,
                "device": s["device"] if s else None, "exact": exact, "similar": similar, "lessons": lessons}

    # ------------------------------------------------------------------ retrieval context ("RAG", research note 10)
    def retrieve(self, sig, device=None, limit=12):
        """The stored facts a new defect with this signature should be told about, as plain-text facts, ranked:
        tier 1 the exact signature (the fine key: this very defect on this device and firmware),
        tier 2 the same defect on other devices or firmware (the family key, the coarse key of the signature),
        tier 3 the same rule at the same level on any command (the wider family: level + rule of the key).
        Inside a tier: more sightings first, then more stored procedures. Each fact carries the device, the reason,
        the scenario name, the best procedure's sequence and score, the expected outcome, the lessons and the summary.
        Returns a list of dicts with 'tier', 'text' (one plain paragraph for the prompt) and the raw fields."""
        con = self._con()
        fields = sig.get("fields") or {}
        lvl, err = fields.get("lvl"), fields.get("err")
        out, seen_fine = [], set()

        def facts_of(row, tier, why):
            procs = self._procedures(con, row["fine"])
            lessons = [r["text"] for r in con.execute("SELECT text FROM lesson WHERE fine=? ORDER BY at DESC LIMIT 5", (row["fine"],))]
            best = procs[0] if procs else None
            f = {"tier": tier, "why": why, "fine": row["fine"], "display": row["display"], "device": row["device"], "firmware": row["firmware"] if "firmware" in row.keys() else None,
                 "seen": row["seen"], "scenario_name": row["scenario_name"], "reason": row["reason"], "summary4": row["summary4"],
                 "procedures": len(procs), "best": None, "lessons": lessons}
            if best:
                f["best"] = {"id": best["id"], "version": best["version"], "score_text": best["score_text"], "a": best["a"], "b": best["b"],
                             "counts": {"correct": best["c_ok"], "correct_with_edits": best["c_ok_edit"], "wrong": best["c_wrong"], "wrong_with_edits": best["c_wrong_edit"]},
                             "steps": best["steps"], "outcome": best.get("outcome"), "test_path": best.get("test_path")}
            parts = ["%s (%s): seen %d time%s on device %s" % (why, "tier %d" % tier, row["seen"] or 0, "" if row["seen"] == 1 else "s", row["device"] or "unknown")]
            if row["reason"]:
                parts.append("reason: %s" % row["reason"])
            if row["scenario_name"]:
                parts.append("scenario: %s" % row["scenario_name"])
            if best:
                parts.append("best stored sequence (version %s, score %s from %d correct / %d wrong signals): %s" % (
                    best["version"], best["score_text"], best["c_ok"] + best["c_ok_edit"], best["c_wrong"] + best["c_wrong_edit"],
                    " -> ".join("%s%s" % (s_.get("command"), (" " + json.dumps(s_.get("parameters"))) if s_.get("parameters") else "") for s_ in best["steps"][:12])))
                exp = (best.get("outcome") or {}).get("expected") or {}
                if exp.get("status"):
                    parts.append("expected outcome of a correct device: %s; check: %s" % (exp.get("status"), exp.get("check") or "-"))
            elif procs == [] and tier == 1:
                parts.append("no sequence stored yet")
            for les in lessons[:3]:
                parts.append("lesson: %s" % les[:200])
            if row["summary4"]:
                parts.append("summary: " + " / ".join(x.strip() for x in row["summary4"].splitlines() if x.strip()))
            f["text"] = "; ".join(parts)
            return f

        cols = "fine, coarse, display, seen, device, firmware, scenario_name, reason, summary4, fields"
        r = con.execute("SELECT %s FROM signature WHERE fine=?" % cols, (sig["fine"],)).fetchone()
        if r is not None:
            out.append(facts_of(r, 1, "this exact defect on this device"))
            seen_fine.add(r["fine"])
        for r in con.execute("SELECT %s FROM signature WHERE coarse=? AND fine!=? ORDER BY seen DESC" % cols, (sig["coarse"], sig["fine"])):
            same_dev = (device or "").strip().upper() and (r["device"] or "").strip().upper() == (device or "").strip().upper()
            out.append(facts_of(r, 2, "the same defect on " + ("this device with other firmware" if same_dev else "another device (%s)" % (r["device"] or "unknown"))))
            seen_fine.add(r["fine"])
        if lvl and err:
            for r in con.execute("SELECT %s FROM signature WHERE coarse!=? ORDER BY seen DESC LIMIT 200" % cols, (sig["coarse"],)):
                if r["fine"] in seen_fine:
                    continue
                try:
                    f2 = json.loads(r["fields"] or "{}")
                except ValueError:
                    f2 = {}
                if f2.get("lvl") == lvl and f2.get("err") == err:
                    out.append(facts_of(r, 3, "the same rule (%s) at the same level on another command (%s)" % (err, f2.get("cmd"))))
                    seen_fine.add(r["fine"])
        con.close()
        out.sort(key=lambda f: (f["tier"], -(f["seen"] or 0), -f["procedures"]))
        for i, f in enumerate(out):
            f["rank"] = i + 1
        return out[:limit]

    def _procedures(self, con, fine):
        rows = [dict(r) for r in con.execute("SELECT * FROM procedure WHERE fine=? AND status='active'", (fine,))]
        for r in rows:
            r["steps"] = json.loads(r["steps"]) if r["steps"] else []
            r["outcome"] = json.loads(r["outcome"]) if r.get("outcome") else None
            r["score"] = round(score(r["a"], r["b"]), 3)
            r["score_text"] = "%d of 100" % round(100 * r["score"])
        order = con.execute("SELECT order_json, valid FROM procedure_order WHERE fine=?", (fine,)).fetchone()
        if order and order["valid"]:
            want = json.loads(order["order_json"])
            pos = {pid: i for i, pid in enumerate(want)}
            rows.sort(key=lambda r: (pos.get(r["id"], len(want)), -r["score"], -r["created"]))
            for r in rows:
                r["ordered_by"] = "the admin's order"
        else:
            rows.sort(key=lambda r: (-r["score"], -r["version"], r["created"]))
            for r in rows:
                r["ordered_by"] = "score"
        return rows

    # ------------------------------------------------------------------ procedures and signals
    def add_procedure(self, fine, steps, text, producer, test_path=None, scenario_name=None, a=2.0, b=1.0, supersedes=None, version=None, outcome=None):
        con = self._con()
        if version is None:
            v = con.execute("SELECT COALESCE(MAX(version), 0) + 1 FROM procedure WHERE fine=?", (fine,)).fetchone()[0]
        else:
            v = version
        cur = con.execute("INSERT INTO procedure (fine, version, vhash, supersedes, steps, text, test_path, producer, created, status, a, b, scenario_name, outcome) "
                          "VALUES (?,?,?,?,?,?,?,?,?,'active',?,?,?,?)",
                          (fine, v, vhash(steps), supersedes, json.dumps(steps), text, test_path, producer, time.time(), a, b, scenario_name,
                           json.dumps(outcome) if outcome else None))
        pid = cur.lastrowid
        con.execute("UPDATE procedure_order SET valid=0 WHERE fine=?", (fine,))
        self._event(con, "procedure_added", {"fine": fine, "id": pid, "version": v, "producer": producer, "supersedes": supersedes})
        con.commit()
        con.close()
        return pid

    def set_test_path(self, procedure_id, path):
        con = self._con()
        con.execute("UPDATE procedure SET test_path=? WHERE id=?", (path, procedure_id))
        con.commit()
        con.close()

    def _decay_and_cap(self, con, fine):
        for r in con.execute("SELECT id, a, b FROM procedure WHERE fine=? AND status='active'", (fine,)).fetchall():
            a = 1 + (r["a"] - 1) * (1 - DECAY)
            b = 1 + (r["b"] - 1) * (1 - DECAY)
            con.execute("UPDATE procedure SET a=?, b=? WHERE id=?", (a, b, r["id"]))

    def _cap(self, con, pid):
        r = con.execute("SELECT a, b FROM procedure WHERE id=?", (pid,)).fetchone()
        if r and r["a"] + r["b"] > CAP:
            k = CAP / (r["a"] + r["b"])
            con.execute("UPDATE procedure SET a=?, b=? WHERE id=?", (r["a"] * k, r["b"] * k, pid))

    def signal(self, fine, procedure_id, sig, admin, edited_steps=None, edited_text=None, upload_id=None, finding_id=None,
               proposal_steps=None, proposal_text=None, scenario_name=None, test_path=None, outcome=None):
        """Apply one of the four signals. procedure_id None = the signal is about a fresh model proposal
        (proposal_steps/proposal_text). Returns {'procedure_id': ..., 'new_procedure_id': ...}."""
        if sig not in SIGNALS:
            raise ValueError("signal must be one of %s" % ", ".join(SIGNALS))
        con = self._con()
        new_id = None
        if procedure_id is None and sig in ("correct", "correct_with_edits"):
            # the same steps already stored for this signature: judge that procedure instead of storing a copy
            steps_ = edited_steps if (sig == "correct_with_edits" and edited_steps is not None) else (proposal_steps or [])
            same = con.execute("SELECT id FROM procedure WHERE fine=? AND status='active' AND vhash=? ORDER BY id LIMIT 1", (fine, vhash(steps_))).fetchone()
            if same is not None:
                procedure_id = same["id"]
                sig = "correct"
        if procedure_id is None:
            # fresh proposal, not yet stored
            if sig in ("correct", "correct_with_edits"):
                steps = edited_steps if (sig == "correct_with_edits" and edited_steps is not None) else (proposal_steps or [])
                text = edited_text if (sig == "correct_with_edits" and edited_text) else (proposal_text or "")
                con.commit()
                con.close()
                new_id = self.add_procedure(fine, steps, text, "admin:%s" % admin if sig == "correct_with_edits" else "llm", test_path, scenario_name, outcome=outcome)
                con = self._con()
            elif sig == "wrong_with_edits" and edited_steps is not None:
                con.commit()
                con.close()
                new_id = self.add_procedure(fine, edited_steps, edited_text or "", "admin:%s" % admin, test_path, scenario_name, outcome=outcome)
                con = self._con()
                con.execute("INSERT INTO lesson (fine, text, producer, at) VALUES (?,?,?,?)", (fine, "model proposal judged wrong; admin replaced it", "admin:%s" % admin, time.time()))
            else:   # wrong
                con.execute("INSERT INTO lesson (fine, text, producer, at) VALUES (?,?,?,?)", (fine, "model proposal judged wrong: " + (proposal_text or "")[:500], "admin:%s" % admin, time.time()))
        else:
            self._decay_and_cap(con, fine)
            r = con.execute("SELECT * FROM procedure WHERE id=?", (procedure_id,)).fetchone()
            if r is None:
                con.close()
                raise ValueError("no such procedure")
            if sig == "correct":
                con.execute("UPDATE procedure SET a=a+1, c_ok=c_ok+1, validated_on=? WHERE id=?", (upload_id, procedure_id))
                if outcome:
                    con.execute("UPDATE procedure SET outcome=? WHERE id=?", (json.dumps(outcome), procedure_id))
            elif sig == "wrong":
                con.execute("UPDATE procedure SET b=b+1, c_wrong=c_wrong+1 WHERE id=?", (procedure_id,))
            elif sig == "correct_with_edits":
                con.execute("UPDATE procedure SET a=a+1, c_ok_edit=c_ok_edit+1, status='superseded' WHERE id=?", (procedure_id,))
                a2, b2 = 1 + INHERIT * (r["a"] + 1 - 1), 1 + INHERIT * (r["b"] - 1)
                con.commit()
                con.close()
                new_id = self.add_procedure(fine, edited_steps if edited_steps is not None else json.loads(r["steps"]), edited_text or r["text"],
                                            "admin:%s" % admin, test_path or r["test_path"], scenario_name or r["scenario_name"], a=a2, b=b2, supersedes=procedure_id,
                                            outcome=outcome or (json.loads(r["outcome"]) if r["outcome"] else None))
                con = self._con()
            else:   # wrong_with_edits
                con.execute("UPDATE procedure SET b=b+1, c_wrong_edit=c_wrong_edit+1, status='superseded' WHERE id=?", (procedure_id,))
                con.commit()
                con.close()
                new_id = self.add_procedure(fine, edited_steps if edited_steps is not None else json.loads(r["steps"]), edited_text or r["text"],
                                            "admin:%s" % admin, test_path, scenario_name or r["scenario_name"], a=2.0, b=1.0, supersedes=procedure_id,
                                            outcome=outcome or (json.loads(r["outcome"]) if r["outcome"] else None))
                con = self._con()
            self._cap(con, procedure_id)
            con.execute("UPDATE procedure_order SET valid=0 WHERE fine=?", (fine,))
        con.execute("INSERT INTO signal (fine, procedure_id, signal, admin, at, edits, new_procedure_id, upload_id, finding_id) VALUES (?,?,?,?,?,?,?,?,?)",
                    (fine, procedure_id, sig, admin, time.time(), json.dumps(edited_steps) if edited_steps is not None else None, new_id, upload_id, finding_id))
        self._event(con, "signal", {"fine": fine, "procedure_id": procedure_id, "signal": sig, "admin": admin, "new_procedure_id": new_id})
        con.commit()
        con.close()
        return {"procedure_id": procedure_id, "new_procedure_id": new_id}

    def reorder(self, fine, order, admin):
        con = self._con()
        con.execute("INSERT OR REPLACE INTO procedure_order (fine, order_json, valid, set_by, at) VALUES (?,?,1,?,?)",
                    (fine, json.dumps([int(x) for x in order]), admin, time.time()))
        self._event(con, "reorder", {"fine": fine, "order": order, "admin": admin})
        con.commit()
        con.close()

    def add_lesson(self, fine, text, producer):
        con = self._con()
        con.execute("INSERT INTO lesson (fine, text, producer, at) VALUES (?,?,?,?)", (fine, text, producer, time.time()))
        con.commit()
        con.close()

    # ------------------------------------------------------------------ chat log
    def chat_append(self, upload_id, finding_id, fine, role, text, data=None):
        con = self._con()
        con.execute("INSERT INTO chat (upload_id, finding_id, fine, role, text, data, at) VALUES (?,?,?,?,?,?,?)",
                    (upload_id, finding_id, fine, role, text, json.dumps(data) if data is not None else None, time.time()))
        con.commit()
        con.close()

    def chat_history(self, upload_id, finding_id):
        con = self._con()
        rows = [dict(r) for r in con.execute("SELECT role, text, data, at FROM chat WHERE upload_id=? AND finding_id=? ORDER BY id", (upload_id, finding_id))]
        con.close()
        for r in rows:
            r["data"] = json.loads(r["data"]) if r["data"] else None
        return rows

    def signals_of(self, fine):
        con = self._con()
        rows = [dict(r) for r in con.execute("SELECT * FROM signal WHERE fine=? ORDER BY at", (fine,))]
        con.close()
        return rows

    def stats(self):
        con = self._con()
        out = {"signatures": con.execute("SELECT COUNT(*) FROM signature").fetchone()[0],
               "procedures": con.execute("SELECT COUNT(*) FROM procedure WHERE status='active'").fetchone()[0],
               "signals": con.execute("SELECT COUNT(*) FROM signal").fetchone()[0]}
        con.close()
        return out
