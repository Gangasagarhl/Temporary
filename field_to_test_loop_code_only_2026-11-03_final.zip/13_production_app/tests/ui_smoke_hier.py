#!/usr/bin/env python3
"""Browser smoke test of the five-level hierarchy page (/hier) against a RUNNING application, through Chrome's
DevTools protocol: opens the page, selects the demo upload (samples/hier_synth, or --upload <id>), walks the four pages
(upload report, tree with expand + a scroll that loads the second page from disk + summary + a level filter, the defect
table of page 3 with its filter, statements and two timing limits, time limits), and fails on any JavaScript error or failed request.
Screenshots go to runs/ui_smoke_hier/.

The chat, the four signals and the test case moved out of page 3 (the isolation tab, built separately): their browser
checks were dropped here; tests/test_hier_e2e.py covers them through the API. A short API-level check below shows that
a decision recorded without a name is accepted (the drive's name or "admin" is the actor).

Needs google-chrome (or chromium) and the `websocket-client` module.   Usage: python3 tests/ui_smoke_hier.py [--base URL] [--upload <id>]
"""
import base64
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request

import websocket

BASE = "http://127.0.0.1:8077"
APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if "--base" in sys.argv:
    BASE = sys.argv[sys.argv.index("--base") + 1]
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(HERE, "runs", "ui_smoke_hier")
os.makedirs(OUT, exist_ok=True)
RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append((bool(ok), name, detail))
    print("%s  %s%s" % ("PASS" if ok else "FAIL", name, ("  | " + str(detail)[:200]) if detail else ""), flush=True)
    return bool(ok)


class Chrome:
    def __init__(self):
        exe = shutil.which("google-chrome") or shutil.which("chromium") or shutil.which("chromium-browser")
        if not exe:
            sys.exit("no chrome/chromium found")
        self.prof = "/tmp/hier_ui_smoke_profile"
        self.p = subprocess.Popen([exe, "--headless=new", "--remote-debugging-port=9333", "--remote-allow-origins=*", "--no-sandbox", "--disable-gpu", "--window-size=1500,1100",
                                   "--user-data-dir=" + self.prof, "about:blank"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(50):
            try:
                tabs = json.loads(urllib.request.urlopen("http://127.0.0.1:9333/json").read())
                break
            except Exception:
                time.sleep(0.2)
        self.ws = websocket.create_connection([t for t in tabs if t["type"] == "page"][0]["webSocketDebuggerUrl"], timeout=60)
        self.seq = 0
        self.errors = []
        self.send("Runtime.enable")
        self.send("Log.enable")
        self.send("Network.enable")

    def send(self, method, **params):
        self.seq += 1
        self.ws.send(json.dumps({"id": self.seq, "method": method, "params": params}))
        while True:
            m = json.loads(self.ws.recv())
            if m.get("method") == "Runtime.exceptionThrown":
                self.errors.append(m["params"]["exceptionDetails"].get("exception", {}).get("description", "")[:300])
            if m.get("method") == "Log.entryAdded" and m["params"]["entry"]["level"] == "error":
                e = m["params"]["entry"]
                self.errors.append("log: %s %s" % (e["text"][:120], e.get("url", "")))
            if m.get("method") == "Network.responseReceived" and m["params"]["response"]["status"] >= 400:
                self.errors.append("http %s %s" % (m["params"]["response"]["status"], m["params"]["response"]["url"]))
            if m.get("id") == self.seq:
                return m.get("result", {})

    def js(self, expr):
        r = self.send("Runtime.evaluate", expression=expr, awaitPromise=True, returnByValue=True)
        return r.get("result", {}).get("value")

    def goto(self, url):
        self.send("Page.navigate", url=url)
        time.sleep(1.5)

    def shot(self, name):
        d = self.send("Page.captureScreenshot", format="png")
        with open(os.path.join(OUT, name + ".png"), "wb") as f:
            f.write(base64.b64decode(d["data"]))

    def close(self):
        self.ws.close()
        self.p.terminate()
        shutil.rmtree(self.prof, ignore_errors=True)


def _cleanup_store(admin):
    """Remove what this test wrote into the shared knowledge store (procedures created by its signals, the signals)."""
    import sqlite3
    path = os.path.join(APP, "db", "hier_knowledge.sqlite")
    if not os.path.exists(path):
        return
    con = sqlite3.connect(path, timeout=30)
    ids = [r[0] for r in con.execute("SELECT new_procedure_id FROM signal WHERE admin=? AND new_procedure_id IS NOT NULL", (admin,))]
    if ids:
        con.execute("DELETE FROM procedure WHERE id IN (%s)" % ",".join("?" * len(ids)), ids)
    con.execute("DELETE FROM signal WHERE admin=?", (admin,))
    con.commit()
    con.close()


def put(path, body, timeout=300):
    req = urllib.request.Request(BASE + path, method="PUT", data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
    return json.loads(urllib.request.urlopen(req, timeout=timeout).read())


def _post(path, body, timeout=120):
    req = urllib.request.Request(BASE + path, method="POST", data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
    return json.loads(urllib.request.urlopen(req, timeout=timeout).read())


def load_sample():
    """Loads samples/hier_synth as a fresh upload (the five files) and waits for the job; returns the upload id."""
    folder = os.path.join(APP, "samples", "hier_synth")
    files = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv", "nvme_command": "nvme_command.csv"}
    r = _post("/api/hier/uploads", {"files": {k: os.path.join(folder, v) for k, v in files.items()}, "operator": "ui-smoke", "device": "Synthetic NVMe SSD 1TB",
                                    "trace_name": "ui-smoke sample", "notes": "loaded by tests/ui_smoke_hier.py; removed at the end"})
    uid, job = r["upload_id"], r["job"]
    for _ in range(300):
        j = json.loads(urllib.request.urlopen(BASE + "/api/jobs/" + job).read())
        if j.get("ended"):
            if j.get("status") != "done":
                sys.exit("the sample upload failed: %s" % (j.get("error") or "")[:200])
            return uid
        time.sleep(1)
    sys.exit("the sample upload did not finish in time")


def main():
    created = None
    if "--upload" in sys.argv:
        uid = sys.argv[sys.argv.index("--upload") + 1]
    else:
        ups = json.loads(urllib.request.urlopen(BASE + "/api/hier/uploads").read())
        done = [u for u in ups if u.get("status") not in ("loading", "failed", "interrupted")]
        # the demo set (samples/hier_synth) when one is loaded, newest first; never a big real recording by accident
        demo = [u for u in done if any("hier_synth" in (p or "") for p in (u.get("file_paths") or {}).values())]
        if demo:
            uid = demo[0]["upload_id"]
        else:
            uid = created = load_sample()      # none loaded: the test loads the sample itself and removes it at the end
    main._created = created
    # a known state: the 43 ms split limit, defaults elsewhere (re-runs the rules)
    put("/api/hier/uploads/%s/thresholds" % uid, {"split": {"value": 43, "unit": "ms", "source": "platform rule"}})
    c = Chrome()
    try:
        c.goto(BASE + "/hier")
        check("page loads", c.js("document.title") == "Five-level NVMe hierarchy")
        # the file picker: a folder browser on the server; one click fills the chosen path and the other four recognised files
        folder = os.path.join(APP, "samples", "hier_synth")
        c.js("document.querySelector('button[data-browse=\"packets\"]').click()")
        time.sleep(1)
        c.js("document.getElementById('br-path').value=%s; document.getElementById('br-go').click()" % json.dumps(folder))
        time.sleep(2)
        check("file picker lists the folder's CSV files", (c.js("document.querySelectorAll('#br-lists tr[data-file]').length") or 0) >= 5)
        c.js("[...document.querySelectorAll('#br-lists tr[data-file]')].find(t=>t.dataset.file.endsWith('/packets.csv')).click()")
        time.sleep(3)
        filled = c.js("['nvme_command','nvme_transaction','split','link','packets'].filter(k=>document.getElementById('path-'+k).value).length")
        check("one pick fills the five paths", filled == 5, filled)
        c.js("['nvme_command','nvme_transaction','split','link','packets'].forEach(k=>{document.getElementById('path-'+k).value='';document.getElementById('chk-'+k).textContent=''})")
        c.js("document.getElementById('upload-select').value=%s; document.getElementById('upload-select').dispatchEvent(new Event('change'))" % json.dumps(uid))
        time.sleep(2)
        check("upload report shows five levels", c.js("document.querySelectorAll('#report table.report tbody tr').length") == 5)
        check("header matches shown", "header matches" in (c.js("document.getElementById('report').innerText") or ""))
        c.shot("1_upload")
        c.js("document.querySelector('button.nav[data-page=tree]').click()")
        time.sleep(2)
        n = c.js("document.querySelectorAll('#tree tbody tr[data-rid]').length")
        check("tree shows command rows", n and n > 0, n)
        # the rows come from disk a page (200) at a time: the first page only, then the next page when the end scrolls into view
        total = json.loads(urllib.request.urlopen(BASE + "/api/hier/uploads/%s/rows?level=nvme_command&top=1&limit=1" % uid).read())["total"]
        check("first page holds at most 200 rows", n == min(200, total), n)
        check("loaded-of-total line shown", ("loaded %s of %s rows" % ("{:,}".format(n), "{:,}".format(total))) in (c.js("document.getElementById('tree-page').innerText") or ""), c.js("document.getElementById('tree-page').innerText"))
        c.js("document.querySelector('#tree tr.more').scrollIntoView()")
        time.sleep(2.5)
        n2 = c.js("document.querySelectorAll('#tree tbody tr[data-rid]').length")
        check("scrolling to the end loads the second page from disk", total <= 200 or (n2 > n and n2 == min(400, total)), "%s -> %s of %s" % (n, n2, total))
        check("loaded line updated", ("loaded %s of %s rows" % ("{:,}".format(n2), "{:,}".format(total))) in (c.js("document.getElementById('tree-page').innerText") or ""), c.js("document.getElementById('tree-page').innerText"))
        c.js("window.scrollTo(0, 0)")
        time.sleep(0.5)
        c.js("document.querySelector('#tree button.exp').click()")
        time.sleep(2.5)
        check("expand shows NVMe transactions", (c.js("document.querySelector('#tree .lvl.l-nvme_transaction') && document.querySelector('#tree .lvl.l-nvme_transaction').innerText.slice(0,80)") or "").find("NVMe transaction") >= 0)
        c.js("document.querySelector('#tree .lvl.l-nvme_transaction button.exp').click()")
        time.sleep(2.5)
        check("second expand shows splits or links", bool(c.js("!!document.querySelector('#tree .lvl.l-split, #tree .lvl.l-link')")))
        c.shot("2_tree_expanded")
        c.js("document.getElementById('btn-summary').click()")
        time.sleep(2)
        check("summary table filled", (c.js("document.querySelectorAll('#summary-table tbody tr[data-key]').length") or 0) > 0)
        check("summary totals computed by the database", "commands in this selection" in (c.js("document.getElementById('summary-totals').innerText") or ""))
        c.js("window.scrollTo(0, 0)")
        c.js("const cb=document.querySelector('#errfilters input[data-lvl=nvme_command]'); cb.checked=true; cb.dispatchEvent(new Event('change'))")
        time.sleep(2)
        nf = c.js("document.querySelectorAll('#tree tbody tr[data-rid]').length") or 0
        ne = c.js("document.querySelectorAll('#tree tbody tr[data-rid].has-err').length") or 0
        check("level filter narrows to commands with a command-level error", 0 < nf <= 200 and nf < total and ne == nf, "%d rows, %d with an error, of %d" % (nf, ne, total))
        c.shot("3_summary_filter")
        c.js("const cb=document.querySelector('#errfilters input[data-lvl=nvme_command]'); cb.checked=false; cb.dispatchEvent(new Event('change'))")
        c.js("document.querySelector('button.nav[data-page=defects]').click()")
        time.sleep(2.5)
        # page 3: the defect table, one row per command, error or not
        n_rows = c.js("document.querySelectorAll('#dt-table tbody tr[data-cmd]').length") or 0
        total = json.loads(urllib.request.urlopen(BASE + "/api/hier/uploads/%s/rows?level=nvme_command&top=1&limit=1" % uid).read())["total"]
        check("defect table shows every command (first page of 200)", n_rows == min(200, total), "%s of %s" % (n_rows, total))
        check("the count line says every command is listed", "every command" in (c.js("document.getElementById('dt-count').innerText") or ""), c.js("document.getElementById('dt-count').innerText"))
        check("the two limit fields show the specification defaults", c.js("document.getElementById('tl-link-value').value") == "50" and c.js("document.getElementById('tl-link-unit').value") == "us"
              and c.js("document.getElementById('tl-ntx-value').value") == "50" and c.js("document.getElementById('tl-ntx-unit').value") == "ms")
        check("the sources of the limits in force are shown", "PCIe Base 3.6.2.1" in (c.js("document.getElementById('tl-link-source').innerText") or "") and "PCIe Base 2.8" in (c.js("document.getElementById('tl-ntx-source').innerText") or ""),
              c.js("document.getElementById('tl-link-source').innerText"))
        row7 = c.js("(document.querySelector('#dt-table tbody tr[data-n=\"7\"]')||{}).innerText") or ""
        check("command 7 (no error): column 1 shows the status in words and the time taken; column 4 says what it did and 'No error.'",
              "status: success" in row7 and "took 48.676 us" in row7 and "Read of 16 blocks at block 2,097,152 on namespace 1, completed with success in 48.676 us. No error." in row7, row7[:200].replace("\n", " | "))
        check("column 3 shows per transaction the time to complete and under it the gap to the next row", (c.js("document.querySelectorAll('#dt-table tbody tr[data-n=\"7\"] td:nth-child(3) .tx').length") or 0) == 7 and "gap to the next row" in row7)
        # error only: command 207 with its statement, evidence and chip
        c.js("document.getElementById('dt-filter').value='error'; document.getElementById('dt-filter').dispatchEvent(new Event('change'))")
        time.sleep(2.5)
        n_err = c.js("document.querySelectorAll('#dt-table tbody tr[data-cmd]').length") or 0
        row207 = c.js("(document.querySelector('#dt-table tbody tr[data-n=\"207\"]')||{}).innerText") or ""
        check("'error only' leaves command 207", n_err == 1 and "command 207" in row207, "%s rows" % n_err)
        check("the statement of command 207 names the error with its evidence and basis", "completed with status Invalid Command Opcode (type 0, code 1)" in row207 and "The drive answered the command with an error status: status 0x0001: type 0, code 1, Invalid Command Opcode, do not retry; basis:" in row207, row207[:200].replace("\n", " | "))
        check("the error chip is red and links to the isolation tab in a new tab", bool(c.js("!!document.querySelector('#dt-table tbody tr[data-n=\"207\"] a.fnd[href^=\"/isolate?upload=\"][target=_blank] .chip-err')")))
        check("the row itself carries the first error finding for the click", bool(c.js("!!document.querySelector('#dt-table tbody tr[data-n=\"207\"]').dataset.fid")))
        c.js("document.getElementById('dt-filter').value='no_error'; document.getElementById('dt-filter').dispatchEvent(new Event('change'))")
        time.sleep(2.5)
        check("'no error only' lists the other commands", (c.js("document.querySelectorAll('#dt-table tbody tr[data-cmd]').length") or 0) == min(200, total - 1) and "without an error" in (c.js("document.getElementById('dt-count').innerText") or ""))
        c.js("document.getElementById('dt-filter').value='all'; document.getElementById('dt-filter').dispatchEvent(new Event('change'))")
        time.sleep(2)
        c.shot("4_defect_table")
        # tiny limits (the sample's link transactions wait at most 260 ns, its NVMe transactions take at most 540 ns): apply re-runs the two rules
        c.js("document.getElementById('tl-link-value').value='100'; document.getElementById('tl-link-unit').value='ns'; document.getElementById('tl-ntx-value').value='100'; document.getElementById('tl-ntx-unit').value='ns'; document.getElementById('tl-apply').click()")
        for _ in range(60):
            time.sleep(1)
            if "applied" in (c.js("document.getElementById('tl-status').innerText") or ""):
                break
        time.sleep(1.5)
        status = c.js("document.getElementById('tl-status').innerText") or ""
        check("the status line reports the counts of both levels", "applied" in status and "link transactions:" in status and "NVMe transactions:" in status, status)
        row7 = c.js("(document.querySelector('#dt-table tbody tr[data-n=\"7\"]')||{}).innerText") or ""
        check("the statement of command 7 now names the NVMe transaction and the link transaction over the tiny limits",
              "An NVMe transaction took longer than the NVMe-transaction limit: transaction 50 (Transferred Data) took " in row7 and "A link transaction under this command took longer than the link limit: link transaction " in row7 and "limit 100 ns (set by the admin)" in row7, row7[:240].replace("\n", " | "))
        check("the sources now read 'set by the admin'", "set by the admin" in (c.js("document.getElementById('tl-link-source').innerText") or "") and "set by the admin" in (c.js("document.getElementById('tl-ntx-source').innerText") or ""))
        c.shot("5_defect_table_100ns")
        # empty fields: timing not considered
        c.js("document.getElementById('tl-link-value').value=''; document.getElementById('tl-ntx-value').value=''; document.getElementById('tl-apply').click()")
        for _ in range(60):
            time.sleep(1)
            if "applied" in (c.js("document.getElementById('tl-status').innerText") or ""):
                break
        time.sleep(1.5)
        row7 = c.js("(document.querySelector('#dt-table tbody tr[data-n=\"7\"]')||{}).innerText") or ""
        check("empty fields: the statement says timing at both levels is not considered", "No error. Timing at the link level: not considered. Timing at the NVMe transaction level: not considered." in row7 and "not considered" in (c.js("document.getElementById('tl-link-source').innerText") or ""), row7[-160:].replace("\n", " | "))
        # the specification defaults button, then apply
        c.js("document.getElementById('tl-defaults').click()")
        check("'specification defaults' fills the two fields", c.js("document.getElementById('tl-link-value').value") == "50" and c.js("document.getElementById('tl-ntx-value').value") == "50" and c.js("document.getElementById('tl-ntx-unit').value") == "ms")
        c.js("document.getElementById('tl-apply').click()")
        for _ in range(60):
            time.sleep(1)
            if "applied" in (c.js("document.getElementById('tl-status').innerText") or ""):
                break
        time.sleep(1.5)
        row7 = c.js("(document.querySelector('#dt-table tbody tr[data-n=\"7\"]')||{}).innerText") or ""
        check("with the defaults back, command 7 reads 'No error.' again", row7.rstrip().endswith("No error.") and "PCIe Base 3.6.2.1" in (c.js("document.getElementById('tl-link-source').innerText") or ""), row7[-80:])
        # API-level: a decision recorded without a name is accepted (the drive's name, else "admin", is the actor): a reorder with the current order changes nothing
        fid = c.js("(document.querySelector('#dt-table tbody tr[data-n=\"207\"]')||{dataset:{}}).dataset.fid") or json.loads(urllib.request.urlopen(BASE + "/api/hier/uploads/%s/defect_table?filter=error&limit=1" % uid).read())["rows"][0]["first_finding"]
        d = json.loads(urllib.request.urlopen(BASE + "/api/hier/uploads/%s/findings/%s" % (uid, fid)).read())
        order = [p["id"] for p in (d.get("knowledge") or {}).get("exact") or []]
        req = urllib.request.Request(BASE + "/api/hier/uploads/%s/findings/%s/reorder" % (uid, fid), method="POST", data=json.dumps({"order": order}).encode(), headers={"Content-Type": "application/json"})
        r = json.loads(urllib.request.urlopen(req, timeout=60).read())
        check("a reorder without a name is accepted by the API (no name is required any more)", "knowledge" in r, list(r)[:3])
        c.js("document.querySelector('button.nav[data-page=settings]').click()")
        time.sleep(1.5)
        check("limits table shows five levels", c.js("document.querySelectorAll('#thr-table tbody tr').length") == 5)
        check("the link and NVMe transaction rows of the limits page point to page 3 (read-only)", "page 3" in (c.js("(document.getElementById('thr-link-note')||{}).innerText") or "") and "page 3" in (c.js("(document.getElementById('thr-ntx-note')||{}).innerText") or ""))
        c.shot("6_limits")
        bad = [e for e in c.errors if "favicon" not in e and not (e.startswith("log:") and "404" in e)]   # a favicon miss is not an error of the page
        check("no JavaScript errors or failed requests", not bad, "; ".join(bad)[:400])
    finally:
        c.close()
        _cleanup_store("ui-smoke")
        if getattr(main, "_created", None):
            try:
                urllib.request.urlopen(urllib.request.Request(BASE + "/api/hier/uploads/" + main._created, method="DELETE"), timeout=60).read()
            except Exception as e:      # noqa: BLE001
                print("could not remove the sample upload %s: %s" % (main._created, e))
    fails = [r for r in RESULTS if not r[0]]
    print("\n%d checks, %d failed" % (len(RESULTS), len(fails)))
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
