#!/usr/bin/env python3
"""End-to-end test of the isolation tab (statement of 2026-11-03, parts 4-8) through the HTTP API against a RUNNING
server, with the synthetic sample samples/hier_synth (the defect: command 207, a vendor opcode 0x7F refused with
"Invalid Command Opcode"). The sample is uploaded by this test and deleted at the end.

What it walks: the header (defect in words, chain, catalogue, device, memory); the window at every combination of the
four lower levels (16 combinations) and its bounds; the stateful chat (two messages, the second answer's history has
4 entries, the context lines and the earlier turns are in the rendered prompt); the memory before and after storing a
reason, a scenario name and a summary; the evidence loop with the stand-in (a hint forces one "need more evidence"
round) and with the real model (ONE call); the optimised-sequence invariants (rows after the defect unchanged, only
commands of the fetched window); the test case in two steps (expected outcomes, then the file, which must compile); the
four-line summary; the "already stored" rule; the reorder. With --browser the page itself is driven in headless Chrome
(port 9333 must be free): controls present, Extract twice with different numbers, the context count line, a chat
answer shown, no JavaScript errors.

Model calls: 4 in a full run (loop, chat, expected outcomes, summary); --no-model makes every call use the stand-in.
Standard library only.   Usage: python3 tests/test_isolate.py [--base URL] [--no-model] [--browser] [--cleanup-store]

The knowledge store is shared across uploads on purpose. The reason, scenario name and summary of the sample's signature
are put back to what they were before the run; with --cleanup-store the procedures, signals, lessons, sightings and chat
lines this run created are removed from the SQLite file as well.
"""
import itertools
import json
import os
import py_compile
import sqlite3
import sys
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

BASE = "http://127.0.0.1:8077"
if "--base" in sys.argv:
    BASE = sys.argv[sys.argv.index("--base") + 1]
NO_MODEL = "--no-model" in sys.argv
BROWSER = "--browser" in sys.argv
CLEANUP_STORE = "--cleanup-store" in sys.argv

SAMPLE = os.path.join(ROOT, "samples", "hier_synth")
FILES = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv", "nvme_command": "nvme_command.csv"}
LOWER = ["nvme_transaction", "split", "link", "packets"]
LABEL = {"packets": "packet", "link": "link transaction", "split": "split transaction", "nvme_transaction": "NVMe transaction", "nvme_command": "NVMe command"}
ADMIN = "iso-test"
DEVICE = "Synthetic NVMe SSD 1TB"
KNOWLEDGE_DB = os.path.join(ROOT, "db", "hier_knowledge.sqlite")

RESULTS = []
MODEL_CALLS = {"n": 0}
CREATED = {"uploads": [], "files": [], "procedures": [], "signature": None, "before": None}
T0 = time.time()


def check(name, ok, detail=""):
    RESULTS.append((bool(ok), name, detail))
    print("%s  %s%s" % ("PASS" if ok else "FAIL", name, ("  | " + str(detail)[:300]) if detail else ""), flush=True)
    return bool(ok)


class ApiError(Exception):
    pass


def api(method, path, body=None, params=None, timeout=120, ok=(200,)):
    url = BASE + path + (("?" + urllib.parse.urlencode(params)) if params else "")
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers={"Content-Type": "application/json"} if data is not None else {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            status, text = r.status, r.read().decode()
    except urllib.error.HTTPError as e:
        status, text = e.code, e.read().decode(errors="replace")
    except (urllib.error.URLError, OSError) as e:
        raise ApiError("%s %s: no answer from the server (%s)" % (method, url, e))
    try:
        out = json.loads(text) if text else None
    except ValueError:
        out = {"_raw": text[:300]}
    if status not in ok:
        raise ApiError("%s %s -> HTTP %s: %s" % (method, url, status, json.dumps(out)[:400]))
    return out


call = api


def wait_job(jid, timeout=240):
    t0 = time.time()
    while time.time() - t0 < timeout:
        j = call("GET", "/api/jobs/%s" % jid)
        if j["status"] in ("done", "failed", "cancelled"):
            return j
        time.sleep(1.0)
    raise ApiError("job %s did not finish within %d s" % (jid, timeout))


def model_q(extra=None):
    """Query parameters: the stand-in is forced with --no-model."""
    p = dict(extra or {})
    if NO_MODEL:
        p["standin"] = "1"
    return p


# ---------------------------------------------------------------------------------------------- the steps
def step1_upload():
    print("\n-- 1. upload the sample")
    body = {"files": {k: os.path.join(SAMPLE, v) for k, v in FILES.items()}, "operator": ADMIN, "device": DEVICE, "trace_name": "isolation test"}
    r = call("POST", "/api/hier/uploads", body)
    uid = r["upload_id"]
    CREATED["uploads"].append(uid)
    job = wait_job(r["job"])
    check("load job finishes", job["status"] == "done", job.get("error"))
    fl = call("GET", "/api/hier/uploads/%s/findings" % uid, params={"rule": "cmd.status_error"})
    f = next((x for x in fl["findings"] if x.get("c_n") == 207), None)
    check("the sample has the cmd.status_error finding on command 207", f is not None)
    return uid, f["id"] if f else None


def step2_header(uid, fid, P):
    print("\n-- 2. the header of the tab")
    h = call("GET", P)
    f = h["finding"]
    check("header names the device from the upload's metadata", h.get("device") == DEVICE, h.get("device"))
    check("header has the level, the rule in words and the catalogue text", f.get("level_label") == "NVMe command" and "status error" in (f.get("rule_words") or "") and (f.get("catalogue") or {}).get("meaning"),
          "%s | %s" % (f.get("rule_words"), ((f.get("catalogue") or {}).get("meaning") or "")[:60]))
    check("header has the chain up to the command and the command's duration with its unit", f.get("chain") and f["chain"][-1]["level"] == "nvme_command" and (f.get("command") or {}).get("duration", "").endswith(("us", "ns", "ms", "s")),
          "%s / %s" % ([c["level"] for c in f.get("chain") or []], (f.get("command") or {}).get("duration")))
    check("header has the observed outcome and the default expected outcome", f.get("observed_outcome") and (f.get("expected_outcome_default") or {}).get("status"))
    m = h.get("memory") or {}
    check("memory block says seen before / on this device / on other devices in words", all(k in m for k in ("seen_before", "seen_before_text", "on_this_device", "on_other_devices", "on_other_devices_text", "retrieval")),
          "%s | %s" % (m.get("seen_before_text"), m.get("on_other_devices_text")))
    check("signature has the exact (fine) and the family key", (f.get("signature") or {}).get("fine") and (f.get("signature") or {}).get("family"))
    check("bounds are stated: 5 rounds, 100 commands above, 20 per step, 50 rows per level, 20 chat entries", h.get("bounds") == {"max_rounds": 5, "max_above": 100, "step_above": 20, "per_level": 50, "history_turns": 20}, h.get("bounds"))
    check("the command-level limit carries its source", (h.get("limits") or {}).get("command_limit_text") and (h.get("limits") or {}).get("command_limit_source"), h.get("limits"))
    check("the chat history is empty on a fresh upload", h.get("history") == [], len(h.get("history") or []))
    check("the model is reported", isinstance((h.get("model") or {}).get("available"), bool), h.get("model"))
    CREATED["signature"] = f["signature"]["fine"]
    st = h.get("stored") or {}
    CREATED["before"] = {"reason": st.get("reason"), "summary4": st.get("summary4"), "scenario_name": st.get("scenario_name")}
    return h


def step3_window(uid, fid, P):
    print("\n-- 3. the window at every level combination")
    combos = [list(c) for k in range(0, 5) for c in itertools.combinations(LOWER, k)]
    check("16 level combinations are tried", len(combos) == 16, len(combos))
    bad = []
    for lv in combos:
        w = call("GET", P + "/window", params={"n": 2, "m": 1, "levels": ",".join(lv)})
        pos = [c["position"] for c in w["commands"]]
        if pos != ["above", "above", "fault", "below"] or w.get("levels") != lv:
            bad.append((lv, pos, w.get("levels")))
            continue
        for c in w["commands"]:
            under = c.get("under") or {}
            if set(under) != set(lv) or any(b["shown"] > 50 or b["shown"] > b["count"] or b["shown"] != len(b["rows"]) for b in under.values()):
                bad.append((lv, c["n"], {k: (b["count"], b["shown"]) for k, b in under.items()}))
            for b in under.values():
                for r in b["rows"]:
                    if not all(k in r for k in ("level", "rowid", "n", "summary", "gap", "dur", "findings", "command_n")):
                        bad.append((lv, "row keys", sorted(r)))
    check("every combination returns 2 above, the fault, 1 below with the ticked levels under each command (first 50 per level, with counts)", not bad, bad[:3])
    w = call("GET", P + "/window", params={"n": 2, "m": 1, "levels": "nvme_transaction,split,link,packets"})
    fault = next(c for c in w["commands"] if c["position"] == "fault")
    check("the fault command carries its finding, its gap and its duration with units", fault["n"] == 207 and fault["findings"] and fault["gap"] and fault["dur"].endswith(("us", "ns", "ms")), "%s %s %s" % (fault["n"], fault["gap"], fault["dur"]))
    above = next(c for c in w["commands"] if c["position"] == "above")
    check("a command with more than 50 link transactions is bounded and says how many exist", any(b["count"] > b["shown"] for c in w["commands"] for b in (c["under"] or {}).values()), [(c["n"], c["under"]["link"]["count"], c["under"]["link"]["shown"]) for c in w["commands"]])
    pk = fault["under"]["packets"]["rows"][0]
    check("a packet row says which link it belongs to (for 'the packets of link N') and which command", pk.get("parent_n") is not None and pk.get("command_n") == 207, "%s / %s" % (pk.get("parent_n"), pk.get("command_n")))
    w0 = call("GET", P + "/window", params={"n": 0, "m": 0})
    check("n=0 m=0 gives the command alone", [c["position"] for c in w0["commands"]] == ["fault"] and w0["levels"] == [])
    w100 = call("GET", P + "/window", params={"n": 500, "m": 0})
    check("n is capped at 100 commands above", w100["n"] == 100 and sum(1 for c in w100["commands"] if c["position"] == "above") == 100, w100["n"])
    ws = call("GET", P + "/window", params={"n": 3, "m": 0, "queue": "same"})
    check("queue=same keeps the commands of the fault's queue only", ws["same_queue"] is True and all(c["queue"] == fault["queue"] for c in ws["commands"]), [c["queue"] for c in ws["commands"]])
    try:
        call("GET", P + "/window", params={"n": "x"})
        check("a bad n is refused with a plain message", False)
    except ApiError as e:
        check("a bad n is refused with a plain message", "whole numbers" in str(e), str(e)[:120])
    return w


def step4_chat(uid, fid, P, w):
    print("\n-- 4. the stateful chat (stand-in)")
    fault = next(c for c in w["commands"] if c["position"] == "fault")
    above = [c for c in w["commands"] if c["position"] == "above"]
    link = fault["under"]["link"]["rows"][0]
    pks = [r for r in fault["under"]["packets"]["rows"] if r.get("parent_rowid") == link["rowid"]][:2]
    rows = [{"level": "nvme_command", "rowid": fault["rowid"]}] + [{"level": "nvme_command", "rowid": c["rowid"]} for c in above] + [{"level": "link", "rowid": link["rowid"]}] + [{"level": "packets", "rowid": p["rowid"]} for p in pks]
    r1 = call("POST", P + "/chat", {"message": "What do the selected rows show?", "context": {"rows": rows, "include_defect": True, "include_catalogue": True, "include_memory": True}}, params={"standin": "1", "debug": "1"})
    want = "context: 3 NVMe commands, 1 link transaction, the packets of link %s" % link["n"]
    check("the context line counts the selection in words", r1.get("context_text") == want, "%s (want %s)" % (r1.get("context_text"), want))
    pr = (r1.get("debug") or {}).get("prompt") or ""
    check("the rendered prompt holds the selected rows as plain lines (level, row, gap, duration, findings)", "SELECTED CONTEXT" in pr and ("NVMe command row %s" % fault["n"]) in pr and "packet row" in pr and "under command 207" in pr and "Invalid Command Opcode" in pr, pr[pr.find("SELECTED CONTEXT"):][:200])
    check("the prompt says the model never decides whether a defect exists", "you never judge that" in pr)
    check("the prompt holds the defect, the catalogue and the memory blocks", "DEFECT (found by a deterministic rule" in pr and "CATALOGUE:" in pr and "MEMORY" in pr)
    check("prompt_chars is reported and matches the prompt", r1.get("prompt_chars") == len(pr) and r1["prompt_chars"] > 500, r1.get("prompt_chars"))
    check("the stand-in answered and says so", r1.get("standin") is True and r1.get("producer") == "stand-in" and (r1.get("answer") or {}).get("answer", "").startswith("Stand-in answer"))
    check("the actor recorded is the device name when no name is typed", r1.get("actor") == DEVICE and r1["history"][0]["role"] == "admin:" + DEVICE, r1.get("actor"))
    check("after one exchange the history has 2 entries", len(r1.get("history") or []) == 2, len(r1.get("history") or []))
    r2 = call("POST", P + "/chat", {"message": "Name the scenario and propose the sequence.", "name": ADMIN, "context": {"rows": []}}, params={"standin": "1", "debug": "1"})
    pr2 = (r2.get("debug") or {}).get("prompt") or ""
    check("the second answer's history has 4 entries in order (admin, answer, admin, answer)", len(r2.get("history") or []) == 4 and [h["role"].startswith("admin:") for h in r2["history"]] == [True, False, True, False], [h["role"] for h in r2.get("history") or []])
    check("the second prompt carries the earlier turns (last 20 entries)", "CONVERSATION SO FAR (last 2 entries)" in pr2 and "What do the selected rows show?" in pr2, pr2[pr2.find("CONVERSATION"):][:160])
    check("a typed name is recorded as the actor", r2.get("actor") == ADMIN and r2["history"][2]["role"] == "admin:" + ADMIN)
    a = r2.get("answer") or {}
    check("the stand-in names the scenario, gives the reason in words and a sequence when asked", a.get("scenario_name") and a.get("reason") and isinstance(a.get("proposed_sequence"), list), "%s | %s" % (a.get("scenario_name"), (a.get("reason") or "")[:80]))
    h = call("GET", P)
    check("the header returns the same history (stored per upload and defect)", len(h.get("history") or []) == 4)
    try:
        call("POST", P + "/chat", {"message": "", "context": {"rows": []}})
        check("an empty message is refused", False)
    except ApiError as e:
        check("an empty message is refused", "type a message" in str(e))
    r3 = call("POST", P + "/chat", {"message": "x", "context": {"rows": [{"level": "packets", "rowid": 999999999}]}}, params={"standin": "1"})
    check("a row that does not exist is reported, not invented", any("no packet" in p for p in (r3.get("answer") or {}).get("checks", {}).get("problems", [])), (r3.get("answer") or {}).get("checks"))


def step5_loop_standin(uid, fid, P, w):
    print("\n-- 5. the evidence loop with the stand-in")
    below_window = [(c["n"], c["summary"]) for c in w["commands"] if c["position"] == "below"]
    r = call("POST", P + "/isolate", {"n": 2, "m": 1, "levels": [], "hint": "look at the packets of the link transactions", "anyway": True}, params={"standin": "1"})
    rounds = r.get("rounds") or []
    check("the hint forces one 'need more evidence' round, then the verdict", len(rounds) == 2 and rounds[0]["verdict"] == "need_more_evidence" and rounds[1]["verdict"] == "reason", [(x["round"], x["verdict"]) for x in rounds])
    check("round 1 is logged in words: 'the model asked for the packets and link transactions of command 207'", "round 1: the model asked for the packets and link transactions of command 207" in rounds[0]["text"], rounds[0]["text"])
    check("the packets and links were fetched for the second round", set(r.get("levels_fetched") or []) == {"packets", "link"} and rounds[1]["evidence_rows"] > rounds[0]["evidence_rows"], "%s %s -> %s" % (r.get("levels_fetched"), rounds[0]["evidence_rows"], rounds[1]["evidence_rows"]))
    check("the loop is answered by the stand-in and says so", r.get("standin") is True and r.get("producer") == "stand-in")
    check("the reason is in words with the device name", "status error" in r.get("reason", "") and DEVICE in r.get("reason", ""), r.get("reason")[:160])
    check("every cited row exists in the fetched evidence (checked by the code)", r["checks"]["ok"] is True and r["cited_rows"] and all(c.get("n") is not None for c in r["cited_rows"]), [(c["label"], c["n"]) for c in r["cited_rows"]])
    seq = r.get("sequence") or []
    fault_i = next(i for i, s in enumerate(seq) if s["position"] == "fault")
    below = [(s["command"], s["position"]) for s in seq[fault_i + 1:]]
    check("the rows after the defect are copied unchanged (same count and commands as the window)", len(below) == len(below_window) and all(p == "below" and c == bw[1].split(",")[0] for (c, p), bw in zip(below, below_window)), "%s / %s" % (below, below_window))
    check("the fault's own command (a vendor opcode) is the fault step", seq[fault_i]["command"] == "opcode 0x7F" and seq[fault_i]["why"] == ["the fault"])
    check("the stand-in's verdict keeps the optimiser's kept rows above (none for this defect)", r["kept_above"] == r["optimiser"]["kept_above"] == 0 and r["dropped_above"] == 2, "%s/%s" % (r["kept_above"], r["dropped_above"]))
    check("every round is in the chat history", sum(1 for h in r["history"] if h["role"] == "loop") >= 2 and any("round 1" in h["text"] for h in r["history"]))
    check("the result says whether it is a seed and lists what is stored", "seed" in r and "stored" in r)
    r0 = call("POST", P + "/isolate", {"n": 3, "m": 2, "levels": ["nvme_transaction"], "anyway": True}, params={"standin": "1"})
    check("without a hint the stand-in gives its verdict in one round", len(r0["rounds"]) == 1 and r0["verdict"] == "reason", len(r0["rounds"]))
    r_above = call("POST", P + "/isolate", {"n": 2, "m": 0, "levels": [], "hint": "look further above, at the earlier commands", "anyway": True}, params={"standin": "1"})
    check("a hint about earlier commands fetches the next 20 above (2 -> 22)", r_above["above_fetched"] == 22 and "20 more commands above" in r_above["rounds"][0]["text"], "%s | %s" % (r_above.get("above_fetched"), r_above["rounds"][0]["text"]))
    return r


def step6_loop_model(uid, fid, P, w):
    print("\n-- 6. the evidence loop with the real model (one call)")
    if NO_MODEL:
        check("skipped (--no-model)", True)
        return None
    MODEL_CALLS["n"] += 1
    r = call("POST", P + "/isolate", {"n": 4, "m": 2, "levels": ["nvme_transaction"], "anyway": True}, timeout=300)
    below_window = [c["summary"].split(",")[0] for c in call("GET", P + "/window", params={"n": 4, "m": 2})["commands"] if c["position"] == "below"]
    check("the model answered (producer anthropic:...)", (r.get("producer") or "").startswith("anthropic:") and r.get("standin") is False, r.get("producer"))
    check("at most 5 rounds, each logged", 1 <= len(r.get("rounds") or []) <= 5 and all(x.get("text") for x in r["rounds"]), [(x["round"], x["verdict"]) for x in r["rounds"]])
    check("the final verdict is a reason in words", r.get("verdict") == "reason" and len(r.get("reason") or "") > 40, (r.get("reason") or "")[:200])
    seq = r.get("sequence") or []
    fault_i = next(i for i, s in enumerate(seq) if s["position"] == "fault")
    check("sequence invariants hold on the model's answer: rows after the defect unchanged, fault present", [s["command"] for s in seq[fault_i + 1:]] == below_window and seq[fault_i]["command"] == "opcode 0x7F", [s["command"] for s in seq])
    check("every kept step above comes from the fetched window (source rows exist)", all(s.get("source_row") for s in seq[:fault_i]) and r["kept_above"] + r["dropped_above"] == r["above_fetched"], "%s kept, %s dropped, %s fetched" % (r["kept_above"], r["dropped_above"], r["above_fetched"]))
    check("the code checks ran and are reported (cited rows must exist, names case-insensitive)", isinstance(r["checks"].get("ok"), bool) and "names matched case-insensitively" in r["checks"]["rules"], r["checks"]["problems"][:3])
    return r


def step7_memory_and_store(uid, fid, P, loop):
    print("\n-- 7. memory before and after storing (reason, device, scenario, summary)")
    m0 = call("GET", P + "/memory")
    reason = "iso-test reason: status error: the command completed with an error status (Invalid Command Opcode), device %s [%d]" % (DEVICE, int(time.time()))
    scenario = "iso-test scenario %d" % int(time.time())
    steps = loop["sequence"]
    r = call("POST", P + "/signal", {"signal": "correct", "procedure_id": None, "proposal_steps": steps, "proposal_text": loop["reason"], "scenario_name": scenario, "reason": reason, "name": ADMIN,
                                     "outcome": {"observed": "x", "expected": {"status": "Successful Completion", "description": "d", "check": "status == (0, 0)"}, "verified_by": ADMIN}})
    pid = (r.get("result") or {}).get("new_procedure_id") or (r.get("result") or {}).get("procedure_id")
    if (r.get("result") or {}).get("new_procedure_id"):
        CREATED["procedures"].append(pid)
    check("signal 'correct' on the seed stores or judges a procedure without an admin name", isinstance(pid, int), r.get("result"))
    m1 = r.get("memory") or {}
    ex = m1.get("exact") or {}
    check("memory now holds the reason in words, by the actor", ex.get("reason") == reason and (m1.get("stored") or {}).get("reason") == reason, (ex.get("reason") or "")[:80])
    check("memory holds the device name and the scenario name", ex.get("device") == DEVICE and ex.get("scenario_name") == scenario, "%s / %s" % (ex.get("device"), ex.get("scenario_name")))
    check("memory ranks the exact signature first with its best sequence and the four-signal counts", ex.get("tier") == 1 and ex.get("rank") == 1 and (ex.get("best") or {}).get("counts") and set(ex["best"]["counts"]) == {"correct", "correct_with_edits", "wrong", "wrong_with_edits"}, ex.get("best") and ex["best"]["counts"])
    check("the retrieval text names the reason, the scenario, the sequence and the score with its counts", all(x in (ex.get("text") or "") for x in ("reason:", "scenario:", "best stored sequence", "correct /")), (ex.get("text") or "")[:200])
    check("seen before is now yes (facts stored)", m1.get("seen_before") is True and "yes" in m1.get("seen_before_text", ""), m1.get("seen_before_text"))
    # the summary
    s = call("POST", P + "/summary", {"reason": reason, "sequence": steps, "name": ADMIN}, params=model_q())
    if not NO_MODEL:
        MODEL_CALLS["n"] += 1
    check("the summary has exactly four non-empty lines", len(s.get("lines") or []) == 4 and all(l.strip() for l in s["lines"]) and s["text"].count("\n") == 3, s.get("lines"))
    check("the summary says who produced it", (s.get("producer") or "") and ((s["producer"].startswith("anthropic:") and not s.get("standin")) or s.get("standin") is True), s.get("producer"))
    m2 = call("GET", P + "/memory")
    check("the memory shows the stored four-line summary", (m2.get("exact") or {}).get("summary4") == s["text"] and "summary:" in (m2["exact"].get("text") or ""), ((m2.get("exact") or {}).get("summary4") or "")[:80])
    # the "already stored" rule
    try:
        call("POST", P + "/isolate", {"n": 2, "m": 1, "levels": []}, params={"standin": "1"})
        check("with a stored sequence the model is not asked again unless 'a new proposal anyway'", False)
    except ApiError as e:
        check("with a stored sequence the model is not asked again unless 'a new proposal anyway'", "409" in str(e) and "already stored" in str(e), str(e)[:160])
    # the stored list, use + move up (reorder)
    st = call("GET", P).get("stored") or {}
    ids = [p["id"] for p in st.get("exact") or []]
    check("stored sequences are listed ranked", len(ids) >= 1 and all(p.get("score_text") for p in st["exact"]), [(p["id"], p["score_text"]) for p in st["exact"]])
    if len(ids) >= 2:
        rr = call("POST", P + "/reorder", {"order": list(reversed(ids)), "name": ADMIN})
        check("'move up' (reorder) is used as the admin's order", [p["id"] for p in rr["stored"]["exact"]] == list(reversed(ids)) and rr["stored"]["exact"][0]["ordered_by"] == "the admin's order")
    else:
        rr = call("POST", P + "/reorder", {"order": ids, "name": ADMIN})
        check("'move up' (reorder) is accepted with one stored sequence", rr["stored"]["exact"][0]["ordered_by"] == "the admin's order")
    rw = call("POST", P + "/signal", {"signal": "wrong", "procedure_id": pid, "name": ADMIN})
    check("signal 'wrong' on the chosen stored procedure is recorded", (rw.get("result") or {}).get("procedure_id") == pid and (rw.get("result") or {}).get("new_procedure_id") is None, rw.get("result"))
    return pid


def step8_chat_model(uid, fid, P, w):
    print("\n-- 8. the chat with the real model (one call)")
    if NO_MODEL:
        check("skipped (--no-model)", True)
        return
    fault = next(c for c in w["commands"] if c["position"] == "fault")
    n0 = len(call("GET", P)["history"])
    MODEL_CALLS["n"] += 1
    r = call("POST", P + "/chat", {"message": "In two sentences: what does the selected command show, and what should a correct drive have answered?", "name": ADMIN,
                                   "context": {"rows": [{"level": "nvme_command", "rowid": fault["rowid"]}] + [{"level": x["level"], "rowid": x["rowid"]} for x in fault["under"]["nvme_transaction"]["rows"]]}}, timeout=300)
    check("the model answered (producer anthropic:...)", (r.get("producer") or "").startswith("anthropic:") and r.get("standin") is False, r.get("producer"))
    check("the answer is free text", len((r.get("answer") or {}).get("answer") or "") > 40, ((r.get("answer") or {}).get("answer") or "")[:200])
    check("the history grew by two entries (question and answer) and is returned", len(r.get("history") or []) == n0 + 2, "%s -> %s" % (n0, len(r.get("history") or [])))
    check("the code checked the cited rows", isinstance((r.get("answer") or {}).get("checks", {}).get("ok"), bool), (r.get("answer") or {}).get("checks"))


def step9_testcase(uid, fid, P, loop, pid):
    print("\n-- 9. the test case with expected outcomes")
    steps = loop["sequence"]
    fault_step = next(s["step"] for s in steps if s["position"] == "fault")
    q = model_q()
    r = call("POST", P + "/testcase", {"sequence": steps, "expected_after": 2, "name": ADMIN}, params=q, timeout=300)
    if not NO_MODEL:
        MODEL_CALLS["n"] += 1
    outs = r.get("expected_outcomes") or []
    check("the expected outcomes cover the 2 commands from the defect onward", [o["step"] for o in outs] == [fault_step, fault_step + 1] and r.get("fault_step") == fault_step, [o["step"] for o in outs])
    check("each outcome has a status, a time within which to complete (with unit) and a check", all(o.get("status") and o.get("timing_us") and o.get("timing_text") and o.get("check") for o in outs), outs and {k: outs[0][k] for k in ("status", "timing_text", "check")})
    check("the limit used is stated with its source", (r.get("limit") or {}).get("text") and (r.get("limit") or {}).get("source"), r.get("limit"))
    check("the outcomes come back unverified (the admin ticks them)", all(o.get("verified") is False for o in outs))
    check("who answered is stated", bool(r.get("producer")), r.get("producer"))
    # the rows above the defect chosen by the admin from the recording (2026-11-03), with their outcomes proposed too
    ra = call("POST", P + "/testcase", {"sequence": steps, "expected_after": 1, "above_n": 2, "expected_before": 2, "same_queue": False, "name": ADMIN}, params={"standin": "1"}, timeout=300)
    seq2 = ra.get("sequence") or []
    fs2 = ra.get("fault_step")
    above2 = [s for s in seq2 if s.get("position") == "above"]
    check("above_n=2 makes the input the last 2 commands before the defect, as recorded", len(above2) == 2 and fs2 == 3 and all("chosen by the admin" in " ".join(s.get("why") or []) for s in above2), [(s.get("step"), s.get("why")) for s in above2])
    check("the rows below the defect are kept unchanged", [s["command"] for s in seq2 if s.get("position") == "below"] == [s["command"] for s in steps if s.get("position") == "below"])
    check("the outcomes then cover the 2 input rows and the defect (expected_after=1 is the defect alone)", [o["step"] for o in ra.get("expected_outcomes") or []] == [1, 2, 3], [o["step"] for o in ra.get("expected_outcomes") or []])
    check("the input rows' outcomes are set-up successes", all(o.get("success") for o in (ra.get("expected_outcomes") or []) if o["step"] < fs2))
    try:
        call("POST", P + "/testcase", {"sequence": steps, "expected_outcomes": outs, "verified": False})
        check("the file is not written without 'verified'", False)
    except ApiError as e:
        check("the file is not written without 'verified'", "verified" in str(e), str(e)[:120])
    for o in outs:
        o["verified"] = True
    wr = call("POST", P + "/testcase", {"sequence": steps, "expected_outcomes": outs, "verified": True, "name": ADMIN, "procedure_id": pid, "scenario_name": "iso-test scenario"})
    path = wr.get("path") or ""
    CREATED["files"].append(path)
    text = wr.get("text") or ""
    check("the test file is written under suite/hier/", path.startswith(os.path.join(ROOT, "suite", "hier") + os.sep) and os.path.isfile(path), path)
    check("the file holds the sequence above the defect as input and the expected outcomes list", "EXPECTED_AFTER = [" in text and "FAULT_STEP = %d" % fault_step in text and ("EXPECTED OUTCOMES FROM THE FAULT ONWARD (verified by %s)" % ADMIN) in text)
    check("the step after the fault asserts its expected status and timing", ('"step": %d' % (fault_step + 1)) in text and "expected completion within" in text and "timing_us" in text)
    check("the fault step keeps the EXPECT=fault/fixed form", "EXPECT == \"fixed\"" in text and "fault_seen(fault)" in text)
    ok = True
    try:
        py_compile.compile(path, doraise=True)
    except Exception as e:      # noqa: BLE001
        ok = False
        print("      py_compile:", e)
    check("the test file compiles (py_compile)", ok)
    st = call("GET", P).get("stored") or {}
    check("the chosen procedure records the test path", any(p.get("id") == pid and p.get("test_path") == path for p in st.get("exact") or []) or pid not in [p["id"] for p in st.get("exact") or []], pid)


def step10_browser(uid, fid):
    print("\n-- 10. the page in headless Chrome")
    if not BROWSER:
        check("skipped (run with --browser)", True)
        return
    try:
        s = __import__("socket").socket()
        s.settimeout(0.5)
        busy = s.connect_ex(("127.0.0.1", 9333)) == 0
        s.close()
    except OSError:
        busy = False
    if busy:
        check("port 9333 is free for Chrome", False, "something listens on 9333; the browser check needs it")
        return
    sys.path.insert(0, HERE)
    import ui_smoke_hier as UI
    c = UI.Chrome()
    try:
        url = "%s/isolate?upload=%s&finding=%s&standin=1" % (BASE, uid, fid)
        c.goto(url)
        time.sleep(3)
        check("page loads with its title", "isolation" in (c.js("document.title") or "").lower(), c.js("document.title"))
        have = c.js("['n-above','m-below','btn-extract','btn-send','chat-msg','btn-isolate','btn-summary','btn-expect','btn-write','ctx-line','reason','scenario-name'].filter(i=>!document.getElementById(i))")
        check("controls present (n, m, levels, Extract, chat, isolate, test case, summary)", have == [] and c.js("document.querySelectorAll('input.lvl').length") == 5, have)
        check("the defect header is filled with the device name", DEVICE in (c.js("document.getElementById('defect').innerText") or ""))
        n1 = c.js("document.querySelectorAll('#win-table tbody tr[data-level]').length")
        check("Extract ran on load: 10 above, the command, 10 below", n1 == 21, n1)
        c.js("document.getElementById('n-above').value=3; document.getElementById('m-below').value=2; document.getElementById('btn-extract').click()")
        time.sleep(2.5)
        n2 = c.js("document.querySelectorAll('#win-table tbody tr[data-level]').length")
        check("Extract again with different numbers (3 / 2) shows 6 commands", n2 == 6, n2)
        c.js("document.querySelector('input.lvl[value=link]').checked=true; document.querySelector('input.lvl[value=link]').dispatchEvent(new Event('change')); document.getElementById('btn-extract').click()")
        time.sleep(3)
        n3 = c.js("document.querySelectorAll('#win-table tbody tr.sub.l-link').length")
        check("ticking 'link transactions' shows link rows under the commands", n3 and n3 > 6, n3)
        c.js("[...document.querySelectorAll('#win-table tr[data-level=nvme_command] input.pick')].slice(0,2).forEach(x=>{x.checked=true;x.dispatchEvent(new Event('change'))})")
        check("the context count line says '2 NVMe commands'", "context: 2 NVMe commands" == (c.js("document.getElementById('ctx-line').innerText") or ""), c.js("document.getElementById('ctx-line').innerText"))
        c.js("document.getElementById('chat-msg').value='What do these show?'; document.getElementById('btn-send').click()")
        for _ in range(20):
            time.sleep(1)
            if "answered by" in (c.js("document.getElementById('chat-status').innerText") or ""):
                break
        check("the chat answer is shown (answered by stand-in)", "answered by stand-in" in (c.js("document.getElementById('chat-status').innerText") or "") and (c.js("document.querySelectorAll('#chat .msg').length") or 0) >= 2,
              c.js("document.getElementById('chat-status').innerText"))
        check("the memory block is filled in words", "seen before" in (c.js("document.getElementById('memory').innerText") or ""))
        c.shot("isolate_tab")
        bad = [e for e in c.errors if "favicon" not in e and not (e.startswith("log:") and "404" in e)]
        check("no JavaScript errors or failed requests", not bad, "; ".join(bad)[:400])
    finally:
        c.close()


def cleanup():
    print("\n-- 11. clean-up")
    for uid in list(CREATED["uploads"]):
        try:
            r = call("DELETE", "/api/hier/uploads/%s" % uid)
            check("upload %s deleted" % uid, r.get("deleted") == uid, r)
        except ApiError as e:
            check("upload %s deleted" % uid, False, e)
    for p in CREATED["files"]:
        if p and os.path.isfile(p):
            os.remove(p)
            print("      removed the generated test case", p)
    if not os.path.exists(KNOWLEDGE_DB) or not CREATED["signature"]:
        return
    con = sqlite3.connect(KNOWLEDGE_DB, timeout=30)
    try:
        b = CREATED["before"] or {}
        con.execute("UPDATE signature SET reason=?, summary4=?, scenario_name=? WHERE fine=?", (b.get("reason"), b.get("summary4"), b.get("scenario_name"), CREATED["signature"]))
        print("      signature's reason, summary and scenario name put back to what they were")
        if CLEANUP_STORE:
            pids = CREATED["procedures"]
            if pids:
                con.execute("DELETE FROM procedure WHERE id IN (%s) AND fine=?" % ",".join("?" * len(pids)), pids + [CREATED["signature"]])
            con.execute("DELETE FROM signal WHERE admin IN (?, ?) AND fine=?", (ADMIN, DEVICE, CREATED["signature"]))
            con.execute("DELETE FROM lesson WHERE producer=? AND fine=?", ("admin:" + ADMIN, CREATED["signature"]))
            for uid in CREATED["uploads"]:
                con.execute("DELETE FROM chat WHERE upload_id=?", (uid,))
                con.execute("DELETE FROM sighting WHERE upload_id=?", (uid,))
            con.execute("UPDATE signature SET seen=(SELECT COUNT(*) FROM sighting WHERE sighting.fine=signature.fine) WHERE fine=?", (CREATED["signature"],))
            print("      knowledge store: removed the %d procedure(s), the signals, lessons, sightings and chat lines this run created" % len(pids))
        else:
            print("      knowledge store: the %d procedure(s), signals and chat lines this run created stay (run with --cleanup-store to remove them)" % len(CREATED["procedures"]))
        con.commit()
    finally:
        con.close()


def main():
    try:
        call("GET", "/api/hier/uploads", timeout=10)
    except ApiError as e:
        print("the application does not answer at %s: %s" % (BASE, e))
        sys.exit(2)
    try:
        uid, fid = step1_upload()
        if fid is None:
            raise ApiError("no finding on command 207")
        P = "/api/isolate/%s/%d" % (uid, fid)
        step2_header(uid, fid, P)
        w = step3_window(uid, fid, P)
        step4_chat(uid, fid, P, w)
        loop = step5_loop_standin(uid, fid, P, w)
        step6_loop_model(uid, fid, P, w)
        pid = step7_memory_and_store(uid, fid, P, loop)
        step8_chat_model(uid, fid, P, w)
        step9_testcase(uid, fid, P, loop, pid)
        step10_browser(uid, fid)
    except ApiError as e:
        check("the suite ran to the end", False, e)
    except Exception as e:      # noqa: BLE001
        traceback.print_exc()
        check("the suite ran to the end without an unexpected error", False, "%s: %s" % (type(e).__name__, e))
    finally:
        try:
            cleanup()
        except Exception as e:      # noqa: BLE001
            traceback.print_exc()
            check("clean-up ran", False, e)
    fails = [r for r in RESULTS if not r[0]]
    print("\n%d checks, %d failed, %d model call(s), %.0f s" % (len(RESULTS), len(fails), MODEL_CALLS["n"], time.time() - T0))
    for ok, name, det in fails:
        print("  FAIL", name, ("| " + str(det)[:300]) if det else "")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
