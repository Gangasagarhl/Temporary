"""Configuration: LLM endpoint / model / effort, stage-2 budgets, picker starting folders. Keys never leave the environment."""
import json

from flask import Blueprint, jsonify, request

from . import ACTION_HELP, svc

bp = Blueprint("config", __name__)


def save_config(cfg):
    out = {k: v for k, v in cfg.items() if not k.startswith("_")}
    with open(cfg["_path"], "w") as f:
        json.dump(out, f, indent=2)


@bp.get("/api/config")
def get_config():
    s = svc()
    c = {k: v for k, v in s.cfg.items() if not k.startswith("_")}
    return jsonify({"config": c, "llm_active": getattr(s.s2.llm, "name", "stand-in"), "actions": ACTION_HELP, "root": s.root})


@bp.put("/api/config")
def put_config():
    s = svc()
    body = request.get_json(force=True) or {}
    if (s.cfg.get("server") or {}).get("lock_endpoint"):
        # production: where the API key is sent is fixed in the config file;
        # the Settings page may still change the model, effort and stage-2 limits
        locked = {"llm": ("base_url", "api_key_env", "backend", "tools")}
        for sec, keys in locked.items():
            for k in keys:
                if k in (body.get(sec) or {}) and body[sec][k] != (s.cfg.get(sec) or {}).get(k):
                    return jsonify({"error": "%s.%s is locked by server.lock_endpoint: stop the service, edit the config file, start it again" % (sec, k)}), 403
    for sec in ("llm", "stage1", "stage2", "paths"):
        if sec in body and isinstance(body[sec], dict):
            s.cfg[sec].update({k: v for k, v in body[sec].items() if not k.startswith("_")})
    save_config(s.cfg)
    s.s2.reload_llm()
    return jsonify({"ok": True, "llm_active": getattr(s.s2.llm, "name", "stand-in")})
