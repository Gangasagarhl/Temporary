/* The isolation tab of one defect: /isolate?upload=<upload id>&finding=<finding id> (statement of 2026-11-03, parts 4-8). */
import { api, $, esc } from "./api.js";

const Q = new URLSearchParams(location.search);
const UID = Q.get("upload"), FID = Q.get("finding");
const BASE = `/api/isolate/${encodeURIComponent(UID)}/${encodeURIComponent(FID)}`;
const LABEL = { packets: "packet", link: "link transaction", split: "split transaction", nvme_transaction: "NVMe transaction", nvme_command: "NVMe command" };
const SIGNAL_WORDS = { correct: "correct", correct_with_edits: "correct with edits", wrong: "wrong", wrong_with_edits: "wrong with edits" };

let H = null;                 // the header (defect, memory, history)
let W = null;                 // the last extracted window
let ISO = null;               // the last isolation result
let SEQ = [];                 // the editable sequence (seed or chosen procedure)
let CHOSEN = null;            // the chosen stored procedure id (null = the seed)
let EXPECT = null;            // the proposed expected outcomes
const name = () => ($("name").value || "").trim() || undefined;
const standinQ = () => (Q.get("standin") === "1" ? "?standin=1" : "");
const status = (id, text, cls = "") => { const e = $(id); e.textContent = text; e.className = "status " + cls; };
const actor = (p) => p ? (p.startsWith("stand-in") ? "answered by stand-in (no model was used)" : "answered by the model " + p) : "";

// ------------------------------------------------------------------ 1 header
async function loadHeader() {
  H = await api("GET", BASE);
  const f = H.finding;
  $("upload-badge").textContent = UID; $("finding-badge").textContent = `defect ${FID}`;
  $("model-badge").textContent = H.model.available && !Q.get("standin") ? H.model.name : "stand-in (no model)";
  $("page-title").textContent = `Defect ${FID}: ${f.name || f.rule_words}`;
  document.title = `Defect ${FID} · isolation`;
  const chain = (f.chain || []).map(c => `${esc(c.label)} ${esc(c.n)}: ${esc(c.summary)}${c.dur ? ` (duration ${esc(c.dur)})` : ""}`).join(" → ");
  const cmd = f.command;
  $("defect").innerHTML = kv([
    ["level", `${esc(f.level_label)} level`],
    ["rule in words", esc(f.rule_words)],
    ["measured value", f.value_ps_text ? `${esc(f.value_ps_text)} measured; limit ${esc(f.limit_ps_text || "-")} (source: ${esc(f.limit_source || "-")})` : "this rule has no measured value (it fires on a status or an event)"],
    ["what the recording shows", esc(f.observed_outcome)],
    ["chain up to the command", chain || "-"],
    ["the command", cmd ? `${esc(cmd.summary)}${cmd.duration ? `, took ${esc(cmd.duration)} from doorbell to completion` : ""}${cmd.status ? `, status ${esc(cmd.status)}` : ""}${Object.keys(cmd.parameters || {}).length ? `, parameters ${esc(JSON.stringify(cmd.parameters))}` : ""}` : "outside any command"],
    ["lowest-level cause inside the command", f.cause ? `${esc(LABEL[f.cause.level] || f.cause.level)} level: ${esc(f.cause.name)}` : "none: the command is its own root"],
    ["device (drive under test)", esc(H.device) + (H.trace_name ? `, recording ${esc(H.trace_name)}` : "") + (H.recording_date ? `, recorded ${esc(H.recording_date)}` : "")],
    ["signature", `<span class="mono small">${esc(f.signature.display)}</span>`],
  ]);
  const c = f.catalogue;
  $("catalogue").innerHTML = c ? `<b>${esc(c.error || "")}</b> ${esc(c.meaning || "")}${c.spec ? ` <span class="muted">(specification ${esc(c.spec)})</span>` : ""}` +
    ((c.defects || []).length ? `<ul>${c.defects.slice(0, 6).map(d => `<li><b>${esc(d.domain)}</b>: ${esc(d.cause)}</li>`).join("")}</ul>` : "") : "no catalogue entry for this rule";
  $("expected-after").value = Math.max(0, Math.min(2, Number($("m-below").value)));
  renderMemory(H.memory);
  renderHistory(H.history);
  renderProcs(H.stored);
  if (H.stored && H.stored.reason) $("reason").value = H.stored.reason;
  if (H.stored && H.stored.scenario_name) $("scenario-name").value = H.stored.scenario_name;
  if (H.stored && H.stored.summary4) showSummary(H.stored.summary4.split("\n"), null);
}
const kv = (pairs) => pairs.map(([k, v]) => `<b>${esc(k)}</b><span>${v}</span>`).join("");

// ------------------------------------------------------------------ 2 window
function levels() { return [...document.querySelectorAll("input.lvl")].filter(x => x.checked && x.value).map(x => x.value); }
async function extract() {
  const n = Number($("n-above").value || 0), m = Number($("m-below").value || 0);
  status("win-status", "extracting…");
  try {
    W = await api("GET", `${BASE}/window?n=${n}&m=${m}&levels=${levels().join(",")}&queue=${$("same-queue").checked ? "same" : "all"}&per=${Math.max(1, Number($("per-level").value || 50))}`);
  } catch (e) { status("win-status", "could not extract: " + e.message, "bad"); return; }
  const tb = $("win-table").querySelector("tbody");
  const rows = [];
  for (const c of W.commands) {
    rows.push(rowHtml(c, c.position === "fault" ? "fault" : "", false));
    for (const lv of W.levels) {
      const blk = (c.under || {})[lv];
      if (!blk) continue;
      for (const r of blk.rows) rows.push(rowHtml(r, `sub l-${lv}`, true));
      if (blk.count > blk.shown) rows.push(`<tr class="more"><td></td><td class="lv">${esc(LABEL[lv])}s</td><td colspan="6">${blk.count - blk.shown} more ${esc(LABEL[lv])}s under this command are not shown (the first ${blk.shown} of ${blk.count} are)</td></tr>`);
    }
  }
  tb.innerHTML = rows.join("") || `<tr><td colspan="8" class="muted">no rows</td></tr>`;
  const above = W.commands.filter(c => c.position === "above").length, below = W.commands.filter(c => c.position === "below").length;
  status("win-status", `${above} command${above === 1 ? "" : "s"} above, the command, ${below} below${W.levels.length ? `; under each: ${W.levels.map(l => LABEL[l] + "s").join(", ")} (first ${W.per_level} per level)` : ""}`, "ok");
  $("win-note").textContent = W.note || "";
  tb.querySelectorAll("input.pick").forEach(cb => cb.addEventListener("change", updateContext));
  updateContext();
}
function rowHtml(r, cls, sub) {
  const f = (r.findings || []).map(x => x.name).join("; ");
  const st = r.status ? esc(r.status) : "";
  return `<tr class="${cls}${f ? " has-f" : ""}" data-level="${r.level}" data-rowid="${r.rowid}" data-n="${r.n}" data-parent="${r.parent_n ?? ""}">
    <td><input type="checkbox" class="pick" aria-label="put this row into the context"></td>
    <td class="lv">${esc(LABEL[r.level])}${r.position && !sub ? ` <span class="muted">[${esc(r.position)}]</span>` : ""}${r.relation === "context" ? ' <span class="muted">(context)</span>' : ""}</td>
    <td class="num">${esc(r.n ?? "")}</td><td>${esc(r.summary)}${sub && r.level === "packets" && r.parent_n != null ? ` <span class="muted">(of link ${esc(r.parent_n)})</span>` : ""}</td>
    <td>${st}${st && f ? "; " : ""}${f ? `<span class="bad">${esc(f)}</span>` : ""}</td>
    <td class="num">${esc(r.gap || "")}</td><td class="num">${esc(r.dur || "")}</td><td>${esc(r.t || "")}</td></tr>`;
}
function picked() {
  return [...document.querySelectorAll("#win-table tr[data-level]")].filter(tr => tr.querySelector("input.pick").checked)
    .map(tr => ({ level: tr.dataset.level, rowid: Number(tr.dataset.rowid), n: tr.dataset.n, parent_n: tr.dataset.parent }));
}
function contextText(rows) {
  if (!rows.length) return "context: nothing selected";
  const parts = [];
  for (const lv of ["nvme_command", "nvme_transaction", "split", "link", "packets"]) {
    const rs = rows.filter(r => r.level === lv);
    if (!rs.length) continue;
    if (lv === "packets") { const ps = [...new Set(rs.map(r => r.parent_n).filter(x => x))]; if (ps.length && ps.length <= 3) { parts.push(`the packets of link${ps.length > 1 ? "s" : ""} ${ps.join(" and ")}`); continue; } }
    parts.push(`${rs.length} ${LABEL[lv]}${rs.length === 1 ? "" : "s"}`);
  }
  return "context: " + parts.join(", ");
}
function updateContext() { $("ctx-line").textContent = contextText(picked()); }

// ------------------------------------------------------------------ 3 chat
function renderHistory(hist) {
  const box = $("chat");
  if (!hist || !hist.length) { box.innerHTML = `<div class="muted">no messages yet</div>`; return; }
  box.innerHTML = hist.map(h => {
    const admin = (h.role || "").startsWith("admin:"), loop = h.role === "loop";
    const who = admin ? h.role.slice(6) : loop ? "evidence loop" : (h.role.startsWith("stand-in") ? "stand-in" : "model " + h.role);
    let extra = "";
    const d = h.data || {};
    if (!admin && !loop && d.scenario_name) extra += `\nscenario name: ${d.scenario_name}`;
    if (!admin && !loop && d.reason && d.kind !== "isolate_result") extra += `\nreason: ${d.reason}`;
    if (admin && d.context) extra += `\n(${d.context})`;
    return `<div class="msg ${admin ? "admin" : loop ? "loop" : ""}"><span class="who">${esc(who)}</span>${esc((h.text || "") + extra)}</div>`;
  }).join("");
  box.scrollTop = box.scrollHeight;
}
async function send() {
  const message = $("chat-msg").value.trim();
  if (!message) { status("chat-status", "type a message first", "warn"); return; }
  status("chat-status", "asking…");
  $("btn-send").disabled = true;
  try {
    const r = await api("POST", `${BASE}/chat${standinQ()}`, { message, name: name(), context: { rows: picked().map(p => ({ level: p.level, rowid: p.rowid })), include_defect: $("inc-defect").checked, include_catalogue: $("inc-cat").checked, include_memory: $("inc-mem").checked } });
    $("chat-msg").value = "";
    renderHistory(r.history);
    status("chat-status", actor(r.producer), r.standin ? "warn" : "ok");
    $("chat-meta").textContent = `${r.context_text}; ${r.prompt_chars.toLocaleString()} characters were sent, with the last ${H.bounds.history_turns} entries of this conversation`;
    const a = r.answer || {};
    if (a.scenario_name && !$("scenario-name").value) $("scenario-name").value = a.scenario_name;
    if (a.reason && !$("reason").value) $("reason").value = a.reason;
  } catch (e) { status("chat-status", "no answer: " + e.message, "bad"); }
  $("btn-send").disabled = false;
}

// ------------------------------------------------------------------ 4 memory
function renderMemory(m) {
  if (!m) return;
  const ex = m.exact || {};
  $("memory").innerHTML = kv([
    ["seen before on this device?", esc(m.seen_before_text)],
    ["on other devices?", esc(m.on_other_devices_text)],
    ["sightings counted", `${m.seen ?? 0} (once per upload and defect)`],
    ["exact key", `<span class="mono small">${esc((m.signature || {}).fine || "")}</span>`],
    ["family key", `<span class="mono small">${esc((m.signature || {}).family || "")}</span>`],
    ["stored for this exact defect", ex.reason || ex.scenario_name || ex.best ? `${ex.reason ? "reason: " + esc(ex.reason) + "; " : ""}${ex.scenario_name ? "scenario: " + esc(ex.scenario_name) + "; " : ""}${ex.best ? `best sequence version ${ex.best.version}, score ${esc(ex.best.score_text)} (${ex.best.counts.correct} correct, ${ex.best.counts.correct_with_edits} correct with edits, ${ex.best.counts.wrong} wrong, ${ex.best.counts.wrong_with_edits} wrong with edits)` : "no sequence yet"}` : "nothing yet"],
    ["four-line summary", ex.summary4 ? esc(ex.summary4).replace(/\n/g, "<br>") : "none yet"],
  ]);
  const facts = m.retrieval || [];
  $("facts").innerHTML = facts.length ? facts.map(f => `<div class="fact t${f.tier}"><b>${f.rank}.</b> ${esc(f.text)}</div>`).join("") : "nothing is stored for this signature or its family yet";
}
async function refreshMemory() { try { const m = await api("GET", `${BASE}/memory`); renderMemory(m); } catch (e) { /* shown already */ } }

// ------------------------------------------------------------------ 5 the evidence loop
async function isolate() {
  status("iso-status", "running the evidence loop…");
  $("btn-isolate").disabled = true;
  try {
    ISO = await api("POST", `${BASE}/isolate${standinQ()}`, { n: Number($("n-above").value || 0), m: Number($("m-below").value || 0), levels: levels(), hint: $("hint").value, anyway: $("anyway").checked, name: name(), queue: $("same-queue").checked ? "same" : "all" });
  } catch (e) {
    status("iso-status", e.message, "bad");
    $("btn-isolate").disabled = false;
    if (/already stored/.test(e.message)) $("anyway").focus();
    return;
  }
  $("btn-isolate").disabled = false;
  status("iso-status", actor(ISO.producer), ISO.standin ? "warn" : "ok");
  const rounds = (ISO.rounds || []).map(r => `<li>${esc(r.text)}${r.evidence_rows ? ` <span class="muted small">(${r.evidence_rows} evidence rows, ${r.prompt_chars.toLocaleString()} characters sent)</span>` : ""}</li>`).join("");
  const cited = (ISO.cited_rows || []).map(c => `${esc(c.label)} ${esc(c.n ?? c.rowid)}: ${esc(c.summary || "")}`).join("<br>");
  $("iso-result").innerHTML = `<ol class="rounds">${rounds}</ol>
    <div class="reason"><b>Reason:</b> ${esc(ISO.reason)}</div>
    <div class="kv"><b>rows cited</b><span>${cited || "none"}</span>
    <b>sequence</b><span>${ISO.kept_above} of ${ISO.kept_above + ISO.dropped_above} commands above kept, the defect, ${ISO.below_copied} after it copied unchanged (fetched: ${ISO.above_fetched} above, levels ${ISO.levels_fetched.join(", ") || "commands only"})</span>
    <b>checks by the code</b><span>${ISO.checks.ok ? '<span class="ok">passed</span>' : '<span class="warn">with remarks</span>'}: ${esc(ISO.checks.rules.join("; "))}${ISO.checks.problems.length ? "<br>remarks: " + esc(ISO.checks.problems.join("; ")) : ""}</span></div>`;
  renderHistory(ISO.history);
  if (!$("reason").value) $("reason").value = ISO.reason;
  if (!$("scenario-name").value && ISO.scenario_name) $("scenario-name").value = ISO.scenario_name;
  if (ISO.seed) { CHOSEN = null; setSeq(ISO.sequence); renderProcs(H.stored, "the seed from the isolation above (nothing is stored yet for this exact defect)"); }
  else { renderProcs(H.stored, "a new proposal was made; the stored sequences stay listed below"); CHOSEN = null; setSeq(ISO.sequence); }
  $("s-seed").scrollIntoView({ behavior: "smooth" });
}

// ------------------------------------------------------------------ 6 sequence, procedures, signals
function setSeq(steps) {
  SEQ = (steps || []).map(s => ({ ...s, parameters: s.parameters || {} }));
  const tb = $("seq-table").querySelector("tbody");
  tb.innerHTML = SEQ.map((s, i) => `<tr class="${s.position === "fault" ? "fault" : ""}" data-i="${i}"><td>${s.step}</td><td><input class="cmd" value="${esc(s.command)}"></td><td><input class="par" value="${esc(JSON.stringify(s.parameters))}"></td>
    <td><input class="gap" type="number" min="1" value="${esc(s.gap_us ?? 10)}"></td><td class="small">${esc(s.expected || "")}</td><td class="small muted">${esc((s.why || []).join ? s.why.join("; ") : (s.why || ""))}</td>
    <td>${s.position === "fault" ? '<span class="pill bad">the defect</span>' : `<button class="small del">remove</button>`}</td></tr>`).join("") || `<tr><td colspan="7" class="muted">no sequence yet: run section 5 or choose a stored one</td></tr>`;
  tb.querySelectorAll("button.del").forEach(b => b.addEventListener("click", () => { SEQ.splice(Number(b.closest("tr").dataset.i), 1); SEQ.forEach((s, i) => s.step = i + 1); setSeq(SEQ); }));
}
function readSeq() {
  const rows = [...$("seq-table").querySelectorAll("tbody tr[data-i]")];
  return rows.map((tr, i) => { const s = SEQ[Number(tr.dataset.i)]; let p = s.parameters; try { p = JSON.parse(tr.querySelector("input.par").value || "{}"); } catch (e) { /* keep */ }
    return { ...s, step: i + 1, command: tr.querySelector("input.cmd").value.trim(), parameters: p, gap_us: Number(tr.querySelector("input.gap").value || 10) }; });
}
function edited() { const a = readSeq(); return JSON.stringify(a.map(s => [s.command, s.parameters, s.gap_us])) !== JSON.stringify(SEQ.map(s => [s.command, s.parameters, s.gap_us])) || a.length !== SEQ.length; }
function renderProcs(know, note) {
  const procs = (know && know.exact) || [];
  const box = $("procs");
  if (!procs.length) { box.innerHTML = `<p class="muted">${esc(note || "nothing is stored for this exact signature yet: the sequence below is the seed once section 5 has run")}</p>`; return; }
  box.innerHTML = (note ? `<p class="muted">${esc(note)}</p>` : "") + `<p>${procs.length} stored sequence${procs.length === 1 ? "" : "s"}, ordered by ${esc(procs[0].ordered_by)}:</p>` + procs.map((p, i) => `<div class="proc ${CHOSEN === p.id ? "sel" : ""}" data-pid="${p.id}">
    <b>version ${p.version}</b> · score ${esc(p.score_text)} (${p.c_ok} correct, ${p.c_ok_edit} correct with edits, ${p.c_wrong} wrong, ${p.c_wrong_edit} wrong with edits) · by ${esc(p.producer)}${p.test_path ? " · has a test file" : ""}
    <div class="small muted">${esc(p.steps.map(s => s.command).join(" → "))}</div>
    <div class="row"><button class="small use">use</button>${i > 0 ? '<button class="small up">move up</button>' : ""}</div></div>`).join("");
  box.querySelectorAll(".proc").forEach(div => {
    const pid = Number(div.dataset.pid), p = procs.find(x => x.id === pid);
    div.querySelector("button.use").addEventListener("click", () => { CHOSEN = pid; setSeq(p.steps); renderProcs(know); status("sig-status", `using stored version ${p.version}; the four signals now apply to it`); });
    const up = div.querySelector("button.up");
    if (up) up.addEventListener("click", async () => {
      const order = procs.map(x => x.id); const k = order.indexOf(pid); [order[k - 1], order[k]] = [order[k], order[k - 1]];
      const r = await api("POST", `${BASE}/reorder`, { order, name: name() }); H.stored = r.stored; renderProcs(H.stored, "your order is used until the next signal");
    });
  });
}
async function signal(sig) {
  const steps = readSeq();
  if (!steps.length) { status("sig-status", "no sequence to judge", "warn"); return; }
  const body = { signal: sig, name: name(), scenario_name: $("scenario-name").value.trim(), reason: $("reason").value.trim(), procedure_id: CHOSEN,
    proposal_steps: steps, proposal_text: ISO ? ISO.reason : "", edited_steps: sig.endsWith("_with_edits") ? steps : undefined,
    outcome: { observed: H.finding.observed_outcome, expected: (ISO && ISO.expected_outcome) || H.finding.expected_outcome_default, verified_by: name() || H.device } };
  if (sig.endsWith("_with_edits") && !edited() && CHOSEN !== null) status("sig-status", "nothing was edited; the stored version is judged as it is", "warn");
  status("sig-status", "storing…");
  try {
    const r = await api("POST", `${BASE}/signal`, body);
    H.stored = r.stored; renderMemory(r.memory);
    const nid = (r.result || {}).new_procedure_id;
    status("sig-status", `recorded: ${SIGNAL_WORDS[sig]} by ${r.actor}${nid ? ` — stored as a new version (procedure ${nid})` : ""}`, "ok");
    if (nid) CHOSEN = nid;
    renderProcs(H.stored);
  } catch (e) { status("sig-status", "not recorded: " + e.message, "bad"); }
}

// ------------------------------------------------------------------ 7 test case
async function askExpected() {
  const steps = readSeq();
  if (!steps.length) { status("test-status", "no sequence yet", "warn"); return; }
  const given = $("above-given").checked;
  const aboveN = given ? Math.max(0, Number($("above-n").value || 0)) : null;
  status("test-status", given ? `asking for the expected outcomes (input: the last ${aboveN} commands before the defect, from the recording)…` : "asking for the expected outcomes (input: the sequence as kept in card 6)…");
  try {
    EXPECT = await api("POST", `${BASE}/testcase${standinQ()}`, { sequence: steps, expected_after: 1 + Math.max(0, Number($("expected-after").value || 0)), name: name(),
      above_n: aboveN, same_queue: $("same-queue").checked, expected_before: given ? aboveN : 0 });
  } catch (e) { status("test-status", e.message, "bad"); return; }
  if (given) { CHOSEN = null; setSeq(EXPECT.sequence); }
  const tb = $("expect-table").querySelector("tbody");
  tb.innerHTML = EXPECT.expected_outcomes.map((o, i) => `<tr data-i="${i}"><td>${o.step}${o.step === EXPECT.fault_step ? ' <span class="pill bad">the defect</span>' : (o.step < EXPECT.fault_step ? ' <span class="pill">input</span>' : "")}</td><td>${esc(o.command)}</td><td><input class="st" value="${esc(o.status)}"></td><td><input class="tm" type="number" min="1" value="${o.timing_us}"> µs</td><td><input class="ck" value="${esc(o.check)}"></td><td class="small muted">${esc(o.basis)}</td><td><input type="checkbox" class="ver"></td></tr>`).join("");
  $("expect-table").hidden = false;
  status("test-status", `${actor(EXPECT.producer)}; limit used: ${EXPECT.limit.text} (${EXPECT.limit.source}). Check every line, tick it, tick "I verified them".`, EXPECT.standin ? "warn" : "ok");
  $("btn-write").disabled = false;
}
async function writeTest() {
  if (!EXPECT) return;
  const rows = [...$("expect-table").querySelectorAll("tbody tr")];
  const outs = rows.map(tr => { const o = EXPECT.expected_outcomes[Number(tr.dataset.i)]; return { ...o, status: tr.querySelector("input.st").value, timing_us: Number(tr.querySelector("input.tm").value || o.timing_us), check: tr.querySelector("input.ck").value, verified: tr.querySelector("input.ver").checked }; });
  if (!$("verified").checked || outs.some(o => !o.verified)) { status("test-status", "tick every expected outcome and 'I verified them' first", "warn"); return; }
  status("test-status", "writing…");
  try {
    const r = await api("POST", `${BASE}/testcase`, { sequence: EXPECT.sequence, expected_outcomes: outs, verified: true, name: name(), scenario_name: $("scenario-name").value.trim(), procedure_id: CHOSEN });
    $("testcase").textContent = r.text;
    status("test-status", `written: ${r.path} (version ${r.version})`, "ok");
  } catch (e) { status("test-status", e.message, "bad"); }
}

// ------------------------------------------------------------------ 8 summary
function showSummary(lines, producer) {
  const names = ["what happened", "where", "why", "what the test checks"];
  $("summary").innerHTML = lines.map((l, i) => `<div><b>${names[i] || ""}:</b> ${esc(l)}</div>`).join("") + (producer ? `<div class="small muted">${esc(actor(producer))}; stored with the signature</div>` : "");
  $("summary").hidden = false;
}
async function summary() {
  status("sum-status", "writing the four lines…");
  try {
    const r = await api("POST", `${BASE}/summary${standinQ()}`, { reason: $("reason").value.trim(), sequence: readSeq(), expected_outcome: ISO && ISO.expected_outcome, name: name() });
    showSummary(r.lines, r.producer);
    status("sum-status", `${r.lines.length} lines; ${actor(r.producer)}`, r.standin ? "warn" : "ok");
    H.stored = r.stored; refreshMemory();
  } catch (e) { status("sum-status", e.message, "bad"); }
}

// ------------------------------------------------------------------ wiring
function wire() {
  document.querySelectorAll("button.nav").forEach(b => b.addEventListener("click", () => { document.querySelectorAll("button.nav").forEach(x => x.classList.toggle("active", x === b)); $(b.dataset.go).scrollIntoView({ behavior: "smooth" }); }));
  $("btn-extract").addEventListener("click", extract);
  document.querySelectorAll("input.lvl").forEach(cb => cb.addEventListener("change", () => {
    const same = document.querySelector('input.lvl[value=""]');
    if (cb.value === "" && cb.checked) document.querySelectorAll("input.lvl").forEach(x => { if (x.value) x.checked = false; });
    else if (cb.value && cb.checked) same.checked = false;
    if (!levels().length) same.checked = true;
  }));
  $("btn-tick-all").addEventListener("click", () => { document.querySelectorAll('#win-table tr[data-level="nvme_command"] input.pick').forEach(x => x.checked = true); updateContext(); });
  $("btn-tick-none").addEventListener("click", () => { document.querySelectorAll("#win-table input.pick").forEach(x => x.checked = false); updateContext(); });
  $("btn-send").addEventListener("click", send);
  $("chat-msg").addEventListener("keydown", e => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) send(); });
  $("btn-isolate").addEventListener("click", isolate);
  document.querySelectorAll("button.sig").forEach(b => b.addEventListener("click", () => signal(b.dataset.sig)));
  $("btn-expect").addEventListener("click", askExpected);
["above-kept", "above-given"].forEach(id => $(id).addEventListener("change", () => { $("above-n").disabled = !$("above-given").checked; }));
  $("btn-write").addEventListener("click", writeTest);
  $("btn-summary").addEventListener("click", summary);
}

(async () => {
  wire();
  if (!UID || !FID) { $("load-error").hidden = false; $("load-error").textContent = "open this tab from page 3 (Defects found): the address needs ?upload=<upload id>&finding=<defect number>"; return; }
  try { await loadHeader(); } catch (e) { $("load-error").hidden = false; $("load-error").textContent = "could not load the defect: " + e.message; return; }
  await extract();
})();
