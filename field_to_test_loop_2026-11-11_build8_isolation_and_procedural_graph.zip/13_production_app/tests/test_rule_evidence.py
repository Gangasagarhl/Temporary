"""The evidence behind every Family 3 item, and sections made by the admin.

    python3 -m pytest -q tests/test_rule_evidence.py

The owner's request of 2026-11-09: when an item is opened, show which column of which file it reads and how it decides,
grounded in evidence, never made up; and let the admin add sections. These tests hold that to the code:
  - every detector rule has its columns and its test written down (agentic/rule_evidence.py READS)
  - every column named there is read by the code that files the rule (so the screen cannot claim a column the code
    does not use), and the lines shown as "the code that decides" are the lines that file it
  - every named column is an analyzer column (the loader's own table) or a column the tree build makes
  - a section made by the admin is stored, numbered after the built-in ones, takes items, and its items go on to
    stage 1 and stage 2 only when the admin said they find defects
  - an item with no plan yet says so instead of inventing columns
With the sample upload of scenario S17 present, the never-completed rule is checked against the data itself.
"""
import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from agentic import family1, family3, pipeline, rule_evidence as E   # noqa: E402
from nvme_hier import rules as RL   # noqa: E402


def test_every_detector_rule_says_what_it_reads_and_how_it_decides():
    assert set(E.READS) == set(RL.BASIS)
    for rule, (reads, test) in E.READS.items():
        assert reads and test.strip(), rule


def test_every_named_column_is_read_by_the_code_that_files_the_rule():
    for rule, (reads, _t) in E.READS.items():
        c = E.code_of(rule)
        assert c and c["snippets"], rule
        shown = "\n".join(s["text"] for s in c["snippets"])
        assert '"%s"' % rule in shown or "LINK_EVENTS" in shown, rule          # the lines shown are the rule's own
        text = c["method_source"] + "\n" + shown
        for _lv, sql in reads:
            assert sql in text, (rule, sql, c["method"])
        for s in c["snippets"]:
            lines = open(os.path.join(E.APP, c["path"]), encoding="utf-8").read().split("\n")
            assert "\n".join(lines[s["from"] - 1:s["to"]]) == s["text"], (rule, s["from"])   # the line numbers are right


def test_every_named_column_is_an_analyzer_column_or_made_by_the_tree():
    for rule, (reads, _t) in E.READS.items():
        for lv, sql in reads:
            assert E.file_columns(lv, sql) or sql in E.DERIVED, (rule, lv, sql)


@pytest.fixture
def knowledge(tmp_path, monkeypatch):
    monkeypatch.setattr(family1, "knowledge_dir", lambda: str(tmp_path))
    family3._SECTIONS_SEEN[0] = None
    yield tmp_path
    family3._SECTIONS_SEEN[0] = None


def test_the_admin_adds_sections_and_their_items_follow_what_the_section_is_for(knowledge):
    assert [s["id"] for s in family3.sections()] == ["analytics", "errors"]
    t = family3.add_section("Timing checks", "rows whose waits are too long", True, "Sagar")
    r = family3.add_section("Queue usage", "how full the queues get", False, "Sagar")
    secs = family3.sections()
    assert [s["title"] for s in secs] == ["Section 1 · Data analytics", "Section 2 · Error roots", "Section 3 · Timing checks", "Section 4 · Queue usage"]
    assert family3.goes_to_stages(t["id"]) and not family3.goes_to_stages(r["id"]) and family3.goes_to_stages("errors")
    with pytest.raises(ValueError):
        family3.add_section("timing  CHECKS", "", False, "Sagar")      # the same name, whatever the case and spacing
    with pytest.raises(ValueError):
        family3.add_section("   ", "", False, "Sagar")
    it = family3.add_item(t["id"], "link", "a link transaction waits too long", "Time Delta above 10 us", "Sagar")
    assert family3.load_rule(t["id"], "link", it["id"])["created_by"] == "Sagar"
    tree = {s["section"]: s for s in family3.tree()}
    assert tree[t["id"]]["defects"] and tree[t["id"]]["about"] == "rows whose waits are too long"
    assert [i["id"] for l in tree[t["id"]]["levels"] for i in l["items"]] == [it["id"]]
    keys = [s["key"] for s in pipeline.item_steps(t["id"], "link", it["id"], it["name"], True)]
    # (owner, 2026-11-11) an errors pattern lists its errors on page 3; stage 1 and stage 2 of each error are done on its own page
    assert any(k.endswith(":errors") for k in keys) and not any(k.endswith((":isolate", ":testcase")) for k in keys)
    keys = [s["key"] for s in pipeline.item_steps(r["id"], "nvme_command", "x", "x", True)]
    assert not any(k.endswith((":errors", ":isolate")) for k in keys)
    x = E.explain(t["id"], "link", it["id"])
    assert x["procedure"] is None and x["code"]["kind"] == "none" and x["admin_words"] == "Time Delta above 10 us"   # nothing invented
    assert x["procedure_json"]["source_data"] == [{"file": "link.csv", "columns": []}] and x["procedure_json"]["steps"] == []
    assert x["section"]["title"] == "Section 3 · Timing checks"


S17 = os.path.join(E.APP, "uploads", "up-20261108-123729-0a98", "hier.sqlite")


@pytest.mark.skipif(not os.path.exists(S17), reason="the S17 sample upload is not on this machine")
def test_a_rule_not_kept_starts_in_deleted_items_and_restored_shows_its_source_its_procedure_and_the_code(knowledge):
    family3.tree()                         # a rules folder of its own: a new installation
    assert family3.load_rule("errors", "nvme_command", "cmd_incomplete") is None
    gone = {g["id"]: g for g in family3.deleted_items()}
    assert gone["cmd_incomplete"]["by"] == family3.INSTALL_DELETED_BY and len(gone) >= 30
    family3.restore_item("errors", "nvme_command", "cmd_incomplete", "Sagar")
    x = E.explain("errors", "nvme_command", "cmd_incomplete", "up-20261108-123729-0a98")
    assert [(v["file"], v["columns"]) for v in x["sources"]] == [("nvme_command.csv", ["OPC", "SQID"]), ("NVME_Transactions.csv", ["Type"])]
    assert x["sources"][1]["path"].endswith("S17_io_timeout_abort_reset/NVME_Transactions.csv")
    steps = " ".join(x["procedure"]["steps"])
    assert "completion" in steps and "lower case" in steps and "NVMe Base 2.1 section 3.3.1.2" in steps
    assert x["code"]["kind"] == "detector" and x["code"]["verified"] and x["code"]["path"] == "nvme_hier/rules.py"
    lines = open(os.path.join(E.APP, "nvme_hier", "rules.py")).read().split("\n")
    a, b = x["code"]["lines"][-1]
    assert '"cmd.incomplete"' in "\n".join(lines[a - 1:b])                         # the lines shown are the rule's own
    assert E.counts("up-20261108-123729-0a98")["errors/nvme_command/cmd_incomplete"]["found"] == 6


@pytest.mark.skipif(not os.path.exists(S17), reason="the S17 sample upload is not on this machine")
def test_the_two_command_items_say_what_they_read_in_short_steps(knowledge):
    family3.tree()
    t = E.explain("errors", "nvme_command", "cmd_timeout", "up-20261108-123729-0a98")
    assert [(v["file"], v["columns"]) for v in t["sources"]] == [("nvme_command.csv", ["OPC", "SQID", "NLB", "ST.SCT", "ST.SC", "Time Stamp"]),
                                                                  ("NVME_Transactions.csv", ["Type", "SCT", "SC", "Time Stamp"]),
                                                                  ("split.csv", []), ("link.csv", ["Explicit ACK", "Link Tra Error"])]
    assert any("section 3.3.1.2" in s and "submitted" in s and "consumed" in s for s in t["procedure"]["steps"])
    assert any("PCIe Base 3.6.2" in s and "ACK" in s and "NAK" in s for s in t["procedure"]["steps"])
    steps = t["procedure"]["steps"]
    assert any(s.startswith("Never completed:") and "ST.SCT and ST.SC are empty" in s for s in steps)
    assert any(s.startswith("Aborted by the host:") and "07h" in s and "71h" in s for s in steps)
    assert any(s.startswith("The host's limit:") and "30 s" in s and "60 s" in s for s in steps)
    assert any(s.startswith("Slower than usual: more than 3 x the slowest normal command") for s in steps) and any("first jump" in s and "type and size" in s for s in steps)
    assert steps[0].startswith("Join the five files") and "Asynchronous Event Request" in steps[1]
    assert not any("page 3" in s for s in steps)                                  # page 3 has no command limit
    assert any("first completion entry" in s and "newest command" in s and "Completion Queue Head Doorbell" in s for s in steps)
    r = E.explain("errors", "nvme_command", "cmd_read_failure", "up-20261108-123729-0a98")
    assert [(v["file"], v["columns"]) for v in r["sources"]] == [("nvme_command.csv", ["OPC", "SQID", "ST.SCT", "ST.SC"])]   # the command file alone
    assert "FAST 2016" in r["procedure"]["steps"][-1] and any("Unrecovered Read Error" in s for s in r["procedure"]["steps"])


def test_the_two_command_rules_and_the_analytics_examples_are_chosen_by_default(knowledge):
    chosen = {(s["section"], l["level"], i["id"]) for s in family3.tree() for l in s["levels"] for i in l["items"] if i["default"]}
    assert chosen == {("analytics", "nvme_command", "command_type_share"), ("analytics", "nvme_command", "read_pattern"),
                      ("errors", "nvme_command", "cmd_timeout"), ("errors", "nvme_command", "cmd_read_failure")}
