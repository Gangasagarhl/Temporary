# Field-to-Test Loop: day-to-day operations

For whoever runs the service after it was installed with `deploy/AGENT_INSTRUCTIONS.md`. `$APP` = the
`13_production_app` folder (the one with `run_app.py`). The service unit is assumed to be installed from
`deploy/field-to-test-loop.service` under the name `field-to-test-loop` as described in `deploy/DEPLOY.md`; adjust
the name if it was installed differently. **AI reviewer** = the large language model (LLM) that gives a second
opinion; **API** = the web addresses under `/api/...`; **KPI** = the "Key results" on the Report page. The
commands use `${PORT:-8077}`: 8077 is the shipped `server.port`; if yours differs, run `export PORT=<port>` first.
The environment file of the service is `/etc/field-to-test-loop/environment` and the service user is `ftl`
(`deploy/DEPLOY.md`).

The hard rules of `deploy/AGENT_INSTRUCTIONS.md` section 1 apply here too: never delete `db/knowledge.sqlite` (and
never copy or move it without its side files `knowledge.sqlite-wal` and `knowledge.sqlite-shm`), never run two server processes on the same `db/`, keep the server on 127.0.0.1 behind the authenticating proxy, keys
never in `config/app_config.json` (only in the service's environment file or, when typed on the Settings page, in
the private key file of section 6), respect the two-person rule, never train a model, never run format / sanitize /
firmware download / namespace delete on a drive.

Since 2026-11-11 a second database holds admin judgements: `db/hier_knowledge.sqlite`, with the **procedural graph**
of the error pages (tables `dg_*`, `nvme_hier/defect_graph.py`) beside the isolation memory. It is also opened in
write-ahead-log mode (`PRAGMA journal_mode=WAL` in `DefectGraph._con`), so the same care applies: copy it with
`deploy/backup.sh`, or with the service stopped together with its `-wal` and `-shm` files. Sections 2, 3, 11 and 12
describe it. Section 6 covers the model connection (URL, model, key), section 13 the flow's Data Grounder, Stop and
Delete.

---

## 1. Start, stop, status, logs

| Task | Command |
|---|---|
| Start | `sudo systemctl start field-to-test-loop` |
| Stop | `sudo systemctl stop field-to-test-loop` |
| Restart (needed after changing keys or the environment file, `server.*`, `paths.*`, `stage2.bench`, any setting edited in the file, and the keys locked by `server.lock_endpoint`) | `sudo systemctl restart field-to-test-loop` |
| Status | `systemctl status field-to-test-loop` → `active (running)` |
| Server log (requests, Python errors) | `journalctl -u field-to-test-loop -n 200 --no-pager` (`-f` to follow) |
| Is it answering? | `curl -fsS http://127.0.0.1:${PORT:-8077}/api/config >/dev/null && echo up` |
| Without systemd (development only) | `cd $APP && . .venv/bin/activate && python3 run_app.py` — prints `Model connection: <URL>, model <model>, key <where it came from> ending ...<last 4 characters>  (change them in Settings -> Model connection)` and then `Field-to-Test Loop  ->  http://127.0.0.1:8077   (local only; Ctrl-C to stop)` (add `--port <port>` for another port); stop with Ctrl-C |
| Which key and address the service started with | `journalctl -u field-to-test-loop -b --no-pager \| grep 'Model connection:' \| tail -1` — the same line as above, printed by `run_app.py` at every start (section 6); the key itself is never printed |

Every lookup and every decision is committed to the knowledge base immediately (`app/stage2_service.py`), so a stop
or a crash loses only a job that is still running: it is marked failed with "server restarted while running" at the
next start (`app/jobs.py`) and has to be repeated. Before a stop or restart, check that no job is running:
```bash
curl -fsS "http://127.0.0.1:${PORT:-8077}/api/jobs?limit=20" | python3 -c 'import json,sys; print([(j["kind"], j["status"]) for j in json.load(sys.stdin) if j["status"] in ("queued","running")])'
# expect: []   (otherwise wait, or warn the admins that they will have to repeat that job)
```

**Jobs of the error page (since 2026-11-11).** The long steps of the error page
(`/isolate?upload=<upload>&finding=<finding>`) run as jobs: **Isolate the defect**, the proposed optimized sequence,
the expected outcomes and the writing of the test file. The page sends the request with `?job=1`
(`POST /api/isolate/<upload>/<finding>/isolate?job=1`, `POST /api/isolate/<upload>/<finding>/testcase?job=1`,
`POST /api/dg/optimized?job=1`), gets a job id back at once, and asks `GET /api/isolate/jobs/<id>` about every 0.7 s
for the percentage, what is being done and, at the end, the answer. The job runs in a thread **inside the server
process** and lives only in its memory (`_JOBS` in `app/api/isolate_api.py`; the 40 newest are kept when a new one
starts). **A stop or restart loses every running job and its answer**; the page then shows "no such job (the server
may have restarted)", and the admin presses the same button again. The kept isolation (`dg_isolation`) and the test
file are written only at the end of a job. These jobs are not in `GET /api/jobs` and no route lists them, so before a
stop or restart, ask the admins whether an error page is working, and check that no page is following a job:
```bash
journalctl -u field-to-test-loop --since "2 min ago" --no-pager | grep -c 'GET /api/isolate/jobs/'
# expect: 0   (otherwise an error page is following a job: wait until it is done)
```
A job keeps running when its page is closed; that case does not show in the log. **Do not restart while a job is
running.**

Other logs, inside `$APP`:
- `runs/<run>/stage1_app.log` — the full output of every stage-1 step of that run (first place to look when a run fails).
- The **Activity log** of a run on the screens = table `job_event` in `db/app.sqlite` (`GET /api/jobs/<job>/events`).
- `db/stage2_log.jsonl` — one line per stage-2 decision result (audit trail).

## 2. Where the data lives and how big it grows

All runtime data is inside `$APP`; there is no setting to move it (`app/services.py`). To put it on another disk,
place `$APP` there (or ask the owner before using symbolic links).

| Path | Contents | Size seen on the development machine | Growth |
|---|---|---|---|
| `db/knowledge.sqlite` (+ `knowledge.sqlite-wal`, `knowledge.sqlite-shm`) | **the knowledge base** (write-ahead-log mode; the two side files belong to it): table `event` (every decision and lab result, never edited) and the tables computed from it | 1.4 MB for 1,144 events | about 1.2 KB per event on average; one decision with a lab job writes several events |
| `db/app.sqlite` | jobs and their activity lines (tables `job`, `job_event`), AI verdict cache (`verdict_cache`) | 2.5 MB for 190 jobs | per job and per activity line |
| `db/llm_cache.jsonl` | every stage-2 AI answer keyed by the exact question | 0.6 MB | per new question |
| `db/stage2_log.jsonl` | audit line per stage-2 result | 0.65 MB | per decision |
| `runs/<run>/` | one folder per analysed capture: stage-1 outputs, `stage2/<defect>.json`, report | 0.2–29 MB for synthetic captures | grows with the capture size; plan for large folders with multi-gigabyte captures |
| `runs/_bench/` | traces written by the **simulated** lab (one folder per error type) | **561 MB** | grows with every simulated lab run |
| `runs/bench_<error type>/` | work folders of a real bench hook (`app/bench_hook.py`) | — | depends on the hook |
| `suite/<test id>/` | the generated regression tests | 1.4 MB for 51 tests | about 27 KB per test |
| `samples/` | synthetic captures made through `POST /api/samples/generate` | 47 MB | only when someone makes samples |
| `config/app_config.json` | all settings (written by **Save** on the Settings page) | — | — |
| `db/hier_knowledge.sqlite` (+ `-wal`, `-shm` while open) | the isolation memory of the tree and error pages (`nvme_hier/store.py`: signatures, procedures, signals, chat) and, since 2026-11-11, the **procedural graph** (`dg_*` tables, below) | 1.7 MB (2026-11-11) | per isolated error and per judgement |
| `db/agentic.sqlite` | the flows: analyses (projects), runs, their steps, reviews and chat | 0.6 MB | per flow |
| `db/isolation_windows.json` | the window (commands above and below the error) last chosen for each kind of defect, with its history | 517 bytes | per new choice; **not in the backup archive** (section 3) |
| `knowledge/` | the admin's work for the flows: data dictionaries, joining strategies and rules, rules and their code, exports (the flow report `exports/flow/run_<run>/flow_report.html` and `.json`, which lists where each error stands) and, since 2026-11-11, `dictionary/term_requests.jsonl` (the notes "not the same kind of defect", section 11; the folder appears with the first note) | 1.5 MB | per approval and per flow |
| `suite/hier/` | the test files written on the error page, `<upload>_f<finding>_v<n>.py`, the replay library `f2t_nvme.py` they import, and for each approved file `<name>.py.approved.json` (section 8) | 6.1 MB | per test file written |
| `uploads/<upload>/` | each loaded recording: its tree (`hier.sqlite`) and `meta.json`; the error pages read it | 11 GB for the recordings loaded on the development machine | per recording (see "Large recordings"); **not in the backup archive** |
| `runs/agentic/` | every agent's working folder (one per run and agent: its prompt and answer) and `_deleted/analysis_<id>_<time>.json`, the copy of every analysis deleted from the start page (section 13) | — | per flow; per deleted analysis |
| `~/.config/f2t/env` of the user the server runs as (**outside `$APP`**; with the shipped unit `/opt/field-to-test-loop/.config/f2t/env`, because the unit sets `HOME=/opt/field-to-test-loop`; the variable `F2T_ENV_FILE` names another file) | the API key typed on the Settings page, one `NAME=value` line, mode 600 (`app/model_env.py` `ENV_FILE`, written by `PUT /api/hier/model`) | 176 bytes on the development machine | only when a key is saved on the page; **not in the backup archive**; in production it should not exist (section 6) |

The procedural graph, tables in `db/hier_knowledge.sqlite` (`nvme_hier/defect_graph.py`):

| Table | One row is | What to know |
|---|---|---|
| `dg_defect` | a defect | `key` = `term:<code key>`, the key made by code in `nvme_hier/terms.py` (section 11). A defect stored before 2026-11-11 without a term was keyed by its name in lower-case words; none is left in the development store |
| `dg_cause` | a cause under a defect | `key` = `kw:<keyword>`, one of the 20 fixed cause keywords; one row per keyword and defect |
| `dg_solution` | a solution under a cause | who made it (`producer`), the error it came from (`origin_upload`, `origin_finding`), `parent` when it was written from a "Wrong, with edits" |
| `dg_revision` | a version of a solution | `error_seq` (the steps that recreate the error; the test is written from them), `optimized` (the steps that solve it), `test_path` (its approved test file) |
| `dg_occurrence` | one error of one recording (unique per upload and finding) | the defect, the cause the admin named, `device`, `firmware`, `isolation`, `test_path`; when the same error is judged again, its row is updated (naming the defect again keeps the cause already chosen), and every change of its defect or cause is also written to `dg_occurrence_log` |
| `dg_verdict` | one judgement: Correct, Correct with edits, Wrong, Wrong with edits | rows are only added, never changed or deleted; the ranking of causes and solutions is computed from them |
| `dg_isolation` | the kept isolation of one error | key: upload, finding, card hash and version `card<CARD_VERSION>-dict<VERSION>-explain1-<model>` (section 11); the cause keyword decided by the rules is kept in it |
| `dg_occurrence_log` | one change of an error's defect or cause (new on 2026-11-11) | `occurrence_id`, `defect_id`, `cause_id`, `admin`, `at`; rows are only added (the code has only an `INSERT` for it, in `DefectGraph.record_occurrence`); the table is created by itself in an existing `db/hier_knowledge.sqlite` the first time the graph is opened (`CREATE TABLE IF NOT EXISTS` in `SCHEMA`) |

Check: `du -sh $APP/db $APP/runs $APP/runs/_bench $APP/suite $APP/samples $APP/knowledge $APP/uploads` and `df -h $APP`.

## 3. Routine backups

What to back up, in order of importance:
1. `db/knowledge.sqlite` with its side files — irreplaceable (the learned knowledge).
2. `db/hier_knowledge.sqlite` with its side files — irreplaceable (the procedural graph: every defect, cause,
   solution and judgement of the admins on the error pages, and the isolation memory).
3. `knowledge/` — the admin's approved dictionaries, strategies, rules and their code, and the dictionary notes.
4. `suite/` — the regression tests, including `suite/hier/` and its approval records.
5. `config/app_config.json` and, once it is implemented, `app/bench_hook.py` (your bench code).
6. `db/app.sqlite`, `db/agentic.sqlite`, `db/llm_cache.jsonl`, `db/stage2_log.jsonl` — run and flow history, caches,
   audit trail.
7. `runs/` — optional (large); without it old runs cannot be reopened, but the knowledge base is complete.

What `deploy/backup.sh` covers (read in the script on 2026-11-11): every `db/*.sqlite` (so `knowledge.sqlite`,
`hier_knowledge.sqlite`, `app.sqlite`, `agentic.sqlite`) through SQLite's online backup, every `db/*.jsonl`,
`suite/` (with `suite/hier/` and the `.approved.json` files), `config/`, `knowledge/`, `app/bench_hook.py`, and
`runs/` with `--with-runs`. **Not in the archive:**
- the key file the Settings page writes (`~/.config/f2t/env` of the service user, section 6): it lies outside `$APP`.
  Keep the key where your key management keeps it; in production it belongs in `/etc/field-to-test-loop/environment`.
- `uploads/` (the recordings and their trees; large). Keep the five CSV files of every recording that matters: without
  its folder under `uploads/`, the error page of that recording answers "no such upload".
- `db/isolation_windows.json` (only the `*.sqlite` and `*.jsonl` files of `db/` are copied). Without it the remembered
  windows are lost: an isolation asked without numbers then uses 15 commands above and 15 below
  (`_window_numbers` in `app/api/isolate_api.py`). It is written by replacing the whole file, so a plain copy is safe
  while the server runs:
  ```bash
  sudo -u ftl cp -p /opt/field-to-test-loop/current/db/isolation_windows.json /opt/field-to-test-loop/backups/isolation_windows-$(date +%F).json
  ```
- `samples/`.

**`deploy/restore.sh` puts `knowledge/` back** (since 2026-11-11: it restores `db/`, `suite/`, `config/`, `runs/`
and `knowledge/` when the archive has them, and `app/bench_hook.py`; `for d in db suite config runs knowledge` in the
script). The folder it replaces is moved into `pre-restore-<time>/knowledge`, not deleted. Its last lines name what
was restored, e.g. `restored: db suite config knowledge app/bench_hook.py into <folder>`. An archive without a
`knowledge/` folder (`tar -tzf <archive> | grep -c /knowledge/` shows 0) leaves the current `knowledge/` in place.
(Until 2026-11-11 `restore.sh` left `knowledge/` out and it had to be copied back by hand; that step is no longer
needed.)

Use `deploy/backup.sh` (and `deploy/restore.sh`) as described in `deploy/DEPLOY.md` section 9, on a schedule the
owner agrees (daily is a sensible default), to a different disk or machine. `backup.sh` uses the SQLite backup
function and is safe while the server runs. Never copy `knowledge.sqlite` alone with `cp`: the database runs in
write-ahead-log mode (`PRAGMA journal_mode=WAL`, `stage2/kgdb.py`), so recent committed decisions may still be
only in `knowledge.sqlite-wal`; a copy of the main file alone can miss them. If you must copy files by hand, stop
the service and copy the three files together (or the whole `db/` folder). For an ad-hoc copy while the server
runs, use the SQLite online backup:
```bash
sqlite3 $APP/db/knowledge.sqlite ".backup '/backup/knowledge-$(date +%F).sqlite'"
sqlite3 -readonly /backup/knowledge-$(date +%F).sqlite "PRAGMA integrity_check;"     # expect: ok
```

## 4. Monthly restore test

A backup is only proven by a restore. Once a month (and after each upgrade), while production keeps running:
1. Make a scratch copy of the release **without its data** (its own `db/`, so it is not a second server on the
   production `db/`), owned by the service user so it can read the backups. `knowledge/` is left out so that the
   copy gets the archive's one (step 2), and `uploads/` because the recordings are not in the backup and can be
   many gigabytes:
   ```bash
   sudo -u ftl mkdir -p /tmp/f2t-restore/13_production_app
   sudo -u ftl rsync -a --exclude=/db/ --exclude=/runs/ --exclude=/suite/ --exclude=/samples/ --exclude=/.venv/ \
        --exclude=/knowledge/ --exclude=/uploads/ --exclude='/knowledge.before-restore-*/' \
        --exclude='/pre-restore-*/' /opt/field-to-test-loop/current/ /tmp/f2t-restore/13_production_app/
   ```
2. Restore the latest backup into the copy. `deploy/restore.sh` allows this while the service runs, because the
   target is not the folder the service runs from:
   ```bash
   LATEST=$(sudo -u ftl sh -c 'ls -t /opt/field-to-test-loop/backups/ftl-backup-*.tar.gz | head -1'); echo "$LATEST"
   sudo -u ftl /opt/field-to-test-loop/current/deploy/restore.sh "$LATEST" \
        --app-dir /tmp/f2t-restore/13_production_app --python /opt/field-to-test-loop/current/.venv/bin/python
   ```
   Expect "the service 'field-to-test-loop' is active, but runs from another folder: restoring into the scratch
   copy ...", "knowledge.sqlite integrity=ok events=<n>", a line for `hier_knowledge.sqlite` (it has an `event`
   table too, so it also shows `events=<n>`) and "restored: db suite config knowledge ..." (`knowledge` is missing
   from that line when the archive has no `knowledge/`: write that into the operations log). A warning that the runs
   were recorded under `/opt/field-to-test-loop/current` is expected for a scratch copy (only the old run list
   lacks its summaries there). Options of the script: `deploy/restore.sh --help`. Check the restored `knowledge/`:
   ```bash
   sudo -u ftl ls /tmp/f2t-restore/13_production_app/knowledge     # expect the folders: dictionaries, strategies, rules, rules_code, exports, ...
   ```
3. If the restored `config/app_config.json` has `"bench": "hook"`, set it to `"synthetic"` in the copy: the copy
   must not drive the lab bench. Then start the copy with the **production virtual environment's Python**, the
   copy's own config, another port and no model calls:
   ```bash
   cd /tmp/f2t-restore/13_production_app && sudo -u ftl /opt/field-to-test-loop/current/.venv/bin/python run_app.py --config config/app_config.json --port 8099 --standin
   ```
4. In a second shell, compare with production:
   ```bash
   for p in ${PORT:-8077} 8099; do curl -fsS http://127.0.0.1:$p/api/db/summary | python3 -c 'import json,sys; print(json.load(sys.stdin)["knowledge"])'; done
   for p in ${PORT:-8077} 8099; do curl -fsS http://127.0.0.1:$p/api/dg/defects | python3 -c 'import json,sys; d=json.load(sys.stdin)["defects"]; print(len(d), "defects in the procedural graph,", sum(x["seen"] for x in d), "occurrences")'; done
   ```
   The counts of the restored copy must equal the counts in the archive's manifest (kept in the copy as
   `pre-restore-<time>/RESTORED_FROM_MANIFEST.txt`; production may have more
   events since the backup). The procedural graph is not counted in the manifest: the copy must show the defects of
   the backup's day, production the same or more. Open http://127.0.0.1:8099/db (through a secure shell tunnel on a
   remote server) and look at one error type's tree.
5. Stop the copy (Ctrl-C), delete the scratch folder (`sudo rm -rf /tmp/f2t-restore`), write the date and result into
   the operations log.

Checked on 2026-10-27 on a scratch installation (as an ordinary user, without systemd): `backup.sh` →
`restore.sh --app-dir <copy>` → copy started on another port → both showed the same counts (10 events, 2
procedures).

## 5. Upgrade

Follow `deploy/DEPLOY.md` (upgrade and rollback). The points that matter for this application:
1. Read the new version's change notes (`docs/CHANGES_*.md`).
2. Run a backup (section 3) and check no job is running (section 1: both the jobs list and the error-page jobs).
3. Stop the service.
4. Replace the code (`app/`, `stage1/`, `stage2/`, `nvme_hier/`, `agentic/`, `data/`, `tests/`, `docs/`, `deploy/`,
   `run_app.py`, `run_tests.sh`), **keeping** `db/`, `runs/`, `suite/`, `samples/`, `knowledge/`, `uploads/`,
   `config/app_config.json` and your `app/bench_hook.py` (replacing `app/` overwrites it — save it first and put it
   back). Compare the new `config/app_config.json` with yours and copy over any new keys. If the change notes say that
   `VERSION` in `nvme_hier/terms.py` or `CARD_VERSION` in `nvme_hier/evidence.py` changed, every kept isolation is
   computed again the next time its error is isolated, and new isolations may get other names or causes (expected:
   such a change is a release of its own, section 12).
5. Mail-safe zip: `python3 restore_names.py` (AGENT_INSTRUCTIONS step 2.1).
6. `python3 -m pip install -r deploy/requirements.txt`, `./run_tests.sh`, the two test files that `run_tests.sh`
   does not run (`python3 -m pytest -q -p no:cacheprovider tests/test_grounder_batches.py tests/test_stop_and_delete.py`,
   see `deploy/AGENT_INSTRUCTIONS.md` step 2.4), and the pre-flight check **as the service
   user with the service's environment file loaded** (run as plain `sudo -u ftl ...` the key variable is missing and
   the key check FAILs):
   ```bash
   sudo sh -c 'set -a; . /etc/field-to-test-loop/environment; set +a; cd /opt/field-to-test-loop/current && exec runuser -u ftl -- .venv/bin/python deploy/preflight.py --config config/app_config.json --check-llm'
   ```
   (`runuser -u` keeps the loaded variables; `sudo -u` would drop them.) Expect `0 FAIL`; in production
   `server.lock_endpoint` is PASS and `bench synthetic` stays a WARN until a real bench is connected.
   `preflight.py` does not read the Settings page's key file (section 6): it checks the key of its own environment.
7. Start; check the start line `Model connection: ...` in the journal (section 1) names the intended address, model
   and key source; press **Save and test the connection** in Settings (section 6); check `GET /api/db/summary` shows
   the same event count as before and `GET /api/dg/defects` the same defects (section 4, step 4); open one earlier run.
8. If anything is wrong: roll back per `deploy/DEPLOY.md` (old code + the backup taken in step 2).

## 6. The model connection: set it, test it, rotate the key, read its errors

Since 2026-11-11 every part that calls a model uses **one connection**: the flow's agents, stage 1's review, stage 2
and the error pages (`app/model_env.py`). It is three values:

| Value | Where it is kept | What to know |
|---|---|---|
| URL | `llm.base_url` in `config/app_config.json` | Empty = Anthropic (`https://api.anthropic.com`), otherwise your company's gateway. Saved from the page it is kept in one form (`model_env.normal_url`): `https://` is added when missing, a typed `/v1` or `/v1/messages` is removed, because every caller adds `/v1/messages` itself. A value typed into the file by hand is used as written (`make_llm` in `app/stage2_service.py`): give the base address only |
| Model name | `llm.model` | shipped `claude-haiku-5-5` |
| API key | **never in the configuration.** Typed on the page: the key file `~/.config/f2t/env` of the user the server runs as (mode 600; the variable `F2T_ENV_FILE` names another file), one line `<llm.api_key_env>=<key>`. Otherwise the environment (for the service: `/etc/field-to-test-loop/environment`, `deploy/DEPLOY.md` section 5) | the page shows only the key's last 4 characters and where it came from |

**At every start** (`run_app.py` calls `model_env.load` before the application is built):
1. A key in the key file, under the configured variable (`llm.api_key_env`, shipped `ANTHROPIC_API_KEY`) or under
   `ANTHROPIC_API_KEY`, **replaces the key the environment already holds**: a key saved on the page wins over the
   service's environment file. (Until 2026-11-11 a key already in the environment always won.)
2. The configured variable is copied into `ANTHROPIC_API_KEY`, which every caller reads, and the URL into
   `ANTHROPIC_BASE_URL` (`model_env.apply`). Only these two variables are taken from the key file: other lines are
   ignored, lines that are not `NAME=value` are skipped, and no value is ever printed.
3. One line goes to the log (the journal for the service, section 1):
   `Model connection: <URL, or "Anthropic (https://api.anthropic.com)">, model <model>, key <source> ending ...<last 4>  (change them in Settings -> Model connection)`.
   `<source>` is `saved on the Settings page`, `from this computer's environment (not set on the Settings page)` or
   `no key yet`; the last 4 characters are shown only for a key of at least 12 characters (`model_env.source`).

**Set it on the page.** The main page's top bar → **Settings** → "Model connection": **URL**, **Model name**, **API
key** (never shown back; its placeholder reads "a key is in use (ending …XXXX): <source>"), and the button **Save and
test the connection**. Saving sends `PUT /api/hier/model` (`app/api/hier_api.py` `model_put`): URL and model go into
`config/app_config.json`, the key into the key file (written whole or not at all, mode 600; an older line of the same
variable is replaced, other lines are kept), and all of it into the running process **at once, without a restart**:
stage 2 and the error pages switch (`reload_llm`), new stage-1 runs use it, and the agents follow
(`runner.http_model`, `runner.model`). Such a save also sets
`llm.backend` to `http` when it was empty, `auto`, `sdk` or `cli`. The **Save** button at the bottom of Settings saves
the same fields together with the agents' settings.

**Who calls where.**
- Stage 2 and the error pages: `llm.backend = "http"` (shipped) sends plain HTTPS to `<URL>/v1/messages` with the key
  (`stage2/llm_adapter.py` `_http`); `sdk` goes through the `anthropic` package.
- Stage 1's review: with `http` it goes through the `anthropic` package with the same key, URL and model; without that
  package installed it runs without a model (`app/stage1_runner.py` `llm_backend`). `deploy/requirements.txt` installs it.
- The agents ("The agents run on": Claude Code, Model connection or Stand-in; shipped `agentic.runtime =
  "claude-code"`). With the URL empty, Claude Code (`claude -p`) runs them, with the Settings key and URL in its
  environment and `CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1` (no update checks, error reports or telemetry).
  **With a URL of your own, Claude Code is not started**: the agents use the Model connection, so every call goes to
  that URL with the Settings key and model (`agentic/core.py` `custom_url`, `AgentRunner.ask`). When a call fails the
  next way answers (Claude Code, then the Model connection, then the stand-in) and every step says who answered.
- "A different model for the agents" (More settings, `agentic.model`, shipped empty) is passed to Claude Code only
  (`--model`); agents that run through the Model connection always use the Model name.
- "The agents may also search the web" (`agentic.web`, shipped `true`): with a URL of your own, a call the address
  refuses with an HTTP 4xx answer because of the web tools is made once more without them, and the step says so
  (`AgentRunner._http`). With the box ticked, the application itself also fetches every web page an agent quotes, to
  check the quote (`WebSources`); those fetches go to the quoted pages, not to your URL. Untick it to keep every
  connection on your URL.

**Test it.** **Save and test the connection** saves what changed (nothing, if nothing changed) and then sends
`POST /api/hier/model/test` (`model_test`): one real call through the model connection, with a one-time marker in the
question so that it never comes from the answer cache, and one through what runs the agents (a real Claude Code call,
limit 90 s, when Claude Code runs them and the URL is empty; otherwise one call through the agents' connection). The
page shows the address called (`<URL>/v1/messages`) and, for each, ✔ with who answered and the seconds, or ✘ with the
reason and "What it means". When the address does not answer, the test can take up to about 2 minutes. The test also
works with the lock on. Transient failures are retried 4 times with pauses of 2, 4 and 8 s; a wrong key is reported at
once (`_model_state`).

**What each error means** (`_hint` in `app/api/hier_api.py`; the first pattern that matches the error text decides):

| The error contains | What it means / what to do |
|---|---|
| `HTTP 402` | payment required: the account behind this key has no credit left or its budget is used up; add credit or ask for a key with budget |
| `HTTP 401` | the key was refused: check that it is the whole key, for this address |
| `HTTP 403` | this key may not use this model or this address |
| `HTTP 404` | not found: give the base address only (for example `https://gateway.company.com`, without `/v1`) and the model name as your service calls it |
| `HTTP 400` | the service did not accept the request: often the model name, or a feature this address does not offer |
| `HTTP 429` or "rate limit" | too many calls for this key at the moment: try again in a minute |
| `HTTP 5xx`, `HTTP 529` or "overloaded" | the service had a problem or is overloaded: try again later |
| "certificate" (`CERTIFICATE_VERIFY_FAILED`) | this computer does not trust the address's certificate (often a company network): the IT team can give the certificate to install |
| "refused", "timed out", "timeout", "getaddrinfo", "Name or service not known", "No route", "unreachable", "within N s" | the address cannot be reached from this computer: check the URL, the proxy or the firewall |
| "no key" | no key is saved: paste the key and press Save and test |

The agents' line can also read (`_test_agents`): "the agents run on the stand-in (no model): choose Claude Code or
Model connection above"; "Claude Code is not installed on this computer: the agents use the model connection
instead"; "Claude Code did not answer within 90 s: check the URL and the key above"; "Claude Code did not answer:
<its reason>" (for a model name that does not exist: "There's an issue with the selected model (…)"). The model
connection's line can read "no model is configured: no key is present" or "... the backend is the stand-in".

**The lock in production** (`server.lock_endpoint`: `false` in the shipped `config/app_config.json`, `true` in
`deploy/config.production.example.json`):
- On the Settings page the URL and API key fields are greyed out with "Locked (server.lock_endpoint is on): the URL
  and the key are changed in the configuration file and the key file, then the application is started again".
  `PUT /api/hier/model` with `base_url`, `api_key_env` or `key` is refused with HTTP 403 "the model endpoint and key
  are locked by server.lock_endpoint: stop the service, edit the config and the environment file, start it again".
  The model name can still be changed there (that save, too, turns `sdk` into `http`).
- On the older settings page (below) a **Save** that changes `llm.backend`, `llm.base_url`, `llm.api_key_env` or
  `llm.tools` is refused with HTTP 403 "<key> is locked by server.lock_endpoint: stop the service, edit the config
  file, start it again".
- The lock does **not** cover the agents' settings (`PUT /api/agents/settings`: where they run, their model, web
  search, the Claude Code program path, the reference folders): `deploy/DEPLOY.md` section 6.2.
- To change a locked value: check no job is running (section 1), `sudo systemctl stop field-to-test-loop`,
  `sudoedit -u ftl /opt/field-to-test-loop/current/config/app_config.json` (URL) or
  `sudoedit /etc/field-to-test-loop/environment` (key), `sudo systemctl start field-to-test-loop`.

**Production practice** (details: `deploy/DEPLOY.md` section 5.2): the key only in
`/etc/field-to-test-loop/environment`; `server.lock_endpoint: true`; **no key file of the service user**, because a key
saved on the page would win over the environment file at every later start. Check (prints no key):
```bash
sudo test -e /opt/field-to-test-loop/.config/f2t/env && echo "a key file written by the Settings page exists: it wins over /etc/field-to-test-loop/environment" || echo "no key file (good)"
journalctl -u field-to-test-loop -b --no-pager | grep 'Model connection:' | tail -1    # expect: key from this computer's environment (not set on the Settings page) ending ...<last 4>
```

**Rotating the key.**

With the lock on (production):
1. Put the new key into the environment file with `sudoedit /etc/field-to-test-loop/environment` (never into
   `config/app_config.json`, never on a command line).
2. Check no job is running (section 1), then `sudo systemctl restart field-to-test-loop` (a running process does not
   see a changed environment file).
3. Check the start line (section 1): `key from this computer's environment (not set on the Settings page) ending
   ...<the new key's last 4>`. If it reads `saved on the Settings page`, a key file exists and wins: see "Production
   practice" above.
4. Settings → **Save and test the connection**: both lines ✔. Or, as the service user with the environment file
   loaded (plain `sudo -u ftl ... preflight.py` has no key variable and its key check FAILs):
   ```bash
   sudo sh -c 'set -a; . /etc/field-to-test-loop/environment; set +a; cd /opt/field-to-test-loop/current && exec runuser -u ftl -- .venv/bin/python deploy/preflight.py --config config/app_config.json --check-llm'
   ```
   Expect the live AI model call PASS and `0 FAIL`. `preflight.py` tests the key of its own environment; it does not
   read the page's key file.
5. Revoke the old key at the provider only after step 4 passed. Cached answers do not depend on the key.

Without the lock (one user on a development machine):
1. Settings → API key: paste the new key → **Save and test the connection**. It is written to the key file and used
   by every part at once, without a restart.
2. Both lines ✔: revoke the old key.
A key saved on the page keeps winning at every start. To go back to the environment's key, remove the key's line from
the key file in an editor (do not print the file), then restart.

**Note for the development machine** (checked 2026-11-11 by listing only the variable names, never the values): its
`~/.config/f2t/env` holds, besides `ANTHROPIC_API_KEY`, three junk lines named `FUZZ_NO_SUCH_KEY`, `fuzz` and `null`,
written by an old test (since then `tests/fuzz_app.py` points the page's key file at its own temporary folder,
`hier_api.ENV_FILE`), and three short lines that are not `NAME=value`. The application reads only the configured
variable and `ANTHROPIC_API_KEY` and skips the rest; the owner can delete those lines.

**The older settings page** (sidebar "⚙ Settings" of the earlier packet workflow) changes "How the AI reviewer is
reached (backend)", "Model", "API base URL", "API key environment variable" and the limits, then **Save**. This sends
`PUT /api/config` (`app/api/config_api.py`): the values are written to `config/app_config.json` and
`Stage2Service.reload_llm` switches the AI reviewer **without a restart**; the message reads "saved · the AI reviewer
now in use: <name>". Check the name (`anthropic:<model>:<effort>` for `http`, `sdk` and `cli`,
`openai-compat:<model>`, or `stand-in` = the model is not reachable). New stage-1 runs pick the new settings up because
each run copies `llm` at its start.

**What needs the file or a restart:**
- `PUT /api/config` accepts only the sections `llm`, `stage1`, `stage2` and `paths`. `kpi.*` (the manual baselines
  of the Key results) and `server.*` can be changed **only in the file**, with the service stopped (a file edit
  while it runs is overwritten by the next **Save**).
- Read only at start (restart after changing them, even when saved on the page): `stage2.bench`, `paths.*`,
  `server.*`.
- The environment of the running process: a **new key variable name** works without restart only if that variable
  is already in the service environment; an `llm.base_url` once set through `PUT /api/config` stays in the process as
  `ANTHROPIC_BASE_URL` until restart (the Model connection page removes it when its URL is emptied); a newly
  installed package or `claude` command is seen after a restart. A key saved on the Model connection page is used at
  once.
- Settings not on the Settings page (`llm.workers`, `stage2.optimizer`; `llm.tools` when not locked) can be sent with
  `PUT /api/config`, or edited in the file with the service stopped.

Side effects of changing the model: the run cache and the stage-1 verdict cache are keyed by model, so the same
capture is analysed again and patterns are re-confirmed (more model calls and cost for a while). Stage-2 answers are
cached per model as well. The kept isolations of the error pages carry the model in their version
(`...-explain1-<model>`), so an error isolated again gets new words (why, how); its cause does not change (section 12).

## Large recordings (5 GB and more)

Files are read as streams and the work sits on disk, so memory does not grow with the size of the recording. Measured on this project's machine (4 cores, 22 GB of memory) with a synthetic
recording of 19.7 GB (31.7 million packets) and the memory held to 4 GB by a systemd limit: finished in 86 minutes (load 29, tree 42, rules 10, indexes 5). The finished database was 40 GB.
A 30 GB recording was not run on this machine: it needs more free disk than the machine had. The database and its scratch files took 2.2 times the size of the CSV files at their peak.

- Before a load starts: at least 4 times the size of the CSV files must be free on the disk, and enough memory to leave the other programs a tenth of the machine (at least 1 GB, at most 4 GB)
  plus 1 GB for the load, or the load is refused with the reason. Several loads at once do not count the same free space twice.
- During a load: when free memory falls below that share, or the other programs are waiting for memory, the load **pauses** and goes on when there is room again. After 9 minutes of waiting, or
  when free memory falls to half that share, or below 1 GB of disk, it stops by itself with the reason. **Load again** continues from the last finished file or stage. The same happens if a worker process is killed.
- One folder holds one recording: two files of the same kind are refused with their names. A CSV file of another kind beside the five is listed and does not stop the flow.

**Other programs on the machine.** The load runs at low priority, its workers are the first to go if the machine really runs out, and the file cache is left to the others. The service file sets
`MemoryHigh=60%`, `MemoryMax=80%`, `CPUWeight=50`, `OOMScoreAdjust=300`. Measured beside a 19.7 GB load, a test program's memory use and small tasks stayed near quiet-machine times and it never
stopped, but **its small file saves sometimes stalled, the worst for 20 seconds**, because both programs shared one disk. If the machine is shared, put the application's `uploads/` folder on its own
disk, or add a write limit to the service: `IOWriteBandwidthMax=/dev/sdX 100M` (a system service only; a limit on writing makes a load slower).

**Agents.** At most 4 model calls run at once. An agent can read only its own folder, and code written by an agent is held by the kernel (Linux Landlock) to the recording's files and its own output,
with no network. Where the kernel has no Landlock, only `open()` is checked; check `/sys/kernel/security/lsm` on the production machine. With the agents' web search on, an agent can still fetch any web
page, so what is in its own folder could reach a page it is told to fetch: turn web search off in Settings if recordings must not leave the machine.
- Page 2 of the flow shows the rules for combining the five files. The admin ticks each one; a change to the code of a rule asks for that rule again. A recording that breaks a rule on more
  than 5% of its rows (`agentic.join_break_limit_percent`) needs the admin's written reason.

## 7. Deleting old runs and freeing disk

- On "1 Choose the trace" → "Earlier runs (history)", press **Delete** on a run (or `DELETE /api/runs/<run id>`).
  It removes the run's stage-1 results, stage-2 state files, jobs and activity log (`app/api/runs_api.py`
  `delete_run`). **The knowledge base and the regression tests in `suite/` are kept.** A running run must be
  cancelled first ("the run is still in progress - cancel it first").
- Note: the Key results are computed over the runs that still exist (`GET /api/kpi` reads the job table), so deleting
  runs lowers the run counts there. Export the report first if the numbers are needed (`GET /api/runs/<run>/report?format=md`).
- `runs/_bench/` (simulated lab traces) is not removed by **Delete**. With the service stopped it can be emptied; the
  simulated bench regenerates traces on demand (first lab runs are slower afterwards). Do not delete
  `runs/bench_*` folders of a real bench without asking whoever wrote the hook.
- `samples/` can be emptied when nobody needs the synthetic captures (runs made from them can then not be re-analysed).

## 8. Exporting the regression suite to the company test system

Each folder `suite/<test id>/` (the id is `T-<error type>-<device>-<procedure id>`; it carries the device model when
one was known) holds three files (`stage2/testgen.py` `emit_closed_loop_test`):
- `test_<id>.py` — the test: runs the procedure on known-bad firmware (repeated so a defect with the measured rate
  is seen at least once with 95 % confidence) and checks that the same stage-1 analyser isolates the same error
  type; then checks that fixed firmware stays silent.
- `manifest.json` — what the test is: error type, procedure, timing, device preconditions, the lab check at
  generation (`closed_loop_at_generation`), and for composed or stress tests `composition` / `stress`.
- `conftest.py` — the bench fixtures `bench` and `bench_fixed`.

Rules for exporting:
1. Export only admitted tests: `manifest.json` → `closed_loop_at_generation.passed` must be `true` (a folder can be
   written for a procedure whose lab check failed; it is not admitted). List them:
   ```bash
   cd $APP && for d in suite/*/; do python3 -c "import json,sys; m=json.load(open('$d/manifest.json')); print(m['test_id'], (m.get('closed_loop_at_generation') or {}).get('passed'))"; done
   ```
   or `GET /api/suite`; single files: `GET /api/suite/<test id>/<file>?download=1`.
2. Run a test: `cd $APP/suite/<test id> && python3 -m pytest -q` (needs `pytest`). Inside `$APP` the fixtures find
   `stage2/` by themselves; in a copy elsewhere set `STAGE2_DIR=$APP/stage2` (the analyser and generator are then
   found relative to it).
3. **The fixtures need the bench.** The shipped `conftest.py` returns `GeneratorBench` — the **simulated** drive. In
   the company test system replace the two fixtures with your hardware bench (an object with `run(scenario)` and
   `detect(trace)`, the same interface as `app/bench_hook.py`; see `deploy/BENCH_INTEGRATION.md`). The manifest's
   preconditions name the device model; run the test only on that model.
4. A passing test on the simulated bench proves the pipeline, not the drive.

**Test files written on the error page (`suite/hier/`, since 2026-11-10; approval since 2026-11-11).** Each file is
`suite/hier/<upload>_f<finding>_v<n>.py`, written by `POST /api/isolate/<upload>/<finding>/testcase`. The files
written since 2026-11-10 import the replay library `f2t_nvme.py` from their own folder: copy it with them. The header of
each file says what it needs and how to run it. A file is **approved** when **Approve this test** on the error page
(`POST /api/isolate/<upload>/<finding>/testcase/approve`, the admin's name required, the file must be inside
`suite/hier/`) wrote `<name>.py.approved.json` beside it: `approved_by`, `at` (Unix time), `sha256` of the file,
`status` "approved", `comment`, `upload_id`, `finding`, `two_sided`. The same request records the file as the
`test_path` of the solution's version (`dg_revision`) and of the error (`dg_occurrence`). Export only approved files
that were not changed after the approval:
```bash
cd $APP/suite/hier && for a in *.py.approved.json; do [ -e "$a" ] || continue; python3 -c 'import json,hashlib,sys
a=json.load(open(sys.argv[1])); f=sys.argv[1][:-len(".approved.json")]; h=hashlib.sha256(open(f,"rb").read()).hexdigest()
print(f, "approved by", a["approved_by"], "| unchanged" if h == a["sha256"] else "| CHANGED after the approval: do not export")' "$a"; done
```

## 9. Monitoring signals

| Signal | How to read it | Healthy |
|---|---|---|
| Process up | `systemctl status field-to-test-loop`; `curl -fsS http://127.0.0.1:${PORT:-8077}/api/config` | active; HTTP 200 |
| AI reviewer reachable | `llm_active` in `GET /api/config` (sidebar badge) | the intended model, not `stand-in` |
| Model connection | `curl -fsS http://127.0.0.1:${PORT:-8077}/api/hier/model` → `base_url`, `model`, `key_present`, `key_source`, `key_end` (last 4 characters, never the key), `locked`, `active`; the start line `Model connection: ...` in the journal (section 1); Settings → **Save and test the connection** for a real call (section 6) | the intended address and model; in production `key_source` "from this computer's environment (not set on the Settings page)" and `locked` true |
| AI reviewer errors and cost | `GET /api/db/overview` → `llm_usage` (`errors`, `cost_usd`, tokens); stage-1 activity "(N answered, M errors)" | errors not growing; cost as expected |
| Failed jobs | `curl -fsS "http://127.0.0.1:${PORT:-8077}/api/jobs?limit=100"` → `status` / `error` | no unexplained `failed` |
| Leakage | `GET /api/kpi` → `quality.known_signature_leakage` ("slipped past their test (must be 0)") | 0 |
| Triage limit | `GET /api/kpi` → `efficiency.runs_within_triage_budget` vs `efficiency.runs`; results "first-level triage limit (10 min) exceeded" | rare |
| Two-person rule | `sqlite3 -readonly $APP/db/knowledge.sqlite "SELECT vhash FROM solution WHERE status='admin-approved' AND approved_by = producer;"` | empty |
| Database intact | `sqlite3 -readonly $APP/db/knowledge.sqlite "PRAGMA integrity_check;"` | `ok` |
| Procedural graph intact | `sqlite3 -readonly $APP/db/hier_knowledge.sqlite "PRAGMA integrity_check;"` | `ok` |
| Where the errors of a recording stand | `curl -fsS "http://127.0.0.1:${PORT:-8077}/api/dg/status?upload=<upload>&findings=<id>,<id>"` → `state` per error: `new`, `isolated`, `cause`, `solved`, `tested` (at most 500 ids per request) | as the admins expect; the flow report lists the same |
| Error-page jobs | the `journalctl ... grep -c 'GET /api/isolate/jobs/'` check of section 1 | 0 before a stop or restart |
| Notes on the dictionary | `wc -l $APP/knowledge/dictionary/term_requests.jsonl` (no file = no note yet) | each note read by the dictionary's keeper (section 11) |
| Disk | `df -h $APP`; `du -sh $APP/runs $APP/runs/_bench` | enough free space for the next captures |
| Server errors | `journalctl -u field-to-test-loop -p err` and Python tracebacks in the journal | none |
| Backups | the backup job's own log; last monthly restore test date | recent |

## 10. Incident response: the knowledge base looks wrong

Symptoms: a procedure is approved that nobody approved, ratings jumped, an error type has a cause it should not have,
tests from a test run appear in production.

1. **Ask the admins to pause decisions** for that error type (new events make the history harder to read). Do not stop
   the service unless the database is damaged (step 5).
2. **Find the event.** Knowledge base page (`/db`) → "Event log (most recent first)" shows id, time, kind, who and
   contents; or the "Earlier decisions on this error type" table on the defect page; or SQL:
   ```bash
   sqlite3 -readonly $APP/db/knowledge.sqlite "SELECT id, datetime(ts,'unixepoch','localtime'), kind, actor, substr(payload,1,200) FROM event WHERE payload LIKE '%\"sig\": \"T-42\"%' ORDER BY id DESC LIMIT 30;"
   ```
   (replace T-42 with the error type). Each event carries `meta` with run, defect, device, firmware and the operator
   name typed at the time.
3. **Undo it.** On the Knowledge base page type the id into "Undo event number" and press **Undo this event &
   rebuild** (confirm "Undo event N and rebuild the knowledge base from the event log?"). This sends
   `POST /api/db/undo`: the event is marked undone and every table is rebuilt from the remaining events
   (`stage2/kgdb.py` `undo`, `rebuild`). Undone events stay visible, marked. Undo the newest wrong event first when
   several belong together (one decision usually wrote several events). Undo cannot be reversed from the screens:
   note every id you undo.
4. **Check**: the rating / status on the error type's tree is back to its earlier value; the two-person SQL query is
   empty; for wrong tests, note that the folders in `suite/` are not removed by an undo — tell the owner which test
   ids are invalid before anyone exports them.

   **The procedural graph of the error pages has no Undo.** Its judgements are only added (`dg_verdict`), and no
   route deletes a defect, cause, solution or judgement; a wrong judgement stays counted in the ranking. Find it, and
   tell the owner:
   ```bash
   sqlite3 -readonly $APP/db/hier_knowledge.sqlite "SELECT v.id, datetime(v.at,'unixepoch','localtime'), v.admin, v.signal, v.solution_id, c.header, d.name, v.device FROM dg_verdict v JOIN dg_solution s ON s.id=v.solution_id JOIN dg_cause c ON c.id=s.cause_id JOIN dg_defect d ON d.id=c.defect_id ORDER BY v.id DESC LIMIT 20;"
   ```
   A test file approved by mistake is recognised by its `suite/hier/<name>.py.approved.json` (section 8). Who changed
   an error's defect or cause, and when (every change is kept in `dg_occurrence_log`, rows only added):
   ```bash
   sqlite3 -readonly $APP/db/hier_knowledge.sqlite "SELECT l.id, datetime(l.at,'unixepoch','localtime'), l.admin, o.upload_id, o.finding_id, d.key, c.key FROM dg_occurrence_log l JOIN dg_occurrence o ON o.id=l.occurrence_id JOIN dg_defect d ON d.id=l.defect_id LEFT JOIN dg_cause c ON c.id=l.cause_id ORDER BY l.id DESC LIMIT 20;"
   ```
5. **Last resort — restore from backup** (only if the file is damaged, `PRAGMA integrity_check` is not `ok`, or the
   wrong events are too many to undo one by one, and only with the owner's agreement):
   ```bash
   sudo systemctl stop field-to-test-loop
   sudo /opt/field-to-test-loop/current/deploy/restore.sh /opt/field-to-test-loop/backups/ftl-backup-<time>.tar.gz
   # restore.sh also puts knowledge/ back when the archive has it (section 3)
   sudo systemctl start field-to-test-loop
   curl -fsS http://127.0.0.1:${PORT:-8077}/api/db/summary | python3 -c 'import json,sys; print(json.load(sys.stdin)["knowledge"])'
   ```
   The restore replaces `db/hier_knowledge.sqlite` too: defects, causes, solutions and judgements made on the error
   pages after the backup are missing afterwards, like the decisions of the knowledge base.
   `restore.sh` moves the whole current `db/` folder — `knowledge.sqlite` **together with** `knowledge.sqlite-wal`
   and `knowledge.sqlite-shm` — into `pre-restore-<time>/` (nothing is deleted; it is the evidence and holds the
   events made since the backup). If you ever move it by hand, do it with the service stopped and move the three
   files together, or the whole `db/` folder (`cd /opt/field-to-test-loop/current && sudo -u ftl mv db db.damaged-$(date +%F)`): the `-wal` file can hold
   committed decisions that are not yet in the main file, and a main file moved without it loses them. Every
   decision made after the backup is missing from the restored knowledge base and must be entered again;
   `db/stage2_log.jsonl` and the moved-aside folder show what they were.
6. **Write it up**: what was wrong, which event ids were undone or which backup was restored, who was told.

## 11. The defect dictionary, the evidence card and the procedural graph (2026-11-11)

**Where the work happens.** In the flow, each chosen item of a section that finds defects (the errors section) ends
with a step that lists the errors its pattern found. After every pattern ran, one decision comes before the report:
"Stage 1 and stage 2 of the errors: on the errors page; then the report" (step `errors_done`, button **Done: write
the report**; `agentic/pipeline.py`). The work on each error is done on its own page, not in the flow: the errors
page (`/#/p/<project>/errors`) lists the errors, and each opens `/isolate?upload=<upload>&finding=<finding>` with six
parts: the error, the commands around it, the isolation of the defect, the procedural graph (its cause), the solution,
the test case. The flow report (`knowledge/exports/flow/run_<run>/flow_report.html` and `.json`) lists each error's
state from `GET /api/dg/status`. A flow planned before 2026-11-11 has no errors step: its result card still asks for
one error and runs stage 1 and stage 2 inline; the errors page shows its errors too.

**The dictionary (`nvme_hier/terms.py`, `VERSION = 3`).** The defect term is made by code from the recording, never
typed and never chosen by the model. Its key is built from codes only (`defect_term`: the rule, the command class and
opcode, what happened, the stage code or the NVMe status code), never from measured values or display words; the name
is the words people read. The graph stores the defect under `term:<key>`. The cause is one of **20 fixed keywords**
(`CAUSES`): 6 on the device, 3 each on the host, the driver and the link, 2 each on the interrupt path and PCIe, and
`unknown_cause`. `GET /api/dg/terms` lists them; a keyword outside the list is refused (HTTP 400 "not a keyword of
the dictionary"). The error page offers only these keywords; `POST /api/dg/causes` **without** a keyword (the path of
flows made before 2026-11-11) still stores a written side and header line under the key of its words
(`app/api/dg_api.py` `add_cause`, `DefectGraph.add_cause`). An admin who finds that an error is not the kind of defect its name says writes a note under "Not
the same kind of defect?" (`POST /api/dg/term_requests`); it is appended to `knowledge/dictionary/term_requests.jsonl`
(`at`, `admin`, `term_key`, `term_name`, `note` up to 2,000 characters, `upload_id`, `finding_id`). The name stays as
the code made it until the dictionary changes. Read the notes:
```bash
python3 -c 'import json,sys,time
for l in open(sys.argv[1]):
    r = json.loads(l); print(time.strftime("%Y-%m-%d %H:%M", time.localtime(r["at"])), r["admin"], "|", r["term_name"] or r["term_key"], "|", r["upload_id"], r["finding_id"], "|", r["note"])' $APP/knowledge/dictionary/term_requests.jsonl
```

**The evidence card and the cause (`nvme_hier/evidence.py`, `CARD_VERSION = 1`).** The card is computed by code from
the error's own command in the tree, never from the window shown. The cause keyword is decided from the card by fixed
rules in a fixed order (`decide_cause`, the first that applies); what, when, where, which and who are stated by code
(`facts`); the model only explains why and how. The isolation is kept per error in `dg_isolation`, keyed by the card's
hash and the version `card<CARD_VERSION>-dict<VERSION>-explain1-<model>`: the same error gives the same isolation
whatever the window and however often it is asked. **Write the words again** writes new why and how only.

**Changing the dictionary or the card** (a code change and a release of its own; why, and what to keep: section 12):
1. **Never change an issued key.** A change of meaning makes a new term. A stored defect is found only by its key
   (`dg_defect.key`), so a changed key leaves its history behind. Rules: `reports/Fixed defect and cause
   dictionary.md` (in the project folder that holds `13_production_app`).
2. Bump `VERSION` in `nvme_hier/terms.py` with every change of the dictionary, and `CARD_VERSION` in
   `nvme_hier/evidence.py` with every change of the card or of `decide_cause`. Kept isolations are keyed by both, so
   each is computed again the next time its error is isolated. A different model also writes new words (it is part
   of the key); the cause does not depend on the model.
3. The new code is loaded at the next start: restart only when no job is running (section 1).

**The migration of 2026-11-11.** When version 3 made the keys from codes only, the one defect then stored on the
development machine was moved to its code-based key. Check:
```bash
sqlite3 -readonly $APP/db/hier_knowledge.sqlite "SELECT id, key, name FROM dg_defect;"
# development machine: 1|term:cmd.timeout|io.read|aborted_by_the_host|nvme.sc.0.07|Read aborted by the host, status Command Abort Requested
sqlite3 -readonly $APP/db/hier_knowledge.sqlite "SELECT d.name, c.key, c.side, (SELECT COUNT(*) FROM dg_occurrence o WHERE o.cause_id=c.id) AS chosen FROM dg_cause c JOIN dg_defect d ON d.id=c.defect_id;"
sqlite3 -readonly $APP/db/hier_knowledge.sqlite "SELECT upload_id, finding_id, device, firmware, admin, test_path FROM dg_occurrence ORDER BY at DESC LIMIT 20;"
```

**Routes added on 2026-11-11.** Every change of the graph needs the admin's name (`admin`; `name` for the approval).

| Route | What it does |
|---|---|
| `GET /api/dg/defects?rule=<rule>` | the stored defects, those of this rule first, with how often seen and how many causes |
| `GET /api/dg/defects?term=<key>` | one defect by its term key, with causes and solutions ranked (`"defect": null` when not stored) |
| `GET /api/dg/defects/<id>` | one defect with its causes and their solutions, ranked |
| `POST /api/dg/defects` | store a defect (`name`, `term_key`, `rule`, `level`, `what`); an existing key gives the same id, `created: false` |
| `POST /api/dg/causes` | store a cause under a defect, with a `keyword` of the dictionary |
| `POST /api/dg/occurrences` | one error of a recording, with its defect, the cause the admin named, device, firmware and isolation |
| `POST /api/dg/solutions` | store a solution: `cause_id`, `error_seq`, `optimized` |
| `POST /api/dg/solutions/<id>/verdict` | one of `correct`, `correct_with_edits`, `wrong`, `wrong_with_edits` |
| `POST /api/dg/optimized` | the model proposes the optimized sequence; nothing is stored |
| `POST /api/dg/revisions/<id>/test` | record an approved test file (`path`, must exist) for one version of a solution |
| `GET /api/dg/status?upload=<upload>&findings=<ids>` | where each error of a recording stands |
| `GET /api/dg/terms` | the dictionary's version and the 20 cause keywords |
| `POST /api/dg/term_requests` | a note "not the same kind of defect" |
| `GET /api/isolate/<upload>/<finding>/children?level=<level>&rowid=<row>` | the rows directly under one row of the tree (`limit` 1 to 2,000, default 200; `offset`) |
| `POST /api/isolate/<upload>/<finding>/testcase/approve` | approve a test file in `suite/hier/` (section 8) |
| `GET /api/isolate/jobs/<id>` | a job's state, percentage, log and, when done, its answer (section 1) |

`?job=1` on `POST /api/isolate/<upload>/<finding>/isolate`, `.../testcase` and `POST /api/dg/optimized` turns the
request into a job (section 1).

## 12. How names and causes stay the same across admins and days

The admin at one time and the admin at another may be different people. So that the same kind of error always gets
the same name and the same cause, and lands on the same place in the procedural graph, both are made **by code from
the recording, never typed by an admin and never chosen by the model**.

**The name** (`nvme_hier/terms.py` `defect_term`, dictionary `VERSION = 3`). Its key is joined from codes found in
the trace: the rule that found the error | the command class and opcode (`level.<level>` for an error outside any
command) | what happened, from the detector's own word for it (`aborted_by_the_host`, `never_completed`,
`completed_late`, `slower_than_usual`, `error_status`; `completed_with_an_error_status` when only a status code shows
it) | the detector's stage code (`stage.fetched`,
`stage.data`, ...) or the official NVMe status code (`nvme.sc.<status code type>.<status code>`). Errors of other
rules end in `part.<part>`. Example: `cmd.timeout|io.read|aborted_by_the_host|nvme.sc.0.07` is named "Read aborted by
the host, status Command Abort Requested". A key never holds a measured value or display words, so it does not change
with the numbers of one recording. The key is the defect's identity in the procedural graph: `dg_defect.key` =
`term:<key>` (`nvme_hier/defect_graph.py`); storing a defect whose key exists returns the stored one, never a copy.
The name is the words people read; a stored defect keeps the words it was stored with.

**The cause** (`nvme_hier/evidence.py` `card` and `decide_cause`, `CARD_VERSION = 1`). Code computes the error's
evidence card from **its own command** in the tree (its NVMe transactions and the waits between them, the host's
Abort of it, its own packets' Nak and unacknowledged counts, the link events and other commands during its own
interval, its time against the host's limit and the usual time of its type), never from the window of n commands
above and m below that the page shows. The fixed rules then read the card in a fixed order, and the first that applies
decides one of the 20 keywords (`terms.CAUSES`):
1. the rule itself is a link event → `link_retraining_recovery`;
2. its own packets were refused (Nak) or left unacknowledged → `link_replay_storm`;
3. a link event happened while it was outstanding → `link_retraining_recovery`;
4. the host aborted it: sooner than its type usually takes (median) → `host_abort_by_tool_or_test`; later, but before
   the driver's limit → `host_timer_shorter_than_drive_latency`; after the limit → `host_reset_or_driver_recovery`;
5. it never completed → `firmware_stall`;
6. the completion entry came but no interrupt → `interrupt_lost`; the interrupt came but no head doorbell →
   `host_missed_completion`;
7. a media error status (status code type 2) → `media_retry_or_read_error`;
8. it took longer than its type's usual bar here, link clean → `device_internal_delay`;
9. otherwise → `unknown_cause`.
So the rules can choose 11 of the 20 keywords today. The other 9 (`driver_queue_configuration`,
`power_state_transition_latency`, `interrupt_delayed_by_coalescing`, `garbage_collection_pause`,
`thermal_throttling`, `controller_fatal_error`, `aspm_l1_exit_latency`, `flow_control_credit_starvation`,
`completion_timeout_or_error_completion`) are reached only when an admin chooses them.

**Kept per error.** The isolation (what, when, where, which and who stated by code; why and how written by the model;
the cause keyword) is kept in `dg_isolation` under the error, the card's hash and the version
`card<CARD_VERSION>-dict<VERSION>-explain1-<model>` (`app/api/isolate_api.py`). Asked again, with any window, the same
error gets the same isolation; the progress line says "this error was isolated before from the same evidence: the same
isolation is used (kept <time>)". **Write the words again** writes new why and how only.

**What the admin does.** "Use this cause" takes the rules' keyword; "Or, if you know better, another keyword of the
dictionary" takes another keyword **from the list only** (nothing is typed on the error page; the server refuses a
keyword outside the list). One error counts once (`dg_occurrence`, one row per upload and finding), and every change
of its defect or cause is kept with the admin's name and the time in `dg_occurrence_log` (section 10 has the query).
"Not the same kind of defect?" writes a note to `knowledge/dictionary/term_requests.jsonl` (section 11); the name
stays as the code made it.

**What the model does.** Only explanations (why and how), proposed optimized sequences (`POST /api/dg/optimized`,
nothing stored until the admin stores a solution) and, in the flow, the Data Grounder's column meanings, each with its
source (section 13). It never names a defect and never classifies it: the isolation's name comes from `defect_term`
and its cause from `decide_cause`. Another model writes other words; the name and the cause stay.

**Changing `terms.py` or `evidence.py` is a release.** Both are code. A change to their rules changes the names or
causes of **new** isolations. So:
1. Write it into the day's change log (`docs/CHANGES_<date>.md`) and ship it as a release (section 5).
2. Bump `VERSION` in `nvme_hier/terms.py` for every change of the dictionary and `CARD_VERSION` in
   `nvme_hier/evidence.py` for every change of the card or of `decide_cause`. Kept isolations are keyed by both: with an
   unchanged version, an error whose card did not change keeps getting its old isolation.
3. Never change an issued key; a change of meaning makes a new term, which is stored as a new defect. Rules:
   `reports/Fixed defect and cause dictionary.md` (in the project folder that holds `13_production_app`).
4. **Keep the old stored records.** No route deletes a defect, cause, solution or judgement, and the isolations kept
   under the old version stay in `dg_isolation`. Back up first (section 3); never edit `db/hier_knowledge.sqlite` by
   hand.
5. The new code is loaded at the next start: restart only when no job is running (section 1).

Which versions made the kept isolations:
```bash
sqlite3 -readonly $APP/db/hier_knowledge.sqlite "SELECT version, COUNT(*) FROM dg_isolation GROUP BY version;"
```

**Open items (say them to the owner as they are).**
- For an NVMe command that never completed, the card's time span ends at the last step the command reached, so the
  cause rules do not yet look at the stall after it, the host's Abort or a later reset; such an error gets
  `firmware_stall` (`reports/Stable isolation across windows.md`). A rules release is planned.
- A cause outside the 20 keywords can only be recorded as `unknown_cause` today: a new keyword needs a dictionary
  release. (`POST /api/dg/causes` without a keyword, the path of flows made before 2026-11-11, still stores a written
  side and header line; the error page never sends one.)
- The admins' judgements (Correct, Correct with my edits, Wrong, Wrong, keep my edits) only re-rank: they change the
  order in which causes and solutions are shown next time, never a name, a rule or a decided cause.

## 13. The flow's Data Grounder, Stop and Delete (2026-11-11)

**The Data Grounder** (`agentic/family1.py` `_ground`) gives every column that holds values a meaning, with its source,
after the Data Explorer has read the file.
- It asks in parts of **20 columns per call** (`GROUND_BATCH`), with up to 15 keywords per column (`GROUND_KEYWORDS`),
  and runs **up to 4 calls at once** (`AgentRunner.AT_ONCE = 4`, a limit shared by all agents of the server). A real
  export of 361 columns with values is 19 parts (361 / 20, rounded up).
- Each column goes with a summary of its contents that code computed from every row: what the Explorer observed, the
  rows with a value, the number of different values, its smallest and largest value and its **8 most common values with
  their counts** (`TOP_VALUES = 8`), plus reference-document passages found for it. The rows themselves are never sent.
- The progress line moves with every part that comes back and every 10 s while the model works: "N% · Data Grounder:
  meanings of <file>: n of N columns done (part k of P), m parts at the model now · <time> so far (documents, the web,
  then the names and contents)" ("the web" only when the agents may search it; "r parts retried without the web" is
  added once a retry ran).
- Two retries: columns left without a meaning are asked again **without the web**, from their names and contents; if
  more than one is still missing, again **in two smaller halves**. After that a column gets a reference document's own
  words when a passage was found for it; otherwise it stays **"no meaning found"** for the admin to fill in on the review
  card. Code never writes a meaning.
- Every meaning keeps its source, and the approved data dictionary stores it per column and keyword: the kind
  (document, web, data, admin or the model's knowledge), the page or file, and the quoted words. Document and web quotes
  are checked on the document or the fetched page; a "data" quote must be one of the column's own values.
- **Operational:** with no credit (HTTP 402), no key or no network, every call falls back to the stand-in, which gives
  no meaning, so every column without a reference-document passage ends "no meaning found"; the step says who answered.
  Press **Save and test the connection** (section 6) before a flow on a large export.
- Measured on 2026-11-11 (`docs/CHANGES_2026-11-11.md`): `tests/test_grounder_batches.py`, 361 columns against a stand-in
  model taking 1 s per call, finished in 5.9 s (about 19 s one part at a time); a real run with Claude Code and web
  search took 30 s for a 33-column file.

**Stop** (one click, no dialog; `POST /api/agents/runs/<run>/stop`, `agentic/core.py` `Engine.stop` and `_halt`):
- the run becomes "stopped by <admin>", its open reviews are closed ("the run was stopped"), and every step still
  working is set to "stopped": the run's own step and those working ahead of their turn;
- its model calls end (`AgentRunner.cancel`): its next calls are refused, and each Claude Code call, started in its own
  process group (`_run_cli`), is ended together with every program it started (`_end_tree`: the process group on Linux
  and macOS, `taskkill /F /T` on Windows); a result that still comes back is not written;
- afterwards the page offers **Run the flow again**: a new flow of the same analysis (it asks who starts it, and the
  data dictionaries and strategy approved before are offered for reuse). **Run it again** appears only in the banner of
  a failed step; it calls `POST /api/agents/runs/<run>/retry` (`Engine.retry`), which puts the run's failed and stopped
  steps back to waiting and goes on.

**Delete** on the start page asks once ("Delete “<name>”? Its runs and decisions go from the list.") and sends
`DELETE /api/agents/projects/<id>` (`app/api/agentic_api.py` `delete_project`): a run of it that is running, or has a
step working, is stopped first (as Stop, reason "deleted"); then a copy of the analysis with its runs, steps, reviews,
conversations and evidence is written to `runs/agentic/_deleted/analysis_<id>_<YYYYmmdd-HHMMSS>.json`, and the
analysis is removed from `db/agentic.sqlite`. Kept for the other analyses: the approved data dictionaries and
strategies, the rules library, the built trees, the failure memory, the test files and the agents' working folders.
No route brings a deleted analysis back; the JSON copy is its record. The start page has no "Create without starting"
any more.
