#!/usr/bin/env bash
# Every test of the application, one after the other; a failing suite does not stop the others; a table at the end.
#
#   bash run_tests.sh              unit suites, then (server on :8077) the API suites, then (Chrome) the browser suites
#   bash run_tests.sh --real       also the agent suites with real model calls (Claude Code + the model connection)
#   bash run_tests.sh --no-browser without the browser suites
#
# The admin's own state (databases, logs, knowledge/) is saved first and put back at the end (tests/protect_state.py):
# do not use the application while the suite runs.
cd "$(dirname "$0")"
REAL=0; BROWSER=1
for a in "$@"; do [ "$a" = "--real" ] && REAL=1; [ "$a" = "--no-browser" ] && BROWSER=0; done
LOG=runs/suite_logs; mkdir -p "$LOG"
declare -a NAMES RESULTS
run() {   # run <name> <what it checks> <command...>
  local name="$1" what="$2"; shift 2
  local t0=$(date +%s)
  echo; echo "===== $name: $what"
  timeout 3600 "$@" > "$LOG/$name.log" 2>&1; local rc=$?
  local line=$(grep -E "checks, [0-9]+ failed|checks passed|^[0-9]+ passed|passed in|^Ran [0-9]+ tests|^OK|FAILED" "$LOG/$name.log" | tail -2 | tr '\n' ' ')
  local dt=$(( $(date +%s) - t0 ))
  if [ $rc -eq 0 ]; then echo "PASS  $name  ($dt s)  $line"; RESULTS+=("PASS"); else echo "FAIL  $name  ($dt s)  exit $rc  $line   -> $LOG/$name.log"; tail -15 "$LOG/$name.log"; RESULTS+=("FAIL"); fi
  NAMES+=("$name|$what|${dt}s|$line")
}

SERVER=0; curl -sf -m 5 http://127.0.0.1:8077/api/hier/uploads >/dev/null 2>&1 && SERVER=1
CHROME=0; { command -v google-chrome || command -v chromium || command -v chromium-browser; } >/dev/null 2>&1 && python3 -c "import websocket" 2>/dev/null && CHROME=1
[ $SERVER -eq 1 ] && python3 tests/protect_state.py save

# ---- unit suites (no server needed)
run unit_app      "packet workflow end to end, stage 2 (tests_v3, tests_v4), stage 1 engine fixtures and analyzer cases" python3 -W ignore tests/test_app.py
run unit_hier     "five-level loader, builder vs ground truth, rules, store, optimiser, real headers, parallel load, test file imports" python3 tests/test_nvme_hier.py
run unit_web      "web evidence: quotes checked on the fetched page, only internet pages, web tools per model, off when the admin says so" python3 -m pytest -q -p no:cacheprovider tests/test_web_evidence.py
run unit_rules    "rule evidence: every rule's columns are read by its code, sections made by the admin" python3 -m pytest -q -p no:cacheprovider tests/test_rule_evidence.py
run unit_procs    "procedures: Code it checks and tries the code, the admin verifies it, Run takes only verified code" python3 -m pytest -q -p no:cacheprovider tests/test_procedures.py
run unit_editcode "edit and code together: Save and code it, coding of the old text replaced, no overwrite of a change made meanwhile" python3 -m pytest -q -p no:cacheprovider tests/test_edit_and_code.py
run unit_delete   "delete an item: leaves the list, kept for Restore, seeds stay deleted, not while a Run or flow step of it is going" python3 -m pytest -q -p no:cacheprovider tests/test_delete_items.py
run unit_graph    "the reinforcement loop on the procedural graph: the four signals change the weights, the weights decide the next output" python3 -m pytest -q -p no:cacheprovider tests/test_graph_loop.py
run unit_attack   "trying to break it: bad signals, hostile CSV files, broken clocks, exact limits, signals at the same moment" python3 -m pytest -q -p no:cacheprovider tests/test_adversarial.py
run fuzz_kpi      "random attacks with a known answer: 179 hostile recordings (faults, noise, broken files, reordered queues) and random signal histories on the graph" python3 tests/fuzz_kpi.py 179 5000
run fuzz_app      "attacks on the whole application: 200 random hostile requests, corrupted files, generated scripts, agent code and page text" python3 tests/fuzz_app.py 200 7000
run fuzz_params   "every route, every parameter its own code reads, one hostile value at a time, for five minutes" python3 tests/fuzz_params.py 300 1
run attack3       "twenty targeted attacks: files outside the app, corrupted saved data, runaway agent code, simultaneous presses, a full disk, binary files" python3 tests/attack_round3.py
run unit_progress "every long step shows a percentage: tree, rules, long silent statements, steps with no progress of their own" python3 -m pytest -q -p no:cacheprovider tests/test_progress.py
run unit_limits   "big files and hard limits: a torn record, a crash during a write, runaway agent code, a file with no line ends, a stray quote, out of memory or disk" python3 -m pytest -q -p no:cacheprovider tests/test_limits.py
run unit_agents   "the agents themselves: bad model answers, outages, many at once, memory among thousands, whole flows together, and what an agent and its code can reach" python3 -m pytest -q tests/test_agent_layer.py
run unit_joins    "the rules that combine the five files: each ticked by the admin and tied to its code, and eleven damaged recordings caught on the right rule" python3 -m pytest -q -p no:cacheprovider tests/test_join_rules.py
run fuzz_deep     "deep attacks: the whole flow played at random, the graph against an independent model, parsers, generated scripts, signatures, the usual-time rule" python3 tests/fuzz_deep.py 100 9000
run attack6       "a hundred and thirty-four different attacks: damaged recordings, things that are not files, machines that run out, killed processes, corrupted saved data, approvals that try to slip past the checks, many requests at once" python3 tests/attack_round6.py
run kpi_proof     "measured KPI evidence: injected faults against ground truth, a trivial baseline, known failures coming back, generated tests on a simulated drive" python3 tests/test_kpi_proof.py
run unit_cmdrules  "the two NVMe command rules: timeout (never completed, aborted by the host, the host's limit, slower than usual per type) and read failure" python3 -m pytest -q -p no:cacheprovider tests/test_command_rules.py
run unit_errors   "the errors page and one error page (2026-11-11): the fixed dictionary, the evidence card, the same isolation whatever the window, the procedural graph, progress jobs, test approval, the 5W1H summary" python3 -m pytest -q -p no:cacheprovider tests/test_defect_graph.py tests/test_isolation_window.py tests/test_summary_and_choice.py tests/test_optional_references.py tests/test_model_settings.py tests/test_grounder_batches.py tests/test_stop_and_delete.py

if [ $SERVER -eq 1 ]; then
  # ---- API suites against the running application
  run e2e_hier     "five files through the HTTP API: load, tree, summary, rules, limits, defects, signals, test case" python3 tests/test_hier_e2e.py --cleanup-store
  run isolate      "the isolation tab: window, stateful chat, memory, evidence loop, test case, summary" python3 tests/test_isolate.py --cleanup-store
  run agents       "the agent families one by one (stand-in): dictionaries, strategy, build, testers, rules, resume" python3 tests/test_agentic.py
  run flow         "THE FLOW twice (stand-in): Family 1 -> 2 -> 3, stage 1, the four signals, stage 2, test file, report, reuse" python3 tests/test_flow.py
  run packet_loop  "the earlier packet workflow on the running app: stage 1, stage 2, every admin signal, cache, undo" python3 tests/exercise_loop.py
  if [ $BROWSER -eq 1 ] && [ $CHROME -eq 1 ]; then
    # ---- browser suites (headless Chrome)
    run ui_packets "the /packets stage-2 decision view: ranking, signals, corrected version, test script" python3 tests/ui_smoke.py
    run ui_tree    "the tree pages /hier: upload, tree, summary, defects, limits, signals" python3 tests/ui_smoke_hier.py
    run ui_pages   "the flow pages: home, top bar, settings, history, rules library, search, add an item" python3 tests/ui_smoke_agents.py
    run ui_flow    "a whole flow clicked through the four pages (light and dark screenshots)" python3 tests/ui_smoke_flow.py
  else
    echo; echo "browser suites skipped: $( [ $BROWSER -eq 0 ] && echo '--no-browser' || echo 'no Chrome or no websocket-client module')"
  fi
  if [ $REAL -eq 1 ]; then
    # ---- real model calls (cost money: Claude Code with ~/.claude/settings.json, the model connection for stage 1 and 2)
    run agent_folder "a real agent cannot read a file outside its own folder" env F2T_REAL=1 F2T_MODEL=claude-haiku-5-5 python3 -m pytest -q -k real_agent tests/test_agent_layer.py
    run agents_real "the agent families with real Claude Code and model-connection calls" python3 tests/test_agentic.py --real
    run flow_real   "THE FLOW twice with real Claude Code agents and the model connection" python3 tests/test_flow.py --real
  fi
  python3 tests/protect_state.py restore
else
  echo; echo "API and browser suites skipped: the application does not answer on http://127.0.0.1:8077 (start it first)"
fi

echo; echo "================ summary"
fail=0
for i in "${!NAMES[@]}"; do IFS='|' read -r n w d l <<< "${NAMES[$i]}"; printf "%-5s %-12s %6s  %s\n        %s\n" "${RESULTS[$i]}" "$n" "$d" "$w" "$l"; [ "${RESULTS[$i]}" = "FAIL" ] && fail=1; done
exit $fail
