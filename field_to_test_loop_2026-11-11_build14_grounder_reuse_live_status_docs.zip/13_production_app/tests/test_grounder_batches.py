"""The Data Grounder on a real-size export (owner, 2026-11-11: "Data Grounder has stuck ... meanings of columns 1 to 120 of 361 ... 0%").

A file of 361 columns, each with keywords, against a stand-in model server that takes a second per call: the Grounder asks in parts of
20 columns, several parts at once (never more than the runner's AT_ONCE), finishes every column, and its progress line moves while
the model works. No real model is called; the stand-in server answers the columns it is given."""
import json
import os
import shutil
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

N_COLUMNS = 361


class _Model:
    """Answers each Grounder call with a meaning for every column it was given, after a pause; records how many calls ran at once."""

    def __init__(self, pause=1.0, mode="all"):
        self.calls, self.now, self.most, self.retries, self.retry_tools, self.contents_seen, self.cols_seen = 0, 0, 0, 0, 0, 0, 0
        lock = threading.Lock()
        me = self

        class H(BaseHTTPRequestHandler):
            def do_POST(self):
                n = int(self.headers.get("content-length") or 0)
                body = json.loads(self.rfile.read(n) or b"{}")
                with lock:
                    me.calls += 1
                    me.now += 1
                    me.most = max(me.most, me.now)
                try:
                    time.sleep(pause)
                    prompt = body["messages"][0]["content"]
                    retry = "THE WEB COULD NOT BE USED" in prompt
                    with lock:
                        me.retries += retry
                        me.retry_tools += bool(retry and body.get("tools"))
                        me.contents_seen += '"most_common"' in prompt
                    if mode in ("fail", "402"):             # the address refuses every call (400, or 402: no credit on the account)
                        data = b'{"type": "error", "error": {"type": "invalid_request_error", "message": "refused"}}'
                        self.send_response(402 if mode == "402" else 400)
                        self.send_header("content-type", "application/json")
                        self.send_header("content-length", str(len(data)))
                        self.end_headers()
                        self.wfile.write(data)
                        return
                    cols = json.loads(prompt.split("CONTEXT:\n", 1)[1])["columns"]
                    with lock:
                        me.cols_seen += len(cols)
                    if mode == "half" and not retry:        # the first try answers only every second column
                        cols = cols[::2]
                    ans = {"columns": [{"column": c["column"], "meaning": "what %s holds" % c["column"],
                                        "source": {"kind": "model", "ref": "model knowledge", "quote": ""},
                                        "keywords": [{"keyword": k, "meaning": "the value %s" % k, "source": {"kind": "model", "ref": "model knowledge", "quote": ""}}
                                                     for k in c.get("keywords") or []]} for c in cols]}
                    data = json.dumps({"id": "m", "type": "message", "role": "assistant", "model": body.get("model"),
                                       "content": [{"type": "text", "text": json.dumps(ans)}], "stop_reason": "end_turn",
                                       "usage": {"input_tokens": 1, "output_tokens": 1}}).encode()
                    self.send_response(200)
                    self.send_header("content-type", "application/json")
                    self.send_header("content-length", str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                finally:
                    with lock:
                        me.now -= 1

            def log_message(self, *a):
                pass

        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = "http://127.0.0.1:%d" % self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()


class _Ctx:
    def __init__(self, runner, mem_file):
        self.engine = type("E", (), {"runner": runner})()
        self.project = {"refs": "[]"}
        self.run = {"id": 1}
        self.notes, self._mem = [], mem_file

    def output_of(self, key):
        return {"memory_file": self._mem}

    def progress(self, text):
        self.notes.append((time.time(), text))

    def evidence(self, claims):
        pass


def test_the_grounder_finishes_a_361_column_export_in_small_parts_at_once_and_its_progress_moves():
    from agentic import core, family1
    root = tempfile.mkdtemp(prefix="grounder_%d_" % os.getpid())
    was = {k: os.environ.get(k) for k in ("ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", "ANTHROPIC_AUTH_TOKEN")}
    model = _Model(pause=1.0)
    try:
        os.environ.update(ANTHROPIC_API_KEY="sk-test-grounder-0000", ANTHROPIC_BASE_URL=model.url)
        os.environ.pop("ANTHROPIC_AUTH_TOKEN", None)
        cols = [{"column": "Field %03d" % i, "header_cell": "Field %03d" % i, "type": "text", "rows_with_value": 50,
                 "keywords": [{"value": "K%d_%d" % (i, j), "count": 5} for j in range(25)]} for i in range(N_COLUMNS)]
        mem = os.path.join(root, "explorer.json")
        json.dump({"columns": cols}, open(mem, "w"))
        runner = core.AgentRunner(os.path.join(root, "runs"), runtime="http", http_model="company-model-1", web=False)
        ctx = _Ctx(runner, mem)
        t0 = time.time()
        res = family1._ground(ctx, {"name": "packets.csv", "level_label": "packets"})
        took = time.time() - t0
        out = json.load(open(res.output["memory_file"]))
        parts = -(-N_COLUMNS // family1.GROUND_BATCH)
        assert model.calls == parts                                                  # 19 parts of at most 20 columns
        assert 1 < model.most <= core.AgentRunner.AT_ONCE                             # several at once, never more than the limit
        assert len(out["columns"]) == N_COLUMNS and all(m["meaning"] for m in out["columns"].values())
        assert all(len(m["keywords"]) == family1.GROUND_KEYWORDS for m in out["columns"].values())   # at most 15 keywords asked per column
        assert took < parts * 1.0                                                     # faster than one part after the other
        texts = [t for _w, t in ctx.notes]
        assert texts[0].startswith("0% · Data Grounder") and texts[-1].startswith("100% · Data Grounder")
        assert len({t.split(" · ")[0] for t in texts}) >= 3                           # the percentage moved on the way
        assert "%d of %d columns done" % (N_COLUMNS, N_COLUMNS) in texts[-1]
    finally:
        model.srv.shutdown()
        for k, v in was.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        shutil.rmtree(root, ignore_errors=True)


def _cols(n):
    return [{"column": "Field %03d" % i, "header_cell": "Field %03d" % i, "type": "text", "rows_with_value": 50, "observed": "holds a code",
             "top_values": [{"value": "V%d_%d" % (i, j), "count": 10 - j} for j in range(6)], "min": "V%d_0" % i, "max": "V%d_5" % i,
             "keywords": [{"value": "K%d_%d" % (i, j), "count": 5} for j in range(5)]} for i in range(n)]


def _run(mode, n=45, pause=0.2, dictionary=None, expect_error=False):
    from agentic import core, family1
    root = tempfile.mkdtemp(prefix="grounder_%s_%d_" % (mode, os.getpid()))
    was = {k: os.environ.get(k) for k in ("ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", "ANTHROPIC_AUTH_TOKEN")}
    was_kd = family1.knowledge_dir
    family1.knowledge_dir = lambda: os.path.join(root, "knowledge")          # its own knowledge folder: approved dictionaries of this test only
    if dictionary:
        d = os.path.join(root, "knowledge", "dictionaries", "fmt1")
        os.makedirs(d)
        json.dump(dictionary, open(os.path.join(d, "packets.current.json"), "w"))
    model = _Model(pause=pause, mode=mode)
    try:
        os.environ.update(ANTHROPIC_API_KEY="sk-test-grounder-0000", ANTHROPIC_BASE_URL=model.url)
        os.environ.pop("ANTHROPIC_AUTH_TOKEN", None)
        mem = os.path.join(root, "explorer.json")
        json.dump({"columns": _cols(n)}, open(mem, "w"))
        runner = core.AgentRunner(os.path.join(root, "runs"), runtime="http", http_model="company-model-1", web=True)
        ctx = _Ctx(runner, mem)
        if expect_error:
            t0 = time.time()
            try:
                family1._ground(ctx, {"name": "packets.csv", "level": "packets", "level_label": "packets"})
            except RuntimeError as e:
                return model, str(e), time.time() - t0, ctx
            raise AssertionError("the step did not stop")
        res = family1._ground(ctx, {"name": "packets.csv", "level": "packets", "level_label": "packets"})
        return model, res, json.load(open(res.output["memory_file"])), ctx
    finally:
        family1.knowledge_dir = was_kd
        model.srv.shutdown()
        for k, v in was.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        shutil.rmtree(root, ignore_errors=True)


def test_columns_left_without_a_meaning_are_asked_again_without_the_web_from_their_name_and_contents():
    """Owner, 2026-11-11: "add a retry if the Data Grounder fails, and if the web cannot give it, use the column names and contents"."""
    model, res, out, ctx = _run("half")
    assert model.contents_seen >= 1                                       # the contents went with the columns
    assert model.retries >= 1 and model.retry_tools == 0                  # retried, and the retry did not use the web
    assert len(out["columns"]) == 45 and all(m["meaning"] and not m["meaning"].startswith("Described from") for m in out["columns"].values())
    assert "retry without the web" in res.producer
    assert any("retried without the web" in t for _w, t in ctx.notes)


def test_when_the_model_gives_nothing_no_meaning_is_written_by_code():
    """Owner, 2026-11-11: "it should not be written": after the three tries, a column without a source keeps no meaning (the admin
    fills it in the review); nothing is made up by code."""
    from agentic import family1
    model, res, out, ctx = _run("fail", n=12)
    assert model.retries >= 2                                             # retried without the web, then in halves
    assert len(out["columns"]) == 0                                       # no meaning was written for any column
    assert family1._status(None) == "no meaning found"
    assert "12 columns without a meaning after 3 tries" in res.producer
    assert res.output["meanings"] == {}


def test_a_meaning_from_the_web_keeps_its_page_and_words():
    """Owner, 2026-11-11: "if it is taken from the web, mention that it is from the web and store the meaning ... save from which
    place it came": the stored meaning keeps kind web, the page and the quoted words, and says so in words."""
    from agentic import family1
    m = {"meaning": "the transaction's sequence number", "checked": True,
         "source": {"kind": "web", "ref": "https://example.org/pcie/dllp", "quote": "a 12-bit sequence number"}}
    assert family1._status(m) == "from a web page (checked)"
    m["checked"] = False
    assert family1._status(m) == "web quote not found on the page: not trusted"


def test_columns_already_in_an_approved_dictionary_are_taken_from_it_and_only_the_others_are_asked():
    """Owner, 2026-11-11: "if it already has the column names, just use the description of the column, else go for finding"."""
    from agentic import family1
    known = {"level": "packets", "file": "packets.csv", "approved_by": "Sagar", "approved_at": 1794390000,
             "columns": [{"column": "Field %03d" % i, "meaning": "approved meaning %d" % i, "source": {"kind": "document", "ref": "manual.pdf:12", "quote": "q"},
                          "keywords": [{"value": "K%d_0" % i, "meaning": "approved keyword", "source": {"kind": "model", "ref": "model knowledge", "quote": ""}}]}
                         for i in range(5)] + [{"column": "Field 011", "meaning": "", "source": {}}]}       # an empty meaning is not reused
    model, res, out, ctx = _run("all", n=12, dictionary=known)
    assert model.cols_seen == 7                                            # only the 7 columns without an approved meaning were asked
    assert len(out["columns"]) == 12
    first = out["columns"]["Field 000"]
    assert first["meaning"] == "approved meaning 0" and first["source"]["ref"] == "manual.pdf:12" and first["keywords"]["K0_0"]["meaning"] == "approved keyword"
    assert family1._status(first).startswith("from the approved dictionary of packets.csv (approved by Sagar, ")
    assert "5 meanings reused from the approved dictionary" in res.producer
    assert any("5 taken from the approved dictionary" in t for _w, t in ctx.notes)


def test_a_refused_connection_stops_the_step_at_once_with_the_reason():
    """No credit (HTTP 402): the Grounder stops asking at once (no retries for every part) and the step fails with the reason in words."""
    model, err, took, ctx = _run("402", n=45, expect_error=True)
    assert "no credit" in err and "Settings -> Model connection" in err
    assert model.retries == 0 and model.calls <= 3                         # the three first tries at most: no retries after a refusal
    assert took < 20
    assert any("last problem: part" in t and "no credit" in t for _w, t in ctx.notes)


def test_the_status_says_which_part_waits_how_long_and_why():
    from agentic import family1
    was = family1.GROUND_SLOW_AFTER
    family1.GROUND_SLOW_AFTER = 0.5
    try:
        model, res, out, ctx = _run("all", n=20, pause=12.5)               # one part, and the model takes 12.5 s
    finally:
        family1.GROUND_SLOW_AFTER = was
    texts = [t for _w, t in ctx.notes]
    slow = [t for t in texts if "has waited" in t]
    assert slow and "part 1 has waited" in slow[0] and "first try" in slow[0] and "a call gives up after" in slow[0], texts
    assert all(" · Data Grounder · packets.csv: " in t for t in texts)
