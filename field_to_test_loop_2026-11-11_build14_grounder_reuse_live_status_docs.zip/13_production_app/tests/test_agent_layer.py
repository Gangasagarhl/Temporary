"""The agents themselves (owner, 2026-11-10: many agents, many model calls, memories, "those all things ... it has to work").

A stand-in model service on this machine, which misbehaves on request, sits behind the same code the agents use. Nothing leaves the machine and no real model is called.

    python3 -m pytest -q tests/test_agent_layer.py

    1. bad answers    text, a missing field, a list, nothing, a cut-off answer, nesting too deep: the step goes on and says who answered and why
    2. outages        refused key, rate limit, overloaded, a hanging service, no service: bounded in time, retried only when retrying can help
    3. at once        many agents together: each gets its own answer, in its own folder, and no more run at once than the limit
    4. memory         the right memory comes back, in the right tier, among thousands; it survives a restart; signals at the same moment are all counted
    5. flows at once  several whole flows at the same time finish with their own results
"""
import http.server
import json
import os
import random
import resource
import shutil
import socketserver
import sys
import tempfile
import threading
import time

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path[:0] = [HERE, APP, os.path.join(APP, "app")]
from agentic import core  # noqa: E402
from nvme_hier import isolate as ISO  # noqa: E402
from nvme_hier import store as ST  # noqa: E402


def ok(text, stop="end_turn"):
    return 200, json.dumps({"content": [{"type": "text", "text": text}], "stop_reason": stop, "usage": {"input_tokens": 10, "output_tokens": 5}}).encode(), 0


class Service:
    """Answers one behaviour per call from `script`, then `after`. A behaviour is (status, body, seconds to wait) or a function of the prompt that gives one."""

    def __init__(self):
        self.script, self.after, self.calls, self.lock = [], ok('{"answer": "from the model"}'), 0, threading.Lock()
        self.active = self.peak = 0
        svc = self

        class H(http.server.BaseHTTPRequestHandler):
            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers["content-length"])))
                prompt = body["messages"][0]["content"]
                with svc.lock:
                    svc.calls += 1
                    svc.active += 1
                    svc.peak = max(svc.peak, svc.active)
                    what = svc.script.pop(0) if svc.script else svc.after
                done = False
                try:
                    status, data, wait, *extra = what(prompt) if callable(what) else what
                    time.sleep(wait)
                    with svc.lock:                  # finished before the answer goes out: the client's next call may start once it has it
                        svc.active -= 1
                    done = True
                    self.send_response(status)
                    self.send_header("content-length", str(len(data)))
                    for k, v in (extra[0] if extra else {}).items():
                        self.send_header(k, v)
                    self.end_headers()
                    self.wfile.write(data)
                except (BrokenPipeError, ConnectionResetError):
                    pass
                finally:
                    if not done:
                        with svc.lock:
                            svc.active -= 1

            def log_message(self, *_a):
                pass

        class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
            daemon_threads = True
        self.server = Server(("127.0.0.1", 0), H)
        self.url = "http://127.0.0.1:%d" % self.server.server_address[1]
        threading.Thread(target=self.server.serve_forever, daemon=True).start()


@pytest.fixture
def service(monkeypatch):
    s = Service()
    monkeypatch.setenv("ANTHROPIC_API_KEY", "not-a-real-key")
    monkeypatch.setenv("ANTHROPIC_BASE_URL", s.url)
    monkeypatch.delenv("ANTHROPIC_AUTH_TOKEN", raising=False)
    yield s
    s.server.shutdown()


def runner(tmp_path, timeout=5):
    return core.AgentRunner(str(tmp_path), runtime="http", http_model="test-model", timeout=timeout, web=False)


def ask(r, agent="a", run=1, context="ctx"):
    return r.ask(run, agent, "Do it.", context, '{"answer": "..."}', "answer", lambda: {"answer": "canned"})


# ---- 1. bad answers
def test_a_good_answer_is_used_and_named(service, tmp_path):
    ans, who, box = ask(runner(tmp_path))
    assert ans["answer"] == "from the model" and "test-model" in who and "stand-in" not in who
    saved = json.load(open(os.path.join(box, "answer.json")))
    assert saved["meta"]["runtime"] == "http" and saved["answer"] == ans


def test_an_answer_in_a_code_fence_is_read(service, tmp_path):
    service.script = [ok('Here it is:\n```json\n{"answer": "fenced"}\n```\nDone.')]
    assert ask(runner(tmp_path))[0]["answer"] == "fenced"


@pytest.mark.parametrize("what,reply", [
    ("plain text", ok("I cannot help with that.")),
    ("the field is missing", ok('{"other": 1}')),
    ("a list of numbers", ok('[1, 2, 3]')),
    ("no content", (200, json.dumps({"content": [], "stop_reason": "end_turn"}).encode(), 0)),
    ("cut off half way", ok('{"answer": "this stops in the mid', "max_tokens")),
    ("nesting too deep", ok('{"answer": ' + "[" * 200000 + "]" * 200000 + "}")),
    ("not JSON at all", (200, b"<html>gateway</html>", 0)),
    ("a body that is not an object", (200, b"[1,2,3]", 0)),
    ("content of the wrong type", (200, json.dumps({"content": "words"}).encode(), 0)),
])
def test_a_bad_answer_never_stops_the_step_and_is_explained(service, tmp_path, what, reply):
    service.after = reply
    ans, who, _ = ask(runner(tmp_path))
    assert ans == {"answer": "canned"}, what
    assert "stand-in" in who and "http failed" in who, (what, who)


# ---- 2. outages
def test_a_refused_key_is_not_retried(service, tmp_path):
    service.after = (401, b'{"error": "invalid key"}', 0)
    ans, who, _ = ask(runner(tmp_path))
    assert service.calls == 1 and ans == {"answer": "canned"} and "401" in who


def test_a_rate_limit_is_waited_out(service, tmp_path):
    service.script = [(429, b"{}", 0)]
    ans, who, _ = ask(runner(tmp_path))
    assert service.calls == 2 and ans["answer"] == "from the model" and "stand-in" not in who


def test_the_wait_the_service_asks_for_is_kept(service, tmp_path):
    service.script = [(429, b"{}", 0, {"retry-after": "3"})]
    t0 = time.time()
    ans, _who, _ = ask(runner(tmp_path))
    assert ans["answer"] == "from the model" and 3 <= time.time() - t0 < 6


def test_an_object_inside_a_list_is_read_as_the_answer(service, tmp_path):
    service.script = [ok('[{"answer": "inside"}]')]
    assert ask(runner(tmp_path))[0]["answer"] == "inside"


def test_an_outage_ends_soon_and_does_not_wait_after_the_last_try(service, tmp_path):
    service.after = (529, b"{}", 0)
    t0 = time.time()
    ans, who, _ = ask(runner(tmp_path))
    took = time.time() - t0
    assert service.calls == 4 and ans == {"answer": "canned"} and "529" in who
    assert took < 18, "2 + 4 + 8 s of waiting between four tries, not %.1f s" % took


def test_a_hanging_service_is_given_up_on(service, tmp_path):
    service.after = (200, b"{}", 30)
    t0 = time.time()
    ans, _who, _ = ask(runner(tmp_path, timeout=1))
    assert ans == {"answer": "canned"} and time.time() - t0 < 25


def test_no_service_at_all(monkeypatch, tmp_path):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "not-a-real-key")
    monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://127.0.0.1:9")
    t0 = time.time()
    ans, who, _ = ask(runner(tmp_path))
    assert ans == {"answer": "canned"} and "connection" in who and time.time() - t0 < 18


def test_without_a_key_it_says_so_at_once(monkeypatch, tmp_path):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.delenv("ANTHROPIC_AUTH_TOKEN", raising=False)
    t0 = time.time()
    ans, who, _ = ask(runner(tmp_path))
    assert ans == {"answer": "canned"} and "no API key" in who and time.time() - t0 < 1


# ---- 3. many agents at once
def _echo(prompt):
    name = prompt.split("CONTEXT:", 1)[1].strip()
    return ok(json.dumps({"answer": name}))[0], ok(json.dumps({"answer": name}))[1], 0.05


def test_agents_at_once_each_get_their_own_answer(service, tmp_path):
    service.after = _echo
    r = runner(tmp_path, timeout=30)
    results, errors = {}, []

    def one(i):
        try:
            ans, _who, box = ask(r, agent="agent_%d" % i, run=i % 5, context="ask-%d" % i)
            results[i] = (ans["answer"], json.load(open(os.path.join(box, "answer.json")))["answer"]["answer"])
        except Exception as e:      # noqa: BLE001
            errors.append(repr(e))
    ts = [threading.Thread(target=one, args=(i,)) for i in range(60)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    assert not errors and len(results) == 60
    assert all(a == "ask-%d" % i and b == a for i, (a, b) in results.items())


def test_no_more_agents_run_at_once_than_the_limit(service, tmp_path):
    service.after = lambda p: (ok('{"answer": "x"}')[0], ok('{"answer": "x"}')[1], 0.2)
    r = runner(tmp_path, timeout=30)
    limit = core.AgentRunner.AT_ONCE
    ts = [threading.Thread(target=ask, args=(r, "a%d" % i, i)) for i in range(limit * 4)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    assert service.calls == limit * 4 and 1 < service.peak <= limit


# ---- 4. memory
def sig(fine, coarse, err="cmd.timeout", cmd="io.Write", lvl="nvme_command"):
    return {"fine": fine, "coarse": coarse, "display": fine, "fields": {"lvl": lvl, "err": err, "cmd": cmd, "cause": "self", "alg": "v1"}}


@pytest.fixture
def store(tmp_path):
    return ST.Store(str(tmp_path / "k.sqlite"))


def test_the_tiers_come_back_in_order_and_nothing_else(store):
    me, sibling, cousin, other = sig("f1", "c1"), sig("f2", "c1"), sig("f3", "c2", cmd="io.Read"), sig("f4", "c3", err="cmd.read_failure")
    for s, dev in ((me, "D1"), (sibling, "D2"), (cousin, "D3"), (other, "D4")):
        store.touch_signature(s, dev, upload_id="u", finding_id=1)
    got = store.retrieve(me, "D1")
    assert [(f["tier"], f["fine"]) for f in got] == [(1, "f1"), (2, "f2"), (3, "f3")]


def test_a_rare_memory_is_found_among_thousands(store):
    target = sig("rare", "rare-family", err="cmd.read_failure", cmd="io.Read")
    store.touch_signature(target, "D0", upload_id="u", finding_id=1)
    for i in range(1500):
        s = sig("n%d" % i, "cn%d" % i)
        for _ in range(2):
            store.touch_signature(s, "D1", upload_id="u", finding_id=i)
    me = sig("new", "new-family", err="cmd.read_failure", cmd="io.Write")
    got = store.retrieve(me, "D9")
    assert any(f["fine"] == "rare" and f["tier"] == 3 for f in got), [f["fine"] for f in got][:5]


def test_memory_stays_quick_and_the_answer_stays_small_as_it_grows(store):
    for i in range(3000):
        store.touch_signature(sig("g%d" % i, "same-family"), "D1", upload_id="u", finding_id=i)
    t0 = time.time()
    got = store.retrieve(sig("g1", "same-family"), "D1")
    assert len(got) <= 12 and time.time() - t0 < 2.0
    assert sum(len(f["text"]) for f in got) < 40000


def test_the_prompt_keeps_only_the_last_turns_of_a_long_conversation():
    history = [{"role": "admin", "text": "turn %d " % i + "x" * 4000, "data": None, "at": i} for i in range(3000)]
    lines = ISO.history_lines(history)
    assert len("\n".join(lines)) < 4100 * (ISO.HISTORY_TURNS + 2)
    assert "turn 2999" in "\n".join(lines) and "turn 0 " not in "\n".join(lines)


def test_memory_survives_a_restart(tmp_path):
    path = str(tmp_path / "k.sqlite")
    a = ST.Store(path)
    s = sig("f1", "c1")
    a.touch_signature(s, "D1", upload_id="u", finding_id=1)
    pid = a.add_procedure("f1", [{"step": 1, "command": "Read", "position": "fault"}], "text", "by")
    a.signal("f1", pid, "correct", "sim")
    a.add_lesson("f1", "a lesson", "by")
    b = ST.Store(path)
    got = b.retrieve(s, "D1")[0]
    assert got["best"]["id"] == pid and got["lessons"] == ["a lesson"] and got["best"]["counts"]["correct"] == 1


def test_signals_at_the_same_moment_are_all_counted(store):
    store.touch_signature(sig("f1", "c1"), "D1", upload_id="u", finding_id=1)
    pid = store.add_procedure("f1", [{"step": 1, "command": "Read", "position": "fault"}], "text", "by")
    errors = []

    def many(_):
        for _i in range(20):
            try:
                store.signal("f1", pid, "correct", "sim")
            except Exception as e:      # noqa: BLE001
                errors.append(repr(e))
    ts = [threading.Thread(target=many, args=(i,)) for i in range(8)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    assert not errors, errors[:2]
    assert store.retrieve(sig("f1", "c1"), "D1")[0]["best"]["counts"]["correct"] == 160


def test_a_conversation_belongs_to_its_recording_and_its_defect(store):
    store.chat_append("u1", 1, "f", "admin", "about one", None)
    store.chat_append("u1", 2, "f", "admin", "about two", None)
    store.chat_append("u2", 1, "f", "admin", "other recording", None)
    assert [r["text"] for r in store.chat_history("u1", 1)] == ["about one"]


# ---- 5. whole flows at the same time
class Yes:
    """Every choice the flow asks for, answered the plain way."""
    def random(self):
        return 0.0

    def choice(self, seq):
        return seq[0]

    def sample(self, seq, k):
        return list(seq)[:k]

    def randint(self, _a, b):
        return b


def _drive(c, FD, name, folder, out):
    p = c.post("/api/agents/projects", json={"admin": "t", "name": name, "folder": folder}).get_json()
    rid = c.post("/api/agents/projects/%d/flow" % p["id"], json={"admin": "t"}).get_json()["run"]
    t0 = time.time()
    while time.time() - t0 < 900:
        v = c.get("/api/agents/runs/%d" % rid).get_json()
        if v["run"]["state"] != "running":
            out[name] = (rid, v["run"]["state"], [s["key"] for s in v["steps"] if s["state"] == "failed"])
            return
        failed = [s for s in v["steps"] if s["state"] == "failed"]
        if failed:
            out[name] = (rid, "failed", [(s["key"], (s.get("error") or "")[:200]) for s in failed])
            return
        rv = next((q for q in v["reviews"] if q["state"] == "open"), None)
        if rv is None:
            time.sleep(0.3)
            continue
        st = next(s for s in v["steps"] if s["id"] == rv["step"])
        r = c.post("/api/agents/reviews/%d/decide" % rv["id"], json={"decision": "approve", "admin": "t", "edits": FD.edits_for(st["key"], rv.get("data") or {}, Yes())})
        if r.status_code >= 500:
            out[name] = (rid, "500", r.get_data()[:300])
            return
    out[name] = (rid, "no end in 900 s", [])


def test_several_whole_flows_at_the_same_time():
    import fuzz_app as F
    import fuzz_deep as FD
    root = tempfile.mkdtemp(prefix="agent_layer_%d_" % os.getpid())
    kick = core.Engine.kick
    try:
        app, _c, _k, _r = F.setup(root)
        core.Engine.kick = F.REAL_KICK or kick           # an earlier F.setup in this process may have switched the start off
        before = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        out = {}
        ts = [threading.Thread(target=_drive, args=(app.test_client(), FD, "flow %d" % i, F.BASE, out)) for i in range(3)]
        t0 = time.time()
        [t.start() for t in ts]
        [t.join() for t in ts]
        print("three flows at once: %.0f s, memory grew by %d MB" % (time.time() - t0, (resource.getrusage(resource.RUSAGE_SELF).ru_maxrss - before) // 1024))
        assert len(out) == 3 and all(v[1] == "finished" for v in out.values()), out
        assert len({v[0] for v in out.values()}) == 3
    finally:
        core.Engine.kick = kick
        shutil.rmtree(root, ignore_errors=True)


_unused = random


# ---- 6. the agent's folder is the limit of what it can read (found 2026-11-10: a bare "Read" permission let an agent open a file outside it)
def test_the_agent_is_only_allowed_to_read_its_own_folder(tmp_path, monkeypatch):
    seen = {}

    class Done:
        returncode, stdout, stderr = 0, json.dumps({"result": '{"answer": "ok"}'}), ""

    def run(cmd, **kw):
        seen["cmd"], seen["cwd"] = cmd, kw.get("cwd")
        return Done()
    monkeypatch.setattr(core.AgentRunner, "_run_cli", lambda self, cmd, prompt, cwd, timeout, env, _f=run: _f(cmd, input=prompt, cwd=cwd, timeout=timeout, env=env))   # Claude Code is started through _run_cli (Stop can end it)
    monkeypatch.setattr(core.AgentRunner, "find_claude", staticmethod(lambda _c=None: "/bin/true"))
    # Anthropic's own address: an address of one's own sends the agents through the Model connection instead of Claude Code (2026-11-11),
    # and an earlier test in this process may have left its stand-in address set
    monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
    r = core.AgentRunner(str(tmp_path), runtime="claude-code", web=False)
    ans, _who, box = r.ask(1, "a", "Do it.", "ctx", '{"answer": "..."}', "answer", lambda: {"answer": "canned"})
    allowed = seen["cmd"][seen["cmd"].index("--allowedTools") + 1].split(",")
    assert ans["answer"] == "ok" and seen["cwd"] == box
    assert sorted(allowed) == ["Glob(./**)", "Grep(./**)", "Read(./**)"]


@pytest.mark.skipif(not os.environ.get("F2T_REAL"), reason="makes a real model call: set F2T_REAL=1")
def test_a_real_agent_cannot_read_a_file_outside_its_folder(tmp_path):
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "note.txt").write_text("MARKER-7741\n")
    r = core.AgentRunner(str(tmp_path / "boxes"), runtime="claude-code", model=os.environ.get("F2T_MODEL") or None, timeout=120, web=False)
    ans, who, _ = r.ask(1, "a", "Use the Read tool on the file named in CONTEXT and copy its first line into 'answer'. If you cannot read it, put CANNOT_READ in 'answer'.",
                        str(outside / "note.txt"), '{"answer": "..."}', "answer", lambda: {"answer": "standin"}, runtime="claude-code")
    assert "Claude Code" in who and "MARKER-7741" not in json.dumps(ans)


# ---- 7. code written by an agent stays inside what it was given (found 2026-11-10: it could open any file the service can read)
def _run_agent_code(tmp_path, body):
    from agentic import procedures as PR
    box = tmp_path / "box"
    box.mkdir()
    source = tmp_path / "data.csv"
    source.write_text("a,b\\n1,2\\n")
    code = box / "item.py"
    code.write_text(body)
    return PR.run_code(str(code), {"data.csv": str(source)}, str(box / "out.csv"), str(box), timeout=30)


def test_agent_code_reads_the_recording_and_writes_its_output(tmp_path):
    body = "def run(sources, out_csv):\n    t = open(sources['data.csv']).read()\n    with open(out_csv, 'w') as f:\n        f.write(t)\n    return {'n': len(t)}\n"
    r = _run_agent_code(tmp_path, body)
    assert r["ok"], r


def test_agent_code_cannot_open_a_file_outside(tmp_path):
    (tmp_path / "secret.txt").write_text("MARKER")
    body = "def run(sources, out_csv):\n    return {'t': open(%r).read()}\n" % str(tmp_path / "secret.txt")
    r = _run_agent_code(tmp_path, body)
    assert not r["ok"] and "MARKER" not in json.dumps(r), r


def test_agent_code_cannot_reach_a_file_through_a_chain_of_modules(tmp_path):
    (tmp_path / "secret.txt").write_text("MARKER")
    body = ("import csv\ndef run(sources, out_csv):\n    m = csv.sys.modules['posix']\n    fd = m.open(%r, 0)\n    return {'t': m.read(fd, 20).decode()}\n" % str(tmp_path / "secret.txt"))
    r = _run_agent_code(tmp_path, body)
    assert not r["ok"] and "MARKER" not in json.dumps(r), r


def test_agent_code_cannot_use_the_network(tmp_path):
    body = ("import csv\ndef run(sources, out_csv):\n    i = csv.sys.modules['importlib'].import_module('socket')\n    s = i.socket()\n    s.settimeout(3)\n    s.connect(('1.1.1.1', 80))\n    return {'t': 'connected'}\n")
    r = _run_agent_code(tmp_path, body)
    assert not r["ok"] and "connected" not in json.dumps(r), r


def test_a_module_of_the_application_cannot_be_imported():
    from agentic import procedures as PR
    probs = PR.check_code("from nvme_hier import loader\ndef run(sources, out_csv):\n    return loader.os.getcwd()\n")
    assert any("other than names" in p for p in probs), probs


# ---- 8. an analysis can be deleted (owner, 2026-11-10: the list had no Delete); what other analyses use stays
def test_an_analysis_is_deleted_with_its_runs_and_a_copy_is_kept():
    import fuzz_app as F
    root = tempfile.mkdtemp(prefix="agent_layer_del_%d_" % os.getpid())
    try:
        app, c, _k, _r = F.setup(root)
        from api import agentic_api as A
        keep_pid = c.post("/api/agents/projects", json={"admin": "t", "name": "keep me", "folder": F.BASE}).get_json()["id"]
        pid = c.post("/api/agents/projects", json={"admin": "t", "name": "delete me", "folder": F.BASE}).get_json()["id"]
        rid = c.post("/api/agents/projects/%d/flow" % pid, json={"admin": "t"}).get_json()["run"]
        with app.app_context():
            eng = A.engine()
        eng.store.exec("UPDATE step SET state='running' WHERE run=? AND idx=0", (rid,))
        # (owner, 2026-11-11: "delete is not working") a step still working no longer refuses Delete: the analysis is stopped, then deleted
        r = c.delete("/api/agents/projects/%d" % pid, json={"admin": "t"})
        j = r.get_json()
        assert r.status_code == 200 and j["runs"] == 1 and os.path.exists(j["copy"])
        kept = json.load(open(j["copy"]))
        assert kept["project"]["name"] == "delete me" and kept["runs"][0]["id"] == rid and kept["steps"]
        assert c.get("/api/agents/projects/%d" % pid).status_code == 404
        assert eng.store.one("SELECT COUNT(*) AS n FROM step WHERE run=?", (rid,))["n"] == 0
        assert c.get("/api/agents/projects/%d" % keep_pid).status_code == 200
        assert c.delete("/api/agents/projects/%d" % pid).status_code == 404
    finally:
        shutil.rmtree(root, ignore_errors=True)


# ---- 9. files are read ahead while the admin reviews (owner, 2026-11-10: "why not simultaneous if there is space, just wait for approval")
def test_other_files_are_read_while_the_first_waits_for_the_admin_and_nothing_runs_twice():
    import fuzz_app as F
    root = tempfile.mkdtemp(prefix="agent_layer_ahead_%d_" % os.getpid())
    kick = core.Engine.kick
    try:
        app, c, _k, _r = F.setup(root)
        core.Engine.kick = F.REAL_KICK or kick           # an earlier F.setup in this process may have switched the start off
        pid = c.post("/api/agents/projects", json={"admin": "t", "name": "ahead", "folder": F.BASE}).get_json()["id"]
        rid = c.post("/api/agents/projects/%d/flow" % pid, json={"admin": "t"}).get_json()["run"]
        t0, v = time.time(), None
        while time.time() - t0 < 300:
            v = c.get("/api/agents/runs/%d" % rid).get_json()
            open_ = [q for q in v["reviews"] if q["state"] == "open"]
            reads = [s for s in v["steps"] if s["key"].startswith(("explore:", "ground:"))]
            if open_ and all(s["state"] in ("done", "skipped") for s in reads):
                break
            time.sleep(0.5)
        first_review = next(q for q in v["reviews"] if q["state"] == "open")
        assert next(s for s in v["steps"] if s["id"] == first_review["step"])["key"].startswith("manager:")
        reads = [s for s in v["steps"] if s["key"].startswith(("explore:", "ground:"))]
        assert reads and all(s["state"] in ("done", "skipped") for s in reads), [(s["key"], s["state"]) for s in reads]
        assert all((s.get("attempts") or 0) <= 1 for s in v["steps"]), [(s["key"], s.get("attempts")) for s in v["steps"] if (s.get("attempts") or 0) > 1]
        managers = [s for s in v["steps"] if s["key"].startswith("manager:")]
        assert sum(1 for s in managers if s["state"] == "needs_review") == 1    # the decisions still come one at a time
    finally:
        core.Engine.kick = kick
        shutil.rmtree(root, ignore_errors=True)


# ---- 10. page 2's rules can be changed, tried on the recording and discussed with an agent that queries the data (owner, 2026-11-10)
def test_join_rule_settings_try_ask_and_note():
    import fuzz_app as F
    from nvme_hier import loader as L
    root = tempfile.mkdtemp(prefix="agent_layer_jw_%d_" % os.getpid())
    try:
        app, c, _k, _r = F.setup(root)
        from api import agentic_api as A, hier_api as H
        pid = c.post("/api/agents/projects", json={"admin": "t", "name": "rules", "folder": F.BASE}).get_json()["id"]
        v = c.get("/api/agents/projects/%d/join_rules" % pid).get_json()
        assert v["settings"]["look_links"] == 256 and v["tree"]["upload_id"] == "up-fuzz" and v["tree"]["own"] is False    # a tree built before from the same files
        assert "at most 256 rows ahead" in v["joins"][0]["steps"][1]
        bad = c.put("/api/agents/projects/%d/join_rules/settings" % pid, json={"settings": {"look_links": 10 ** 9}})
        assert bad.status_code == 400 and "from 1 to 65,536" in bad.get_json()["error"]
        v = c.put("/api/agents/projects/%d/join_rules/settings" % pid, json={"settings": {"look_links": 4096}, "admin": "t"}).get_json()
        assert v["settings"]["look_links"] == 4096 and "4,096 rows ahead" in v["joins"][0]["steps"][1]
        # a loaded recording for this analysis
        with app.app_context():
            eng = A.engine()
        uid = "up-jw"
        d = os.path.join(H.uploads_dir(app.config["services"]), uid)
        os.makedirs(d)
        files = {k: os.path.join(F.BASE, n) for k, n in F.NAMES.items()}
        L.load_upload(os.path.join(d, "hier.sqlite"), files)
        H.write_meta(d, {"upload_id": uid, "status": "loaded", "files": files, "thresholds": {}})
        eng.store.exec("UPDATE project SET upload_id=? WHERE id=?", (uid, pid))
        r = c.post("/api/agents/projects/%d/join_rules/try" % pid, json={"settings": {"look_cmds": 1024}, "admin": "t"}).get_json()
        t0 = time.time()
        while time.time() - t0 < 120:
            v = c.get("/api/agents/projects/%d/join_rules" % pid).get_json()
            if v["try_job"] and v["try_job"]["status"] in ("done", "failed"):
                break
            time.sleep(0.5)
        assert v["try_job"]["status"] == "done", v["try_job"]
        assert v["tree"]["built_with"]["look_links"] == 4096 and v["tree"]["built_with"]["look_cmds"] == 1024
        last = v["tries"][-1]
        assert set(last["after"]) >= {"packets_to_links", "ntx_to_cmds"} and last["settings"]["look_cmds"] == 1024
        # the agent asks for a query, then answers from its result; a write is refused
        calls = []

        def fake_ask(run_id, agent, instruction, context, shape, must_have, standin, **kw):
            calls.append(json.loads(context))
            if len(calls) == 1:
                return {"answer": "", "queries": ["SELECT COUNT(*) AS n FROM lnk", "DELETE FROM lnk"]}, "test model", None
            return {"answer": "There are %s link rows." % calls[-1]["query_results"][0]["rows"][0][0], "queries": [], "proposed_settings": {"look_links": 512, "look_cmds": 7}}, "test model", None
        real = eng.runner.ask
        eng.runner.ask = fake_ask
        try:
            chat = c.post("/api/agents/projects/%d/join_rules/packets_to_links/ask" % pid, json={"message": "how many link rows?", "admin": "t"}).get_json()["chat"]
        finally:
            eng.runner.ask = real
        ans = chat[-1]
        assert ans["who"] == "agent" and "link rows" in ans["text"] and ans["queries"][0]["rows"][0][0] > 0
        assert "error" in ans["queries"][1] and "only one SELECT" in ans["queries"][1]["error"]
        assert ans["proposed_settings"] == {"look_links": 512}          # only this rule's own setting is kept
        v = c.put("/api/agents/projects/%d/join_rules/links_to_splits/note" % pid, json={"text": "completions can arrive on another RequesterID", "admin": "t"}).get_json()
        assert v["notes"]["links_to_splits"]["text"].startswith("completions")
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_rules_words_are_edited_saved_as_versions_and_can_go_back():
    import fuzz_app as F
    root = tempfile.mkdtemp(prefix="agent_layer_jwt_%d_" % os.getpid())
    try:
        app, c, _k, _r = F.setup(root)
        pid = c.post("/api/agents/projects", json={"admin": "t", "name": "words", "folder": F.BASE}).get_json()["id"]
        url = "/api/agents/projects/%d/join_rules/packets_to_links/text" % pid
        assert c.put(url, json={"steps": "not a list"}).status_code == 400
        v = c.put(url, json={"steps": ["IF a TLP matches Link Dir and PSN THEN it opens the row, searching until the PSN repeats", ""], "check": "packets equal Metrics.# Packets",
                             "when_broken": ["counted"], "why": "the analyzer can drop rows", "admin": "t"}).get_json()
        t = v["texts"]["packets_to_links"]
        assert t["v"] == 1 and t["steps"] == ["IF a TLP matches Link Dir and PSN THEN it opens the row, searching until the PSN repeats"] and t["by"] == "t"
        assert v["joins"][0]["steps"][1].startswith("IF a packet has a TLP Type")      # the program's own version is untouched
        same = c.put(url, json={"steps": t["steps"], "check": t["check"], "when_broken": t["when_broken"], "admin": "t"})   # owner, 2026-11-10: saving unchanged words made versions that changed nothing
        assert same.status_code == 400 and "nothing changed since your version 1" in same.get_json()["error"]
        r = c.put(url, json={"steps": ["second wording"], "admin": "t"})
        v = r.get_json()
        assert v["texts"]["packets_to_links"]["v"] == 2 and v["text_versions"]["packets_to_links"] == 2
        folder = v["paths"]["rules"]["packets_to_links"]
        assert v["saved"] == os.path.join(folder, "v2.json") and os.path.isfile(v["saved"]) and folder.startswith(os.path.join(root, "knowledge", "join_rules"))
        with open(os.path.join(folder, "current.json")) as fh:
            assert json.load(fh)["steps"] == ["second wording"]
        v = c.put(url, json={"steps": [], "admin": "t"}).get_json()
        assert v["texts"]["packets_to_links"] is None and v["text_versions"]["packets_to_links"] == 3
        again = c.put(url, json={"steps": [], "admin": "t"})                    # going back twice is refused, not a fourth version
        assert again.status_code == 400 and "already the one in force" in again.get_json()["error"]
        prog = v["joins"][0]
        same = c.put(url, json={"steps": prog["steps"], "check": prog["check"], "when_broken": prog["when_broken"], "admin": "t"})
        assert same.status_code == 400 and "the program's own words" in same.get_json()["error"]
        assert c.get("/api/agents/projects/%d/join_rules" % pid).get_json()["text_versions"]["packets_to_links"] == 3
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_old_rule_versions_move_to_the_knowledge_folder_without_the_unchanged_saves():
    """The first workbench kept versions in runs/agentic/join_rules/project_<id>.json, saves of the unchanged words among them. They move to
    knowledge/join_rules/<format>/<rule>/v<N>.json once; the unchanged ones stay behind in the old file, which is renamed, not deleted."""
    import fuzz_app as F
    root = tempfile.mkdtemp(prefix="agent_layer_jwm_%d_" % os.getpid())
    try:
        app, c, _k, _r = F.setup(root)
        from api import agentic_api as A
        from agentic import join_rules as JR
        pid = c.post("/api/agents/projects", json={"admin": "t", "name": "old", "folder": F.BASE}).get_json()["id"]
        with app.app_context():
            eng = A.engine()
        prog = next(j for j in JR.as_strategy() if j["id"] == "packets_to_links")
        old = os.path.join(eng.runner.sandbox_root, "join_rules", "project_%d.json" % pid)
        os.makedirs(os.path.dirname(old), exist_ok=True)
        unchanged = {"by": "t", "at": 1.0, "steps": prog["steps"], "check": prog["check"], "when_broken": prog["when_broken"], "v": 1}
        with open(old, "w") as fh:
            json.dump({"settings": {}, "notes": {}, "chat": {}, "tries": [], "texts": {"packets_to_links": [
                unchanged, {"by": "t", "at": 2.0, "back_to_the_program": True, "v": 2}, dict(unchanged, v=3, at=3.0),
                {"by": "t", "at": 4.0, "steps": ["a real change"], "check": "", "when_broken": [], "v": 4}]}}, fh)
        v = c.get("/api/agents/projects/%d/join_rules" % pid).get_json()
        assert v["text_versions"]["packets_to_links"] == 1 and v["texts"]["packets_to_links"]["steps"] == ["a real change"]
        assert not os.path.exists(old) and os.path.exists(old + ".moved")
        assert os.path.isfile(v["paths"]["analysis_file"])
    finally:
        shutil.rmtree(root, ignore_errors=True)
