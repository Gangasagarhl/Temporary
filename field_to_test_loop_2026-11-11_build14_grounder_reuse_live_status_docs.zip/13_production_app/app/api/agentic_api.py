"""The agent families' web API (the /agents page).

  GET  /api/agents/state                          settings, projects, open reviews, recent runs
  GET  /api/agents/settings | PUT                 runtime (claude-code | http | standin), model, slices, connectors, web
  GET  /api/agents/inventory?folder=              the CSVs of a folder, as Family 1's Director sees them
  GET  /api/agents/places                         recordings ready on this machine, the reference documents, where results are kept
  POST /api/agents/projects                       {admin, name (required, unique), folder, refs[]} -> project; the same
                                                  name on the same folder returns that analysis (reused: true)
  GET  /api/agents/projects/<pid> | PUT
  POST /api/agents/projects/<pid>/flow            {admin: who starts it (required)} start THE FLOW: Family 1 -> 2 -> 3, one run
  POST /api/agents/projects/<pid>/family1         start Family 1 alone (data dictionaries)
  POST /api/agents/projects/<pid>/family2         start Family 2 alone (hierarchy)
  GET  /api/agents/runs?project=                  runs, newest first
  GET  /api/agents/runs/<rid>                     the run with its steps, reviews, evidence and whether its worker is alive
  POST /api/agents/runs/<rid>/retry | /stop
  GET  /api/agents/reviews?state=open
  POST /api/agents/reviews/<id>/decide            {decision: approve|change|reject, admin, comment, edits}
  POST /api/agents/reviews/<id>/ask               {message, admin} -> an answer about what is being reviewed
  GET  /api/agents/rules                          the sidebar tree: sections, levels, items
  POST /api/agents/rules                          {section, level, name, description, admin, project} -> new item + its first draft run
  GET  /api/agents/rules/<sec>/<lvl>/<id>         the rule, in plain words, its code, its versions, its last run
  POST /api/agents/rules/<sec>/<lvl>/<id>/edit    {message, project} -> a draft run (Rule writer, then review)
  POST /api/agents/rules/<sec>/<lvl>/<id>/proceed {project, upload_id?} -> a run of the approved rule
  GET  /api/agents/file?path=                     an exported file (only under knowledge/exports)
"""
import json
import os
import re
import sqlite3
import sys
import threading
import time

from flask import Blueprint, Response, jsonify, request, send_file

from . import svc, whole, as_text, a_dict

APP = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, APP)
from agentic import core, family1, family2, family3, pipeline, rule_evidence   # noqa: E402
from agentic import join_rules as JR   # noqa: E402
from nvme_hier import loader as L   # noqa: E402

bp = Blueprint("agentic", __name__)
_FLOW_START = threading.Lock()
_LOCK = threading.Lock()
DEFAULTS = {"runtime": "claude-code", "model": "", "slices": 6, "connectors": {}, "web": True,
            "references": [os.path.join(os.path.dirname(APP), "09_defect_isolation_research", "research_notes")]}


def settings(s):
    a = dict(DEFAULTS)
    a.update({k: v for k, v in (s.cfg.get("agentic") or {}).items() if not k.startswith("_")})
    if not a.get("references"):            # empty in the configuration = the project's own research notes, when they are next to the app
        # (the code-only zip does not carry them: on a production machine the folder is missing, and a missing default must never stop
        # a flow from starting; owner's screenshot 2026-11-11: "these reference folders do not exist: D:\\...\\research_notes")
        a["references"] = [r for r in DEFAULTS["references"] if os.path.isdir(r)]
    return a


def engine():
    s = svc()
    with _LOCK:
        eng = getattr(s, "agentic_engine", None)
        if eng is None:
            a = settings(s)
            store = core.Store(os.path.join(s.root, "db", "agentic.sqlite"))
            runner = core.AgentRunner(os.path.join(s.root, "runs", "agentic"), runtime=a["runtime"],
                                      llm_getter=lambda: getattr(getattr(s, "s2", None), "llm", None), model=a.get("model") or (s.cfg.get("llm") or {}).get("model") or None,
                                      http_model=(s.cfg.get("llm") or {}).get("model"), claude_path=a.get("claude_path"), web=a.get("web", True))
            eng = core.Engine(store, {"flow": pipeline, "family1": family1, "family2": family2, "rule_draft": family3, "rule_run": family3, "rule_code": family3, "rule_exec": family3}, runner,
                              services=s, cfg=s.cfg)
            s.agentic_engine = eng
            eng.resume_all()
        return eng


def admin_of(body):
    return as_text(body.get("admin"), "admin").strip() or "admin"


def _project(pid):
    p = engine().store.one("SELECT * FROM project WHERE id=?", (pid,))
    if p:
        p["refs"] = core.jload(p["refs"], [])
    return p


@bp.get("/api/agents/state")
def state():
    eng = engine()
    s = svc()
    projects = eng.store.all("SELECT * FROM project ORDER BY updated DESC, id DESC LIMIT 50")
    for p in projects:
        p["refs"] = core.jload(p["refs"], [])
    runs = eng.store.all("SELECT id, project, kind, target, state, created, updated, heartbeat, summary, params FROM run ORDER BY id DESC LIMIT 30")
    for r in runs:
        r["started_by"] = (core.jload(r.pop("params"), {}) or {}).get("started_by")
        r["steps"] = eng.store.all("SELECT state, COUNT(*) AS n FROM step WHERE run=? GROUP BY state", (r["id"],))
        r["worker_alive"] = bool(eng.threads.get(r["id"]) and eng.threads[r["id"]].is_alive())
        if r["state"] == "running":           # what it is doing now, with its progress (the top bar shows it on every page)
            r["now"] = eng.store.one("SELECT key, title, note FROM step WHERE run=? AND state='running' ORDER BY idx LIMIT 1", (r["id"],))
    reviews = eng.store.all("SELECT r.id, r.run, r.title, r.created, run.kind, run.target FROM review r JOIN run ON run.id=r.run WHERE r.state='open' ORDER BY r.id")
    return jsonify({"settings": settings(s), "projects": projects, "runs": runs, "open_reviews": reviews})


@bp.get("/api/agents/settings")
def get_settings():
    a = settings(svc())
    a["claude_found"] = core.AgentRunner.find_claude(a.get("claude_path"))
    return jsonify(a)


@bp.put("/api/agents/settings")
def put_settings():
    s = svc()
    body = request.get_json(force=True) or {}
    a = s.cfg.setdefault("agentic", {})
    if "runtime" in body:
        if not isinstance(body["runtime"], str) or body["runtime"] not in core.AgentRunner.ORDER:
            return jsonify({"error": "runtime must be one of %s" % ", ".join(core.AgentRunner.ORDER)}), 400
        a["runtime"] = body["runtime"]
    if "model" in body:
        a["model"] = as_text(body["model"], "model").strip()
    if "claude_path" in body:
        if (s.cfg.get("server") or {}).get("lock_endpoint"):     # the program the server runs as Claude Code is locked like the model endpoint
            return jsonify({"error": "the path of Claude Code is locked by server.lock_endpoint: change it in the configuration file and start the application again"}), 403
        a["claude_path"] = as_text(body["claude_path"], "claude_path").strip()
    if "slices" in body:
        a["slices"] = max(1, min(100, whole(body["slices"], "slices")))
    if "connectors" in body:
        a["connectors"] = a_dict(body["connectors"], "connectors")
    if "references" in body:
        if not isinstance(body["references"], list):
            return jsonify({"error": "references must be a list of paths"}), 400
        a["references"] = [as_text(x, "references") for x in body["references"]]
    if "web" in body:
        a["web"] = bool(body["web"])
    path = os.path.join(s.root, "config", "app_config.json")
    try:
        cfg = json.load(open(path))
        cfg["agentic"] = a
        L.write_json_atomic(path, cfg, indent=2)
    except OSError as e:
        return jsonify({"error": "could not save the configuration: %s" % e}), 500
    eng = engine()
    eng.runner.runtime = a.get("runtime", eng.runner.runtime)
    eng.runner.model = a.get("model") or (s.cfg.get("llm") or {}).get("model") or None
    eng.runner.web_enabled = bool(a.get("web", True))
    return jsonify(settings(s))


SAMPLE_WORDS = {"demo_225_commands": "the small demo recording: 225 NVMe commands, one vendor command with an error",
                "S08_interrupt_before_completion": "made-up fault S08: an interrupt arrives before its completion entry",
                "S17_io_timeout_abort_reset": "made-up fault S17: I/O timeout, abort, then controller reset (6 commands never complete: the demo error)",
                "S27_lcrc_nak_replay": "made-up fault S27: bad TLP, LCRC error, Nak and replay on the link"}


@bp.get("/api/agents/places")
def places():
    """Where things are on this machine, for the start page: the recordings ready to analyse (folders of exported CSV
    files, with their levels), the reference documents, and where every result of the flow is kept."""
    s = svc()
    root = s.root
    rec = []
    cands = []
    clean = os.path.join(root, "samples", "clean_five_files")
    if os.path.isdir(clean):
        cands += [os.path.join(clean, n) for n in sorted(os.listdir(clean))]
    for pr in engine().store.all("SELECT folder FROM project ORDER BY id DESC"):
        if pr["folder"] and pr["folder"] not in cands and not os.path.basename(pr["folder"]).startswith("_"):
            cands.append(pr["folder"])
    for d in cands:
        if not os.path.isdir(d):
            continue
        inv = [f for f in family1.inventory(d) if f["level"]]
        if not inv:
            continue
        rec.append({"path": d, "name": os.path.basename(d.rstrip("/")), "levels": len(inv), "files": [f["name"] for f in inv],
                    "mb": round(sum(f["bytes"] for f in inv) / 1e6, 1), "about": SAMPLE_WORDS.get(os.path.basename(d.rstrip("/")), "")})
    refs = settings(s)["references"]
    know = family1.knowledge_dir()
    kept = [("Data dictionaries (Family 1), one folder per file format", os.path.join(know, "dictionaries")),
            ("Joining strategies (Family 2), versions per file format", os.path.join(know, "strategies")),
            ("Rules (Family 3), one JSON file per item", os.path.join(know, "rules")),
            ("Code made from the rules", os.path.join(know, "rules_code")),
            ("Exports of the rules (CSV and HTML)", os.path.join(know, "exports")),
            ("Flow reports, one folder per run", os.path.join(know, "exports", "flow")),
            ("Trees built from the files (one folder per upload: hier.sqlite)", os.path.join(root, "uploads")),
            ("Test files written by stage 2", os.path.join(root, "suite", "hier")),
            ("What every agent was asked and answered, one folder per run", os.path.join(root, "runs", "agentic")),
            ("The flow's records (runs, steps, reviews, evidence)", os.path.join(root, "db", "agentic.sqlite")),
            ("The isolation memory (signatures, procedures, the four signals)", os.path.join(root, "db", "hier_knowledge.sqlite")),
            ("Test logs", os.path.join(root, "runs", "suite_logs")),
            ("The settings", os.path.join(root, "config", "app_config.json"))]
    return jsonify({"root": root, "recordings": rec,
                    "references": [{"path": r, "files": sum(len(fs) for _b, _d, fs in os.walk(r)) if os.path.isdir(r) else 0} for r in refs],
                    "kept": [{"what": w, "path": pth, "exists": os.path.exists(pth)} for w, pth in kept],
                    "server_log": "journalctl --user -u f2t-app -f"})


@bp.get("/api/agents/inventory")
def inventory():
    folder = request.args.get("folder") or ""
    if not os.path.isdir(folder):
        return jsonify({"error": "not a folder: %s" % folder}), 400
    found = family1.inventory(folder)
    return jsonify({"folder": folder, "files": found, "problem": family1.folder_problem(found) if found else None})


@bp.post("/api/agents/projects")
def create_project():
    body = request.get_json(force=True) or {}
    folder = as_text(body.get("folder"), "folder").strip()
    if not os.path.isdir(folder):
        return jsonify({"error": "the input folder does not exist: %s" % folder}), 400
    found = family1.inventory(folder)
    if not found:
        return jsonify({"error": "the folder holds no CSV file: %s" % folder}), 400
    problem = family1.folder_problem(found)
    if problem:
        return jsonify({"error": problem}), 400
    typed = [r.strip() for r in (body.get("refs") or []) if isinstance(r, str) and r.strip()]
    bad = [r for r in typed if not os.path.isdir(r)]
    if bad:                                 # only the folders the admin typed are refused; configured ones that are missing are left out
        return jsonify({"error": "these reference folders do not exist: %s" % ", ".join(bad)}), 400
    refs = typed or [r for r in settings(svc())["references"] if r and os.path.isdir(r)]
    # the name is required and unique: it is how the same analysis is recognised. The same name on the same folder opens
    # that analysis (not a second one), so everything approved for it (dictionaries, strategy, the tree built from these
    # files) is used again and nothing is computed twice; a name already used for another folder is refused
    name = re.sub(r"\s+", " ", as_text(body.get("name"), "name")).strip()
    if not name:
        return jsonify({"error": "give the analysis a name: the same name on the same folder later opens this analysis again, "
                                 "so nothing approved or built for it is computed twice"}), 400
    for old in engine().store.all("SELECT * FROM project ORDER BY id DESC"):
        if re.sub(r"\s+", " ", old["name"] or "").strip().lower() != name.lower():
            continue
        if os.path.realpath(old["folder"] or "") == os.path.realpath(folder):
            engine().store.exec("UPDATE project SET updated=? WHERE id=?", (time.time(), old["id"]))
            return jsonify(dict(_project(old["id"]), reused=True))
        return jsonify({"error": "the name \"%s\" is already used by another analysis, of the folder %s: choose another name, "
                                 "or give that folder to open that analysis" % (old["name"], old["folder"]), "project": old["id"]}), 409
    t = time.time()
    pid = engine().store.exec("INSERT INTO project (admin, name, folder, refs, rea, upload_id, notes, created, updated) VALUES (?,?,?,?,?,?,?,?,?)",
                              (admin_of(body), name, folder, json.dumps(refs),
                               as_text(body.get("rea"), "rea").strip(), as_text(body.get("upload_id"), "upload_id").strip() or None, body.get("notes") or "", t, t))
    return jsonify(_project(pid))


@bp.get("/api/agents/projects/<int:pid>")
def get_project(pid):
    p = _project(pid)
    return jsonify(p) if p else (jsonify({"error": "no such project"}), 404)


@bp.put("/api/agents/projects/<int:pid>")
def put_project(pid):
    body = request.get_json(force=True) or {}
    p = _project(pid)
    if not p:
        return jsonify({"error": "no such project"}), 404
    for k in ("admin", "name", "rea", "upload_id", "notes"):
        if k in body:
            engine().store.exec("UPDATE project SET %s=?, updated=? WHERE id=?" % k, (as_text(body[k], k), time.time(), pid))
    if "refs" in body:
        engine().store.exec("UPDATE project SET refs=?, updated=? WHERE id=?", (json.dumps(body["refs"]), time.time(), pid))
    return jsonify(_project(pid))


def _start(pid, kind, target="", params=None):
    p = _project(pid)
    if not p:
        return jsonify({"error": "no such project"}), 404
    params = dict(params or {})
    body = request.get_json(silent=True) or {}
    # who starts this run: its reviews are addressed to this person and the run records it (default: the project's admin)
    params.setdefault("started_by", as_text(body.get("admin"), "admin").strip() or p.get("admin") or "admin")
    rid = engine().start(pid, kind, target, params)
    return jsonify({"run": rid, "view": engine().view(rid)})


@bp.post("/api/agents/projects/<int:pid>/flow")
def start_flow(pid):
    eng = engine()
    body = request.get_json(silent=True) or {}
    who = as_text(body.get("admin"), "admin").strip()
    if not who:
        return jsonify({"error": "say who is starting the flow: every review of it is addressed to that person, and every decision is stored with a name"}), 400
    with _FLOW_START:             # the check and the start are one step: two presses at the same moment start one flow
        busy = eng.store.one("SELECT id FROM run WHERE project=? AND kind='flow' AND state='running'", (pid,))
        if busy:
            return jsonify({"error": "this project's flow is already running (run %d): open it, or stop it first" % busy["id"], "run": busy["id"]}), 409
        return _start(pid, "flow", "Family 1 -> 2 -> 3", {"started_by": who})


@bp.post("/api/agents/projects/<int:pid>/family1")
def start_family1(pid):
    return _start(pid, "family1", "data dictionaries")


@bp.post("/api/agents/projects/<int:pid>/family2")
def start_family2(pid):
    return _start(pid, "family2", "hierarchy")


@bp.get("/api/agents/runs")
def list_runs():
    pid = request.args.get("project")
    q, a = "SELECT id, project, kind, target, state, created, updated, summary, params FROM run", ()
    if pid:
        q, a = q + " WHERE project=?", (whole(pid, "project"),)
    out = engine().store.all(q + " ORDER BY id DESC LIMIT 100", a)
    for r in out:
        r["started_by"] = (core.jload(r.pop("params"), {}) or {}).get("started_by")
    return jsonify(out)


@bp.get("/api/agents/runs/<int:rid>")
def get_run(rid):
    v = engine().view(rid)
    if not v:
        return jsonify({"error": "no such run"}), 404
    for r in v.get("reviews") or []:            # each document source of a dictionary says what the document is and what it names at that line
        d = r.get("data") if isinstance(r.get("data"), dict) else None
        if d and d.get("table") is not None and "empty" not in d and d.get("dictionary_file"):    # a card made before 2026-11-10: the empty columns come from its dictionary
            try:
                d["empty"] = json.load(open(d["dictionary_file"])).get("empty_columns") or []
            except (OSError, ValueError):
                d["empty"] = []
        if d and d.get("table") is not None and "spacers" not in d and d.get("path"):
            d["spacers"] = family1.blank_header_positions(d["path"])
        for row in (d or {}).get("table") or []:
            for src in [row.get("source")] + [k.get("source") for k in row.get("keywords") or [] if isinstance(k, dict)]:
                if isinstance(src, dict) and src.get("kind") == "document" and src.get("ref"):
                    src["where"] = family1.source_details(src["ref"])
    return jsonify(v)


@bp.post("/api/agents/runs/<int:rid>/retry")
def retry_run(rid):
    engine().retry(rid)
    return jsonify(engine().view(rid))


@bp.delete("/api/agents/projects/<int:pid>")
def delete_project(pid):
    """Deletes one analysis with its runs, decisions and conversations (owner, 2026-11-10: the list had no way to delete). What other analyses use is kept: the approved
    data dictionaries and strategies (they belong to the file format), the rules library, the built trees, the failure memory, the test files and the agents' working folders.
    A copy of every deleted record is written to runs/agentic/_deleted/ first. A running analysis is stopped first (its steps and model calls
    end), then deleted (owner, 2026-11-11: "delete is not working")."""
    body = request.get_json(force=True, silent=True) or {}
    eng = engine()
    p = eng.store.one("SELECT * FROM project WHERE id=?", (pid,))
    if not p:
        return jsonify({"error": "no such analysis"}), 404
    runs = eng.store.all("SELECT * FROM run WHERE project=?", (pid,))
    for r in runs:                                     # (owner, 2026-11-11) a running analysis is stopped first: its steps and model calls end
        if r["state"] == "running" or eng.store.one("SELECT id FROM step WHERE run=? AND state='running'", (r["id"],)):
            eng.stop(r["id"], admin_of(body), "deleted")
    ids = [r["id"] for r in runs]
    marks = ",".join("?" * len(ids)) or "NULL"
    copy = {"deleted_by": admin_of(body), "deleted_at": time.time(), "project": p, "runs": runs,
            "steps": eng.store.all("SELECT * FROM step WHERE run IN (%s)" % marks, ids),
            "reviews": eng.store.all("SELECT * FROM review WHERE run IN (%s)" % marks, ids),
            "chat": eng.store.all("SELECT * FROM chat WHERE review IN (SELECT id FROM review WHERE run IN (%s))" % marks, ids),
            "evidence": eng.store.all("SELECT * FROM evidence WHERE run IN (%s)" % marks, ids)}
    keep = os.path.join(eng.runner.sandbox_root, "_deleted")
    os.makedirs(keep, exist_ok=True)
    path = os.path.join(keep, "analysis_%d_%s.json" % (pid, time.strftime("%Y%m%d-%H%M%S")))
    L.write_json_atomic(path, copy, indent=1)
    eng.store.exec("DELETE FROM chat WHERE review IN (SELECT id FROM review WHERE run IN (%s))" % marks, ids)
    for t in ("evidence", "review", "step"):
        eng.store.exec("DELETE FROM %s WHERE run IN (%s)" % (t, marks), ids)
    eng.store.exec("DELETE FROM run WHERE project=?", (pid,))
    eng.store.exec("DELETE FROM project WHERE id=?", (pid,))
    return jsonify({"deleted": pid, "name": p["name"], "runs": len(ids), "copy": path})


@bp.post("/api/agents/runs/<int:rid>/stop")
def stop_run(rid):
    engine().stop(rid, admin_of(request.get_json(force=True) or {}))
    return jsonify(engine().view(rid))


@bp.get("/api/agents/reviews")
def list_reviews():
    st = request.args.get("state", "open")
    return jsonify(engine().store.all("SELECT r.*, run.kind, run.target, run.project FROM review r JOIN run ON run.id=r.run WHERE r.state=? ORDER BY r.id", (st,)))


@bp.post("/api/agents/reviews/<int:rv>/decide")
def decide(rv):
    body = request.get_json(force=True) or {}
    try:
        engine().decide(rv, as_text(body.get("decision"), "decision"), admin_of(body), as_text(body.get("comment"), "comment"), body.get("edits"))
    except (ValueError, KeyError) as e:
        return jsonify({"error": str(e)}), 400
    r = engine().store.one("SELECT run FROM review WHERE id=?", (rv,))
    return jsonify(engine().view(r["run"]))


ASK_INSTRUCTION = """You are the agent whose work is under the admin's review. Answer the admin's question about it in
short, plain sentences, using only what is in CONTEXT (the review text, the step's output, the evidence). When CONTEXT has
HOW_IT_WORKS and ITEMS_NOW, they are the application's current state and come first: the review text was written when the
review opened and can be older. Do not use internal names without saying what they are. If CONTEXT does not hold the
answer, say so and say what would be needed."""

# how the rules stage works now, in the application's own words (owner, 2026-11-09: the agent answered from an older review text)
RULES_HOW = [
    "Each item has its source data (the file and the columns it reads) and its procedure: numbered steps saying how each cell is read, counted and output.",
    "Tick the items to run, then press 'Run the chosen rules'. An item without a procedure first goes to the Rule writer, who writes it from your words for your review.",
    "An item without verified code goes to the Coder, who writes Python code from the procedure. The program checks the code without running it on the recording, and it comes to you for review (the chime sounds). You can 'Try on a sample' (the first records only). Approved, it is the verified code of that procedure version.",
    "The verified code then runs on the whole recording, with its progress shown in percent. The Tester checks the result (the columns, the totals, an independent count where there is one) and it is exported as CSV and HTML, then shown to you.",
    "Error roots items use the detector's own verified code (part of the application). After their result you pick one defect: stage 1 isolates it (the reason, the evidence, the shortest sequence of commands; you answer with a signal) and stage 2 writes what a correct drive must answer, then the test file.",
    "On each item: Edit rule/procedure changes the procedure (a JSON); Samples shows and exports records of the source file from a line on; Run and Export CSV work once the code is verified.",
]


def _rules_facts(r, step, data):
    """HOW_IT_WORKS and ITEMS_NOW for a review of the rules stage: the plan, a procedure, a piece of code, a result."""
    key = step["key"]
    if not (key == "f3_plan" or key in ("write", "code", "result") or key.startswith("f3:")):
        return {}
    keys = [i["key"] for i in (data.get("items") or []) if i.get("selected")] if key == "f3_plan" else []
    if key.startswith("f3:"):
        keys = [key[3:].rsplit(":", 1)[0].split("#")[0]]
    elif key in ("write", "code", "result"):
        p = core.jload((engine().store.one("SELECT params FROM run WHERE id=?", (step["run"],)) or {}).get("params"), {}) or {}
        if p.get("section"):
            keys = ["%s/%s/%s" % (p["section"], p["level"], p["id"])]
    proj = engine().store.one("SELECT upload_id FROM project WHERE id=(SELECT project FROM run WHERE id=?)", (step["run"],)) or {}
    items = []
    for k in keys[:12]:
        try:
            sec, lvl, rid = k.split("/")
            x = rule_evidence.explain(sec, lvl, rid, data.get("upload_id") or proj.get("upload_id"))
        except ValueError:
            x = None
        if x:
            items.append({"item": x["name"], "section": (x.get("section") or {}).get("title"), "level": x["level"]["label"],
                          "source_data": x["sources"], "procedure_steps": (x.get("procedure") or {}).get("steps"),
                          "output": (x.get("procedure") or {}).get("output"),
                          "code": {c: x["code"].get(c) for c in ("kind", "verified", "verified_by", "procedure_version")}})
    return {"HOW_IT_WORKS": RULES_HOW, "ITEMS_NOW": items}


def _dictionary_digest(k, folder=None):
    """One approved dictionary in a form small enough for a question to the model: its size, its summary, every column that holds a value with what it is and what it means, and the empty columns.
    A review made before 2026-11-10 does not name the file's format; it is found again from the analysis's folder."""
    if not k.get("format_key") and folder:
        f = next((x for x in family1.inventory(folder) if x["name"] == k.get("file")), None)
        if f:
            k = dict(k, format_key=f["format_key"], columns_in_file=f["columns"])
    d = family1.approved_dictionary(k.get("format_key") or "", k.get("file") or "") or {}
    empty = d.get("empty_columns") or []
    return {"file": k.get("file"), "rows": d.get("rows"), "columns_in_the_file": k.get("columns_in_file"), "summary": d.get("summary"),
            "columns_holding_a_value": [{"column": c.get("column"), "type": c.get("type"), "rows_with_value": c.get("rows_with_value"),
                                         "what_the_data_shows": (c.get("observed") or "")[:160], "meaning": (c.get("meaning") or "")[:160], "status": c.get("status")}
                                        for c in (d.get("columns") or []) if isinstance(c, dict)],
            "empty_columns": {"count": len(empty), "first": [e if isinstance(e, str) else str(e) for e in empty[:40]]},
            "blank_spacer_columns": {"count": max(0, (k.get("columns_in_file") or 0) - len(d.get("columns") or []) - len(empty)) if isinstance(k.get("columns_in_file"), int) else None,
                                     "what": "the analyzer's spacer columns between groups of columns: no header and no value; not listed in the dictionary"},
            "approved_by": d.get("approved_by"), "version": d.get("version")}


@bp.post("/api/agents/reviews/<int:rv>/ask")
def ask(rv):
    body = request.get_json(force=True) or {}
    msg = as_text(body.get("message"), "message").strip()
    if not msg:
        return jsonify({"error": "write a question"}), 400
    eng = engine()
    r = eng.store.one("SELECT * FROM review WHERE id=?", (rv,))
    if not r:
        return jsonify({"error": "no such review"}), 404
    step = eng.store.one("SELECT * FROM step WHERE id=?", (r["step"],))
    eng.store.exec("INSERT INTO chat (review, role, text, at) VALUES (?,?,?,?)", (rv, "admin:" + admin_of(body), msg, time.time()))
    history = eng.store.all("SELECT role, text FROM chat WHERE review=? ORDER BY id", (rv,))
    out = core.jload(step["output"], {}) or {}
    # a data dictionary: the admin talks to the Manager, who asks its two helpers (each with its own memory)
    if step["key"].startswith("manager:") and out.get("dictionary_file") and os.path.exists(out["dictionary_file"]) and \
            json.load(open(out["dictionary_file"])).get("explorer_memory"):
        try:
            text, producer = family1.manager_ask(eng, r, step, msg, history)
        except RuntimeError as e:
            return jsonify({"error": str(e)}), 502
        eng.store.exec("INSERT INTO chat (review, role, text, at) VALUES (?,?,?,?)", (rv, producer, text, time.time()))
        return jsonify({"answer": text, "producer": producer, "chat": eng.store.all("SELECT role, text, at FROM chat WHERE review=? ORDER BY id", (rv,))})
    data = core.jload(r["data"], {}) or {}
    detail = {}
    # what is under review in full: the dictionary's rows (column, what the data shows, meaning, status, sources), the
    # strategy's joins, the rule draft, the result's first rows; not only the step's summary
    if out.get("dictionary_file") and os.path.exists(out["dictionary_file"]):
        detail["dictionary"] = json.load(open(out["dictionary_file"])).get("columns")
    if isinstance(out.get("known"), list):             # dictionaries offered again: what is in each, so a question about rows, columns or meanings has its answer (owner, 2026-11-10)
        folder = (eng.store.one("SELECT p.folder FROM project p JOIN run r ON r.project = p.id WHERE r.id=?", (r["run"],)) or {}).get("folder")
        detail["dictionaries"] = [_dictionary_digest(k, folder) for k in out["known"] if isinstance(k, dict)]
    for k in ("table", "joins", "draft", "strategy", "columns", "head", "items", "sequence", "reason", "scenario_name", "outcomes", "reuse"):
        if data.get(k) and k not in detail:
            detail[k] = data[k]
    ctx = {"review": r["body"], "under_review": detail, "step_output": out, "conversation": history,
           "evidence": eng.store.all("SELECT claim, kind, ref, quote, verified FROM evidence WHERE step=? LIMIT 200", (r["step"],))}
    ctx.update(_rules_facts(r, step, data))
    # (owner, 2026-11-10: "it doesn't have information about the family one, family two ... make those connections") the card's question goes
    # with what Families 1 and 2 approved, and the model may look at the recording's tree with read-only queries, as the side panel does
    from agentic import data_chat as DC
    project = eng.store.one("SELECT p.* FROM project p JOIN run x ON x.project = p.id WHERE x.id=?", (r["run"],)) or {}
    db, conn = _chat_db(project) if project else (None, {"words": "no analysis"})
    con = None
    try:
        con = DC.open_ro(db) if db else None
    except sqlite3.Error:
        con = None
    sizes = DC.table_sizes(con) if con else {}
    if con:
        ctx["the_tree"] = {"connected": conn.get("words"), "tables": DC.schema(con), "rows_per_table": sizes, "joins": DC.JOINS}
    ctx["joining_rules_family_2"] = [{"title": j["title"], "steps": j["steps"]} for j in JR.as_strategy()]
    ctx["column_meanings_family_1"] = DC.dictionaries(project) if project else []
    ctx["query_results"] = []
    instruction = ASK_INSTRUCTION + ("\n\nYou may look at the recording's tree yourself: put up to %d read-only SQL queries (SQLite, one SELECT or WITH ... SELECT "
                                     "each) in \"queries\"; the program runs them and asks you again with the results (at most %d rows each). Join the levels "
                                     "exactly as the_tree.joins says; never join levels by Tag, Address or time. When you have what you need, leave \"queries\" "
                                     "empty and answer; every number you give must come from a result or from the text you were given." % (DC.MAX_QUERIES, DC.QUERY_ROWS)
                                     if con else "\n\nNo tree of this recording is built yet: answer from what you were given and say the data could not be looked at.")
    ran, ans, producer = [], None, "stand-in (no model)"
    try:
        for rnd in range(DC.MAX_ROUNDS + 1):
            try:
                ans, producer, _ = eng.runner.ask(r["run"], "ask_review_%d" % rv, instruction + "\n\nQUESTION: " + msg, json.dumps(ctx, default=str)[:150000],
                                                  '{"answer": "...", "queries": ["SELECT ..."]}', "answer",
                                                  lambda: {"answer": "Stand-in answer (no model): the review says: " + r["body"][:600], "queries": []})
            except RuntimeError as e:
                return jsonify({"error": str(e)}), 502
            qs = [q for q in (ans.get("queries") or []) if isinstance(q, str) and q.strip()][:DC.MAX_QUERIES]
            if not qs or con is None or rnd == DC.MAX_ROUNDS:
                break
            res = [DC.run_query(con, q, sizes) for q in qs]
            ran += res
            ctx["query_results"] += res
    finally:
        if con is not None:
            con.close()
    text = str(ans.get("answer") or "")
    if ran:
        check = DC.numbers_check(text, ran, msg + " " + (r["body"] or ""))
        text += "\n\n— Looked at the recording with %d quer%s: %s." % (len(ran), "y" if len(ran) == 1 else "ies", "; ".join(
            ("`%s` → %s" % (q["sql"][:160], ("did not run: " + q["error"]) if q.get("error") else "%d row%s%s" % (len(q.get("rows") or []), "" if len(q.get("rows") or []) == 1 else "s", " (cut)" if q.get("more_rows") else "")))
            for q in ran))
        if not check["ok"]:
            text += " These numbers are in no query result: %s. Check them before you use them." % ", ".join(check["missing"])
    ans["answer"] = text
    eng.store.exec("INSERT INTO chat (review, role, text, at) VALUES (?,?,?,?)", (rv, producer, ans["answer"], time.time()))
    return jsonify({"answer": ans["answer"], "producer": producer, "chat": eng.store.all("SELECT role, text, at FROM chat WHERE review=? ORDER BY id", (rv,))})


@bp.get("/api/agents/rules")
def rules_tree():
    return jsonify(family3.tree())


@bp.get("/api/agents/rules/sections")
def rule_sections():
    return jsonify({"sections": family3.sections(), "levels": [{"id": k, "label": family3.LEVEL_LABEL[k], "about": rule_evidence.LEVEL_ABOUT[k]}
                                                               for k in family3.LEVELS], "levels_note": rule_evidence.LEVELS_NOTE,
                    "rules_folder": family3.rules_root()})


@bp.post("/api/agents/rules/sections")
def add_rule_section():
    """A new section, made by the admin: {label, about, defects (its items find defects that go on to stage 1 and 2), admin}."""
    body = request.get_json(force=True) or {}
    try:
        sec = family3.add_section(body.get("label"), body.get("about") or "", bool(body.get("defects")), admin_of(body))
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"section": sec, "sections": family3.sections()})


@bp.get("/api/agents/rules/counts")
def rule_counts():
    """{item key: {found, commands}}: how often each detector item fired in the upload's tree (for the item list)."""
    return jsonify(rule_evidence.counts(request.args.get("upload") or ""))


@bp.get("/api/agents/rules/recording")
def rule_recording():
    """The recording the rules run on, in words (name, folder, who loaded it and when, rows per file), for the rules card."""
    return jsonify(rule_evidence.recording(request.args.get("upload") or "") or {})


def _item_activity(sec, lvl, rid):
    """The item's Code it / Run work in progress: the newest rule_code or rule_exec run, and an open code review of it
    (also inside a flow: the step f3:<item>:code)."""
    eng = engine()
    key = "%s/%s/%s" % (sec, lvl, rid)
    runs = eng.store.all("SELECT id, kind, state, created FROM run WHERE kind IN ('rule_code', 'rule_exec') AND params LIKE ? ORDER BY id DESC LIMIT 6",
                         ('%%"id": "%s"%%' % rid,))
    runs = [x for x in runs if core.jload((eng.store.one("SELECT params FROM run WHERE id=?", (x["id"],)) or {}).get("params"), {}).get("section") == sec]
    out = {"coding": None, "running": None}
    for x in runs:
        slot = "coding" if x["kind"] == "rule_code" else "running"
        if out[slot] is None:
            out[slot] = {"run": x["id"], "state": x["state"]}
    for rv in eng.store.all("SELECT r.id, r.run, s.key FROM review r JOIN step s ON s.id = r.step WHERE r.state = 'open' ORDER BY r.id DESC"):
        if rv["key"] == "code" and out["coding"] and rv["run"] == out["coding"]["run"]:
            out["coding"]["review"] = rv["id"]
        elif rv["key"].startswith("f3:%s" % key) and rv["key"].endswith(":code"):
            out["flow_review"] = {"review": rv["id"], "run": rv["run"]}
    return out


@bp.get("/api/agents/rules/<sec>/<lvl>/<rid>/explain")
def explain_rule(sec, lvl, rid):
    """The card of one item: the source data (full paths in the recording ?upload=<id>), the procedure (numbered steps and
    the editable JSON), the code (verified or not, with its text), the last result, and Code it / Run work in progress."""
    try:
        x = rule_evidence.explain(sec, lvl, rid, request.args.get("upload") or None)
    except ValueError:
        x = None
    if not x:
        return jsonify({"error": "no such item"}), 404
    x["activity"] = _item_activity(sec, lvl, rid)
    return jsonify(x)


@bp.put("/api/agents/rules/<sec>/<lvl>/<rid>/procedure")
def save_procedure(sec, lvl, rid):
    """The admin's own edit of the procedure (the JSON): {procedure, admin, base_sha, code, project}. A changed procedure is a
    new version. Editing and coding work together (owner, 2026-11-09): code being made for the earlier text is stopped, and
    with code=true the Coder starts on the saved text at once (one request: 'Save and code it'). base_sha is the text the
    editor started from: when the procedure changed meanwhile (the Coder's change approved, another admin), nothing is
    saved and the answer says so (409), so nobody's change is overwritten without seeing it."""
    from agentic import procedures as PR
    body = request.get_json(force=True) or {}
    r = _rule_or_404(sec, lvl, rid)
    if not r:
        return jsonify({"error": "no such item"}), 404
    if body.get("code") and not body.get("project"):
        return jsonify({"error": "open an analysis first: the code is made for its recording"}), 400
    cur = PR.procedure_of(r)
    if body.get("base_sha") and cur and PR.sha(cur) != body["base_sha"]:
        return jsonify({"error": "the procedure was changed while you were editing it: it is now version %s (%s). Your text is kept in the "
                                 "editor: Load the current text to start from it, or save again to replace it with yours."
                                 % (cur.get("version", 0), cur.get("edited_by") or "?"),
                        "conflict": True, "current_sha": PR.sha(cur), "current_version": cur.get("version", 0)}), 409
    try:
        r, changed = PR.store(r, body.get("procedure"), admin_of(body), note="edited by %s" % admin_of(body))
    except ValueError as e:
        return jsonify({"error": "the procedure is not complete: %s" % e}), 400
    stopped = []
    if changed:
        family3.save_rule(r)
        # code being written, or waiting for review, belongs to the earlier text: that Code it run is stopped
        for rid_ in _coding_runs(sec, lvl, rid):
            engine().stop(rid_, admin_of(body), "the procedure was edited (version %d): its code is made for the new text" % r["procedure"]["version"])
            stopped.append(rid_)
    run, note = None, ""
    if body.get("code"):
        run, note = _start_coding(sec, lvl, rid, r, body)
    x = rule_evidence.explain(sec, lvl, rid, as_text(body.get("upload_id"), "upload_id") or None)
    x["activity"] = _item_activity(sec, lvl, rid)
    x["changed"], x["stopped_coding"], x["run"], x["coding_note"] = changed, stopped, run, note
    return jsonify(x)


@bp.delete("/api/agents/rules/<sec>/<lvl>/<rid>")
def delete_rule(sec, lvl, rid):
    """Delete an item (owner, 2026-11-09: "there can be rules which can be deleted"): {admin, why}. It leaves the list and is not
    offered or run any more; its rule file moves to the deleted items, from where Restore brings it back. Not while a Run of it,
    or a flow's step of it, is going; code being written for it is stopped."""
    body = request.get_json(force=True, silent=True) or {}
    r = _rule_or_404(sec, lvl, rid)
    if not r:
        return jsonify({"error": "no such item"}), 404
    eng = engine()
    key = "%s/%s/%s" % (sec, lvl, rid)
    for x in eng.store.all("SELECT id, params FROM run WHERE kind='rule_exec' AND state='running'"):
        p = core.jload(x["params"], {}) or {}
        if (p.get("section"), p.get("level"), p.get("id")) == (sec, lvl, rid):
            return jsonify({"error": "a Run of this item is going (run %d): wait for it to end, then delete it" % x["id"]}), 409
    busy = eng.store.one("SELECT s.run, r.target FROM step s JOIN run r ON r.id = s.run WHERE r.state='running' AND (s.key LIKE ? OR s.key LIKE ?) "
                         "AND s.state IN ('waiting', 'running', 'needs_review') LIMIT 1", ("f3:%s:%%" % key, "f3:%s#%%" % key))
    if busy:
        return jsonify({"error": "the flow '%s' (run %d) still has steps for this item: finish or stop that flow first" % (busy["target"], busy["run"])}), 409
    stopped = []
    for rid_ in _coding_runs(sec, lvl, rid):
        eng.stop(rid_, admin_of(body), "the item was deleted")
        stopped.append(rid_)
    try:
        entry = family3.delete_item(sec, lvl, rid, admin_of(body), as_text(body.get("why"), "why"))
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"deleted": entry, "stopped_coding": stopped, "deleted_items": family3.deleted_items()})


@bp.get("/api/agents/rules/deleted")
def deleted_rules():
    """The items deleted and not restored, newest first: name, section, level, who, when, why, where the file is kept."""
    return jsonify(family3.deleted_items())


@bp.post("/api/agents/rules/<sec>/<lvl>/<rid>/restore")
def restore_rule(sec, lvl, rid):
    """Restore a deleted item to its place in the list, as it was when deleted (its procedure, code and results). {admin}"""
    body = request.get_json(force=True, silent=True) or {}
    try:
        family3.rule_path(sec, lvl, rid)
        r = family3.restore_item(sec, lvl, rid, admin_of(body))
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"restored": {"section": sec, "level": lvl, "id": rid, "name": r.get("name")}, "deleted_items": family3.deleted_items()})


def _coding_runs(sec, lvl, rid):
    """The item's Code it runs still going (writing, or waiting for the admin's review)."""
    out = []
    for x in engine().store.all("SELECT id, params FROM run WHERE kind='rule_code' AND state='running' ORDER BY id"):
        p = core.jload(x["params"], {}) or {}
        if (p.get("section"), p.get("level"), p.get("id")) == (sec, lvl, rid):
            out.append(x["id"])
    return out


def _start_coding(sec, lvl, rid, r, body):
    """(run, note): the Coder starts on the item's procedure as it is now. Nothing new starts when code is already being made
    for this item (that run is given back) or the code of this version is verified."""
    from agentic import procedures as PR
    going = _coding_runs(sec, lvl, rid)
    if going:
        return going[-1], "code is already being made for this text"
    st = PR.code_state(r)
    if st["kind"] == "detector":
        return None, "this item runs the detector's own verified code: nothing to code"
    if st["kind"] == "none":
        return None, "write the procedure first (Edit rule/procedure)"
    if st.get("verified"):
        return None, "the code of this version is already verified"
    p = _project(whole(body.get("project"), "project")) or {}
    return engine().start(whole(body.get("project"), "project"), "rule_code", "Code it: " + r["name"],
                          {"_kind": "rule_code", "section": sec, "level": lvl, "id": rid, "upload_id": p.get("upload_id"),
                           "started_by": admin_of(body)}), ""


def _sample_args(sec, lvl, rid, max_count):
    """(path, file, columns or None, from line, count) of a samples request, or (None, error, code). Only the item's own
    source files, in the recording of the analysis, can be read."""
    from agentic import procedures as PR
    r = _rule_or_404(sec, lvl, rid)
    if not r:
        return None, "no such item", 404
    proc = PR.procedure_of(r) or {}
    srcs = {x["file"]: x["columns"] for x in proc.get("source_data") or []}
    f = request.args.get("file") or next(iter(srcs), "")
    if f not in srcs:
        return None, "not a source file of this item", 400
    path = PR.source_paths(request.args.get("upload") or "").get(f)
    if not path or not os.path.exists(path):
        return None, "this recording has no %s" % f, 404
    try:
        start, count = whole(request.args.get("from") or 2, "from"), whole(request.args.get("count") or 20, "count")
    except ValueError:
        return None, "the line and the number of records must be whole numbers", 400
    if start < 2 or count < 1:
        return None, "line 1 is the header: start at line 2 or later, and ask for at least 1 record", 400
    cols = None if request.args.get("all") == "1" else (srcs[f] or None)
    return (path, f, cols, start, min(count, max_count)), None, 200


@bp.get("/api/agents/rules/<sec>/<lvl>/<rid>/samples")
def rule_samples(sec, lvl, rid):
    """Samples of the item's source data as they are in the file: ?upload=&file=&from=<line>&count=<records>; the columns the
    procedure uses (the file's own line numbers: line 1 is the header)."""
    from agentic import procedures as PR
    a, err, code = _sample_args(sec, lvl, rid, PR.SAMPLE_MAX_SHOW)
    if err:
        return jsonify({"error": err}), code
    path, f, cols, start, count = a
    try:
        x = PR.sample_rows(path, cols, start, count)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify(dict(x, file=f, path=path, from_line=start, count=count, all_columns=cols is None))


@bp.get("/api/agents/rules/<sec>/<lvl>/<rid>/samples.csv")
def rule_samples_csv(sec, lvl, rid):
    """The same samples as a CSV file (UTF-8 with a byte order mark, opens in Excel): a 'line' column, then the columns the
    procedure uses, or every column with &all=1. Up to 100,000 records."""
    from nvme_hier.loader import CsvOut as _CsvOut
    import io
    from agentic import procedures as PR
    a, err, code = _sample_args(sec, lvl, rid, PR.SAMPLE_MAX_EXPORT)
    if err:
        return jsonify({"error": err}), code
    path, f, cols, start, count = a
    try:
        x = PR.sample_rows(path, cols, start, count)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    buf = io.StringIO()
    buf.write("\ufeff")
    w = _CsvOut(buf)
    w.writerow(x["header"])
    w.writerows(x["rows"])
    last = x["rows"][-1][0] if x["rows"] else start
    name = "%s_lines_%d-%d%s.csv" % (os.path.splitext(f)[0], start, last, "_all_columns" if cols is None else "")
    return Response(buf.getvalue(), mimetype="text/csv", headers={"Content-Disposition": 'attachment; filename="%s"' % name})


@bp.post("/api/agents/rules/<sec>/<lvl>/<rid>/code")
def code_rule(sec, lvl, rid):
    """Code it: the Coder writes the Python code of the item's procedure, the program checks it (it is not run), and the admin
    reviews it (the chime sounds). {project, admin}. When code is already being made for the item, that run is given back."""
    body = request.get_json(force=True) or {}
    r = _rule_or_404(sec, lvl, rid)
    if not r:
        return jsonify({"error": "no such item"}), 404
    if not body.get("project"):
        return jsonify({"error": "open an analysis first: the code is made for its recording"}), 400
    run, note = _start_coding(sec, lvl, rid, r, body)
    if not run:
        return jsonify({"error": note}), 409
    return jsonify({"run": run, "note": note})


@bp.post("/api/agents/rules/<sec>/<lvl>/<rid>/try")
def try_rule(sec, lvl, rid):
    """Try on a sample: the code waiting for review (or the verified code) on the first records of each source file only
    (header + N records), so it ends in seconds on any size. {review, records, upload_id} -> the output's first lines and
    the program's checks. Nothing is stored."""
    import tempfile
    from agentic import procedures as PR
    body = request.get_json(force=True) or {}
    r = _rule_or_404(sec, lvl, rid)
    if not r:
        return jsonify({"error": "no such item"}), 404
    code_file = None
    if body.get("review"):
        rv = engine().store.one("SELECT step FROM review WHERE id=?", (whole(body.get("review"), "review"),))
        st = engine().store.one("SELECT output FROM step WHERE id=?", (rv["step"],)) if rv else None
        code_file = (core.jload(st["output"], {}) or {}).get("code_file") if st else None
    else:
        code_file = (PR.code_state(r) or {}).get("path")
    base = os.path.realpath(os.path.join(family1.knowledge_dir(), "rules_code"))
    if not code_file or not os.path.realpath(code_file).startswith(base + os.sep) or not os.path.exists(code_file):
        return jsonify({"error": "no code to try"}), 404
    proc = PR.procedure_of(r)
    paths = PR.source_paths(as_text(body.get("upload_id"), "upload_id"))
    files = [x["file"] for x in proc["source_data"]]
    if any(f not in paths for f in files):
        return jsonify({"error": "the recording has no %s" % ", ".join(f for f in files if f not in paths)}), 404
    probs = PR.check_code(open(code_file).read(), tree=PR.uses_tree(proc))
    if probs:
        return jsonify({"error": "the code is refused before it runs: %s" % "; ".join(probs)}), 400
    n = max(1, min(whole(body.get("records") or PR.TRY_RECORDS, "records"), 100000))
    os.makedirs(os.path.join(APP, "runs", "agentic"), exist_ok=True)
    box = tempfile.mkdtemp(prefix="try_", dir=os.path.join(APP, "runs", "agentic"))
    try:
        src = PR.sample_sources({f: paths[f] for f in files}, os.path.join(box, "src"), records=n)
        res = PR.run_code(code_file, src, os.path.join(box, "out.csv"), os.path.join(box, "run"), timeout=PR.TRY_TIMEOUT_S)
        if not res.get("ok"):
            return jsonify({"error": "the code failed on the sample: %s" % res.get("error")}), 400
        cols, head, rows = PR.read_output(os.path.join(box, "out.csv"), head=50)
        checks = PR.output_checks(proc, cols, head, rows, res.get("summary"))
    finally:
        import shutil
        shutil.rmtree(box, ignore_errors=True)
    return jsonify({"records": n, "columns": cols, "head": head, "rows": rows, "checks": checks, "seconds": res.get("seconds"), "summary": res.get("summary")})


@bp.post("/api/agents/rules/<sec>/<lvl>/<rid>/run")
def exec_rule(sec, lvl, rid):
    """Run: the item's verified code on the recording, checked and exported as CSV (no review). {project, admin}"""
    from agentic import procedures as PR
    body = request.get_json(force=True) or {}
    r = _rule_or_404(sec, lvl, rid)
    if not r:
        return jsonify({"error": "no such item"}), 404
    if not body.get("project"):
        return jsonify({"error": "open an analysis first: the item runs on its recording"}), 400
    if not PR.code_state(r)["verified"]:
        return jsonify({"error": "there is no verified code for this procedure yet: press Code it and approve the code"}), 409
    p = _project(whole(body.get("project"), "project")) or {}
    run = engine().start(whole(body.get("project"), "project"), "rule_exec", "Run: " + r["name"],
                         {"_kind": "rule_exec", "section": sec, "level": lvl, "id": rid, "upload_id": p.get("upload_id"), "started_by": admin_of(body)})
    return jsonify({"run": run})


@bp.post("/api/agents/rules")
def add_rule():
    body = request.get_json(force=True) or {}
    family3.sync_sections()
    sec, lvl, name = body.get("section"), body.get("level"), as_text(body.get("name"), "name").strip()
    if not isinstance(sec, str) or not isinstance(lvl, str) or sec not in family3.SECTIONS or lvl not in family3.LEVELS or not name:
        return jsonify({"error": "give the section, the level and a name"}), 400
    r = family3.add_item(sec, lvl, name, as_text(body.get("description"), "description"), admin_of(body))
    out = {"rule": r}
    if body.get("project"):
        rid = engine().start(whole(body.get("project"), "project"), "rule_draft", r["name"],
                             {"_kind": "rule_draft", "section": sec, "level": lvl, "id": r["id"], "message": (body.get("description") or name)})
        out["run"] = rid
    return jsonify(out)


def _rule_or_404(sec, lvl, rid):
    try:
        return family3.load_rule(sec, lvl, rid)
    except ValueError:
        return None


@bp.get("/api/agents/rules/<sec>/<lvl>/<rid>")
def get_rule(sec, lvl, rid):
    r = _rule_or_404(sec, lvl, rid)
    if not r:
        return jsonify({"error": "no such item"}), 404
    code, problem = None, None
    try:
        code = family3.compile_rule(r)[0]
    except Exception as e:      # noqa: BLE001 - shown on the page
        problem = str(e)
    runs = engine().store.all("SELECT id, kind, state, created, summary FROM run WHERE kind IN ('rule_draft','rule_run') AND params LIKE ? ORDER BY id DESC LIMIT 10",
                              ('%%"id": "%s"%%' % rid,))
    return jsonify({"rule": r, "in_words": family3.describe(r), "code": code, "code_problem": problem, "runs": runs,
                    "section_label": family3.SECTIONS[sec], "level_label": family3.LEVEL_LABEL[lvl]})


@bp.post("/api/agents/rules/<sec>/<lvl>/<rid>/edit")
def edit_rule(sec, lvl, rid):
    body = request.get_json(force=True) or {}
    r = _rule_or_404(sec, lvl, rid)
    if not r:
        return jsonify({"error": "no such item"}), 404
    if not body.get("project"):
        return jsonify({"error": "open a project first (the start page)"}), 400
    run = engine().start(whole(body.get("project"), "project"), "rule_draft", r["name"],
                         {"_kind": "rule_draft", "section": sec, "level": lvl, "id": rid, "message": as_text(body.get("message"), "message").strip()})
    return jsonify({"run": run, "view": engine().view(run)})


@bp.post("/api/agents/rules/<sec>/<lvl>/<rid>/proceed")
def proceed_rule(sec, lvl, rid):
    body = request.get_json(force=True) or {}
    r = _rule_or_404(sec, lvl, rid)
    if not r:
        return jsonify({"error": "no such item"}), 404
    from agentic import procedures as PR
    if PR.code_state(r)["kind"] == "none":
        return jsonify({"error": "this item has no procedure yet: write it first"}), 409
    if not body.get("project"):
        return jsonify({"error": "open a project first (the start page)"}), 400
    run = engine().start(whole(body.get("project"), "project"), "rule_run", r["name"],
                         {"_kind": "rule_run", "section": sec, "level": lvl, "id": rid, "upload_id": as_text(body.get("upload_id"), "upload_id") or None})
    return jsonify({"run": run, "view": engine().view(run)})


@bp.get("/api/agents/file")
def get_file():
    try:
        p = os.path.realpath(request.args.get("path") or "")
    except (OSError, ValueError):            # a NUL byte in the path
        return jsonify({"error": "not an exported file"}), 404
    base = os.path.realpath(os.path.join(family1.knowledge_dir(), "exports"))
    if not p.startswith(base + os.sep) or not os.path.isfile(p):
        return jsonify({"error": "not an exported file"}), 404
    return send_file(p, as_attachment=p.endswith(".csv"))


@bp.get("/api/agents/projects/<int:pid>/join_rules")
def join_rules_of(pid):
    """The rules that combine the five files, with who checked each one for this project's file format."""
    from agentic import join_rules as JR
    p = engine().store.one("SELECT * FROM project WHERE id=?", (pid,))
    if not p:
        return jsonify({"error": "no such project"}), 404
    try:
        fmt, _files = family2.project_format(p)
        st = family2.last_strategy(fmt) or {}
    except (OSError, ValueError, TypeError):
        st = {}
    return jsonify(_join_rules_view(p, st))


def _join_rules_view(p, st):
    """Page 2's rules for one analysis: their words with the settings it builds with, who checked each, and the workbench (settings, notes, conversations, tries, the running try)."""
    from agentic import join_rules as JR, join_workbench as JW
    from api import hier_api as H
    eng = engine()
    eff = JW.effective(eng, p)
    wb = JW.load(eng, p["id"], p)
    tree = None
    uid, own = _tree_of(p)
    if uid:
        d = H.upload_dir(svc(), uid)
        m = H.read_meta(d) or {}
        tree = {"upload_id": uid, "own": own, "built_with": JR.settings_of(((m.get("result") or {}).get("build") or {}).get("settings")), "loaded": m.get("status") == "loaded"}
    job = None
    if wb.get("try_job"):
        j = svc().jobs.get(wb["try_job"])
        if j:
            job = {"id": j["id"], "status": j["status"], "progress": j.get("progress"), "error": (j.get("error") or "").split("\n")[0][:300]}
    return {"joins": JR.as_strategy(eff), "verified": st.get("verified") or {}, "needs_check": JR.needs_check(st.get("verified"), eff), "approved_version": st.get("version"),
            "settings": eff, "edited": bool(wb["settings"]), "approved_settings": JW.approved_settings(p), "notes": wb["notes"], "chat": wb["chat"], "tries": wb["tries"][-3:],
            "texts": {k: JW.current_text(p, k) for k in JR.BY_ID}, "text_versions": {k: len(JW.text_versions(p, k)) for k in JR.BY_ID},
            "paths": {"rules": {k: JW.text_dir(p, k) for k in JR.BY_ID}, "code": {k: JW.code_dir(p, k) for k in JR.BY_ID},
                      "analysis_file": JW._path(eng, p["id"]), "program": os.path.join(family2.APP, "nvme_hier", "builder.py")},
            "tree": tree, "try_job": job}


def _tree_of(p):
    """(upload id, its own?) of the loaded tree the rules of this analysis are tried and queried on: its own, or one already built from these same files
    (the flow reuses such a tree for its build too), so the agent can look at the data before this analysis's own build."""
    from api import hier_api as H
    if p.get("upload_id"):
        d = H.upload_dir(svc(), p["upload_id"])
        if d and os.path.exists(H.db_of(d)) and (H.read_meta(d) or {}).get("status") == "loaded":
            return p["upload_id"], True
    try:
        files = {f["level"]: f["path"] for f in family1.inventory(p.get("folder")) if f["level"]}
        up, _m = family2.find_built_tree(svc(), files, any_settings=True) if files else (None, None)
    except (OSError, ValueError):
        up = None
    return (up, False) if up else (None, False)


def _project_or_404(pid):
    p = engine().store.one("SELECT * FROM project WHERE id=?", (pid,))
    return p


def _strategy_of(p):
    try:
        fmt, _files = family2.project_format(p)
        return family2.last_strategy(fmt) or {}
    except (OSError, ValueError, TypeError):
        return {}


@bp.put("/api/agents/projects/<int:pid>/join_rules/settings")
def put_join_settings(pid):
    """body: {settings: {look_links, look_splits, look_cmds}, admin}. Kept for this analysis; the rules they change ask to be checked again. {} puts back the approved ones."""
    from agentic import join_workbench as JW
    body = request.get_json(force=True) or {}
    p = _project_or_404(pid)
    if not p:
        return jsonify({"error": "no such analysis"}), 404
    try:
        given = JW.check_settings(a_dict(body.get("settings"), "settings"))
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    wb = JW.load(engine(), pid)
    wb["settings"] = dict(wb["settings"], **given) if given else {}
    wb.setdefault("history", []).append({"at": time.time(), "by": admin_of(body), "settings": wb["settings"]})
    JW.save(engine(), pid, wb)
    return jsonify(_join_rules_view(p, _strategy_of(p)))


@bp.post("/api/agents/projects/<int:pid>/join_rules/try")
def try_join_settings(pid):
    """Builds this recording's tree again with the analysis's settings (body.settings are saved first) and compares how every rule held before and after."""
    from agentic import join_workbench as JW
    from api import hier_api as H
    body = request.get_json(force=True) or {}
    p = _project_or_404(pid)
    if not p:
        return jsonify({"error": "no such analysis"}), 404
    s = svc()
    uid, own = _tree_of(p)
    d = H.upload_dir(s, uid) if uid else None
    if not d:
        return jsonify({"error": "no tree of these files is built yet: approve the build on page 2 first, then try settings on its tree"}), 409
    if not own:                 # the tree built before from these same files becomes this analysis's tree, as the build step would reuse it
        engine().store.exec("UPDATE project SET upload_id=?, updated=? WHERE id=?", (uid, time.time(), pid))
    wb = JW.load(engine(), pid)
    if wb.get("try_job") and (s.jobs.get(wb["try_job"]) or {}).get("status") in ("queued", "running"):
        return jsonify({"error": "a try is already running for this analysis"}), 409
    for r in engine().store.all("SELECT id FROM run WHERE project=? AND state='running'", (pid,)):
        if engine().store.one("SELECT id FROM step WHERE run=? AND state='running' AND (key='build' OR key LIKE 'f3:%%' OR key IN ('code_tester','breaker','independent'))", (r["id"],)):
            return jsonify({"error": "a step of this analysis is using the tree now: wait until it waits for you, then try"}), 409
    try:
        given = JW.check_settings(a_dict(body.get("settings"), "settings"))
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    if given:
        wb["settings"] = dict(wb["settings"], **given)
    JW.save(engine(), pid, wb)
    eff = JW.effective(engine(), p)
    params = {"db": H.db_of(d), "upload_dir": d, "settings": eff, "project": pid, "admin": admin_of(body), "limit": family2.break_limit(s.cfg)}
    jid = s.jobs.create("join_try", {k: v for k, v in params.items()})
    params.update(_engine=engine(), _t0=time.time())
    s.jobs.start(jid, lambda j, _p, mgr: JW.try_settings(j, params, mgr))
    wb = JW.load(engine(), pid)
    wb["try_job"] = jid
    JW.save(engine(), pid, wb)
    return jsonify({"job": jid, "settings": eff, "view": _join_rules_view(p, _strategy_of(p))})


@bp.post("/api/agents/projects/<int:pid>/join_rules/<rule>/ask")
def ask_join_rule(pid, rule):
    """body: {message, admin}: one question about one rule; the agent may look at the recording through read-only queries."""
    from agentic import join_rules as JR, join_workbench as JW
    from api import hier_api as H
    body = request.get_json(force=True) or {}
    msg = as_text(body.get("message"), "message").strip()
    if not msg:
        return jsonify({"error": "write a question"}), 400
    p = _project_or_404(pid)
    if not p or rule not in JR.BY_ID:
        return jsonify({"error": "no such analysis or rule"}), 404
    uid, _own = _tree_of(p)
    d = H.upload_dir(svc(), uid) if uid else None
    db = H.db_of(d) if d and os.path.exists(H.db_of(d)) else None
    try:
        chat = JW.ask(engine(), p, rule, msg, admin_of(body), db)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"chat": chat})


@bp.put("/api/agents/projects/<int:pid>/join_rules/<rule>/text")
def text_join_rule(pid, rule):
    """body: {steps: [line, ...], check, when_broken: [line, ...], why, admin}: a new version of the admin's wording of one rule; steps [] goes back to the program's version."""
    from agentic import join_rules as JR, join_workbench as JW
    body = request.get_json(force=True) or {}
    p = _project_or_404(pid)
    if not p or rule not in JR.BY_ID:
        return jsonify({"error": "no such analysis or rule"}), 404
    try:
        program = next(j for j in JR.as_strategy(JW.effective(engine(), p)) if j["id"] == rule)
        path = JW.save_text(engine(), p, rule, body.get("steps"), as_text(body.get("check"), "check"), body.get("when_broken"), as_text(body.get("why"), "why"), admin_of(body),
                            program={"steps": program["steps"], "check": program["check"], "when_broken": program["when_broken"]})
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify(dict(_join_rules_view(p, _strategy_of(p)), saved=path))


@bp.put("/api/agents/projects/<int:pid>/join_rules/<rule>/note")
def note_join_rule(pid, rule):
    """body: {text, admin}: the admin's correction to a rule's logic, kept with this analysis and given to the research of the strategy."""
    from agentic import join_rules as JR, join_workbench as JW
    body = request.get_json(force=True) or {}
    p = _project_or_404(pid)
    if not p or rule not in JR.BY_ID:
        return jsonify({"error": "no such analysis or rule"}), 404
    text = as_text(body.get("text"), "text").strip()[:4000]
    wb = JW.load(engine(), pid)
    if text:
        wb["notes"][rule] = {"text": text, "by": admin_of(body), "at": time.time()}
    else:
        wb["notes"].pop(rule, None)
    JW.save(engine(), pid, wb)
    return jsonify(_join_rules_view(p, _strategy_of(p)))


# ---------------------------------------------------------------------------------------------- the side panel: talk to the data (owner, 2026-11-10)
def _chat_db(p):
    """(database path or None, what the panel is connected to, in words)."""
    from api import hier_api as H
    up, own = _tree_of(p)
    if not up:
        return None, {"tree": None, "words": "no tree of these files is built yet: the agents answer from what they know, without looking at the data"}
    d = H.upload_dir(svc(), up)
    return H.db_of(d), {"tree": up, "own": own, "words": "the tree of this recording (%s), read-only%s" % (up, "" if own else ", built before from the same files")}


def _open_item(page):
    """The rules item open on the page (for the rules agent): its name, procedure and the first rows of its last run."""
    key = (page or {}).get("item") or ""
    parts = key.split("/")
    if len(parts) != 3:
        return None
    try:
        r = family3.load_rule(*parts)
    except (ValueError, OSError):
        return None
    last = r.get("last_result") or {}
    return {"key": key, "name": r.get("name"), "section": parts[0], "level": parts[1], "procedure": r.get("procedure") or r.get("definition"),
            "last_run": {"columns": last.get("columns"), "rows": (last.get("head") or [])[:5], "lines": last.get("rows")} if last else None}


@bp.get("/api/agents/projects/<int:pid>/chat")
def chat_get(pid):
    from agentic import data_chat as DC
    p = _project_or_404(pid)
    if not p:
        return jsonify({"error": "no such analysis"}), 404
    agent = request.args.get("agent") or "data"
    if agent not in DC.AGENTS:
        return jsonify({"error": "the agent must be one of: %s" % ", ".join(DC.AGENTS)}), 400
    db, conn = _chat_db(p)
    if db:
        try:
            con = DC.open_ro(db)
            conn["rows"] = {DC.TABLES[k][1]: v for k, v in DC.table_sizes(con).items()}
            con.close()
        except sqlite3.Error as e:
            conn["error"] = str(e)[:200]
    conn["dictionaries"] = [{"file": d["file"], "columns": len(d["columns"]), "version": d.get("version")} for d in DC.dictionaries(p)]
    return jsonify({"agent": agent, "agents": DC.AGENTS, "turns": DC.turns(pid, agent), "connected": conn, "analysis": p.get("name"),
                    "limits": {"rows": DC.QUERY_ROWS, "seconds": DC.QUERY_SECONDS, "rounds": DC.MAX_ROUNDS, "queries": DC.MAX_QUERIES}})


@bp.post("/api/agents/projects/<int:pid>/chat")
def chat_post(pid):
    from agentic import data_chat as DC
    p = _project_or_404(pid)
    if not p:
        return jsonify({"error": "no such analysis"}), 404
    body = request.get_json(force=True) or {}
    agent = as_text(body.get("agent"), "agent") or "data"
    page = a_dict(body.get("page"), "page")
    page = {k: as_text(page.get(k), k)[:300] for k in ("title", "stage", "item", "review", "url") if page.get(k) not in (None, "")}
    db, _conn = _chat_db(p)
    try:
        new = DC.ask(engine(), p, db, agent, as_text(body.get("message"), "message"), admin_of(body), page, _open_item(page) if agent == "rules" else None)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"new": new, "turns": DC.turns(pid, agent)})


@bp.post("/api/agents/projects/<int:pid>/chat/clear")
def chat_clear(pid):
    from agentic import data_chat as DC
    p = _project_or_404(pid)
    if not p:
        return jsonify({"error": "no such analysis"}), 404
    agent = as_text((request.get_json(force=True) or {}).get("agent"), "agent") or "data"
    if agent not in DC.AGENTS:
        return jsonify({"error": "the agent must be one of: %s" % ", ".join(DC.AGENTS)}), 400
    DC.clear(pid, agent)
    return jsonify({"turns": []})
