"""NVMe-level hierarchy API: uploads of the five per-level exports, the load job, row browsing with filters.

An upload = one folder uploads/<upload id>/ holding meta.json (who, which trace, which device, when) and
hier.sqlite (the staged rows, one table per level, plus the tree links the builder fills in).
Only file paths are sent to the server (the files stay where they are), as for the stage-1 runs.
"""
import csv
import json
import os
import pathlib
import re
import sqlite3
import time
import uuid

from flask import Blueprint, jsonify, request

from . import svc

import sys
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
from nvme_hier import columns as C, loader as L, parse as P   # noqa: E402

bp = Blueprint("hier", __name__)
LEVELS = C.LEVEL_ORDER
TABLE = L.TABLE
FILTER_OPS = {"eq", "ne", "in", "contains", "gt", "lt", "ge", "le", "between", "blank", "notblank"}


def uploads_dir(s):
    d = os.path.join(s.root, "uploads")
    os.makedirs(d, exist_ok=True)
    return d


def upload_dir(s, uid):
    base = pathlib.Path(uploads_dir(s)).resolve()
    d = pathlib.Path(base, uid).resolve()
    if not d.is_relative_to(base) or d == base or not d.is_dir():
        return None
    return str(d)


def read_meta(d):
    p = os.path.join(d, "meta.json")
    if not os.path.exists(p):
        return None
    with open(p) as f:
        return json.load(f)


def write_meta(d, meta):
    with open(os.path.join(d, "meta.json"), "w") as f:
        json.dump(meta, f, indent=1)


def db_of(d):
    return os.path.join(d, "hier.sqlite")


# Indexes the browsing endpoints need beyond what the loader creates (the loader, builder and rules modules are not
# touched here). Each statement is a no-op when the index exists; they run when an upload is opened and after the
# rules re-run (rules.apply recreates the finding table, which drops its indexes).
BROWSE_INDEXES = [
    # relation alone (the "outside any command" list, the context packets of a parent)
    "CREATE INDEX IF NOT EXISTS ix_%(t)s_rel ON %(t)s (relation, parent_level, parent)",
    # findings by command and by severity+level (the per-level error check boxes, the defects list counts)
    "CREATE INDEX IF NOT EXISTS ix_finding_sev ON finding (severity, level, cmd_rowid)",
    "CREATE INDEX IF NOT EXISTS ix_finding_row ON finding (level, rowid, severity)",
]


def ensure_indexes(con):
    """CREATE INDEX IF NOT EXISTS for the browsing queries; nothing is cached in memory, SQLite keeps the index on disk."""
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    for stmt in BROWSE_INDEXES:
        if "%(t)s" in stmt:
            for t in TABLE.values():
                if t in tables:
                    con.execute(stmt % {"t": t})
        elif "finding" in tables:
            con.execute(stmt)
    con.commit()


# ---------------------------------------------------------------------------------------------- the load job
def run_hier_load(jid, params, mgr):
    d = params["upload_dir"]
    files = params["files"]
    done = {}

    sizes = {k: os.path.getsize(files[k]) for k in LEVELS if k in files and files[k] and os.path.exists(files[k])}
    total_bytes = max(1, sum(sizes.values()))
    bytes_before = {"n": 0}
    LOAD_SHARE = 82.0          # the load is most of the time; build 82-95, rules 95-99, browsing indexes 99-100

    class Cancelled(Exception):
        pass

    def progress(key, n, nbytes=None):
        if mgr.cancelled(jid):
            raise Cancelled()
        b = bytes_before["n"] + min(nbytes or 0, sizes.get(key, 0))
        pct = round(LOAD_SHARE * b / total_bytes, 1)
        mgr.progress(jid, "loading", "%s: %s rows read · %s of %s MB read" % (C.LEVEL_LABEL[key], "{:,}".format(n), "{:,}".format(b // 1000000), "{:,}".format(total_bytes // 1000000)),
                     pct, stats={"rows_" + key: n, "bytes_done": b, "bytes_total": total_bytes})
    reports = {}
    with mgr.span(jid, "load the files", {"files": list(files)}):
        con = L.open_db(db_of(d))
        for key in LEVELS:
            if key in files and files[key]:
                with mgr.span(jid, "load " + C.LEVEL_LABEL[key] + " file", {"path": files[key]}):
                    mgr.progress(jid, "loading", "%s: starting" % C.LEVEL_LABEL[key], round(LOAD_SHARE * bytes_before["n"] / total_bytes, 1))
                    try:
                        reports[key] = L.load_file(con, key, files[key], progress=progress)
                    except Cancelled:
                        con.close()
                        meta = read_meta(d) or {}
                        meta["status"] = "cancelled"
                        write_meta(d, meta)
                        raise RuntimeError("cancelled by the admin")
                    bytes_before["n"] += sizes.get(key, 0)
                    done[key] = reports[key]["rows"]
                    mgr.event(jid, "%s: %s rows, %d of %d named columns found, %d separator columns dropped" % (
                        C.LEVEL_LABEL[key], "{:,}".format(reports[key]["rows"]), reports[key]["found_named_columns"],
                        reports[key]["expected_named_columns"], reports[key]["separator_columns_dropped"]))
        L.set_meta(con, "load_reports", reports)
        L.set_meta(con, "levels_present", [k for k in LEVELS if k in reports])
        L.set_meta(con, "upload", {k: v for k, v in params.items() if k != "files"})
        con.close()
    result = {"reports": reports, "levels_present": [k for k in LEVELS if k in reports]}
    # the hierarchy build and the rules run here once those modules exist (builder.build, rules.apply)
    try:
        from nvme_hier import builder
    except ImportError:
        builder = None
    if builder is not None:
        with mgr.span(jid, "build the hierarchy"):
            seen = []

            def bprog(step, detail):
                if step not in seen:
                    seen.append(step)
                mgr.progress(jid, step, detail, round(82 + 13 * min(len(seen), 6) / 6.0, 1))
            mgr.progress(jid, "build the hierarchy", "starting", 82)
            result["build"] = builder.build(db_of(d), progress=bprog)
    try:
        from nvme_hier import rules
    except ImportError:
        rules = None
    if rules is not None:
        with mgr.span(jid, "apply the rules"):
            seen_r = []

            def rprog(step, detail):
                if step not in seen_r:
                    seen_r.append(step)
                mgr.progress(jid, step, detail, round(95 + 4 * min(len(seen_r), 8) / 8.0, 1))
            mgr.progress(jid, "apply the rules", "starting", 95)
            result["rules"] = rules.apply(db_of(d), params.get("thresholds") or {}, progress=rprog)
    with mgr.span(jid, "index for browsing"):
        mgr.progress(jid, "index for browsing", "creating the browsing indexes", 99)
        con = sqlite3.connect(db_of(d))
        ensure_indexes(con)
        con.close()
    mgr.progress(jid, "done", "loaded, built, rules applied", 100)
    meta = read_meta(d) or {}
    meta["status"] = "loaded"
    meta["result"] = result
    meta["loaded_at"] = time.time()
    write_meta(d, meta)
    return result


# ---------------------------------------------------------------------------------------------- endpoints
ENV_FILE = os.environ.get("F2T_ENV_FILE") or os.path.join(os.path.expanduser("~"), ".config", "f2t", "env")


def _model_state(s):
    l = s.cfg.get("llm") or {}
    var = l.get("api_key_env") or "ANTHROPIC_API_KEY"
    return {"backend": l.get("backend"), "model": l.get("model"), "base_url": l.get("base_url") or "", "api_key_env": var,
            "key_present": bool(os.environ.get(var) or os.environ.get("ANTHROPIC_API_KEY")), "env_file": ENV_FILE,
            "active": getattr(s.s2.llm, "name", "stand-in"), "locked": bool((s.cfg.get("server") or {}).get("lock_endpoint")),
            "retries": {"tries": 4, "first_pause_s": 2.0, "note": "transient failures are retried 4 times with pauses of 2, 4 and 8 seconds; a wrong key is reported at once"}}


@bp.get("/api/hier/model")
def model_get():
    """The model connection as the settings page shows it: where the calls go, which model, which environment
    variable holds the key (never the key itself), and whether a key is present."""
    return jsonify(_model_state(svc()))


@bp.put("/api/hier/model")
def model_put():
    """body: {base_url?, model?, api_key_env?, key?}. The key is written to the private environment file (mode 600,
    outside the project) and put into this process's environment; it is never stored in the config file."""
    s = svc()
    body = request.get_json(force=True) or {}
    if (s.cfg.get("server") or {}).get("lock_endpoint") and any(k in body for k in ("base_url", "api_key_env", "key")):
        return jsonify({"error": "the model endpoint and key are locked by server.lock_endpoint: stop the service, edit the config and the environment file, start it again"}), 403
    l = s.cfg.setdefault("llm", {})
    for k in ("base_url", "model", "api_key_env"):
        if k in body and body[k] is not None:
            l[k] = str(body[k]).strip()
    if l.get("backend") in (None, "", "auto", "sdk", "cli"):
        l["backend"] = "http"
    key = (body.get("key") or "").strip()
    written = False
    if key:
        var = l.get("api_key_env") or "ANTHROPIC_API_KEY"
        os.environ[var] = key
        if var != "ANTHROPIC_API_KEY":
            os.environ["ANTHROPIC_API_KEY"] = key
        try:
            os.makedirs(os.path.dirname(ENV_FILE), exist_ok=True)
            lines = []
            if os.path.exists(ENV_FILE):
                lines = [ln for ln in open(ENV_FILE).read().splitlines() if ln and not ln.startswith(var + "=")]
            lines.append("%s=%s" % (var, key))
            with open(ENV_FILE, "w") as fh:
                fh.write("\n".join(lines) + "\n")
            os.chmod(ENV_FILE, 0o600)
            written = True
        except OSError as e:
            return jsonify({"error": "the key could not be written to %s: %s" % (ENV_FILE, e)}), 500
    if l.get("base_url"):
        os.environ["ANTHROPIC_BASE_URL"] = l["base_url"]
    elif "base_url" in body:
        os.environ.pop("ANTHROPIC_BASE_URL", None)
    from .config_api import save_config
    save_config(s.cfg)
    s.s2.reload_llm()
    st = _model_state(s)
    st["key_written_to_env_file"] = written
    return jsonify(st)


@bp.post("/api/hier/model/test")
def model_test():
    """One small call to the model with the current settings; reports who answered, how long it took and how many
    tries were needed, or the error after the last try."""
    s = svc()
    llm = s.s2.llm
    name = getattr(llm, "name", "stand-in")
    if name in ("standin", "stand-in"):
        return jsonify({"ok": False, "producer": name, "error": "no model is configured: " + ("no key is present" if not _model_state(s)["key_present"] else "the backend is the stand-in")})
    before = dict(getattr(llm, "usage", {}) or {})
    t0 = time.time()
    try:
        out = llm.generate_json("Answer with a JSON object whose field ok is the text yes.", {"type": "object", "properties": {"ok": {"type": "string"}}, "required": ["ok"]})
    except Exception as e:      # noqa: BLE001
        return jsonify({"ok": False, "producer": name, "error": str(e)[:300], "seconds": round(time.time() - t0, 1)})
    if isinstance(out, tuple):
        out = out[0]
    after = dict(getattr(llm, "usage", {}) or {})
    tries = 1 + (after.get("retries", 0) - before.get("retries", 0))
    if isinstance(out, dict) and out.get("_error"):
        return jsonify({"ok": False, "producer": name, "error": out["_error"], "tries": tries, "seconds": round(time.time() - t0, 1)})
    return jsonify({"ok": True, "producer": name, "answer": out, "tries": tries, "seconds": round(time.time() - t0, 1)})


@bp.get("/api/hier/browse")
def browse():
    """Folders and CSV files on this machine for the upload page's file picker. Any folder can be opened: nothing is
    refused on the ground of where it lies (owner's rule, 2026-11-03). ?path=<folder>; empty = the starting points
    (shortcuts: home, /, /mnt, /media, /tmp and the configured folders). Each CSV gets the level its header looks like."""
    s = svc()
    starts = []
    for x in [os.path.expanduser("~"), "/", "/mnt", "/media", "/tmp"] + [str(r) for r in s.roots]:
        if os.path.isdir(x) and x not in starts:
            starts.append(x)
    raw = (request.args.get("path") or "").strip().strip('"').strip("'")
    if not raw:
        return jsonify({"path": "", "parent": None, "roots": starts, "dirs": [{"name": r, "path": r} for r in starts], "files": []})
    rp = os.path.realpath(os.path.expanduser(raw))
    if os.path.isfile(rp):
        rp = os.path.dirname(rp)
    if not os.path.isdir(rp):
        return jsonify({"error": "not a folder: %s" % rp, "roots": starts}), 400
    dirs, files = [], []
    try:
        names = sorted(os.listdir(rp), key=str.lower)
    except OSError as e:
        return jsonify({"error": "cannot read the folder: %s" % e, "roots": starts}), 400
    for n in names:
        if n.startswith("."):
            continue
        fp = os.path.join(rp, n)
        try:
            if os.path.isdir(fp):
                dirs.append({"name": n, "path": fp})
            elif n.lower().endswith((".csv", ".txt")):
                st = os.stat(fp)
                level = None
                try:
                    with open(fp, newline="", encoding="utf-8", errors="replace") as fh:
                        header = next(csv.reader(fh), [])
                    level = L.guess_level(header)
                except Exception:          # noqa: BLE001 - a file we cannot read is listed without a level
                    level = None
                files.append({"name": n, "path": fp, "bytes": st.st_size, "modified": time.strftime("%Y-%m-%d %H:%M", time.localtime(st.st_mtime)),
                              "level": level, "level_label": C.LEVEL_LABEL.get(level) if level else None})
        except OSError:
            continue
    parent = os.path.dirname(rp) if rp != "/" else None
    return jsonify({"path": rp, "parent": parent, "roots": starts, "dirs": dirs, "files": files})


@bp.post("/api/hier/sniff")
def sniff():
    """Header + first rows of one file and the level it looks like, for the upload page."""
    s = svc()
    body = request.get_json(force=True) or {}
    path, err = s.safe_path(body.get("path"))
    if err:
        return jsonify({"error": err}), 400
    header, rows = L.sniff(path, 3)
    level = L.guess_level(header)
    rep = None
    if level:
        al = L.align_header(level, header, L.prescan_values(path, L.ambiguous_columns(level, header), max_rows=20000))
        rep = al.report(level)
    return jsonify({"path": path, "bytes": os.path.getsize(path), "columns_in_file": len(header), "level": level,
                    "level_label": C.LEVEL_LABEL.get(level), "header_check": rep,
                    "first_rows": [[c[:40] for c in r[:12]] for r in rows]})


@bp.post("/api/hier/uploads")
def create_upload():
    s = svc()
    body = request.get_json(force=True) or {}
    files = {}
    for key in LEVELS:
        p = (body.get("files") or {}).get(key)
        if p:
            path, err = s.safe_path(p)
            if err:
                return jsonify({"error": "%s: %s" % (C.LEVEL_LABEL[key], err)}), 400
            files[key] = path
    if not files:
        return jsonify({"error": "give at least one of the five files"}), 400
    device = (body.get("device") or "").strip()
    if not device:
        return jsonify({"error": "the drive under test is required (its name is stored with the upload, with every decision and with every stored signature)"}), 400
    operator = (body.get("operator") or "").strip() or "admin"      # the owner's rule of 2026-11-03: no admin name at the start; "admin" is the default
    uid = time.strftime("up-%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:4]
    d = os.path.join(uploads_dir(s), uid)
    os.makedirs(d, exist_ok=True)
    meta = {"upload_id": uid, "created": time.time(), "operator": operator, "device": device,
            "trace_name": (body.get("trace_name") or "").strip(), "recording_date": (body.get("recording_date") or "").strip(),
            "notes": (body.get("notes") or "").strip(), "files": files, "status": "loading",
            "thresholds": body.get("thresholds") or {}}
    write_meta(d, meta)
    params = {"upload_id": uid, "upload_dir": d, "files": files, "operator": operator, "device": meta["device"],
              "trace_name": meta["trace_name"], "recording_date": meta["recording_date"], "thresholds": meta["thresholds"]}
    jid = s.jobs.submit("hier_load", params, run_hier_load)
    meta["job"] = jid
    write_meta(d, meta)
    return jsonify({"upload_id": uid, "job": jid})


def settle_status(s, d, m):
    """A load that was cut off (the server stopped while loading) must not stay 'loading' forever: the job manager marks
    such jobs failed at start-up; here the upload gets status 'interrupted' with the reason, so the page can offer 'load again'."""
    if m.get("status") == "loading" and m.get("job"):
        job = s.jobs.get(m["job"])
        if job is None or job["status"] in ("failed", "cancelled"):
            m["status"] = "interrupted"
            m["error"] = (job or {}).get("error") or "the load job no longer exists (the server was stopped while loading)"
            write_meta(d, m)
    return m


@bp.get("/api/hier/uploads")
def list_uploads():
    s = svc()
    out = []
    for name in sorted(os.listdir(uploads_dir(s)), reverse=True):
        d = upload_dir(s, name)
        if not d:
            continue
        m = read_meta(d)
        if m:
            m = settle_status(s, d, m)
            row = {k: m.get(k) for k in ("upload_id", "created", "operator", "device", "trace_name", "recording_date",
                                          "status", "job", "loaded_at", "error", "notes")}
            row.update({"files": list((m.get("files") or {}).keys()), "file_paths": m.get("files") or {}})
            if m.get("status") == "loading" and m.get("job"):
                job = s.jobs.get(m["job"])
                row["progress"] = (job or {}).get("progress")
            out.append(row)
    return jsonify(out)


@bp.get("/api/hier/uploads/<uid>")
def get_upload(uid):
    s = svc()
    d = upload_dir(s, uid)
    if not d:
        return jsonify({"error": "no such upload"}), 404
    m = settle_status(s, d, read_meta(d) or {})
    job = s.jobs.get(m.get("job")) if m.get("job") else None
    m["job_status"] = job["status"] if job else None
    m["job_progress"] = job["progress"] if job else None
    m["job_error"] = job["error"] if job else None
    m["job_spans"] = job["spans"] if job else None
    if os.path.exists(db_of(d)):
        con = sqlite3.connect(db_of(d))
        try:
            if m.get("status") == "loaded":
                ensure_indexes(con)          # upload-open time: the browsing indexes, if an older load lacks them
            m["levels_present"] = L.get_meta(con, "levels_present", [])
            m["load_reports"] = L.get_meta(con, "load_reports", {})
            m["build"] = L.get_meta(con, "build", None)
            m["rules"] = L.get_meta(con, "rules", None)
            counts = {}
            for key in m["levels_present"]:
                counts[key] = con.execute("SELECT COUNT(*) FROM %s" % TABLE[key]).fetchone()[0]
            m["row_counts"] = counts
        except sqlite3.Error:
            pass
        con.close()
    return jsonify(m)


@bp.delete("/api/hier/uploads/<uid>")
def delete_upload(uid):
    s = svc()
    d = upload_dir(s, uid)
    if not d:
        return jsonify({"error": "no such upload"}), 404
    import shutil
    m = read_meta(d) or {}
    if m.get("status") == "loading" and m.get("job"):
        s.jobs.cancel(m["job"])          # the load thread stops at its next progress report and then the folder goes
        for _ in range(300):
            j = s.jobs.get(m["job"])
            if not j or j["status"] != "running":
                break
            time.sleep(0.2)
    shutil.rmtree(d, ignore_errors=True)
    return jsonify({"deleted": uid})


@bp.get("/api/hier/uploads/<uid>/columns")
def columns_of(uid):
    """Columns of one level for the filter bar: the typed key columns (with their SQL type) and every named
    column of the file (filterable through the raw JSON)."""
    s = svc()
    d = upload_dir(s, uid)
    level = request.args.get("level")
    if not d or level not in LEVELS:
        return jsonify({"error": "no such upload or level"}), 404
    typed = {}
    for cname, sql, fn in L.KEYS[level]:
        typed.setdefault(sql, {"sql": sql, "names": [], "kind": "text" if sql in L.TEXT_COLS else "number"})
        typed[sql]["names"].append(cname)
        if sql in ("t_ps", "delta_ps", "dur_ps"):
            typed[sql]["kind"] = "time"
    out = {"level": level, "label": C.LEVEL_LABEL[level], "typed": list(typed.values()),
           "all_columns": C.canonical_names(level), "plain": C.PLAIN}
    return jsonify(out)


def _where(level, filters):
    """filters: [{column, op, value}] -> (sql, args). column = canonical name or a typed sql column."""
    typed = {}
    for cname, sql, fn in L.KEYS[level]:
        typed[cname] = sql
        typed[sql] = sql
    clauses, args = [], []
    for f in filters or []:
        col = f.get("column")
        op = f.get("op")
        val = f.get("value")
        if not col or op not in FILTER_OPS:
            continue
        if col in typed:
            expr = typed[col]
            numeric = expr not in L.TEXT_COLS
        else:
            if col not in C.canonical_names(level):
                continue
            expr = "json_extract(raw, ?)"
            args.append('$."%s"' % col.replace('"', ""))      # names hold spaces and dots: quote the key
            numeric = False
            if op in ("gt", "lt", "ge", "le", "between"):
                expr = "CAST(%s AS REAL)" % expr
                numeric = True
        if op == "blank":
            clauses.append("(%s IS NULL OR %s = '')" % (expr, expr))
        elif op == "notblank":
            clauses.append("(%s IS NOT NULL AND %s != '')" % (expr, expr))
        elif op == "eq":
            clauses.append("%s = ?" % expr)
            args.append(val)
        elif op == "ne":
            clauses.append("%s != ?" % expr)
            args.append(val)
        elif op == "in":
            vals = val if isinstance(val, list) else [v.strip() for v in str(val).split(",") if v.strip()]
            if vals:
                clauses.append("%s IN (%s)" % (expr, ",".join("?" * len(vals))))
                args.extend(vals)
        elif op == "contains":
            clauses.append("%s LIKE ?" % expr)
            args.append("%" + str(val) + "%")
        elif op in ("gt", "lt", "ge", "le"):
            clauses.append("%s %s ?" % (expr, {"gt": ">", "lt": "<", "ge": ">=", "le": "<="}[op]))
            args.append(val)
        elif op == "between":
            lo, hi = (val or [None, None])[:2]
            if lo is not None:
                clauses.append("%s >= ?" % expr)
                args.append(lo)
            if hi is not None:
                clauses.append("%s <= ?" % expr)
                args.append(hi)
    return (" AND ".join(clauses) if clauses else "1=1"), args


def _scope(level, args):
    """The WHERE of one browsing request: column filters + tree position (parent / top / relation) + the five
    per-level error check boxes (finding_at). Returns (where, args) or raises ValueError."""
    try:
        filters = json.loads(args.get("filters") or "[]")
    except ValueError:
        raise ValueError("filters must be a JSON list")
    where, a = _where(level, filters)
    if args.get("parent"):
        where += " AND parent_level = ? AND parent = ?"
        a += [args.get("parent_level"), int(args.get("parent"))]
    elif args.get("top") == "1":
        # both columns are NULL for a row without a parent, so the (parent_level, parent) index serves this
        where += " AND parent IS NULL"      # command rows have no parent; orphans keep their parent_level but no parent
    if args.get("relation"):
        where += " AND relation = ?"
        a.append(args.get("relation"))
    # the five level filters: commands whose subtree holds an error finding at the given level(s)
    fa = [x for x in (args.get("finding_at") or "").split(",") if x in LEVELS]
    if fa and level == "nvme_command":
        where += " AND rowid_file IN (SELECT cmd_rowid FROM finding WHERE severity='error' AND level IN (%s))" % ",".join("?" * len(fa))
        a += fa
    elif fa:
        where += " AND rowid_file IN (SELECT rowid FROM finding WHERE severity='error' AND level=? AND level IN (%s))" % ",".join("?" * len(fa))
        a += [level] + fa
    return where, a


def _page(args, default_limit=200, max_limit=2000):
    """Paging parameters. Keyset (after / before = a rowid_file) walks the rows in file order without an OFFSET
    scan, which is what the scrolling lists use; offset stays for sorted or random access. count=0 skips the
    COUNT(*) on follow-up pages (the browser keeps the total of the first page)."""
    offset = max(0, int(args.get("offset") or 0))
    limit = max(1, min(int(args.get("limit") or default_limit), max_limit))
    after = int(args["after"]) if args.get("after") not in (None, "") else None
    before = int(args["before"]) if args.get("before") not in (None, "") else None
    want_count = args.get("count", "1") != "0"
    return offset, limit, after, before, want_count


def _rows_out(cur):
    """Only the rows of this page are turned into dicts and only their raw JSON is parsed."""
    out = []
    for r in cur:
        row = dict(r)
        row["raw"] = json.loads(row["raw"]) if row.get("raw") else {}
        for k in ("t_ps", "delta_ps", "dur_ps"):
            if row.get(k) is not None:
                row[k + "_text"] = P.fmt_ps(row[k])
        out.append(row)
    return out


@bp.get("/api/hier/uploads/<uid>/rows")
def rows(uid):
    """Rows of one level, one page at a time (the browser scrolls through them; nothing is held server side).
    parent_level + parent select the children of one row (the tree); top=1 selects the rows with no parent (the
    top of the tree, or the rows outside any command when level is not the command level).
    filters = JSON list; after / before = keyset paging by rowid_file (file order); offset/limit = positional
    paging; sort = sql column (offset paging only); count=0 skips the total."""
    s = svc()
    d = upload_dir(s, uid)
    level = request.args.get("level")
    if not d or level not in LEVELS or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload or level"}), 404
    t = TABLE[level]
    try:
        where, args = _scope(level, request.args)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    offset, limit, after, before, want_count = _page(request.args, default_limit=100)
    sort = request.args.get("sort") or "rowid_file"
    if sort not in ("rowid_file", "t_ps", "delta_ps", "dur_ps", "n") and sort not in {s2 for _, s2, _ in L.KEYS[level]}:
        sort = "rowid_file"
    desc = " DESC" if request.args.get("desc") == "1" else ""
    con = sqlite3.connect(db_of(d))
    con.row_factory = sqlite3.Row
    try:
        total = con.execute("SELECT COUNT(*) FROM %s WHERE %s" % (t, where), args).fetchone()[0] if want_count else None
        if after is not None and sort == "rowid_file" and not desc:
            cur = con.execute("SELECT * FROM %s WHERE %s AND rowid_file > ? ORDER BY rowid_file LIMIT ?" % (t, where), args + [after, limit])
            out = _rows_out(cur)
        elif before is not None and sort == "rowid_file" and not desc:
            cur = con.execute("SELECT * FROM %s WHERE %s AND rowid_file < ? ORDER BY rowid_file DESC LIMIT ?" % (t, where), args + [before, limit])
            out = _rows_out(cur)[::-1]
        else:
            cur = con.execute("SELECT * FROM %s WHERE %s ORDER BY %s%s LIMIT ? OFFSET ?" % (t, where, sort, desc), args + [limit, offset])
            out = _rows_out(cur)
    except sqlite3.Error as e:
        con.close()
        return jsonify({"error": "query failed: %s" % e}), 400
    con.close()
    return jsonify({"level": level, "label": C.LEVEL_LABEL[level], "total": total, "offset": offset, "limit": limit, "rows": out,
                    "first_key": out[0]["rowid_file"] if out else None, "last_key": out[-1]["rowid_file"] if out else None,
                    "has_more": len(out) == limit})


# the summary table (page 2): one aggregate row per NVMe command, computed in SQL, paged like the tree
SUMMARY_COLS = ["rowid_file", "n", "opc", "sqid", "cqid", "cid", "nsid", "slba", "nlb", "nbytes", "fua", "sct", "sc", "n_ntx",
                "delta_ps", "t_ps", "dur_ps", "errors", "warnings", "errors2", "cns", "fid", "lid", "ad", "nr", "relation",
                "n_findings", "n_sub_findings", "cause_level", "cause_rule", "role"]


@bp.get("/api/hier/uploads/<uid>/summary")
def summary(uid):
    """One line per NVMe command for the summary table (c1 command, c2 parameters, c3 time, c4 errors, lower levels),
    as a SQL projection + aggregate (the error findings per level inside the command's subtree), never the raw JSON.
    Same filters, finding_at and paging (after / before / offset, count=0) as the rows endpoint; totals for the
    whole selection come with the first page."""
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    con = sqlite3.connect(db_of(d))
    con.row_factory = sqlite3.Row
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if "cmd" not in tables:
        con.close()
        return jsonify({"error": "the summary needs the NVMe command file"}), 400
    have = {r[1] for r in con.execute("PRAGMA table_info(cmd)")}
    cols = [c for c in SUMMARY_COLS if c in have]
    sel = ", ".join("c.%s" % c for c in cols)
    if "finding" in tables:
        sel += (", (SELECT GROUP_CONCAT(level || ':' || k, ',') FROM (SELECT level, COUNT(*) AS k FROM finding f "
                "WHERE f.cmd_rowid = c.rowid_file AND f.severity = 'error' GROUP BY level)) AS findings_by_level")
    args_in = request.args.to_dict()
    args_in.setdefault("top", "1")
    try:
        where, args = _scope("nvme_command", args_in)
    except ValueError as e:
        con.close()
        return jsonify({"error": str(e)}), 400
    offset, limit, after, before, want_count = _page(request.args, default_limit=200)
    try:
        totals = None
        if want_count:
            err_expr = " OR ".join(x for x in [
                "(c.errors IS NOT NULL AND c.errors != '')", "(c.sc IS NOT NULL AND c.sc != 0)",
                "c.n_findings > 0" if "n_findings" in have else "", "c.n_sub_findings > 0" if "n_sub_findings" in have else ""] if x)
            r = con.execute("SELECT COUNT(*), SUM(CASE WHEN %s THEN 1 ELSE 0 END), SUM(c.n_ntx), MAX(c.dur_ps), AVG(c.dur_ps) FROM cmd c WHERE %s"
                            % (err_expr, where), args).fetchone()
            totals = {"commands": r[0], "commands_with_errors": r[1] or 0, "nvme_transactions": r[2] or 0,
                      "longest_ps": r[3], "longest_text": P.fmt_ps(r[3]) if r[3] is not None else None,
                      "mean_ps": int(r[4]) if r[4] is not None else None, "mean_text": P.fmt_ps(int(r[4])) if r[4] is not None else None}
        if after is not None:
            cur = con.execute("SELECT %s FROM cmd c WHERE %s AND c.rowid_file > ? ORDER BY c.rowid_file LIMIT ?" % (sel, where), args + [after, limit])
            out = [dict(r) for r in cur]
        elif before is not None:
            cur = con.execute("SELECT %s FROM cmd c WHERE %s AND c.rowid_file < ? ORDER BY c.rowid_file DESC LIMIT ?" % (sel, where), args + [before, limit])
            out = [dict(r) for r in cur][::-1]
        else:
            cur = con.execute("SELECT %s FROM cmd c WHERE %s ORDER BY c.rowid_file LIMIT ? OFFSET ?" % (sel, where), args + [limit, offset])
            out = [dict(r) for r in cur]
    except sqlite3.Error as e:
        con.close()
        return jsonify({"error": "query failed: %s" % e}), 400
    con.close()
    for row in out:
        for k in ("t_ps", "delta_ps", "dur_ps"):
            if row.get(k) is not None:
                row[k + "_text"] = P.fmt_ps(row[k])
        fb = {}
        for part in (row.pop("findings_by_level", None) or "").split(","):
            if ":" in part:
                lv, k = part.rsplit(":", 1)
                fb[lv] = int(k)
        row["findings_by_level"] = fb
    return jsonify({"total": totals["commands"] if totals else None, "totals": totals, "offset": offset, "limit": limit, "rows": out,
                    "first_key": out[0]["rowid_file"] if out else None, "last_key": out[-1]["rowid_file"] if out else None,
                    "has_more": len(out) == limit, "level_labels": C.LEVEL_LABEL})


@bp.get("/api/hier/uploads/<uid>/thresholds")
def get_thresholds(uid):
    s = svc()
    d = upload_dir(s, uid)
    if not d:
        return jsonify({"error": "no such upload"}), 404
    return jsonify((read_meta(d) or {}).get("thresholds") or {})


@bp.put("/api/hier/uploads/<uid>/thresholds")
def set_thresholds(uid):
    """thresholds: {level: {"value": number, "unit": "ns|us|ms|s", "source": text}}; stored in picoseconds too."""
    s = svc()
    d = upload_dir(s, uid)
    if not d:
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    th = {}
    for level, v in body.items():
        if level in TIMING_LEVELS and v is None:
            th[level] = None              # page 3's "timing at this level is not considered" stays as it is
            continue
        if level not in LEVELS or not isinstance(v, dict):
            continue
        unit = v.get("unit", "ms")
        if unit not in P.UNIT_PS or v.get("value") in (None, ""):
            continue
        th[level] = {"value": float(v["value"]), "unit": unit, "ps": int(float(v["value"]) * P.UNIT_PS[unit]),
                     "source": (v.get("source") or "set by the admin").strip()}
    meta = read_meta(d) or {}
    if meta.get("status") == "loading" and body.get("rerun", True):
        return jsonify({"error": "this upload is still loading; change the limits when the load report is shown"}), 409
    meta["thresholds"] = th
    write_meta(d, meta)
    out = {"thresholds": th}
    if os.path.exists(db_of(d)) and body.get("rerun", True):
        from nvme_hier import rules
        out["rules"] = rules.apply(db_of(d), th)
        con = sqlite3.connect(db_of(d))
        ensure_indexes(con)
        con.close()
    return jsonify(out)


# ---------------------------------------------------------------------------------------------- page 3: the defect table and the two timing limits
from nvme_hier import rules as _RL   # noqa: E402

DT_COLS = ["rowid_file", "n", "opc", "sqid", "cqid", "cid", "nsid", "slba", "nlb", "nbytes", "fua", "sct", "sc", "st", "n_ntx", "delta_ps", "t_ps", "dur_ps",
           "errors", "warnings", "cns", "fid", "lid", "ad", "nr", "qid", "qsize", "relation", "n_findings", "n_sub_findings", "cause_level", "cause_rule", "role"]
# a command has an error on page 3 when a rule of severity error fired at the NVMe transaction level or the NVMe command level
# inside it (the NVMe-transaction timing rule is one of them), or a link transaction under it is at or over the link limit
DT_DEFECT = "((f.level IN ('nvme_transaction', 'nvme_command') AND f.severity = 'error') OR f.rule = 'lnk.response_over_limit')"
DT_SEV_ORDER = "CASE f.severity WHEN 'error' THEN 0 WHEN 'check' THEN 1 ELSE 2 END"
LINK_RULE = "lnk.response_over_limit"
NTX_RULE = "ntx.over_limit"
TIMING_LEVELS = ("link", "nvme_transaction")
LIMIT_UNITS = ("ns", "us", "ms", "s")
DT_FILTERS = ("all", "error", "no_error")
# the rule in words, for the evidence line of column 4 (the finding's name carries the measured facts)
RULE_WORDS = {
    "cmd.status_error": "the drive answered the command with an error status", "cmd.analyzer_error": "the analyzer's error cell of the command is not empty",
    "cmd.analyzer_warning": "the analyzer's warning cell of the command is not empty", "cmd.incomplete": "the command never completed",
    "cmd.not_fetched": "the submission entry was never fetched", "cmd.doorbell_missing": "no submission doorbell write was seen for the command",
    "cmd.no_interrupt": "the command completed without an interrupt write", "cmd.latency_over_limit": "the command took longer than the command limit",
    "cmd.bytes_short": "fewer data bytes moved than the command asked for", "cmd.write_zeroes_readback": "a read of a range cleared by Write Zeroes",
    "cmd.deallocate_readback": "a read of a range deallocated earlier", "ntx.analyzer_error": "the analyzer's error cell of the transaction is not empty",
    "ntx.analyzer_warning": "the analyzer's warning cell of the transaction is not empty", "ntx.status_error": "the completion entry carries an error status",
    "ntx.over_limit": "an NVMe transaction took longer than the NVMe-transaction limit", "ntx.phase_wrong": "the completion entry carries the wrong phase bit",
    "ntx.interrupt_before_completion": "the interrupt was written before the completion entry it announces",
    "ntx.completion_unknown_command": "a completion entry for a command id that is not open", "lnk.response_over_limit": "a link transaction under this command took longer than the link limit",
}
MEASURED = {"link": "from the TLP to the Ack or Nak that answered it", "nvme_transaction": "from the transaction's first packet to its last"}


def _value_unit(ps):
    """50000000 -> (50, 'us'): the largest unit in which the limit is a round number (for the number + unit boxes)."""
    for u in ("s", "ms", "us", "ns"):
        size = P.UNIT_PS[u]
        if ps % size == 0:
            return ps // size, u
    return ps / P.UNIT_PS["ns"], "ns"


def _timing_limits_of(meta, con):
    """The two page-3 limits in force (link, nvme_transaction): the admin's (thresholds[level]), None = not considered,
    or the specification default; plus the limit the stored findings were computed with (the 'rules' report), so the
    page can say when the two differ."""
    th_all = meta.get("thresholds") or {}
    try:
        used_all = (L.get_meta(con, "rules", {}) or {}).get("limits", {})
    except sqlite3.Error:
        used_all = {}
    out = {}
    for level in TIMING_LEVELS:
        rule = _RL.TIMING_RULES[level][0]
        dflt = _RL.DEFAULT_LIMITS[level]
        o = {"level": level, "label": LEVEL_LABEL[level], "rule": rule, "measured": MEASURED[level],
             "default": {"ps": dflt["ps"], "text": P.fmt_ps(dflt["ps"]), "value": _value_unit(dflt["ps"])[0], "unit": _value_unit(dflt["ps"])[1], "source": dflt["source"], "short": dflt["short"]}}
        if level in th_all and th_all[level] is None:
            o.update({"considered": False, "ps": None, "text": "not considered", "value": "", "unit": o["default"]["unit"],
                      "source": "the field is empty: timing errors at this level are not considered", "short": "not considered", "set_by_admin": True})
        elif (th_all.get(level) or {}).get("ps"):
            th = th_all[level]
            v, u = (th.get("value"), th.get("unit")) if th.get("unit") in LIMIT_UNITS and th.get("value") not in (None, "") else _value_unit(int(th["ps"]))
            o.update({"considered": True, "ps": int(th["ps"]), "text": P.fmt_ps(int(th["ps"])), "value": v, "unit": u,
                      "source": th.get("source") or "set by the admin", "short": "set by the admin", "set_by_admin": True})
        else:
            o.update({"considered": True, "ps": dflt["ps"], "text": o["default"]["text"], "value": o["default"]["value"], "unit": o["default"]["unit"],
                      "source": dflt["source"], "short": dflt["short"], "set_by_admin": False})
        used = used_all.get(level)
        o["in_force"] = used                                   # the limit of the last rules run at this level (None before the rules ran, or when never set)
        used_ps = (used or {}).get("ps") if used else (None if used_all else "unknown")
        o["findings_match"] = (used_ps == o["ps"]) if used_ps != "unknown" else True
        out[level] = o
    return out


def _cat_entry(cat, ref):
    if not ref:
        return None
    e = cat.by_id.get(ref) or cat.by_name.get(str(ref).lower()) or cat.silent.get(str(ref).lower())
    if e is None:
        for x in cat.by_status.values():
            if x.get("error") == ref:
                return x
    return e


def _evidence(f, cat):
    """The evidence that makes a finding an error, in plain words (the owner's addition of 2026-11-03 to column 4): the rule
    in words; the cell or value that made it fire; the row it was seen on; the catalogue's one-line meaning when there is one."""
    d = f.get("detail") or {}
    rule = f.get("rule") or ""
    facts = []
    if rule in ("cmd.status_error", "ntx.status_error") and (d.get("SCT") is not None or d.get("SC") is not None):
        sct, sc = int(d.get("SCT") or 0), int(d.get("SC") or 0)
        e = _cat_entry(cat, f.get("cat_ref"))
        facts.append("status 0x%04x: type %d, code %d, %s%s" % ((sct << 8) | sc, sct, sc, (e or {}).get("error") or "unknown status name", ", do not retry" if d.get("DNR") else ""))
    elif "cell" in d:
        facts.append("the analyzer's %s cell reads \"%s\"" % ("warning" if "warning" in rule else "error", d["cell"]))
    if f.get("value_ps") is not None and f.get("limit_ps") is not None:
        facts.append("took %s, limit %s, %s" % (P.fmt_ps(f["value_ps"]), P.fmt_ps(f["limit_ps"]), f.get("limit_source") or "limit source not recorded"))
    if rule == "cmd.incomplete":
        facts.append("no completion entry was written; parts seen: %s" % ", ".join(d.get("parts_seen") or []) or "none")
    elif rule == "cmd.not_fetched":
        facts.append("no fetch of the submission entry; parts seen: %s" % ", ".join(d.get("parts_seen") or []))
    elif rule == "cmd.doorbell_missing":
        facts.append("no submission doorbell write of its own (a coalesced doorbell is possible)")
    elif rule == "cmd.no_interrupt":
        facts.append("completion entry written, no interrupt write seen")
    elif rule == "ntx.phase_wrong":
        facts.append("phase bit found %s, expected %s, at slot %s of completion queue %s" % (d.get("phase"), d.get("expected"), d.get("slot"), d.get("queue")))
    elif rule == "ntx.interrupt_before_completion" and d.get("interrupt_t") is not None and d.get("completion_t") is not None:
        facts.append("interrupt at %s, completion entry at %s" % (P.fmt_ps(d["interrupt_t"]), P.fmt_ps(d["completion_t"])))
    elif rule == "ntx.completion_unknown_command":
        facts.append("queue %s, command id %s is not open" % (d.get("sqid"), d.get("cid")))
    elif rule == "cmd.bytes_short":
        facts.append("%s bytes requested, %s moved" % (d.get("requested"), d.get("moved")))
    elif rule in ("cmd.deallocate_readback", "cmd.write_zeroes_readback"):
        facts.append("%s bytes checked, pattern %s" % (d.get("bytes_checked", 0), d.get("pattern") or "not exported"))
    elif not facts and d:
        facts.append("; ".join("%s: %s" % (k, v) for k, v in d.items() if k != "opcode"))
    if f.get("level") == "nvme_command":
        seen = "seen on the command itself"
    elif f.get("level") == "link":
        seen = "seen on link transaction %s" % (f.get("row_n") if f.get("row_n") is not None else f.get("rowid"))
    else:
        seen = "seen on %s %s" % (LEVEL_LABEL.get(f.get("level"), f.get("level")), f.get("row_n") if f.get("row_n") is not None else "file row %s" % f.get("rowid"))
    b = RL.basis(rule)
    facts.append("basis: %s (%s; %s)" % (b["text"], "firm: " + b["kind"] if b["firm"] else "a suspect: " + b["kind"], b["ref"]) if b["ref"] else "basis: %s" % b["text"])
    e = _cat_entry(cat, f.get("cat_ref")) or {}
    meaning = (e.get("meaning") or e.get("description") or "").strip()
    if not meaning and e.get("defects"):
        d0 = e["defects"][0]
        meaning = "usual cause: %s (%s)" % (d0.get("cause", ""), d0.get("domain", "")) if isinstance(d0, dict) else str(d0)
    if not meaning and isinstance(e.get("rule"), dict) and e["rule"].get("description"):
        meaning = str(e["rule"]["description"]).strip()
    if meaning:
        meaning = meaning.split(". ")[0].rstrip(".") + "."
    return {"rule_words": RULE_WORDS.get(rule, rule), "facts": facts, "seen_on": seen, "meaning": meaning or None,
            "text": "%s · %s · %s" % (RULE_WORDS.get(rule, rule), "; ".join(facts) or f.get("name", ""), seen)}



def _status_words(row, cat):
    """The command's completion status in words: 'success', 'Invalid Command Opcode (type 0, code 1)', or 'no completion recorded'."""
    sct, sc = row.get("sct"), row.get("sc")
    if sct is None and sc is None:
        return "no completion recorded", False
    if not sct and not sc:
        return "success", True
    e = cat.by_status.get((int(sct or 0), int(sc or 0))) or {}
    name = e.get("error")
    if not name:
        m = re.search(r"\(([^)]+)\)", str(row.get("st") or ""))
        name = m.group(1) if m else None
    return "%s (type %s, code %s)" % (name or "an error status", sct or 0, sc or 0), False


IO_RW = {1: "Write", 2: "Read", 4: "Write Uncorrectable", 5: "Compare", 8: "Write Zeroes", 12: "Verify", 25: "Copy"}


def _did_text(row):
    """What the command did, in one clause: 'Read of 16 blocks at block 2,097,152 on namespace 1'."""
    name = NM.opcode_name(row.get("opc"), row.get("sqid"))
    sqid, opc = row.get("sqid"), row.get("opc")
    ns = (" on namespace %s" % row["nsid"]) if row.get("nsid") is not None else ""
    if sqid != 0 and opc in IO_RW and row.get("nlb") is not None and row.get("slba") is not None:
        return "%s of %s block%s at block %s%s%s" % (IO_RW[opc], "{:,}".format(row["nlb"] + 1), "" if row["nlb"] == 0 else "s", "{:,}".format(row["slba"]), ns, " with FUA" if row.get("fua") else "")
    if sqid != 0 and opc == 0:
        return "Flush%s" % ns
    if sqid != 0 and opc == 9:
        return "Dataset Management of %s range%s%s%s" % ((row.get("nr") or 0) + 1, "" if not row.get("nr") else "s", " (deallocate)" if row.get("ad") else "", ns)
    if sqid == 0:
        extra = ""
        if opc == 6 and row.get("cns") is not None:
            extra = " with CNS %s" % row["cns"]
        elif opc in (9, 10) and row.get("fid") is not None:
            extra = ", feature %s" % row["fid"]
        elif opc == 2 and row.get("lid") is not None:
            extra = ", log %s" % row["lid"]
        elif opc in (0, 1, 4, 5) and row.get("qid") is not None:
            extra = ", queue %s%s" % (row["qid"], (" of %s entries" % row["qsize"]) if row.get("qsize") else "")
        return "%s%s%s" % (name, extra, ns if row.get("nsid") else "")
    return "%s%s" % (name, ns)


def _short_source(level, limit_source):
    d = _RL.DEFAULT_LIMITS[level]
    return d["short"] if limit_source == d["source"] else ("set by the admin" if limit_source else "limit source not recorded")


def _statement(row, tx_by_rowid, findings, link_findings, limits):
    """ONE plain-English statement for the whole row, written by code: what the command did and how it ended; 'No error.'
    when nothing fired; otherwise every error at the NVMe transaction and command level with its evidence, the timing
    errors named by level with the transaction (or link transaction) number, the measured time and the limit; then the
    checks and the context; then the levels whose timing is not considered."""
    did = _did_text(row)
    status, ok = _status_words(row, _statement.cat)
    dur = row.get("dur_ps_text")
    if status == "no completion recorded":
        ended = ", no completion recorded" + (" (%s so far)" % dur if dur else "")
    else:
        ended = (", completed with %s" % ("success" if ok else "status " + status)) + ((" in %s" % dur) if dur else " (duration not built)")
    parts = [did + ended + "."]
    errors = [f for f in findings if f.get("severity") == "error" and f.get("rule") != NTX_RULE]
    ntx_t = [f for f in findings if f.get("rule") == NTX_RULE]
    checks = [f for f in findings if f.get("severity") == "check"]
    warns = [f for f in findings if f.get("severity") == "warning"]
    if not errors and not ntx_t and not link_findings:
        parts.append("No error.")
    for f in errors:
        e = f.get("evidence") or {}
        parts.append("%s: %s; %s." % (_cap(e.get("rule_words") or f.get("rule")), "; ".join(e.get("facts") or [f.get("name") or ""]), e.get("seen_on") or ""))
    if ntx_t:
        items = []
        for f in ntx_t[:8]:
            t = tx_by_rowid.get(f.get("rowid")) or {}
            items.append("transaction %s (%s) took %s, limit %s (%s)" % (f.get("row_n") if f.get("row_n") is not None else f.get("rowid"), t.get("type") or "type not in the tree",
                                                                           f.get("value_ps_text") or "-", f.get("limit_ps_text") or "-", _short_source("nvme_transaction", f.get("limit_source"))))
        if len(ntx_t) > 8:
            items.append("and %d more" % (len(ntx_t) - 8))
        b = _RL.basis(NTX_RULE)
        parts.append("An NVMe transaction took longer than the NVMe-transaction limit: %s. Basis: %s (%s)." % ("; ".join(items), b["text"], b["ref"]))
    if link_findings:
        items = []
        for f in link_findings[:8]:
            under = ("under NVMe transaction %s (%s)" % (f["ntx_n"], f.get("ntx_type") or "-")) if f.get("ntx_n") is not None else "under no NVMe transaction in the tree"
            items.append("link transaction %s %s took %s, limit %s (%s)" % (f.get("row_n") if f.get("row_n") is not None else f.get("rowid"), under, f.get("value_ps_text") or "-",
                                                                          f.get("limit_ps_text") or "-", _short_source("link", f.get("limit_source"))))
        if len(link_findings) > 8:
            items.append("and %d more" % (len(link_findings) - 8))
        b = _RL.basis(LINK_RULE)
        parts.append("A link transaction under this command took longer than the link limit: %s. Basis: %s (%s)." % ("; ".join(items), b["text"], b["ref"]))
    if checks:
        parts.append("To check by hand: %s." % "; ".join("%s (%s)" % (f.get("name"), (f.get("evidence") or {}).get("seen_on") or "") for f in checks))
    if warns:
        parts.append("Context: %s." % "; ".join(f.get("name") or "" for f in warns))
    for level in TIMING_LEVELS:
        if limits.get(level) and not limits[level]["considered"]:
            parts.append("Timing at the %s level: not considered." % ("link" if level == "link" else "NVMe transaction"))
    return " ".join(parts)


def _cap(t):
    return (t[:1].upper() + t[1:]) if t else t


@bp.get("/api/hier/uploads/<uid>/defect_table")
def defect_table(uid):
    """Page 3. One page of NVMe commands (error or not) with their NVMe transactions, their findings and ONE statement per
    row written by code, in one query set (no query per command): the transactions and the findings come as JSON arrays
    aggregated by the database, keyed by the command's rowid_file. filter=all (default) | error (at least one error:
    a rule of severity error at the NVMe transaction or command level, or a slow link transaction) | no_error, applied
    in SQL; the legacy all=1 / all=0 mean all / error. filters / finding_at / relation as `rows`; keyset paging (after /
    before) by rowid_file, offset for positional access, count=0 skips the total."""
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    meta = read_meta(d) or {}
    con = sqlite3.connect(db_of(d))
    con.row_factory = sqlite3.Row
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if "cmd" not in tables:
        con.close()
        return jsonify({"error": "the defect table needs the NVMe command file"}), 400
    have = {r[1] for r in con.execute("PRAGMA table_info(cmd)")}
    have_f, have_ntx, have_lnk, have_spl = "finding" in tables, "ntx" in tables, "lnk" in tables, "spl" in tables
    limits = _timing_limits_of(meta, con)
    flt = request.args.get("filter") or ({"1": "all", "0": "error"}.get(request.args.get("all")) if request.args.get("all") is not None else "all")
    if flt not in DT_FILTERS:
        con.close()
        return jsonify({"error": "filter must be one of all, error, no_error"}), 400
    sel = ", ".join("c.%s" % c for c in DT_COLS if c in have)
    # columns 2 and 3: the NVMe transactions of the command, one JSON object each, in file order
    if have_ntx:
        have_x = {r[1] for r in con.execute("PRAGMA table_info(ntx)")}
        sel += (", (SELECT json_group_array(json_object('rowid', x.rowid_file, 'n', x.n, 'type', x.type, 'delta_ps', x.delta_ps, 'dur_ps', x.dur_ps, "
                "'t_ps', x.t_ps, 'nbytes', x.nbytes, 'sct', x.sct, 'sc', x.sc, 'errors', x.errors, 'warnings', x.warnings, 'relation', x.relation, 'n_findings', %s)) "
                "FROM (SELECT * FROM ntx WHERE parent_level = 'nvme_command' AND parent = c.rowid_file ORDER BY rowid_file) x) AS ntx_json"
                % ("x.n_findings" if "n_findings" in have_x else "NULL"))
    else:
        sel += ", NULL AS ntx_json"
    # column 4: the findings at the NVMe transaction and command level, and the link-level timing errors with the link row's
    # identity and its parent chain (link -> split or NVMe transaction -> command), read through primary-key joins
    if have_f:
        if have_lnk:
            ntx_of = ("CASE l.parent_level WHEN 'nvme_transaction' THEN l.parent WHEN 'split' THEN (SELECT p.parent FROM spl p WHERE p.rowid_file = l.parent) END" if have_spl
                      else "CASE l.parent_level WHEN 'nvme_transaction' THEN l.parent END")
            spl_n = "(SELECT p.n FROM spl p WHERE l.parent_level = 'split' AND p.rowid_file = l.parent)" if have_spl else "NULL"
            lnk_join = " LEFT JOIN lnk l ON f.level = 'link' AND l.rowid_file = f.rowid"
            lnk_cols = "'tlp_type', l.tlp_type, 'dir', l.dir, 'psn', l.psn, 'ntx_rowid', %s, 'split_n', %s" % (ntx_of, spl_n)
        else:
            lnk_join, lnk_cols = "", "'tlp_type', NULL, 'dir', NULL, 'psn', NULL, 'ntx_rowid', NULL, 'split_n', NULL"
        sel += (", (SELECT json_group_array(json_object('id', f.id, 'level', f.level, 'rule', f.rule, 'name', f.name, 'severity', f.severity, 'rowid', f.rowid, "
                "'row_n', f.row_n, 'value_ps', f.value_ps, 'limit_ps', f.limit_ps, 'limit_source', f.limit_source, 't_ps', f.t_ps, 'part', f.part, 'detail', f.detail, "
                "'cat_ref', f.cat_ref, %s)) "
                "FROM (SELECT f.* FROM finding f WHERE f.cmd_rowid = c.rowid_file AND (f.level IN ('nvme_transaction', 'nvme_command') OR f.rule = '%s') "
                "ORDER BY %s, COALESCE(f.t_ps, 0), f.id) f%s) AS findings_json" % (lnk_cols, LINK_RULE, DT_SEV_ORDER, lnk_join))
    else:
        sel += ", NULL AS findings_json"
    args_in = request.args.to_dict()
    args_in.setdefault("top", "1")
    try:
        where, args = _scope("nvme_command", args_in)
    except ValueError as e:
        con.close()
        return jsonify({"error": str(e)}), 400
    err_set = "(SELECT f.cmd_rowid FROM finding f WHERE f.cmd_rowid IS NOT NULL AND %s)" % DT_DEFECT
    if flt == "error":
        where += (" AND c.rowid_file IN %s" % err_set) if have_f else " AND 0"
    elif flt == "no_error" and have_f:
        where += " AND c.rowid_file NOT IN %s" % err_set
    offset, limit, after, before, want_count = _page(request.args, default_limit=200, max_limit=1000)
    try:
        total = con.execute("SELECT COUNT(*) FROM cmd c WHERE %s" % where, args).fetchone()[0] if want_count else None
        if after is not None:
            cur = con.execute("SELECT %s FROM cmd c WHERE %s AND c.rowid_file > ? ORDER BY c.rowid_file LIMIT ?" % (sel, where), args + [after, limit])
            out = [dict(r) for r in cur]
        elif before is not None:
            cur = con.execute("SELECT %s FROM cmd c WHERE %s AND c.rowid_file < ? ORDER BY c.rowid_file DESC LIMIT ?" % (sel, where), args + [before, limit])
            out = [dict(r) for r in cur][::-1]
        else:
            cur = con.execute("SELECT %s FROM cmd c WHERE %s ORDER BY c.rowid_file LIMIT ? OFFSET ?" % (sel, where), args + [limit, offset])
            out = [dict(r) for r in cur]
    except sqlite3.Error as e:
        con.close()
        return jsonify({"error": "query failed: %s" % e}), 400
    con.close()
    cat = RL.Catalogue()
    _statement.cat = cat
    for row in out:
        for k in ("t_ps", "delta_ps", "dur_ps"):
            if row.get(k) is not None:
                row[k + "_text"] = P.fmt_ps(row[k])
        row["command"] = NM.opcode_name(row.get("opc"), row.get("sqid"))
        row["status_text"], row["status_ok"] = _status_words(row, cat)
        row["did"] = _did_text(row)
        tx = json.loads(row.pop("ntx_json", None) or "[]")
        by_rowid = {}
        for t in tx:
            for k in ("t_ps", "delta_ps", "dur_ps"):
                if t.get(k) is not None:
                    t[k + "_text"] = P.fmt_ps(t[k])
            t["part"] = NM.part_key(t.get("type"))
            by_rowid[t["rowid"]] = t
        row["transactions"] = tx
        fs = json.loads(row.pop("findings_json", None) or "[]")
        for f in fs:
            try:
                f["detail"] = json.loads(f["detail"]) if isinstance(f.get("detail"), str) else (f.get("detail") or {})
            except ValueError:
                f["detail"] = {}
            for k in ("t_ps", "value_ps", "limit_ps"):
                if f.get(k) is not None:
                    f[k + "_text"] = P.fmt_ps(f[k])
            f["level_label"] = LEVEL_LABEL.get(f.get("level"), f.get("level"))
            f["evidence"] = _evidence(f, cat)
            if f["level"] == "link":
                t = by_rowid.get(f.get("ntx_rowid"))
                f["ntx_n"], f["ntx_type"] = (t.get("n"), t.get("type")) if t else (None, None)
                f["under"] = "%s, queue %s, id %s (command %s) > %s > link transaction %s" % (
                    row["command"], row.get("sqid"), row.get("cid"), row.get("n"),
                    ("NVMe transaction %s (%s)%s" % (t["n"], t.get("type") or "-", (" > split transaction %s" % f["split_n"]) if f.get("split_n") is not None else "")) if t else "NVMe transaction not in the tree",
                    f.get("row_n") if f.get("row_n") is not None else f.get("rowid"))
        row["findings"] = [f for f in fs if f["level"] != "link"]            # the NVMe transaction and command level (timing included)
        row["link_findings"] = [f for f in fs if f["level"] == "link"]       # the slow link transactions
        row["has_error"] = any(f["severity"] == "error" for f in fs)
        row["statement"] = _statement(row, by_rowid, row["findings"], row["link_findings"], limits)
        first = next((f for f in fs if f["severity"] == "error"), fs[0] if fs else None)
        row["first_finding"] = first["id"] if first else None                # the isolate tab a click on the row opens
    return jsonify({"total": total, "offset": offset, "limit": limit, "rows": out, "filter": flt,
                    "first_key": out[0]["rowid_file"] if out else None, "last_key": out[-1]["rowid_file"] if out else None,
                    "has_more": len(out) == limit, "timing_limits": limits, "level_labels": LEVEL_LABEL})


@bp.get("/api/hier/uploads/<uid>/timing_limits")
def get_timing_limits(uid):
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    con = sqlite3.connect(db_of(d))
    out = _timing_limits_of(read_meta(d) or {}, con)
    con.close()
    return jsonify(out)


def _limit_entry(level, v):
    """One limit from the request: {value, unit} -> the stored entry; None -> None (not considered); "default" -> absent."""
    if v is None:
        return None
    if v == "default":
        return "default"
    if not isinstance(v, dict):
        raise ValueError("%s: give {value, unit}, null (not considered) or \"default\"" % LEVEL_LABEL[level])
    if v.get("value") in (None, ""):
        return None
    unit = v.get("unit") or "ms"
    if unit not in LIMIT_UNITS:
        raise ValueError("%s: the unit must be one of ns, us, ms, s" % LEVEL_LABEL[level])
    try:
        fv = float(v["value"])
    except (TypeError, ValueError):
        raise ValueError("%s: the limit must be a number" % LEVEL_LABEL[level])
    if fv <= 0:
        raise ValueError("%s: the limit must be above zero" % LEVEL_LABEL[level])
    return {"value": fv, "unit": unit, "ps": int(round(fv * P.UNIT_PS[unit])),
            "source": (v.get("source") or "").strip() or ("set by the admin on page 3, %s" % time.strftime("%Y-%m-%d %H:%M"))}


@bp.put("/api/hier/uploads/<uid>/timing_limits")
def set_timing_limits(uid):
    """body: {link: {value, unit, source?} | null | "default", nvme_transaction: ...}; a level that is absent stays as it is.
    null (or an empty value) = timing at that level is not considered: the limit is stored as none and that rule's
    findings are deleted. "default" = back to the specification default. Each level given is stored under the upload's
    thresholds and ONLY the levels whose limit changed have their timing rule re-run (rules.apply_link_limit /
    apply_ntx_limit) with the roll-up; returns the counts per level re-run."""
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    meta = read_meta(d) or {}
    if meta.get("status") == "loading":
        return jsonify({"error": "this upload is still loading; set the limits when the load report is shown"}), 409
    th = dict(meta.get("thresholds") or {})
    con = sqlite3.connect(db_of(d))
    before = _timing_limits_of(meta, con)
    con.close()
    changed = []
    for level in TIMING_LEVELS:
        if level not in body:
            continue
        try:
            e = _limit_entry(level, body[level])
        except ValueError as ex:
            return jsonify({"error": str(ex)}), 400
        if e == "default":
            th.pop(level, None)
        else:
            th[level] = e
        new_ps = None if e in (None, "default") else e["ps"]
        if e == "default":
            new_ps = _RL.DEFAULT_LIMITS[level]["ps"]
        if new_ps != before[level]["ps"] or not before[level]["findings_match"] or body.get("force"):
            changed.append(level)
    meta["thresholds"] = th
    write_meta(d, meta)
    counts = {}
    try:
        for level in changed:
            counts[level] = (_RL.apply_link_limit if level == "link" else _RL.apply_ntx_limit)(db_of(d), th)
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 409
    con = sqlite3.connect(db_of(d))
    ensure_indexes(con)
    limits = _timing_limits_of(meta, con)
    n_cmds = con.execute("SELECT COUNT(DISTINCT f.cmd_rowid) FROM finding f WHERE f.cmd_rowid IS NOT NULL AND %s" % DT_DEFECT).fetchone()[0] if changed or True else None
    con.close()
    return jsonify({"timing_limits": limits, "counts": counts, "changed": changed, "commands_with_errors": n_cmds, "thresholds": th})


# ---------------------------------------------------------------------------------------------- findings
from nvme_hier import names as NM, rules as RL, signature as SG, store as ST   # noqa: E402
from nvme_hier import chat as CH, optimise as OPT, testcase as TC   # noqa: E402

LEVEL_LABEL = C.LEVEL_LABEL


def knowledge(s):
    if not hasattr(s, "hier_store"):
        s.hier_store = ST.Store(os.path.join(s.root, "db", "hier_knowledge.sqlite"))
    return s.hier_store


def _row(con, level, rowid):
    r = con.execute("SELECT * FROM %s WHERE rowid_file=?" % TABLE[level], (rowid,)).fetchone()
    if r is None:
        return None
    row = dict(r)
    row["raw"] = json.loads(row["raw"]) if row.get("raw") else {}
    row["level"] = level
    for k in ("t_ps", "delta_ps", "dur_ps"):
        if row.get(k) is not None:
            row[k + "_text"] = P.fmt_ps(row[k])
    return row


def _summary(level, row):
    """One line that names a row in plain words."""
    if not row:
        return ""
    if level == "nvme_command":
        return "%s, queue %s, command id %s" % (NM.opcode_name(row.get("opc"), row.get("sqid")), row.get("sqid"), row.get("cid"))
    if level == "nvme_transaction":
        return "%s%s" % (row.get("type") or "NVMe transaction", (" (queue %s, id %s)" % (row.get("sqid"), row.get("cid"))) if row.get("cid") is not None else "")
    if level == "split":
        return "%s request, tag %s, completion status %s" % (row.get("tlp_type") or "", row.get("tag"), row.get("cpl_status") or "-")
    if level == "link":
        return "%s %s, sequence number %s" % (row.get("dir") or "", row.get("tlp_type") or "", row.get("psn"))
    return "%s %s" % (row.get("dir") or "", row.get("tlp_type") or row.get("dllp_type") or row.get("os_type") or row.get("link_event") or "packet")


def _chain(con, level, rowid):
    """Rows from the finding's row up to its command: [(level, row)]."""
    out = []
    lv, rid = level, rowid
    while rid is not None and lv is not None:
        row = _row(con, lv, rid)
        if row is None:
            break
        out.append({"level": lv, "label": LEVEL_LABEL[lv], "rowid": rid, "n": row.get("n"), "summary": _summary(lv, row),
                    "t": row.get("raw", {}).get("Time Stamp"), "dur": row.get("dur_ps_text"), "errors": row.get("errors"), "row": row})
        lv, rid = row.get("parent_level"), row.get("parent")
        if lv == "nvme_command" and rid is not None and level != "nvme_command":
            row = _row(con, lv, rid)
            if row:
                out.append({"level": lv, "label": LEVEL_LABEL[lv], "rowid": rid, "n": row.get("n"), "summary": _summary(lv, row),
                            "t": row.get("raw", {}).get("Time Stamp"), "dur": row.get("dur_ps_text"), "errors": row.get("errors"), "row": row})
            break
    return out


CHILD_LEVELS = {"nvme_command": ["nvme_transaction"], "nvme_transaction": ["split", "link"], "split": ["link"], "link": ["packets"], "packets": []}


def _children(con, level, rowid, limit=20):
    """The rows one level down whose parent is this row (member rows first), at most `limit` per child level."""
    out = []
    for cl in CHILD_LEVELS.get(level, []):
        t = TABLE[cl]
        for r in con.execute("SELECT * FROM %s WHERE parent_level=? AND parent=? ORDER BY (relation='context'), rowid_file LIMIT ?" % t, (level, rowid, limit)):
            row = dict(r)
            row["raw"] = json.loads(row["raw"]) if isinstance(row.get("raw"), str) else (row.get("raw") or {})
            for k in ("t_ps", "delta_ps", "dur_ps"):
                if row.get(k) is not None:
                    row[k + "_text"] = P.fmt_ps(row[k])
            out.append({"level": cl, "label": LEVEL_LABEL[cl], "rowid": row["rowid_file"], "n": row.get("n"), "summary": _summary(cl, row),
                        "t": row.get("raw", {}).get("Time Stamp"), "dur": row.get("dur_ps_text"), "errors": row.get("errors"), "relation": row.get("relation"), "row": row})
    return out


def _below(con, level, rowid, per_level=12):
    """Everything under a row, level by level down to the packets: the first rows of each level (member rows first)."""
    levels, lv, rid = [], level, rowid
    while True:
        kids = _children(con, lv, rid, per_level)
        if not kids:
            break
        counts = {cl: con.execute("SELECT COUNT(*) FROM %s WHERE parent_level=? AND parent=?" % TABLE[cl], (lv, rid)).fetchone()[0] for cl in CHILD_LEVELS.get(lv, [])}
        levels.append({"under": lv, "under_label": LEVEL_LABEL[lv], "rows": kids, "counts": counts})
        first = next((k for k in kids if k["relation"] != "context"), kids[0])
        lv, rid = first["level"], first["rowid"]
    return levels


def _finding(con, fid):
    r = con.execute("SELECT * FROM finding WHERE id=?", (fid,)).fetchone()
    if r is None:
        return None
    f = dict(r)
    f["detail"] = json.loads(f["detail"]) if f.get("detail") else {}
    for k in ("t_ps", "value_ps", "limit_ps"):
        if f.get(k) is not None:
            f[k + "_text"] = P.fmt_ps(f[k])
    return f


def _device(con, meta):
    r = con.execute("SELECT mn FROM cmd WHERE mn IS NOT NULL LIMIT 1").fetchone() if "nvme_command" in L.get_meta(con, "levels_present", []) else None
    dev = (r[0] if r else None) or meta.get("device") or None
    fw = None
    r2 = con.execute("SELECT raw FROM cmd WHERE opc=6 AND sqid=0 LIMIT 50").fetchall() if dev else []
    for x in r2:
        raw = json.loads(x[0]) if x[0] else {}
        if raw.get("Controller Capabilities.FR"):
            fw = raw["Controller Capabilities.FR"]
            break
    return dev, fw or meta.get("firmware")


def _signature_of(con, meta, f, cmd_row):
    dev, fw = _device(con, meta)
    cause = "self"
    if f.get("cause_rule"):
        cause = f["cause_rule"]
    sig = SG.compute({"dev": dev, "fw": fw, "lvl": f["level"], "err": f["rule"],
                      "cmd": SG.cmd_key(NM.opcode_name(cmd_row.get("opc"), cmd_row.get("sqid")), cmd_row.get("sqid")) if cmd_row else "none",
                      "part": f.get("part") or "none", "cause": cause,
                      "st": SG.status_key(cmd_row.get("sct"), cmd_row.get("sc")) if cmd_row and (cmd_row.get("sct") is not None) else "none",
                      "dnr": (f.get("detail") or {}).get("DNR")})
    sig["device"], sig["firmware"] = dev, fw
    return sig


@bp.get("/api/hier/uploads/<uid>/findings")
def findings(uid):
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    con = sqlite3.connect(db_of(d))
    con.row_factory = sqlite3.Row
    try:
        con.execute("SELECT 1 FROM finding LIMIT 1")
    except sqlite3.Error:
        con.close()
        return jsonify({"findings": [], "total": 0, "by_level": {}, "by_rule": {}, "message": "the rules have not run yet"})
    where, args = ["1=1"], []
    for k in ("level", "rule", "severity"):
        v = request.args.get(k) or (request.args.get("kind") if k == "severity" else None)   # "kind" is the screen's word
        if v:
            where.append("%s=?" % k)
            args.append(v)
    if request.args.get("cmd"):
        where.append("cmd_rowid=?")
        args.append(int(request.args.get("cmd")))
    w = " AND ".join(where)
    offset, limit, _after, _before, want_count = _page(request.args, default_limit=100, max_limit=1000)
    # count=0 (follow-up pages of the scrolling list): no COUNT and no GROUP BY over the whole table again
    total = con.execute("SELECT COUNT(*) FROM finding WHERE " + w, args).fetchone()[0] if want_count else None
    out = []
    for r in con.execute("SELECT f.*, c.opc, c.sqid AS c_sqid, c.cid AS c_cid, c.n AS c_n, c.role FROM finding f LEFT JOIN cmd c ON c.rowid_file=f.cmd_rowid "
                         "WHERE " + w + " ORDER BY CASE severity WHEN 'error' THEN 0 WHEN 'check' THEN 1 ELSE 2 END, t_ps LIMIT ? OFFSET ?", args + [limit, offset]):
        f = dict(r)
        f["detail"] = json.loads(f["detail"]) if f.get("detail") else {}
        f["command"] = ("%s, queue %s, id %s (command %s)" % (NM.opcode_name(f["opc"], f["c_sqid"]), f["c_sqid"], f["c_cid"], f["c_n"])) if f.get("cmd_rowid") else "outside any command"
        for k in ("t_ps", "value_ps", "limit_ps"):
            if f.get(k) is not None:
                f[k + "_text"] = P.fmt_ps(f[k])
        f["level_label"] = LEVEL_LABEL[f["level"]]
        out.append(f)
    by_level = by_rule = by_sev = None
    rules_meta = {}
    if want_count:
        by_level = {r[0]: r[1] for r in con.execute("SELECT level, COUNT(*) FROM finding WHERE severity='error' GROUP BY level")}
        by_rule = {r[0]: r[1] for r in con.execute("SELECT rule, COUNT(*) FROM finding GROUP BY rule")}
        by_sev = {r[0]: r[1] for r in con.execute("SELECT severity, COUNT(*) FROM finding GROUP BY severity")}
        rules_meta = L.get_meta(con, "rules", {})
    con.close()
    return jsonify({"findings": out, "total": total, "offset": offset, "limit": limit, "has_more": len(out) == limit,
                    "by_level": by_level, "by_rule": by_rule, "by_severity": by_sev,
                    "limits": rules_meta.get("limits"), "level_labels": LEVEL_LABEL})


@bp.get("/api/hier/uploads/<uid>/findings/<int:fid>")
def finding_detail(uid, fid):
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    meta = read_meta(d) or {}
    con = sqlite3.connect(db_of(d))
    con.row_factory = sqlite3.Row
    f = _finding(con, fid)
    if f is None:
        con.close()
        return jsonify({"error": "no such finding"}), 404
    f["level_label"] = LEVEL_LABEL[f["level"]]
    cat = RL.Catalogue()
    entry = None
    if f.get("cat_ref"):
        entry = cat.by_id.get(f["cat_ref"]) or cat.by_name.get(str(f["cat_ref"]).lower()) or cat.silent.get(str(f["cat_ref"]).lower())
        if entry is None:
            for e in cat.by_status.values():
                if e.get("error") == f["cat_ref"]:
                    entry = e
                    break
    f["catalogue"] = RL.brief(entry)
    f["basis"] = RL.basis(f.get("rule"))
    f["source_row"] = _row(con, f["level"], f["rowid"])
    f["chain"] = _chain(con, f["level"], f["rowid"])
    f["below"] = _below(con, f["level"], f["rowid"])
    f["observed_outcome"] = CH.observed_outcome(f)                 # what the recording shows at the fault
    f["expected_outcome_default"] = CH.expected_outcome_default(f) # first guess of what a correct device must do
    cmd_row = _row(con, "nvme_command", f["cmd_rowid"]) if f.get("cmd_rowid") else None
    f["command"] = {"rowid": f["cmd_rowid"], "summary": _summary("nvme_command", cmd_row), "row": cmd_row} if cmd_row else None
    f["other_findings_in_command"] = [dict(r) for r in con.execute(
        "SELECT id, level, rule, name, severity, row_n, t_ps FROM finding WHERE cmd_rowid=? AND id!=? ORDER BY t_ps", (f["cmd_rowid"], fid))] if f.get("cmd_rowid") else []
    f["cause"] = _finding(con, f["cause_finding"]) if f.get("cause_finding") else None
    sig = _signature_of(con, meta, f, cmd_row)
    f["signature"] = sig
    st = knowledge(s)
    st.touch_signature(sig, sig.get("device"), upload_id=uid, finding_id=fid)   # counted once per upload and finding, not per view
    f["knowledge"] = st.lookup(sig)
    f["chat"] = st.chat_history(uid, fid)
    f["levels_present"] = L.get_meta(con, "levels_present", [])
    con.close()
    return jsonify(f)


@bp.get("/api/hier/uploads/<uid>/findings/<int:fid>/window")
def finding_window(uid, fid):
    """n rows above and m rows below the fault at the chosen level (default: the command level, same queue)."""
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    con = sqlite3.connect(db_of(d))
    con.row_factory = sqlite3.Row
    f = _finding(con, fid)
    if f is None:
        con.close()
        return jsonify({"error": "no such finding"}), 404
    con.close()
    level = request.args.get("level") or "nvme_command"
    if level not in LEVELS:
        level = "nvme_command"
    n_above, m_below = int(request.args.get("n") or 5), int(request.args.get("m") or 5)
    same_queue = request.args.get("queue", "same") == "same"
    w = _window(s, uid, fid, level, n_above, m_below, same_queue)     # one implementation for the page and the optimiser
    if w is None:
        return jsonify({"error": "no row at the %s level can be placed around this finding" % LEVEL_LABEL[level]}), 400
    return jsonify(w)


@bp.post("/api/hier/uploads/<uid>/findings/<int:fid>/signal")
def finding_signal(uid, fid):
    """body: {signal, procedure_id|null, admin, edited_steps?, edited_text?, proposal_steps?, proposal_text?, scenario_name?}"""
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    if body.get("signal") not in ST.SIGNALS:
        return jsonify({"error": "signal must be one of: " + ", ".join(ST.SIGNALS)}), 400
    admin = (body.get("admin") or "").strip() or "admin"
    meta = read_meta(d) or {}
    con = sqlite3.connect(db_of(d))
    con.row_factory = sqlite3.Row
    f = _finding(con, fid)
    if f is None:
        con.close()
        return jsonify({"error": "no such finding"}), 404
    cmd_row = _row(con, "nvme_command", f["cmd_rowid"]) if f.get("cmd_rowid") else None
    sig = _signature_of(con, meta, f, cmd_row)
    con.close()
    st = knowledge(s)
    try:
        r = st.signal(sig["fine"], body.get("procedure_id"), body["signal"], admin, edited_steps=body.get("edited_steps"),
                      edited_text=body.get("edited_text"), upload_id=uid, finding_id=fid, proposal_steps=body.get("proposal_steps"),
                      proposal_text=body.get("proposal_text"), scenario_name=body.get("scenario_name"), test_path=body.get("test_path"),
                      outcome=body.get("outcome"))
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    if body.get("scenario_name"):
        st.set_scenario_name(sig["fine"], body["scenario_name"], "admin:" + admin)
    return jsonify({"result": r, "knowledge": st.lookup(sig)})


@bp.post("/api/hier/uploads/<uid>/findings/<int:fid>/reorder")
def finding_reorder(uid, fid):
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    meta = read_meta(d) or {}
    con = sqlite3.connect(db_of(d))
    con.row_factory = sqlite3.Row
    f = _finding(con, fid)
    cmd_row = _row(con, "nvme_command", f["cmd_rowid"]) if f and f.get("cmd_rowid") else None
    sig = _signature_of(con, meta, f, cmd_row) if f else None
    con.close()
    if not sig:
        return jsonify({"error": "no such finding"}), 404
    st = knowledge(s)
    st.reorder(sig["fine"], body.get("order") or [], (body.get("admin") or "admin").strip())
    return jsonify({"knowledge": st.lookup(sig)})


# ---------------------------------------------------------------------------------------------- chat, optimise, test case


def _detail_for_model(s, uid, fid):
    """The finding detail and the knowledge lookup, as the detail endpoint builds them (shared by chat and test case)."""
    with current_app_ctx(s, uid) as (d, meta, con):
        f = _finding(con, fid)
        if f is None:
            return None, None, None, None
        f["level_label"] = LEVEL_LABEL[f["level"]]
        cat = RL.Catalogue()
        entry = cat.by_id.get(f.get("cat_ref")) or cat.by_name.get(str(f.get("cat_ref")).lower()) or cat.silent.get(str(f.get("cat_ref")).lower())
        if entry is None and f.get("cat_ref"):
            for e in cat.by_status.values():
                if e.get("error") == f["cat_ref"]:
                    entry = e
                    break
        f["catalogue"] = RL.brief(entry)
        f["basis"] = RL.basis(f.get("rule"))
        f["chain"] = _chain(con, f["level"], f["rowid"])
        cmd_row = _row(con, "nvme_command", f["cmd_rowid"]) if f.get("cmd_rowid") else None
        f["command"] = {"rowid": f["cmd_rowid"], "summary": _summary("nvme_command", cmd_row), "row": cmd_row} if cmd_row else None
        f["cause"] = _finding(con, f["cause_finding"]) if f.get("cause_finding") else None
        sig = _signature_of(con, meta, f, cmd_row)
        f["signature"] = sig
        return f, sig, cmd_row, meta


class current_app_ctx:
    def __init__(self, s, uid):
        self.s, self.uid = s, uid

    def __enter__(self):
        d = upload_dir(self.s, self.uid)
        if not d or not os.path.exists(db_of(d)):
            raise FileNotFoundError("no such upload")
        self.con = sqlite3.connect(db_of(d))
        self.con.row_factory = sqlite3.Row
        return d, (read_meta(d) or {}), self.con

    def __exit__(self, *a):
        self.con.close()
        return False


def _window(s, uid, fid, level, n, m, same_queue):
    with current_app_ctx(s, uid) as (d, meta, con):
        f = _finding(con, fid)
        chain = _chain(con, f["level"], f["rowid"])
        anchor = next((c["row"] for c in chain if c["level"] == level), None)
        note = ""
        if anchor is None and f.get("cmd_rowid") and level == "nvme_command":
            anchor = _row(con, "nvme_command", f["cmd_rowid"])
        if anchor is None and LEVELS.index(level) > LEVELS.index(f["level"]):
            # a level BELOW the finding's row: the first member row under it, level by level (split -> its request link -> its packet)
            lv, rid = f["level"], f["rowid"]
            while lv != level:
                kids = [k for k in _children(con, lv, rid, 5) if k["relation"] != "context"] or _children(con, lv, rid, 1)
                if not kids:
                    break
                lv, rid = kids[0]["level"], kids[0]["rowid"]
            if lv == level:
                anchor = _row(con, level, rid)
                note = "the window is around the first %s inside the %s that fired" % (LEVEL_LABEL[level], LEVEL_LABEL[f["level"]])
        if anchor is None and f.get("t_ps") is not None:
            # a level ABOVE a row that belongs to no parent: the nearest row at that level in time, said so
            r = con.execute("SELECT * FROM %s WHERE t_ps<=? ORDER BY t_ps DESC, rowid_file DESC LIMIT 1" % TABLE[level], (f["t_ps"],)).fetchone()
            if r is None:
                r = con.execute("SELECT * FROM %s ORDER BY t_ps, rowid_file LIMIT 1" % TABLE[level]).fetchone()
            if r is not None:
                anchor = dict(r)
                anchor["raw"] = json.loads(anchor["raw"]) if isinstance(anchor.get("raw"), str) else (anchor.get("raw") or {})
                note = "this %s belongs to no %s (outside any command), so the window is placed by time only: the %s nearest before it" % (LEVEL_LABEL[f["level"]], LEVEL_LABEL[level], LEVEL_LABEL[level])
        if anchor is None:
            return None
        t = TABLE[level]
        cond, args = "", []
        if level == "nvme_command" and same_queue and anchor.get("sqid") is not None:
            cond, args = " AND sqid=?", [anchor["sqid"]]
        above = [dict(r) for r in con.execute("SELECT * FROM %s WHERE rowid_file<?%s ORDER BY rowid_file DESC LIMIT ?" % (t, cond), [anchor["rowid_file"]] + args + [n])][::-1]
        below = [dict(r) for r in con.execute("SELECT * FROM %s WHERE rowid_file>?%s ORDER BY rowid_file LIMIT ?" % (t, cond), [anchor["rowid_file"]] + args + [m])]
        rows = []
        for pos, lst in (("above", above), ("fault", [anchor]), ("below", below)):
            for r in lst:
                r = dict(r)
                r["raw"] = json.loads(r["raw"]) if isinstance(r.get("raw"), str) else (r.get("raw") or {})
                for k in ("t_ps", "delta_ps", "dur_ps"):
                    if r.get(k) is not None:
                        r[k + "_text"] = P.fmt_ps(r[k])
                r["position"] = pos
                r["summary"] = _summary(level, r)
                r["findings"] = [dict(x) for x in con.execute("SELECT id, rule, name, severity FROM finding WHERE level=? AND rowid=?", (level, r["rowid_file"]))]
                if level != "nvme_command":
                    # which command this row belongs to (up the parent columns), so a window at a low level still shows the commands
                    top = _chain(con, level, r["rowid_file"])
                    cmd = next((c for c in top if c["level"] == "nvme_command"), None)
                    r["command"] = cmd["summary"] if cmd else "outside any command"
                    r["command_rowid"] = cmd["rowid"] if cmd else None
                    r["below_count"] = {cl: con.execute("SELECT COUNT(*) FROM %s WHERE parent_level=? AND parent=?" % TABLE[cl], (level, r["rowid_file"])).fetchone()[0] for cl in CHILD_LEVELS.get(level, [])}
                rows.append(r)
        for i in range(1, len(rows)):
            a, b = rows[i - 1].get("t_ps"), rows[i].get("t_ps")
            rows[i]["gap_text"] = P.fmt_ps(b - a) if a is not None and b is not None else ""
        return {"level": level, "label": LEVEL_LABEL[level], "n": n, "m": m, "same_queue": same_queue, "rows": rows, "anchor_rowid": anchor["rowid_file"], "note": note}


@bp.post("/api/hier/uploads/<uid>/findings/<int:fid>/optimise")
def finding_optimise(uid, fid):
    """body: {level, n, m, same_queue} -> the window with keep/why per row and the minimal sequence."""
    s = svc()
    body = request.get_json(force=True) or {}
    try:
        w = _window(s, uid, fid, body.get("level") or "nvme_command", int(body.get("n") or 5), int(body.get("m") or 5), body.get("same_queue", True))
    except FileNotFoundError:
        return jsonify({"error": "no such upload"}), 404
    if w is None:
        return jsonify({"error": "no row at that level"}), 400
    if w["level"] != "nvme_command":
        return jsonify({"error": "the sequence optimisation works on the command level; extract the window at the command level"}), 400
    out = OPT.optimise(w["rows"])
    out["window"] = {k: v for k, v in w.items() if k != "rows"}
    return jsonify(out)


@bp.post("/api/hier/uploads/<uid>/findings/<int:fid>/chat")
def finding_chat(uid, fid):
    """body: {message, admin, level, n, m, same_queue}. The model gets the finding, the window and the stored procedures."""
    s = svc()
    body = request.get_json(force=True) or {}
    admin = (body.get("admin") or "").strip() or "admin"
    try:
        f, sig, cmd_row, meta = _detail_for_model(s, uid, fid)
        w = _window(s, uid, fid, body.get("level") or "nvme_command", int(body.get("n") or 5), int(body.get("m") or 5), body.get("same_queue", True))
    except FileNotFoundError:
        return jsonify({"error": "no such upload"}), 404
    if f is None:
        return jsonify({"error": "no such finding"}), 404
    if w is None:
        w = {"level": "nvme_command", "label": "NVMe command", "n": 0, "m": 0, "rows": [], "same_queue": True}
    st = knowledge(s)
    know = st.lookup(sig)
    if know.get("exact") and not body.get("anyway"):
        # the owner's rule: a signature that already has a stored procedure is not sent to the model again,
        # unless the admin explicitly asks for a new proposal ("a new proposal anyway")
        return jsonify({"error": "this fault is already stored (%d procedure%s for this signature); use a stored procedure, or tick \"a new proposal anyway\""
                        % (len(know["exact"]), "" if len(know["exact"]) == 1 else "s"), "stored": len(know["exact"])}), 409
    llm = getattr(getattr(s, "s2", None), "llm", None)
    st.chat_append(uid, fid, sig["fine"], "admin:" + admin, body.get("message") or "", {"window": {k: v for k, v in w.items() if k != "rows"}})
    ans = CH.ask(llm, f, w, know, body.get("message") or "")
    st.chat_append(uid, fid, sig["fine"], ans.get("producer", "model"), ans.get("summary", ""), ans)
    if ans.get("scenario_name") and not know.get("scenario_name"):
        st.set_scenario_name(sig["fine"], ans["scenario_name"], ans.get("producer", "model"))
    return jsonify({"answer": ans, "history": st.chat_history(uid, fid)})


@bp.post("/api/hier/uploads/<uid>/findings/<int:fid>/testcase")
def finding_testcase(uid, fid):
    """body: {steps (the agreed sequence), scenario_name, admin, procedure_id?}. Writes suite/hier/<upload>_<finding>_v<n>.py."""
    s = svc()
    body = request.get_json(force=True) or {}
    try:
        f, sig, cmd_row, meta = _detail_for_model(s, uid, fid)
    except FileNotFoundError:
        return jsonify({"error": "no such upload"}), 404
    if f is None:
        return jsonify({"error": "no such finding"}), 404
    steps = body.get("steps")
    if not steps:
        w = _window(s, uid, fid, "nvme_command", int(body.get("n") or 5), int(body.get("m") or 5), body.get("same_queue", True))
        steps = OPT.optimise(w["rows"])["steps"] if w else []
    if not steps:
        return jsonify({"error": "no sequence to turn into a test"}), 400
    if not any(st_.get("position") == "fault" for st_ in steps):
        steps[-1]["position"] = "fault"
    for i, st_ in enumerate(steps):
        st_["step"] = i + 1
    suite = os.path.join(s.root, "suite", "hier")
    os.makedirs(suite, exist_ok=True)
    version = 1 + len([x for x in os.listdir(suite) if x.startswith("%s_f%d_" % (uid, fid))])
    name = "%s_f%d_v%d.py" % (uid, fid, version)
    nsid = (cmd_row or {}).get("nsid") or 1
    text = TC.generate(f, steps, sig, body.get("scenario_name") or (knowledge(s).lookup(sig).get("scenario_name")), uid, version=version,
                       device=sig.get("device"), firmware=sig.get("firmware"), nsid=nsid, name=name, outcome=body.get("outcome"))
    path = os.path.join(suite, name)
    with open(path, "w") as fh:
        fh.write(text)
    if body.get("procedure_id"):
        knowledge(s).set_test_path(int(body["procedure_id"]), path)
    return jsonify({"path": path, "name": name, "version": version, "text": text, "steps": steps})
