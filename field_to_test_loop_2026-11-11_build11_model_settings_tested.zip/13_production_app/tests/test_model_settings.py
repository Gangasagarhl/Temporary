"""The model connection is set on the Settings page and used by every part (owner, 2026-11-11: "it should not depend solely on my API
key ... I open the settings from run_app.py and change the model name, the URL and the API key, so that everything works properly").

* the key saved on the page wins at start over a key the computer's environment already holds (run_app.py -> model_env.load);
* a key under another variable name (llm.api_key_env) is what every caller reads (ANTHROPIC_API_KEY);
* the page is told only the key's last 4 characters and where it came from, never the key;
* the agents follow the connection's model name and URL at once, without a restart.
Every test here works on its own key file in a temporary folder; the real one is never read or written."""
import os
import shutil
import sys
import tempfile

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

NAMES = ("ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", "COMPANY_KEY")


@pytest.fixture
def env():
    was = {k: os.environ.get(k) for k in NAMES}
    d = tempfile.mkdtemp(prefix="model_env_%d_" % os.getpid())
    try:
        yield d
    finally:
        for k, v in was.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        shutil.rmtree(d, ignore_errors=True)


def test_the_saved_key_wins_over_the_environment_and_junk_lines_are_ignored(env):
    import model_env as ME
    f = os.path.join(env, "env")
    open(f, "w").write("# saved by the Settings page\nnot a setting at all\nexport ANTHROPIC_API_KEY='theirs-key-0000000000ABCD'\nBAD NAME=1\n=x\n")
    assert ME.read_env_file(f) == {"ANTHROPIC_API_KEY": "theirs-key-0000000000ABCD"}
    os.environ["ANTHROPIC_API_KEY"] = "mine-key-11111111111WXYZ"                 # the developer's key, inherited
    src = ME.load({"llm": {"base_url": "https://gateway.example.test", "model": "m"}}, f)
    assert os.environ["ANTHROPIC_API_KEY"] == "theirs-key-0000000000ABCD"
    assert os.environ["ANTHROPIC_BASE_URL"] == "https://gateway.example.test"
    assert src == {"present": True, "end": "ABCD", "source": "saved on the Settings page"}


def test_a_key_under_its_own_variable_is_what_every_caller_reads(env):
    import model_env as ME
    f = os.path.join(env, "env")
    open(f, "w").write("COMPANY_KEY=company-key-22222222222QRST\n")
    os.environ["ANTHROPIC_API_KEY"] = "mine-key-11111111111WXYZ"
    ME.load({"llm": {"api_key_env": "COMPANY_KEY"}}, f)
    assert os.environ["COMPANY_KEY"] == os.environ["ANTHROPIC_API_KEY"] == "company-key-22222222222QRST"
    os.environ["COMPANY_KEY"] = "company-key-33333333333LMNO"                    # set by a service's environment file instead
    ME.apply({"llm": {"api_key_env": "COMPANY_KEY"}})
    assert os.environ["ANTHROPIC_API_KEY"] == "company-key-33333333333LMNO"
    assert ME.source({"llm": {"api_key_env": "COMPANY_KEY"}}, f)["source"].startswith("from this computer's environment")


def test_no_key_says_so(env):
    import model_env as ME
    for k in NAMES:
        os.environ.pop(k, None)
    assert ME.source({"llm": {}}, os.path.join(env, "missing"))["present"] is False


def test_the_settings_page_sets_url_model_and_key_for_every_part_at_once(env):
    import fuzz_app as F
    from api import agentic_api as A
    from api import hier_api as H
    if not os.path.isdir(F.BASE):
        pytest.skip("the S08 sample recording is not on this machine (the code-only zip carries no samples)")
    root = os.path.join(env, "app")
    os.makedirs(root)
    app, c, _k, _r = F.setup(root)
    s = app.config["services"]
    s.cfg.setdefault("llm", {})["backend"] = "http"
    s.cfg.setdefault("agentic", {})["model"] = ""                               # the agents follow the connection's model
    assert H.ENV_FILE.startswith(root)                                           # never the real key file
    with app.app_context():
        A.engine()                                                               # the agents' engine exists before the change
    r = c.put("/api/hier/model", json={"base_url": "http://127.0.0.1:9", "model": "company-model-1", "key": "sk-test-key-abcdefgh1234"})
    assert r.status_code == 200, r.get_json()
    m = r.get_json()
    assert (m["base_url"], m["model"], m["key_present"], m["key_end"], m["key_source"]) == (
        "http://127.0.0.1:9", "company-model-1", True, "1234", "saved on the Settings page")
    assert "sk-test-key-abcdefgh1234" not in r.get_data(as_text=True)              # the key is never sent back
    assert os.environ["ANTHROPIC_API_KEY"] == "sk-test-key-abcdefgh1234" and os.environ["ANTHROPIC_BASE_URL"] == "http://127.0.0.1:9"
    assert "sk-test-key-abcdefgh1234" in open(H.ENV_FILE).read() and "sk-test-key" not in open(os.path.join(root, "config", "app_config.json")).read()
    eng = s.agentic_engine
    assert eng.runner.http_model == "company-model-1" and eng.runner.model == "company-model-1"
    assert c.get("/api/hier/model").get_json()["agents_model"] == "company-model-1"


class _FakeModel:
    """A stand-in Messages API on this computer: it records the address, the key and the model of every call it gets."""

    def __init__(self):
        import json as _json
        import threading
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
        seen = self.seen = []

        class H(BaseHTTPRequestHandler):
            def do_POST(self):
                n = int(self.headers.get("content-length") or 0)
                body = _json.loads(self.rfile.read(n) or b"{}")
                seen.append({"path": self.path, "key": self.headers.get("x-api-key"), "model": body.get("model")})
                data = _json.dumps({"id": "msg_test", "type": "message", "role": "assistant", "model": body.get("model"),
                                    "content": [{"type": "text", "text": '{"ok": "yes"}'}], "stop_reason": "end_turn",
                                    "usage": {"input_tokens": 1, "output_tokens": 1}}).encode()
                self.send_response(200)
                self.send_header("content-type", "application/json")
                self.send_header("content-length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def log_message(self, *a):
                pass

        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = "http://127.0.0.1:%d" % self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def close(self):
        self.srv.shutdown()


def test_a_change_in_settings_reaches_every_part_without_a_restart(env, monkeypatch):
    """Owner, 2026-11-11: "every time the API and the model change ... properly test that everything works". Two stand-in model
    servers: the Settings page points at the first, then at the second; every part must follow at once, and a restart keeps it."""
    import json as _json
    import types
    import fuzz_app as F
    import model_env as ME
    from agentic import core
    from api import agentic_api as A
    from api import hier_api as H
    from api import isolate_api as I
    import stage1_runner
    if not os.path.isdir(F.BASE):
        pytest.skip("the S08 sample recording is not on this machine (the code-only zip carries no samples)")
    root = os.path.join(env, "app")
    os.makedirs(root)
    app, c, _k, _r = F.setup(root)
    s = app.config["services"]
    s.cfg.setdefault("llm", {})["backend"] = "http"
    s.cfg.setdefault("agentic", {}).update(model="", runtime="http")
    one, two = _FakeModel(), _FakeModel()
    try:
        with app.app_context():
            eng = A.engine()
        eng.runner.runtime = "http"
        after_one = None
        for fake, model, key in ((one, "company-model-1", "sk-test-key-one-00001111"), (two, "company-model-2", "sk-test-key-two-22223333")):
            r = c.put("/api/hier/model", json={"base_url": fake.url, "model": model, "key": key})
            assert r.status_code == 200, r.get_json()
            t = c.post("/api/hier/model/test").get_json()
            # the button's two checks: the model connection (stage 1 and 2, the error pages) and the agents
            assert t["ok"] is True and t["agents"]["ok"] is True, t
            assert len(fake.seen) >= 2 and all(x == {"path": "/v1/messages", "key": key, "model": model} for x in fake.seen), fake.seen
            # the error pages use the same model object
            with app.test_request_context("/"):
                assert I._llm(s, {}).model == model
            # Claude Code, when it runs the agents, is started with this model and inherits this key and address
            got = {}

            def fake_run(cmd, **kw):
                got.update(cmd=cmd, key=os.environ.get("ANTHROPIC_API_KEY"), url=os.environ.get("ANTHROPIC_BASE_URL"))
                return types.SimpleNamespace(returncode=0, stdout=_json.dumps({"result": '{"ok": "yes"}'}), stderr="")
            monkeypatch.setattr(core.subprocess, "run", fake_run)
            monkeypatch.setattr(core.AgentRunner, "find_claude", staticmethod(lambda configured=None: "/usr/bin/claude"))
            assert eng.runner._claude_code("x", env) == {"ok": "yes"}
            assert got["cmd"][got["cmd"].index("--model") + 1] == model and got["key"] == key and got["url"] == fake.url
            monkeypatch.undo()
            # stage 1 (the analyser's review) uses the same connection through the Anthropic package
            pytest.importorskip("anthropic")
            assert stage1_runner.llm_backend(s.cfg["llm"]) == "sdk"
            if fake is one:
                after_one = len(one.seen)
        assert after_one >= 2 and len(one.seen) == after_one          # after the switch nothing more went to the first server
        # a restart: the key saved on the page is loaded and wins over a key someone else left in the environment
        os.environ["ANTHROPIC_API_KEY"] = "someone-elses-key-99999999"
        ME.load(s.cfg, H.ENV_FILE)
        assert os.environ["ANTHROPIC_API_KEY"] == "sk-test-key-two-22223333" and os.environ["ANTHROPIC_BASE_URL"] == two.url
    finally:
        one.close()
        two.close()
