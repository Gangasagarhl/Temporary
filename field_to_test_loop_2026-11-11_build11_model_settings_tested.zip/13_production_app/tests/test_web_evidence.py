"""Web evidence: the agents may search the web, and every page they quote is checked by the program itself.

    python3 -m pytest -q tests/test_web_evidence.py

A local web server stands in for the internet: a quote that is on the page is verified (whatever the spacing, case or
punctuation), words that are not on it are not, a quote too short to prove anything is refused, and addresses that are
not http(s) pages on the internet are never fetched. The agent runner adds web search only when the admin allows it:
Claude Code gets the WebSearch and WebFetch tools, the model connection gets Anthropic's web tools in the version its
model takes.
"""
import http.server
import os
import sys
import threading

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from agentic import core   # noqa: E402

PAGE = b"""<!doctype html><html><head><title>PCIe notes</title><script>var x = "not text";</script></head>
<body><h1>Data Link Layer</h1><p>Each TLP is assigned a <b>Sequence Number</b> (PSN);
the receiver acknowledges it with an&nbsp;Ack DLLP.</p><p>A Nak requests that the TLPs after it are sent again.</p></body></html>"""


def _server():
    class H(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(PAGE)

        def log_message(self, *a):
            pass
    srv = http.server.HTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, "http://127.0.0.1:%d/notes.html" % srv.server_address[1]


def test_a_quote_on_the_page_is_verified_and_invented_words_are_not(tmp_path):
    srv, url = _server()
    try:
        web = core.WebSources(str(tmp_path), allow_local=True)
        assert web.has_quote(url, "Each TLP is assigned a Sequence Number (PSN); the receiver acknowledges it with an Ack DLLP.")
        assert web.has_quote(url, "each tlp is assigned a   SEQUENCE number")              # spacing and case do not matter
        assert not web.has_quote(url, "Each TLP is assigned a Tag by the completer")           # not on the page
        assert not web.has_quote(url, "var x = not text")                                      # scripts are not page text
        assert not web.has_quote(url, "PSN")                                                   # too short to prove anything
        claims = core.check_claims([{"text": "a", "source": {"kind": "web", "ref": url, "quote": "A Nak requests that the TLPs after it are sent again"}},
                                    {"text": "b", "source": {"kind": "web", "ref": url, "quote": "A Nak resets the link"}}], web=web)
        assert [c["verified"] for c in claims] == [True, False]
        assert "did not find the quoted words" in claims[1]["why"]
    finally:
        srv.shutdown()


def test_web_claims_stay_unverified_when_web_checking_is_off():
    c = core.check_claims([{"text": "a", "source": {"kind": "web", "ref": "https://example.com", "quote": "something long enough to check"}}])[0]
    assert c["verified"] is False and "checking web pages is off" in c["why"]


def test_only_internet_pages_are_fetched(tmp_path):
    web = core.WebSources(str(tmp_path))
    for bad in ("file:///etc/passwd", "ftp://example.com/x", "http://localhost/x", "http://127.0.0.1/x", "http://192.168.1.10/x",
                "http://10.0.0.1/x", "http://169.254.169.254/latest/meta-data", "javascript:alert(1)", ""):
        assert web.text(bad) is None, bad
    assert web._allowed("https://nvmexpress.org/specifications/")


def test_the_web_tools_follow_the_model():
    r = core.AgentRunner("/tmp/none", runtime="http", http_model="claude-haiku-5-5")
    assert [t["type"] for t in r._web_tools()] == ["web_search_20250305", "web_fetch_20250910"]
    for m in ("claude-sonnet-5-5", "claude-opus-5-5", "claude-opus-4-6", "claude-sonnet-4-6"):
        r.http_model = m
        assert [t["type"] for t in r._web_tools()] == ["web_search_20260209", "web_fetch_20260209"], m


def test_web_search_is_offered_only_when_the_admin_allows_it(tmp_path, monkeypatch):
    seen = []

    class P:
        returncode, stderr = 0, ""
        stdout = '{"result": "{\\"columns\\": []}"}'

    def fake_run(cmd, **kw):
        seen.append((cmd, kw.get("input", "")))
        return P()
    monkeypatch.setattr(core.subprocess, "run", fake_run)
    monkeypatch.setattr(core.AgentRunner, "find_claude", staticmethod(lambda configured=None: "/usr/bin/claude"))
    r = core.AgentRunner(str(tmp_path), runtime="claude-code", web=True)
    r.ask(1, "grounder", "Say what the columns mean.", {}, "{}", "columns", lambda: {"columns": []}, web=True)
    cmd, prompt = seen[-1]
    assert core.AgentRunner.READ_ONLY_HERE + ",WebSearch,WebFetch" in cmd and "THE WEB" in prompt
    r.web_enabled = False                      # Settings: the agents may not search the web
    r.ask(1, "grounder", "Say what the columns mean.", {}, "{}", "columns", lambda: {"columns": []}, web=True)
    cmd, prompt = seen[-1]
    assert core.AgentRunner.READ_ONLY_HERE in cmd and "WebSearch" not in " ".join(cmd) and "THE WEB" not in prompt
    assert r.web_sources() is None and not r.can_search_web()
