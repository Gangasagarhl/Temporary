#!/usr/bin/env python3
"""Functional end-to-end test of the five-level NVMe hierarchy application through its HTTP API, against a RUNNING
server, with the small synthetic sample samples/hier_synth (225 commands, 44,023 packets; command 207 is a vendor
opcode 0x7F refused with "Invalid Command Opcode").

What it walks, in order: sniff of the five files; upload + load job; row browsing (paging, filters, the tree, the
summary); page 3's defect table (one row per command, the three-way filter, the statements of commands 7 and 207,
the two timing limits with 100 ns tiny values, empty = not considered, the specification defaults); the findings and one finding's detail (chain, catalogue, signature, knowledge); the window and the
sequence optimiser; one chat with the model (ONE model call in the whole run); the reinforcement level through the
API (the four signals, versions, decay, cap, reorder, scenario name) and the Store class directly on a temporary
file; the generated test case; a second upload of the same files (the signature is seen again and the stored
procedures come back); the time limits (a 1 us split limit makes findings appear, the defaults make them go); and
the clean-up of both uploads.

Every check prints PASS or FAIL with a plain-English name; the exit code is 1 when any check failed.
Standard library only.   Usage: python3 tests/test_hier_e2e.py [--base URL] [--cleanup-store]

The knowledge store (db/hier_knowledge.sqlite) is shared across uploads on purpose: the procedures, signals and chat
lines this test writes stay there under the admin name "e2e" (the Store has no delete API). With --cleanup-store the
rows this run created are removed directly from the SQLite file at the end. The scenario name of the signature is
always put back to what it was before the run.
"""
import json
import os
import py_compile
import sqlite3
import subprocess
import sys
import tempfile
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

BASE = "http://127.0.0.1:8077"
if "--base" in sys.argv:
    BASE = sys.argv[sys.argv.index("--base") + 1]
CLEANUP_STORE = "--cleanup-store" in sys.argv

SAMPLE = os.path.join(ROOT, "samples", "hier_synth")
FILES = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv", "nvme_command": "nvme_command.csv"}
LEVELS = ["nvme_command", "nvme_transaction", "split", "link", "packets"]
EXPECT_ROWS = {"nvme_command": 225, "nvme_transaction": 2529, "split": 1271, "link": 22560, "packets": 44023}
BUILD_CHECKS = ["link_rows_whose_packet_count_differs", "split_rows_whose_link_count_differs",
                "ntx_rows_whose_unit_count_differs", "command_rows_whose_transaction_count_differs"]
ADMIN = "e2e"
DEVICE = "Synthetic NVMe SSD 1TB"
KNOWLEDGE_DB = os.path.join(ROOT, "db", "hier_knowledge.sqlite")
LOAD_TIMEOUT_S = 240
TOL = 1e-6          # floating-point tolerance on the Beta counts (every rule is a handful of multiplications)

RESULTS = []
MODEL_CALLS = {"n": 0}
CREATED = {"uploads": [], "procedures": [], "files": [], "signature": None, "scenario_before": None, "scenario_changed": False,
           "order_row_existed": None}
T0 = time.time()


def check(name, ok, detail=""):
    RESULTS.append((bool(ok), name, detail))
    print("%s  %s%s" % ("PASS" if ok else "FAIL", name, ("  | " + str(detail)[:300]) if detail else ""), flush=True)
    return bool(ok)


class ApiError(Exception):
    pass


def api(method, path, body=None, params=None, timeout=60, ok=(200,)):
    """One HTTP call; returns the decoded JSON. Raises ApiError with the request and the answer on a wrong status."""
    url = BASE + path + (("?" + urllib.parse.urlencode(params)) if params else "")
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers={"Content-Type": "application/json"} if data is not None else {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            status, text = r.status, r.read().decode()
    except urllib.error.HTTPError as e:
        status, text = e.code, e.read().decode(errors="replace")
    except (urllib.error.URLError, OSError) as e:
        raise ApiError("%s %s: no answer from the server (%s)" % (method, url, e))
    try:
        out = json.loads(text) if text else None
    except ValueError:
        out = {"_raw": text[:300]}
    if status not in ok:
        raise ApiError("%s %s -> HTTP %s: %s (body sent: %s)" % (method, url, status, json.dumps(out)[:400], json.dumps(body)[:300] if body is not None else "-"))
    return out


def wait_job(jid, timeout=LOAD_TIMEOUT_S):
    t0 = time.time()
    last = None
    while time.time() - t0 < timeout:
        j = api("GET", "/api/jobs/%s" % jid)
        if j["status"] in ("done", "failed", "cancelled"):
            return j
        p = (j.get("progress") or {})
        line = "%s %s" % (p.get("step"), p.get("pct"))
        if line != last:
            print("      job %s: %s %s" % (jid, p.get("step"), p.get("detail") or ""), flush=True)
            last = line
        time.sleep(1.0)
    raise ApiError("job %s did not finish within %d s" % (jid, timeout))


def upload(trace_name):
    body = {"files": {k: os.path.join(SAMPLE, v) for k, v in FILES.items()}, "operator": ADMIN, "device": DEVICE, "trace_name": trace_name}
    r = api("POST", "/api/hier/uploads", body)
    uid = r["upload_id"]
    CREATED["uploads"].append(uid)
    job = wait_job(r["job"])
    return uid, job


def rows(uid, **params):
    return api("GET", "/api/hier/uploads/%s/rows" % uid, params=params)


def detail(uid, fid):
    return api("GET", "/api/hier/uploads/%s/findings/%d" % (uid, fid))


def signal(uid, fid, body):
    body = dict(body, admin=ADMIN)
    return api("POST", "/api/hier/uploads/%s/findings/%d/signal" % (uid, fid), body)


def proc_by_id(know, pid):
    return next((p for p in know["exact"] if p["id"] == pid), None)


def status_error_finding_on_207(uid):
    """The cmd.status_error finding of command 207 (the vendor opcode refused with Invalid Command Opcode)."""
    fl = api("GET", "/api/hier/uploads/%s/findings" % uid, params={"rule": "cmd.status_error"})
    hits = [f for f in fl["findings"] if f.get("c_n") == 207]
    return fl, (hits[0] if hits else None)


# ---------------------------------------------------------------------------------------------- a mirror of the store's arithmetic
def sim_decay(p, DECAY):
    p["a"] = 1 + (p["a"] - 1) * (1 - DECAY)
    p["b"] = 1 + (p["b"] - 1) * (1 - DECAY)


def sim_cap(p, CAP):
    if p["a"] + p["b"] > CAP:
        k = CAP / (p["a"] + p["b"])
        p["a"], p["b"] = p["a"] * k, p["b"] * k


# ---------------------------------------------------------------------------------------------- the steps
def step1_sniff():
    print("\n-- 1. sniff")
    for key, name in FILES.items():
        r = api("POST", "/api/hier/sniff", {"path": os.path.join(SAMPLE, name)})
        hc = r.get("header_check") or {}
        check("sniff recognises %s as the %s level" % (name, key), r.get("level") == key, "level=%s" % r.get("level"))
        check("sniff header check finds every named column of %s" % name,
              hc.get("found_named_columns") == hc.get("expected_named_columns") and not hc.get("missing_columns"),
              "found %s of %s, missing %s" % (hc.get("found_named_columns"), hc.get("expected_named_columns"), hc.get("missing_columns")))


def step2_upload():
    print("\n-- 2. upload and load job")
    uid, job = upload("e2e sample")
    check("load job finishes with status done", job["status"] == "done", "status=%s error=%s" % (job["status"], job.get("error")))
    u = api("GET", "/api/hier/uploads/%s" % uid)
    check("upload status is loaded", u.get("status") == "loaded", u.get("status"))
    check("upload records operator, device and trace name", u.get("operator") == ADMIN and u.get("device") == DEVICE and u.get("trace_name") == "e2e sample")
    rep = u.get("load_reports") or {}
    for lv in LEVELS:
        check("load report: %s rows = %d" % (lv, EXPECT_ROWS[lv]), (rep.get(lv) or {}).get("rows") == EXPECT_ROWS[lv], (rep.get(lv) or {}).get("rows"))
        check("load report: %s header fully matched" % lv, (rep.get(lv) or {}).get("found_named_columns") == (rep.get(lv) or {}).get("expected_named_columns"))
    check("row counts in the staging database match the files", u.get("row_counts") == EXPECT_ROWS, u.get("row_counts"))
    checks = ((u.get("build") or {}).get("checks") or {})
    for c in BUILD_CHECKS:
        check("build check %s is 0" % c, checks.get(c) == 0, checks.get(c))
    check("rules ran and produced findings", ((u.get("rules") or {}).get("findings") or 0) > 0, (u.get("rules") or {}).get("findings"))
    return uid


def step3_rows(uid):
    print("\n-- 3. rows, paging, filters, tree, summary")
    r = rows(uid, level="nvme_command", top="1", limit=25)
    check("top level rows: total 225", r.get("total") == 225, r.get("total"))
    check("top level rows: first page holds 25 rows", len(r["rows"]) == 25 and r["has_more"], len(r["rows"]))
    last = r["last_key"]
    r2 = rows(uid, level="nvme_command", top="1", limit=25, after=last, count="0")
    check("keyset paging after=last_key returns the next 25", len(r2["rows"]) == 25 and all(x["rowid_file"] > last for x in r2["rows"]) and r2["first_key"] > last,
          "last_key=%s next first=%s" % (last, r2.get("first_key")))
    check("keyset page skips the count when count=0", r2.get("total") is None)
    f = rows(uid, level="nvme_command", filters=json.dumps([{"column": "opc", "op": "eq", "value": 127}]))
    check("filter opc equals 127 returns exactly command 207", f.get("total") == 1 and len(f["rows"]) == 1 and f["rows"][0].get("n") == 207,
          "total=%s n=%s" % (f.get("total"), [x.get("n") for x in f["rows"]]))
    cmd207 = f["rows"][0] if f["rows"] else None
    check("command 207 is a vendor opcode with a non-zero status", cmd207 and cmd207.get("opc") == 0x7F and (cmd207.get("sc") or 0) != 0,
          "opc=%s sct=%s sc=%s" % (cmd207 and cmd207.get("opc"), cmd207 and cmd207.get("sct"), cmd207 and cmd207.get("sc")))
    fa = rows(uid, level="nvme_command", top="1", finding_at="nvme_command", limit=500)
    errs = api("GET", "/api/hier/uploads/%s/findings" % uid, params={"level": "nvme_command", "severity": "error", "limit": 1000})
    err_cmds = {x["cmd_rowid"] for x in errs["findings"] if x.get("cmd_rowid")}
    check("finding_at=nvme_command narrows to the commands with a command-level error", 0 < fa.get("total", 0) < 225 and {x["rowid_file"] for x in fa["rows"]} == err_cmds,
          "%s rows, %d commands with a command-level error" % (fa.get("total"), len(err_cmds)))
    if not cmd207:
        return None
    kids = rows(uid, level="nvme_transaction", parent_level="nvme_command", parent=cmd207["rowid_file"])
    check("children of command 207 are 5 NVMe transactions", kids.get("total") == 5, "%s: %s" % (kids.get("total"), [k.get("type") for k in kids["rows"]]))
    entry = next((k for k in kids["rows"] if "Submission Queue Entry" in (k.get("type") or "")), None)
    check("one of them is the submission queue entry", entry is not None)
    if entry:
        spl = rows(uid, level="split", parent_level="nvme_transaction", parent=entry["rowid_file"])
        check("the entry transaction holds one split transaction", spl.get("total") == 1, spl.get("total"))
        if spl["rows"]:
            lnk = rows(uid, level="link", parent_level="split", parent=spl["rows"][0]["rowid_file"])
            check("the split under the entry has 2 link transactions", lnk.get("total") == 2, lnk.get("total"))
            if lnk["rows"]:
                pk = rows(uid, level="packets", parent_level="link", parent=lnk["rows"][0]["rowid_file"])
                check("a link transaction has 2 packets", pk.get("total") == 2, pk.get("total"))
                rel = {x.get("relation") for x in pk["rows"]}
                check("the packets carry a relation (member or context)", rel and rel <= {"member", "context"} and "member" in rel, rel)
                mem = rows(uid, level="packets", parent_level="link", parent=lnk["rows"][0]["rowid_file"], relation="member")
                check("relation=member filter keeps the member packets only", mem.get("total") == sum(1 for x in pk["rows"] if x.get("relation") == "member"), mem.get("total"))
    ctx = rows(uid, level="packets", relation="context", limit=1)
    check("context packets exist and can be listed by relation", (ctx.get("total") or 0) > 0, ctx.get("total"))
    sm = api("GET", "/api/hier/uploads/%s/summary" % uid, params={"limit": 10})
    tot = sm.get("totals") or {}
    # totals.nvme_transactions is the sum of the analyzer's per-command counts = the member transactions of the commands (not the file's 2,529:
    # the 74 register accesses and such belong to no command and are listed by relation=orphan)
    members = rows(uid, level="nvme_transaction", relation="member", limit=1).get("total") or 0
    orphans = rows(uid, level="nvme_transaction", relation="orphan", limit=1).get("total") or 0
    check("NVMe transactions outside any command are listed by relation=orphan and members add up to the file", orphans > 0 and members + orphans == 2529, "%d members + %d orphans" % (members, orphans))
    # the page's "rows outside any command" mode asks for top=1&relation=orphan (app/static/js/hier.js); top=1 means parent_level IS NULL AND parent IS NULL,
    # but the builder writes parent_level (and parent NULL) for an orphan row, so that list must still hold the orphans
    page = rows(uid, level="nvme_transaction", top="1", relation="orphan", limit=1)
    check("the page's 'rows outside any command' query (top=1&relation=orphan) lists the orphans", page.get("total") == orphans, "%s listed of %d orphans" % (page.get("total"), orphans))
    check("summary returns totals and rows", sm.get("total") == 225 and tot.get("commands") == 225 and len(sm["rows"]) == 10 and tot.get("nvme_transactions") == members, "total %s rows %s" % (sm.get("total"), len(sm.get("rows") or [])))
    check("summary row 207 shows a command-level finding", any(x.get("n") == 207 and (x.get("findings_by_level") or {}).get("nvme_command") for x in
          api("GET", "/api/hier/uploads/%s/summary" % uid, params={"filters": json.dumps([{"column": "opc", "op": "eq", "value": 127}])})["rows"]))
    return cmd207


def step3b_defect_table(uid):
    print("\n-- 3b. page 3: the defect table, the statements and the two timing limits")
    dt = api("GET", "/api/hier/uploads/%s/defect_table" % uid, params={"limit": 300})
    tl = dt.get("timing_limits") or {}
    lk, nt = tl.get("link") or {}, tl.get("nvme_transaction") or {}
    check("defect table: the link transaction limit defaults to 50 us from PCIe Base 3.6.2.1 (replay timer)", lk.get("text") == "50 us" and lk.get("value") == 50 and lk.get("unit") == "us" and lk.get("considered") is True
          and lk.get("set_by_admin") is False and "PCIe Base 3.6.2.1" in (lk.get("source") or "") and lk.get("rule") == "lnk.response_over_limit", lk)
    check("defect table: the NVMe transaction limit defaults to 50 ms from PCIe Base 2.8 (completion timeout)", nt.get("text") == "50 ms" and nt.get("value") == 50 and nt.get("unit") == "ms" and nt.get("considered") is True
          and nt.get("set_by_admin") is False and "PCIe Base 2.8" in (nt.get("source") or "") and nt.get("rule") == "ntx.over_limit", nt)
    check("filter all (the default): one row per command, error or not (225)", dt.get("filter") == "all" and dt.get("total") == 225 and len(dt["rows"]) == 225, "%s %s" % (dt.get("filter"), dt.get("total")))
    e = api("GET", "/api/hier/uploads/%s/defect_table" % uid, params={"filter": "error", "limit": 300})
    check("filter error: every row has an error and command 207 (status error) is among them; idle gaps at or above the default limits count too (Time Delta rule, 2026-11-03)", 1 <= e.get("total", 0) <= 225 and all(r["has_error"] is True for r in e["rows"]) and 207 in [r["n"] for r in e["rows"]], "%s %s" % (e.get("total"), [r["n"] for r in e["rows"]][:12]))
    ne = api("GET", "/api/hier/uploads/%s/defect_table" % uid, params={"filter": "no_error", "limit": 10})
    check("filter no_error: the commands without any error, the complement of the error filter", ne.get("total") == 225 - e.get("total", 0) and all(r["has_error"] is False and r["first_finding"] is None for r in ne["rows"]), ne.get("total"))
    bad = api("GET", "/api/hier/uploads/%s/defect_table" % uid, params={"filter": "maybe"}, ok=(400,))
    check("an unknown filter is refused", "filter" in (bad.get("error") or ""), bad)
    rows_by_n = {r["n"]: r for r in dt["rows"]}
    r = rows_by_n.get(207, {})
    check("column 1 of command 207: name, queue, id, status in words, duration with a unit", r.get("command") and r.get("sqid") == 1 and r.get("cid") == 5 and r.get("status_text") == "Invalid Command Opcode (type 0, code 1)"
          and r.get("status_ok") is False and r.get("dur_ps_text", "").split()[-1] in ("ps", "ns", "us", "ms", "s"), "%s queue %s id %s status %s took %s" % (r.get("command"), r.get("sqid"), r.get("cid"), r.get("status_text"), r.get("dur_ps_text")))
    tx = r.get("transactions") or []
    check("column 2: the 5 NVMe transactions of command 207, each with a type and its number", len(tx) == 5 and all(t.get("type") and t.get("n") for t in tx) and any("Doorbell" in t["type"] for t in tx), [(t.get("type"), t.get("n")) for t in tx])
    check("column 3: each transaction carries its own duration and the analyzer's Time Delta as text", all("dur_ps_text" in t and "delta_ps_text" in t for t in tx), [(t.get("dur_ps_text"), t.get("delta_ps_text")) for t in tx][:3])
    st = r.get("statement") or ""
    check("column 4 of command 207: the statement says what it did and how it ended", st.startswith("opcode 0x7F on namespace 1, completed with status Invalid Command Opcode (type 0, code 1) in "), st[:120])
    check("column 4 of command 207: the statement carries the error with its evidence, the basis and where it was seen",
          "The drive answered the command with an error status: status 0x0001: type 0, code 1, Invalid Command Opcode, do not retry; basis: the command's status field is not Successful Completion" in st
          and "(firm: specification; NVMe Base 2.1" in st and "seen on the command itself. Specification: NVMe Base 2.1" in st and "No error" not in st, st[120:400])
    fs = r.get("findings") or []
    check("column 4 of command 207: the chips (findings) hold cmd.status_error and the row names it as the first error", any(f["rule"] == "cmd.status_error" for f in fs) and r.get("first_finding") == next((f["id"] for f in fs if f["severity"] == "error"), None), [(f["rule"], f["id"]) for f in fs])
    r7 = rows_by_n.get(7, {})
    check("column 4 of command 7 (a read without an error): 'Read of 16 blocks at block 2,097,152 on namespace 1, completed with success in …' then 'No error.'",
          (r7.get("statement") or "").startswith("Read of 16 blocks at block 2,097,152 on namespace 1, completed with success in ") and (r7.get("statement") or "").endswith(" No error.")
          and r7.get("status_text") == "success" and r7.get("status_ok") is True and r7.get("has_error") is False and r7.get("findings") == [] and r7.get("link_findings") == [], r7.get("statement"))
    r1 = rows_by_n.get(1, {})
    check("column 4 of an admin command names its parameter: 'Identify (admin) with CNS 1, completed with success in …'", (r1.get("statement") or "").startswith("Identify (admin) with CNS 1, completed with success in "), r1.get("statement"))
    a = api("GET", "/api/hier/uploads/%s/defect_table" % uid, params={"limit": 25})
    b = api("GET", "/api/hier/uploads/%s/defect_table" % uid, params={"limit": 25, "after": a["last_key"], "count": 0})
    check("keyset paging: 25 per page, after=last_key gives the next 25 with larger keys and no count", len(a["rows"]) == 25 and a["has_more"] and len(b["rows"]) == 25 and all(x["rowid_file"] > a["last_key"] for x in b["rows"]) and b.get("total") is None, "%s > %s" % (b.get("first_key"), a["last_key"]))
    f = api("GET", "/api/hier/uploads/%s/defect_table" % uid, params={"filters": json.dumps([{"column": "opc", "op": "eq", "value": 127}])})
    check("the column filters of page 2 apply to the table too (opc = 127 -> command 207)", f.get("total") == 1 and f["rows"][0]["n"] == 207)
    # a tiny link limit (the sample's link transactions wait at most 260 ns for their Ack): only lnk.response_over_limit runs again
    before = api("GET", "/api/hier/uploads/%s/findings" % uid, params={"limit": 1})
    n_links = rows(uid, level="link", limit=1).get("total") or 0
    r1 = api("PUT", "/api/hier/uploads/%s/timing_limits" % uid, {"link": {"value": 100, "unit": "ns"}}, timeout=180)
    c1 = (r1.get("counts") or {}).get("link") or {}
    n_slow = c1.get("after") or 0
    check("PUT timing_limits {link: 100 ns} stores it under thresholds.link and re-runs only the link level", r1.get("changed") == ["link"] and (r1.get("thresholds") or {}).get("link", {}).get("ps") == 100000
          and r1["timing_limits"]["link"]["set_by_admin"] is True and r1["timing_limits"]["link"]["text"] == "100 ns" and "nvme_transaction" not in (r1.get("counts") or {}), r1.get("changed"))
    check("the link-level timing rule fired on some but not all of the %d link transactions (%d with a Time Delta at or above 100 ns)" % (n_links, n_slow), 0 <= (c1.get("before") or 0) < n_slow < n_links and c1.get("rule") == "lnk.response_over_limit", c1)
    check("the other rules' counts did not change", {k: v for k, v in (c1.get("by_rule") or {}).items() if k != "lnk.response_over_limit"} == {k: v for k, v in (before.get("by_rule") or {}).items() if k != "lnk.response_over_limit"},
          "%s vs %s" % (c1.get("by_rule"), before.get("by_rule")))
    dt2 = api("GET", "/api/hier/uploads/%s/defect_table" % uid, params={"limit": 300})
    x7 = next((y for y in dt2["rows"] if y["n"] == 7), {})
    lf = x7.get("link_findings") or []
    check("with a 100 ns link limit the error filter holds most commands (every command with a link row whose Time Delta reaches 100 ns)", (lambda t: 0 < t <= 225)(api("GET", "/api/hier/uploads/%s/defect_table" % uid, params={"filter": "error", "limit": 1}).get("total") or 0), api("GET", "/api/hier/uploads/%s/defect_table" % uid, params={"filter": "error", "limit": 1}).get("total"))
    check("the statement of command 7 names the link transactions whose Time Delta reaches the 100 ns limit, under their NVMe transactions", "A link transaction under this command has a Time Delta at or above the link limit: link transaction " in (x7.get("statement") or "") and "limit 100 ns (set by the admin" in (x7.get("statement") or ""), (x7.get("statement") or "")[120:420])
    tx_rowids = {t["rowid"]: t for t in x7.get("transactions") or []}
    check("each slow link transaction is placed under its NVMe transaction (number, type, TLP kind, chain text)",
          lf and all(f["rule"] == "lnk.response_over_limit" and f["limit_ps_text"] == "100 ns" and (f.get("value_ps") or 0) >= 100000 and f.get("ntx_rowid") in tx_rowids
                     and f.get("ntx_n") == tx_rowids[f["ntx_rowid"]]["n"] and f.get("tlp_type") and "command 7" in (f.get("under") or "") for f in lf), [(f.get("row_n"), f.get("ntx_n"), f.get("under")) for f in lf][:2])
    check("the roll-up ran: command 7 is 'lower-level finding inside this command' with n_sub_findings = its slow links; command 207 is 'caused by the link level'",
          x7.get("n_sub_findings") == len(lf) > 0 and (x7.get("role") or "").startswith("lower-level finding") and x7.get("cause_level") == "link"
          and (next((y for y in dt2["rows"] if y["n"] == 207), {}).get("role") or "").startswith("caused by the link"), "%s / %s" % (x7.get("role"), x7.get("n_sub_findings")))
    # a tiny NVMe transaction limit (the sample's transactions take at most 540 ns from first to last packet; the data pages 18 ns to 540 ns)
    r2 = api("PUT", "/api/hier/uploads/%s/timing_limits" % uid, {"nvme_transaction": {"value": 100, "unit": "ns"}}, timeout=180)
    c2 = (r2.get("counts") or {}).get("nvme_transaction") or {}
    n_ntx = rows(uid, level="nvme_transaction", limit=1).get("total") or 0
    check("PUT timing_limits {nvme_transaction: 100 ns} re-runs only the NVMe transaction level: ntx.over_limit fired on some but not all of the %d transactions (%d)" % (n_ntx, c2.get("after") or 0),
          r2.get("changed") == ["nvme_transaction"] and c2.get("rule") == "ntx.over_limit" and 0 < (c2.get("after") or 0) < n_ntx and (c2.get("by_rule") or {}).get("lnk.response_over_limit") == n_slow, c2)
    x7 = next((y for y in api("GET", "/api/hier/uploads/%s/defect_table" % uid, params={"filters": json.dumps([{"column": "n", "op": "eq", "value": 7}])})["rows"] if y["n"] == 7), {})
    st7 = x7.get("statement") or ""
    check("the statement of command 7 names the NVMe transactions whose Time Delta reaches the 100 ns limit", "An NVMe transaction's Time Delta is at or above the NVMe-transaction limit: transaction " in st7 and "limit 100 ns (set by the admin" in st7, st7[120:420])
    check("the ntx timing findings are in the chips with their evidence facts (Time Delta …, limit …, basis)", any(f["rule"] == "ntx.over_limit" and any(x.startswith("Time Delta ") for x in f["evidence"]["facts"]) and any(x.startswith("basis: ") for x in f["evidence"]["facts"]) for f in x7.get("findings") or []), [(f["rule"], f["row_n"]) for f in x7.get("findings") or []][:6])
    th = api("GET", "/api/hier/uploads/%s/thresholds" % uid)
    check("GET thresholds shows both page-3 limits", (th.get("link") or {}).get("ps") == 100000 and (th.get("nvme_transaction") or {}).get("ps") == 100000, th)
    fl = api("GET", "/api/hier/uploads/%s/findings" % uid, params={"rule": "lnk.response_over_limit", "limit": 1})
    check("the findings list agrees: %d lnk.response_over_limit, limit 100 ns set by the admin" % n_slow, fl.get("total") == n_slow and (fl.get("limits") or {}).get("link", {}).get("text") == "100 ns" and (fl.get("limits") or {}).get("link", {}).get("set_by_admin") is True, fl.get("limits"))
    # empty fields: timing at that level is not considered
    r3 = api("PUT", "/api/hier/uploads/%s/timing_limits" % uid, {"link": None, "nvme_transaction": {"value": "", "unit": "ms"}}, timeout=180)
    c3 = r3.get("counts") or {}
    check("PUT null / empty value: both levels re-run, their findings deleted, the limits stored as none", sorted(r3.get("changed") or []) == ["link", "nvme_transaction"] and c3["link"]["after"] == 0 and c3["link"]["before"] == n_slow
          and c3["nvme_transaction"]["after"] == 0 and c3["nvme_transaction"]["before"] == c2.get("after") and r3.get("thresholds") == {"link": None, "nvme_transaction": None}
          and r3["timing_limits"]["link"]["considered"] is False and r3["timing_limits"]["link"]["text"] == "not considered" and r3["timing_limits"]["nvme_transaction"]["considered"] is False, (r3.get("changed"), r3.get("thresholds")))
    x7 = api("GET", "/api/hier/uploads/%s/defect_table" % uid, params={"filters": json.dumps([{"column": "n", "op": "eq", "value": 7}])})["rows"][0]
    check("the statement says 'No error.' and that timing at both levels is not considered", x7["statement"].endswith(" No error. Timing at the link level: not considered. Timing at the NVMe transaction level: not considered.") and x7["has_error"] is False, x7["statement"])
    check("the error filter is back to command 207 alone", api("GET", "/api/hier/uploads/%s/defect_table" % uid, params={"filter": "error", "limit": 5}).get("total") == 1 and r3.get("commands_with_errors") == 1)
    th = api("GET", "/api/hier/uploads/%s/thresholds" % uid)
    check("the settings page's PUT keeps the two 'not considered' states (null) when it saves another level", api("PUT", "/api/hier/uploads/%s/thresholds" % uid, {"link": None, "nvme_transaction": None, "split": {"value": 50, "unit": "ms", "source": "e2e"}}, timeout=180).get("thresholds", {}).get("link", "missing") is None
          and api("GET", "/api/hier/uploads/%s/thresholds" % uid).get("nvme_transaction", "missing") is None)
    # back to the specification defaults
    r4 = api("PUT", "/api/hier/uploads/%s/timing_limits" % uid, {"link": "default", "nvme_transaction": "default"}, timeout=180)
    check("PUT \"default\" puts the specification defaults back (50 us, 50 ms) and the thresholds hold no page-3 entries", r4.get("changed") == ["link", "nvme_transaction"] and not any(k in (r4.get("thresholds") or {}) for k in ("link", "nvme_transaction")), (r4.get("changed"), r.get("thresholds")))
    r5 = api("PUT", "/api/hier/uploads/%s/timing_limits" % uid, {"link": "default"}, timeout=180)
    check("an apply that changes nothing re-runs nothing", r5.get("changed") == [] and r5.get("counts") == {}, r5.get("changed"))
    bad = api("PUT", "/api/hier/uploads/%s/timing_limits" % uid, {"link": {"value": "abc", "unit": "ms"}}, ok=(400,))
    check("a limit that is not a number is refused", "number" in (bad.get("error") or ""), bad)
    x7 = api("GET", "/api/hier/uploads/%s/defect_table" % uid, params={"filters": json.dumps([{"column": "n", "op": "eq", "value": 7}])})["rows"][0]
    check("command 7 is back to a plain 'No error.' statement", x7["statement"].endswith(" No error.") and "not considered" not in x7["statement"], x7["statement"])
    _, f207 = status_error_finding_on_207(uid)
    check("the status-error finding on command 207 survived the partial re-runs with its id", f207 is not None and f207["id"] == r["first_finding"], "%s / %s" % (f207 and f207["id"], r.get("first_finding")))
    # page 1's rule: the drive under test is required, the name is not
    no_dev = api("POST", "/api/hier/uploads", {"files": {k: os.path.join(SAMPLE, v) for k, v in FILES.items()}, "operator": ADMIN, "device": ""}, ok=(400,))
    check("an upload without the drive under test is refused", "drive under test" in (no_dev.get("error") or ""), no_dev)


def step4_findings(uid):
    print("\n-- 4. findings")
    fl = api("GET", "/api/hier/uploads/%s/findings" % uid)
    check("findings list has a total and the per-rule counts", (fl.get("total") or 0) > 0 and isinstance(fl.get("by_rule"), dict) and fl.get("by_level"),
          "total=%s by_level=%s" % (fl.get("total"), fl.get("by_level")))
    check("findings counts include cmd.status_error", (fl.get("by_rule") or {}).get("cmd.status_error", 0) >= 1, (fl.get("by_rule") or {}).get("cmd.status_error"))
    fl2, f = status_error_finding_on_207(uid)
    check("filter rule=cmd.status_error returns the finding on command 207", f is not None and all(x["rule"] == "cmd.status_error" for x in fl2["findings"]),
          "%d findings, command numbers %s" % (len(fl2["findings"]), [x.get("c_n") for x in fl2["findings"]][:10]))
    if f is None:
        return None, None
    check("the finding names Invalid Command Opcode", "Invalid Command Opcode" in (f.get("name") or ""), f.get("name"))
    d = detail(uid, f["id"])
    chain = d.get("chain") or []
    check("detail has a chain that ends at command 207", chain and chain[-1]["level"] == "nvme_command" and chain[-1].get("n") == 207 and all(c["level"] in LEVELS for c in chain),
          "%d element(s): %s (a command-level finding: its row is the command itself)" % (len(chain), [c["level"] for c in chain]))
    check("detail carries the source row and the command", (d.get("source_row") or {}).get("n") == 207 and (d.get("command") or {}).get("rowid") == f["cmd_rowid"])
    cat = d.get("catalogue") or {}
    check("detail has the catalogue text", bool(cat) and len(json.dumps(cat)) > 40, json.dumps(cat)[:120])
    sig = d.get("signature") or {}
    check("signature display starts with v1|dev:", (sig.get("display") or "").startswith("v1|dev:"), sig.get("display"))
    check("signature names the command-level status error of the vendor opcode", "err:cmd.status_error" in sig.get("display", "") and "vendor_0x7F" in sig.get("display", ""), sig.get("display"))
    k = d.get("knowledge") or {}
    seen = k.get("seen")
    check("knowledge.seen is a count (1 on the first ever sight)", isinstance(seen, int) and seen >= 1,
          ("seen before this run: yes (%d sightings incl. this one, %d stored procedure(s))" % (seen, len(k.get("exact") or []))) if seen > 1 else "first ever sight")
    check("detail has the chat history list", isinstance(d.get("chat"), list), type(d.get("chat")).__name__)
    CREATED["signature"] = sig.get("fine")
    CREATED["scenario_before"] = k.get("scenario_name")
    return f["id"], d


def step5_window(uid, fid):
    print("\n-- 5. window and optimise")
    w = api("GET", "/api/hier/uploads/%s/findings/%d/window" % (uid, fid), params={"level": "nvme_command", "n": 2, "m": 1})
    pos = [r.get("position") for r in w.get("rows") or []]
    check("window n=2 m=1 same queue returns 4 rows above/fault/below", pos == ["above", "above", "fault", "below"] and w.get("same_queue") is True, pos)
    check("window rows carry the gap text to the previous row", all(r.get("gap_text") for r in (w.get("rows") or [])[1:]), [r.get("gap_text") for r in w.get("rows") or []])
    check("window fault row is command 207 with its finding", any(r["position"] == "fault" and r.get("n") == 207 and r.get("findings") for r in w.get("rows") or []))
    o = api("POST", "/api/hier/uploads/%s/findings/%d/optimise" % (uid, fid), {"level": "nvme_command", "n": 2, "m": 1, "same_queue": True})
    steps = o.get("steps") or []
    check("optimise keeps only the fault (steps == 1, why 'the fault')", len(steps) == 1 and steps[0].get("why") == ["the fault"] and steps[0].get("position") == "fault",
          "%d steps: %s" % (len(steps), [(s.get("command"), s.get("why")) for s in steps]))
    check("optimise reports what it dropped", o.get("dropped_above") == 2 and o.get("dropped_below") == 1, "%s/%s" % (o.get("dropped_above"), o.get("dropped_below")))
    # the window at a lower level anchors on the finding's own row or an ancestor: a command-level finding has no link row,
    # so the link-level window is taken on a finding that lives at or below the link level
    low = api("GET", "/api/hier/uploads/%s/findings" % uid, params={"level": "link", "limit": 1})
    if not low["findings"]:
        low = api("GET", "/api/hier/uploads/%s/findings" % uid, params={"level": "packets", "limit": 1})
    if low["findings"]:
        lf = low["findings"][0]
        wl = api("GET", "/api/hier/uploads/%s/findings/%d/window" % (uid, lf["id"]), params={"level": "link", "n": 3, "m": 3})
        pl = [r.get("position") for r in wl.get("rows") or []]
        check("window at the link level (n=3, m=3) returns link rows around a %s-level finding" % lf["level"],
              wl.get("level") == "link" and "fault" in pl and pl.count("above") <= 3 and pl.count("below") <= 3 and len(pl) >= 2 and all("psn" in r for r in wl["rows"]), pl)
    else:
        check("window at the link level (n=3, m=3) returns link rows", False, "the sample has no link- or packet-level finding to anchor on")
    # for the command-level finding itself the window at a lower level is placed around the first member row under the command
    wl = api("GET", "/api/hier/uploads/%s/findings/%d/window" % (uid, fid), params={"level": "link", "n": 3, "m": 3})
    pl = [r.get("position") for r in wl.get("rows") or []]
    fault = next((r for r in wl.get("rows") or [] if r.get("position") == "fault"), None)
    check("window at the link level (n=3, m=3) for the command-level finding returns link rows around the command's first link transaction",
          wl.get("level") == "link" and pl == ["above"] * 3 + ["fault"] + ["below"] * 3 and "first link transaction" in (wl.get("note") or "") and fault and "psn" in fault,
          "%s | %s" % (pl, wl.get("note")))
    check("the link rows say which command they belong to and how many packets lie below", fault and fault.get("command_rowid") == (detail(uid, fid).get("command") or {}).get("rowid")
          and (fault.get("below_count") or {}).get("packets", 0) > 0, "%s / %s" % (fault and fault.get("command"), fault and fault.get("below_count")))
    return steps


def step0_model():
    """The model connection: settings readable, the key present (or not), and one test call with retries."""
    print("\n-- 0. model connection")
    m = api("GET", "/api/hier/model")
    check("the model settings are readable (backend, model, key variable, key present or not)", all(k in m for k in ("backend", "model", "api_key_env", "key_present", "active", "retries")), {k: m.get(k) for k in ("backend", "model", "api_key_env", "key_present", "active")})
    check("the retry policy is stated (4 tries, pauses from 2 s)", (m.get("retries") or {}).get("tries") == 4)
    r = api("POST", "/api/hier/model/test", {}, timeout=240)
    MODEL_CALLS["n"] += 1 if r.get("ok") else 0
    check("the connection test reports who answered or why not", "producer" in r and ("tries" in r or "error" in r), {k: r.get(k) for k in ("ok", "producer", "tries", "seconds", "error")})
    if m.get("key_present"):
        check("with a key present the model answers the test call", bool(r.get("ok")), r.get("error"))
    return m


def step6_chat(uid, fid, scenario_before):
    print("\n-- 6. chat (one model call)")
    # a signature that already has a stored procedure is not sent to the model unless the admin asks for a new proposal anyway
    know = api("GET", "/api/hier/uploads/%s/findings/%d" % (uid, fid)).get("knowledge") or {}
    if know.get("exact"):
        try:
            api("POST", "/api/hier/uploads/%s/findings/%d/chat" % (uid, fid), {"message": "x", "admin": ADMIN, "level": "nvme_command", "n": 2, "m": 1, "same_queue": True}, timeout=60)
            refused = False
        except Exception as e:      # noqa: BLE001 - urllib raises on HTTP 409
            refused = "409" in str(e) or "already stored" in str(e)
        check("a stored signature is not sent to the model without 'a new proposal anyway'", refused)
    else:
        check("a signature with nothing stored may be sent to the model", True)
    MODEL_CALLS["n"] += 1
    r = api("POST", "/api/hier/uploads/%s/findings/%d/chat" % (uid, fid),
            {"message": "Name this scenario, propose the shortest sequence that reproduces it and say what a correct drive should answer.", "admin": ADMIN,
             "level": "nvme_command", "n": 2, "m": 1, "same_queue": True, "anyway": True}, timeout=240)
    ans = r.get("answer") or {}
    eo = ans.get("expected_outcome") or {}
    d0 = api("GET", "/api/hier/uploads/%s/findings/%d" % (uid, fid))
    check("the finding detail states the rule's basis (kind, text, source, firm or suspect)", isinstance(d0.get("basis"), dict) and d0["basis"].get("kind") == "specification" and d0["basis"].get("firm") is True and "NVMe Base" in (d0["basis"].get("ref") or ""), d0.get("basis"))
    dt = api("GET", "/api/hier/uploads/%s/defect_table" % uid, params={"limit": 1, "count": 0, "filters": json.dumps([{"column": "opc", "op": "eq", "value": 127}])})
    ev = ((dt.get("rows") or [{}])[0].get("findings") or [{}])[0].get("evidence") or {}
    check("page 3's evidence carries the basis line", any(str(x).startswith("basis:") for x in (ev.get("facts") or [])), ev.get("facts"))
    check("page 3's evidence names the specification or the source in its own line", any(str(x).startswith(("specification:", "source:")) for x in (ev.get("facts") or [])), ev.get("facts"))
    check("the finding detail carries the source sentence", str((d0.get("basis") or {}).get("words", "")).startswith(("Specification:", "Source:")), (d0.get("basis") or {}).get("words"))
    check("the proposal has the observed outcome (what the recording shows)", bool((ans.get("observed_outcome") or "").strip()), (ans.get("observed_outcome") or "")[:80])
    check("the proposal has an expected outcome with status, description and check", all((eo.get(k) or "").strip() for k in ("status", "description", "check")), eo)
    producer = ans.get("producer") or ""
    check("model answered (producer anthropic:...)", producer.startswith("anthropic:"), producer)
    check("chat proposal has a scenario name and a proposed sequence", (ans.get("scenario_name") or "").strip() and isinstance(ans.get("proposed_sequence"), list) and ans["proposed_sequence"],
          "%s | %d steps" % (ans.get("scenario_name"), len(ans.get("proposed_sequence") or [])))
    # the code checks (chat.check_answer): commands must be in chat.ALLOWED, cited rows inside the window. For this finding the fault command is a
    # vendor opcode outside that set, so even the deterministic stand-in's own sequence (the optimiser's fault step "opcode 0x7F") fails the check:
    # computed here without a model call, as evidence next to the result
    try:
        from nvme_hier import chat as CH, optimise as OPT
        w = api("GET", "/api/hier/uploads/%s/findings/%d/window" % (uid, fid), params={"level": "nvme_command", "n": 2, "m": 1})
        standin_ok, standin_problems = CH.check_answer(CH.standin_answer(detail(uid, fid), w, OPT.optimise(w["rows"])), w)
    except Exception as e:      # noqa: BLE001
        standin_ok, standin_problems = None, [str(e)]
    check("chat answer passes the code checks", (ans.get("checks") or {}).get("ok") is True,
          "%s | the stand-in's own sequence passes: %s %s" % (ans.get("checks"), standin_ok, standin_problems))
    check("chat history holds the question and the answer", isinstance(r.get("history"), list) and len(r["history"]) >= 2 and r["history"][-2]["role"] == "admin:" + ADMIN, len(r.get("history") or []))
    d = detail(uid, fid)
    k = d.get("knowledge") or {}
    if scenario_before:
        check("chat does not overwrite an existing scenario name", k.get("scenario_name") == scenario_before, "%s / %s" % (k.get("scenario_name"), scenario_before))
    else:
        check("chat names the scenario when it had no name", k.get("scenario_name") == ans.get("scenario_name"), k.get("scenario_name"))
        CREATED["scenario_changed"] = True
    return ans


def step7_signals(uid, fid, proposal):
    print("\n-- 7. the four signals and the store (through the API)")
    from nvme_hier import store as ST
    DECAY, CAP, INHERIT = ST.DECAY, ST.CAP, ST.INHERIT
    sim = {}
    steps = [{k: s[k] for k in ("step", "command", "parameters", "gap_us", "expected") if k in s} for s in (proposal.get("proposed_sequence") or [])]
    for i, s in enumerate(steps):
        s["step"] = i + 1
        s.setdefault("gap_us", 10)
    k0 = detail(uid, fid)["knowledge"]
    pre_ids = {p["id"] for p in k0["exact"]}
    with sqlite3.connect(KNOWLEDGE_DB, timeout=30) as _c:     # the store numbers versions from the highest one ever stored for this signature
        pre_versions = _c.execute("SELECT COALESCE(MAX(version), 0) FROM procedure WHERE fine=?", (CREATED["signature"],)).fetchone()[0]

    # a. correct on the fresh proposal -> stored as a new version with a=2, b=1
    outcome = {"observed": proposal.get("observed_outcome") or "", "expected": {k: (proposal.get("expected_outcome") or {}).get(k, "") for k in ("status", "description", "check")}, "verified_by": ADMIN}
    r = signal(uid, fid, {"signal": "correct", "procedure_id": None, "proposal_steps": steps, "proposal_text": proposal.get("summary") or "", "outcome": outcome})
    stored = next((p for p in (r.get("knowledge") or {}).get("exact", []) if p["id"] == (r.get("result") or {}).get("new_procedure_id")), {})
    check("the stored procedure keeps the observed and the verified expected outcome", (stored.get("outcome") or {}).get("verified_by") == ADMIN and ((stored.get("outcome") or {}).get("expected") or {}).get("status") == outcome["expected"]["status"], stored.get("outcome"))
    p1 = (r.get("result") or {}).get("new_procedure_id")
    check("signal correct on the proposal returns a procedure id", isinstance(p1, int), r.get("result"))
    if not isinstance(p1, int):
        return None
    CREATED["procedures"].append(p1)
    sim[p1] = {"a": 2.0, "b": 1.0}
    k = detail(uid, fid)["knowledge"]
    p = proc_by_id(k, p1)
    check("knowledge.exact lists the new procedure (one more than before): Beta(1, 1) with the Correct that stored it counted, shown as judgements",
          p and len(k["exact"]) == len(pre_ids) + 1 and p["a"] == 2.0 and p["b"] == 1.0 and p["c_ok"] == 1 and p["score_text"] == "judged correct 1 of 1 time" and p["status"] == "active",
          "exact=%d (before %d) a=%s b=%s score=%s" % (len(k["exact"]), len(pre_ids), p and p["a"], p and p["b"], p and p["score_text"]))
    again = signal(uid, fid, {"signal": "correct", "procedure_id": None, "proposal_steps": steps, "proposal_text": proposal.get("summary") or "", "outcome": outcome})
    check("storing the same steps again makes no copy (the existing procedure is judged instead)",
          (again.get("result") or {}).get("new_procedure_id") is None and (again.get("result") or {}).get("procedure_id") == (r.get("result") or {}).get("new_procedure_id"),
          again.get("result"))
    for q in sim.values():          # the repeat counted as a "correct" on the stored procedure: decay everything, then a + 1
        sim_decay(q, DECAY)
    sim[p1]["a"] += 1
    check("the stored version carries the proposal's steps and the producer llm", p and p["steps"] == steps and p["producer"] == "llm" and p["version"] >= 1,
          "version %s producer %s" % (p and p["version"], p and p["producer"]))

    # b. correct_with_edits -> old version superseded (a+1), new version inherits 0.7 of the evidence
    edited = json.loads(json.dumps(steps))
    edited[0]["gap_us"] = int(edited[0].get("gap_us") or 10) + 25
    for q in sim.values():
        sim_decay(q, DECAY)
    old = dict(sim[p1])
    sim[p1]["a"] += 1
    r = signal(uid, fid, {"signal": "correct_with_edits", "procedure_id": p1, "edited_steps": edited})
    p2 = (r.get("result") or {}).get("new_procedure_id")
    check("signal correct_with_edits creates a new version", isinstance(p2, int) and p2 != p1, r.get("result"))
    if not isinstance(p2, int):
        return None
    CREATED["procedures"].append(p2)
    sim[p2] = {"a": 1 + INHERIT * (old["a"] + 1 - 1), "b": 1 + INHERIT * (old["b"] - 1)}
    k = detail(uid, fid)["knowledge"]
    q = proc_by_id(k, p2)
    check("the old version is no longer listed (superseded)", proc_by_id(k, p1) is None)
    check("the new version supersedes the old one and carries the edited step", q and q["supersedes"] == p1 and q["steps"][0]["gap_us"] == edited[0]["gap_us"] and q["producer"] == "admin:" + ADMIN,
          "supersedes=%s gap=%s" % (q and q["supersedes"], q and q["steps"][0].get("gap_us")))
    check("the new version inherits 0.7 of the decayed evidence: a = 1 + 0.7*(a_old+1-1) = %.4f, b = %.4f" % (sim[p2]["a"], sim[p2]["b"]),
          q and abs(q["a"] - sim[p2]["a"]) < TOL and abs(q["b"] - sim[p2]["b"]) < TOL, "a=%s b=%s" % (q and q["a"], q and q["b"]))
    with sqlite3.connect(KNOWLEDGE_DB, timeout=30) as con:
        row = con.execute("SELECT status, a, b, c_ok_edit FROM procedure WHERE id=?", (p1,)).fetchone()
    check("the old version is marked superseded with a+1 in the store", row and row[0] == "superseded" and abs(row[1] - sim[p1]["a"]) < TOL and row[3] == 1, row)
    score_before = q["score"] if q else None

    # c. wrong on the active version -> b + 1, score drops
    for x in sim.values():
        sim_decay(x, DECAY)
    sim[p2]["b"] += 1
    r = signal(uid, fid, {"signal": "wrong", "procedure_id": p2})
    check("signal wrong creates no new version", (r.get("result") or {}).get("new_procedure_id") is None, r.get("result"))
    k = detail(uid, fid)["knowledge"]
    q = proc_by_id(k, p2)
    check("after wrong: b increased by 1 (after the 2 %% decay) and the score dropped", q and abs(q["b"] - sim[p2]["b"]) < TOL and abs(q["a"] - sim[p2]["a"]) < TOL and q["score"] < score_before,
          "a=%s b=%s score %s -> %s" % (q and q["a"], q and q["b"], score_before, q and q["score"]))

    # d. wrong_with_edits -> old superseded (b+1), new version a=2 b=1
    edited2 = json.loads(json.dumps(edited))
    edited2[0]["gap_us"] += 5
    for x in sim.values():
        sim_decay(x, DECAY)
    sim[p2]["b"] += 1
    r = signal(uid, fid, {"signal": "wrong_with_edits", "procedure_id": p2, "edited_steps": edited2})
    p3 = (r.get("result") or {}).get("new_procedure_id")
    check("signal wrong_with_edits creates a new version", isinstance(p3, int) and p3 != p2, r.get("result"))
    if not isinstance(p3, int):
        return None
    CREATED["procedures"].append(p3)
    sim[p3] = {"a": 1.0, "b": 1.0}
    k = detail(uid, fid)["knowledge"]
    q = proc_by_id(k, p3)
    check("the replacement starts neutral (a=1 b=1, not yet judged) and supersedes the wrong version", q and q["a"] == 1.0 and q["b"] == 1.0 and q["score_text"] == "not yet judged"
          and q["supersedes"] == p2 and proc_by_id(k, p2) is None,
          "a=%s b=%s supersedes=%s" % (q and q["a"], q and q["b"], q and q["supersedes"]))
    with sqlite3.connect(KNOWLEDGE_DB, timeout=30) as con:
        row = con.execute("SELECT status, a, b, c_wrong, c_wrong_edit FROM procedure WHERE id=?", (p2,)).fetchone()
        chain = [x[0] for x in con.execute("WITH RECURSIVE c(id, sup) AS (SELECT id, supersedes FROM procedure WHERE id=? UNION ALL "
                                           "SELECT p.id, p.supersedes FROM procedure p JOIN c ON p.id = c.sup) SELECT id FROM c", (p3,))]
    check("the wrong version is superseded with b+1 and both wrong counters", row and row[0] == "superseded" and abs(row[2] - sim[p2]["b"]) < TOL and row[3] == 1 and row[4] == 1, row)
    check("the version chain runs v3 -> v2 -> v1 through supersedes", chain == [p3, p2, p1], chain)
    versions = {}
    with sqlite3.connect(KNOWLEDGE_DB, timeout=30) as con:
        for pid in (p1, p2, p3):
            versions[pid] = con.execute("SELECT version FROM procedure WHERE id=?", (pid,)).fetchone()[0]
    check("versions number upward from the ones already stored", versions[p1] == pre_versions + 1 and versions[p2] == pre_versions + 2 and versions[p3] == pre_versions + 3, versions)

    # e. reorder: the admin's order holds until the next write
    other = [{"step": 1, "command": "Flush", "parameters": {}, "gap_us": 10 + (os.getpid() % 9000), "expected": "completes"},   # a run-unique gap: the same steps would be de-duplicated onto a stored procedure
             {"step": 2, "command": steps[-1]["command"] if steps else "Read", "parameters": steps[-1].get("parameters", {}) if steps else {}, "gap_us": 10, "expected": "the fault"}]
    r = signal(uid, fid, {"signal": "correct", "procedure_id": None, "proposal_steps": other, "proposal_text": "a second procedure for the reorder check"})
    p4 = (r.get("result") or {}).get("new_procedure_id")
    check("a second active procedure is stored for the reorder check", isinstance(p4, int), r.get("result"))
    if not isinstance(p4, int):
        return None
    CREATED["procedures"].append(p4)
    sim[p4] = {"a": 2.0, "b": 1.0}
    k = detail(uid, fid)["knowledge"]
    ids = [p["id"] for p in k["exact"]]
    want = list(reversed(ids))
    with sqlite3.connect(KNOWLEDGE_DB, timeout=30) as con:
        CREATED["order_row_existed"] = con.execute("SELECT COUNT(*) FROM procedure_order WHERE fine=?", (CREATED["signature"],)).fetchone()[0] > 0
    r = api("POST", "/api/hier/uploads/%s/findings/%d/reorder" % (uid, fid), {"order": want})      # no name: "admin" is recorded (the owner's rule of 2026-11-03)
    got = [p["id"] for p in (r.get("knowledge") or {}).get("exact") or []]
    check("reorder (without a name) returns the procedures in the admin's order", got == want, "%s vs %s" % (got, want))
    k = detail(uid, fid)["knowledge"]
    check("GET detail lists the procedures in the admin's order", [p["id"] for p in k["exact"]] == want and all(p.get("ordered_by") == "the admin's order" for p in k["exact"]),
          [p["id"] for p in k["exact"]])
    for x in sim.values():
        sim_decay(x, DECAY)
    sim[p3]["a"] += 1
    signal(uid, fid, {"signal": "correct", "procedure_id": p3})
    k = detail(uid, fid)["knowledge"]
    by_score = [p["id"] for p in sorted(k["exact"], key=lambda p: (-p["score"], -p["version"], p["created"]))]
    check("after the next signal the order reverts to score order", [p["id"] for p in k["exact"]] == by_score and all(p.get("ordered_by") == "score" for p in k["exact"]),
          "%s (scores %s)" % ([p["id"] for p in k["exact"]], [p["score"] for p in k["exact"]]))

    # f. scenario name through the signal
    name = "e2e: vendor opcode 0x7F refused"
    for x in sim.values():
        sim_decay(x, DECAY)
    sim[p3]["a"] += 1
    r = signal(uid, fid, {"signal": "correct", "procedure_id": p3, "scenario_name": name})
    CREATED["scenario_changed"] = True
    check("scenario_name given with a signal is returned in knowledge", (r.get("knowledge") or {}).get("scenario_name") == name and detail(uid, fid)["knowledge"].get("scenario_name") == name,
          (r.get("knowledge") or {}).get("scenario_name"))

    # g. decay: N signals on one procedure, the counts follow the implemented arithmetic and stay under the cap
    N = 8
    a0 = proc_by_id(detail(uid, fid)["knowledge"], p4)["a"]      # already decayed by the signals on p3 above
    check("the second procedure was decayed by the two signals on the other one (a = 1 + 0.98^2)", abs(a0 - (1 + (1 - DECAY) ** 2)) < TOL, a0)
    for _ in range(N):
        for x in sim.values():
            sim_decay(x, DECAY)
        sim[p4]["a"] += 1
        sim_cap(sim[p4], CAP)
        signal(uid, fid, {"signal": "correct", "procedure_id": p4})
    k = detail(uid, fid)["knowledge"]
    q4, q3 = proc_by_id(k, p4), proc_by_id(k, p3)
    closed = 1 + (a0 - 1) * (1 - DECAY) ** N + (1 - (1 - DECAY) ** N) / DECAY     # a after N 'correct' signals from a0: decay then +1 each time (geometric series)
    check("after %d correct signals: a follows the 2 %% decay towards the prior (closed form %.6f)" % (N, closed),
          q4 and abs(q4["a"] - sim[p4]["a"]) < TOL and abs(q4["a"] - closed) < TOL and abs(q4["b"] - 1.0) < TOL and q4["a"] + q4["b"] <= CAP,
          "a=%s b=%s" % (q4 and q4["a"], q4 and q4["b"]))
    check("the other active procedure decayed on every signal (a = 1 + (a-1)*0.98^n)", q3 and abs(q3["a"] - sim[p3]["a"]) < TOL and abs(q3["b"] - sim[p3]["b"]) < TOL,
          "a=%s expected %.6f" % (q3 and q3["a"], sim[p3]["a"]))
    check("every active procedure respects the cap a+b <= %d" % CAP, all(p["a"] + p["b"] <= CAP + TOL for p in k["exact"]))
    sigs = api("GET", "/api/hier/uploads/%s/findings/%d" % (uid, fid))["knowledge"]
    check("knowledge lists the lessons list (empty for this signature unless a proposal was judged wrong)", isinstance(sigs.get("lessons"), list))
    return {"p1": p1, "p2": p2, "p3": p3, "p4": p4, "steps": steps, "name": name, "gap": edited2[0]["gap_us"]}


def step7h_store_direct():
    print("\n-- 7h. the Store class directly on a temporary file")
    from nvme_hier import signature as SG, store as ST
    DECAY, CAP, INHERIT = ST.DECAY, ST.CAP, ST.INHERIT
    sig = SG.compute({"dev": "e2e dev", "fw": "1", "lvl": "nvme_command", "err": "cmd.status_error", "cmd": "io.vendor_0x7F", "part": "cqe", "cause": "self", "st": "sct0.sc01", "dnr": 1})
    with tempfile.TemporaryDirectory() as tmp:
        st = ST.Store(os.path.join(tmp, "k.sqlite"))
        check("store: a signature is counted once per sighting", st.touch_signature(sig) == 1 and st.touch_signature(sig) == 2 and st.lookup(sig)["seen"] == 2)
        st.signal(sig["fine"], None, "wrong", "e2e", proposal_text="a bad proposal")
        les = st.lookup(sig)["lessons"]
        check("store: wrong on a fresh proposal stores a lesson, no procedure", len(les) == 1 and les[0]["text"].startswith("model proposal judged wrong") and not st.lookup(sig)["exact"], les)
        r = st.signal(sig["fine"], None, "correct", "e2e", proposal_steps=[{"step": 1, "command": "Read"}], proposal_text="t")
        p = r["new_procedure_id"]
        ex = st.lookup(sig)["exact"]
        check("store: correct on a fresh proposal stores version 1 with a=2 b=1 and that Correct counted", len(ex) == 1 and ex[0]["id"] == p and ex[0]["version"] == 1 and ex[0]["a"] == 2 and ex[0]["b"] == 1
              and ex[0]["c_ok"] == 1)
        st.signal(sig["fine"], p, "correct", "e2e")
        a, b = 1 + (2 - 1) * (1 - DECAY) + 1, 1.0
        q = st.lookup(sig)["exact"][0]
        check("store: correct = decay then a+1 -> a=%.4f b=%.4f" % (a, b), abs(q["a"] - a) < TOL and abs(q["b"] - b) < TOL and q["c_ok"] == 2, "a=%s b=%s" % (q["a"], q["b"]))
        st.signal(sig["fine"], p, "wrong", "e2e")
        a, b = 1 + (a - 1) * (1 - DECAY), 1 + (b - 1) * (1 - DECAY) + 1
        q = st.lookup(sig)["exact"][0]
        check("store: wrong = decay then b+1 -> a=%.4f b=%.4f" % (a, b), abs(q["a"] - a) < TOL and abs(q["b"] - b) < TOL and q["c_wrong"] == 1, "a=%s b=%s" % (q["a"], q["b"]))
        r = st.signal(sig["fine"], p, "correct_with_edits", "e2e", edited_steps=[{"step": 1, "command": "Read"}, {"step": 2, "command": "Flush"}], edited_text="edited")
        p2 = r["new_procedure_id"]
        a_d, b_d = 1 + (a - 1) * (1 - DECAY), 1 + (b - 1) * (1 - DECAY)
        a2, b2 = 1 + INHERIT * (a_d + 1 - 1), 1 + INHERIT * (b_d - 1)
        ex = st.lookup(sig)["exact"]
        check("store: correct_with_edits -> one active version 2 that supersedes version 1", len(ex) == 1 and ex[0]["id"] == p2 and ex[0]["version"] == 2 and ex[0]["supersedes"] == p and ex[0]["text"] == "edited")
        check("store: the new version inherits a=1+0.7*(a_old+1-1)=%.4f b=1+0.7*(b_old-1)=%.4f" % (a2, b2), abs(ex[0]["a"] - a2) < TOL and abs(ex[0]["b"] - b2) < TOL, "a=%s b=%s" % (ex[0]["a"], ex[0]["b"]))
        con = sqlite3.connect(st.path)
        old = con.execute("SELECT status, a, b FROM procedure WHERE id=?", (p,)).fetchone()
        check("store: the old version is superseded with a+1 = %.4f" % (a_d + 1), old[0] == "superseded" and abs(old[1] - (a_d + 1)) < TOL and abs(old[2] - b_d) < TOL, old)
        r = st.signal(sig["fine"], p2, "wrong_with_edits", "e2e", edited_steps=[{"step": 1, "command": "Flush"}])
        p3 = r["new_procedure_id"]
        ex = st.lookup(sig)["exact"]
        b2_after = 1 + (b2 - 1) * (1 - DECAY) + 1
        old2 = con.execute("SELECT status, b, c_wrong_edit FROM procedure WHERE id=?", (p2,)).fetchone()
        check("store: wrong_with_edits -> version 3 at the neutral start a=1 b=1 supersedes version 2, which is superseded with b+1",
              len(ex) == 1 and ex[0]["id"] == p3 and ex[0]["version"] == 3 and ex[0]["supersedes"] == p2 and ex[0]["a"] == 1 and ex[0]["b"] == 1
              and old2[0] == "superseded" and abs(old2[1] - b2_after) < TOL and old2[2] == 1, "%s / %s" % (ex[0] if ex else None, old2))
        chain = [x[0] for x in con.execute("WITH RECURSIVE c(id, sup) AS (SELECT id, supersedes FROM procedure WHERE id=? UNION ALL "
                                           "SELECT q.id, q.supersedes FROM procedure q JOIN c ON q.id = c.sup) SELECT id FROM c", (p3,))]
        check("store: the version chain is v3 -> v2 -> v1", chain == [p3, p2, p])
        # cap
        big = st.add_procedure(sig["fine"], [{"step": 1, "command": "Write"}], "big", "admin:e2e", a=48.0, b=4.0)
        st.signal(sig["fine"], big, "correct", "e2e")
        q = next(x for x in st.lookup(sig)["exact"] if x["id"] == big)
        a_b, b_b = 1 + 47 * (1 - DECAY) + 1, 1 + 3 * (1 - DECAY)
        kf = CAP / (a_b + b_b)
        check("store: a+b over %d is scaled back to the cap, keeping the ratio" % CAP, abs(q["a"] + q["b"] - CAP) < TOL and abs(q["a"] - a_b * kf) < TOL and abs(q["b"] - b_b * kf) < TOL,
              "a=%.4f b=%.4f" % (q["a"], q["b"]))
        # reorder: valid until the next write
        ids = [x["id"] for x in st.lookup(sig)["exact"]]
        st.reorder(sig["fine"], list(reversed(ids)), "e2e")
        k = st.lookup(sig)
        check("store: the admin's order is used verbatim", [x["id"] for x in k["exact"]] == list(reversed(ids)) and k["exact"][0]["ordered_by"] == "the admin's order")
        st.signal(sig["fine"], p3, "correct", "e2e")
        k = st.lookup(sig)
        check("store: a signal invalidates the admin's order (score order again)", k["exact"][0]["ordered_by"] == "score" and [x["id"] for x in k["exact"]] == [x["id"] for x in sorted(k["exact"], key=lambda x: (-x["score"], -x["version"], x["created"]))])
        st.reorder(sig["fine"], ids, "e2e")
        st.add_procedure(sig["fine"], [{"step": 1, "command": "Read"}], "t", "admin:e2e")
        check("store: adding a procedure invalidates the admin's order too", st.lookup(sig)["exact"][0]["ordered_by"] == "score")
        st.set_scenario_name(sig["fine"], "named", "admin:e2e")
        st.add_lesson(sig["fine"], "a lesson", "admin:e2e")
        k = st.lookup(sig)
        check("store: scenario name and lessons come back in the lookup", k["scenario_name"] == "named" and len(k["lessons"]) == 2 and k["lessons"][0]["text"] == "a lesson")
        sigs = st.signals_of(sig["fine"])
        check("store: every signal is logged (%d) and the stats count them" % len(sigs), len(sigs) == 8 and st.stats()["signals"] == 8 and st.stats()["signatures"] == 1, st.stats())
        check("store: a signal outside the four is refused", _raises(lambda: st.signal(sig["fine"], p3, "maybe", "e2e"), ValueError))
        check("store: a signal on an unknown procedure is refused", _raises(lambda: st.signal(sig["fine"], 999999, "correct", "e2e"), ValueError))
        other = SG.compute({"dev": "other dev", "fw": "2", "lvl": "nvme_command", "err": "cmd.status_error", "cmd": "io.vendor_0x7F", "part": "cqe", "cause": "self", "st": "sct0.sc01", "dnr": 0})
        st.touch_signature(other)
        k = st.lookup(other)
        check("store: the same defect on another device is listed as similar (coarse key) with its procedures", k["seen"] == 1 and not k["exact"] and len(k["similar"]) == 1 and k["similar"][0]["procedures"])
        con.close()


def _raises(fn, exc):
    try:
        fn()
    except exc:
        return True
    except Exception:       # noqa: BLE001
        return False
    return False


def step8_testcase(uid, fid, p):
    print("\n-- 8. test case")
    outcome = {"observed": "opcode 0x7F completed with status Invalid Command Opcode", "verified_by": ADMIN,
               "expected": {"status": "Invalid Command Opcode (status type 0, code 1)", "description": "a vendor opcode the drive does not support is refused", "check": "status == (0, 1)"}}
    r = api("POST", "/api/hier/uploads/%s/findings/%d/testcase" % (uid, fid), {"admin": ADMIN, "n": 2, "m": 1, "procedure_id": p["p3"], "scenario_name": p["name"], "outcome": outcome})
    path = r.get("path") or ""
    CREATED["files"].append(path)
    suite = os.path.join(ROOT, "suite", "hier")
    check("test case written under suite/hier/", path.startswith(suite + os.sep) and os.path.isfile(path) and r.get("name", "").startswith("%s_f%d_v" % (uid, fid)), path)
    text = open(path).read() if os.path.isfile(path) else ""
    check("test case has a test function, the EXPECT switch and the fault step", "def test_" in text and "EXPECT" in text and "FAULT_STEP = 1" in text)
    check("test case names the vendor opcode 0x7F and asserts the recorded status (type 0, code 1)", "0x7f" in text.lower() and "want = (0, 1)" in text,
          [l.strip() for l in text.splitlines() if "want = " in l])
    check("test case names the scenario and the signature", p["name"] in text and "v1|dev:" in text)
    check("test case states the input's observed outcome and the verified expected outcome", "observed outcome: " + outcome["observed"] in text and "expected outcome: " + outcome["expected"]["status"] in text and ("verified by " + ADMIN) in text)
    check("test case fails with 'expected … got …'", "FAILED: expected" in text)
    ok = True
    try:
        py_compile.compile(path, doraise=True)
        subprocess.run([sys.executable, "-m", "py_compile", path], check=True, capture_output=True, timeout=60)
    except Exception as e:      # noqa: BLE001
        ok = False
        print("      py_compile:", e)
    check("test case compiles (python3 -m py_compile)", ok)
    k = detail(uid, fid)["knowledge"]
    q = proc_by_id(k, p["p3"])
    check("the procedure records the test path", q and q.get("test_path") == path, q and q.get("test_path"))


def step9_second_upload(fine1, seen1, p):
    print("\n-- 9. second upload of the same files: seen before")
    uid2, job = upload("e2e sample 2")
    check("second load job finishes", job["status"] == "done", job.get("error"))
    fl, f = status_error_finding_on_207(uid2)
    check("second upload has the cmd.status_error finding on command 207", f is not None)
    if f is None:
        return uid2
    d = detail(uid2, f["id"])
    k = d.get("knowledge") or {}
    check("the finding's signature fine key is the same as in the first upload", (d.get("signature") or {}).get("fine") == fine1, (d.get("signature") or {}).get("fine"))
    check("knowledge says seen before (count grew)", isinstance(k.get("seen"), int) and k["seen"] > seen1, "%s > %s" % (k.get("seen"), seen1))
    ids = {x["id"] for x in k.get("exact") or []}
    check("the procedures stored on the first upload are listed for the second", {p["p3"], p["p4"]} <= ids, sorted(ids))
    check("the scenario name set on the first upload comes back", k.get("scenario_name") == p["name"], k.get("scenario_name"))
    q = proc_by_id(k, p["p3"])
    check("the stored procedure keeps its edited steps and its test path across uploads", q and q["steps"][0].get("gap_us") == p["gap"] and q.get("test_path") == CREATED["files"][-1],
          "gap %s (want %s), test_path %s" % (q and q["steps"][0].get("gap_us"), p["gap"], q and q.get("test_path")))
    check("the chat history is per upload (empty on the second)", d.get("chat") == [], d.get("chat"))
    return uid2


def step10_thresholds(uid):
    print("\n-- 10. time limits")
    api("PUT", "/api/hier/uploads/%s/thresholds" % uid, {}, timeout=180)          # step 3b left a split limit; the defaults again
    th0 = api("GET", "/api/hier/uploads/%s/thresholds" % uid)
    check("thresholds are empty (defaults in force)", th0 == {}, th0)
    r = api("PUT", "/api/hier/uploads/%s/thresholds" % uid, {"split": {"value": 1, "unit": "us", "source": "e2e: very small limit"}}, timeout=180)
    check("PUT a 1 us split limit stores it in picoseconds and re-runs the rules", (r.get("thresholds") or {}).get("split", {}).get("ps") == 10 ** 6 and isinstance(r.get("rules"), dict),
          json.dumps(r.get("thresholds")))
    fl = api("GET", "/api/hier/uploads/%s/findings" % uid, params={"rule": "spl.latency_over_limit", "limit": 50})
    n = (fl.get("by_rule") or {}).get("spl.latency_over_limit", 0)
    check("findings now include spl.latency_over_limit (count > 0)", n > 0 and fl.get("total") == n, n)
    check("the findings report the admin's limit", (fl.get("limits") or {}).get("split", {}).get("set_by_admin") is True and (fl.get("limits") or {}).get("split", {}).get("text") == "1 us",
          (fl.get("limits") or {}).get("split"))
    inside = next((f for f in fl["findings"] if f.get("cmd_rowid")), None)
    check("one of them lies inside a command", inside is not None)
    if inside:
        d = detail(uid, inside["id"])
        ch = d.get("chain") or []
        check("the split finding's chain goes from the split up to its command", ch and ch[0]["level"] == "split" and ch[-1]["level"] == "nvme_command" and ch[-1]["rowid"] == inside["cmd_rowid"],
              [c["level"] for c in ch])
        check("the finding states the measured value and the 1 us limit", d.get("limit_ps_text") == "1 us" and (d.get("value_ps") or 0) > 10 ** 6, "%s / %s" % (d.get("value_ps_text"), d.get("limit_ps_text")))
        w = api("GET", "/api/hier/uploads/%s/findings/%d/window" % (uid, inside["id"]), params={"level": "split", "n": 2, "m": 2})
        pos = [x.get("position") for x in w.get("rows") or []]
        check("the window at the split level works for it", w.get("level") == "split" and pos.count("fault") == 1 and pos.count("above") == 2 and pos.count("below") == 2
              and any(x["position"] == "fault" and x["rowid_file"] == inside["rowid"] for x in w["rows"]), pos)
    r = api("PUT", "/api/hier/uploads/%s/thresholds" % uid, {}, timeout=180)
    check("PUT the defaults back (empty body) re-runs the rules", r.get("thresholds") == {} and isinstance(r.get("rules"), dict), r.get("thresholds"))
    fl = api("GET", "/api/hier/uploads/%s/findings" % uid, params={"rule": "spl.latency_over_limit", "limit": 1})
    check("the default 50 ms split limit is back in force (rows whose Time Delta reaches 50 ms, idle gaps included, stay as timing errors)", (fl.get("limits") or {}).get("split", {}).get("text") == "50 ms" and isinstance(fl.get("total"), int), (fl.get("total"), (fl.get("limits") or {}).get("split")))
    _, f = status_error_finding_on_207(uid)
    check("the status-error finding on command 207 is still there after the re-runs", f is not None)


def cleanup():
    print("\n-- 11. clean-up")
    for uid in list(CREATED["uploads"]):
        try:
            r = api("DELETE", "/api/hier/uploads/%s" % uid)
            check("upload %s deleted" % uid, r.get("deleted") == uid, r)
        except ApiError as e:
            check("upload %s deleted" % uid, False, e)
    try:
        ups = api("GET", "/api/hier/uploads")
        left = [u["upload_id"] for u in ups if u["upload_id"] in CREATED["uploads"]]
        others = [u["upload_id"] for u in ups if (u.get("operator") or "") != ADMIN]
        check("the e2e uploads are gone and the other uploads are untouched", not left and len(others) == len(ups), "left %s; %d other upload(s) still listed" % (left, len(others)))
    except ApiError as e:
        check("the e2e uploads are gone", False, e)
    for p in CREATED["files"]:
        if p and os.path.isfile(p):
            os.remove(p)
            print("      removed the generated test case", p)
    if not os.path.exists(KNOWLEDGE_DB) or not CREATED["signature"]:
        return
    con = sqlite3.connect(KNOWLEDGE_DB, timeout=30)
    try:
        if CREATED["scenario_changed"]:
            con.execute("UPDATE signature SET scenario_name=? WHERE fine=?", (CREATED["scenario_before"], CREATED["signature"]))
            print("      scenario name of the signature put back to %r" % CREATED["scenario_before"])
        if CLEANUP_STORE:
            pids = CREATED["procedures"]
            q = ",".join("?" * len(pids))
            if pids:
                con.execute("DELETE FROM procedure WHERE id IN (%s) AND fine=?" % q, pids + [CREATED["signature"]])
                con.execute("UPDATE procedure SET test_path=NULL WHERE id IN (%s)" % q, pids)
            con.execute("DELETE FROM signal WHERE admin=? AND fine=?", (ADMIN, CREATED["signature"]))
            con.execute("DELETE FROM lesson WHERE producer=? AND fine=?", ("admin:" + ADMIN, CREATED["signature"]))
            for uid in CREATED["uploads"]:
                con.execute("DELETE FROM chat WHERE upload_id=?", (uid,))
            if CREATED["order_row_existed"] is False:
                con.execute("DELETE FROM procedure_order WHERE fine=?", (CREATED["signature"],))
            print("      knowledge store: removed the %d procedure(s), the e2e signals, lessons and chat lines this run created" % len(pids))
        else:
            print("      knowledge store: the %d procedure(s), signals and chat lines this run created stay under admin %r (run with --cleanup-store to remove them)"
                  % (len(CREATED["procedures"]), ADMIN))
        con.commit()
    finally:
        con.close()


def main():
    try:
        api("GET", "/api/hier/uploads", timeout=10)
    except ApiError as e:
        print("the application does not answer at %s: %s" % (BASE, e))
        sys.exit(2)
    for v in FILES.values():
        if not os.path.isfile(os.path.join(SAMPLE, v)):
            sys.exit("sample file missing: %s" % os.path.join(SAMPLE, v))
    try:
        step0_model()
        step1_sniff()
        uid = step2_upload()
        step3_rows(uid)
        step3b_defect_table(uid)
        fid, d = step4_findings(uid)
        if fid is None:
            raise ApiError("no cmd.status_error finding on command 207: the rest of the suite cannot run")
        fine1, seen1 = d["signature"]["fine"], d["knowledge"]["seen"]
        step5_window(uid, fid)
        ans = step6_chat(uid, fid, CREATED["scenario_before"])
        p = step7_signals(uid, fid, ans)
        step7h_store_direct()
        if p:
            step8_testcase(uid, fid, p)
            step9_second_upload(fine1, detail(uid, fid)["knowledge"]["seen"], p)
        else:
            check("steps 8 and 9 (test case, second upload)", False, "skipped: the signals did not store a procedure")
        step10_thresholds(uid)
    except ApiError as e:
        check("the suite ran to the end", False, e)
    except Exception as e:      # noqa: BLE001
        traceback.print_exc()
        check("the suite ran to the end without an unexpected error", False, "%s: %s" % (type(e).__name__, e))
    finally:
        try:
            cleanup()
        except Exception as e:      # noqa: BLE001
            traceback.print_exc()
            check("clean-up ran", False, e)
    fails = [r for r in RESULTS if not r[0]]
    print("\n%d checks, %d failed, %d model call(s), %.0f s" % (len(RESULTS), len(fails), MODEL_CALLS["n"], time.time() - T0))
    for ok, name, det in fails:
        print("  FAIL", name, ("| " + str(det)[:300]) if det else "")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
