"""The fixed dictionary of defect terms and cause keywords (owner, 2026-11-11: "you, as the system, should maintain the name ... not the
admin every time: the person at time t1 and at time t2 might be different ... maintain one dictionary: if these kinds of words are there,
this is the defect, this is the causation").

* The DEFECT TERM is built by code from what the recording shows, never typed and never chosen by the model: the rule that found the error,
  the command, what happened to it (aborted by the host, never completed, completed after the limit, completed with an error status) and
  where it stopped or which status it got (official NVMe status names). The same kind of error always gets the same term, whoever looks at
  it and whenever; the term's key is the defect's key in the procedural graph.
* The CAUSE is one keyword from a fixed list, grouped by side (host, driver, device, interrupt path, link, PCIe). The model chooses one with
  its evidence; the admin confirms it or chooses another from the same list. A keyword outside the list is never stored.

Every term carries the dictionary version it was made with, so a stored record says which version named it.
"""
import json
import re

VERSION = 3          # 2: the causes host_missed_completion, device_internal_delay; 3: keys from codes only, NVMe 2.1 names corrected (2026-11-11)

# official NVMe status names (NVM Express Base Specification 2.x; the names Linux uses in include/linux/nvme.h), by (status code type, status code)
NVME_STATUS = {
    (0, 0x00): "Successful Completion", (0, 0x01): "Invalid Command Opcode", (0, 0x02): "Invalid Field in Command",
    (0, 0x03): "Command ID Conflict", (0, 0x04): "Data Transfer Error", (0, 0x05): "Commands Aborted due to Power Loss Notification",
    (0, 0x06): "Internal Error", (0, 0x07): "Command Abort Requested", (0, 0x08): "Command Aborted due to SQ Deletion",
    (0, 0x09): "Command Aborted due to Failed Fused Command", (0, 0x0A): "Command Aborted due to Missing Fused Command",
    (0, 0x0B): "Invalid Namespace or Format", (0, 0x0C): "Command Sequence Error", (0, 0x0D): "Invalid SGL Segment Descriptor",
    (0, 0x14): "Atomic Write Unit Exceeded", (0, 0x15): "Operation Denied", (0, 0x20): "Namespace is Write Protected",
    (0, 0x21): "Command Interrupted", (0, 0x22): "Transient Transport Error", (0, 0x80): "LBA Out of Range", (0, 0x81): "Capacity Exceeded",
    (0, 0x82): "Namespace Not Ready", (1, 0x00): "Completion Queue Invalid", (1, 0x01): "Invalid Queue Identifier",
    (1, 0x02): "Invalid Queue Size", (1, 0x03): "Abort Command Limit Exceeded", (1, 0x0B): "Firmware Activation Requires Conventional Reset", (1, 0x0C): "Invalid Queue Deletion",
    (2, 0x80): "Write Fault", (2, 0x81): "Unrecovered Read Error", (2, 0x82): "End-to-end Guard Check Error",
    (2, 0x83): "End-to-end Application Tag Check Error", (2, 0x84): "End-to-end Reference Tag Check Error", (2, 0x85): "Compare Failure",
    (2, 0x86): "Access Denied", (2, 0x87): "Deallocated or Unwritten Logical Block", (3, 0x00): "Internal Path Error",
    (3, 0x01): "Asymmetric Access Persistent Loss", (3, 0x60): "Controller Pathing Error", (3, 0x70): "Host Pathing Error",
    (3, 0x71): "Command Aborted By Host",
}

# where a command's cycle stopped (the detector's own stage names) in words
# the detector's stage words (nvme_hier/rules.py CYCLE: doorbell, entry fetched, PRP list, data, completion entry, interrupt, head doorbell),
# each with a stable code for the key and words for the name
STAGES = {"doorbell": ("submitted", "stopped after the doorbell (the drive never fetched it)"),
          "entry fetched": ("fetched", "stopped after the drive fetched it"),
          "PRP list": ("prp", "stopped after the PRP list"),
          "data": ("data", "stopped after the data (no completion entry)"),
          "completion entry": ("completed", "stopped after the completion entry (no interrupt)"),
          "interrupt": ("interrupt", "stopped after the interrupt (the host never took it)")}
KIND_WORDS = {"aborted by the host": "aborted by the host", "never completed": "never completed", "completed late": "completed after the limit",
              "slower than usual": "slower than usual for its type", "error status": "completed with an error status"}

# the fixed cause keywords: side, words, and what in the recording points at it (research: reports/Procedural graph causes and solutions.md)
CAUSES = {
    "host_timer_shorter_than_drive_latency": ("host", "the host's timer is shorter than the drive's normal answer time",
                                              "the command completed or was aborted well inside the drive's usual time; nothing else on the link"),
    "host_abort_by_tool_or_test": ("host", "a test tool or program aborted the command on purpose", "an Abort with a short, fixed delay; no driver timeout"),
    "host_reset_or_driver_recovery": ("driver", "the driver reset the controller after a timeout", "controller status read, then a reset; queues re-created"),
    "driver_queue_configuration": ("driver", "the queue set-up (size, depth, vectors) does not fit", "queue creation parameters; commands stuck on one queue"),
    "power_state_transition_latency": ("driver", "the drive was leaving a power-saving state (APST / power state)", "Set Features 0Ch or 02h before; slow first command after idle"),
    "interrupt_lost": ("interrupt", "the completion arrived but the interrupt never reached the host", "completion entry written, no MSI-X write after it"),
    "interrupt_delayed_by_coalescing": ("interrupt", "interrupt coalescing held the interrupt back", "Set Features 08h; completion entries waiting for one interrupt"),
    "firmware_stall": ("device", "the drive's firmware stopped making progress", "fetched, then nothing on any queue; link clean"),
    "garbage_collection_pause": ("device", "a garbage-collection pause inside the drive", "slow answers in bursts after heavy writes; link clean"),
    "thermal_throttling": ("device", "the drive slowed itself to cool down", "even slow-down on all queues; thermal event or SMART thermal counters"),
    "media_retry_or_read_error": ("device", "the drive retried a hard-to-read block", "slow or failed reads of the same blocks; media error status"),
    "controller_fatal_error": ("device", "the controller reported a fatal error", "controller status fatal bit; all-ones reads; reset"),
    "link_replay_storm": ("link", "packets were resent many times on the link", "Nak and repeated sequence numbers in the window"),
    "link_retraining_recovery": ("link", "the link went through recovery or retraining", "training sets, link down or speed change in the window"),
    "aspm_l1_exit_latency": ("link", "the link was waking up from a power-saving state (ASPM L1)", "L1 entry before; the first packet after it is late"),
    "flow_control_credit_starvation": ("pcie", "the link had no flow-control credits to send", "credits at zero; transmitter waiting"),
    "completion_timeout_or_error_completion": ("pcie", "a PCIe read was not answered or answered with an error", "completion timeout, Unsupported Request or Completer Abort"),
    "host_missed_completion": ("host", "the host never took the completion although the interrupt came", "MSI-X written; no completion-queue head doorbell after it"),
    "device_internal_delay": ("device", "the drive was slow inside; the recording cannot tell why (firmware, garbage collection, temperature)",
                              "fetched, then a long wait before the answer; all packets acknowledged"),
    "unknown_cause": ("other", "not decided from this recording", "the rows do not tell the causes apart; more data is needed"),
}
SIDE_WORDS = {"host": "the host", "driver": "the driver or admin software", "device": "the device", "interrupt": "the interrupt path",
              "link": "the link", "pcie": "PCIe transactions", "other": "not decided"}


def slug(s):
    return re.sub(r"[^0-9a-z]+", "_", str(s or "").lower()).strip("_")


def _status(st):
    """'sct0.sc07' -> (0, 7, 'Command Abort Requested'), or None."""
    m = re.match(r"sct(\w+)\.sc(\w+)", str(st or ""))
    if not m:
        return None
    try:
        sct, sc = int(m.group(1), 16), int(m.group(2), 16)
    except ValueError:
        return None
    return sct, sc, NVME_STATUS.get((sct, sc), "status %Xh/%02Xh" % (sct, sc))


def defect_term(f):
    """{"key", "name", "slots", "version"} of an error (a finding with its signature and detail), made by code from what was observed.
    The key is built from codes only (rule, command class and opcode, what happened, the stage code or the NVMe status code), never from
    measured values or display words, so it never changes for the same kind of error; the name is the words people read."""
    fields = ((f.get("signature") or {}).get("fields") or {})
    detail = f.get("detail")
    if isinstance(detail, str):
        try:
            detail = json.loads(detail)
        except ValueError:
            detail = {}
    detail = detail or {}
    rule, level = f.get("rule") or fields.get("err") or "", f.get("level") or fields.get("lvl") or ""
    cmd = fields.get("cmd") or ""
    cls, _, opname = cmd.partition(".")
    command = (opname or "").replace("_", " ") or ("outside any command" if cmd in ("", "none") else cmd)
    if cls == "admin":
        command += " (admin)"
    kind = detail.get("kind") or ""
    cyc = detail.get("cycle") or {}
    other = False
    st = _status(fields.get("st"))
    st_code = ("nvme.sc.%X.%02X" % st[:2]) if st else ""
    if kind == "aborted by the host" and st:
        what, qual, qcode = "aborted by the host", "status %s" % st[2], st_code
    elif kind == "never completed":
        code, words = STAGES.get(cyc.get("stopped_after") or "", ("none", "no step of it was seen"))
        what, qual, qcode = "never completed", words, "stage." + code
    elif kind:
        what = KIND_WORDS.get(kind, kind)
        qual, qcode = (("status %s" % st[2]), st_code) if st and st[:2] != (0, 0) else ("", "")
    elif st and st[:2] != (0, 0):
        what, qual, qcode = "completed with an error status", "status %s" % st[2], st_code
    else:
        # any other rule: the rule's own description (nvme_hier/rules.py BASIS, never the measured text) for the name; rule, level and part for the key
        try:
            from .rules import BASIS as _B
            what = re.split(r"[:;]", re.sub(r"\s*\([^)]*\)", "", (_B.get(rule) or ("", ""))[1]))[0].strip()
        except ImportError:
            what = ""
        what = what or re.sub(r"\s*[-+]?\d[\d.,]*\s*(ps|ns|us|µs|ms|s|%|x)?\b", "", (f.get("name") or rule).split(":")[0]).strip() or rule
        qual, qcode = "", "part." + (fields.get("part") or "none")
        other = True
    slots = {"rule": rule, "level": level, "command": command, "what": what, "qualifier": qual}
    key = "|".join(x for x in (rule, (cmd.lower() if cmd and cmd != "none" else "level." + level), slug(kind or what), qcode) if x)
    name = ("%s: %s" % (command[:1].upper() + command[1:], what)) if other and cmd and cmd != "none" else \
        "%s %s%s" % (command[:1].upper() + command[1:], what, (", %s" % qual) if qual else "") if cmd and cmd != "none" else \
        "%s (%s level)%s" % (what[:1].upper() + what[1:], level, (", %s" % qual) if qual else "")
    return {"key": key, "name": name, "slots": slots, "version": VERSION}


def cause_choices():
    """The fixed cause keywords for a page or a prompt: [{"key", "side", "side_words", "name", "evidence"}]."""
    return [{"key": k, "side": v[0], "side_words": SIDE_WORDS.get(v[0], v[0]), "name": v[1], "evidence": v[2]} for k, v in CAUSES.items()]


def cause_of(key):
    v = CAUSES.get(key)
    return {"key": key, "side": v[0], "side_words": SIDE_WORDS.get(v[0], v[0]), "name": v[1], "evidence": v[2]} if v else None
