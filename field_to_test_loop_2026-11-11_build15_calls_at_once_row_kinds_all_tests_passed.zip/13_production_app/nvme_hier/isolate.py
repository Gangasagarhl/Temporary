"""The isolation tab's model work (owner's statement of 2026-11-03, parts 4 to 8): the stateful chat over a chosen
context, the retrieval context from the signature memory, the evidence loop that optimises the sequence above the
defect, the expected outcomes of the commands after the defect, and the summary (who, what, when, where, why, how).

Everything here is pure: no Flask, no SQLite. The API (app/api/isolate_api.py) fetches rows and passes them in as
plain dicts; the loop asks for more evidence through callbacks. Every model call has a deterministic stand-in built
from the rule, the optimiser and the catalogue, so the page and the tests work without a model.

The model never decides whether a defect exists: the rules did. It explains, names, proposes, and cites rows.
"""
import json
import re

from . import chat as CH
from . import terms as TERMS
from . import optimise as OPT

MAX_ROUNDS = 5             # evidence loop: at most 5 model rounds
MAX_ABOVE = 100            # ... and at most 100 commands above the defect
STEP_ABOVE = 20            # "I need more commands above" fetches the next 20 (x - 20)
HISTORY_TURNS = 20         # the chat sends the last 20 entries of the conversation
MAX_CONTEXT_LINES = 800    # evidence lines in one prompt; the prompt says how many were left out
LEVEL_LABEL = {"packets": "packet", "link": "link transaction", "split": "split transaction", "nvme_transaction": "NVMe transaction", "nvme_command": "NVMe command"}
LOWER_LEVELS = ("nvme_transaction", "split", "link", "packets")

SYSTEM = (
    "You help an NVMe / PCIe test engineer isolate ONE defect that a deterministic rule found in a recording of the traffic "
    "between a computer and a drive. The rule decided that the defect exists; you never judge that. You explain in plain words, "
    "give things names, say what the evidence shows, and propose. Use only the evidence lines you are given: every number you "
    "mention must come from them, with its unit; cite rows by level and row number. Say 'I need more evidence' rather than guess. "
    "Write for a person who is not an engineer where you can: short sentences, no abbreviations without their meaning."
)

# ---------------------------------------------------------------------------------------------- JSON schemas (checked by code)
_SEQ_ITEM = {"type": "object", "properties": {"step": {"type": "integer"}, "command": {"type": "string"}, "source_row": {"type": "integer"},
                                              "gap_us": {"type": "integer"}, "why": {"type": "string"}}, "required": ["step", "command", "source_row", "gap_us", "why"]}
_CITED = {"type": "array", "items": {"type": "object", "properties": {"level": {"type": "string"}, "rowid": {"type": "integer"}}, "required": ["level", "rowid"]}}
_OUTCOME = {"type": "object", "properties": {"status": {"type": "string"}, "description": {"type": "string"}, "check": {"type": "string"}}, "required": ["status", "description", "check"]}

CHAT_SCHEMA = {"type": "object", "properties": {
    "answer": {"type": "string"},
    "scenario_name": {"type": "string"},
    "reason": {"type": "string"},
    "proposed_sequence": {"type": "array", "items": _SEQ_ITEM},
    "expected_outcome": _OUTCOME,
    "summary": {"type": "string"},
    "cited_rows": _CITED},
    "required": ["answer", "scenario_name", "reason", "proposed_sequence", "expected_outcome", "summary", "cited_rows"]}

LOOP_SCHEMA = {"type": "object", "properties": {
    "verdict": {"type": "string", "enum": ["reason", "need_more_evidence"]},
    "reason": {"type": "string"},
    "cited_rows": _CITED,
    "optimised_sequence": {"type": "array", "items": _SEQ_ITEM},
    "need": {"type": "object", "properties": {
        "more_above": {"type": "integer"},
        "levels": {"type": "array", "items": {"type": "string", "enum": list(LOWER_LEVELS)}},
        "commands": {"type": "array", "items": {"type": "integer"}},
        "why": {"type": "string"}}, "required": ["more_above", "levels", "commands", "why"]}},
    "required": ["verdict", "reason", "cited_rows", "optimised_sequence", "need"]}

OUTCOMES_SCHEMA = {"type": "object", "properties": {"outcomes": {"type": "array", "items": {"type": "object", "properties": {
    "step": {"type": "integer"}, "command": {"type": "string"}, "status": {"type": "string"}, "status_type": {"type": "integer"}, "status_code": {"type": "integer"},
    "timing_us": {"type": "integer"}, "check": {"type": "string"}, "basis": {"type": "string"}},
    "required": ["step", "command", "status", "status_type", "status_code", "timing_us", "check", "basis"]}}}, "required": ["outcomes"]}

# the summary of an error (owner, 2026-11-11: "explain like five W's and one H ... mention it as just summary"; 2026-11-10: "within 100 word")
SUMMARY_KEYS = ("who", "what", "when", "where", "why", "how")
SUMMARY_LABEL = {"who": "Who", "what": "What", "when": "When", "where": "Where", "why": "Why", "how": "How"}
SUMMARY_WORDS = 100
SUMMARY_SCHEMA = {"type": "object", "properties": {k: {"type": "string"} for k in SUMMARY_KEYS}, "required": list(SUMMARY_KEYS)}
LEVEL_CSV = {"nvme_command": "nvme_command.csv", "nvme_transaction": "nvme_transaction.csv", "split": "split.csv", "link": "link.csv", "packets": "packets.csv"}


# ---------------------------------------------------------------------------------------------- words
RULE_WORDS = {
    "cmd.latency_over_limit": "timing error: the command took longer than {limit} to complete (from its submission doorbell to its completion-queue doorbell)",
    "cmd.status_error": "status error: the command completed with an error status ({name})",
    "cmd.incomplete": "the command never completed: no completion entry was written",
    "cmd.not_fetched": "the command was never fetched after its doorbell",
    "cmd.no_interrupt": "no interrupt followed the completion",
    "cmd.bytes_short": "fewer bytes were moved than the command asked for",
    "cmd.deallocate_readback": "deallocated blocks still read back their old data",
    "cmd.write_zeroes_readback": "blocks written with zeroes did not read back as zeroes",
    "ntx.over_limit": "timing error at the NVMe transaction level: this step of the command took longer than {limit}",
    "ntx.analyzer_error": "the analyzer flagged this NVMe transaction with an error",
    "ntx.analyzer_warning": "the analyzer flagged this NVMe transaction with a warning",
    "ntx.status_error": "the completion entry carries an error status",
    "ntx.phase_wrong": "the completion entry's phase bit is not the one the host expects (the entry is invisible to the host)",
    "ntx.interrupt_before_completion": "the interrupt was written before the completion entry it announces",
    "ntx.completion_unknown_command": "a completion arrived for a command that was not open",
    "spl.latency_over_limit": "timing error at the split level: the answer to the memory request came later than {limit}",
    "spl.incomplete": "the memory request was never answered (completion timeout)",
    "spl.cpl_ur": "the memory request was answered Unsupported Request: the other side does not serve that address",
    "spl.cpl_ca": "the memory request was answered Completer Abort",
    "spl.cpl_crs": "the memory request was answered 'retry' (configuration retry status)",
    "spl.short_data": "the answer carried fewer bytes than requested",
    "lnk.response_over_limit": "timing error at the link layer: a link transaction took longer than {limit} to complete (from the packet to the Ack or Nak that answered it)",
    "lnk.replay": "packets were sent again on the link (a Nak, or more packets than the packet and its Ack)",
    "lnk.incomplete": "the packet was never acknowledged",
    "pkt.analyzer_error": "the analyzer flagged this packet with an error",
    "pkt.bad_lcrc": "the packet's checksum (LCRC) was wrong: the wire corrupted it",
    "pkt.bad_ecrc": "the packet's end-to-end checksum (ECRC) was wrong",
    "pkt.bad_crc16": "the link-layer packet's checksum (CRC16) was wrong",
    "pkt.poisoned_tlp": "the packet was marked poisoned (its data is known bad)",
    "pkt.invalid_packet": "the packet has no number and no type: the analyzer could not decode it",
    "pkt.recovery": "the link went through recovery (re-training)",
    "pkt.link_down": "the link went down",
    "pkt.speed_change": "the link changed speed",
    "pkt.width_change": "the link changed width",
    "pkt.electrical_idle": "the link went electrically idle",
}


def rule_in_words(f):
    """The rule of a finding as a plain sentence, with the limit (and its unit) when the rule has one."""
    rule = f.get("rule") or ""
    tpl = RULE_WORDS.get(rule) or ("%s level: %s" % (LEVEL_LABEL.get(f.get("level"), f.get("level")), rule.split(".", 1)[-1].replace("_", " ")))
    return tpl.format(limit=f.get("limit_ps_text") or "the limit", name=f.get("name") or rule)


def reason_text(f, device=None, evidence_note=None):
    """The error reason in words, as the store keeps it: '<rule in words>, device X' (+ what the evidence showed)."""
    parts = [rule_in_words(f)]
    if f.get("value_ps_text"):
        parts.append("measured %s against the limit %s (%s)" % (f["value_ps_text"], f.get("limit_ps_text") or "-", f.get("limit_source") or "limit"))
    if evidence_note:
        parts.append(evidence_note)
    parts.append("device %s" % (device or "unknown"))
    return "; ".join(parts)


def defect_lines(f, device):
    """The defect header for a prompt: level, rule in words, measured value and limit with source, chain, catalogue."""
    lines = ["DEFECT (found by a deterministic rule; its existence is not in question):",
             "  level: %s; rule: %s" % (LEVEL_LABEL.get(f.get("level"), f.get("level")), rule_in_words(f)),
             "  rule id %s: %s" % (f.get("rule"), f.get("name") or "")]
    if f.get("value_ps_text") or f.get("limit_ps_text"):
        lines.append("  measured: %s; limit: %s (source: %s)" % (f.get("value_ps_text") or "-", f.get("limit_ps_text") or "-", f.get("limit_source") or "-"))
    cmd = (f.get("command") or {}).get("summary")
    lines.append("  command: %s" % (cmd or "outside any command"))
    lines.append("  device: %s" % (device or "unknown"))
    if f.get("chain"):
        lines.append("  chain from the row that fired up to its command: " + " -> ".join("%s %s (%s)" % (c.get("label"), c.get("n"), c.get("summary")) for c in f["chain"]))
    if f.get("cause"):
        lines.append("  lowest-level cause inside this command: %s level, %s" % (f["cause"].get("level"), f["cause"].get("name")))
    return lines


def catalogue_lines(cat):
    if not cat:
        return []
    lines = ["CATALOGUE: %s | %s | specification: %s" % (cat.get("error"), (cat.get("meaning") or "")[:400], cat.get("spec") or "-")]
    for d in (cat.get("defects") or [])[:6]:
        lines.append("  possible defect [%s]: %s" % (d.get("domain"), d.get("cause")))
    return lines


def memory_lines(facts):
    if not facts:
        return ["MEMORY: nothing is stored for this signature or its family yet."]
    lines = ["MEMORY (what was stored for this signature and its family; ranked, exact first):"]
    for f in facts:
        lines.append("  %d. %s" % (f.get("rank", 0), f.get("text", "")))
    return lines


def row_line(r):
    """One evidence row as a plain-text line: '<level> row <n> [position] <summary> | t=.. gap=.. dur=.. | findings'."""
    d = {"rowid_file": r.get("n") if r.get("n") is not None else r.get("rowid"), "position": r.get("position") or r.get("relation") or "",
         "summary": r.get("summary"), "raw": {"Time Stamp": r.get("t") or ""}, "gap_text": r.get("gap") or "", "dur_ps_text": r.get("dur") or "",
         "findings": r.get("findings") or []}
    line = "%s %s" % (LEVEL_LABEL.get(r.get("level"), r.get("level")), CH._row_line(d))
    if r.get("command_n") is not None and r.get("level") != "nvme_command":
        line += " | under command %s" % r["command_n"]
    return line


def context_text(rows):
    """'context: 12 commands, 3 link transactions, the packets of link 21837'."""
    if not rows:
        return "context: nothing selected"
    parts = []
    by = {}
    for r in rows:
        by.setdefault(r.get("level"), []).append(r)
    for lv in ("nvme_command", "nvme_transaction", "split", "link", "packets"):
        rs = by.get(lv)
        if not rs:
            continue
        n = len(rs)
        label = LEVEL_LABEL[lv]
        if lv == "packets":
            parents = sorted({str(r.get("parent_n")) for r in rs if r.get("parent_n") is not None})
            if parents and len(parents) <= 3:
                parts.append("the packets of link%s %s" % ("" if len(parents) == 1 else "s", " and ".join(parents)))
                continue
        parts.append("%d %s%s" % (n, label, "" if n == 1 else "s"))
    return "context: " + ", ".join(parts)


def history_lines(history, last=HISTORY_TURNS):
    hist = [h for h in (history or []) if h.get("role") != "loop"][-last:]
    if not hist:
        return []
    lines = ["CONVERSATION SO FAR (last %d entries):" % len(hist)]
    for h in hist:
        role = h.get("role") or ""
        who = "admin" if role.startswith("admin:") else ("model" if role not in ("stand-in",) and not role.startswith("stand-in") else "stand-in")
        lines.append("  %s: %s" % (who, (h.get("text") or "")[:1500]))
    return lines


def bounded(lines, limit=MAX_CONTEXT_LINES):
    if len(lines) <= limit:
        return lines
    return lines[:limit] + ["  ... and %d more rows not shown (narrow the selection to see them)" % (len(lines) - limit)]


# ---------------------------------------------------------------------------------------------- prompts
def chat_prompt(f, device, facts, context_rows, history, message, include_defect=True, include_catalogue=True, include_memory=True):
    lines = [SYSTEM, "", "Answer as JSON: 'answer' is your free-text answer (plain words). Fill scenario_name, reason, proposed_sequence,",
             "expected_outcome and summary only when the admin asked for them or they follow from the question; otherwise leave them empty.",
             "A proposed_sequence step names a command and the source_row (row number of the NVMe command in the evidence) it comes from.", ""]
    if include_defect:
        lines += defect_lines(f, device) + [""]
    if include_catalogue and f.get("catalogue"):
        lines += catalogue_lines(f["catalogue"]) + [""]
    if include_memory:
        lines += memory_lines(facts) + [""]
    lines.append("SELECTED CONTEXT (%s):" % context_text(context_rows)[len("context: "):])
    lines += bounded(["  " + row_line(r) for r in context_rows]) or ["  (no rows selected)"]
    lines.append("")
    lines += history_lines(history)
    lines.append("")
    lines.append("ADMIN: " + (message or "").strip())
    return "\n".join(lines)


def loop_prompt(f, device, facts, optimised, evidence, hint, rounds, above_fetched, lower_fetched, final=False):
    lines = [SYSTEM, "",
             "TASK: the defect was seen at command x (the row marked [fault]). The commands after x stay exactly as recorded; the code copies them.",
             "You optimise the commands ABOVE x: keep only those that can have caused the defect, in their recorded order, each named with",
             "its source_row (the row number of that NVMe command in the evidence). Answer as JSON with verdict 'reason' when the evidence is enough:",
             "reason = 'this error occurred because ...' in plain words with the rows you cite (cited_rows: level + row number from the evidence),",
             "optimised_sequence = the kept commands above x only. Answer verdict 'need_more_evidence' when it is not enough, with need.more_above",
             "(how many more commands above x you want; the code fetches the next %d) and/or need.levels (which lower levels you want to see under" % STEP_ABOVE,
             "the suspect commands: nvme_transaction, split, link, packets) and need.commands (the row numbers of the suspect commands). For a",
             "link-layer timing error the evidence is at the packet level (the packet and the Ack that answered it late), so ask for the packets;",
             "for a command timing error ask for the transactions, splits and links under the command to see which unit was late.",
             "Bounds: at most %d rounds and %d commands above; so far %d commands above are fetched and lower levels %s." % (
                 MAX_ROUNDS, MAX_ABOVE, above_fetched, (", ".join(sorted(lower_fetched)) if lower_fetched else "none") + " are fetched"),
             ""]
    if final:
        lines += ["FINAL ROUND: no more evidence will be fetched after this answer. Give verdict 'reason' now, with the evidence at hand;",
                  "say in the reason text what stays uncertain and which rows would settle it. A 'need_more_evidence' answer is not possible any more.", ""]
    lines += defect_lines(f, device) + [""]
    lines += catalogue_lines(f.get("catalogue")) + [""]
    lines += memory_lines(facts) + [""]
    if optimised and optimised.get("steps"):
        lines.append("STARTING POINT (the deterministic dependency rules D1-D9 / C1-C4 kept these; refine, do not add commands the evidence does not justify):")
        for s in optimised["steps"]:
            lines.append("  step %d %s %s gap %d us source_row %s [%s] - %s" % (s["step"], s["command"], json.dumps(s.get("parameters", {})), s.get("gap_us", 0),
                                                                              s.get("source_row"), s.get("position"), "; ".join(s.get("why") or [])))
        lines.append("")
    if hint:
        lines.append("THE ADMIN SAYS WHERE TO LOOK: " + hint.strip())
        lines.append("")
    if rounds:
        lines.append("EARLIER ROUNDS:")
        for r in rounds:
            lines.append("  round %d: %s" % (r.get("round"), r.get("text")))
        lines.append("")
    lines.append("EVIDENCE (%d rows):" % len(evidence))
    lines += bounded(["  " + row_line(r) for r in evidence])
    # the error goes last as well (owner, 2026-11-10: "at the bottom of the prompt ... this is the error that has been found ... isolate the
    # defect"): the model reads the window, then the question
    lines += ["", "THE ERROR FOUND BY THE ADMIN'S PATTERN (rule %s): %s" % (f.get("rule"), f.get("name") or rule_in_words(f)),
              "  its NVMe command (N1): %s" % ((f.get("command") or {}).get("summary") or "outside any command"),
              "  the error row: %s, at %s in the recording" % (where_words(f), when_words(f)),
              "ISOLATE THE DEFECT behind this error from the evidence above: in the reason, say who caused it (the host, the driver, the device",
              "firmware, an interrupt, the link, PCIe), why, what happened and when, and cite the exact row (level and row number) where it started."]
    return "\n".join(lines)


def outcomes_prompt(f, device, steps, fault_step, n_after, limit_text, limit_source, n_before=0):
    lines = [SYSTEM, "",
             "TASK: for the %d command(s) from the defect onward%s in the sequence below, say what a CORRECT device must produce: the completion status" % (
                 n_after, (" and the %d command(s) before it (the test's input, chosen by the admin: each must complete as a set-up step)" % n_before) if n_before else ""),
             "(status_type and status_code numbers, 0 and 0 for success) and the time within which it must complete (timing_us, in microseconds; the",
             "command-level limit is %s, source: %s), plus the check an automatic test can run and the basis of your answer (specification or the limit)." % (limit_text, limit_source),
             "The step at the defect is listed too: for it, give the outcome a correct device produces (the fault must NOT appear).", ""]
    lines += defect_lines(f, device) + [""]
    lines.append("SEQUENCE:")
    for s in steps:
        lines.append("  step %d %s %s gap %d us [%s]%s" % (s["step"], s["command"], json.dumps(s.get("parameters", {})), s.get("gap_us", 0), s.get("position") or "",
                                                       " <- the defect" if s["step"] == fault_step else ""))
    return "\n".join(lines)


def summary_prompt(f, device, reason, steps, expected):
    lines = [SYSTEM, "", "TASK: write the summary of this error. Answer the five W's and one H, one plain sentence each, at most %d words "
             "in all, every number with its unit:" % SUMMARY_WORDS,
             "  who: which side caused it (the host, the drive, the link, a switch), as far as the reason and the rows show it; "
             "write 'not known from the recording' when they do not;",
             "  what: what happened;",
             "  when: the time in the recording, in seconds, and the command it belongs to;",
             "  where: the level, the file and its row, and the device;",
             "  why: the reason;",
             "  how: how it came about, and what the test does to make it happen again and what it checks.", ""]
    lines += defect_lines(f, device)
    lines += ["  row: %s" % where_words(f), "  time in the recording: %s" % when_words(f), ""]
    if reason:
        lines.append("REASON (as isolated): " + reason)
    if steps:
        lines.append("SEQUENCE: " + " -> ".join("%s%s" % (s.get("command"), " [fault]" if s.get("position") == "fault" else "") for s in steps))
    if expected:
        lines.append("EXPECTED OUTCOME OF A CORRECT DEVICE: %s; check: %s" % (expected.get("status"), expected.get("check")))
    return "\n".join(lines)


# ---------------------------------------------------------------------------------------------- the model call
def is_model(llm):
    return llm is not None and getattr(llm, "name", "stand-in") not in ("standin", "stand-in")


def call_model(llm, prompt, schema, must_have):
    """(answer dict or None, producer text). The stand-in is used when there is no model, when it fails or when its
    answer lacks the field the code needs; the producer text says why."""
    if not is_model(llm):
        return None, "stand-in"
    try:
        out = llm.generate_json(prompt, schema)
        if isinstance(out, tuple):
            out = out[0]
        if isinstance(out, dict) and out.get("_error"):
            return None, "stand-in (the model did not answer: %s)" % str(out["_error"])[:160]
        if isinstance(out, dict) and must_have in out:
            return out, getattr(llm, "name", "model")
        return None, "stand-in (the model's answer had no '%s' field)" % must_have
    except Exception as e:      # noqa: BLE001 - the page says the stand-in answered and why
        return None, "stand-in (model call failed: %s)" % str(e)[:120]


# ---------------------------------------------------------------------------------------------- stand-ins
def standin_chat(f, device, context_rows, message, optimised, facts):
    """Deterministic chat answer: what the selected context holds, the rule in words, the stored memory."""
    msg = (message or "").lower()
    parts = ["Stand-in answer (no model was used)."]
    parts.append("The defect: %s." % rule_in_words(f))
    if context_rows:
        by = {}
        for r in context_rows:
            by.setdefault(r.get("level"), []).append(r)
        parts.append("The selected %s." % context_text(context_rows)[len("context: "):])
        with_f = [r for r in context_rows if r.get("findings")]
        if with_f:
            parts.append("%d of the selected rows carry findings: %s." % (len(with_f), "; ".join("%s %s (%s)" % (LEVEL_LABEL.get(r["level"], r["level"]), r.get("n"), "; ".join(x.get("name", "") for x in r["findings"])) for r in with_f[:5])))
        durs = [(r.get("dur") or "", r) for r in context_rows if r.get("dur")]
        if durs:
            parts.append("Durations of the selected rows run from %s to %s (the analyzer's measurements)." % (durs[0][0], durs[-1][0]))
    else:
        parts.append("No rows are selected: tick rows of the window to put them into the context.")
    if facts:
        parts.append("Memory: %s" % facts[0].get("text", "")[:400])
    ans = {"answer": " ".join(parts), "scenario_name": "", "reason": "", "proposed_sequence": [], "expected_outcome": {"status": "", "description": "", "check": ""},
           "summary": "", "cited_rows": [{"level": r["level"], "rowid": r["rowid"]} for r in context_rows[:5]]}
    if any(w in msg for w in ("name", "scenario", "propose", "sequence", "reason", "why", "cause")):
        std = CH.standin_answer(f, {"rows": [], "n": 0, "m": 0}, optimised)
        ans["scenario_name"] = std["scenario_name"]
        ans["reason"] = reason_text(f, device)
        ans["proposed_sequence"] = [{"step": s["step"], "command": s["command"], "source_row": s.get("source_row") or 0, "gap_us": s.get("gap_us", 10), "why": "; ".join(s.get("why") or [])}
                                    for s in (optimised or {}).get("steps") or []]
        ans["expected_outcome"] = CH.expected_outcome_default(f)
    return ans


HINT_LEVELS = (("packet", "packets"), ("link", "link"), ("split", "split"), ("nvme transaction", "nvme_transaction"))


def standin_loop(f, device, optimised, evidence, hint, rounds, above_fetched, lower_fetched, fault_rowid):
    """Deterministic loop answer. Round 1 may ask for more evidence once: when the admin's hint names a lower level
    (or more commands above) that is not fetched yet, or, for a timing error, the level where the late unit lies
    (a link-layer timing error: the packets, the packet and the Ack that answered it late; a command timing error:
    the transactions, splits and links under the command). Otherwise the verdict is 'reason' with the optimiser's
    kept rows above the fault."""
    h = (hint or "").lower()
    want_levels = [lv for word, lv in HINT_LEVELS if word in h and lv not in lower_fetched]
    more_above = STEP_ABOVE if any(w in h for w in ("above", "earlier", "before", "further up", "more commands")) and above_fetched < MAX_ABOVE else 0
    rule = f.get("rule") or ""
    if not rounds and not want_levels and not more_above and not lower_fetched:
        if rule == "lnk.response_over_limit" or rule.startswith("lnk."):
            want_levels = ["packets"]                                   # the late Ack is a packet under the link transaction
        elif rule == "cmd.latency_over_limit":
            want_levels = ["nvme_transaction", "split", "link"]         # which unit under the command was late
    if not rounds and (want_levels or more_above):
        return {"verdict": "need_more_evidence", "reason": "", "cited_rows": [],
                "optimised_sequence": [], "need": {"more_above": more_above, "levels": want_levels, "commands": [fault_rowid] if fault_rowid else [],
                                                   "why": "stand-in: " + ("the admin asked to look there" if (hint or "").strip() else "for a timing error the late unit lies below the row that fired (a late Ack is a packet)")}}
    kept = [s for s in (optimised or {}).get("steps") or [] if s.get("position") == "above"]
    seq = [{"step": i + 1, "command": s["command"], "source_row": s.get("source_row") or 0, "gap_us": s.get("gap_us", 10), "why": "; ".join(s.get("why") or [])} for i, s in enumerate(kept)]
    cited = [{"level": "nvme_command", "rowid": fault_rowid}] if fault_rowid else []
    note = None
    under = [r for r in evidence if r.get("level") != "nvme_command" and r.get("command_rowid") == fault_rowid]
    if under:
        with_f = [r for r in under if r.get("findings")]
        longest = max(under, key=lambda r: r.get("dur_ps") or 0)
        pick = with_f[0] if with_f else longest
        cited.append({"level": pick["level"], "rowid": pick["rowid"]})
        note = "under the command the %s %s %s (duration %s)" % (LEVEL_LABEL.get(pick["level"], pick["level"]), pick.get("n"),
                                                                "carries a finding: " + "; ".join(x.get("name", "") for x in pick["findings"]) if with_f else "is the longest unit", pick.get("dur") or "-")
    for s in kept:
        cited.append({"level": "nvme_command", "rowid": s.get("source_row")})
    reason = reason_text(f, device, note)
    if kept:
        reason += "; the %d command%s above it kept by the dependency rules: %s" % (len(kept), "" if len(kept) == 1 else "s", "; ".join("%s (%s)" % (s["command"], "; ".join(s.get("why") or [])) for s in kept))
    else:
        reason += "; none of the commands above it is needed to reproduce it (no dependency rule kept one)"
    return {"verdict": "reason", "reason": reason, "cited_rows": cited, "optimised_sequence": seq,
            "need": {"more_above": 0, "levels": [], "commands": [], "why": ""}}


def standin_outcomes(f, steps, fault_step, n_after, limit_us, limit_text, limit_source, n_before=0):
    out = []
    exp = CH.expected_outcome_default(f)
    for s in steps:
        if s["step"] < fault_step - n_before or s["step"] >= fault_step + n_after:
            continue
        if s["step"] == fault_step:
            out.append({"step": s["step"], "command": s["command"], "status": exp["status"], "status_type": 0, "status_code": 0, "timing_us": int(limit_us),
                        "check": exp["check"], "basis": "stand-in: the rule that fired (%s) must stay silent; limit %s (%s)" % (f.get("rule"), limit_text, limit_source)})
        else:
            out.append({"step": s["step"], "command": s["command"], "status": "Successful Completion (status type 0, code 0)", "status_type": 0, "status_code": 0,
                        "timing_us": int(limit_us), "check": "status == (0, 0) and elapsed <= %s" % limit_text,
                        "basis": "stand-in: NVMe status success; completion within the command-level limit %s (%s)" % (limit_text, limit_source)})
    return {"outcomes": out}


# ---------------------------------------------------------------------------------------------- the isolation of the defect
# (owner, 2026-11-11: "at the bottom ... this is the source ... Isolate the defect. What is the reason? Why? When? Whom? Which? How? ...
# Give the standard name to it. Ask admin." Then the cause: "one liner you should keep as a header", e.g. timing caused by the device,
# the host or the interrupt.) The model answers from the window; the code checks every cited row and the side of the cause.
ISOLATION_KEYS = ("what", "why", "when", "where", "who", "which", "how")
ISOLATION_LABEL = {"what": "What happened", "why": "Why", "when": "When", "where": "Where", "who": "Who caused it", "which": "Which row started it",
                   "how": "How it came about"}
CAUSE_SIDES = ("host", "driver", "device", "interrupt", "link", "pcie", "other")
ISOLATION_SCHEMA = {"type": "object", "properties": dict({k: {"type": "string"} for k in ISOLATION_KEYS}, **{
    "standard_name": {"type": "string"}, "cause_side": {"type": "string", "enum": list(CAUSE_SIDES)}, "cause_header": {"type": "string"},
    "cause_key": {"type": "string", "enum": list(TERMS.CAUSES)},
    "cited_rows": _CITED}), "required": list(ISOLATION_KEYS) + ["standard_name", "cause_side", "cause_header", "cause_key", "cited_rows"]}


def isolation_prompt(f, device, evidence, reason, known_names):
    lines = [SYSTEM, ""]
    lines.append("THE WINDOW (%d rows: the NVMe commands above and below the error's command, each with the NVMe transactions, split "
                 "transactions, link transactions and packets under it):" % len(evidence))
    lines += bounded(["  " + row_line(r) for r in evidence])
    if reason:
        lines += ["", "WHAT THE EVIDENCE LOOP FOUND (check it against the rows): " + reason]
    if known_names:
        lines += ["", "STANDARD NAMES ALREADY USED FOR DEFECTS (reuse one exactly when it is the same defect; else propose a new one in the same style): "
                  + "; ".join(known_names[:30])]
    lines += ["", "THE ERROR FOUND BY THE ADMIN'S PATTERN (rule %s): %s" % (f.get("rule"), f.get("name") or rule_in_words(f)),
              "  its NVMe command: %s" % ((f.get("command") or {}).get("summary") or "outside any command"),
              "  the error row: %s, at %s in the recording; device %s" % (where_words(f), when_words(f), device or "not named"),
              "ISOLATE THE DEFECT behind this error, one plain sentence each, every number with its unit and from the rows above:",
              "  what: what happened;  why: the reason;  when: the time in the recording and the command;  where: the level and the row;",
              "  who: which side caused it (the host, the driver, the device firmware, the interrupt path, the link, PCIe), or 'not known from these rows';",
              "  which: the exact row (level and row number) where it started;  how: how it came about, step by step in one sentence.",
              "  standard_name: a short name of the defect by what was observed (not by its cause, not by the device), e.g. 'Read aborted by host after "
              "late completion'; reuse an existing name above when it is the same defect.",
              "  cause_key: the ONE cause keyword below that the rows support best (unknown_cause when they cannot tell); cause_side: its side;",
              "  cause_header: one line saying which rows point at that keyword.",
              "CAUSE KEYWORDS (a fixed list; use one of them exactly):"] + ["  %s (%s): %s; points at it: %s" % (k, v[0], v[1], v[2]) for k, v in TERMS.CAUSES.items()] + [
              "  cited_rows: the rows (level and row number) your answer rests on."]
    return "\n".join(lines)


OPTIMIZED_SCHEMA = {"type": "object", "properties": {"lines": {"type": "array", "items": {"type": "string"}}, "note": {"type": "string"}},
                    "required": ["lines", "note"]}


def optimized_prompt(f, device, isolation, cause, error_seq):
    """The optimized sequence (owner, 2026-11-11: "optimized sequence to solve the problem ... given from the admin at the first time; the
    LLM also should generate it, but that can be edited by the admin"): the steps that avoid the error for this cause."""
    lines = [SYSTEM, "", "THE ISOLATED DEFECT:"]
    lines += ["  %s: %s" % (ISOLATION_LABEL.get(k, k), (isolation or {}).get(k, "")) for k in ISOLATION_KEYS if (isolation or {}).get(k)]
    lines += ["", "ITS CAUSE (%s): %s" % ((cause or {}).get("side", ""), (cause or {}).get("header", "")), "",
              "THE ERROR SEQUENCE (the commands that recreate the error, as recorded):"]
    lines += ["  step %s %s [%s] wait %s us %s" % (s.get("step"), s.get("command"), s.get("position") or "", s.get("gap_us", 0), json.dumps(s.get("parameters") or {}))
              for s in (error_seq or [])[:60]]
    lines += ["", "TASK: write the OPTIMIZED SEQUENCE: the solution to this problem for this cause, as an ordered list of actions, one per line",
              "(a host setting, a command with its parameters, a wait, a configuration change, or what the firmware must do differently).",
              "Every number must come from the rows above or from a source you name; say 'to be measured' where you have none.",
              "It is a proposal: the admin edits it before it is stored. note: one sentence on why it solves the problem for this cause."]
    return "\n".join(lines)


EXPLAIN_SCHEMA = {"type": "object", "properties": {"why": {"type": "string"}, "how": {"type": "string"}, "cited_rows": _CITED},
                  "required": ["why", "how", "cited_rows"]}


def explain_prompt(f, card, cause, rule_words, facts, evidence):
    """The model only explains (owner, 2026-11-11: the isolation must not change with the window): the evidence card and the cause are fixed
    by code; the window's rows are there to cite, not to decide."""
    compact = {k: card.get(k) for k in ("rule", "kind", "status", "reached", "completed", "stopped_after", "answer", "nak", "unacked", "packets",
                                        "host_limit_ps", "usual_ps", "median_ps", "times_median", "command", "stages", "longest_wait", "stall_row", "abort", "during", "link_events")}
    lines = [SYSTEM, "", "THE EVIDENCE CARD OF THIS ERROR (computed by code from the error's own command; these facts are fixed, times in picoseconds):",
             json.dumps(compact, default=str), "",
             "THE CAUSE, DECIDED BY THE FIXED RULES (do not change it): %s: %s. The rule that decided it: %s." % (cause.get("key"), cause.get("name"), rule_words),
             "", "WHAT THE CODE ALREADY STATES:"] + ["  %s: %s" % (k, facts[k]) for k in ("what", "when", "where", "which", "who")]
    lines += ["", "ROWS YOU MAY CITE (the error's own rows first):"] + bounded(["  " + row_line(r) for r in evidence])
    lines += ["", "TASK: write two short paragraphs in plain words, every number with its unit and taken from the card or the rows:",
              "  why: the reason the error happened, built on the decided cause and the card's facts;",
              "  how: how it came about, step by step, from the doorbell to the end.",
              "  cited_rows: the rows your words rest on (level and row number). If a row contradicts the card, say so in 'why'; never change the cause."]
    return "\n".join(lines)


def standin_explain(card, cause, rule_words):
    stages = " > ".join("%s %s" % (s_["what"], ("+" + str(round(s_["after_doorbell_ps"] / 1e6, 3)) + " µs") if s_.get("after_doorbell_ps") else "")
                        for s_ in card.get("stages") or [])
    return {"why": "%s: %s." % ((cause or {}).get("name", "not decided"), rule_words), "how": (stages + ".") if stages else "the rows do not show the command's steps.",
            "cited_rows": ([{"level": "nvme_command", "rowid": card["command"]["row"]}] if card.get("command") else [])}


def standin_isolation(f, device, reason, fault_row_id):
    """The isolation without a model: built from the rule's own facts; it says what the rule cannot decide."""
    cmd = (f.get("command") or {}).get("summary") or "outside any command"
    name = (f.get("name") or rule_in_words(f)).split(":")[0].strip()
    return {"what": "%s." % (f.get("name") or rule_in_words(f)).rstrip("."),
            "why": (reason or rule_in_words(f)).rstrip(".") + ".",
            "when": "At %s in the recording, during %s." % (when_words(f), cmd),
            "where": "%s level, %s." % (LEVEL_LABEL.get(f.get("level"), f.get("level")), where_words(f)),
            "who": "Not known from the rule alone: the model (or you) names the side.",
            "which": "%s." % where_words(f),
            "how": "The rule %s fired on this row; how it came about needs the model's reading of the window." % (f.get("rule") or ""),
            "standard_name": name[:80], "cause_side": "other", "cause_header": "not named yet (no model answered)", "cause_key": "unknown_cause",
            "cited_rows": [{"level": f.get("level"), "rowid": fault_row_id}] if fault_row_id is not None else []}


def check_isolation(ans, evidence):
    """(clean isolation, problems). Every field filled, the side one of the list, the cited rows in the window."""
    problems = []
    out = {k: " ".join(str(ans.get(k) or "").split()) for k in ISOLATION_KEYS}
    for k in ISOLATION_KEYS:
        if not out[k]:
            problems.append("'%s' was left empty" % ISOLATION_LABEL[k])
    out["standard_name"] = " ".join(str(ans.get("standard_name") or "").split())[:120]
    if not out["standard_name"]:
        problems.append("no standard name was proposed")
    side = str(ans.get("cause_side") or "").strip().lower()
    out["cause_side"] = side if side in CAUSE_SIDES else "other"
    if side not in CAUSE_SIDES:
        problems.append("the side of the cause was not one of the list (%s): set to 'other'" % (side or "empty"))
    out["cause_header"] = " ".join(str(ans.get("cause_header") or "").split())[:200]
    ck = str(ans.get("cause_key") or "").strip()
    out["cause_key"] = ck if ck in TERMS.CAUSES else "unknown_cause"
    if ck not in TERMS.CAUSES:
        problems.append("the cause keyword was not one of the dictionary's (%s): set to unknown_cause" % (ck or "empty"))
    cited, cite_problems = check_cited(ans.get("cited_rows") or [], evidence)
    out["cited_rows"] = cited
    return out, problems + cite_problems


def where_words(f):
    return "row %s of %s" % ("{:,}".format(f["rowid"]) if isinstance(f.get("rowid"), int) else f.get("rowid") or "?", LEVEL_CSV.get(f.get("level"), "its file"))


def when_words(f):
    t = f.get("t_ps")
    return ("%.6f s" % (t / 1e12)) if isinstance(t, (int, float)) else "not in the recording's rows"


def standin_summary(f, device, reason, steps, expected):
    """The summary without a model: the same six questions from the rule, the reason as isolated, and the test."""
    cmd = (f.get("command") or {}).get("summary") or "outside any command"
    cat = f.get("catalogue") or {}
    why = reason or (("the catalogue names as a possible defect: " + (cat.get("defects") or [{}])[0].get("cause", "")) if cat.get("defects") else rule_in_words(f))
    exp = expected or CH.expected_outcome_default(f)
    n = len(steps or [])
    return {"who": "The side named in the reason below (isolated in stage 1)." if reason else "Not known from the recording yet: stage 1 names who caused it.",
            "what": "%s." % (f.get("name") or rule_in_words(f)).rstrip("."),
            "when": "At %s in the recording, during %s." % (when_words(f), cmd),
            "where": "%s level, %s, device %s." % (LEVEL_LABEL.get(f.get("level"), f.get("level")), where_words(f), device or "not named"),
            "why": why.rstrip(".") + ".",
            "how": "The test replays %d command%s and checks that %s (%s)." % (n, "" if n == 1 else "s", exp.get("status") or "the fault does not appear", exp.get("check") or "-")}


# ---------------------------------------------------------------------------------------------- code checks
LEVEL_OF = {k: k for k in LEVEL_LABEL}
LEVEL_OF.update({v.lower(): k for k, v in LEVEL_LABEL.items()})
LEVEL_OF.update({"packet": "packets", "command": "nvme_command", "nvme command": "nvme_command", "transaction": "nvme_transaction", "link": "link", "split": "split"})


def level_key(x):
    t = str(x or "").strip().lower().rstrip("s") if str(x or "").strip().lower() not in LEVEL_OF else str(x or "").strip().lower()
    return LEVEL_OF.get(str(x or "").strip().lower()) or LEVEL_OF.get(t) or LEVEL_OF.get(t + "s")


def check_cited(cited, evidence_index):
    """Only rows that exist in the fetched evidence may be cited (by level and row id, or by the row number the
    evidence lines show; the level may be written as its label); returns (kept, problems)."""
    kept, problems, seen = [], [], set()
    by_n = {(key[0], r.get("n")): key for key, r in evidence_index.items() if r.get("n") is not None}
    for c in cited or []:
        if not isinstance(c, dict):
            continue
        lv, rid = level_key(c.get("level")), c.get("rowid")
        key = (lv, rid) if (lv, rid) in evidence_index else by_n.get((lv, rid))
        if key is not None:
            if key in seen:
                continue
            seen.add(key)
            r = evidence_index[key]
            kept.append({"level": key[0], "label": LEVEL_LABEL.get(key[0], key[0]), "rowid": key[1], "n": r.get("n"), "summary": r.get("summary")})
        else:
            problems.append("cited row %s %s is not in the fetched evidence" % (LEVEL_LABEL.get(lv, c.get("level")), rid))
    return kept, problems


def _name(s):
    return re.sub(r"\s*\(admin\)\s*$", "", str(s or "")).strip().lower()


def check_sequence(seq, above_rows, fault_row):
    """The model's optimised sequence (above the defect only): every step must name a command of the fetched window
    (its source_row), with the command name matching that row (case-insensitive; the fault's own command is allowed
    as a step too), in recorded order, no duplicates. Returns (kept rows, problems)."""
    by_row = {r.get("rowid_file"): r for r in above_rows}
    for r in above_rows:
        by_row.setdefault(r.get("n"), r)
    if fault_row is not None:
        by_row[fault_row.get("rowid_file")] = fault_row
        by_row.setdefault(fault_row.get("n"), fault_row)
    kept, problems, seen = [], [], set()
    for s in seq or []:
        if not isinstance(s, dict):
            continue
        rid = s.get("source_row")
        r = by_row.get(rid)
        if r is None:
            problems.append("step %s (%s) names row %s, which is not in the fetched window above the defect" % (s.get("step"), s.get("command"), rid))
            continue
        if fault_row is not None and r.get("rowid_file") == fault_row.get("rowid_file"):
            continue    # the fault itself is added by the code
        rid = r.get("rowid_file")
        want = _name(OPT.N.opcode_name(r.get("opc"), r.get("sqid")))
        got = _name(s.get("command"))
        if got != want and not got.startswith(want + " ") and not got.startswith(want + ","):
            problems.append("step %s names %s but row %s is %s" % (s.get("step"), s.get("command"), rid, OPT.N.opcode_name(r.get("opc"), r.get("sqid"))))
            continue
        if rid in seen:
            continue
        seen.add(rid)
        kept.append((r, s))
    kept.sort(key=lambda x: x[0].get("rowid_file"))
    return kept, problems


def assemble(kept_above, fault_row, below_rows, optimised):
    """The final sequence: the model's kept rows above (checked), the fault, then every row below copied unchanged."""
    why_of = {s.get("source_row"): s.get("why") for s in (optimised or {}).get("steps") or []}
    steps = []
    for r, s in kept_above:
        why = [w for w in [s.get("why")] if w] or why_of.get(r.get("rowid_file")) or ["kept by the model"]
        gap = s.get("gap_us") if isinstance(s.get("gap_us"), int) and s.get("gap_us") > 0 else None
        steps.append(OPT.step_of(dict(r, position="above"), len(steps) + 1, why=why, gap_us=gap))
    fs = next((s for s in (optimised or {}).get("steps") or [] if s.get("position") == "fault"), None)
    steps.append(OPT.step_of(dict(fault_row, position="fault"), len(steps) + 1, why=["the fault"], gap_us=(fs or {}).get("gap_us")))
    prev_t = fault_row.get("t_ps")
    for r in below_rows:
        t = r.get("t_ps")
        gap = max(1, (t - prev_t) // 10 ** 6) if (t is not None and prev_t is not None and t > prev_t) else OPT.DEFAULT_GAP_US
        steps.append(OPT.step_of(dict(r, position="below"), len(steps) + 1, why=["after the defect: copied unchanged, as recorded"], gap_us=gap))
        prev_t = t if t is not None else prev_t
    return steps


def round_text(ans, k):
    """'round 2: the model asked for the packets of links 21837 and 21838'."""
    if ans.get("verdict") == "need_more_evidence":
        need = ans.get("need") or {}
        bits = []
        if need.get("more_above"):
            bits.append("%d more commands above the defect" % need["more_above"])
        if need.get("levels"):
            cmds = need.get("commands") or []
            bits.append("the %s%s" % (" and ".join(LEVEL_LABEL.get(l, l) + "s" for l in need["levels"]),
                                       (" of command%s %s" % ("" if len(cmds) == 1 else "s", " and ".join(str(c) for c in cmds[:6]))) if cmds else " of the suspect commands"))
        return "round %d: the model asked for %s%s" % (k, " and ".join(bits) or "more evidence (it did not say what)", (" (" + need["why"] + ")") if need.get("why") else "")
    return "round %d: the model gave its reason: %s" % (k, (ans.get("reason") or "")[:300])


def summary_lines(ans, limit=SUMMARY_WORDS):
    """The summary as six lines, "Who: ...", "What: ...", "When: ...", "Where: ...", "Why: ...", "How: ...", or None when one is missing
    or the whole is over the word limit."""
    if not isinstance(ans, dict):
        return None
    parts = [" ".join(str(ans.get(k) or "").split()) for k in SUMMARY_KEYS]
    if any(not p for p in parts) or sum(len(p.split()) for p in parts) > limit:
        return None
    return ["%s: %s" % (SUMMARY_LABEL[k], p) for k, p in zip(SUMMARY_KEYS, parts)]


def fit_summary(ans, limit=SUMMARY_WORDS):
    """Shorten the longest answers, a word at a time, until the whole is within the limit (for the stand-in, whose reason can be long)."""
    parts = {k: " ".join(str(ans.get(k) or "").split()).split() for k in SUMMARY_KEYS}
    while sum(len(v) for v in parts.values()) > limit:
        k = max(parts, key=lambda x: len(parts[x]))
        parts[k] = parts[k][:-2] + [parts[k][-2].rstrip(".,;") + "…"] if len(parts[k]) > 2 else parts[k][:1]
    return {k: " ".join(v) for k, v in parts.items()}
