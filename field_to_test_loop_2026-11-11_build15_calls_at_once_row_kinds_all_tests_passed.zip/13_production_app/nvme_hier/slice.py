"""The commands from EARLIER in the recording that the failing command depends on, wherever they are (owner, 2026-11-10:
"regenerate the environment to make the test case work"; research report "Defect replay tests and deallocate checks", section
"Slice by shared state first; the admin's n is padding, not the cause").

The admin's window (n commands above the defect, m below) is padding: it catches coupling no shared field shows. What the
failing command F really depends on can lie far before the window. NVMe processes commands as independent entities (Base 2.1
section 3.4.1), so every dependency the field host relied on shows up only through what commands SHARE. This module finds,
in the whole recording before the window, by identity and never by time stamp alone:

  H1  data       for every block of F's range, the last command that wrote it (Write, Write Uncorrectable, Write Zeroes)
  H2  data       every deallocate (Dataset Management with the deallocate attribute) or Write Zeroes of those blocks after it
  H3  state      the last Set Features of every feature identifier
  H4  state      the latest Format NVM, Sanitize, namespace management or attachment, firmware commit
  H5  queues     the Create I/O Submission Queue and Create I/O Completion Queue of F's queue pair
  H6  in flight  commands on any queue submitted before F and still open when F was submitted

A Format NVM or Sanitize is a cut-off: data written before the latest one cannot matter, so H1/H2 look only after it.
Everything returned carries its reason; nothing is guessed. Rows are read from the staged command table with SQL; the whole
recording is never in memory.
"""
import json

from .optimise import _dsm_ranges, _overlaps, _range

WRITE_OPCS = (0x01, 0x04, 0x08)          # Write, Write Uncorrectable, Write Zeroes (the I/O opcodes that put data, or zeros, into blocks)
DSM_OPC = 0x09                          # Dataset Management (on an I/O queue)
ADMIN_SET_FEATURES = 0x09
CUTOFF_OPCS = {0x80: "Format NVM", 0x84: "Sanitize"}
STATE_OPCS = {0x80: "Format NVM", 0x84: "Sanitize", 0x0D: "Namespace Management", 0x15: "Namespace Attachment", 0x10: "Firmware Commit"}
CREATE_SQ, CREATE_CQ = 0x01, 0x05
MAX_WRITES = 64                         # writes followed back per range before the coverage search gives up (said so)
MAX_DSM_SCAN = 5000                     # Dataset Management commands looked at (newest first): their ranges are in the raw cells
MAX_IN_FLIGHT = 64
FEATURE_NAMES = {0x01: "Arbitration", 0x02: "Power Management", 0x03: "LBA Range Type", 0x04: "Temperature Threshold", 0x05: "Error Recovery",
                 0x06: "Volatile Write Cache", 0x07: "Number of Queues", 0x08: "Interrupt Coalescing", 0x09: "Interrupt Vector Configuration",
                 0x0A: "Write Atomicity Normal", 0x0B: "Asynchronous Event Configuration", 0x0C: "Autonomous Power State Transition",
                 0x0D: "Host Memory Buffer", 0x0E: "Timestamp", 0x0F: "Keep Alive Timer", 0x10: "Host Controlled Thermal Management",
                 0x11: "Non-Operational Power State Config", 0x16: "Host Behavior Support"}


def _rows(con, sql, args):
    out = []
    for r in con.execute(sql, args):
        d = dict(r)
        if isinstance(d.get("raw"), str):
            try:
                d["raw"] = json.loads(d["raw"])
            except ValueError:
                d["raw"] = {}
        out.append(d)
    return out


def fault_ranges(fault):
    """(nsid, first block, last block) of every range the failing command touches (its Dataset Management ranges, or SLBA..SLBA+NLB)."""
    if fault.get("sqid") == 0:
        return []
    if fault.get("opc") == DSM_OPC:
        return _dsm_ranges(fault) or ([_range(fault)] if _range(fault) else [])
    rg = _range(fault)
    return [rg] if rg else []


def _subtract(parts, cover):
    """The pieces of `parts` (inclusive block intervals) that `cover` (nsid, first, last) does not cover."""
    out = []
    for a, b in parts:
        c0, c1 = cover[1], cover[2]
        if c1 < a or c0 > b:
            out.append((a, b))
            continue
        if a < c0:
            out.append((a, c0 - 1))
        if c1 < b:
            out.append((c1 + 1, b))
    return out


def history(con, fault, before_rowid):
    """The commands before row `before_rowid` (the first row of the admin's window) that F depends on, oldest first:
    [{**command row, "history_why": [reasons]}], plus a report {"cutoff", "uncovered", "scanned"} of what was and was not found."""
    if before_rowid is None or before_rowid <= 1:
        return [], {"note": "the window starts at the first command of the recording: nothing lies before it"}
    picked, report = {}, {"scanned": {}, "uncovered": [], "cutoff": None}

    def take(r, why):
        k = r["rowid_file"]
        if k not in picked:
            picked[k] = dict(r, history_why=[])
        if why not in picked[k]["history_why"]:
            picked[k]["history_why"].append(why)

    ranges = fault_ranges(fault)
    nsids = sorted({rg[0] for rg in ranges if rg and rg[0] is not None})
    # the cut-off: the latest Format NVM / Sanitize before the window (a format of another namespace is not one, unless it names all)
    cut = 0
    for opc, name in CUTOFF_OPCS.items():
        args = [opc, before_rowid]
        cond = ""
        if opc == 0x80 and nsids:
            cond = " AND (nsid IN (%s) OR nsid=4294967295 OR nsid IS NULL)" % ",".join("?" * len(nsids))
            args += nsids
        r = _rows(con, "SELECT * FROM cmd WHERE sqid=0 AND opc=? AND rowid_file<?%s ORDER BY rowid_file DESC LIMIT 1" % cond, args)
        if r:
            take(r[0], "H4 the latest %s before the window: the data written before it cannot matter" % name)
            if r[0]["rowid_file"] > cut:
                cut = r[0]["rowid_file"]
                report["cutoff"] = {"rowid": cut, "command": name}
    # H1/H2 data: per range, the newest writes back until the range is covered; then every deallocate / Write Zeroes after the oldest kept write
    for rg in ranges:
        if not rg or rg[0] is None:
            continue
        nsid, lo, hi = rg
        left = [(lo, hi)]
        oldest = None
        writes = _rows(con, "SELECT * FROM cmd WHERE sqid!=0 AND opc IN (%s) AND nsid=? AND rowid_file<? AND rowid_file>? AND slba<=? AND slba+COALESCE(nlb,0)>=? "
                            "ORDER BY rowid_file DESC LIMIT ?" % ",".join("?" * len(WRITE_OPCS)), list(WRITE_OPCS) + [nsid, before_rowid, cut, hi, lo, MAX_WRITES])
        report["scanned"]["writes"] = report["scanned"].get("writes", 0) + len(writes)
        for w in writes:
            wr = _range(w)
            if not wr:
                continue
            rest = _subtract(left, wr)
            if rest != left:
                kind = "Write Zeroes" if w.get("opc") == 0x08 else "Write Uncorrectable" if w.get("opc") == 0x04 else "Write"
                take(w, "H1 the last %s of blocks %d to %d of the failing command's range (namespace %s)" % (kind, max(lo, wr[1]), min(hi, wr[2]), nsid))
                oldest = w["rowid_file"] if oldest is None else min(oldest, w["rowid_file"])
                left = rest
            if not left:
                break
        if left:
            report["uncovered"] += [{"nsid": nsid, "first": a, "last": b} for a, b in left]
        since = max(cut, (oldest or cut))
        dsms = _rows(con, "SELECT * FROM cmd WHERE sqid!=0 AND opc=? AND nsid=? AND rowid_file<? AND rowid_file>? ORDER BY rowid_file DESC LIMIT ?",
                     (DSM_OPC, nsid, before_rowid, since, MAX_DSM_SCAN))
        report["scanned"]["dataset_management"] = report["scanned"].get("dataset_management", 0) + len(dsms)
        for d in dsms:
            if str(d.get("ad") or (d.get("raw") or {}).get("AD", "")).strip() in ("", "0", "0x0", "False"):
                continue                # without the deallocate attribute the command changes no data
            if any(_overlaps(a, rg) for a in _dsm_ranges(d)):
                take(d, "H2 a deallocate (Dataset Management) of blocks of the failing command's range, after their last write")
        for z in [w for w in writes if w.get("opc") == 0x08 and w["rowid_file"] > since]:
            take(z, "H2 a Write Zeroes of blocks of the failing command's range, after their last write")
    # H3 state: the last Set Features of every feature identifier
    for r in _rows(con, "SELECT c.* FROM cmd c JOIN (SELECT fid, MAX(rowid_file) AS m FROM cmd WHERE sqid=0 AND opc=? AND rowid_file<? AND fid IS NOT NULL GROUP BY fid) x "
                        "ON c.rowid_file=x.m", (ADMIN_SET_FEATURES, before_rowid)):
        fid = r.get("fid")
        take(r, "H3 the last Set Features of %s (feature %s): the drive's setting when the failing command ran" % (FEATURE_NAMES.get(fid, "feature"), "0x%02X" % fid if isinstance(fid, int) else fid))
    # H4 the latest namespace management / attachment / firmware commit
    for opc, name in STATE_OPCS.items():
        if opc in CUTOFF_OPCS:
            continue
        r = _rows(con, "SELECT * FROM cmd WHERE sqid=0 AND opc=? AND rowid_file<? ORDER BY rowid_file DESC LIMIT 1", (opc, before_rowid))
        if r:
            take(r[0], "H4 the latest %s before the window" % name)
    # H5 the creation of the failing command's own queue pair
    if fault.get("sqid"):
        for opc, qid, name in ((CREATE_CQ, fault.get("cqid") or fault.get("sqid"), "Create I/O Completion Queue"), (CREATE_SQ, fault.get("sqid"), "Create I/O Submission Queue")):
            r = _rows(con, "SELECT * FROM cmd WHERE sqid=0 AND opc=? AND qid=? AND rowid_file<? ORDER BY rowid_file DESC LIMIT 1", (opc, qid, before_rowid))
            if r:
                take(r[0], "H5 the %s of queue %s, which the failing command uses (its size and interrupt vector)" % (name, qid))
    # H6 in flight when F was submitted, on any queue
    ft = fault.get("t_ps")
    if ft is not None:
        for r in _rows(con, "SELECT * FROM cmd WHERE rowid_file<? AND t_ps<=? AND dur_ps IS NOT NULL AND t_ps+dur_ps>=? ORDER BY rowid_file DESC LIMIT ?",
                       (before_rowid, ft, ft, MAX_IN_FLIGHT)):
            take(r, "H6 still open on queue %s when the failing command was submitted" % r.get("sqid"))
    out = sorted(picked.values(), key=lambda r: r["rowid_file"])
    report["found"] = len(out)
    return out, report
