"""Stored procedures per signature, the admin's order, and the four signals (research note 05).

One SQLite file (db/hier_knowledge.sqlite). Nothing is trained: a procedure carries two counts a and b
(Beta-Bernoulli, the standard neutral start Beta(1, 1): a = 1, b = 1, nothing judged yet) and its score a / (a + b) only orders
the procedures. The admin is shown the judgements themselves: "not yet judged", or "judged correct s of n times" (owner,
2026-11-10: "do not start with a default value of 67"; research: reports/Defect isolation and solution memory.md). The admin's
explicit order, once given, is used verbatim until the next write to that signature's procedures.

Signals (exactly four):
  correct              a += 1
  correct_with_edits   a += 1 on the old version, which becomes superseded; the edited steps become a new version
                       that inherits 0.7 of the old evidence (a' = 1 + 0.7 (a-1), b' = 1 + 0.7 (b-1))
  wrong                b += 1
  wrong_with_edits     b += 1 on the old version (superseded); the edited steps become a new version at the neutral start
                       a = 1, b = 1: written by the admin, not yet judged
Before every signal, every active procedure of that signature decays 2 % towards the prior; after it, a + b is
capped at 50. A fresh model proposal that gets 'correct' or 'correct_with_edits' is stored as version 1 with that
judgement counted: a = 1 + 1, b = 1, and one 'correct' (or 'correct with edits') in its counts; 'wrong' stores only a lesson;
'wrong_with_edits' stores the edited steps as version 1 at the neutral start (a = 1, b = 1, not yet judged).
Every write is also appended to an event log so the history can be read back.

The procedural graph (owner, 2026-11-09: reinforcement is mimicked on a graph, with weights on its nodes and edges; no model
is trained). The same tables and kinds as stage2/procgraph.py, in this same file:
  signature (one failure) -CAUSED_BY-> cause -REPRODUCED_BY-> scenario (one procedure version) -TESTED_BY-> test
  scenario -SUPERSEDES-> the version it replaced; lesson -LESSON_ABOUT-> cause
Weights are a and b, shown as a / (a + b). The four signals set them:
  a procedure's node    the a, b of its procedure row above (with the 2 % decay)
  REPRODUCED_BY edge    1 + the signals that accepted this procedure, 1 + the signals that rejected it
  CAUSED_BY edge and the cause and signature nodes    1 + correct and correct-with-edits, 1 + wrong (wrong-with-edits says the
                        sequence was wrong, not the cause, and leaves them as they are)
The graph is written from the rows of this file after every change (_graph_sync), so it can always be rebuilt from them.
The policy (graph_choice): the path signature -> cause -> procedure with the highest weight (the geometric mean of its three
weights; the admin's explicit order first) whose procedure is not judged wrong more often than right. That procedure is what
the next look at the same failure proposes, and what the test file is written from.
"""
import hashlib
import json
import math
import os
import sqlite3
import sys
import time
from collections import defaultdict

_STAGE2 = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "stage2")
if _STAGE2 not in sys.path:
    sys.path.append(_STAGE2)
from procgraph import SCHEMA as GRAPH_SCHEMA, ProcGraph  # noqa: E402

from . import loader as L  # noqa: E402

SIGNALS = ("correct", "correct_with_edits", "wrong", "wrong_with_edits")
EXPLORE = 0.15             # how strongly a little-tested procedure is preferred, so that the policy cannot lock onto a mediocre one
DECAY = 0.02
CAP = 50.0
INHERIT = 0.7

SCHEMA = """
CREATE TABLE IF NOT EXISTS signature (fine TEXT PRIMARY KEY, coarse TEXT, display TEXT, fields TEXT, first_seen REAL, seen INTEGER DEFAULT 0,
  device TEXT, scenario_name TEXT, alg TEXT);
CREATE INDEX IF NOT EXISTS ix_sig_coarse ON signature (coarse);
CREATE TABLE IF NOT EXISTS procedure (id INTEGER PRIMARY KEY, fine TEXT, version INTEGER, vhash TEXT, supersedes INTEGER, steps TEXT, text TEXT,
  test_path TEXT, producer TEXT, created REAL, status TEXT, a REAL, b REAL, c_ok INTEGER DEFAULT 0, c_ok_edit INTEGER DEFAULT 0,
  c_wrong INTEGER DEFAULT 0, c_wrong_edit INTEGER DEFAULT 0, scenario_name TEXT, validated_on TEXT, outcome TEXT);
CREATE INDEX IF NOT EXISTS ix_proc_fine ON procedure (fine, status);
CREATE TABLE IF NOT EXISTS procedure_order (fine TEXT PRIMARY KEY, order_json TEXT, valid INTEGER, set_by TEXT, at REAL);
CREATE TABLE IF NOT EXISTS signal (id INTEGER PRIMARY KEY, fine TEXT, procedure_id INTEGER, signal TEXT, admin TEXT, at REAL, edits TEXT,
  new_procedure_id INTEGER, upload_id TEXT, finding_id INTEGER);
CREATE TABLE IF NOT EXISTS lesson (id INTEGER PRIMARY KEY, fine TEXT, text TEXT, producer TEXT, at REAL, procedure_id INTEGER);
CREATE TABLE IF NOT EXISTS test_file (procedure_id INTEGER PRIMARY KEY, path TEXT, sha TEXT, text TEXT, at REAL);
CREATE TABLE IF NOT EXISTS event (id INTEGER PRIMARY KEY, kind TEXT, payload TEXT, at REAL);
CREATE TABLE IF NOT EXISTS chat (id INTEGER PRIMARY KEY, upload_id TEXT, finding_id INTEGER, fine TEXT, role TEXT, text TEXT, data TEXT, at REAL);
"""


def vhash(steps):
    return hashlib.sha256(json.dumps(steps, sort_keys=True, separators=(",", ":")).encode()).hexdigest()[:16]


def score(a, b):
    return a / (a + b) if (a + b) > 0 else 0.5


class _GraphDb:
    """What stage2/procgraph.ProcGraph asks of its database. Only its queries are used here: this store writes the graph."""

    def __init__(self, con):
        self.con, self.hooks = con, []


def _json(text, default):
    """A stored JSON text; a damaged one reads as empty, so one bad row cannot take its whole failure down."""
    if not text:
        return default
    try:
        return json.loads(text)
    except (TypeError, ValueError):
        return default


def _hundred(x):
    return "%d of 100" % round(100 * x)


def judged_words(ok, wrong, ok_edits=0, wrong_edits=0):
    """The admin's judgements in words, never a bare number: "not yet judged" or "judged correct 3 of 4 times (1 with your edits)"."""
    good, n = int(round(ok + ok_edits)), int(round(ok + ok_edits + wrong + wrong_edits))
    if n <= 0:
        return "not yet judged"
    edits = int(round(ok_edits + wrong_edits))
    return "judged correct %d of %d time%s%s" % (good, n, "" if n == 1 else "s", (" (%d with edits)" % edits) if edits else "")


SIGNAL_SAID = {"correct": "Correct", "correct_with_edits": "Correct with edits", "wrong": "Wrong", "wrong_with_edits": "Wrong, with edits"}


def stored_words(sg, proc):
    """Where a stored procedure came from: who made the steps, who stored them with which judgement, when, and the recording and defect
    (as ids: the page words them). Never a number without its meaning on the screen."""
    return {"made_by": "the model" if proc.get("producer") == "llm" else str(proc.get("producer") or "").replace("admin:", ""),
            "stored_at": time.strftime("%Y-%m-%d %H:%M", time.localtime(proc.get("created") or 0)),
            "stored_by": (sg or {}).get("admin"), "signal": SIGNAL_SAID.get((sg or {}).get("signal"), (sg or {}).get("signal")),
            "upload_id": (sg or {}).get("upload_id"), "finding_id": (sg or {}).get("finding_id")}


def ab_words(a, b):
    """A node's or a link's weight, as the judgements behind it (its counts above the neutral start Beta(1, 1))."""
    return judged_words(max(0.0, (a or 1) - 1), max(0.0, (b or 1) - 1))


def _check_steps(steps):
    """A procedure must have steps, and when its steps say where they stand, one of them is the defect itself."""
    if not steps:
        raise ValueError("a procedure needs at least one step")
    if any("position" in s for s in steps) and not any(s.get("position") == "fault" for s in steps):
        raise ValueError("the steps no longer contain the defect itself: keep the step of the defect")


def _has_defect_step(steps):
    return any(s.get("position") == "fault" for s in steps or [])


class Store:
    def __init__(self, path):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)
        con = self._con()
        con.executescript(SCHEMA)
        con.executescript(GRAPH_SCHEMA)
        con.commit()
        con.close()
        self._graph_backfill()

    def _con(self):
        con = sqlite3.connect(self.path, timeout=30)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA journal_mode=WAL")
        # a database put back from a backup while the server runs has no graph tables: make them, and fill them from its rows
        if con.execute("SELECT 1 FROM sqlite_master WHERE name='signature'").fetchone() and not con.execute("SELECT 1 FROM sqlite_master WHERE name='pnode'").fetchone():
            con.executescript(GRAPH_SCHEMA)
            for r in con.execute("SELECT fine FROM signature").fetchall():
                self._graph_sync(con, r[0])
            con.commit()
        if not getattr(self, "_outcome_col", False) and con.execute("SELECT 1 FROM sqlite_master WHERE name='procedure'").fetchone():
            cols = [r[1] for r in con.execute("PRAGMA table_info(procedure)")]
            if cols and "outcome" not in cols:
                con.execute("ALTER TABLE procedure ADD COLUMN outcome TEXT")      # {observed, expected{status,description,check}, verified_by}
                con.commit()
            # the isolation tab (statement of 2026-11-03, part 6): the error reason in words and the summary (column summary4: its name is kept)
            # live on the signature row, next to the device name and the scenario name
            lcols = [r[1] for r in con.execute("PRAGMA table_info(lesson)")]
            if lcols and "procedure_id" not in lcols:
                con.execute("ALTER TABLE lesson ADD COLUMN procedure_id INTEGER")
            con.execute("CREATE TABLE IF NOT EXISTS test_file (procedure_id INTEGER PRIMARY KEY, path TEXT, sha TEXT, text TEXT, at REAL)")
            scols = [r[1] for r in con.execute("PRAGMA table_info(signature)")]
            for col in ("device", "reason", "summary4", "reason_by", "summary_by", "firmware"):
                if scols and col not in scols:
                    con.execute("ALTER TABLE signature ADD COLUMN %s TEXT" % col)
            # before 2026-11-11 the 'correct' that stored a fresh proposal was not counted (its a held it): count it, once per database
            con.execute("CREATE TABLE IF NOT EXISTS store_migration (name TEXT PRIMARY KEY, at REAL)")
            mark = "2026-11-11 count the judgement that stored a fresh proposal"
            if not con.execute("SELECT 1 FROM store_migration WHERE name=?", (mark,)).fetchone():
                if con.execute("SELECT 1 FROM sqlite_master WHERE name='signal'").fetchone():
                    for sg, col in (("correct", "c_ok"), ("correct_with_edits", "c_ok_edit")):
                        con.execute("UPDATE procedure SET %s = %s + 1 WHERE id IN (SELECT new_procedure_id FROM signal WHERE procedure_id IS NULL "
                                    "AND signal = ? AND new_procedure_id IS NOT NULL)" % (col, col), (sg,))
                con.execute("INSERT INTO store_migration VALUES (?, ?)", (mark, time.time()))
            con.commit()
            self._outcome_col = True
        return con

    def _event(self, con, kind, payload):
        con.execute("INSERT INTO event (kind, payload, at) VALUES (?, ?, ?)", (kind, json.dumps(payload, default=str), time.time()))

    # ------------------------------------------------------------------ signatures
    def touch_signature(self, sig, device=None, upload_id=None, finding_id=None):
        """Register a signature as seen (sig = signature.compute() result). Returns the seen count after this.
        With upload_id + finding_id the sighting is counted once: opening the same defect again does not add."""
        con = self._con()
        con.execute("CREATE TABLE IF NOT EXISTS sighting (fine TEXT, upload_id TEXT, finding_id INTEGER, at REAL, PRIMARY KEY (fine, upload_id, finding_id))")
        r = con.execute("SELECT seen FROM signature WHERE fine=?", (sig["fine"],)).fetchone()
        if upload_id is not None and finding_id is not None:
            already = con.execute("SELECT 1 FROM sighting WHERE fine=? AND upload_id=? AND finding_id=?", (sig["fine"], upload_id, finding_id)).fetchone()
            if already and r is not None:
                con.close()
                return r["seen"]
            con.execute("INSERT OR IGNORE INTO sighting VALUES (?,?,?,?)", (sig["fine"], upload_id, finding_id, time.time()))
        if r is None:
            con.execute("INSERT INTO signature (fine, coarse, display, fields, first_seen, seen, device, alg) VALUES (?,?,?,?,?,1,?,?)",
                        (sig["fine"], sig["coarse"], sig["display"], json.dumps(sig["fields"]), time.time(), device, sig["fields"].get("alg")))
            seen = 1
        else:
            seen = r["seen"] + 1
            con.execute("UPDATE signature SET seen=? WHERE fine=?", (seen, sig["fine"]))
        self._event(con, "signature_seen", {"fine": sig["fine"], "seen": seen})
        self._graph_sync(con, sig["fine"])
        con.commit()
        con.close()
        return seen

    def remap_findings(self, upload_id, mapping):
        """Defect numbers of one upload moved (rules.Rules.renumber after a timing re-run): the sightings, chat lines and
        signals that name them follow, so nothing stored points at the wrong defect."""
        if not mapping:
            return 0
        con = self._con()
        con.execute("CREATE TABLE IF NOT EXISTS sighting (fine TEXT, upload_id TEXT, finding_id INTEGER, at REAL, PRIMARY KEY (fine, upload_id, finding_id))")
        n = 0
        for table in ("sighting", "chat", "signal"):
            for old, new in mapping.items():
                n += con.execute("UPDATE %s SET finding_id = ? WHERE upload_id = ? AND finding_id = ?" % table, (-int(new), upload_id, int(old))).rowcount
            con.execute("UPDATE %s SET finding_id = -finding_id WHERE upload_id = ? AND finding_id < 0" % table, (upload_id,))
        con.commit()
        con.close()
        return n

    def sightings(self, fine):
        """Where this exact signature was seen: [{upload_id, finding_id, at}] (one row per upload and finding)."""
        con = self._con()
        con.execute("CREATE TABLE IF NOT EXISTS sighting (fine TEXT, upload_id TEXT, finding_id INTEGER, at REAL, PRIMARY KEY (fine, upload_id, finding_id))")
        rows = [dict(r) for r in con.execute("SELECT upload_id, finding_id, at FROM sighting WHERE fine=? ORDER BY at", (fine,))]
        con.close()
        return rows

    def set_scenario_name(self, fine, name, producer):
        con = self._con()
        con.execute("UPDATE signature SET scenario_name=? WHERE fine=?", (name, fine))
        self._event(con, "scenario_named", {"fine": fine, "name": name, "producer": producer})
        self._graph_sync(con, fine)
        con.commit()
        con.close()

    def set_reason(self, fine, reason, by):
        """The error reason in words (named by the model, confirmed by the admin), kept on the signature row."""
        con = self._con()
        con.execute("UPDATE signature SET reason=?, reason_by=? WHERE fine=?", (reason, by, fine))
        self._event(con, "reason_set", {"fine": fine, "reason": reason, "by": by})
        self._graph_sync(con, fine)
        con.commit()
        con.close()

    def set_summary(self, fine, text, by):
        """The summary (who, what, when, where, why, how; at most 100 words), kept on the signature row."""
        con = self._con()
        con.execute("UPDATE signature SET summary4=?, summary_by=? WHERE fine=?", (text, by, fine))
        self._event(con, "summary_set", {"fine": fine, "by": by})
        con.commit()
        con.close()

    def set_device(self, fine, device, firmware=None):
        con = self._con()
        con.execute("UPDATE signature SET device=COALESCE(?, device), firmware=COALESCE(?, firmware) WHERE fine=?", (device, firmware, fine))
        con.commit()
        con.close()

    def lookup(self, sig):
        """{'seen': n, 'first_seen', 'scenario_name', 'reason', 'summary', 'device', 'exact': [procedures in display order], 'similar': [...]}."""
        con = self._con()
        s = con.execute("SELECT * FROM signature WHERE fine=?", (sig["fine"],)).fetchone()
        exact = self._procedures(con, sig["fine"])
        similar = []
        for r in con.execute("SELECT fine, display, scenario_name, seen, device, reason, summary4 FROM signature WHERE coarse=? AND fine!=?", (sig["coarse"], sig["fine"])):
            procs = self._procedures(con, r["fine"])
            similar.append({"fine": r["fine"], "display": r["display"], "scenario_name": r["scenario_name"], "seen": r["seen"], "procedures": procs,
                            "device": r["device"], "reason": r["reason"], "summary": r["summary4"]})
        lessons = [dict(r) for r in con.execute("SELECT id, text, producer, at FROM lesson WHERE fine=? ORDER BY at DESC", (sig["fine"],))]
        con.close()
        return {"seen": s["seen"] if s else 0, "first_seen": s["first_seen"] if s else None,
                "scenario_name": s["scenario_name"] if s else None, "reason": s["reason"] if s else None, "summary": s["summary4"] if s else None,
                "device": s["device"] if s else None, "exact": exact, "similar": similar, "lessons": lessons}

    # ------------------------------------------------------------------ retrieval context ("RAG", research note 10)
    def retrieve(self, sig, device=None, limit=12):
        """The stored facts a new defect with this signature should be told about, as plain-text facts, ranked:
        tier 1 the exact signature (the fine key: this very defect on this device and firmware),
        tier 2 the same defect on other devices or firmware (the family key, the coarse key of the signature),
        tier 3 the same rule at the same level on any command (the wider family: level + rule of the key).
        Inside a tier: more sightings first, then more stored procedures. Each fact carries the device, the reason,
        the scenario name, the best procedure's sequence and score, the expected outcome, the lessons and the summary.
        Returns a list of dicts with 'tier', 'text' (one plain paragraph for the prompt) and the raw fields."""
        con = self._con()
        fields = sig.get("fields") or {}
        lvl, err = fields.get("lvl"), fields.get("err")
        out, seen_fine = [], set()

        def facts_of(row, tier, why):
            procs = self._procedures(con, row["fine"])
            lessons = [r["text"] for r in con.execute("SELECT text FROM lesson WHERE fine=? ORDER BY at DESC LIMIT 5", (row["fine"],))]
            best = procs[0] if procs else None
            f = {"tier": tier, "why": why, "fine": row["fine"], "display": row["display"], "device": row["device"], "firmware": row["firmware"] if "firmware" in row.keys() else None,
                 "seen": row["seen"], "scenario_name": row["scenario_name"], "reason": row["reason"], "summary": row["summary4"],
                 "procedures": len(procs), "best": None, "lessons": lessons}
            if best:
                f["best"] = {"id": best["id"], "version": best["version"], "score_text": best["score_text"], "a": best["a"], "b": best["b"],
                             "counts": {"correct": best["c_ok"], "correct_with_edits": best["c_ok_edit"], "wrong": best["c_wrong"], "wrong_with_edits": best["c_wrong_edit"]},
                             "steps": best["steps"], "outcome": best.get("outcome"), "test_path": best.get("test_path")}
            parts = ["%s (%s): seen %d time%s on device %s" % (why, "tier %d" % tier, row["seen"] or 0, "" if row["seen"] == 1 else "s", row["device"] or "unknown")]
            if row["reason"]:
                parts.append("reason: %s" % row["reason"])
            if row["scenario_name"]:
                parts.append("scenario: %s" % row["scenario_name"])
            if best:
                parts.append("best stored sequence (version %s, score %s from %d correct / %d wrong signals): %s" % (
                    best["version"], best["score_text"], best["c_ok"] + best["c_ok_edit"], best["c_wrong"] + best["c_wrong_edit"],
                    " -> ".join("%s%s" % (s_.get("command"), (" " + json.dumps(s_.get("parameters"))) if s_.get("parameters") else "") for s_ in best["steps"][:12])))
                exp = (best.get("outcome") or {}).get("expected") or {}
                if exp.get("status"):
                    parts.append("expected outcome of a correct device: %s; check: %s" % (exp.get("status"), exp.get("check") or "-"))
            elif procs == [] and tier == 1:
                parts.append("no sequence stored yet")
            for les in lessons[:3]:
                parts.append("lesson: %s" % les[:200])
            if row["summary4"]:
                parts.append("summary: " + " / ".join(x.strip() for x in row["summary4"].splitlines() if x.strip()))
            f["text"] = "; ".join(parts)
            return f

        cols = "fine, coarse, display, seen, device, firmware, scenario_name, reason, summary4, fields"
        r = con.execute("SELECT %s FROM signature WHERE fine=?" % cols, (sig["fine"],)).fetchone()
        if r is not None:
            out.append(facts_of(r, 1, "this exact defect on this device"))
            seen_fine.add(r["fine"])
        wanted = max(limit * 4, 48)        # only so many are read in full: a family or a rule can hold thousands of memories, and the prompt takes twelve
        for r in con.execute("SELECT %s FROM signature WHERE coarse=? AND fine!=? ORDER BY seen DESC LIMIT ?" % cols, (sig["coarse"], sig["fine"], wanted)):
            same_dev = (device or "").strip().upper() and (r["device"] or "").strip().upper() == (device or "").strip().upper()
            out.append(facts_of(r, 2, "the same defect on " + ("this device with other firmware" if same_dev else "another device (%s)" % (r["device"] or "unknown"))))
            seen_fine.add(r["fine"])
        if lvl and err:
            # the rule is matched inside the query: looking through only the most seen signatures would lose a rare memory once there are many others (found 2026-11-10)
            same_rule = ("SELECT %s FROM signature WHERE coarse!=? AND CASE WHEN json_valid(fields) THEN json_extract(fields, '$.lvl') = ? AND json_extract(fields, '$.err') = ? ELSE 0 END "
                         "ORDER BY seen DESC LIMIT ?") % cols
            for r in con.execute(same_rule, (sig["coarse"], lvl, err, wanted)):
                if r["fine"] in seen_fine:
                    continue
                try:
                    f2 = _json(r["fields"], {})
                except ValueError:
                    f2 = {}
                out.append(facts_of(r, 3, "the same rule (%s) at the same level on another command (%s)" % (err, f2.get("cmd"))))
                seen_fine.add(r["fine"])
        con.close()
        out.sort(key=lambda f: (f["tier"], -(f["seen"] or 0), -f["procedures"]))
        for i, f in enumerate(out):
            f["rank"] = i + 1
        return out[:limit]

    @staticmethod
    def _repair_counts(con):
        """A damaged count (not a number, infinite, zero or negative) goes back to the starting value, so that one bad row cannot stop the graph."""
        ok = "(typeof(%s) IN ('integer', 'real') AND %s > 0 AND %s < 1e12)"
        good = " AND ".join(ok % (c, c, c) for c in ("a", "b"))
        try:
            if con.execute("SELECT 1 FROM procedure WHERE NOT (%s) LIMIT 1" % good).fetchone():
                con.execute("UPDATE procedure SET a = CASE WHEN %s THEN a ELSE 1 END, b = CASE WHEN %s THEN b ELSE 1 END WHERE NOT (%s)" % (ok % ("a", "a", "a"), ok % ("b", "b", "b"), good))
                con.commit()
        except sqlite3.Error:
            pass

    def _procedures(self, con, fine):
        self._repair_counts(con)
        rows = [dict(r) for r in con.execute("SELECT * FROM procedure WHERE fine=? AND status='active'", (fine,))]
        for r in rows:
            r["steps"] = _json(r["steps"], [])
            r["outcome"] = _json(r.get("outcome"), None)
            r["score"] = round(score(r["a"], r["b"]), 3)
            r["score_text"] = judged_words(r["c_ok"], r["c_wrong"], r["c_ok_edit"], r["c_wrong_edit"])
        order = con.execute("SELECT order_json, valid FROM procedure_order WHERE fine=?", (fine,)).fetchone()
        if order and order["valid"]:
            want = _json(order["order_json"], [])
            pos = {pid: i for i, pid in enumerate(want)}
            rows.sort(key=lambda r: (pos.get(r["id"], len(want)), -r["score"], -r["created"]))
            for r in rows:
                r["ordered_by"] = "the admin's order"
        else:
            rows.sort(key=lambda r: (-r["score"], -r["version"], r["created"]))
            for r in rows:
                r["ordered_by"] = "score"
        return rows

    # ------------------------------------------------------------------ procedures and signals
    def add_procedure(self, fine, steps, text, producer, test_path=None, scenario_name=None, a=1.0, b=1.0, supersedes=None, version=None, outcome=None,
                      c_ok=0, c_ok_edit=0):
        con = self._con()
        if version is None:
            v = con.execute("SELECT COALESCE(MAX(version), 0) + 1 FROM procedure WHERE fine=?", (fine,)).fetchone()[0]
        else:
            v = version
        cur = con.execute("INSERT INTO procedure (fine, version, vhash, supersedes, steps, text, test_path, producer, created, status, a, b, scenario_name, outcome, "
                          "c_ok, c_ok_edit) VALUES (?,?,?,?,?,?,?,?,?,'active',?,?,?,?,?,?)",
                          (fine, v, vhash(steps), supersedes, json.dumps(steps), text, test_path, producer, time.time(), a, b, scenario_name,
                           json.dumps(outcome) if outcome else None, int(c_ok), int(c_ok_edit)))
        pid = cur.lastrowid
        con.execute("UPDATE procedure_order SET valid=0 WHERE fine=?", (fine,))
        self._event(con, "procedure_added", {"fine": fine, "id": pid, "version": v, "producer": producer, "supersedes": supersedes})
        self._graph_sync(con, fine)
        con.commit()
        con.close()
        return pid

    def set_test_path(self, procedure_id, path):
        con = self._con()
        con.execute("UPDATE procedure SET test_path=? WHERE id=?", (path, procedure_id))
        if path and os.path.exists(path):         # kept here too: a test file that is lost can be written again
            text = open(path, encoding="utf-8").read()
            con.execute("INSERT OR REPLACE INTO test_file (procedure_id, path, sha, text, at) VALUES (?,?,?,?,?)",
                        (procedure_id, path, hashlib.sha256(text.encode()).hexdigest(), text, time.time()))
        r = con.execute("SELECT fine FROM procedure WHERE id=?", (procedure_id,)).fetchone()
        if r is not None:
            self._graph_sync(con, r["fine"])
        con.commit()
        con.close()

    def _decay_and_cap(self, con, fine):
        self._repair_counts(con)
        for r in con.execute("SELECT id, a, b FROM procedure WHERE fine=? AND status='active'", (fine,)).fetchall():
            a = 1 + (r["a"] - 1) * (1 - DECAY)
            b = 1 + (r["b"] - 1) * (1 - DECAY)
            con.execute("UPDATE procedure SET a=?, b=? WHERE id=?", (a, b, r["id"]))

    def _cap(self, con, pid):
        r = con.execute("SELECT a, b FROM procedure WHERE id=?", (pid,)).fetchone()
        if r and r["a"] + r["b"] > CAP:
            k = CAP / (r["a"] + r["b"])
            con.execute("UPDATE procedure SET a=?, b=? WHERE id=?", (r["a"] * k, r["b"] * k, pid))

    def signal(self, fine, procedure_id, sig, admin, edited_steps=None, edited_text=None, upload_id=None, finding_id=None,
               proposal_steps=None, proposal_text=None, scenario_name=None, test_path=None, outcome=None, advice=None):
        """Apply one of the four signals. procedure_id None = the signal is about a fresh model proposal
        (proposal_steps/proposal_text). Returns {'procedure_id': ..., 'new_procedure_id': ...}."""
        if sig not in SIGNALS:
            raise ValueError("signal must be one of %s" % ", ".join(SIGNALS))
        if sig.endswith("_with_edits") and edited_steps is not None:
            _check_steps(edited_steps)
        if procedure_id is None and sig == "correct":
            _check_steps(proposal_steps)
        con = self._con()
        new_id = None
        if procedure_id is None and sig in ("correct", "correct_with_edits"):
            # the same steps already stored for this signature: judge that procedure instead of storing a copy
            steps_ = edited_steps if (sig == "correct_with_edits" and edited_steps is not None) else (proposal_steps or [])
            same = con.execute("SELECT id FROM procedure WHERE fine=? AND status='active' AND vhash=? ORDER BY id LIMIT 1", (fine, vhash(steps_))).fetchone()
            if same is not None:
                procedure_id = same["id"]
                sig = "correct"
        if procedure_id is None:
            # fresh proposal, not yet stored
            if sig in ("correct", "correct_with_edits"):
                steps = edited_steps if (sig == "correct_with_edits" and edited_steps is not None) else (proposal_steps or [])
                text = edited_text if (sig == "correct_with_edits" and edited_text) else (proposal_text or "")
                con.commit()
                con.close()
                # the judgement that stores it is counted (it was lost before 2026-11-11: the card read "0 / 0 signals" beside "67 of 100")
                new_id = self.add_procedure(fine, steps, text, "admin:%s" % admin if sig == "correct_with_edits" else "llm", test_path, scenario_name, outcome=outcome,
                                            a=2.0, b=1.0, c_ok=1 if sig == "correct" else 0, c_ok_edit=1 if sig == "correct_with_edits" else 0)
                con = self._con()
            elif sig == "wrong_with_edits" and edited_steps is not None:
                con.commit()
                con.close()
                new_id = self.add_procedure(fine, edited_steps, edited_text or "", "admin:%s" % admin, test_path, scenario_name, outcome=outcome)     # neutral: not yet judged
                con = self._con()
                con.execute("INSERT INTO lesson (fine, text, producer, at) VALUES (?,?,?,?)", (fine, "model proposal judged wrong; admin replaced it", "admin:%s" % admin, time.time()))
            else:   # wrong
                con.execute("INSERT INTO lesson (fine, text, producer, at) VALUES (?,?,?,?)", (fine, "model proposal judged wrong: " + (proposal_text or "")[:500], "admin:%s" % admin, time.time()))
        else:
            self._decay_and_cap(con, fine)
            r = con.execute("SELECT * FROM procedure WHERE id=?", (procedure_id,)).fetchone()
            if r is None or r["fine"] != fine:
                con.rollback()
                con.close()
                raise ValueError("no such procedure for this failure")
            if r["status"] != "active":
                con.rollback()
                con.close()
                raise ValueError("this version of the procedure was replaced: give the signal on the current version")
            if sig == "correct":
                con.execute("UPDATE procedure SET a=a+1, c_ok=c_ok+1, validated_on=? WHERE id=?", (upload_id, procedure_id))
                if outcome:
                    con.execute("UPDATE procedure SET outcome=? WHERE id=?", (json.dumps(outcome), procedure_id))
            elif sig == "wrong":
                con.execute("UPDATE procedure SET b=b+1, c_wrong=c_wrong+1 WHERE id=?", (procedure_id,))
            elif sig == "correct_with_edits":
                con.execute("UPDATE procedure SET a=a+1, c_ok_edit=c_ok_edit+1, status='superseded' WHERE id=?", (procedure_id,))
                a2, b2 = 1 + INHERIT * (r["a"] + 1 - 1), 1 + INHERIT * (r["b"] - 1)
                con.commit()
                con.close()
                new_id = self.add_procedure(fine, edited_steps if edited_steps is not None else _json(r["steps"], []), edited_text or r["text"],
                                            "admin:%s" % admin, test_path or r["test_path"], scenario_name or r["scenario_name"], a=a2, b=b2, supersedes=procedure_id,
                                            outcome=outcome or _json(r["outcome"], None))
                con = self._con()
            else:   # wrong_with_edits
                con.execute("UPDATE procedure SET b=b+1, c_wrong_edit=c_wrong_edit+1, status='superseded' WHERE id=?", (procedure_id,))
                con.commit()
                con.close()
                new_id = self.add_procedure(fine, edited_steps if edited_steps is not None else _json(r["steps"], []), edited_text or r["text"],
                                            "admin:%s" % admin, test_path, scenario_name or r["scenario_name"], a=1.0, b=1.0, supersedes=procedure_id,
                                            outcome=outcome or _json(r["outcome"], None))
                con = self._con()
            self._cap(con, procedure_id)
            con.execute("UPDATE procedure_order SET valid=0 WHERE fine=?", (fine,))
        con.execute("INSERT INTO signal (fine, procedure_id, signal, admin, at, edits, new_procedure_id, upload_id, finding_id) VALUES (?,?,?,?,?,?,?,?,?)",
                    (fine, procedure_id, sig, admin, time.time(), json.dumps(edited_steps) if edited_steps is not None else None, new_id, upload_id, finding_id))
        if (advice or "").strip():               # the admin's advice stays on the graph, tied to the procedure it was about
            con.execute("INSERT INTO lesson (fine, text, producer, at, procedure_id) VALUES (?,?,?,?,?)",
                        (fine, "advice with the signal %s: %s" % (sig, advice.strip()[:2000]), "admin:%s" % admin, time.time(), new_id or procedure_id))
        self._event(con, "signal", {"fine": fine, "procedure_id": procedure_id, "signal": sig, "admin": admin, "new_procedure_id": new_id})
        self._graph_sync(con, fine)
        con.commit()
        con.close()
        return {"procedure_id": procedure_id, "new_procedure_id": new_id}

    def reorder(self, fine, order, admin):
        con = self._con()
        con.execute("INSERT OR REPLACE INTO procedure_order (fine, order_json, valid, set_by, at) VALUES (?,?,1,?,?)",
                    (fine, json.dumps([int(x) for x in order]), admin, time.time()))
        self._event(con, "reorder", {"fine": fine, "order": order, "admin": admin})
        con.commit()
        con.close()

    def add_lesson(self, fine, text, producer):
        con = self._con()
        con.execute("INSERT INTO lesson (fine, text, producer, at) VALUES (?,?,?,?)", (fine, text, producer, time.time()))
        self._graph_sync(con, fine)
        con.commit()
        con.close()

    # ------------------------------------------------------------------ the procedural graph
    def _graph_backfill(self):
        """Failures stored before the graph existed get their part of it once."""
        con = self._con()
        fines = [r[0] for r in con.execute("SELECT fine FROM signature")]
        have = {r[0] for r in con.execute("SELECT id FROM pnode WHERE kind='signature'")}
        for fine in fines:
            if fine not in have:
                self._graph_sync(con, fine)
        con.commit()
        con.close()

    def _graph_sync(self, con, fine):
        """This failure's nodes and edges, written from its rows. Inside the caller's transaction. The graph can always be rebuilt from the rows, so
        a problem here is reported and never stops the caller, whose open transaction would otherwise lock the database for everyone."""
        try:
            self._graph_write(con, fine)
        except (sqlite3.Error, ValueError, TypeError) as e:
            print("procedural graph not updated for %s: %s" % (fine[:16], e), flush=True)

    def _graph_write(self, con, fine):
        s = con.execute("SELECT * FROM signature WHERE fine=?", (fine,)).fetchone()
        if s is None:
            return
        fields = _json(s["fields"], {})
        procs = [dict(r) for r in con.execute("SELECT * FROM procedure WHERE fine=? ORDER BY id", (fine,))]
        pos, neg = defaultdict(int), defaultdict(int)
        c_pos = c_neg = 0
        for x in con.execute("SELECT procedure_id, new_procedure_id, signal FROM signal WHERE fine=? ORDER BY id", (fine,)):
            good = x["signal"] in ("correct", "correct_with_edits")
            if x["procedure_id"] is not None:
                (pos if good else neg)[x["procedure_id"]] += 1
            if x["new_procedure_id"] is not None and good:  # a version stored with Correct (or Correct with edits) counts as accepted; the steps
                pos[x["new_procedure_id"]] += 1              # written after Wrong start neutral, not yet judged (2026-11-11)
            c_pos += 1 if good else 0
            c_neg += 1 if x["signal"] == "wrong" else 0
        old = [r[0] for r in con.execute("SELECT id FROM pnode WHERE sig=?", (fine,))]
        for i in range(0, len(old), 400):
            part = old[i:i + 400]
            marks = ",".join("?" * len(part))
            con.execute("DELETE FROM pedge WHERE src IN (%s) OR dst IN (%s)" % (marks, marks), part + part)
        con.execute("DELETE FROM pnode WHERE sig=?", (fine,))

        def cap(a, b):
            k = CAP / (a + b) if a + b > CAP else 1.0
            return a * k, b * k

        def node(nid, kind, props, a=1.0, b=1.0, n=0, status="active"):
            con.execute("INSERT OR REPLACE INTO pnode (id, kind, sig, props, a, b, n, status) VALUES (?,?,?,?,?,?,?,?)",
                        (nid, kind, fine, json.dumps(props, sort_keys=True), a, b, n, status))

        def edge(kind, src, dst, props=None, a=1.0, b=1.0, n=0, status="active"):
            con.execute("INSERT OR REPLACE INTO pedge (id, kind, src, dst, props, a, b, n, status) VALUES (?,?,?,?,?,?,?,?,?)",
                        (ProcGraph.edge_id(kind, src, dst), kind, src, dst, json.dumps(props or {}, sort_keys=True), a, b, n, status))

        ca, cb = cap(1.0 + c_pos, 1.0 + c_neg)
        cn = c_pos + c_neg
        cause = "cause::%s::%s" % (fine, fields.get("cause") or "self")
        node(fine, "signature", {"display": s["display"], "seen": s["seen"], "rule": fields.get("err"), "level": fields.get("lvl"), "command": fields.get("cmd"),
                                 "device": s["device"], "scenario_name": s["scenario_name"]}, ca, cb, cn)
        node(cause, "cause", {"cause": fields.get("cause") or "self", "part": fields.get("part"), "reason": s["reason"]}, ca, cb, cn)
        edge("CAUSED_BY", fine, cause, None, ca, cb, cn)
        for p in procs:
            pid = "proc::%d" % p["id"]
            state = "active" if p["status"] == "active" else "superseded"
            node(pid, "scenario", {"procedure_id": p["id"], "version": p["version"], "vhash": p["vhash"], "producer": p["producer"], "status": state,
                                   "scenario_name": p["scenario_name"], "test_path": p["test_path"]},
                 p["a"], p["b"], pos[p["id"]] + neg[p["id"]], state)
            ea, eb = cap(1.0 + pos[p["id"]], 1.0 + neg[p["id"]])
            edge("REPRODUCED_BY", cause, pid, {"procedure": _json(p["steps"], [])}, ea, eb, pos[p["id"]] + neg[p["id"]], state)
            if p["supersedes"]:
                edge("SUPERSEDES", pid, "proc::%d" % p["supersedes"])
            if p["test_path"]:
                tid = "test::%d" % p["id"]
                node(tid, "test", {"path": p["test_path"], "file": os.path.basename(p["test_path"])})
                edge("TESTED_BY", pid, tid, {"path": p["test_path"]})
        known = {"proc::%d" % p["id"] for p in procs}
        for r in con.execute("SELECT id, text, producer, procedure_id FROM lesson WHERE fine=?", (fine,)).fetchall():
            lid = "lesson::%d" % r["id"]
            node(lid, "lesson", {"text": (r["text"] or "")[:400], "producer": r["producer"]})
            about = "proc::%d" % r["procedure_id"] if r["procedure_id"] else None
            edge("LESSON_ABOUT", lid, about if about in known else cause)

    def graph_paths(self, fine):
        """Every usable path signature -> cause -> procedure of this failure, in the order the policy takes them."""
        con = self._con()
        rows = ProcGraph(_GraphDb(con)).procedures_for(fine, statuses=None)
        procs = {r["id"]: r for r in self._procedures(con, fine)}
        order = con.execute("SELECT order_json, valid FROM procedure_order WHERE fine=?", (fine,)).fetchone()
        place = {int(x): i for i, x in enumerate(_json(order["order_json"], []))} if order and order["valid"] else {}
        # who stored each procedure, when, and from which recording and defect (owner, 2026-11-11: "who gave you that")
        stored = {}
        for g in con.execute("SELECT new_procedure_id, procedure_id, signal, admin, at, upload_id, finding_id FROM signal WHERE fine=? AND new_procedure_id IS NOT NULL "
                             "ORDER BY id", (fine,)):
            stored.setdefault(g["new_procedure_id"], dict(g))
        con.close()
        out = []
        for x in rows:
            pid = int(x["scenario_id"].split("::")[1])
            r = procs.get(pid)
            if r is None:
                continue
            w = (x["cause_post"] * x["edge_post"] * x["scenario_post"]) ** (1 / 3.0)
            out.append({"procedure_id": pid, "version": r["version"], "steps": r["steps"], "text": r["text"], "scenario_name": r["scenario_name"], "producer": r["producer"],
                        "test_path": r["test_path"], "test_state": self._test_state(pid, r["test_path"]), "outcome": r.get("outcome"), "weight": w,
                        "weight_text": judged_words(r["c_ok"], r["c_wrong"], r["c_ok_edit"], r["c_wrong_edit"]), "stored": stored_words(stored.get(pid), r),
                        "cause_weight": round(x["cause_post"], 3), "edge_weight": round(x["edge_post"], 3), "node_weight": round(x["scenario_post"], 3),
                        "counts": {"correct": r["c_ok"], "correct_with_edits": r["c_ok_edit"], "wrong": r["c_wrong"], "wrong_with_edits": r["c_wrong_edit"]},
                        "ordered_by": "the admin's order" if pid in place else "the graph's weights"})
        tried = {p["procedure_id"]: sum(p["counts"].values()) for p in out}
        total = sum(tried.values())
        for p in out:
            p["explore"] = EXPLORE * math.sqrt(math.log(total + 1) / (tried[p["procedure_id"]] + 1))
        out.sort(key=lambda p: (place.get(p["procedure_id"], len(place)), -(p["weight"] + p["explore"]), -p["version"]))
        if out and out[0]["ordered_by"] != "the admin's order" and out[0]["weight"] < max(p["weight"] for p in out):
            out[0]["ordered_by"] = "the graph's weights, trying a procedure tested less often"
        return out

    def _test_state(self, procedure_id, path):
        """The regression test named on a procedure: on file, changed since it was written, written again from the stored copy, or missing."""
        if not path:
            return None
        con = self._con()
        r = con.execute("SELECT sha, text FROM test_file WHERE procedure_id=?", (procedure_id,)).fetchone()
        con.close()
        if not os.path.exists(path):
            if r is None or r["text"] is None:
                return "missing"
            os.makedirs(os.path.dirname(path), exist_ok=True)
            L.write_text_atomic(path, r["text"])
            return "written again from the stored copy"
        if r is not None and hashlib.sha256(open(path, encoding="utf-8").read().encode()).hexdigest() != r["sha"]:
            return "changed since it was written"
        return "on file"

    def _family(self, sig):
        """Other failures that are this one in another form, nearest first: the same defect on other firmware or another device, then the same
        rule on the same command with another cause or status. [(fine, words)]."""
        con = self._con()
        fields = sig.get("fields") or {}
        rows = con.execute("SELECT fine, coarse, fields, seen FROM signature WHERE fine != ? ORDER BY seen DESC", (sig["fine"],)).fetchall()
        con.close()
        near, wider = [], []
        for r in rows:
            f = _json(r["fields"], {})
            if r["coarse"] == sig.get("coarse"):
                near.append((r["fine"], "the same defect on other firmware or another device"))
            elif (f.get("lvl"), f.get("err"), f.get("cmd")) == (fields.get("lvl"), fields.get("err"), fields.get("cmd")):
                wider.append((r["fine"], "the same rule on the same command, with another cause or status"))
        return near + wider

    def graph_choice(self, sig, exclude=()):
        """The policy: the first path whose procedure was not just rejected and is not judged wrong more often than right, or None.
        `sig` is a signature key, or the signature itself: then, when this exact failure has nothing usable, the nearest member of its family
        answers (a failure coming back on new firmware is the case a regression suite exists for), marked with from_family."""
        skip = {int(x) for x in exclude or () if str(x).isdigit()}
        usable = lambda fine: next((p for p in self.graph_paths(fine) if p["procedure_id"] not in skip and p["node_weight"] >= 0.5 and _has_defect_step(p["steps"])), None)   # noqa: E731
        if not isinstance(sig, dict):
            return usable(sig)
        p = usable(sig["fine"])
        if p is not None:
            return p
        for fine, words in self._family(sig):
            q = usable(fine)
            if q is not None:
                return dict(q, from_family=words, family_signature=fine)
        return None

    def graph_view(self, fine):
        """The failure's graph in plain fields: nodes, edges (each with its weight) and the paths."""
        con = self._con()
        g = ProcGraph(_GraphDb(con))
        nodes = g.nodes(sig=fine, status=None)
        ids = [n["id"] for n in nodes]
        edges = []
        for i in range(0, len(ids), 400):
            part = ids[i:i + 400]
            marks = ",".join("?" * len(part))
            edges += [g._erow(r) for r in con.execute("SELECT id, kind, src, dst, props, a, b, n, status FROM pedge WHERE src IN (%s)" % marks, part)]
        con.close()

        def label(n):
            p = n["props"]
            return {"signature": p.get("display"), "cause": "cause: %s" % p.get("cause"), "scenario": "procedure version %s" % p.get("version"),
                    "test": "test file %s" % p.get("file"), "lesson": "lesson: %s" % (p.get("text") or "")[:80]}.get(n["kind"], n["id"])

        names = {n["id"]: label(n) for n in nodes}
        return {"signature": fine,
                "nodes": [{"id": n["id"], "kind": n["kind"], "label": names[n["id"]], "a": n["a"], "b": n["b"], "n": n["n"], "status": n["status"],
                           "weight": round(n["posterior"], 3), "weight_text": ab_words(n["a"], n["b"]),
                           "seen": n["props"].get("seen"), "path": n["props"].get("path")} for n in nodes],
                "edges": [{"id": e["id"], "kind": e["kind"], "from": names.get(e["src"], e["src"]), "to": names.get(e["dst"], e["dst"]), "a": e["a"], "b": e["b"], "n": e["n"],
                           "status": e["status"], "weight": round(e["posterior"], 3), "weight_text": ab_words(e["a"], e["b"])} for e in edges],
                "paths": self.graph_paths(fine)}

    @staticmethod
    def graph_change(before, after):
        """In plain sentences, what one signal changed: two graph_view() results."""
        was_n = {n["id"]: n for n in before.get("nodes") or []}
        was_e = {e["id"]: e for e in before.get("edges") or []}
        lines = []
        for e in after.get("edges") or []:
            old = was_e.get(e["id"])
            if e["kind"] == "CAUSED_BY" and old and old["weight_text"] != e["weight_text"]:
                lines.append("the link from this failure to its %s: %s -> %s" % (e["to"], old["weight_text"], e["weight_text"]))
            if e["kind"] == "REPRODUCED_BY" and old and old["weight_text"] != e["weight_text"]:
                lines.append("the link to %s: %s -> %s" % (e["to"], old["weight_text"], e["weight_text"]))
        for n in after.get("nodes") or []:
            old = was_n.get(n["id"])
            if n["kind"] != "scenario":
                continue
            if old is None:
                lines.append("new %s: %s" % (n["label"], n["weight_text"]))
            elif old["status"] != n["status"]:
                lines.append("%s replaced by your edited version" % n["label"])
            elif old["weight_text"] != n["weight_text"]:
                lines.append("%s: %s -> %s" % (n["label"], old["weight_text"], n["weight_text"]))
        first = lambda v: (v.get("paths") or [{}])[0].get("version")                    # noqa: E731
        a, b = first(before), first(after)
        if b is not None and a != b:
            lines.append("first choice next time: procedure version %s%s" % (b, " (it was version %s)" % a if a is not None else ""))
        return lines

    # ------------------------------------------------------------------ chat log
    def chat_append(self, upload_id, finding_id, fine, role, text, data=None):
        con = self._con()
        con.execute("INSERT INTO chat (upload_id, finding_id, fine, role, text, data, at) VALUES (?,?,?,?,?,?,?)",
                    (upload_id, finding_id, fine, role, text, json.dumps(data) if data is not None else None, time.time()))
        con.commit()
        con.close()

    def chat_history(self, upload_id, finding_id):
        con = self._con()
        rows = [dict(r) for r in con.execute("SELECT role, text, data, at FROM chat WHERE upload_id=? AND finding_id=? ORDER BY id", (upload_id, finding_id))]
        con.close()
        for r in rows:
            r["data"] = _json(r["data"], None)
        return rows

    def signals_of(self, fine):
        con = self._con()
        rows = [dict(r) for r in con.execute("SELECT * FROM signal WHERE fine=? ORDER BY at", (fine,))]
        con.close()
        return rows

    def stats(self):
        con = self._con()
        out = {"signatures": con.execute("SELECT COUNT(*) FROM signature").fetchone()[0],
               "procedures": con.execute("SELECT COUNT(*) FROM procedure WHERE status='active'").fetchone()[0],
               "signals": con.execute("SELECT COUNT(*) FROM signal").fetchone()[0]}
        con.close()
        return out
