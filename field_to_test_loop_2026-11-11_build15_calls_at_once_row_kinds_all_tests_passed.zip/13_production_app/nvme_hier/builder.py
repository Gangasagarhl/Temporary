"""Build the containment tree from the five staged level tables, by identity, never by time stamp alone.

Joins (research note 04_export_and_grouping.md, "hierarchy builder contract"):
  packet -> link transaction     same Link Dir + PSN, in row order; a repeated PSN while the earlier one is still
                                 open is a replay of it; an Ack/Nak DLLP joins the open link transaction of the
                                 other direction whose PSN it names (explicit); links it covers implicitly close
  link -> split transaction      a split row IS its request (same direction, RequesterID, Tag and time stamp);
                                 completions (other direction, same RequesterID + Tag) join the oldest open split
                                 with that key until Metrics.# LinkTrans is reached
  link/split -> NVMe transaction the NVMe transaction row names its first packet's time, its address and how many
                                 units it holds (Metrics.# Link & Split Trans): the units are the first unassigned
                                 posted link transactions / split transactions at or after that time whose address
                                 lies in the row's address range (doorbells, interrupts, queue entries, data pages)
  NVMe transaction -> command    SQID + CID against the open command (the submission doorbell opens the command
                                 whose time stamp equals the doorbell's; the completion-queue head doorbell goes to
                                 the command whose completion entry sits in slot head - 1 of the queue as it was
                                 created at that moment, else to the oldest completed command of that queue; a queue
                                 created again starts with nothing waiting); Metrics.# NVME Trans bounds the command
Time stamps only order the streams, bound windows and attach the context rows (flow control, ordered sets, link
events) to the command whose window contains them. Every mismatch with the analyzer's own Metrics.# counts is
counted and reported, never hidden.

Results are written back into the staging tables: parent, parent_level, relation (member | context | orphan),
dur_ps (per-level duration, see durations()).

Memory: every pass streams one table in row order and keeps only what is OPEN in RAM (open link transactions per
direction and PSN, open split transactions per requester and tag, open commands per SQID and CID, the handful of
page heads one NVMe transaction is choosing from). Everything that scales with the capture lives in the attached
scratch database `w` (hier.work.sqlite): the parent of every row as it is decided (batches of BATCH rows), the
not-yet-consumed split rows and units (indexed, consumed rows deleted), the command queue with its attach counts,
the command windows. The write-back then copies the scratch tables into the staging tables in rowid chunks of
CHUNK rows, one transaction each, so neither the Python process nor the write-ahead log holds a whole table.
"""
import heapq
import json
import os
import re
import sqlite3
import time
from collections import defaultdict, deque

from . import loader as L
from . import names as N

PAGE = 4096
LOOKAHEAD_LINKS = 256      # link rows the PSN search may look past (skipped rows are never revisited)
LOOKAHEAD_CMDS = 512       # command rows the open-next search may look past
LOOKAHEAD_SPLITS = 8       # split rows with the same key the exact-time search may look past
# the admin can change these three for a project (owner, 2026-11-10: "an admin can change, right?"); build(settings=) takes them, the constants are the defaults
SETTING_BOUNDS = {"look_links": (1, 65536), "look_splits": (1, 4096), "look_cmds": (1, 65536)}


def settings_of(given=None):
    """The three look-ahead settings to build with: the defaults, replaced by what was given within its bounds."""
    out = {"look_links": LOOKAHEAD_LINKS, "look_splits": LOOKAHEAD_SPLITS, "look_cmds": LOOKAHEAD_CMDS}
    for k, (lo, hi) in SETTING_BOUNDS.items():
        try:
            v = int((given or {}).get(k, out[k]))
        except (TypeError, ValueError):
            continue
        out[k] = max(lo, min(hi, v))
    return out
BATCH = 20000              # rows per executemany into the scratch tables
CHUNK = 200000             # rowids per write-back transaction
PROGRESS_EVERY = 2000      # rows between two looks at the clock; the reports themselves are at most one per second


def _other(d):
    return "Upstream" if d == "Downstream" else "Downstream"


class Sink:
    """Batched INSERT OR REPLACE into one scratch table (BATCH rows per executemany, committed as it goes)."""

    def __init__(self, con, sql):
        self.con = con
        self.sql = sql
        self.rows = []
        self.count = 0

    def add(self, row):
        self.rows.append(row)
        if len(self.rows) >= BATCH:
            self.flush()

    def flush(self):
        if self.rows:
            self.con.executemany(self.sql, self.rows)
            self.count += len(self.rows)
            self.rows = []
            self.con.commit()


class LinkStream:
    """The link rows of one direction in row order, read LOOKAHEAD_LINKS rows ahead at most. The PSN search looks
    into this window only; the rows it skips are consumed with the match and never revisited (as before)."""

    def __init__(self, con, d, look=LOOKAHEAD_LINKS):
        self.look = look
        self.cur = con.execute("SELECT rowid_file, psn, n_packets, t_ps FROM lnk WHERE dir=? ORDER BY rowid_file", (d,))
        self.win = deque()
        self.done = False
        self.consumed = 0

    def fill(self):
        while len(self.win) < self.look and not self.done:
            r = self.cur.fetchone()
            if r is None:
                self.done = True
                break
            self.win.append((r[0], r[1], r[2] or 1, r[3]))

    def find(self, psn, t_ps):
        """Index in the window of the link row this TLP belongs to, or None."""
        self.fill()
        w = self.win
        if w and w[0][1] == psn:
            return 0
        for j in range(len(w)):
            if w[j][1] == psn and (w[j][3] is None or t_ps is None or w[j][3] == t_ps):
                return j
        return None

    def take(self, j):
        """Consume the window up to and including j; returns (row, rows skipped)."""
        for _ in range(j):
            self.win.popleft()
        row = self.win.popleft()
        self.consumed += j + 1
        return row, j

    def close(self):
        self.cur.close()


class Build:
    def __init__(self, con, progress=None, settings=None):
        self.con = con
        self.settings = settings_of(settings)
        self.report_to = progress or (lambda step, detail, pct: None)
        self.step, self.pct, self.said, self.finished = None, 0.0, 0.0, 0.0
        self.step_since = self.started = time.time()
        self.report = {"steps": {}, "mismatches": {}, "unmatched": {}, "orphans": {}, "settings": dict(self.settings)}
        r = con.execute("SELECT v FROM meta WHERE k='levels_present'").fetchone()
        self.levels = json.loads(r[0]) if r else []
        self.tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.rebuild = con.execute("SELECT 1 FROM meta WHERE k='build'").fetchone() is not None
        self._plan()
        self._scratch()

    def _plan(self):
        """How much work each step is, in rows: the percentage of the whole build comes from it."""
        n = {t: (self.con.execute("SELECT COALESCE(MAX(rowid_file), 0) FROM %s" % t).fetchone()[0] if t in self.tables else 0) for t in ("pkt", "lnk", "spl", "ntx", "cmd")}
        # (rows counted, cost): the cost is rows x microseconds per row measured on a recording of 13.9 million rows, so that the percentage follows the time
        self.plan = {"tree: packets to link transactions": (n["pkt"], 11 * n["pkt"]), "tree: link to split transactions": (n["lnk"], 12 * n["lnk"]),
                     "tree: units to NVMe transactions": (n["ntx"], 5 * (n["lnk"] + n["spl"] + n["ntx"])), "tree: NVMe transactions to commands": (n["ntx"], 65 * n["ntx"]),
                     "tree: context rows to command windows": (n["pkt"] // 8, 55 * n["pkt"]), "tree: writing the packet links": (n["pkt"], 44 * n["pkt"]),
                     "tree: writing the link transaction links": (n["lnk"], 14 * n["lnk"]), "tree: writing the split transaction links": (n["spl"], 14 * n["spl"]),
                     "tree: writing the NVMe transaction links": (n["ntx"], 14 * n["ntx"]), "tree: checking the analyzer's counts": (7, 8 * (n["lnk"] + n["spl"] + n["ntx"] + n["cmd"]))}
        self.work = max(1, sum(w for _t, w in self.plan.values()))

    def progress(self, step, detail=""):
        """Report the step and the percentage of the whole build: at once on a new step, otherwise at most once a second."""
        now = time.time()
        if step == self.step and now - self.said < L.REPORT_SECONDS:
            return
        if step != self.step:
            self.finished += self.plan.get(self.step, (0, 0))[1]
            self.step = step
            self.step_since = now
        total, weight = self.plan.get(step, (0, 0))
        m = re.match(r"\s*([\d,]+)", detail or "")
        part = min(0.99, int(m.group(1).replace(",", "")) / total) if m and total else 0.0
        self.pct = max(self.pct, round(min(99.0, 100.0 * (self.finished + part * weight) / self.work), 1))
        self.said = now
        self.report_to(step, detail, self.pct)

    def beat(self, secs):
        """Long database work is running: nothing to count, but the page must not look stuck. The percentage keeps moving, by how long this step should
        take at the speed the build has had so far (never past this step's share)."""
        self.said = time.time()
        weight = self.plan.get(self.step, (0, 0))[1]
        spent = self.said - self.started
        if weight and self.finished and spent > 0:
            expected = weight * (spent - (self.said - self.step_since)) / self.finished       # seconds per unit of work so far x this step's work
            if expected > 0:
                self.pct = max(self.pct, round(min(99.0, 100.0 * (self.finished + 0.95 * min(1.0, (self.said - self.step_since) / expected) * weight) / self.work), 1))
        self.report_to(self.step, "still working on this step, %d s so far" % (self.said - self.step_since), self.pct)

    def _scratch(self):
        """Scratch tables (in the attached `w` database): one parent row per decided row, one duration per row."""
        con = self.con
        for t in ("pkt", "lnk", "spl", "ntx"):
            con.execute("CREATE TABLE w.%s_parent (rowid INTEGER PRIMARY KEY, lvl TEXT, par INTEGER, rel TEXT%s)"
                        % (t, ", t INTEGER" if t == "pkt" else ""))
        for t in ("lnk", "spl", "ntx", "cmd"):
            con.execute("CREATE TABLE w.%s_dur (rowid INTEGER PRIMARY KEY, dur INTEGER)" % t)
        con.commit()
        self.sink = {t: Sink(con, "INSERT OR REPLACE INTO w.%s_parent (rowid, lvl, par, rel%s) VALUES (?,?,?,?%s)"
                             % (t, ", t" if t == "pkt" else "", ",?" if t == "pkt" else "")) for t in ("pkt", "lnk", "spl", "ntx")}
        self.dur = {t: Sink(con, "INSERT OR REPLACE INTO w.%s_dur (rowid, dur) VALUES (?,?)" % t) for t in ("lnk", "spl", "ntx", "cmd")}

    def _flush(self):
        for s in list(self.sink.values()) + list(self.dur.values()):
            s.flush()

    # ------------------------------------------------------------------ 1 packets -> links
    def packets_to_links(self):
        t0 = time.time()
        con = self.con
        pkt_sink = self.sink["pkt"]
        dur_lnk = self.dur["lnk"]
        links = {"Upstream": LinkStream(con, "Upstream", self.settings["look_links"]), "Downstream": LinkStream(con, "Downstream", self.settings["look_links"])}
        total = {d: 0 for d in links}
        for d, k in con.execute("SELECT dir, COUNT(*) FROM lnk GROUP BY dir"):
            if d in total:
                total[d] = k
        open_ = {"Upstream": {}, "Downstream": {}}      # psn -> [link rowid, attached, needed, first_t, last_t]
        unmatched_tlp = 0
        unmatched_ack = 0
        replays = 0
        n = 0
        skipped_links = 0
        tlp_packets = ack_nak_packets = 0
        for rowid, _pn, d, tlp_type, dllp_type, psn, acknak, t_ps in con.execute(
                "SELECT rowid_file, n, dir, tlp_type, dllp_type, psn, acknak, t_ps FROM pkt ORDER BY rowid_file"):
            n += 1
            if n % PROGRESS_EVERY == 0:
                self.progress("tree: packets to link transactions", "{:,} packets".format(n))
            if tlp_type and d in links:
                tlp_packets += 1
                st = open_[d].get(psn)
                if st is not None:
                    st[1] += 1
                    st[4] = t_ps
                    replays += 1
                    pkt_sink.add((rowid, "link", st[0], "member", t_ps))
                    if st[1] >= st[2]:
                        open_[d].pop(psn, None)
                    continue
                stream = links[d]
                found = stream.find(psn, t_ps)
                if found is None:
                    unmatched_tlp += 1
                    continue
                (lrow, _, needed, _t_first), skipped = stream.take(found)
                skipped_links += skipped
                pkt_sink.add((rowid, "link", lrow, "member", t_ps))
                if needed > 1:
                    open_[d][psn] = [lrow, 1, needed, t_ps, t_ps]
                else:
                    dur_lnk.add((lrow, 0))
            elif dllp_type and (dllp_type.upper() in ("ACK", "NAK")) and acknak is not None and d in links:
                ack_nak_packets += 1
                td = _other(d)
                seq = acknak
                kind = dllp_type.upper()
                st = open_[td].get(seq)
                if kind == "ACK":
                    if st is not None:
                        st[1] += 1
                        pkt_sink.add((rowid, "link", st[0], "member", t_ps))
                        if st[3] is not None and t_ps is not None:
                            dur_lnk.add((st[0], t_ps - st[3]))
                        if st[1] >= st[2]:
                            open_[td].pop(seq, None)
                    else:
                        unmatched_ack += 1
                        pkt_sink.add((rowid, "link", None, "context", t_ps))
                    # links the Ack covers implicitly close
                    for psn2 in [x for x in open_[td] if ((seq - x) & 0xFFF) < 2048 and x != seq]:
                        s2 = open_[td][psn2]
                        if s2[1] >= s2[2]:
                            open_[td].pop(psn2, None)
                else:
                    # NAK: it names the last TLP received correctly (PCIe Data Link Layer retry rules), so it acknowledges
                    # every open TLP up to that number and refuses the later ones. Which link transaction the analyzer
                    # counts the Nak packet in is not documented: follow its own count (Metrics.# Packets). The link the
                    # Nak names gets it if that link still needs a packet; otherwise the first refused link that does.
                    named = open_[td].get(seq)
                    later = sorted((x for x in open_[td] if ((x - seq) & 0xFFF) < 2048 and x != seq), key=lambda x: (x - seq) & 0xFFF)
                    target = named if (named is not None and named[1] < named[2]) else next((open_[td][x] for x in later if open_[td][x][1] < open_[td][x][2]), None)
                    if target is not None:
                        target[1] += 1
                        pkt_sink.add((rowid, "link", target[0], "member", t_ps))
                    else:
                        unmatched_ack += 1
                        pkt_sink.add((rowid, "link", None, "context", t_ps))
                    for psn2 in [x for x in open_[td] if ((seq - x) & 0xFFF) < 2048]:    # psn <= seq: acknowledged by the Nak
                        s2 = open_[td][psn2]
                        if s2[1] >= s2[2]:
                            if s2[3] is not None and t_ps is not None:
                                dur_lnk.add((s2[0], t_ps - s2[3]))
                            open_[td].pop(psn2, None)
            else:
                pkt_sink.add((rowid, None, None, "context", t_ps))
        self._flush()
        for s in links.values():
            s.close()
        # links still open: every one with fewer packets than the analyzer counted
        short = sum(1 for d in open_ for st in open_[d].values() if st[1] < st[2])
        total_links = sum(total.values())
        remaining = sum(total[d] - links[d].consumed for d in links)
        self.report["steps"]["packets_to_links"] = {
            "packets": n, "tlp_packets": tlp_packets, "ack_nak_packets": ack_nak_packets, "link_rows": total_links, "link_rows_matched": total_links - skipped_links - remaining,
            "link_rows_skipped": skipped_links + remaining,
            "replays_seen": replays, "tlp_without_link_row": unmatched_tlp, "ack_nak_without_open_link": unmatched_ack,
            "links_with_fewer_packets_than_counted": short, "seconds": round(time.time() - t0, 2)}

    # ------------------------------------------------------------------ 2 links -> splits
    def links_to_splits(self):
        t0 = time.time()
        con = self.con
        lnk_sink = self.sink["lnk"]
        dur_spl = self.dur["spl"]
        # the not-yet-consumed split rows, by (dir, rid, tag) in row order; a consumed row is deleted
        con.execute("CREATE TABLE w.spl_q (rowid INTEGER PRIMARY KEY, dir TEXT, rid TEXT, tag INTEGER, n_links INTEGER, t INTEGER)")
        con.execute("INSERT INTO w.spl_q SELECT rowid_file, dir, rid, tag, CASE WHEN n_links IS NULL OR n_links = 0 THEN 2 ELSE n_links END, t_ps FROM spl ORDER BY rowid_file")
        con.execute("CREATE INDEX w.ix_spl_q ON spl_q (dir, rid, tag, rowid)")
        con.commit()
        n_splits = con.execute("SELECT COUNT(*) FROM w.spl_q").fetchone()[0]
        q_sql = "SELECT rowid, n_links, t FROM w.spl_q WHERE dir IS ? AND rid IS ? AND tag IS ? ORDER BY rowid LIMIT %d" % self.settings["look_splits"]
        open_ = defaultdict(deque)     # (req dir, rid, tag) -> deque of [split rowid, attached, needed, req_t, first_cpl_t]
        matched_req = 0
        unmatched_req = 0
        unmatched_cpl = 0
        completions = 0
        n = 0
        for rowid, d, tlp_type, rid, tag, t_ps in con.execute("SELECT rowid_file, dir, tlp_type, rid, tag, t_ps FROM lnk ORDER BY rowid_file"):
            n += 1
            if n % PROGRESS_EVERY == 0:
                self.progress("tree: link to split transactions", "{:,} link transactions".format(n))
            cls = N.tlp_class(tlp_type)
            if cls == "non-posted":
                key = (d, rid, tag)
                q = con.execute(q_sql, key).fetchall()
                if q and (q[0][2] is None or t_ps is None or q[0][2] == t_ps):
                    srow, needed, t_req = q[0]
                elif q:
                    # the split's time stamp is its request's: look a few ahead for the exact time
                    hit = None
                    for k in range(len(q)):
                        if q[k][2] == t_ps:
                            hit = k
                            break
                    if hit is None:
                        unmatched_req += 1
                        lnk_sink.add((rowid, "split", None, "orphan"))
                        continue
                    srow, needed, t_req = q[hit]
                else:
                    unmatched_req += 1
                    lnk_sink.add((rowid, "split", None, "orphan"))
                    continue
                con.execute("DELETE FROM w.spl_q WHERE rowid=?", (srow,))
                matched_req += 1
                lnk_sink.add((rowid, "split", srow, "member"))
                if needed > 1:
                    open_[key].append([srow, 1, needed, t_ps, None])
            elif cls == "completion":
                completions += 1
                key = (_other(d), rid, tag)
                q = open_.get(key)
                if not q:
                    unmatched_cpl += 1
                    lnk_sink.add((rowid, "split", None, "orphan"))
                    continue
                st = q[0]
                st[1] += 1
                if st[4] is None:
                    st[4] = t_ps
                    if st[3] is not None and t_ps is not None:
                        dur_spl.add((st[0], t_ps - st[3]))
                lnk_sink.add((rowid, "split", st[0], "member"))
                if st[1] >= st[2]:
                    q.popleft()
            # posted / other classes: no split; units_to_ntx may claim them, else they are orphans at write time
        self._flush()
        still_open = sum(len(q) for q in open_.values())
        con.execute("DROP TABLE w.spl_q")
        con.commit()
        self.report["steps"]["links_to_splits"] = {
            "split_rows": n_splits, "requests_matched": matched_req, "requests_without_split_row": unmatched_req,
            "completions": completions, "completions_without_open_split": unmatched_cpl, "splits_with_fewer_completions_than_counted": still_open,
            "seconds": round(time.time() - t0, 2)}

    # ------------------------------------------------------------------ 3 units -> NVMe transactions
    def units_to_ntx(self):
        t0 = time.time()
        con = self.con
        lnk_sink, spl_sink, dur_ntx = self.sink["lnk"], self.sink["spl"], self.dur["ntx"]
        # units: posted links (not completions, not non-posted) and split rows, keyed by page and time; a unit an
        # NVMe transaction takes is deleted, so "the first unassigned unit at or after the time" is one index seek
        con.execute("CREATE TABLE w.unit (seq INTEGER PRIMARY KEY, page INTEGER, t INTEGER, level TEXT, rowid INTEGER)")
        unit_sink = Sink(con, "INSERT INTO w.unit (seq, page, t, level, rowid) VALUES (?,?,?,?,?)")
        seq = 0
        for rowid, tlp_type, addr, t_ps in (con.execute("SELECT rowid_file, tlp_type, addr, t_ps FROM lnk ORDER BY rowid_file") if "lnk" in self.tables else ()):
            if addr is not None and N.tlp_class(tlp_type) == "posted":
                seq += 1
                unit_sink.add((seq, addr >> 12, t_ps or 0, "link", rowid))
        for rowid, addr, t_ps in (con.execute("SELECT rowid_file, addr, t_ps FROM spl ORDER BY rowid_file") if "spl" in self.tables else ()):
            if addr is not None:
                seq += 1
                unit_sink.add((seq, addr >> 12, t_ps or 0, "split", rowid))
        unit_sink.flush()
        n_units = seq
        con.execute("CREATE INDEX w.ix_unit ON unit (page, t, seq)")
        con.commit()
        head_sql = "SELECT t, seq, level, rowid FROM w.unit WHERE page=? AND t>=? ORDER BY t, seq LIMIT ?"
        used = 0
        n_ntx = 0
        short = 0
        empty = 0
        for nrow, addr, nbytes, n_ls, t_ps in con.execute("SELECT rowid_file, addr, nbytes, n_links_splits, t_ps FROM ntx ORDER BY rowid_file"):
            n_ntx += 1
            if n_ntx % PROGRESS_EVERY == 0:
                self.progress("tree: units to NVMe transactions", "{:,} transactions".format(n_ntx))
            need = n_ls or 1
            if addr is None:
                empty += 1
                continue
            lo = addr >> 12
            hi = (addr + max(nbytes or 4, 4) - 1) >> 12
            t_min = t_ps or 0
            taken = []
            if lo == hi:
                taken = con.execute(head_sql, (lo, t_min, need)).fetchall()
            else:
                # merge the pages in (time, seq) order: the heap holds the first usable unit of each page
                heads = []
                for pg in range(lo, hi + 1):
                    h = con.execute(head_sql, (pg, t_min, 1)).fetchone()
                    if h:
                        heapq.heappush(heads, (h, pg))
                while heads and len(taken) < need:
                    h, pg = heapq.heappop(heads)
                    taken.append(h)
                    con.execute("DELETE FROM w.unit WHERE seq=?", (h[1],))
                    nxt = con.execute(head_sql, (pg, t_min, 1)).fetchone()
                    if nxt:
                        heapq.heappush(heads, (nxt, pg))
            if taken:
                if lo == hi:
                    con.executemany("DELETE FROM w.unit WHERE seq=?", [(u[1],) for u in taken])
                used += len(taken)
                first_t = last_t = None
                for t, _seq, level, rowid in taken:
                    (lnk_sink if level == "link" else spl_sink).add((rowid, "nvme_transaction", nrow, "member"))
                    first_t = t if first_t is None else min(first_t, t)
                    last_t = t if last_t is None else max(last_t, t)
                dur_ntx.add((nrow, last_t - first_t))
            if len(taken) < need:
                short += 1
        self._flush()
        con.execute("DROP TABLE w.unit")
        con.commit()
        self.report["steps"]["units_to_ntx"] = {
            "units": n_units, "ntx_rows": n_ntx, "ntx_without_address": empty,
            "ntx_with_fewer_units_than_counted": short, "units_assigned": used,
            "seconds": round(time.time() - t0, 2)}

    # ------------------------------------------------------------------ 4 NVMe transactions -> commands
    def ntx_to_cmds(self):
        t0 = time.time()
        con = self.con
        ntx_sink = self.sink["ntx"]
        # the command queue on disk: rowid order is file order; opened / attached / completion time / slot per row
        con.execute("CREATE TABLE w.cmdq (rowid INTEGER PRIMARY KEY, sqid INTEGER, cqid INTEGER, cid INTEGER, need INTEGER, "
                    "t INTEGER, attached INTEGER, cqe_t INTEGER, opened INTEGER, slot INTEGER)")
        con.execute("INSERT INTO w.cmdq SELECT rowid_file, sqid, COALESCE(cqid, sqid), cid, CASE WHEN n_ntx IS NULL OR n_ntx = 0 THEN 1 ELSE n_ntx END, t_ps, 0, NULL, 0, NULL "
                    "FROM cmd ORDER BY rowid_file")
        con.execute("CREATE INDEX w.ix_cmdq_t ON cmdq (sqid, t, rowid)")
        con.commit()
        # completion queue bases and sizes: Create I/O CQ commands (PRP1 = base, QID, QSIZE); the admin queue's
        # base is the address of its first completion entry (slot 0) when no register value is available
        # A queue can be deleted and created again (after a reset, or by the test that recorded the trace), each time at
        # a new address: the base in force is the one of the latest Create I/O CQ before the row being placed, never
        # one base for the whole recording (found by the Code tester on 2026-11-08: with the last base used everywhere the
        # slot of every completion entry was wrong and the head doorbells drifted to older commands).
        cq_base, cq_size = {}, {}
        creates = deque((t, qid, qsize, prp1) for t, qid, qsize, prp1 in con.execute(
            "SELECT t_ps, qid, qsize, prp1 FROM cmd WHERE sqid = 0 AND opc = 5 AND qid IS NOT NULL AND prp1 IS NOT NULL AND t_ps IS NOT NULL ORDER BY t_ps, rowid_file"))
        # a part of a recording (a test window) may start after its queues were created: the queues in force are then
        # given in meta 'cq_context' as [t, qid, qsize, base] and come first
        for t, qid, qsize, prp1 in reversed(sorted(L.get_meta(con, "cq_context", []) or [])):
            creates.appendleft((t, qid, qsize, prp1))
        next_row = con.execute("SELECT COALESCE(MIN(rowid), 1) FROM w.cmdq").fetchone()[0]
        open_ = {}                    # (sqid, cid) -> command rowid, while fewer than Metrics.# NVME Trans are attached
        pending_cq = defaultdict(deque)   # cqid -> command rowids whose completion entry was written, doorbell not yet rung
        last_cqe = None
        last_cqe_irq = False          # the command of the last completion entry already has its interrupt
        n_rows = 0
        orphan = 0
        matched = 0
        by_t_sql = "SELECT rowid, sqid, cid FROM w.cmdq WHERE sqid IS ? AND t IS ? AND opened=0 ORDER BY rowid LIMIT 1"
        next_sql = ("SELECT rowid, sqid, cid FROM w.cmdq WHERE rowid >= ? AND rowid < ? AND opened=0 AND sqid IS ? "
                    "AND (? IS NULL OR cid IS ?) AND (? IS NULL OR t IS NULL OR t <= ?) ORDER BY rowid LIMIT 1")

        def mark_open(row):
            nonlocal next_row
            con.execute("UPDATE w.cmdq SET opened=1 WHERE rowid=?", (row[0],))
            open_[(row[1], row[2])] = row[0]
            if row[0] == next_row:
                r = con.execute("SELECT MIN(rowid) FROM w.cmdq WHERE rowid > ? AND opened=0", (row[0],)).fetchone()[0]
                next_row = r if r is not None else row[0] + 1

        def open_next(sqid, cid, t):
            row = con.execute(next_sql, (next_row, next_row + self.settings["look_cmds"], sqid, cid, cid, t, t)).fetchone()
            if row is None:
                return None
            mark_open(row)
            return row[0]

        def attach(crow, ntx_rowid, is_entry=False):
            r = con.execute("UPDATE w.cmdq SET attached = attached + 1 WHERE rowid=? RETURNING attached, need, sqid, cid, cqid, cqe_t", (crow,)).fetchone()
            ntx_sink.add((ntx_rowid, "nvme_command", crow, "member"))
            # a command stays open until it has its completion entry, whatever the count says: a late entry must find its command
            # (a command that never gets one is replaced here when its queue and number are used again: mark_open)
            if r[0] >= r[1] and (is_entry or r[5] is not None) and open_.get((r[2], r[3])) == crow:
                open_.pop((r[2], r[3]), None)
            return r[4]

        for nrow, typ, qid, sqid, cid, t_ps, db_index, addr in con.execute(
                "SELECT rowid_file, type, qid, sqid, cid, t_ps, db_index, addr FROM ntx ORDER BY rowid_file"):
            while creates and t_ps is not None and creates[0][0] <= t_ps:
                _t, cq_q, cq_n, cq_p = creates.popleft()
                cq_base[cq_q], cq_size[cq_q] = cq_p, cq_n
                pending_cq.pop(cq_q, None)      # a new queue: what waited on the old one will never be rung for
            n_rows += 1
            if n_rows % PROGRESS_EVERY == 0:
                self.progress("tree: NVMe transactions to commands", "{:,} transactions".format(n_rows))
            part = N.part_key(typ)
            crow = None
            if part == "dbl":
                tl = (typ or "").lower()
                is_cq = "completion" in tl or "cq" in tl.replace("sq", "") and "head" in tl
                if is_cq:
                    q = pending_cq.get(qid)
                    if q:
                        # the doorbell value is the new head: the entry it consumed last sits in slot value-1
                        want = None
                        if db_index is not None and qid in cq_base:
                            size = cq_size.get(qid)
                            want = (db_index - 1) % size if size else db_index - 1
                        hit = None
                        if want is not None:
                            for k, j in enumerate(q):
                                slot = con.execute("SELECT slot FROM w.cmdq WHERE rowid=?", (j,)).fetchone()[0]
                                if slot == want:
                                    hit = k
                                    break
                        if hit is None:
                            crow = q.popleft()
                        else:
                            crow = q[hit]
                            del q[hit]
                else:
                    # the submission doorbell opens the command with the same time stamp on that queue
                    row = con.execute(by_t_sql, (qid, t_ps)).fetchone()
                    if row is not None:
                        mark_open(row)
                        crow = row[0]
                    if crow is None:
                        crow = open_next(qid, None, t_ps)
            elif sqid is not None and cid is not None:
                crow = open_.get((sqid, cid))
                if crow is None:
                    crow = open_next(sqid, cid, t_ps)
            elif part == "irq":
                # an interrupt announces the completion entry written before it: one interrupt per entry. A second
                # interrupt with no new entry belongs to no command (it is left outside, where it is reported) instead of
                # being counted inside the last command (found on the 4.3 GB set, 2026-11-08)
                crow = last_cqe if not last_cqe_irq else None
            if crow is None:
                orphan += 1
                ntx_sink.add((nrow, "nvme_command", None, "orphan"))
                continue
            matched += 1
            cq = attach(crow, nrow, part == "cqe")
            if part == "cqe":
                if addr is not None:
                    if cq not in cq_base:
                        cq_base[cq] = addr          # first completion entry of this queue = slot 0
                    # the command ends at its FIRST completion entry; a second one for it is a fault of its own (2026-11-09)
                    con.execute("UPDATE w.cmdq SET cqe_t=COALESCE(cqe_t, ?), slot=? WHERE rowid=?", (t_ps, (addr - cq_base[cq]) // 16, crow))
                else:
                    con.execute("UPDATE w.cmdq SET cqe_t=COALESCE(cqe_t, ?) WHERE rowid=?", (t_ps, crow))
                pending_cq[cq].append(crow)
                last_cqe = crow
                last_cqe_irq = False
            elif part == "irq":
                last_cqe_irq = True
        self._flush()
        con.execute("INSERT INTO w.cmd_dur SELECT rowid, cqe_t - t FROM w.cmdq WHERE cqe_t IS NOT NULL AND t IS NOT NULL")
        n_cmds, opened, fewer = con.execute("SELECT COUNT(*), SUM(opened), SUM(attached < need) FROM w.cmdq").fetchone()
        con.execute("DROP TABLE w.cmdq")
        con.commit()
        self.report["steps"]["ntx_to_cmds"] = {
            "ntx_rows": n_rows, "ntx_matched": matched, "ntx_outside_any_command": orphan, "command_rows": n_cmds,
            "commands_opened": opened or 0, "commands_with_fewer_transactions_than_counted": fewer or 0,
            "seconds": round(time.time() - t0, 2)}

    # ------------------------------------------------------------------ 5 context packets -> command windows
    def context_to_commands(self):
        t0 = time.time()
        con = self.con
        # command windows: first and last packet time reached through the chain packet -> link -> (split ->) NVMe
        # transaction -> command, computed in SQL over the scratch tables (no row of the big tables is loaded)
        con.execute("CREATE TABLE w.chain (lnk INTEGER PRIMARY KEY, cmd INTEGER)")
        con.execute("""INSERT OR REPLACE INTO w.chain
                       SELECT l.rowid, n.par FROM w.lnk_parent l JOIN w.ntx_parent n ON n.rowid = l.par
                       WHERE l.lvl = 'nvme_transaction' AND l.par IS NOT NULL AND n.par IS NOT NULL""")
        con.execute("""INSERT OR REPLACE INTO w.chain
                       SELECT l.rowid, n.par FROM w.lnk_parent l JOIN w.spl_parent s ON s.rowid = l.par
                       JOIN w.ntx_parent n ON n.rowid = s.par
                       WHERE l.lvl = 'split' AND l.par IS NOT NULL AND s.par IS NOT NULL AND n.par IS NOT NULL""")
        con.execute("CREATE TABLE w.win (cmd INTEGER PRIMARY KEY, t0 INTEGER, t1 INTEGER)")
        con.execute("""INSERT INTO w.win SELECT c.cmd, MIN(p.t), MAX(p.t) FROM w.pkt_parent p JOIN w.chain c ON c.lnk = p.par
                       WHERE p.lvl = 'link' AND p.par IS NOT NULL AND p.t IS NOT NULL GROUP BY c.cmd""")
        # the context packets in time order (ties in row order), and where each one lands
        con.execute("CREATE TABLE w.ctx (rowid INTEGER PRIMARY KEY, t INTEGER)")
        con.execute("INSERT INTO w.ctx SELECT rowid, t FROM w.pkt_parent WHERE rel = 'context' AND t IS NOT NULL")
        con.commit()
        n_win = con.execute("SELECT COUNT(*) FROM w.win").fetchone()[0]
        n_ctx = con.execute("SELECT COUNT(*) FROM w.ctx").fetchone()[0]
        out = Sink(con, "UPDATE w.pkt_parent SET lvl = 'nvme_command', par = ? WHERE rowid = ?")
        # sweep: windows enter the heap as their start passes; the heap top is the latest-started window; a window
        # whose end has passed is popped when it reaches the top (an ended window below the top can never be the
        # innermost one, so the top is always the innermost active window = the one the packet joins)
        starts = con.execute("SELECT t0, t1, cmd FROM w.win ORDER BY t0, t1, cmd")
        nxt = starts.fetchone()
        active = []     # heap of (-start, end, cmd)
        attached = 0
        n = 0
        for pk, t in con.execute("SELECT rowid, t FROM w.ctx ORDER BY t, rowid"):
            n += 1
            if n % PROGRESS_EVERY == 0:
                self.progress("tree: context rows to command windows", "{:,} context packets".format(n))
            while nxt is not None and nxt[0] <= t:
                heapq.heappush(active, (-nxt[0], nxt[1], nxt[2]))
                nxt = starts.fetchone()
            while active and active[0][1] < t:
                heapq.heappop(active)
            if active:
                out.add((active[0][2], pk))
                attached += 1
        out.flush()
        starts.close()
        for t in ("chain", "ctx"):
            con.execute("DROP TABLE w.%s" % t)
        con.commit()
        self.report["steps"]["context_to_commands"] = {"context_packets": n_ctx, "attached_to_a_command_window": attached,
                                                      "command_windows": n_win, "seconds": round(time.time() - t0, 2)}

    # ------------------------------------------------------------------ write back
    def _chunks(self, table):
        hi = self.con.execute("SELECT COALESCE(MAX(rowid_file), 0) FROM %s" % table).fetchone()[0]
        return [(lo, min(lo + CHUNK - 1, hi)) for lo in range(1, hi + 1, CHUNK)]

    def _write_parents(self, table, label):
        """Copy w.<table>_parent into the staging table, CHUNK rowids per transaction."""
        con = self.con
        if self.rebuild:    # a previous build wrote into this table: clear it (a fresh load is all NULL already)
            con.execute("UPDATE %s SET parent=NULL, parent_level=NULL, relation=NULL WHERE parent IS NOT NULL OR parent_level IS NOT NULL OR relation IS NOT NULL" % table)
            con.commit()
        done = 0
        for lo, hi in self._chunks(table):
            con.execute("UPDATE %s SET parent=p.par, parent_level=p.lvl, relation=p.rel FROM w.%s_parent p "
                        "WHERE p.rowid = %s.rowid_file AND %s.rowid_file BETWEEN ? AND ?" % (table, table, table, table), (lo, hi))
            if table != "pkt":
                con.execute("UPDATE %s SET relation='orphan' WHERE parent IS NULL AND rowid_file BETWEEN ? AND ? AND relation IS NOT 'orphan'" % table, (lo, hi))
            con.commit()
            done += hi - lo + 1
            if done % PROGRESS_EVERY < CHUNK:
                self.progress("tree: writing the %s links" % label, "{:,} rows".format(min(done, hi)))

    def _write_durations(self, table):
        con = self.con
        if con.execute("SELECT COUNT(*) FROM w.%s_dur" % table).fetchone()[0] == 0:
            return
        for lo, hi in self._chunks(table):
            con.execute("UPDATE %s SET dur_ps=d.dur FROM w.%s_dur d WHERE d.rowid = %s.rowid_file AND %s.rowid_file BETWEEN ? AND ?"
                        % (table, table, table, table), (lo, hi))
            con.commit()

    def write(self):
        t0 = time.time()
        con = self.con
        self._flush()
        for table, label in (("pkt", "packet"), ("lnk", "link transaction"), ("spl", "split transaction"), ("ntx", "NVMe transaction")):
            if table in self.tables:
                self._write_parents(table, label)
        for table in ("lnk", "spl", "ntx", "cmd"):
            if table in self.tables:
                self._write_durations(table)
        L.checkpoint(con)
        self.report["steps"]["write"] = {"seconds": round(time.time() - t0, 2)}

    def checks(self):
        """Counts the analyzer wrote against what the tree holds."""
        con = self.con
        out = {}
        step = "tree: checking the analyzer's counts"
        self.progress(step, "0 of 7 checks")
        if "link" in self.levels and "packets" in self.levels:
            self.progress(step, "1 of 7 checks")
            r = con.execute("SELECT COUNT(*) FROM lnk l WHERE n_packets != (SELECT COUNT(*) FROM pkt p WHERE p.parent_level='link' AND p.parent=l.rowid_file)").fetchone()[0]
            out["link_rows_whose_packet_count_differs"] = r
        if "split" in self.levels and "link" in self.levels:
            self.progress(step, "2 of 7 checks")
            r = con.execute("SELECT COUNT(*) FROM spl s WHERE n_links != (SELECT COUNT(*) FROM lnk l WHERE l.parent_level='split' AND l.parent=s.rowid_file)").fetchone()[0]
            out["split_rows_whose_link_count_differs"] = r
        if "nvme_transaction" in self.levels:
            self.progress(step, "3 of 7 checks")
            kids = " + ".join("(SELECT COUNT(*) FROM %s x WHERE x.parent_level='nvme_transaction' AND x.parent=n.rowid_file)" % t for t in ("lnk", "spl") if t in self.tables) or "0"
            r = con.execute("SELECT COUNT(*) FROM ntx n WHERE n_links_splits != (%s)" % kids).fetchone()[0]
            out["ntx_rows_whose_unit_count_differs"] = r
        if "nvme_command" in self.levels and "nvme_transaction" in self.levels:
            self.progress(step, "4 of 7 checks")
            r = con.execute("SELECT COUNT(*) FROM cmd c WHERE n_ntx != (SELECT COUNT(*) FROM ntx n WHERE n.parent_level='nvme_command' AND n.parent=c.rowid_file)").fetchone()[0]
            out["command_rows_whose_transaction_count_differs"] = r
        for t, name in (("lnk", "link"), ("spl", "split"), ("ntx", "nvme_transaction")):
            if name in self.levels:
                out["%s_outside_any_parent" % name] = con.execute("SELECT COUNT(*) FROM %s WHERE relation='orphan'" % t).fetchone()[0]
        self.report["checks"] = out


def build(db_path, progress=None, settings=None):
    """Run every join the present levels allow, write the links back, return the report (also stored in meta)."""
    con = L.open_db(db_path)
    L.attach_work(con, db_path)
    try:
        b = Build(con, progress, settings)
        lv = set(b.levels)
        t0 = time.time()
        end_beat = L.heartbeat(con, b.beat)
        try:
            if {"packets", "link"} <= lv:
                b.progress("tree: packets to link transactions", "")
                b.packets_to_links()
            if {"link", "split"} <= lv:
                b.progress("tree: link to split transactions", "")
                b.links_to_splits()
            if {"nvme_transaction"} <= lv and ("link" in lv or "split" in lv):
                b.progress("tree: units to NVMe transactions", "")
                b.units_to_ntx()
            if {"nvme_transaction", "nvme_command"} <= lv:
                b.progress("tree: NVMe transactions to commands", "")
                b.ntx_to_cmds()
            if {"packets", "link", "nvme_transaction", "nvme_command"} <= lv:
                b.progress("tree: context rows to command windows", "")
                b.context_to_commands()
            b.write()
            b.checks()
        finally:
            end_beat()
        b.report_to("tree: finished", "", 100.0)
        b.report["seconds"] = round(time.time() - t0, 2)
        b.report["levels"] = b.levels
        con.execute("INSERT OR REPLACE INTO meta (k, v) VALUES ('build', ?)", (json.dumps(b.report),))
        con.commit()
    finally:
        L.drop_work(con, db_path)
        L.checkpoint(con)
        con.close()
    return b.report
