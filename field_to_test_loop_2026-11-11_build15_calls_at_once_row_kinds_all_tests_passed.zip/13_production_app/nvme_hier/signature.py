"""The signature of a finding: a key computed the same way every time from the finding alone.

Design: research note 05_signature_and_signals.md (Sentry / Socorro / WER grouping principles, RFC 8785 canonical
JSON). Ten fields in a fixed order; nothing that varies between recordings (time stamps, packet numbers, addresses,
tags, CIDs, measured values) enters the key. Two tiers: the FINE key (all ten fields) is the key for exact reuse of
a stored procedure; the COARSE key (without device, firmware and the DNR bit) groups "the same kind of defect seen on
another device". The algorithm version is part of the hashed object, so a change of the method never silently
merges or splits history.

    sig = compute(dict(dev=..., fw=..., lvl="spl", err="spl.latency_over_limit", cmd="io.Write", part="data",
                       cause="lnk.replay", st="sct0.sc04", dnr="0"))
    sig["fine"], sig["coarse"], sig["display"]
"""
import hashlib
import json
import re

ALG = "v1"
LEVEL_KEY = {"packets": "pkt", "link": "lnk", "split": "spl", "nvme_transaction": "ntx", "nvme_command": "cmd"}
FIELDS = ("alg", "dev", "fw", "lvl", "err", "cmd", "part", "cause", "st", "dnr")
COARSE_DROP = ("dev", "fw", "dnr")
PARTS = ("entry", "prp", "data", "cqe", "irq", "dbl", "reg", "none")
CAUSE_PREFIX = ("pkt.", "lnk.", "spl.", "ntx.", "cmd.")


def _norm_text(s):
    s = re.sub(r"\s+", " ", str(s if s is not None else "").strip()).upper()
    return s or "UNKNOWN"


def cmd_key(opcode_name, sqid):
    """'io.Write' / 'admin.Identify' / 'none'. Vendor opcodes: 'io.vendor_0xC1'."""
    if opcode_name is None:
        return "none"
    name = re.sub(r"\s*\(admin\)\s*$", "", opcode_name).strip()
    m = re.match(r"^opcode 0x([0-9A-Fa-f]{2})$", name)
    if m:
        name = "vendor_0x" + m.group(1).upper()
    else:
        name = re.sub(r"[^A-Za-z0-9]+", "", name)
    return ("admin." if sqid == 0 else "io.") + name


def status_key(sct, sc):
    if sct is None or sc is None:
        return "none"
    return "sct%d.sc%02x" % (int(sct), int(sc))


def canonical(fields):
    """Canonical JSON: sorted keys, no spaces, ASCII only (RFC 8785-equivalent for these strings)."""
    return json.dumps(fields, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def compute(f):
    """f: dict with dev, fw, lvl, err, cmd, part, cause, st, dnr (strings; missing -> normalised defaults).
    Returns {"fine": sha256 hex, "coarse": sha256 hex, "display": string, "fields": the canonical fields}."""
    fields = {
        "alg": ALG,
        "dev": _norm_text(f.get("dev")),
        "fw": _norm_text(f.get("fw")),
        "lvl": LEVEL_KEY.get(f.get("lvl"), f.get("lvl") or "cmd"),
        "err": (f.get("err") or "unknown").strip().lower(),
        "cmd": f.get("cmd") or "none",
        "part": f.get("part") if f.get("part") in PARTS else "none",
        "cause": str(f.get("cause") or "self"),
        "st": f.get("st") or "none",
        "dnr": str(f.get("dnr")) if f.get("dnr") in (0, 1, "0", "1") else "-",
    }
    if not (fields["cause"] == "self" or fields["cause"].startswith(CAUSE_PREFIX)):
        fields["cause"] = "self"
    fine = hashlib.sha256(canonical(fields).encode()).hexdigest()
    coarse_fields = {k: v for k, v in fields.items() if k not in COARSE_DROP}
    coarse = hashlib.sha256(canonical(coarse_fields).encode()).hexdigest()
    display = "|".join("%s:%s" % (k, fields[k]) if k not in ("alg",) else fields[k] for k in FIELDS)
    return {"fine": fine, "coarse": coarse, "display": display, "fields": fields}


def from_finding(finding, dev=None, fw=None):
    """Build the signature from a finding record as the rules module writes it:
    {level, rule, opcode_name, sqid, part, cause, sct, sc, dnr}."""
    return compute({
        "dev": dev or finding.get("device"), "fw": fw or finding.get("firmware"),
        "lvl": finding.get("level"), "err": finding.get("rule"),
        "cmd": cmd_key(finding.get("opcode_name"), finding.get("sqid")) if finding.get("opcode_name") else "none",
        "part": finding.get("part") or "none", "cause": finding.get("cause") or "self",
        "st": status_key(finding.get("sct"), finding.get("sc")), "dnr": finding.get("dnr"),
    })
