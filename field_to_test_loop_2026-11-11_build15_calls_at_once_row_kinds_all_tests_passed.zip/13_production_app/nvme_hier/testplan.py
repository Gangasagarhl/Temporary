"""The regression test of one defect as a PLAN (data) and the file that runs it (owner, 2026-11-10: "generate the test case ... verified by
the admin ... regenerate the environment"; research report 'Defect replay tests and deallocate checks').

  build_plan   the sequence of stage 1 (with the commands from earlier in the recording it depends on), the outcomes the admin verified in
               stage 2, and the recording's environment (model, LBA size, deallocate read behaviour) -> PLAN
  check_plan   the code's checks before anyone reads it: shape, every step one of the window's commands with its own parameters, numbers in
               range, an oracle that can fail (not only "it returned 0")
  render       the test file: a header in the UNH-IOL test layout (Purpose, References, Resource Requirements, Last Modification, Discussion,
               Test Setup, Procedure, Observable Results, Possible Problems), the PLAN as a Python literal, and test functions that call the
               fixed library nvme_hier/regress/f2t_nvme.py (copied beside the file)
  two_sided    the file run on the simulated drive four ways: with the recorded fault (EXPECT=fault must pass, EXPECT=fixed must fail) and
               without it (EXPECT=fixed must pass, EXPECT=fault must fail). Passing means "mechanics checked on a simulated drive", never
               "fault reproduced": that needs the real drive with the faulty firmware.
"""
import hashlib
import json
import os
import pprint
import re
import shutil
import subprocess
import sys
import tempfile
import time

from . import names as N

HERE = os.path.dirname(os.path.abspath(__file__))
LIBRARY = os.path.join(HERE, "regress", "f2t_nvme.py")
PLAN_VERSION = 1
ALLOWED_OPS = {("io", 0x00), ("io", 0x01), ("io", 0x02), ("io", 0x04), ("io", 0x08), ("io", 0x09), ("io", 0x0C),
               ("admin", 0x02), ("admin", 0x06), ("admin", 0x08), ("admin", 0x09), ("admin", 0x0A), ("admin", 0x18),
               ("admin", 0x00), ("admin", 0x01), ("admin", 0x04), ("admin", 0x05), ("admin", 0x0C), ("admin", 0x10), ("admin", 0x11), ("admin", 0x80), ("admin", 0x84),
               ("admin", 0x0D), ("admin", 0x15)}
MAX_LBA = 1 << 48
MAX_NLB = 65535


def library_sha():
    with open(LIBRARY, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()[:16]


def _int(v):
    try:
        return int(str(v), 0) if isinstance(v, str) else (int(v) if v is not None else None)
    except (TypeError, ValueError):
        return None


def fmt_us(us):
    """A time in plain units: 421.788 us, 30 s, 1.5 ms."""
    us = float(us or 0)
    if us >= 10 ** 6:
        return ("%.3f" % (us / 10 ** 6)).rstrip("0").rstrip(".") + " s"
    if us >= 1000:
        return ("%.3f" % (us / 1000)).rstrip("0").rstrip(".") + " ms"
    return ("%.3f" % us).rstrip("0").rstrip(".") + " us"


DRIVER_OWNED = {0x07: "Number of Queues", 0x0C: "Autonomous Power State Transition", 0x0D: "Host Memory Buffer", 0x0F: "Keep Alive Timer", 0x16: "Host Behavior Support"}
NOT_SENT = {0x00: "the driver's (queues)", 0x01: "the driver's (queues)", 0x04: "the driver's (queues)", 0x05: "the driver's (queues)", 0x0C: "waits for events by design",
            0x10: "changes the drive for good", 0x11: "changes the drive for good", 0x80: "changes the drive for good", 0x84: "changes the drive for good",
            0x0D: "changes the drive for good", 0x15: "changes the drive for good", 0x08: "names a command id the kernel chose in the field"}


def send_note(step):
    """Whether the library sends this step, in words (the same rules as f2t_nvme.send_step)."""
    p = step.get("parameters") or {}
    if step.get("admin"):
        opc = step.get("opc")
        if opc in NOT_SENT:
            return "not sent: %s" % NOT_SENT[opc]
        if opc == 0x09:
            fid = p.get("fid")
            if fid in DRIVER_OWNED:
                return "compared, not sent: %s is the Linux driver's" % DRIVER_OWNED[fid]
            if p.get("value") is None:
                return "not sent: the export does not carry the value"
        if opc not in (0x02, 0x06, 0x09, 0x0A, 0x18):
            return "not sent: not replayable from a host"
    elif step.get("opc") not in (0x00, 0x01, 0x02, 0x04, 0x08, 0x09, 0x0C):
        return "not sent: not replayable from a host"
    return ""


# ---------------------------------------------------------------------------------------------- the oracle of each detector rule
def oracle_of(finding, limit_us):
    """What 'the fault appears again' means for the rule that found it. A rule at the packet or link level is not reproducible from a host."""
    rule = finding.get("rule") or ""
    det = finding.get("detail") or {}
    if rule.startswith(("pkt.", "lnk.")):
        return {"kind": "link_level", "rule": rule, "words": "a PCIe link-level event (%s): a host cannot send it; the analyzer's exerciser can" % rule}
    if rule in ("cmd.status_error", "cmd.read_failure"):
        sct, sc = _int(det.get("SCT")), _int(det.get("SC"))
        return {"kind": "status", "rule": rule, "sct": sct, "sc": sc,
                "words": ("the command completes with status type %s code 0x%02X, as recorded" % (sct, sc)) if sct is not None and sc is not None else "the command completes with an error status, as recorded"}
    if rule == "cmd.timeout":
        # the rule's own kind decides what a lab host can see again (nvme_hier/rules.py command_timeout)
        kind = det.get("kind")
        host_us = int((det.get("host_limit_ps") or finding.get("limit_ps") or limit_us * 10 ** 6) // 10 ** 6)
        bar_us = round(det["usual_bar_ps"] / 10 ** 6, 3) if det.get("usual_bar_ps") else None          # microseconds, kept to the nanosecond
        took_us = round(finding["value_ps"] / 10 ** 6, 3) if finding.get("value_ps") else None
        if kind in ("never completed", "over the host's limit") or (kind not in ("aborted by the host", "slower than usual")):
            return {"kind": "timeout", "rule": rule, "limit_us": host_us, "field_kind": kind,
                    "words": "the command does not complete within %s, the host's limit (%s in the recording)" % (fmt_us(host_us), kind or "timeout")}
        limit = bar_us or took_us or host_us
        field = ("; in the field the host aborted it after %s" % fmt_us(took_us)) if kind == "aborted by the host" and took_us else ""
        return {"kind": "latency", "rule": rule, "limit_us": max(0.001, limit), "field_kind": kind,
                "words": "the command takes %s or more, the recording's bar for this command type and size%s (measured around the passthrough call, which adds the host's own few tens of microseconds)" % (fmt_us(limit), field)}
    if rule in ("cmd.incomplete", "cmd.not_fetched"):
        return {"kind": "timeout", "rule": rule, "limit_us": int(limit_us), "words": "the command does not complete within %s (the host gives up on it)" % fmt_us(limit_us)}
    if rule in ("cmd.latency_over_limit", "spl.latency_over_limit", "ntx.over_limit", "spl.incomplete"):
        return {"kind": "latency", "rule": rule, "limit_us": int(limit_us),
                "words": "the command takes %s or more%s" % (fmt_us(limit_us), "" if rule.startswith("cmd.") else " (measured for the whole command: a host cannot time the transaction inside it)")}
    if rule in ("cmd.deallocate_readback", "cmd.write_zeroes_readback"):
        return {"kind": "deallocate_readback", "rule": rule, "words": "a read of the deallocated blocks returns data other than the value the drive declares (DLFEAT)"}
    if rule == "cmd.bytes_short":
        return {"kind": "bytes_short", "rule": rule, "words": "the read moves fewer bytes than it asked for"}
    return {"kind": "any_error", "rule": rule, "words": "the command does not complete successfully"}


# ---------------------------------------------------------------------------------------------- the plan
def recorded_environment(cmd_rows, device, firmware):
    """What the recording itself says about the drive: model (the export's MN), firmware, LBA size from a data command, DLFEAT, namespace."""
    model = next(((r.get("raw") or {}).get("MN") for r in cmd_rows if (r.get("raw") or {}).get("MN")), None) or None
    lba_bytes = None
    for r in cmd_rows:
        if r.get("sqid") and r.get("opc") in (0x01, 0x02) and r.get("nbytes") and r.get("nlb") is not None:
            lb = int(r["nbytes"]) // (int(r["nlb"]) + 1)
            if lb in (512, 1024, 2048, 4096, 8192, 16384):
                lba_bytes = lb
                break
    dlfeat = next((r.get("dlfeat") for r in cmd_rows if r.get("dlfeat") is not None), None)
    nsid = next((r.get("nsid") for r in cmd_rows if r.get("sqid") and r.get("nsid")), 1)
    return {"device": device, "model": model, "firmware": firmware if firmware and firmware != "unknown" else None, "lba_bytes": lba_bytes,
            "dlfeat": dlfeat, "drb": (int(dlfeat) & 7) if dlfeat is not None else None, "nsid": nsid}


def _features(cmd_rows):
    out = []
    for r in cmd_rows:
        if r.get("sqid") == 0 and r.get("opc") == 0x09 and r.get("fid") is not None:
            raw = r.get("raw") or {}
            value = _int(raw.get("DW11") or raw.get("CDW11") or raw.get("Value"))
            out.append({"fid": int(r["fid"]), "name": N.opcode_name(0x09, 0) + " " + str(r["fid"]), "value": value, "sv": bool(_int(raw.get("SV")) or 0),
                        "source_row": r.get("rowid_file")})
    last = {}
    for f in out:
        last[f["fid"]] = f
    return list(last.values())


def build_plan(finding, steps, signature, scenario, upload_id, version, device, firmware, limit_us, expected, cmd_rows, verified_by, test_id,
               deallocate_range=None, known_rate=None, author="code"):
    """PLAN of the test. steps: the stage-1 sequence (OPT.step_of shape); expected: the outcomes the admin verified (normalised);
    cmd_rows: the raw command rows of the steps (for the recorded environment and feature values)."""
    fault_step = next((s["step"] for s in steps if s.get("position") == "fault"), len(steps))
    oracle = oracle_of(finding, limit_us)
    env = recorded_environment(cmd_rows, device, firmware)
    by_row = {r.get("rowid_file"): r for r in cmd_rows}
    reads = []
    for s in steps:
        p = s.get("parameters") or {}
        if not s.get("admin") and s.get("opc") in (0x02, 0x05, 0x0C) and p.get("slba") is not None:
            reads.append({"nsid": p.get("nsid") or env["nsid"], "slba": int(p["slba"]), "nlb": int(p.get("nlb") or 0),
                          "why": "step %d reads these blocks: they are written with a known pattern first, since the recording does not carry the drive's data" % s["step"]})
    plan_steps = []
    for s in steps:
        p = dict(s.get("parameters") or {})
        raw = (by_row.get(s.get("source_row")) or {}).get("raw") or {}
        for k, col in (("lr", "LR"), ("prinfo", "PRINFO"), ("cns", "CNS"), ("fid", "FID"), ("lid", "LID"), ("sv", "SV")):
            if p.get(k) is None and raw.get(col) not in (None, ""):
                p[k] = _int(raw.get(col))
        if s.get("opc") == 0x09 and s.get("admin"):
            p["value"] = _int(raw.get("DW11") or raw.get("CDW11") or raw.get("Value"))
        plan_steps.append({"step": s["step"], "command": s.get("command"), "opc": s.get("opc"), "admin": bool(s.get("admin")), "queue": s.get("queue"),
                           "parameters": p, "gap_us": int(s.get("gap_us") or 10), "position": s.get("position"), "source_row": s.get("source_row"),
                           "why": s.get("why") or [], "must_succeed": s.get("position") != "fault"})
    return {
        "id": test_id, "version": version, "plan_version": PLAN_VERSION, "author": author, "library": library_sha(),
        "signature": signature.get("display") if isinstance(signature, dict) else str(signature), "rule": finding.get("rule"), "level": finding.get("level"),
        "scenario": scenario or "(not named)", "upload": upload_id, "finding": finding.get("id"), "observed": finding.get("observed_outcome") or finding.get("name"),
        "recorded": env, "lba_offset": 0,
        "setup": {"features": _features(cmd_rows), "prewrite": reads, "deallocated": []},
        "steps": plan_steps, "fault_step": fault_step, "oracle_fault": oracle, "expected": expected or [],
        "limits": {"io_ms": max(1000, int(limit_us // 1000) + 5000) if oracle["kind"] in ("timeout", "latency") else 30000, "admin_ms": 60000},
        "repeat": {"fault_runs": 10, "fixed_runs_unmeasured": 30, "known": known_rate},
        "deallocate_range": deallocate_range, "verified_by": verified_by, "generated": time.strftime("%Y-%m-%d %H:%M:%S"),
    }


def check_plan(plan, window_rowids=None):
    """Problems of a plan in words (empty = it passes). window_rowids: the command rows of the stage-1 window (every step must be one of them)."""
    probs = []
    for k in ("id", "steps", "fault_step", "oracle_fault", "recorded", "setup"):
        if k not in plan:
            probs.append("the plan has no %s" % k)
    if probs:
        return probs
    steps = plan["steps"]
    if not steps or not isinstance(steps, list):
        return ["the plan has no steps"]
    if [s.get("step") for s in steps] != list(range(1, len(steps) + 1)):
        probs.append("the steps are not numbered 1..%d in order" % len(steps))
    if not any(s.get("step") == plan["fault_step"] and s.get("position") == "fault" for s in steps):
        probs.append("the fault step %s is not one of the steps, or not marked as the fault" % plan["fault_step"])
    for s in steps:
        kind = ("admin" if s.get("admin") else "io", s.get("opc"))
        if kind not in ALLOWED_OPS:
            probs.append("step %s: opcode %s on the %s queue is not one the library knows" % (s.get("step"), s.get("opc"), kind[0]))
        p = s.get("parameters") or {}
        if p.get("slba") is not None and not (0 <= int(p["slba"]) < MAX_LBA):
            probs.append("step %s: starting block %s is out of range" % (s.get("step"), p["slba"]))
        if p.get("nlb") is not None and not (0 <= int(p["nlb"]) <= MAX_NLB):
            probs.append("step %s: block count %s is out of range (0..%d, zero-based)" % (s.get("step"), p["nlb"], MAX_NLB))
        for rg in p.get("ranges") or []:
            if not (isinstance(rg, (list, tuple)) and len(rg) == 2 and 0 <= int(rg[0]) < MAX_LBA and 0 <= int(rg[1]) <= 0xFFFFFFFF):
                probs.append("step %s: a deallocate range %s is not [first block, number of blocks]" % (s.get("step"), rg))
        if window_rowids is not None and s.get("source_row") not in window_rowids:
            probs.append("step %s (%s) is not a command of the window (row %s): every replayed command must come from the recording" % (s.get("step"), s.get("command"), s.get("source_row")))
        if not 0 <= int(s.get("gap_us") or 0) <= 600 * 10 ** 6:
            probs.append("step %s: the wait before it is out of range" % s.get("step"))
    o = plan["oracle_fault"]
    if o.get("kind") not in ("status", "timeout", "latency", "deallocate_readback", "bytes_short", "any_error", "link_level"):
        probs.append("the fault check '%s' is not one the library knows" % o.get("kind"))
    if o.get("kind") in ("timeout", "latency") and not (o.get("limit_us") or 0) > 0:
        probs.append("a time check needs a limit above zero")
    if o.get("kind") == "status" and (o.get("sct"), o.get("sc")) == (0, 0):
        probs.append("the fault check is 'successful completion': it cannot fail, so it proves nothing")
    for e in plan.get("expected") or []:
        if e.get("step") not in {s.get("step") for s in steps}:
            probs.append("an expected outcome names step %s, which is not in the plan" % e.get("step"))
    return probs


# ---------------------------------------------------------------------------------------------- the file
def _w(v):
    return re.sub(r"[\r\n\x00]+", " ", str(v if v is not None else "")).replace("\\", "/").replace('"' * 3, "'" * 3)


def render(plan):
    """The test file. Everything it does on a drive is in f2t_nvme.py (fixed, owned by the tool); this file is the plan and the header."""
    o, env, s = plan["oracle_fault"], plan["recorded"], plan["steps"]
    lines = ["#!/usr/bin/env python3", '"""REGRESSION TEST %s version %s (field-to-test loop; generated %s; plan written by %s; library %s)' % (
        _w(plan["id"]), plan["version"], _w(plan["generated"]), _w(plan["author"]), _w(plan["library"])), ""]
    lines += ["Purpose", "    Re-create, on a drive of the recorded kind, the defect found in upload %s (finding %s, rule %s at the %s level):" % (
        _w(plan["upload"]), plan["finding"], _w(plan["rule"]), _w(plan["level"])), "    %s." % _w(plan["observed"]),
              "    Scenario: %s. Signature: %s." % (_w(plan["scenario"]), _w(plan["signature"])), ""]
    lines += ["References", "    NVM Express Base Specification 2.1 and NVM Command Set Specification 1.1 (nvmexpress.org): the commands and status codes replayed.",
              "    Linux include/uapi/linux/nvme_ioctl.h: the passthrough ioctl that sends them.", "    The recording: upload %s, command rows %s." % (
                  _w(plan["upload"]), ", ".join(str(x.get("source_row")) for x in s if x.get("source_row"))), ""]
    lines += ["Resource Requirements", "    Linux, Python 3.8+, pytest, root (CAP_SYS_ADMIN) for the passthrough ioctls.",
              "    A drive of model %s%s with a namespace the operator dedicates to this test (it writes to the blocks below)." % (
                  _w(env.get("model") or "(not in the export: any)"), (" firmware %s" % _w(env["firmware"])) if env.get("firmware") else ""),
              "    The recorded blocks are %s bytes%s." % (_w(env.get("lba_bytes") or "of unknown size"), "; deallocated blocks read as %s" % {0: "either 00h or FFh", 1: "00h", 2: "FFh"}.get(env.get("drb"), "?") if env.get("drb") is not None else ""), ""]
    lines += ["Last Modification", "    %s, verified by %s." % (_w(plan["generated"]), _w(plan["verified_by"] or "nobody yet")), ""]
    lines += ["Discussion", "    The fault: %s." % _w(o.get("words")),
              "    What a host can and cannot re-create: the opcode, the namespace and the command's own fields are sent as recorded; the kernel",
              "    chooses the command id, the queue and the data pointers, and PCIe link events cannot be sent from a host (the analyzer's",
              "    exerciser can). A defect that shows only sometimes is replayed several times; 'fixed' needs as many clean runs as the old",
              "    firmware's reproduction rate requires (see the result file).", ""]
    lines += ["Test Setup (done by the test, in this order)", "    1. Safety gate: the drive's serial number and namespace must be in the operator's allow-list (NVME_ALLOW);",
              "       the namespace must not be mounted, held, swap or the boot disk; writing needs NVME_DESTRUCTIVE=1 and NVME_CONFIRM=ERASE-<serial>.",
              "    2. Identity: model, firmware, block size and deallocate read behaviour against the recording (a different model or block size: skipped).",
              "    3. Features from the recording: %s." % ("; ".join("%s (0x%02X) %s" % (DRIVER_OWNED.get(f["fid"], "feature"), f["fid"], "compared, not set: the Linux driver's own" if f["fid"] in DRIVER_OWNED
                                                                     else "not set: the export does not carry its value" if f.get("value") is None else "set to 0x%X and read back" % f["value"]) for f in plan["setup"]["features"]) or "none"),
              "    4. Data: the blocks the replay reads are written first with a pattern that names each block and run (%d range%s)." % (
                  len(plan["setup"]["prewrite"]), "" if len(plan["setup"]["prewrite"]) == 1 else "s"), ""]
    lines += ["Procedure"] + ["    %2d. %s%s%s%s" % (x["step"], _w(x.get("command")), " " + _w(json.dumps({k: v for k, v in (x.get("parameters") or {}).items() if v is not None}, sort_keys=True)) if x.get("parameters") else "",
                                                      "   <- THE DEFECT" if x.get("position") == "fault" else "   (after the defect)" if x.get("position") == "below" else "",
                                                      ("   [%s]" % send_note(x)) if send_note(x) else "") for x in s] + [""]
    lines += ["Observable Results", "    EXPECT=fault (default): PASS when the fault appears again: %s." % _w(o.get("words")),
              "    EXPECT=fixed: PASS only when it does not appear in the required number of clean runs, and every outcome below is met:"]
    lines += ["      step %s: %s%s%s" % (e.get("step"), _w(e.get("status") or "successful completion"), (", within %s" % fmt_us(e["timing_us"])) if e.get("timing_us") else "",
                                        ("   [%s: not checked]" % send_note(next((x for x in s if x["step"] == e.get("step")), {}))) if send_note(next((x for x in s if x["step"] == e.get("step")), {})) else "")
              for e in plan.get("expected") or []] or ["      (no further outcomes listed)"]
    lines += ["", "Possible Problems", "    A skip is not a pass: it says which precondition was not met. 'PRECONDITION NOT MET' failures are the setup, not the drive.",
              "    Relocate the blocks with NVME_LBA_OFFSET=<blocks> when the recorded ones are in use (this can hide a block-specific defect).",
              "    NVME_BACKEND=sim NVME_SIM=<json> runs it on the simulated drive: that checks the test's mechanics, never the drive.", "",
              "How to run", "    NVME_NS=/dev/ng0n1 NVME_ALLOW=allow.txt NVME_DESTRUCTIVE=1 NVME_CONFIRM=ERASE-<serial> python3 -m pytest -q --junit-xml=result.xml %s" % "<this file>",
              "    EXPECT=fixed for the regression form; EXPECT=fault NVME_MEASURE=1 on the faulty firmware measures k of n (give it back to the tool).", '"""',
              "import os", "import sys", "", "sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))", "import f2t_nvme as T  # noqa: E402  (the fixed replay library, beside this file)", "",
              "PLAN = " + pprint.pformat(plan, indent=1, width=140, sort_dicts=False), "", "",
              "def test_defect_reproduces_or_stays_fixed(record_testsuite_property):",
              '    """EXPECT=fault: the recorded defect appears again. EXPECT=fixed: it does not, and a correct drive\'s outcomes are met."""',
              "    if PLAN[\"oracle_fault\"][\"kind\"] == \"link_level\":",
              "        import pytest", "        pytest.skip(PLAN[\"oracle_fault\"][\"words\"])",
              "    T.run_case(PLAN, record=record_testsuite_property)"]
    if plan.get("deallocate_range"):
        lines += ["", "", "def test_deallocate_range(record_testsuite_property):",
                  '    """The deallocate check of blocks %s..%s (with guard bands), judged by what the specification forbids."""' % (
                      plan["deallocate_range"].get("slba"), int(plan["deallocate_range"].get("slba", 0)) + int(plan["deallocate_range"].get("blocks", 0)) - 1),
                  "    T.deallocate_check(PLAN, record=record_testsuite_property)"]
    return "\n".join(lines) + "\n"


def write(plan, folder, name):
    """The test file and the library beside it; returns the file's path."""
    os.makedirs(folder, exist_ok=True)
    lib = os.path.join(folder, "f2t_nvme.py")
    if not os.path.exists(lib) or open(lib, "rb").read() != open(LIBRARY, "rb").read():
        shutil.copyfile(LIBRARY, lib)
    path = os.path.join(folder, name)
    text = render(plan)
    compile(text, path, "exec")
    with open(path, "w") as fh:
        fh.write(text)
    return path


# ---------------------------------------------------------------------------------------------- the two-sided check on the simulated drive
def sim_fault(plan):
    """The simulated drive's fault that stands for the recorded one (None: a host cannot show it)."""
    o = plan["oracle_fault"]
    f = next(s for s in plan["steps"] if s["step"] == plan["fault_step"])
    p = f.get("parameters") or {}
    where = {"opc": f.get("opc"), "slba": p.get("slba"), "nlb": p.get("nlb") or 0}
    if o["kind"] == "status":
        return dict(where, kind="status", sct=o.get("sct") if o.get("sct") is not None else 0, sc=o.get("sc") if o.get("sc") is not None else 6)
    if o["kind"] == "timeout":
        return dict(where, kind="timeout")
    if o["kind"] == "latency":
        return dict(where, kind="latency", us=int(o["limit_us"]) * 2)
    if o["kind"] == "deallocate_readback":
        return {"kind": "stale_deallocate"}
    if o["kind"] == "bytes_short":
        return {"kind": "short_read"}
    if o["kind"] == "any_error":
        return dict(where, kind="status", sct=0, sc=6)
    return None


def two_sided(path, plan, timeout=180):
    """Run the file on the simulated drive with and without the fault, both EXPECT forms. -> {"ok", "runs": [...], "words"}."""
    fault = sim_fault(plan)
    if fault is None:
        return {"ok": True, "skipped": True, "words": "not checked on the simulated drive: %s" % plan["oracle_fault"].get("words"), "runs": []}
    env = plan["recorded"]
    top = max([int((s.get("parameters") or {}).get("slba") or 0) + int((s.get("parameters") or {}).get("nlb") or 0) for s in plan["steps"]] + [0])
    base = {"model": env.get("model") or "Simulated NVMe drive", "firmware": env.get("firmware") or "SIMFW001", "lba_bytes": env.get("lba_bytes") or 512,
            "nsze": max(1 << 20, top + 1024), "drb": env.get("drb") if env.get("drb") in (1, 2) else 1, "thinp": True, "dae": True, "nsid": env.get("nsid") or 1}
    work = tempfile.mkdtemp(prefix="f2t_twosided_")
    runs, ok = [], True
    try:
        for drive, faults in (("faulty", [fault]), ("correct", [])):
            cfg = os.path.join(work, "%s.json" % drive)
            with open(cfg, "w") as fh:
                json.dump(dict(base, faults=faults), fh)
            for expect in ("fault", "fixed"):
                want = "pass" if (drive == "faulty") == (expect == "fault") else "fail"
                e = {k: v for k, v in os.environ.items() if not k.startswith("NVME_")}
                e.update(NVME_BACKEND="sim", NVME_SIM=cfg, EXPECT=expect, NVME_REPEAT="2", NVME_RESULTS=os.path.join(work, "results"), PYTHONDONTWRITEBYTECODE="1")
                p = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "-k", "reproduces_or_stays_fixed", path], capture_output=True, text=True,
                                   timeout=timeout, cwd=work, env=e)
                last = [x for x in (p.stdout or "").strip().splitlines() if x.strip()]
                got = "pass" if p.returncode == 0 and "passed" in (last[-1] if last else "") else "skip" if "skipped" in (last[-1] if last else "") else "fail"
                good = got == want
                ok = ok and good
                runs.append({"drive": drive, "expect": expect, "wanted": want, "got": got, "ok": good, "last_line": last[-1] if last else (p.stderr or "")[-200:],
                             "why": next((x for x in last if x.startswith("E ") and "FAILED" in x), "")[:300]})
    finally:
        shutil.rmtree(work, ignore_errors=True)
    return {"ok": ok, "runs": runs, "words": ("checked on the simulated drive: it reproduces the fault where the fault is, and passes where it is not (mechanics only, not the real drive)"
                                             if ok else "the simulated-drive check failed: " + "; ".join("%s drive, EXPECT=%s: wanted %s, got %s %s" % (r["drive"], r["expect"], r["wanted"], r["got"], r["why"]) for r in runs if not r["ok"]))}


# ---------------------------------------------------------------------------------------------- the model writes the plan (owner, 2026-11-10: "use that as input to llm and llm will generate the test case")
PLAN_SCHEMA = {"type": "object", "properties": {
    "analysis": {"type": "string"},
    "replay_rows": {"type": "array", "items": {"type": "integer"}},
    "row_reasons": {"type": "array", "items": {"type": "object", "properties": {"row": {"type": "integer"}, "why": {"type": "string"}}, "required": ["row", "why"]}},
    "oracle": {"type": "object", "properties": {"kind": {"type": "string"}, "status_type": {"type": "integer"}, "status_code": {"type": "integer"}, "limit_us": {"type": "number"}},
               "required": ["kind"]},
    "deallocate_first_block": {"type": "integer"}, "deallocate_blocks": {"type": "integer"},
    "setup_note": {"type": "string"}},
    "required": ["analysis", "replay_rows", "row_reasons", "oracle", "deallocate_first_block", "deallocate_blocks", "setup_note"]}

PLAN_INSTRUCTION = """You write the plan of a regression test for ONE defect that a detection rule found in a PCIe/NVMe analyzer recording of an SSD.
The rule already proved the defect: you do not decide whether it exists. The test will replay commands on a drive of the same kind (Linux, kernel
passthrough: the opcode, namespace and command fields are sent as recorded; the kernel chooses the command id, queue and data pointers; PCIe link
events cannot be sent from a host) and check whether the defect appears again.

Your answer, as JSON:
- analysis: in plain words, which rows of the WINDOW prove the defect (cite their row numbers and what the lower levels show), what state the defect
  depends on, and which commands must be replayed to re-create it. Say plainly what a host cannot re-create.
- replay_rows: the row numbers to replay, oldest first, taken ONLY from the WINDOW table, including the defect row. Keep what sets up the state the
  defect depends on (same blocks, features, queue) and the rows after the defect that it affects; leave out independent commands. The code copies
  every parameter from the recording; you only choose rows.
- row_reasons: one short reason per chosen row.
- oracle: what shows the defect again: kind = status (with status_type and status_code), timeout (limit_us), latency (limit_us),
  deallocate_readback, bytes_short or any_error. It must match what the rule found.
- deallocate_first_block, deallocate_blocks: a block range to check deallocation on, when the defect involves deallocating or zeroing blocks; else 0, 0.
- setup_note: anything about the drive's state before the replay that the window shows (features, data written earlier, format), in one or two sentences.
Never invent rows, numbers or statuses that are not in the text below. The STORED TESTS are examples of earlier, approved choices for this kind of
defect: learn from them, never copy their rows or numbers."""


def _table(rows, cols):
    head = "| " + " | ".join(c[0] for c in cols) + " |"
    out = [head, "|" + "---|" * len(cols)]
    for r in rows:
        out.append("| " + " | ".join(str(c[1](r)).replace("|", "/").replace("\n", " ")[:160] for c in cols) + " |")
    return "\n".join(out)


def plan_prompt(defect_lines, window, outcomes, stored, sequence, problems=None):
    """The model's input: stored examples first, then the window (one table per level), the verified outcomes, the defect and the task last."""
    parts = [PLAN_INSTRUCTION, ""]
    if stored:
        parts += ["STORED TESTS FOR THIS KIND OF DEFECT (approved earlier; examples, not answers):"]
        for i, x in enumerate(stored[:2], 1):
            parts.append("%d. %s; steps: %s; check: %s" % (i, x.get("scenario") or "(not named)", "; ".join("%s (%s)" % (s.get("command"), ", ".join(s.get("why") or [])[:80]) for s in x.get("steps") or [])[:900],
                                                         (x.get("oracle") or {}).get("words") or "not recorded"))
        parts.append("")
    cmds = window.get("commands") or []
    parts += ["WINDOW: the commands around the defect (n above, m below, and commands from earlier in the recording that it depends on):",
              _table(cmds, [("row", lambda r: r.get("rowid")), ("where", lambda r: "earlier: " + "; ".join(r.get("history_why") or [])[:120] if r.get("from_history") else
                                                                    {"above": "before", "fault": "THE DEFECT", "below": "after"}.get(r.get("position"), r.get("position"))),
                            ("command", lambda r: r.get("summary")), ("parameters", lambda r: json.dumps(r.get("parameters") or {}, sort_keys=True)), ("status", lambda r: r.get("status") or ""),
                            ("took", lambda r: r.get("dur") or ""), ("gap before", lambda r: r.get("gap") or ""),
                            ("findings", lambda r: "; ".join(x.get("name", "")[:90] for x in r.get("findings") or []))]), ""]
    fault = next((c for c in cmds if c.get("position") == "fault"), None)
    for lv, blk in ((fault or {}).get("under") or {}).items():
        rows = blk.get("rows") or []
        parts += ["UNDER THE DEFECT COMMAND, %s: %d rows (%d shown; the rest are counted, rows with findings are always shown):" % (blk.get("label") or lv, blk.get("count") or 0, len(rows)),
                  _table(rows, [("row", lambda r: r.get("rowid")), ("parent", lambda r: "%s %s" % (r.get("parent_level") or "", r.get("parent_n") or r.get("parent_rowid") or "")),
                                ("what", lambda r: r.get("summary")), ("took", lambda r: r.get("dur") or ""), ("findings", lambda r: "; ".join(x.get("name", "")[:90] for x in r.get("findings") or []))]), ""]
    others = {}
    for c in cmds:
        if c is fault:
            continue
        for lv, blk in (c.get("under") or {}).items():
            others[blk.get("label") or lv] = others.get(blk.get("label") or lv, 0) + (blk.get("count") or 0)
    if others:
        parts += ["Under the other commands of the window: " + ", ".join("%s %s" % ("{:,}".format(v), k) for k, v in others.items()) + " (counted, not listed).", ""]
    parts += ["THE SEQUENCE STAGE 1 KEPT (the admin gave it a signal): " + "; ".join("row %s %s" % (s.get("source_row"), s.get("command")) for s in sequence), ""]
    if outcomes:
        parts += ["WHAT A CORRECT DRIVE MUST ANSWER (verified by the admin): " + "; ".join("step %s %s: %s" % (o.get("step"), o.get("command"), o.get("status")) for o in outcomes), ""]
    if problems:
        parts += ["YOUR LAST ANSWER DID NOT PASS THE CODE'S CHECKS. Fix these and answer again:"] + ["- " + p for p in problems] + [""]
    parts += ["THE DEFECT:"] + list(defect_lines) + ["", "Answer with the JSON described at the top."]
    return "\n".join(parts)


def check_answer(ans, window, rule_oracle):
    """The model's answer against the window and the rule. -> (chosen rows, problems, notes)."""
    probs, notes = [], []
    rows = {c.get("rowid"): c for c in window.get("commands") or []}
    fault = next((c.get("rowid") for c in window.get("commands") or [] if c.get("position") == "fault"), None)
    chosen = []
    for x in ans.get("replay_rows") or []:
        try:
            x = int(x)
        except (TypeError, ValueError):
            probs.append("replay_rows holds %r, which is not a row number" % (x,))
            continue
        if x not in rows:
            probs.append("row %s is not in the WINDOW table" % x)
        elif x not in chosen:
            chosen.append(x)
    if fault is not None and fault not in chosen:
        probs.append("the defect row %s is not among replay_rows" % fault)
    if chosen != sorted(chosen):
        notes.append("the rows were put in recording order")
        chosen = sorted(chosen)
    o = ans.get("oracle") or {}
    kind = o.get("kind")
    if kind not in ("status", "timeout", "latency", "deallocate_readback", "bytes_short", "any_error"):
        probs.append("oracle kind %r is not one of status, timeout, latency, deallocate_readback, bytes_short, any_error" % (kind,))
    elif kind != rule_oracle.get("kind") and rule_oracle.get("kind") != "link_level":
        notes.append("the model proposed the check '%s'; the rule's own check '%s' is kept (detection is by rule)" % (kind, rule_oracle.get("kind")))
    elif kind == "status" and rule_oracle.get("sct") is not None and (o.get("status_type"), o.get("status_code")) != (rule_oracle.get("sct"), rule_oracle.get("sc")):
        notes.append("the model proposed status %s/%s; the recorded status %s/%s is kept" % (o.get("status_type"), o.get("status_code"), rule_oracle.get("sct"), rule_oracle.get("sc")))
    if not (ans.get("analysis") or "").strip():
        probs.append("the analysis is empty")
    return chosen, probs, notes
