"""The tree Family 2 built, as the only door Family 3's code has to the data (owner, 2026-11-10: "it needs to talk to family two and family one
... the data building and the rules ... otherwise it is just a waste of time"; research: reports/Connecting agent families for rules.md).

A rule's code gets a Tree and never the raw CSV files, so it cannot join the levels again by repeating values (Tag, Address, CID): every row
already knows its parent, by the approved identity rules (NVMe command > NVMe transaction > split transaction > link transaction > packet;
posted writes hang directly under their NVMe transaction; flow-control and link-event packets are context rows of the unit whose time window
holds them). Rows that the approved joins left without a parent stay without one: unlinked() lists them; nothing here guesses a parent.

    for cmd in tree.rows("nvme_command"):                       # file order; cmd["OPC"] is the cell exactly as the export wrote it
        for ntx in tree.children("nvme_command", cmd.row):     # its NVMe transactions
            ...
    for pkt in tree.rows("packets", with_ancestor="nvme_command"):
        pkt.ancestor                                            # the row of the command it belongs to, or None (outside any command)

Read only: the database is opened read-only (and the process that runs a rule's code can open nothing else). Every call is counted, so the
approval card can show what the code used.
"""
import collections
import json
import sqlite3

LEVELS = ("nvme_command", "nvme_transaction", "split", "link", "packets")
TABLE = {"nvme_command": "cmd", "nvme_transaction": "ntx", "split": "spl", "link": "lnk", "packets": "pkt"}
FILE = {"nvme_command": "nvme_command.csv", "nvme_transaction": "NVME_Transactions.csv", "split": "split.csv", "link": "link.csv", "packets": "packets.csv"}
# the parent levels a row of each level can have, as the approved joins build them (a link row: its split transaction, or for a posted write
# its NVMe transaction; a packet: its link transaction, or as a context row any unit)
UP = {"nvme_transaction": ("nvme_command",), "split": ("nvme_transaction",), "link": ("split", "nvme_transaction"), "packets": ("link",)}
CHILD = {"nvme_command": ("nvme_transaction",), "nvme_transaction": ("split", "link"), "split": ("link",), "link": ("packets",), "packets": ()}
BATCH = 5000


class NotInTree(LookupError):
    """A relation the approved joins did not build: the code must not invent it."""


class Row(dict):
    """One row: its cells by the exact header of its file (row["OPC"]), plus .level, .row (its row in the file, counted under the header),
    .number (the analyzer's own number for it), .parent (level, row) or None, .relation (member, context or orphan), .time_ps, .ancestor."""
    __slots__ = ("level", "row", "number", "parent", "relation", "time_ps", "ancestor")

    def __repr__(self):
        return "<%s row %s of %s>" % (self.level, self.row, FILE.get(self.level))


def _row(level, r, cols):
    d = dict(zip(cols, r))
    raw = d.get("raw")
    out = Row(json.loads(raw) if isinstance(raw, str) and raw else {})
    out.level, out.row, out.number = level, d.get("rowid_file"), d.get("n")
    out.parent = (d.get("parent_level"), d.get("parent")) if d.get("parent") is not None else None
    out.relation, out.time_ps, out.ancestor = d.get("relation"), d.get("t_ps"), d.get("_anc")
    return out


def _paths(level, to):
    """Every way up from level to the level `to`, through the parent levels the joins build: [[level, ..., to]]."""
    if level == to:
        return [[level]]
    out = []
    for p in UP.get(level, ()):
        for rest in _paths(p, to):
            out.append([level] + rest)
    return out


class Tree:
    def __init__(self, db_path, meanings=None, immutable=False):
        """immutable=True reads the main database file only (no -wal or -shm): for a confined process that may only read, once the server has
        folded the write-ahead log into the file (procedures.run_code does)."""
        self.db = db_path
        self.con = sqlite3.connect("file:%s?mode=ro%s" % (db_path, "&immutable=1" if immutable else ""), uri=True, check_same_thread=False)
        self.con.execute("PRAGMA query_only=1")
        self.meanings = meanings or {}
        self.calls = collections.Counter()
        self.present = {lv for lv, t in TABLE.items() if self.con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (t,)).fetchone()}

    def close(self):
        self.con.close()

    def _need(self, level):
        if level not in TABLE:
            raise ValueError("no level %r: the levels are %s" % (level, ", ".join(LEVELS)))
        if level not in self.present:
            raise NotInTree("this recording has no %s (its file was not loaded)" % FILE[level])

    def _cols(self, t, alias="x"):
        return [r[1] for r in self.con.execute("PRAGMA table_info(%s)" % t)]

    # ---------------------------------------------------------------- reading
    def levels(self):
        """{level: number of rows} of the levels this recording has."""
        self.calls["levels"] += 1
        return {lv: self.con.execute("SELECT COUNT(*) FROM %s" % TABLE[lv]).fetchone()[0] for lv in LEVELS if lv in self.present}

    def columns(self, level):
        """The headers of the level's file, in the file's order."""
        self.calls["columns"] += 1
        self._need(level)
        r = self.con.execute("SELECT raw FROM %s ORDER BY rowid_file LIMIT 1" % TABLE[level]).fetchone()
        return list(json.loads(r[0]).keys()) if r and r[0] else []

    def rows(self, level, with_ancestor=None, include_context=True):
        """Every row of a level in file order. with_ancestor=<a higher level>: each row's .ancestor is the row (in that level's file) it belongs to
        through the approved parent links, or None when it belongs to none."""
        self.calls["rows"] += 1
        self._need(level)
        t = TABLE[level]
        where = "" if include_context else " WHERE (x.relation IS NULL OR x.relation != 'context')"
        if not with_ancestor:
            cur = self.con.execute("SELECT x.* FROM %s x%s ORDER BY x.rowid_file" % (t, where))
        else:
            self._need(with_ancestor)
            paths = _paths(level, with_ancestor)
            if not paths:
                raise NotInTree("a %s has no %s above it in the tree (the levels go: %s)" % (level, with_ancestor, " > ".join(LEVELS)))
            joins, ends = [], []
            for k, path in enumerate(paths):
                prev = "x"
                for i, lv in enumerate(path[1:], 1):
                    a = "p%d_%d" % (k, i)
                    joins.append("LEFT JOIN %s %s ON %s.parent_level = '%s' AND %s.rowid_file = %s.parent" % (TABLE[lv], a, prev, lv, a, prev))
                    prev = a
                ends.append("%s.rowid_file" % prev)
            cur = self.con.execute("SELECT x.*, COALESCE(%s) AS _anc FROM %s x %s%s ORDER BY x.rowid_file" % (", ".join(ends), t, " ".join(joins), where))
        cols = [c[0] for c in cur.description]
        while True:
            batch = cur.fetchmany(BATCH)
            if not batch:
                return
            for r in batch:
                yield _row(level, r, cols)

    def get(self, level, row):
        """One row by its row number in its file, or NotInTree."""
        self.calls["get"] += 1
        self._need(level)
        cur = self.con.execute("SELECT * FROM %s WHERE rowid_file = ?" % TABLE[level], (int(row),))
        r = cur.fetchone()
        if r is None:
            raise NotInTree("%s has no row %s" % (FILE[level], row))
        return _row(level, r, [c[0] for c in cur.description])

    def children(self, level, row, child_level=None, include_context=False):
        """The rows directly under one row (all child levels, or only child_level), in file order. Context rows (time-window attachments) are
        left out unless include_context=True."""
        self.calls["children"] += 1
        self._need(level)
        want = [child_level] if child_level else [c for c in CHILD[level] if c in self.present]
        if child_level and child_level not in CHILD[level]:
            raise NotInTree("a %s is never directly under a %s (the levels go: %s)" % (child_level, level, " > ".join(LEVELS)))
        out = []
        for cl in want:
            self._need(cl)
            q = "SELECT * FROM %s WHERE parent_level = ? AND parent = ?%s ORDER BY rowid_file" % (TABLE[cl], "" if include_context else " AND (relation IS NULL OR relation != 'context')")
            cur = self.con.execute(q, (level, int(row)))
            cols = [c[0] for c in cur.description]
            out += [_row(cl, r, cols) for r in cur.fetchall()]
        if include_context and level != "packets" and "packets" not in want and "packets" in self.present:
            cur = self.con.execute("SELECT * FROM pkt WHERE parent_level = ? AND parent = ? AND relation = 'context' ORDER BY rowid_file", (level, int(row)))
            cols = [c[0] for c in cur.description]
            out += [_row("packets", r, cols) for r in cur.fetchall()]       # link events and flow control attached to this unit by its time window
        return out

    def parent(self, level, row):
        """The row directly above, or None when the approved joins gave it no parent (outside any command, or unlinked)."""
        self.calls["parent"] += 1
        r = self.get(level, row)
        if not r.parent or r.parent[0] not in TABLE:
            return None
        return self.get(r.parent[0], r.parent[1])

    def ancestor(self, level, row, to_level):
        """The row at to_level that this row belongs to, or None (outside any such row)."""
        self.calls["ancestor"] += 1
        if LEVELS.index(to_level) >= LEVELS.index(level):
            raise NotInTree("%s is not above %s in the tree (the levels go: %s)" % (to_level, level, " > ".join(LEVELS)))
        r = self.get(level, row)
        while r is not None and r.level != to_level:
            r = self.parent(r.level, r.row) if r.parent else None
        return r

    def descendants(self, level, row, to_level, include_context=False):
        """Every row at to_level under one row (through all levels in between), in file order."""
        self.calls["descendants"] += 1
        if LEVELS.index(to_level) <= LEVELS.index(level):
            raise NotInTree("%s is not below %s in the tree (the levels go: %s)" % (to_level, level, " > ".join(LEVELS)))
        frontier, out = [self.get(level, row)], []
        while frontier:
            nxt = []
            for r in frontier:
                for c in self.children(r.level, r.row, include_context=include_context):
                    (out if c.level == to_level else nxt).append(c)
            frontier = [r for r in nxt if LEVELS.index(r.level) < LEVELS.index(to_level)]
        return sorted(out, key=lambda r: r.row)

    def unlinked(self, level):
        """The rows the approved joins left without a parent (and that are not context rows): they belong to no unit above."""
        self.calls["unlinked"] += 1
        self._need(level)
        cur = self.con.execute("SELECT * FROM %s WHERE parent IS NULL AND (relation IS NULL OR relation != 'context') ORDER BY rowid_file" % TABLE[level])
        cols = [c[0] for c in cur.description]
        for r in cur:
            yield _row(level, r, cols)

    def findings(self, rule=None, level=None):
        """The defects the detector's rules found: {id, level, rule, name, severity, row, command_row, time_ps}."""
        self.calls["findings"] += 1
        q, a = "SELECT id, level, rule, name, severity, rowid, cmd_rowid, t_ps FROM finding WHERE 1=1", []
        if rule:
            q, a = q + " AND rule = ?", a + [rule]
        if level:
            q, a = q + " AND level = ?", a + [level]
        for r in self.con.execute(q + " ORDER BY id", a):
            yield {"id": r[0], "level": r[1], "rule": r[2], "name": r[3], "severity": r[4], "row": r[5], "command_row": r[6], "time_ps": r[7]}

    def meaning(self, level, column):
        """Family 1's approved meaning of a column of a level's file, or '' when none is approved."""
        self.calls["meaning"] += 1
        return (self.meanings.get(level) or {}).get(column, "")


# the words the Rule writer and the Coder are given (one place, so the prompts and the code agree)
GUIDE = """THE TREE (built by Family 2 with the joining rules the admin approved; use it, never the raw CSV files):
  levels, top down: nvme_command (nvme_command.csv) > nvme_transaction (NVME_Transactions.csv) > split (split.csv) > link (link.csv) > packets (packets.csv)
  every row already knows its parent: a posted write's link row hangs directly under its NVMe transaction; flow-control and link-event packets are
  context rows of the unit whose time window holds them; rows the joins could not place have no parent (tree.unlinked(level) lists them).
  Never join two levels again by Tag, Address, CID, RequesterID or time: the tree already joined them by identity.
THE CALLS (tree is given to run(tree, out_csv)):
  tree.levels() -> {level: rows}            tree.columns(level) -> the file's headers
  tree.rows(level, with_ancestor=None) -> rows in file order; with_ancestor="nvme_command" sets row.ancestor to the command's row (or None)
  tree.get(level, row)   tree.children(level, row, child_level=None)   tree.parent(level, row)
  tree.ancestor(level, row, to_level)   tree.descendants(level, row, to_level)   tree.unlinked(level)
  tree.findings(rule=None, level=None)      tree.meaning(level, column) -> Family 1's approved meaning
A row: row["OPC"] is the cell exactly as the export wrote it (text); row.level, row.row (its row in its file), row.number (the analyzer's own
number), row.parent (level, row) or None, row.relation (member, context, orphan), row.time_ps (its Time Stamp in picoseconds), row.ancestor.
A relation the tree does not have raises tree_api.NotInTree: report it, never guess."""
