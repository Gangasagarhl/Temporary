"""Load the five per-level CSV exports into a SQLite staging database.

What the loader does, per file
  1. Reads the header. Aligns it with the known column list of that file (columns.py): named cells must appear
     in the known order; a blank header cell is either a separator column (the export puts one between field
     groups; dropped) or one of the label-less value columns ("16.0", "1 warning(s)", ...; kept and named).
     Anything that does not align is reported (unknown column kept under its own name, missing column listed).
  2. Streams the rows into one table per level. The typed key columns (times in picoseconds, identifiers as
     integers, data sizes in bytes) become real columns so the builder and the filters can use SQL; every other
     non-empty cell is kept in a compact JSON object (`raw`) so nothing from the file is lost and every number on
     the page can be traced to its file and row.
  3. Counts rows, blank key cells and unreadable cells per column, and keeps the first unreadable example.

The database is one file per upload (uploads/<id>/hier.sqlite) so an upload can be removed as a unit.

Memory: nothing that scales with the file is kept in RAM. Rows are read one at a time from the CSV and inserted in
batches; a transaction is committed every COMMIT_EVERY rows so the write-ahead log stays small; the blank-cell
counts are taken while streaming (no second pass over the table). open_db() sets the bulk PRAGMAs (page cache
~200 MB, synchronous off, temporary files next to the database rather than in /tmp, which is a RAM disk on this
machine) and the builder and the rules keep their own scratch tables in a second file (hier.work.sqlite) that is
attached while they run and removed afterwards, so every lookup table that grows with the capture lives on disk.
"""
import concurrent.futures
import concurrent.futures.process
import contextlib
import csv
import io
import json
import multiprocessing
import operator
import os
import shutil
import sqlite3
import sys
import tempfile
import threading
import time

from . import columns as C
from . import parse as P

MAX_LINE_CHARS = 64 * 1024 * 1024           # far beyond any analyzer row; a file with no line ends must not be read whole into memory
csv.field_size_limit(MAX_LINE_CHARS)

INSERT_BATCH = 5000          # rows per executemany
REPORT_SECONDS = 1.0         # at most one progress report per second, and never fewer on a long pass
NUMBER = __import__("re").compile(r"^[+-]?[\d.,]+([eE][+-]?\d+)?$")
COMMIT_EVERY = 100000        # rows per transaction (bounds the WAL file during a load)
# Parallel parsing (2026-11-03): the CSV is cut into chunks at line boundaries, worker processes parse the chunks
# (the CPU-bound part: splitting cells, typing the key columns, packing the raw cells), the main process inserts the
# rows in file order. Row numbers, typed values, raw cells, unreadable and blank counts are exactly those of the
# serial pass: the chunk order is the file order and every chunk is parsed with the same code. WORKERS: None = auto
# (the machine's cores minus one, at most 8), 1 = serial. Files under PARALLEL_MIN_BYTES are parsed serially.
WORKERS = None
PARALLEL_MIN_BYTES = 64 * 1024 * 1024
CHUNK_BYTES = 16 * 1024 * 1024
MAX_CHUNK_BYTES = 8 * CHUNK_BYTES            # what a damaged file (an unbalanced quote) can make one chunk grow to
WAVE = 2                     # chunks in flight per worker (bounds the memory the parsed rows take)


def worker_count():
    if WORKERS is not None:
        try:
            return max(1, int(WORKERS))
        except (TypeError, ValueError):
            return 1
    env = os.environ.get("F2T_WORKERS")
    if env:
        try:
            return max(1, int(env))
        except ValueError:
            pass
    room = memory_available()
    by_memory = 8 if room is None else int((room - keep_for_others()) // WORKER_MEMORY_BYTES)      # on a machine short of memory, fewer workers at once
    return max(1, min(8, (os.cpu_count() or 2) - 1, by_memory))


# ---------------------------------------------------------------------------------------------- room on the machine (owner, 2026-11-09: "5, 6, 7, 8 GB files: RAM may crash")
MEMORY_KEEP_BYTES = 1024 ** 3              # left to the rest of the machine when the number of workers is chosen
WORKER_MEMORY_BYTES = 300 * 1024 ** 2      # one worker parses a chunk of 16 MB: its rows take about this much at most
MIN_START_MEMORY_BYTES = 1024 ** 3         # below this a load does not start
MEMORY_STOP_BYTES = 300 * 1024 ** 2        # below this a running load stops by itself, before the operating system kills the application
SHM_MIN_BYTES = 1024 ** 3                  # shared memory free before the chunk databases are put there
PAUSE_LIMIT_S = 540                        # the longest a load waits for the other programs in one go; shorter than the ten minutes after which the page says it is stuck
PRESSURE_PAUSE = 40.0                      # percent of the last 10 s in which programs waited for memory: the load pauses from here
PRESSURE_GO = 15.0                         # and goes on below this
DISK_STOP_BYTES = 1024 ** 3                # likewise for the disk
DISK_PER_CSV_BYTE = 4.0                    # the database, its indexes and the scratch files, per byte of CSV (measured for the finished database: 3.1 on a 3.4 GB recording, 1.9 on 7.9 GB)
_GUARDS = set()
ROOM_LOCK = threading.Lock()               # a check of the free disk and the promise that follows it are one step
_RESERVED = {}


def _cgroup_room():
    """Bytes left under this process's own memory limit (a service started with MemoryMax), counting file cache as free. None when there is no limit."""
    try:
        with open("/proc/self/cgroup") as fh:
            path = next(ln.split("::", 1)[1].strip() for ln in fh if ln.startswith("0::"))
    except (OSError, StopIteration, IndexError):
        return None
    best = None
    p = "/sys/fs/cgroup" + path.rstrip("/")
    while p.startswith("/sys/fs/cgroup/"):
        try:
            with open(p + "/memory.max") as fh:
                top = fh.read().strip()
            if top != "max":
                with open(p + "/memory.current") as fh:
                    used = int(fh.read())
                with open(p + "/memory.stat") as fh:
                    stat = {k: int(v) for k, v in (ln.split() for ln in fh)}
                room = int(top) - (used - stat.get("file", 0) - stat.get("slab_reclaimable", 0))
                best = room if best is None else min(best, room)
        except (OSError, ValueError, KeyError):
            pass
        p = os.path.dirname(p)
    return best


def memory_available():
    """Bytes of memory that can still be used: what the machine has free, or what is left under this service's limit if that is less. None where it cannot be told."""
    host = None
    try:
        with open("/proc/meminfo") as fh:
            for line in fh:
                if line.startswith("MemAvailable:"):
                    host = int(line.split()[1]) * 1024
                    break
    except (OSError, ValueError, IndexError):
        pass
    limit = _cgroup_room()
    known = [x for x in (host, limit) if x is not None]
    return min(known) if known else None


def _gb(n):
    return "%.1f GB" % (n / 1024 ** 3)


def total_memory():
    """The memory of the machine, or this service's own limit when that is smaller. None when it cannot be told."""
    host = None
    try:
        with open("/proc/meminfo") as fh:
            host = next(int(ln.split()[1]) * 1024 for ln in fh if ln.startswith("MemTotal:"))
    except (OSError, ValueError, IndexError, StopIteration):
        pass
    limit = None
    try:
        with open("/proc/self/cgroup") as fh:
            p = "/sys/fs/cgroup" + next(ln.split("::", 1)[1].strip() for ln in fh if ln.startswith("0::")).rstrip("/")
        while p.startswith("/sys/fs/cgroup/"):
            try:
                with open(p + "/memory.max") as fh:
                    top = fh.read().strip()
                if top != "max":
                    limit = int(top) if limit is None else min(limit, int(top))
            except (OSError, ValueError):
                pass
            p = p.rsplit("/", 1)[0]
    except (OSError, StopIteration, IndexError):
        pass
    known = [x for x in (host, limit) if x is not None]
    return min(known) if known else None


def keep_for_others():
    """Memory a load leaves to the other programs on the machine: a tenth of it, at least 1 GB and at most 4 GB (the owner, 2026-11-10: what else runs on the machine must not suffer)."""
    total = total_memory()
    return MEMORY_KEEP_BYTES if total is None else int(max(MEMORY_KEEP_BYTES, min(4 * 1024 ** 3, total * 0.10)))


def memory_pressure():
    """How much of the last 10 seconds some program on the machine spent waiting for memory, in percent; None where Linux does not tell."""
    try:
        with open("/proc/pressure/memory") as fh:
            return float(fh.readline().split("avg10=")[1].split()[0])
    except (OSError, ValueError, IndexError):
        return None


def give_way():
    """For work that can wait: this thread takes a lower priority for processor time, so whatever else runs on the machine stays responsive."""
    try:
        os.nice(5)
    except OSError:
        pass


def worker_starts():
    """A chunk worker gives way to the other programs, and it is the first to go if the machine really runs out: the load then stops with a reason, and nothing else is killed."""
    try:
        os.nice(10)
    except OSError:
        pass
    try:
        with open("/proc/self/oom_score_adj", "w") as fh:
            fh.write("800")
    except OSError:
        pass


def chunk_folder(beside):
    """Where the workers put their small chunk databases, and whether that folder is in memory. A chunk lives for seconds: in shared memory it is never written to the disk, which halves
    what a load writes and leaves the disk to the other programs. Only when there is room for it (at most a few hundred MB are in use at any time); otherwise they go beside the database."""
    try:
        room = memory_available()
        if os.access("/dev/shm", os.W_OK) and shutil.disk_usage("/dev/shm").free >= SHM_MIN_BYTES and (room is None or room >= SHM_MIN_BYTES + keep_for_others()):
            return tempfile.mkdtemp(prefix="f2t-chunks-", dir="/dev/shm"), True
    except OSError:
        pass
    return beside, False


def drop_file_cache(fh, start, length):
    """The part of a file just read is not needed again: it is taken out of the machine's file cache, so reading a 30 GB recording does not push out what other programs keep there."""
    try:
        os.posix_fadvise(fh.fileno(), start, length, os.POSIX_FADV_DONTNEED)
    except (AttributeError, OSError, ValueError):
        pass


def room_problem(csv_bytes, folder, already=0):
    """In plain words why this machine cannot take a recording of this size now, or None. `already` = the bytes of an earlier, unfinished load kept in the folder."""
    need = int(csv_bytes * DISK_PER_CSV_BYTE) - already
    free = shutil.disk_usage(folder).free - sum(_RESERVED.values())     # what other running loads will still use is not free
    if need > free:
        return "this recording needs about %s of free disk space and %s are free. Free some space and load it again; nothing was changed." % (_gb(need), _gb(free))
    room = memory_available()
    if room is not None and room < MIN_START_MEMORY_BYTES + keep_for_others():
        return "only %s of memory is free, and a load needs at least %s, so that the other programs keep theirs. Close other programs and load it again; nothing was changed." % (_gb(room), _gb(MIN_START_MEMORY_BYTES + keep_for_others()))
    return None


def reserve(csv_bytes, already=0):
    """Promises this load's disk space to it: the next load's check does not count it as free. Returns the function that gives it back."""
    key = object()
    _RESERVED[key] = max(0, int(csv_bytes * DISK_PER_CSV_BYTE) - already)
    return lambda: _RESERVED.pop(key, None)


@contextlib.contextmanager
def reserve_room(csv_bytes, already=0):
    release = reserve(csv_bytes, already)
    try:
        yield
    finally:
        release()


class NoRoom(RuntimeError):
    """A load stopped by itself because the machine was running out of memory or disk."""


class RoomGuard:
    """While a load runs: every 2 seconds, how much memory and disk are left. When one of them runs out the load stops by itself with a reason, so the operating system
    does not kill the application. What was finished is kept and 'load again' continues from there. Files are read as streams and the work sits on disk, so this is a safety net."""

    def __init__(self, folder, every=2.0, memory_floor=None, disk_floor=None):
        self.folder, self.every = folder, every
        self.memory_floor = max(MEMORY_STOP_BYTES, keep_for_others() // 2) if memory_floor is None else memory_floor
        self.disk_floor = DISK_STOP_BYTES if disk_floor is None else disk_floor
        self.why = None
        self.pause_floor = keep_for_others()    # below this the load waits for the others; it stops only at memory_floor
        self.pause_limit = PAUSE_LIMIT_S
        self.tight = False
        self.paused_seconds = 0
        self.on_pause = None                    # called once a second while the load waits, with the words for the page
        self.lowest_memory = None
        self._end = threading.Event()
        self._low = 0

    def look(self):
        room = memory_available()
        if room is not None:
            self.lowest_memory = room if self.lowest_memory is None else min(self.lowest_memory, room)
            self._low = self._low + 1 if room < self.memory_floor else 0
            if self._low >= 2 and not self.why:             # two looks in a row: one short dip is not a shortage
                self.why = "the machine was running out of memory (%s left), so the load stopped by itself." % _gb(room)
        pressure = memory_pressure()
        short = room is not None and room < self.pause_floor
        strained = pressure is not None and pressure >= PRESSURE_PAUSE
        if short or strained:
            self.tight = True
        elif self.tight and (room is None or room >= self.pause_floor * 1.25) and (pressure is None or pressure <= PRESSURE_GO):
            self.tight = False
        self.room_now = room
        try:
            free = shutil.disk_usage(self.folder).free
        except OSError:
            return
        if free < self.disk_floor and not self.why:
            self.why = "the disk was nearly full (%s left), so the load stopped by itself." % _gb(free)

    def check(self):
        """Called between pieces of work. When the machine is tight the load waits here for the other programs, and goes on as soon as there is room again."""
        t0 = time.time()
        while self.tight and not self.why:
            if time.time() - t0 >= self.pause_limit:
                self.why = "the other programs on this machine kept needing the memory for %d minutes, so the load stopped by itself." % (self.pause_limit // 60)
                break
            self.paused_seconds += 1
            if self.on_pause:
                try:
                    self.on_pause("waiting %d s: the other programs on this machine need the memory (%s free)" % (time.time() - t0, _gb(getattr(self, "room_now", 0) or 0)))
                except Exception:       # noqa: BLE001 - words on a page must never stop the wait
                    pass
            time.sleep(1)
        if self.why:
            raise NoRoom(self.why)

    def start(self):
        _GUARDS.add(self)

        def run():
            while not self._end.wait(self.every):
                self.look()
        threading.Thread(target=run, name="room-guard", daemon=True).start()
        return self

    def stop(self):
        self._end.set()
        _GUARDS.discard(self)


def stop_reason():
    for g in list(_GUARDS):
        if g.why:
            return g.why
    return None


class BadFile(ValueError):
    """A file that cannot be an analyzer export; the message says why, in plain words."""


def csv_lines(fh, name=""):
    """The lines of an open text file, one at a time, for csv.reader. A plain read of a file with no line ends would pull all of it into memory: here a line stops at MAX_LINE_CHARS."""
    n = 0
    while True:
        line = fh.readline(MAX_LINE_CHARS)
        if not line:
            return
        n += 1
        if len(line) >= MAX_LINE_CHARS and line[-1] not in "\r\n":
            raise BadFile("line %d of %s is longer than %d MB: this is not an analyzer's CSV export" % (n, os.path.basename(name) or "the file", MAX_LINE_CHARS // 1024 ** 2))
        yield line


class read_csv:
    """csv.reader over csv_lines; a cell that never ends (a stray quote) stops with a plain message instead of filling the memory. Used like csv.reader, line_num included."""

    def __init__(self, fh, name=""):
        self.name = name
        self.rd = csv.reader(csv_lines(fh, name))

    def __iter__(self):
        return self

    def __next__(self):
        try:
            return next(self.rd)
        except csv.Error as e:
            raise BadFile("%s, near line %d, cannot be read as CSV: %s (a stray quote can do this)" % (os.path.basename(self.name) or "the file", self.rd.line_num, e)) from e

    @property
    def line_num(self):
        return self.rd.line_num


def plan_chunks(path, start, chunk_bytes=CHUNK_BYTES):
    """Byte ranges [start, end) that each end at a line end and never split a quoted cell: the quote count from the chunk's start to the cut is kept even, counted once
    as the cut moves (a stray quote must not cause the chunk to be read again for every line). A chunk never grows past MAX_CHUNK_BYTES. Deterministic for a given file."""
    size = os.path.getsize(path)
    out = []

    def next_line(fb):
        line = fb.readline(MAX_LINE_CHARS)
        if len(line) >= MAX_LINE_CHARS and line[-1:] not in (b"\n", b"\r"):
            raise BadFile("%s has a line longer than %d MB: this is not an analyzer's CSV export" % (os.path.basename(path), MAX_LINE_CHARS // 1024 ** 2))
        return line
    with open(path, "rb") as fb:
        pos = start
        while pos < size:
            end = min(size, pos + chunk_bytes)
            if end < size:
                fb.seek(pos)
                quotes, left = 0, end - pos
                while left > 0:
                    blk = fb.read(min(left, 8 * 1024 * 1024))
                    quotes += blk.count(b'"')
                    left -= len(blk)
                quotes += next_line(fb).count(b'"')
                end = fb.tell()
                while quotes % 2 and end < size and end - pos < MAX_CHUNK_BYTES:
                    quotes += next_line(fb).count(b'"')
                    end = fb.tell()
            out.append((pos, end))
            pos = end
    return out


def _value(fn, cell, cname, unread):
    try:
        v = fn(cell)
    except (ValueError, OverflowError, TypeError):
        v = None
    if isinstance(v, int) and not (-INT64 <= v < INT64):
        v = None
    if v is None:
        _note_unread(cell, cname, unread)
    return v


def _note_unread(cell, cname, unread):
    u = unread.setdefault(cname, {"count": 0, "example": cell[:80]})
    u["count"] += 1


MEMO_PER_COLUMN = 5000      # cell texts remembered per column and chunk: enough for what repeats, nothing for what does not (a time stamp)
_COMPACT = json.JSONEncoder(separators=(",", ":")).encode      # one encoder for all rows: json.dumps with separators builds a new one for every call


def parse_rows(rows, typed, named, sql_cols, unread, blanks):
    """The per-row work of the loader, shared by the serial pass and the chunk workers: typed values in sql_cols
    order and the raw cells as compact JSON. Returns [[typed..., raw_json], ...].
    This is the loader's hottest loop (113 columns, millions of rows): cells are fetched in one C call, and a short row is padded once instead of testing every cell."""
    out = []
    names = [c for c, _ in named]
    picks = [i for _, i in named]
    fetch = operator.itemgetter(*picks) if len(picks) > 1 else (lambda r: (r[picks[0]],)) if picks else (lambda r: ())
    width = 1 + max(picks + [t[0] for t in typed] + [-1])
    memo = {t[0]: {} for t in typed}
    for row in rows:
        if not any(c.strip() for c in row):         # a blank line holds no data: it is not a row
            continue
        if len(row) < width:
            row = row + [""] * (width - len(row))
        vals = {}
        for idx, sql, fn, cname in typed:
            cell = row[idx]
            if cell == "":
                if sql not in vals:
                    vals[sql] = None
                continue
            known = memo[idx]
            if cell in known:           # the same cell text gives the same value: direction, type, ports and most numbers repeat
                v = known[cell]
                if v is None:
                    _note_unread(cell, cname, unread)
            else:
                v = _value(fn, cell, cname, unread)
                if len(known) < MEMO_PER_COLUMN:
                    known[cell] = v
            if sql in vals and vals[sql] is not None:
                continue
            vals[sql] = v
        typed_vals = [vals.get(s_) for s_ in sql_cols]
        for sql, v in zip(sql_cols, typed_vals):
            if v is None:
                blanks[sql] += 1
        out.append(typed_vals + [_COMPACT({n: c for n, c in zip(names, fetch(row)) if c != ""})])
    return out


def _parse_chunk(args):
    """Worker: parse one byte range of the file into its own small database file (rows numbered 1..n within the
    chunk). Returns (n_rows, unread, blanks). The main process copies the rows in file order with the right offset:
    a database-to-database copy is far cheaper than sending parsed rows back through a pipe."""
    path, start, end, typed, named, sql_cols, file_key, out_db = args
    with open(path, "rb") as fb:
        fb.seek(start)
        data = fb.read(end - start)
        drop_file_cache(fb, start, end - start)
    text = data.decode("utf-8", errors="replace")
    rd = csv.reader(io.StringIO(text, newline=""))
    unread, blanks = {}, {sql: 0 for sql in sql_cols}
    try:
        rows = parse_rows(rd, typed, named, sql_cols, unread, blanks)
    except csv.Error as e:
        raise BadFile("%s, in bytes %d to %d, cannot be read as CSV: %s (a stray quote can do this)" % (os.path.basename(path), start, end, e)) from e
    for ext in ("", "-journal", "-wal", "-shm"):
        if os.path.exists(out_db + ext):
            os.remove(out_db + ext)
    c = sqlite3.connect(out_db)
    c.execute("PRAGMA journal_mode=OFF")
    c.execute("PRAGMA synchronous=OFF")
    t = TABLE[file_key]
    c.execute("CREATE TABLE %s (rowid_file INTEGER PRIMARY KEY, %s, raw TEXT)" % (t, ", ".join("%s" % col for col in sql_cols)))
    c.executemany("INSERT INTO %s (rowid_file, %s, raw) VALUES (%s)" % (t, ", ".join(sql_cols), ", ".join(["?"] * (len(sql_cols) + 2))),
                  ([i + 1] + r for i, r in enumerate(rows)))
    c.commit()
    c.close()
    return len(rows), unread, blanks


def _merge_unread(total, part):
    for k, u in part.items():
        t = total.setdefault(k, {"count": 0, "example": u["example"]})
        t["count"] += u["count"]
INT64 = 2 ** 63              # SQLite stores 64-bit integers; a parsed number outside that range is unreadable, never fatal
PROGRESS_EVERY = 500000      # rows between two progress reports
CACHE_KB = 200000            # SQLite page cache per connection, ~200 MB
PAGE_BYTES = 4096            # database page size
SORT_THREADS = max(1, min(4, (os.cpu_count() or 2) - 1))     # threads SQLite may use to sort while it builds an index

# Typed key columns per level: canonical column name -> (sql column, parser)
# Several export names map to one sql column where the export splits a field by TLP class (Mem./Cpl./Msg.).
KEYS = {
    "packets": [
        ("Packet", "n", P.int_value), ("Link Dir", "dir", P.direction), ("Ord.Set Type", "os_type", P.text),
        ("DLLP Type", "dllp_type", P.text), ("TLP Type", "tlp_type", P.text), ("Link Event", "link_event", P.text),
        ("PSN", "psn", P.int_value), ("AckNak Seq Num", "acknak", P.int_value), ("VC ID", "vc", P.int_value),
        ("Length", "length", P.int_value), ("RequesterID", "rid", P.text), ("Tag", "tag", P.int_value),
        ("CompleterID", "cplid", P.text), ("Address", "addr", P.address), ("DeviceID", "devid", P.text),
        ("Register", "reg", P.text), ("Cpl Status", "cpl_status", P.text), ("Byte Cnt", "bytecnt", P.int_value),
        ("BCM", "bcm", P.int_value), ("Lwr Addr", "lwr", P.address), ("Message Code", "msgcode", P.text),
        ("EP", "ep", P.int_value), ("LCRC", "lcrc", P.text), ("ECRC", "ecrc", P.text), ("CRC 16", "crc16", P.text),
        ("DATA", "nbytes", P.data_bytes), ("Time Delta", "delta_ps", P.delta_ps), ("Time Stamp", "t_ps", P.time_stamp_ps),
        ("Errors", "errors", P.text), ("Marker", "marker", P.text),
    ],
    "link": [
        ("Link Tra", "n", P.int_value), ("Link Dir", "dir", P.direction), ("Link Speed", "speed", P.text),
        ("Link Tra Error", "errors", P.text), ("PSN", "psn", P.int_value),
        ("Mem.TLP Type", "tlp_type", P.text), ("Cpl.TLP Type", "tlp_type", P.text), ("Msg.TLP Type", "tlp_type", P.text),
        ("Mem.Attributes", "attr", P.text),
        ("Mem.Length", "length", P.int_value), ("Cpl.Length", "length", P.int_value), ("Msg.Length", "length", P.int_value),
        ("RequesterID", "rid", P.text), ("Tag", "tag", P.int_value), ("Address", "addr", P.address),
        ("1st BE", "fbe", P.text), ("Last BE", "lbe", P.text), ("Data", "nbytes", P.data_bytes), ("VC ID", "vc", P.int_value),
        ("Metrics.# Packets", "n_packets", P.int_value), ("Time Delta", "delta_ps", P.delta_ps),
        ("Time Stamp", "t_ps", P.time_stamp_ps), ("CompleterID", "cplid", P.text), ("Cpl Status", "cpl_status", P.text),
        ("BCM", "bcm", P.int_value), ("Byte Cnt", "bytecnt", P.int_value), ("Lwr Addr", "lwr", P.address),
        ("Explicit ACK", "explicit_ack", P.text), ("Msg.Msg Routing", "routing", P.text), ("Message Code", "msgcode", P.text),
    ],
    "split": [
        ("Split Tra", "n", P.int_value), ("Link Dir", "dir", P.direction), ("Link Speed", "speed", P.text),
        ("Split Tra Error", "errors", P.text), ("Mem.TLP Type", "tlp_type", P.text), ("RequesterID", "rid", P.text), ("CompleterID", "cplid", P.text),
        ("Tag", "tag", P.int_value), ("TC", "tc", P.int_value), ("VC ID", "vc", P.int_value), ("Address", "addr", P.address),
        ("Cpl Status", "cpl_status", P.text), ("Data", "nbytes", P.data_bytes),
        ("Metrics.# LinkTrans", "n_links", P.int_value), ("Time Delta", "delta_ps", P.delta_ps),
        ("Time Stamp", "t_ps", P.time_stamp_ps),
    ],
    "nvme_transaction": [
        ("NVMe", "n", P.int_value), ("Link Dir", "dir", P.direction), ("Device ID", "devid", P.text),
        ("QID", "qid", P.int_value), ("QSIZE", "qsize", P.int_value), ("Address", "addr", P.address), ("Type", "type", P.text),
        ("Doorbell index", "db_index", P.int_value), ("SQID", "sqid", P.int_value), ("CID", "cid", P.int_value),
        ("P", "phase", P.int_value), ("DW0", "dw0", P.text), ("ST", "st", P.text), ("SCT", "sct", P.int_value),
        ("SC", "sc", P.int_value), ("CRD", "crd", P.int_value), ("M", "more", P.int_value), ("DNR", "dnr", P.int_value),
        ("MN", "mn", P.text), ("Metrics.# Link & Split Trans", "n_links_splits", P.int_value),
        ("Time Delta", "delta_ps", P.delta_ps), ("Time Stamp", "t_ps", P.time_stamp_ps),
        ("MPTR.Address", "mptr", P.address), ("PRP1.Address", "prp1", P.address), ("PRP2.Address", "prp2", P.address),
        ("SLBA", "slba", P.int_value), ("NLB", "nlb", P.int_value), ("Data", "nbytes", P.data_bytes),
        ("Errors", "errors", P.text), ("Warnings", "warnings", P.text),
    ],
    "nvme_command": [
        ("NVMe Cmd", "n", P.int_value), ("Link Dir", "dir", P.direction), ("OPC", "opc", P.int_value),
        ("SQID", "sqid", P.int_value), ("CQID", "cqid", P.int_value), ("CID", "cid", P.int_value),
        ("Data", "nbytes", P.data_bytes), ("MPTR", "mptr", P.address), ("PRP1", "prp1", P.address), ("PRP2", "prp2", P.address),
        ("SLBA", "slba", P.int_value), ("NLB", "nlb", P.int_value), ("FUA", "fua", P.int_value), ("LR", "lr", P.int_value),
        ("ST", "st", P.text), ("ST.SCT", "sct", P.int_value), ("ST.SC", "sc", P.int_value),
        ("Device ID", "devid", P.text), ("MN", "mn", P.text), ("NSID", "nsid", P.int_value),
        ("Metrics.# NVME Trans", "n_ntx", P.int_value), ("Time Delta", "delta_ps", P.delta_ps),
        ("Time Stamp", "t_ps", P.time_stamp_ps), ("Warnings", "warnings", P.text), ("Errors", "errors", P.text),
        ("Errors#2", "errors2", P.text), ("AD", "ad", P.int_value), ("NR", "nr", P.int_value),
        ("CNS", "cns", P.int_value), ("FID", "fid", P.int_value), ("LID", "lid", P.int_value), ("QID", "qid", P.int_value),
        ("QSIZE", "qsize", P.int_value), ("NUSE", "nuse", P.int_value), ("DLFEAT.Bits 0-2", "dlfeat", P.int_value),
    ],
}
TABLE = {"packets": "pkt", "link": "lnk", "split": "spl", "nvme_transaction": "ntx", "nvme_command": "cmd"}
TEXT_COLS = {"dir", "os_type", "dllp_type", "tlp_type", "link_event", "rid", "cplid", "devid", "reg", "cpl_status",
             "msgcode", "lcrc", "ecrc", "crc16", "errors", "marker", "speed", "attr", "fbe", "lbe", "explicit_ack",
             "routing", "type", "dw0", "st", "mn", "warnings", "errors2"}


class HeaderAlignment:
    """Result of aligning a file header with the known list."""

    def __init__(self):
        self.positions = {}        # canonical name -> column index in the file
        self.separators = []       # column indices dropped
        self.unknown = []          # (index, header text) kept under their own name
        self.missing = []          # canonical names not found
        self.renamed = {}          # canonical name -> what the header cell held ("" for label-less)
        self.header_format = "single row"
        self.known = set()         # the canonical names of this file (to tell known columns from extras)
        self.absent_note = ""      # when the names not found are ones this export does not carry by design
        self.expected = None       # the expected count when a stored header defines it (else the reference list)

    def extras(self):
        """Columns kept that are not in the customer's list (known extras and group-named cells), in file order."""
        return [n for n, _ in sorted(self.positions.items(), key=lambda kv: kv[1]) if n not in self.known]

    def report(self, file_key):
        return {
            "expected_named_columns": self.expected if self.expected is not None else C.expected_count(file_key),
            "found_named_columns": len(self.positions) if self.expected is not None else sum(1 for n in self.positions if n in self.known),
            "extra_columns_kept": [] if self.expected is not None else self.extras(),
            "absent_note": self.absent_note,
            "separator_columns_dropped": len(self.separators),
            "label_less_columns_named": {k: v for k, v in self.renamed.items() if v == ""},
            "unknown_columns": [{"index": i, "header": h} for i, h in self.unknown],
            "missing_columns": self.missing,
            "header_format": self.header_format,
        }


def _blank_runs(hdr):
    """Runs of consecutive blank header cells: list of (start, end_exclusive)."""
    runs = []
    j = 0
    while j < len(hdr):
        if hdr[j] == "":
            k = j
            while k < len(hdr) and hdr[k] == "":
                k += 1
            runs.append((j, k))
            j = k
        else:
            j += 1
    return runs


import re as _re

_LABEL_LESS_TEXT = _re.compile(r"^(\d+(\.\d+)?|\d+ (warning|error)\(s\))$")


def _norm(cell):
    """Spelling-insensitive form of a header cell: case, underscores and repeated spaces do not matter
    (the analyzer wrote AckNak_Seq_Num in one export and AckNak Seq Num in another)."""
    return " ".join((cell or "").replace("_", " ").split()).lower()


def _looks_label_less(cell):
    """A header cell that holds the first row's text instead of a label: "16.0" (the link speed),
    "1 warning(s)", "2 error(s)". The analyzer writes these in some exports; others leave the cell blank."""
    return bool(_LABEL_LESS_TEXT.match((cell or "").strip()))


def align_header(file_key, header, has_value=None):
    """Walk the known list against the header cells in order (see module docstring).

    has_value: set of header indices known to hold a value in at least one row. It is only consulted for a run
    of blank header cells that must contain both separators and label-less columns; a column with no value
    anywhere is a separator by the customer's own definition.

    Two header layouts are accepted (seen on the customer's analyzer, 2026-11-02 and 2026-11-03):
      A. label-less cells blank, sub-columns written with their group ("ST.SCT", "Metrics.# NVME Trans");
      B. label-less cells holding the first row's text ("16.0", "1 warning(s)"), sub-columns bare ("SCT",
         "# NVME Trans") right after their group cell ("ST", "Metrics"), few or no blank separator columns.
    Names are compared spelling-insensitively (case, underscores, repeated spaces)."""
    known = C.canonical_names(file_key)
    orig = C.original_names(file_key)
    label_less = set(C.label_less_positions(file_key))
    extras = set(C.KNOWN_EXTRAS.get(file_key, []))
    hdr = [(h or "").strip().lstrip("\ufeff") for h in header]
    stored = C.real_header_match(file_key, hdr)
    if stored is not None:
        # the customer's own header, stored cell by cell: every column is already known by its position
        al = HeaderAlignment()
        al.known = set(known)
        al.header_format = "the customer's stored header (%s)" % stored.get("name", "stored")
        for idx, name in stored["columns"].items():
            idx = int(idx)
            if idx < len(hdr):
                al.positions[name] = idx
                if hdr[idx] != name:
                    al.renamed[name] = hdr[idx]
        al.separators = [int(i) for i in stored.get("separators", []) if int(i) < len(hdr)]
        # the customer's own header is the expected list for this export: every named cell is expected and found,
        # none is missing or extra (the reference list's per-kind names that this export does not carry are only a note)
        al.expected = len(stored["columns"])
        al.missing = []
        absent = list(stored.get("absent", []))
        if absent:
            al.absent_note = ("note: this export has one TLP Type column and one Length column for every kind of TLP (the reference list's %s are not separate columns here); nothing is lost"
                              % ", ".join(absent)) if file_key == "link" else "note: the reference list's %s are not separate columns in this export" % ", ".join(absent)
        return al
    hn = [_norm(h) for h in hdr]
    has_value = has_value or set()
    al = HeaderAlignment()
    al.known = set(known)
    group_extra = [None]       # an extra group cell just passed ("Cfg"): the bare cells after it belong to it

    def keep_unknown(idx, cell):
        if group_extra[0]:
            al.positions[group_extra[0] + "." + cell] = idx
        else:
            al.unknown.append((idx, cell))

    known_set = set(known)

    def _same(cell, want):
        if not want:
            return False
        if cell == want or _norm(cell) == _norm(want):
            return True
        # the customer's script numbered the second of two same-named columns (CSI, CSI#2); the export does not
        base = _re.sub(r"#\d+$", "", want)
        return base != want and _norm(cell) == _norm(base)

    def _bare(name):
        # "ST.SCT" -> "SCT" when "ST" is itself a column (the group cell) of this file; else None
        prefix, _, sub = name.partition(".")
        return sub if sub and prefix in known_set and name not in C.LABEL_LESS.values() else None

    def _ahead(start, *wants):
        ws = set()
        for w in wants:
            if w:
                ws.add(_norm(w))
                ws.add(_norm(_re.sub(r"#\d+$", "", w)))
        return any(x in ws for x in hn[start:])
    j = 0
    i = 0
    while i < len(known):
        name = known[i]
        if i in label_less:
            # gather the group of consecutive label-less names expected here
            grp = [i]
            while grp[-1] + 1 < len(known) and (grp[-1] + 1) in label_less:
                grp.append(grp[-1] + 1)
            # layout B: the cells hold the first row's text ("16.0", "1 warning(s)") instead of being blank
            k = j
            taken = []
            while len(taken) < len(grp):
                m = k
                while m < len(hdr) and hdr[m] == "":
                    m += 1
                if m < len(hdr) and (hdr[m] == orig[grp[len(taken)]] or _looks_label_less(hdr[m])):
                    al.separators.extend(range(k, m))
                    taken.append(m)
                    k = m + 1
                else:
                    break
            if taken:
                for g, x in zip(grp, taken):
                    al.positions[known[g]] = x
                    al.renamed[known[g]] = hdr[x]
                al.missing.extend(known[g] for g in grp[len(taken):])
                al.header_format = "first-row text in the label-less cells"
                j = k
                i = grp[-1] + 1
                continue
            # layout A: the blank run at the current header position
            while j < len(hdr) and hdr[j] != "":
                # a named cell where blanks were expected: unknown column, keep it
                keep_unknown(j, hdr[j])
                j += 1
            k = j
            while k < len(hdr) and hdr[k] == "":
                k += 1
            run = list(range(j, k))
            if len(run) == len(grp):
                chosen = run
            elif len(run) > len(grp):
                valued = [x for x in run if x in has_value]
                chosen = valued[:len(grp)]
                if len(chosen) < len(grp):          # the rest are empty columns either way
                    rest = [x for x in run if x not in chosen]
                    chosen = sorted(chosen + rest[len(rest) - (len(grp) - len(chosen)):])
                al.separators.extend(x for x in run if x not in chosen)
            else:
                chosen = run
                al.missing.extend(known[g] for g in grp[len(run):])
                grp = grp[:len(run)]
            for g, x in zip(grp, chosen):
                al.positions[known[g]] = x
                al.renamed[known[g]] = ""
            j = k
            i = grp[-1] + 1 if grp else i + 1
            continue
        found = False
        bare = _bare(name)
        while j < len(hdr):
            cell = hdr[j]
            if _same(cell, name) or _same(cell, orig[i]) or _same(cell, bare):
                al.positions[name] = j
                if cell != name:
                    al.renamed[name] = cell
                j += 1
                found = True
                group_extra[0] = None
                break
            if cell == "":
                al.separators.append(j)
                j += 1
                continue
            if cell in extras and cell not in known:
                al.positions[(group_extra[0] + "." + cell) if group_extra[0] and cell not in C.EXTRA_GROUPS else cell] = j
                group_extra[0] = cell if cell in C.EXTRA_GROUPS else group_extra[0]
                j += 1
                continue
            if _ahead(j + 1, name, orig[i], bare):
                keep_unknown(j, cell)
                j += 1
                continue
            break
        if not found:
            al.missing.append(name)
        i += 1
    while j < len(hdr):
        cell = hdr[j]
        if cell == "":
            al.separators.append(j)
        elif cell in extras:
            al.positions[(group_extra[0] + "." + cell) if group_extra[0] and cell not in C.EXTRA_GROUPS else cell] = j
            group_extra[0] = cell if cell in C.EXTRA_GROUPS else group_extra[0]
        else:
            keep_unknown(j, cell)
        j += 1
    # layout B, second pass: a sub-column written bare ("SCT") right after its group cell ("ST") stands for the
    # dotted name ("ST.SCT"). Only cells between the group cell and the next matched column of another group
    # qualify, so the three "Address" cells of MPTR, PRP1 and PRP2 each go to their own group.
    if al.missing and al.unknown:
        known_set = set(known)
        by_idx = {v: k for k, v in al.positions.items()}
        unk = dict(al.unknown)
        still = []
        for name in al.missing:
            prefix, _, sub = name.partition(".")
            p = al.positions.get(prefix) if (sub and prefix in known_set and name not in C.LABEL_LESS.values()) else None
            if p is None:
                still.append(name)
                continue
            limit = min([x for x, n in by_idx.items() if x > p and not n.startswith(prefix + ".")] or [len(hdr)])
            hit = next((x for x in sorted(unk) if p < x < limit and _norm(unk[x]) == _norm(sub)), None)
            if hit is None:
                still.append(name)
                continue
            al.positions[name] = hit
            al.renamed[name] = unk.pop(hit)
            by_idx[hit] = name
            al.header_format = "bare sub-column names after their group cell"
        al.missing = still
        al.unknown = sorted(unk.items())
    # a column the walk did not reach, whose full name stands exactly once in the header: this export changed the order of the columns
    if al.missing and al.unknown:
        unk, still = dict(al.unknown), []
        names = [_norm(h) for h in hdr if h]
        for name in al.missing:
            want = _norm(name)
            hits = [x for x, h in unk.items() if _norm(h) == want]
            if len(hits) == 1 and names.count(want) == 1:
                al.positions[name] = hits[0]
                unk.pop(hits[0])
            else:
                still.append(name)
        al.missing, al.unknown = still, sorted(unk.items())
    return al


def ambiguous_columns(file_key, header):
    """Header indices of blank runs that may hold both separators and label-less columns, with how many
    value-bearing columns must be found in each run before the scan can stop: [(run_indices, needed)]."""
    if not C.label_less_positions(file_key):
        return []
    hdr = [(h or "").strip().lstrip("\ufeff") for h in header]
    known = C.canonical_names(file_key)
    label_less = set(C.label_less_positions(file_key))
    # anchor = the named known column just before each label-less group
    out = []
    i = 0
    while i < len(known):
        if i in label_less:
            grp = [i]
            while grp[-1] + 1 < len(known) and (grp[-1] + 1) in label_less:
                grp.append(grp[-1] + 1)
            prev = known[i - 1] if i > 0 else None
            if prev in hdr:
                j = hdr.index(prev) + 1
                k = j
                while k < len(hdr) and hdr[k] == "":
                    k += 1
                if k - j > len(grp):
                    out.append((list(range(j, k)), len(grp)))
            i = grp[-1] + 1
        else:
            i += 1
    return out


def write_text_atomic(path, text, encoding="utf-8", mode=None):
    """The whole file or none of it: written beside the target, flushed to disk, then renamed over it. A reader sees the old file or the new one,
    never half of one, and a crash during the write leaves the old file untouched. Used for everything that is read back later."""
    folder, name = os.path.split(os.path.abspath(path))
    tmp = os.path.join(folder, ".%s.%d.%d.tmp" % (name[:80], os.getpid(), threading.get_ident()))     # hidden: a folder listing that counts versions does not see it
    try:
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, mode if mode is not None else 0o666)     # mode: private from its first byte, for a file that holds a key
        with os.fdopen(fd, "w", encoding=encoding) as fh:
            fh.write(text)
            fh.flush()
            os.fsync(fh.fileno())
        if mode is None and os.path.exists(path):
            os.chmod(tmp, os.stat(path).st_mode & 0o7777)     # a file kept private stays private
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


def write_json_atomic(path, obj, **dump_args):
    write_text_atomic(path, json.dumps(obj, **dump_args))


class CsvOut:
    """csv.writer for files a person opens in a spreadsheet: a text cell that a spreadsheet would run as a formula gets a leading quote mark."""

    def __init__(self, fh):
        self.w = csv.writer(fh)

    @staticmethod
    def safe(v):
        if isinstance(v, str) and v[:1] in ("=", "+", "-", "@", "\t", "\r") and not NUMBER.match(v):
            return "'" + v
        return v

    def writerow(self, row):
        self.w.writerow([self.safe(v) for v in row])

    def writerows(self, rows):
        for r in rows:
            self.writerow(r)


def heartbeat(con, say, every=3.0):
    """Long database work cannot report progress: one statement, a sort or a commit can run for minutes, and the screen looks stuck. A small thread beside it
    calls `say(seconds so far)` every few seconds for as long as the work lasts. Returns the function that ends it. `con` is not touched from the thread."""
    t0 = time.time()
    stop = threading.Event()

    def tick():
        while not stop.wait(every):
            if stop_reason():            # out of memory or disk: the one statement still running is stopped too (interrupt is the one call allowed from another thread)
                try:
                    con.interrupt()
                except sqlite3.Error:
                    pass
            try:
                say(time.time() - t0)
            except Exception:           # noqa: BLE001 - a report that fails must never stop the work it reports on
                pass
    threading.Thread(target=tick, name="heartbeat", daemon=True).start()
    return stop.set


def add_missing_columns(con):
    """A recording loaded by an earlier version lacks columns added since: they are added, empty, so that every rule can run on it."""
    for key, t in TABLE.items():
        have = {r[1] for r in con.execute("PRAGMA table_info(%s)" % t)}
        if have:
            for col in _schema(key):
                name, kind = col.split(" ", 1)
                if name not in have:
                    con.execute("ALTER TABLE %s ADD COLUMN %s %s" % (t, name, kind))
    con.commit()


def prescan_values(path, runs, max_rows=None, say=None):
    """Read rows until every ambiguous run has shown the needed number of value-bearing columns (or the file
    ends). Returns the set of header indices seen with a value."""
    seen = set()
    if not runs:
        return seen
    need = {tuple(r): n for r, n in runs}
    watch = [x for r, _ in runs for x in r]
    with open(path, "r", encoding="utf-8-sig", errors="replace", newline="") as fh:
        rd = read_csv(fh, path)
        next(rd, None)
        for n, row in enumerate(rd, 1):
            for x in watch:
                if x < len(row) and row[x] != "":
                    seen.add(x)
            if all(sum(1 for x in r if x in seen) >= k for r, k in need.items()):
                break
            if max_rows and n >= max_rows:
                break
            if say and n % 20000 == 0:
                say(n)
    return seen


def _schema(file_key):
    cols = []
    seen = set()
    for _, sql, _ in KEYS[file_key]:
        if sql in seen:
            continue
        seen.add(sql)
        cols.append("%s %s" % (sql, "TEXT" if sql in TEXT_COLS else "INTEGER"))
    return cols


def create_tables(con, file_key):
    t = TABLE[file_key]
    con.execute("DROP TABLE IF EXISTS %s" % t)
    con.execute("CREATE TABLE %s (rowid_file INTEGER PRIMARY KEY, %s, parent INTEGER, parent_level TEXT, "
                "relation TEXT, dur_ps INTEGER, raw TEXT)" % (t, ", ".join(_schema(file_key))))
    con.execute("CREATE INDEX ix_%s_parent ON %s (parent_level, parent)" % (t, t))


def load_file(con, file_key, path, limit=None, progress=None):
    """Stream one CSV into its table. Returns the load report (dict)."""
    t = TABLE[file_key]
    keys = KEYS[file_key]
    fb = open(path, "rb")
    with io.TextIOWrapper(fb, encoding="utf-8-sig", errors="replace", newline="") as fh:   # fb.tell() = bytes consumed, for the progress bar
        rd = read_csv(fh, path)
        header = next(rd, None)
        if header is None:
            return {"file": file_key, "path": path, "rows": 0, "error": "empty file"}
        has_value = prescan_values(path, ambiguous_columns(file_key, header),
                                   say=(lambda k: progress(file_key, 0, 0, "checking which columns hold values, {:,} lines so far".format(k))) if progress else None)
        al = align_header(file_key, header, has_value)
        create_tables(con, file_key)
        # typed columns present in this file
        typed = []
        sql_cols = []
        for cname, sql, fn in keys:
            if cname in al.positions and sql not in sql_cols:
                sql_cols.append(sql)
            if cname in al.positions:
                typed.append((al.positions[cname], sql, fn, cname))
        if not sql_cols:             # a binary capture, or some other table: nothing here can be read as this level
            return {"file": file_key, "path": path, "rows": 0, "error": "none of the columns of this level are in the file: is it a CSV export of the analyzer?"}
        # every named column (for raw)
        named = sorted(al.positions.items(), key=lambda kv: kv[1])
        named += [(h, i) for i, h in al.unknown]
        # the analyzer's blank spacer columns are kept too: a value under a blank header cell is stored under the
        # column's position ("column 23"), so nothing of the file is ever dropped (owner's rule 2026-11-03)
        named += [("column %d" % (i + 1), i) for i in al.separators]
        ins = "INSERT INTO %s (rowid_file, %s, raw) VALUES (%s)" % (
            t, ", ".join(sql_cols), ", ".join(["?"] * (len(sql_cols) + 2)))
        unread = {}
        blanks = {sql: 0 for sql in sql_cols}
        n = 0
        con.commit()
        nworkers = worker_count()
        if nworkers > 1 and not limit and os.path.getsize(path) >= PARALLEL_MIN_BYTES:
            # ---- parallel: chunks parsed by worker processes, inserted here in file order
            with open(path, "rb") as fb2:
                fb2.readline()                     # the header line (a BOM, if any, sits inside it)
                start = fb2.tell()
            chunks = plan_chunks(path, start)
            typed_w = [(idx, sql, fn, cname) for idx, sql, fn, cname in typed]
            main_db = next((r[2] for r in con.execute("PRAGMA database_list") if r[1] == "main"), "")
            tmp_dir = os.path.dirname(main_db) if main_db and main_db != ":memory:" else os.path.dirname(path)
            tmp_dir, in_memory = chunk_folder(tmp_dir)
            ctx = multiprocessing.get_context("spawn")
            col_list = ", ".join(sql_cols)
            # a pool that notices a dead worker: multiprocessing.Pool waits for ever when the operating system kills one (out of memory), this one raises BrokenProcessPool
            pool = concurrent.futures.ProcessPoolExecutor(max_workers=min(nworkers, max(1, len(chunks))), mp_context=ctx, initializer=worker_starts)
            try:
                wave = max(1, nworkers * WAVE)
                for w0 in range(0, len(chunks), wave):
                    tasks = [(path, a, b, typed_w, named, sql_cols, file_key, os.path.join(tmp_dir, "chunk_%s_%d.sqlite" % (t, w0 + i)))
                             for i, (a, b) in enumerate(chunks[w0:w0 + wave])]
                    for (n_rows, unread_p, blanks_p), task in zip(pool.map(_parse_chunk, tasks), tasks):
                        _merge_unread(unread, unread_p)
                        for sql, k in blanks_p.items():
                            blanks[sql] += k
                        out_db = task[-1]
                        con.execute("ATTACH DATABASE ? AS chunk", (out_db,))
                        con.execute("INSERT INTO %s (rowid_file, %s, raw) SELECT rowid_file + ?, %s, raw FROM chunk.%s ORDER BY rowid_file" % (t, col_list, col_list, t), (n,))
                        con.commit()
                        con.execute("DETACH DATABASE chunk")
                        os.remove(out_db)
                        n += n_rows
                        if progress:
                            progress(file_key, n, task[2])    # the callback may raise to cancel the load
            except concurrent.futures.process.BrokenProcessPool as e:
                raise NoRoom("a worker process reading %s was killed, usually because the machine ran out of memory, so the load stopped by itself." % os.path.basename(path)) from e
            finally:
                pool.shutdown(wait=False, cancel_futures=True)
                if in_memory:
                    shutil.rmtree(tmp_dir, ignore_errors=True)
            al.parallel = {"workers": min(nworkers, max(1, len(chunks))), "chunks": len(chunks)}
        else:
            # ---- serial: the same per-row work, row by row
            batch = []
            rows_buf = []
            said = [time.time()]
            for row in rd:
                rows_buf.append(row)
                if len(rows_buf) >= INSERT_BATCH:
                    parsed = parse_rows(rows_buf, typed, named, sql_cols, unread, blanks)
                    batch = [[n + i + 1] + r for i, r in enumerate(parsed)]
                    con.executemany(ins, batch)
                    n += len(parsed)
                    rows_buf = []
                    if n % COMMIT_EVERY == 0:
                        con.commit()
                    if progress and time.time() - said[0] >= REPORT_SECONDS:
                        said[0] = time.time()
                        progress(file_key, n, fb.tell())      # the callback may raise to cancel the load
                if limit and n + len(rows_buf) >= limit:
                    break
            if rows_buf:
                parsed = parse_rows(rows_buf, typed, named, sql_cols, unread, blanks)
                con.executemany(ins, [[n + i + 1] + r for i, r in enumerate(parsed)])
                n += len(parsed)
        con.commit()
    rep = al.report(file_key)
    rep.update({"file": file_key, "path": path, "rows": n, "unreadable_cells": unread, "blank_key_cells": blanks,
                "typed_columns": sql_cols, "parallel": getattr(al, "parallel", None)})
    done_beat = heartbeat(con, lambda secs: progress(file_key, n, os.path.getsize(path), "indexing the rows, %d s so far" % secs)) if progress else (lambda: None)
    con.execute("CREATE INDEX IF NOT EXISTS ix_%s_t ON %s (t_ps)" % (t, t))
    if file_key == "packets":
        con.execute("CREATE INDEX IF NOT EXISTS ix_pkt_psn ON pkt (dir, psn)")
        con.execute("CREATE INDEX IF NOT EXISTS ix_pkt_tag ON pkt (rid, tag)")
    if file_key == "link":
        con.execute("CREATE INDEX IF NOT EXISTS ix_lnk_psn ON lnk (dir, psn)")
        con.execute("CREATE INDEX IF NOT EXISTS ix_lnk_tag ON lnk (rid, tag)")
    if file_key == "split":
        con.execute("CREATE INDEX IF NOT EXISTS ix_spl_tag ON spl (rid, tag)")
    if file_key == "nvme_transaction":
        con.execute("CREATE INDEX IF NOT EXISTS ix_ntx_q ON ntx (sqid, cid)")
    if file_key == "nvme_command":
        con.execute("CREATE INDEX IF NOT EXISTS ix_cmd_q ON cmd (sqid, cid)")
    con.commit()
    done_beat()
    checkpoint(con)
    if progress:
        progress(file_key, n, os.path.getsize(path))
    return rep


def open_db(path):
    """Connection with the bulk settings: WAL (readers never block the job and the job never blocks the pages),
    no fsync while the job runs, a ~200 MB page cache, sorts and temporary tables spilled to files next to the
    database (not /tmp, which is a RAM disk here), 60 s busy wait."""
    con = sqlite3.connect(path, timeout=60)
    con.execute("PRAGMA page_size=%d" % PAGE_BYTES)        # only a new, empty database takes it; one being resumed keeps its own
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=OFF")                  # NORMAL was measured on 2026-11-10: 45% slower and other programs' saves still stalled; a power cut can damage the file, and the load then says so and is run again
    con.execute("PRAGMA temp_store=FILE")
    con.execute("PRAGMA threads=%d" % SORT_THREADS)
    con.execute("PRAGMA cache_size=-%d" % CACHE_KB)
    con.execute("PRAGMA wal_autocheckpoint=20000")
    d = os.path.dirname(os.path.abspath(path))
    try:
        con.execute("PRAGMA temp_store_directory='%s'" % d.replace("'", "''"))
    except sqlite3.Error:
        pass
    con.execute("CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)")
    return con


def checkpoint(con):
    """Fold the write-ahead log back into the database and truncate it, so the WAL never keeps a copy of a
    whole pass on disk."""
    try:
        con.commit()
        con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    except sqlite3.Error:
        pass


def work_path(db_path):
    return os.path.splitext(db_path)[0] + ".work.sqlite"


def attach_work(con, db_path):
    """Attach the scratch database `w` (hier.work.sqlite next to the staging file). It holds the per-row lookup
    tables of the builder and the rules on disk; it starts empty every time and is deleted by drop_work()."""
    p = work_path(db_path)
    for f in (p, p + "-journal", p + "-wal", p + "-shm"):
        if os.path.exists(f):
            os.remove(f)
    con.commit()
    con.execute("ATTACH DATABASE ? AS w", (p,))
    con.execute("PRAGMA w.journal_mode=OFF")
    con.execute("PRAGMA w.synchronous=OFF")          # the scratch tables are thrown away and rebuilt if the work stops: flushing them only costs time (measured: the tree took twice as long)
    con.execute("PRAGMA w.cache_size=-%d" % CACHE_KB)     # the scratch tables do most of the build's work: the default cache there is 2 MB
    return p


def drop_work(con, db_path):
    p = work_path(db_path)
    try:
        con.commit()
        con.execute("DETACH DATABASE w")
    except sqlite3.Error:
        pass
    for f in (p, p + "-journal", p + "-wal", p + "-shm"):
        if os.path.exists(f):
            os.remove(f)


def set_meta(con, key, value):
    con.execute("INSERT OR REPLACE INTO meta (k, v) VALUES (?, ?)", (key, json.dumps(value)))
    con.commit()


def get_meta(con, key, default=None):
    r = con.execute("SELECT v FROM meta WHERE k = ?", (key,)).fetchone()
    return json.loads(r[0]) if r else default


def load_upload(db_path, files, limit=None, progress=None):
    """files: {file_key: path}. Loads every given file; returns {file_key: report}. Missing levels are simply
    absent from the result (the pages say so)."""
    con = open_db(db_path)
    reports = {}
    for key in C.LEVEL_ORDER:
        if key in files and files[key]:
            reports[key] = load_file(con, key, files[key], limit=limit, progress=progress)
    set_meta(con, "load_reports", reports)
    set_meta(con, "levels_present", [k for k in C.LEVEL_ORDER if k in reports and not reports[k].get("error")])      # an empty file is reported, not a level
    checkpoint(con)
    con.close()
    return reports


def sniff(path, n=3):
    """Header and first rows of a file, for the upload page's preview and for guessing which level a file is."""
    with open(path, "r", encoding="utf-8-sig", errors="replace", newline="") as fh:
        rd = read_csv(fh, path)
        header = next(rd, [])
        rows = []
        for row in rd:
            rows.append(row)
            if len(rows) >= n:
                break
    return header, rows


def guess_level(header):
    """Which level a file is, from its first named header cells."""
    first = [h.strip() for h in header if h and h.strip()][:3]
    starts = {"packets": "Marker", "link": "Link Tra", "split": "Split Tra", "nvme_transaction": "NVMe",
              "nvme_command": "NVMe Cmd"}
    for key, name in sorted(starts.items(), key=lambda kv: -len(kv[1])):
        if first and first[0] == name:
            return key
    if first and first[0] == "Packet":
        return "packets"
    return None
