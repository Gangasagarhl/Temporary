"""The evidence card of one error, and its cause by fixed rules (owner, 2026-11-11: "even if I draw 1,000 lines from above or below, the
causation should always be proper, one; otherwise it keeps on changing").

The card is computed by code from the error's OWN command, never from the window the admin happens to show: the stages its cycle reached
(the NVMe transactions under it, in time order), the time between them and the longest wait, the row just before that wait (where the
defect started), the time it took against the host's limit and against the usual time of its command type in this recording, the link
problems of its own packets, the host's Abort of it (if any), and what else ran and which link events happened during its own interval.
The same error therefore always gets the same card, whatever n and m are; the cause keyword is decided from the card by fixed rules in a
fixed order (the first that applies), so the same card always gives the same cause. The model only explains, in words, around these facts.
"""
import hashlib
import json

from . import terms as TERMS

CARD_VERSION = 1
ABORT_OPC = 0x08
LINK_RULES = ("pkt.link_down", "pkt.speed_change", "pkt.electrical_idle")


def _ps(x):
    return None if x is None else int(x)


def fmt(ps):
    if ps is None:
        return "-"
    a = abs(ps)
    return "%.3f s" % (ps / 1e12) if a >= 1e12 else "%.3f ms" % (ps / 1e9) if a >= 1e9 else "%.3f µs" % (ps / 1e6) if a >= 1e6 else "%d ns" % round(ps / 1e3)


def card(con, f):
    """The evidence card of a finding (an error) from its own command in the tree (an sqlite connection to hier.sqlite)."""
    d = f.get("detail") or {}
    if isinstance(d, str):
        try:
            d = json.loads(d)
        except ValueError:
            d = {}
    cyc = d.get("cycle") or {}
    fields = ((f.get("signature") or {}).get("fields") or {})
    out = {"version": CARD_VERSION, "rule": f.get("rule"), "level": f.get("level"), "error_row": f.get("rowid"), "kind": d.get("kind"),
           "status": fields.get("st"), "reached": cyc.get("reached") or [], "completed": cyc.get("completed"), "stopped_after": cyc.get("stopped_after"),
           "answer": cyc.get("answer"), "nak": cyc.get("nak") or 0, "unacked": cyc.get("unacked") or 0, "packets": cyc.get("tlps"),
           "host_limit_ps": _ps(d.get("host_limit_ps")), "usual_ps": _ps(d.get("usual_bar_ps")), "median_ps": _ps(d.get("median_ps")),
           "times_median": d.get("times_median"), "command": None, "stages": [], "longest_wait": None, "stall_row": None, "abort": None,
           "during": None, "link_events": []}
    cmd_row = f.get("cmd_rowid") or (f.get("rowid") if f.get("level") == "nvme_command" else None)
    if not cmd_row:
        return out
    con.row_factory = __import__("sqlite3").Row
    c = con.execute("SELECT rowid_file, opc, sqid, cid, sct, sc, t_ps, dur_ps FROM cmd WHERE rowid_file=?", (cmd_row,)).fetchone()
    if c is None:
        return out
    c = dict(c)
    t0 = c["t_ps"]
    stages = [dict(r) for r in con.execute("SELECT rowid_file, type, t_ps FROM ntx WHERE parent_level='nvme_command' AND parent=? ORDER BY t_ps, rowid_file", (cmd_row,))]
    prev = t0
    for s in stages:
        s["after_doorbell_ps"] = (s["t_ps"] - t0) if s["t_ps"] is not None and t0 is not None else None
        s["gap_ps"] = (s["t_ps"] - prev) if s["t_ps"] is not None and prev is not None else None
        prev = s["t_ps"] if s["t_ps"] is not None else prev
    end = (t0 + c["dur_ps"]) if (t0 is not None and c.get("dur_ps")) else (stages[-1]["t_ps"] if stages else t0)
    out["command"] = {"row": cmd_row, "opc": c["opc"], "queue": c["sqid"], "id": c["cid"], "doorbell_ps": t0, "end_ps": end, "elapsed_ps": c.get("dur_ps"),
                      "status": [c["sct"], c["sc"]] if c["sct"] is not None else None}
    out["stages"] = [{"row": s["rowid_file"], "what": s["type"], "after_doorbell_ps": s["after_doorbell_ps"], "gap_ps": s["gap_ps"]} for s in stages]
    if len(stages) >= 2:
        w = max(range(1, len(stages)), key=lambda i: (stages[i]["gap_ps"] or 0, -i))
        out["longest_wait"] = {"from_row": stages[w - 1]["rowid_file"], "from_what": stages[w - 1]["type"], "to_row": stages[w]["rowid_file"], "to_what": stages[w]["type"],
                               "ps": stages[w]["gap_ps"]}
    # where the defect started: the last step the command made before its longest wait (completed late), or the last step it reached (stopped)
    if out["completed"] is False and stages:
        last = stages[-1]
        out["stall_row"] = {"level": "nvme_transaction", "row": last["rowid_file"], "what": last["type"], "why": "the last step the command reached; nothing came after it"}
    elif out["longest_wait"]:
        lw = out["longest_wait"]
        out["stall_row"] = {"level": "nvme_transaction", "row": lw["from_row"], "what": lw["from_what"], "why": "the last step before the longest wait (%s)" % fmt(lw["ps"])}
    elif stages:
        out["stall_row"] = {"level": "nvme_transaction", "row": stages[0]["rowid_file"], "what": stages[0]["type"], "why": "the command's first step"}
    # the host's Abort of it: an Abort (admin) sent while it was outstanding
    if t0 is not None and end is not None:
        a = con.execute("SELECT rowid_file, t_ps, sct, sc FROM cmd WHERE opc=? AND sqid=0 AND rowid_file!=? AND t_ps>=? AND t_ps<=? ORDER BY t_ps LIMIT 1",
                        (ABORT_OPC, cmd_row, t0, end)).fetchone()
        if a is not None:
            out["abort"] = {"row": a["rowid_file"], "after_doorbell_ps": a["t_ps"] - t0}
        # what else ran in its own interval, and the link events in it
        other = con.execute("SELECT COUNT(*), SUM(CASE WHEN sct IS NOT NULL THEN 1 ELSE 0 END), SUM(CASE WHEN sqid=? THEN 1 ELSE 0 END) FROM cmd "
                            "WHERE rowid_file!=? AND t_ps>=? AND t_ps<=?", (c["sqid"], cmd_row, t0, end)).fetchone()
        out["during"] = {"commands": other[0] or 0, "completed": other[1] or 0, "same_queue": other[2] or 0, "from_ps": t0, "to_ps": end}
        out["link_events"] = [{"rule": r[0], "row": r[1], "level": r[2]} for r in con.execute(
            "SELECT rule, rowid, level FROM finding WHERE level IN ('packets','link','split') AND t_ps>=? AND t_ps<=? ORDER BY t_ps LIMIT 20", (t0, end))]
    return out


def card_hash(c):
    return hashlib.sha256(json.dumps(c, sort_keys=True, default=str).encode()).hexdigest()[:16]


def decide_cause(c):
    """(cause keyword, the rule that decided it, in words). Fixed rules in a fixed order: the first that applies decides."""
    rule = c.get("rule") or ""
    if rule in LINK_RULES:
        return "link_retraining_recovery", "the rule itself is a link event (%s)" % rule
    if (c.get("nak") or 0) > 0 or (c.get("unacked") or 0) > 0:
        return "link_replay_storm", "the command's own packets were refused or left unacknowledged on the link (Nak %s, unacknowledged %s)" % (c.get("nak"), c.get("unacked"))
    if any(e["rule"] in LINK_RULES for e in c.get("link_events") or []):
        return "link_retraining_recovery", "a link event happened while the command was outstanding (%s)" % ", ".join(sorted({e["rule"] for e in c["link_events"]}))
    ab, med, usual, limit = c.get("abort"), c.get("median_ps"), c.get("usual_ps"), c.get("host_limit_ps")
    if ab is not None:
        t = ab["after_doorbell_ps"]
        if med and t < med:
            return "host_abort_by_tool_or_test", ("the host sent the Abort %s after the doorbell, sooner than this command type usually takes here (median %s); "
                                                  "the host's driver limit is %s, so the Abort came from a program or test, not from the drive's slowness") % (fmt(t), fmt(med), fmt(limit))
        if limit and t < limit:
            return "host_timer_shorter_than_drive_latency", ("the host sent the Abort %s after the doorbell, after the usual time (median %s) but long before "
                                                             "the driver's limit (%s): the host's own timer was shorter than the drive's answer") % (fmt(t), fmt(med), fmt(limit))
        return "host_reset_or_driver_recovery", "the host aborted the command after its limit (%s)" % fmt(limit)
    reached = c.get("reached") or []
    if c.get("completed") is False:
        st = c.get("stopped_after")
        if st in ("doorbell", None) and "fetched" not in reached:
            return "firmware_stall", "the drive never fetched the command (it stopped after the doorbell); the link was clean"
        return "firmware_stall", "the drive took the command and stopped making progress (it stopped after the %s); its packets were all acknowledged" % (st or "last step")
    if "completed" in reached and "interrupt" not in reached:
        return "interrupt_lost", "the completion entry was written but no interrupt followed it"
    if "interrupt" in reached and "consumed" not in reached:
        return "host_missed_completion", "the interrupt was sent but the host never took the completion (no head doorbell)"
    st = TERMS._status(c.get("status"))
    if st and st[0] == 2:
        return "media_retry_or_read_error", "the drive answered with a media error status (%s)" % st[2]
    if usual and (c.get("command") or {}).get("elapsed_ps") and c["command"]["elapsed_ps"] > usual:
        return "device_internal_delay", ("the drive answered after %s, longer than this command type's usual bar here (%s), with a clean link; "
                                         "the recording cannot tell why inside the drive") % (fmt(c["command"]["elapsed_ps"]), fmt(usual))
    return "unknown_cause", "none of the fixed rules applies to this evidence"


def facts(c, term, cause_key):
    """The parts of the isolation code states itself (what, when, where, which, who), the same for the same card."""
    cmd = c.get("command") or {}
    cz = TERMS.cause_of(cause_key) or {}
    st = c.get("stall_row") or {}
    elapsed = cmd.get("elapsed_ps")
    what = term["name"] + ("; it took %s" % fmt(elapsed) if elapsed else "")
    if c.get("median_ps"):
        what += " (this command type usually takes %s here; the host's driver limit is %s)" % (fmt(c["median_ps"]), fmt(c.get("host_limit_ps")))
    when = ("from %s (the doorbell) to %s in the recording" % (fmt(cmd.get("doorbell_ps")), fmt(cmd.get("end_ps")))) if cmd.get("doorbell_ps") is not None else "-"
    if c.get("abort"):
        when += "; the host's Abort came %s after the doorbell (row %s)" % (fmt(c["abort"]["after_doorbell_ps"]), c["abort"]["row"])
    where = ("NVMe command row %s (queue %s, id %s)" % (cmd.get("row"), cmd.get("queue"), cmd.get("id"))) if cmd else "row %s, %s level" % (c.get("error_row"), c.get("level"))
    if c.get("stages"):
        where += "; its NVMe transactions: " + ", ".join("row %s %s" % (s["row"], s["what"]) for s in c["stages"])
    which = ("NVMe transaction row %s (%s): %s" % (st.get("row"), st.get("what"), st.get("why"))) if st else where
    who = cz.get("side_words") or "not decided"
    return {"what": what, "when": when, "where": where, "which": which, "who": who}
