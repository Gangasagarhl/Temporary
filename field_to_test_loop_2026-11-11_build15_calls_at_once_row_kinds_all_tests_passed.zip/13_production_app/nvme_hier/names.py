"""Plain names for the numbers the exports carry: opcodes, NVMe transaction parts, TLP classes.

Status code names (SCT/SC) come from the research note 03_errors_nvme_command.json once it is in data/; this
module only carries the tables that do not need a source beyond the NVMe Base and NVM Command Set specifications'
opcode lists (NVMe Base 2.0 Figure 138 admin opcodes; NVM Command Set 1.0 Figure 28 I/O opcodes).
"""

IO_OPC = {
    0x00: "Flush", 0x01: "Write", 0x02: "Read", 0x04: "Write Uncorrectable", 0x05: "Compare", 0x08: "Write Zeroes",
    0x09: "Dataset Management", 0x0C: "Verify", 0x0D: "Reservation Register", 0x0E: "Reservation Report",
    0x11: "Reservation Acquire", 0x15: "Reservation Release", 0x19: "Copy",
}
ADMIN_OPC = {
    0x00: "Delete I/O Submission Queue", 0x01: "Create I/O Submission Queue", 0x02: "Get Log Page",
    0x04: "Delete I/O Completion Queue", 0x05: "Create I/O Completion Queue", 0x06: "Identify", 0x08: "Abort",
    0x09: "Set Features", 0x0A: "Get Features", 0x0C: "Asynchronous Event Request", 0x0D: "Namespace Management",
    0x10: "Firmware Commit", 0x11: "Firmware Image Download", 0x14: "Device Self-test", 0x15: "Namespace Attachment",
    0x18: "Keep Alive", 0x19: "Directive Send", 0x1A: "Directive Receive", 0x1C: "Virtualization Management",
    0x1D: "NVMe-MI Send", 0x1E: "NVMe-MI Receive", 0x20: "Capacity Management", 0x24: "Lockdown",
    0x7C: "Doorbell Buffer Config", 0x7F: "Fabrics Commands", 0x80: "Format NVM", 0x81: "Security Send",
    0x82: "Security Receive", 0x84: "Sanitize", 0x86: "Get LBA Status",
}
# which direction the data moves, for the part-of-command logic (h2d = host to device = Write-like)
IO_DATA_DIR = {0x01: "h2d", 0x02: "d2h", 0x04: None, 0x05: "h2d", 0x08: None, 0x09: "h2d", 0x0C: None, 0x0D: "h2d",
               0x0E: "d2h", 0x11: "h2d", 0x15: "h2d", 0x19: "h2d"}
ADMIN_DATA_DIR = {0x02: "d2h", 0x06: "d2h", 0x09: "h2d", 0x0A: "d2h", 0x0D: "h2d", 0x11: "h2d", 0x15: "h2d",
                  0x1D: "h2d", 0x1E: "d2h", 0x81: "h2d", 0x82: "d2h", 0x86: "d2h"}


def opcode_name(opc, sqid):
    """sqid 0 is the admin queue; every other queue carries I/O commands."""
    if opc is None:
        return "-"
    table = ADMIN_OPC if sqid == 0 else IO_OPC
    name = table.get(opc, "opcode 0x%02X" % opc)
    return name + (" (admin)" if sqid == 0 else "")


def is_admin(sqid):
    return sqid == 0


def data_direction(opc, sqid):
    return (ADMIN_DATA_DIR if sqid == 0 else IO_DATA_DIR).get(opc)


# The part of a command an NVMe transaction belongs to, from the analyzer's Type text. The real Type strings are
# matched by key words so the exact wording of the export does not matter; unknown types keep their text.
PART_KEYWORDS = [
    ("doorbell", "doorbell"),
    ("submission", "entry fetch"),
    ("completion", "completion entry"),
    ("prp", "PRP list fetch"),
    ("sgl", "SGL fetch"),
    ("data", "data transfer"),
    ("interrupt", "interrupt"),
    ("msi", "interrupt"),
    ("register", "controller register"),
    ("index", "controller register"),
]
PART_KEY = {"doorbell": "dbl", "entry fetch": "entry", "completion entry": "cqe", "PRP list fetch": "prp",
            "SGL fetch": "prp", "data transfer": "data", "interrupt": "irq", "controller register": "reg"}


def part_of_command(type_text):
    t = (type_text or "").lower()
    for kw, part in PART_KEYWORDS:
        if kw in t:
            return part
    return type_text or "unknown"


def part_key(type_text):
    return PART_KEY.get(part_of_command(type_text), "none")


# TLP classes for the link/split levels
POSTED = {"MWr(32)", "MWr(64)", "Msg", "MsgD", "DMWr"}
NON_POSTED = {"MRd(32)", "MRd(64)", "MRdLk(32)", "MRdLk(64)", "IORd", "IOWr", "CfgRd0", "CfgRd1", "CfgWr0", "CfgWr1",
              "FetchAdd", "Swap", "CAS"}
COMPLETIONS = {"Cpl", "CplD", "CplLk", "CplDLk"}


def tlp_class(tlp_type):
    t = (tlp_type or "").strip()
    if t in COMPLETIONS:
        return "completion"
    if t in POSTED:
        return "posted"
    if t in NON_POSTED:
        return "non-posted"
    base = t.split("(")[0]
    if base in ("MWr", "Msg", "MsgD"):
        return "posted"
    if base in ("MRd", "MRdLk", "IORd", "IOWr", "CfgRd0", "CfgRd1", "CfgWr0", "CfgWr1"):
        return "non-posted"
    if base.startswith("Cpl"):
        return "completion"
    return "other"
