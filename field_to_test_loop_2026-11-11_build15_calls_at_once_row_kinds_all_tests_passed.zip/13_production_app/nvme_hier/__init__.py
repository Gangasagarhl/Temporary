"""NVMe-level hierarchy: load the five Teledyne LeCroy per-level CSV exports, build the containment tree
(command > NVMe transaction > split transaction > link transaction > packet), compute durations, apply the
deterministic rules, and serve the tree, the summary and the filters to the pages.

Project statement: 09_defect_isolation_research/research_notes/nvme_app/00_project_statement.md
Modules
  columns   canonical column lists per file (from data/lecroy_export_columns.json) and the label-less renames
  parse     value parsers: time stamps and deltas to picoseconds, hex/decimal integers, data sizes
  loader    header alignment (separator columns dropped, label-less headers named), SQLite staging per level
"""
