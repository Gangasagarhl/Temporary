"""NVMe-over-PCIe device/host model and the healthy building blocks of a capture.

A command is a Python generator: it emits TLPs through the Engine and yields a
delay in picoseconds.  The Sched interleaves many generators so concurrent
commands, DLLPs and background traffic share the two link directions the way a
real capture does.  Every fault hook used by the episodes is a keyword in the
`f` dict passed to nvme_cmd(); with an empty dict the command is spec-correct.
"""
import heapq
import json
import struct

from tracegen_core import (COL, DN, HOST_RID, MS, NS, RC_CPL_ID, SEC, SSD_RID, UP, US,
                           Engine, fmt_ts)

MPS = 256
MRRS = 512
LBA = 512
PAGE = 4096


class Sched:
    def __init__(self, eng):
        self.eng = eng
        self.h = []
        self.n = 0

    def spawn(self, gen, delay=0):
        self.n += 1
        heapq.heappush(self.h, (self.eng.now + int(delay), self.n, gen))

    def run(self):
        e = self.eng
        while self.h:
            t, _, g = heapq.heappop(self.h)
            e.at_least(t)
            try:
                d = next(g)
            except StopIteration:
                continue
            if d is None:
                d = 0
            self.n += 1
            heapq.heappush(self.h, (e.now + int(d), self.n, g))
        e.flush(e.now)


# ----------------------------------------------------------------------------- byte builders
def sqe(opc, cid, nsid=1, prp1=0, prp2=0, cdw10=0, cdw11=0, cdw12=0, cdw13=0, cdw14=0,
        cdw15=0, fuse=0, psdt=0, mptr=0, cdw2=0, cdw3=0):
    dw0 = (opc & 0xFF) | ((fuse & 3) << 8) | ((psdt & 3) << 14) | ((cid & 0xFFFF) << 16)
    return struct.pack("<IIIIQQQIIIIII", dw0, nsid & 0xFFFFFFFF, cdw2, cdw3, mptr, prp1, prp2,
                       cdw10 & 0xFFFFFFFF, cdw11 & 0xFFFFFFFF, cdw12 & 0xFFFFFFFF, cdw13, cdw14, cdw15)


def cqe(cid, sqid, sqhd, phase, sc=0, sct=0, dnr=0, more=0, crd=0, dw0=0, dw1=0):
    st = (sc & 0xFF) | ((sct & 7) << 8) | ((crd & 3) << 11) | ((more & 1) << 13) | ((dnr & 1) << 14)
    dw3 = (cid & 0xFFFF) | ((phase & 1) << 16) | (st << 17)
    return struct.pack("<IIII", dw0, dw1, (sqhd & 0xFFFF) | ((sqid & 0xFFFF) << 16), dw3)


# ----------------------------------------------------------------------------- state
class SQ:
    def __init__(self, qid, base, size, cqid):
        self.qid, self.base, self.size, self.cqid = qid, base, size, cqid
        self.tail = 0
        self.head = 0
        self.cid = 0
        self.open = {}


class CQ:
    def __init__(self, qid, base, size, vec):
        self.qid, self.base, self.size, self.vec = qid, base, size, vec
        self.tail = 0
        self.phase = 1
        self.head = 0


class Nvme:
    def __init__(self, rng):
        self.rng = rng
        self.bar0 = 0xFCE00000
        self.dstrd = 0
        self.sq, self.cq = {}, {}
        self.cc = 0
        self.csts = 0
        self.mdts_bytes = 512 * 1024
        self.msix_addr = {v: 0xFEE00000 | ((v % 8) << 12) for v in range(65)}
        self.msix_data = {v: 0x4020 + v for v in range(65)}
        self.dev_tag = 0
        self.dev_open_tags = set()
        self.host_tag = 0
        self.nsze = 0x3A386030     # 500 GB of 512-byte LBAs
        self.fr = "2B2QGXA7"
        self.enabled = False
        self.aer_cids = []

    def db(self, qid, cq=False):
        return self.bar0 + 0x1000 + (2 * qid + (1 if cq else 0)) * (4 << self.dstrd)

    def next_dev_tag(self):
        for _ in range(256):
            t = self.dev_tag
            self.dev_tag = (self.dev_tag + 1) & 0xFF
            if t not in self.dev_open_tags:
                self.dev_open_tags.add(t)
                return t
        return self.dev_tag

    def next_host_tag(self):
        t = self.host_tag
        self.host_tag = (self.host_tag + 1) & 0x1F
        return t


class Ctx:
    """Everything an episode needs: engine, scheduler, models, logs, index."""

    def __init__(self, path, seed, data_format, event_log_path):
        self.eng = Engine(path, seed, data_format)
        self.rng = self.eng.rng
        self.sched = Sched(self.eng)
        self.nv = Nvme(self.rng)
        self.ver = {}            # 4 KiB unit -> data version (-1 = deallocated -> zeros)
        self.pool = [bytes(self.rng.getrandbits(8) for _ in range(PAGE)) for _ in range(32)]
        self.evlog = open(event_log_path, "w", encoding="utf-8")
        self.cur_episode = None
        self.keys = []
        self.stop_bg = False
        self.phase = "boot"
        self.slba_cursor = 0x200000

    # -------------------------------------------------------------- logging
    def log(self, kind, **kw):
        rec = {"t": fmt_ts(self.eng.now), "t_ps": self.eng.now, "packet_next": self.eng.pkt,
               "phase": self.phase, "event": kind}
        if self.cur_episode:
            rec["episode"] = self.cur_episode
        rec.update(kw)
        self.evlog.write(json.dumps(rec, sort_keys=True) + "\n")

    def key(self, n, note):
        self.keys.append((n, note))
        return n

    # -------------------------------------------------------------- memory model
    def alloc(self, npages, low=None):
        if low is None:
            low = self.rng.random() < 0.3
        out = []
        base = (self.rng.randrange(0x00100, 0x7F000) << 12) if low else \
            (self.rng.randrange(0x100000, 0x480000) << 12)
        contiguous = self.rng.random() < 0.5
        for i in range(npages):
            if contiguous:
                out.append(base + i * PAGE)
            else:
                out.append(((self.rng.randrange(0x00100, 0x7F000) << 12) if low else
                            (self.rng.randrange(0x100000, 0x480000) << 12)))
        return out

    def qalloc(self, nbytes):
        """Queue memory comes from a reserved region (>= 0x4_8000_0000) that data buffers never use."""
        if not hasattr(self, "_qptr") or self._qptr > 0x4A0000000:
            self._qptr = 0x480000000 + self.rng.randrange(0, 64) * 0x10000
        base = self._qptr
        self._qptr += (nbytes + 0xFFFF) & ~0xFFFF
        return base

    def data(self, slba, off, n, version=None):
        unit = (slba * LBA + off) // PAGE
        v = self.ver.get(unit, 0) if version is None else version
        if v < 0:
            return bytes(n)
        blk = self.pool[(unit * 2654435761 + v * 40503) % len(self.pool)]
        o = (slba * LBA + off) % PAGE
        if o + n <= PAGE:
            return blk[o:o + n]
        return (blk[o:] + blk)[:n]

    # -------------------------------------------------------------- primitive TLP helpers
    def mmio_wr(self, addr, value, length=1, fbe=0xF, lbe=None, payload=None, owner=None):
        pl = payload if payload is not None else int(value).to_bytes(4 * length, "little")
        self.eng.owner = owner
        return self.eng.tlp(DN, "MWr(32)", length, rid=HOST_RID, tag=0, addr=addr, fbe=fbe,
                            lbe=lbe, payload=pl)[0]

    def mmio_rd(self, addr, length=1, value=0, status="SC", lat=None, no_cpl=False, owner=None):
        tag = self.nv.next_host_tag()
        self.eng.owner = owner
        n = self.eng.tlp(DN, "MRd(32)", length, rid=HOST_RID, tag=tag, addr=addr)[0]
        if no_cpl:
            return n, None
        yield lat if lat is not None else self.rng.randint(450, 800) * NS
        self.eng.owner = owner
        if status != "SC":
            c = self.eng.tlp(UP, "Cpl", 0, rid=HOST_RID, tag=tag, cid=SSD_RID, status=status,
                             bytecnt=4 * length, lwr=addr & 0x7F)[0]
        else:
            pl = int(value).to_bytes(4 * length, "little")
            c = self.eng.tlp(UP, "CplD", length, rid=HOST_RID, tag=tag, cid=SSD_RID,
                             bytecnt=4 * length, lwr=addr & 0x7F, payload=pl)[0]
        return n, c

    def cfg_rd(self, reg, value, status="SC", devid=SSD_RID, cpl_id=SSD_RID, lat=None, kind="CfgRd0"):
        tag = self.nv.next_host_tag()
        n = self.eng.tlp(DN, kind, 1, rid=HOST_RID, tag=tag, devid=devid, reg="0x%03X" % reg)[0]
        yield lat if lat is not None else self.rng.randint(350, 700) * NS
        if status == "SC":
            c = self.eng.tlp(UP, "CplD", 1, rid=HOST_RID, tag=tag, cid=cpl_id, bytecnt=4, lwr=0,
                             payload=int(value & 0xFFFFFFFF).to_bytes(4, "little"))[0]
        elif status is None:
            c = None
        else:
            c = self.eng.tlp(UP, "Cpl", 0, rid=HOST_RID, tag=tag, cid=cpl_id, status=status, bytecnt=4, lwr=0)[0]
        return n, c

    def cfg_wr(self, reg, value, status="SC", devid=SSD_RID, fbe=0xF):
        tag = self.nv.next_host_tag()
        n = self.eng.tlp(DN, "CfgWr0", 1, rid=HOST_RID, tag=tag, devid=devid, reg="0x%03X" % reg,
                         fbe=fbe, payload=int(value & 0xFFFFFFFF).to_bytes(4, "little"))[0]
        yield self.rng.randint(350, 700) * NS
        c = None
        if status is not None:
            c = self.eng.tlp(UP, "Cpl", 0, rid=HOST_RID, tag=tag, cid=SSD_RID, status=status, bytecnt=4, lwr=0)[0]
        return n, c

    def dev_mrd(self, addr, length, tag, rid=SSD_RID, owner=None, **kw):
        kind = "MRd(64)" if addr >= (1 << 32) else "MRd(32)"
        self.eng.owner = owner
        return self.eng.tlp(UP, kind, length, rid=rid, tag=tag, addr=addr,
                            lbe=(0 if length == 1 else 0xF), **kw)[0]

    def dev_mwr(self, addr, payload, rid=SSD_RID, nbytes=None, owner=None, **kw):
        kind = "MWr(64)" if addr >= (1 << 32) else "MWr(32)"
        n = nbytes if nbytes is not None else len(payload)
        length = max(1, (n + 3) // 4)
        self.eng.owner = owner
        return self.eng.tlp(UP, kind, length, rid=rid, tag=0, addr=addr, payload=payload,
                            nbytes=n, lbe=(0 if length == 1 else 0xF), **kw)[0]

    def host_cpld(self, tag, addr, payload, status="SC", chunk=MPS, ep=False, cid=RC_CPL_ID,
                  gap=None, bytecnt_bias=0, lwr_override=None, stall_after=None, owner=None, **kw):
        """Root-complex completion(s) for a device MRd; split on MPS-aligned boundaries."""
        total = len(payload)
        if status != "SC":
            self.eng.owner = owner
            n = self.eng.tlp(DN, "Cpl", 0, rid=SSD_RID, tag=tag, cid=cid, status=status,
                             bytecnt=total, lwr=addr & 0x7F, **kw)[0]
            self.nv.dev_open_tags.discard(tag)
            return [n]
        out = []
        off = 0
        a = addr
        while off < total:
            nxt = min(total, off + (chunk - (a % chunk)))
            part = payload[off:nxt]
            self.eng.owner = owner
            n = self.eng.tlp(DN, "CplD", len(part) // 4 or 1, rid=SSD_RID, tag=tag, cid=cid,
                             bytecnt=total - off + bytecnt_bias,
                             lwr=(a & 0x7F) if lwr_override is None else lwr_override,
                             payload=part, ep=ep, **kw)[0]
            out.append(n)
            a += len(part)
            off = nxt
            if stall_after is not None and len(out) >= stall_after:
                return out
            if gap:
                yield gap
        self.nv.dev_open_tags.discard(tag)
        return out

    def msi(self, vec, owner=None):
        return self.dev_mwr(self.nv.msix_addr[vec], self.nv.msix_data[vec].to_bytes(4, "little"), owner=owner)

    def ring_sq(self, qid, value=None, owner=None, **kw):
        sq = self.nv.sq[qid]
        return self.mmio_wr(self.nv.db(qid), sq.tail if value is None else value, owner=owner, **kw)

    def ring_cq(self, cqid, value=None, owner=None):
        cq = self.nv.cq[cqid]
        return self.mmio_wr(self.nv.db(cqid, cq=True), cq.tail if value is None else value, owner=owner)

    # -------------------------------------------------------------- the NVMe command
    def nvme_cmd(self, qid, opc, nsid=1, slba=0, nlb=7, xfer=None, nbytes=None, cdw10=None,
                 cdw11=0, cdw12=None, cdw13=0, dw0=0, f=None, out=None, payload_out=None,
                 fetch_lat=None, media_lat=None, note=None):
        """Generator for one NVMe command; xfer in {'d2h','h2d',None}.

        f (fault hooks): status=(sct,sc,dnr[,more,crd]) | no_cqe | no_fetch | fetch_lat |
        no_data | cqe_delay | no_msix | msix_first | data_after_cqe | dup_cqe=(delay,status) |
        cqe_cid | cqe_sqid | cqe_sqhd | phase_flip | prp1_off | prp2_off | db_value |
        db_fbe | extra_mwr=(addr,len) | ep_data | data_rid | cqe_rid | cid | sqe_override |
        stall_data_after | data_ro | cqe_dw0 | data_mps | mrd_len | list_overread
        """
        f = f or {}
        rng = self.rng
        nv = self.nv
        sq = nv.sq[qid]
        cq = nv.cq[sq.cqid]
        if "cid" in f:
            cid = f["cid"]
        else:
            sq.cid = (sq.cid + 1) & 0xFFFF
            cid = sq.cid
        if nbytes is None:
            nbytes = (nlb + 1) * LBA if xfer else 0
        npages = (nbytes + PAGE - 1) // PAGE if nbytes else 0
        pages = self.alloc(max(npages, 1)) if npages else []
        prp1 = (pages[0] + f.get("prp1_off", 0)) if pages else 0
        prp_list = None
        if npages == 2:
            prp2 = pages[1] + f.get("prp2_off", 0)
        elif npages > 2:
            prp_list = self.alloc(1)[0]
            prp2 = prp_list
        else:
            prp2 = 0
        if "prp1" in f:
            prp1 = f["prp1"]
        if cdw10 is None:
            cdw10 = slba & 0xFFFFFFFF
            cdw11 = slba >> 32
        if cdw12 is None:
            cdw12 = nlb if xfer and qid != 0 else 0
        s = f.get("sqe_override") or sqe(opc, cid, nsid, prp1, prp2, cdw10, cdw11, cdw12, cdw13,
                                         fuse=f.get("fuse", 0), cdw2=f.get("cdw2", 0),
                                         mptr=f.get("mptr", 0))
        slot = sq.tail
        sq.tail = (sq.tail + 1) % sq.size
        sq.open[cid] = (opc, slba, nlb)
        rec = out if out is not None else {}
        self.cmd_seq = getattr(self, "cmd_seq", 0) + 1
        own = {"c": self.cmd_seq, "q": qid, "cid": cid}
        O = lambda part, i="": dict(own, part=part, i=i)      # noqa: E731 - owner tag for one emission
        rec.update({"qid": qid, "cid": cid, "opc": opc, "slba": slba, "nlb": nlb, "bytes": nbytes,
                    "prp1": prp1, "prp2": prp2, "note": note, "seq": self.cmd_seq})
        db = None if f.get("skip_doorbell") else self.ring_sq(qid, f.get("db_value"), fbe=f.get("db_fbe", 0xF), owner=O("dbl"))
        rec["pkt_doorbell"] = db
        if f.get("no_fetch"):
            self.log("nvme_submit_not_fetched", **rec)
            return rec
        yield f.get("fetch_lat") or fetch_lat or rng.randint(400, 1200) * NS
        tag = nv.next_dev_tag()
        rec["pkt_fetch"] = self.dev_mrd(sq.base + slot * 64, 16, tag, owner=O("entry"))
        yield rng.randint(500, 900) * NS
        cps = yield from self.host_cpld(tag, sq.base + slot * 64, s, owner=O("entry"))
        rec["pkt_sqe"] = cps[0]
        sq.head = (slot + 1) % sq.size
        if f.get("fetched_then_hang"):
            self.log("nvme_cmd_lost_in_controller", **rec)
            return rec
        # PRP list
        if prp_list is not None and not f.get("no_data"):
            yield rng.randint(200, 600) * NS
            t2 = nv.next_dev_tag()
            ln = (npages - 1) * 2
            if f.get("list_overread"):
                ln = f["list_overread"]
            self.dev_mrd(prp_list, ln, t2, owner=O("prp"))
            yield rng.randint(500, 900) * NS
            lst = b"".join(p.to_bytes(8, "little") for p in pages[1:])
            lst = (lst + bytes(ln * 4))[:ln * 4]
            yield from self.host_cpld(t2, prp_list, lst, owner=O("prp"))
        st = f.get("status", (0, 0, 0))
        data_pkts = []
        late_chunks = []
        # data phase
        if (xfer and not f.get("no_data") and st[0] == 0 and st[1] == 0) or (xfer and f.get("data_even_if_error")):
            if xfer == "d2h":
                yield f.get("media_lat") or media_lat or (rng.randint(8, 15) * US if rng.random() < 0.3
                                                          else rng.randint(45, 90) * US)
                chunk = f.get("data_mps", MPS)
                total = nbytes + f.get("extra_bytes", 0)
                off = 0
                payload_bytes = payload_out if payload_out is not None else None
                ci = 0
                stop_at = f.get("stall_data_after")
                while off < total:
                    pg = off // PAGE
                    if pg < len(pages):
                        a = pages[pg] + (off % PAGE) + (f.get("prp1_off", 0) if pg == 0 else 0)
                    else:
                        a = pages[-1] + PAGE + (off % PAGE)
                    n = min(chunk, total - off, PAGE - (a % PAGE) if not f.get("cross_4k") else chunk)
                    pl = self.data(slba, off, n, f.get("read_version"))
                    if f.get("content") is not None:          # fixed device-to-host content (e.g. an Identify data structure)
                        pl = bytes(f["content"][off:off + n]).ljust(n, b"\0")
                    ca = f.get("corrupt_at")
                    if ca is not None and off <= ca < off + n:
                        b = bytearray(pl)
                        b[ca - off] ^= 0x04
                        pl = bytes(b)
                    if payload_bytes is not None:
                        payload_bytes.append(pl)
                    if f.get("data_after_cqe") and total - off <= f["data_after_cqe"] * chunk:
                        late_chunks.append((a, pl))
                    else:
                        data_pkts.append(self.dev_mwr(a, pl, rid=f.get("data_rid", SSD_RID),
                                                      ep=f.get("ep_data", False), attr=f.get("data_attr", ""),
                                                      owner=O("data", pg)))
                    off += n
                    ci += 1
                    if stop_at and ci >= stop_at:
                        break
                    if off % PAGE == 0:
                        yield rng.randint(0, 40) * NS
            else:
                yield rng.randint(600, 1500) * NS
                off = 0
                mrd_len = f.get("mrd_len", MRRS)
                while off < nbytes:
                    wave = []
                    for _ in range(8):
                        if off >= nbytes:
                            break
                        pg = off // PAGE
                        a = pages[pg] + (off % PAGE) + (f.get("prp1_off", 0) if pg == 0 else 0)
                        n = min(mrd_len, nbytes - off, PAGE - (a % PAGE) if not f.get("cross_4k") else mrd_len)
                        t = nv.next_dev_tag()
                        data_pkts.append(self.dev_mrd(a, n // 4, t, rid=f.get("data_rid", SSD_RID), owner=O("data", pg)))
                        wave.append((t, a, off, n))
                        off += n
                    yield rng.randint(500, 900) * NS
                    for t, a, o, n in wave:
                        pl = self.data(slba, o, n, f.get("host_version", 0))
                        od = O("data", o // PAGE)
                        if f.get("ep_data") and o == 0:
                            ps = yield from self.host_cpld(t, a, pl, ep=True, owner=od)
                            rec["pkt_poisoned"] = ps[0]
                        elif f.get("cpl_status") and o == 0:
                            ps = yield from self.host_cpld(t, a, pl, status=f["cpl_status"], owner=od)
                            rec["pkt_bad_cpl"] = ps[0]
                        else:
                            yield from self.host_cpld(t, a, pl, owner=od)
                if xfer == "h2d" and qid != 0:
                    for i in range(0, nbytes, PAGE):
                        self.ver[(slba * LBA + i) // PAGE] = f.get("write_version", 1 + self.rng.randint(0, 999))
            if f.get("extra_mwr"):
                a, n = f["extra_mwr"]
                yield rng.randint(20, 200) * NS
                rec["pkt_stray"] = self.dev_mwr(a, bytes(n), owner=O("stray"))
        rec["data_pkts"] = (data_pkts[0], data_pkts[-1]) if data_pkts else None
        # completion
        if f.get("no_cqe"):
            self.log("nvme_cqe_never_posted", **rec)
            return rec
        if xfer == "h2d" or not xfer:
            yield f.get("cqe_delay") or (rng.randint(8, 20) * US if xfer else
                                         (f.get("exec_lat") or rng.randint(3, 12) * US))
        else:
            yield f.get("cqe_delay") or rng.randint(200, 600) * NS
        sct, sc, dnr = st[0], st[1], st[2]
        more = st[3] if len(st) > 3 else 0
        crd = st[4] if len(st) > 4 else 0
        cslot = cq.tail
        phase = cq.phase ^ (1 if f.get("phase_flip") else 0)
        cbytes = cqe(f.get("cqe_cid", cid), f.get("cqe_sqid", qid), f.get("cqe_sqhd", sq.head), phase,
                     sc, sct, dnr, more, crd, dw0=f.get("cqe_dw0", dw0))
        cq.tail = (cq.tail + 1) % cq.size
        if cq.tail == 0:
            cq.phase ^= 1
        if f.get("msix_first"):
            rec["pkt_msix"] = self.msi(cq.vec, owner=O("irq"))
            yield rng.randint(200, 400) * NS
        rec["pkt_cqe"] = self.dev_mwr(cq.base + cslot * 16, cbytes, rid=f.get("cqe_rid", SSD_RID), owner=O("cqe"))
        rec["status"] = "SCT%d/SC0x%02X%s" % (sct, sc, " DNR" if dnr else "")
        sq.open.pop(cid, None)
        for a, pl in late_chunks:
            yield rng.randint(100, 300) * NS
            rec.setdefault("pkt_late_data", self.dev_mwr(a, pl, owner=O("data", "late")))
        if not f.get("msix_first") and not f.get("no_msix"):
            yield rng.randint(30, 80) * NS
            rec["pkt_msix"] = self.msi(cq.vec, owner=O("irq"))
        if f.get("dup_cqe"):
            dly, dst = f["dup_cqe"]
            yield dly
            dslot = cq.tail
            cq.tail = (cq.tail + 1) % cq.size
            rec["pkt_dup_cqe"] = self.dev_mwr(cq.base + dslot * 16,
                                              cqe(cid, qid, sq.head, cq.phase, dst[1], dst[0], dst[2]), owner=O("cqe", "dup"))
            yield 60 * NS
            self.msi(cq.vec, owner=O("irq", "dup"))
        if f.get("post_cqe_dma"):
            yield rng.randint(1, 3) * US
            rec["pkt_post_dma"] = self.dev_mwr(prp1 if prp1 else self.alloc(1)[0], bytes(256), owner=O("stray", "post"))
        if f.get("no_cq_doorbell"):
            self.log("nvme_cmd_done", **rec)
            return rec
        yield f.get("db_lat") or rng.randint(1500, 4000) * NS
        self.ring_cq(sq.cqid, f.get("cq_db_value"), owner=O("cqdbl"))
        cq.head = cq.tail
        self.log("nvme_cmd_done", **{k: v for k, v in rec.items() if k != "data_pkts"})
        return rec

    def run(self, *gens):
        for g in gens:
            self.sched.spawn(g)
        self.sched.run()

    def do(self, gen):
        """Run a single generator to completion through the scheduler and return its value."""
        box = {}

        def wrap():
            box["v"] = yield from gen
        self.sched.spawn(wrap())
        self.sched.run()
        return box.get("v")

    # -------------------------------------------------------------- convenience commands
    def read(self, qid=1, slba=None, nlb=7, f=None, **kw):
        if slba is None:
            slba = self.next_lba(nlb)
        return self.nvme_cmd(qid, 0x02, 1, slba, nlb, "d2h", f=f, **kw)

    def write(self, qid=1, slba=None, nlb=7, f=None, **kw):
        if slba is None:
            slba = self.next_lba(nlb)
        return self.nvme_cmd(qid, 0x01, 1, slba, nlb, "h2d", f=f, **kw)

    def flush_cmd(self, qid=1, f=None, lat=None):
        f = dict(f or {})
        f.setdefault("exec_lat", lat or self.rng.randint(60, 400) * US)
        return self.nvme_cmd(qid, 0x00, 1, 0, 0, None, f=f, cdw10=0, cdw12=0)

    def dsm(self, qid=1, ranges=((0x100000, 8),), f=None):
        """Dataset Management / Deallocate: command + range-list DMA read."""
        f = dict(f or {})
        nr = len(ranges)
        body = b"".join(struct.pack("<IIQ", 0, n, s) for s, n in ranges)
        gen = self._dsm(qid, nr, body, ranges, f)
        return gen

    def _dsm(self, qid, nr, body, ranges, f):
        rng = self.rng
        nv = self.nv
        sq = nv.sq[qid]
        cq = nv.cq[sq.cqid]
        sq.cid = (sq.cid + 1) & 0xFFFF
        cid = sq.cid
        buf = self.alloc(1)[0]
        s = sqe(0x09, cid, 1, buf, 0, cdw10=nr - 1, cdw11=0x4)
        slot = sq.tail
        sq.tail = (sq.tail + 1) % sq.size
        if f.get("not_sent"):
            self.log("host_discard_dropped_before_device", ranges=[list(r) for r in ranges])
            return {}
        db = self.ring_sq(qid)
        yield rng.randint(400, 1200) * NS
        tag = nv.next_dev_tag()
        fetch = self.dev_mrd(sq.base + slot * 64, 16, tag)
        yield rng.randint(500, 900) * NS
        yield from self.host_cpld(tag, sq.base + slot * 64, s)
        sq.head = (slot + 1) % sq.size
        yield rng.randint(300, 800) * NS
        t2 = nv.next_dev_tag()
        ln = f.get("range_dw", nr * 4)
        lst = self.dev_mrd(buf, ln, t2)
        yield rng.randint(500, 900) * NS
        yield from self.host_cpld(t2, buf, (body + bytes(ln * 4))[:ln * 4])
        if not f.get("dealloc_ignored"):
            for sl, n in ranges:
                for u in range((sl * LBA) // PAGE, ((sl + n) * LBA + PAGE - 1) // PAGE):
                    self.ver[u] = -1
        yield f.get("exec_lat") or rng.randint(20, 80) * US
        st = f.get("status", (0, 0, 0))
        cslot = cq.tail
        cq.tail = (cq.tail + 1) % cq.size
        if cq.tail == 0:
            cq.phase ^= 1
        c = self.dev_mwr(cq.base + cslot * 16, cqe(cid, qid, sq.head, cq.phase if cq.tail else cq.phase ^ 1,
                                                   st[1], st[0], st[2]))
        yield rng.randint(30, 80) * NS
        self.msi(cq.vec)
        yield rng.randint(1500, 4000) * NS
        self.ring_cq(sq.cqid)
        rec = {"qid": qid, "cid": cid, "opc": 9, "pkt_doorbell": db, "pkt_fetch": fetch,
               "pkt_range_read": lst, "pkt_cqe": c, "ranges": [list(r) for r in ranges]}
        self.log("nvme_dsm_deallocate", **rec)
        return rec

    def admin(self, opc, cdw10=0, cdw11=0, xfer=None, nbytes=None, f=None, nsid=0, dw0=0, **kw):
        return self.nvme_cmd(0, opc, nsid, 0, 0, xfer, nbytes=nbytes, cdw10=cdw10, cdw11=cdw11,
                             cdw12=0, dw0=dw0, f=f, **kw)

    def next_lba(self, nlb):
        s = self.slba_cursor
        self.slba_cursor += ((nlb + 8) // 8) * 8
        if self.slba_cursor > 0x30000000:
            self.slba_cursor = 0x200000
        return s

    # -------------------------------------------------------------- link layer sequences
    def train(self, final_speed=16.0, width=4, from_detect=True, ts_n=3, eq_reject_lane=None,
              eq_fail_speed=None, nfts="255", note="link training"):
        """Detect -> Polling -> Configuration -> L0 (2.5 GT/s) -> Recovery speed changes."""
        e = self.eng
        L = e.link
        if from_detect:
            L.speed = 2.5
            L.width = width
            e.event("Electrical Idle Exit")
            for st in ("PAD",):
                for _ in range(ts_n):
                    e.os(DN, "TS1", link="PAD", lane="PAD", nfts=nfts, rate=L.max_speed)
                    e.os(UP, "TS1", link="PAD", lane="PAD", nfts=nfts, rate=L.max_speed)
                for _ in range(ts_n):
                    e.os(DN, "TS2", link="PAD", lane="PAD", nfts=nfts, rate=L.max_speed)
                    e.os(UP, "TS2", link="PAD", lane="PAD", nfts=nfts, rate=L.max_speed)
            for _ in range(2):
                e.os(DN, "TS1", link="0", lane="PAD", nfts=nfts, rate=L.max_speed)
                e.os(UP, "TS1", link="0", lane="PAD", nfts=nfts, rate=L.max_speed)
            for _ in range(2):
                e.os(DN, "TS1", link="0", lane="0", nfts=nfts, rate=L.max_speed)
                e.os(UP, "TS1", link="0", lane="0", nfts=nfts, rate=L.max_speed)
            for _ in range(ts_n):
                e.os(DN, "TS2", link="0", lane="0", nfts=nfts, rate=L.max_speed)
                e.os(UP, "TS2", link="0", lane="0", nfts=nfts, rate=L.max_speed)
            e.event("Link Up", DN)
            e.event("Link Up", UP)
            yield from self.dl_init()
        for sp in (8.0, 16.0):
            if sp > final_speed:
                break
            yield from self.speed_change(sp, eq_reject_lane=eq_reject_lane if sp == eq_fail_speed else None,
                                         fail=(sp == eq_fail_speed))
            if sp == eq_fail_speed:
                break
        self.log("link_trained", speed=L.speed, width=L.width, note=note)

    def dl_init(self, fc_stall=False):
        e = self.eng
        e.rx_drop = {UP: False, DN: False}
        e.retry = {UP: e.retry[UP].__class__(), DN: e.retry[DN].__class__()}
        e.psn = {UP: 0, DN: 0}
        e.last_good_rx = {UP: 4095, DN: 4095}
        if e.link.speed >= 16.0 or e.link.max_speed >= 16.0:
            e.dllp(DN, "Data Link Feature", feat_sup="0x000001", feat_ack="0")
            e.dllp(UP, "Data Link Feature", feat_sup="0x000001", feat_ack="1")
            e.dllp(DN, "Data Link Feature", feat_sup="0x000001", feat_ack="1")
        adv = {DN: {"P": (128, 2048), "NP": (64, 64), "Cpl": (0, 0)},
               UP: {"P": (32, 512), "NP": (16, 16), "Cpl": (0, 0)}}
        rounds = ("InitFC1", "InitFC2") if not fc_stall else ("InitFC1", "InitFC1", "InitFC1", "InitFC1")
        for rnd in rounds:
            for _ in range(2):
                for d in (DN, UP):
                    for typ in ("P", "NP", "Cpl"):
                        h, dd = adv[d][typ]
                        e.dllp(d, "%s-%s" % (rnd, typ), vc=0, hdr=h, data=dd)
            yield 200 * NS
        # receiver in direction d advertises credits for TLPs flowing towards it
        e.set_fc_limits(UP, "P", *adv[DN]["P"])
        e.set_fc_limits(UP, "NP", *adv[DN]["NP"])
        e.set_fc_limits(DN, "P", *adv[UP]["P"])
        e.set_fc_limits(DN, "NP", *adv[UP]["NP"])
        e.link_up = True

    def speed_change(self, sp, eq_reject_lane=None, fail=False):
        e = self.eng
        e.os(DN, "EIOS")
        e.os(UP, "EIOS")
        yield 300 * NS
        old = e.link.speed
        e.link.speed = sp
        e.event("Speed Change: %.1f GT/s" % sp)
        e.os(DN, "EIEOS")
        e.os(UP, "EIEOS")
        if sp >= 8.0:
            for ph in (0, 1, 2, 3):
                e.os(DN, "TS1", eq="0 %02d 10" % int(bin(ph)[2:]), pre=6 if ph >= 2 else "",
                     cur=36 if ph >= 2 else "", post=6 if ph >= 2 else "")
                if eq_reject_lane is not None and ph == 2:
                    for _ in range(6):
                        e.os(UP, "TS1", lane=str(eq_reject_lane), eq="1 10 10", pre=8, cur=30, post=10)
                        yield 2 * MS
                        e.os(DN, "TS1", lane=str(eq_reject_lane), eq="0 10 10", pre=6, cur=36, post=6)
                    if fail:
                        e.event("Equalization Phase 3 Timeout (Lane %d)" % eq_reject_lane)
                        yield 12 * MS
                        e.link.speed = old
                        e.event("Speed Change: %.1f GT/s" % old)
                        e.os(DN, "EIEOS")
                        e.os(UP, "EIEOS")
                        for _ in range(2):
                            e.os(DN, "TS1")
                            e.os(UP, "TS1")
                            e.os(DN, "TS2")
                            e.os(UP, "TS2")
                        e.os(DN, "SDS")
                        e.os(UP, "SDS")
                        return
                e.os(UP, "TS1", eq="0 %02d 10" % int(bin(ph)[2:]), pre=6 if ph >= 2 else "",
                     cur=36 if ph >= 2 else "", post=6 if ph >= 2 else "")
                yield (300 if ph < 2 else 900) * US if sp >= 16 else (200 if ph < 2 else 700) * US
        for _ in range(3):
            e.os(DN, "TS1")
            e.os(UP, "TS1")
        for _ in range(3):
            e.os(DN, "TS2")
            e.os(UP, "TS2")
        if sp >= 8.0:
            e.os(DN, "SDS")
            e.os(UP, "SDS")
        yield 200 * NS

    def recovery(self, n_ts=2, reason=None, eieos=True):
        """Short Recovery.RcvrLock/RcvrCfg excursion back to L0 (no speed change)."""
        e = self.eng
        if eieos:
            e.os(UP, "EIEOS")
            e.os(DN, "EIEOS")
        for _ in range(n_ts):
            e.os(UP, "TS1")
            e.os(DN, "TS1")
        for _ in range(n_ts):
            e.os(UP, "TS2")
            e.os(DN, "TS2")
        if e.link.speed >= 8.0:
            e.os(UP, "SDS")
            e.os(DN, "SDS")
        if reason:
            self.log("ltssm_recovery", reason=reason)
        yield 100 * NS

    def aspm_l1(self, idle_ps, l12=True, exit_lat=None, ack=True, by_host=False):
        """ASPM L1 (optionally L1.2 with CLKREQ#) entry, idle, and exit through Recovery."""
        e = self.eng
        yield 2 * US
        for _ in range(3):
            e.dllp(UP, "PM_Active_State_Request_L1")
            yield 100 * NS
        if ack:
            for _ in range(2):
                e.dllp(DN, "PM_Request_Ack")
                yield 60 * NS
        e.os(UP, "EIOS")
        e.os(DN, "EIOS")
        e.event("Electrical Idle")
        e.link.state = "L1"
        if l12:
            yield 5 * US
            e.event("CLKREQ# Deasserted")
        yield idle_ps
        if l12:
            e.event("CLKREQ# Asserted")
            yield exit_lat if exit_lat is not None else self.rng.randint(18, 60) * US
        e.event("Electrical Idle Exit")
        e.link.state = "L0"
        yield from self.recovery(n_ts=2)

    def ltr(self, snoop_val=3, snoop_scale=4, req=1, ns_val=3, ns_scale=4):
        scales = {0: "1 ns", 1: "32 ns", 2: "1024 ns", 3: "32768 ns", 4: "1048576 ns", 5: "33554432 ns"}
        ex = {"Snoop": "Yes", "Requirement (Snoop)": str(req), "Scale (Snoop)": scales[snoop_scale],
              "Value (Snoop)": str(snoop_val), "No-Snoop": "Yes", "Requirement (No-Snoop)": str(req),
              "Scale (No-Snoop)": scales[ns_scale], "Value (No-Snoop)": str(ns_val)}
        return self.eng.tlp(UP, "Msg", 0, rid=SSD_RID, tag=0, routing="Local",
                            msgcode="Latency_Tolerance_Reporting", extra=ex)[0]

    def msg(self, d, code, routing, rid=None, data=None, extra=None):
        rid = rid or (SSD_RID if d == UP else HOST_RID)
        if data is not None:
            return self.eng.tlp(d, "MsgD", len(data) // 4, rid=rid, tag=0, routing=routing,
                                msgcode=code, payload=data, extra=extra)[0]
        return self.eng.tlp(d, "Msg", 0, rid=rid, tag=0, routing=routing, msgcode=code, extra=extra)[0]

    # -------------------------------------------------------------- platform sequences
    def power_on_preamble(self):
        """Mirrors the opening rows of the user's real capture (CLKREQ#/Link Up/Down flicker)."""
        e = self.eng
        e.now = 161897042 * 1000
        e.event("CLKREQ# Asserted", marker="Marker")
        e.advance(150398 * NS)
        e.event("Link Up", DN)
        e.advance(482728 * NS)
        e.event("Link Up", UP)
        e.advance(64110 * NS)
        e.event("Link Down", UP)
        e.advance(646 * NS)
        e.event("Link Down", DN)
        e.advance(10318 * NS)
        e.event("CLKREQ# Deasserted")
        e.advance(228124 * US)
        e.event("CLKREQ# Asserted")
        e.advance(152580 * NS)
        self.log("platform_power_on", note="PERST# released; refclk running")

    CFG = {0x000: 0x00101B36, 0x004: 0x00100000, 0x008: 0x01080202, 0x00C: 0x00000000,
           0x02C: 0x00101B36, 0x034: 0x00000040, 0x040: 0x5BC35001, 0x050: 0x0080B011,
           0x070: 0x00020010, 0x074: 0x10008FC2, 0x078: 0x00102810, 0x07C: 0x0047AC44,
           0x080: 0x10440040, 0x094: 0x00000000, 0x0B0: 0x00000000, 0x100: 0x14820001,
           0x104: 0x00000000, 0x108: 0x00000000, 0x10C: 0x00462030, 0x110: 0x00000000,
           0x114: 0x00002000}

    def enumerate(self, full=True, bar_probe_value=0xFFFFC004):
        """Firmware/OS PCI enumeration of the SSD function."""
        regs = [0x000, 0x008, 0x00C, 0x02C, 0x034, 0x040, 0x050, 0x070, 0x074, 0x07C, 0x080]
        if not full:
            regs = [0x000, 0x008, 0x034]
        for r in regs:
            yield from self.cfg_rd(r, self.CFG.get(r, 0))
            yield self.rng.randint(1, 4) * US
        # BAR0 sizing (64-bit, 16 KiB, non-prefetchable)
        yield from self.cfg_wr(0x010, 0xFFFFFFFF)
        yield from self.cfg_rd(0x010, bar_probe_value)
        yield from self.cfg_wr(0x014, 0xFFFFFFFF)
        yield from self.cfg_rd(0x014, 0xFFFFFFFF)
        yield from self.cfg_wr(0x010, self.nv.bar0 | 0x4)
        yield from self.cfg_wr(0x014, 0x00000000)
        if full:
            yield from self.cfg_rd(0x100, self.CFG[0x100])
            yield from self.cfg_rd(0x104, 0)
            yield from self.cfg_rd(0x114, 0x00002000)
            yield from self.cfg_wr(0x078, 0x00102830)   # Device Control: MPS 256, MRRS 512, AER reporting on
            yield from self.cfg_wr(0x080, 0x10440042)   # Link Control: ASPM L1 enable, CCC
            yield from self.cfg_wr(0x098, 0x00000400)   # Device Control 2: LTR Mechanism Enable
        yield from self.cfg_wr(0x004, 0x00100406)       # Command: Memory + Bus Master, INTx disabled
        yield from self.cfg_rd(0x0B0, 0x80200011)       # MSI-X control
        yield from self.cfg_wr(0x0B0, 0x80200011 | (1 << 31))
        self.log("pci_enumerated", bar0="0x%08X" % self.nv.bar0)

    def msix_program(self, nvec=5):
        tbl = self.nv.bar0 + 0x2000
        for v in range(nvec):
            pl = (self.nv.msix_addr[v].to_bytes(4, "little") + bytes(4) +
                  self.nv.msix_data[v].to_bytes(4, "little") + bytes(4))
            self.mmio_wr(tbl + 16 * v, 0, length=4, lbe=0xF, payload=pl)
            yield self.rng.randint(200, 600) * NS

    def controller_disable(self, rdy_polls=2):
        nv = self.nv
        self.mmio_wr(nv.bar0 + 0x14, 0x00460000)
        nv.enabled = False
        for i in range(rdy_polls):
            yield 1 * MS
            yield from self.mmio_rd(nv.bar0 + 0x1C, 1, 1 if i < rdy_polls - 1 else 0)
        nv.sq.clear()
        nv.cq.clear()
        nv.dev_open_tags.clear()

    def controller_init(self, nq=4, admin_size=32, io_size=1024, rdy_polls=3, identify=True,
                        create_io=True, aer=1, cap_to=20, rdy_never=False, note="nvme init",
                        keep_addrs=None):
        """Linux nvme-pci style bring-up: CAP/VS, AQA/ASQ/ACQ, CC.EN=1, CSTS.RDY, Identify, queues."""
        nv = self.nv
        rng = self.rng
        cap = 0x3FF | (1 << 16) | (cap_to << 24) | (1 << 37) | (4 << 52)
        yield from self.mmio_rd(nv.bar0 + 0x00, 2, cap)
        yield rng.randint(2, 6) * US
        yield from self.mmio_rd(nv.bar0 + 0x08, 1, 0x00020100)
        yield rng.randint(2, 6) * US
        yield from self.mmio_rd(nv.bar0 + 0x1C, 1, 0)
        self.mmio_wr(nv.bar0 + 0x14, 0x00460000)       # nvme_disable_ctrl(): CC.EN=0 before admin setup
        yield rng.randint(2, 6) * US
        if keep_addrs:
            asq, acq = keep_addrs
        else:
            asq = self.qalloc(admin_size * 64)
            acq = self.qalloc(admin_size * 16)
        self.mmio_wr(nv.bar0 + 0x24, ((admin_size - 1) << 16) | (admin_size - 1))
        yield 400 * NS
        self.mmio_wr(nv.bar0 + 0x28, asq, length=2, lbe=0xF, payload=asq.to_bytes(8, "little"))
        yield 400 * NS
        self.mmio_wr(nv.bar0 + 0x30, acq, length=2, lbe=0xF, payload=acq.to_bytes(8, "little"))
        nv.sq[0] = SQ(0, asq, admin_size, 0)
        nv.cq[0] = CQ(0, acq, admin_size, 0)
        yield 600 * NS
        nv.cc = 0x00460001
        self.mmio_wr(nv.bar0 + 0x14, nv.cc)
        for i in range(rdy_polls):
            yield rng.randint(900, 2500) * US
            ready = (i == rdy_polls - 1) and not rdy_never
            yield from self.mmio_rd(nv.bar0 + 0x1C, 1, 1 if ready else 0)
        if rdy_never:
            return
        nv.enabled = True
        yield from self.msix_program(nq + 1)
        if identify:
            yield from self.admin(0x06, cdw10=1, xfer="d2h", nbytes=4096, f={"content": identify_controller_bytes()})   # Identify Controller
            yield from self.admin(0x06, cdw10=2, xfer="d2h", nbytes=4096)          # Active NS list
            yield from self.nvme_cmd(0, 0x06, 1, 0, 0, "d2h", nbytes=4096, cdw10=0, cdw12=0)  # Identify NS
            yield from self.admin(0x09, cdw10=0x07, cdw11=((nq - 1) << 16) | (nq - 1),
                                  dw0=((nq - 1) << 16) | (nq - 1))  # Set Features: Number of Queues
        if create_io:
            for q in range(1, nq + 1):
                base_c = self.qalloc(io_size * 16)
                base_s = self.qalloc(io_size * 64)
                yield from self.admin(0x05, cdw10=((io_size - 1) << 16) | q, cdw11=(q << 16) | 0x3,
                                      f={"prp1": base_c}, note="Create I/O CQ %d" % q)
                nv.cq[q] = CQ(q, base_c, io_size, q)
                yield from self.admin(0x01, cdw10=((io_size - 1) << 16) | q, cdw11=(q << 16) | 0x1,
                                      f={"prp1": base_s}, note="Create I/O SQ %d" % q)
                nv.sq[q] = SQ(q, base_s, io_size, q)
        for _ in range(aer):
            yield from self.admin_async_event_request()
        self.log("nvme_controller_ready", note=note, queues=nq)

    def admin_async_event_request(self):
        """AER (0Ch) is submitted and fetched; its CQE arrives only when an event occurs."""
        nv = self.nv
        sq = nv.sq[0]
        sq.cid = (sq.cid + 1) & 0xFFFF
        cid = sq.cid
        slot = sq.tail
        sq.tail = (sq.tail + 1) % sq.size
        self.ring_sq(0)
        yield self.rng.randint(400, 1200) * NS
        tag = nv.next_dev_tag()
        self.dev_mrd(sq.base + slot * 64, 16, tag)
        yield self.rng.randint(500, 900) * NS
        yield from self.host_cpld(tag, sq.base + slot * 64, sqe(0x0C, cid, 0))
        sq.head = (slot + 1) % sq.size
        nv.aer_cids.append(cid)
        return cid

    def post_aen(self, dw0, then_log=None, rae=0, log_bytes=512):
        """Complete an outstanding AER with an event, optionally followed by the host's log read."""
        nv = self.nv
        cq = nv.cq[0]
        if not nv.aer_cids:
            yield from self.admin_async_event_request()
        cid = nv.aer_cids.pop(0)
        slot = cq.tail
        cq.tail = (cq.tail + 1) % cq.size
        if cq.tail == 0:
            cq.phase ^= 1
        n = self.dev_mwr(cq.base + slot * 16, cqe(cid, 0, nv.sq[0].head, cq.phase, dw0=dw0))
        yield 60 * NS
        self.msi(0)
        yield self.rng.randint(2, 5) * US
        self.ring_cq(0)
        if then_log is not None:
            yield self.rng.randint(20, 80) * US
            numd = log_bytes // 4 - 1
            yield from self.admin(0x02, cdw10=(numd << 16) | (rae << 15) | then_log, xfer="d2h",
                                  nbytes=log_bytes, nsid=0xFFFFFFFF)
            yield self.rng.randint(5, 20) * US
            yield from self.admin_async_event_request()
        return n

    def shutdown(self):
        nv = self.nv
        yield from self.flush_cmd(1)
        for q in sorted(k for k in nv.sq if k):
            yield from self.admin(0x00, cdw10=q, note="Delete I/O SQ")
            yield from self.admin(0x04, cdw10=q, note="Delete I/O CQ")
        self.mmio_wr(nv.bar0 + 0x14, nv.cc | (1 << 14))
        for v in (0x5, 0x5, 0x9):
            yield self.rng.randint(80, 300) * MS
            yield from self.mmio_rd(nv.bar0 + 0x1C, 1, v)
        yield 40 * MS
        self.msg(DN, "PME_Turn_Off", "Broadcast")
        yield self.rng.randint(8, 20) * US
        self.msg(UP, "PME_TO_Ack", "Gathered")
        yield 3 * US
        for _ in range(3):
            self.eng.dllp(UP, "PM_Enter_L23")
            yield 100 * NS
        self.eng.dllp(DN, "PM_Request_Ack")
        yield 1 * US
        self.eng.os(UP, "EIOS")
        self.eng.os(DN, "EIOS")
        self.eng.event("Electrical Idle")
        yield 2 * MS
        self.eng.event("Link Down", DN)
        self.eng.event("Link Down", UP)
        self.eng.event("CLKREQ# Deasserted")


def identify_controller_bytes(vid=0x1234, ssvid=0x1234, sn="SYN0000000000001", mn="Synthetic NVMe SSD 1TB", fr="FW-A"):
    """NVMe Identify Controller data structure (CNS 01h): VID 01:00, SSVID 03:02, SN 23:04, MN 63:24, FR 71:64 (ASCII,
    space padded). The synthetic device identifies itself so that the analyser can read the device from the trace."""
    b = bytearray(4096)
    b[0:2] = vid.to_bytes(2, "little")
    b[2:4] = ssvid.to_bytes(2, "little")
    b[4:24] = sn.encode("ascii")[:20].ljust(20, b" ")
    b[24:64] = mn.encode("ascii")[:40].ljust(40, b" ")
    b[64:72] = fr.encode("ascii")[:8].ljust(8, b" ")
    return bytes(b)
