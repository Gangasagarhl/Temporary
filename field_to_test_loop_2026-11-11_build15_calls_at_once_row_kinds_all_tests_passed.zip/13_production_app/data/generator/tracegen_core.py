"""Core engine for the synthetic LeCroy-style PCIe/NVMe trace generator.

Everything that touches the wire lives here: the integer picosecond clock, the
per-direction link layer (PSN, retry buffer, Ack/Nak, flow-control credits),
row projection onto the 113-column schema, CRC fields and the streaming CSV
writer.  NVMe semantics live in tracegen_nvme.py, failure episodes in
tracegen_episodes.py.

Conventions inferred from the user's real export (final_113_columns.csv):
  * Time Stamp  "SSSS.ffffffffffffs"  (picoseconds, display truncated to 10 ps)
  * Time Delta  gap from THIS packet to the NEXT row: end-of-packet -> next start
                when the next row is in the same direction, start -> start when
                it is in the other direction (or either row is an event).
  * DATA        payload size summary "256 B" (or hex bytes with --data-format hex)
  * Header bits that are zero (TC, TD, EP, Attr, AT ...) are left blank.
"""
import csv
import hashlib
import heapq
import random
import zlib
from collections import deque

HEADER = [
    "Marker", "Packet", "Link Dir", "Ord.Set Type", "DLLP Type", "TLP Type", "Link Event", "PSN",
    "AckNak Seq Num", "VC ID", "HdrScale", "HdrFC", "DataScale", "DataFC", "Feature Ack",
    "Feature Support", "TC", "LN", "TH", "NW", "TD", "EP", "Attributes", "AT", "Length",
    "RequesterID", "Tag", "CompleterID", "Address", "DeviceID", "Register", "st BE", "Last BE",
    "Cpl Status", "Byte Cnt", "BCM", "Lwr Addr", "Msg Routing", "Message Code", "TS Link",
    "TS Lane", "N_FTS", "Training Control", "TS Data Rate", "TS Gen3 Eq Control",
    "TS Gen3 Pre-Cursor", "TS Gen3 Cursor", "TS Gen3 Post-Cursor", "PMUX Channel ID",
    "PMUX Metadata", "Snoop", "Requirement (Snoop)", "Scale (Snoop)", "Value (Snoop)", "No-Snoop",
    "Requirement (No-Snoop)", "Scale (No-Snoop)", "Value (No-Snoop)", "PTM Master Time[63:32]",
    "PTM Master Time[31:0]", "PTM Propagation Delay", "ARP Command", "Slave Address",
    "Target Address", "Device Slave Address", "Assign Address", "Read", "Write", "Byte Count",
    "Address Type", "PEC Support", "UDID Version", "Silicon Revision ID", "Vendor ID", "Device ID",
    "ZONE", "IPMI", "ASF", "OEM", "SMBus Version", "Sub Vendor ID", "Sub Device ID",
    "Vendor Specific ID", "PEC", "LCRC", "ECRC", "CRC 16", "DATA", "Time Delta", "Time Stamp",
    "Jammer Phase", "Action", "Jammer Target Packet", "Jammer Result Packet", "CXL Pkt Type",
    "CXL Pkt Subtype", "OpCode", "CQID", "UQID", "Address [51:6]", "NT", "RSP_PRE", "MESI",
    "ChunkValid", "Bogus", "Poison", "Go-Err", "MetaField", "MetaValue", "SnpType",
    "LLCTRL Pkt Subtype", "ALMP VLSM State", "ALMP VLSM Target",
]
assert len(HEADER) == 113
NCOL = 113
COL = {name: i for i, name in enumerate(HEADER)}

UP, DN = "Upstream", "Downstream"
OTHER = {UP: DN, DN: UP}

# Topology (bus:dev:func printed as in the sample export: 3-digit bus, 2-digit dev, 1-digit fn)
SSD_RID = "002:00:0"
RC_CPL_ID = "000:02:4"      # completer of host-memory reads, as seen in the sample
HOST_RID = "000:00:0"       # requester of CPU MMIO / config requests (modeling assumption)

TS_RATES = {2.5: "2.5 GT/s", 5.0: "2.5 GT/s, 5.0 GT/s", 8.0: "2.5 GT/s, 5.0 GT/s, 8.0 GT/s",
            16.0: "2.5 GT/s, 5.0 GT/s, 8.0 GT/s, 16.0 GT/s"}

NS = 1000          # ps per ns
US = 1000 * NS
MS = 1000 * US
SEC = 1000 * MS
GRID = 125         # analyzer timestamp granularity observed in the sample (ps)


def fmt_ts(ps):
    ps = (ps // 10) * 10
    return "%04d.%012ds" % (ps // SEC, ps % SEC)


def fmt_delta(ps):
    if ps < 0:
        ps = 0
    if ps < US:
        return "%.3f ns" % (ps / NS)
    if ps < MS:
        return "%.3f us" % (ps / US)
    if ps < SEC:
        return "%.3f ms" % (ps / MS)
    return "%.3f s" % (ps / SEC)


def fmt_addr(a):
    if a < (1 << 32):
        return "%08X" % a
    return "%08X:%08X" % (a >> 32, a & 0xFFFFFFFF)


def be_str(v):
    return format(v & 0xF, "04b")


# --- CRC-16 for DLLPs: polynomial 100Bh, seed FFFFh (PCIe Base 3.2.x DLLP CRC). ------------
def _mk_crc16_table():
    t = []
    for i in range(256):
        c = i << 8
        for _ in range(8):
            c = ((c << 1) ^ 0x100B) if c & 0x8000 else (c << 1)
        t.append(c & 0xFFFF)
    return t


_CRC16_T = _mk_crc16_table()


def crc16_dllp(b):
    c = 0xFFFF
    for x in b:
        c = ((c << 8) & 0xFFFF) ^ _CRC16_T[((c >> 8) ^ x) & 0xFF]
    return (~c) & 0xFFFF


DLLP_CODE = {"ACK": 0x00, "NAK": 0x10, "PM_Enter_L1": 0x20, "PM_Enter_L23": 0x21,
             "PM_Active_State_Request_L1": 0x23, "PM_Request_Ack": 0x24,
             "Vendor Specific": 0x30, "NOP": 0x31, "Data Link Feature": 0x02,
             "InitFC1-P": 0x40, "InitFC1-NP": 0x50, "InitFC1-Cpl": 0x60,
             "InitFC2-P": 0xC0, "InitFC2-NP": 0xD0, "InitFC2-Cpl": 0xE0,
             "UpdateFC-P": 0x80, "UpdateFC-NP": 0x90, "UpdateFC-Cpl": 0xA0}

# Fmt/Type byte per TLP mnemonic (PCIe Base 2.2.1); used only to build header bytes for LCRC.
FMT_TYPE = {"MRd(32)": 0x00, "MRd(64)": 0x20, "MRdLk": 0x01, "MWr(32)": 0x40, "MWr(64)": 0x60,
            "IORd": 0x02, "IOWr": 0x42, "CfgRd0": 0x04, "CfgWr0": 0x44, "CfgRd1": 0x05,
            "CfgWr1": 0x45, "Msg": 0x30, "MsgD": 0x70, "Cpl": 0x0A, "CplD": 0x4A, "CplLk": 0x0B,
            "CplDLk": 0x4B, "FetchAdd": 0x4C, "Swap": 0x4D, "CAS": 0x4E, "DMWr": 0x5B}
POSTED = {"MWr(32)", "MWr(64)", "Msg", "MsgD", "DMWr"}
CPL_TYPES = {"Cpl", "CplD", "CplLk", "CplDLk"}
HDR_BYTES = {"MRd(64)": 16, "MWr(64)": 16, "Msg": 16, "MsgD": 16, "DMWr": 16}


class Link:
    """Negotiated link state; durations follow encoding efficiency (8b/10b vs 128b/130b)."""

    def __init__(self, speed=16.0, width=4):
        self.speed, self.width = speed, width
        self.state = "L0"
        self.max_speed, self.max_width = 16.0, 4

    def bytes_ps(self, nbytes):
        if self.speed >= 8.0:
            ps = nbytes * 8 * 1000 * 130 / (128 * self.speed * self.width)
        else:
            ps = nbytes * 10 * 1000 / (self.speed * self.width)
        return max(GRID, int(-(-ps // GRID)) * GRID)

    def os_ps(self):
        if self.speed >= 8.0:
            return int(-(-(16 * 8 * 1000 * 130 / (128 * self.speed)) // GRID)) * GRID
        return int(16 * 10 * 1000 / self.speed)

    def framing(self):
        # Gen3+: 4-byte STP token carries the sequence number. Gen1/2: STP + 2 seq + END.
        return 4 if self.speed >= 8.0 else 4


class Engine:
    """Streams rows to the CSV in timestamp order and models the data link layer."""

    def __init__(self, path, seed, data_format="summary"):
        self.rng = random.Random(seed)
        self.data_format = data_format
        self.fh = open(path, "w", newline="", encoding="utf-8")
        self.w = csv.writer(self.fh, lineterminator="\n")
        self.w.writerow(HEADER)
        self.link = Link()
        self.now = 0
        self.last_t = 0
        self.busy = {UP: 0, DN: 0}
        self.pkt = 0
        self.prev = None          # (row, t, end, dir)
        self.pending = []         # heap of (t, seq, fn)
        self._pseq = 0
        self.psn = {UP: 0, DN: 0}
        self.retry = {UP: deque(), DN: deque()}      # sender retry buffers: (psn, rowcopy, nbytes, kind)
        self.rx = {UP: deque(), DN: deque()}         # TLPs received from dir d, awaiting Ack: (ready, psn)
        self.ack_sched = {UP: False, DN: False}
        self.ack_mode = {UP: "normal", DN: "normal"}  # normal | hold | late
        self.ack_late_ps = 0
        self.rx_drop = {UP: False, DN: False}         # receiver discarding after a Nak
        self.last_good_rx = {UP: 4095, DN: 4095}
        # flow control (receiver side, credits for TLPs flowing in direction d)
        self.fc_limit = {}
        self.fc_pending = {}
        self.fc_hold = set()       # (dir, type) whose UpdateFC is withheld
        self.fc_every = {UP: 6, DN: 6}
        self.bytes_written = 0
        self.rows = 0
        self.marker_next = None
        self.on_row = None         # hook(pkt, row) used by the episode index
        self.counts = {}
        self.link_up = True
        self.hide_dllp = False     # analyzer display filter: DLLP rows not exported
        self.hide_all = False      # recording paused: nothing is captured or numbered
        # ground truth for the five-level exports: the NVMe command and the part of it that emitted each TLP.
        # Set by the Ctx helpers right before each tlp() call (valid for that one synchronous emission only),
        # cleared after it; Ack/Nak and flow-control DLLPs have no owner (they belong to a link transaction by PSN).
        self.owner = None
        self.owner_writer = None   # csv.writer of the packet_owner sidecar, or None

    # ------------------------------------------------------------------ clock
    def q(self, ps):
        return int(-(-ps // GRID)) * GRID

    def advance(self, ps):
        self.now = self.q(self.now + max(0, int(ps)))
        self.flush(self.now)

    def at_least(self, t):
        if t > self.now:
            self.now = self.q(t)
        self.flush(self.now)

    def schedule(self, t, fn):
        self._pseq += 1
        heapq.heappush(self.pending, (t, self._pseq, fn))

    def flush(self, upto):
        while self.pending and self.pending[0][0] <= upto:
            t, _, fn = heapq.heappop(self.pending)
            fn(t)

    def drain(self):
        while self.pending:
            t, _, fn = heapq.heappop(self.pending)
            fn(t)

    # ------------------------------------------------------------------ row output
    def blank(self):
        return [""] * NCOL

    def _write(self, row, t, dur, d):
        """Place a fully built row at time t; returns packet number."""
        if t < self.last_t:
            t = self.last_t
        if self.hide_all:
            self.last_t = t
            return None
        if self.prev is not None:
            prow, pt, pend, pd = self.prev
            if pd and d and pd == d:
                gap = (t // 10 * 10) - (pend // 10 * 10)
            else:
                gap = (t // 10 * 10) - (pt // 10 * 10)
            prow[COL["Time Delta"]] = fmt_delta(gap)
            self._emit_line(prow)
        n = self.pkt
        self.pkt += 1
        row[COL["Packet"]] = str(n)
        row[COL["Time Stamp"]] = fmt_ts(t)
        if self.marker_next is not None:
            row[0] = self.marker_next
            self.marker_next = None
        self.prev = (row, t, t + dur, d)
        self.last_t = t
        if self.on_row:
            self.on_row(n, row)
        return n

    def _emit_line(self, row):
        self.w.writerow(row)
        self.rows += 1
        # approximate byte accounting (exact size is read from disk at the end)
        self.bytes_written += 113 + sum(len(x) for x in row if x)

    def close(self):
        self.drain()
        if self.prev is not None:
            self._emit_line(self.prev[0])
            self.prev = None
        self.fh.close()

    def _start(self, d, earliest=None):
        t = self.now if earliest is None else max(self.now, earliest)
        if d:
            t = max(t, self.busy[d])
        t = max(t, self.last_t)
        return self.q(t)

    # ------------------------------------------------------------------ events / markers
    def event(self, text, d=None, marker=None, gap_ns=0):
        if gap_ns:
            self.advance(gap_ns * NS)
        self.flush(self.now)
        t = (max(self.now, self.last_t) + NS - 1) // NS * NS
        r = self.blank()
        if d:
            r[COL["Link Dir"]] = d
        r[COL["Link Event"]] = text
        if marker:
            r[0] = marker
        self.now = t
        if text.startswith("Link Down") or (text.startswith("Electrical Idle") and "Exit" not in text):
            self.link_quiesce()
        self._count("EVENT:" + text.split(":")[0])
        return self._write(r, t, 0, None)

    def link_quiesce(self):
        """Link left L0: DLLPs that were scheduled but not yet sent are never transmitted."""
        self.pending = []
        for d in (UP, DN):
            self.rx[d].clear()
            self.ack_sched[d] = False

    def marker(self, text):
        self.marker_next = text

    def _count(self, k):
        self.counts[k] = self.counts.get(k, 0) + 1

    # ------------------------------------------------------------------ ordered sets
    def os(self, d, kind, n=1, link="0", lane="0", nfts="255", tc="0 0 0 0 0 0 00",
           rate=None, eq="0 00 10", pre="", cur="", post="", gap_ps=0):
        first = None
        rate = TS_RATES.get(self.link.max_speed if rate is None else rate, rate)
        for _ in range(n):
            self.flush(self.now)
            t = self._start(d) + gap_ps
            dur = self.link.os_ps()
            r = self.blank()
            r[COL["Link Dir"]] = d
            r[COL["Ord.Set Type"]] = kind
            if kind in ("TS1", "TS2"):
                r[COL["TS Link"]] = link
                r[COL["TS Lane"]] = lane
                r[COL["N_FTS"]] = nfts
                r[COL["Training Control"]] = tc
                r[COL["TS Data Rate"]] = rate
                if self.link.speed >= 8.0 or eq != "0 00 10":
                    r[COL["TS Gen3 Eq Control"]] = eq
                if pre != "":
                    r[COL["TS Gen3 Pre-Cursor"]] = str(pre)
                    r[COL["TS Gen3 Cursor"]] = str(cur)
                    r[COL["TS Gen3 Post-Cursor"]] = str(post)
            self.busy[d] = t + dur
            self.now = t
            n_ = self._write(r, t, dur, d)
            self._count("OS:" + kind)
            if first is None:
                first = n_
        return first

    # ------------------------------------------------------------------ DLLPs
    def dllp(self, d, kind, seq=None, vc=None, hdr=None, data=None, hscale=None, dscale=None,
             feat_sup=None, feat_ack=None, bad_crc=False, t=None):
        if t is None:
            self.flush(self.now)
            t = self._start(d)
        else:
            t = self.q(max(t, self.busy[d], self.last_t))
        dur = self.link.bytes_ps(8)
        r = self.blank()
        r[COL["Link Dir"]] = d
        r[COL["DLLP Type"]] = kind
        b = bytearray(4)
        b[0] = DLLP_CODE.get(kind, 0x31)
        if seq is not None:
            r[COL["AckNak Seq Num"]] = str(seq)
            b[2], b[3] = (seq >> 8) & 0xF, seq & 0xFF
        if vc is not None:
            r[COL["VC ID"]] = str(vc)
        if hdr is not None:
            r[COL["HdrFC"]] = str(hdr)
            r[COL["DataFC"]] = str(data)
            b[1] = (hdr >> 2) & 0x3F
            b[2] = ((hdr & 3) << 6) | ((data >> 8) & 0xF)
            b[3] = data & 0xFF
        if hscale is not None:
            r[COL["HdrScale"]] = str(hscale)
            r[COL["DataScale"]] = str(dscale)
        if feat_sup is not None:
            r[COL["Feature Support"]] = feat_sup
            r[COL["Feature Ack"]] = feat_ack
        if self.hide_dllp:
            self.busy[d] = t + dur
            self._count("DLLP(hidden):" + kind)
            return None
        crc = crc16_dllp(b)
        if bad_crc:
            crc ^= 0x5A3C
        r[COL["CRC 16"]] = "0x%04X" % crc + (" (Bad)" if bad_crc else "")
        self.busy[d] = t + dur
        if t > self.now:
            self.now = t
        self._count("DLLP:" + kind)
        return self._write(r, t, dur, d)

    # ------------------------------------------------------------------ TLPs
    def tlp(self, d, kind, length=0, rid="", tag="", cid="", addr=None, devid="", reg="",
            fbe=0xF, lbe=None, status="", bytecnt=None, lwr=None, routing="", msgcode="",
            payload=None, nbytes=None, td=False, ep=False, tc=0, attr="", at="", th=False,
            bad_lcrc=False, bad_ecrc=False, extra=None, psn=None, consume_fc=True,
            nullified=False, lcrc_text=None, earliest=None, display_bad=False):
        """Emit one TLP. payload: bytes (used for CRC and hex DATA) or None; nbytes: summary size."""
        self.flush(self.now)
        t = self._start(d, earliest)
        if nbytes is None:
            nbytes = len(payload) if payload is not None else (length * 4 if kind in
                                                                ("MWr(32)", "MWr(64)", "CplD", "MsgD", "CplDLk", "DMWr", "IOWr", "CfgWr0", "CfgWr1", "FetchAdd", "Swap", "CAS") else 0)
        hdr = HDR_BYTES.get(kind, 12)
        if kind in ("FetchAdd", "Swap", "CAS") and addr is not None and addr >= (1 << 32):
            hdr = 16
        wire = self.link.framing() + hdr + nbytes + (4 if td else 0) + 4
        dur = self.link.bytes_ps(wire)
        if psn is None:
            psn = self.psn[d]
            self.psn[d] = (psn + 1) & 0xFFF
        r = self.blank()
        r[COL["Link Dir"]] = d
        r[COL["TLP Type"]] = kind
        r[COL["PSN"]] = str(psn)
        if tc:
            r[COL["TC"]] = str(tc)
        if th:
            r[COL["TH"]] = "1"
        if td:
            r[COL["TD"]] = "1"
        if ep:
            r[COL["EP"]] = "1"
        if attr:
            r[COL["Attributes"]] = attr
        if at:
            r[COL["AT"]] = at
        if kind not in ("Cpl", "CplLk") and not (kind == "Msg" and length == 0):
            r[COL["Length"]] = str(length)
        elif kind == "Msg":
            r[COL["Length"]] = "0"
        r[COL["RequesterID"]] = rid
        r[COL["Tag"]] = "" if tag == "" else str(tag)
        if cid:
            r[COL["CompleterID"]] = cid
        if addr is not None:
            r[COL["Address"]] = fmt_addr(addr)
        if devid:
            r[COL["DeviceID"]] = devid
            r[COL["Register"]] = reg
        if kind not in CPL_TYPES and kind not in ("Msg", "MsgD"):
            r[COL["st BE"]] = be_str(fbe)
            r[COL["Last BE"]] = be_str(lbe if lbe is not None else (0 if length <= 1 else 0xF))
        if kind in CPL_TYPES:
            r[COL["Cpl Status"]] = status or "SC"
            r[COL["Byte Cnt"]] = str(bytecnt if bytecnt is not None else nbytes)
            r[COL["BCM"]] = "0"
            r[COL["Lwr Addr"]] = "0x%03X" % (lwr or 0)
        if routing:
            r[COL["Msg Routing"]] = routing
            r[COL["Message Code"]] = msgcode
        if extra:
            for k, v in extra.items():
                r[COL[k]] = v
        # header bytes (synthetic but deterministic) -> LCRC / ECRC
        hb = bytearray(hdr)
        hb[0] = FMT_TYPE.get(kind, 0x00)
        hb[1] = (tc & 7) << 4
        hb[2] = (0x80 if td else 0) | (0x40 if ep else 0) | ((length >> 8) & 3)
        hb[3] = length & 0xFF
        hb[6] = (int(tag) & 0xFF) if isinstance(tag, int) else (zlib.crc32(str(tag).encode()) & 0xFF)
        hb[7] = ((lbe or 0) << 4 | fbe) & 0xFF
        if addr is not None:
            hb[8:hdr] = (addr & ((1 << (8 * (hdr - 8))) - 1)).to_bytes(hdr - 8, "big")
        crc = zlib.crc32(psn.to_bytes(2, "big"))
        crc = zlib.crc32(bytes(hb), crc)
        if payload is not None:
            crc = zlib.crc32(payload, crc)
        if td:
            e = zlib.crc32(bytes(hb)) ^ (zlib.crc32(payload) if payload else 0)
            if bad_ecrc:
                r[COL["ECRC"]] = "0x%08X (Bad)" % (e ^ 0x1BADC0DE)
            else:
                r[COL["ECRC"]] = "0x%08X" % e
        if nullified:
            r[COL["LCRC"]] = "0x%08X (Nullified)" % ((~crc) & 0xFFFFFFFF)
        elif bad_lcrc or display_bad:
            r[COL["LCRC"]] = "0x%08X (Bad)" % (crc ^ 0x00F00F00)
        elif lcrc_text is not None:
            r[COL["LCRC"]] = lcrc_text
        else:
            r[COL["LCRC"]] = "0x%08X" % crc
        if nbytes:
            if self.data_format == "hex" and payload is not None:
                r[COL["DATA"]] = payload.hex(" ").upper()
            else:
                r[COL["DATA"]] = "%d B" % nbytes
        self.busy[d] = t + dur
        self.now = t
        n = self._write(r, t, dur, d)
        self._count("TLP:" + kind)
        owner = self.owner
        self.owner = None
        self._record_owner(n, owner)
        if not nullified:
            self.retry[d].append((psn, r[:], wire, kind, nbytes, owner))
            if len(self.retry[d]) > 512:
                self.retry[d].popleft()
            self._rx_tlp(d, psn, t + dur, kind, nbytes, bad_lcrc, consume_fc)
        return n, t, t + dur

    def _record_owner(self, n, owner):
        if n is None or self.owner_writer is None:
            return
        o = owner or {}
        self.owner_writer.writerow([n, o.get("c", ""), o.get("q", ""), o.get("cid", ""), o.get("part", ""),
                                    o.get("i", "")])

    def replay(self, d, from_psn=None, gap_ps=0):
        """Retransmit the retry buffer of direction d (same PSN, same LCRC)."""
        items = list(self.retry[d])
        if from_psn is not None:
            idx = next((i for i, it in enumerate(items) if it[0] == from_psn), 0)
            items = items[idx:]
        self.rx_drop[d] = False
        first = None
        for psn, row, wire, kind, nbytes, owner in items:
            self.flush(self.now)
            t = self._start(d) + gap_ps
            gap_ps = 0
            dur = self.link.bytes_ps(wire)
            r = row[:]
            r[0] = ""
            lc = r[COL["LCRC"]]
            if lc.endswith("(Bad)"):
                r[COL["LCRC"]] = "0x%08X" % (int(lc.split()[0], 16) ^ 0x00F00F00)
            self.busy[d] = t + dur
            self.now = t
            n = self._write(r, t, dur, d)
            first = n if first is None else first
            self._record_owner(n, dict(owner or {}, replay=1))
            self._count("TLP:replay")
            self._rx_tlp(d, psn, t + dur, kind, nbytes, False, False)
        return first

    # ------------------------------------------------------------------ receiver behaviour
    def _rx_tlp(self, d, psn, end, kind, nbytes, bad, consume_fc):
        rxer = OTHER[d]          # the receiver transmits its DLLPs in the other direction
        if bad:
            self.rx_drop[d] = True
            nak_t = end + self.rng.randint(60, 140) * NS
            good = self.last_good_rx[d]
            self.schedule(nak_t, lambda tt, rxer=rxer, good=good: self._send_nak(rxer, good, tt))
            return
        if self.rx_drop[d]:
            return
        self.last_good_rx[d] = psn
        if self.ack_mode[d] == "hold":
            return
        proc = self.rng.randint(90, 150) * NS + (self.ack_late_ps if self.ack_mode[d] == "late" else 0)
        self.rx[d].append((end + proc, psn))
        if not self.ack_sched[d]:
            self.ack_sched[d] = True
            self.schedule(end + proc + self.rng.randint(0, 25) * NS, lambda tt, d=d: self._send_ack(d, tt))
        if consume_fc and kind in POSTED | {"MRd(32)", "MRd(64)", "CfgRd0", "CfgWr0", "IORd", "IOWr"}:
            typ = "P" if kind in POSTED else "NP"
            key = (d, typ)
            h, dc = self.fc_pending.get(key, (0, 0))
            h += 1
            dc += (nbytes + 15) // 16
            if h >= self.fc_every[d] and key not in self.fc_hold:
                lim_h, lim_d = self.fc_limit.get(key, (0, 0))
                lim_h, lim_d = (lim_h + h) & 0xFF, (lim_d + dc) & 0xFFF
                self.fc_limit[key] = (lim_h, lim_d)
                h = dc = 0
                self.schedule(end + self.rng.randint(150, 400) * NS,
                              lambda tt, rxer=rxer, typ=typ, a=lim_h, b=lim_d:
                              self.dllp(rxer, "UpdateFC-" + typ, vc=0, hdr=a, data=b, t=tt))
            self.fc_pending[key] = (h, dc)

    def _send_ack(self, d, t):
        self.ack_sched[d] = False
        if not self.rx[d] or self.ack_mode[d] == "hold":
            self.rx[d].clear()
            return
        best = None
        while self.rx[d] and self.rx[d][0][0] <= t:
            best = self.rx[d].popleft()[1]
        if best is None:
            best = self.rx[d].popleft()[1]
        self.dllp(OTHER[d], "ACK", seq=best, t=t)
        self._ack_retry(d, best)
        if self.rx[d]:
            self.ack_sched[d] = True
            nxt = self.rx[d][0][0] + self.rng.randint(0, 25) * NS
            self.schedule(max(nxt, t + 8 * NS), lambda tt, d=d: self._send_ack(d, tt))

    def _ack_retry(self, d, seq):
        buf = self.retry[d]
        while buf and ((seq - buf[0][0]) & 0xFFF) < 2048:
            buf.popleft()

    def _send_nak(self, rxer, good, t):
        """A Nak names the last TLP received correctly (PCIe Data Link Layer retry rules): it acknowledges every TLP up to
        that number, exactly like an Ack, and asks for everything after it to be sent again."""
        self.dllp(rxer, "NAK", seq=good, t=t)
        if good is not None:
            self._ack_retry(OTHER[rxer], good)

    def force_ack(self, d, seq, bad_crc=False):
        """Send an Ack for TLPs that flowed in direction d (DLLP travels the other way)."""
        n = self.dllp(OTHER[d], "ACK", seq=seq, bad_crc=bad_crc)
        if not bad_crc:
            self._ack_retry(d, seq)
        return n

    def set_fc_limits(self, d, typ, hdr, data):
        self.fc_limit[(d, typ)] = (hdr, data)
