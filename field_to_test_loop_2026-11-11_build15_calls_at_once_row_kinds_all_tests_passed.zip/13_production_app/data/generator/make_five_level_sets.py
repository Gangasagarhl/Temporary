#!/usr/bin/env python3
"""Build the five-level synthetic data sets, one per failure scenario of the corpus (data/catalogue/08_failure_corpus.json):
generate the capture with the scenario's atlas cards, export the five per-level files in the customer's layout,
load + build + apply the rules with the application's own modules, and record which rules fired.

SYNTHETIC DATA: imitates the layout of the Teledyne LeCroy exports; not an analyzer capture.

Usage
  python3 make_five_level_sets.py --out ../../samples/five_level            # all 59 scenarios
  python3 make_five_level_sets.py --out DIR --only S01,S17,S41 --seed 5
Outputs: DIR/<id>/{packets.csv, link.csv, split.csv, NVME_Transactions.csv, nvme_command.csv, truth_packet.csv,
levels_manifest.json, scenario.json, rules.json} and DIR/coverage.csv + DIR/coverage.json.
"""
import argparse
import csv
import json
import os
import shutil
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, APP)
CORPUS = os.path.join(APP, "data", "catalogue", "08_failure_corpus.json")
CARDS = os.path.join(APP, "data", "atlas_cards_raw.json")


def build_one(sc, out_dir, seed, keep_db=False, thresholds=None):
    from nvme_hier import builder, loader, rules
    d = os.path.join(out_dir, sc["id"])
    if os.path.isdir(d):
        shutil.rmtree(d)
    os.makedirs(d)
    work = os.path.join(d, "_work")
    os.makedirs(work)
    cards = ",".join(sc.get("atlas_cards") or [])
    t0 = time.time()
    csv_path = os.path.join(work, "t.csv")
    r = subprocess.run([sys.executable, os.path.join(HERE, "generate_synthetic_pcie_trace.py"), "--only", cards, "--output", csv_path, "--seed", str(seed),
                        "--data-format", "hex", "--cards", CARDS, "--target-bytes", "0"], capture_output=True, text=True, timeout=1800)
    if r.returncode != 0 or not os.path.exists(csv_path):
        return {"id": sc["id"], "error": (r.stderr or r.stdout)[-400:]}
    r = subprocess.run([sys.executable, os.path.join(HERE, "export_levels.py"), "--csv", csv_path, "--out", d], capture_output=True, text=True, timeout=1800)
    if r.returncode != 0:
        return {"id": sc["id"], "error": (r.stderr or r.stdout)[-400:]}
    shutil.copy(os.path.join(work, "t_sidecars", "scenario_event_log.jsonl"), os.path.join(d, "scenario_event_log.jsonl"))
    shutil.copy(os.path.join(work, "t_sidecars", "csv_row_scenario_index.csv"), os.path.join(d, "csv_row_scenario_index.csv"))
    shutil.rmtree(work)
    files = {"packets": os.path.join(d, "packets.csv"), "link": os.path.join(d, "link.csv"), "split": os.path.join(d, "split.csv"),
             "nvme_transaction": os.path.join(d, "NVME_Transactions.csv"), "nvme_command": os.path.join(d, "nvme_command.csv")}
    db = os.path.join(d, "hier.sqlite")
    rep = loader.load_upload(db, files)
    b = builder.build(db)
    rr = rules.apply(db, thresholds or {})
    if not keep_db:
        for ext in ("", "-wal", "-shm"):
            if os.path.exists(db + ext):
                os.remove(db + ext)
    with open(os.path.join(d, "scenario.json"), "w") as fh:
        json.dump({"scenario": sc, "seed": seed, "cards": sc.get("atlas_cards"), "provenance": "SYNTHETIC five-level set"}, fh, indent=1)
    with open(os.path.join(d, "rules.json"), "w") as fh:
        json.dump({"load": {k: {"rows": v["rows"], "named": v["found_named_columns"]} for k, v in rep.items()}, "build": b["checks"], "rules": rr}, fh, indent=1)
    return {"id": sc["id"], "name": sc["name"], "first_level": sc["first_level"], "visibility": sc["visibility"], "cards": cards,
            "rows": {k: v["rows"] for k, v in rep.items()}, "build_checks": b["checks"], "findings": rr["findings"], "by_rule": rr["by_rule"],
            "errors": rr["by_severity"].get("error", 0), "checks": rr["by_severity"].get("check", 0), "seconds": round(time.time() - t0, 1)}


def rules_only(sc, out_dir, thresholds):
    """Re-load, re-build and re-apply the rules on an existing set (after a rule changed), rewriting rules.json."""
    from nvme_hier import builder, loader, rules
    d = os.path.join(out_dir, sc["id"])
    if not os.path.isdir(d):
        return {"id": sc["id"], "error": "no set folder"}
    t0 = time.time()
    files = {"packets": os.path.join(d, "packets.csv"), "link": os.path.join(d, "link.csv"), "split": os.path.join(d, "split.csv"),
             "nvme_transaction": os.path.join(d, "NVME_Transactions.csv"), "nvme_command": os.path.join(d, "nvme_command.csv")}
    db = os.path.join(d, "hier.sqlite")
    rep = loader.load_upload(db, files)
    b = builder.build(db)
    rr = rules.apply(db, thresholds or {})
    for ext in ("", "-wal", "-shm"):
        if os.path.exists(db + ext):
            os.remove(db + ext)
    with open(os.path.join(d, "rules.json"), "w") as fh:
        json.dump({"load": {k: {"rows": v["rows"], "named": v["found_named_columns"]} for k, v in rep.items()}, "build": b["checks"], "rules": rr}, fh, indent=1)
    return {"id": sc["id"], "name": sc["name"], "first_level": sc["first_level"], "visibility": sc["visibility"], "cards": ",".join(sc.get("atlas_cards") or []),
            "rows": {k: v["rows"] for k, v in rep.items()}, "build_checks": b["checks"], "findings": rr["findings"], "by_rule": rr["by_rule"],
            "errors": rr["by_severity"].get("error", 0), "checks": rr["by_severity"].get("check", 0), "seconds": round(time.time() - t0, 1)}


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--out", required=True)
    ap.add_argument("--only", default="")
    ap.add_argument("--seed", type=int, default=11)
    ap.add_argument("--keep-db", action="store_true")
    ap.add_argument("--rules-only", action="store_true", help="do not regenerate: reload the existing sets and apply the current rules")
    ap.add_argument("--split-limit-ms", type=float, default=43.0, help="split-level limit used for the rules (the customer's 43 ms)")
    a = ap.parse_args()
    corpus = json.load(open(CORPUS))
    only = {x.strip() for x in a.only.split(",") if x.strip()}
    os.makedirs(a.out, exist_ok=True)
    th = {"split": {"ps": int(a.split_limit_ms * 10 ** 9), "source": "platform rule %g ms" % a.split_limit_ms}}
    results = []
    for sc in corpus:
        if only and sc["id"] not in only:
            continue
        res = rules_only(sc, a.out, th) if a.rules_only else build_one(sc, a.out, a.seed, a.keep_db, th)
        results.append(res)
        print("%s %-45s %s" % (sc["id"], sc["name"][:45], ("ERROR " + res["error"]) if res.get("error") else
                                "findings %d (errors %d) rules %s" % (res["findings"], res["errors"], ",".join(sorted(res["by_rule"])))), flush=True)
    with open(os.path.join(a.out, "coverage.json"), "w") as fh:
        json.dump(results, fh, indent=1)
    rules_all = sorted({r for x in results for r in (x.get("by_rule") or {})})
    with open(os.path.join(a.out, "coverage.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["scenario", "name", "first_level", "visibility", "cards", "findings", "errors", "checks"] + rules_all)
        for x in results:
            if x.get("error"):
                w.writerow([x["id"], "ERROR", "", "", "", "", "", "", x["error"]])
                continue
            w.writerow([x["id"], x["name"], x["first_level"], x["visibility"], x["cards"], x["findings"], x["errors"], x["checks"]] + [(x["by_rule"] or {}).get(r, 0) for r in rules_all])
    ok = [x for x in results if not x.get("error")]
    print("done: %d scenarios, %d with at least one error finding, %d with none" % (len(ok), sum(1 for x in ok if x["errors"]), sum(1 for x in ok if not x["errors"])))


if __name__ == "__main__":
    main()
