#!/usr/bin/env python3
"""Build data/lecroy_real_headers.json from the customer's headers_only/ALL_HEADERS_INDEXED.csv.

    python3 data/real_headers_from_index.py <ALL_HEADERS_INDEXED.csv> [--name "<label>"] [--write]

ALL_HEADERS_INDEXED.csv has one row per header cell of each real export: file,column_index,column_name,is_blank,
occurrence,duplicate_name. The script rebuilds every file's header line, aligns it with the known column list
(nvme_hier.loader.align_header, the matching logic), prints what every cell became, and refuses to write when a known
column is missing without being declared absent or when a cell stays unknown. With --write the table is written (or
the entry of the same name replaced), and from then on a file whose header equals the stored one is aligned from the
table directly, with no matching logic at all.

Declared absent (this export carries one TLP Type / Length column for every TLP kind): link.csv Cpl.TLP Type,
Cpl.Length, Msg.TLP Type, Msg.Length.
"""
import csv
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from nvme_hier import columns as C, loader as L   # noqa: E402

ABSENT_OK = {"link": {"Cpl.TLP Type", "Cpl.Length", "Msg.TLP Type", "Msg.Length"}}


def read_index(path):
    files = {}
    with open(path, newline="", encoding="utf-8-sig") as fh:
        rd = csv.DictReader(fh)
        for row in rd:
            fname = (row.get("file") or "").strip()
            if not fname:
                continue
            idx = int(row["column_index"])
            files.setdefault(fname, {})[idx] = "" if (row.get("is_blank") or "").strip().upper() == "Y" else (row.get("column_name") or "")
    out = {}
    for fname, cells in files.items():
        n = max(cells) + 1
        missing = [i for i in range(n) if i not in cells]
        if missing:
            sys.exit("%s: column indexes missing from the index file: %s" % (fname, missing[:20]))
        out[fname] = [cells[i] for i in range(n)]
    return out


def build(headers, name):
    entries, ok = {}, True
    for fname, hdr in headers.items():
        key = next((k for k, v in C.FILE_KEYS.items() if v == fname), None)
        if key is None:
            print("%s: not one of the five exports, skipped" % fname)
            continue
        C._REAL = {}                                   # align with the matching logic, never with a stored table
        al = L.align_header(key, hdr)
        C._REAL = None
        r = al.report(key)
        absent = set(r["missing_columns"])
        bad_missing = absent - ABSENT_OK.get(key, set())
        print("%-22s %4d cells: found %d of %d known, %d separators, %d extra kept, missing %s, unknown %s" % (
            fname, len(hdr), r["found_named_columns"], r["expected_named_columns"], r["separator_columns_dropped"],
            len(r["extra_columns_kept"]), sorted(absent) or "-", [h for _, h in al.unknown] or "-"))
        if bad_missing or al.unknown:
            ok = False
        entries[fname] = {"name": name, "cells": len(hdr), "header": hdr,
                          "columns": {str(i): n for n, i in sorted(al.positions.items(), key=lambda kv: kv[1])},
                          "separators": sorted(al.separators), "absent": sorted(absent), "extras": r["extra_columns_kept"]}
    return entries, ok


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    name = "the customer's export of 2026-11-03 (1st_pex)"
    if "--name" in sys.argv:
        name = sys.argv[sys.argv.index("--name") + 1]
        args = [a for a in args if a != name]
    if not args:
        sys.exit(__doc__)
    headers = read_index(args[0])
    entries, ok = build(headers, name)
    if not ok:
        sys.exit("REFUSED: a known column is missing without being declared absent, or a cell stayed unknown (see above)")
    if "--write" not in sys.argv:
        print("dry run: add --write to store the table in %s" % C.REAL_HEADERS_JSON)
        return
    table = {"source": "the customer's headers_only/ALL_HEADERS_INDEXED.csv, built by data/real_headers_from_index.py", "files": {}}
    if os.path.exists(C.REAL_HEADERS_JSON):
        with open(C.REAL_HEADERS_JSON, encoding="utf-8") as f:
            table = json.load(f)
    for fname, e in entries.items():
        lst = [x for x in (table["files"].get(fname) or []) if x.get("name") != name]
        table["files"][fname] = lst + [e]
    with open(C.REAL_HEADERS_JSON, "w", encoding="utf-8") as f:
        json.dump(table, f, indent=1)
    print("written %s" % C.REAL_HEADERS_JSON)


if __name__ == "__main__":
    main()
