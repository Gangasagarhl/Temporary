"""Family 1 — Data Experts: one sub-family per CSV of the input folder -> one approved data dictionary per CSV.

The sub-family has three agents, each with its OWN context (owner, 2026-11-08: "I don't want to mess the whole context"):

  Data Explorer   THE DATA, and only the data. Code reads EVERY row of the file (no sample) and records every column:
                  how many rows hold a value, its type, how many different values it has, and every special keyword:
                  the WORDS a column holds ("ACK", "UpdateFC-P", "CplD", "Link Up"; never a number, hex value, address,
                  id, time or the column's own name; see is_keyword), with how many rows hold it and the first rows where
                  it appears (kept in its memory for questions; the keywords themselves are shown by name). The model then only writes a summary
                  of that profile (what one row is, what the file records). The data is the truth: nothing about it is
                  "verified", it is counted. No notes, no meanings: those are the Grounder's.
  Data Grounder   THE MEANINGS, and only the meanings. It gets the column names and the keywords (never the data rows)
                  and finds what each one means: in the reference documents first, then on the web (when allowed), then
                  from the model's own knowledge. Every meaning says where it comes from; a document line and a web page
                  are checked by code (the quote must be there), model knowledge is labelled as such.
  Manager         TALKS TO THE ADMIN. It puts both together into the data dictionary and asks for review: a plain
                  summary of what the file is, then every column and keyword with what the data holds, what it means,
                  where the meaning comes from, and where to see it (file and line). When the admin asks a question, the
                  Manager asks the right helper (the Explorer for the data, with rows; the Grounder for a meaning) and
                  answers with the rows and the path.

Steps of a run (kind "family1"; the same steps inside the flow):
  director              lists the CSVs of the folder and what each one is (its level, its size, its header)
  explore:<csv>         the Data Explorer (code over every row, then the summary) -> runs/<run>/explorer_<csv>/memory.json
  ground:<csv>          the Data Grounder (meanings with sources) -> runs/<run>/grounder_<csv>/memory.json
  manager:<csv>         the Manager's dictionary -> REVIEW "Admin <name>, need review" (approve / change / reject)
"""
import csv
import functools
import glob
import hashlib
import json
import os
import re
import sys
import threading
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed

from . import core

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
from nvme_hier import columns as C, loader as L   # noqa: E402

BATCH = 120                    # columns per Explorer call at most (one short sentence per column, no web) ...
EXPLORE_LEAST = 20             # ... and at least: the columns are cut into as many parts as calls run at the same time
GROUND_BATCH = 20              # columns per Grounder call at most (owner, 2026-11-11: with 120 columns, their keywords and web search in one call,
                               # a real export of 361 columns stood at 'columns 1 to 120 of 361 ... 0%' for many minutes)
GROUND_MEANINGS = 60           # meanings per Grounder call at most (a column counts 1, each of its keywords 1). The time of a call is the
                               # time the model takes to WRITE its answer: 20 columns with 15 keywords each are 320 meanings in one answer,
                               # minutes of writing and close to the longest answer a call may give; 60 meanings are written in seconds
GROUND_MEANINGS_LEAST = 30     # ... and at least this many, so that a small file is not cut into many tiny calls
GROUND_KEYWORDS = 15           # keywords per column whose meaning the Grounder is asked for
KIND_SAMPLE = 5000             # rows looked at (the start of the file and four other places) to find which column names the kind of each row
KIND_MAX = 60                  # the most different kinds of row counted one by one (beyond: "other values")
GROUND_SLOW_AFTER = 120        # seconds a part may wait for the model before the progress line says which part waits, how long and why
KEYWORD_MAX_DISTINCT = 300     # a text column with at most this many different values holds keywords
DISTINCT_CAP = 2000            # different values counted one by one per column (beyond: "more than 2,000")
ROWS_PER_VALUE = 3             # the first rows where each value appears (where to see it)
TOP_VALUES = 8


def knowledge_dir():
    d = os.path.join(APP, "knowledge")
    os.makedirs(d, exist_ok=True)
    return d


# ---------------------------------------------------------------------------------------------- the inventory
def inventory(folder):
    out = []
    if not folder or not os.path.isdir(folder):
        return out
    for fn in sorted(os.listdir(folder)):
        p = os.path.join(folder, fn)
        if not (os.path.isfile(p) and fn.lower().endswith(".csv")):
            continue
        try:
            header, _rows = L.sniff(p, 0)
        except (OSError, UnicodeDecodeError):
            continue
        level = L.guess_level(header)
        out.append({"name": fn, "path": p, "bytes": os.path.getsize(p), "level": level,
                    "level_label": C.LEVEL_LABEL.get(level) if level else "not one of the five analyzer levels",
                    "columns": len(header), "format_key": format_key(level, header)})
    return out


def folder_problem(files):
    """Why this folder cannot be built into one tree, in words, or None. One folder holds one recording: two files of the same kind are two recordings,
    and quietly using the last one by name would join the packets of one recording to the commands of another (found 2026-11-10)."""
    by = {}
    for f in files:
        if f["level"]:
            by.setdefault(f["level"], []).append(f["name"])
    if not by:
        return "none of the CSV files in this folder is an analyzer export of the five kinds (packets, link, split, NVMe transactions, NVMe commands)"
    two = sorted((k, v) for k, v in by.items() if len(v) > 1)
    if two:
        return "this folder holds more than one file of the same kind: %s. One folder holds one recording: move the other files to a folder of their own, then run again" % (
            "; ".join("%s (%s)" % (C.LEVEL_LABEL.get(k, k), ", ".join(v)) for k, v in two))
    return None


def format_key(level, header):
    """The file format: the level and its header cells. The same key = the same export layout."""
    cells = [re.sub(r"^\d+(\.\d+)?$|^\d+ (warning|error)\(s\)$", "<value>", (h or "").strip()) for h in header]
    return hashlib.sha1(("%s|%s" % (level, "|".join(cells))).encode()).hexdigest()[:12]


# ---------------------------------------------------------------------------------------------- the Explorer's code
_INT = re.compile(r"^-?\d+$")
_HEX = re.compile(r"^(0x)?[0-9A-Fa-f]+$")
_TIME = re.compile(r"^\d+\.\d+\s*s$")
_DUR = re.compile(r"^\d+(\.\d+)?\s*(ps|ns|us|µs|ms|s)$")


def _type_of(values):
    vals = [v for v in values if v][:500]
    if not vals:
        return "empty"
    for name, rx in (("integer", _INT), ("time stamp", _TIME), ("time span", _DUR), ("hex", _HEX)):
        if all(rx.match(v) for v in vals):
            return name
    return "text"


_ID = re.compile(r"^\d{1,4}:\d{1,3}[:.]\d{1,2}$")                    # a requester / completer / device id: bus:device.function
_NUMERIC_LIKE = re.compile(r"^[0-9.,:;/_\-+x ]+$", re.I)              # digits and separators only (numbers, ranges, addresses)
_QUANTITY = re.compile(r"^-?\d[\d.,]*\s*(ps|ns|us|µs|ms|s|b|kb|mb|gb|bytes?|dw|dwords?|gt/s|lanes?|%)$", re.I)


def is_keyword(value, column):
    """A special keyword is a WORD: the name of a type, an event, a status (ACK, UpdateFC-P, PM_Request_Ack, CplD, TS1,
    Link Up, Successful Completion). Never a number (a sequence number, a tag, a length), a hex value or an address, a
    bus:device.function id, a time or a quantity with its unit, or the column's own name repeated in a cell."""
    v = value.strip()
    if not v or not re.search(r"[A-Za-z]", v):
        return False
    if _NUMERIC_LIKE.match(v) or _ID.match(v) or _TIME.match(v) or _DUR.match(v) or _QUANTITY.match(v):
        return False
    if _HEX.match(v) and re.search(r"\d", v):          # 1F, 0x2A, 3fe0: a hex number, not a word
        return False
    if v.lower() == (column or "").strip().lower() or v.lower() == (column or "").partition(".")[2].strip().lower():
        return False                                    # the header repeated in the first row ("Marker" under Marker)
    return True


IDENTITY_COLUMNS = {"mn", "sn", "fr", "model number", "serial number", "firmware revision", "subnqn", "nqn"}   # the drive's identity
FLAG_WORDS = {"yes", "no", "true", "false", "on", "off"}                      # a yes/no flag is not a keyword
_CODE_NAME = re.compile(r"^(0x[0-9A-Fa-f]+|\d+)\s*\((.+)\)$")              # "0x02 (Read)" -> Read
_NAME_VALUE = re.compile(r"^([A-Za-z][^:]{0,60}?)\s*:\s*[-+]?\d[\d.,]*\s*[A-Za-z/%µ#]{0,6}$")   # "Speed Change: 16.0 GT/s" -> Speed Change
_COUNT_PHRASE = re.compile(r"^\d[\d,]*\s+[A-Za-z]")                         # "1 error(s)", "3 warnings": a count


def keyword_names(value, column):
    """The special keywords a cell holds, as NAMES: the words (ACK, UpdateFC-P, Read, Successful Completion, Speed Change),
    without the numbers around them. A listed cell ("2.5 GT/s, 5.0 GT/s") is looked at part by part."""
    col = (column or "").strip().lower()
    if col in IDENTITY_COLUMNS or col.partition(".")[2].strip() in IDENTITY_COLUMNS:
        return []
    out = []
    for part in ([x.strip() for x in value.split(",")] if "," in value else [value.strip()]):
        m = _CODE_NAME.match(part)
        if m:
            part = m.group(2).strip()
        m = _NAME_VALUE.match(part)
        if m:
            part = m.group(1).strip()
        if part.lower() in FLAG_WORDS or _COUNT_PHRASE.match(part):
            continue
        if is_keyword(part, column):
            out.append(part)
    return out


SPEC_CITE = re.compile(r"((?:NVMe|NVM Express|PCIe|PCI Express)[^|\n]{0,40}?(?:§\s*[0-9][0-9.]*[0-9]|Section\s+[0-9][0-9.]*[0-9]|Figure\s+[0-9]+|Table\s+[0-9]+)"
                       r"|doc\s+[A-Z]{2,}\s+[0-9][0-9.]*[0-9]|manual\s+v[0-9][0-9.]*[0-9])", re.I)      # specification sections, and the LeCroy manual references the notes use ("doc VSE 5.2.12")


@functools.lru_cache(maxsize=512)
def _source_details(path, line, mtime):
    kind = "project research note" if "research_notes" in path else "LeCroy manual" if "lecroy" in os.path.basename(path).lower() and not path.endswith((".md", ".json")) else \
        "specification" if re.search(r"(nvm.?express|pci.?express|base.?spec)", os.path.basename(path), re.I) else "reference document"
    heading, here = "", ""
    with open(path, encoding="utf-8", errors="replace") as fh:
        for i, text in enumerate(fh, 1):
            if text.lstrip().startswith("#"):
                heading = text.strip().lstrip("#").strip()
            if i == line:
                here = text.strip()
                break
    cites = list(dict.fromkeys(m.strip() for m in SPEC_CITE.findall(here)))
    return {"document": os.path.basename(path), "kind": kind, "section": heading[:120], "cites": cites[:4], "line_text": here[:240]}


@functools.lru_cache(maxsize=256)
def _blank_positions(path, mtime):
    header, _rows = L.sniff(path, 0)
    return [i + 1 for i, h in enumerate(header) if not (h or "").strip()]


def blank_header_positions(path):
    """The positions (1 = first) of the analyzer's blank spacer columns: no header and never a value."""
    try:
        return list(_blank_positions(path, os.path.getmtime(path)))
    except (OSError, UnicodeDecodeError, ValueError):
        return []


def source_details(ref):
    """Where a fact taken from a document comes from, in words for the page (owner, 2026-11-10: "which specification, in that .md file?"): the kind of document (a project
    research note is not a specification), the heading the line sits under, and any specification section named on that very line; none named is said as such."""
    path, _, line = (ref or "").rpartition(":")
    try:
        n = int(line)
        mtime = os.path.getmtime(path)
    except (ValueError, OSError):
        return None
    return dict(_source_details(path, n, mtime))


def reading_line(name, lines, done_bytes, size, t0, share=(0.0, 100.0), columns=None):
    """One status line while a file is read: '37% · reading packets.csv: 36,700 of about 99,100 lines, about 62,400 left · 12 s so far · about 20 s to go'.
    The total is estimated from the bytes read so far, so it says "about". share maps the reading onto part of the step's own percentage."""
    frac = min(1.0, done_bytes / float(max(1, size)))
    pct = share[0] + (share[1] - share[0]) * frac
    el = time.time() - t0
    est = int(lines / frac) if frac > 0.001 else None
    cols = " (%s columns)" % "{:,}".format(columns) if columns else ""
    text = "%d%% · reading %s%s: %s of about %s lines, about %s left" % (pct, name, cols, "{:,}".format(lines), "{:,}".format(est), "{:,}".format(max(0, est - lines))) if est else \
        "%d%% · reading %s%s: %s lines so far" % (pct, name, cols, "{:,}".format(lines))
    text += " · %s so far" % core.fmt_secs(el)
    if 0.01 < frac < 1.0:
        togo = el * (1 - frac) / frac
        text += " · about %s to go" % core.fmt_secs(togo) if togo >= 1 else " · almost done"
    return text


def _named_columns(level, header):
    """-> (the header's alignment or None, [(column name, its position in the file)]) for every column of the file."""
    al = L.align_header(level, header) if level else None
    named = sorted(al.positions.items(), key=lambda kv: kv[1]) if al else [((h or "column %d" % (i + 1)), i) for i, h in enumerate(header)]
    if al:
        named += [(h, i) for i, h in al.unknown]
        named += [("column %d" % (i + 1), i) for i in al.separators]     # no header: read too, so a value under a blank header is seen (found 2026-11-10: split.csv column 4 held the link speed); the loader stores them under the same name
    return al, named


# ---- which kind of row fills which column (owner, 2026-11-11: "a Read command fills only the columns it needs, a Write only its
# own ... that special status is also needed when extracting from the model"). Nothing is assumed about the file: the column (or
# the few columns, never filled on the same row) whose WORD says what kind of row a row is, is the one that best decides which other
# columns hold a value. It is looked for in a sample; the counts that are then stated come from every row.
_NO_KIND, _TWO_KINDS, _OTHER_KINDS = (-1, ""), (-2, ""), (-3, "")


def _sample_rows(path, rows=KIND_SAMPLE):
    """-> (header, rows): from the start of the file and, when the file is longer, from four other places in it (a recording often
    starts with one kind of row only)."""
    size = os.path.getsize(path)
    out, head = [], rows * 3 // 5
    with open(path, "r", encoding="utf-8-sig", errors="replace", newline="") as fh:
        rd = L.read_csv(fh, path)
        header = next(rd, [])
        for row in rd:
            out.append(row)
            if len(out) >= head:
                break
        covered = fh.buffer.tell() if hasattr(fh, "buffer") else size
        if covered * 2 >= size:                 # a short file: simply the first rows
            for row in rd:
                out.append(row)
                if len(out) >= rows:
                    break
            return header, out
    width = Counter(len(r) for r in out).most_common(1)[0][0] if out else len(header)
    with open(path, "rb") as fb:
        for frac in (0.3, 0.5, 0.7, 0.9):
            at = int(size * frac)
            if at <= covered:
                continue
            fb.seek(at)
            fb.readline(L.MAX_LINE_CHARS)       # the rest of the line the place fell into
            lines = []
            for _ in range((rows - head) // 4):
                ln = fb.readline(L.MAX_LINE_CHARS)
                if not ln:
                    break
                lines.append(ln.decode("utf-8", errors="replace"))
            try:
                out += [r for r in csv.reader(lines) if len(r) == width]      # a row cut by a line break inside a cell is left out
            except csv.Error:
                pass
    return header, out


def _kind_key(row, places):
    m, key = len(row), None
    for p in places:
        if p < m:
            v = row[p]
            if v and not v.isspace():
                if key is not None:
                    return _TWO_KINDS
                key = (p, v.strip())
    return key or _NO_KIND


def kind_columns(path, level):
    """The column that names the KIND of each row (the command of an NVMe command row, the type of a transaction), or the few
    columns that do it together when each kind of row has its own (a packet has a TLP Type or a DLLP Type or an ordered-set type,
    never two). Candidates are columns of words with at most KIND_MAX different values; the one kept is the one that decides the
    most of the columns that are filled on some rows only (for every kind: filled on all its rows or on none). None when no column
    decides at least two of them and a quarter. -> {"columns": [(name, position)], "decides", "of", "rows_looked_at"}."""
    header, sample = _sample_rows(path)
    _al, named = _named_columns(level, header)
    n, width = len(sample), len(named)
    if n < 20 or width < 3:
        return None
    fill, vals, masks = [0] * width, [dict() for _ in named], []
    for row in sample:
        m, mask = len(row), 0
        for j, (_nm, idx) in enumerate(named):
            if idx < m:
                v = row[idx]
                if v and not v.isspace():
                    fill[j] += 1
                    mask |= 1 << j
                    d = vals[j]
                    if len(d) <= KIND_MAX:
                        v = v.strip()
                        d[v] = d.get(v, 0) + 1
        masks.append(mask)
    partly = 0
    for j in range(width):
        if 0 < fill[j] < n:
            partly |= 1 << j
    if not partly:
        return None
    words = [j for j in range(width) if fill[j] and len(vals[j]) <= KIND_MAX
             and sum(k for v, k in vals[j].items() if keyword_names(v, named[j][0])) >= 0.95 * fill[j]]
    cands = [[j] for j in words if fill[j] >= 0.98 * n and len(vals[j]) >= 2 and n >= 3 * len(vals[j])]
    some = sorted((j for j in words if fill[j] < 0.98 * n), key=lambda j: (-fill[j], j))[:24]
    rows_of = {}
    for j in some:
        idx, bits = named[j][1], 0
        for i, row in enumerate(sample):
            if idx < len(row) and row[idx] and not row[idx].isspace():
                bits |= 1 << i
        rows_of[j] = bits
    seen = set()
    for seed in some[:4]:                       # columns never filled on the same row, which together name nearly every row
        group, union = [seed], rows_of[seed]
        for j in some:
            if j != seed and not (rows_of[j] & union):
                group.append(j)
                union |= rows_of[j]
        key = tuple(sorted(group))
        if len(group) >= 2 and key not in seen and bin(union).count("1") >= 0.98 * n and 2 <= sum(len(vals[j]) for j in group) <= KIND_MAX:
            seen.add(key)
            cands.append(list(key))
    best = None
    for group in cands:
        places = [named[j][1] for j in group]
        both, either = {}, {}
        for row, mask in zip(sample, masks):
            key = _kind_key(row, places)
            if key in both:
                both[key] &= mask
                either[key] |= mask
            else:
                both[key] = either[key] = mask
        undecided, mine = 0, 0
        for key in both:
            undecided |= either[key] & ~both[key]
        for j in group:
            mine |= 1 << j
        decides, of = bin(partly & ~undecided & ~mine).count("1"), bin(partly & ~mine).count("1")
        rank = (decides, -len(both), -group[0])
        if best is None or rank > best[0]:
            best = (rank, group, decides, of)
    if best is None or best[2] < max(2, -(-best[3] // 4)):
        return None
    return {"columns": [named[j] for j in best[1]], "decides": best[2], "of": best[3], "rows_looked_at": n}


def _n(x):
    return "{:,}".format(x)


def _filled_for(j, kinds, members, rows):
    """The special status of column j: which kinds of row fill it, as counted on every row; None when every kind of row fills it
    at least sometimes (then the kind of row says nothing about it)."""
    mine = [k for k in kinds if k["counts"][j]]
    never = sum(k["rows"] for k in kinds if not k["counts"][j])
    if not mine or not never:
        return None
    phrases, short = [], []
    for col in members + [""]:
        ks = sorted((k for k in mine if k["column"] == col), key=lambda k: (-k["counts"][j], k["value"]))
        if not ks:
            continue
        f, r = sum(k["counts"][j] for k in ks), sum(k["rows"] for k in ks)
        if not col:
            phrases.append("rows where %s (%s of %s rows)" % (" or ".join(k["value"] for k in ks), _n(f), _n(r)))
            short.append("rows where %s" % " or ".join(k["value"] for k in ks))
        elif len(members) > 1 and len(ks) == sum(1 for k in kinds if k["column"] == col):
            phrases.append("rows that have a %s (%s of %s rows)" % (col, _n(f), _n(r)))
            short.append("rows that have a %s" % col)
        else:
            shown = ", ".join("%s (%s of %s rows)" % (k["value"], _n(k["counts"][j]), _n(k["rows"])) for k in ks[:5])
            if len(ks) > 5:
                shown += " and %d more (%s of %s rows)" % (len(ks) - 5, _n(sum(k["counts"][j] for k in ks[5:])), _n(sum(k["rows"] for k in ks[5:])))
            phrases.append("rows where %s is %s" % (col, shown))
            short.append("rows where %s is %s" % (col, " or ".join(k["value"] for k in ks[:5]) + (" or %d more" % (len(ks) - 5) if len(ks) > 5 else "")))
    return {"by": [c for c in members if any(k["column"] == c for k in mine)],
            "kinds": [{"column": k["column"], "value": k["value"], "rows_filled": k["counts"][j], "rows": k["rows"]} for k in
                      sorted(mine, key=lambda k: -k["counts"][j])[:12]],
            "kinds_filled": len(mine), "rows_never": never, "rows": "; and ".join(short),
            "text": "filled only on %s; never on the other %s row%s" % ("; and on ".join(phrases), _n(never), "" if never == 1 else "s")}


def full_profile(path, level, progress=None, share=(0.0, 100.0)):
    """EVERY row of the file, every column, by code (no model, no sample): per column how many rows hold a value, its
    type, how many different values, the values with their counts and the first rows where each appears (row n = line
    n + 1 of the file, after the header); and, per kind of row (see kind_columns), how many of its rows fill each column.
    Memory stays low: at most DISTINCT_CAP different values are counted per column."""
    size = os.path.getsize(path)
    try:
        kind = kind_columns(path, level)
    except (OSError, ValueError, L.BadFile):
        kind = None
    with open(path, "r", encoding="utf-8-sig", errors="replace", newline="") as fh:
        rd = L.read_csv(fh, path)
        header = next(rd, [])
        al, named = _named_columns(level, header)
        pairs = [(j, idx) for j, (_n1, idx) in enumerate(named)]
        filled = [0] * len(named)
        counts = [dict() for _ in named]
        first = [dict() for _ in named]
        over = [False] * len(named)
        width = len(named)
        places = [p for _nm, p in kind["columns"]] if kind else []
        by_kind = {}                    # kind of row -> how many of its rows fill each column, and (last) how many rows it has
        bk = [0] * (width + 1)          # no kind column: one list that is never read
        n, t0, bytes_seen, last_report = 0, time.time(), 0, 0.0
        for row in rd:
            n += 1
            m = len(row)
            if places:
                key = None
                for p in places:
                    if p < m:
                        v = row[p]
                        if v and not v.isspace():
                            if key is not None:
                                key = _TWO_KINDS
                                break
                            key = (p, v.strip())
                if key is None:
                    key = _NO_KIND
                bk = by_kind.get(key)
                if bk is None:
                    if len(by_kind) >= KIND_MAX:
                        key = _OTHER_KINDS
                    bk = by_kind.get(key)
                    if bk is None:
                        bk = by_kind[key] = [0] * (width + 1)
                bk[width] += 1
            for j, idx in pairs:
                if idx >= m:
                    continue
                v = row[idx]
                if not v or v.isspace():
                    continue
                v = v.strip()
                filled[j] += 1
                bk[j] += 1
                c = counts[j]
                if v in c:
                    c[v] += 1
                    f = first[j][v]
                    if len(f) < ROWS_PER_VALUE:
                        f.append(n)
                elif len(c) < DISTINCT_CAP:
                    c[v] = 1
                    first[j][v] = [n]
                else:
                    over[j] = True
            if n % 100000 == 0 and hasattr(fh, "buffer"):
                L.drop_file_cache(fh.buffer, 0, fh.buffer.tell())         # every row is read once: the file cache is left to the other programs
            if progress and n % 2000 == 0 and time.time() - last_report >= 1:      # about once a second, in one line: which file, lines read, about how many are left (owner, 2026-11-10)
                last_report = time.time()
                bytes_seen = fh.buffer.tell() if hasattr(fh, "buffer") else 0
                progress(reading_line(os.path.basename(path), n, bytes_seen, size, t0, share, columns=len(header)))
    # the kinds of row, by name: "0x02 (Read)" and "Read" are the same kind
    kinds, members, kind_fact = [], [], None
    if kind and len(by_kind) > 1:
        name_at = {p: nm for nm, p in kind["columns"]}
        members = [nm for nm, _p in kind["columns"]]
        merged = {}
        for key, cnt in by_kind.items():
            if key == _NO_KIND:
                col, value = "", "none of %s holds a value" % ", ".join(members) if len(members) > 1 else "%s holds no value" % members[0]
            elif key == _TWO_KINDS:
                col, value = "", "more than one of %s holds a value" % ", ".join(members)
            elif key == _OTHER_KINDS:
                col, value = "", "%s holds one of the less common values" % " or ".join(members)
            else:
                col = name_at[key[0]]
                value = (keyword_names(key[1], col) or [key[1]])[0][:60]
            have = merged.get((col, value))
            if have is None:
                merged[(col, value)] = {"column": col, "value": value, "rows": cnt[width], "counts": list(cnt[:width])}
            else:
                have["rows"] += cnt[width]
                have["counts"] = [a + b for a, b in zip(have["counts"], cnt[:width])]
        kinds = sorted(merged.values(), key=lambda k: (-k["rows"], k["column"], k["value"]))
        shown = ", ".join("%s (%s rows)" % (k["value"] if len(members) == 1 or not k["column"] else "%s %s" % (k["column"], k["value"]), _n(k["rows"])) for k in kinds[:8])
        kind_fact = {"columns": members, "kinds": [{"column": k["column"], "value": k["value"], "rows": k["rows"]} for k in kinds],
                     "decides": kind["decides"], "of": kind["of"], "rows_looked_at": kind["rows_looked_at"],
                     "text": "The kind of each row is named by %s: %s%s. Found by code, from which columns hold a value on which rows: in the %s rows "
                             "looked at it decides %d of the %d columns that are filled on some rows only. The counts are from every row." % (
                                 members[0] if len(members) == 1 else "one of %s (never two on the same row)" % ", ".join(members), shown,
                                 " and %d more" % (len(kinds) - 8) if len(kinds) > 8 else "", _n(kind["rows_looked_at"]), kind["decides"], kind["of"])}
    cols = []
    for j, (name, idx) in enumerate(named):
        c = counts[j]
        typ = _type_of(list(c.keys()))
        distinct = len(c)
        top = sorted(c.items(), key=lambda kv: (-kv[1], kv[0]))
        agg = {}
        for v, k in top:
            for nm in keyword_names(v, name):
                a = agg.setdefault(nm, {"count": 0, "rows": [], "as_written": []})
                a["count"] += k
                a["rows"] = sorted(set(a["rows"] + first[j][v]))[:ROWS_PER_VALUE]
                if v != nm and len(a["as_written"]) < 3:
                    a["as_written"].append(v[:120])
        words = sorted(agg.items(), key=lambda kv: (-kv[1]["count"], kv[0]))
        keyword_col = 0 < len(words) <= KEYWORD_MAX_DISTINCT and not over[j]
        col = {"column": name, "position": idx, "header_cell": header[idx] if idx < len(header) else "", "type": typ,
               "rows_with_value": filled[j], "filled_pct": round(100.0 * filled[j] / max(1, n), 2),
               "distinct": distinct, "distinct_more_than_counted": over[j],
               "top_values": [{"value": v[:120], "count": k, "rows": first[j][v]} for v, k in top[:TOP_VALUES]]}
        if keyword_col:
            # the keywords are the words only; their counts and first rows stay in the Explorer's memory for questions
            col["keywords"] = [{"value": nm[:120], "count": a["count"], "rows": a["rows"], "as_written": a["as_written"]} for nm, a in words]
        if typ == "integer" and c:
            nums = [int(v) for v in c]
            col["min"], col["max"] = min(nums), max(nums)
        if kinds and name not in members and 0 < filled[j] < n:
            ff = _filled_for(j, kinds, members, n)
            if ff:
                col["filled_for"] = ff
        cols.append(col)
    return {"path": path, "level": level, "level_label": C.LEVEL_LABEL.get(level) if level else "", "rows": n, "kind_of_row": kind_fact,
            "columns_with_special_status": sum(1 for x in cols if x.get("filled_for")),
            "columns_in_file": len(header), "columns_with_values": sum(1 for x in cols if x["rows_with_value"]),
            "columns_empty": [x["column"] for x in cols if not x["rows_with_value"]],
            "keyword_columns": sum(1 for x in cols if x.get("keywords")), "keywords": sum(len(x.get("keywords") or []) for x in cols),
            "header_format": al.header_format if al else "unknown", "seconds": round(time.time() - t0, 1), "columns": cols}


def where(path, rows):
    """Where to see it: the file and its line numbers (row n of the data is line n + 1, after the header line)."""
    return "%s line %s" % (path, ", ".join(str(r + 1) for r in rows[:ROWS_PER_VALUE])) if rows else path


# ---------------------------------------------------------------------------------------------- stand-ins (no model)
def _standin_explore(prof, batch, with_summary):
    out = {"columns": []}
    for c in batch:
        kw = c.get("keywords") or []
        if kw:
            what = "%d keyword%s: %s%s" % (len(kw), "" if len(kw) == 1 else "s", ", ".join(k["value"] for k in kw[:8]), " ..." if len(kw) > 8 else "")
        elif c["type"] == "integer" and "min" in c:
            what = "numbers from %s to %s (%s different)" % (c["min"], c["max"], "{:,}".format(c["distinct"]))
        else:
            what = "%s values (%s different%s), such as %s" % (c["type"], "{:,}".format(c["distinct"]), " or more" if c["distinct_more_than_counted"] else "",
                                                              ", ".join(t["value"] for t in c["top_values"][:3]))
        out["columns"].append({"column": c["column"], "observed": "%s of %s rows hold a value: %s." % ("{:,}".format(c["rows_with_value"]), "{:,}".format(prof["rows"]), what)})
    if with_summary:
        busy = sorted([c for c in prof["columns"] if c.get("keywords")], key=lambda c: -c["rows_with_value"])[:3]
        out["summary"] = ("This file has %s rows, one %s record per row, exported by the protocol analyzer. %d of its %d columns hold values; "
                          "%d columns hold special keywords (%d different keywords in all)%s." % (
                              "{:,}".format(prof["rows"]), prof["level_label"] or "analyzer", prof["columns_with_values"], prof["columns_in_file"],
                              prof["keyword_columns"], prof["keywords"],
                              ("; the most used are in " + ", ".join(c["column"] for c in busy)) if busy else ""))
    return out


def _contents(c):
    """A column's contents in a few facts that code computed from every row (the Explorer's profile): never the rows themselves."""
    out = {"observed": str(c.get("observed") or "")[:300], "rows_with_value": c.get("rows_with_value")}
    for k in ("distinct", "min", "max"):
        if c.get(k) not in (None, ""):
            out[k] = c[k]
    tops = [{"value": t.get("value"), "count": t.get("count")} for t in (c.get("top_values") or [])[:TOP_VALUES] if isinstance(t, dict)]   # every value the Explorer kept
    if tops:
        out["most_common"] = tops
    return out


def _values_of(it):
    c = it.get("contents") or {}
    vals = [str(t["value"]) for t in c.get("most_common") or [] if t.get("value") is not None] + [str(k) for k in it.get("keywords") or []]
    return vals + [str(c[k]) for k in ("min", "max") if c.get(k) not in (None, "")]


def _approved_meanings(level):
    """{column: (dictionary, row)} from the approved data dictionaries of this level (knowledge/dictionaries/*/<file>.current.json);
    the newest approval wins. Only rows with a meaning."""
    if not level:
        return {}
    found = []
    for p in glob.glob(os.path.join(knowledge_dir(), "dictionaries", "*", "*.current.json")):
        try:
            d = json.load(open(p))
        except (OSError, ValueError):
            continue
        if isinstance(d, dict) and d.get("level") == level and d.get("approved_by"):
            found.append(d)
    out = {}
    for d in sorted(found, key=lambda d: d.get("approved_at") or 0):
        for c in d.get("columns") or []:
            if isinstance(c, dict) and c.get("column") and str(c.get("meaning") or "").strip():
                out[c["column"]] = (d, c)
    return out


def _reused_answer(column, known):
    d, c = known
    kws = {}
    for k in c.get("keywords") or []:
        if isinstance(k, dict) and (k.get("value") or k.get("keyword")) and str(k.get("meaning") or "").strip():
            kws[k.get("value") or k.get("keyword")] = {"meaning": k["meaning"], "source": k.get("source") or {}, "checked": True, "why": "approved earlier",
                                                         "status": k.get("status") or ""}
    on = time.strftime("%Y-%m-%d", time.localtime(d["approved_at"])) if d.get("approved_at") else ""
    return {"column": column, "meaning": str(c["meaning"]).strip(), "source": c.get("source") or {}, "keyword_map": kws,
            "reused": {"file": d.get("file") or os.path.basename(str(d.get("path") or "")), "by": d.get("approved_by"), "on": on}}


def _plain_problem(why):
    """A failed model call in words (the same meanings as the Settings test)."""
    w = str(why)
    for pat, words in ((r"cut off", "the answer was longer than one call may write; the part is asked again in two halves"),
                       (r"HTTP 402", "HTTP 402: the account behind this key has no credit left or its budget is used up"),
                       (r"HTTP 401", "HTTP 401: the key was refused"), (r"HTTP 403", "HTTP 403: this key may not use this model or address"),
                       (r"HTTP 404|not_found_error|unrecognized_model|issue with the selected model", "the model name or the address was not found"),
                       (r"no API key", "no API key is saved (Settings -> Model connection)"), (r"HTTP 429|rate limit", "too many calls at the moment (HTTP 429)"),
                       (r"HTTP 5\d\d|overloaded", "the model service had a problem or is overloaded"),
                       (r"timed out|timeout|TimeoutExpired", "the call ran out of time"),
                       (r"refused|getaddrinfo|Name or service not known|unreachable|No route", "the address cannot be reached from this computer"),
                       (r"the run was stopped", "the run was stopped")):
        if re.search(pat, w, re.I):
            return words
    return w.strip()[:160] or "no model answered"


def _doc_meaning(it):
    """The last answer when the model gave none: the reference document's own words about the column, if a snippet was found
    for it (a real source); otherwise None, and the column stays without a meaning for the admin (owner, 2026-11-11: no text
    written by code)."""
    if not it.get("snippets"):
        return None
    s = it["snippets"][0]
    return {"column": it["column"], "meaning": s["quote"][:240], "source": {"kind": "document", "ref": s["ref"], "quote": s["quote"][:160]}, "keywords": []}


def _standin_ground(items):
    out = []
    for it in items:
        if not it["snippets"]:
            continue
        s = it["snippets"][0]
        out.append({"column": it["column"], "meaning": s["quote"][:240],
                    "source": {"kind": "document", "ref": s["ref"], "quote": s["quote"][:160]}, "keywords": []})
    return {"columns": out}


EXPLORE_INSTRUCTION = """You are the Data Explorer of one CSV file exported by a Teledyne LeCroy PCIe/NVMe protocol
analyzer. You know ONLY the data: CONTEXT holds the profile that code computed from EVERY row of the file (each column's
number "n", its type, how many rows hold a value, how many different values, its top values, and its special keywords: the
WORDS the column holds, such as ACK, UpdateFC-P, CplD, Link Up; numbers are never keywords). The counts are exact: repeat
them as they are, never estimate. Describe only what the data holds. Do NOT say what a column or a keyword means in protocol
terms: another agent (the Grounder) does that. For each column write "n" (its number, as given; do not repeat its name) and
"observed": one plain sentence of what the data holds (for example "99,088 rows hold a value; keywords: ACK, UpdateFC-P,
UpdateFC-NP, PM_Request_Ack"). When CONTEXT asks for a summary, write "summary": 3 to 5 plain sentences for a reader who
has never seen this file: what one row is (file_facts may name the column that tells the kinds of row apart, with their
counts), what the file records, how big it is, which columns carry most of the information, which keywords stand out."""
EXPLORE_SHAPE = '{"summary": "... (only when asked)", "columns": [{"n": <the column\'s number in CONTEXT>, "observed": "..."}]}'

GROUND_INSTRUCTION = """You are the Data Grounder of one CSV file exported by a Teledyne LeCroy PCIe/NVMe protocol
analyzer. CONTEXT gives each column with a number "n", its name, the special keywords found in it and a summary of its
contents that code computed from every row (what the Data Explorer observed, its most common values with their counts, its
smallest and largest value; never the rows themselves). "filled_on", when a column has it, was counted by code on every row:
the only kinds of row (the commands, the packet types, the transaction types) that hold a value in this column. The column
is then a field of exactly those kinds of row: give its meaning for them and name them; never describe it as a field of
every row. Find what each column and each keyword means, and say where you found it.
Look in this order: (1) the snippets of the reference documents given in CONTEXT: kind "document", ref exactly as given,
quote copied from the snippet; (2) the web, when it is allowed (see THE WEB below): kind "web", ref = the page's address,
quote = words copied from the page; (3) the column's name and contents, read with your knowledge of PCI Express and NVMe:
when the contents decide it, kind "data", quote = one value from its contents that shows it; otherwise kind "model"
(allowed, and shown to the admin as such). One short plain sentence per meaning, 25 words at most. Leave a meaning empty
only when neither documents, the web, the name nor the contents tell it: never invent.
THE FORM OF THE ANSWER: one entry per column, known by its number "n" (do not repeat its name). Each keyword is a short
list: the keyword exactly as given, its meaning, the kind; for document and web two more, the ref and the quote. Give
every keyword listed under a column. Write nothing that is not asked for: the answer is read by a program."""
GROUND_RETRY_NOTE = """

THE WEB COULD NOT BE USED for these columns (the first try gave no meaning for them): understand each column from its name
and the data it holds (its most common values with their counts, its smallest and largest value, its keywords, what the Explorer
observed, the kinds of row that fill it), read with your knowledge of PCI Express and NVMe: kind "data" when the values decide it
(quote one of them), else "model"."""
# the answer's form decides how long a call takes (owner, 2026-11-11: "proper structuring will help in producing the output"): the
# model writes the answer token by token, so nothing is asked twice. A column is named by its number, a keyword is a list and
# not an object with five field names, and "ref" and "quote" are left out where the code knows them (data: the column itself;
# model: none). For 20 columns with 15 keywords each that is about a third of the text of the long form.
GROUND_SHAPE = ('{"columns": [{"n": <the column\'s number in CONTEXT>, "meaning": "...", "kind": "document|web|data|model", '
                '"ref": "<document: file:line as given; web: the address; leave out for data and model>", '
                '"quote": "<document, web: words copied exactly; data: one value of the column; leave out for model>", '
                '"keywords": [["<keyword as given>", "<its meaning>", "<kind>", "<ref: document and web only>", "<quote: document and web only>"]]}]}')
_KINDS = ("document", "web", "data", "model")


def _source(o, column, keyword=None):
    """Where one meaning comes from, read from the short form (kind, ref, quote beside the meaning) or the long one (a "source"
    object). What the code knows is filled in by the code: a "data" meaning points at its own column (and a keyword is its own
    value there); a "model" meaning has no reference and no quote."""
    src = o.get("source") if isinstance(o.get("source"), dict) else o
    kind = str(src.get("kind") or "model").strip().lower()
    if kind not in _KINDS:
        kind = "model"
    ref, quote = str(src.get("ref") or "").strip(), str(src.get("quote") or "").strip()
    if kind == "data":
        ref = column
        if keyword and not quote:
            quote = keyword
    elif kind == "model":
        ref, quote = "model knowledge", ""
    return {"kind": kind, "ref": ref, "quote": quote}


def _read_answers(ans, batch):
    """The model's answer to one call -> {column: {"column", "meaning", "source", "keywords": [{"keyword", "meaning", "source"}]}},
    for the columns of that call only and only those with a meaning. A column is known by its name when the answer gives it
    (exactly, or without regard to capitals and spacing), else by its number n; a keyword by its name among the column's own
    keywords. Both forms are read: the short one that is asked for and the long one (objects with a "source")."""
    by_name = {it["column"]: it for it in batch}
    by_norm = {}
    for it in batch:
        by_norm.setdefault(core.norm(it["column"]), it)
    rows = ans.get("columns") if isinstance(ans, dict) else None
    out = {}
    for a in rows if isinstance(rows, list) else []:
        if not isinstance(a, dict) or not str(a.get("meaning") or "").strip():
            continue
        name, it = a.get("column"), None
        if isinstance(name, str) and name.strip():
            it = by_name.get(name) or by_norm.get(core.norm(name))
        if it is None:
            try:
                n = int(a.get("n"))
                it = batch[n - 1] if 1 <= n <= len(batch) else None
            except (TypeError, ValueError, OverflowError):
                it = None
        if it is None or it["column"] in out:
            continue
        col = it["column"]
        mine = {core.norm(k): k for k in it.get("keywords") or []}
        kws, seen = [], set()
        for k in a.get("keywords") if isinstance(a.get("keywords"), list) else []:
            if isinstance(k, dict):
                word, meaning, o = k.get("keyword") or k.get("value"), k.get("meaning"), k
            elif isinstance(k, (list, tuple)) and len(k) >= 2:
                word, meaning = k[0], k[1]
                o = {"kind": k[2] if len(k) > 2 else "", "ref": k[3] if len(k) > 3 else "", "quote": k[4] if len(k) > 4 else ""}
            else:
                continue
            real = mine.get(core.norm(word))
            if real is None or real in seen or not str(meaning or "").strip():
                continue
            seen.add(real)
            kws.append({"keyword": real, "meaning": str(meaning).strip(), "source": _source(o, col, real)})
        out[col] = {"column": col, "meaning": str(a["meaning"]).strip(), "source": _source(a, col), "keywords": kws}
    return out


def ground_parts(items, at_once):
    """The columns cut into the Grounder's calls -> (parts, the most meanings one part holds). A column counts 1 and each of its
    keywords 1. The work is cut into as many parts as calls may run at the same time, so that one round of calls finishes it;
    a part never holds more than GROUND_MEANINGS meanings (a longer answer takes the model minutes to write) or GROUND_BATCH
    columns, and not fewer than GROUND_MEANINGS_LEAST when there is that much. Columns filled on the same kinds of row stay
    together: a new part starts where the kind changes, once the part is half full."""
    def weight(it):
        return 1 + len(it.get("keywords") or [])
    total = sum(weight(it) for it in items)
    per = max(GROUND_MEANINGS_LEAST, min(GROUND_MEANINGS, -(-total // max(1, int(at_once or 1)))))
    parts, cur, w = [], [], 0
    for it in items:
        wi = weight(it)
        other = bool(cur) and it.get("group") != cur[-1].get("group") and 2 * w >= per
        if cur and (len(cur) >= GROUND_BATCH or w + wi > per or other):
            parts.append(cur)
            cur, w = [], 0
        cur.append(it)
        w += wi
    if cur:
        parts.append(cur)
    return parts, per


def _for_model(n, it):
    """A column as the Grounder's model gets it: its number in this call and only what holds something."""
    out = {"n": n, "column": it["column"], "type": it["type"], "keywords": it["keywords"], "contents": it["contents"]}
    if it.get("header_cell") and it["header_cell"] != it["column"]:
        out["header_cell"] = it["header_cell"]
    if it.get("filled_on"):
        out["filled_on"] = it["filled_on"]
    if it.get("snippets"):
        out["snippets"] = it["snippets"]
    return out


# ---------------------------------------------------------------------------------------------- the run
def steps(params, project):
    files = inventory(project.get("folder"))
    out = [{"key": "director", "title": "Director: list the CSVs of the folder and what each one is", "family": "1", "agent": "Director"}]
    for f in files:
        n = f["name"]
        out += [
            {"key": "explore:" + n, "title": "Data Explorer: every row and column of %s (the data)" % n, "family": "1", "agent": "Data Explorer", "input": {"file": f}},
            {"key": "ground:" + n, "title": "Data Grounder: what the columns and keywords of %s mean" % n, "family": "1", "agent": "Data Grounder", "input": {"file": f}},
            {"key": "manager:" + n, "title": "Manager: the data dictionary of %s, for your review" % n, "family": "1", "agent": "Manager", "review": True, "input": {"file": f}},
        ]
    return out


def refs_of(ctx):
    p = ctx.project
    folders = [x for x in (core.jload(p.get("refs"), []) or []) if x]
    return core.References(folders, os.path.join(ctx.engine.runner.sandbox_root, "_pdf_cache"))


def run_step(ctx):
    key = ctx.step["key"]
    if key == "director":
        files = inventory(ctx.project.get("folder"))
        if not files:
            raise RuntimeError("no CSV file in the folder %s" % ctx.project.get("folder"))
        problem = folder_problem(files)
        if problem:
            raise RuntimeError(problem)
        return core.Result({"files": files, "references": core.jload(ctx.project.get("refs"), [])})
    kind, _, name = key.partition(":")
    f = ctx.input["file"]
    if kind == "explore":
        return _explore(ctx, f)
    if kind == "ground":
        return _ground(ctx, f)
    if kind == "manager":
        return _manager(ctx, f)
    raise RuntimeError("unknown step %s" % key)


def _slim(c, k=25):
    """A column as the Explorer's model sees it: the counts, the top values and up to k keywords."""
    return {key: c[key] for key in ("column", "type", "rows_with_value", "filled_pct", "distinct", "distinct_more_than_counted", "min", "max") if key in c} | {
        "top_values": [{"value": t["value"], "count": t["count"]} for t in c["top_values"][:6]],
        "keywords": [t["value"] for t in (c.get("keywords") or [])[:k]]}


def _explore(ctx, f):
    ctx.progress("Data Explorer: reading every row of %s by code" % f["name"])
    prof = full_profile(f["path"], f["level"], progress=lambda t: ctx.progress(t + " · Data Explorer"), share=(0.0, 70.0))      # reading is the first 70% of this step
    runner = ctx.engine.runner
    box = runner.sandbox(ctx.run["id"], "explorer_" + f["name"])
    filled = [c for c in prof["columns"] if c["rows_with_value"]]
    head = {k: prof[k] for k in ("rows", "level_label", "columns_in_file", "columns_with_values", "keyword_columns", "keywords")}
    if prof.get("kind_of_row"):
        head["kind_of_row"] = prof["kind_of_row"]["text"]
    # (owner, 2026-11-11: "do the requests simultaneously") the columns are cut into as many parts as model calls run at the same
    # time, each of EXPLORE_LEAST to BATCH columns, and the parts are asked together; before, one part of 120 after the other
    at_once = runner.calls_at_once()
    size = max(EXPLORE_LEAST, min(BATCH, -(-len(filled) // max(1, at_once))))
    parts = [filled[i:i + size] for i in range(0, max(1, len(filled)), size)]
    observed, producers, lock, state, t0 = {}, set(), threading.Lock(), {"done": 0, "summary": ""}, time.time()

    def say():
        ctx.progress("%d%% · %s: all %s lines read · the model describes the %d columns that hold a value: %d of %d part%s done, up to %d calls at the same time · "
                     "%s so far · Data Explorer" % (70 + 29 * state["done"] // len(parts), f["name"], _n(prof["rows"]), len(filled), state["done"], len(parts),
                                                    "" if len(parts) == 1 else "s", runner.slots.limit, core.fmt_secs(time.time() - t0)))

    def one(k_batch):
        k, batch = k_batch
        want = k == 0                           # the summary of the file is asked once, with the first part
        ans, producer, _ = runner.ask(ctx.run["id"], "explorer_%s%s" % (f["name"], "" if k == 0 else "_part%d" % (k + 1)), EXPLORE_INSTRUCTION,
                                      {"file": f["name"], "file_facts": head, "write_summary": want, "columns": [dict(_slim(c), n=i + 1) for i, c in enumerate(batch)]},
                                      EXPLORE_SHAPE, "columns", lambda: _standin_explore(prof, batch, want))
        by_name, got = {c["column"]: c for c in batch}, {}
        for a in ans.get("columns") if isinstance(ans.get("columns"), list) else []:
            if not isinstance(a, dict):
                continue
            c = by_name.get(a.get("column")) if isinstance(a.get("column"), str) else None
            if c is None:
                try:
                    n = int(a.get("n"))
                    c = batch[n - 1] if 1 <= n <= len(batch) else None
                except (TypeError, ValueError, OverflowError):
                    c = None
            if c is not None:
                got[c["column"]] = str(a.get("observed") or "")[:400]
        with lock:
            observed.update(got)
            producers.add(producer)
            state["done"] += 1
            if want:
                state["summary"] = str(ans.get("summary") or "").strip()
        say()

    say()
    with ThreadPoolExecutor(max_workers=max(1, min(len(parts), runner.CALLS_MOST))) as pool:
        list(pool.map(one, list(enumerate(parts))))
    summary = state["summary"] or _standin_explore(prof, [], True)["summary"]
    for c in prof["columns"]:
        c["observed"] = observed.get(c["column"]) or (_standin_explore(prof, [c], False)["columns"][0]["observed"] if c["rows_with_value"] else "no row holds a value")
    memory = dict(prof, summary=summary, made=time.time(), agent="Data Explorer")
    path = os.path.join(box, "memory.json")
    with open(path, "w") as fh:
        json.dump(memory, fh, indent=1)
    return core.Result({"memory_file": path, "rows": prof["rows"], "columns_with_values": prof["columns_with_values"], "columns_in_file": prof["columns_in_file"],
                        "keywords": prof["keywords"], "seconds_reading": prof["seconds"], "summary": summary,
                        "kind_of_row": (prof.get("kind_of_row") or {}).get("text", ""), "columns_with_special_status": prof.get("columns_with_special_status", 0),
                        "model_parts": len(parts), "seconds_model": round(time.time() - t0, 1)}, producer=", ".join(sorted(producers)))


def _terms(column, keywords):
    terms = [column]
    leaf = column.partition(".")[2]
    if leaf:
        terms.append(leaf)
    terms += [k for k in keywords[:3] if 2 <= len(k) <= 40]
    return list(dict.fromkeys(t for t in terms if t))


def _ground(ctx, f):
    ex = ctx.output_of("explore:" + f["name"])
    mem = json.load(open(ex["memory_file"]))
    refs = refs_of(ctx)
    runner = ctx.engine.runner
    web_ok = runner.can_search_web()
    t0, head = time.time(), "Data Grounder · %s: " % f["name"]
    filled = [c for c in mem["columns"] if c["rows_with_value"]]
    items, said = [], 0.0
    for i, c in enumerate(filled):
        kws = [k["value"] for k in (c.get("keywords") or [])][:GROUND_KEYWORDS]
        snips = []
        if refs.folders:
            if time.time() - said >= 1:         # the first look-up reads the documents: the line says what is going on
                said = time.time()
                ctx.progress("0%% · %slooking up the reference documents for column %d of %d · %s so far" % (head, i + 1, len(filled), core.fmt_secs(time.time() - t0)))
            for t in _terms(c["column"], kws):
                snips += refs.search(t, limit=2)
        ff = c.get("filled_for") or {}
        items.append({"column": c["column"], "header_cell": c.get("header_cell"), "type": c["type"], "keywords": kws, "snippets": snips[:4],
                      "contents": _contents(c), "filled_on": ff.get("text") or "", "group": ff.get("rows") or ""})
    t_refs = time.time() - t0
    # (owner, 2026-11-11: "if it already has the column names, just use the description of the column, else go for finding") a column
    # whose meaning is in an approved data dictionary of the same level is taken from there, with its source; only the others are asked
    known = _approved_meanings(f.get("level"))
    reused = [it for it in items if it["column"] in known]
    items = [it for it in items if it["column"] not in known]
    answers, producers = [_reused_answer(it["column"], known[it["column"]]) for it in reused], set()
    if reused:
        producers.add("%d meaning%s reused from the approved dictionary" % (len(reused), "" if len(reused) == 1 else "s"))
    # (owner, 2026-11-11: "look at the number of cores and do the calls simultaneously ... proper structuring will help") the columns
    # that the same kinds of row fill go together, the work is cut into as many parts as calls run at the same time (see
    # ground_parts), and every part is asked at once: the runner's places (AgentRunner.slots) decide how many are at the model
    order = {}
    for it in items:
        order.setdefault(it["group"], len(order))
    items.sort(key=lambda it: order[it["group"]])
    at_once = runner.calls_at_once()
    parts, per = ground_parts(items, at_once)
    total = len(items) + len(reused)
    state = {"done": 0, "cols": 0, "meant": 0, "retries": 0, "problem": "", "fatal": "", "secs": [], "most": 0}
    lock, stop = threading.Lock(), threading.Event()
    at_model = {}                     # part number -> [since, what it is doing, True once it has its place among the calls]
    limit = runner.timeout * (2 if web_ok else 1)
    kind_text = (mem.get("kind_of_row") or {}).get("text") or ""

    def say(after="", final=False):
        with lock:
            done, cols, meant, retries, problem = state["done"], state["cols"], state["meant"], state["retries"], state["problem"]
            secs = list(state["secs"])
            # a call that just gave its place back is still listed here for a moment: the runner's own count of the places
            # taken is the upper bound, so the number shown is never above the calls really running
            there = min(sum(1 for c in at_model.values() if c[2]), runner.slots.active)
            waits = [(time.time() - c[0], k, c[1]) for k, c in at_model.items() if c[2]]
        if waits:                     # the part that has waited longest; of parts that started together, the first one
            longest = max(w for w, _k, _what in waits)
            waits = sorted((x for x in waits if x[0] >= longest - 2), key=lambda x: x[1])
        bits = ["%d of %d columns done, %d with a meaning" % (cols + len(reused), total, meant + len(reused))]
        if reused:
            bits.append("%d taken from the approved dictionary" % len(reused))
        if parts:
            left, now = len(parts) - done, runner.slots.limit
            bits.append("%d part%s of at most %d meanings: %d done, %d at the model now, %d waiting for a free call" % (
                len(parts), "" if len(parts) == 1 else "s", per, done, there, max(0, left - there)))
            if runner.slots.refused:
                bits.append("the model service said 'too many calls' %d time%s, so now up to %d calls at the same time" % (
                    runner.slots.refused, "" if runner.slots.refused == 1 else "s", now))
            else:
                bits.append("up to %d calls at the same time" % now)
            if secs and left > 0:
                avg = sum(secs) / len(secs)
                bits.append("a call takes about %s; about %s left" % (core.fmt_secs(max(1, avg)), core.fmt_secs(max(1, avg * -(-left // max(1, now))))))
        if retries:
            bits.append("%d part%s retried without the web" % (retries, "" if retries == 1 else "s"))
        if waits and waits[0][0] >= GROUND_SLOW_AFTER:
            w, k, what = waits[0]
            bits.append("part %d has waited %s for the model (%s); a call gives up after %s and is then tried again" % (k, core.fmt_secs(w), what, core.fmt_secs(limit)))
        if problem:
            bits.append("last problem: " + problem)
        if after:
            bits.append(after)
        pct = 100 if final else min(99, 100 * (cols + len(reused)) // max(1, total))     # 100% only when the checks after the answers are done too
        ctx.progress("%d%% · %s%s · %s so far" % (pct, head, " · ".join(bits), core.fmt_secs(time.time() - t0)))

    def tick():
        while not stop.wait(10):
            say()

    def ask(batch, name, web, note="", k=0, what=""):
        """One call -> (the meanings it gave, who answered, the reason when it failed). The stand-in gives nothing here, so a failed
        call is seen as columns without a meaning and is retried. Its time at the model and, when it fails, the reason in words go to
        the status; a refused connection (no credit, key refused, model not found) stops the asking at once."""
        if state["fatal"]:
            return {}, "not asked: " + state["fatal"], ""
        with lock:
            at_model[k] = [time.time(), what, False]

        def started():                # the call has its place: from here it is at the model
            with lock:
                if k in at_model:
                    at_model[k][0], at_model[k][2] = time.time(), True
                state["most"] = max(state["most"], min(sum(1 for c in at_model.values() if c[2]), runner.slots.active))
        context = {"file": f["name"], "level": f["level_label"], "columns": [_for_model(i + 1, it) for i, it in enumerate(batch)]}
        if kind_text:
            context["kind_of_row"] = kind_text
        try:
            ans, producer, _ = runner.ask(ctx.run["id"], name, GROUND_INSTRUCTION + note, context, GROUND_SHAPE, "columns", lambda: {"columns": []},
                                          web=web, on_start=started)
        finally:
            with lock:
                was = at_model.pop(k, None)
                if was and was[2]:
                    state["secs"].append(time.time() - was[0])
        got, why = _read_answers(ans, batch), ""
        if producer.startswith("stand-in"):
            why = producer.split("(after:", 1)[1].rstrip(") ") if "(after:" in producer else "no model answered"
            plain = _plain_problem(why)
            with lock:
                state["problem"] = "part %d: %s" % (k, plain)
                if re.search(r"HTTP 40[1-4]|no API key|unrecognized_model|not_found_error|model .*not found|issue with the selected model", why, re.I):
                    state["fatal"] = plain
            say()
        return got, producer, why

    def one(k_batch):
        k, batch = k_batch
        name = "grounder_%s_part%d" % (f["name"], k + 1)
        try:
            got, producer, why = ask(batch, name, web_ok, "", k + 1, "first try: documents%s, the names and data" % (", the web" if web_ok else ""))
            used = [producer]
            if "cut off" in why and not state["fatal"]:     # the answer was longer than one call may write: the same question in two halves
                half = -(-len(batch) // 2)
                for j, part in enumerate(p for p in (batch[:half], batch[half:]) if p):
                    more, producer, _why = ask(part, "%s_half%d" % (name, j + 1), web_ok, "", k + 1, "the first answer was too long: asked again in two halves")
                    got.update(more)
                    used.append(producer + " (asked in two halves: the first answer was cut off)")
            missing = [c for c in batch if c["column"] not in got]
            if missing and not state["fatal"]:   # retry 1 (owner, 2026-11-11): without the web, from each column's name and contents
                with lock:
                    state["retries"] += 1
                more, producer, _why = ask(missing, name + "_retry", False, GROUND_RETRY_NOTE, k + 1, "retry without the web, from the names and data")
                got.update(more)
                used.append(producer + " (retry without the web)")
                missing = [c for c in batch if c["column"] not in got]
            if len(missing) > 1 and not state["fatal"]:      # retry 2: the same, in two smaller halves
                half = -(-len(missing) // 2)
                for j, part in enumerate((missing[:half], missing[half:])):
                    more, producer, _why = ask(part, "%s_retry%d" % (name, j + 2), False, GROUND_RETRY_NOTE, k + 1, "retry in smaller halves")
                    got.update(more)
                    used.append(producer + " (retry in halves)")
                missing = [c for c in batch if c["column"] not in got]
            if missing:               # last: a reference document's snippet, if one was found for it; never a text written by code
                for c in missing:     # (owner, 2026-11-11: "it should not be written"): without a source the column stays without a meaning
                    m = _doc_meaning(c)
                    if m:
                        got[c["column"]] = m
                left = len([c for c in batch if c["column"] not in got])
                if left:
                    used.append("%d column%s without a meaning after 3 tries" % (left, "" if left == 1 else "s"))
            with lock:
                state["meant"] += len(got)
            return list(got.values()), "; ".join(dict.fromkeys(used)), left if missing else 0
        finally:
            with lock:
                state["done"] += 1
                state["cols"] += len(batch)

    say()
    ticker = threading.Thread(target=tick, daemon=True)
    ticker.start()
    without = 0
    try:
        with ThreadPoolExecutor(max_workers=max(1, min(len(parts), runner.CALLS_MOST))) as pool:
            for got, producer, left in pool.map(one, list(enumerate(parts))):
                without += left
                for bit in producer.split("; "):        # every way a part was answered, said once (not once per part)
                    if not re.match(r"\d+ columns? without a meaning", bit):
                        producers.add(bit)
                answers += got
                say()                       # the line moves with every part that comes back, besides every 10 s
    finally:
        stop.set()
    if without:
        producers.add("%d column%s without a meaning after 3 tries" % (without, "" if without == 1 else "s"))
    if state["fatal"]:                # the model could not be reached at all: the step stops with the reason, for "Run it again" after the fix
        say()
        raise RuntimeError("The Data Grounder could not reach the model: %s. Fix it in Settings -> Model connection (Save and test the connection), "
                           "then press Run it again." % state["fatal"])
    t_calls = time.time() - t0 - t_refs
    # the web pages the answers quote are opened by the program itself, several at the same time (before: one after the other,
    # up to 25 s each, which was most of the step's time when the web was used); the quotes are then checked on the pages kept
    web, t1 = runner.web_sources(), time.time()
    urls = []
    if web is not None:
        for a in answers:
            if a.get("reused"):
                continue
            for src in [a.get("source") or {}] + [k.get("source") or {} for k in a.get("keywords") or []]:
                if src.get("kind") == "web" and str(src.get("ref") or "").strip():
                    urls.append(str(src["ref"]).strip())
        urls = list(dict.fromkeys(urls))
        if urls:
            def page(u):
                if ctx.run["id"] not in runner.cancelled:
                    web.text(u)
            say("all answers are in; checking the quotes on %d web page%s: 0 opened" % (len(urls), "" if len(urls) == 1 else "s"))
            with ThreadPoolExecutor(max_workers=min(8, len(urls))) as pool:
                for n, _done in enumerate(as_completed([pool.submit(page, u) for u in urls]), 1):
                    say("all answers are in; checking the quotes on %d web page%s: %d opened" % (len(urls), "" if len(urls) == 1 else "s", n))
    seen_values = {it["column"]: _values_of(it) for it in items}        # a "data" quote must be one of the column's own values
    meanings = {}
    for a in answers:
        if not a.get("column"):
            continue
        if a.get("reused"):
            meanings[a["column"]] = {"meaning": a["meaning"], "source": a.get("source") or {}, "checked": True, "why": "approved earlier",
                                     "reused": a["reused"], "keywords": a.get("keyword_map") or {}}
            continue
        entry = {"meaning": str(a.get("meaning") or "").strip()}
        claims = core.check_claims([{"text": a["column"], "source": a.get("source") or {}}], refs=refs, web=web, data_values=seen_values)
        entry["source"], entry["checked"], entry["why"] = claims[0]["source"], claims[0]["verified"], claims[0]["why"]
        ctx.evidence(claims if entry["meaning"] else [])
        kw = {}
        for k in a.get("keywords") or []:
            if not k.get("keyword") or not str(k.get("meaning") or "").strip():
                continue
            kc = core.check_claims([{"text": "%s = %s" % (a["column"], k["keyword"]), "source": k.get("source") or {}}], refs=refs, web=web, data_values=seen_values)[0]
            kw[k["keyword"]] = {"meaning": str(k["meaning"]).strip(), "source": kc["source"], "checked": kc["verified"], "why": kc["why"]}
        entry["keywords"] = kw
        meanings[a["column"]] = entry
    t_web = time.time() - t1
    secs = state["secs"]
    timing = {"seconds_total": round(time.time() - t0, 1), "seconds_reference_lookup": round(t_refs, 1), "seconds_model_calls": round(t_calls, 1),
              "seconds_quote_checks": round(t_web, 1), "parts": len(parts), "meanings_per_part_at_most": per, "model_calls": len(secs),
              "calls_at_once_allowed": at_once, "calls_at_once_most": state["most"], "seconds_per_call_average": round(sum(secs) / len(secs), 1) if secs else None,
              "seconds_per_call_longest": round(max(secs), 1) if secs else None, "web_pages_opened": len(urls), "too_many_calls_refusals": runner.slots.refused}
    how_long = "The Data Grounder took %s for %s: %s looking up the reference documents; %s for %d model call%s in %d part%s%s; %s checking the quotes%s." % (
        core.fmt_secs(timing["seconds_total"]), f["name"], core.fmt_secs(t_refs), core.fmt_secs(t_calls), len(secs), "" if len(secs) == 1 else "s",
        len(parts), "" if len(parts) == 1 else "s",
        " (up to %d at the same time, %d at the most; a call took %s on average and %s at the longest)" % (
            at_once, state["most"], core.fmt_secs(max(1, sum(secs) / len(secs))), core.fmt_secs(max(1, max(secs)))) if secs else "",
        core.fmt_secs(t_web), " on %d web page%s" % (len(urls), "" if len(urls) == 1 else "s") if urls else "")
    memory = {"agent": "Data Grounder", "file": f["name"], "made": time.time(), "web_allowed": web_ok,
              "reference_folders": refs.folders, "timing": timing, "columns": meanings}
    box = runner.sandbox(ctx.run["id"], "grounder_" + f["name"])
    path = os.path.join(box, "memory.json")
    with open(path, "w") as fh:
        json.dump(memory, fh, indent=1)
    say(final=True)
    by = Counter(_status(m) for m in meanings.values())
    return core.Result({"memory_file": path, "columns_asked": len(items), "meanings": dict(by), "web_allowed": web_ok, "timing": timing, "how_long": how_long},
                       producer=", ".join(sorted(producers)))


def _status(m):
    """Where a meaning comes from, in words."""
    if not m or not m.get("meaning"):
        return "no meaning found"
    if m.get("reused"):
        r = m["reused"]
        return "from the approved dictionary of %s (approved by %s, %s)" % (r.get("file") or "this file", r.get("by") or "the admin", r.get("on") or "earlier")
    kind = (m.get("source") or {}).get("kind")
    if kind == "document":
        return "from a reference document" if m.get("checked") else "document quote not found: not trusted"
    if kind == "web":
        return "from a web page (checked)" if m.get("checked") else "web quote not found on the page: not trusted"
    if kind == "admin":
        return "given by the admin"
    if kind == "data":
        return "from the column's name and contents (checked: the value is in the column)" if m.get("checked") else "from the column's name and contents"
    return "from the model's knowledge (no source to check)"


def _manager(ctx, f):
    ex, gr = ctx.output_of("explore:" + f["name"]), ctx.output_of("ground:" + f["name"])
    emem = json.load(open(ex["memory_file"]))
    gmem = json.load(open(gr["memory_file"])) if gr.get("memory_file") and os.path.exists(gr["memory_file"]) else {"columns": {}}
    edits = ctx.input.get("edits") or {}
    rows = []
    for c in emem["columns"]:
        if not c["rows_with_value"]:
            continue
        g = gmem["columns"].get(c["column"]) or {}
        if c["column"] in edits:
            g = dict(g, meaning=edits[c["column"]], source={"kind": "admin", "ref": ctx.project.get("admin") or "admin", "quote": ""}, checked=True)
        kws = []
        for k in c.get("keywords") or []:
            gk = (g.get("keywords") or {}).get(k["value"]) or {}
            kws.append({"value": k["value"], "count": k["count"], "rows": k["rows"], "where": where(f["path"], k["rows"]),
                        "meaning": gk.get("meaning", ""), "status": _status(gk), "source": gk.get("source")})
        first_rows = (c["top_values"][0]["rows"] if c["top_values"] else [])
        rows.append({"column": c["column"], "type": c["type"], "rows_with_value": c["rows_with_value"], "distinct": c["distinct"],
                     "observed": c.get("observed", ""), "filled_for": (c.get("filled_for") or {}).get("text", ""),
                     "meaning": g.get("meaning", ""), "status": _status(g),
                     "sources": [g["source"]] if g.get("meaning") and g.get("source") and g.get("checked") else [],
                     "source": g.get("source") if g.get("meaning") else None, "where": where(f["path"], first_rows), "keywords": kws})
    counts = Counter(r["status"] for r in rows)
    dictionary = {"file": f["name"], "path": f["path"], "level": f["level"], "format_key": f["format_key"], "made": time.time(),
                  "rows": emem["rows"], "rows_estimate": emem["rows"], "summary": emem.get("summary", ""), "kind_of_row": emem.get("kind_of_row"), "columns": rows,
                  "empty_columns": emem["columns_empty"], "explorer_memory": ex["memory_file"], "grounder_memory": gr.get("memory_file")}
    box = ctx.engine.runner.sandbox(ctx.run["id"], "manager_" + f["name"])
    path = os.path.join(box, "dictionary.json")
    with open(path, "w") as fh:
        json.dump(dictionary, fh, indent=1)
    admin = ctx.project.get("admin") or "admin"
    body = ["**Admin %s, need review.** The data dictionary of **%s**." % (admin, f["name"]), "", emem.get("summary", ""), "",
            "%s rows; %d of %d columns hold values; %d special keywords." % ("{:,}".format(emem["rows"]), len(rows), emem["columns_in_file"], emem["keywords"]), ""]
    special = sum(1 for r in rows if r["filled_for"])
    if emem.get("kind_of_row") and special:
        body += ["%s %d column%s hold a value on some kinds of row only: the table says which, under what the data holds." % (
            emem["kind_of_row"]["text"], special, "" if special == 1 else "s"), ""]
    if gr.get("how_long"):
        body += [gr["how_long"], ""]
    body += ["| where the meanings come from | columns |", "|---|---|"] + ["| %s | %d |" % kv for kv in counts.most_common()]
    return core.Result({"dictionary_file": path, "counts": dict(counts)},
                       review={"title": "Data dictionary of %s" % f["name"], "body": "\n".join(body),
                               "data": {"dictionary_file": path, "summary": emem.get("summary", ""), "path": f["path"], "kind_of_row": emem.get("kind_of_row"),
                                        "timing": gr.get("timing"),
                                        "facts": {"rows": emem["rows"], "columns_in_file": emem["columns_in_file"], "columns_with_values": len(rows),
                                                  "keywords": emem["keywords"], "level": f["level_label"], "seconds_reading": emem.get("seconds")},
                                        "counts": dict(counts), "table": rows, "empty": list(emem["columns_empty"]), "spacers": blank_header_positions(f["path"]),
                                        "memories": {"explorer": ex["memory_file"], "grounder": gr.get("memory_file"), "dictionary": path}}})


# ---------------------------------------------------------------------------------------------- the Manager answers the admin
DATA_WORDS = re.compile(r"\b(row|rows|line|lines|how many|count|which|where|show|appear|present|value|values|keyword|keywords|data|hold|holds|contain|contains|find|list)\b", re.I)
MEANING_WORDS = re.compile(r"\b(mean|means|meaning|stand|stands|what is|what are|why|define|definition|purpose|used for)\b", re.I)


def _lookup(path, mem, question):
    """Code first: the columns and keywords the question names, with their counts and the lines where they are."""
    q = question.lower()
    hits = []
    for c in mem["columns"]:
        if not c["rows_with_value"]:
            continue
        named = c["column"].lower() in q or (c["column"].partition(".")[2] or "~").lower() in q
        for k in c.get("keywords") or []:
            if len(k["value"]) >= 2 and re.search(r"(?<![a-z0-9])%s(?![a-z0-9])" % re.escape(k["value"].lower()), q):
                hits.append({"column": c["column"], "keyword": k["value"], "rows_holding_it": k["count"], "where": where(path, k["rows"])})
        if named:
            hits.append({"column": c["column"], "rows_with_value": c["rows_with_value"], "type": c["type"], "distinct": c["distinct"],
                         "observed": c.get("observed"), "filled_only_on": (c.get("filled_for") or {}).get("text") or "",
                         "top_values": [{"value": t["value"], "count": t["count"], "where": where(path, t["rows"])} for t in c["top_values"][:6]],
                         "keywords": [{"value": k["value"], "count": k["count"]} for k in (c.get("keywords") or [])[:30]]})
    return hits[:20]


EXPLORER_ANSWER = """You are the Data Explorer of one CSV file. Answer the admin's question from your memory of the data
(CONTEXT: the summary, the profile counted from every row, and the lines the code found for what the question names).
Use the exact counts; give the file path and line numbers where the admin can see it. Say nothing about what things
mean (that is the Grounder's). If your memory does not hold the answer, say so."""
GROUNDER_ANSWER = """You are the Data Grounder of one CSV file. Answer the admin's question about what a column or a keyword
means, from your memory (CONTEXT: the meanings you found, each with its source). Say where each meaning comes from (the
document and line, the web page, or model knowledge). If your memory does not hold it, say so; you may look it up (see
THE WEB below, when allowed) and cite the page."""


def manager_ask(engine, review, step, question, history):
    """The admin asks the Manager; the Manager asks the right helper: the Explorer for the data (with the lines where it
    is), the Grounder for a meaning (with its source), or both. -> (answer text, producer)."""
    out = core.jload(step["output"], {}) or {}
    d = json.load(open(out["dictionary_file"]))
    emem = json.load(open(d["explorer_memory"]))
    gmem = json.load(open(d["grounder_memory"])) if d.get("grounder_memory") and os.path.exists(d["grounder_memory"]) else {"columns": {}}
    data_q, meaning_q = bool(DATA_WORDS.search(question)), bool(MEANING_WORDS.search(question))
    ask = (["explorer"] if data_q or not meaning_q else []) + (["grounder"] if meaning_q or not data_q else [])
    hits = _lookup(d["path"], emem, question)
    parts, producers = [], []
    runner, run_id = engine.runner, review["run"]
    if "explorer" in ask:
        ctx = {"question": question, "file": d["path"], "summary": emem.get("summary"), "rows": emem["rows"],
               "what_the_question_names": hits, "columns": [{"column": c["column"], "rows_with_value": c["rows_with_value"], "observed": c.get("observed")}
                                                            for c in emem["columns"] if c["rows_with_value"]][:150], "conversation": history[-6:]}

        def standin():
            if hits:
                return {"answer": "; ".join(("%s = %s: %s rows, see %s" % (h["column"], h["keyword"], "{:,}".format(h["rows_holding_it"]), h["where"])) if "keyword" in h else
                                            ("%s: %s rows hold a value; %s" % (h["column"], "{:,}".format(h["rows_with_value"]), h.get("observed") or "")) for h in hits[:6])}
            return {"answer": "%s (the file %s)" % (emem.get("summary") or "", d["path"])}
        a, prod, _ = runner.ask(run_id, "explorer_answers", EXPLORER_ANSWER, ctx, '{"answer": "..."}', "answer", standin)
        parts.append("**Data Explorer (the data):** " + str(a.get("answer", "")))
        producers.append("Explorer: " + prod)
    if "grounder" in ask:
        names = {h["column"] for h in hits}
        kwn = {(h["column"], h["keyword"]) for h in hits if "keyword" in h}
        mine = {c: m for c, m in gmem["columns"].items() if c in names} or gmem["columns"]
        ctx = {"question": question, "meanings": {c: {"meaning": m.get("meaning"), "status": _status(m), "source": m.get("source"),
                                                      "keywords": {k: v for k, v in (m.get("keywords") or {}).items() if not kwn or (c, k) in kwn}}
                                                  for c, m in list(mine.items())[:80]}, "conversation": history[-6:]}

        def standin():
            got = [("%s: %s (%s)" % (c, m.get("meaning"), _status(m))) for c, m in mine.items() if m.get("meaning")][:6]
            return {"answer": "; ".join(got) if got else "I have no meaning for that yet (no document, web page or model knowledge gave one)."}
        a, prod, _ = runner.ask(run_id, "grounder_answers", GROUNDER_ANSWER, ctx, '{"answer": "..."}', "answer", standin, web=runner.can_search_web())
        parts.append("**Data Grounder (the meanings):** " + str(a.get("answer", "")))
        producers.append("Grounder: " + prod)
    asked = " and ".join({"explorer": "the Data Explorer", "grounder": "the Data Grounder"}[x] for x in ask)
    return "I asked %s.\n\n%s" % (asked, "\n\n".join(parts)), "Manager (%s)" % "; ".join(producers)


def on_approve(engine, run, step, data, admin):
    if not step["key"].startswith("manager:"):
        return
    out = core.jload(step["output"], {})
    d = json.load(open(out["dictionary_file"]))
    edits = data.get("edits") or {}
    if not isinstance(edits, dict):
        edits = {}
    by_col = {r["column"]: r for r in d["columns"]}
    unknown = []
    for key, meaning in edits.items():             # "column" or "column: keyword" (owner, 2026-11-10: keyword meanings too; a name the file does not have is refused, not ignored)
        col, _, kw = str(key).partition(":")
        col, kw = col.strip(), kw.strip()
        r = by_col.get(col) or by_col.get(str(key).strip())
        if r is None:
            unknown.append(str(key))
        elif kw and r is not by_col.get(str(key).strip()):
            k = next((k for k in r.get("keywords") or [] if k.get("value") == kw), None)
            if k is None:
                unknown.append(str(key))
            else:
                k["meaning"], k["status"], k["source"] = str(meaning), "given by the admin", {"kind": "admin", "ref": admin, "quote": ""}
        else:
            r["meaning"], r["status"], r["source"] = str(meaning), "given by the admin", {"kind": "admin", "ref": admin, "quote": ""}
    empty = set(d.get("empty_columns") or [])
    for key in list(unknown):                      # a column with no value in this recording can still be given a meaning: it is kept beside the dictionary
        if key.strip() in empty:
            d.setdefault("empty_meanings", {})[key.strip()] = {"meaning": str(edits[key]), "by": admin, "at": time.time()}
            unknown.remove(key)
    if unknown:
        raise ValueError("not in %s, so not saved: %s. Correct or remove these lines, then approve" % (d.get("file"), "; ".join(unknown)))
    d["approved_by"], d["approved_at"] = admin, time.time()
    folder = os.path.join(knowledge_dir(), "dictionaries", d["format_key"])
    os.makedirs(folder, exist_ok=True)
    n = 1 + len([x for x in os.listdir(folder) if x.startswith(os.path.splitext(d["file"])[0] + ".v")])
    d["version"] = n
    base = os.path.splitext(d["file"])[0]
    L.write_json_atomic(os.path.join(folder, "%s.v%d.json" % (base, n)), d, indent=1)
    L.write_json_atomic(os.path.join(folder, "%s.current.json" % base), d, indent=1)


def approved_dictionary(format_key, file_name):
    p = os.path.join(knowledge_dir(), "dictionaries", format_key, "%s.current.json" % os.path.splitext(file_name)[0])
    try:
        return json.load(open(p)) if os.path.exists(p) else None
    except (OSError, ValueError):            # a damaged dictionary counts as none: the data is simply learned again
        return None


def dictionaries_for_level(level):
    """Every approved dictionary of a level (any format), newest first."""
    out = []
    root = os.path.join(knowledge_dir(), "dictionaries")
    if not os.path.isdir(root):
        return out
    for fk in os.listdir(root):
        for fn in os.listdir(os.path.join(root, fk)):
            if fn.endswith(".current.json"):
                try:
                    d = json.load(open(os.path.join(root, fk, fn)))
                except (OSError, ValueError):
                    continue
                if d.get("level") == level:
                    out.append(d)
    out.sort(key=lambda d: d.get("approved_at") or 0, reverse=True)
    return out
