"""Changing, trying and discussing the rules that combine the five files, one rule at a time (owner, 2026-11-10: "an admin can change ... please do research on
this ... as a chat with LLM, so that LLM will go and analyze the data again ... checking for each and every section").

For each rule the admin can:
  settings   change the numbers the builder uses (how far a search looks ahead); the rule's words follow, and the rule asks to be checked again
  try        rebuild this recording's tree with those settings and see, rule by rule, how many rows followed it before and after
  ask        talk about the rule with an agent that may look at the recording itself through read-only queries, and that may propose settings
  note       write a correction to the rule's logic; it goes to the research of the strategy and to the developer. The logic itself is program code and does
             not change by itself: only the settings do.

Where it is kept (owner, 2026-11-10: "give the source path where the rules should be saved"), all under knowledge/, which the backup copies:
  knowledge/join_rules/<file format>/<rule>/v<N>.json and current.json   the admin's versions of a rule's words (per file format, like the strategy)
  knowledge/join_code/<file format>/<rule>/                              the code written for an admin's version (part 2)
  knowledge/join_rules/analysis_<id>.json                                one analysis's settings, notes, conversations and tries
The program's own rules stay in nvme_hier/builder.py and are never edited.
"""
import json
import os
import re
import sqlite3
import threading
import time

from . import join_rules as JR
from nvme_hier import loader as L

_LOCK = threading.Lock()
MAX_ROUNDS = 3            # rounds of queries the agent may run before it must answer
MAX_QUERIES = 3           # queries per round
QUERY_ROWS = 40           # rows of each result the agent sees
QUERY_SECONDS = 15.0      # the longest one query may run
CODE_LINES = 220          # lines of the builder the agent sees


def knowledge():
    from . import family1
    return family1.knowledge_dir()


def _path(engine, pid):
    d = os.path.join(knowledge(), "join_rules")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "analysis_%d.json" % int(pid))


def _old_path(engine, pid):
    return os.path.join(engine.runner.sandbox_root, "join_rules", "project_%d.json" % int(pid))


def load(engine, pid, project=None):
    """One analysis's workbench. A file left in runs/ by the first version is moved to knowledge/ (its rule versions go to their per-format folders)."""
    try:
        with open(_path(engine, pid), encoding="utf-8") as fh:
            wb = json.load(fh)
    except (OSError, ValueError):
        wb = {}
        try:
            with open(_old_path(engine, pid), encoding="utf-8") as fh:
                wb = json.load(fh)
            if isinstance(wb, dict) and project is not None:
                program = {j["id"]: (j["steps"], j["check"], j["when_broken"]) for j in JR.as_strategy(JR.settings_of(wb.get("settings")))}
                for rule_id, versions in (wb.pop("texts", None) or {}).items():
                    in_force = None
                    for v in versions if isinstance(versions, list) else []:     # only versions that change something (saves of the unchanged words stay behind in the old file);
                        if not isinstance(v, dict):                                 # a going back is kept only when a moved version was in force
                            continue
                        words = (v.get("steps"), v.get("check") or "", v.get("when_broken") or [])
                        if v.get("steps") and words != program.get(rule_id) and words != in_force:
                            _write_version(project, rule_id, {x: y for x, y in v.items() if x != "v"})
                            in_force = words
                        elif v.get("back_to_the_program") and in_force:
                            _write_version(project, rule_id, {x: y for x, y in v.items() if x != "v"})
                            in_force = None
                save(engine, pid, wb)
                os.replace(_old_path(engine, pid), _old_path(engine, pid) + ".moved")
        except (OSError, ValueError):
            wb = {}
    wb = wb if isinstance(wb, dict) else {}
    for k, v in (("settings", {}), ("notes", {}), ("chat", {}), ("tries", []), ("texts", {})):
        if not isinstance(wb.get(k), type(v)):
            wb[k] = v
    return wb


def save(engine, pid, wb):
    with _LOCK:
        L.write_json_atomic(_path(engine, pid), wb, indent=1)


def approved_settings(project):
    from . import family2
    try:
        fmt, _files = family2.project_format(project)
        st = family2.last_strategy(fmt) or {}
    except (OSError, ValueError, TypeError):
        st = {}
    return st.get("settings") if isinstance(st.get("settings"), dict) else None


def effective(engine, project):
    """The settings this analysis builds with: the admin's edits for it, else those approved with the strategy for this file format, else the defaults."""
    wb = load(engine, project["id"])
    return JR.settings_of(wb["settings"] or approved_settings(project))


def check_settings(given):
    """The settings as given, refused with the reason when a key is unknown or a number is outside what the builder takes."""
    from nvme_hier import builder as B
    out = {}
    for k, v in (given or {}).items():
        if k not in B.SETTING_BOUNDS:
            raise ValueError("%s is not a setting of these rules" % k)
        lo, hi = B.SETTING_BOUNDS[k]
        if isinstance(v, bool) or not isinstance(v, (int, float, str)):
            raise ValueError("%s must be a whole number" % k)
        try:
            n = int(str(v).strip())
        except ValueError:
            raise ValueError("%s must be a whole number" % k)
        if not lo <= n <= hi:
            raise ValueError("%s must be from %s to %s" % (k, "{:,}".format(lo), "{:,}".format(hi)))
        out[k] = n
    return out


# ---------------------------------------------------------------------------------------------- the admin's own version of a rule's words
def _lines(v, name, most):
    if v is None:
        return []
    if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
        raise ValueError("%s must be a list of lines" % name)
    out = [x.strip()[:1200] for x in v if x and x.strip()]
    if len(out) > most:
        raise ValueError("%s can have at most %d lines" % (name, most))
    return out


def text_dir(project, rule_id):
    """knowledge/join_rules/<file format>/<rule>: where the admin's versions of one rule's words are kept for this file format."""
    from . import family2
    fmt, _files = family2.project_format(project)
    return os.path.join(knowledge(), "join_rules", fmt, rule_id)


def code_dir(project, rule_id):
    from . import family2
    fmt, _files = family2.project_format(project)
    return os.path.join(knowledge(), "join_code", fmt, rule_id)


def text_versions(project, rule_id):
    d = text_dir(project, rule_id)
    out = []
    for name in os.listdir(d) if os.path.isdir(d) else []:
        if re.match(r"^v\d+\.json$", name):
            try:
                with open(os.path.join(d, name), encoding="utf-8") as fh:
                    out.append(json.load(fh))
            except (OSError, ValueError):
                continue
    return sorted((v for v in out if isinstance(v, dict) and isinstance(v.get("v"), int)), key=lambda v: v["v"])


def _write_version(project, rule_id, entry):
    d = text_dir(project, rule_id)
    os.makedirs(d, exist_ok=True)
    entry = dict(entry, v=1 + len(text_versions(project, rule_id)))
    path = os.path.join(d, "v%d.json" % entry["v"])
    L.write_json_atomic(path, entry, indent=1)
    L.write_json_atomic(os.path.join(d, "current.json"), dict(entry, file=path), indent=1)
    return path


def save_text(engine, project, rule_id, steps, check, when_broken, why, admin, program=None):
    """A new version of the admin's wording of one rule (owner, 2026-11-10: "these rules can be edited and saved properly"), written to
    knowledge/join_rules/<file format>/<rule>/v<N>.json and current.json. The program's own version is kept as it is; every version is kept, numbered,
    with who and when. Empty steps put the program's version back (that is a version too). Returns the file written."""
    steps = _lines(steps, "the steps", 40)
    check, when_broken = (check or "").strip()[:1200], _lines(when_broken, "the lines for a row that does not follow", 20)
    cur = current_text(project, rule_id)
    if steps:                                   # a save that changes nothing is refused (owner, 2026-11-10: saves of the unchanged text made no sense)
        mine = (steps, check, when_broken)
        if cur and (cur.get("steps"), cur.get("check") or "", cur.get("when_broken") or []) == mine:
            raise ValueError("nothing changed since your version %d" % cur["v"])
        if not cur and program and (program.get("steps"), program.get("check") or "", program.get("when_broken") or []) == mine:
            raise ValueError("nothing changed: these are the program's own words. Change a step, the check or a line first")
    elif not cur:
        raise ValueError("the program's version is already the one in force")
    entry = {"by": admin, "at": time.time(), "why": (why or "").strip()[:2000], "rule": rule_id}
    if steps:
        entry.update(steps=steps, check=check, when_broken=when_broken)
    else:
        entry["back_to_the_program"] = True
    with _LOCK:
        return _write_version(project, rule_id, entry)


def current_text(project, rule_id):
    """The admin's latest version of a rule's words (with its file), or None when the program's own version is in force."""
    try:
        with open(os.path.join(text_dir(project, rule_id), "current.json"), encoding="utf-8") as fh:
            last = json.load(fh)
    except (OSError, ValueError):
        return None
    return None if not isinstance(last, dict) or last.get("back_to_the_program") else last


# ---------------------------------------------------------------------------------------------- try the settings on this recording
def _short(checks):
    """How the rules held, without the example rows: what the page compares before and after."""
    out = {}
    for r in (checks or {}).get("rules") or []:
        out[r["id"]] = {"verdict": r.get("verdict"), "checks": [{"words": k.get("words"), "broke": k.get("broke"), "of": k.get("of"), "share": k.get("share")} for k in r.get("checks") or []]}
    return out


def try_settings(jid, params, mgr):
    """A job: the tree of this recording built again with the given settings, the rules applied again, and how every joining rule held before and after."""
    from api import hier_api as H
    from nvme_hier import builder as B, rules as RL
    from . import core
    db, d = params["db"], params["upload_dir"]
    limit = params.get("limit")
    mgr.progress(jid, "before", "how the rules hold on the tree as it is", 1)
    before = JR.evaluate(db, limit=limit)
    meta = H.read_meta(d) or {}
    mgr.progress(jid, "build", "building the tree again with the new settings", 5)
    report = B.build(db, progress=lambda step, detail, pct: mgr.progress(jid, step, "%d%% of the tree · %s" % (pct, detail), round(5 + 75 * pct / 100.0, 1)),
                     settings=params["settings"])
    mgr.progress(jid, "rules", "applying the error rules again to the new tree", 82)
    RL.apply(db, meta.get("thresholds") or {})
    con = sqlite3.connect(db)
    try:
        H.ensure_indexes(con)
    finally:
        con.close()
    mgr.progress(jid, "after", "how the rules hold on the new tree", 95)
    after = JR.evaluate(db, limit=limit)
    meta = H.read_meta(d) or {}
    meta.setdefault("result", {})["build"] = report
    meta["join_settings"] = report.get("settings")
    H.write_meta(d, meta)
    engine = params["_engine"]
    wb = load(engine, params["project"])
    wb["tries"] = (wb["tries"] + [{"at": time.time(), "by": params.get("admin"), "settings": report.get("settings"), "before": _short(before), "after": _short(after),
                                   "summary_before": before.get("summary"), "summary_after": after.get("summary")}])[-5:]
    save(engine, params["project"], wb)
    return {"settings": report.get("settings"), "summary_before": before.get("summary"), "summary_after": after.get("summary"), "seconds": core.now() - params.get("_t0", core.now())}


# ---------------------------------------------------------------------------------------------- ask about one rule; the agent may query the recording
ASK_INSTRUCTION = """You help an admin check ONE rule that combines the analyzer's CSV exports of one PCIe/NVMe recording into a tree. CONTEXT holds the rule in words,
the program code that applies it, its settings, how it held on this recording (rows that did and did not follow it), the tables of the recording with their
columns, the conversation so far and the results of any queries you asked for.

You may look at the recording yourself: put up to 3 read-only SQL queries (SQLite, SELECT or WITH ... SELECT only, one statement each, no semicolons) in
"queries". The program runs them and calls you again with the results. Ask only what you need; each result shows at most 40 rows, so count and group in SQL.
Tables: pkt (packets.csv), lnk (link.csv), spl (split.csv), ntx (NVME_Transactions.csv), cmd (nvme_command.csv); every row has rowid_file (its row in the
file), raw (every cell as JSON; json_extract(raw, '$."Column Name"')), parent, parent_level and relation (how the tree placed it).

When you have what you need, leave "queries" empty and answer. Say what the data shows, with numbers from the results; say plainly what you could not check.
If a different setting would serve this recording better, put it in "proposed_settings" with only this rule's setting names, and explain why in "answer".
You change nothing yourself: the admin decides. The rule's logic is program code; if the logic itself should change, say so in "logic_change" in plain words."""

ASK_SHAPE = '{"answer": "...", "queries": ["SELECT ..."], "proposed_settings": {}, "logic_change": ""}'
_SAFE = re.compile(r"^\s*(select|with)\b", re.I)


def run_query(db, sql):
    """One read-only query, stopped after QUERY_SECONDS; at most QUERY_ROWS rows come back. Anything but one SELECT is refused."""
    sql = (sql or "").strip().rstrip(";").strip()
    if not _SAFE.match(sql) or ";" in sql:
        return {"sql": sql[:500], "error": "only one SELECT (or WITH ... SELECT) statement is allowed"}
    try:
        from .data_chat import open_ro            # read-only, query_only, no ATTACH, an authorizer that allows only reading (research 2026-11-10: mode=ro alone still accepted ATTACH)
        con = open_ro(db)
    except sqlite3.Error as e:
        return {"sql": sql[:500], "error": str(e)}
    t0 = time.time()
    try:
        con.set_progress_handler(lambda: 1 if time.time() - t0 > QUERY_SECONDS else 0, 20000)     # query_only is set by open_ro (a second PRAGMA is refused by its authorizer)
        cur = con.execute(sql)
        cols = [c[0] for c in (cur.description or [])]
        rows = cur.fetchmany(QUERY_ROWS)
        more = cur.fetchone() is not None
        cell = lambda v: v if isinstance(v, (int, float)) or v is None else str(v)[:200]     # noqa: E731
        return {"sql": sql[:500], "columns": cols, "rows": [[cell(v) for v in r] for r in rows], "more_rows": more, "seconds": round(time.time() - t0, 2)}
    except sqlite3.Error as e:
        return {"sql": sql[:500], "error": ("stopped after %d s" % QUERY_SECONDS) if "interrupt" in str(e).lower() else str(e)[:300]}
    finally:
        con.close()


def _schema(db):
    out = {}
    try:
        con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
        for t in ("pkt", "lnk", "spl", "ntx", "cmd"):
            cols = [r[1] for r in con.execute("PRAGMA table_info(%s)" % t)]
            if cols:
                n = con.execute("SELECT MAX(rowid_file) FROM %s" % t).fetchone()[0]
                out[t] = {"columns": cols, "rows": n}
        con.close()
    except sqlite3.Error:
        pass
    return out


def _code(j):
    from nvme_hier import builder as B
    with open(B.__file__, encoding="utf-8") as fh:
        lines = fh.read().split("\n")
    c = j["code"]
    return "\n".join(lines[c["first"] - 1:min(c["last"], c["first"] - 1 + CODE_LINES)])


def ask(engine, project, rule_id, message, admin, db=None):
    """One question about one rule; the agent may run read-only queries on the recording for up to MAX_ROUNDS rounds. Returns the rule's conversation."""
    settings = effective(engine, project)
    j = next((x for x in JR.as_strategy(settings) if x["id"] == rule_id), None)
    if j is None:
        raise ValueError("no such rule")
    wb = load(engine, project["id"])
    last_try = next((t for t in reversed(wb["tries"]) if isinstance(t, dict)), None)
    ctx = {"rule": {k: j[k] for k in ("title", "from", "to", "column_map", "steps", "check", "when_broken", "settings")},
           "code": _code(j), "how_it_held_last_time_it_was_tried": ((last_try or {}).get("after") or {}).get(rule_id),
           "tables": _schema(db) if db else "no tree of this recording is built yet: answer from the rule and the code, and say that the data could not be looked at",
           "conversation": (wb["chat"].get(rule_id) or [])[-12:], "admin_question": message, "query_results": []}
    ran = []
    ans, producer = None, "stand-in (no model)"
    for rnd in range(MAX_ROUNDS + 1):
        def standin():
            held = ctx["how_it_held_last_time_it_was_tried"]
            return {"answer": "The stand-in cannot look at the data. The rule as the code applies it: %s %s" % (" ".join(j["steps"]),
                    ("How it held when last tried: %s." % json.dumps(held)) if held else "It has not been tried on this recording yet."), "queries": []}
        try:
            ans, producer, _ = engine.runner.ask("join_p%d" % project["id"], "join_%s" % rule_id, ASK_INSTRUCTION, json.dumps(ctx, default=str)[:120000], ASK_SHAPE, "answer", standin)
        except RuntimeError as e:
            ans, producer = {"answer": "No answer: %s" % e}, "nobody"
            break
        qs = [q for q in (ans.get("queries") or []) if isinstance(q, str) and q.strip()][:MAX_QUERIES]
        if not qs or not db or rnd == MAX_ROUNDS:
            break
        res = [run_query(db, q) for q in qs]
        ran += res
        ctx["query_results"] += res
    proposed = {}
    allowed = {s["key"] for s in j["settings"]}
    if isinstance(ans.get("proposed_settings"), dict):
        try:
            proposed = {k: v for k, v in check_settings({k: v for k, v in ans["proposed_settings"].items() if k in allowed}).items()}
        except ValueError:
            proposed = {}
    t = time.time()
    entries = [{"who": "admin", "by": admin, "at": t, "text": message},
               {"who": "agent", "by": producer, "at": time.time(), "text": str(ans.get("answer") or "")[:6000], "queries": ran,
                "proposed_settings": proposed, "logic_change": str(ans.get("logic_change") or "")[:2000]}]
    wb = load(engine, project["id"])
    wb["chat"][rule_id] = ((wb["chat"].get(rule_id) or []) + entries)[-60:]
    save(engine, project["id"], wb)
    return wb["chat"][rule_id]
