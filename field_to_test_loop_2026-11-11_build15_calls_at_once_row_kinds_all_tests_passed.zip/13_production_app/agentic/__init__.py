"""The agent families of the Field-to-Test Loop (owner's statement of 2026-11-07, reframed 2026-11-08).

core      the step engine (fixed steps, states, review, resume), the agent runner (Claude Code, the model over HTTP,
          or the stand-in), the evidence checks and the reference search
family1   Data Experts: one sub-family per CSV (Explorer, Grounder, Manager) -> an approved data dictionary per CSV
family2   Hierarchy: strategy (with evidence) -> admin review -> tests on real slices, breaker, independent tester -> build
family3   Rules: sections, levels, items; one JSON rule file per item; code generated from the rule; run, test, export
"""
