"""The rules that combine the five files into one tree, written the way nvme_hier/builder.py applies them (owner, 2026-11-09: "I didn't see what's the rules,
how to combine different CSVs. I want those rules to be properly verified by the admin").

Three things live here:

  RULES         each rule in plain words: which file goes into which, the columns it reads, IF/THEN steps, and what happens to a row that does not follow it.
                The words describe the code. A model may comment on a rule; it cannot rewrite it, because a rewritten sentence would change nothing the builder does.
  code_of       the lines of the builder that apply a rule and their fingerprint. The admin's check is tied to that fingerprint: if the code changes, the rule asks again.
  evaluate      how the rules held on one recording: for each rule how many rows followed it and how many did not, with example rows. A rule broken beyond the limit
                stops the tree from being accepted until the admin writes why it is accepted anyway. A row that breaks a rule is never dropped: it stays in the tree, marked.
"""
import hashlib
import json
import os
import sqlite3
import sys
import time

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if APP not in sys.path:
    sys.path.insert(0, APP)
from nvme_hier import builder as B  # noqa: E402

BREAK_LIMIT_PERCENT = 5.0       # a design choice, not a number from a specification: above it the admin must give a reason (agentic.join_break_limit_percent)
EXAMPLES = 3
EXAMPLE_SECONDS = 20.0

RULES = [
    {"id": "packets_to_links", "join": "packets -> link transaction", "title": "Packets into link transactions", "from": ["packets.csv"], "to": "link.csv", "code": "packets_to_links",
     "column_map": {"packets.csv": ["Link Dir", "TLP Type", "DLLP Type", "PSN", "AckNak Seq Num", "Time Stamp"], "link.csv": ["Link Dir", "PSN", "Metrics.# Packets", "Time Stamp"]},
     "steps": ["Both files are read from the top, one link direction (Link Dir) at a time.",
               "IF a packet has a TLP Type and its Link Dir and PSN (the packet's sequence number) match the next unused row of link.csv, THEN it opens that link transaction. "
               "The search looks at most {look_links} rows ahead, and past the first row it also needs the same Time Stamp.",
               "IF a packet repeats a PSN that is still open in its direction, THEN it joins that link transaction as a resend.",
               "IF a packet is an Ack going the other way and its AckNak Seq Num names an open PSN, THEN it joins that link transaction, and every earlier PSN that has all its packets closes with it.",
               "IF a packet is a Nak, THEN it acknowledges every open PSN up to the number it names. It joins that transaction if that one still needs a packet, otherwise the first later one that does.",
               "A link transaction is complete when it holds Metrics.# Packets packets.",
               "Every other packet (flow control, ordered sets, link events) is handled by the last rule, as context."],
     "when_broken": ["A TLP with no matching row in link.csv stays in the tree with no parent and is counted.",
                     "An Ack or Nak that names no open link transaction becomes a context packet and is counted.",
                     "A row of link.csv that no packet claimed stays in the tree with fewer packets than it says, and is counted."],
     "check": "For each row of link.csv, the packets joined equal its Metrics.# Packets.",
     "terms": ["PSN", "AckNak Seq Num", "Ack", "Nak"]},
    {"id": "links_to_splits", "join": "link transactions -> split transaction", "title": "Link transactions into split transactions", "from": ["link.csv"], "to": "split.csv", "code": "links_to_splits",
     "column_map": {"link.csv": ["Link Dir", "Mem.TLP Type", "Cpl.TLP Type", "RequesterID", "Tag", "Time Stamp"], "split.csv": ["Link Dir", "RequesterID", "Tag", "Metrics.# LinkTrans", "Time Stamp"]},
     "steps": ["A split transaction is one request that needs an answer, plus its completions. A row of split.csv is that request.",
               "IF a link transaction is such a request, THEN it joins the oldest unused row of split.csv with the same Link Dir, RequesterID and Tag. "
               "If that row's Time Stamp differs, the next {look_splits} rows with that key are tried for the exact Time Stamp.",
               "IF a link transaction is a completion, THEN it joins the oldest open split going the other way with the same RequesterID and Tag, until that split holds Metrics.# LinkTrans.",
               "Posted writes and messages need no answer: they belong to no split and go to the next rule."],
     "when_broken": ["A request with no row in split.csv, or a completion with no open split, is marked as outside and stays in the tree, counted.",
                     "A split that received fewer link transactions than Metrics.# LinkTrans keeps what it got, and is counted."],
     "check": "For each row of split.csv, the link transactions joined equal its Metrics.# LinkTrans.",
     "terms": ["RequesterID", "Tag"]},
    {"id": "units_to_ntx", "join": "link and split transactions -> NVMe transaction", "title": "Link and split transactions into NVMe transactions", "from": ["link.csv", "split.csv"], "to": "NVME_Transactions.csv", "code": "units_to_ntx",
     "column_map": {"link.csv": ["Mem.TLP Type", "Address", "Time Stamp"], "split.csv": ["Address", "Time Stamp"],
                    "NVME_Transactions.csv": ["Address", "Data", "Metrics.# Link & Split Trans", "Time Stamp"]},
     "steps": ["The candidates are the posted writes of link.csv and every row of split.csv that has an Address.",
               "Each row of NVME_Transactions.csv covers the memory from its Address for Data bytes, in 4 KB pages.",
               "IF a candidate lies in one of those pages, is at or after the row's Time Stamp and is not taken yet, THEN it is taken, earliest first, until the row holds Metrics.# Link & Split Trans.",
               "The address is what connects them. The time only says where to start looking."],
     "when_broken": ["A row of NVME_Transactions.csv that finds fewer candidates keeps the ones it found, and is counted.",
                     "A candidate that no row takes is marked as outside and stays in the tree, counted."],
     "check": "For each row of NVME_Transactions.csv, the units joined equal its Metrics.# Link & Split Trans.",
     "terms": ["Address", "Doorbell"]},
    {"id": "ntx_to_cmds", "join": "NVMe transactions -> NVMe command", "title": "NVMe transactions into NVMe commands", "from": ["NVME_Transactions.csv"], "to": "nvme_command.csv", "code": "ntx_to_cmds",
     "column_map": {"NVME_Transactions.csv": ["Type", "QID", "SQID", "CID", "Doorbell index", "Address", "Time Stamp"],
                    "nvme_command.csv": ["OPC", "SQID", "CQID", "CID", "QID", "QSIZE", "PRP1", "Metrics.# NVME Trans", "Time Stamp"]},
     "steps": ["IF a row is a submission queue doorbell (it has no CID), THEN it opens the command of that queue whose Time Stamp equals the doorbell's, because the analyzer stamps a command with its doorbell. "
               "If there is none, it opens the next unopened command of that queue, looking at most {look_cmds} rows ahead.",
               "IF a row has a SQID and a CID, THEN it joins the open command with that SQID and CID, or opens the next one with them.",
               "IF a row is a completion entry, THEN it joins that command. The first entry ends the command, and its place in the completion queue is noted.",
               "IF a row is an interrupt, THEN it joins the command of the last completion entry, one interrupt per entry.",
               "IF a row is a completion queue head doorbell, THEN its value minus 1 is the slot it consumed: it joins the waiting command in that slot, otherwise the oldest waiting command of that queue. A queue created again starts empty.",
               "A command stays open until it has its completion entry, so a late entry still finds its command."],
     "when_broken": ["A row that matches no command is marked as outside and stays in the tree, counted.",
                     "A command with fewer rows than Metrics.# NVME Trans keeps what it got, and is counted."],
     "check": "For each row of nvme_command.csv, the NVMe transactions joined equal its Metrics.# NVME Trans.",
     "terms": ["SQID", "CID", "Doorbell"]},
    {"id": "context_to_commands", "join": "context rows -> NVMe command", "title": "Other packets attached to a command as context", "from": ["packets.csv"], "to": "nvme_command.csv", "code": "context_to_commands",
     "column_map": {"packets.csv": ["Time Stamp"]},
     "steps": ["A command's time window runs from its first to its last packet, reached through the four rules above.",
               "IF a packet joined no transaction (flow control, ordered sets, link events, an Ack with nothing open) and its Time Stamp is inside a window, THEN it is attached to the most recently started window, as context.",
               "Context is the only place where the time decides, and it never counts as part of a transaction."],
     "when_broken": ["A packet outside every window stays in the tree with no command. That is normal while the link is idle, so this rule never stops the tree."],
     "check": "Context packets never change any of the counts above.",
     "terms": ["Ordered Set", "Link Event"]},
]
BY_ID = {r["id"]: r for r in RULES}
FILE_OF = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv", "nvme_command": "nvme_command.csv"}


def code_of(name):
    """(first line, last line, fingerprint) of one method of the builder."""
    with open(B.__file__, encoding="utf-8") as fh:
        lines = fh.read().split("\n")
    start = next(i for i, ln in enumerate(lines) if ln.startswith("    def %s(" % name))
    end = next((i for i in range(start + 1, len(lines)) if lines[i].startswith(("    def ", "def ", "class "))), len(lines))
    while end > start + 1 and (not lines[end - 1].strip() or lines[end - 1].lstrip().startswith("#")):
        end -= 1
    return start + 1, end, hashlib.sha1("\n".join(lines[start:end]).encode()).hexdigest()[:12]


# the numbers of a rule the admin may change for a project (owner, 2026-11-10), with what each does; the builder takes them as build(settings=)
SETTINGS = {
    "packets_to_links": [{"key": "look_links", "label": "How many rows of link.csv the PSN search may look ahead", "unit": "rows",
                          "why": "A packet opens the next unused row of link.csv with its Link Dir and PSN. When one file holds rows the other lacks, the right row can be further ahead, "
                                 "and a larger window finds it. The PSN has 12 bits, so it repeats every 4,096 TLPs in a direction: with a window of 4,096 or more a later, unrelated "
                                 "row can carry the same PSN. Past the first row the same Time Stamp is still required, which guards against that."}],
    "links_to_splits": [{"key": "look_splits", "label": "How many rows with the same Link Dir, RequesterID and Tag are tried for the exact Time Stamp", "unit": "rows",
                         "why": "A request joins the oldest unused split row with its key. Tags are reused, so the oldest row may belong to an earlier request; then the next rows with "
                                "that key are tried for the exact Time Stamp. More rows tried finds a match further away, at the cost of time on long recordings."}],
    "ntx_to_cmds": [{"key": "look_cmds", "label": "How many rows of nvme_command.csv a doorbell may look ahead for the next unopened command of its queue", "unit": "rows",
                     "why": "A submission doorbell opens the command with its Time Stamp. When none has it, the next unopened command of that queue is taken, at most this many "
                            "rows ahead. A deep queue with many commands in flight may need more."}],
}


def settings_of(given=None):
    return B.settings_of(given)


def rule_settings(rule_id, given=None):
    """{key: value} of the settings one rule uses."""
    eff = settings_of(given)
    return {s["key"]: eff[s["key"]] for s in SETTINGS.get(rule_id, [])}


def as_strategy(settings=None):
    """The rules as the joins of a strategy: what the Coder comments on and what the admin verifies, written with the settings they will be built with."""
    eff = settings_of(settings)
    defaults = settings_of(None)
    out = []
    for r in RULES:
        first, last, sha = code_of(r["code"])
        steps = []
        for text in r["steps"]:
            for k, v in eff.items():
                text = text.replace("{%s}" % k, "{:,}".format(v))
            steps.append(text)
        sets = [dict(s, value=eff[s["key"]], default=defaults[s["key"]], min=B.SETTING_BOUNDS[s["key"]][0], max=B.SETTING_BOUNDS[s["key"]][1]) for s in SETTINGS.get(r["id"], [])]
        out.append({"id": r["id"], "join": r["join"], "title": r["title"], "from": r["from"], "to": r["to"], "column_map": r["column_map"], "steps": steps, "when_broken": r["when_broken"],
                    "columns": sorted({c for cols in r["column_map"].values() for c in cols}), "rule": " ".join(steps), "check": r["check"], "terms": r["terms"], "settings": sets,
                    "code": {"file": "nvme_hier/builder.py", "function": r["code"], "first": first, "last": last, "sha": sha}})
    return out


def needs_check(verified, settings=None):
    """{rule id: why} for every rule the admin has to tick: never checked, its code changed since, or its settings changed since."""
    out = {}
    verified = verified if isinstance(verified, dict) else {}
    for j in as_strategy(settings):
        v = verified.get(j["id"])
        if not isinstance(v, dict) or not v.get("sha"):
            out[j["id"]] = "not checked yet"
        elif v.get("sha") != j["code"]["sha"]:
            out[j["id"]] = "the code that applies this rule changed since %s checked it" % v.get("by", "the admin")
        elif (v.get("settings") or rule_settings(j["id"])) != rule_settings(j["id"], settings):
            out[j["id"]] = "its settings changed since %s checked it" % v.get("by", "the admin")
    return out


def record_check(verified, ticked, admin, settings=None):
    """The admin's ticks as they are stored with the strategy, tied to the code and the settings they were made on. Raises ValueError if a rule that needs a check has no tick."""
    ticked = set(ticked or [])
    missing = [BY_ID[i]["title"] for i in needs_check(verified, settings) if i not in ticked]
    if missing:
        raise ValueError("check every rule before approving: not ticked yet: %s" % "; ".join(missing))
    verified = verified if isinstance(verified, dict) else {}
    t = time.time()
    out = {}
    for j in as_strategy(settings):
        was = verified.get(j["id"])
        kept = j["id"] not in ticked and isinstance(was, dict) and was.get("sha") == j["code"]["sha"]
        out[j["id"]] = was if kept else {"by": admin, "at": t, "sha": j["code"]["sha"], "settings": rule_settings(j["id"], settings)}
    return out


# ---------------------------------------------------------------------------------------------- how the rules held on one recording
def _ratio(s, c):
    p, ls, u, n, x = (s.get(k) or {} for k in ("packets_to_links", "links_to_splits", "units_to_ntx", "ntx_to_cmds", "context_to_commands"))
    tree_ntx = "(SELECT COUNT(*) FROM lnk x WHERE x.parent_level='nvme_transaction' AND x.parent=n.rowid_file) + (SELECT COUNT(*) FROM spl x WHERE x.parent_level='nvme_transaction' AND x.parent=n.rowid_file)"
    lnk_n = "(SELECT COUNT(*) FROM pkt p WHERE p.parent_level='link' AND p.parent=l.rowid_file)"
    spl_n = "(SELECT COUNT(*) FROM lnk l WHERE l.parent_level='split' AND l.parent=s.rowid_file)"
    cmd_n = "(SELECT COUNT(*) FROM ntx n WHERE n.parent_level='nvme_command' AND n.parent=c.rowid_file)"
    return {
        "packets_to_links": [
            ("TLP packets that found their row in link.csv", p.get("tlp_without_link_row"), p.get("tlp_packets") or p.get("packets"), False, "packets.csv",
             'SELECT n AS "Packet", dir AS "Link Dir", tlp_type AS "TLP Type", psn AS "PSN" FROM pkt WHERE relation IS NULL AND tlp_type IS NOT NULL LIMIT ?'),
            ("Ack and Nak packets that name an open link transaction", p.get("ack_nak_without_open_link"), p.get("ack_nak_packets") or p.get("packets"), False, "packets.csv",
             'SELECT n AS "Packet", dir AS "Link Dir", dllp_type AS "DLLP Type", acknak AS "AckNak Seq Num" FROM pkt WHERE relation=\'context\' AND acknak IS NOT NULL LIMIT ?'),
            ("Rows of link.csv whose packets equal Metrics.# Packets", c.get("link_rows_whose_packet_count_differs"), p.get("link_rows"), False, "link.csv",
             'SELECT l.n AS "Link Tra", l.dir AS "Link Dir", l.psn AS "PSN", l.n_packets AS "Metrics.# Packets", %s AS "packets joined" FROM lnk l WHERE l.n_packets != %s LIMIT ?' % (lnk_n, lnk_n))],
        "links_to_splits": [
            ("Requests that found their row in split.csv", ls.get("requests_without_split_row"), (ls.get("requests_matched") or 0) + (ls.get("requests_without_split_row") or 0), False, "link.csv",
             'SELECT n AS "Link Tra", dir AS "Link Dir", tlp_type AS "TLP Type", rid AS "RequesterID", tag AS "Tag" FROM lnk WHERE relation=\'orphan\' AND parent_level=\'split\' AND tlp_type NOT LIKE \'Cpl%\' LIMIT ?'),
            ("Completions that found an open split", ls.get("completions_without_open_split"), ls.get("completions") or ls.get("split_rows"), False, "link.csv",
             'SELECT n AS "Link Tra", dir AS "Link Dir", tlp_type AS "TLP Type", rid AS "RequesterID", tag AS "Tag" FROM lnk WHERE relation=\'orphan\' AND parent_level=\'split\' AND tlp_type LIKE \'Cpl%\' LIMIT ?'),
            ("Rows of split.csv whose link transactions equal Metrics.# LinkTrans", c.get("split_rows_whose_link_count_differs"), ls.get("split_rows"), False, "split.csv",
             'SELECT s.n AS "Split Tra", s.rid AS "RequesterID", s.tag AS "Tag", s.n_links AS "Metrics.# LinkTrans", %s AS "joined" FROM spl s WHERE s.n_links != %s LIMIT ?' % (spl_n, spl_n))],
        "units_to_ntx": [
            ("Rows of NVME_Transactions.csv whose units equal Metrics.# Link & Split Trans", c.get("ntx_rows_whose_unit_count_differs"), u.get("ntx_rows"), False, "NVME_Transactions.csv",
             'SELECT n.n AS "NVMe", n.type AS "Type", n.addr AS "Address", n.n_links_splits AS "Metrics.# Link & Split Trans", %s AS "units joined" FROM ntx n WHERE n.n_links_splits != %s LIMIT ?' % (tree_ntx, tree_ntx)),
            ("Link and split transactions that belong to something", (c.get("link_outside_any_parent") or 0) + (c.get("split_outside_any_parent") or 0), (p.get("link_rows") or 0) + (ls.get("split_rows") or 0), False, "link.csv",
             'SELECT n AS "Link Tra", dir AS "Link Dir", tlp_type AS "TLP Type", addr AS "Address" FROM lnk WHERE relation=\'orphan\' AND parent_level IS NOT \'split\' LIMIT ?')],
        "ntx_to_cmds": [
            ("NVMe transactions that found their command", n.get("ntx_outside_any_command"), n.get("ntx_rows"), False, "NVME_Transactions.csv",
             'SELECT n AS "NVMe", type AS "Type", qid AS "QID", sqid AS "SQID", cid AS "CID" FROM ntx WHERE relation=\'orphan\' LIMIT ?'),
            ("Rows of nvme_command.csv whose transactions equal Metrics.# NVME Trans", c.get("command_rows_whose_transaction_count_differs"), n.get("command_rows"), False, "nvme_command.csv",
             'SELECT c.n AS "NVMe Cmd", c.sqid AS "SQID", c.cid AS "CID", c.n_ntx AS "Metrics.# NVME Trans", %s AS "joined" FROM cmd c WHERE c.n_ntx != %s LIMIT ?' % (cmd_n, cmd_n))],
        "context_to_commands": [
            ("Context packets inside a command's window", (x.get("context_packets") or 0) - (x.get("attached_to_a_command_window") or 0) if x else None, x.get("context_packets"), True, "packets.csv",
             'SELECT n AS "Packet", dir AS "Link Dir", dllp_type AS "DLLP Type", os_type AS "Ord.Set Type", link_event AS "Link Event" FROM pkt WHERE relation=\'context\' AND parent IS NULL LIMIT ?')],
    }


def _examples(db, sql):
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    t0 = time.time()
    con.set_progress_handler(lambda: 1 if time.time() - t0 > EXAMPLE_SECONDS else 0, 20000)
    try:
        cur = con.execute(sql, (EXAMPLES,))
        names = [d[0] for d in cur.description]
        return [dict(zip(names, row)) for row in cur]
    except sqlite3.Error:
        return []
    finally:
        con.close()


def _numbers(d):
    return {k: v for k, v in d.items() if isinstance(v, (int, float)) and not isinstance(v, bool)} if isinstance(d, dict) else {}


def _report(db):
    """The builder's report, with only the counts that really are numbers: a damaged record reads as no record."""
    def stored(key):
        try:
            con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
            try:
                row = con.execute("SELECT v FROM meta WHERE k=?", (key,)).fetchone()
            finally:
                con.close()
            value = json.loads(row[0]) if row else {}
        except (sqlite3.Error, ValueError, TypeError):
            value = {}
        return value if isinstance(value, dict) else {}
    rep = stored("build")
    steps = rep.get("steps") if isinstance(rep.get("steps"), dict) else {}
    unusable = {FILE_OF[k]: str(v.get("error")) for k, v in stored("load_reports").items() if k in FILE_OF and isinstance(v, dict) and v.get("error")}
    return {"steps": {k: _numbers(v) for k, v in steps.items()}, "checks": _numbers(rep.get("checks")), "unusable": unusable}


def evaluate(db, limit=BREAK_LIMIT_PERCENT, progress=None):
    """How the rules held on this recording, from the builder's own counts: one entry per rule, each with its checks and example rows. Never raises for odd data."""
    rep = _report(db)
    table = _ratio(rep["steps"], rep["checks"])
    out = []
    worst_rules = []
    for ir, r in enumerate(RULES):
        # a file that was given but could not be used: the tree was built without it, and the admin must know
        checks = [{"words": "%s was given but could not be used: %s" % (f, rep["unusable"][f]), "broke": 1, "of": 1, "percent": 100.0, "verdict": "broken", "file": f, "information_only": False, "examples": []}
                  for f in r["from"] + [r["to"]] if f in rep["unusable"]]
        for words, broke, of, info, file_name, sql in table[r["id"]]:
            if broke is None or not of:
                continue
            pct = min(100.0, round(100.0 * broke / of, 2))
            verdict = "followed" if not broke else "few" if info or pct <= limit else "broken"
            if progress:
                progress("%d of %d rules: %s" % (ir + 1, len(RULES), words[:60]))
            checks.append({"words": words, "broke": broke, "of": of, "percent": pct, "verdict": verdict, "file": file_name, "information_only": info,
                           "examples": _examples(db, sql) if broke else []})
        verdicts = {c["verdict"] for c in checks}
        verdict = "not_run" if not checks else "broken" if "broken" in verdicts else "few" if "few" in verdicts else "followed"
        if verdict == "broken":
            worst_rules.append(r["title"])
        out.append({"id": r["id"], "title": r["title"], "verdict": verdict, "checks": checks, "when_broken": r["when_broken"]})
    return {"limit_percent": limit, "rules": out, "broken": worst_rules, "must_explain": bool(worst_rules),
            "summary": ("Rules not followed by this recording: %s. The rows are kept and marked; nothing was dropped." % "; ".join(worst_rules)) if worst_rules else "Every rule was followed within the limit."}
