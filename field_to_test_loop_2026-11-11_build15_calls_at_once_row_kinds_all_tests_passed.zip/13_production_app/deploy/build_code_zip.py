#!/usr/bin/env python3
"""Builds the deployable archive field_to_test_loop_code_only.zip (and its .SHA256.txt) from this project.

    python3 deploy/build_code_zip.py [--out DIR]

The archive unzips to 13_production_app/ and holds the application, the analyser, the knowledge-base engine, the
tests, the install and operations documents (deploy/), the two HTML guides and the data files the analyser needs.
It leaves out the local databases (db/), earlier runs (runs/), samples, virtual environments and caches, so one
archive is the same for every machine.  Run it after the tests pass:

    ./run_tests.sh && python3 deploy/build_code_zip.py
"""
import argparse
import hashlib
import os
import sys
import time
import zipfile

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NAME = "field_to_test_loop_code_only"
ROOT_IN_ZIP = "13_production_app"

# directories copied whole (minus the excluded names) and single files
DIRS = ["app", "config", "data/catalogue", "data/generator", "deploy", "docs/guide_images", "docs/ui_map_images", "docs/ui_map_src", "nvme_hier",
        "stage1/pcie_isolate", "stage1/reference", "stage1/runs", "stage1/tests", "stage1/tools", "stage1/vendor",
        "stage2", "tests", "agentic"]
FILES = ["BUILD.txt", "README.md", "README_CODE_ONLY.md", "README_FIRST.md", "run_app.py", "run_tests.sh",
         "data/DEFECT_DETECTION_SPEC_485.jsonl", "data/atlas_cards_raw.json", "data/final_113_columns.csv", "data/lecroy_export_columns.json",
         "data/lecroy_real_headers.json", "data/real_headers_from_index.py", "data/customer_headers/ALL_HEADERS_INDEXED_2026-11-03_1st_pex.csv",
         "docs/errors.html", "docs/document.html", "docs/APPLICATION_MAP.html", "docs/OPERATOR_AND_BACKEND_GUIDE.html", "docs/FAQ.html", "docs/HOW_THE_APP_WORKS.html", "docs/CHANGES_2026-10-27.md", "docs/CHANGES_2026-11-11.md",
         "docs/PROVENANCE_AUDIT.md", "docs/START_HERE.md", "docs/VERIFICATION_FROM_SCRATCH.md", "docs/build_ui_map.py", "docs/shoot_ui_map.py",
         "stage1/README.md", "stage1/requirements.txt", "stage1/selfcheck.py"]
EXCLUDE_DIRS = {"__pycache__", ".pytest_cache", ".venv", "node_modules"}
EXCLUDE_SUFFIX = (".pyc", ".pyo", ".log", ".tmp")


def walk(rel):
    base = os.path.join(APP, rel)
    for root, dirs, files in os.walk(base):
        dirs[:] = sorted(d for d in dirs if d not in EXCLUDE_DIRS)
        for f in sorted(files):
            if f.endswith(EXCLUDE_SUFFIX):
                continue
            p = os.path.join(root, f)
            yield p, os.path.relpath(p, APP)


def archive_previous(out_dir):
    """Owner's rule (2026-11-03): the previous build is never lost. Before a new zip is written, the existing root zip
    (and its SHA256 file and the MAIL_SAFE copy) are moved into 14_previous_versions/<build date>_<sha8>/ next to the
    project, under dated names; the root keeps the fixed name the readmes and the GitHub rule refer to."""
    import shutil
    import time as _t
    zpath = os.path.join(out_dir, NAME + ".zip")
    if not os.path.exists(zpath):
        return None
    sha = hashlib.sha256(open(zpath, "rb").read()).hexdigest()
    stamp = _t.strftime("%Y-%m-%d", _t.localtime(os.path.getmtime(zpath)))
    vdir = os.path.join(out_dir, "14_previous_versions")
    if any(sha[:16] in open(os.path.join(vdir, d, f)).read()
           for d in (os.listdir(vdir) if os.path.isdir(vdir) else []) if os.path.isdir(os.path.join(vdir, d))
           for f in os.listdir(os.path.join(vdir, d)) if f.endswith(".SHA256.txt")):
        return None                                   # this build is already archived under its own folder
    dest = os.path.join(vdir, "%s_%s" % (stamp, sha[:8]))
    os.makedirs(dest, exist_ok=True)
    for src, dst in ((NAME + ".zip", "%s_%s.zip" % (NAME, stamp)), (NAME + ".SHA256.txt", "%s_%s.SHA256.txt" % (NAME, stamp)),
                     (NAME + "_MAIL_SAFE.zip", "%s_MAIL_SAFE_%s.zip" % (NAME, stamp)), (NAME + "_MAIL_SAFE.SHA256.txt", "%s_MAIL_SAFE_%s.SHA256.txt" % (NAME, stamp))):
        if os.path.exists(os.path.join(out_dir, src)):
            shutil.move(os.path.join(out_dir, src), os.path.join(dest, dst))
    return dest


def build(out_dir):
    import datetime as _dt
    import json
    import shutil
    import sys
    with open(os.path.join(APP, "config", "app_config.json"), encoding="utf-8") as _f:     # a production zip never ships canned answers
        _cfg = json.load(_f)
    if _cfg.get("agentic", {}).get("runtime") == "standin" or _cfg.get("llm", {}).get("backend") == "standin":
        sys.exit("config/app_config.json is on the stand-in (canned answers, often left by a test that stopped half way). Set the agents to claude-code and the model connection to http, then build again.")
    for page in ("errors.html", "document.html"):       # the two pages for the reader, kept next to the project, travel inside the zip
        src = os.path.join(os.path.dirname(APP), page)
        if os.path.isfile(src):
            shutil.copy(src, os.path.join(APP, "docs", page))
    with open(os.path.join(APP, "BUILD.txt"), "w") as _f:     # shown on page 1 and in every file-check line, so the running build is never in doubt
        _f.write("build %s\n" % _dt.datetime.now().strftime("%Y-%m-%d %H:%M"))
    moved = archive_previous(out_dir)
    if moved:
        print("previous build kept in", moved)
    zpath = os.path.join(out_dir, NAME + ".zip")
    n = size = 0
    missing = []
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for rel in FILES:
            p = os.path.join(APP, rel)
            if not os.path.isfile(p):
                missing.append(rel)
                continue
            z.write(p, ROOT_IN_ZIP + "/" + rel)
            n += 1
            size += os.path.getsize(p)
        for d in DIRS:
            if not os.path.isdir(os.path.join(APP, d)):
                missing.append(d + "/")
                continue
            for p, rel in walk(d):
                z.write(p, ROOT_IN_ZIP + "/" + rel)
                n += 1
                size += os.path.getsize(p)
    h = hashlib.sha256()
    with open(zpath, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    with open(os.path.join(out_dir, NAME + ".SHA256.txt"), "w") as f:
        f.write("%s  %s\n" % (h.hexdigest(), NAME + ".zip"))
    print("wrote %s: %d files, %.1f MB uncompressed, %.1f MB zipped, sha256 %s" %
          (zpath, n, size / 1048576, os.path.getsize(zpath) / 1048576, h.hexdigest()[:16]))
    if missing:
        print("WARNING: not found and left out: " + ", ".join(missing))
    return zpath


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.dirname(APP), help="folder for the zip (default: the folder above the app)")
    a = ap.parse_args()
    t0 = time.time()
    build(a.out)
    print("built in %.0f s" % (time.time() - t0))
    sys.exit(0)
