#!/usr/bin/env bash
# Back up the Field-to-Test Loop data. Safe while the server is running.
#
#   deploy/backup.sh [--app-dir DIR] [--out-dir DIR] [--with-runs] [--keep N] [--python PY]
#
#   --app-dir DIR   the application folder (holds run_app.py, db/, suite/, config/)  default: /opt/field-to-test-loop/current
#   --out-dir DIR   where the archive is written                                     default: /opt/field-to-test-loop/backups
#   --with-runs     also include runs/ (stage-1 outputs and stage-2 state of every run; can be large).
#                   The lab-search scratch folders runs/_bench and runs/bench_* are never included.
#   --keep N        after a successful backup, delete all but the newest N archives in --out-dir (default: keep all)
#   --python PY     Python 3 interpreter used for the database copies                default: python3
#
# Run it as the user that owns the data (the service user), e.g.  sudo -u ftl /opt/field-to-test-loop/current/deploy/backup.sh
# Running as root could leave root-owned database side files behind that the service cannot open; the script refuses.
#
# What is in the archive  ftl-backup-<YYYYmmdd-HHMMSS>.tar.gz:
#   db/*.sqlite   consistent copies made with SQLite's online backup function (no need to stop the server; the
#                 sqlite3 command-line tool is NOT needed), each checked with PRAGMA integrity_check and stored as a
#                 single file (rollback-journal mode, no -wal/-shm side files; the server switches it back to
#                 write-ahead logging when it opens it). The copy runs in a separate Python process that only reads
#                 the live database (one read transaction); it writes nothing into it. This does not break the
#                 one-process rule, which is about processes that open the knowledge base through stage2/kgdb.py.
#   db/*.jsonl    the model-answer cache and the stage-2 log (append-only files, copied as they are)
#   suite/        the generated regression tests (without __pycache__/ and .pytest_cache/)
#   config/       the configuration (the API key is not in it; it lives in /etc/field-to-test-loop/environment)
#   app/bench_hook.py  the site's bench integration (code you wrote, deploy/BENCH_INTEGRATION.md), when present
#   runs/         only with --with-runs (without __pycache__/, .pytest_cache/ and the lab scratch folders)
#   MANIFEST.txt  time, host, source folder, file list and the knowledge-base counts
# Not in the archive: samples/ (demo traces; regenerated from the page at any time), .venv/ and the program code
# (reinstall them from the release zip), the API key.
#
# Durability: the server commits every lookup and every decision as soon as it is made (db/knowledge.sqlite uses
# write-ahead logging; knowledge.sqlite-wal and -shm belong to the database while it is open). A backup therefore
# holds every decision made before it started. A lab job still running when the backup starts is not in it yet
# (see DEPLOY.md, "Durability").
set -euo pipefail

APP_DIR=${FTL_APP_DIR:-/opt/field-to-test-loop/current}
OUT_DIR=${FTL_BACKUP_DIR:-/opt/field-to-test-loop/backups}
PY=${FTL_PYTHON:-python3}
WITH_RUNS=0
KEEP=0

die() { echo "backup.sh: $*" >&2; exit 1; }

while [ $# -gt 0 ]; do
    case "$1" in
        --app-dir)   APP_DIR=${2:?--app-dir needs a value}; shift 2 ;;
        --out-dir)   OUT_DIR=${2:?--out-dir needs a value}; shift 2 ;;
        --with-runs) WITH_RUNS=1; shift ;;
        --keep)      KEEP=${2:?--keep needs a value}; shift 2 ;;
        --python)    PY=${2:?--python needs a value}; shift 2 ;;
        -h|--help)   sed -n '2,35p' "$0"; exit 0 ;;
        *)           die "unknown option: $1 (see --help)" ;;
    esac
done

[[ "$KEEP" =~ ^[0-9]+$ ]] || die "--keep must be a whole number"
APP_DIR_GIVEN=${APP_DIR%/}
APP_DIR=$(cd "$APP_DIR" 2>/dev/null && pwd -P) || die "application folder not found"
[ -d "$APP_DIR/db" ] || die "no db/ folder in $APP_DIR (is this the application folder?)"
command -v "$PY" >/dev/null 2>&1 || die "python interpreter not found: $PY"

if [ "$(id -u)" -eq 0 ]; then
    owner=$(stat -c %U "$APP_DIR/db")
    [ "$owner" = "root" ] || die "running as root, but $APP_DIR/db belongs to '$owner'; run: sudo -u $owner $0 $*"
fi

mkdir -p "$OUT_DIR"
OUT_DIR=$(cd "$OUT_DIR" && pwd -P)
STAMP=$(date +%Y%m%d-%H%M%S)
NAME="ftl-backup-$STAMP"
STAGE=$(mktemp -d "$OUT_DIR/.staging-$STAMP-XXXXXX")
trap 'rm -rf "$STAGE"' EXIT
DEST="$STAGE/$NAME"
mkdir -p "$DEST/db"

# ---- 1. databases: online, consistent copies ----
shopt -s nullglob
dbs=("$APP_DIR"/db/*.sqlite)
[ ${#dbs[@]} -gt 0 ] || echo "backup.sh: warning: no *.sqlite files in $APP_DIR/db (empty installation?)" >&2

# -I: isolated mode, ignores PYTHON* variables and the current folder. The script reads (source, target) pairs.
SQLITE_COPY='
import sqlite3, sys
src_path, dst_path = sys.argv[1], sys.argv[2]
src = sqlite3.connect(src_path, timeout=60)        # waits while the server is in the middle of a commit
dst = sqlite3.connect(dst_path)
src.backup(dst)                                    # one step: a consistent snapshot of the committed state
src.close()
dst.execute("PRAGMA journal_mode=DELETE")       # one self-contained file in the archive, no -wal/-shm
ok = dst.execute("PRAGMA integrity_check").fetchone()[0]
if ok != "ok":
    sys.exit("integrity check failed for %s: %s" % (src_path, ok))
tables = {r[0] for r in dst.execute("SELECT name FROM sqlite_master WHERE type=?", ("table",))}
counts = []
for t in ("event", "solution", "lesson", "signature", "job"):
    if t in tables:
        counts.append("%s=%d" % (t, dst.execute("SELECT COUNT(*) FROM %s" % t).fetchone()[0]))
dst.close()
print("%s integrity=ok %s" % (dst_path.rsplit("/", 1)[-1], " ".join(counts)))
'
DB_LINES=""
for db in "${dbs[@]}"; do
    line=$("$PY" -I -c "$SQLITE_COPY" "$db" "$DEST/db/$(basename "$db")") || die "copy of $db failed"
    echo "  $line"
    DB_LINES+="$line"$'\n'
done
for f in "$APP_DIR"/db/*.jsonl; do
    cp -p "$f" "$DEST/db/"
done
shopt -u nullglob

# ---- 2. folders ----
# Python caches are never backed up (they are re-created and may belong to other users).
EXCLUDES=(--exclude=__pycache__/ --exclude=.pytest_cache/)
copy_dir() {   # copy_dir <name> [rsync excludes...]
    local d=$1; shift
    if [ -d "$APP_DIR/$d" ]; then
        if command -v rsync >/dev/null 2>&1; then
            rsync -a "${EXCLUDES[@]}" "$@" "$APP_DIR/$d/" "$DEST/$d/"
        else
            cp -a "$APP_DIR/$d" "$DEST/$d"
            find "$DEST/$d" -depth \( -name __pycache__ -o -name .pytest_cache \) -type d -exec rm -rf {} +
        fi
    else
        echo "backup.sh: note: $APP_DIR/$d does not exist, skipped" >&2
    fi
}
copy_dir suite
copy_dir config
copy_dir knowledge      # rules, data dictionaries, strategies and generated code: the admin's work
if [ "$WITH_RUNS" -eq 1 ]; then
    if command -v rsync >/dev/null 2>&1; then
        copy_dir runs --exclude=/_bench/ --exclude='/bench_*/'
    else
        copy_dir runs
        rm -rf "$DEST/runs/_bench" "$DEST"/runs/bench_*
    fi
fi
# the site's bench integration (shipped as a stub; once implemented it is code that exists nowhere else)
if [ -f "$APP_DIR/app/bench_hook.py" ]; then
    mkdir -p "$DEST/app"
    cp -p "$APP_DIR/app/bench_hook.py" "$DEST/app/bench_hook.py"
fi
# samples/ is not backed up on purpose: the demo traces are regenerated from the page.

# the configuration must still be readable JSON
for c in "$DEST"/config/*.json; do
    [ -e "$c" ] || continue
    "$PY" -I -c 'import json,sys; json.load(open(sys.argv[1]))' "$c" || die "configuration file is not valid JSON: $c"
done

# ---- 3. manifest and archive ----
{
    echo "Field-to-Test Loop backup"
    echo "created:    $(date -Iseconds)"
    echo "host:       $(hostname)"
    echo "source:     $APP_DIR_GIVEN (resolved: $APP_DIR)"
    echo "with runs:  $([ "$WITH_RUNS" -eq 1 ] && echo yes || echo no)"
    echo "databases:"
    printf '%s' "$DB_LINES" | sed 's/^/  /'
    echo "files:"
    (cd "$DEST" && find . -type f ! -name MANIFEST.txt | sort | sed 's/^/  /')
} > "$DEST/MANIFEST.txt"

ARCHIVE="$OUT_DIR/$NAME.tar.gz"
tar -C "$STAGE" -czf "$ARCHIVE.part" "$NAME"
mv "$ARCHIVE.part" "$ARCHIVE"
chmod 600 "$ARCHIVE"
echo "backup written: $ARCHIVE ($(du -h "$ARCHIVE" | cut -f1))"

# ---- 4. retention ----
if [ "$KEEP" -gt 0 ]; then
    mapfile -t old < <(ls -1t "$OUT_DIR"/ftl-backup-*.tar.gz 2>/dev/null | tail -n +"$((KEEP + 1))")
    for f in "${old[@]}"; do
        rm -f -- "$f"
        echo "removed old backup: $f"
    done
fi
