# Field-to-Test Loop: running it as a production service on Linux

For the engineer or AI coding agent who puts the application on a server. Every command is meant to be copied.
`deploy/INSTALL.md` (Python, packages, pre-flight check, tests) comes first; `deploy/OPERATIONS.md` covers the
day-to-day work afterwards. This file covers the service itself: user and folders, settings, the key, systemd, the
reverse proxy, backups, restore, upgrades and the go-live checklist.

Words used here: **systemd** = the Linux service manager (`systemctl`, `journalctl`); **TLS** (Transport Layer
Security) = the encryption behind `https://`; **SSO** (single sign-on) = the company login; **OAuth2 / OIDC** (OpenID
Connect) = the protocols such logins use; **reverse proxy** = a web server (here nginx) that receives the users'
requests, checks the login and passes them to the application; **SQLite** = the file database the application uses;
**venv** = a Python virtual environment (a private set of Python packages).

---

## 0. Read this first: what the application does not do for you

| Fact (where in the code) | What it means for the deployment |
|---|---|
| No login, no user accounts (`app/server.py:4`). The operator, requester and approver names are typed into the page or sent in the request body (`app/stage2_service.py:207`). | Anyone who can reach the port can do everything, under any name. The **two-person rule** (promote, deprecate, delete need an approver different from the requester) compares typed names only: it is exactly as strong as your access control and nothing more. |
| Binds to `server.host` from the configuration, default `127.0.0.1` (`run_app.py:29`). | Keep `127.0.0.1`. **Never set `0.0.0.0`.** Users reach it through an authenticating reverse proxy (section 6) or, for a single user, an SSH tunnel. |
| `127.0.0.1` still lets **every local account on the server** connect. | Give no other people shell access to this server, or block the port for other local users (section 6.4). |
| `PUT /api/config` changes and saves settings for whoever reaches the application (`app/api/config_api.py:25-32`), including `llm.base_url` and `llm.api_key_env`. | A user could point the model endpoint at their own server and receive the API key. Set `server.lock_endpoint: true` (done in `deploy/config.production.example.json`; the shipped `config/app_config.json` has `false`): the server then refuses with 403 any change of `llm.base_url`, `llm.api_key_env`, `llm.backend` or `llm.tools` through `PUT /api/config` (`app/api/config_api.py:28-35`). Optionally also make settings read-only through the proxy (section 6.2). |
| Since 2026-11-11 the main page's Settings → "Model connection" sets the URL, the model and the **API key** for every part (`PUT /api/hier/model`, `app/api/hier_api.py` `model_put`). A key typed there is written to `~/.config/f2t/env` of the service user and, at every start, **wins over the key in the service's environment file** (`app/model_env.py` `load`). | Without the lock, anyone who reaches the page can send the calls, with the key, to another address or replace the key. With `server.lock_endpoint: true` a change of the URL, the key variable or the key there is refused with 403 (the model name can still be changed). Keep the key in the environment file only and make sure the service user has no such key file (section 5.2). |
| The lock does not cover the agents' settings (`PUT /api/agents/settings`, `app/api/agentic_api.py`: where the agents run, their model, web search, the Claude Code program path, the reference folders). | Anyone who reaches the page can change them. If they must be fixed, make that route read-only at the proxy (section 6.2). |
| Trace paths are chosen with the file picker or typed, not uploaded; **any file the service user can read** can be opened (`app/services.py` `safe_path`; since 2026-11-03 the application refuses no path, the owner's rule; `paths.allowed_csv_roots` only lists the picker's starting folders). | Limit what the service user can read with file permissions: run the service as its own user that can read only the export folder(s) and the application folder. |
| One Python process holds the knowledge base and runs every background job as a thread (`app/jobs.py`, `app/stage2_service.py`). | **Exactly one server process.** No second copy on the same folder, no gunicorn (a Python web-server launcher) with more than one worker, no load balancing across copies. |
| The built-in Flask web server prints "This is a development server" at start. | Acceptable here: one process, few users, behind nginx. Do not expose it directly. |

---

## 1. Layout

```
/opt/field-to-test-loop/                      home of the service user "ftl"
    releases/2026-10-27/13_production_app/    one unpacked release: code + .venv/ + db/ runs/ suite/ config/ samples/ knowledge/ uploads/
    current -> releases/2026-10-27/13_production_app
    backups/                                  archives written by deploy/backup.sh
/etc/field-to-test-loop/environment           the API key (mode 600, owner root)
/opt/field-to-test-loop/.config/f2t/env       the key file the Settings page would write ($HOME of ftl, set by the unit); should NOT exist in production (5.2)
/etc/systemd/system/field-to-test-loop.service
/etc/nginx/conf.d/field-to-test-loop.conf, /etc/nginx/field-to-test-loop.htpasswd
/srv/analyzer-exports/                        where the analyzer CSV exports land (your choice; read-only for ftl)
```

Why a `current` link: the application keeps its data inside its own folder (`db/`, `runs/`, `suite/`, `config/`, `knowledge/`,
`uploads/` next to `run_app.py`), and it records each run folder as an **absolute path** in `db/app.sqlite`. Starting it always as
`/opt/field-to-test-loop/current/run_app.py` keeps those paths valid across upgrades. `deploy/INSTALL.md` uses
`/opt/f2t/13_production_app` as its example; for the service, use the folders above with the same commands.

## 2. Service user and folders

```
sudo useradd --system --home-dir /opt/field-to-test-loop --shell /usr/sbin/nologin ftl
sudo mkdir -p /opt/field-to-test-loop/releases /opt/field-to-test-loop/backups
sudo chown -R ftl:ftl /opt/field-to-test-loop
sudo chmod 750 /opt/field-to-test-loop

# the analyzer export folder: readable (not writable) by ftl
sudo mkdir -p /srv/analyzer-exports
sudo chgrp ftl /srv/analyzer-exports && sudo chmod 2750 /srv/analyzer-exports
```

How exports get into `/srv/analyzer-exports` (a network share mount, an `rsync` job from the analyzer PC) is your
choice; the application only reads them. The whole release folder is owned by `ftl`: the application writes into
`db/`, `runs/`, `suite/`, `config/` and `samples/` of its own folder.

## 3. Install the code and the virtual environment

```
REL=/opt/field-to-test-loop/releases/$(date +%Y-%m-%d)
sudo -u ftl mkdir -p "$REL"
sudo -u ftl unzip -q /path/to/field_to_test_loop_code_only.zip -d "$REL"   # the zip must be readable by ftl (e.g. copy it to /tmp)
# deploy/ must be inside 13_production_app/ (INSTALL.md section 2). Mail-safe zip: also run restore_names.py (INSTALL.md).
sudo -u ftl sh -c "cd '$REL/13_production_app' && python3 -m venv .venv && .venv/bin/python -m pip install -r deploy/requirements.txt"
#   offline server: INSTALL.md section 3b
sudo ln -sfn "$REL/13_production_app" /opt/field-to-test-loop/current
```

The venv lives inside the release (`.venv/`), so a rollback switches code and packages together.

`/opt/field-to-test-loop` is mode 750 and owned by `ftl`: an administrator who is not root cannot `cd` into it or
read files there. Every command in this file therefore either uses absolute paths with `sudo -u ftl`, runs the
`cd` inside `sudo -u ftl sh -c '...'`, or (for the pre-flight check) goes through root. Working from a root shell
(`sudo -i`) also works; then prefix commands that write into the application folder with `sudo -u ftl` (or
`runuser -u ftl --`) so the files stay owned by `ftl`.

## 4. Production configuration

Start from `deploy/config.production.example.json`. Every section has a `_help` text explaining the value; keys
that start with `_` are ignored by the application (the settings page drops them from what it sends, `config_api.py:30`,
and the code reads only the keys it knows), so they may stay in the file.

```
C=/opt/field-to-test-loop/current
sudo -u ftl cp "$C/config/app_config.json" "$C/config/app_config.json.shipped"
sudo -u ftl cp "$C/deploy/config.production.example.json" "$C/config/app_config.json"
sudo -u ftl chmod 640 "$C/config/app_config.json"
sudoedit -u ftl "$C/config/app_config.json"
```

Change at least:

| Key | Set to |
|---|---|
| `llm.backend` | `sdk` (the production example; through the `anthropic` package) or `http` (the shipped default; plain HTTPS for stage 2, the `anthropic` package for stage 1's review). Both use the key and URL below; a save on Settings → Model connection turns `sdk` into `http`. `cli` needs a logged-in `claude` tool in the service user's home and is not suitable for a service. |
| `llm.base_url` | your gateway's **base address only** (e.g. `https://llm-gateway.example.com`, without `/v1`: every caller adds `/v1/messages`; a value in the file is used as written), or `""` for the public Anthropic API. With an address of your own the flow's agents run through it instead of Claude Code |
| `llm.model` | the model name your gateway or account offers |
| `llm.api_key_env` | the **name** of the variable holding the key (example: `ANTHROPIC_API_KEY`); the key itself goes in section 5 |
| `paths.allowed_csv_roots` | the export folder(s) the file picker should start in, e.g. `["/srv/analyzer-exports"]` (no path is refused; file permissions decide what can be read) |
| `stage2.bench` | `synthetic` until `app/bench_hook.py` is implemented and tested per `deploy/BENCH_INTEGRATION.md`; then `hook` |
| `stage2.search_on` | `model`; `bench` only once the hook is proven on the real drive |
| `stage1.firmware_label` | your current firmware name (used when the operator types none) |
| `kpi.manual_triage_minutes_per_run`, `kpi.manual_script_minutes_per_test` | your measured manual baselines (numbers, not text), or `null` until measured |
| `server.host` / `server.port` | keep `127.0.0.1` / `8077` (the port must match `proxy_pass` in the nginx file) |
| `server.lock_endpoint` | `true` (the production example has it; the shipped `config/app_config.json` has `false`): the server refuses with 403 any change of `llm.base_url`, `llm.api_key_env`, `llm.backend` and `llm.tools` through `PUT /api/config` (`app/api/config_api.py`), and of the URL, the key variable and the key through `PUT /api/hier/model` (Settings → Model connection). `paths.allowed_csv_roots` is not locked (it only lists the file picker's starting folders and is read at start) |
| `llm.tools` | `[]` (no web search: trace content goes only to your model endpoint); `["web_search"]` lets the proposal calls search the web. Locked by `server.lock_endpoint` |
| `agentic.web` | `false` if every connection must stay on your model endpoint: when `true` (both shipped files) the agents may search the web and the application fetches every page they quote to check it. Not locked by `server.lock_endpoint` (the Settings box "The agents may also search the web") |
| `agentic.calls_at_once` | absent or `0` = automatic: over the model connection 2 calls per processor core of the server (at least 4, at most 32). Set a number from 1 to 64 when you know how many calls your model endpoint accepts at once (Settings -> More settings -> "Model calls at the same time"; used without a restart). When the endpoint answers HTTP 429, 503 or 529 the application halves the number by itself and lets it climb back, so a number that is too high costs retries, not failures (`deploy/OPERATIONS.md` section 13) |

Then put the key in place (section 5) and run the pre-flight check (section 5.1).

Facts about settings:

- `server.*`, `paths.allowed_csv_roots` and `stage2.bench` are read once at start.
- The Settings page (`PUT /api/config`) changes only the sections `llm`, `stage1`, `stage2` and `paths`
  (`app/api/config_api.py:36-38`); `server` and `kpi` are changed only in the file. There is no Settings-page field
  for `paths.allowed_csv_roots`; with `server.lock_endpoint: true` the server refuses a change of `llm.base_url`,
  `llm.api_key_env`, `llm.backend` or `llm.tools` with 403 and the message "stop the service, edit the config file,
  start it again", and on Settings → Model connection a change of the URL, the key variable or the key with 403 "the
  model endpoint and key are locked by server.lock_endpoint: stop the service, edit the config and the environment
  file, start it again".
- Every Save on the Settings page rewrites `config/app_config.json` in place from the settings the running server
  holds in memory (`save_config`, `app/api/config_api.py:11-14`). An edit of the file while the service runs is
  therefore undone by the next Save and is ignored until a restart anyway. **To change the file: stop the service,
  edit the file, start the service again.**

```
sudo systemctl stop field-to-test-loop
sudoedit -u ftl /opt/field-to-test-loop/current/config/app_config.json
sudo systemctl start field-to-test-loop
```

## 5. The API key: an environment file readable only by root

```
sudo install -d -m 755 /etc/field-to-test-loop
sudo install -m 600 -o root -g root /dev/null /etc/field-to-test-loop/environment
sudoedit /etc/field-to-test-loop/environment
```

Content (plain `NAME=value` lines, no `export`, no quotes needed):

```
ANTHROPIC_API_KEY=sk-ant-...your-key...
```

The variable name must equal `llm.api_key_env`. systemd reads this file as root before it starts the service as
`ftl`, so `ftl` itself cannot read the file, and the key never appears in `config/app_config.json`, in the
backups or in the process command line. Rules: the variable named by `llm.api_key_env` decides; the application copies it
into `ANTHROPIC_API_KEY`, which every part reads (since 2026-11-11 it no longer gives way to a key already in
`ANTHROPIC_API_KEY`; `app/model_env.py`, `app/stage2_service.py`). **A key saved on the Settings page wins over this file**
(section 5.2). Do not put a `.env` file in the
application folder (stage 1 would read it, `stage1/pcie_isolate/llm.py:155-165`). To rotate the key: edit the
file, then `sudo systemctl restart field-to-test-loop` (details: `deploy/OPERATIONS.md` section 6). Never put the key on a command line (`VAR=sk-... command`,
`export VAR=sk-...`): it ends up in the shell history and in the process list. For a one-off command that needs the
key in a shell, type it without echo: `read -rs ANTHROPIC_API_KEY; export ANTHROPIC_API_KEY`, or load the
environment file as root as in 5.1.

### 5.1 Pre-flight check

The check (`deploy/preflight.py`, it never changes anything) must run as `ftl` (so the folder checks see the
service user's permissions) **and** with the key in its environment (otherwise the "backend sdk key" check fails).
`ftl` cannot read `/etc/field-to-test-loop/environment`, so root loads the file and then drops to `ftl`:

```
sudo sh -c 'set -a; . /etc/field-to-test-loop/environment; set +a; cd /opt/field-to-test-loop/current && exec runuser -u ftl -- .venv/bin/python deploy/preflight.py --config config/app_config.json'
```

`runuser` keeps the exported variables. The file is read by the shell here; that works for the plain `NAME=value`
lines of section 5 (a value with spaces, quotes or `$` would need quoting). Expect no FAIL line.
`preflight.py` checks the key in its own environment; it does not read the Settings page's key file (5.2).

### 5.2 The key and the URL in production: the environment file, not the Settings page

What the code does (2026-11-11):
- Settings → "Model connection" on the main page can set the URL, the model name and the key (`PUT /api/hier/model`).
  A key saved there is written to `$HOME/.config/f2t/env` of the user the server runs as (`app/model_env.py`
  `ENV_FILE`; the variable `F2T_ENV_FILE` names another file). With the shipped unit
  (`Environment=HOME=/opt/field-to-test-loop`) that is `/opt/field-to-test-loop/.config/f2t/env`: inside the unit's
  writable `ReadWritePaths=/opt/field-to-test-loop`, mode 600, owned by `ftl` (so readable by the service user), and
  not in the backups (`deploy/backup.sh` copies only the application folder).
- At every start `run_app.py` loads that file before anything else (`model_env.load`): a key in it, under
  `llm.api_key_env` or `ANTHROPIC_API_KEY`, **replaces the key from `/etc/field-to-test-loop/environment`**. Once a
  key has been saved on the page, a key rotated in the environment file is no longer used.
- The start line in the journal says which key is in use, by its source and last 4 characters (shown only for a key
  of at least 12 characters): `Model connection: <URL>, model <model>, key from this computer's environment (not set
  on the Settings page) ending ...XXXX` or `... key saved on the Settings page ending ...XXXX`.
- With `server.lock_endpoint: true` the page cannot change the URL, the key variable or the key (the fields are greyed
  out; the server answers 403); the model name can still be changed.
- With a URL of your own the flow's agents run through this connection instead of Claude Code, so every model call
  goes to that URL (`agentic/core.py` `custom_url`). When Claude Code runs them (empty URL), it runs with the same key
  and URL and `CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1`.

Recommended practice:
1. The key only in `/etc/field-to-test-loop/environment` (root, mode 600), under the name in `llm.api_key_env`
   (section 5).
2. The URL in `llm.base_url` (base address only, no `/v1`) and the model in `llm.model` of `config/app_config.json`,
   changed with the service stopped (section 4).
3. `server.lock_endpoint: true` (section 4).
4. **No key file of the service user.** Check at go-live and whenever the lock was off for a while (prints no key):
   ```
   sudo test -e /opt/field-to-test-loop/.config/f2t/env && echo "a key file written by the Settings page exists: it wins over /etc/field-to-test-loop/environment" || echo "no key file (good)"
   ```
   If it exists: compare `key_end` of `curl -fsS http://127.0.0.1:8077/api/hier/model` with the last 4 characters of
   the key you mean to use; if the page's key is the one to keep, put it into the environment file first
   (`sudoedit /etc/field-to-test-loop/environment`; never print either file). Then, with no job running
   (`deploy/OPERATIONS.md` section 1), `sudo rm /opt/field-to-test-loop/.config/f2t/env` and
   `sudo systemctl restart field-to-test-loop`.
5. After every start:
   ```
   journalctl -u field-to-test-loop -b --no-pager | grep 'Model connection:' | tail -1
   ```
   Expect your address and model and `key from this computer's environment (not set on the Settings page) ending ...`
   with the last 4 characters of your key.
6. Settings → **Save and test the connection** (with the lock on and nothing changed it only tests): both lines ✔.
   What each error means (HTTP 402 = no credit or budget left on the account, and the others): `deploy/OPERATIONS.md`
   section 6.
7. With a company URL, `agentic.web: false` and `llm.tools: []` keep every connection on that URL (section 4).
8. Rotating the key: `deploy/OPERATIONS.md` section 6, "Rotating the key".

## 6. Access: the authenticating reverse proxy

### 6.1 The systemd unit

```
sudo install -m 644 /opt/field-to-test-loop/current/deploy/field-to-test-loop.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now field-to-test-loop
systemctl status field-to-test-loop --no-pager          # expect: active (running)
curl -fsS -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8077/api/config   # expect: 200
```

What the unit does (`deploy/field-to-test-loop.service`): runs as `ftl`, starts
`/opt/field-to-test-loop/current/.venv/bin/python run_app.py --config .../config/app_config.json`, reads the key
from the environment file, restarts on failure (at most 5 times in 5 minutes), and applies sandboxing that leaves
only `/opt/field-to-test-loop` writable (`ProtectSystem=strict`, `ReadWritePaths=/opt/field-to-test-loop`,
`ProtectHome=yes`, a private `/tmp`, no extra privileges). Adjust it when:

- the exports are under `/home`: change `ProtectHome=yes` to `ProtectHome=read-only`;
- you use a hardware bench (`stage2.bench: "hook"`): the hardened unit blocks it (`ProtectKernelTunables=yes`
  makes all of `/sys` read-only, the empty `CapabilityBoundingSet=` removes `CAP_SYS_ADMIN`, and `ftl` has no access
  to `/dev/nvme*`). Keep the unit as it is and add the drop-in from "Running with a hardware bench" below;
- your venv is elsewhere: change `ExecStart`.

### 6.2 nginx with TLS and a login (several users)

```
sudo apt install nginx apache2-utils               # RHEL: sudo dnf install nginx httpd-tools
sudo cp /opt/field-to-test-loop/current/deploy/nginx-field-to-test-loop.conf /etc/nginx/conf.d/field-to-test-loop.conf
sudoedit /etc/nginx/conf.d/field-to-test-loop.conf  # server_name, the origin "https://ftl.example.com", certificate paths
sudo htpasswd -c -B /etc/nginx/field-to-test-loop.htpasswd alice      # -c only for the first user
sudo htpasswd -B /etc/nginx/field-to-test-loop.htpasswd bob
sudo chown root:www-data /etc/nginx/field-to-test-loop.htpasswd && sudo chmod 640 /etc/nginx/field-to-test-loop.htpasswd
sudo nginx -t && sudo systemctl reload nginx
```

What the file does: redirects `http` to `https`; TLS 1.2/1.3 with your certificate; HTTP basic authentication
against the htpasswd file; rejects write requests that are not JSON and requests from foreign web sites (the
application has no protection against cross-site request forgery, i.e. another web page making a logged-in browser
send requests); `client_max_body_size 1m` (the application receives only small JSON bodies, there are no uploads);
`proxy_read_timeout 1200s` (preparing a defect card waits for the model, typically about 30 s, longer on a slow
endpoint; while a lab search runs it holds the stage-2 lock and card requests wait for it). Give **one login per
person**: the nginx access log (`/var/log/nginx/field-to-test-loop.access.log`) is then the only reliable record of
who did what, because the application logs every request as coming from `127.0.0.1` and trusts typed names.

To use the company SSO instead of htpasswd, run an OAuth2/OIDC proxy (for example oauth2-proxy) on
`127.0.0.1:4180`; the end of the nginx file lists the exact lines to swap. Restrict the login to a group.

`server.lock_endpoint: true` (section 4) already makes the server refuse changes of the model endpoint, the key
variable, the key, the backend and `llm.tools`. Optional, stricter: uncomment the `location = /api/config`
block in the nginx file: the settings of `PUT /api/config` then become read-only from the browser (changes: stop the
service, edit the file, start it again). That block does not cover `PUT /api/hier/model` (the model name of the Model
connection) or `PUT /api/agents/settings` (the agents: where they run, their model, web search, the Claude Code
program path, the reference folders); the lock does not cover the agents' settings either. If those must be fixed too,
add blocks of the same form for `location = /api/hier/model` and `location = /api/agents/settings` (not shipped in the
nginx file and not tested in this package).

### 6.3 Single user: SSH tunnel instead of nginx

```
ssh -N -L 8077:127.0.0.1:8077 you@server       # on your PC; then open http://127.0.0.1:8077
```

### 6.4 Other local accounts on the server (optional)

Anyone with a shell on the server can open `127.0.0.1:8077`. If the server has other users, allow only nginx and
root to connect (example with iptables owner matching; adapt the nginx user name, make it persistent with your
firewall tool; not tested in this package):

```
sudo iptables -A OUTPUT -o lo -p tcp --dport 8077 -m owner --uid-owner root -j ACCEPT
sudo iptables -A OUTPUT -o lo -p tcp --dport 8077 -m owner --uid-owner www-data -j ACCEPT
sudo iptables -A OUTPUT -o lo -p tcp --dport 8077 -j REJECT
```

### Running with a hardware bench

The unit in `deploy/field-to-test-loop.service` is hardened for the synthetic bench. A hardware bench hook
(`app/bench_hook.py`, `deploy/BENCH_INTEGRATION.md`) typically runs `nvme-cli` against the drive under test and
`setpci` (or writes under `/sys/bus/pci`: `remove`, `rescan`, `reset`, config space) against it and its upstream
port. That needs four things the hardened unit takes away. Add them with a drop-in instead of editing the unit, so
an upgrade of the unit does not lose them and removing the file undoes them.

> **Warning.** This drop-in widens what the service may do: with `CAP_SYS_ADMIN` and `CAP_SYS_RAWIO`, write access
> to the PCI part of `/sys` and the drive's device nodes, a fault in the hook (or anyone who can make the
> application run a procedure) can format the drive, rewrite its firmware, reset or remove PCI devices. Use it
> **only with a scratch drive** that holds no data, never with the drive the server boots from or stores data on,
> and only on a server dedicated to the bench. Keep `stage2.bench: "synthetic"` on any other server.

1. Find the scratch drive: `sudo nvme list` (controller `/dev/nvmeX`, namespace `/dev/nvmeXnY`), its serial
   number (`cat /sys/class/nvme/nvmeX/serial`), its PCI address (`readlink -f /sys/class/nvme/nvmeX/device`, the
   last part, e.g. `0000:03:00.0`) and the PCI root it hangs under (the `/sys/devices/pci0000:NN` part of that path).
2. Give the service user group access to exactly that drive (capabilities do not bypass file permissions; the
   nodes are normally `root`-only):

```
sudo groupadd --system ftlbench
sudo tee /etc/udev/rules.d/70-field-to-test-loop-bench.rules >/dev/null <<'EOF'
# the scratch drive used by the Field-to-Test Loop bench hook: replace SERIAL and 0000:03:00.0
SUBSYSTEM=="nvme", ATTR{serial}=="SERIAL", GROUP="ftlbench", MODE="0660"
SUBSYSTEM=="block", KERNEL=="nvme*n*", ATTRS{serial}=="SERIAL", GROUP="ftlbench", MODE="0660"
SUBSYSTEM=="pci", KERNEL=="0000:03:00.0", RUN+="/bin/sh -c 'cd /sys%p && chgrp ftlbench config remove reset 2>/dev/null; chmod g+w config remove reset 2>/dev/null; true'"
EOF
sudo tee /etc/tmpfiles.d/field-to-test-loop-bench.conf >/dev/null <<'EOF'
z /sys/bus/pci/rescan 0220 root ftlbench -
EOF
sudo udevadm control --reload && sudo udevadm trigger && sudo systemd-tmpfiles --create /etc/tmpfiles.d/field-to-test-loop-bench.conf
ls -l /dev/nvmeX /dev/nvmeXnY /sys/bus/pci/devices/0000:03:00.0/config      # expect group ftlbench
```

   If the hook also retrains or disables the link on the upstream port (setpci on the root port), add a `pci`
   line for that port's address too.
3. The drop-in (replace `nvmeX`, `nvmeXnY` and `pci0000:00`):

```
sudo mkdir -p /etc/systemd/system/field-to-test-loop.service.d
sudo tee /etc/systemd/system/field-to-test-loop.service.d/bench.conf >/dev/null <<'EOF'
# Hardware bench for the Field-to-Test Loop (deploy/DEPLOY.md, "Running with a hardware bench").
# WARNING: widens what the service may do. Only with a scratch drive on a dedicated bench server.
[Service]
# /sys was read-only (ProtectKernelTunables=yes); open it again, but keep everything outside the PCI tree read-only
ProtectKernelTunables=no
ReadOnlyPaths=/sys /proc/sys
ReadWritePaths=/sys/bus/pci /sys/devices/pci0000:00
# nvme-cli admin commands and setpci config-space writes need CAP_SYS_ADMIN; CAP_SYS_RAWIO for raw I/O tools
CapabilityBoundingSet=CAP_SYS_ADMIN CAP_SYS_RAWIO
AmbientCapabilities=CAP_SYS_ADMIN CAP_SYS_RAWIO
# the scratch drive's nodes (group ftlbench from the udev rule); with DeviceAllow= set, every other device is
# refused except /dev/null, /dev/zero, /dev/urandom and the other standard pseudo devices
SupplementaryGroups=ftlbench
DeviceAllow=/dev/nvmeX rw
DeviceAllow=/dev/nvmeXnY rw
# if the hook writes the analyzer captures outside /opt/field-to-test-loop, also: ReadWritePaths=/srv/analyzer-exports
EOF
sudo systemd-analyze verify /etc/systemd/system/field-to-test-loop.service
sudo systemctl daemon-reload && sudo systemctl restart field-to-test-loop
systemctl show field-to-test-loop -p CapabilityBoundingSet -p AmbientCapabilities -p DeviceAllow -p SupplementaryGroups
```

Notes: `DeviceAllow=` resolves the device names when the service starts; NVMe names can change after a reboot or
a rescan, so check `nvme list` against the serial number after each reboot. `NoNewPrivileges=yes` stays: the hook
cannot use `sudo`; the tools it starts inherit the two capabilities. If a tool fails with "Address family not
supported", add `RestrictAddressFamilies=AF_UNIX AF_INET AF_INET6 AF_NETLINK` to the drop-in. To go back to the
synthetic bench: `sudo rm /etc/systemd/system/field-to-test-loop.service.d/bench.conf`, `daemon-reload`, restart,
and set `stage2.bench` to `synthetic`. Not tested on this package (no hardware bench and no root on the test
machine); `systemd-analyze verify` accepts the drop-in (section 13).

## 7. Health check and logs

| What | Command |
|---|---|
| Alive (cheap, does not wait for the stage-2 lock) | `curl -fsS -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8077/api/config` → `200` |
| Runs listed (heavier: reads every run folder) | `curl -fsS http://127.0.0.1:8077/api/runs >/dev/null && echo ok` |
| Jobs running now | `curl -fsS 'http://127.0.0.1:8077/api/jobs?limit=50' \| python3 -c 'import json,sys; print([(j["id"], j["status"]) for j in json.load(sys.stdin) if j["status"] in ("queued","running")])'` |
| Server log | `journalctl -u field-to-test-loop -n 200 --no-pager` (`-f` to follow). The server prints one line per request (`127.0.0.1 - - [time] "GET /api/... HTTP/1.1" 200 -`) and Python errors. |
| Who did it | the nginx access log (the logged-in name is in the third field) |

`/api/db/...` requests wait while a lab search holds the stage-2 lock; do not use them as a health check.

## 8. Durability: what is on disk, and what a restart loses

| Path | What | Precious? |
|---|---|---|
| `db/knowledge.sqlite` | the learned knowledge base: every decision as an event (event-sourced, `stage2/kgdb.py`) | **yes, the main asset** |
| `db/app.sqlite` | jobs, their progress and the stage-1 verdict cache | yes (run list, history) |
| `db/llm_cache.jsonl`, `db/stage2_log.jsonl` | model-answer cache, stage-2 log; append-only, grow without limit | useful (saves model calls) |
| `suite/<test>/` | the generated regression tests | **yes** |
| `config/app_config.json` | the settings (no key) | yes |
| `runs/<run>/` | stage-1 outputs per trace, `stage2/<defect>.json` state, report | yes, but can be re-created by re-analysing the trace |
| `runs/_bench/`, `runs/bench_*/` | scratch captures of lab runs; never cleaned by the application | no |
| `db/hier_knowledge.sqlite` | the procedural graph (defect → cause → solution, `dg_*` tables), each error's kept isolation, every admin judgement (rows are only added) | **yes** |
| `db/agentic.sqlite` | the flows and their steps, reviews and answers | yes |
| `knowledge/` | the admin's rules, data dictionaries, strategies, generated rule code, flow reports, and `dictionary/term_requests.jsonl` (notes that a defect name does not fit) | **yes** |
| `suite/hier/` | the test files written from the error pages, each with its `.approved.json` (who approved it, sha256) | **yes** |
| `uploads/<id>/` | each loaded recording's tree (`hier.sqlite`) and its meta; large (several GB per real capture) | can be re-created by loading the five files again |
| `db/isolation_windows.json` | the n above / m below the admin last used per error | small; convenience only |
| `runs/agentic/_deleted/` | a copy of every analysis deleted from the start page (`analysis_<id>_<time>.json`) | the only record of a deleted analysis |
| `/opt/field-to-test-loop/.config/f2t/env` (outside the release folder) | a key saved on the Settings page; wins over the environment file at start | should not exist in production (5.2); not in the backups |

The error page's progress jobs ("Isolate the defect", the optimized sequence, the test file) live in the server's memory: a restart
loses a job that is still running (the page then says "no such job (the server may have restarted)"; press the button again). What a
finished job stored is on disk. Check that no job is running before a restart (OPERATIONS section 1).

Known limitations, verified on this package (2026-10-27):

1. **Every lookup and every decision is committed at once.** Showing a defect card (`present`) and every decision
   (`act`, and a lab job when it finishes, `_execute_job`) end with a commit (`app/stage2_service.py:171,222,236`);
   undo commits too (`rebuild`, `stage2/kgdb.py:328-341`). A decision is on disk when its answer reaches the
   screen, so a stop, restart or crash of the process loses no decision already answered.
2. The knowledge base on disk uses `PRAGMA journal_mode=WAL` and `synchronous=NORMAL` (`stage2/kgdb.py:44-52`).
   `db/knowledge.sqlite-wal` and `db/knowledge.sqlite-shm` are **part of the database**: never delete them, and never
   copy `knowledge.sqlite` alone while the server runs (use `deploy/backup.sh`). A power cut or kernel crash can
   lose the last commit, but does not corrupt the file. `db/app.sqlite` also uses write-ahead logging (`app/jobs.py:58`).
3. A stop or crash during a lab job (search, composition, sweep, workload) loses only that job: its events are
   committed when it finishes. At the next start the application marks every queued or running job `failed` with
   the error "server restarted while running" (`app/jobs.py:51`); start it again from the page. The stage-2 state
   of each defect persists in `runs/<run>/stage2/*.json`.
4. The configuration and the per-defect state files are rewritten in place, not atomically
   (`app/api/config_api.py:11-14`, `app/stage2_service.py:124-126`). A crash in the middle of a write can leave a
   truncated file; an unreadable `config/app_config.json` stops the service from starting (restore it from a backup).
5. A stop is immediate (the server has no shutdown handler; systemd sends SIGTERM and Python exits).

## 9. Backups

`deploy/backup.sh` is safe while the server runs. It copies each `db/*.sqlite` with SQLite's online backup function
through Python (`sqlite3.Connection.backup`; the `sqlite3` command-line tool is not needed), checks every copy with
`PRAGMA integrity_check`, copies the `.jsonl` files, `suite/` and `config/`, optionally `runs/` (`--with-runs`,
without the `_bench`/`bench_*` scratch folders), writes a `MANIFEST.txt` with the event count, and packs a
timestamped `ftl-backup-YYYYmmdd-HHMMSS.tar.gz` (mode 600). It also includes `app/bench_hook.py` (the site's bench
integration: code you wrote that exists nowhere else), and leaves out `__pycache__/` and `.pytest_cache/` folders
inside `suite/` and `runs/`. It archives `knowledge/` too, and `deploy/restore.sh` puts it back (since 2026-11-11). Not backed up: `uploads/`
(large; load the five files again), `db/isolation_windows.json` (copy it by hand, OPERATIONS section 3), `samples/` (demo traces,
regenerated from the page at any time), the program code and `.venv/` (reinstall from the release zip) and the key. A backup holds every decision answered
before it started (section 8); a lab job still running is not in it yet. The databases in the archive are single
files without `-wal`/`-shm`.

```
sudo -u ftl /opt/field-to-test-loop/current/deploy/backup.sh                    # db, suite, config
sudo -u ftl /opt/field-to-test-loop/current/deploy/backup.sh --with-runs --keep 14
# options: --app-dir DIR (default /opt/field-to-test-loop/current) --out-dir DIR (default /opt/field-to-test-loop/backups)
```

Run it as `ftl` (as root it refuses, because SQLite side files created by root would lock the service out).

Schedule, with a systemd timer (logs go to the journal):

```
sudo tee /etc/systemd/system/field-to-test-loop-backup.service >/dev/null <<'EOF'
[Unit]
Description=Field-to-Test Loop backup
[Service]
Type=oneshot
User=ftl
ExecStart=/opt/field-to-test-loop/current/deploy/backup.sh --keep 30
EOF
sudo tee /etc/systemd/system/field-to-test-loop-backup.timer >/dev/null <<'EOF'
[Unit]
Description=Daily Field-to-Test Loop backup
[Timer]
OnCalendar=*-*-* 02:15
Persistent=true
[Install]
WantedBy=timers.target
EOF
sudo systemctl daemon-reload && sudo systemctl enable --now field-to-test-loop-backup.timer
systemctl list-timers field-to-test-loop-backup.timer
```

Add a weekly `--with-runs` run if the run folders matter to you, and **copy the archives off the server** (they sit
on the same disk as the data). For an ad-hoc copy of one database, as `ftl`:
`sudo -u ftl sqlite3 /opt/field-to-test-loop/current/db/knowledge.sqlite ".backup /opt/field-to-test-loop/backups/knowledge-adhoc.sqlite"`
(if the `sqlite3` tool is installed). Like `backup.sh`, this uses SQLite's backup function from a separate process
that **only reads** the live database, which is safe next to the running server. Do not use `KGDB.snapshot()` from
`stage2/kgdb.py` for this: it needs a `KGDB` object, and constructing one in a second process writes to the
database (schema, journal settings, cache load), which breaks the one-process rule of section 0.

### Restore

**In place** (the live installation; the service must be stopped):

```
sudo systemctl stop field-to-test-loop
sudo /opt/field-to-test-loop/current/deploy/restore.sh /opt/field-to-test-loop/backups/ftl-backup-20261027-021500.tar.gz
sudo systemctl start field-to-test-loop
curl -fsS -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8077/api/config
curl -fsS http://127.0.0.1:8077/api/db/summary | python3 -c 'import json,sys; print(json.load(sys.stdin)["knowledge"]["events"])'
#   must equal the knowledge.sqlite events count in the archive's MANIFEST.txt
```

**Into a scratch copy** (to test a backup; the production service keeps running):

```
S=/opt/field-to-test-loop/restore-test
sudo -u ftl mkdir -p "$S" && sudo -u ftl unzip -q /path/to/field_to_test_loop_code_only.zip -d "$S"
sudo /opt/field-to-test-loop/current/deploy/restore.sh /opt/field-to-test-loop/backups/ftl-backup-20261027-021500.tar.gz --app-dir "$S/13_production_app"
# optional: look at it on another port, without model calls. If its config has "bench": "hook", set it to
# "synthetic" first (sudoedit -u ftl "$S/13_production_app/config/app_config.json"): the copy must not drive the bench.
sudo -u ftl sh -c "cd '$S/13_production_app' && exec /opt/field-to-test-loop/current/.venv/bin/python run_app.py --config config/app_config.json --port 8095 --standin"
#   in a second terminal: curl -fsS http://127.0.0.1:8095/api/db/summary   (events = MANIFEST.txt); Ctrl-C to stop it
sudo rm -rf "$S"
```

`restore.sh` decides which case applies by comparing `--app-dir` with the folder the service runs from (its
`WorkingDirectory`, and the working folder of its running process). For the live folder it refuses while the
service is active; any other folder may be restored while the service runs. In both cases it refuses while a process
holds that folder's `db/knowledge.sqlite` open (`--force` overrides; do not). `--service none` skips the service
checks (a machine without the unit). It checks every database and the configuration in the archive before it
touches anything, moves what it replaces into `<app>/pre-restore-<time>/` (nothing is deleted; `db/` moves as a
whole, so the old `knowledge.sqlite-wal`/`-shm` go aside with the old database and no stale write-ahead log is
replayed onto the restored file), copies the restored `db/`, `suite/`, `config/` (and `runs/` and `knowledge/` if the
archive has them) into place, restores `app/bench_hook.py` when the archive has it (the replaced one is kept in
`pre-restore-<time>/app/`) and, when run as root, gives everything to the owner of the application folder. Its last
lines say what to do next: start the service for the live folder; for a scratch copy, not the service but a
separate copy on another port. It warns when the runs in the archive were recorded under another folder path: for
the live installation restore into the folder the service starts from (`/opt/field-to-test-loop/current`), otherwise
the run list loses its summaries (expected for a scratch copy). Compare the event count it prints with the one in the
archive's `MANIFEST.txt`.

## 10. Upgrade and rollback

```
NEWREL=/opt/field-to-test-loop/releases/$(date +%Y-%m-%d-%H%M)
OLD=$(sudo readlink -f /opt/field-to-test-loop/current)    # sudo: /opt/field-to-test-loop is mode 750
NEW=$NEWREL/13_production_app

# 1. prepare the new code next to the old one (the service keeps running)
sudo -u ftl mkdir -p "$NEWREL"
sudo -u ftl unzip -q /path/to/new/field_to_test_loop_code_only.zip -d "$NEWREL"
sudo -u ftl cp "$NEW/config/app_config.json" "$NEW/config/app_config.json.new-default"   # for the key comparison in step 3
sudo -u ftl sh -c "cd '$NEW' && python3 -m venv .venv && .venv/bin/python -m pip install -r deploy/requirements.txt"
sudo -u ftl sh -c "cd '$NEW' && PATH='$NEW/.venv/bin':\$PATH ./run_tests.sh"    # works on a temporary copy, never on db/

# 2. no job running (see section 7), then stop and back up
sudo systemctl stop field-to-test-loop
sudo -u ftl "$OLD/deploy/backup.sh" --with-runs

# 3. carry the data over (copies: the old release stays intact for a rollback)
# knowledge/ = the admin's rules, dictionaries and strategies; uploads/ = the recordings and their trees (the errors pages read them)
for d in db suite config samples runs knowledge uploads; do
  [ -d "$OLD/$d" ] && sudo -u ftl rsync -a --exclude=/_bench/ --exclude='/bench_*/' "$OLD/$d/" "$NEW/$d/"
done
# app/bench_hook.py is code you wrote: copy it over too if you implemented it
#   sudo -u ftl cp "$OLD/app/bench_hook.py" "$NEW/app/bench_hook.py"
# a drop-in in /etc/systemd/system/field-to-test-loop.service.d/ (hardware bench) stays in place by itself
# keys that are new in the shipped configuration and missing from yours:
sudo -u ftl python3 -c 'import json,sys; a=json.load(open(sys.argv[1])); b=json.load(open(sys.argv[2])); [print(s+"."+k) for s in a if isinstance(a[s],dict) for k in a[s] if not k.startswith("_") and k not in b.get(s,{})]' \
  "$NEW/config/app_config.json.new-default" "$NEW/config/app_config.json"
#   add every printed key to config/app_config.json (values and meaning: the new default file and its _help texts)

# 4. check and switch
sudo sh -c "set -a; . /etc/field-to-test-loop/environment; set +a; cd '$NEW' && exec runuser -u ftl -- .venv/bin/python deploy/preflight.py --config config/app_config.json"
sudo ln -sfn "$NEW" /opt/field-to-test-loop/current
sudo systemctl start field-to-test-loop
curl -fsS -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8077/api/config     # 200
curl -fsS http://127.0.0.1:8077/api/db/summary | python3 -c 'import json,sys; print(json.load(sys.stdin)["knowledge"]["events"])'
#   must equal the knowledge.sqlite event count in the MANIFEST.txt of the backup from step 2
```

Use `rsync --remove-source-files` or `mv` for `runs/` instead if the disk cannot hold two copies; a rollback then
needs the runs moved back. If the unit file changed in the new release, install it again (section 6.1) before the
start.

**Rollback** (the new version misbehaves):

```
sudo systemctl stop field-to-test-loop
sudo ln -sfn "$OLD" /opt/field-to-test-loop/current
sudo systemctl start field-to-test-loop
```

The old release still holds the data as it was at the upgrade stop. Decisions made on the new version are not in
it; to keep them, run `restore.sh` with a backup taken on the new version only if the new version did not change the
database layout (the release notes say so). When unsure, keep the old data.

## 11. Sizing

- **CPU:** one Python process; the CPU-heavy work (stage-1 analysis, lab searches) effectively uses one core at a
  time, and searches are serialized by the stage-2 lock. A small server with a few cores is enough for the
  application; the model runs remotely.
- **Time:** stage 1 reads the CSV as a stream, so memory does not grow with the file, but time does: plan on
  minutes for multi-gigabyte traces and measure with your first real trace (the Report page shows the seconds per
  step). On this package's synthetic two-defect sample, stage 1 took about 2 s and one lab search with the simulated
  bench about 45-50 s (measured 2026-10-27).
- **Disk:** `runs/` grows with every analysed trace and the lab scratch folders (`runs/_bench/`) are never cleaned:
  the development copy held about 600 MB in `runs/` (560 MB of it `_bench`) and 5 MB in `db/` after two days of
  tests (measured 2026-10-27). Monitor `du -sh /opt/field-to-test-loop/current/{runs,db,suite}` and the backup
  folder; delete old runs from the page (the knowledge base is not touched) and clear `runs/_bench/` while the
  service is stopped.
- **Memory:** watch `systemctl status field-to-test-loop` (Memory line) during your largest trace.

## 12. Go-live checklist

- [ ] `deploy/INSTALL.md` done: venv in the release folder, `./run_tests.sh` passes; `preflight.py` run as in
      section 5.1 (root loads the key, then runs it as `ftl`) shows no FAIL
- [ ] service user `ftl` owns `/opt/field-to-test-loop`; `current` link points at the release
- [ ] `config/app_config.json` from the production example: `backend sdk` (or `http`), `base_url` (base address, no `/v1`), `model`, `api_key_env` set;
      `allowed_csv_roots` = the export folder (the picker's starting point; no path is refused); `host` = `127.0.0.1`; `lock_endpoint` = `true`; `tools` = `[]`
      unless web search was approved
- [ ] `stage2.bench` = `synthetic` unless `deploy/BENCH_INTEGRATION.md` is complete and signed off; with `hook`, the
      drop-in from "Running with a hardware bench" is installed and the device is a scratch drive
- [ ] key in `/etc/field-to-test-loop/environment`, mode 600, owner root; not in any file under the application folder;
      no key file `/opt/field-to-test-loop/.config/f2t/env` (5.2); the start line in the journal reads `key from this
      computer's environment (not set on the Settings page)`; Settings → **Save and test the connection** shows both ✔
- [ ] `systemctl status field-to-test-loop` active; `curl .../api/config` returns 200 locally
- [ ] `ss -ltnp | grep 8077` shows `127.0.0.1:8077` only, never `0.0.0.0` or `*`
- [ ] nginx: `nginx -t` ok; https works; without a login you get 401; one login per person; `http` redirects
- [ ] decided whether settings are read-only from the browser (nginx `location = /api/config` block)
- [ ] other shell users on the server: none, or port blocked for them (section 6.4)
- [ ] backup timer enabled; one manual backup made; **one restore tested** into a scratch copy with
      `restore.sh --app-dir <scratch copy>` while the service runs (section 9, Restore), event count equal to
      `MANIFEST.txt`; archives copied off the server
- [ ] the admins know: no login of their own beyond the proxy, typed names are trusted, and a stop during a lab job
      loses that job (start it again; section 8)
- [ ] KPI baselines entered or consciously left empty

## 13. How these files were checked (2026-10-27)

On a fresh unpack of `field_to_test_loop_code_only.zip` with these deploy files copied in:
the production example configuration, adapted to `backend standin`, `bench synthetic`, port 8092 and a scratch export
folder, loaded and served (`/api/config` 200; `/etc/passwd` was refused as outside the allowed folders by the version of that day; since 2026-11-03 no folder restriction exists); a synthetic
trace was analysed, stage 2 started, decisions and two lab searches run; `backup.sh` ran 12 times while the server was
running, 11 of them during a lab search that was writing, all copies passed the integrity check and the server kept
working; `restore.sh` refused the live folder (database open), restored into another unpacked copy and in place
after the stop, with the same event count (14 and 26) as the archive; `bash -n` on both scripts; `systemd-analyze
verify` passed on the unit with the paths changed to ones that exist on the test machine (unchanged, it only reports
that `/opt/field-to-test-loop/current/.venv/bin/python`
does not exist there); the sandboxed start itself could not be tried on the test machine. `nginx -t` passed (nginx
1.27.5 in a container, throwaway certificate), and with that proxy in front of the application: no login 401,
wrong password 401, login 200, a text/plain POST 403, a foreign Origin 403, a body over 1 MB 413, http 301 to https.

Second check of the revised scripts and unit (same day, fresh unpack, port 8094, `--standin`, `server.lock_endpoint`
true): a `PUT /api/config` of `llm.base_url` answered 403; a sample trace was analysed, stage 2 started, a card shown
and a "lesson" decision made (4 events, on disk at once); `backup.sh --with-runs` ran while a lab search was running
(archive: 4 events, `app/bench_hook.py` included, no `__pycache__`/`.pytest_cache`, no `-wal`/`-shm`, no `samples/`);
with the server still running, `restore.sh` refused the live folder (database open) and restored into a second
unpacked copy (4 events, no `-wal`/`-shm` in its `db/`, the replaced `app/bench_hook.py` kept in `pre-restore-*/app/`,
"do NOT start the service" printed); after the search (12 events) the server was stopped, leaving a 247 KB
`knowledge.sqlite-wal`; the in-place restore of the 4-event archive moved `knowledge.sqlite`, `-wal` and `-shm`
together into `pre-restore-*/db/`, and the restarted server reported 4 events (the stale log was not replayed).
`systemd-analyze verify` accepted the unit together with the bench drop-in of "Running with a hardware bench" (and
reported an unknown key planted in the drop-in, so the drop-in was read). Not tried: the service checks of
`restore.sh` against an active systemd unit, and the drop-in on real hardware (no root, no bench on the test machine).
