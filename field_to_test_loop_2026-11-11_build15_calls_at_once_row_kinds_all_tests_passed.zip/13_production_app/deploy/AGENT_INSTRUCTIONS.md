# Field-to-Test Loop: master runbook for the installer (engineer or AI coding agent)

You received a zip of a production application and must install it, deploy it, operate it and keep it healthy
without having seen the project before. Read this file from top to bottom once, then work through section 2 in order.
Everything quoted here (commands, file names, setting keys, button names, messages) exists in the code of this
folder. Files in `deploy/` that this runbook links to (INSTALL.md, DEPLOY.md, BENCH_INTEGRATION.md, preflight.py,
backup.sh, restore.sh, the service and proxy files) are the detailed instructions for their topic: follow them where
this runbook says "see deploy/...".

Words used below: **PCIe** = PCI Express, the link between a computer and a drive. **NVMe** = Non-Volatile Memory
Express, the command language of the drive. **CSV** = comma-separated values file. **LLM** = large language model;
on the screens it is called **the AI reviewer**. **API** = application programming interface (here: the web addresses
under `/api/...` that the screens call). **KPI** = key performance indicator, called **Key results** on the screens.
**venv** = Python virtual environment. **systemd** = the Linux service manager. `$APP` = the folder
`13_production_app` after unpacking (the folder that contains `run_app.py`).

---

## 0. What this is, in ten lines, and what is in the zip

1. An engineer exports a protocol-analyzer capture of PCIe/NVMe traffic as a 113-column CSV and gives its path.
2. **Stage 1** (`stage1/pcie_isolate/`, "the analyser") reads it in one streaming pass and isolates every defect with
   rules taken from the specifications; each defect is matched to one of 485 known error types.
3. The AI reviewer gives a second opinion per defect (agrees / disagrees / not sure). It never decides.
4. **Stage 2** (`stage2/`) starts only when an admin presses **Start stage 2**. Each defect is looked up in the
   knowledge base (`db/knowledge.sqlite`); saved procedures are shown next to a fresh AI proposal.
5. An admin decides per procedure: **Correct**, **Needs changes** or **Not correct**, plus 23 more decisions under
   **All details** (26 in total, `app/api/__init__.py` `ACTION_HELP`).
6. On **Correct** the lab reproduces the defect: the saved procedure is re-run, or a search over command sequences and
   timing runs; then a "most stressful conditions" step pushes the timing to its limit.
7. A lab check runs the procedure on known-bad and on fixed firmware with the same analyser; it passes only when the
   defect appears on known-bad and never on fixed.
8. A passed check writes a regression test to `suite/<test id>/` (`test_*.py`, `manifest.json`, `conftest.py`).
9. Learning is counting in SQLite (success and failure counters per cause and procedure). No model is trained.
10. Until a real lab bench is connected (`stage2.bench = "synthetic"`), **every lab run is SIMULATED**.

| In the zip | What it is |
|---|---|
| `README_FIRST.md`, `README_CODE_ONLY.md`, `README.md` | the one-page entry point; what the code-only package contains and the shipped settings; design and background |
| `run_app.py`, `run_tests.sh` | start the server; run the offline tests |
| `app/` | Flask web server (`server.py`), API (`app/api/*.py`), background jobs, web pages (`app/static/`), `bench_hook.py` (the place a real bench plugs in) |
| `stage1/` | the analyser; `stage1/vendor/` = a bundled copy of the Anthropic software development kit (SDK), built for CPython 3.13 on x86-64 Linux |
| `stage2/` | knowledge base, retrieval, the 26 decisions, search, lab check, test writer, `llm_adapter.py` |
| `data/` | the 485 error-type cards, the detection specification, the synthetic trace generator (used by the simulated bench) |
| `config/app_config.json` | all settings |
| `tests/` | the suites run by `run_tests.sh`: 23 unit suites (offline, their own temporary folders), 5 API suites (need the server on :8077), 4 browser suites (also need Chrome), and 3 more with `--real` (real model calls). The Data Grounder, Stop and Delete, and the calls at the same time have their own test files in it (step 2.4). The code-only zip carries no samples: most tests that need one skip, some fail (step 2.4) |
| `docs/` | `APPLICATION_MAP.html` (every button and piece of content, 571 entries, each with the arrow chain browser → server → Python → database and numbered screenshots in `ui_map_images/`), `OPERATOR_AND_BACKEND_GUIDE.html` (every screen and button, 15 sections, with `guide_images/`), `CHANGES_2026-11-11.md` (latest change log: the errors page, one page per error, the fixed dictionary and the evidence card; `CHANGES_2026-10-27.md` before it), `PROVENANCE_AUDIT.md` (where every formula, threshold and constant comes from), `VERIFICATION_FROM_SCRATCH.md` (the full package unpacked into an empty folder and run end to end, with timings). The entry page is `README_FIRST.md` in the top folder |
| `deploy/` | this runbook, `OPERATIONS.md`, and the install / deploy / bench files written for production |
| `db/`, `runs/`, `suite/`, `samples/`, `knowledge/`, `uploads/` | runtime data; created on first start if missing (`db/hier_knowledge.sqlite` holds the procedural graph and the kept isolations; `knowledge/` the admin's rules and dictionaries; `uploads/` each loaded recording's tree). Their location is always inside `$APP` (`app/services.py`); there is no setting to move them |

---

## 1. Hard rules (never break these; stop and ask the owner if a task seems to require it)

1. **Never train or fine-tune any model.** The application only sends questions to a model and checks the answers.
   Do not add training code, do not upload the knowledge base or traces to any training service.
2. **Never run format, sanitize, firmware download or namespace delete on a drive** — not from the bench hook, not by
   hand "to reset the bench". The application refuses such commands itself (only the twelve commands in
   `stage2/llm_adapter.py` `ALLOWED_OPS` exist: read, write, flush, trim, write_zeroes, reset, power_cycle,
   aspm_idle, identify, get_log, set_feature, abort); `app/bench_hook.py` says "never let this hook run format /
   sanitize / firmware commands; keep the device in a scratch namespace".
3. **Never delete `db/knowledge.sqlite`.** It is the learned knowledge: every admin decision and lab result as an
   event log, from which all other tables are computed. A wrong decision is fixed with **Undo** (section 3 and
   `deploy/OPERATIONS.md` section 10), never by deleting or editing the file. If you think it must go, stop and ask.
   The file has two side files, `db/knowledge.sqlite-wal` (write-ahead log: recent committed decisions may still be
   only in it) and `db/knowledge.sqlite-shm`; they belong to the database. Never copy or move `knowledge.sqlite`
   alone: move or copy the three together (or the whole `db/` folder) with the server stopped, and make backups with
   `deploy/backup.sh`, which uses the SQLite backup function and is safe while the server runs. (This rule is for a
   working installation; removing a test installation is in `deploy/INSTALL.md` section 9: back up first.)
4. **Never run more than one server process on the same `db/` folder.** The stage-2 state is held in memory and
   serialised by one lock inside one process (`app/stage2_service.py`); `knowledge.sqlite` is opened with
   `PRAGMA journal_mode=WAL` and `synchronous=NORMAL` (`stage2/kgdb.py`). Two processes on one `db/` will
   contradict each other's in-memory state and knowledge. A test copy in another folder with its own `db/` on
   another port is fine.
5. **Keep the server on 127.0.0.1 behind an authenticating reverse proxy.** The application has **no
   authentication** and the names typed in "Your name" are **self-declared**. Leave `server.host` at `127.0.0.1` in
   `config/app_config.json`; expose it only through the proxy described in `deploy/DEPLOY.md`
   (`deploy/nginx-field-to-test-loop.conf`).
6. **API keys never in the configuration.** The config holds only the *name* of the variable
   (`llm.api_key_env`, default `ANTHROPIC_API_KEY`). The key lives in the service's environment file
   (`/etc/field-to-test-loop/environment`) or, when typed on the Settings page, in the private key file
   `~/.config/f2t/env` of the user the server runs as (step 2.5). Never write a key into `config/app_config.json`, a
   script, a log, a ticket or this folder, and never print the key file.
7. **Respect the two-person rule.** Approve (`promote`), retire (`deprecate`) and delete (`delete_approve`) need a
   second, *real* person. The server refuses when the names are equal ("promote needs a second admin (approver !=
   requester)", "delete needs a second admin (approver != requester of the delete)"), but it cannot know whether two
   different names are two different people. Never type a second name yourself, and never let one person use two
   names. As an agent you are never the second admin.

---

## 2. From zip to production: the ordered checklist

Work top to bottom. Each step: command, expected output, what to do if it fails. Tick the box when done and note
anything unusual for the report in section 7. Steps 2.1–2.6 need no network access except for `pip`; step 2.5 needs
the AI endpoint.

### [ ] 2.0 Prerequisites

- Linux on x86-64 (tested on CPython 3.12 and 3.13), Python 3.10 or newer, `unzip`, `curl`; optional `sqlite3`
  (for the checks in section 4).
- Disk: on the development machine `runs/` reached 606 MB with small synthetic captures (561 MB of it simulated lab
  traces); real multi-gigabyte captures need more. See `deploy/OPERATIONS.md` section 2 for what grows.
- A service account that will own `$APP` and run the server (see `deploy/DEPLOY.md`).

```bash
python3 --version          # expect: Python 3.10.x or newer
df -h .                    # check the free space against deploy/OPERATIONS.md section 2
```
If Python is older, install a newer one (for example from the distribution's packages) and use it for every command
below.

### [ ] 2.1 Unpack (including the mail-safe variant)

```bash
mkdir -p /path/of/your/choice && cd /path/of/your/choice
unzip <the zip you received>.zip
sha256sum -c <the zip>.SHA256.txt      # only if a .SHA256.txt came with it; expect: "<zip name>: OK"
cd 13_production_app                   # this is $APP; every later command runs from here
```

**Mail-safe archives** (`*_MAIL_SAFE.zip`): e-mail providers refuse archives with `.js` files, so the ten browser
scripts are stored as `.js.txt`. Run the helper once, from the folder that contains `restore_names.py` (in the
code-only archive that is `13_production_app/`, where you are now; in the full package it is the top folder: run it
there first, then `cd 13_production_app`):

```bash
python3 restore_names.py               # expect: "restored 10 JavaScript file(s)"; the script then deletes itself
ls app/static/js/*.js | wc -l                     # expect: 10
ls app/static/js/*.js.txt 2>/dev/null | wc -l     # expect: 0
```
If it fails: the page will later load without working buttons. Re-run `restore_names.py`, or rename every
`*.js.txt` under `app/static/js/` back to `*.js` by hand.

Check whether the zip already carries a knowledge base: `ls -la db/`. A production installation normally starts with
an empty one. If `db/knowledge.sqlite` exists, **do not delete it** (rule 3): note its size and ask the owner whether
it is test data or knowledge to keep (`docs/OPERATOR_AND_BACKEND_GUIDE.html` section 15.4: the development database
contains exercise data).

### [ ] 2.2 Install

Follow `deploy/INSTALL.md`. The short form, from `$APP`:

```bash
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install -r deploy/requirements.txt     # expect: "Successfully installed flask-... numpy-... ..."
python3 -c "import flask, numpy; print('ok')"         # expect: ok
```
Notes from the code:
- `flask` and `numpy` are required. `anthropic` (the Anthropic software development kit) is required **for
  `llm.backend = "sdk"`** (and for `auto` when it picks `sdk`). Both stages import the installed package first and
  fall back to the copy in `stage1/vendor/` (`stage2/llm_adapter.py`). That copy imports only where its compiled
  dependency matches: it was built for CPython 3.13 on x86-64 Linux. On any other Python, without the installed
  package, stage 2 **silently uses the deterministic stand-in instead of the model**. So for `sdk` always install
  `anthropic` from `deploy/requirements.txt`. `pytest` is needed only for the tests and the generated regression
  tests in `suite/`.
- If `pip` has no internet access, see `deploy/INSTALL.md` for an offline install.

### [ ] 2.3 Preflight

```bash
python3 deploy/preflight.py            # expect: PASS / WARN lines and exit code 0 (echo $? -> 0)
```
It prints PASS, WARN or FAIL per check and exits non-zero on any FAIL. Fix every FAIL before continuing (the line
names the problem; section 5 lists the common ones, for example the bench hook). WARN lines go into your report.

Expected on the shipped `config/app_config.json` (`llm.backend = "http"`) with port 8077 free: `0 FAIL` and the
summary line `... ready to start (read every WARN line)`. The shipped backend `http` has no line of its own in the
"AI model backend" check (`deploy/preflight.py` `check_llm` covers `standin`, `cli`, `sdk`, `openai-compat`, `ollama`
and `auto`); `--check-llm` makes the real call for it. Two WARN lines are expected:
- `WARN  server.lock_endpoint  -  off: anyone who reaches the Settings page can point llm.base_url at another server
  and receive the API key; ...` — for production use `deploy/config.production.example.json`, which sets
  `server.lock_endpoint: true` (the line then reads PASS). See step 2.5 for what the lock does.
- `WARN  bench synthetic  -  lab runs are simulated ...` — stays until a real bench is connected (step 2.8).

Other common results: `FAIL backend cli` when `llm.backend` is `cli` and the `claude` command is missing (install and
log in, or choose another backend in step 2.5); a WARN on the port when something already listens on 8077 (check
another port with `python3 deploy/preflight.py --port <port>`). `preflight.py` checks the key in its own environment;
it does not read the Settings page's key file (step 2.5).
If `stage1/selfcheck.py` is present (it is not in the code-only archive), you may also run
`cd stage1 && python3 selfcheck.py && cd ..` (expect PASS lines and exit code 0).

### [ ] 2.4 Tests (offline, no model, no network)

```bash
./run_tests.sh
```
Run it **before** the service is started for the first time: when the server answers on :8077 the script also runs the API and
browser suites, which switch the agents to the stand-in and set the admin's `knowledge/` aside while they run.
It prints one line per suite (`PASS` or `FAIL`, seconds, the suite's own count) and a summary table at the end; the exit code is
0 only when every suite passed. A failing suite's log is in `runs/suite_logs/<suite>.log`.
**On a bare install from the code-only archive (no `samples/` folder)** most tests that need a sample recording report
`skipped`; a skip is a pass. **Some fail there, and that is expected, not a fault of the install:** the throw-away
application of `tests/fuzz_app.py` (`setup`) loads `samples/clean_five_files/S08_interrupt_before_completion` without a
skip guard, so everything built on it stops with "No such file or directory" for a sample file:
- suite `unit_agents`: six tests of `tests/test_agent_layer.py` (`test_several_whole_flows_at_the_same_time`,
  `test_an_analysis_is_deleted_with_its_runs_and_a_copy_is_kept`,
  `test_other_files_are_read_while_the_first_waits_for_the_admin_and_nothing_runs_twice`,
  `test_join_rule_settings_try_ask_and_note`, `test_a_rules_words_are_edited_saved_as_versions_and_can_go_back`,
  `test_old_rule_versions_move_to_the_knowledge_folder_without_the_unchanged_saves`);
- suites `fuzz_app`, `fuzz_params`, `attack3`, `attack6` and `fuzz_deep` (the scripts `tests/fuzz_app.py`,
  `fuzz_params.py`, `attack_round3.py`, `attack_round6.py`, `fuzz_deep.py` build that application first).
Note them in the report (section 7) as "need the samples"; every other suite must pass. With the full package (which
has `samples/`) they run.

**The suite `fuzz_params` sends what fits in five minutes** (about 10,465 of its 37,903 cases on the development computer). To
send every case, run the parts at the same time, each on its own throw-away application (about 9 minutes with six parts on 8
cores):
```bash
for p in 0 1 2 3 4 5; do python3 tests/fuzz_params.py 2400 1 $p 6 > /tmp/fuzz_part$p.log 2>&1 & done; wait; tail -n 1 /tmp/fuzz_part*.log   # each: "... 0 distinct problems"
```
A line that starts with `[5` in a log is a server error to report. HTTP 503 "the database is busy: try again in a moment" is
the designed answer while a background job writes a recording's database; the script counts it on its own line, not as a
problem.

**The Data Grounder, Stop and Delete, and the calls at the same time** are tested offline (a stand-in model server and a
stand-in Claude Code program; no server, no key). They are in `run_tests.sh` (suites `unit_errors` and `unit_calls`); to
run only them:
```bash
python3 -m pytest -q -p no:cacheprovider tests/test_grounder_batches.py tests/test_stop_and_delete.py tests/test_calls_at_once.py   # 27 tests; expect "27 passed" (with samples); on a bare install the tests that need a sample skip
```
- `tests/test_grounder_batches.py` (12 tests): the Data Grounder on a 361-column file (121 parts of 3 columns, never more
  calls at once than allowed, the progress moves), the two retries, an answer that was cut off asked again in two
  halves, the short and the long form of the answer, which rows fill a column given to the model, no meaning written by
  code, sources kept, a refused connection stops the step.
- `tests/test_calls_at_once.py` (13 tests): the automatic number from the processor cores for both paths, a number in
  Settings wins, halving on "too many calls" and climbing back, a stopped run leaves the queue, the kind of row found
  by code and counted on every row, the fast reference search gives the same lines as the line-by-line one, and the
  Settings route (shows the number and why, a new number is used at once and saved, a wrong one is refused with
  HTTP 400).
- `tests/test_stop_and_delete.py` (2 tests): Stop ends a step waiting on Claude Code together with its programs, and
  Delete stops a running analysis first.

Run `tests/test_web_evidence.py` in a `pytest` call of its own, as `run_tests.sh` does: the test files that start the
whole application set a company URL for their process, and with a company URL Claude Code is never started.
(`tests/test_optional_references.py` and `tests/test_model_settings.py` are in `run_tests.sh`, suite `unit_errors`.)

The unit suites use their
own temporary databases, run folders and test folder (it never touches `db/`, the run list or `suite/` of the
installation) and always uses the stand-in AI reviewer and the simulated bench, whatever the config says. **One
exception:** the simulated bench writes its trace files into `$APP/runs/_bench/` (about 166 MB after one test run).
That folder may be deleted afterwards when no server is running from `$APP` (`rm -rf runs/_bench`); the simulated
bench writes new traces when it needs them.

If it fails: read the assertion text; the usual causes are a missing package (step 2.2), a Python older than 3.10, or
a file-system without symbolic links for `/tmp` (the test links `app/`, `stage1/`, `stage2/`, `data/`, `config/`
into a temporary folder). Do not continue to production with a failing test.

### [ ] 2.5 Configure the AI reviewer

Decide with the owner which endpoint to use. The backends (`stage2/llm_adapter.py`, `app/stage2_service.py`
`make_llm`, `app/stage1_runner.py` `llm_backend`):

| `llm.backend` | What it uses | Stage-1 second opinion | Needs |
|---|---|---|---|
| `http` (shipped in `config/app_config.json`) | the Messages API over plain HTTPS (`<URL>/v1/messages`) with the key, no package needed for stage 2 (`stage2/llm_adapter.py` `_http`) | yes, through the `anthropic` package with the same key, URL and model; without the package stage 1 runs without a model (`app/stage1_runner.py` `llm_backend`) | the key (Settings → Model connection, or the variable named by `llm.api_key_env`); `llm.base_url` for a gateway; `anthropic` from `deploy/requirements.txt` for stage 1 |
| `cli` | the `claude` command-line program, logged in on this machine | yes | `claude` on the `PATH` of the **service user**, logged in as that user; no key |
| `sdk` | Anthropic API or a company gateway through the `anthropic` package | yes (`llm.batch = true` sends stage 1 as one batch: cheaper, slower) | `anthropic` installed in the venv; the key in the variable named by `llm.api_key_env`; `llm.base_url` for a gateway (the SDK appends `/v1/messages`); a gateway that wants a bearer token can use `ANTHROPIC_AUTH_TOKEN` |
| `openai-compat` | any OpenAI-style chat-completions endpoint | **no**: stage 1 runs its review without a model (status "isolated from the packets alone; no second opinion was asked"); stage 2 uses the endpoint | `llm.base_url` = the part before `/chat/completions` (the code posts to `base_url + "/chat/completions"`, so for most servers it ends in `/v1`), `llm.model`, key variable in `llm.api_key_env` |
| `standin` | no model; deterministic answers from the stored knowledge and the error family's template | no | nothing (tests, demonstrations, an installation that must not call a model) |
| `auto` | `sdk` if `ANTHROPIC_API_KEY` or `ANTHROPIC_AUTH_TOKEN` is set, else `cli` if `claude` exists, else stand-in | as chosen | — |

Other keys: `llm.model` (shipped: `claude-haiku-5-5`), `llm.effort` (`low` / `medium` / `high`),
`llm.capture_check` (one extra call per run), `llm.workers` (parallel stage-1 calls), `llm.tools` (`[]` or
`["web_search"]`). The code also accepts `ollama` (a local Ollama server on `http://localhost:11434`); it is not
offered on the Settings page, it gives stage 2 a model, and stage 1 then runs its review without a model (like
`openai-compat` and `standin`; only `auto`, `sdk`, `cli` and, with the `anthropic` package, `http` give stage 1 a
model, `app/stage1_runner.py`). The production example `deploy/config.production.example.json` has `sdk` with an
example gateway address; a save on Settings → Model connection turns `auto`, `sdk` or `cli` into `http`
(`app/api/hier_api.py` `model_put`). The flow's agents are set apart: "The agents run on" Claude Code (shipped
`agentic.runtime`), Model connection or Stand-in.

How to set it:
- **Settings → Model connection** (the main page's top bar, after `python3 run_app.py`; added 2026-11-11), the one place for
  every part (the agents, stage 1 and 2, the error pages): **URL** (empty = Anthropic, https://api.anthropic.com; otherwise the
  company gateway), **Model name**, **API key** (never shown back: the field shows only its last 4 characters and whether it was
  saved on this page or came from the computer's environment), then **Save and test the connection** (one small call; the answer
  or the error is shown). The key goes to `~/.config/f2t/env` of the user the server runs as (mode 600; `F2T_ENV_FILE` names
  another file), never into `config/app_config.json`. `run_app.py` loads it at every start (`app/model_env.py` `load`):
  **a key saved on the page wins over a key already in the environment**, including the service's environment file; the
  configured variable (`llm.api_key_env`) is copied into `ANTHROPIC_API_KEY`, which every part reads, and the URL into
  `ANTHROPIC_BASE_URL`. The start prints `Model connection: <URL>, model <model>, key <source> ending ...XXXX` (the last 4
  characters only for a key of at least 12 characters; `<source>` says "saved on the Settings page" or "from this computer's
  environment (not set on the Settings page)"). A save takes effect at once, without a restart, and sets `llm.backend` to
  `http` when it was `auto`, `sdk` or `cli`. On the page the URL is kept in one form: `https://` added, a typed `/v1` or
  `/v1/messages` removed (`/v1/messages` is added by every caller); a URL typed into the file by hand is used as written.
  The agents: with the URL empty Claude Code runs them (with the same key and URL, and
  `CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1`); **with a URL of the company's own (a gateway) they run through the Model
  connection instead of Claude Code**, so every call goes to that URL. "A different model for the agents" (More settings) is
  used by Claude Code only. "Save and test the connection" makes one real call through the model connection and one
  through what runs the agents, names the address it called, and explains every error in words (HTTP 402: no credit or
  budget left on the account; 401: the key was refused; 404: give the base address without `/v1`; the full list is in
  `deploy/OPERATIONS.md` section 6). With `server.lock_endpoint: true` the URL and key fields are greyed out and a change of
  them is refused (HTTP 403); the model name can still be changed. **Production practice** (`deploy/DEPLOY.md` section 5.2):
  the key only in the root-only environment file, the lock on, and no key file of the service user, because a key saved on
  the page would win over the environment file at every later start.
- **Older settings page** (sidebar "⚙ Settings" of the earlier packet workflow): "How the AI reviewer is reached (backend)", "Model", "API base URL",
  "API key environment variable", then **Save**. This sends `PUT /api/config` (`app/api/config_api.py`), writes
  `config/app_config.json` and switches the AI reviewer at once, without a restart (`Stage2Service.reload_llm`).
  The message reads "saved · the AI reviewer now in use: <name>".
- **The lock (`server.lock_endpoint`)**: shipped `false` in `config/app_config.json`, `true` in
  `deploy/config.production.example.json`. When it is `true`, the Settings page (and `PUT /api/config`) can no
  longer change `llm.backend`, `llm.base_url`, `llm.api_key_env` or `llm.tools`: a
  **Save** that changes one of them is refused with HTTP 403 "<key> is locked by server.lock_endpoint: stop the
  service, edit the config file, start it again". This stops anyone who reaches the page from sending the key to
  another server or widening the readable folders. Model, effort and the stage-1 / stage-2 limits can still be
  changed on the page.
- **What `PUT /api/config` accepts**: only the sections `llm`, `stage1`, `stage2` and `paths`. `kpi.*` (the manual
  baselines for the Key results) and `server.*` can only be changed by editing the file.
- **Read only at start** (restart after changing them, even when saved on the Settings page): `stage2.bench`,
  `paths.*`, `server.*`, and the environment (keys in the environment file, `PATH`). A key or URL saved on
  Settings → Model connection is the exception: it is used at once.
- **Edit `config/app_config.json`** with the server stopped, then start it. (Editing it while the server runs is
  pointless: the next **Save** on the Settings page overwrites the file with the values in memory.)

The key itself goes into the service environment (`/etc/field-to-test-loop/environment`, see `deploy/DEPLOY.md`
section 5). Never type the key on the command line (it would land in the shell history and the process list). For a
test shell:
```bash
read -rs ANTHROPIC_API_KEY; export ANTHROPIC_API_KEY   # paste the key, press Enter (nothing is shown); or the variable named in llm.api_key_env
python3 deploy/preflight.py --check-llm                # expect: the AI reviewer check PASS (one real model call)
```
As the service user with the service's environment file (this is what the service will see):
```bash
sudo sh -c 'set -a; . /etc/field-to-test-loop/environment; set +a; cd /opt/field-to-test-loop/current && exec runuser -u ftl -- .venv/bin/python deploy/preflight.py --config config/app_config.json --check-llm'
```
(`runuser -u` keeps the loaded variables; plain `sudo -u ftl ...` drops them, and then the key check FAILs.)
`preflight.py` checks the key of its own environment; it does not read the page's key file. After the start, check
which key the server uses: `curl -fsS http://127.0.0.1:${PORT:-8077}/api/hier/model` → `key_source`, `key_end` (last 4
characters), `base_url`, `model`, `locked`; then press **Save and test the connection** in Settings.
Expected name of the active reviewer (`GET /api/config` → `llm_active`, also the sidebar badge "AI reviewer"):
`anthropic:<model>:<effort>` for http/cli/sdk, `openai-compat:<model>`, or `stand-in` (badge "stand-in (no model)").
**If you configured a model and see `stand-in`, the model is not reachable** — see section 5.

### [ ] 2.6 First start and the first synthetic run, end to end

**Where to run it.** This run writes events into the knowledge base and a regression test into `suite/`. If the
production knowledge base must start empty, do it on a scratch copy of `$APP` with its own `db/` and another port
(rule 4); the copy uses the virtual environment of `$APP`:
```bash
APP=$PWD                                         # run this block from the installation folder
mkdir -p /tmp/f2t-demo/13_production_app
rsync -a --exclude=/db/ --exclude=/runs/ --exclude=/suite/ --exclude=/samples/ --exclude=/.venv/ "$APP/" /tmp/f2t-demo/13_production_app/
cd /tmp/f2t-demo/13_production_app && PORT=8098 && "$APP/.venv/bin/python" run_app.py --port $PORT --standin
```
That shell now runs the scratch server: skip the start command below, run the rest in a second shell from
`/tmp/f2t-demo/13_production_app` with `PORT=8098`, and delete that folder afterwards.

`paths.allowed_csv_roots` only lists the folders the file picker starts in (shipped `["/"]`). Since 2026-11-03
(the owner's rule) **no path is refused**: any file the service user can read may be loaded, so limit a shared
server with file permissions on the service user, not with this list. It is read **only at start**.

Every command below uses the shell variable `PORT` (default 8077, the shipped `server.port`); set `PORT=<port>` in
each shell if you start on another port.
```bash
PORT=${PORT:-8077}
ss -ltn "sport = :$PORT"                # expect: no listener (otherwise see section 5, "port in use")
python3 run_app.py --port "$PORT"       # expect: "Model connection: <URL>, model <model>, key <source> ...", then
                                        #         "Field-to-Test Loop  ->  http://127.0.0.1:8077   (local only; Ctrl-C to stop)"
```
Options: `--port N`, `--config PATH`, `--standin` (forces the stand-in AI reviewer for this process; if you then
press **Save** on the Settings page, `"backend": "standin"` is written into the config file — check it afterwards).
In a second shell:
```bash
PORT=${PORT:-8077}
curl -fsS http://127.0.0.1:$PORT/api/config | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d["llm_active"], d["config"]["stage2"]["bench"])'
# expect e.g.: anthropic:claude-haiku-5-5:low synthetic      (stand-in synthetic with --standin)
curl -fsS http://127.0.0.1:$PORT/api/db/summary | python3 -c 'import json,sys; print(json.load(sys.stdin)["knowledge"])'
# expect on a fresh install: {... 'events': 0 ...}
```

**About the synthetic captures in the code-only package.** The screens have no sample picker;
`POST /api/samples/generate` makes a capture with the error types you name ("cards"). In this package it answers
`"host_evidence": {}`: the host-log simulator (`stage1/tools/`) is not shipped, so error types that need the host log
are not found. The analyser may also report error types that were not planted and miss planted ones: on the cold
install `{"cards":"T-42,L-21,C-16","seed":11}` gave T-42, M-020 and C-16 (L-21 missed, M-020 not planted). Use
`{"cards":"T-42","seed":5}`: it gives exactly one defect, T-42, which stage 2 reproduces on the simulated bench
(checked on 2026-10-27 on a fresh unpacked copy).

#### A. Through the API (agents without a browser) — the complete loop

On a fresh installation with the stand-in there is no procedure card on the screen yet (no stored procedure and no
AI proposal), so a headless installer drives the decision through the API. Copy the whole block into a shell in
`$APP` while the server runs (`jq` is not needed; `python3` reads the answers). It was run exactly like this on a
fresh unpacked copy of the code-only archive, started with `--standin`, and took about 45 seconds.

```bash
PORT=${PORT:-8077}                  # the port the server listens on
BASE=http://127.0.0.1:$PORT
WHO="installer one"                 # your real name or agent name: recorded with the run and the decision
# jget KEY: print one field of the JSON read from standard input (dots for nested keys); jq is not needed
jget() { python3 -c 'import json,sys
d = json.load(sys.stdin)
for k in sys.argv[1].split("."):
    d = d[int(k)] if isinstance(d, list) else d.get(k)
print(json.dumps(d) if isinstance(d, (dict, list)) else d)' "$1"; }
# waitjob JOB: ask every 2 seconds until the job has ended; prints done, failed or cancelled
waitjob() { while :; do st=$(curl -fsS "$BASE/api/jobs/$1" | jget status)
  case "$st" in done|failed|cancelled) echo "job $1: $st"; return ;; esac; sleep 2; done; }

# 1. make a synthetic capture with one planted error type (T-42)
S=$(curl -fsS -X POST -H 'Content-Type: application/json' -d '{"cards":"T-42","seed":5}' "$BASE/api/samples/generate")
echo "$S"
CSV=$(echo "$S" | jget csv_path); NSZE=$(echo "$S" | jget nsze)

# 2. stage 1 (the analyser), then list the defects
R=$(curl -fsS -X POST -H 'Content-Type: application/json' \
  -d "{\"csv_path\":\"$CSV\",\"nsze\":\"$NSZE\",\"operator\":\"$WHO\",\"label\":\"first end-to-end run\"}" "$BASE/api/runs")
echo "$R"
RUN=$(echo "$R" | jget run_id)
waitjob "$(echo "$R" | jget job)"
curl -fsS "$BASE/api/runs/$RUN/incidents" | python3 -c 'import json,sys
for i in json.load(sys.stdin): print(i["id"], i["card"], i["status_word"])'

# 3. start stage 2 (the knowledge-base lookup of every defect) and wait for it
J=$(curl -fsS -X POST "$BASE/api/runs/$RUN/stage2/start" | jget job)
waitjob "$J"
INC=$(curl -fsS "$BASE/api/runs/$RUN/stage2/queue" | jget next)
echo "next defect: $INC"

# 4. show the defect's candidates and choose what "Correct" applies to
V=$(curl -fsS -X POST "$BASE/api/runs/$RUN/incidents/$INC/present")
echo "$V" | python3 -c 'import json,sys
for a in json.load(sys.stdin)["card"]["alternatives"]: print(a["doc_id"], "|", a["kind"], "|", a["label"])'
TARGET=$(echo "$V" | python3 -c 'import json,sys
c = json.load(sys.stdin)["card"]; alts = [a for a in c["alternatives"] if a.get("sig") in (None, c["card"])]
pick = [a for a in alts if a["doc_id"].startswith("sol::")] or [a for a in alts if a["doc_id"].startswith("cause::")] or alts
print(pick[0]["doc_id"])')
echo "target: $TARGET"

# 5. the decision "Correct" (action accept): starts a lab job (search, lab check, test writer)
A=$(curl -sS -X POST -H 'Content-Type: application/json' \
  -d "{\"action\":\"accept\",\"targets\":[\"$TARGET\"],\"requester\":\"$WHO\"}" "$BASE/api/runs/$RUN/incidents/$INC/act")
echo "$A"
J=$(echo "$A" | jget job)
waitjob "$J"
curl -fsS "$BASE/api/jobs/$J" | python3 -c 'import json,sys
r = json.load(sys.stdin)["result"]; c = r.get("closed_loop") or {}
print("outcome:", r["status"], "| regression test admitted:", r["admitted"])
print("lab check: found on known-bad firmware", c.get("known_bad_hits"), "of", c.get("known_bad_n"), "| on fixed firmware", c.get("fixed_hits"), "of", c.get("fixed_n"))
print("test files:", r.get("test_files"))'

# 6. the tests on disk, the report and the leakage key result
ls suite/
curl -fsS "$BASE/api/runs/$RUN/report?format=md" | tail -3; echo
curl -fsS "$BASE/api/kpi" | python3 -c 'import json,sys; print("leakage (must be 0):", json.load(sys.stdin)["quality"]["known_signature_leakage"])'
```

Output of the verified run (ids and paths differ on your machine; `…` = shortened):
```
{"cards":["T-42"],"csv_path":"<$APP>/samples/sample_T-42_seed5.csv","host_evidence":{},"nsze":"0x3A386030","rows":35371}
{"job":"stage1-7eb5f164ee","reused":false,"run_id":"run-20261027-132525-dc46"}
job stage1-7eb5f164ee: done
INC-0001 T-42 Confirmed
job stage2_prepare-2fce07389e: done
next defect: INC-0001
sig::T-42 | signature | error type T-42
target: sig::T-42
{"job":"stage2-1ea5aa0aeb","result":{"job":"stage2-1ea5aa0aeb","queued":true}}
job stage2-1ea5aa0aeb: done
outcome: confirmed | regression test admitted: True
lab check: found on known-bad firmware 6 of 6 | on fixed firmware 0 of 3
test files: ['conftest.py', 'manifest.json', 'test_T_T_42_Synthetic_NVMe_SSD_1TB_a1192a40.py', 'conftest.py', 'test_T_T_42_Synthetic_NVMe_SSD_1TB_9fe3c93b.py']
T-T-42-Synthetic_NVMe_SSD_1TB-9fe3c93b
T-T-42-Synthetic_NVMe_SSD_1TB-a1192a40
| INC-0001 | T-42 | Not seen before - … | accept | AI reviewer's proposal | confirmed | 263 | 68 | 6 of 6 known-bad / 0 of 3 fixed | yes | yes | … |

Stage 2 totals: 1 presented, 1 executed, 1 tests admitted, 1 optimal (same error in 3 runs in a row), 0 first-level-triage timeouts.
leakage (must be 0): 0
```
How to read it:
- **The target.** On a fresh database the only candidate is the error type itself, `sig::T-42`; accepting it starts
  the search from the packets. Once procedures are stored, the candidates also include `sol::<procedure id>` (a
  stored procedure) and `cause::<error type>::<cause id>` (a stored cause); the script then prefers a procedure,
  then a cause, as the **Correct** button does (`app/static/js/review.js`). The accepted forms are listed in
  `stage2/admin_actions.py` `parse_target`. `accept` needs no second admin; promote, retire and delete do (rule 7).
- **The result.** `admitted: True` and "6 of 6 on known-bad, 0 of 3 on fixed" mean the lab check passed and a
  regression test was written. Two folders appear in `suite/`: the reproducing procedure and its "most stressful
  conditions" variant (`result.stress.admitted`). `status` can also be `budget_exhausted` ("not reproduced") or
  `triage_timeout` (section 5).
- Run the block once. A second time, the same capture with the same inputs opens the existing run
  (`"reused": true`) instead of analysing it again.
- Optional: run a generated test, `cd suite/<test id> && python3 -m pytest -q` → `2 passed` (about 40 s; the
  fixtures use the simulated bench).

#### B. The same in a browser

In a browser on the server (or through a secure shell (SSH) tunnel: `ssh -L $PORT:127.0.0.1:$PORT <server>`), open
http://127.0.0.1:$PORT (8077 unless you chose another port) and:
1. **1 Choose the trace**: paste the `csv_path` of the sample into "Analyzer CSV path", press "Find companion files
   next to the CSV" (fills the host evidence and namespace size when present; in this package there are none), type
   "Your name" (required), enter `0x3A386030` as the namespace size, press **Analyse the trace (stage 1)**. The ring
   fills to 100 %; the activity stream ends with "stage 1 complete: ...".
2. **3 Defects found**: one defect (Defect 1, error type T-42, status **Confirmed**) with the AI reviewer's opinion.
   Press **Continue to stage 2**, then **Start stage 2**.
3. **4 Reproduce and decide (stage 2)**: press **Correct** on a procedure card. On a fresh installation with the
   stand-in there may be no card yet ("Nothing saved for this error type yet ..."); then use the API block above
   for this decision. A lab job runs (simulated); the Result section shows the lab runs, "found … on known-bad
   firmware and … on fixed firmware", and "regression test admitted" when the lab check passed.
4. **5 Report and tests**: **Build or refresh the report**; the generated test appears under "Generated regression
   tests"; "Key results — all runs on this installation" shows "known defects that came back and slipped past their
   test (must be 0)" = 0.

**Afterwards.** This is a demonstration on the simulated bench; delete the run if the owner wants a clean history
(the **Delete** button under "Earlier runs", or `curl -X DELETE http://127.0.0.1:$PORT/api/runs/<run id>`, keeps the
knowledge base). The knowledge-base events it created stay; tell the owner (or use the scratch copy described at
the top of this step). **Before step 2.7, stop this server** (Ctrl-C in its shell, or `kill <PID>` with the PID
shown by `ss -ltnp "sport = :$PORT"`): the service of step 2.7 runs from the same `db/` and port, and two processes
on one `db/` break rule 4. The stop loses nothing that is finished: every lookup and every decision is committed to
`db/knowledge.sqlite` immediately; only a lab job still running would be lost (marked failed at the next start). The
backups of step 2.7 (`deploy/backup.sh`) are safe while the service runs.

### [ ] 2.7 Service, reverse proxy and backups

Follow `deploy/DEPLOY.md`. It covers the systemd unit `deploy/field-to-test-loop.service`, the authenticating reverse
proxy `deploy/nginx-field-to-test-loop.conf` (the application has no authentication of its own), the production
config template `deploy/config.production.example.json`, backups with `deploy/backup.sh` / `deploy/restore.sh`,
upgrades and rollback. Checks after it:

```bash
systemctl status field-to-test-loop          # expect: active (running)   [unit name as installed per deploy/DEPLOY.md]
curl -fsS http://127.0.0.1:${PORT:-8077}/api/config >/dev/null && echo up   # expect: up   (PORT = server.port)
curl -s -o /dev/null -w '%{http_code}\n' https://<proxy host>/           # without credentials: expect 401 or a login redirect, never 200
curl -s --max-time 5 http://<server address>:${PORT:-8077}/ ; echo $?     # from ANOTHER machine: expect a connection failure (non-zero)
```
Also check: the service user can write `$APP/db`, `$APP/runs`, `$APP/suite`, `$APP/samples` and
`$APP/config/app_config.json` (Save writes it); for `cli` the service user is logged in to `claude`; the key variable
is in the service environment, not in the config, and no key file written by the Settings page exists for the service
user (`deploy/DEPLOY.md` section 5.2). Run one backup and one restore test now
(`deploy/OPERATIONS.md` sections 3 and 4).

### [ ] 2.8 Bench integration (separate track; may come after go-live)

With `stage2.bench = "synthetic"` the lab is a simulated drive (`stage2/oracle.py` `SyntheticDeviceOracle` with
`stage2/testgen.py` `GeneratorBench`): the whole loop works, but procedures found are **not physically meaningful**
(`docs/OPERATOR_AND_BACKEND_GUIDE.html` sections 9.6 and 13). To connect a real drive, follow
`deploy/BENCH_INTEGRATION.md` and `deploy/bench_hook_template.py`: implement `run(scenario)` and `detect(trace)` in
`app/bench_hook.py` (optional `inject(spec)` / `clear_faults()` for a jammer), then set `stage2.bench = "hook"` and
decide `stage2.search_on` (`model` = search on the fast device model, the bench verifies; `bench` = every search
trial on the bench). **`stage2.bench` is read only when the server starts** (`app/stage2_service.py` builds the bench
factory in `__init__`; `reload_llm` does not touch it): restart after changing it, even if you changed it on the
Settings page. Until the hook is done, say "lab runs are simulated" in every report to the owner.

### [ ] 2.9 Go-live acceptance

All of these, recorded in the report (section 7):
- [ ] `./run_tests.sh` OK; `deploy/preflight.py --check-llm` exit 0 when run as the service user with the environment file loaded (command in step 2.5); `server.lock_endpoint` PASS.
- [ ] `llm_active` is the intended model (not `stand-in`, unless the owner chose no model).
- [ ] Settings → **Save and test the connection**: both lines ✔ (model connection and agents); the start line in the journal reads `key from this computer's environment (not set on the Settings page)` and no key file of the service user exists (`deploy/DEPLOY.md` section 5.2).
- [ ] The bench decision is explicit: `synthetic` (lab simulated, said so to the owner) or `hook` (one real lab run done).
- [ ] The server listens on 127.0.0.1 only; the proxy refuses unauthenticated requests; the server port (8077 unless changed) is unreachable from another machine.
- [ ] The service user can read only the export folders and the application (file permissions; the application itself refuses no path).
- [ ] One backup made and restored into a scratch copy, counts compared (OPERATIONS sections 3 and 4).
- [ ] One end-to-end run (synthetic, or a real capture if available) reached a regression test; Key results show leakage 0.
- [ ] Two named admins exist for the two-person rule and know it.
- [ ] Operators have the operator guide (`docs/OPERATOR_AND_BACKEND_GUIDE.html`).

---

## 3. Operating it day to day (short; details in `deploy/OPERATIONS.md` and the operator guide)

- **Analyse a capture**: sidebar "1 Choose the trace" → path, "Your name", optional host evidence (`dmesg -x`,
  `host_events.jsonl`) → **Analyse the trace (stage 1)**. Without host evidence about 46 error types end as "Needs
  evidence". A file analysed before with the same inputs opens the earlier run ("this CSV was already processed with
  the same inputs and LLM settings; opened the existing run"); tick "analyse again even if this file was analysed
  before" to force. Guide sections "4. Step 1 · Choose the trace", "5. Step 2 · Analyse the trace (stage 1)".
- **Read the defects**: "3 Defects found" and the defect page ("Open the full record"). Guide section "6".
- **Decide**: **Continue to stage 2** → **Start stage 2** (one model call per defect; it runs in the background) →
  per defect **Correct** / **Needs changes** / **Not correct**, ranking, "Save decisions", "Generate test cases",
  "Try nearby variations"; everything else under **All details**. Guide sections "7", "8", "9. What happens in the lab
  when you press Correct".
- **Report and tests**: "5 Report and tests" → **Build or refresh the report**. Guide section "12.1", "12.2".
- **Knowledge base page** (`/db`, sidebar "Knowledge base"): counts, error types, the event log with "Undo event
  number" and **Undo this event & rebuild**. Guide section "12.3", "3.5 The knowledge base is an event log".
- **Settings**: guide section "12.4". The model connection (URL, model, key, the test, rotating the key):
  `deploy/OPERATIONS.md` section 6.
- **Defect names and causes** are made by code, the same for every admin and every day; the admin can only choose
  another of the 20 cause keywords: `deploy/OPERATIONS.md` section 12. The flow's Data Grounder, Stop and Delete:
  section 13.
- Service start / stop / logs, backups, upgrades, key rotation, deleting runs, exporting tests: `deploy/OPERATIONS.md`.

---

## 4. How to verify it is working

1. **Tests**: `./run_tests.sh` (section 2.4). After an upgrade or a config change, run them again.
2. **Health check** (no dedicated health address exists; these are cheap read-only calls):
   ```bash
   PORT=${PORT:-8077}     # server.port
   curl -fsS http://127.0.0.1:$PORT/api/config  | python3 -c 'import json,sys; print(json.load(sys.stdin)["llm_active"])'
   curl -fsS http://127.0.0.1:$PORT/api/db/summary | python3 -m json.tool | head -20
   curl -fsS "http://127.0.0.1:$PORT/api/jobs?kind=stage1&limit=20" | python3 -c 'import json,sys; print([j["status"] for j in json.load(sys.stdin)])'
   ```
   Healthy: HTTP 200, the intended `llm_active`, no unexplained `failed` jobs.
3. **Key results** (Report page, or `GET /api/kpi`):
   ```bash
   curl -fsS http://127.0.0.1:${PORT:-8077}/api/kpi | python3 -c 'import json,sys; q=json.load(sys.stdin)["quality"]; print("leakage", q["known_signature_leakage"], "| tested recurrences", q["recurrences_tested"])'
   ```
   **"known defects that came back and slipped past their test (must be 0)"** = `quality.known_signature_leakage`.
   Anything above 0 means an error type seen before, judged Correct again, did not pass its own test again:
   investigate (wrong device or firmware on the bench, a changed procedure, or a real regression) and tell the owner.
   Also watch `efficiency.runs_within_triage_budget` against `efficiency.runs`.
4. **Database by hand** (operator guide section "15.3 Check the database by hand"; read-only, safe while running):
   ```bash
   sqlite3 -readonly db/knowledge.sqlite "SELECT id, datetime(ts,'unixepoch','localtime'), kind, actor, substr(payload,1,160) FROM event ORDER BY id DESC LIMIT 20;"
   sqlite3 -readonly db/knowledge.sqlite "SELECT src, dst, a, b, n, round(a/(a+b),2) AS rating, ta, tb, round(ta/(ta+tb),2) AS lab_reliability FROM edge;"
   sqlite3 -readonly db/knowledge.sqlite "SELECT vhash FROM solution WHERE status='admin-approved' AND approved_by = producer;"   # two-person rule: must be empty
   sqlite3 -readonly db/knowledge.sqlite "PRAGMA integrity_check;"     # expect: ok
   ```
5. **A generated test still passes**: `cd suite/<test id> && python3 -m pytest -q` (simulated bench unless the
   fixtures were replaced; see `deploy/OPERATIONS.md` section 8).
6. **Long checks with the real model** (optional, cost money, need the server running): `python3 tests/exercise_loop.py`
   (10–17 min, report in `runs/exercise_report.md`; it writes to the database of the running server — run it on a
   scratch copy, not on production) and `python3 tests/ui_smoke.py` (needs Chrome and `websocket-client`).

---

## 5. Troubleshooting

| Symptom (exact text where there is one) | Likely cause | Fix |
|---|---|---|
| Toast "Stage 1 must complete before stage 2 can be started." | Step 4 was opened while the selected run's stage 1 is still running, failed, or no run is selected (`app/static/js/main.js`) | Select the run under "Earlier runs", wait for 100 %, press **Continue to stage 2** → **Start stage 2** |
| HTTP 409 from `.../incidents/<inc>/act`, `/present` or `/solutions`: "stage 1 has not finished for this run (…)" or "stage 2 has not been started for this run - POST /api/runs/<run>/stage2/start" | The stage gate (`app/api/stage2_api.py` `_gate`) | Wait for stage 1; press **Start stage 2** or `POST /api/runs/<run>/stage2/start` |
| HTTP 400 from `/act` with "promote needs a second admin (approver != requester)" (also `deprecate`), or "delete needs a second admin (approver != requester of the delete)" | Two-person rule (`stage2/admin_actions.py`) | A second real person enters their own name as the second admin. Never work around it |
| "not a file: <path>" | Wrong path, or the service user cannot read it | Check the path and the file permissions for the service user |
| "Please type your name first: it is recorded with the run and with every decision." | "Your name" is empty | Type a name |
| Sidebar badge "AI reviewer stand-in (no model)" although a model was configured | `cli`: `claude` not on the service user's `PATH`; `sdk`: `anthropic` not installed in the venv and the copy in `stage1/vendor/` does not load on this Python (it was built for CPython 3.13 x86-64), so stage 2 silently uses the stand-in; `auto`: no key and no `claude` | Install `anthropic` from `deploy/requirements.txt` / install and log in `claude` / set the key in the service environment; then **restart** the service (a new package, `PATH` or key is seen only by a new process; with `server.lock_endpoint: true` a backend change also needs the file edit and a restart); confirm with the preflight command of step 2.5 (as the service user, with the environment file loaded) |
| Badge shows the model, but proposals say "problems in the proposal found by the analyser's checks: fallback to stand-in", or the stage-1 activity reads "... (N answered, M errors)" with M > 0 | Model calls fail: key missing or revoked, `claude` not logged in for the service user, wrong `llm.base_url`, rate limit, non-JSON answers | Fix the endpoint; failed answers are never cached, so re-running works. For `openai-compat` check that `base_url` ends where `/chat/completions` should be appended |
| Every defect "isolated from the packets alone; no second opinion was asked" | `llm.backend` is `openai-compat`, `ollama` or `standin`: stage 1 then runs its review without a model (`app/stage1_runner.py` `llm_backend`) | Expected with those backends; use `cli`, `sdk` or `auto` if the stage-1 second opinion is required |
| `deploy/preflight.py` FAIL on the bench hook | `stage2.bench = "hook"` but `app/bench_hook.py` is still the template (`HardwareBench.run` raises `NotImplementedError("drive fio / nvme-cli on the device, ...")`) | Set `stage2.bench` back to `"synthetic"` and restart, or finish the hook per `deploy/BENCH_INTEGRATION.md` |
| Lab job failed with that `NotImplementedError` | Same as above, at run time | Same as above |
| Bench changed on the Settings page, lab runs did not change | `stage2.bench` is read only at start | Restart the service |
| `OSError: [Errno 98] Address already in use` at start | Another process holds the port (8077 unless changed) — possibly a second copy of this application (rule 4) | `ss -ltnp "sport = :${PORT:-8077}"`; stop the other process if it is a duplicate of this app; otherwise `python3 run_app.py --port <free port>` and update the proxy |
| The page opens but nothing works / is blank; browser console shows 404 for `/static/js/main.js` | Mail-safe archive unpacked without `restore_names.py` (files still `*.js.txt`) | `python3 restore_names.py` in the folder that holds it, or rename `app/static/js/*.js.txt` to `*.js`; reload |
| Activity log / job error "stage-1 step analyze failed (exit N): …" (or `fuse`, `isolate`, `review`, `report`) | The analyser sub-command exited non-zero (`app/stage1_runner.py` `step`). Common: not the 113-column export (header must match `stage1/reference/final_113_columns.csv`), unreadable or truncated file, disk full, `numpy` missing for the service's Python; for `review`: the AI backend | Read `runs/<run>/stage1_app.log` (full output of every step). For `review`, switch to `standin` once to confirm the rest works, then fix the backend. The optional `capture_check` step never fails a run |
| Job status `failed` with "server restarted while running" | The service was restarted during a job (`app/jobs.py` marks such jobs failed at start) | Run it again (stage 1: tick "analyse again even if this file was analysed before"; stage 2: repeat the decision). Only that job is lost: the decision itself and every lookup were committed before the job started |
| "the run is still in progress - cancel it first" / "a stage-2 job of this run is still in progress - wait for it to finish" on **Delete** | A job of that run is running | Cancel or wait, then delete |
| Result "first-level triage limit (10 min) exceeded" (status `triage_timeout`) | Search + lab check passed `stage2.time_budget_s` (600 s): slow bench, `search_on = "bench"`, large `opt_budget`, or many decisions waiting (lab jobs run one at a time) | **Record the failed attempt (−1) and restart the search** (`restart_failed`) to search again with another random seed, give a better procedure with **Needs changes**, or — owner's decision, it is the project's 10-minute rule — raise `stage2.time_budget_s` |
| **Correct** pressed, procedure "reproduced", but no regression test admitted; the Result line shows "found … on fixed firmware" with more than 0 | The lab check failed on fixed firmware: it passes only with ≥ 1 hit on known-bad and 0 on fixed (`stage2/testgen.py` `verify_closed_loop`). On a real bench: the "fixed" device is not running the fixed firmware, or the procedure triggers a neighbouring error type there | Check the fixed bench's firmware; try **Needs changes** or "Try nearby variations". A folder may still be written under `suite/` with `manifest.json` → `closed_loop_at_generation.passed = false`; it is not admitted — do not export it |
| Own version "confirmed" in 3–5 of 6 runs, but no test | Its safe lower estimate (19–44 %) is below the 50 % the lab check requires (guide section 15.4) | Press **Correct** on it so the lab confirms it with 8 runs |
| "not reproduced (trial budget used up)" | The search used `stage2.opt_budget` trials without a reproduction | **Record the failed attempt (−1) and restart the search**, a better starting procedure, or a larger `stage2.opt_budget` |
| Result "not applicable (host workload record)" | The defect came from a workload artifact (ADK / PCMark JSON); the simulated bench cannot run workloads | Expected until a hardware bench runs workloads |
| **Start stage 2** takes very long | One model call per defect (about 20 s each measured with the real model, `docs/VERIFICATION_FROM_SCRATCH.md`); a 4 GB capture had 544 defects | Let the background job run; the screens can be used meanwhile; the answers are cached |
| Disk filling up | `runs/` (each run, plus `runs/_bench/` simulated lab traces: 561 MB on the development machine) | `deploy/OPERATIONS.md` sections 2 and 7 |
| The knowledge base shows a decision nobody meant to make | A wrong click, a test run on production | `deploy/OPERATIONS.md` section 10 (Undo; restore only as a last resort) |
| Settings → **Save and test the connection** shows ✘ with "HTTP 402" ("payment required: the account behind this key has no credit left or its budget is used up ...") | The account behind the key has no credit or budget | Add credit or use a key with budget; every other error and its meaning: `deploy/OPERATIONS.md` section 6 |
| HTTP 403 "the model endpoint and key are locked by server.lock_endpoint: ..." when saving the Model connection | `server.lock_endpoint` is `true` | Expected in production: change the URL in the config file and the key in the environment file with the service stopped (`deploy/OPERATIONS.md` section 6) |
| A new key in `/etc/field-to-test-loop/environment` is not used after the restart; the start line reads `key saved on the Settings page` | A key saved on the Settings page (the service user's `~/.config/f2t/env`) wins over the environment at every start | Remove that key file (or its key line) and restart (`deploy/DEPLOY.md` section 5.2) |
| The Data Grounder ends with every column "no meaning found" | No model answered (no credit, no key, no network); the stand-in gives no meaning | Fix the connection (Save and test the connection), then run the flow again (`deploy/OPERATIONS.md` section 13) |
| Delete of an analysis did nothing, or Stop seemed to do nothing (before 2026-11-11) | Delete was refused while a step worked; a step showed "running" until its model call returned | Since 2026-11-11 Stop ends the steps and their model calls at once and Delete stops a running analysis first (`deploy/OPERATIONS.md` section 13) |

---

## 6. Known limits (state them to the owner; from operator guide section 15.4 and the code)

1. **The lab is simulated** until `app/bench_hook.py` is implemented and `stage2.bench = "hook"`: the loop is proven
   end to end, but the procedures found are only physically meaningful on a real bench (guide sections 9.6 and 13).
2. The jammer variations of "Try nearby variations" need a hardware bench with fault injection (`inject`,
   `clear_faults`); on the simulated bench the result says "needs a hardware bench with fault injection (app/bench_hook.py inject)".
3. An admin's own version reproducing in 3–5 of 6 runs is saved as validated but gets no lab check and no test
   (safe lower estimate below 50 %); only 6 of 6 (61 %) passes. Press **Correct** on it to get a test.
4. The triage-effort saving needs the current manual minutes in `kpi.manual_triage_minutes_per_run`; without them
   it shows "n/a" instead of a guess.
5. The development database contains exercise data; a production installation should start with an empty one
   (section 2.1).
6. **No authentication; operator names are self-declared.** The two-person rule is only as strong as the proxy's
   authentication and the honesty of the names typed.
7. One server process per `db/`; stage-2 lab jobs run one after another (one lock).
8. The stage-1 second opinion runs only with `cli`, `sdk`, `auto`, or `http` with the `anthropic` package installed;
   `openai-compat` and `ollama` give stage 2 a model but stage 1 none; `standin` gives neither.
9. Read only at start: `server.*`, `paths.*` (including `allowed_csv_roots`), `stage2.bench`, and environment
   variables (keys in the environment file, `PATH`). A URL, model or key saved on Settings → Model connection is used
   at once. `kpi.*` and `server.*` can only be changed in the file (with the server stopped). With
   `server.lock_endpoint: true`, `llm.backend`, `llm.base_url`, `llm.api_key_env` and `llm.tools` are refused on the
   older settings page, and the URL, the key variable and the key on the Model connection (HTTP 403); they are
   changed only in the files, followed by a restart. The lock does not cover the agents' settings
   (`PUT /api/agents/settings`: where they run, their model, web search, the Claude Code program path).
15. **A key saved on the Settings page wins over the environment at every start** (`app/model_env.py`). In production
    keep the key only in `/etc/field-to-test-loop/environment` and no key file of the service user
    (`deploy/DEPLOY.md` section 5.2). `preflight.py` does not read that key file.
16. **Defect names and causes are made by code** (`nvme_hier/terms.py`, `nvme_hier/evidence.py`): the model only
    explains. A change of those files changes the names or causes of new isolations; it is a release, with the old
    stored records kept (`deploy/OPERATIONS.md` section 12).
17. For an NVMe command that never completed, the cause rules do not yet look at the stall after its last step, the
    host's Abort or a later reset (they give `firmware_stall`); a rules release is planned.
18. A cause outside the 20 keywords can only be recorded as `unknown_cause`; 9 of the 20 keywords are never chosen by
    the rules, only by an admin. `POST /api/dg/causes` without a keyword (flows made before 2026-11-11) can still store
    a written side and header line.
19. The admins' judgements on the error pages only re-rank causes and solutions (no Undo; rows are only added).
20. The flow's Data Grounder gives a column a meaning only from a source (the web, a reference document, the column's
    name and contents, the model's knowledge, or the admin); without a working model connection the columns stay "no
    meaning found" (`deploy/OPERATIONS.md` section 13).
21. Some tests need the samples, which the code-only zip does not carry (step 2.4).
10. The bundled Anthropic SDK in `stage1/vendor/` loads only on CPython 3.13 x86-64 Linux (its compiled part); for
    `sdk` install `anthropic` from `deploy/requirements.txt`, otherwise stage 2 falls back to the stand-in.
11. `db/knowledge.sqlite` runs with a write-ahead log (`journal_mode=WAL`, `synchronous=NORMAL`): every lookup and
    every decision is committed immediately, so a stop or crash during a lab job loses only that job (it is marked
    failed at the next start). A power failure can at most lose the last commits; the file stays consistent. The
    side files `knowledge.sqlite-wal` and `-shm` belong to it (rule 3). Backups (OPERATIONS sections 3 and 4) protect
    against a lost disk and against wrong decisions.
12. An **Undo** cannot itself be undone from the screens; if an undo was wrong, restore from backup or ask the owner.
13. `db/`, `runs/`, `suite/`, `samples/`, `knowledge/`, `uploads/` always live inside `$APP`; carry `knowledge/` and `uploads/` over on an upgrade (DEPLOY section 10).
14. Generated tests' `conftest.py` uses the simulated bench (`GeneratorBench`); to run them on hardware the two
    fixtures must be replaced (OPERATIONS section 8).

---

## 7. What to report back to the owner after installation

Copy, fill in, send. Never include keys.

```
Field-to-Test Loop installation report
Date / installer:            <date> / <name or agent id>
Host / OS / Python:          <hostname> / <distribution, kernel> / <python3 --version>
Install path ($APP):         <path>          Service user: <user>
Zip received / SHA-256 ok:   <file name> / <yes|no|no checksum supplied>
Mail-safe names restored:    <yes, 10 files | not a mail-safe zip>
Knowledge base at start:     <empty | N events found - owner decided: ...>
Preflight:                   <exit code>; WARN lines: <list>
Tests (./run_tests.sh):      <every suite PASS | FAIL: the suite names and their logs>
AI reviewer:                 backend <...>, model <...>, llm_active <...>, preflight --check-llm <PASS|FAIL>
Model connection:            URL <empty = Anthropic | gateway>, key source <environment | Settings page>, lock <on|off>,
                             Save and test the connection: model connection <ok|error>, agents <ok|error> (<who ran them>)
Tests not in run_tests.sh:   test_grounder_batches.py + test_stop_and_delete.py <passed | ...>; suites that need the samples: <list>
Stage-1 second opinion:      <yes | no (openai-compat/ollama/standin)>
Bench:                       <synthetic - LAB RUNS ARE SIMULATED | hook - first real lab run on <date>>
Network exposure:            server.host 127.0.0.1 <confirmed>; proxy <url>, auth method <...>, unauthenticated request -> <code>
Allowed CSV folders:         <list>
Backups:                     <schedule, destination>; restore test on <date>: counts matched <yes|no>
First end-to-end run:        <run id>, defects <n>, tests admitted <n>, leakage <0>
Two-person rule:             second admins named: <names>
Open issues / deviations:    <...>
Decisions still needed:      <AI endpoint | real bench | who may reach the app | ...>
```
