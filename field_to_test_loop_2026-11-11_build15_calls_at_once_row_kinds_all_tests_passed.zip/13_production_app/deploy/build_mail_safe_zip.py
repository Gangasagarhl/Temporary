#!/usr/bin/env python3
"""Builds field_to_test_loop_code_only_MAIL_SAFE.zip (and its .SHA256.txt) from the code-only archive:
    python3 deploy/build_mail_safe_zip.py [--out DIR]       (run build_code_zip.py first)
Same program, packaged so a mail service accepts it and the copy stays well under the usual attachment limit:
  1. every .js file is named .js.txt and every .sh file .sh.txt; restore_names.py at the archive root (and inside
     13_production_app/) renames them back in one run
  2. stage1/vendor/ (the vendored Anthropic SDK) is left out; `pip install anthropic` replaces it for the sdk backend
  3. docs/ui_map_images/*.jpg are re-encoded smaller (same names) when Pillow is available
"""
import argparse
import hashlib
import io
import os
import time
import zipfile

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NAME = "field_to_test_loop_code_only"
RESTORE = '''"""Restore the file names of the mail-safe package: .js.txt -> .js and .sh.txt -> .sh.
Run once from the folder that holds 13_production_app (or from inside it):  python3 restore_names.py
Running it again is harmless: it reports that there is nothing left to rename."""
import os, sys
here = os.path.dirname(os.path.abspath(__file__))
root = here if os.path.basename(here) == "13_production_app" else os.path.join(here, "13_production_app")
if not os.path.isdir(root):
    sys.exit("13_production_app/ not found next to this script; unzip the package first")
n = 0
for dp, dn, fn in os.walk(root):
    for f in fn:
        if f.endswith(".js.txt") or f.endswith(".sh.txt"):
            src = os.path.join(dp, f); dst = src[:-4]
            os.rename(src, dst); n += 1
            print("renamed", os.path.relpath(src, root), "->", os.path.basename(dst))
print("%d file(s) renamed." % n if n else "Nothing to rename: the names are already restored.")
'''
README = '''MAIL-SAFE COPY of field_to_test_loop_code_only.zip
==================================================
Same program, packaged so a mail service accepts it:
  1. every .js file is named .js.txt and every .sh file .sh.txt  -> run:  python3 restore_names.py  (once)
  2. stage1/vendor/ (a vendored copy of the Anthropic SDK, 5 MB) is left out; the "cli" and "dry-run" AI
     backends need nothing; for the "sdk" backend run:  pip install anthropic
  3. docs/ui_map_images/*.jpg (the application map's screenshots) are re-encoded smaller; same names.
Then follow 13_production_app/README_FIRST.md:  python3 deploy/preflight.py  ->  python3 run_app.py
FAQ entry 44 (13_production_app/docs/FAQ.html) explains both zips; FAQ 55-60 the five-level NVMe hierarchy pages.
'''


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.dirname(APP))
    a = ap.parse_args()
    src = os.path.join(a.out, NAME + ".zip")
    if not os.path.exists(src):
        raise SystemExit("build the code-only archive first: python3 deploy/build_code_zip.py")
    dst = os.path.join(a.out, NAME + "_MAIL_SAFE.zip")
    try:
        from PIL import Image
    except ImportError:
        Image = None
    t0 = time.time()
    n_in = n_out = 0
    renamed = 0
    with zipfile.ZipFile(src) as zin, zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zout:
        for info in zin.infolist():
            n_in += 1
            name = info.filename
            if "/stage1/vendor/" in name:
                continue
            data = zin.read(name)
            if name.endswith((".js", ".sh")):
                name += ".txt"
                renamed += 1
            elif Image is not None and "/docs/ui_map_images/" in name and name.lower().endswith((".jpg", ".jpeg", ".png")):
                try:
                    im = Image.open(io.BytesIO(data)).convert("RGB")
                    buf = io.BytesIO()
                    im.save(buf, "JPEG", quality=55, optimize=True)
                    if len(buf.getvalue()) < len(data):
                        data = buf.getvalue()
                except Exception:      # noqa: BLE001 - keep the original picture
                    pass
            zout.writestr(name, data)
            n_out += 1
        zout.writestr("restore_names.py", RESTORE)
        zout.writestr("13_production_app/restore_names.py", RESTORE)
        zout.writestr("README_MAIL_SAFE.txt", README)
    sha = hashlib.sha256(open(dst, "rb").read()).hexdigest()
    with open(os.path.join(a.out, NAME + "_MAIL_SAFE.SHA256.txt"), "w") as f:
        f.write("%s  %s\n" % (sha, os.path.basename(dst)))
    print("wrote %s: %d of %d files kept, %d renamed, %.1f MB, sha256 %s, in %d s" % (dst, n_out, n_in, renamed, os.path.getsize(dst) / 1e6, sha[:16], time.time() - t0))


if __name__ == "__main__":
    main()
