"""Unit tests for the architecture-rule additions: loop rules + signature score, failure signature, neighbourhood sweep,
workload-artifact import, PPO option, restart_failed / sweep actions."""
import json
import os
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "app"))

from loop_rules import SCORE_THRESHOLD, OPTIMAL_CONSECUTIVE, FIRST_LEVEL_TRIAGE_S, signature_score, consecutive_above   # noqa: E402
from sweep import neighbourhood, stress_of   # noqa: E402
from stage1_adapter import Incident, signature_of   # noqa: E402
from admin_actions import ALL, available   # noqa: E402
from oracle import SyntheticDeviceOracle   # noqa: E402
from ppo_optimizer import PPOOptimizer   # noqa: E402
from llm_adapter import family_template_scenario   # noqa: E402


class LoopRules(unittest.TestCase):
    def test_constants_are_the_diagram_rules(self):
        self.assertEqual((SCORE_THRESHOLD, OPTIMAL_CONSECUTIVE, FIRST_LEVEL_TRIAGE_S), (0.9, 3, 600))

    def test_score_above_threshold_needs_confirmed_same_rule(self):
        f = {"card_id": "T-42", "verdict": "CONFIRMED", "closeness": 0.7, "rule": "CFG.D0_EARLY"}
        self.assertGreater(signature_score([f], {"T-42"}, "CFG.D0_EARLY"), SCORE_THRESHOLD)
        self.assertLessEqual(signature_score([dict(f, verdict="SUSPECT")], {"T-42"}, "CFG.D0_EARLY"), SCORE_THRESHOLD)
        self.assertLessEqual(signature_score([f], {"T-42"}, "OTHER.RULE"), SCORE_THRESHOLD)
        self.assertEqual(signature_score([dict(f, card_id="L-21")], {"T-42"}, "CFG.D0_EARLY"), 0.0)

    def test_consecutive(self):
        self.assertEqual(consecutive_above([0.95, 0.96, 0.5, 0.95, 0.95, 0.95]), 3)
        self.assertEqual(consecutive_above([0.9, 0.9, 0.9]), 0)      # strictly greater


class Signature(unittest.TestCase):
    def test_signature_object(self):
        inc = Incident(id="INC-0001", card="T-42", candidates=[], verdict="CONFIRMED", layer="config", pattern="P19", origin="host",
                       task="t", first_abnormal={"pkt": 37395, "rule": "CFG.D0_EARLY", "detail": "MMIO read 2 ms after D3hot->D0"},
                       packets=(1, 2), evidence_packets=[], rows=[{"range": [1, 3], "rows": ["Packet=1 | TLP Type=CfgWr0 | x", "Packet=2 | DLLP Type=ACK | NAK", "Packet=3 | TLP Type=MRd(32)"]}],
                       explanation={}, nvme_commands=[], tokens=[], firmware="FW-A", raw={})
        s = signature_of(inc, workload="trace A")
        self.assertEqual(s["signature_id"], "sig-INC-0001-T-42")
        self.assertEqual(s["preceding_packets"], ["CfgWr0", "ACK", "MRd(32)"])
        self.assertEqual(s["link_events"].get("NAK"), 1)
        self.assertEqual(s["latency_class"], "slow")
        self.assertEqual(s["workload"], "trace A")


class Sweep(unittest.TestCase):
    def test_neighbourhood_and_stress(self):
        base = {"commands": [{"op": "flush"}, {"op": "write"}], "timing": {"qd": 8, "inter_cmd_us": 400, "bs_kb": 4, "burst_len": 16, "idle_gap_ms": 0}, "power_state": "none"}
        vs = neighbourhood(base)
        keys = [v["variation"] for v in vs]
        self.assertTrue(any("inter_cmd_us x2" in n for n in keys) and any("power L1.2" in n for n in keys) and any("burst" in n for n in keys))
        names = [v["name"] for v in vs]      # the operator's labels are plain words
        self.assertTrue(any("spacing between commands doubled" in n for n in names) and any("power state ASPM L1.2" in n for n in names))
        self.assertTrue(all(v["scenario"] != base for v in vs))
        v2 = next(v for v in vs if "inter_cmd_us x2" in v["variation"])
        self.assertAlmostEqual(stress_of(base, v2), 2.0)
        self.assertEqual(stress_of(base, {"scenario": base, "jammer": {"kind": "tlp_corrupt"}}), 2.0)
        # ranges are respected
        self.assertTrue(all(1 <= v["scenario"]["timing"]["qd"] <= 256 for v in vs))


class WorkloadImport(unittest.TestCase):
    def test_boot_etl_artifact_and_generic_shape(self):
        from workload_import import normalise, to_incidents, card_of
        art = {"run": {"run_id": "fast_01", "assessment": "Fast-Startup"}, "verdict": {"outcome": "FAIL", "measured_ms": 14948, "limit_ms": 14000},
               "primary_hypothesis": "Flush blocked behind background work",
               "abnormalities": [{"id": "ABN-001", "kind": "performance", "severity": "warning", "phase": "postboot",
                                  "component": {"type": "driver", "name": "stornvme"}, "title": "flush latency regressed", "statement": "flush p99 rose from 41 ms to 1512 ms",
                                  "observed": {"metric_id": "postboot.stornvme.flush_latency_p99_ms", "value": 1512, "unit": "ms"},
                                  "baseline": {"center": 41, "spread": 3.0, "n": 10}, "delta": {"abs": 1471, "robust_z": 37.1, "impact_ms": 1471},
                                  "evidence": [{"source_file": "FastStartup_IO_1.etl", "source_offset": 3}], "confidence": 0.9,
                                  "graph_keys": {"symptom": "storage.flush.latency", "component_class": "driver"}}]}
        meta, abn = normalise(art)
        self.assertEqual(meta["workload"], "Fast-Startup")
        self.assertEqual(abn[0]["observed"], 1512)
        self.assertEqual(abn[0]["symptom"], "storage.flush.latency")
        incs, rows = to_incidents(meta, abn)
        self.assertEqual(incs[0]["layer"], "workload")
        self.assertEqual(incs[0]["verdict"], "CONFIRMED")
        self.assertEqual(incs[0]["atlas_candidates"][0]["card_id"], "WL-storage.flush.latency")
        self.assertEqual(card_of(abn[0]), "WL-storage.flush.latency")
        self.assertTrue(rows[0]["blocks"][0]["rows"][0].startswith("Evidence="))
        gen = {"workload": "PCMark 10 Storage", "abnormalities": [{"id": "A1", "title": "score drop", "metric": "storage.score", "observed": 800, "baseline": 1000, "delta": -200, "confidence": 0.5}]}
        meta2, abn2 = normalise(gen)
        incs2, _ = to_incidents(meta2, abn2)
        self.assertEqual(incs2[0]["verdict"], "SUSPECT")
        self.assertEqual(incs2[0]["atlas_candidates"][0]["card_id"], "WL-storage.score")


class Actions(unittest.TestCase):
    def test_new_actions_are_in_the_vocabulary(self):
        self.assertIn("restart_failed", ALL)
        self.assertIn("sweep", ALL)
        self.assertIn("sweep", available("new", False))


class PPO(unittest.TestCase):
    def test_ppo_searches_and_reports_like_the_bandit(self):
        oracle = SyntheticDeviceOracle("T-42", 0, seed=0, family="P19")
        r = PPOOptimizer(oracle, family_template_scenario("P19"), budget=60, rng_seed=0).search()
        for k in ("status", "best_scenario", "repro_k", "repro_n", "trials", "best_reward", "policy_updates"):
            self.assertIn(k, r)
        self.assertLessEqual(r["trials"], 60)


class AnswerBudget(unittest.TestCase):
    """An answer cut off at max_tokens is reported as cut off and retried once with twice the room (it was reported as
    'non-json' and the composition of test variants failed once the stored sequences grew; full suite, 2026-11-08)."""

    def test_cut_answer_is_retried_with_twice_the_room(self):
        import io
        import llm_adapter as LA
        sent = []

        class Resp(io.BytesIO):
            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False

        def fake_urlopen(req, timeout=None):
            body = json.loads(req.data.decode())
            sent.append(body["max_tokens"])
            if len(sent) == 1:
                return Resp(json.dumps({"stop_reason": "max_tokens", "content": [{"type": "text", "text": '{"variants": [{"na'}], "usage": {}}).encode())
            return Resp(json.dumps({"stop_reason": "end_turn", "content": [{"type": "text", "text": '{"variants": []}'}], "usage": {}}).encode())
        llm = LA.AnthropicLLM(backend="http")
        old_env, old_open = os.environ.get("ANTHROPIC_API_KEY"), LA.urllib.request.urlopen
        os.environ["ANTHROPIC_API_KEY"] = old_env or "test-key"
        LA.urllib.request.urlopen = fake_urlopen
        try:
            out, cached = llm.generate_json("compose something", {"type": "object", "properties": {"variants": {"type": "array"}}}, max_tokens=8000)
        finally:
            LA.urllib.request.urlopen = old_open
            if old_env is None:
                os.environ.pop("ANTHROPIC_API_KEY", None)
        self.assertEqual(out, {"variants": []})
        self.assertEqual(sent, [8000, 16000])
        self.assertEqual(llm.answer_limit(), 2000)          # the budget of one call does not leak into the next

    def test_composition_asks_for_the_larger_budget(self):
        import compose
        self.assertGreaterEqual(compose.COMPOSE_MAX_TOKENS, 8000)


if __name__ == "__main__":
    unittest.main(verbosity=1)
