"""Field-to-Test Loop - local full-stack application.

Flask app factory: registers the API blueprints (config, runs, stage 2, database, misc) and serves the two pages
(the workflow at / and the database interface at /db). Binds to 127.0.0.1 only; single admin, no authentication.
"""
import json
import os
import sys

from flask import Flask, jsonify, request, send_from_directory
from werkzeug.exceptions import HTTPException
import sqlite3

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from services import Services                       # noqa: E402
from api import agentic_api, config_api, db_api, dg_api, hier_api, isolate_api, misc_api, runs_api, stage2_api   # noqa: E402


def load_config(path):
    with open(path) as f:
        cfg = json.load(f)
    cfg["_path"] = path
    return cfg


def create_app(cfg, root):
    app = Flask("field_to_test_loop", static_folder=os.path.join(HERE, "static"), static_url_path="/static")
    # pages and scripts are checked for a newer version on every load (a 304 when unchanged), so a reload always shows
    # the newest page; without it a browser kept an old agents.js after an update (seen 2026-11-09)
    app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0
    app.config["services"] = Services(cfg, root)
    app.config["services"].app = app        # the flow's stage 1 and stage 2 call the isolation endpoints through the app itself
    app.config["JSON_SORT_KEYS"] = False
    for m in (config_api, runs_api, stage2_api, db_api, misc_api, hier_api, isolate_api, dg_api, agentic_api):
        app.register_blueprint(m.bp)
    from agentic import procedures
    procedures.use_uploads_folder(hier_api.uploads_dir(app.config["services"]))      # the application's uploads, wherever its root is

    @app.errorhandler(sqlite3.DatabaseError)
    def _database_problem(e):
        """A recording's database that is damaged or unfinished is reported in words; it never brings a page down."""
        if "locked" in str(e):
            return jsonify({"error": "the database is busy: try again in a moment"}), 503
        return jsonify({"error": "this recording's database cannot be read (%s): load the recording again" % e}), 422

    @app.errorhandler(HTTPException)
    def _http_error_as_json(e):
        """Refusals on the API are JSON with a reason, like every other answer of the API."""
        if request.path.startswith("/api/"):
            return jsonify({"error": e.description}), e.code
        return e

    @app.before_request
    def _names_in_the_address_are_sensible():
        """An id or a name in the address is short and stays inside its folder; anything else names nothing that exists."""
        if request.path.startswith("/api/"):
            for v in (request.view_args or {}).values():
                if isinstance(v, str) and (len(v) > 200 or "\x00" in v or ".." in v.split("/")):
                    return jsonify({"error": "no such item"}), 404
                if isinstance(v, int) and abs(v) >= 2 ** 63:
                    return jsonify({"error": "no such item"}), 404

    @app.before_request
    def _json_body_is_an_object():
        """Every API body is one JSON object: anything else is refused here, with a reason, instead of failing somewhere inside a route."""
        if request.method in ("POST", "PUT", "PATCH", "DELETE") and request.path.startswith("/api/") and request.content_type and "json" in request.content_type:
            raw = request.get_data(cache=True)
            if raw.strip():
                try:
                    body = json.loads(raw)
                except (ValueError, RecursionError):
                    return jsonify({"error": "the request body is not valid JSON"}), 400
                if not isinstance(body, dict):
                    return jsonify({"error": "the request body must be a JSON object"}), 400

    @app.get("/")
    def index():
        # Front page (2026-11-08, the owner's statement): ONE flow, Family 1 -> Family 2 -> Family 3, from the folder to the
        # test case. The tree pages (/hier) and the isolation tab (/isolate) open from the flow's steps.
        return send_from_directory(app.static_folder, "agents.html")

    @app.get("/packets")
    def packets_page():
        # The earlier single-CSV packet-level workflow (stage 1 / stage 2), kept as is.
        return send_from_directory(app.static_folder, "index.html")

    @app.get("/db")
    def db_page():
        return send_from_directory(app.static_folder, "db.html")

    @app.get("/defect")
    def defect_page():
        return send_from_directory(app.static_folder, "defect.html")

    @app.get("/hier")
    def hier_page():
        return send_from_directory(app.static_folder, "hier.html")

    @app.get("/isolate")
    def isolate_page():
        # the isolation tab of one defect (?upload=<upload id>&finding=<finding id>), opened by page 3 in a new browser tab
        return send_from_directory(app.static_folder, "isolate.html")

    @app.get("/agents")
    def agents_page():
        # the agent families (2026-11-08): start page, Families 1 and 2, the review inbox, the rules page with its sections
        return send_from_directory(app.static_folder, "agents.html")

    @app.get("/how")
    def how_page():
        # the interactive guide to the whole application (also readable as a file: docs/HOW_THE_APP_WORKS.html)
        return send_from_directory(os.path.join(os.path.dirname(HERE), "docs"), "HOW_THE_APP_WORKS.html")

    @app.after_request
    def no_cache(resp):
        if resp.mimetype in ("text/html", "application/javascript", "text/css"):
            resp.headers["Cache-Control"] = "no-store"
        return resp
    return app
