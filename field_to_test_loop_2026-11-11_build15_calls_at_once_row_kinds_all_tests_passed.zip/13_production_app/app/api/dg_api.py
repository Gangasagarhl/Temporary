"""The procedural graph of defects, causes and solutions (nvme_hier/defect_graph.py), for the flow's stage 2 and the page.

  GET  /api/dg/defects?rule=            the stored defects (those of this rule first)
  GET  /api/dg/defects/<id>             one defect with its causes and their solutions, ranked
  POST /api/dg/defects                  store a defect under its standard name (an existing name is returned, never copied)
  POST /api/dg/causes                   store a cause under a defect
  POST /api/dg/occurrences              one occurrence of a defect with the cause the admin named (device and firmware kept with it)
  POST /api/dg/solutions                store a solution: the error sequence and the optimized sequence
  POST /api/dg/solutions/<id>/verdict   one of the four signals on a stored solution
  POST /api/dg/optimized                the model proposes the optimized sequence (the admin edits it before it is stored)
"""
import os
import sys

from flask import Blueprint, jsonify, request

from . import svc, as_text, a_dict

APP = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if APP not in sys.path:
    sys.path.insert(0, APP)
from nvme_hier import defect_graph as DG   # noqa: E402
from nvme_hier import isolate as ISO       # noqa: E402

bp = Blueprint("dg", __name__)


def graph(s):
    if not hasattr(s, "defect_graph"):
        s.defect_graph = DG.DefectGraph(os.path.join(s.root, "db", "hier_knowledge.sqlite"))
    return s.defect_graph


def _admin(body):
    a = as_text(body.get("admin"), "admin").strip()
    if not a:
        raise ValueError("say who you are (your name) first")
    return a


def _int(v, what):
    try:
        x = int(v)
    except (TypeError, ValueError, OverflowError):
        raise ValueError("%s must be a whole number" % what)
    if not -(1 << 63) <= x < (1 << 63):          # SQLite holds 64-bit numbers (parameter fuzz, 2026-11-11)
        raise ValueError("%s is too large" % what)
    return x


@bp.errorhandler(ValueError)
def _bad(e):
    return jsonify({"error": str(e)}), 400


@bp.get("/api/dg/defects")
def defects():
    term = request.args.get("term")
    if term:                         # one defect by its fixed term: is it in the procedural graph?
        d = graph(svc()).find_defect(term_key=term)
        return jsonify({"defect": graph(svc()).view(d["id"]) if d else None})
    return jsonify({"defects": graph(svc()).defects(request.args.get("rule"))})


@bp.get("/api/dg/terms")
def term_list():
    """The fixed cause keywords (the dictionary), for the page."""
    from nvme_hier import terms as TM
    return jsonify({"version": TM.VERSION, "causes": TM.cause_choices()})


@bp.get("/api/dg/defects/<int:did>")
def defect(did):
    v = graph(svc()).view(did)
    if v is None:
        return jsonify({"error": "no such defect"}), 404
    return jsonify(v)


@bp.post("/api/dg/defects")
def add_defect():
    b = request.get_json(force=True) or {}
    did, created = graph(svc()).add_defect(as_text(b.get("name"), "name"), b.get("rule"), b.get("level"), as_text(b.get("what"), "what"), _admin(b),
                                           term_key=as_text(b.get("term_key"), "term_key") or None)
    return jsonify({"id": did, "created": created})


@bp.post("/api/dg/causes")
def add_cause():
    b = request.get_json(force=True) or {}
    g = graph(svc())
    did = _int(b.get("defect_id"), "defect_id")
    if g.defect(did) is None:
        return jsonify({"error": "no such defect"}), 404
    kw = as_text(b.get("keyword"), "keyword")
    if kw:                           # a fixed keyword of the dictionary: its side and words come from it, never typed
        from nvme_hier import terms as TM
        c = TM.cause_of(kw)
        if c is None:
            return jsonify({"error": "not a keyword of the dictionary: %s" % kw}), 400
        cid, created = g.add_cause(did, c["side"], c["name"], _admin(b), keyword=kw)
    else:
        cid, created = g.add_cause(did, as_text(b.get("side"), "side"), as_text(b.get("header"), "header"), _admin(b))
    return jsonify({"id": cid, "created": created})


@bp.post("/api/dg/occurrences")
def add_occurrence():
    b = request.get_json(force=True) or {}
    g = graph(svc())
    did = _int(b.get("defect_id"), "defect_id")
    cid = _int(b.get("cause_id"), "cause_id") if b.get("cause_id") not in (None, "") else None
    if g.defect(did) is None or (cid and (g.cause(cid) or {}).get("defect_id") != did):
        return jsonify({"error": "no such defect, or the cause is not one of its causes"}), 404
    oid = g.record_occurrence(did, cid, as_text(b.get("upload_id"), "upload_id"), _int(b.get("finding_id"), "finding_id"), b.get("device"), b.get("firmware"),
                              a_dict(b.get("isolation"), "isolation"), _admin(b))
    return jsonify({"id": oid})


@bp.post("/api/dg/solutions")
def add_solution():
    b = request.get_json(force=True) or {}
    g = graph(svc())
    cid = _int(b.get("cause_id"), "cause_id")
    if g.cause(cid) is None:
        return jsonify({"error": "no such cause"}), 404
    admin = _admin(b)
    sid, rid = g.add_solution(cid, b.get("error_seq"), b.get("optimized"), as_text(b.get("note"), "note"), b.get("producer") or "admin:%s" % admin, admin,
                              b.get("upload_id"), b.get("finding_id"))
    return jsonify({"id": sid, "revision_id": rid, "solution": g.solution(sid)})


@bp.post("/api/dg/solutions/<int:sid>/verdict")
def verdict(sid):
    b = request.get_json(force=True) or {}
    r = graph(svc()).verdict(sid, as_text(b.get("signal"), "signal"), _admin(b), b.get("occurrence_id"), b.get("device"), b.get("firmware"),
                             b.get("error_seq"), b.get("optimized"), b.get("note"))
    return jsonify(r)


@bp.post("/api/dg/optimized")
def optimized():
    """The model's proposal of the optimized sequence; nothing is stored here."""
    from .isolate_api import _llm, _load, _ok_upload
    from .isolate_api import _as_job, _progress
    s = svc()
    b = request.get_json(force=True) or {}
    if request.args.get("job") == "1":
        return _as_job(b)
    uid, fid = as_text(b.get("upload_id"), "upload_id"), _int(b.get("finding_id"), "finding_id")
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    ctx = _load(s, uid, fid)
    if ctx is None:
        return jsonify({"error": "no such finding"}), 404
    prompt = ISO.optimized_prompt(ctx["f"], ctx["device"], a_dict(b.get("isolation"), "isolation"), a_dict(b.get("cause"), "cause"), b.get("error_seq") or [])
    _progress(b, 20, "the model proposes the optimized sequence for this cause")
    ans, producer = ISO.call_model(_llm(s, b), prompt, ISO.OPTIMIZED_SCHEMA, "lines")
    if ans is None:
        return jsonify({"lines": [], "note": "No model answered: write the optimized sequence yourself, one action per line.", "producer": producer, "standin": True})
    return jsonify({"lines": DG.clean_lines(ans.get("lines")), "note": " ".join(str(ans.get("note") or "").split()), "producer": producer, "standin": False})


@bp.post("/api/dg/revisions/<int:rid>/test")
def revision_test(rid):
    """The approved test file of one version of a solution (stage 3)."""
    b = request.get_json(force=True) or {}
    path = as_text(b.get("path"), "path")
    if not path or not os.path.exists(path):
        return jsonify({"error": "no such test file"}), 400
    graph(svc()).set_test_path(rid, path)
    return jsonify({"ok": True})


@bp.get("/api/dg/status")
def status():
    """Where each error of one recording stands in the procedural graph (the errors page shows it)."""
    up = request.args.get("upload") or ""
    try:
        ids = [_int(x, "findings") for x in (request.args.get("findings") or "").split(",") if x.strip()][:500]
    except ValueError:
        return jsonify({"error": "findings must be whole numbers, separated by commas"}), 400
    return jsonify({"status": graph(svc()).status(up, ids)})


@bp.post("/api/dg/term_requests")
def term_request():
    """A note to the dictionary's keeper: "this is not the same kind of defect" (the name stays as the code made it until the dictionary changes)."""
    import json as _json
    import time as _time
    b = request.get_json(force=True) or {}
    note = as_text(b.get("note"), "note").strip()
    if not note:
        return jsonify({"error": "write the note"}), 400
    rec = {"at": _time.time(), "admin": _admin(b), "term_key": as_text(b.get("term_key"), "term_key"), "term_name": as_text(b.get("term_name"), "term_name"),
           "note": note[:2000], "upload_id": as_text(b.get("upload_id"), "upload_id"), "finding_id": b.get("finding_id")}
    d = os.path.join(svc().root, "knowledge", "dictionary")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "term_requests.jsonl"), "a", encoding="utf-8") as fh:
        fh.write(_json.dumps(rec) + "\n")
    return jsonify({"ok": True})
