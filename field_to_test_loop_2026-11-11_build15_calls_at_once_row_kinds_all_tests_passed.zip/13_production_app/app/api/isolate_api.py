"""The isolation tab (owner's statement of 2026-11-03, parts 4 to 8): one defect of one command, opened by page 3 in
a new browser tab at /isolate?upload=<upload id>&finding=<finding id>.

Endpoints (all under /api/isolate/<upload>/<finding>):
  GET  /                 the header: the defect in words, the chain, the catalogue, the device, the memory, the chat history
  GET  /window           n commands above, the command, m below; under each the ticked lower levels (first 50 rows per level, with counts)
  POST /chat             the stateful chat: {message, context: {rows: [{level, rowid}], include_defect, include_catalogue, include_memory}, name?}
  GET  /memory           the signature memory: seen before, on this device, on other devices, the stored facts, the retrieval context
  POST /isolate          the evidence loop: {n, m, levels, name?, hint?, queue?, anyway?} -> reason, cited rows, optimised sequence, rounds
  POST /signal           one of the four signals on the seed or a stored procedure (+ scenario name + reason); POST /reorder the admin's order
  POST /testcase         {sequence, expected_after: n} -> the expected outcomes to verify; with expected_outcomes + verified -> the test file
  POST /summary          the summary (who, what, when, where, why, how; at most 100 words), stored with the signature
No admin name is required: the actor recorded is the device name unless a name is typed in the optional field.
Every model call works without a model (the stand-in from nvme_hier/isolate.py); ?standin=1 or body.standin forces it.
"""
import copy
import json
import os
import sqlite3
import sys
import time

from flask import Blueprint, jsonify, request

from . import svc, whole, NM, as_text, a_dict, dicts, wholes
from .hier_api import (_window, _chain, _below, _finding, _row, _summary, _signature_of, knowledge, upload_dir, db_of, read_meta,
                       current_app_ctx, TABLE, LEVELS)

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
from nvme_hier import chat as CH, isolate as ISO, optimise as OPT, parse as P, rules as RL, store as ST, testcase as TC   # noqa: E402
from nvme_hier import loader as L   # noqa: E402
from nvme_hier import slice as SL   # noqa: E402
from nvme_hier import testplan as TP   # noqa: E402

bp = Blueprint("isolate", __name__)

# ---------------------------------------------------------------------------------------------- long requests as background jobs
# (owner, 2026-11-11: "if it is streamed ... the 50% done, 20% done ... what's going on at the back end ... the sound after completing")
# A request with ?job=1 answers at once with a job id; the same request runs in the background and reports how far it is and what it does;
# GET /api/isolate/jobs/<id> follows it, and gives the answer when it is done.
import threading as _threading   # noqa: E402
import uuid as _uuid             # noqa: E402

_JOBS = {}
_JLOCK = _threading.Lock()


def _progress(body, pct, text):
    if body is None:                     # deep inside a request: its own body says which job it is
        try:
            body = request.get_json(silent=True) or {}
        except RuntimeError:
            body = {}
    j = _JOBS.get((body or {}).get("_job") or "")
    if j is not None:
        j["pct"] = max(j["pct"], int(pct))
        j["text"] = text
        j["log"].append({"s": round(time.time() - j["t0"], 1), "pct": j["pct"], "text": text})


def _as_job(body):
    app = __import__("flask").current_app._get_current_object()
    jid = _uuid.uuid4().hex[:12]
    job = {"state": "running", "pct": 1, "text": "starting", "t0": time.time(), "log": [], "result": None, "error": None}
    with _JLOCK:
        for k in sorted(_JOBS, key=lambda k: _JOBS[k]["t0"])[:-40]:
            _JOBS.pop(k, None)
        _JOBS[jid] = job
    path, qs = request.path, "&".join("%s=%s" % (k, v) for k, v in request.args.items() if k != "job")
    b = dict(body or {}, _job=jid)

    def run():
        try:
            with app.test_client() as c:
                r = c.post(path + ("?" + qs if qs else ""), json=b)
            j = r.get_json(silent=True)
            if r.status_code >= 400:
                job.update(state="error", error=(j or {}).get("error") if isinstance(j, dict) else str(r.status_code))
            else:
                job.update(state="done", pct=100, text="done", result=j)
        except Exception as e:          # noqa: BLE001 - the page shows it
            job.update(state="error", error=str(e))
    _threading.Thread(target=run, daemon=True, name="isolate-job-" + jid).start()
    return jsonify({"job": jid})


@bp.get("/api/isolate/jobs/<jid>")
def job_state(jid):
    j = _JOBS.get(jid)
    if j is None:
        return jsonify({"error": "no such job (the server may have restarted)"}), 404
    out = {k: j[k] for k in ("state", "pct", "text", "error")}
    out["seconds"] = round(time.time() - j["t0"], 1)
    out["log"] = j["log"][:200]          # a job writes a few dozen lines at most; the page appends the new ones
    if j["state"] == "done":
        out["result"] = j["result"]
    return jsonify(out)
PER_LEVEL = 50
MAX_CONTEXT_ROWS = 400
LABEL = ISO.LEVEL_LABEL


# ---------------------------------------------------------------------------------------------- shared pieces
def _catalogue(f):
    cat = RL.Catalogue()
    ref = f.get("cat_ref")
    entry = None
    if ref:
        entry = cat.by_id.get(ref) or cat.by_name.get(str(ref).lower()) or cat.silent.get(str(ref).lower())
        if entry is None:
            for e in cat.by_status.values():
                if e.get("error") == ref:
                    entry = e
                    break
    b = RL.brief(entry)
    if b and not b.get("meaning"):
        # a status-code entry has no meaning text of its own: its rule description and the specification section say what it is
        b["meaning"] = ((entry.get("rule") or {}).get("description") if isinstance(entry.get("rule"), dict) else None) or \
                       ("the drive answered with the status '%s'" % entry.get("error"))
    return b


def _load(s, uid, fid):
    """The finding with its chain, catalogue, command, cause and signature; the metadata; the device name."""
    with current_app_ctx(s, uid) as (d, meta, con):
        f = _finding(con, fid)
        if f is None:
            return None
        f["level_label"] = LABEL.get(f["level"], f["level"])
        f["rule_words"] = ISO.rule_in_words(f)
        f["basis"] = RL.basis(f.get("rule"))
        f["catalogue"] = _catalogue(f)
        f["chain"] = [{k: v for k, v in c.items() if k != "row"} for c in _chain(con, f["level"], f["rowid"])]
        cmd_row = _row(con, "nvme_command", f["cmd_rowid"]) if f.get("cmd_rowid") else None
        f["command"] = {"rowid": f["cmd_rowid"], "n": cmd_row.get("n"), "summary": _summary("nvme_command", cmd_row),
                        "parameters": {k: cmd_row.get(k) for k in ("nsid", "slba", "nlb", "fua", "nbytes") if cmd_row.get(k) is not None},
                        "duration": cmd_row.get("dur_ps_text"), "status": _status_words(cmd_row)} if cmd_row else None
        cause = _finding(con, f["cause_finding"]) if f.get("cause_finding") else None
        f["cause"] = {k: cause.get(k) for k in ("id", "level", "rule", "name", "value_ps_text", "limit_ps_text")} if cause else None
        sig = _signature_of(con, meta, f, cmd_row)
        f["signature"] = {k: sig.get(k) for k in ("fine", "coarse", "display", "fields", "device", "firmware")}
        f["signature"]["family"] = sig["coarse"]
        f["levels_present"] = L.get_meta(con, "levels_present", [])
        f["observed_outcome"] = CH.observed_outcome(f)
        f["expected_outcome_default"] = CH.expected_outcome_default(f)
        device = (meta.get("device") or "").strip() or sig.get("device") or "unknown device"
        return {"f": f, "sig": sig, "cmd_row": cmd_row, "meta": meta, "device": device}


def _status_words(r):
    if not r or r.get("sct") is None:
        return None
    if r.get("sct") == 0 and r.get("sc") == 0:
        return "success"
    raw = r.get("raw") or {}
    txt = (raw.get("ST") or raw.get("Cpl Status") or "").strip()
    return txt or ("status type %s code %s" % (r.get("sct"), r.get("sc")))


def _actor(body, ctx):
    name = (as_text((body or {}).get("name"), "name") or request.args.get("name") or "").strip()
    return name or ctx["device"]


def _llm(s, body):
    """The configured model with the isolation system text, or None for the stand-in (also when asked for)."""
    if (body or {}).get("standin") or request.args.get("standin") == "1":
        return None
    llm = getattr(getattr(s, "s2", None), "llm", None)
    if not ISO.is_model(llm):
        return None
    if hasattr(llm, "system"):
        llm = copy.copy(llm)
        llm.system = ISO.SYSTEM
    return llm


def _findings_of(con, level, rowid):
    return [dict(x) for x in con.execute("SELECT id, rule, name, severity FROM finding WHERE level=? AND rowid=?", (level, rowid))]


def _evidence_row(con, level, row, position=None, command=None):
    """The row shape the page and the prompts use: level, row number, summary, time, gap, duration, findings."""
    raw = row.get("raw") or {}
    out = {"level": level, "label": LABEL[level], "rowid": row["rowid_file"], "n": row.get("n"), "summary": _summary(level, row),
           "t": raw.get("Time Stamp"), "gap": row.get("delta_ps_text") or (P.fmt_ps(row["delta_ps"]) if row.get("delta_ps") is not None else ""),
           "dur": row.get("dur_ps_text") or (P.fmt_ps(row["dur_ps"]) if row.get("dur_ps") is not None else ""), "dur_ps": row.get("dur_ps"), "t_ps": row.get("t_ps"),
           "findings": _findings_of(con, level, row["rowid_file"]), "relation": row.get("relation"), "position": position,
           "errors": row.get("errors") or "", "status": _status_words(row) if level in ("nvme_command", "nvme_transaction") else (row.get("cpl_status") or None)}
    if level == "nvme_command":
        out["parameters"] = {k: row.get(k) for k in ("nsid", "slba", "nlb", "fua", "nbytes") if row.get(k) is not None}
        out["queue"], out["cid"], out["opc"], out["sqid"] = row.get("sqid"), row.get("cid"), row.get("opc"), row.get("sqid")
    if command:
        out["command_rowid"], out["command_n"] = command.get("rowid"), command.get("n")
    if row.get("parent") is not None:
        out["parent_level"], out["parent_rowid"] = row.get("parent_level"), row.get("parent")
    return out


def _parents(con, level, ids):
    """Row numbers (n) of the parents of lower-level rows, for 'the packets of link 21837'."""
    out = {}
    if not ids:
        return out
    for lv in set(level for level, _ in ids):
        rids = [rid for l2, rid in ids if l2 == lv]
        for r in con.execute("SELECT rowid_file, n FROM %s WHERE rowid_file IN (%s)" % (TABLE[lv], ",".join("?" * len(rids))), rids):
            out[(lv, r[0])] = r[1]
    return out


UNDER_SQL = {
    "nvme_transaction": "parent_level='nvme_command' AND parent=?",
    "split": "parent_level='nvme_transaction' AND parent IN (SELECT rowid_file FROM ntx WHERE parent_level='nvme_command' AND parent=?)",
    "link": "(parent_level='nvme_transaction' AND parent IN (SELECT rowid_file FROM ntx WHERE parent_level='nvme_command' AND parent=?)) OR "
            "(parent_level='split' AND parent IN (SELECT rowid_file FROM spl WHERE parent_level='nvme_transaction' AND parent IN (SELECT rowid_file FROM ntx WHERE parent_level='nvme_command' AND parent=?)))",
    "packets": "(parent_level='link' AND parent IN (SELECT rowid_file FROM lnk WHERE (parent_level='nvme_transaction' AND parent IN (SELECT rowid_file FROM ntx WHERE parent_level='nvme_command' AND parent=?)) OR "
               "(parent_level='split' AND parent IN (SELECT rowid_file FROM spl WHERE parent_level='nvme_transaction' AND parent IN (SELECT rowid_file FROM ntx WHERE parent_level='nvme_command' AND parent=?))))) OR "
               "(parent_level='nvme_command' AND parent=?)",
}


def _under(con, cmd, levels, per_level=PER_LEVEL, present=None):
    """The rows of the ticked lower levels under one command (bounded: the first per_level rows per level, member rows first, with the count)."""
    out = {}
    tables = present or [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")]
    for lv in levels:
        if lv not in UNDER_SQL or TABLE[lv] not in tables:
            continue
        where = UNDER_SQL[lv]
        args = [cmd["rowid"]] * where.count("?")
        total = con.execute("SELECT COUNT(*) FROM %s WHERE %s" % (TABLE[lv], where), args).fetchone()[0]
        rows = []
        for r in con.execute("SELECT * FROM %s WHERE %s ORDER BY (relation='context'), rowid_file LIMIT ?" % (TABLE[lv], where), args + [per_level]):
            row = dict(r)
            row["raw"] = json.loads(row["raw"]) if isinstance(row.get("raw"), str) else (row.get("raw") or {})
            for k in ("t_ps", "delta_ps", "dur_ps"):
                if row.get(k) is not None:
                    row[k + "_text"] = P.fmt_ps(row[k])
            rows.append(_evidence_row(con, lv, row, command=cmd))
        pn = _parents(con, lv, [(x["parent_level"], x["parent_rowid"]) for x in rows if x.get("parent_rowid") is not None and x.get("parent_level") in TABLE])
        for x in rows:
            if x.get("parent_rowid") is not None:
                x["parent_n"] = pn.get((x.get("parent_level"), x["parent_rowid"]))
        out[lv] = {"rows": rows, "count": total, "shown": len(rows), "label": LABEL[lv]}
    return out


def _levels_arg(v):
    want = v if isinstance(v, list) else [x.strip() for x in as_text(v, "levels").split(",") if x.strip()]
    return [lv for lv in ISO.LOWER_LEVELS if lv in want]


MAX_PER_LEVEL = 5000
DEFAULT_N, DEFAULT_M = 15, 15        # owner, 2026-11-11: 15 NVMe commands above the error's command and 15 below, 31 in all, with every lower level


# the admin's window, remembered per kind of defect (owner, 2026-11-10: "the admin will keep on looking at it, and he might change the values of n");
# the next defect of the same kind starts from the numbers the admin chose last time. A starting point only, never a rule.
def _window_memory_path(s):
    return os.path.join(s.root, "db", "isolation_windows.json")


def window_memory(s):
    try:
        with open(_window_memory_path(s), encoding="utf-8") as fh:
            d = json.load(fh)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def remember_window(s, sig_fine, n, m, who, uid, fid):
    d = window_memory(s)
    hist = (d.get(sig_fine) or {}).get("history") or []
    d[sig_fine] = {"n": n, "m": m, "by": who, "at": time.time(), "upload_id": uid, "finding": fid,
                   "history": (hist + [{"n": n, "m": m, "by": who, "at": time.time(), "upload_id": uid, "finding": fid}])[-50:]}
    os.makedirs(os.path.dirname(_window_memory_path(s)), exist_ok=True)
    L.write_json_atomic(_window_memory_path(s), d, indent=1)


def _window_numbers(s, body, sig_fine):
    """(n, m, where the numbers come from): the admin's numbers when given, else the ones chosen last time for this kind of defect, else 15 / 15."""
    was = window_memory(s).get(sig_fine) or {}
    given = body.get("n") not in (None, ""), body.get("m") not in (None, "")
    n = whole(body.get("n") if given[0] else was.get("n", DEFAULT_N), message=NM)
    m = whole(body.get("m") if given[1] else was.get("m", DEFAULT_M), message=NM)
    if given[0] or given[1]:
        src = "set by the admin for this look"
    elif was:
        src = "the numbers %s chose for this kind of defect on %s" % (was.get("by") or "the admin", time.strftime("%Y-%m-%d", time.localtime(was.get("at") or 0)))
    else:
        src = "the default (15 above, 15 below)"
    return max(0, min(n, ISO.MAX_ABOVE)), max(0, min(m, 100)), src


def _with_history(s, uid, w):
    """The commands from earlier in the recording that the failing command depends on (nvme_hier/slice.py), put in front of the window as
    rows above it, each with its reason. Returns the slice report."""
    with current_app_ctx(s, uid) as (d, meta, con):
        first = min(r["rowid_file"] for r in w["rows"])
        fault = next(r for r in w["rows"] if r["position"] == "fault")
        hist, report = SL.history(con, fault, first)
        ev = []
        for r in hist:
            for k in ("t_ps", "delta_ps", "dur_ps"):
                if r.get(k) is not None:
                    r[k + "_text"] = P.fmt_ps(r[k])
            r.update(position="above", from_history=True, summary=_summary("nvme_command", r),
                     findings=[dict(x) for x in con.execute("SELECT id, rule, name, severity FROM finding WHERE level='nvme_command' AND rowid=?", (r["rowid_file"],))])
            er = _evidence_row(con, "nvme_command", r, position="above")
            er.update(history_why=r["history_why"], from_history=True, under={})
            ev.append(er)
    w["rows"] = hist + w["rows"]
    w["commands"] = ev + w["commands"]
    report["rows"] = [{"rowid": r["rowid_file"], "n": r.get("n"), "summary": r["summary"], "why": r["history_why"]} for r in hist]
    return report


def window_counts(w):
    """What the window holds, per level: the commands, and the rows under them (all of them, counted, not only those shown)."""
    out = {"commands": len(w.get("commands") or []), "from_history": sum(1 for c in w.get("commands") or [] if c.get("from_history"))}
    for c in w.get("commands") or []:
        for lv, blk in (c.get("under") or {}).items():
            out[lv] = out.get(lv, 0) + (blk.get("count") or 0)
    return out


def _window_rows(s, uid, fid, n, m, same_queue, levels, per_level=PER_LEVEL):
    """The command-level window (hier_api._window) with the ticked lower levels under every command.
    per_level: how many rows of each ticked level to bring to the screen under one command (member rows first, then
    context rows); the count of all of them is always reported, so nothing is hidden silently."""
    per_level = max(1, min(int(per_level or PER_LEVEL), MAX_PER_LEVEL))
    w = _window(s, uid, fid, "nvme_command", n, m, same_queue)
    if w is None:
        return None
    with current_app_ctx(s, uid) as (d, meta, con):
        tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        cmds = []
        for r in w["rows"]:
            er = _evidence_row(con, "nvme_command", r, position=r["position"])
            er["gap"] = r.get("gap_text") or ""          # in a command window the gap is to the previous command of the window
            er["time_delta"] = r.get("delta_ps_text") or ""
            er["under"] = _under(con, er, levels, per_level=per_level, present=tables) if levels else {}
            cmds.append(er)
        f = _finding(con, fid)
        below_defect = _below(con, f["level"], f["rowid"], per_level=per_level) if f and f["level"] != "nvme_command" else []
    w["commands"] = cmds
    w["levels"] = levels
    w["per_level"] = per_level
    w["defect_below"] = [{"under": b["under"], "under_label": b["under_label"], "counts": b["counts"],
                          "rows": [{k: v for k, v in r.items() if k != "row"} for r in b["rows"]]} for b in below_defect]
    return w


def _ok_upload(s, uid):
    d = upload_dir(s, uid)
    return bool(d and os.path.exists(db_of(d)))


def _memory(s, ctx, uid):
    """Seen before? on this device? on other devices? plus the stored facts and the retrieval context."""
    st = knowledge(s)
    sig = ctx["sig"]
    st.touch_signature(sig, ctx["device"], upload_id=uid, finding_id=ctx["f"]["id"])
    st.set_device(sig["fine"], ctx["device"], sig.get("firmware"))
    know = st.lookup(sig)
    sightings = st.sightings(sig["fine"])
    other_uploads = sorted({x["upload_id"] for x in sightings if x["upload_id"] != uid})
    facts = st.retrieve(sig, ctx["device"])
    fam = [x for x in facts if x["tier"] >= 2]
    other_devices = sorted({(x.get("device") or "unknown") for x in fam if (x.get("device") or "").strip().upper() != ctx["device"].strip().upper()})
    exact = next((x for x in facts if x["tier"] == 1), None)
    seen_before = bool(other_uploads) or bool(know.get("exact")) or bool(know.get("reason")) or bool(know.get("summary"))
    return {"signature": ctx["f"]["signature"], "seen": know.get("seen"), "seen_before": seen_before,
            "seen_before_text": ("seen before: yes, in %d earlier upload%s of this device" % (len(other_uploads), "" if len(other_uploads) == 1 else "s")) if other_uploads
            else ("seen before: yes (facts are stored for it)" if seen_before else "seen before: no, this is the first time this exact defect is recorded on this device"),
            "on_this_device": seen_before, "on_other_devices": other_devices,
            "on_other_devices_text": ("the same kind of defect was seen on %s" % ", ".join(other_devices)) if other_devices else "the same kind of defect has not been seen on another device",
            "exact": exact, "family": fam, "retrieval": facts, "stored": know, "device": ctx["device"]}


# ---------------------------------------------------------------------------------------------- endpoints
@bp.get("/api/isolate/<uid>/<int:fid>")
def header(uid, fid):
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    ctx = _load(s, uid, fid)
    if ctx is None:
        return jsonify({"error": "no such finding"}), 404
    st = knowledge(s)
    mem = _memory(s, ctx, uid)
    llm = getattr(getattr(s, "s2", None), "llm", None)
    f = ctx["f"]
    th = (ctx["meta"].get("thresholds") or {})
    return jsonify({"upload": uid, "finding": f, "device": ctx["device"], "trace_name": ctx["meta"].get("trace_name"), "recording_date": ctx["meta"].get("recording_date"),
                    "memory": mem, "history": st.chat_history(uid, fid), "stored": mem["stored"],
                    "model": {"available": ISO.is_model(llm), "name": getattr(llm, "name", "stand-in") if llm else "stand-in"},
                    "limits": {"command_limit_text": _cmd_limit(ctx)[1], "command_limit_source": _cmd_limit(ctx)[2], "thresholds": th},
                    "bounds": {"max_rounds": ISO.MAX_ROUNDS, "max_above": ISO.MAX_ABOVE, "step_above": ISO.STEP_ABOVE, "per_level": PER_LEVEL, "history_turns": ISO.HISTORY_TURNS}})


def _cmd_limit(ctx):
    """(limit in microseconds, text, source) for the command level: the finding's own limit, else the admin's command limit, else the default."""
    f, meta, cmd = ctx["f"], ctx["meta"], ctx.get("cmd_row") or {}
    if f.get("limit_ps") and f.get("level") == "nvme_command":
        return f["limit_ps"] // 10 ** 6, f.get("limit_ps_text"), f.get("limit_source") or "the finding's limit"
    th = (meta.get("thresholds") or {}).get("nvme_command")
    if th and th.get("ps"):
        return th["ps"] // 10 ** 6, P.fmt_ps(th["ps"]), th.get("source") or "set by the admin"
    key = "nvme_command_admin" if cmd.get("sqid") == 0 else "nvme_command"
    d = RL.DEFAULT_LIMITS[key]
    return d["ps"] // 10 ** 6, P.fmt_ps(d["ps"]), d["source"]


@bp.get("/api/isolate/<uid>/<int:fid>/window")
def window(uid, fid):
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    try:
        n, m = max(0, min(whole(request.args.get("n") or 10, message=NM), ISO.MAX_ABOVE)), max(0, min(whole(request.args.get("m") or 10, message=NM), 100))
    except ValueError:
        return jsonify({"error": "n and m must be whole numbers"}), 400
    levels = _levels_arg(request.args.get("levels"))
    same_queue = request.args.get("queue", "all") == "same"
    try:
        per_level = max(1, min(whole(request.args.get("per") or PER_LEVEL, "per"), MAX_PER_LEVEL))
    except ValueError:
        return jsonify({"error": "per must be a whole number"}), 400
    try:
        w = _window_rows(s, uid, fid, n, m, same_queue, levels, per_level=per_level)
    except FileNotFoundError:
        return jsonify({"error": "no such upload"}), 404
    if w is None:
        return jsonify({"error": "no NVMe command can be placed around this finding"}), 400
    w.pop("rows", None)
    return jsonify(w)


def _context_rows(con, items):
    """The rows the admin ticked for the prompt, as evidence rows (bounded)."""
    rows, problems = [], []
    for it in (items or [])[:MAX_CONTEXT_ROWS]:
        lv, rid = (it or {}).get("level"), (it or {}).get("rowid")
        if not isinstance(lv, str) or lv not in LEVELS or not isinstance(rid, int) or abs(rid) >= 2 ** 63:
            problems.append("row %s at level %s was not understood" % (rid, lv))
            continue
        r = _row(con, lv, rid)
        if r is None:
            problems.append("no %s with row id %s" % (LABEL.get(lv, lv), rid))
            continue
        cmd = None
        if lv != "nvme_command":
            top = _chain(con, lv, rid)
            c = next((c for c in top if c["level"] == "nvme_command"), None)
            cmd = {"rowid": c["rowid"], "n": c["n"]} if c else None
        er = _evidence_row(con, lv, r, command=cmd)
        rows.append(er)
    pn = _parents(con, "link", [(x["parent_level"], x["parent_rowid"]) for x in rows if x.get("level") == "packets" and x.get("parent_level") == "link" and x.get("parent_rowid") is not None]) if rows else {}
    for x in rows:
        if x.get("level") == "packets" and x.get("parent_rowid") is not None:
            x["parent_n"] = pn.get(("link", x["parent_rowid"]))
    return rows, problems


@bp.post("/api/isolate/<uid>/<int:fid>/chat")
def chat(uid, fid):
    """Option 1: the stateful chat. The whole history (last 20 entries) and the selected context go to the model every time."""
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    message = as_text(body.get("message"), "message").strip()
    if not message:
        return jsonify({"error": "type a message first"}), 400
    ctx = _load(s, uid, fid)
    if ctx is None:
        return jsonify({"error": "no such finding"}), 404
    f, sig = ctx["f"], ctx["sig"]
    c = a_dict(body.get("context"), "context")
    with current_app_ctx(s, uid) as (d, meta, con):
        rows, problems = _context_rows(con, dicts(c.get("rows"), "the rows of the context"))
    st = knowledge(s)
    facts = st.retrieve(sig, ctx["device"]) if c.get("include_memory", True) else []
    history = st.chat_history(uid, fid)
    ctext = ISO.context_text(rows)
    actor = _actor(body, ctx)
    prompt = ISO.chat_prompt(f, ctx["device"], facts, rows, history, message, include_defect=c.get("include_defect", True),
                             include_catalogue=c.get("include_catalogue", True), include_memory=c.get("include_memory", True))
    st.chat_append(uid, fid, sig["fine"], "admin:" + actor, message, {"context": ctext, "rows": len(rows), "problems": problems})
    llm = _llm(s, body)
    ans, producer = ISO.call_model(llm, prompt, ISO.CHAT_SCHEMA, "answer")
    standin = ans is None
    if ans is None:
        w = _window(s, uid, fid, "nvme_command", 10, 10, False) or {"rows": []}
        ans = ISO.standin_chat(f, ctx["device"], rows, message, OPT.optimise(w["rows"]), facts)
    # code checks: cited rows must be in the selected context; a proposed sequence may only name commands of the context or the fault
    idx = {(r["level"], r["rowid"]): r for r in rows}
    ans["cited_rows"], cite_problems = ISO.check_cited(ans.get("cited_rows") or [], idx)
    ans["checks"] = {"ok": not cite_problems, "problems": cite_problems + problems}
    ans["producer"] = producer
    ans["standin"] = standin
    ans["prompt_chars"] = len(prompt)
    st.chat_append(uid, fid, sig["fine"], producer, ans.get("answer") or "", {k: v for k, v in ans.items() if k != "answer"})
    if ans.get("scenario_name") and not st.lookup(sig).get("scenario_name"):
        st.set_scenario_name(sig["fine"], ans["scenario_name"], producer)
    out = {"answer": ans, "history": st.chat_history(uid, fid), "context_text": ctext, "context_rows": len(rows), "prompt_chars": len(prompt),
           "producer": producer, "standin": standin, "actor": actor}
    if request.args.get("debug") == "1":
        out["debug"] = {"prompt": prompt}
    return jsonify(out)


@bp.get("/api/isolate/<uid>/<int:fid>/memory")
def memory(uid, fid):
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    ctx = _load(s, uid, fid)
    if ctx is None:
        return jsonify({"error": "no such finding"}), 404
    return jsonify(_memory(s, ctx, uid))


@bp.post("/api/isolate/<uid>/<int:fid>/isolate")
def isolate(uid, fid):
    """Part 7, the evidence loop. The deterministic optimiser runs first; the model refines, asks for more evidence
    (the next 20 commands above, the lower levels of the suspect commands) at most 5 times, and every round is logged."""
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    if request.args.get("job") == "1":
        return _as_job(body)
    ctx = _load(s, uid, fid)
    if ctx is None:
        return jsonify({"error": "no such finding"}), 404
    f, sig = ctx["f"], ctx["sig"]
    _progress(body, 3, "reading the error and its command")
    st = knowledge(s)
    st.touch_signature(sig, ctx["device"], upload_id=uid, finding_id=f["id"])       # the graph needs its failure node before the first signal
    know = st.lookup(sig)
    if know.get("exact") and not body.get("anyway"):
        return jsonify({"error": "this defect is already stored (%d procedure%s for this signature); use a stored procedure, or tick \"a new proposal anyway\""
                        % (len(know["exact"]), "" if len(know["exact"]) == 1 else "s"), "stored": know["exact"], "seed": False}), 409
    try:
        n, m, n_source = _window_numbers(s, body, sig["fine"])
    except (TypeError, ValueError, OverflowError):
        return jsonify({"error": "n and m must be whole numbers"}), 400
    levels = _levels_arg(body.get("levels"))
    same_queue = body.get("queue", "all") == "same"
    hint = as_text(body.get("hint"), "hint").strip()
    actor = _actor(body, ctx)
    w = _window_rows(s, uid, fid, n, m, same_queue, levels)
    if w is None:
        return jsonify({"error": "no NVMe command can be placed around this finding"}), 400
    if body.get("remember"):
        remember_window(s, sig["fine"], n, m, actor, uid, f["id"])
    _progress(body, 8, "read the window: %d commands" % len(w.get("commands") or []))
    history_report = _with_history(s, uid, w) if body.get("history", True) else {"note": "not asked for"}
    _progress(body, 12, "added the earlier commands the error depends on (by shared blocks, features and queues)")
    window_info = {"n": n, "m": m, "source": n_source, "counts": window_counts(w), "history": history_report, "levels": levels}
    cmd_rows = {r["rowid_file"]: r for r in w["rows"]}                     # the raw command rows (for the optimiser and the step builder)
    fault_raw = next(r for r in w["rows"] if r["position"] == "fault")
    optimised = OPT.optimise(w["rows"])
    evidence, order = {}, []

    def add(r):
        key = (r["level"], r["rowid"])
        if key not in evidence:
            evidence[key] = r
            order.append(key)

    # the failing command and every row under it come FIRST, then the commands nearest to it, outward: the prompt keeps at most
    # ISO.MAX_CONTEXT_LINES evidence lines, and in file order the 10 commands above used them up before the defect's own rows (found 2026-11-10:
    # the model said "the transactions, splits, links and packets under row 144 were not in the evidence I was given")
    fault_i = next((i for i, c in enumerate(w["commands"]) if c.get("position") == "fault"), 0)
    by_nearness = sorted(range(len(w["commands"])), key=lambda i: (i != fault_i, abs(i - fault_i), i))
    for i in by_nearness:
        c = w["commands"][i]
        add(c)
        for lv, blk in (c.get("under") or {}).items():
            for r in blk["rows"]:
                add(r)
    lower_fetched = set(levels)
    above_fetched = sum(1 for c in w["commands"] if c["position"] == "above")
    facts = st.retrieve(sig, ctx["device"])
    llm = _llm(s, body)
    rounds, producer, ans, standin_used = [], "stand-in", None, False
    st.chat_append(uid, fid, sig["fine"], "admin:" + actor, "isolate: %d above, %d below, levels %s%s" % (n, m, ", ".join(levels) or "commands only", ("; hint: " + hint) if hint else ""),
                   {"kind": "isolate_start", "n": n, "m": m, "levels": levels, "hint": hint})
    final = False
    for k in range(1, ISO.MAX_ROUNDS + 1):
        ev = [evidence[key] for key in order]
        final = final or k == ISO.MAX_ROUNDS
        prompt = ISO.loop_prompt(f, ctx["device"], facts, optimised, ev, hint, rounds, above_fetched, lower_fetched, final=final)
        _progress(body, 15 + 55 * (k - 1) / ISO.MAX_ROUNDS, "round %d: the model reads %d rows of evidence, the error last" % (k, len(ev)))
        ans, producer = ISO.call_model(llm, prompt, ISO.LOOP_SCHEMA, "verdict")
        if final and ans is not None and ans.get("verdict") == "need_more_evidence" and (ans.get("reason") or "").strip():
            # the model still asked although nothing more can be fetched: its reason text is the verdict (it was told so)
            ans["verdict"] = "reason"
            producer = producer + " (final round: answered with the evidence at hand)"
        if ans is None:
            standin_used = True
            ans = ISO.standin_loop(f, ctx["device"], optimised, ev, hint, rounds, above_fetched, lower_fetched, fault_raw["rowid_file"])
        text = ISO.round_text(ans, k)
        _progress(body, 15 + 55 * k / ISO.MAX_ROUNDS, text[:300])
        rec = {"round": k, "verdict": ans.get("verdict"), "text": text, "producer": producer, "prompt_chars": len(prompt), "evidence_rows": len(ev),
               "above_fetched": above_fetched, "levels_fetched": sorted(lower_fetched), "need": ans.get("need") if ans.get("verdict") == "need_more_evidence" else None}
        rounds.append(rec)
        st.chat_append(uid, fid, sig["fine"], "loop", text, rec)
        if ans.get("verdict") != "need_more_evidence" or k == ISO.MAX_ROUNDS:
            break
        need = ans.get("need") or {}
        fetched_any = False
        if need.get("more_above") and above_fetched < ISO.MAX_ABOVE:
            new_n = min(ISO.MAX_ABOVE, above_fetched + ISO.STEP_ABOVE)
            w2 = _window_rows(s, uid, fid, new_n, 0, same_queue, levels)
            if w2:
                lowest = min((k for k, r in cmd_rows.items() if not r.get("from_history")), default=min(cmd_rows))   # the window's own first row: rows from history lie far before it
                for r in w2["rows"]:
                    if r["rowid_file"] < lowest and r["rowid_file"] not in cmd_rows:
                        cmd_rows[r["rowid_file"]] = r
                for c in w2["commands"]:
                    if (c["level"], c["rowid"]) not in evidence:
                        fetched_any = True
                        add(c)
                        for lv, blk in (c.get("under") or {}).items():
                            for r in blk["rows"]:
                                add(r)
                above_fetched = sum(1 for key in order if key[0] == "nvme_command" and evidence[key]["position"] == "above")
        want_levels = [lv for lv in _levels_arg(need.get("levels") or []) if lv in f["levels_present"]]
        if want_levels:
            suspects = [c for c in need.get("commands") or [] if isinstance(c, int) and ("nvme_command", c) in evidence]
            if not suspects:
                suspects = [fault_raw["rowid_file"]] + [s_["source_row"] for s_ in optimised["steps"] if s_.get("position") == "above"]
            with current_app_ctx(s, uid) as (d, meta, con):
                for c in suspects[:40]:
                    cmd = evidence.get(("nvme_command", c))
                    if not cmd:
                        continue
                    under = _under(con, cmd, [lv for lv in want_levels if lv not in (cmd.get("under") or {})])
                    for lv, blk in under.items():
                        cmd.setdefault("under", {})[lv] = blk
                        for r in blk["rows"]:
                            if (r["level"], r["rowid"]) not in evidence:
                                fetched_any = True
                            add(r)
            lower_fetched |= set(want_levels)
        if not fetched_any:
            rounds[-1]["text"] += " (nothing more could be fetched: the bounds are reached or the rows do not exist; the next round is the final one)"
            final = True                     # one last round with what there is, told so; then the loop closes
            continue
    if ans.get("verdict") != "reason":
        # the bounds are reached without any reason text: the deterministic answer closes the loop (it replaces the last round's record, so the rounds stay within the bound)
        ev = [evidence[key] for key in order]
        ans = ISO.standin_loop(f, ctx["device"], optimised, ev, "", rounds, above_fetched, lower_fetched, fault_raw["rowid_file"])
        producer = "stand-in (the bounds were reached without a verdict)"
        standin_used = True
        last = rounds[-1] if rounds else {"round": 1}
        rec = {"round": last.get("round", len(rounds)), "verdict": "reason", "text": ISO.round_text(ans, last.get("round", len(rounds))) + " (closed by the code: the model gave no reason within %d rounds)" % len(rounds), "producer": producer}
        if rounds:
            rounds[-1] = rec
        else:
            rounds.append(rec)
        st.chat_append(uid, fid, sig["fine"], "loop", rec["text"], rec)
    # code checks on the final answer
    cited, cite_problems = ISO.check_cited(ans.get("cited_rows") or [], evidence)
    above_rows = sorted([r for r in cmd_rows.values() if r["position"] == "above"], key=lambda r: r["rowid_file"])
    below_rows = sorted([r for r in cmd_rows.values() if r["position"] == "below"], key=lambda r: r["rowid_file"])
    kept, seq_problems = ISO.check_sequence(ans.get("optimised_sequence") or [], above_rows, fault_raw)
    steps = ISO.assemble(kept, fault_raw, below_rows, optimised)
    reason = (ans.get("reason") or "").strip() or ISO.reason_text(f, ctx["device"])
    result = {"verdict": "reason", "reason": reason, "cited_rows": cited, "sequence": steps, "kept_above": len(kept), "dropped_above": len(above_rows) - len(kept),
              "below_copied": len(below_rows), "fault_step": next(s_["step"] for s_ in steps if s_["position"] == "fault"),
              "checks": {"ok": not (cite_problems or seq_problems), "problems": cite_problems + seq_problems,
                         "rules": ["commands after the defect copied unchanged", "only commands from the fetched window", "names matched case-insensitively", "the fault's own command allowed"]},
              "optimiser": {k: v for k, v in optimised.items() if k != "rows"}, "rounds": rounds, "producer": producer, "standin": standin_used,
              "evidence_rows": len(evidence), "above_fetched": above_fetched, "levels_fetched": sorted(lower_fetched),
              "seed": not know.get("exact"), "stored": know.get("exact"), "scenario_name": know.get("scenario_name") or CH.standin_answer(f, {"rows": [], "n": n, "m": m}, optimised)["scenario_name"],
              "expected_outcome": f["expected_outcome_default"], "observed_outcome": f["observed_outcome"], "actor": actor, "window": window_info}
    if body.get("isolation"):
        # the isolation of the defect (owner, 2026-11-11: "even if I draw 1,000 lines from above or below, the causation should always be one"):
        # the evidence card is computed by code from the error's own command (never from the window shown), the cause keyword is decided from it by
        # fixed rules, the defect term is made by code; the model only writes why and how; the isolation is kept per error and its card, so the same
        # error gives the same isolation whatever n and m are and however often it is asked
        from .dg_api import graph as _dg
        from nvme_hier import terms as _TM, evidence as _EV
        with current_app_ctx(s, uid) as (d_, meta_, con_):
            card = _EV.card(con_, f)
        cause_key, rule_words = _EV.decide_cause(card)
        term = _TM.defect_term(f)
        # the key of a kept isolation: the card, the rules (card and dictionary versions), the prompt and the model that wrote the words (research: a
        # result is reused only when every input matches; the cause itself never depends on the model)
        model_id = "stand-in" if llm is None else str(getattr(llm, "model", "") or getattr(llm, "name", "") or "model")
        version = "card%s-dict%s-explain1-%s" % (_EV.CARD_VERSION, _TM.VERSION, model_id)
        h = _EV.card_hash(card)
        kept, kept_at = (None, None) if body.get("rewrite") else _dg(s).kept_isolation(uid, f["id"], h, version)
        if kept is not None:
            iso_, iprod, iproblems = kept["isolation"], kept["producer"], kept["problems"]
            _progress(body, 90, "this error was isolated before from the same evidence: the same isolation is used (kept %s)" % time.strftime("%Y-%m-%d %H:%M", time.localtime(kept_at)))
        else:
            facts = _EV.facts(card, term, cause_key)
            cause = _TM.cause_of(cause_key)
            ev = [evidence[key] for key in order]
            iprompt = ISO.explain_prompt(f, card, cause, rule_words, facts, ev)
            _progress(body, 74, "the cause is decided by the fixed rules (%s); the model explains why and how" % cause_key)
            ia, iprod = ISO.call_model(llm, iprompt, ISO.EXPLAIN_SCHEMA, "why")
            _progress(body, 92, "the code checks every row the explanation cites")
            if ia is None:
                ia = ISO.standin_explain(card, cause, rule_words)
            cited, iproblems = ISO.check_cited(ia.get("cited_rows") or [], evidence)
            iso_ = dict(facts, why=" ".join(str(ia.get("why") or "").split()), how=" ".join(str(ia.get("how") or "").split()), cited_rows=cited,
                        cause_key=cause_key, cause_header=rule_words, cause_side=(cause or {}).get("side"), standard_name=term["name"])
            _dg(s).keep_isolation(uid, f["id"], h, version, {"isolation": iso_, "producer": iprod, "problems": iproblems})
            kept_at = None
        found = _dg(s).find_defect(term_key=term["key"])
        iso_ = dict(iso_, term=term, stored=_dg(s).view(found["id"]) if found else None, cause=_TM.cause_of(iso_["cause_key"]), card=card, card_hash=h,
                    decided_by="the fixed rules of the evidence card (version %s) and the dictionary (version %s)" % (_EV.CARD_VERSION, _TM.VERSION),
                    kept_at=kept_at)
        result["isolation"] = dict(iso_, producer=iprod, problems=iproblems, labels=ISO.ISOLATION_LABEL,
                                   device=ctx["device"], firmware=sig.get("firmware"), rule=f.get("rule"), level=f.get("level"))
    st.chat_append(uid, fid, sig["fine"], producer, "reason: " + reason, {"kind": "isolate_result", **{k: v for k, v in result.items() if k not in ("rounds", "optimiser")}})
    result["history"] = st.chat_history(uid, fid)
    result["graph"] = st.graph_view(sig["fine"])
    result["choice"] = st.graph_choice(sig, wholes(body.get("exclude_procedures"), "exclude_procedures"))    # the procedural graph's first choice for this failure
    if request.args.get("debug") == "1":
        result["debug"] = {"last_prompt": prompt}
    return jsonify(result)


# the rows directly under one row of the tree, for the error page's "expand" (owner, 2026-11-11: the commands around the error shown like
# the hierarchy page: a table of NVMe commands, each opened level by level)
CHILD_LEVELS = {"nvme_command": ["nvme_transaction"], "nvme_transaction": ["split", "link"], "split": ["link"], "link": ["packets"], "packets": []}


@bp.get("/api/isolate/<uid>/<int:fid>/children")
def children(uid, fid):
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    level = request.args.get("level")
    if level not in CHILD_LEVELS:
        return jsonify({"error": "level must be one of %s" % ", ".join(CHILD_LEVELS)}), 400
    numbers = "rowid, limit and offset must be whole numbers"       # `whole` also refuses a number SQLite cannot hold (parameter fuzz over all cases, 2026-11-11)
    rowid = whole(request.args.get("rowid"), message=numbers)
    limit = max(1, min(whole(request.args.get("limit") or 200, message=numbers), 2000))
    offset = max(0, whole(request.args.get("offset") or 0, message=numbers))
    parts = []
    with current_app_ctx(s, uid) as (d, meta, con):
        tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        for lv in CHILD_LEVELS[level]:
            if TABLE[lv] not in tables:
                continue
            where = "parent_level=? AND parent=? AND COALESCE(relation, 'member') != 'context'"
            total = con.execute("SELECT COUNT(*) FROM %s WHERE %s" % (TABLE[lv], where), (level, rowid)).fetchone()[0]
            if not total:
                continue
            rows = []
            for r in con.execute("SELECT * FROM %s WHERE %s ORDER BY rowid_file LIMIT ? OFFSET ?" % (TABLE[lv], where), (level, rowid, limit, offset)):
                row = dict(r)
                row["raw"] = json.loads(row["raw"]) if isinstance(row.get("raw"), str) else (row.get("raw") or {})
                for k in ("t_ps", "delta_ps", "dur_ps"):
                    if row.get(k) is not None:
                        row[k + "_text"] = P.fmt_ps(row[k])
                x = _evidence_row(con, lv, row)
                x["has_children"] = bool(CHILD_LEVELS.get(lv))
                rows.append(x)
            parts.append({"level": lv, "label": LABEL[lv], "count": total, "offset": offset, "rows": rows})
    return jsonify({"level": level, "rowid": rowid, "parts": parts})


@bp.post("/api/isolate/<uid>/<int:fid>/testcase/approve")
def approve_testcase(uid, fid):
    """The admin approves the test file written on the error page: recorded with who, when and the file's fingerprint, and tied to the
    version of the solution it was written from."""
    import hashlib
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    path = as_text(body.get("path"), "path")
    suite = os.path.realpath(os.path.join(s.root, "suite", "hier"))
    try:
        real = os.path.realpath(path) if path else ""
    except (OSError, ValueError):            # a NUL byte in the path (parameter fuzz, 2026-11-11)
        real = ""
    if not real.startswith(suite + os.sep) or not os.path.exists(real):
        return jsonify({"error": "no such test file in the suite"}), 400
    admin = as_text(body.get("name"), "name").strip()
    if not admin:
        return jsonify({"error": "say who you are (your name) first"}), 400
    revision = whole(body["revision_id"], "revision_id") if body.get("revision_id") else None     # refused before anything is written
    with open(real, "rb") as fh:
        sha = hashlib.sha256(fh.read()).hexdigest()
    rec = {"approved_by": admin, "at": time.time(), "sha256": sha, "status": "approved", "comment": as_text(body.get("comment"), "comment").strip(),
           "upload_id": uid, "finding": fid, "two_sided": body.get("two_sided")}
    L.write_json_atomic(real + ".approved.json", rec, indent=1)
    from .dg_api import graph as _dg
    _dg(s).set_test_path(revision, real, uid, fid)      # tied to the solution's version and to this error
    return jsonify({"ok": True, "approved": rec})


@bp.get("/api/isolate/<uid>/<int:fid>/graph")
def graph(uid, fid):
    """This failure's part of the procedural graph: nodes and edges with their weights, the paths in the policy's order."""
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    ctx = _load(s, uid, fid)
    if ctx is None:
        return jsonify({"error": "no such finding"}), 404
    st = knowledge(s)
    return jsonify({"graph": st.graph_view(ctx["sig"]["fine"]), "choice": st.graph_choice(ctx["sig"])})


@bp.post("/api/isolate/<uid>/<int:fid>/signal")
def signal(uid, fid):
    """Part 8: one of the four signals on the seed (procedure_id null + proposal_steps) or on a stored procedure;
    stores the scenario name and the reason in words with it. No admin name required."""
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    if body.get("signal") not in ST.SIGNALS:
        return jsonify({"error": "signal must be one of: " + ", ".join(ST.SIGNALS)}), 400
    ctx = _load(s, uid, fid)
    if ctx is None:
        return jsonify({"error": "no such finding"}), 404
    sig = ctx["sig"]
    actor = _actor(body, ctx)
    st = knowledge(s)
    outcome = a_dict(body.get("outcome"), "outcome") or {"observed": ctx["f"]["observed_outcome"], "expected": ctx["f"]["expected_outcome_default"], "verified_by": None}
    st.touch_signature(sig, ctx["device"], upload_id=uid, finding_id=ctx["f"]["id"])
    before = st.graph_view(sig["fine"])
    try:
        r = st.signal(sig["fine"], body.get("procedure_id"), body["signal"], actor, edited_steps=body.get("edited_steps"), edited_text=body.get("edited_text"),
                      upload_id=uid, finding_id=fid, proposal_steps=body.get("proposal_steps"), proposal_text=body.get("proposal_text"),
                      scenario_name=as_text(body.get("scenario_name"), "scenario_name") or None, outcome=outcome, advice=as_text(body.get("advice"), "advice") or None)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    if as_text(body.get("scenario_name"), "scenario_name").strip():
        st.set_scenario_name(sig["fine"], body["scenario_name"].strip(), "admin:" + actor)
    if as_text(body.get("reason"), "reason").strip():
        st.set_reason(sig["fine"], body["reason"].strip(), "admin:" + actor)
    st.chat_append(uid, fid, sig["fine"], "admin:" + actor, "signal %s%s" % (body["signal"], (" on procedure %s" % body.get("procedure_id")) if body.get("procedure_id") else " on the seed"),
                   {"kind": "signal", "result": r})
    memory_now = _memory(s, ctx, uid)
    after = st.graph_view(sig["fine"])
    return jsonify({"result": r, "stored": st.lookup(sig), "memory": memory_now, "actor": actor, "graph": after, "graph_change": ST.Store.graph_change(before, after)})


@bp.post("/api/isolate/<uid>/<int:fid>/reorder")
def reorder(uid, fid):
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    ctx = _load(s, uid, fid)
    if ctx is None:
        return jsonify({"error": "no such finding"}), 404
    st = knowledge(s)
    st.reorder(ctx["sig"]["fine"], wholes(body.get("order"), "order"), _actor(body, ctx))
    return jsonify({"stored": st.lookup(ctx["sig"])})


@bp.post("/api/isolate/<uid>/<int:fid>/testcase")
def testcase(uid, fid):
    """Part 8, the test case in two steps. Without expected_outcomes: the model is asked once for the expected outcomes
    of the n commands from the defect onward (status and timing a correct device must produce); the admin verifies them
    in the page. With expected_outcomes and verified=true: the file is written (input = the sequence above the
    defect; expected output = the verified outcomes).

    The rows above the defect are either the kept sequence of card 6 (default) or, when the admin gives above_n, the
    last above_n commands before the defect taken from the recording as they are (same_queue restricts them to the
    defect's queue), with their measured gaps (owner's request 2026-11-03). expected_before asks the model for the
    outcomes of that many steps before the defect as well (the set-up steps of the test)."""
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    if request.args.get("job") == "1":
        return _as_job(body)
    ctx = _load(s, uid, fid)
    if ctx is None:
        return jsonify({"error": "no such finding"}), 404
    f, sig = ctx["f"], ctx["sig"]
    _progress(body, 5, "reading the error and the sequence")
    steps = dicts(body.get("sequence"), "sequence")
    if not steps:
        return jsonify({"error": "no sequence: run the isolation first or use a stored procedure"}), 400
    steps = [dict(s_) for s_ in steps]
    if not any(s_.get("position") == "fault" for s_ in steps):
        if any("position" in s_ for s_ in steps):
            return jsonify({"error": "the steps no longer contain the defect itself: keep the step of the defect"}), 400
        steps[-1]["position"] = "fault"
    above_n = body.get("above_n")
    if above_n is not None and above_n != "":
        try:
            above_n = max(0, min(ISO.MAX_ABOVE, int(above_n)))
        except (TypeError, ValueError, OverflowError):
            return jsonify({"error": "above_n must be a whole number"}), 400
        w = _window_rows(s, uid, fid, above_n, 0, bool(body.get("same_queue")), [])
        rows_above = sorted([r for r in w["rows"] if r["position"] == "above"], key=lambda r: r["rowid_file"])
        fault_raw = next((r for r in w["rows"] if r["position"] == "fault"), None)
        chosen = []
        prev_t = None
        for r in rows_above:
            t = r.get("t_ps")
            gap = max(1, (t - prev_t) // 10 ** 6) if (t is not None and prev_t is not None and t > prev_t) else OPT.DEFAULT_GAP_US
            chosen.append(OPT.step_of(dict(r, position="above"), len(chosen) + 1, why=["chosen by the admin: one of the %d commands before the defect, as recorded" % len(rows_above)], gap_us=gap))
            prev_t = t if t is not None else prev_t
        fault_old = next(s_ for s_ in steps if s_.get("position") == "fault")
        if fault_raw is not None and prev_t is not None and fault_raw.get("t_ps") is not None and fault_raw["t_ps"] > prev_t:
            fault_old = dict(fault_old, gap_us=max(1, (fault_raw["t_ps"] - prev_t) // 10 ** 6))
        steps = chosen + [fault_old] + [s_ for s_ in steps if s_.get("position") == "below"]
    for i, s_ in enumerate(steps):
        s_["step"] = i + 1
    fault_step = next(s_["step"] for s_ in steps if s_.get("position") == "fault")
    try:
        n_after = max(1, whole(body.get("expected_after") or (len(steps) - fault_step + 1), "expected_after"))
        n_before = max(0, whole(body.get("expected_before") or 0, "expected_before"))
    except (TypeError, ValueError, OverflowError):
        return jsonify({"error": "expected_after and expected_before must be whole numbers"}), 400
    n_after = min(n_after, len(steps) - fault_step + 1)
    n_before = min(n_before, fault_step - 1)
    limit_us, limit_text, limit_source = _cmd_limit(ctx)
    actor = _actor(body, ctx)
    st = knowledge(s)
    if not body.get("expected_outcomes"):
        prompt = ISO.outcomes_prompt(f, ctx["device"], steps, fault_step, n_after, limit_text, limit_source, n_before=n_before)
        _progress(body, 25, "the model proposes what a correct drive must answer, command by command")
        ans, producer = ISO.call_model(_llm(s, body), prompt, ISO.OUTCOMES_SCHEMA, "outcomes")
        _progress(body, 85, "the code checks that every proposed command is in the sequence")
        standin = ans is None
        if ans is None:
            ans = ISO.standin_outcomes(f, steps, fault_step, n_after, limit_us, limit_text, limit_source, n_before=n_before)
        by_step = {s_["step"]: s_ for s_ in steps}
        outs = []
        for o in ans.get("outcomes") or []:
            try:
                stp = int(o.get("step"))
            except (TypeError, ValueError, OverflowError):
                continue
            if stp < fault_step - n_before or stp >= fault_step + n_after or stp not in by_step:
                continue
            try:                # the model's answer is not trusted: a status that is not a number is treated as none given
                code = [int(o.get("status_type") or 0), int(o.get("status_code") or 0)] if o.get("status_type") is not None else None
            except (TypeError, ValueError, OverflowError):
                code = None
            outs.append({"step": stp, "command": by_step[stp]["command"], "position": by_step[stp].get("position"), "status": o.get("status") or "", "status_code": code,
                         "success": code in (None, [0, 0]), "timing_us": int(o["timing_us"]) if isinstance(o.get("timing_us"), int) and o["timing_us"] > 0 else int(limit_us),
                         "timing_text": P.fmt_ps(int(o["timing_us"]) * 10 ** 6) if isinstance(o.get("timing_us"), int) and o["timing_us"] > 0 else limit_text,
                         "check": o.get("check") or "", "basis": o.get("basis") or "", "verified": False})
        missing = [stp for stp in range(fault_step - n_before, fault_step + n_after) if stp not in {o["step"] for o in outs}]
        if missing:     # the model skipped steps: the stand-in fills them so every step has an outcome to verify
            fill = ISO.standin_outcomes(f, steps, fault_step, n_after, limit_us, limit_text, limit_source, n_before=n_before)["outcomes"]
            for o in fill:
                if o["step"] in missing:
                    outs.append({"step": o["step"], "command": o["command"], "position": by_step[o["step"]].get("position"), "status": o["status"], "status_code": [0, 0], "success": True,
                                 "timing_us": o["timing_us"], "timing_text": P.fmt_ps(o["timing_us"] * 10 ** 6), "check": o["check"], "basis": o["basis"], "verified": False})
        outs.sort(key=lambda o: o["step"])
        st.chat_append(uid, fid, sig["fine"], producer, "expected outcomes proposed for steps %d to %d%s" % (fault_step - n_before, fault_step + n_after - 1, (" (rows above chosen by the admin: %d)" % above_n) if above_n not in (None, "") else ""), {"kind": "expected_outcomes", "outcomes": outs})
        return jsonify({"expected_outcomes": outs, "fault_step": fault_step, "expected_after": n_after, "expected_before": n_before, "above_n": above_n if above_n not in (None, "") else None,
                        "producer": producer, "standin": standin, "prompt_chars": len(prompt), "limit": {"text": limit_text, "source": limit_source}, "sequence": steps})
    if not body.get("verified"):
        return jsonify({"error": "tick 'verified' after checking the expected outcomes; the file is written only with verified outcomes"}), 400
    outs = body["expected_outcomes"]
    if not isinstance(outs, list) or not all(isinstance(o, dict) for o in outs):
        return jsonify({"error": "expected_outcomes must be a list of outcomes"}), 400
    fault_exp = next((o for o in outs if whole(o.get("step", 0), "step") == fault_step), None)
    outcome = {"observed": f["observed_outcome"], "verified_by": actor,
               "expected": {"status": (fault_exp or {}).get("status") or f["expected_outcome_default"]["status"], "description": f["expected_outcome_default"]["description"],
                           "check": (fault_exp or {}).get("check") or f["expected_outcome_default"]["check"]}}
    suite = os.path.join(s.root, "suite", "hier")
    os.makedirs(suite, exist_ok=True)
    version = 1 + len([x for x in os.listdir(suite) if x.startswith("%s_f%d_" % (uid, fid))])
    name = "%s_f%d_v%d.py" % (uid, fid, version)
    nsid = (ctx.get("cmd_row") or {}).get("nsid") or 1
    scenario = as_text(body.get("scenario_name"), "scenario_name") or st.lookup(sig).get("scenario_name")
    if body.get("format") == "nvme-cli":
        # the first form of the test file (nvme-cli, one command at a time); kept for the suites and harnesses written against it
        text = TC.generate(f, steps, sig, scenario, uid, version=version, device=ctx["device"], firmware=sig.get("firmware"), nsid=nsid, name=name,
                           outcome=outcome, limit_us=limit_us, expected_after=outs)
        path = os.path.join(suite, name)
        with open(path, "w") as fh:
            fh.write(text)
        made = {}
    else:
        # the regression test (owner, 2026-11-10): the plan, checked against the recording, written beside the fixed replay library, run
        # both ways on the simulated drive; research report "Defect replay tests and deallocate checks"
        dealloc, known = a_dict(body.get("deallocate_range"), "deallocate_range") or None, a_dict(body.get("known_rate"), "known_rate") or None
        expected = TC.normalise_expected(outs, steps, fault_step)
        try:
            if body.get("author") == "model":
                made = _model_regression_test(s, body, uid, f, steps, sig, scenario, version, ctx, limit_us, expected, actor, suite, name, dealloc, known,
                                              as_text(body.get("hint"), "hint"))
            else:
                made = _write_regression_test(s, uid, f, steps, sig, scenario, version, ctx, limit_us, expected, actor, suite, name, dealloc, known, "code")
        except ValueError as e:
            return jsonify({"error": str(e)}), 400
        path, text = made["path"], made["text"]
    if body.get("procedure_id"):
        st.set_test_path(whole(body.get("procedure_id"), "procedure_id"), path)
    st.chat_append(uid, fid, sig["fine"], "admin:" + actor, "test case written: " + name, {"kind": "testcase", "path": path})
    return jsonify({"path": path, "name": name, "version": version, "text": text, "steps": steps, "expected_after": TC.normalise_expected(outs, steps, fault_step), "actor": actor,
                    **{k: made[k] for k in ("plan", "checks", "two_sided", "library", "model") if k in made}})


def _steps_from_rows(w, chosen, reasons):
    """The replay steps from the window rows the model chose, every parameter copied from the recording (OPT.step_of), with the measured gaps."""
    rows = {r["rowid_file"]: r for r in w["rows"]}
    out, prev = [], None
    fault_t = next((r.get("t_ps") for r in w["rows"] if r.get("position") == "fault"), None)
    for rid in chosen:
        r = rows[rid]
        pos = r.get("position") if r.get("position") in ("fault", "below") else "above"
        t = r.get("t_ps")
        gap = max(1, (t - prev) // 10 ** 6) if (t is not None and prev is not None and t > prev) else OPT.DEFAULT_GAP_US
        out.append(OPT.step_of(dict(r, position=pos), len(out) + 1, why=[reasons.get(rid) or "chosen by the model"] + list(r.get("history_why") or []), gap_us=min(gap, 600 * 10 ** 6)))
        prev = t if t is not None else prev
    return out, fault_t


def _remap_expected(expected, old_steps, new_steps):
    """The admin's verified outcomes follow their command rows into the model's steps; an outcome of a row the model left out is dropped (said so)."""
    row_of = {x["step"]: x.get("source_row") for x in old_steps}
    step_of = {x.get("source_row"): x["step"] for x in new_steps}
    out, dropped = [], []
    for e in expected:
        rid = row_of.get(e.get("step"))
        if rid in step_of:
            out.append(dict(e, step=step_of[rid]))
        else:
            dropped.append("step %s (%s)" % (e.get("step"), e.get("command")))
    return out, dropped


def _model_regression_test(s, body, uid, f, steps, sig, scenario, version, ctx, limit_us, expected, actor, suite, name, dealloc, known, hint):
    """The model writes the plan from the multi-level window (owner, 2026-11-10); the code checks it, renders it and runs it both ways on the
    simulated drive; a failed check goes back to the model with the problems, at most twice. With no model, the code's own plan is used, said so."""
    st = knowledge(s)
    n, m, _src = _window_numbers(s, body, sig["fine"])
    w = _window_rows(s, uid, f["id"], n, m, False, list(ISO.LOWER_LEVELS))
    if w is None:
        raise ValueError("no NVMe command can be placed around this finding")
    _with_history(s, uid, w)
    stored = []
    for x in st.retrieve(sig, ctx["device"]) or []:
        if x.get("steps") and len(stored) < 2:
            stored.append({"scenario": x.get("scenario_name"), "steps": x.get("steps"), "oracle": None})
    rule_oracle = TP.oracle_of(f, limit_us)
    defect = ISO.defect_lines(f, ctx["device"]) + ([("The admin's comment for this try: " + hint)] if hint else [])
    llm, problems, rounds = _llm(s, body), None, []
    for rnd in range(3):
        prompt = TP.plan_prompt(defect, w, expected, stored, steps, problems)
        _progress(body, 20 + 15 * rnd, "the model writes the test plan from the window (try %d of at most 3)" % (rnd + 1))
        ans, producer = ISO.call_model(llm, prompt, TP.PLAN_SCHEMA, "replay_rows")
        _progress(body, 30 + 15 * rnd, "the code checks every step of the plan against its row of the recording")
        if ans is None:
            made = _write_regression_test(s, uid, f, steps, sig, scenario, version, ctx, limit_us, expected, actor, suite, name, dealloc, known, "code (no model answer)")
            made["model"] = {"producer": producer, "analysis": "No model answered (%s): the code's own plan from stage 1 is used." % producer, "rounds": rounds, "used": "code", "prompt_chars": len(prompt)}
            return made
        chosen, problems, notes = TP.check_answer(ans, w, rule_oracle)
        rec = {"round": rnd + 1, "producer": producer, "problems": list(problems), "notes": notes, "rows": chosen}
        rounds.append(rec)
        if problems:
            continue
        reasons = {}
        for x in ans.get("row_reasons") or []:
            try:
                reasons[int(x.get("row"))] = str(x.get("why") or "")[:300]
            except (TypeError, ValueError, OverflowError):
                continue
        new_steps, _ft = _steps_from_rows(w, chosen, reasons)
        exp2, dropped = _remap_expected(expected, steps, new_steps)
        d2 = dealloc
        if d2 is None and int(ans.get("deallocate_blocks") or 0) > 0:
            d2 = {"slba": int(ans.get("deallocate_first_block") or 0), "blocks": int(ans["deallocate_blocks"]), "guard": 8, "why": "proposed by the model"}
        try:
            made = _write_regression_test(s, uid, f, new_steps, sig, scenario, version, ctx, limit_us, exp2, actor, suite, name, d2, known, "model (%s)" % producer)
        except ValueError as e:
            problems = [str(e)]
            rec["problems"] = problems
            continue
        if not made["two_sided"].get("ok"):
            problems = [made["two_sided"]["words"]]
            rec["problems"] = problems
            continue
        made["model"] = {"producer": producer, "analysis": str(ans.get("analysis") or "")[:6000], "setup_note": str(ans.get("setup_note") or "")[:1000], "rounds": rounds,
                         "notes": notes + (["the verified outcomes of %s were dropped: the model did not replay those commands" % ", ".join(dropped)] if dropped else []),
                         "used": "model", "prompt_chars": len(prompt), "window": {"n": n, "m": m, "commands": len(w["commands"])}}
        return made
    made = _write_regression_test(s, uid, f, steps, sig, scenario, version, ctx, limit_us, expected, actor, suite, name, dealloc, known, "code (the model's plan failed the checks)")
    made["model"] = {"producer": rounds[-1]["producer"] if rounds else "model", "rounds": rounds, "used": "code",
                     "analysis": "The model's plan did not pass the code's checks in %d tries (%s): the code's own plan from stage 1 is used." % (len(rounds), "; ".join((rounds[-1]["problems"] if rounds else [])[:3]))}
    return made


def evidence_check(con, steps):
    """Every replayed step against its own row in the recording: the same command, on the same blocks. -> problems in words."""
    probs = []
    for x in steps:
        rid = x.get("source_row")
        if rid is None:
            probs.append("step %s (%s) names no row of the recording" % (x.get("step"), x.get("command")))
            continue
        r = _row(con, "nvme_command", rid)
        if r is None:
            probs.append("step %s names row %s, which is not a command of this recording" % (x.get("step"), rid))
            continue
        if r.get("opc") != x.get("opc") or bool(r.get("sqid") == 0) != bool(x.get("admin")):
            probs.append("step %s says %s, but row %s of the recording is %s" % (x.get("step"), x.get("command"), rid, _summary("nvme_command", r)))
            continue
        p = x.get("parameters") or {}
        for k in ("nsid", "slba", "nlb"):
            if p.get(k) is not None and r.get(k) is not None and int(p[k]) != int(r[k]):
                probs.append("step %s: %s is %s, but row %s of the recording has %s" % (x.get("step"), k.upper(), p[k], rid, r[k]))
    return probs


def _write_regression_test(s, uid, f, steps, sig, scenario, version, ctx, limit_us, expected, actor, suite, name, dealloc=None, known=None, author="code"):
    """The plan of the test, checked, written with the library beside it, and run both ways on the simulated drive."""
    with current_app_ctx(s, uid) as (d, meta, con):
        problems = evidence_check(con, steps)
        rows = [r for r in (_row(con, "nvme_command", x["source_row"]) for x in steps if x.get("source_row") is not None) if r]
    if problems:
        raise ValueError("the steps do not match the recording: " + "; ".join(problems[:8]))
    fault = next(x for x in steps if x.get("position") == "fault")
    fp = fault.get("parameters") or {}
    if dealloc is None and (f.get("rule") in ("cmd.deallocate_readback", "cmd.write_zeroes_readback") or (not fault.get("admin") and fault.get("opc") in (0x08, 0x09))):
        rg = (fp.get("ranges") or [[fp.get("slba"), (fp.get("nlb") or 0) + 1]])[0]
        if rg[0] is not None:
            dealloc = {"slba": int(rg[0]), "blocks": int(rg[1]), "guard": 8, "command": "write_zeroes" if fault.get("opc") == 0x08 and not fault.get("admin") else "dsm",
                       "why": "the defect involves a deallocate of these blocks"}
    if dealloc is not None:
        try:
            dealloc = {"slba": max(0, int(dealloc.get("slba", 0))), "blocks": max(1, min(1 << 20, int(dealloc.get("blocks", 64)))), "guard": max(1, min(4096, int(dealloc.get("guard", 8)))),
                       "command": "write_zeroes" if dealloc.get("command") == "write_zeroes" else "dsm", "why": as_text(dealloc.get("why"), "why") or "asked by the admin"}
        except (TypeError, ValueError, OverflowError):
            raise ValueError("deallocate_range: slba, blocks and guard must be whole numbers")
    if known is not None:
        try:
            known = {"k": max(0, int(known["k"])), "n": max(1, int(known["n"])), "firmware": as_text(known.get("firmware"), "firmware") or None}
        except (TypeError, ValueError, KeyError):
            raise ValueError("known_rate needs k (reproductions) and n (runs) as whole numbers")
        if known["k"] > known["n"]:
            raise ValueError("known_rate: k cannot be more than n")
    plan = TP.build_plan(f, steps, sig, scenario, uid, version, ctx["device"], sig.get("firmware"), limit_us, expected, rows, actor,
                         "%s_f%d" % (uid, f["id"]), deallocate_range=dealloc, known_rate=known, author=author)
    checks = TP.check_plan(plan)
    if checks:
        raise ValueError("the test plan does not pass the checks: " + "; ".join(checks[:8]))
    path = TP.write(plan, suite, name)
    _progress(None, 70, "the test file is written; it runs four times on the simulated drive (faulty and correct)")
    two = TP.two_sided(path, plan)
    _progress(None, 95, "the simulated drive gave its answers")
    with open(path) as fh:
        text = fh.read()
    return {"path": path, "text": text, "plan": plan, "checks": {"evidence": "every step matches its row of the recording", "plan": "passed", "compiled": True},
            "two_sided": two, "library": {"path": os.path.join(suite, "f2t_nvme.py"), "version": plan["library"]}}


@bp.post("/api/isolate/<uid>/<int:fid>/summary")
def summary(uid, fid):
    """The summary of the error: who, what, when, where, why and how, one line each, at most 100 words (owner, 2026-11-11); stored with
    the signature."""
    s = svc()
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    ctx = _load(s, uid, fid)
    if ctx is None:
        return jsonify({"error": "no such finding"}), 404
    f, sig = ctx["f"], ctx["sig"]
    st = knowledge(s)
    know = st.lookup(sig)
    reason = (as_text(body.get("reason"), "reason") or know.get("reason") or "").strip()
    steps = dicts(body.get("sequence"), "sequence")
    expected = a_dict(body.get("expected_outcome"), "expected_outcome") or f["expected_outcome_default"]
    prompt = ISO.summary_prompt(f, ctx["device"], reason, steps, expected)
    ans, producer = ISO.call_model(_llm(s, body), prompt, ISO.SUMMARY_SCHEMA, "what")
    standin = ans is None
    lines = ISO.summary_lines(ans) if ans else None
    if lines is None:
        if ans is not None:
            producer = "stand-in (the model's answer left a question empty or was over %d words)" % ISO.SUMMARY_WORDS
        standin = True
        lines = ISO.summary_lines(ISO.fit_summary(ISO.standin_summary(f, ctx["device"], reason, steps, expected)))
    text = "\n".join(lines)
    actor = _actor(body, ctx)
    st.set_summary(sig["fine"], text, producer if not body.get("name") else "admin:" + actor)
    st.chat_append(uid, fid, sig["fine"], producer, "summary:\n" + text, {"kind": "summary", "lines": lines})
    return jsonify({"lines": lines, "text": text, "producer": producer, "standin": standin, "prompt_chars": len(prompt), "stored": st.lookup(sig)})
