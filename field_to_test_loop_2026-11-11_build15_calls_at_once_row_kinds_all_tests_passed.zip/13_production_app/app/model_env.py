"""The model connection the Settings page sets: where the calls go (URL), the model name and the API key.

Owner, 2026-11-11: "it should not depend solely on my API key ... I open the settings from run_app.py and change the model name, the
URL and the API key, so that everything works properly." So the Settings page is the one place that decides, for every part of the
application (stage 1 and 2, the error pages, and the agents, including Claude Code, which inherits the key and the URL):

* the key typed on the page is kept in a private file on this computer (ENV_FILE, readable only by its owner), never in the
  configuration file; run_app.py loads it at start, and it wins over a key the computer's environment already holds;
* the key is put under the variable the configuration names (llm.api_key_env) and under ANTHROPIC_API_KEY, which every caller reads;
* the URL (llm.base_url) is put in ANTHROPIC_BASE_URL; empty means Anthropic's own address.

Only the two key variables are read from the file: any other line in it is ignored, and no value is ever printed.
"""
import os
import re

ENV_FILE = os.environ.get("F2T_ENV_FILE") or os.path.join(os.path.expanduser("~"), ".config", "f2t", "env")
_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def read_env_file(path=None):
    """{NAME: value} of the NAME=value lines of the file; comments, blank lines and lines that are not NAME=value are skipped."""
    out = {}
    try:
        with open(path or ENV_FILE, encoding="utf-8", errors="replace") as fh:
            for line in fh:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if line.startswith("export "):
                    line = line[7:].strip()
                name, eq, value = line.partition("=")
                name, value = name.strip(), value.strip().strip('"').strip("'")
                if eq and _NAME.match(name) and value and not any(ord(c) < 32 for c in value):
                    out[name] = value
    except OSError:
        pass
    return out


def normal_url(u):
    """'gateway.company.com/v1/' -> 'https://gateway.company.com'; '' stays '' (Anthropic). Every caller adds /v1/messages itself, so an
    address typed with /v1 or /v1/messages would be called twice over (/v1/v1/messages: 'not found')."""
    u = (u or "").strip()
    if not u:
        return ""
    if not re.match(r"^https?://", u, re.I):
        u = "https://" + u
    u = u.rstrip("/")
    for tail in ("/v1/messages", "/v1"):
        if u.lower().endswith(tail):
            u = u[: -len(tail)]
    return u.rstrip("/")


def key_var(cfg):
    return ((cfg or {}).get("llm") or {}).get("api_key_env") or "ANTHROPIC_API_KEY"


def apply(cfg):
    """Put the configured key under ANTHROPIC_API_KEY and the configured URL under ANTHROPIC_BASE_URL (what every caller reads)."""
    var = key_var(cfg)
    if var != "ANTHROPIC_API_KEY" and os.environ.get(var):
        os.environ["ANTHROPIC_API_KEY"] = os.environ[var]
    url = normal_url(((cfg or {}).get("llm") or {}).get("base_url"))
    if url:
        os.environ["ANTHROPIC_BASE_URL"] = url


def load(cfg, path=None):
    """At start: the key saved on the Settings page (if any) replaces a key inherited from the environment; then apply().
    Returns where the key came from, in words (never the key)."""
    saved = read_env_file(path)
    var = key_var(cfg)
    key = saved.get(var) or saved.get("ANTHROPIC_API_KEY")
    if key:
        os.environ[var] = key
        os.environ["ANTHROPIC_API_KEY"] = key
    apply(cfg)
    return source(cfg, path)


def source(cfg, path=None):
    """{"present", "end", "source"}: whether a key is in use, its last 4 characters and where it came from, for the Settings page."""
    var = key_var(cfg)
    key = os.environ.get(var) or os.environ.get("ANTHROPIC_API_KEY") or ""
    if not key:
        return {"present": False, "end": "", "source": "no key yet"}
    saved = read_env_file(path)
    from_page = key in (saved.get(var), saved.get("ANTHROPIC_API_KEY"))
    return {"present": True, "end": key[-4:] if len(key) >= 12 else "",
            "source": "saved on the Settings page" if from_page else "from this computer's environment (not set on the Settings page)"}
