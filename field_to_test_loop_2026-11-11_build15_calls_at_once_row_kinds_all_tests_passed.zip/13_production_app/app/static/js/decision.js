/* Manager decision view for one isolated defect (stage 2).
   Layout follows research_notes_v3/manager_decision_view.md: bottom line → what the packets showed (host/device flow graph,
   Δt per row, first abnormal row shaded) → proposed reproductions as ranked cards (Correct / Needs changes / Not correct,
   drag or menu to rank) → in-place correction (Stored vs Your version) → removal as an undoable stub → result.
   Everything else stays behind the "All details" control that review.js owns. */
import { $, esc, fmt, toast, errorTypeFull, defectName, when } from "./api.js";
import { searchWords, stressWords } from "./review.js";

const OPS = ["read", "write", "flush", "trim", "write_zeroes", "reset", "power_cycle", "aspm_idle", "identify", "get_log", "set_feature", "abort"];
const OP_WORD = { read: "read", write: "write", flush: "flush", trim: "trim", write_zeroes: "write zeroes", reset: "controller reset", power_cycle: "power cycle",
  aspm_idle: "ASPM idle", identify: "Identify", get_log: "Get Log Page", set_feature: "Set Features", abort: "Abort" };
const TIMING_KEYS = [["qd", "queue depth", ""], ["inter_cmd_us", "between commands", "µs"], ["bs_kb", "block size", "KB"], ["burst_len", "burst length", ""], ["idle_gap_ms", "idle gap", "ms"]];
const REASONS = ["Wrong timing", "Wrong command order", "Does not match the packets"];
const PENDING = new Map();            // "<run>/<incident>" -> { removed: Map(id -> {note, retire}), order: [ids] | null }

/* ---------------- small formatters ---------------- */
const sig3 = (x) => +x.toPrecision(3);
function dt(us) { if (us < 1000) return sig3(us) + " µs"; if (us < 1e6) return sig3(us / 1000) + " ms"; return sig3(us / 1e6) + " s"; }
const usWord = (us) => us >= 1000 ? sig3(us / 1000) + " ms" : us + " µs";
const msWord = (ms) => ms >= 1000 ? sig3(ms / 1000) + " s" : ms + " ms";
export function likelihood(p) { if (p == null) return ""; return p >= 0.8 ? "very likely" : p >= 0.5 ? "likely" : p >= 0.25 ? "possible" : "unlikely"; }   // word for a 95 % LOWER bound
const pct = (p) => Math.round(p * 100) + " %";
export { pct };
/* ---------------- plain words for internal status / mode / action / id values ---------------- */
const STATUS_WORD = { done: "done", confirmed: "reproduced", reused_validated: "reproduced (saved procedure reused)", CONFIRMED: "confirmed", NOT_CONFIRMED: "not confirmed",
  not_reproduced: "not reproduced", budget_exhausted: "not reproduced (trial budget used up)", triage_timeout: "first-level triage limit (10 min) exceeded",
  admin_procedure_failed: "your version did not reproduce", no_search: "no search run", composed: "tests composed", no_sources: "nothing saved to compose from",
  no_valid_variants: "no valid variant", swept: "nearby variations tried", no_base: "nothing to vary", not_applicable_workload: "workload: needs the hardware bench",
  awaiting_hardware_bench: "awaiting the hardware bench", admitted: "regression test filed", rejected: "rejected", superseded: "replaced by a newer version",
  proposed: "proposed", proposal: "proposal (not run yet)", deprecated: "retired", active: "active", failed: "failed", pending: "pending",
  "admin-approved": "approved by a second admin", "validated-by-execution": "awaiting approval by a second admin" };
export const statusWord = (s) => s == null || s === "" ? "-" : (STATUS_WORD[s] || String(s).replace(/_/g, " "));
const MODE_WORD = { reuse: "saved procedure reused", adapt: "searched from the saved procedure", search: "searched from the evidence", generate: "searched from the evidence", admin_procedure: "your version, run as given",
  compose: "tests composed by the AI reviewer", sweep: "nearby variations tried", workload: "workload baseline" };
export const modeWord = (m) => m == null || m === "" ? "-" : (MODE_WORD[m] || String(m).replace(/_/g, " "));
const ACTION_WORD = { accept: "Accept", accept_with_note: "Accept with a note", add_cause: "Add a cause", add_procedure: "Add a procedure", reject: "Reject (not correct)",
  not_reproducible: "Could not be reproduced", revise: "Revise the text", rerank: "Record my ranking", prefer: "Prefer this one", tie: "Tie (no preference)", undo: "Undo a decision", promote: "Approve as second admin",
  deprecate: "Retire the procedure", skip: "Skip", defer: "Defer (keep in the queue)", escalate: "Needs more evidence", wrong_signature: "Dispute the stage-1 finding",
  delete_request: "Request deletion", delete_approve: "Approve the deletion (second admin)", duplicate_of: "Mark as a duplicate", link: "Link to another", split: "Split",
  lesson: "Record a lesson", restart_failed: "Restart the search after a failed attempt", sweep: "Try nearby variations", compose_tests: "Generate test cases" };
export const actionWord = (a) => a == null || a === "" ? "-" : (ACTION_WORD[a] || String(a).replace(/_/g, " "));
/* saved procedure status in the operator's words: "approved by <name>" / "awaiting approval by a second admin" */
export const procStatus = (status, by) => status === "admin-approved" ? (by ? "approved by " + by : "approved by a second admin") : status === "validated-by-execution" ? "awaiting approval by a second admin" : statusWord(status);
/* "procedure #ab12cd34": the first 8 characters of a stored procedure's hash, or of a "sol::…" / "scn::…" id */
export const procId = (id) => { const h = String(id || "").split("::").pop(); return h ? "procedure #" + h.slice(0, 8) : "-"; };

/* ---------------- packet flow graph ---------------- */
function parseRows(d) {
  const out = [];
  for (const b of d.rows || []) for (const r of b.rows) {
    const f = {}; r.split("|").forEach(kv => { const i = kv.indexOf("="); if (i > 0) f[kv.slice(0, i).trim()] = kv.slice(i + 1).trim(); });
    if (!f.Packet) continue;
    const ts = (f["Time Stamp"] || "").replace("s", ""), t = ts ? Math.round(parseFloat(ts) * 1e6) : null;   // µs
    const kind = f["TLP Type"] || f["DLLP Type"] || f["Ord.Set Type"] || f["Link Event"] || f["Event"] || "?";
    out.push({ p: +f.Packet, dir: f["Link Dir"] || "", kind, f, t, dllp: !!f["DLLP Type"] && !f["TLP Type"] });
  }
  return out;
}
function label(x) {
  const f = x.f, k = x.kind;
  if (/^Cpl/.test(k)) { const st = f["Cpl Status"]; return st && !/^SC/.test(st) ? `${k} · status ${st}` : `${k}${f.Tag ? " · tag " + f.Tag : ""}`; }
  if (/^Cfg/.test(k)) return `${k}${f.Register ? " · register " + f.Register : ""}`;
  if (/^(MRd|MWr|IORd|IOWr)/.test(k)) return `${k}${f.Address ? " · " + f.Address : ""}${f.Length ? " · " + f.Length + " DW" : ""}`;
  if (/^(ACK|NAK)/.test(k)) return `${k}${f["AckNak Seq Num"] ? " · seq " + f["AckNak Seq Num"] : ""}`;
  return k;
}
export function flowGraph(d, full) {
  const inc = d.incident, fa = (inc.first_abnormal || {}).pkt, ev = new Set(inc.evidence_packets || []);
  const all = parseRows(d);
  if (!all.length) return { html: "<p class=empty>No packet rows attached to this defect.</p>", n: 0, shown: 0 };
  let rows;
  if (full) rows = all.slice(0, 300);
  else {
    const key = all.filter(x => !x.dllp || x.p === fa || ev.has(x.p));
    let i0 = key.findIndex(x => x.p === fa); if (i0 < 0) i0 = Math.min(key.length - 1, 5);
    const s = Math.max(0, i0 - 5); rows = key.slice(s, s + 12);
  }
  const RH = 26, GAP = 22, X0 = 78, XH = 150, XD = 330, W = 720;
  const bands = []; let y = 30;
  rows.forEach((x, i) => {
    const prev = i ? rows[i - 1] : null, delta = prev && x.t != null && prev.t != null ? x.t - prev.t : null;
    const gap = delta != null && delta >= 1000;
    if (gap) { bands.push({ gap: true, y, h: GAP, delta }); y += GAP; }
    bands.push({ x, y, h: RH, delta }); y += RH;
  });
  const H = y + 8;
  let g = `<svg viewBox="0 0 ${W} ${H}" class="flow" role="img" aria-label="packet exchange between host and device, top to bottom in time">
    <text x="${X0 - 6}" y="16" text-anchor="end" class="hd">Δt</text><text x="${XH}" y="16" text-anchor="middle" class="hd">HOST</text><text x="${XD}" y="16" text-anchor="middle" class="hd">DEVICE</text><text x="${W - 6}" y="16" text-anchor="end" class="hd">packet</text>
    <line x1="${XH}" x2="${XH}" y1="22" y2="${H - 4}" class="lane"/><line x1="${XD}" x2="${XD}" y1="22" y2="${H - 4}" class="lane"/>`;
  for (const b of bands) {
    if (b.gap) { g += `<rect x="0" y="${b.y}" width="${W}" height="${b.h}" class="gapband"/><text x="${(XH + XD) / 2}" y="${b.y + 15}" text-anchor="middle" class="gaptxt">— ${dt(b.delta)} gap, no traffic —</text>`; continue; }
    const x = b.x, abn = x.p === fa, evd = ev.has(x.p), cy = b.y + b.h / 2, cls = abn ? "abn" : evd ? "evd" : x.dllp ? "dllp" : "";
    if (abn) g += `<rect x="0" y="${b.y}" width="${W}" height="${b.h}" class="abnband"/><text x="${W - 60}" y="${cy + 4}" text-anchor="end" class="abnmark">◂ first abnormal</text>`;
    g += `<text x="${X0 - 6}" y="${cy + 4}" text-anchor="end" class="dt">${b.delta == null ? "" : "+" + dt(b.delta)}</text>`;
    const down = x.dir === "Downstream", up = x.dir === "Upstream";
    if (down || up) g += `<line x1="${down ? XH : XD}" x2="${down ? XD - 8 : XH + 8}" y1="${cy}" y2="${cy}" class="arr ${cls}" marker-end="url(#m-${cls || "n"})"/>`;
    else g += `<circle cx="${(XH + XD) / 2}" cy="${cy}" r="4" class="dot ${cls}"/>`;
    g += `<text x="${XD + 20}" y="${cy + 4}" class="lbl ${cls}">${esc(label(x).slice(0, abn ? 30 : 40))}</text><text x="${W - 6}" y="${cy + 4}" text-anchor="end" class="pno">#${x.p}</text>`;
  }
  g += `<defs>${["n", "dllp", "evd", "abn"].map(c => `<marker id="m-${c}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="${c === "abn" ? 7 : 6}" markerHeight="${c === "abn" ? 7 : 6}" orient="auto"><path d="M0 0L10 5L0 10z" class="mk ${c}"/></marker>`).join("")}</defs></svg>`;
  return { html: `<div class="flowwrap">${g}</div>`, n: all.length, shown: rows.length };
}

/* ---------------- solution cards ---------------- */
export function titleOf(sol) {
  const ops = (sol.commands || []).map(c => OP_WORD[c] || c);
  const t = sol.timing || {};
  const seq = ops.length ? ops.length === 1 ? ops[0] : ops.slice(0, -1).join(", ") + ", then " + ops[ops.length - 1] : "no commands";
  const bits = [];
  if (t.inter_cmd_us != null && ops.length > 1) bits.push(usWord(t.inter_cmd_us) + " apart");
  if (t.idle_gap_ms) bits.push("idle " + msWord(t.idle_gap_ms));
  if (sol.power_state && sol.power_state !== "none") bits.push("in " + sol.power_state);
  const s = seq.charAt(0).toUpperCase() + seq.slice(1);
  return bits.length ? `${s} — ${bits.join(", ")}` : s;
}
function chipStrip(sol, diffFrom) {
  const cmds = sol.commands || [], t = sol.timing || {}, base = diffFrom ? (diffFrom.commands || []) : null;
  const gapTxt = t.inter_cmd_us != null ? usWord(t.inter_cmd_us) : "";
  let h = `<div class="chips-seq">`;
  cmds.forEach((c, i) => {
    const cls = base && base[i] !== c ? " changed" : "";
    if (i) h += `<span class="conn" title="time between commands"><i></i><small>${esc(gapTxt)}</small></span>`;
    h += `<span class="chipop${cls}"><small>${i + 1}</small>${esc(OP_WORD[c] || c)}</span>`;
  });
  if (base) base.slice(cmds.length).forEach(c => { h += `<span class="conn"><i></i></span><span class="chipop removed"><small>×</small>${esc(OP_WORD[c] || c)}</span>`; });
  if (!cmds.length) h += `<span class=muted>no commands</span>`;
  h += `</div><div class="tchips">`;
  for (const [k, w, u] of TIMING_KEYS) { if (t[k] == null) continue; const ch = diffFrom && diffFrom.timing && diffFrom.timing[k] !== t[k] ? " changed" : ""; h += `<span class="tchip${ch}" title="tunable timing parameter">${esc(w)} <b>${k === "idle_gap_ms" ? esc(msWord(t[k])) : k === "inter_cmd_us" ? esc(usWord(t[k])) : esc(t[k] + (u ? " " + u : ""))}</b></span>`; }
  const pw = sol.power_state || "none", pch = diffFrom && (diffFrom.power_state || "none") !== pw ? " changed" : "";
  h += `<span class="tchip${pch}">power state <b>${esc(pw)}</b></span></div>`;
  return h;
}
function provenance(sol) {
  const f = sol.feedback || {}, parts = [];
  if (sol.status === "proposal") { parts.push("Proposed now by the AI reviewer from these packets; not run yet"); }
  else {
    parts.push(sol.source.startsWith("database: approved for this error") ? "Saved in the knowledge base for this error type" : sol.source.startsWith("database: validated") ? "Validated in the lab, awaiting approval by a second admin" : esc(sol.source.replace(/^database: approved for /, "Saved in the knowledge base for error type ")));
    if (sol.approved_by) parts.push("approved by " + esc(sol.approved_by));
    if (sol.repro_lower95 != null) parts.push(`<b>reproduced in at least ${pct(sol.repro_lower95)} of lab runs (${likelihood(sol.repro_lower95)})</b>`);
    if (f.n) parts.push(`admins said Correct ${f.positive} time${f.positive === 1 ? "" : "s"}, Not correct ${f.negative} time${f.negative === 1 ? "" : "s"}`);
    if (sol.tests) parts.push(`${sol.tests} regression test${sol.tests > 1 ? "s" : ""} generated`);
  }
  return parts.join(" · ");
}
function producerWord(p) { return !p ? "the search" : p === "admin" ? "an admin" : /llm|optimizer|search/.test(p) ? "the search (AI reviewer proposal, refined in the lab)" : p === "compose" ? "test composition" : p === "sweep" ? "the sweep" : p; }
function metaLine(sol) {
  const h = sol.history; if (!h) return "";
  const parts = [];
  if (h.proposed_at) parts.push(`Proposed ${when(h.proposed_at)} by ${esc(h.proposed_operator ? h.proposed_operator + ", via " + producerWord(h.proposed_by) : producerWord(h.proposed_by))}${h.proposed_on_device ? " on " + esc(h.proposed_on_device) : ""}${h.proposed_for_defect ? " for " + esc(defectName(h.proposed_for_defect)) + (h.proposed_in_run ? " of run " + esc(h.proposed_in_run) : "") : ""}`);
  if (h.validated_at) parts.push(`last reproduced in the lab ${when(h.validated_at)}${h.validated_on_device ? " on " + esc(h.validated_on_device) : ""}${h.validated_firmware ? " (firmware " + esc(h.validated_firmware) + ")" : ""}${h.validations > 1 ? ", " + h.validations + " lab validations in all" : ""}`);
  if (h.approved_at) parts.push(`approved ${when(h.approved_at)} by ${esc(h.approved_by || "a second admin")}`);
  const last = (h.decisions || []).slice(-1)[0];
  if (last) parts.push(`last judged ${when(last.at)} by ${esc(last.by)}: ${esc(actionWord(last.action))}${last.device ? " on " + esc(last.device) : ""}`);
  if (h.devices && h.devices.length > 1) parts.push(`seen on ${h.devices.length} devices: ${esc(h.devices.join(", "))}`);
  if (h.last_test_at) parts.push(`last regression test written ${when(h.last_test_at)}`);
  return `<div class="metaline">${parts.length ? parts.join(" · ") : "no dates recorded for this procedure yet"}</div>`;
}
function why(sol, sols) {
  if (sol.status === "proposal") return `<p>${esc(sol.mechanism || sols.llm_mechanism || "")}</p><p class="help">Key packets: ${(sol.key_packets || []).map(p => "#" + p).join(", ") || "-"}. The AI reviewer read the evidence rows and the rule text and proposed this procedure; nothing has been run yet. "Correct" runs it in the lab first and keeps it only if it reproduces the defect.</p>`;
  const ld = sol.last_decision;
  return `<p>This procedure is saved under this error type in the knowledge base (<b>${esc(procStatus(sol.status, sol.approved_by))}</b>). ${sol.repro_lower95 != null ? `When it was validated it reproduced the defect in at least ${pct(sol.repro_lower95)} of lab runs (${likelihood(sol.repro_lower95)}).` : ""} ${sol.feedback && sol.feedback.n ? `Admins judged it ${sol.feedback.positive} time(s) correct and ${sol.feedback.negative} time(s) not correct.` : "No admin judgement on it yet."}</p>${ld ? `<p class="help">Last decision: <b>${esc(actionWord(ld.action))}</b> by ${esc(ld.actor)}${ld.note ? ` — "${esc(ld.note)}"` : ""}.</p>` : ""}<p class="help">"Correct" re-runs it first as a safety check; if it still reproduces the defect it is reused without a new search and the regression test is written from it.</p>`;
}

export function render(el, ctx) {
  const { detail, sols, act, engineer, key } = ctx;
  el._act = act;
  const inc = detail.incident, fa = inc.first_abnormal || {};
  const pend = PENDING.get(key) || { removed: new Map(), order: null, shown: new Set() };
  PENDING.set(key, pend);
  const ids = sols.solutions.map(s => s.id);
  for (const id of [...pend.removed.keys()]) if (!ids.includes(id)) pend.removed.delete(id);
  let order = pend.order && pend.order.length === ids.length && pend.order.every(i => ids.includes(i)) ? [...pend.order] : [...ids];
  const live = { correct: 0, corrected: 0 };
  // identical procedures (same commands, timing and power state) are shown once: the best-evidenced card stays, the others fold into it
  const fpOf = (s) => JSON.stringify([(s.commands || []).map(c => c.op || c), s.timing || {}, s.power_state || "none"]);
  const EVIDENCE = { "admin-approved": 3, "validated-by-execution": 2, proposal: 1 };
  const folded = new Map(), dupOf = new Map();                      // hidden id -> kept id ; kept id -> [hidden solutions]
  { const best = new Map();
    for (const s of sols.solutions) { const k = fpOf(s), b = best.get(k); if (!b || (EVIDENCE[s.status] || 0) > (EVIDENCE[b.status] || 0)) best.set(k, s); }
    for (const s of sols.solutions) { const b = best.get(fpOf(s)); if (b && b.id !== s.id) { folded.set(s.id, b.id); if (!dupOf.has(b.id)) dupOf.set(b.id, []); dupOf.get(b.id).push(s); } } }
  const visible = sols.solutions.filter(s => !folded.has(s.id));
  const stored = visible.filter(s => s.status !== "proposal").length, llm = visible.length - stored;
  const top = visible[0];
  const cand = ((inc.atlas_candidates || [])[0]) || {};
  const proposedLine = !visible.length ? "Nothing to judge: no saved procedure and no proposal." :
    `${visible.length} reproduction${visible.length > 1 ? "s" : ""} proposed${stored ? ` (${stored} saved in the knowledge base${llm ? `, ${llm} new from the AI reviewer` : ""})` : " (new, from the AI reviewer)"}` +
    (top && top.repro_lower95 != null ? `; the top one reproduced the defect in at least ${pct(top.repro_lower95)} of lab runs (${likelihood(top.repro_lower95)}).` : ".");
  el.innerHTML = `
    <div class="bluf">
      <div><span class="k">What the packets showed</span><span class="v">${esc(errorTypeFull(cand.card_id, cand.title))}. ${esc(sols.llm_headline || fa.detail || "")}</span></div>
      <div><span class="k">What is proposed</span><span class="v">${esc(proposedLine)}</span></div>
      <div><span class="k">Your decision</span><span class="v" id="bluf-decision"></span></div>
    </div>
    <section class="dsec"><h3 class="dh">What the packets showed</h3>
      <div id="flow-box"></div>
      <p class="help">Time runs top to bottom; Δt is the time since the previous row. <span class="sw abn">Shaded</span> = first abnormal packet (#${esc(fa.pkt)}: ${esc(fa.detail)}), <span class="sw evd">blue</span> = evidence, grey = link-layer acknowledgements. <button class="linklike" id="flow-toggle"></button></p>
    </section>
    <section class="dsec"><h3 class="dh">Proposed reproductions</h3>
      <p class="help">Drag to rank, best first${visible.filter(s => s.id.startsWith("sol::")).length < 2 ? " (the order is recorded once two or more different saved procedures exist)" : ""}. Judge each one: <b>Correct</b> runs it in the lab and writes the regression test · <b>Needs changes</b> opens it for editing · <b>Not correct</b> removes it (undo any time). A procedure validated in the lab stays "awaiting approval by a second admin" until a <b>second admin</b> approves it (two-person rule).</p>
      <div id="sol-list" class="sols"></div>
      <div class="sr-only" aria-live="polite" id="sol-live"></div>
    </section>
    <section class="dsec" id="dsec-compose"><h3 class="dh">Generate test cases from the knowledge base</h3>
      <p class="help" id="compose-text"></p>
      <div class="row"><button class="primary" id="btn-compose">Generate test cases — the AI reviewer composes them from the saved procedures</button><span class="muted small" id="compose-note"></span></div>
    </section>
    <section class="dsec" id="dsec-sweep" hidden><h3 class="dh">Failure-prone conditions — try nearby variations</h3>
      <p class="help">Around the reproducing procedure, each timing value is tried at half and at double, every other power state, a doubled burst, and injected link faults when the bench can inject them. Variations that still reproduce the defect are the <b>failure-prone conditions</b>; the most stressful ones are filed as regression tests (never approved automatically).</p>
      <div class="row"><button class="primary" id="btn-sweep">Try nearby variations</button><span class="muted small">a few minutes: up to 15 variations × 3 lab runs each, then the lab check on known-bad and fixed firmware for the top 3</span></div>
    </section>
    <section class="dsec" id="dsec-result" hidden><h3 class="dh">Result</h3><div id="d-result-box"></div></section>
    <div class="dfoot" id="dfoot"><span id="dfoot-sum"></span><button class="primary" id="btn-save-decisions">Save decisions</button></div>`;
  // generate test case from the stored knowledge (LLM composition, validated by execution)
  const nS = sols.stored_count || 0, nF = sols.family_count || 0, cbtn = el.querySelector("#btn-compose");
  el.querySelector("#compose-text").innerHTML = nS ? `The database holds <b>${nS}</b> correct / optimised sequence${nS > 1 ? "s" : ""} (saved procedure${nS > 1 ? "s" : ""}) for this error type${nF ? ` (and ${nF} from the same error family)` : ""}. The AI reviewer composes up to three test variants from them that recreate the defect — a robust recreation, the same trigger at its timing boundary, and a different path to the same state. Each variant is run in the lab, kept only if the analyser finds this defect, and filed as a regression test that names its sources and why. Nothing is approved automatically.`
    : `No saved sequence for this error type yet. Judge one <b>Correct</b> first (or save a corrected version); then the AI reviewer can compose tests from it.`;
  const workload = sols.layer === "workload";
  if (workload) { el.querySelector("#compose-text").innerHTML = "This defect comes from a workload tool's record (ADK / PCMark), not from a command sequence: generating test variants and trying nearby variations need lab runs of that workload, which only the hardware bench provides. On Correct, the baseline workload is filed as a proposed test."; }
  cbtn.disabled = !nS || workload;
  el.querySelector("#compose-note").textContent = nS ? "takes a few minutes: the AI reviewer, then up to three variants with six lab runs each, then the lab check on known-bad and fixed firmware" : "";
  cbtn.onclick = () => { cbtn.disabled = true; act("compose", null, {}); };
  const swsec = el.querySelector("#dsec-sweep"), swbtn = el.querySelector("#btn-sweep");
  swsec.hidden = !nS || workload;                       // a sweep needs a reproducing procedure in the database and a bench that runs it
  swbtn.onclick = () => { swbtn.disabled = true; act("sweep", null, {}); };
  // flow graph with the disclosure control
  let full = false; const fbox = el.querySelector("#flow-box"), ftog = el.querySelector("#flow-toggle");
  const drawFlow = () => { const r = flowGraph(detail, full); fbox.innerHTML = r.html; ftog.textContent = full ? `Show the ${r.shown} key packets only` : `Show the full exchange (${r.n} packets)`; ftog.hidden = r.n <= 12; };
  ftog.onclick = () => { full = !full; drawFlow(); }; drawFlow();

  const list = el.querySelector("#sol-list"), liveEl = el.querySelector("#sol-live");
  // a ranking is recorded only between stored procedures that are SHOWN: an identical copy folded into another card
  // is not a second procedure to rank (found 2026-11-08: one visible card + its hidden copy claimed "a new ranking not
  // yet saved" after the AI proposal was moved, and Save recorded a meaningless rerank)
  const storedOrder = o => o.filter(i => i.startsWith("sol::") && !folded.has(i)).join();
  const rankable = ids.filter(i => i.startsWith("sol::") && !folded.has(i)).length >= 2;
  if (!document.body.dataset.menuClose) { document.body.dataset.menuClose = "1"; document.addEventListener("click", e => { if (!e.target.closest("details.menu")) document.querySelectorAll("#sol-list details.menu[open]").forEach(d => d.open = false); }); }
  const summary = () => {
    const earlierOut = order.filter(i => { const s = sols.solutions.find(x => x.id === i); return s && !folded.has(i) && s.status === "proposal" && s.last_decision && s.last_decision.polarity === "negative" && !pend.shown.has(i); }).length;
    const removed = pend.removed.size, und = order.length - folded.size - removed - earlierOut - live.correct - live.corrected;
    const earlier = sols.solutions.reduce((a, s) => { const f = s.feedback || {}; return [a[0] + (f.positive || 0), a[1] + (f.negative || 0)]; }, [0, 0]);
    el.querySelector("#bluf-decision").textContent = (order.length - folded.size > 0 ? `${live.correct} correct · ${live.corrected} corrected · ${removed} removed · ${Math.max(0, und)} undecided` : "nothing to decide")
      + (earlier[0] + earlier[1] ? ` · earlier decisions on this error type: ${earlier[0]} correct, ${earlier[1]} not correct` : "");
    const reordered = rankable && !!pend.order && storedOrder(pend.order) !== storedOrder(ids);   // only the stored procedures' order is a ranking
    const n = removed + (reordered ? 1 : 0);
    el.querySelector("#dfoot-sum").textContent = n ? `${removed ? removed + " removal" + (removed > 1 ? "s" : "") : ""}${removed && reordered ? " and " : ""}${reordered ? "a new ranking" : ""} not yet saved` : "Correct and Save corrected version apply at once; removals and ranking are saved together.";
    el.querySelector("#btn-save-decisions").disabled = !n;
  };
  async function commitPending() {
    for (const [id, r] of [...pend.removed.entries()]) { const sol = sols.solutions.find(s => s.id === id); if (sol) await act("reject", sol, { note: r.note, retire: r.retire, quiet: true }); }
    const reordered = rankable && !!pend.order && storedOrder(pend.order) !== storedOrder(ids);
    if (reordered) await act("rerank", null, { order: pend.order.filter(i => !pend.removed.has(i)), quiet: true });
    pend.removed.clear(); pend.order = null;
  }
  el.querySelector("#btn-save-decisions").onclick = async () => { await commitPending(); toast("decisions saved"); ctx.refresh(); };
  const move = (id, to, fromHandle) => {
    const a = order.indexOf(id); if (a < 0) return; to = Math.max(0, Math.min(order.length - 1, to)); if (to === a) return;
    order.splice(a, 1); order.splice(to, 0, id); pend.order = [...order]; draw();
    const sol = sols.solutions.find(s => s.id === id); liveEl.textContent = `${titleOf(sol)} moved to rank ${to + 1} of ${order.length}, from rank ${a + 1}.`;
    if (fromHandle) { const h = list.querySelector(`[data-id="${CSS.escape(id)}"] .handle`); if (h) h.focus(); }
  };
  function draw() {
    list.innerHTML = ""; let shownRank = 0;
    order.forEach((id, i) => {
      const sol = sols.solutions.find(s => s.id === id); if (!sol || folded.has(id)) return;
      const rank = ++shownRank;
      const card = document.createElement("article"); card.dataset.id = id; card.tabIndex = 0;
      const rm = pend.removed.get(id);
      if (rm) {
        card.className = "solcard stub";
        const custom = rm.note && !REASONS.includes(rm.note) ? rm.note : "";
        card.innerHTML = `<div class="stubrow"><span class="rank">${rank}</span><span class="muted">Removed — ${esc(titleOf(sol))}${rm.note ? ` · <i>${esc(rm.note)}</i>` : ""}</span><button class="small btn-undo">Undo</button></div>
          <div class="reasons">${REASONS.map(r => `<button class="small rchip${rm.note === r ? " on" : ""}">${r}</button>`).join("")}<input class="rnote" placeholder="or say why in your words (saved with the decision)" value="${esc(custom)}">
            ${sol.status === "admin-approved" ? `<label class="inline small"><input type="checkbox" class="retire" ${rm.retire ? "checked" : ""}> also retire it from the knowledge base (needs a second admin)</label>` : ""}</div>`;
        card.querySelector(".btn-undo").onclick = () => { pend.removed.delete(id); draw(); };
        card.querySelectorAll(".rchip").forEach(b => b.onclick = () => { rm.note = b.textContent; draw(); });
        card.querySelector(".rnote").onchange = (e) => { rm.note = e.target.value; draw(); };
        const rt = card.querySelector(".retire"); if (rt) rt.onchange = (e) => rm.retire = e.target.checked;
        list.appendChild(card); return;
      }
      const neg = sol.last_decision && sol.last_decision.polarity === "negative";
      if (sol.status === "proposal" && neg && !pend.shown.has(id)) {
        card.className = "solcard stub earlier";
        card.innerHTML = `<div class="stubrow"><span class="rank">${rank}</span><span class="muted">Marked <b>not correct</b> earlier by ${esc(sol.last_decision.actor)} — ${esc(titleOf(sol))}${sol.last_decision.note ? ` · <i>${esc(String(sol.last_decision.note).replace(/^NOT CORRECT:.*\)\s*—\s*/, ""))}</i>` : ""}</span><button class="small btn-show">Show it again</button></div>`;
        card.querySelector(".btn-show").onclick = () => { pend.shown.add(id); draw(); };
        list.appendChild(card); return;
      }
      card.className = "solcard" + (sol.status === "proposal" ? " proposal" : sol.status === "admin-approved" ? " approved" : "");
      const dups = dupOf.get(id) || [];
      const dupNote = dups.map(d => d.status === "validated-by-execution" ? "also validated again in the lab on a later attempt, not yet approved" : d.status === "proposal" ? "the AI reviewer proposed this same procedure again now" : "also saved and approved a second time").filter((t, k, arr) => arr.indexOf(t) === k).join("; ");
      const approveSol = sol.status === "validated-by-execution" ? sol : dups.find(d => d.status === "validated-by-execution") || null;
      card.innerHTML = `<div class="solhead"><span class="handle" draggable="true" tabindex="0" role="button" aria-label="drag handle: press up or down arrow to move" title="drag to rank (or use the … menu)">⋮⋮</span><span class="rank">${rank}</span>
          <div class="ttl"><div class="t1">${esc(titleOf(sol))}</div><div class="src">${provenance(sol)}</div>${metaLine(sol)}</div>
          <details class="menu"><summary aria-label="more actions">…</summary><div class="menubox">
            <button data-m="top">Move to top</button><button data-m="up">Move up</button><button data-m="down">Move down</button><button data-m="bottom">Move to bottom</button><hr>
            <button data-m="why">Why is this proposed?</button><button data-m="eng">All details</button></div></details></div>
        ${neg ? `<div class="callout small">An admin rejected it once${sol.last_decision.note ? " with the note: " + esc(sol.last_decision.note) : "."}</div>` : ""}
        ${dupNote ? `<div class="help">${esc(dupNote)}</div>` : ""}
        ${chipStrip(sol)}
        <div class="whybox" hidden></div>
        <div class="verdicts">${approveSol ? `<button class="v approve" data-v="approve" title="two-person rule: a second admin approves">Approve as second admin</button>` : ""}<button class="v no" data-v="wrong"><kbd>3</kbd>Not correct</button><button class="v edit" data-v="partial"><kbd>2</kbd>Needs changes</button><button class="v ok primary" data-v="correct"><kbd>1</kbd>Correct</button></div>
        <div class="editor" hidden></div>`;
      const menu = card.querySelector("details.menu");
      card.querySelectorAll(".menubox button").forEach(b => b.onclick = () => { menu.open = false; const m = b.dataset.m;
        if (m === "top") move(id, 0); else if (m === "up") move(id, i - 1); else if (m === "down") move(id, i + 1); else if (m === "bottom") move(id, order.length - 1);
        else if (m === "why") { const w = card.querySelector(".whybox"); w.hidden = !w.hidden; if (!w.hidden) w.innerHTML = why(sol, sols); }
        else if (m === "eng") engineer(); });
      card.querySelectorAll("button[data-v]").forEach(b => b.onclick = () => verdict(card, b.dataset.v === "approve" && approveSol ? approveSol : sol, b.dataset.v));
      card.addEventListener("keydown", e => { if (e.target.closest("input,select,textarea") || pend.removed.has(id)) return; if (e.key === "1") verdict(card, sol, "correct"); else if (e.key === "2") verdict(card, sol, "partial"); else if (e.key === "3") verdict(card, sol, "wrong"); });
      const h = card.querySelector(".handle");
      h.addEventListener("keydown", e => { if (e.key === "ArrowUp") { e.preventDefault(); move(id, i - 1, true); } else if (e.key === "ArrowDown") { e.preventDefault(); move(id, i + 1, true); } });
      h.addEventListener("dragstart", e => { e.dataTransfer.setData("text/plain", id); card.classList.add("drag"); });
      h.addEventListener("dragend", () => card.classList.remove("drag"));
      card.addEventListener("dragover", e => { e.preventDefault(); card.classList.add("over"); });
      card.addEventListener("dragleave", () => card.classList.remove("over"));
      card.addEventListener("drop", e => { e.preventDefault(); card.classList.remove("over"); const from = e.dataTransfer.getData("text/plain"); if (from && from !== id) move(from, order.indexOf(id)); });
      list.appendChild(card);
    });
    if (!shownRank) list.innerHTML = `<p class=empty>No candidate to judge. Open "All details" to add a cause or a procedure by hand.</p>`;
    summary();
  }
  function verdict(card, sol, v) {
    if (v === "approve") {
      const who = prompt("Name of the second admin who approves this procedure (must differ from the requester):", "");
      if (!who || !who.trim()) return;
      card.querySelectorAll("button").forEach(b => b.disabled = true);
      act("promote", sol, { approver: who.trim() }); return;
    }
    if (v === "wrong") { pend.removed.set(sol.id, { note: "", retire: false }); draw(); toast("removed — undo on the card, or Save decisions to record it", 5000); return; }
    if (v === "correct") {
      card.querySelectorAll("button").forEach(b => b.disabled = true); live.correct++; summary();
      commitPending().then(() => act("accept", sol, {})); return;
    }
    // needs changes -> in-place correction: Stored (read-only) vs Your version (editable)
    const box = card.querySelector(".editor"); box.hidden = false;
    const st = { commands: [...(sol.commands || [])], timing: Object.assign({ qd: 8, inter_cmd_us: 50, bs_kb: 4, burst_len: 16, idle_gap_ms: 0 }, sol.timing || {}), power_state: sol.power_state || "none" };
    const drawEd = () => {
      const base = sol.commands || [], bt = sol.timing || {};
      const nChanged = st.commands.filter((c, i) => base[i] !== c).length + Math.max(0, base.length - st.commands.length)
        + TIMING_KEYS.filter(([k]) => bt[k] != null && bt[k] !== st.timing[k]).length + ((sol.power_state || "none") !== st.power_state ? 1 : 0);
      box.innerHTML = `<div class="edrow"><span class="edlbl">Stored</span><div>${chipStrip(sol)}</div></div>
        <div class="edrow yours"><span class="edlbl">Your version <small>${nChanged} change${nChanged === 1 ? "" : "s"}</small></span><div>
          <div class="chips-seq edit">${st.commands.map((c, i) => `<span class="chipop rm${base[i] !== c ? " changed" : ""}" data-i="${i}" title="click to remove"><small>${i + 1}</small>${esc(OP_WORD[c] || c)} ✕</span>`).join('<span class="conn"><i></i></span>')}
            <select class="addop" aria-label="command to add">${OPS.map(o => `<option value="${o}">${OP_WORD[o]}</option>`).join("")}</select><button class="small add">+ add</button></div>
          <div class="trow">${TIMING_KEYS.map(([k, w, u]) => `<label>${w}${u ? " (" + u + ")" : ""}<input class="t${bt[k] != null && bt[k] !== st.timing[k] ? " changed" : ""}" data-k="${k}" type="number" min="${k === "idle_gap_ms" ? 0 : 1}" value="${st.timing[k]}"></label>`).join("")}
            <label>power state<select class="pw${(sol.power_state || "none") !== st.power_state ? " changed" : ""}">${["none", "L1", "L1.2", "D3hot", "APST"].map(o => `<option ${o === st.power_state ? "selected" : ""}>${o}</option>`).join("")}</select></label></div></div></div>
        <div class="edfoot"><span class="muted small">Your version is run in the lab first and saved only if it reproduces the defect; you are recorded as its author.</span><button class="small discard">Discard my edits</button><button class="primary save">Save corrected version</button></div>`;
      box.querySelectorAll(".chipop.rm").forEach(e => e.onclick = () => { st.commands.splice(+e.dataset.i, 1); drawEd(); });
      box.querySelector(".add").onclick = () => { st.commands.push(box.querySelector(".addop").value); drawEd(); };
      box.querySelectorAll("input.t").forEach(e => e.onchange = () => { st.timing[e.dataset.k] = +e.value; drawEd(); });
      box.querySelector(".pw").onchange = (e) => { st.power_state = e.target.value; drawEd(); };
      box.querySelector(".discard").onclick = () => box.hidden = true;
      box.querySelector(".save").onclick = () => { if (!st.commands.length) return toast("add at least one command"); if (!nChanged) return toast("nothing changed — use Correct if it is right as saved");
        card.querySelectorAll("button").forEach(b => b.disabled = true); live.corrected++; summary();
        commitPending().then(() => act("procedure", sol, { scenario: { commands: st.commands.map(op => ({ op })), timing: st.timing, power_state: st.power_state } })); };
    };
    drawEd();
  }
  draw();
}

function renderComposed(box, r) {
  const vs = r.variants || [], srcs = r.sources || [];
  const head = r.status === "composed" ? (r.admitted ? ["ok", "✓ Test cases composed from the stored knowledge — " + vs.filter(v => v.admitted).length + " filed as regression tests"] : ["warn", "! Variants reproduced the defect, but the lab check on known-bad and fixed firmware passed none"])
    : r.status === "no_sources" ? ["bad", "✕ Nothing stored for this error type yet"] : r.status === "no_valid_variants" ? ["bad", "✕ The AI reviewer returned no valid variant"] : ["bad", "✕ No composed variant reproduced the defect in the lab"];
  box.innerHTML = `<div class="solcard ${head[0] === "ok" ? "approved" : ""}"><div class="vline ${head[0]}">${head[1]}</div>
    ${r.llm_summary ? `<p class="lead" style="font-size:14px">${esc(r.llm_summary)}</p>` : ""}
    <div class="help">Composed from ${srcs.length} stored sequence${srcs.length === 1 ? "" : "s"}: ${srcs.map(s => `<span class="mono">${esc(procId(s.vhash))}</span> (from ${esc(s.origin)}, ${esc(procStatus(s.status, s.approved_by))})`).join(", ") || "-"} · ${r.trials} lab runs · ${fmt((r.llm_s || 0), 0)} s AI reviewer + ${fmt((r.search_s || 0) + (r.verify_s || 0), 0)} s lab${(r.proposal_problems || []).length ? ` · corrected by the analyser's checks: ${esc(r.proposal_problems.join("; ")).slice(0, 200)}` : ""}</div>
    <div class="sols" style="margin-top:8px">${vs.map((v, i) => { const sc = { commands: (v.scenario.commands || []).map(c => c.op || c), timing: v.scenario.timing, power_state: v.scenario.power_state };
      const cl = v.closed_loop, st = v.admitted ? ["ok", "✓ reproduced and filed"] : v.confirmed ? ["warn", "! reproduced, but not passed by the lab check on known-bad and fixed firmware"] : ["bad", "✕ did not reproduce"];
      const files = (v.test_files || []).filter(f => f.endsWith(".py"));
      return `<article class="solcard ${v.admitted ? "approved" : ""}"><div class="solhead"><span class="rank">${i + 1}</span><div class="ttl"><div class="t1">${esc(v.name)}${v.adapted ? " <span class=muted>(adapted by the search)</span>" : ""}</div><div class="src"><span class="${st[0] === "ok" ? "ok" : st[0] === "warn" ? "warn" : "bad"}">${st[1]}</span> · reproduced ${v.repro_k} of ${v.repro_n} lab runs (at least ${pct(v.repro_lower95)}, ${likelihood(v.repro_lower95)})${cl ? ` · the analyser found the same defect in ${cl.known_bad_hits} of ${cl.known_bad_n} lab runs on known-bad firmware and in ${cl.fixed_hits} of ${cl.fixed_n} on fixed firmware` : ""}</div></div></div>
        ${chipStrip(sc)}<p class="help">${esc(v.rationale)}${(v.expected_packets || []).length ? ` · expected on the analyzer: ${esc(v.expected_packets.join(", "))}` : ""}${(v.sources_used || []).length ? ` · built from ${v.sources_used.map(x => esc(procId(x))).join(", ")}` : ""}</p>
        ${files.length ? `<div><b>Test script:</b> ${files.map(f => `<a href="/api/suite/${encodeURIComponent((v.test_dir || "").split("/").pop())}/${encodeURIComponent(f)}" target=_blank>${esc(f)}</a>`).join(", ")} <span class="muted small">(plus manifest.json, which lists the sources, and conftest.py)</span></div>` : ""}</article>`; }).join("")}</div>
    <p class="help">Filed variants are <b>validated by running them in the lab</b> and listed under this error type as "awaiting approval by a second admin"; approving one as the procedure stays a two-person decision.</p></div>`;
}

function renderSwept(box, r) {
  const vs = r.variants || [];
  const head = r.status === "no_base" ? ["bad", "✕ Nothing to vary: no reproducing procedure saved for this error type yet"] : (r.failure_prone || []).length ? ["ok", `✓ ${r.failure_prone.length} failure-prone condition${r.failure_prone.length === 1 ? "" : "s"} found near the procedure — ${(r.most_stressful || []).length} filed as regression tests`] : ["warn", "! No nearby variation reproduced the defect (only this exact procedure triggers it)"];
  box.innerHTML = `<div class="solcard ${head[0] === "ok" ? "approved" : ""}"><div class="vline ${head[0]}">${head[1]}</div>
    <div class="help">${r.trials} lab runs · ${esc(r.jammer || "")}${r.triage_timeout ? " · first-level triage limit (10 min) reached" : ""}</div>
    <table style="margin-top:8px"><thead><tr><th>Variation</th><th>Reproduced (lab runs)</th><th>Failure-prone</th><th>How far it was pushed</th><th>Regression test filed</th></tr></thead><tbody>
    ${vs.map(v => `<tr class="${v.failure_prone ? "" : "muted"}"><td>${esc(v.name)}${v.skipped ? ` <span class=muted>(${esc(v.skipped)})</span>` : ""}</td><td class=mono>${v.n ? `${v.hits} of ${v.n}` : "-"}</td><td>${v.failure_prone ? "<b class=bad>yes</b>" : "no"}</td><td class=mono>${v.stress != null ? fmt(v.stress, 1) + "×" : "-"}</td><td>${v.admitted ? `✓ ${(v.test_files || []).filter(f => f.endsWith(".py")).map(f => `<a href="/api/suite/${encodeURIComponent((v.test_dir || "").split("/").pop())}/${encodeURIComponent(f)}" target=_blank>${esc(f)}</a>`).join(", ")}` : v.vhash ? "validated, no test filed" : ""}</td></tr>`).join("")}</tbody></table>
    <p class="help">The most stressful failure-prone variations (by reproduction count, then by how far they push the value) become regression tests next to the procedure's own test.</p></div>`;
}
function renderWorkload(box, r) {
  const sc = r.best ? { commands: (r.best.commands || []).map(c => c.op || c), timing: r.best.timing, power_state: r.best.power_state } : null;
  box.innerHTML = `<div class="solcard"><div class="vline warn">! Baseline workload filed as a proposed test — only the hardware bench can run the workload</div>
    ${sc ? `<div class="t1">${esc(titleOf(sc))}</div>${chipStrip(sc)}` : ""}<p class="help">${esc(r.note || "")}</p>
    ${(r.test_files || []).length ? `<div><b>Proposed test:</b> ${(r.test_files || []).filter(f => f.endsWith(".py")).map(f => `<a href="/api/suite/${encodeURIComponent((r.test_dir || "").split("/").pop())}/${encodeURIComponent(f)}" target=_blank>${esc(f)}</a>`).join(", ")} <span class="muted small">(manifest.json carries the workload's settings and the failure signature, the fingerprint of the defect)</span></div>` : ""}</div>`;
}
export function renderResult(el, r) {
  const sec = el.querySelector("#dsec-result"), box = el.querySelector("#d-result-box");
  if (!sec || !r || r.status === "no_search") return;
  sec.hidden = false;
  if (r.mode === "compose") { renderComposed(box, r); return; }
  if (r.mode === "sweep") { renderSwept(box, r); return; }
  if (r.mode === "workload") { renderWorkload(box, r); return; }
  const stressFiles = ((r.stress || {}).test_files || []).filter(f => f.endsWith(".py"));
  const cl = r.closed_loop, files = (r.test_files || []).filter(f => f.endsWith(".py") && !stressFiles.includes(f));
  const head = r.admitted ? ["ok", "Reproduced and checked — regression test written"]
    : (r.status === "confirmed" || r.status === "reused_validated") && !r.closed_loop ? ["warn", `Reproduced in ${r.repro_k != null ? r.repro_k + " of " + r.repro_n + " lab runs" : "the lab"}, too few for the lab check (it needs a safe estimate of at least 50 %: 6 of 6 with six runs), so no check ran and no test was filed — press Correct on it to confirm it with more runs`]
    : (r.status === "confirmed" || r.status === "reused_validated") ? ["warn", "Reproduced, but the lab check on known-bad and fixed firmware did not pass it, so no test was filed"] : ["bad", "Not reproduced within the limits"];
  const best = r.best ? { commands: (r.best.commands || []).map(c => c.op || c), timing: r.best.timing, power_state: r.best.power_state } : null;
  const yours = r.action === "add_procedure" ? (r.mode === "admin_procedure" ? `<div class="callout small">Your version reproduced the defect ${r.repro_k != null ? "in " + r.repro_k + " of " + r.repro_n + " lab runs" : "in the lab"} and was saved under your name.</div>`
    : r.mode === "adapt" ? `<div class="callout small">Your version did <b>not</b> reproduce the defect reliably${r.admin_procedure_k != null ? ` (${r.admin_procedure_k} of ${r.admin_procedure_n} lab runs)` : ""}; it is recorded as failed validation. The lab searched from it and found the version below.</div>` : "") : "";
  box.innerHTML = `<div class="solcard ${head[0] === "ok" ? "approved" : ""}"><div class="vline ${head[0]}">${head[0] === "ok" ? "✓" : head[0] === "warn" ? "!" : "✕"} ${head[1]}</div>${yours}
    ${best ? `<div class="t1">${esc(titleOf(best))}</div>${chipStrip(best)}` : ""}
    <div class="help">${r.trials} lab run${r.trials === 1 ? "" : "s"}${r.attempt ? ` (attempt ${r.attempt + 1})` : ""}${r.repro_lower95 != null ? ` · reproduced in at least ${pct(r.repro_lower95)} of runs (${likelihood(r.repro_lower95)})` : ""}${cl ? ` · the analyser found the same defect in ${cl.known_bad_hits} of ${cl.known_bad_n} lab runs on known-bad firmware and in ${cl.fixed_hits} of ${cl.fixed_n} on fixed firmware` : ""}${r.triage_timeout ? " · first-level triage limit (10 min) exceeded" : ""} · ${fmt((r.search_s || 0) + (r.verify_s || 0), 0)} s</div>
    ${r.search ? `<div class="help"><b>How the search went:</b> ${esc(searchWords(r))}</div>` : ""}
    ${r.stress ? `<div class="help"><b>Most stressful conditions:</b> ${esc(stressWords(r))}${r.stress.differs && r.stress.scenario ? chipStrip({ commands: (r.stress.scenario.commands || []).map(c => c.op || c), timing: r.stress.scenario.timing, power_state: r.stress.scenario.power_state }, best) : ""}${stressFiles.length ? `<div><b>Margin test script:</b> ${stressFiles.map(f => `<a href="/api/suite/${encodeURIComponent((r.stress.test_dir || "").split("/").pop())}/${encodeURIComponent(f)}" target=_blank>${esc(f)}</a>`).join(", ")}</div>` : ""}</div>` : ""}
    ${cl && cl.scores ? `<div class="help">Score per lab run (how closely the run matched the original packets): <span class=mono>${cl.scores.map(x => fmt(x, 2)).join(" · ")}</span> → ${cl.max_consecutive_score_hits} in a row above ${fmt(cl.score_threshold, 1)}: <b>${cl.optimal ? "optimal (rule met)" : "not yet optimal"}</b> <span class=muted>(rule: above ${fmt(cl.score_threshold, 1)} ${(r.rules || {}).optimal_consecutive || 3} times in a row = optimal; fail = first-level triage limit of ${Math.round(((r.rules || {}).first_level_triage_s || 600) / 60)} min exceeded)</span></div>` : ""}
    ${["budget_exhausted", "triage_timeout", "not_reproduced", "admin_procedure_failed"].includes(r.status) ? `<div class="row" style="margin-top:8px"><button class="primary" id="btn-restart">Record the failed attempt (−1) and restart the search</button><span class="muted small">the failure is counted against the procedure and the next attempt uses a different random seed</span></div>` : ""}
    ${files.length ? `<div><b>${r.admitted ? "Test script:" : "Test files written for inspection only (not filed: the lab check did not pass):"}</b> ${files.map(f => `<a href="/api/suite/${encodeURIComponent((r.test_dir || "").split("/").pop())}/${encodeURIComponent(f)}" target=_blank>${esc(f)}</a>`).join(", ")} <span class="muted small">(plus manifest.json and conftest.py)</span></div>` : ""}</div>`;
  const rb = box.querySelector("#btn-restart");
  if (rb && el._act) rb.onclick = () => { rb.disabled = true; el._act("restart", null, { note: "no reproduction within the limits (" + statusWord(r.status) + ")" }); };
}
