// One error's page (owner, 2026-11-11): 1 the error -> 2 the commands around it (a tree, like the hierarchy page) -> 3 the isolation of the
// defect (the model; you name the defect) -> 4 the procedural graph (is the defect stored? its causes; you name the cause) -> 5 the solution
// (stored ones ranked by your judgements, or the first one) -> 6 the test case. Each part opens when the one before it is done.
import { api, $, esc } from "./api.js";

const Q = new URLSearchParams(location.search);
const UID = Q.get("upload"), FID = Number(Q.get("finding"));
const BASE = `/api/isolate/${encodeURIComponent(UID)}/${encodeURIComponent(FID)}`;
const STANDIN = Q.get("standin") === "1";
const LABEL = { nvme_command: "NVMe command", nvme_transaction: "NVMe transaction", split: "split transaction", link: "link transaction", packets: "packet" };
const FILE = { nvme_command: "nvme_command.csv", nvme_transaction: "NVME_Transactions.csv", split: "split.csv", link: "link.csv", packets: "packets.csv" };
const POS = { above: "before the error", fault: "THE ERROR", below: "after the error" };
const S = { H: null, W: null, iso: null, defect: null, occ: null, cause: null, sol: null, testSeq: null, expect: null, file: null };

const name = () => ($("name").value || "").trim();
const status = (id, text, cls = "") => { const e = $(id); if (e) { e.textContent = text; e.className = "status " + cls; } };
const who = p => !p ? "" : /^stand-in/.test(p) ? "no model answered: built by the code from the rule's own facts" : "answered by the model";
const UNITS = [[1e12, "s"], [1e9, "ms"], [1e6, "µs"]];
const fmtT = ps => { if (ps == null || isNaN(ps)) return ""; const [div, u] = S.tunit || [1e6, "µs"], sg = ps < 0 ? "−" : ps > 0 ? "+" : "";
  return `${sg}${(Math.abs(ps) / div).toLocaleString("en-US", { maximumFractionDigits: 3 })} ${u}`; };
const nf = x => Number(x).toLocaleString("en-US");
// ---- long steps: progress while the server works, and a sound when it is done (owner, 2026-11-11)
function unlockAudio() { try { S.audio = S.audio || new (window.AudioContext || window.webkitAudioContext)(); if (S.audio.state === "suspended") S.audio.resume(); } catch (e) { /* no sound */ } }
function ding(ok) {
  const a = S.audio; if (!a) return;
  try { (ok ? [660, 880] : [440, 330]).forEach((f, i) => { const o = a.createOscillator(), g = a.createGain(), t = a.currentTime + i * 0.2;
    o.frequency.value = f; o.connect(g); g.connect(a.destination); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.2, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.18); o.start(t); o.stop(t + 0.2); }); } catch (e) { /* no sound */ }
}
async function runJob(url, body, statusId) {
  unlockAudio();
  const box = $(statusId), base = document.title;
  box.className = "status"; box.innerHTML = `<div class="prog"><div class="bar"><span style="width:1%"></span></div><div class="ptext">starting…</div><details class="plog"><summary>what happened so far</summary><ol></ol></details></div>`;
  const { job } = await api("POST", url + (url.includes("?") ? "&" : "?") + "job=1", body);
  let shown = 0;
  try {
    for (;;) {
      await new Promise(r => setTimeout(r, 700));
      const j = await api("GET", `/api/isolate/jobs/${job}`);
      box.querySelector(".bar span").style.width = `${Math.max(1, j.pct)}%`;
      box.querySelector(".ptext").innerHTML = `<b>${j.pct}%</b> · ${esc(j.text || "")} · ${j.seconds} s`;
      const ol = box.querySelector("ol");
      while (shown < (j.log || []).length) { const l = j.log[shown++]; ol.insertAdjacentHTML("beforeend", `<li>${l.s} s · ${l.pct}% · ${esc(l.text)}</li>`); }
      document.title = `${j.pct}% · ${base}`;
      if (j.state === "done") { document.title = base; ding(true); box.querySelector(".ptext").innerHTML = `<b>done</b> in ${j.seconds} s`; return j.result; }
      if (j.state === "error") { document.title = base; ding(false); throw new Error(j.error || "it failed"); }
    }
  } catch (e) { document.title = base; throw e; }
}

function needName() { if (name()) return true; $("name").focus(); alertBox("Write your name at the top first: every decision here is kept with it."); return false; }
function alertBox(text) { const e = $("load-error"); e.hidden = false; e.textContent = text; setTimeout(() => { e.hidden = true; }, 6000); }

// ------------------------------------------------------------------ 1 the error
async function loadError() {
  const H = S.H = await api("GET", BASE);
  const f = H.finding, cmd = f.command || {};
  const where = `row ${nf(f.rowid)} of ${FILE[f.level] || f.level}`;
  S.where = where;
  $("upload-badge").textContent = UID;
  $("model-badge").textContent = H.model.available && !STANDIN ? H.model.name : "no model (the code's own answers)";
  $("page-title").textContent = `Error at ${where}`;
  document.title = `Error at ${where}`;
  $("error-kv").innerHTML = [
    ["What the pattern found", esc(f.name || f.rule_words)],
    ["The pattern (rule)", esc(f.rule_words)],
    ["Where in the files", `${esc(where)} <a href="/hier?upload=${encodeURIComponent(UID)}" target="_blank">open the tree ↗</a>`],
    ["Its NVMe command", cmd.summary ? `${esc(cmd.summary)}${cmd.duration ? `, took ${esc(cmd.duration)}` : ""}${cmd.status ? `, status ${esc(cmd.status)}` : ""}` : "outside any command"],
    ["Measured against the limit", f.value_ps_text ? `${esc(f.value_ps_text)} measured; the limit is ${esc(f.limit_ps_text || "-")} (${esc(f.limit_source || "no source recorded")})` : "this rule fires on a status or an event, not on a time"],
    ["The drive", esc(H.device || "not named")],
  ].map(([k, v]) => `<b>${esc(k)}</b><span>${v}</span>`).join("");
  const chain = (f.chain || []).map(c => `${esc(c.label)} ${esc(c.n)}: ${esc(c.summary)}`).join(" → ");
  const c = f.catalogue;
  $("error-more").innerHTML = `<p><b>From the row up to its command:</b> ${chain || "-"}</p>
    <p><b>Catalogue text:</b> ${c ? `${esc(c.error || "")} ${esc(c.meaning || "")}${c.spec ? ` (specification ${esc(c.spec)})` : ""}` : "none for this rule"}</p>
    <p class="hint">Key of this kind of error: ${esc((f.signature || {}).display || "")}</p>`;
}

// ------------------------------------------------------------------ 2 the commands around it: a tree, opened level by level
function rowCells(r, d, errT) {
  const f = (r.findings || []).map(x => x.name).join("; ");
  const exp = r.level !== "packets" && (r.level === "nvme_command" || r.has_children) ? `<button class="exp" data-lvl="${r.level}" data-rid="${r.rowid}" data-d="${d}">expand</button>` : "";
  return `<td>${exp}</td><td class="num">${esc(r.rowid)}</td><td class="what">${d ? `<span class="hint">${esc(LABEL[r.level])}</span> ` : ""}${esc(r.summary || "")}</td>
    <td>${r.status ? esc(r.status) : ""}${r.status && f ? "; " : ""}${f ? `<span class="fnd">${esc(f)}</span>` : ""}</td>
    <td class="num">${esc(r.gap || "")}</td><td class="num">${esc(r.dur || "")}</td><td class="t">${r.t_ps != null && errT != null ? esc(fmtT(r.t_ps - errT)) : ""}</td>`;
}
async function showWindow() {
  const n = Number($("n-above").value), m = Number($("m-below").value);
  if (!Number.isInteger(n) || !Number.isInteger(m) || n < 0 || m < 0 || n > 100 || m > 100) { status("win-status", "above and below: whole numbers from 0 to 100", "bad"); return; }
  status("win-status", "reading the commands…");
  try { S.W = await api("GET", `${BASE}/window?n=${n}&m=${m}&levels=`); } catch (e) { status("win-status", e.message, "bad"); return; }
  const cmds = S.W.commands || [], fault = cmds.find(c => c.position === "fault") || {}, errT = fault.t_ps;
  S.errT = errT;
  const widest = Math.max(0, ...cmds.map(c => Math.abs((c.t_ps ?? errT) - errT)));
  S.tunit = UNITS.find(([d]) => widest >= d) || [1e6, "µs"];          // one unit for the whole column (research: trace viewers keep one time base)
  $("win").querySelector("thead th:last-child").textContent = `time from the error (${S.tunit[1]})`;
  S.shownWindow = { n, m };
  const above = cmds.filter(c => c.position === "above"), below = cmds.filter(c => c.position === "below");
  const tr = c => `<tr class="${c.position === "fault" ? "err" : ""}${(c.findings || []).length ? " has-f" : ""}" data-key="nvme_command:${c.rowid}">${rowCells(c, 0, errT)}</tr>`;
  $("win").querySelector("tbody").innerHTML =
    `<tr class="sep"><td colspan="7">${above.length} command${above.length === 1 ? "" : "s"} before the error</td></tr>${above.map(tr).join("")}` +
    `<tr class="sep"><td colspan="7">the error's command</td></tr>${tr(fault)}` +
    `<tr class="sep"><td colspan="7">${below.length} command${below.length === 1 ? "" : "s"} after the error</td></tr>${below.map(tr).join("")}`;
  status("win-status", `${above.length} above, the error's command, ${below.length} below. The isolation in part 3 reads these, with everything under them.`, "ok");
  const wrap = $("win").closest(".treewrap"), er = $("win").querySelector("tr.err");
  if (wrap && er) wrap.scrollTop = Math.max(0, er.offsetTop - wrap.clientHeight / 2);
}
async function expand(b) {
  const lvl = b.dataset.lvl, rid = Number(b.dataset.rid), d = Number(b.dataset.d), key = `${lvl}:${rid}`, row = b.closest("tr");
  const tbody = row.parentElement;
  if (b.textContent === "collapse") { tbody.querySelectorAll("tr").forEach(x => { if ((x.dataset.anc || "").split(" ").includes(key)) x.remove(); }); b.textContent = "expand"; return; }
  b.textContent = "…";
  let r;
  try { r = await api("GET", `${BASE}/children?level=${lvl}&rowid=${rid}&limit=200`); } catch (e) { b.textContent = "expand"; status("win-status", e.message, "bad"); return; }
  const anc = ((row.dataset.anc || "") + " " + key).trim();
  const html = [];
  for (const p of r.parts) {
    for (const x of p.rows) html.push(`<tr class="kid l-${x.level}${(x.findings || []).length ? " has-f" : ""}" style="--d:${d + 1}" data-key="${x.level}:${x.rowid}" data-anc="${anc}">${rowCells(x, d + 1, S.errT)}</tr>`);
    if (p.count > p.rows.length) html.push(`<tr class="kid note" style="--d:${d + 1}" data-anc="${anc}"><td></td><td></td><td class="what" colspan="5">and ${nf(p.count - p.rows.length)} more ${esc(p.label)}s under this ${esc(LABEL[lvl])} (the first ${p.rows.length} are shown; the tree page shows them all)</td></tr>`);
  }
  if (!html.length) html.push(`<tr class="kid note" style="--d:${d + 1}" data-anc="${anc}"><td></td><td></td><td class="what" colspan="5">nothing under this ${esc(LABEL[lvl])}</td></tr>`);
  row.insertAdjacentHTML("afterend", html.join(""));
  b.textContent = "collapse";
}

// ------------------------------------------------------------------ 3 the isolation of the defect
async function isolate(rewrite) {
  if (!needName()) return;
  const { n, m } = S.shownWindow || { n: Number($("n-above").value), m: Number($("m-below").value) };      // the window on the screen
  $("btn-isolate").disabled = true;
  try {
    S.iso = await runJob(`${BASE}/isolate${STANDIN ? "?standin=1" : ""}`, { n, m, levels: ["nvme_transaction", "split", "link", "packets"], history: true, anyway: true,
                                                                         isolation: true, rewrite: rewrite === true, name: name(), standin: STANDIN }, "iso-prog");
  } catch (e) { status("iso-status", e.message, "bad"); $("btn-isolate").disabled = false; return; }
  $("btn-isolate").disabled = false; $("btn-isolate").textContent = "Isolate again";
  const i = S.iso.isolation || {}, L = i.labels || {};
  status("iso-status", i.kept_at ? `the same isolation as before (kept ${new Date(i.kept_at * 1000).toLocaleString()}): this error's evidence has not changed, so its isolation does not change, whatever the window`
    : `${who(i.producer)}; ${(i.problems || []).length ? "the code's checks found: " + i.problems.join("; ") : "the code checked every row it cites"}`, (i.problems || []).length && !i.kept_at ? "warn" : "ok");
  const t = i.term || {}, st = i.stored, sl = t.slots || {};
  $("iso-out").innerHTML = `<div class="answer"><div class="q">${["what", "why", "when", "where", "who", "which", "how"].map(k => `<b>${esc(L[k] || k)}</b><span>${esc(i[k] || "")}</span>`).join("")}</div>
      ${(i.cited_rows || []).length ? `<p class="hint" style="margin:8px 0 0">The rows it rests on: ${i.cited_rows.map(c => `${esc(LABEL[c.level] || c.level)} row ${esc(c.rowid)}`).join(", ")}.</p>` : ""}
      <p style="margin:10px 0 0"><b>How the cause was decided:</b> ${esc((i.cause || {}).name || "")} <span class="hint">(${esc(i.cause_key || "")})</span>, because ${esc(i.cause_header || "")}.
        <span class="hint">Decided by ${esc(i.decided_by || "the fixed rules")}, from this error's own command, not by the model and not by the window: the same error always gets the same cause.
        What, when, where, which row and who are stated by the code too; the model writes only why and how.</span></p>
      ${cardHtml(i.card)}
      <div class="row" style="margin-top:8px"><button class="small" id="btn-rewrite">Write the words again</button><span class="hint">the facts and the cause stay; only why and how are written again</span></div></div>
    <div class="choice"><h3>The defect, as the dictionary names it</h3>
      <p style="font-size:16px;margin:4px 0"><b>${esc(t.name || "")}</b></p>
      <p class="hint">Named by the code from what the recording shows, never typed: the rule ${esc(sl.rule || "")}, the command ${esc(sl.command || "")}, what happened (${esc(sl.what || "")})${sl.qualifier ? `, ${esc(sl.qualifier)}` : ""}. The same kind of error always gets this name, whoever looks at it and whenever. (Dictionary version ${esc(t.version)}.)</p>
      <p>${st ? `<b>Already in the procedural graph:</b> seen ${st.seen} time${st.seen === 1 ? "" : "s"}${(st.devices || []).length ? ` on ${esc(st.devices.join(", "))}` : ""}; ${(st.causes || []).length} cause${(st.causes || []).length === 1 ? "" : "s"} stored.`
        : `<b>Not in the procedural graph yet:</b> this is its first finding; it is stored under this name.`}</p>
      <div class="row" style="margin-top:8px"><button class="primary" id="btn-name">Continue with this defect</button><span id="name-status" class="status"></span></div>
      <details class="node" style="margin-top:10px"><summary>Not the same kind of defect?</summary><div class="in">
        <p class="hint">Say why. The note goes to the dictionary's keeper; the name stays as the code made it until the dictionary changes, so it stays the same for everyone.</p>
        <textarea id="term-note" style="width:100%;min-height:60px"></textarea><div class="row" style="margin-top:6px"><button id="btn-term-note">Send the note</button><span id="term-status" class="status"></span></div></div></details></div>`;
  $("btn-name").onclick = nameDefect;
  $("btn-rewrite").onclick = () => isolate(true);
  $("btn-term-note").onclick = async () => {
    const note = ($("term-note").value || "").trim(); if (!note || !needName()) return;
    try { await api("POST", "/api/dg/term_requests", { term_key: t.key, term_name: t.name, note, upload_id: UID, finding_id: FID, admin: name() }); status("term-status", "sent", "ok"); }
    catch (e) { status("term-status", e.message, "bad"); }
  };
}
const fmtAny = ps => { if (ps == null || isNaN(ps)) return "-"; const a = Math.abs(ps); return a >= 1e12 ? `${(ps / 1e12).toFixed(3)} s` : a >= 1e9 ? `${(ps / 1e9).toFixed(3)} ms` : a >= 1e6 ? `${(ps / 1e6).toFixed(3)} µs` : `${Math.round(ps / 1e3)} ns`; };
function cardHtml(c) {
  if (!c || !c.command) return "";
  const fmtT = fmtAny;            // each card value in its own unit
  const st = (c.stages || []).map(s => `<tr><td>${esc(s.row)}</td><td>${esc(s.what)}</td><td class="num">${s.after_doorbell_ps != null ? esc(fmtT(s.after_doorbell_ps)) : ""}</td><td class="num">${s.gap_ps != null ? esc(fmtT(s.gap_ps)) : ""}</td></tr>`).join("");
  const lw = c.longest_wait, ab = c.abort, du = c.during || {};
  return `<details class="node" style="margin-top:8px"><summary>The evidence card <span class="hint">· computed by the code from this error's own command; the same for every window</span></summary><div class="in">
    <table class="steps"><tr><th>row</th><th>step of the command</th><th>after the doorbell</th><th>wait before it</th></tr>${st}</table>
    <p class="hint">${lw ? `The longest wait: ${esc(fmtT(lw.ps))}, from row ${esc(lw.from_row)} (${esc(lw.from_what)}) to row ${esc(lw.to_row)} (${esc(lw.to_what)}). ` : ""}
      ${ab ? `The host's Abort: row ${esc(ab.row)}, ${esc(fmtT(ab.after_doorbell_ps))} after the doorbell. ` : "No Abort while it was outstanding. "}
      Its own packets: ${esc(c.packets ?? "-")}, refused (Nak) ${esc(c.nak)}, unacknowledged ${esc(c.unacked)}.
      During its time: ${esc(du.commands ?? 0)} other commands (${esc(du.completed ?? 0)} completed, ${esc(du.same_queue ?? 0)} on the same queue)${(c.link_events || []).length ? `; link events: ${esc(c.link_events.map(e => e.rule).join(", "))}` : "; no link event"}.
      ${c.median_ps ? `This command type usually takes ${esc(fmtT(c.median_ps))} here; the host's driver limit is ${esc(fmtT(c.host_limit_ps))}.` : ""}</p></div></details>`;
}
async function nameDefect() {
  if (!needName()) return;
  const i = S.iso.isolation || {}, t = i.term || {};
  try {
    const did = (await api("POST", "/api/dg/defects", { name: t.name, term_key: t.key, rule: i.rule, level: i.level, what: i.what, admin: name() })).id;
    S.occ = (await api("POST", "/api/dg/occurrences", { defect_id: did, cause_id: null, upload_id: UID, finding_id: FID, device: i.device, firmware: i.firmware,
                                                         isolation: isolationRecord(), admin: name() })).id;
    S.defect = did;
    status("name-status", "kept under this defect; part 4 shows what the procedural graph holds for it", "ok");
    await showGraph();
    $("s-graph").scrollIntoView({ behavior: "smooth" });
  } catch (e) { status("name-status", e.message, "bad"); }
}
const isolationRecord = () => { const i = S.iso.isolation || {}; const o = {}; ["what", "why", "when", "where", "who", "which", "how", "cause_key", "cause_header", "cited_rows"].forEach(k => o[k] = i[k]); o.term = (i.term || {}).key; return o; };

// ------------------------------------------------------------------ 4 the procedural graph: the defect, its causes, their solutions
function seqTable(seq, tick) {
  return `<table class="steps"><tr><th>step</th><th>command</th><th>where</th><th>wait before it</th>${tick ? "<th></th>" : ""}</tr>${(seq || []).map(x =>
    `<tr class="${x.position === "fault" ? "err" : ""}" ${tick ? `data-tick="${tick}" data-step="${x.step}"` : ""}>
     <td>${esc(x.step)}</td><td><b>${esc(x.command || "")}</b>${x.parameters && Object.keys(x.parameters).length ? ` <span class="hint">${esc(Object.entries(x.parameters).map(([k, v]) => `${k} ${v}`).join(", "))}</span>` : ""}</td>
     <td>${esc(POS[x.position] || x.position || "")}</td><td>${x.gap_us != null ? nf(Math.round(x.gap_us)) + " µs" : ""}</td>
     ${tick ? `<td>${x.position === "fault" ? '<span class="hint">stays</span>' : '<button class="small drop" type="button">drop</button>'}</td>` : ""}</tr>`).join("")}</table>`;
}
document.addEventListener("click", e => { const b = e.target.closest("button.drop"); if (!b) return; const tr = b.closest("tr"); tr.classList.toggle("dropped"); b.textContent = tr.classList.contains("dropped") ? "put back" : "drop"; });
function solutionBody(x) {
  const devs = (x.devices || []).map(d => `${esc(d.device)}: ${esc(d.words)}`).join("; ");
  return `<p class="hint">Stored ${esc(x.created)} by ${esc(x.created_by || "")}${x.last_judged ? `; last judged ${esc(x.last_judged)}` : ""}${devs ? `; on drives: ${devs}` : ""}.</p>
    <h4 style="margin:8px 0 4px">Error sequence <span class="hint">· makes the error happen again; the test is written from it</span></h4>${seqTable(x.error_seq)}
    <h4 style="margin:10px 0 4px">Optimized sequence <span class="hint">· solves the problem for this cause</span></h4>
    ${(x.optimized || []).length ? `<ol>${x.optimized.map(l => `<li>${esc(l)}</li>`).join("")}</ol>` : `<p class="hint">none written yet</p>`}
    <p class="hint">Versions: ${(x.versions || []).map(v => `${esc(v.version)} (${esc(v.at)}, ${esc(v.by || "")}${v.test_path ? ", test approved" : ""})`).join("; ")}.
      ${(x.verdicts || []).length ? `Judgements: ${x.verdicts.map(v => `${esc(v.signal)} by ${esc(v.by)} on ${esc(v.at)}${v.counted === false ? " (replaced by a later judgement of the same error)" : ""}`).join("; ")}.` : "Not judged yet."}</p>`;
}
async function showGraph() {
  const v = S.view = await api("GET", `/api/dg/defects/${S.defect}`), i = S.iso.isolation || {};
  const outline = !(v.causes || []).length ? `<p><b>First finding of this defect:</b> nothing is stored for it yet. Name its cause below; it is stored under the defect.</p>`
    : `<p><b>Already in the procedural graph:</b> ${v.causes.length} cause${v.causes.length === 1 ? "" : "s"}; the defect was seen ${v.seen} time${v.seen === 1 ? "" : "s"} on ${esc((v.devices || []).join(", ") || "no named drive")}. Open a cause to see its solutions.</p>` +
      v.causes.map(c => `<details class="node"><summary><b>${esc(c.header)}</b> <span class="hint">· ${esc(c.side_words)} · ${esc(c.chosen_words)} · ${c.solutions.length} solution${c.solutions.length === 1 ? "" : "s"}</span></summary>
        <div class="in">${c.solutions.length ? c.solutions.map(x => `<details class="node"><summary>Solution ${x.rank}: ${esc(((x.optimized || [])[0] || "no optimized sequence yet").slice(0, 120))} <span class="hint">· ${esc(x.judged_words)}</span></summary><div class="in">${solutionBody(x)}</div></details>`).join("")
          : `<p class="hint">no solution stored under this cause yet</p>`}</div></details>`).join("") + `<p class="hint">${esc(v.order || "")}</p>`;
  if (!S.causes) { try { S.causes = (await api("GET", "/api/dg/terms")).causes || []; } catch (e) { S.causes = []; } }
  const mc = i.cause || {}, stored = new Set((v.causes || []).map(c => c.key));
  const bySide = {}; S.causes.forEach(c => (bySide[c.side_words] = bySide[c.side_words] || []).push(c));
  $("graph-out").innerHTML = `<h3 style="margin:0 0 6px">The defect: ${esc(v.name)}</h3>${outline}
    <div class="choice"><h3>The cause of this error</h3>
      <p class="hint">A cause is one keyword of the dictionary, the same words for everyone; nothing is typed.</p>
      <p>The fixed rules decided: <b>${esc(mc.name || "not decided")}</b> <span class="hint">(${esc(mc.key || "")}, ${esc(mc.side_words || "")}${stored.has("kw:" + mc.key) ? "; already stored for this defect" : ""})</span><br><span class="hint">Because ${esc(i.cause_header || "")}.</span></p>
      <div class="row"><button class="primary" id="btn-cause-model">Use this cause</button></div>
      <label style="display:block;margin-top:10px">Or, if you know better, another keyword of the dictionary <select id="cause-choice"><option value="">choose…</option>${Object.entries(bySide).map(([side, cs]) => `<optgroup label="${esc(side)}">${cs.map(c => `<option value="${esc(c.key)}">${esc(c.name)}${stored.has("kw:" + c.key) ? " (stored for this defect)" : ""}</option>`).join("")}</optgroup>`).join("")}</select></label>
      <p class="hint" id="cause-evidence"></p>
      <div class="row"><button id="btn-cause">Use the chosen keyword</button><span id="cause-status" class="status"></span></div></div>`;
  $("cause-choice").onchange = () => { const c = S.causes.find(x => x.key === $("cause-choice").value); $("cause-evidence").textContent = c ? `${c.side_words}; points at it: ${c.evidence}` : ""; };
  $("btn-cause-model").onclick = () => useCause(mc.key);
  $("btn-cause").onclick = () => useCause($("cause-choice").value);
}
async function useCause(kw) {
  if (!needName()) return;
  if (!kw) { status("cause-status", "choose a keyword first", "bad"); return; }
  const i = S.iso.isolation || {};
  try {
    const cid = (await api("POST", "/api/dg/causes", { defect_id: S.defect, keyword: kw, admin: name() })).id;
    await api("POST", "/api/dg/occurrences", { defect_id: S.defect, cause_id: cid, upload_id: UID, finding_id: FID, device: i.device, firmware: i.firmware, isolation: isolationRecord(), admin: name() });
    S.cause = cid;
    status("cause-status", "this error is kept under that cause (one count for it, with this drive)", "ok");
    await showSolutions();
    $("s-solution").scrollIntoView({ behavior: "smooth" });
  } catch (e) { status("cause-status", e.message, "bad"); }
}

// ------------------------------------------------------------------ 5 the solution
async function showSolutions(did) {
  const v = S.view = await api("GET", `/api/dg/defects/${S.defect}`), c = (v.causes || []).find(x => x.id === S.cause);
  if (!c) { $("sol-out").innerHTML = `<p class="bad">the cause is not under this defect</p>`; return; }
  const head = `<div id="sol-prog"></div><p>Defect <b>${esc(v.name)}</b> · cause <b>${esc(c.header)}</b> (${esc(c.side_words)}).</p>${did ? `<div class="did"><b>What your judgement did:</b> ${did.map(esc).join("; ")}.</div>` : ""}`;
  if (!c.solutions.length) { $("sol-out").innerHTML = head + `<p><b>No solution is stored for this cause yet.</b> Store the first one:</p>${await firstSolutionForm()}`; wireFirst(); return; }
  // (owner, 2026-11-11: "where are positive, negative, positive with feedback, negative with feedback?") the four judgements sit at the
  // top of every stored solution, named in the owner's words; the best-ranked solution is open, so they are seen without a click
  $("sol-out").innerHTML = head + `<p>Stored solutions for this cause, best judged first (${c.solutions.length}). Judge each one with the four buttons at its top: <b>positive</b>, <b>positive with feedback</b> (your changes), <b>negative</b>, <b>negative with feedback</b>. Your judgement only changes the order the solutions are shown in next time.</p>` +
    c.solutions.map((x, k) => `<details class="node" data-sid="${x.id}"${k === 0 ? " open" : ""}><summary>Solution ${x.rank}: ${esc(((x.optimized || [])[0] || "no optimized sequence yet").slice(0, 120))} <span class="hint">· ${esc(x.judged_words)}</span></summary>
      <div class="in">
        <div class="judge"><h4>Your judgement of this solution <span class="hint">· it only changes the order the solutions are shown in next time</span></h4>
          <div class="verdicts"><button class="plus" data-sig="correct" data-sid="${x.id}"><b>Correct</b><small>positive</small></button>
            <button class="plus" data-sig="correct_with_edits" data-sid="${x.id}"><b>Correct with my edits</b><small>positive with feedback</small></button>
            <button class="minus" data-sig="wrong" data-sid="${x.id}"><b>Wrong</b><small>negative</small></button>
            <button class="minus" data-sig="wrong_with_edits" data-sid="${x.id}"><b>Wrong, keep my edits</b><small>negative with feedback</small></button></div>
          <span class="status" data-st="${x.id}"></span>
          <div class="choice" data-edit="${x.id}" hidden><h3>Your edits <span class="hint">· then press the button again to save them with your judgement</span></h3><p class="hint">Drop the error-sequence steps it does not need; change the optimized sequence, one action per line.</p>${seqTable(x.error_seq, "s" + x.id)}
            <textarea class="seqbox" data-opt="${x.id}">${esc((x.optimized || []).join("\n"))}</textarea>
            <div class="row" style="margin-top:8px"><button class="primary" data-save="${x.id}">Save my edits with my judgement</button></div></div></div>
        ${solutionBody(x)}</div></details>`).join("") +
    `<details class="node" id="none-fits"><summary>None fits: store this recording's sequence as a new solution</summary><div class="in"><p class="hint">opening…</p></div></details>`;
  $("none-fits").addEventListener("toggle", async ev => { const d = ev.target; if (!d.open || d.dataset.ready) return; d.dataset.ready = "1"; d.querySelector(".in").innerHTML = await firstSolutionForm(); wireFirst(); });
  $("sol-out").querySelectorAll(".verdicts button").forEach(b => b.onclick = () => judge(b, c));
  // the same save at the bottom of the edits, so the admin need not scroll back up after editing a long sequence
  $("sol-out").querySelectorAll("button[data-save]").forEach(b => b.onclick = () => {
    const box = document.querySelector(`[data-edit="${b.dataset.save}"]`), armed = document.querySelector(`.verdicts button[data-sid="${b.dataset.save}"][data-sig="${box.dataset.sig}"]`);
    if (armed) judge(armed, c);
  });
}
async function firstSolutionForm() {
  const i = S.iso.isolation || {}, c = (S.view.causes || []).find(x => x.id === S.cause) || {};
  let prop = { lines: [], note: "" };
  try { prop = await runJob("/api/dg/optimized", { upload_id: UID, finding_id: FID, isolation: isolationRecord(), cause: { side: c.side, header: c.header }, error_seq: S.iso.sequence || [], standin: STANDIN }, "sol-prog"); } catch (e) { /* written by hand */ }
  return `<h4 style="margin:8px 0 4px">Error sequence <span class="hint">· this recording's commands that make the error happen again; drop what it does not need (the error's own step stays)</span></h4>${seqTable(S.iso.sequence, "new")}
    <h4 style="margin:10px 0 4px">Optimized sequence <span class="hint">· the solution for this cause, one action per line; ${prop.standin ? "no model answered: write it yourself" : "the model proposed it: edit it before you store it"}</span></h4>
    ${prop.note ? `<p class="hint">${esc(prop.note)}</p>` : ""}<textarea class="seqbox" id="opt-new">${esc((prop.lines || []).join("\n"))}</textarea>
    <div class="row" style="margin-top:8px"><button class="primary" id="btn-store">Store this solution</button><span id="store-status" class="status"></span></div>`;
}
const kept = (seq, tick) => { const drop = new Set([...document.querySelectorAll(`tr[data-tick="${tick}"].dropped`)].map(x => Number(x.dataset.step)));
  return (seq || []).filter(s => !drop.has(s.step) || s.position === "fault").map((s, i) => Object.assign({}, s, { step: i + 1 })); };
// a sequence box shows all its steps: it grows to its text (up to three quarters of the screen, then it scrolls) and again as the admin types
function growBox(t) { if (!t || t.offsetParent === null) return; t.style.height = "auto"; t.style.height = (t.scrollHeight + 4) + "px"; }
document.addEventListener("input", ev => { if (ev.target.classList && ev.target.classList.contains("seqbox")) growBox(ev.target); });
window.addEventListener("resize", () => document.querySelectorAll("textarea.seqbox").forEach(growBox));
function wireFirst() {
  growBox($("opt-new"));
  const b = $("btn-store"); if (!b) return;
  b.onclick = async () => {
    if (!needName()) return;
    const lines = ($("opt-new").value || "").split("\n").map(x => x.trim()).filter(Boolean);
    if (!lines.length) { status("store-status", "write the optimized sequence, one action per line", "bad"); return; }
    try {
      const r = await api("POST", "/api/dg/solutions", { cause_id: S.cause, error_seq: kept(S.iso.sequence, "new"), optimized: lines, admin: name(), producer: `model, edited by ${name()}`, upload_id: UID, finding_id: FID });
      chooseForTest(r.solution, r.revision_id);          // written or edited by you: it starts "not yet judged" (no judgement is invented for it)
      await showSolutions([`stored as a new solution under this cause; it is not judged yet. Judge it with the four buttons below once you have checked it, or the next time this defect and cause come back`]);
    } catch (e) { status("store-status", e.message, "bad"); }
  };
}
async function judge(b, c) {
  if (!needName()) return;
  const sid = Number(b.dataset.sid), sig = b.dataset.sig, x = c.solutions.find(s => s.id === sid), box = document.querySelector(`[data-edit="${sid}"]`);
  if (sig.endsWith("_with_edits") && box.hidden) { box.hidden = false; box.dataset.sig = sig; growBox(box.querySelector("textarea.seqbox")); const t = b.querySelector("b"); t.textContent = `Save: ${t.textContent}`; box.scrollIntoView({ behavior: "smooth", block: "start" }); return; }   // first click opens the edits
  const body = { signal: sig, admin: name(), occurrence_id: S.occ, device: (S.iso.isolation || {}).device, firmware: (S.iso.isolation || {}).firmware };
  if (sig.endsWith("_with_edits")) { body.error_seq = kept(x.error_seq, "s" + sid); body.optimized = (document.querySelector(`[data-opt="${sid}"]`).value || "").split("\n").map(l => l.trim()).filter(Boolean); }
  try {
    const r = await api("POST", `/api/dg/solutions/${sid}/verdict`, body);
    if (sig !== "wrong") chooseForTest(r.new_solution_id ? Object.assign({}, r.solution, { id: r.new_solution_id, error_seq: body.error_seq || x.error_seq, origin_upload: x.origin_upload }) : r.solution, r.new_revision_id || r.solution.revision_id);
    await showSolutions(r.did);
  } catch (e) { const st = document.querySelector(`[data-st="${sid}"]`); if (st) { st.textContent = e.message; st.className = "status bad"; } }
}
function chooseForTest(sol, rev) {
  const fromHere = !sol.origin_upload || sol.origin_upload === UID;
  S.sol = { id: sol.id, revision_id: rev, from_here: fromHere };
  S.testSeq = fromHere ? sol.error_seq : S.iso.sequence;          // a solution stored from another recording: the test uses this recording's rows of the same error
  showTest();
}

// ------------------------------------------------------------------ 6 the test case
function showTest() {
  $("test-out").innerHTML = `<p>The test replays the error sequence (${S.testSeq.length} command${S.testSeq.length === 1 ? "" : "s"}${S.sol.from_here ? "" : ", taken from this recording because the chosen solution was stored from another one"}) and then checks what a correct drive must answer.</p>
    <div class="row"><button class="primary" id="btn-expect">Propose what a correct drive must answer</button><span id="test-status" class="status"></span></div><div id="test-prog"></div><div id="expect-out"></div><div id="file-out"></div>`;
  $("btn-expect").onclick = proposeExpected;
  $("s-test").scrollIntoView({ behavior: "smooth" });
}
async function proposeExpected() {
  if (!needName()) return;
  try { S.expect = await runJob(`${BASE}/testcase${STANDIN ? "?standin=1" : ""}`, { sequence: S.testSeq, expected_after: 3, name: name(), standin: STANDIN }, "test-prog"); }
  catch (e) { status("test-status", e.message, "bad"); return; }
  const E = S.expect;
  status("test-status", `${who(E.producer)}; the time limit used: ${E.limit.text} (${E.limit.source})`, E.standin ? "warn" : "ok");
  const nAfter = E.expected_outcomes.filter(o => o.step > E.fault_step).length;
  $("expect-out").innerHTML = `<p style="margin-top:10px"><b>What the test does:</b> it sends the ${E.sequence.length} commands of the error sequence in order, then checks what the drive answered to the error's command${nAfter ? ` and the ${nAfter} after it` : ""}. A correct drive must answer as in the table.</p>
    <p><b>Check each line.</b> Change what is wrong, tick it, then write the file.</p>
    <table class="steps"><tr><th>step</th><th>command</th><th>a correct drive answers</th><th>within</th><th>how the test checks it</th><th>why</th><th>checked</th></tr>
    ${E.expected_outcomes.map((o, k) => `<tr class="${o.step === E.fault_step ? "err" : ""}" data-k="${k}"><td>${esc(o.step)}${o.step === E.fault_step ? " · the error" : ""}</td><td>${esc(o.command)}</td>
      <td><input class="st" value="${esc(o.status)}"></td><td><input class="tm" type="number" min="1" value="${esc(o.timing_us)}" style="width:110px"> µs<div class="hint">= ${esc((o.timing_us / 1e6).toLocaleString("en-US", { maximumFractionDigits: 6 }))} s</div></td><td><input class="ck" value="${esc(o.check)}"></td>
      <td class="hint">${esc(o.basis)}</td><td><input type="checkbox" class="ver"></td></tr>`).join("")}</table>
    <div class="row" style="margin-top:8px"><button class="primary" id="btn-write">Write the test file</button><span id="write-status" class="status"></span></div><div id="write-prog"></div>`;
  $("btn-write").onclick = writeFile;
}
async function writeFile() {
  const E = S.expect, rows = [...$("expect-out").querySelectorAll("tr[data-k]")];
  const outs = rows.map(tr => { const o = E.expected_outcomes[Number(tr.dataset.k)]; return Object.assign({}, o, { status: tr.querySelector(".st").value, timing_us: Number(tr.querySelector(".tm").value || o.timing_us), check: tr.querySelector(".ck").value, verified: tr.querySelector(".ver").checked }); });
  if (outs.some(o => !o.verified)) { status("write-status", "tick every line you checked first", "bad"); return; }
  try { S.file = await runJob(`${BASE}/testcase${STANDIN ? "?standin=1" : ""}`, { sequence: E.sequence, expected_outcomes: outs, verified: true, name: name(), scenario_name: (S.view || {}).name || "", standin: STANDIN, author: "model" }, "write-prog"); }
  catch (e) { status("write-status", e.message, "bad"); return; }
  const F = S.file, two = F.two_sided || {};
  const runs = (two.runs || []).map(x => `<li>a simulated <b>${esc(x.drive)}</b> drive, the test looking for ${x.expect === "fault" ? "the error" : "the fix"}: it should <b>${esc(x.wanted)}</b>, it did <b>${esc(x.got)}</b>${x.wanted === x.got ? "" : " ✘"}</li>`).join("");
  status("write-status", "written", "ok");
  $("file-out").innerHTML = `<div class="answer"><p><b>${esc(F.name)}</b> (version ${esc(F.version)}) is written.</p>
      <p>Tried on the simulated drive: ${two.ok ? "<b>every run gave what was wanted</b>" : two.runs ? "<b class='bad'>a run did not give what was wanted</b>" : esc(two.words || "not tried")}.</p>${runs ? `<ul>${runs}</ul>` : ""}
      <details class="node"><summary>The whole test file</summary><div class="in"><p class="hint">Saved at ${esc(F.path)}</p><pre class="file">${esc(F.text || "")}</pre></div></details>
      <div class="row" style="margin-top:8px"><button class="primary" id="btn-approve">Approve this test</button><span id="approve-status" class="status"></span></div></div>`;
  $("btn-approve").onclick = approve;
  if (!two.ok) { $("btn-approve").disabled = true; status("approve-status", "the simulated trial did not give what was wanted: write it again before approving", "bad"); }
}
async function approve() {
  if (!needName()) return;
  try {
    await api("POST", `${BASE}/testcase/approve`, { path: S.file.path, name: name(), revision_id: (S.sol || {}).revision_id, two_sided: (S.file.two_sided || {}).ok });
    status("approve-status", `approved by ${name()}; this error is done`, "ok");
    $("btn-approve").disabled = true;
    $("file-out").insertAdjacentHTML("beforeend", `<div class="did"><b>This error is done.</b> <a href="${esc($("back-link").href)}">Back to the errors</a></div>`);
  } catch (e) { status("approve-status", e.message, "bad"); }
}

// ------------------------------------------------------------------ ask the model (optional)
async function ask() {
  const msg = ($("chat-msg").value || "").trim(); if (!msg) return;
  if (!needName()) return;
  $("btn-send").disabled = true;
  try {
    const r = await api("POST", `${BASE}/chat${STANDIN ? "?standin=1" : ""}`, { message: msg, name: name(), standin: STANDIN,
      context: { rows: ((S.W || {}).commands || []).map(c => ({ level: c.level, rowid: c.rowid })), include_memory: false } });
    $("chat").innerHTML = (r.history || []).filter(h => h.text).slice(-20).map(h => `<div class="msg ${String(h.role || h.who || "").startsWith("admin") ? "me" : ""}">${esc(h.text)}</div>`).join("")
      || `<div class="msg">${esc((r.answer || {}).answer || "")}</div>`;
    $("chat-msg").value = "";
  } catch (e) { $("chat").insertAdjacentHTML("beforeend", `<div class="msg bad">${esc(e.message)}</div>`); }
  $("btn-send").disabled = false;
}

// ------------------------------------------------------------------ wiring
(async () => {
  document.querySelectorAll("button.nav").forEach(b => b.addEventListener("click", () => $(b.dataset.go).scrollIntoView({ behavior: "smooth" })));
  try { $("name").value = localStorage.getItem("agents.admin") || ""; } catch (e) { /* private window */ }
  $("name").addEventListener("change", () => { try { localStorage.setItem("agents.admin", name()); } catch (e) { /* private window */ } });
  const back = Q.get("back"); if (back && back.startsWith("/")) $("back-link").href = back;
  $("btn-show").onclick = showWindow;
  $("win").addEventListener("click", e => { const b = e.target.closest("button.exp"); if (b) expand(b); });
  $("btn-isolate").onclick = isolate;
  $("btn-send").onclick = ask;
  if (!UID || !Number.isInteger(FID)) { $("load-error").hidden = false; $("load-error").textContent = "open this page from the errors page: the address needs ?upload=…&finding=…"; return; }
  try { await loadError(); } catch (e) { $("load-error").hidden = false; $("load-error").textContent = "could not load the error: " + e.message; return; }
  await showWindow();
})();
