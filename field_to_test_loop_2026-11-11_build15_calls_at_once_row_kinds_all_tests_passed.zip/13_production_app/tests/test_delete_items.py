"""Deleting an item (owner, 2026-11-09: "why only multiselect, there can be rules which can be deleted").

    python3 -m pytest -q tests/test_delete_items.py

Through the real API (Flask test client, a throw-away engine database, no step is executed):
  - a deleted item leaves the list, its rule file moves to rules/_deleted/, and the register says who, when and why;
  - a deleted seed (an analytics example, a detector item) does not come back by itself;
  - Restore puts it back as it was (procedure and code record included);
  - code being written for it is stopped; a Run of it, or a flow's step of it, still going refuses the delete;
  - a new item with the same name gets another id (the deleted one keeps its name for Restore);
  - a plan approved after the delete does not run the deleted item.
"""
import copy
import json
import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(HERE)
sys.path.insert(0, APP_DIR)
sys.path.insert(0, os.path.join(APP_DIR, "app"))
from agentic import core, family1, family3, pipeline, procedures as PR, rule_evidence as E   # noqa: E402

U = "up-20261108-123729-0a98"
pytestmark = pytest.mark.skipif(not os.path.exists(os.path.join(E.APP, "uploads", U, "hier.sqlite")), reason="the S17 sample upload is not on this machine")
SEED = ("analytics", "nvme_command", "read_pattern")
DETECTOR = ("errors", "nvme_command", "cmd_read_failure")


class QuietEngine(core.Engine):
    def kick(self, rid):            # the runs are recorded, their steps are not executed
        pass


@pytest.fixture
def api(tmp_path, monkeypatch):
    from flask import Flask
    from api import agentic_api as A
    monkeypatch.setattr(family1, "knowledge_dir", lambda: str(tmp_path / "knowledge"))
    family3._SECTIONS_SEEN[0] = None
    family3.tree()
    store = core.Store(str(tmp_path / "agentic.sqlite"))
    eng = QuietEngine(store, {"rule_code": family3, "rule_exec": family3, "flow": pipeline}, runner=None)
    pid = store.exec("INSERT INTO project (admin, name, upload_id, created, updated) VALUES ('Sagar', 'S17', ?, 0, 0)", (U,))
    monkeypatch.setattr(A, "engine", lambda: eng)
    app = Flask(__name__)
    app.register_blueprint(A.bp)
    yield app.test_client(), eng, pid
    family3._SECTIONS_SEEN[0] = None


def url(item, tail=""):
    return "/api/agents/rules/%s/%s/%s%s" % (item + (("/" + tail) if tail else "",))


def keys(c):
    return {(s["section"], l["level"], i["id"]) for s in c.get("/api/agents/rules").get_json() for l in s["levels"] for i in l["items"]}


@pytest.mark.parametrize("item", [SEED, DETECTOR])
def test_a_deleted_item_leaves_the_list_and_restore_puts_it_back_as_it_was(api, item):
    c, eng, pid = api
    before = family3.load_rule(*item)
    if item == SEED:            # a verified-code record, to see it come back with the item
        before["code"] = {"path": "/x/read_pattern.p1.run4.py", "procedure_sha": PR.sha(PR.procedure_of(before)), "verified_by": "Sagar"}
        family3.save_rule(before)
    assert item in keys(c)
    r = c.delete(url(item), json={"admin": "Sagar", "why": "the same check as another item"})
    j = r.get_json()
    assert r.status_code == 200 and j["deleted"]["by"] == "Sagar" and j["deleted"]["why"] == "the same check as another item"
    assert item not in keys(c)                                     # tree() runs seed(): the seed did not come back
    assert family3.load_rule(*item) is None
    assert os.path.exists(j["deleted"]["file"]) and "/_deleted/%s/%s/" % item[:2] in j["deleted"]["file"]
    gone = [x for x in c.get("/api/agents/rules/deleted").get_json() if x["by"] != family3.INSTALL_DELETED_BY]      # not the rules a new installation starts without
    assert [(x["section"], x["level"], x["id"]) for x in gone] == [item]
    assert c.get(url(item, "explain")).status_code == 404
    # Restore
    r = c.post(url(item, "restore"), json={"admin": "Sagar"})
    assert r.status_code == 200 and [x for x in r.get_json()["deleted_items"] if x["by"] != family3.INSTALL_DELETED_BY] == []
    assert item in keys(c) and family3.load_rule(*item) == before
    reg = json.load(open(family3.deleted_file()))
    assert next(x for x in reg if (x["section"], x["level"], x["id"]) == item)["restored_by"] == "Sagar"       # the register keeps the history
    assert c.post(url(item, "restore"), json={"admin": "Sagar"}).status_code == 400


def test_coding_is_stopped_and_a_run_or_a_flow_step_still_going_refuses_the_delete(api):
    c, eng, pid = api
    coding = c.post(url(SEED, "code"), json={"project": pid, "admin": "Sagar"}).get_json()["run"]
    run = eng.start(pid, "rule_exec", "Run: Read pattern", {"_kind": "rule_exec", "section": SEED[0], "level": SEED[1], "id": SEED[2]})
    r = c.delete(url(SEED), json={"admin": "Sagar"})
    assert r.status_code == 409 and "Run of this item is going" in r.get_json()["error"]
    eng.store.exec("UPDATE run SET state='finished' WHERE id=?", (run,))
    # a flow that still has a step of this item to do
    flow = eng.store.exec("INSERT INTO run (project, kind, target, params, state, created, updated) VALUES (?, 'flow', 'Family 1 -> 2 -> 3', '{}', 'running', 0, 0)", (pid,))
    eng.store.exec("INSERT INTO step (run, idx, key, title, state) VALUES (?, 0, ?, 'Run', 'waiting')", (flow, "f3:%s/%s/%s:run" % SEED))
    r = c.delete(url(SEED), json={"admin": "Sagar"})
    assert r.status_code == 409 and "still has steps for this item" in r.get_json()["error"]
    eng.store.exec("UPDATE step SET state='done' WHERE run=?", (flow,))
    r = c.delete(url(SEED), json={"admin": "Sagar"}).get_json()
    assert r["stopped_coding"] == [coding]
    assert eng.store.one("SELECT state FROM run WHERE id=?", (coding,))["state"] == "stopped"


def test_a_new_item_with_the_same_name_gets_another_id_and_restore_still_works(api):
    c, eng, pid = api
    sec, lvl = "analytics", "link"
    first = family3.add_item(sec, lvl, "Replay count", "how many replays", "Sagar")
    c.delete(url((sec, lvl, first["id"])), json={"admin": "Sagar"})
    second = family3.add_item(sec, lvl, "Replay count", "again", "Sagar")
    assert second["id"] != first["id"]
    assert c.post(url((sec, lvl, first["id"]), "restore"), json={"admin": "Sagar"}).status_code == 200
    assert {(sec, lvl, first["id"]), (sec, lvl, second["id"])} <= keys(c)


def test_a_plan_approved_after_the_delete_does_not_run_the_deleted_item(api):
    c, eng, pid = api
    c.delete(url(DETECTOR), json={"admin": "Sagar"})
    plan, sel = pipeline._plan_steps(eng, {"edits": {"selected": ["%s/%s/%s" % SEED, "%s/%s/%s" % DETECTOR]}}, "Sagar")
    assert sel == ["%s/%s/%s" % SEED]
    assert not [s for s in plan if "cmd_read_failure" in s["key"]]
    with pytest.raises(ValueError, match="every chosen item was deleted"):
        pipeline._plan_steps(eng, {"edits": {"selected": ["%s/%s/%s" % DETECTOR]}}, "Sagar")
