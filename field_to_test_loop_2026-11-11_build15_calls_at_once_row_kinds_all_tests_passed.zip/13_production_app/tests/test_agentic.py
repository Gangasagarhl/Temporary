"""End-to-end test of the agent families (/agents) against the running server.

    python3 tests/test_agentic.py [--base http://127.0.0.1:8077] [--real]

Without --real every agent answers through the stand-in (deterministic, no model). With --real a few agent calls also go
through Claude Code headless (the key and model of ~/.claude/settings.json): one Family 1 run on one CSV, one question
in a review, one rule conversation. Everything the test creates (projects, runs, uploads, dictionaries, strategies,
rule versions, exports) is removed at the end; the seeded rules are put back as they were.
"""
import csv
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import time
import urllib.error
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
BASE = "http://127.0.0.1:8077"
if "--base" in sys.argv:
    BASE = sys.argv[sys.argv.index("--base") + 1]
REAL = "--real" in sys.argv
S08_SRC = os.path.join(ROOT, "samples", "five_level", "S08")
S08 = os.path.join(ROOT, "uploads", "_agentic_test_S08")       # a clean folder: only the five exports (the sample folder also holds the generator's answer key)
FIVE = ["packets.csv", "link.csv", "split.csv", "NVME_Transactions.csv", "nvme_command.csv"]
BIG_UPLOAD = "up-20261102-210717-2895"
KNOW = os.path.join(ROOT, "knowledge")
ADMIN = "agentic-test"
RESULTS = {"pass": 0, "fail": 0}
CREATED = {"projects": [], "uploads": [], "dirs": [], "rule_backups": {}}


def check(name, ok, detail=""):
    RESULTS["pass" if ok else "fail"] += 1
    print("%s  %s%s" % ("PASS" if ok else "FAIL", name, ("  | " + str(detail)[:300]) if detail != "" else ""), flush=True)
    return ok


class ApiError(Exception):
    def __init__(self, code, body):
        super().__init__("HTTP %s: %s" % (code, body))
        self.code, self.body = code, body


def api(method, path, body=None, timeout=120):
    req = urllib.request.Request(BASE + path, data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Content-Type": "application/json"}, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            return json.loads(raw) if raw[:1] in (b"{", b"[") else raw
    except urllib.error.HTTPError as e:
        raw = e.read().decode(errors="replace")
        try:
            raw = json.loads(raw)
        except ValueError:
            pass
        raise ApiError(e.code, raw)


def wait(rid, until, timeout=600, label=""):
    t0 = time.time()
    while time.time() - t0 < timeout:
        v = api("GET", "/api/agents/runs/%d" % rid)
        if until(v):
            return v
        if v["run"]["state"] in ("stopped", "finished") and not until(v):
            return v
        if any(s["state"] == "failed" for s in v["steps"]):
            return v
        time.sleep(1.5)
    print("      (timed out waiting for %s)" % label)
    return api("GET", "/api/agents/runs/%d" % rid)


def open_review(v):
    return next((r for r in v["reviews"] if r["state"] == "open"), None)


def has_open(v):
    return open_review(v) is not None


def finished(v):
    return v["run"]["state"] in ("finished", "stopped")


def step(v, key):
    return next((s for s in v["steps"] if s["key"] == key), None)


def _ticked(rv, decision, edits):
    """The admin in the test ticks every rule the page asks about (a strategy is refused otherwise)."""
    d = rv.get("data") or {}
    if decision == "approve" and d.get("joins") and edits is None:
        return {"verified": list((d.get("needs_check") or {}).keys())}
    return edits


def decide(rv, decision, comment="", edits=None):
    return api("POST", "/api/agents/reviews/%d/decide" % rv["id"], {"decision": decision, "admin": ADMIN, "comment": comment, "edits": _ticked(rv, decision, edits)})


def backup_rule(sec, lvl, rid):
    p = os.path.join(KNOW, "rules", sec, lvl, rid + ".json")
    if p not in CREATED["rule_backups"]:
        CREATED["rule_backups"][p] = open(p).read() if os.path.exists(p) else None


# ---------------------------------------------------------------------------------------------- 0. settings
def t_settings():
    print("\n-- 0. settings")
    s0 = api("GET", "/api/agents/settings")
    CREATED["settings"] = {k: s0.get(k) for k in ("runtime", "model", "slices")}
    check("settings name the runtime (Claude Code by default, from ~/.claude/settings.json)", s0.get("runtime") in ("claude-code", "http", "standin"), s0.get("runtime"))
    try:
        api("PUT", "/api/agents/settings", {"runtime": "nonsense"})
        check("an unknown runtime is refused", False)
    except ApiError as e:
        check("an unknown runtime is refused", e.code == 400, e.body)
    s1 = api("PUT", "/api/agents/settings", {"runtime": "standin", "slices": 6})
    check("the runtime can be switched (to the stand-in for this test)", s1["runtime"] == "standin")


# ---------------------------------------------------------------------------------------------- 1. project
def t_project():
    print("\n-- 1. start page: project")
    for bad, why in (({"admin": ADMIN, "folder": "/nonexistent"}, "a missing folder"), ({"admin": ADMIN, "folder": HERE}, "a folder without CSV files"),
                     ({"admin": ADMIN, "folder": S08, "refs": ["/nonexistent/refs"]}, "a missing reference folder")):
        try:
            api("POST", "/api/agents/projects", bad)
            check("refused: %s" % why, False)
        except ApiError as e:
            check("refused: %s" % why, e.code == 400, e.body)
    inv = api("GET", "/api/agents/inventory?folder=" + urllib.request.quote(S08))
    levels = sorted(str(f["level"]) for f in inv["files"])
    check("the Director's inventory sees the five CSVs and their levels", levels == sorted(["packets", "link", "split", "nvme_transaction", "nvme_command"]), levels)
    p = api("POST", "/api/agents/projects", {"admin": ADMIN, "name": "agentic test S08", "folder": S08})
    CREATED["projects"].append(p["id"])
    check("a project is created with the default reference folder", p["folder"] == S08 and p["refs"] and os.path.isdir(p["refs"][0]), p["refs"])
    return p


# ---------------------------------------------------------------------------------------------- 2. Family 1
def t_family1(p):
    print("\n-- 2. Family 1: one sub-family per CSV, reviews")
    r = api("POST", "/api/agents/projects/%d/family1" % p["id"])
    rid = r["run"]
    keys = [s["key"] for s in r["view"]["steps"]]
    check("the run has the Director and 3 steps per CSV (Explorer, Grounder, Manager) = 16 steps", len(keys) == 16 and keys[0] == "director", len(keys))
    v = wait(rid, has_open, 300, "the first dictionary review")
    rv = open_review(v)
    check("the run stops at the first Manager review", rv is not None and step(v, rv and next(s["key"] for s in v["steps"] if s["id"] == rv["step"]))["state"] == "needs_review" if rv else False)
    if not rv:
        return None
    check("the review is addressed to the admin by name", ("Admin %s, need review" % ADMIN) in rv["body"], rv["body"][:120])
    rvstep = next(s for s in v["steps"] if s["id"] == rv["step"])
    fname = rvstep["key"].split(":", 1)[1]
    ex = step(v, "explore:" + fname)
    mem = json.load(open(ex["output"]["memory_file"]))
    with open(os.path.join(S08, fname), newline="") as fh:
        n_rows = sum(1 for _ in csv.reader(fh)) - 1
    check("the Data Explorer read EVERY row of the file by code (no sample)", mem["rows"] == n_rows and ex["output"]["rows"] == n_rows, (mem["rows"], n_rows))
    kwc = next((c for c in mem["columns"] if c.get("keywords")), None)
    if kwc:
        k = kwc["keywords"][0]
        with open(os.path.join(S08, fname), newline="") as fh:
            rd = csv.reader(fh)
            hdr = next(rd)
            sys.path.insert(0, ROOT)
            from agentic import family1 as F1
            exact = sum(1 for row in rd if kwc["position"] < len(row) and row[kwc["position"]].strip() and k["value"] in F1.keyword_names(row[kwc["position"]].strip(), kwc["column"]))
        check("each keyword is counted over every row, with the lines where it appears", k["count"] == exact and k["rows"], (kwc["column"], k["value"], k["count"], exact, k["rows"]))
    check("the Data Explorer keeps its own memory (the data only: no meanings in it)", os.path.exists(ex["output"]["memory_file"]) and not any("meaning" in c for c in mem["columns"]))
    gr = step(v, "ground:" + fname)
    gmem = json.load(open(gr["output"]["memory_file"]))
    check("the Data Grounder keeps its own memory (the meanings only, each with where it comes from)", all("source" in m for m in gmem["columns"].values()) and "rows" not in gmem, len(gmem["columns"]))
    d0 = rv["data"]
    check("the review starts with what the file is (a summary), the facts, and where the meanings come from",
          bool(d0.get("summary")) and d0["facts"]["rows"] == n_rows and d0.get("counts") and all(t.get("where", "").startswith(os.path.join(S08, fname)) for t in d0["table"]), d0.get("summary", "")[:120])
    ev = v["evidence"]
    doc_ok = [e for e in ev if e["kind"] == "document" and e["verified"]]
    check("meanings from the reference documents are checked against the line they quote", len(doc_ok) > 0, "%d checked document quotes" % len(doc_ok))
    # a hallucinated claim is caught by the code
    sys.path.insert(0, ROOT)
    from agentic import core
    refs = core.References(p["refs"], "/tmp/agentic_test_pdf_cache")
    bad = core.check_claims([{"text": "x", "source": {"kind": "document", "ref": doc_ok[0]["ref"] if doc_ok else "nofile:1", "quote": "a sentence that is in no document at all 4711"}},
                             {"text": "y", "source": {"kind": "data", "ref": "PSN", "quote": "999999999"}}, {"text": "z", "source": {"kind": "model", "ref": "", "quote": "trust me"}}],
                            refs=refs, data_values={"PSN": ["1", "2"]})
    check("a quote found in no document, a value not in the data, and a claim with no source are all marked NOT verified", not any(c["verified"] for c in bad), [c["why"] for c in bad])
    # ask
    a = api("POST", "/api/agents/reviews/%d/ask" % rv["id"], {"message": "Which rows have %s?" % (kwc["keywords"][0]["value"] if kwc else "a value"), "admin": ADMIN}, timeout=300)
    check("the admin asks the Manager; a data question goes to the Data Explorer and comes back with the lines", a.get("producer", "").startswith("Manager") and
          "Data Explorer" in a.get("answer", "") and "line" in a.get("answer", ""), a.get("answer", "")[:200])
    a2 = api("POST", "/api/agents/reviews/%d/ask" % rv["id"], {"message": "What does %s mean?" % (kwc["column"] if kwc else "PSN"), "admin": ADMIN}, timeout=300)
    check("a meaning question goes to the Data Grounder", "Data Grounder" in a2.get("answer", "") and "Data Explorer" not in a2.get("answer", ""), a2.get("answer", "")[:200])
    # change with a comment: the step runs again and comes back for review
    decide(rv, "change", "please look again")
    v = wait(rid, lambda x: any(r2["state"] == "open" for r2 in x["reviews"]), 300, "the review after a change")
    rv2 = open_review(v)
    check("Change sends the step back; it runs again and asks for review again", rv2 is not None and rv2["id"] != rv["id"] and rv2["step"] == rv["step"])
    table = (rv2 or {}).get("data", {}).get("table") or []
    col = table[0]["column"] if table else None
    decide(rv2, "approve", "", {col: "set by the test admin"} if col else None)
    n_approved = 1
    while True:
        v = wait(rid, lambda x: has_open(x) or finished(x), 300, "the next dictionary review")
        rv = open_review(v)
        if not rv:
            break
        decide(rv, "approve")
        n_approved += 1
    check("all five dictionaries were reviewed and approved and the run finished", v["run"]["state"] == "finished" and n_approved == 5, (v["run"]["state"], n_approved))
    fmt_dirs = set()
    for s in v["steps"]:
        if s["key"].startswith("manager:"):
            d = json.load(open(s["output"]["dictionary_file"]))
            fmt_dirs.add(os.path.join(KNOW, "dictionaries", d["format_key"]))
    CREATED["dirs"] += sorted(fmt_dirs)
    stored = [f for d in fmt_dirs if os.path.isdir(d) for f in os.listdir(d) if f.endswith(".current.json")]
    check("an approved dictionary is stored per CSV (current and versioned)", len(stored) == 5, stored)
    if col:
        found = False
        for d in fmt_dirs:
            for f in os.listdir(d):
                if f.endswith(".current.json"):
                    j = json.load(open(os.path.join(d, f)))
                    found = found or any(c["column"] == col and c["meaning"] == "set by the test admin" and c["status"] == "given by the admin" for c in j["columns"])
        check("the admin's edit is in the stored dictionary", found, col)
    return rid


# ---------------------------------------------------------------------------------------------- 3. Family 2
def t_family2(p):
    print("\n-- 3. Family 2: strategy, build, tests")
    r = api("POST", "/api/agents/projects/%d/family2" % p["id"])
    rid = r["run"]
    # no REA findings were given: the REA step asks for them here, where they are used (not on the start page)
    v = wait(rid, has_open, 300, "the REA question")
    rv = open_review(v)
    check("with no REA findings given, the REA step asks for them at this point", rv and rv["title"].startswith("REA findings"), (rv or {}).get("title"))
    try:
        decide(rv, "approve", edits={"rea": "/no/such/rea/folder"})
        check("a REA folder that does not exist is refused, and the question stays open", False)
    except ApiError as e:
        still = open_review(api("GET", "/api/agents/runs/%d" % rid))
        check("a REA folder that does not exist is refused, and the question stays open", e.code == 400 and still and still["id"] == rv["id"], e.body)
    rea_dir = os.path.join(ROOT, "runs", "_agentic_test_rea")
    os.makedirs(rea_dir, exist_ok=True)
    with open(os.path.join(rea_dir, "group_packets.c"), "w") as fh:
        fh.write("/* decompiled: how the analyzer groups packets (test fixture) */\n"
                 "if (pkt->PSN == open->PSN && pkt->dir == open->dir) join(open, pkt);   /* PSN */\n"
                 "split_key = (RequesterID << 8) | Tag;   /* RequesterID Tag */\n")
    CREATED["dirs"].append(rea_dir)
    decide(rv, "approve", edits={"rea": rea_dir})
    v = wait(rid, has_open, 300, "the strategy review")
    rs = step(v, "rea_search")
    check("the REA findings given there are read for the join columns (a step is added for it)", rs and rs["state"] == "done" and "PSN" in (rs["output"].get("hits") or {}),
          rs and (rs["state"], sorted((rs["output"].get("hits") or {}))))
    ls = step(v, "last_strategy")
    check("no strategy was approved before for this format: the 'used last time' step is skipped with the reason", ls["state"] == "skipped", ls.get("note"))
    rv = open_review(v)
    check("the Coder's strategy is up for review, with the five joins and evidence", rv and "packets -> link transaction" in rv["body"] and "evidence" in rv["body"], (rv or {}).get("title"))
    coder = step(v, "coder")
    check("every column the strategy uses exists in the files (no problem found by the code)", coder["output"].get("problems") == [], coder["output"].get("problems"))
    col = step(v, "collect")
    srcs = {s["source"]: s for s in col["output"].get("sources") or []}
    check("the collector reports IMS and JIRA as not connected on this machine, with how to connect them", all(not srcs[k]["reachable"] and "not connected" in srcs[k]["note"] for k in ("IMS", "JIRA")))
    check("the collector says why the web was not searched in this run (the stand-in cannot search it)", not srcs["web"]["reachable"] and "stand-in" in srcs["web"]["note"], srcs["web"])
    check("the collector used Family 1's approved dictionaries", srcs.get("Family 1 dictionaries", {}).get("reachable") is True)
    decide(rv, "approve")
    fmt = coder["output"]["format"]
    CREATED["dirs"].append(os.path.join(KNOW, "strategies", fmt))
    v = wait(rid, has_open, 120, "the build question")
    rv = open_review(v)
    check("the Builder asks before building (no tree was built before from these files)", rv and "Shall I build" in rv["title"], (rv or {}).get("title"))
    decide(rv, "approve")
    v = wait(rid, has_open, 900, "the test review")
    b = step(v, "build")
    up = b["output"].get("upload_id")
    if up:
        CREATED["uploads"].append(up)
    check("the Builder loaded and built the five files (a new upload)", b["state"] == "done" and up and b["output"].get("reused") is False, b["output"])
    st = step(v, "slice_test")
    check("the Code tester rebuilt 5 to 10 random windows of the real data", 5 <= st["output"].get("of", 0) <= 10, st["output"].get("of"))
    check("every random window agrees with the analyzer's counts and with the full tree", st["output"].get("passed") == st["output"].get("of"),
          [w["name"] for w in st["output"].get("windows", []) if not w["passed"]])
    br = step(v, "breaker")
    check("the Breaker tried the hard windows (start, end, busiest moment ...)", br["state"] in ("done", "skipped") and (br["output"].get("of", 0) >= 3 or br["state"] == "skipped"), br["output"].get("of"))
    check("every hard window passed", br["state"] == "skipped" or br["output"].get("passed") == br["output"].get("of"),
          [(w["name"], {k: x["n"] for k, x in w["count_mismatch"].items() if x["n"]}, {k: x["n"] for k, x in w["parent_mismatch"].items() if x["n"]}) for w in br["output"].get("windows", []) if not w["passed"]])
    ind = step(v, "independent")
    inv = ind["output"].get("invariants") or []
    check("the Independent tester checked every join with the column meanings: no violation", inv and all(x.get("violations") == 0 and x.get("rows_checked", 0) > 0 for x in inv),
          [(x["check"][:40], x.get("rows_checked"), x.get("violations")) for x in inv])
    decide(open_review(v), "approve")
    v = wait(rid, finished, 60, "the end of the run")
    pj = api("GET", "/api/agents/projects/%d" % p["id"])
    check("the run finished and the project is linked to its built data", v["run"]["state"] == "finished" and pj["upload_id"] == up, (v["run"]["state"], pj["upload_id"]))
    # the second time: the stored strategy is offered
    r = api("POST", "/api/agents/projects/%d/family2" % p["id"])
    rid2 = r["run"]
    v = wait(rid2, has_open, 120, "the 'used last time' review")
    rv = open_review(v)
    check("the second time, the strategy used last time is offered: proceed?", rv and "Proceed with strategy v1" in rv["title"], (rv or {}).get("title"))
    decide(rv, "approve")
    v = wait(rid2, has_open, 120, "the build question (second time)")
    check("approving it skips the research and the Coder", all(step(v, k)["state"] == "skipped" for k in ("rea", "collect", "coder")), [step(v, k)["state"] for k in ("rea", "collect", "coder")])
    rv = open_review(v)
    check("the second time, the Builder says the tree built from these same files is used again", rv and rv["title"].startswith("Use the tree built before") and (rv["data"].get("reuse") or {}).get("upload_id") == up,
          (rv or {}).get("title"))
    decide(rv, "approve")
    v = wait(rid2, has_open, 600, "the test review (second time)")
    check("the Builder reuses the data already built (nothing rebuilt)", step(v, "build")["output"].get("reused") is True, step(v, "build")["output"])
    decide(open_review(v), "reject", "test of reject")
    v = api("GET", "/api/agents/runs/%d" % rid2)
    check("Reject stops the run, with who and why", v["run"]["state"] == "stopped" and ADMIN in (v["run"]["summary"] or ""), v["run"]["summary"])
    return up


# ---------------------------------------------------------------------------------------------- 4. Family 3
def run_rule(p, sec, lvl, rid, upload_id=None, approve=True):
    """Proceed: the code (verified, or written and reviewed: approved here), run, test, export, then the result review."""
    r = api("POST", "/api/agents/rules/%s/%s/%s/proceed" % (sec, lvl, rid), {"project": p["id"], "upload_id": upload_id})
    for _ in range(4):
        v = wait(r["run"], has_open, 600, "the review of %s" % rid)
        rv = open_review(v)
        st = next((s for s in v["steps"] if rv and s["id"] == rv["step"]), {})
        if rv and st.get("key") == "code":
            decide(rv, "approve")                     # the Coder's code, reviewed: it becomes the verified code
            continue
        if rv and approve:
            decide(rv, "approve")
        return r["run"], v, rv
    return r["run"], v, None


def approve_draft(p, sec, lvl, rid, message="as written"):
    backup_rule(sec, lvl, rid)
    r = api("POST", "/api/agents/rules/%s/%s/%s/edit" % (sec, lvl, rid), {"project": p["id"], "message": message})
    v = wait(r["run"], has_open, 300, "the procedure review of %s" % rid)
    rv = open_review(v)
    if rv:
        decide(rv, "approve")
    return v, rv


def code_it(p, sec, lvl, rid):
    """Code it: the Coder writes the code of the procedure; the program checks and tries it; the admin approves it."""
    r = api("POST", "/api/agents/rules/%s/%s/%s/code" % (sec, lvl, rid), {"project": p["id"], "admin": ADMIN})
    v = wait(r["run"], has_open, 600, "the code review of %s" % rid)
    rv = open_review(v)
    return r["run"], v, rv


def exec_rule(p, sec, lvl, rid):
    """Run: the verified code on the recording, checked and exported (no review)."""
    r = api("POST", "/api/agents/rules/%s/%s/%s/run" % (sec, lvl, rid), {"project": p["id"], "admin": ADMIN})
    v = wait(r["run"], lambda x: x["run"]["state"] in ("finished", "stopped") or any(s["state"] == "failed" for s in x["steps"]), 600, "the run of %s" % rid)
    return r["run"], v


def t_family3(p, up):
    print("\n-- 4. Family 3: items as source data + procedure + code; Edit, Code it, Run, Export CSV")
    tree = api("GET", "/api/agents/rules")
    secs = {s["section"]: s for s in tree}
    check("the sidebar has the two sections with the five levels each", set(secs) == {"analytics", "errors"} and all(len(s["levels"]) == 5 for s in tree))
    cmd_items = {i["id"]: i for i in secs["analytics"]["levels"][0]["items"]}
    check("Section 1 has the command type percentages and the read pattern items", {"command_type_share", "read_pattern"} <= set(cmd_items), list(cmd_items))
    n_err = sum(len(l["items"]) for l in secs["errors"]["levels"])
    check("Section 2 lists the owner's two rules on a new installation, each running the detector's verified code", n_err == 2 and all(
        i["code"] == "detector" for l in secs["errors"]["levels"] for i in l["items"]), n_err)
    demo = [i for l in secs["errors"]["levels"] for i in l["items"] if i["demo"]]
    check("the demo error is marked: the NVMe command timeout", len(demo) == 1 and demo[0]["id"] == "cmd_timeout", demo)
    for rid in ("command_type_share", "read_pattern"):
        backup_rule("analytics", "nvme_command", rid)
    x = api("GET", "/api/agents/rules/analytics/nvme_command/command_type_share/explain?upload=%s" % up)
    check("an item shows its source data with the full path in the recording, and its procedure step by step",
          x["sources"] and x["sources"][0]["path"] and x["sources"][0]["path"].endswith("nvme_command.csv") and x["sources"][0]["columns"] == ["OPC", "SQID"]
          and len(x["procedure"]["steps"]) >= 5 and any("hash map" in s for s in x["procedure"]["steps"]), x["sources"])
    if not x["code"]["verified"]:
        try:
            api("POST", "/api/agents/rules/analytics/nvme_command/command_type_share/run", {"project": p["id"], "admin": ADMIN})
            check("Run is refused while there is no verified code", False)
        except ApiError as e:
            check("Run is refused while there is no verified code", e.code == 409, e.body)
    # the Rule writer: a change in words -> the procedure comes back for review
    r = api("POST", "/api/agents/rules/analytics/nvme_command/command_type_share/edit", {"project": p["id"], "message": "keep it as written"})
    v = wait(r["run"], has_open, 300, "procedure review")
    rv = open_review(v)
    check("the Rule writer's procedure is up for review: source data, the numbered steps, the output", rv and "**Source data:**" in rv["body"] and "**Rules or procedure:**" in rv["body"], (rv or {}).get("title"))
    decide(rv, "change", "count admin and I/O commands together, as written")
    v = wait(r["run"], lambda q: any(z["state"] == "open" for z in q["reviews"]), 300, "procedure review after change")
    rv2 = open_review(v)
    check("Change on a procedure: the Rule writer answers and the procedure comes back", rv2 is not None and "count admin and I/O commands together" in rv2["body"], (rv2 or {}).get("body", "")[:100])
    decide(rv2, "approve")
    # the admin's own edit of the JSON: checked, versioned, and its code must be made again
    proc = dict(x["procedure_json"])
    try:
        api("PUT", "/api/agents/rules/analytics/nvme_command/command_type_share/procedure", {"procedure": {"steps": "not a list"}, "admin": ADMIN})
        check("a procedure that is not complete is refused, with every problem named", False)
    except ApiError as e:
        body = json.dumps(e.body) if not isinstance(e.body, str) else e.body      # the answer is JSON: {"error": "..."}
        check("a procedure that is not complete is refused, with every problem named", e.code == 400 and "source_data" in body and "steps" in body, body[:160])
    proc["steps"] = proc["steps"] + ["(test) This step only marks a new version; it changes nothing in the counting."]
    y = api("PUT", "/api/agents/rules/analytics/nvme_command/command_type_share/procedure", {"procedure": proc, "admin": ADMIN, "upload_id": up})
    check("the admin's edit is a new version of the procedure, and its code is needed again", y["changed"] and y["procedure_info"]["version"] >= 2
          and y["procedure_info"]["edited_by"] == ADMIN and not y["code"]["verified"], (y["procedure_info"], y["code"]))
    # Code it -> the program's checks and the trial run -> the admin approves -> verified
    rid_c, v, rv = code_it(p, "analytics", "nvme_command", "command_type_share")
    out = step(v, "code")["output"] or {}
    check("Code it: the Coder's Python is up for review with the program's checks; it is checked, not run", rv and "```python" in rv["body"] and "checked, not run" in rv["body"]
          and not out.get("problems") and "rows" not in out, (out.get("problems"), (rv or {}).get("title")))
    t = api("POST", "/api/agents/rules/analytics/nvme_command/command_type_share/try", {"review": rv["id"], "records": 50, "upload_id": up})
    check("Try on a sample: the code runs on the first records only, and its output has the procedure's columns", t["records"] == 50 and t["rows"] > 0
          and (t.get("summary") or {}).get("rows_read") == 50 and all(c["ok"] for c in t["checks"] if "columns" in c["check"]), t.get("checks"))
    check("the program's checks pass: the procedure's columns, the counts and the percentages add up", out.get("checks") and all(c["ok"] for c in out["checks"]),
          [(c["check"][:40], c["ok"]) for c in out.get("checks") or []])
    decide(rv, "approve")
    z = api("GET", "/api/agents/rules/analytics/nvme_command/command_type_share/explain?upload=%s" % up)
    check("approved, it is the verified code of this procedure version, with who approved it", z["code"]["verified"] and z["code"]["verified_by"] == ADMIN, z["code"])
    rid_x, v = exec_rule(p, "analytics", "nvme_command", "command_type_share")
    check("Run: the verified code runs on the recording, the Tester passes, the result is exported", v["run"]["state"] == "finished" and step(v, "test")["output"].get("passed") is True,
          [(s["key"], s["state"], (s.get("error") or "")[:80]) for s in v["steps"]])
    files = step(v, "export")["output"]["files"]
    check("the result is exported as CSV and HTML", os.path.exists(files.get("csv", "")) and os.path.exists(files.get("html", "")), files)
    db = os.path.join(ROOT, "uploads", up, "hier.sqlite")
    con = sqlite3.connect(db)
    n_cmd = con.execute("SELECT COUNT(*) FROM cmd").fetchone()[0]
    reads = con.execute("SELECT COUNT(*) FROM cmd WHERE opc=2 AND sqid!=0").fetchone()[0]
    rows = list(__import__("csv").reader(open(files["csv"])))[1:]
    check("independently: the exported counts add up to the commands of the upload", sum(int(q[1]) for q in rows) == n_cmd, (sum(int(q[1]) for q in rows), n_cmd))
    read_row = next((q for q in rows if q[0] == "Read"), None)
    check("independently: the Read line equals the Read commands counted straight from the data", read_row and int(read_row[1]) == reads, (read_row, reads))
    z = api("GET", "/api/agents/rules/analytics/nvme_command/command_type_share/explain?upload=%s" % up)
    check("Export CSV: the item keeps its last result on this recording", (z.get("last_result") or {}).get("csv") == files["csv"], z.get("last_result"))
    f = api("GET", "/api/agents/file?path=" + urllib.request.quote(files["csv"]))
    check("the export can be downloaded from the page", isinstance(f, bytes) and f.startswith(b"command type,count,percent"), f[:40] if isinstance(f, bytes) else f)
    try:
        api("GET", "/api/agents/file?path=/etc/passwd")
        check("a file outside the exports is refused", False)
    except ApiError as e:
        check("a file outside the exports is refused", e.code == 404)
    # read pattern: Code it, approve, Run; an independent recount in Python
    rid_c, v, rv = code_it(p, "analytics", "nvme_command", "read_pattern")
    if rv:
        decide(rv, "approve")
    rid_x, v = exec_rule(p, "analytics", "nvme_command", "read_pattern")
    res = {q[0]: int(q[1]) for q in list(__import__("csv").reader(open(step(v, "export")["output"]["files"]["csv"])))[1:]}
    last, seq, rnd, first = {}, 0, 0, 0
    for nsid, slba, nlb in con.execute("SELECT nsid, slba, nlb FROM cmd WHERE opc=2 AND sqid!=0 AND slba IS NOT NULL AND nlb IS NOT NULL ORDER BY t_ps, rowid_file"):
        if nsid not in last:
            first += 1
        elif slba == last[nsid][0] + last[nsid][1] + 1:
            seq += 1
        else:
            rnd += 1
        last[nsid] = (slba, nlb)
    check("independently: sequential and random reads recounted in Python match the verified code",
          res.get("sequential read", 0) == seq and res.get("random read (RndRead)", 0) == rnd and res.get("first read of its namespace", 0) == first, (res, seq, rnd, first))
    # Section 2 on this upload: the detector's own code, no Coder
    sec2 = next((rule for rule in ("ntx_interrupt_before_completion", "cmd_status_error")
                 if con.execute("SELECT COUNT(*) FROM finding WHERE rule=?", (rule.replace("_", ".", 1),)).fetchone()[0]), None)
    con.close()
    if sec2:
        lvl = "nvme_transaction" if sec2.startswith("ntx") else "nvme_command"
        restored = api("POST", "/api/agents/rules/errors/%s/%s/restore" % (lvl, sec2), {"admin": ADMIN})     # a new installation starts with it in Deleted items
        check("a detector rule that a new installation does not list can be restored", any(True for _ in [restored]))
        try:
            api("POST", "/api/agents/rules/errors/%s/%s/code" % (lvl, sec2), {"project": p["id"], "admin": ADMIN})
            check("a detector item has nothing to code: it runs the detector's verified code", False)
        except ApiError as e:
            check("a detector item has nothing to code: it runs the detector's verified code", e.code == 409, e.body)
        rid, v, rv = run_rule(p, "errors", lvl, sec2, up, approve=False)
        not_done = [(s_["key"], s_["state"], (s_.get("error") or "")[:300]) for s_ in v["steps"] if s_["state"] != "done"]
        check("a Section 2 item lists its errors on its result card (each error then has its own page)", rv and rv["data"].get("section") == "errors" and rv["data"].get("head"),
              (rv or {}).get("title") or not_done)
        check("the Section 2 tester finds every listed defect's row", step(v, "test")["output"].get("passed") is True, step(v, "test")["output"].get("checks"))
        exp_out = (step(v, "export") or {}).get("output") or {}
        check("the export step wrote its files", bool((exp_out.get("files") or {}).get("html")), (step(v, "export") or {}).get("state"))
        html = open(exp_out["files"]["html"]).read() if (exp_out.get("files") or {}).get("html") else ""
        check("the HTML export links every defect to /isolate", "/isolate?upload=%s&finding=" % up in html)
        decide(rv, "approve")
    # a new item, from the admin's words to a verified run
    a = api("POST", "/api/agents/rules", {"section": "analytics", "level": "link", "name": "agentic test link TLP types", "description": "percentage by tlp_type", "admin": ADMIN, "project": p["id"]})
    CREATED["rule_backups"][os.path.join(KNOW, "rules", "analytics", "link", a["rule"]["id"] + ".json")] = None
    v = wait(a["run"], has_open, 300, "the new item's first procedure")
    rv = open_review(v)
    check("Add creates the item and the Rule writer drafts its procedure from the words (a share by TLP Type)", rv and "TLP Type" in rv["body"], (rv or {}).get("body", "")[:200])
    decide(rv, "approve")
    rid, v, rv = run_rule(p, "analytics", "link", a["rule"]["id"], up)
    check("the new item is coded, reviewed, run, and its tester passes", step(v, "test")["output"].get("passed") is True, step(v, "test")["output"].get("checks"))
    tree = api("GET", "/api/agents/rules")
    names = [i["name"] for s in tree for l in s["levels"] for i in l["items"]]
    check("the new item is in the sidebar", "agentic test link TLP types" in names)


def t_demo_big(p_big):
    print("\n-- 5. the Section 2 demo on the large recording: the NVMe command timeout")
    rid, v, rv = run_rule(p_big, "errors", "nvme_command", "cmd_timeout", BIG_UPLOAD, approve=False)
    res = step(v, "run")["output"]
    test = step(v, "test")["output"]
    check("the demo error is found on the large recording", res.get("rows", 0) > 0, res.get("rows"))
    check("the tester passes it", test.get("passed") is True, test.get("checks"))
    if rv:
        decide(rv, "approve")


# ---------------------------------------------------------------------------------------------- 6. failure, retry, resume
def t_retry_resume(p):
    print("\n-- 6. a failed step is retried; a run survives a server restart")
    p2 = api("POST", "/api/agents/projects", {"admin": ADMIN, "name": "agentic test no data", "folder": S08})
    CREATED["projects"].append(p2["id"])
    r = api("POST", "/api/agents/rules/analytics/nvme_command/command_type_share/proceed", {"project": p2["id"]})
    v = wait(r["run"], lambda x: any(s["state"] == "failed" for s in x["steps"]), 60, "the failure")
    fs = next((s for s in v["steps"] if s["state"] == "failed"), None)
    check("a step that cannot work fails with a plain reason, and the run waits", fs and "no built data" in (fs["error"] or ""), (fs or {}).get("error", "").split("\n")[0][:120])
    api("PUT", "/api/agents/projects/%d" % p2["id"], {"upload_id": p["upload_id"]})
    api("POST", "/api/agents/runs/%d/retry" % r["run"])
    v = wait(r["run"], has_open, 300, "the review after retry")
    check("'run the failed step again' continues the run from that step", has_open(v), [s["state"] for s in v["steps"]])
    decide(open_review(v), "approve")
    # resume after a restart of the server
    r = api("POST", "/api/agents/projects/%d/family1" % p2["id"])
    time.sleep(1.0)
    subprocess.run(["systemctl", "--user", "restart", "f2t-app"], check=False)
    for _ in range(60):
        try:
            api("GET", "/api/agents/state")
            break
        except Exception:       # noqa: BLE001 - the server is restarting
            time.sleep(1)
    v = wait(r["run"], has_open, 300, "the review after the restart")
    check("a run interrupted by a server restart continues by itself from its first unfinished step", has_open(v), [s["state"] for s in v["steps"]][:5])
    api("POST", "/api/agents/runs/%d/stop" % r["run"], {"admin": ADMIN})
    check("Stop stops a run", api("GET", "/api/agents/runs/%d" % r["run"])["run"]["state"] == "stopped")


# ---------------------------------------------------------------------------------------------- 7. real agents (Claude Code)
def t_real(p):
    print("\n-- 7. real agents through Claude Code (the key and model of ~/.claude/settings.json)")
    api("PUT", "/api/agents/settings", {"runtime": "claude-code"})
    one = os.path.join("/tmp", "agentic_test_one_csv")
    shutil.rmtree(one, ignore_errors=True)
    os.makedirs(one)
    shutil.copy(os.path.join(S08, "split.csv"), one)
    CREATED["dirs"].append(one)
    p3 = api("POST", "/api/agents/projects", {"admin": ADMIN, "name": "agentic test real split", "folder": one})
    CREATED["projects"].append(p3["id"])
    r = api("POST", "/api/agents/projects/%d/family1" % p3["id"])
    v = wait(r["run"], has_open, 1200, "the real dictionary review")
    ex, gr = step(v, "explore:split.csv"), step(v, "ground:split.csv")
    check("the Explorer was answered by Claude Code", "Claude Code" in (ex.get("producer") or ""), ex.get("producer"))
    check("the Grounder was answered by Claude Code", "Claude Code" in (gr.get("producer") or "") or gr["state"] == "skipped", gr.get("producer"))
    ev = [e for e in v["evidence"] if e["step"] in (ex["id"], gr["id"])]
    check("the Grounder's meanings say where they come from, and documents and web pages are checked by the code", ev and all(e["kind"] in ("document", "web", "model") for e in ev),
          "%d meanings with a source: %s" % (len(ev), dict(__import__("collections").Counter((e["kind"], bool(e["verified"])) for e in ev))))
    check("the Data Explorer's summary is written by Claude Code from the counted profile", bool((ex.get("output") or {}).get("summary")), (ex.get("output") or {}).get("summary", "")[:160])
    if gr["state"] != "skipped":
        check("the Grounder may also search the web, after the reference documents", (gr.get("output") or {}).get("web_allowed") is True and "web search" in (gr.get("producer") or ""), gr.get("producer"))
    wev = [e for e in ev if e["kind"] == "web"]
    check("every web page the agents quoted was fetched and checked by the program (the quote found on it, or the claim marked not verified with why)",
          all(e["verified"] or (e["why"] or "").startswith("the program fetched") for e in wev),
          "%d web quotes: %d found on their page; %s" % (len(wev), sum(1 for e in wev if e["verified"]), "; ".join("%s %s" % ("OK" if e["verified"] else "NO", e["ref"]) for e in wev[:5])))
    rv = open_review(v)
    if rv:
        a = api("POST", "/api/agents/reviews/%d/ask" % rv["id"], {"message": "In one sentence: what does the Tag column hold?", "admin": ADMIN}, timeout=600)
        check("a question in a review is answered by Claude Code", "Claude Code" in a.get("producer", ""), (a.get("producer"), a.get("answer", "")[:160]))
        check("the answer is about the column asked for (the review's table is in the agent's context)", "tag" in a.get("answer", "").lower() and "doesn't say" not in a.get("answer", "").lower() and "does not say" not in a.get("answer", "").lower(), a.get("answer", "")[:200])
        api("PUT", "/api/agents/settings", {"runtime": "http"})
        a2 = api("POST", "/api/agents/reviews/%d/ask" % rv["id"], {"message": "In one sentence: what does the RequesterID column hold?", "admin": ADMIN}, timeout=600)
        check("the same question through the application's own model connection is answered too", "model connection" in a2.get("producer", ""), (a2.get("producer"), a2.get("answer", "")[:160]))
        check("that answer is about the column asked for too", "requester" in a2.get("answer", "").lower() and "does not say" not in a2.get("answer", "").lower(), a2.get("answer", "")[:200])
        api("PUT", "/api/agents/settings", {"runtime": "claude-code"})
        decide(rv, "approve")
        for d in os.listdir(os.path.join(KNOW, "dictionaries")):
            pth = os.path.join(KNOW, "dictionaries", d)
            if any(f.startswith("split.") for f in os.listdir(pth)) and pth not in CREATED["dirs"]:
                CREATED["dirs"].append(pth)
    backup_rule("analytics", "nvme_command", "command_type_share")
    r = api("POST", "/api/agents/rules/analytics/nvme_command/command_type_share/edit",
            {"project": p["id"], "message": "Instead of the command type, count the commands per submission queue (the sqid column)."})
    v = wait(r["run"], has_open, 900, "the real rule draft")
    rv = open_review(v)
    w = step(v, "write")
    proc = w["output"].get("procedure") or {}       # the Rule writer answers with a procedure (source data, steps, output) since 2026-11-09
    check("the Rule writer was answered by Claude Code and its procedure is complete", "Claude Code" in (w.get("producer") or "") and proc and not w["output"].get("problem"), (w.get("producer"), w["output"].get("problem")))
    check("Claude Code turned the admin's words into a procedure that counts by the submission queue (SQID)",
          any("sqid" in str(c).lower() for f in proc.get("source_data") or [] for c in f.get("columns") or []), proc.get("source_data"))
    if rv:
        decide(rv, "reject", "test only")
    api("PUT", "/api/agents/settings", {"runtime": "standin"})


def cleanup():
    print("\n-- clean-up")
    s = CREATED.get("settings")
    if s:
        try:
            api("PUT", "/api/agents/settings", s)
        except Exception:       # noqa: BLE001
            pass
    for up in CREATED["uploads"]:
        try:
            api("DELETE", "/api/hier/uploads/%s" % up)
        except Exception:       # noqa: BLE001
            pass
    for d in CREATED["dirs"]:
        shutil.rmtree(d, ignore_errors=True)
    for p, content in CREATED["rule_backups"].items():
        if content is None:
            if os.path.exists(p):
                os.remove(p)
        else:
            with open(p, "w") as fh:
                fh.write(content)
    for sec in ("analytics", "errors"):
        d = os.path.join(KNOW, "exports", sec)
        for base, _dirs, files in os.walk(d):
            for fn in files:
                if any(("_run%d." % rid) in fn for rid in CREATED.get("runs", [])):
                    os.remove(os.path.join(base, fn))
    db = os.path.join(ROOT, "db", "agentic.sqlite")
    con = sqlite3.connect(db, timeout=30)
    for pid in CREATED["projects"]:
        runs = [r[0] for r in con.execute("SELECT id FROM run WHERE project=?", (pid,))]
        for rid in runs:
            for t in ("step", "review", "evidence"):
                con.execute("DELETE FROM %s WHERE run=?" % t, (rid,))
            shutil.rmtree(os.path.join(ROOT, "runs", "agentic", "run_%d" % rid), ignore_errors=True)
            for base, _dirs, files in os.walk(os.path.join(KNOW, "exports")):
                for fn in files:
                    if ("_run%d." % rid) in fn:
                        os.remove(os.path.join(base, fn))
            for base, _dirs, files in os.walk(os.path.join(KNOW, "rules_code")):
                pass
        con.execute("DELETE FROM chat WHERE review NOT IN (SELECT id FROM review)")
        con.execute("DELETE FROM run WHERE project=?", (pid,))
        con.execute("DELETE FROM project WHERE id=?", (pid,))
    con.commit()
    con.close()
    print("      removed %d project(s), %d upload(s), %d folder(s); %d rule file(s) put back" % (
        len(CREATED["projects"]), len(CREATED["uploads"]), len(CREATED["dirs"]), len(CREATED["rule_backups"])))


def _set_aside_knowledge():
    """The test must not see, nor change, what the admin approved (dictionaries, strategies, rules, their generated
    code, exports): it is moved aside for the test and put back at the end."""
    keep = os.path.join(ROOT, "runs", "_agentic_test_kept_knowledge")
    shutil.rmtree(keep, ignore_errors=True)
    os.makedirs(keep)
    for d in ("dictionaries", "strategies", "rules", "rules_code", "exports"):
        src = os.path.join(KNOW, d)
        if os.path.isdir(src):
            shutil.move(src, os.path.join(keep, d))
    CREATED["kept_knowledge"] = keep


def _restore_knowledge():
    keep = CREATED.get("kept_knowledge")
    if not keep:
        return
    for d in ("dictionaries", "strategies", "rules", "rules_code", "exports"):
        shutil.rmtree(os.path.join(KNOW, d), ignore_errors=True)
        if os.path.isdir(os.path.join(keep, d)):
            shutil.move(os.path.join(keep, d), os.path.join(KNOW, d))
    shutil.rmtree(keep, ignore_errors=True)
    print("      the admin's own dictionaries and strategies are back in place")


def main():
    t0 = time.time()
    _set_aside_knowledge()
    shutil.rmtree(S08, ignore_errors=True)
    os.makedirs(S08)
    for f in FIVE:
        shutil.copy(os.path.join(S08_SRC, f), S08)
    CREATED["dirs"].append(S08)
    try:
        t_settings()
        p = t_project()
        t_family1(p)
        up = t_family2(p)
        p = api("GET", "/api/agents/projects/%d" % p["id"])
        t_family3(p, up)
        if os.path.isdir(os.path.join(ROOT, "uploads", BIG_UPLOAD)):
            pb = api("POST", "/api/agents/projects", {"admin": ADMIN, "name": "agentic test 4.3 GB", "folder": S08, "upload_id": BIG_UPLOAD})
            CREATED["projects"].append(pb["id"])
            t_demo_big(pb)
        t_retry_resume(p)
        if REAL:
            t_real(p)
    except Exception as e:      # noqa: BLE001 - reported as a failed check
        import traceback
        traceback.print_exc()
        check("the suite ran to the end", False, e)
    finally:
        cleanup()
        _restore_knowledge()
    print("\n%d checks, %d failed, %.0f s" % (RESULTS["pass"] + RESULTS["fail"], RESULTS["fail"], time.time() - t0))
    sys.exit(1 if RESULTS["fail"] else 0)


if __name__ == "__main__":
    main()
