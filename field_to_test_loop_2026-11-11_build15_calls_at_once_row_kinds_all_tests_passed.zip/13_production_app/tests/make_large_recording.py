"""A large five-file recording made from a small one, for memory and speed tests: the small recording repeated N times, its row numbers and time stamps moved on each time.
Everything is written as a stream. The source files stay as they are.

    python3 tests/make_large_recording.py <source folder> <target folder> <copies>
"""
import csv
import os
import sys

csv.field_size_limit(10 ** 8)
FILES = {"packets.csv": "Packet", "link.csv": "Link Tra", "split.csv": "Split Tra", "NVME_Transactions.csv": "NVMe", "nvme_command.csv": "NVMe Cmd"}


def ps(text):
    whole, frac = text.rstrip("s").split(".")
    return int(whole) * 10 ** 12 + int(frac.ljust(12, "0"))


def text_of(value):
    return "%04d.%012ds" % (value // 10 ** 12, value % 10 ** 12)


def read(path):
    with open(path, newline="", encoding="utf-8-sig", errors="replace") as fh:
        return list(csv.reader(fh))


def make(source, target, copies):
    os.makedirs(target, exist_ok=True)
    data = {name: read(os.path.join(source, name)) for name in FILES}
    first, last = None, None
    for name, rows in data.items():
        i = rows[0].index("Time Stamp")
        times = [ps(r[i]) for r in rows[1:] if i < len(r) and r[i]]
        first = min(times) if first is None else min(first, min(times))
        last = max(times) if last is None else max(last, max(times))
    step = last - first + 10 ** 9                  # one millisecond between two copies
    written = {}
    for name, number in FILES.items():
        rows = data.pop(name)
        n, t = rows[0].index(number), rows[0].index("Time Stamp")
        count = len(rows) - 1
        with open(os.path.join(target, name), "w", newline="", encoding="utf-8") as out:
            w = csv.writer(out, lineterminator="\n")
            w.writerow(rows[0])
            for k in range(copies):
                shift = k * step
                for r in rows[1:]:
                    x = list(r)
                    if n < len(x) and x[n]:
                        x[n] = str(int(x[n]) + k * count)
                    if t < len(x) and x[t]:
                        x[t] = text_of(ps(x[t]) + shift)
                    w.writerow(x)
        written[name] = os.path.getsize(os.path.join(target, name))
        del rows
    return step, written


if __name__ == "__main__":
    step_ps, sizes = make(sys.argv[1], sys.argv[2], int(sys.argv[3]))
    print("time between copies: %.3f s" % (step_ps / 1e12))
    print({k: round(v / 1024 ** 3, 2) for k, v in sizes.items()}, "total GB:", round(sum(sizes.values()) / 1024 ** 3, 2))
