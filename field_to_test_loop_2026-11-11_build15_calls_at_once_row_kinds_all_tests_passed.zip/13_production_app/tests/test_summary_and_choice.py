"""The owner's corrections of 2026-11-11:
- "explain like five W's and one H ... mention it as just summary": the summary answers who, what, when, where, why and how, at
  most 100 words, checked by code;
- "If the defect is not stored ... you are showing the defect number by default. Who gave you that": nothing is chosen for the
  admin, and a stage 1 made on a defect nobody chose gives no signal;
- the weights (2026-11-10: "do not start with a default value of 67"): the neutral start Beta(1, 1), the judgement that stores a
  procedure counted, the steps written after Wrong not yet judged, and every weight shown as the judgements behind it.

    python3 -m pytest -q tests/test_summary_and_choice.py
"""
import os
import sqlite3
import sys
import time

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
sys.path.insert(0, os.path.join(APP, "app"))

from nvme_hier import isolate as ISO      # noqa: E402
from nvme_hier import store as ST         # noqa: E402
from agentic import pipeline as PL        # noqa: E402
from agentic import procedures as PR      # noqa: E402

F = {"id": 10, "level": "nvme_command", "rule": "cmd.timeout", "name": "Read not completed within the host limit", "rowid": 155, "t_ps": 1_594_714_000_000,
     "command": {"rowid": 155, "summary": "Read of 8 blocks at block 4,096 on queue 3"}, "catalogue": {}, "chain": [], "cause": None}


# ---------------------------------------------------------------------------------------------- the summary
def test_the_summary_answers_six_questions_within_100_words():
    ans = {"who": "The drive.", "what": "A Read never completed.", "when": "At 1.594714 s.", "where": "Row 155 of nvme_command.csv.",
           "why": "The drive stopped answering on queue 3.", "how": "The test replays 11 commands and checks the Read completes in time."}
    lines = ISO.summary_lines(ans)
    assert [l.split(":")[0] for l in lines] == ["Who", "What", "When", "Where", "Why", "How"]
    assert ISO.summary_lines(dict(ans, how="")) is None                                  # a question left empty
    assert ISO.summary_lines(dict(ans, why=" ".join(["word"] * 101))) is None              # over 100 words
    assert set(ISO.SUMMARY_SCHEMA["required"]) == set(ISO.SUMMARY_KEYS)


def test_the_prompt_asks_the_six_questions_and_never_four_lines():
    p = ISO.summary_prompt(F, "Samsung PM9A3", "the drive stopped answering", [{"command": "Read", "position": "fault"}], None)
    assert "five W's and one H" in p and "at most 100 words" in p and "four" not in p.lower()
    assert "row 155 of nvme_command.csv" in p and "1.594714 s" in p


def test_the_isolation_prompt_ends_with_the_error_and_the_task():
    ev = [{"level": "nvme_command", "rowid": 150 + i, "n": 150 + i, "summary": "Read", "position": "fault" if i == 5 else "above"} for i in range(8)]
    p = ISO.loop_prompt(F, "Samsung PM9A3", [], None, ev, "", [], 15, set())
    tail = p[p.index("EVIDENCE"):]
    assert "THE ERROR FOUND BY THE ADMIN'S PATTERN (rule cmd.timeout)" in tail and "its NVMe command (N1): Read of 8 blocks" in tail
    assert "the error row: row 155 of nvme_command.csv, at 1.594714 s" in tail
    assert p.rstrip().endswith("cite the exact row (level and row number) where it started.")


def test_the_stand_in_is_fitted_to_100_words():
    long_reason = " ".join(["because"] * 150)
    out = ISO.summary_lines(ISO.fit_summary(ISO.standin_summary(F, "Samsung PM9A3", long_reason, [{"command": "Read"}] * 3, None)))
    assert out and len(out) == 6 and sum(len(l.split(":", 1)[1].split()) for l in out) <= 100
    assert out[3] == "Where: NVMe command level, row 155 of nvme_command.csv, device Samsung PM9A3."


# ---------------------------------------------------------------------------------------------- the weights
SIG = {"fine": "f" * 64, "coarse": "c" * 64, "display": "cmd.timeout on Read", "fields": {"lvl": "nvme_command", "err": "cmd.timeout"}}
STEPS = [{"step": 1, "command": "Write", "position": "above"}, {"step": 2, "command": "Read", "position": "fault"}]


@pytest.fixture
def st(tmp_path):
    s = ST.Store(str(tmp_path / "db" / "k.sqlite"))
    s.touch_signature(SIG, "DRIVE", upload_id="up-1", finding_id=1)
    return s


def test_the_correct_that_stores_a_proposal_is_counted(st):
    p = st.signal(SIG["fine"], None, "correct", "Sagar", proposal_steps=STEPS, proposal_text="why", upload_id="up-1", finding_id=1)["new_procedure_id"]
    ex = st.lookup(SIG)["exact"][0]
    assert ex["id"] == p and (ex["a"], ex["b"], ex["c_ok"]) == (2.0, 1.0, 1) and ex["score_text"] == "judged correct 1 of 1 time"
    path = st.graph_paths(SIG["fine"])[0]
    assert path["weight_text"] == "judged correct 1 of 1 time"
    assert path["stored"]["stored_by"] == "Sagar" and path["stored"]["signal"] == "Correct" and path["stored"]["made_by"] == "the model"
    assert path["stored"]["upload_id"] == "up-1" and path["stored"]["finding_id"] == 1


def test_steps_written_after_wrong_start_neutral(st):
    p = st.signal(SIG["fine"], None, "wrong_with_edits", "Sagar", proposal_steps=STEPS, edited_steps=STEPS[1:], edited_text="mine")["new_procedure_id"]
    ex = st.lookup(SIG)["exact"][0]
    assert ex["id"] == p and (ex["a"], ex["b"], ex["c_ok"]) == (1.0, 1.0, 0) and ex["score_text"] == "not yet judged"
    v = st.graph_view(SIG["fine"])
    rep = next(e for e in v["edges"] if e["kind"] == "REPRODUCED_BY")
    assert (rep["a"], rep["b"]) == (1.0, 1.0) and rep["weight_text"] == "not yet judged"
    assert all("of 100" not in (x.get("weight_text") or "") for x in v["nodes"] + v["edges"] + v["paths"])


def test_old_procedures_get_their_storing_correct_counted_once(tmp_path):
    path = str(tmp_path / "db" / "k.sqlite")
    s = ST.Store(path)
    s.touch_signature(SIG, "DRIVE")
    p = s.signal(SIG["fine"], None, "correct", "Sagar", proposal_steps=STEPS, proposal_text="why")["new_procedure_id"]
    with sqlite3.connect(path) as con:          # as a procedure stored before 2026-11-11 was: its Correct not counted
        con.execute("UPDATE procedure SET c_ok=0 WHERE id=?", (p,))
        con.execute("DELETE FROM store_migration")
    assert ST.Store(path).lookup(SIG)["exact"][0]["c_ok"] == 1
    assert ST.Store(path).lookup(SIG)["exact"][0]["c_ok"] == 1          # once only


def test_the_words_for_judgements():
    assert ST.judged_words(0, 0) == "not yet judged"
    assert ST.judged_words(3, 1, 1, 0) == "judged correct 4 of 5 times (1 with edits)"
    assert ST.ab_words(1.0000003, 1.0) == "not yet judged" and ST.ab_words(3, 2) == "judged correct 2 of 3 times"


# ---------------------------------------------------------------------------------------------- nothing chosen for the admin
class _IC:
    def __init__(self, inp, head):
        self.input = inp
        self.item = "errors/nvme_command/cmd_timeout"
        self._run = {"upload_id": "up-1", "head": head, "columns": list(PR.DETECTOR_OUTPUT)}

    def output_of(self, key):
        return self._run if key == "run" else {}


HEAD = [[10, "nvme_command", "cmd.timeout", "Read not completed", "error", 155, 1_594_714_000_000, 155, 155],
        [11, "nvme_command", "cmd.timeout", "Write not completed", "error", 160, 1_600_000_000_000, 160, 160]]


def test_no_defect_is_taken_unless_the_admin_chose_it():
    assert PL._defect(_IC({}, HEAD)) == ("up-1", None)
    assert PL._defect(_IC({"defect": "none"}, HEAD)) == ("up-1", None)
    assert PL._defect(_IC({"defect": 11}, HEAD)) == ("up-1", 11)
    r = PL._isolate(_IC({}, HEAD))
    assert "no defect was chosen" in (r.skip or "")
    r = PL._isolate(_IC({"defect": "none"}, HEAD))
    assert "you chose no defect" in (r.skip or "")


def test_the_defect_is_named_in_words_not_by_its_number():
    ch = PL.defect_choices({"head": HEAD, "columns": list(PR.DETECTOR_OUTPUT)})
    assert ch[0][0] == 10 and ch[0][1].startswith("row 155 of nvme_command.csv") and "Read not completed" in ch[0][1]
    assert "10" not in ch[0][1].split("·")[0].replace("155", "")


def test_no_signal_on_a_defect_nobody_chose():
    step = {"key": "f3:errors/nvme_command/cmd_timeout:isolate", "input": "{}", "output": "{}"}
    with pytest.raises(ValueError, match="not chosen by you"):
        PL._apply_signal(None, {"id": 1}, step, {}, "Sagar", "correct", {})
