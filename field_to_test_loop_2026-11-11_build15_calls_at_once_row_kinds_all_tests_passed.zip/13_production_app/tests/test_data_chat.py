"""The side panel's agents (owner, 2026-11-10: "talk to the data expert agents and builder agents ... ask the database directly ... then add
the rules"): the read-only door to the tree, the numbers check, and a whole question through the routes on a copy of the S17 tree.

    python3 -m pytest -q tests/test_data_chat.py
"""
import json
import os
import shutil
import sqlite3
import sys
import tempfile
import time

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
sys.path.insert(0, os.path.join(APP, "app"))
sys.path.insert(0, HERE)

from agentic import data_chat as DC   # noqa: E402


@pytest.fixture()
def small_db(tmp_path):
    p = str(tmp_path / "t.sqlite")
    con = sqlite3.connect(p)
    con.execute("CREATE TABLE cmd (rowid_file INTEGER PRIMARY KEY, n INTEGER, opc INTEGER, raw TEXT, parent INTEGER, parent_level TEXT, relation TEXT)")
    con.execute("CREATE TABLE pkt (rowid_file INTEGER PRIMARY KEY, n INTEGER, raw TEXT, parent INTEGER, parent_level TEXT, relation TEXT)")
    con.executemany("INSERT INTO cmd (rowid_file, n, opc, raw) VALUES (?,?,?,?)", [(i, i, 2 if i % 3 else 1, json.dumps({"OPC": "0x02 (Read)"})) for i in range(1, 301)])
    con.executemany("INSERT INTO pkt (rowid_file, n, raw, parent, parent_level) VALUES (?,?,?,?,?)", [(i, i - 1, "{}", i % 300 + 1, "link") for i in range(1, 2001)])
    con.commit()
    con.close()
    return p


def test_the_door_only_reads(small_db, tmp_path):
    con = DC.open_ro(small_db)
    try:
        ok = DC.run_query(con, "SELECT opc, COUNT(*) AS n FROM cmd GROUP BY opc ORDER BY opc")
        assert ok["columns"] == ["opc", "n"] and ok["rows"] == [[1, 100], [2, 200]]
        assert "only one SELECT" in DC.run_query(con, "DELETE FROM cmd")["error"]
        assert "only one SELECT" in DC.run_query(con, "SELECT 1; DROP TABLE cmd")["error"]
        assert "only one SELECT" in DC.run_query(con, "ATTACH DATABASE '%s' AS x" % (tmp_path / "x.sqlite"))["error"]
        with pytest.raises(sqlite3.DatabaseError):            # the authorizer refuses a write even past the text check
            con.execute("INSERT INTO cmd (rowid_file) VALUES (9999)")
        with pytest.raises(sqlite3.DatabaseError):
            con.execute("ATTACH DATABASE ? AS x", (str(tmp_path / "y.sqlite"),))
        big = DC.run_query(con, "SELECT COUNT(*) FROM pkt", {"pkt": 30_000_000})
        assert "would read every one of the 30,000,000 rows of packets.csv" in big["error"]
        assert DC.run_query(con, "SELECT * FROM pkt WHERE rowid_file BETWEEN 10 AND 12", {"pkt": 30_000_000})["rows"][0][0] == 10
        many = DC.run_query(con, "SELECT rowid_file FROM cmd")
        assert len(many["rows"]) == DC.QUERY_ROWS and many["more_rows"] is True
    finally:
        con.close()
    with sqlite3.connect(small_db) as c2:
        assert c2.execute("SELECT COUNT(*) FROM cmd").fetchone()[0] == 300


def test_a_runaway_query_is_stopped(small_db, monkeypatch):
    monkeypatch.setattr(DC, "QUERY_SECONDS", 0.2)
    con = DC.open_ro(small_db)
    try:
        t0 = time.time()
        r = DC.run_query(con, "WITH RECURSIVE c(x) AS (SELECT 1 UNION ALL SELECT x + 1 FROM c) SELECT MAX(x) FROM c")
        assert "stopped after" in r["error"] and time.time() - t0 < 5
    finally:
        con.close()


def test_numbers_in_the_answer_must_come_from_a_result():
    res = [{"rows": [[144, "0.594714 s"], [155, 421.788]]}]
    assert DC.numbers_check("Row 144 took 421.788 us; 3 steps.", res)["ok"]
    bad = DC.numbers_check("Row 144 took 512.5 us and 1,234 reads failed.", res)
    assert not bad["ok"] and bad["missing"] == ["512.5", "1,234"]
    assert DC.numbers_check("You asked about row 9999.", res, also="what about row 9999?")["ok"]


def _s17_app(root):
    import test_regression_tests as R
    return R._app_with_s17(root)


def test_a_question_goes_through_the_panel_with_its_queries_rows_and_a_rule_proposal(monkeypatch):
    from api import agentic_api as A
    root = tempfile.mkdtemp(prefix="chat_%d_" % os.getpid())
    try:
        app, c = _s17_app(root)
        pid = c.post("/api/agents/projects", json={"admin": "t", "name": "S17 chat",
                                                    "folder": os.path.join(APP, "samples", "clean_five_files", "S17_io_timeout_abort_reset")}).get_json()["id"]
        with app.app_context():
            eng = A.engine()
        eng.store.exec("UPDATE project SET upload_id=? WHERE id=?", ("up-s17", pid))
        g = c.get("/api/agents/projects/%d/chat?agent=builder" % pid).get_json()
        assert g["connected"]["tree"] == "up-s17" and g["connected"]["rows"]["nvme_command.csv"] > 0 and set(g["agents"]) == {"data", "builder", "rules"}
        seen = []

        def fake(run_id, agent, instruction, ctx, shape, must, standin, **kw):
            seen.append(json.loads(ctx))
            if len(seen) == 1:
                return {"answer": "", "queries": ["SELECT COUNT(*) AS writes FROM cmd WHERE opc = 1 AND sqid != 0 AND sct IS NULL"]}, "test model", None
            n = seen[-1]["query_results"][0]["rows"][0][0]
            return {"answer": "%d writes never got a status; 77 of them were on queue 3." % n, "queries": [],
                    "steps": [{"say": "counted the writes with no status", "query": 0}],
                    "proposal": {"kind": "new_rule", "name": "Write with no completion", "section": "errors", "level": "nvme_command",
                                 "in_words": "In nvme_command.csv, a Write (OPC 0x01) on an I/O queue whose ST.SCT and ST.SC are empty is a defect.", "open_questions": ["how long to wait?"]}}, "test model", None
        monkeypatch.setattr(eng.runner, "ask", fake)
        r = c.post("/api/agents/projects/%d/chat" % pid, json={"agent": "builder", "message": "how many writes never completed?", "admin": "Tester",
                                                               "page": {"title": "3 · Rules, defects, test cases", "stage": "rules"}})
        out = r.get_json()
        assert r.status_code == 200, out
        a = out["new"][1]
        assert a["queries"][0]["rows"][0][0] >= 4 and a["steps"][0]["query"] == 0
        assert a["numbers"]["ok"] is False and a["numbers"]["missing"] == ["77"]          # 77 is in no result: flagged
        assert a["proposal"]["kind"] == "new_rule" and a["proposal"]["level"] == "nvme_command"
        assert "joins" in seen[0] and "joining_rules" in seen[0] and "column_meanings" not in seen[0]       # the builder knows the joins
        assert len(c.get("/api/agents/projects/%d/chat?agent=builder" % pid).get_json()["turns"]) == 2
        assert c.post("/api/agents/projects/%d/chat" % pid, json={"agent": "nobody", "message": "x"}).status_code == 400
        assert c.post("/api/agents/projects/%d/chat" % pid, json={"agent": "data", "message": "  "}).status_code == 400
        assert c.post("/api/agents/projects/%d/chat/clear" % pid, json={"agent": "builder"}).get_json()["turns"] == []
    finally:
        shutil.rmtree(root, ignore_errors=True)
