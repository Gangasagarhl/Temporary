"""Keep the admin's own state while the full test suite runs.

    python3 tests/protect_state.py save       before the suite
    python3 tests/protect_state.py restore    after the suite (also after a crash: the saved copy stays until restored)

save: a consistent copy of every db/*.sqlite (SQLite's online backup, safe while the server runs), the db/*.jsonl logs
and the knowledge/ folder, plus the lists of runs/, runs/agentic/, uploads/ and suite/hier/.
restore: the copies go back (SQLite backup into the live files), and the run folders, uploads and test files that the
suite created are removed. Some older suites (tests/exercise_loop.py, tests/ui_smoke.py) record decisions in the
stage-2 knowledge base and do not undo them; this puts everything back as it was.
Do not use the application while the full suite runs: what you do in that time is undone by restore.
"""
import json
import os
import shutil
import sqlite3
import sys

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SAVE = os.path.join(APP, "runs", "_suite_saved_state")
LISTS = {"runs": os.path.join(APP, "runs"), "agentic": os.path.join(APP, "runs", "agentic"), "uploads": os.path.join(APP, "uploads"),
         "suite": os.path.join(APP, "suite", "hier")}


def _listing(d):
    return sorted(os.listdir(d)) if os.path.isdir(d) else []


def save():
    if os.path.exists(os.path.join(SAVE, "done")):
        sys.exit("a saved state already exists (%s): restore it first, or remove it if it is stale" % SAVE)
    shutil.rmtree(SAVE, ignore_errors=True)
    os.makedirs(os.path.join(SAVE, "db"))
    for fn in sorted(os.listdir(os.path.join(APP, "db"))):
        p = os.path.join(APP, "db", fn)
        if fn.endswith(".sqlite"):
            src, dst = sqlite3.connect(p, timeout=60), sqlite3.connect(os.path.join(SAVE, "db", fn))
            src.backup(dst)
            src.close()
            dst.close()
        elif fn.endswith(".jsonl"):
            shutil.copy2(p, os.path.join(SAVE, "db", fn))
    if os.path.isdir(os.path.join(APP, "knowledge")):
        shutil.copytree(os.path.join(APP, "knowledge"), os.path.join(SAVE, "knowledge"))
    shutil.copy2(os.path.join(APP, "config", "app_config.json"), os.path.join(SAVE, "app_config.json"))     # the settings too: a suite that stopped half way left the agents on the stand-in (found 2026-11-10)
    with open(os.path.join(SAVE, "lists.json"), "w") as fh:
        json.dump({k: _listing(d) for k, d in LISTS.items()}, fh)
    open(os.path.join(SAVE, "done"), "w").close()
    print("saved: %d database files, the logs, knowledge/, and the lists of runs, uploads and test files" % len(os.listdir(os.path.join(SAVE, "db"))))


def restore():
    if not os.path.exists(os.path.join(SAVE, "done")):
        sys.exit("nothing saved to restore (%s)" % SAVE)
    for fn in sorted(os.listdir(os.path.join(SAVE, "db"))):
        p, s = os.path.join(APP, "db", fn), os.path.join(SAVE, "db", fn)
        if fn.endswith(".sqlite"):
            src, dst = sqlite3.connect(s), sqlite3.connect(p, timeout=60)
            src.backup(dst)
            src.close()
            dst.close()
        elif fn.endswith(".jsonl"):         # not the -shm/-wal files SQLite makes next to a copy that was opened (found 2026-11-09)
            shutil.copy2(s, p)
    if os.path.isdir(os.path.join(SAVE, "knowledge")):
        shutil.rmtree(os.path.join(APP, "knowledge"), ignore_errors=True)
        shutil.copytree(os.path.join(SAVE, "knowledge"), os.path.join(APP, "knowledge"))
    if os.path.exists(os.path.join(SAVE, "app_config.json")):
        shutil.copy2(os.path.join(SAVE, "app_config.json"), os.path.join(APP, "config", "app_config.json"))
    before = json.load(open(os.path.join(SAVE, "lists.json")))
    removed = []
    for k, d in LISTS.items():
        for name in set(_listing(d)) - set(before.get(k, [])):
            p = os.path.join(d, name)
            if k == "runs" and not (name.startswith("run-") or name.startswith("_flow_test") or name.startswith("_agentic_test")):
                continue        # logs and screenshot folders of the suite stay
            if k == "uploads" and not (name.startswith("up-") or name.startswith("_")):
                continue
            shutil.rmtree(p, ignore_errors=True) if os.path.isdir(p) else os.remove(p)
            removed.append("%s/%s" % (k, name))
    shutil.rmtree(SAVE, ignore_errors=True)
    print("restored: the databases, the logs and knowledge/ are as before the suite; removed %d item(s) the suite made%s" % (
        len(removed), (": " + ", ".join(removed[:12]) + (" ..." if len(removed) > 12 else "")) if removed else ""))


if __name__ == "__main__":
    {"save": save, "restore": restore}.get(sys.argv[1] if len(sys.argv) > 1 else "", lambda: sys.exit(__doc__))()
