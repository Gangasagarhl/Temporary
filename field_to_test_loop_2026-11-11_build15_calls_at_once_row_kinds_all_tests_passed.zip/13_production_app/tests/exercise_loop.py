#!/usr/bin/env python3
"""Drive the RUNNING application through a complete scenario and verify each mechanism against the database.

  A. three synthetic captures with overlapping defects -> stage 1 on each (LLM confirmation as configured)
  B. stage 2 on capture A: every defect -> "Generate the test script" (accept) -> test admitted?
  C. capture B contains two of A's defects again -> retrieval must say "seen before", show the STORED procedure,
     and accept must REUSE it (zero search); then the admin's other signals on real defects:
       reject with a reason (weights must drop, history negative), edited procedure (add_procedure: validated by
       execution), rerank (rating only), not_reproducible (technical counts only), revise, promote / deprecate
       (second admin), undo (event replay), skip / defer / escalate
  D. capture A re-run with force -> every stage-1 verdict must come from the pattern cache (0 model calls)
  E. database: signature tree, feedback history, counts before / after
Writes runs/exercise_report.md and prints a pass/fail table.   Usage: python3 tests/exercise_loop.py [--base http://127.0.0.1:8077]
"""
import argparse
import json
import os
import sys
import time
import urllib.request

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BASE = "http://127.0.0.1:8077"
RESULTS = []


def api(method, path, body=None):
    req = urllib.request.Request(BASE + path, data=json.dumps(body).encode() if body is not None else None, method=method,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=900) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


def check(name, ok, detail=""):
    RESULTS.append((name, bool(ok), detail))
    print("%s  %s  %s" % ("PASS" if ok else "FAIL", name, detail), flush=True)
    return ok


def wait_job(jid, label=""):
    t0 = time.time()
    while True:
        _, j = api("GET", "/api/jobs/%s" % jid)
        if j.get("status") in ("done", "failed", "cancelled"):
            return j
        p = j.get("progress") or {}
        print("   ... %s %s %s %ds" % (label, p.get("step"), (p.get("detail") or "")[:60], time.time() - t0), flush=True)
        time.sleep(4)


def stage1(cards, seed, label):
    _, g = api("POST", "/api/samples/generate", {"cards": cards, "seed": seed})
    body = {"csv_path": g["csv_path"], "nsze": g["nsze"], "firmware": "FW-A", "label": label, "force": True}
    body.update(g.get("host_evidence") or {})
    _, r = api("POST", "/api/runs", body)
    j = wait_job(r["job"], "stage1 " + label)
    _, v = api("GET", "/api/runs/%s" % r["run_id"])
    return r["run_id"], j, v, g


def defects(run_id):
    return api("GET", "/api/runs/%s/incidents" % run_id)[1]


def start_stage2(run_id):
    _, s = api("POST", "/api/runs/%s/stage2/start" % run_id)
    if s.get("job"):
        wait_job(s["job"], "prepare")
    return s


def present(run_id, inc):
    return api("POST", "/api/runs/%s/incidents/%s/present" % (run_id, inc))[1]


def act(run_id, inc, action, wait=True):
    code, r = api("POST", "/api/runs/%s/incidents/%s/act" % (run_id, inc), action)
    if code != 200:
        return code, r, None
    if r.get("job") and wait:
        return code, r, wait_job(r["job"], action["action"])["result"]
    return code, r, r.get("result")


def edge(sig, cid):
    _, t = api("GET", "/api/db/table/edge?sig=%s" % sig)
    return next((x for x in t["rows"] if x["dst"].endswith("::" + cid)), None)


def main():
    global BASE
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default=BASE)
    a = ap.parse_args()
    BASE = a.base
    t_all = time.time()
    _, cfg = api("GET", "/api/config")
    print("LLM active:", cfg["llm_active"])
    _, db0 = api("GET", "/api/db/summary")
    before = db0["knowledge"]

    # ------------------------------------------------------------ A. stage 1 on three captures
    runA, jA, vA, gA = stage1("T-42,L-21,C-16", 11, "exercise A")
    check("A1 stage 1 completes on capture A", jA["status"] == "done", "%s defects, %s s" % (vA["summary"]["incidents"], jA["elapsed_s"]))
    check("A2 LLM confirmation ran", vA["summary"]["llm_reviewed"] >= 1, "reviewed %s, calls %s, cached %s, confirmed %s" % (
        vA["summary"]["llm_reviewed"], vA["summary"]["llm_called"], vA["summary"]["llm_cached"], vA["summary"]["llm_confirmed"]))
    check("A3 stage 2 is gated before start", api("POST", "/api/runs/%s/incidents/INC-0001/present" % runA)[0] == 409)
    dA = defects(runA)
    check("A4 defects carry status words and LLM verdicts", all(d["status_word"] for d in dA), ", ".join("%s %s/%s" % (d["card"], d["status_word"], (d["llm"] or {}).get("verdict")) for d in dA))
    # since 2026-10-28 stage 1 also files the analyzer's own error kinds; they have no atlas card, and stage 2 (which
    # works from a card's causes and procedures) refuses them by design: only the defects with a card go on
    nocard = [d for d in dA if not d.get("card")]
    dA = [d for d in dA if d.get("card")]

    # ------------------------------------------------------------ B. generate a test for every defect of A
    start_stage2(runA)
    _, q = api("GET", "/api/runs/%s/stage2/queue" % runA)
    check("B1 stage 2 started and every defect prepared (cached cards)", q["started"] and q["counts"]["presented"] == q["counts"]["total"], json.dumps(q["counts"]))
    if nocard:
        code, body = api("POST", "/api/runs/%s/incidents/%s/present" % (runA, nocard[0]["id"]))
        check("B0 a defect without an atlas card (an analyzer error kind) is refused by stage 2 with the reason", code == 400 and "no atlas card" in (body or {}).get("error", ""),
              "%d of the %d defects have no card; %s: %s" % (len(nocard), len(nocard) + len(dA), nocard[0]["id"], (body or {}).get("error")))
    gen = {}
    for d in dA:
        v = present(runA, d["id"])
        check("B2 %s %s: retrieval answered (%s)" % (d["id"], d["card"], v["seen"]), v["seen"] in ("new", "ambiguous", "match"), v["seen_label"])
        check("B3 %s: card shows the LLM proposal%s" % (d["id"], " next to the stored procedure" if v["stored"] else " (nothing stored)"), v["generated"] is not None or v["llm"] is None, "stored=%s generated=%s" % (bool(v["stored"]), bool(v["generated"])))
        target = v["stored"]["doc_id"] if v["stored"] else next((x["doc_id"] for x in v["card"]["alternatives"] if x["kind"] == "cause" and x["sig"] == d["card"]), None)
        action = {"action": "accept", "targets": [target], "requester": "admin", "approver": "second_admin"} if target else \
                 {"action": "add_cause", "content": {"text": "cause from exercise"}, "requester": "admin", "approver": "second_admin"}
        code, r, res = act(runA, d["id"], action)
        gen[d["card"]] = res
        check("B4 %s %s: generate test -> %s, %d trials, repro %.2f, closed loop %s, admitted %s" % (
            d["id"], d["card"], res["status"], res["trials"], res["repro_lower95"] or 0, "%s/%s bad, %s/%s fixed" % (
                (res["closed_loop"] or {}).get("known_bad_hits"), (res["closed_loop"] or {}).get("known_bad_n"),
                (res["closed_loop"] or {}).get("fixed_hits"), (res["closed_loop"] or {}).get("fixed_n")) if res["closed_loop"] else "-", res["admitted"]),
            res["status"] in ("confirmed", "budget_exhausted", "reused_validated", "triage_timeout"), "search %ss verify %ss files %s" % (res["search_s"], res["verify_s"], res.get("test_files")))
    admitted = [c for c, r in gen.items() if r and r.get("admitted")]
    check("B5 at least one test script admitted and filed", len(admitted) >= 1, "admitted: %s" % admitted)
    _, suite = api("GET", "/api/suite")
    check("B6 suite lists the generated tests with manifest + pytest + conftest", all({"manifest.json", "conftest.py"} <= set(t["files"]) for t in suite) and len(suite) >= len(admitted), "%d tests" % len(suite))
    for d in dA:
        if d["card"] in admitted:
            code, r, res = act(runA, d["id"], {"action": "compose_tests", "requester": "admin", "approver": "second_admin"})
            vs = res.get("variants") or []
            check("B9 %s %s: 'generate test case' composed %d variant(s) from %d stored sequence(s) via the LLM; %d reproduced, %d filed" % (
                  d["id"], d["card"], len(vs), res.get("n_sources", 0), sum(1 for v in vs if v.get("confirmed")), sum(1 for v in vs if v.get("admitted"))),
                  res.get("mode") == "compose" and res.get("n_sources", 0) >= 1 and len(vs) >= 1 and res.get("status") in ("composed", "not_reproduced"),
                  "status %s · %s · llm %ss lab %ss · %s" % (res.get("status"), [(v["name"], v["repro_k"], v.get("admitted")) for v in vs], res.get("llm_s"), res.get("search_s"), (res.get("llm_summary") or "")[:90]))
            if vs:
                check("B9b %s: a composed variant that reproduced is filed with its sources and rationale (not auto-approved)" % d["card"],
                      (not any(v.get("confirmed") for v in vs)) or any(v.get("admitted") and v.get("test_files") and v.get("sources_used") for v in vs),
                      "admitted %s" % [v["name"] for v in vs if v.get("admitted")])
        _, sol = api("GET", "/api/runs/%s/incidents/%s/solutions" % (runA, d["id"]))
        kinds = [("stored" if x["id"].startswith("sol::") else "llm") for x in sol["solutions"]]
        check("B8 %s %s: manager view lists the candidates (stored first, LLM proposal last) with provenance" % (d["id"], d["card"]),
              sol["card"] == d["card"] and all(("source" in x and "commands" in x and "feedback" in x) for x in sol["solutions"]) and kinds == sorted(kinds, key=lambda k: k == "llm"),
              "%s · headline: %s" % (kinds, (sol.get("llm_headline") or "")[:80]))
    for d in dA:
        if d["card"] in admitted:
            code, r, res = act(runA, d["id"], {"action": "sweep", "requester": "admin", "approver": "second_admin"})
            vs = res.get("variants") or []
            check("B10 %s %s: vulnerability sweep ran %d variants (%d lab runs): %d failure-prone, %d filed as tests; jammer: %s" % (
                  d["id"], d["card"], len(vs), res.get("trials", 0), len(res.get("failure_prone") or []), sum(1 for v in vs if v.get("admitted")), (res.get("jammer") or "")[:40]),
                  res.get("mode") == "sweep" and res.get("status") in ("swept", "no_variants") and len(vs) >= 8,
                  "most stressful: %s" % res.get("most_stressful"))
            break
    failing = next((d for d in dA if d["card"] not in admitted), None)
    if failing:
        v = present(runA, failing["id"])
        tgt = next((a["doc_id"] for a in v["card"]["alternatives"] if a["kind"] == "cause" and a["sig"] == failing["card"]), None)
        if tgt:
            e0 = edge(failing["card"], tgt.split("::")[2])
            code, r, res = act(runA, failing["id"], {"action": "restart_failed", "targets": [tgt], "requester": "admin", "note": "exercise: no reproduction"})
            e1 = edge(failing["card"], tgt.split("::")[2])
            check("B11 %s %s: Negative Ack -> failed trial recorded (tb %s -> %s) and the search restarted on attempt %s: %s" % (
                  failing["id"], failing["card"], e0.get("tb"), e1.get("tb"), res.get("attempt"), res.get("status")),
                  res.get("action") == "restart_failed" and (e1.get("tb") or 0) == (e0.get("tb") or 0) + 1 and res.get("attempt", 0) >= 1,
                  "%d trials, a %.2f -> %.2f unchanged" % (res.get("trials", 0), e0.get("a", 0), e1.get("a", 0)))
    _, ov = api("GET", "/api/db/overview")
    check("B7 database grew: causes, procedures, approved, tests", ov["knowledge"]["cause_nodes"] >= len(dA) and ov["knowledge"]["solutions"] >= len(admitted) and ov["knowledge"]["approved_solutions"] >= 1, json.dumps({k: ov["knowledge"][k] for k in ("events", "signatures", "cause_nodes", "solutions", "approved_solutions")}))

    # ------------------------------------------------------------ C. recurrence + every admin signal on capture B
    runB, jB, vB, gB = stage1("T-42,L-21,M-039", 12, "exercise B (recurrences of T-42, L-21)")
    check("C1 stage 1 completes on capture B", jB["status"] == "done", "%s defects" % vB["summary"]["incidents"])
    start_stage2(runB)
    dB = [d for d in defects(runB) if d.get("card")]       # the defects stage 2 works on (see B0)
    rec = {d["card"]: d for d in dB if d["card"] in admitted}
    newc = [d for d in dB if d["card"] not in gen]
    check("C2 capture B contains recurrences of admitted defects", len(rec) >= 1, "recurring: %s; new: %s" % (list(rec), [d["card"] for d in newc]))
    for card, d in list(rec.items())[:2]:
        v = present(runB, d["id"])
        check("C3 %s recurrence: retrieval recognises it (%s) and shows the STORED procedure" % (card, v["seen"]), v["seen"] in ("match", "ambiguous") and v["stored"] is not None, v["seen_label"])
        if v["stored"]:
            check("C4 %s: stored procedure carries its metadata (status, approver, repro bound, feedback)" % card,
                  (v["stored"]["status"] == "admin-approved" and v["stored"]["approved_by"]) or (v["stored"]["status"] == "validated-by-execution" and v["stored"]["repro_lower95"] is not None), "status %s by %s repro %s feedback %s/%s" % (
                v["stored"]["status"], v["stored"]["approved_by"], v["stored"]["repro_lower95"], v["stored"]["edge_posterior"], v["stored"]["edge_n"]))
            _, sol = api("GET", "/api/runs/%s/incidents/%s/solutions" % (runB, d["id"]))
            top = sol["solutions"][0] if sol["solutions"] else {}
            check("C20 %s: manager view puts the stored procedure (approved, or validated and awaiting approval) first with its lab numbers" % card,
                  str(top.get("id", "")).startswith("sol::") and top.get("sig") == card and top.get("status") in ("admin-approved", "validated-by-execution") and top.get("repro_lower95") is not None and top.get("tests", 0) >= 1,
                  "%s · %s · repro %.2f · %s tests" % (top.get("source"), top.get("commands"), top.get("repro_lower95") or 0, top.get("tests")))
            e0 = edge(card, v["stored"]["cause"])
            code, r, res = act(runB, d["id"], {"action": "accept", "targets": [v["stored"]["doc_id"]], "requester": "admin", "approver": "second_admin"})
            check("C5 %s: accept on the stored procedure -> regression guard first (mode %s, status %s, %d trials)" % (card, res["mode"], res["status"], res["trials"]),
                  res["mode"] in ("reuse", "adapt") and res["trials"] <= 6 or res["mode"] == "adapt", "search %ss, admitted %s" % (res["search_s"], res["admitted"]))
            e1 = edge(card, v["stored"]["cause"])
            check("C6 %s: positive signal raised the cause's success count (a %.2f -> %.2f)" % (card, e0["a"], e1["a"]), e1["a"] > e0["a"])
    # negative signal + edited procedure on the first recurring card
    if rec:
        card, d = next(iter(rec.items()))
        v = present(runB, d["id"])
        tgt = v["stored"]["doc_id"] if v["stored"] else None
        cause = v["stored"]["cause"] if v["stored"] else "c0"
        def proc_counts(vh):
            _, t = api("GET", "/api/db/table/pnode?sig=%s" % card)
            return next((x for x in t["rows"] if x["id"] == "scn::" + vh), None)
        p0 = proc_counts(v["stored"]["vhash"]) if v["stored"] else None
        e0 = edge(card, cause)
        code, r, res = act(runB, d["id"], {"action": "reject", "targets": [tgt], "requester": "admin", "note": "exercise: timing is wrong for this firmware"})
        e1 = edge(card, cause)
        p1 = proc_counts(v["stored"]["vhash"]) if v["stored"] else None
        if p0:    # the rejected item is the PROCEDURE: its node/edge takes the blame, the cause edge is untouched (localized blame)
            check("C7 %s: reject with reason -> the rejected procedure's failure count up (b %.2f -> %.2f); cause untouched (a %.2f -> %.2f)" % (card, p0["b"], p1["b"], e0["a"], e1["a"]),
                  p1["b"] > p0["b"] and abs(e1["a"] - e0["a"]) < 0.1 * max(1, e0["a"]), "; ".join(res["action_effects"]))
        else:
            check("C7 %s: reject with reason -> failure count up (b %.2f -> %.2f), success untouched" % (card, e0["b"], e1["b"]), e1["b"] > e0["b"] and abs(e1["a"] - e0["a"]) < 0.1 * max(1, e0["a"]), "; ".join(res["action_effects"]))
        _, h = api("GET", "/api/db/feedback/%s" % card)
        check("C8 %s: history shows the negative decision with its note" % card, h["history"] and h["history"][0]["polarity"] == "negative" and "exercise" in (h["history"][0]["note"] or ""), "%d entries" % len(h["history"]))
        v2 = present(runB, d["id"])
        _, dd = api("GET", "/api/runs/%s/defect/%s" % (runB, d["id"]))
        check("C9 %s: full record carries the earlier decisions" % card, any(x["polarity"] == "negative" for x in dd["history"]))
        edited = dict(v2["stored"] and {"commands": [{"op": s["op"]} for s in v2["stored"]["procedure"]], "timing": dict(v2["stored"]["timing"]), "power_state": v2["stored"]["power_state"]} or
                      {"commands": [{"op": "write"}, {"op": "flush"}], "timing": {"qd": 8, "inter_cmd_us": 50, "bs_kb": 4, "burst_len": 16, "idle_gap_ms": 0}, "power_state": "none"})
        edited["timing"]["inter_cmd_us"] = max(1, int(edited["timing"].get("inter_cmd_us", 50) * 2))
        code, r, res = act(runB, d["id"], {"action": "add_procedure", "content": edited, "requester": "admin", "approver": "second_admin"})
        check("C10 %s: admin-edited procedure is validated by execution (mode %s, status %s) before it is stored" % (card, res["mode"], res["status"]),
              res["mode"] in ("admin_procedure", "adapt"), "repro %s admitted %s" % (res["repro_lower95"], res["admitted"]))
        _, sigtree = api("GET", "/api/db/signature/%s" % card)
        n_proc = sum(len(c["procedures"]) for c in sigtree["tree"])
        check("C11 %s: signature tree shows causes -> procedures -> tests" % card, n_proc >= 2, "%d causes, %d procedures" % (len(sigtree["tree"]), n_proc))
        # rerank: rating only, never a success
        v3 = present(runB, d["id"])
        cands = [x["doc_id"] for x in v3["card"]["alternatives"]][:3]
        if len(cands) >= 2:
            e0 = edge(card, cause)
            code, r, res = act(runB, d["id"], {"action": "rerank", "ranking": list(reversed(cands)), "requester": "admin"})
            e1 = edge(card, cause)
            check("C12 %s: rerank changes the rating only (a %.2f == %.2f, n %d == %d)" % (card, e0["a"], e1["a"], e0["n"], e1["n"]), abs(e1["a"] - e0["a"]) < 1e-6 and e1["n"] == e0["n"], "; ".join(res["action_effects"]))
        e0 = edge(card, cause)
        code, r, res = act(runB, d["id"], {"action": "not_reproducible", "targets": ["cause::%s::%s" % (card, cause)], "requester": "admin", "note": "exercise: bench silent"})
        e1 = edge(card, cause)
        check("C13 %s: not_reproducible touches technical counts only (tb %s -> %s, b %.2f -> %.2f)" % (card, e0["tb"], e1["tb"], e0["b"], e1["b"]), e1["tb"] == e0["tb"] + 1 and abs(e1["b"] - e0["b"]) < 0.05)
        code, r, res = act(runB, d["id"], {"action": "revise", "targets": ["cause::%s::%s" % (card, cause)], "content": {"text": "revised by exercise"}, "requester": "admin"})
        _, nodes = api("GET", "/api/db/table/node?sig=%s" % card)
        check("C14 %s: revise creates a new content version, counts kept" % card, code == 200 and "revised" in " ".join(res["action_effects"]), "; ".join(res["action_effects"]))
        # two-person rules
        _, sols = api("GET", "/api/db/table/solution?sig=%s" % card)
        validated = [s for s in sols["rows"] if s["status"] == "validated-by-execution"]
        approved = [s for s in sols["rows"] if s["status"] == "admin-approved"]
        if approved:
            code, r, res = act(runB, d["id"], {"action": "deprecate", "targets": ["sol::" + approved[0]["vhash"]], "requester": "admin", "approver": "admin"})
            check("C15 %s: deprecate by the same person is refused" % card, code == 400 or (res and res.get("action_error")), (res or r).get("action_error") or r.get("error"))
            code, r, res = act(runB, d["id"], {"action": "deprecate", "targets": ["sol::" + approved[0]["vhash"]], "requester": "admin", "approver": "second_admin"})
            _, sols2 = api("GET", "/api/db/table/solution?sig=%s" % card)
            st = next(s["status"] for s in sols2["rows"] if s["vhash"] == approved[0]["vhash"])
            check("C16 %s: deprecate with a second admin -> status %s" % (card, st), st == "deprecated")
            # undo it
            ev = res["action_events"]
            for eid in reversed(ev):
                api("POST", "/api/db/undo", {"event_id": eid, "actor": "admin"})
            _, sols3 = api("GET", "/api/db/table/solution?sig=%s" % card)
            st2 = next(s["status"] for s in sols3["rows"] if s["vhash"] == approved[0]["vhash"])
            check("C17 %s: undo restores the status (%s)" % (card, st2), st2 == "admin-approved")
        for name in ("skip", "defer", "escalate"):
            code, r, res = act(runB, d["id"], {"action": name, "requester": "admin", "note": "exercise"})
            check("C18 %s: %s applies without touching weights" % (card, name), code == 200 and res["status"] == "no_search", "; ".join(res["action_effects"]))
    # a new card in B: retrieval should offer related procedures
    if newc:
        d = newc[0]
        v = present(runB, d["id"])
        check("C19 %s (new card): retrieval offers related candidates from the database" % d["card"], len(v["card"]["alternatives"]) >= 1, "%s · %d candidates" % (v["seen_label"], len(v["card"]["alternatives"])))

    # ------------------------------------------------------------ D. pattern cache on a forced re-run of A
    body = {"csv_path": gA["csv_path"], "nsze": gA["nsze"], "firmware": "FW-A", "label": "exercise A again", "force": True}
    body.update(gA.get("host_evidence") or {})
    _, r = api("POST", "/api/runs", body)
    jD = wait_job(r["job"], "stage1 A again")
    _, vD = api("GET", "/api/runs/%s" % r["run_id"])
    sm = vD["summary"]
    # every MODEL verdict comes from the cache (since 2026-10-28 the analyzer's own error kinds are filed without a model
    # verdict, so the reviewed defects, not all defects, are the ones to compare)
    check("D1 forced re-run of capture A: every model verdict from the pattern cache, 0 model calls", sm["llm_called"] == 0 and sm["llm_cached"] == sm["llm_reviewed"] and sm["llm_reviewed"] >= 1,
          "cached %s of %s reviewed (%s defects), calls %s" % (sm["llm_cached"], sm["llm_reviewed"], sm["incidents"], sm["llm_called"]))
    _, r2 = api("POST", "/api/runs", dict(body, force=False))
    check("D2 run cache: the same CSV without force reopens an existing run", r2.get("reused") is True, r2.get("run_id"))

    # ------------------------------------------------------------ E. database after everything
    _, db1 = api("GET", "/api/db/summary")
    after = db1["knowledge"]
    check("E1 event log grew and projections are consistent", after["events"] > before["events"] and after["approved_solutions"] >= 1, json.dumps({k: (before.get(k), after.get(k)) for k in ("events", "signatures", "cause_nodes", "solutions", "approved_solutions", "lessons")}))
    _, cache = api("GET", "/api/db/cache")
    check("E2 verdict cache has entries and hits", cache["stats"]["entries"] >= 1 and cache["stats"]["hits"] >= 1, json.dumps(cache["stats"]))
    _, rep = api("GET", "/api/runs/%s/report" % runA)
    _, k = api("GET", "/api/kpi")
    check("E4 KPI report: rules %s, %d/%d runs within the triage budget, leakage %s, tests on file %d (0 by hand)" % (
          json.dumps(k["rules"]), k["efficiency"]["runs_within_triage_budget"], k["efficiency"]["runs"], k["quality"]["known_signature_leakage"], k["productivity"]["tests_on_file"]),
          k["rules"] == {"score_threshold": 0.9, "optimal_consecutive": 3, "first_level_triage_s": 600} and k["quality"]["known_signature_leakage"] == 0 and k["productivity"]["tests_authored_by_hand"] == 0)
    check("E3 report of run A shows stage-1 and stage-2 timings", rep["stage1"]["seconds_total"] > 0 and rep["stage2"]["incidents_executed"] >= 1, "stage1 %.1fs stage2 %.1fs total %.1fs" % (rep["stage1"]["seconds_total"], rep["stage2"]["seconds_total"], rep["total_seconds"]))

    # ------------------------------------------------------------ report
    n_ok = sum(1 for _, ok, _ in RESULTS if ok)
    lines = ["# Exercise of the complete loop on the running application", "", "LLM: %s · %d checks, %d passed · %.0f s" % (cfg["llm_active"], len(RESULTS), n_ok, time.time() - t_all), "",
             "| Result | Check | Detail |", "|---|---|---|"] + ["| %s | %s | %s |" % ("PASS" if ok else "FAIL", n, d.replace("|", "/")) for n, ok, d in RESULTS]
    out = os.path.join(HERE, "runs", "exercise_report.md")
    with open(out, "w") as f:
        f.write("\n".join(lines))
    print("\n%d / %d checks passed · report: %s" % (n_ok, len(RESULTS), out))
    sys.exit(0 if n_ok == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
