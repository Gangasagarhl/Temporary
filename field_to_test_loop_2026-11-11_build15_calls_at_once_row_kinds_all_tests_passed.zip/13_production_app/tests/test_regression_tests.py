"""The regression test of a defect (owner, 2026-11-10): plan from the isolated sequence and the verified outcomes, checked against the recording,
written beside the fixed replay library, and run both ways on the simulated drive; the deallocate check of a base range; the safety gate.

    python3 -m pytest -q tests/test_regression_tests.py
"""
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
sys.path.insert(0, os.path.join(APP, "app"))
sys.path.insert(0, HERE)

S17 = os.path.join(APP, "uploads", "up-20261108-123729-0a98")
LIB = os.path.join(APP, "nvme_hier", "regress")
sys.path.insert(0, LIB)
import f2t_nvme as T   # noqa: E402


def _app_with_s17(root):
    """A throw-away application with a consistent copy of the S17 tree (timeouts, a read aborted with status 0/7)."""
    import fuzz_app as F
    from api import hier_api as H
    if not os.path.exists(os.path.join(S17, "hier.sqlite")):
        pytest.skip("the S17 sample tree is not on this machine")
    app, c, _k, _r = F.setup(root)
    d = os.path.join(H.uploads_dir(app.config["services"]), "up-s17")
    os.makedirs(d)
    src = sqlite3.connect("file:%s?mode=ro" % os.path.join(S17, "hier.sqlite"), uri=True)
    dst = sqlite3.connect(os.path.join(d, "hier.sqlite"))
    src.backup(dst)
    src.close()
    dst.close()
    with open(os.path.join(S17, "meta.json")) as fh:
        meta = json.load(fh)
    meta["upload_id"] = "up-s17"
    H.write_meta(d, meta)
    return app, c


def _make(c, fid, **extra):
    base = "/api/isolate/up-s17/%d/" % fid
    iso = c.post(base + "isolate", json={"anyway": True, "standin": True, "name": "t", "n": 4, "m": 2}).get_json()
    prop = c.post(base + "testcase", json={"sequence": iso["sequence"], "name": "t", "standin": True}).get_json()
    made = c.post(base + "testcase", json=dict({"sequence": prop["sequence"], "expected_outcomes": prop["expected_outcomes"], "verified": True, "name": "Tester"}, **extra))
    return iso, prop, made


def _pytest(path, **env):
    e = {k: v for k, v in os.environ.items() if not k.startswith("NVME_") and k != "EXPECT"}
    e.update(env)
    p = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "-rs", path], capture_output=True, text=True, timeout=180, cwd=os.path.dirname(path), env=e)
    return p.returncode, p.stdout


@pytest.fixture(scope="module")
def s17():
    root = tempfile.mkdtemp(prefix="regress_%d_" % os.getpid())
    try:
        yield _app_with_s17(root)
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_an_aborted_read_is_judged_by_the_recordings_usual_time_not_by_the_hosts_30_s(s17):
    app, c = s17
    iso, prop, made = _make(c, 10)             # finding 10: a Read the field host aborted after 421.788 us (status 0/7)
    r = made.get_json()
    assert made.status_code == 200, r
    o = r["plan"]["oracle_fault"]
    assert o["kind"] == "latency" and o["field_kind"] == "aborted by the host" and abs(o["limit_us"] - 305.689) < 0.01, o
    assert "421.788 us" in o["words"] and r["two_sided"]["ok"], r["two_sided"]


def test_a_timeout_defect_becomes_a_test_that_works_both_ways(s17):
    app, c = s17
    iso, prop, made = _make(c, 13)             # finding 13: a Write that never completed
    r = made.get_json()
    assert made.status_code == 200, r
    plan = r["plan"]
    assert plan["oracle_fault"]["kind"] == "timeout" and plan["oracle_fault"]["limit_us"] == 30 * 10 ** 6 and plan["steps"][plan["fault_step"] - 1]["position"] == "fault"
    assert r["checks"]["evidence"].startswith("every step matches") and r["two_sided"]["ok"], r["two_sided"]
    assert {(x["drive"], x["expect"], x["got"]) for x in r["two_sided"]["runs"]} == {("faulty", "fault", "pass"), ("faulty", "fixed", "fail"), ("correct", "fixed", "pass"), ("correct", "fault", "fail")}
    text = r["text"]
    for part in ("Purpose", "References", "Resource Requirements", "Last Modification", "Discussion", "Test Setup", "Procedure", "Observable Results", "Possible Problems", "PLAN = {", "T.run_case(PLAN"):
        assert part in text, part
    assert os.path.exists(os.path.join(os.path.dirname(r["path"]), "f2t_nvme.py"))
    # no drive on this machine: the file skips cleanly, it never passes
    rc, out = _pytest(r["path"])
    assert rc == 0 and "skipped" in out and "passed" not in out and "no drive given" in out, out


def test_a_status_defect_checks_the_recorded_status(s17):
    app, c = s17
    iso, prop, made = _make(c, 9)
    r = made.get_json()
    assert made.status_code == 200, r
    o = r["plan"]["oracle_fault"]
    assert (o["kind"], o["sct"], o["sc"]) == ("status", 0, 7) and r["two_sided"]["ok"], r["two_sided"]


def test_a_step_that_does_not_match_the_recording_is_refused(s17):
    app, c = s17
    base = "/api/isolate/up-s17/10/"
    iso = c.post(base + "isolate", json={"anyway": True, "standin": True, "name": "t"}).get_json()
    seq = [dict(x, parameters=dict(x.get("parameters") or {})) for x in iso["sequence"]]
    f = next(x for x in seq if x["position"] == "fault")
    f["parameters"]["slba"] = int(f["parameters"].get("slba") or 0) + 999
    prop = c.post(base + "testcase", json={"sequence": seq, "name": "t", "standin": True}).get_json()
    bad = c.post(base + "testcase", json={"sequence": prop["sequence"], "expected_outcomes": prop["expected_outcomes"], "verified": True, "name": "t"})
    assert bad.status_code == 400 and "do not match the recording" in bad.get_json()["error"] and "SLBA" in bad.get_json()["error"]


def test_the_first_form_is_still_written_when_asked_for(s17):
    app, c = s17
    iso, prop, made = _make(c, 10, format="nvme-cli")
    r = made.get_json()
    assert made.status_code == 200 and "EXPECT == \"fixed\"" in r["text"] and "PLAN = {" not in r["text"]


def test_known_reproduction_rate_sets_the_clean_runs():
    assert T.clean_runs_needed(10, 10) == 3
    assert T.clean_runs_needed(3, 10) == 33
    assert T.clean_runs_needed(1, 10) == 585
    assert T.clean_runs_needed(0, 10) is None
    assert abs(T.lower_bound(1, 10) - 0.0051) < 0.0002


@pytest.mark.parametrize("fault,command,want", [
    (None, "dsm", "PASS"),
    ("ignore_deallocate", "dsm", "PASS with warning"),
    ("stale_deallocate", "dsm", "FAIL"),
    ("wrong_value", "dsm", "FAIL"),
    ("spill", "dsm", "FAIL"),
    ("unstable", "dsm", "FAIL"),
    (None, "write_zeroes", "PASS"),
    ("ignore_deallocate", "write_zeroes", "PASS"),
])
def test_the_deallocate_check_fails_only_for_what_the_specification_forbids(tmp_path, fault, command, want):
    plan = {"id": "dealloc_probe", "version": 1, "deallocate_range": {"slba": 1000, "blocks": 32, "guard": 4, "command": command}}
    cfg = tmp_path / "sim.json"
    cfg.write_text(json.dumps({"lba_bytes": 512, "nsze": 100000, "drb": 1, "thinp": True, "faults": [{"kind": fault}] if fault else []}))
    os.environ.update(NVME_BACKEND="sim", NVME_SIM=str(cfg), NVME_RESULTS=str(tmp_path / "results"))
    try:
        if want == "FAIL":
            with pytest.raises(AssertionError) as e:
                T.deallocate_check(plan)
            assert "FAILED" in str(e.value)
        else:
            T.deallocate_check(plan)
        res = json.loads(next((tmp_path / "results").glob("*.json")).read_text())
        assert res["verdict"].startswith(want), res["verdict"]
        if fault == "spill":
            assert any("guard block" in x for x in res["fails"])
        if fault == "stale_deallocate":
            assert any("OLDER generation" in x for x in res["fails"])
    finally:
        for k in ("NVME_BACKEND", "NVME_SIM", "NVME_RESULTS"):
            os.environ.pop(k, None)


def test_the_safety_gate_never_runs_without_the_operators_allow_list(tmp_path, monkeypatch):
    monkeypatch.delenv("NVME_BACKEND", raising=False)
    monkeypatch.delenv("NVME_NS", raising=False)
    with pytest.raises(T.Skip, match="no drive given"):
        T.safety_gate({}, False)
    monkeypatch.setenv("NVME_NS", "/dev/ng9n1")
    with pytest.raises(T.Skip, match="does not exist"):
        T.safety_gate({}, False)
    monkeypatch.setenv("NVME_NS", "/etc/hostname")
    with pytest.raises(T.Skip, match="must name a namespace device"):
        T.safety_gate({}, False)


def test_the_models_plan_is_checked_sent_back_and_only_rows_of_the_window_are_replayed(s17, monkeypatch):
    """The model chooses rows; the code copies their parameters from the recording. A row outside the window is caught and sent back with the
    problem; the second answer is used; the rule's own check is kept when the model proposes another."""
    from api import isolate_api as A
    app, c = s17
    base = "/api/isolate/up-s17/9/"
    iso = c.post(base + "isolate", json={"anyway": True, "standin": True, "name": "t", "n": 4, "m": 2}).get_json()
    prop = c.post(base + "testcase", json={"sequence": iso["sequence"], "name": "t", "standin": True}).get_json()
    fault_row = next(x["source_row"] for x in iso["sequence"] if x["position"] == "fault")
    seen = []

    def fake(llm, prompt, schema, must_have):
        seen.append(prompt)
        if schema is not A.TP.PLAN_SCHEMA:
            return None, "stand-in"
        if len(seen) == 1:
            return {"analysis": "x", "replay_rows": [999999, fault_row], "row_reasons": [], "oracle": {"kind": "status", "status_type": 0, "status_code": 7},
                    "deallocate_first_block": 0, "deallocate_blocks": 0, "setup_note": ""}, "fake model"
        return {"analysis": "Row %d is the read that the drive answered with Command Abort Requested." % fault_row, "replay_rows": [fault_row],
                "row_reasons": [{"row": fault_row, "why": "the defect"}], "oracle": {"kind": "any_error"}, "deallocate_first_block": 0, "deallocate_blocks": 0,
                "setup_note": "nothing before it matters"}, "fake model"
    monkeypatch.setattr(A.ISO, "call_model", fake)
    made = c.post(base + "testcase", json={"sequence": prop["sequence"], "expected_outcomes": prop["expected_outcomes"], "verified": True, "name": "t", "author": "model"})
    r = made.get_json()
    assert made.status_code == 200, r
    m = r["model"]
    assert m["used"] == "model" and len(m["rounds"]) == 2 and "row 999999 is not in the WINDOW table" in m["rounds"][0]["problems"][0]
    assert "YOUR LAST ANSWER DID NOT PASS" in seen[-1] and "UNDER THE DEFECT COMMAND" in seen[0] and "WINDOW:" in seen[0]
    assert [s["source_row"] for s in r["plan"]["steps"]] == [fault_row]
    assert r["plan"]["oracle_fault"]["kind"] == "status" and any("the rule's own check 'status' is kept" in n for n in m["notes"])
    assert r["two_sided"]["ok"]
