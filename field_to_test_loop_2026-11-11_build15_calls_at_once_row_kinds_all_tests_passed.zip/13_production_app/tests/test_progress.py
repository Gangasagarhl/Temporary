"""Every long piece of work shows how far it is (owner, 2026-11-09: "while building the tree it was stuck; I want the percentage in all these places").

    python3 -m pytest -q tests/test_progress.py
"""
import os
import re
import sqlite3
import sys
import threading
import time

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
sys.path.insert(0, os.path.join(APP, "app"))
from agentic import core  # noqa: E402
from nvme_hier import builder as B, loader as L, rules as RL  # noqa: E402

S08 = os.path.join(APP, "samples", "clean_five_files", "S08_interrupt_before_completion")
NAMES = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv", "nvme_command": "nvme_command.csv"}


@pytest.fixture
def loaded(tmp_path):
    if not os.path.isdir(S08):
        pytest.skip("the sample set is not on this machine")
    db = str(tmp_path / "h.sqlite")
    L.load_upload(db, {k: os.path.join(S08, n) for k, n in NAMES.items()})
    return db


def test_the_tree_build_reports_a_percentage_that_only_grows_to_100(loaded, monkeypatch):
    monkeypatch.setattr(L, "REPORT_SECONDS", 0.0)            # every report, not one per second, on a recording this small
    seen = []
    B.build(loaded, progress=lambda step, detail, pct: seen.append((step, detail, pct)))
    pcts = [p for _s, _d, p in seen]
    assert all(0 <= p <= 100 for p in pcts) and pcts == sorted(pcts), pcts[:40]
    assert pcts[0] < 15 and pcts[-1] == 100.0
    names = {s for s, _d, _p in seen}
    for step in ("tree: packets to link transactions", "tree: link to split transactions", "tree: NVMe transactions to commands", "tree: writing the packet links", "tree: checking the analyzer's counts"):
        assert step in names
    assert len({round(p) for p in pcts}) >= 6                # the bar moves, it does not jump from nothing to done


def test_the_percentage_moves_inside_one_pass(loaded, monkeypatch):
    monkeypatch.setattr(L, "REPORT_SECONDS", 0.0)
    monkeypatch.setattr(B, "PROGRESS_EVERY", 500)
    seen = []
    B.build(loaded, progress=lambda step, detail, pct: seen.append((step, pct)))
    first_pass = [p for s, p in seen if s == "tree: packets to link transactions"]
    assert len(set(first_pass)) >= 5, first_pass


def test_one_long_silent_statement_still_says_it_is_working():
    con = sqlite3.connect(":memory:")
    said = []
    end = L.heartbeat(con, said.append, every=0.05)
    con.execute("WITH RECURSIVE c(x) AS (SELECT 1 UNION ALL SELECT x + 1 FROM c WHERE x < 8000000) SELECT SUM(x) FROM c").fetchone()
    end()
    assert said and all(b >= a for a, b in zip(said, said[1:]))


def test_the_rules_report_progress_and_a_sign_of_life(loaded):
    B.build(loaded)
    seen = []
    RL.apply(loaded, progress=lambda step, detail: seen.append(step))
    assert any(s.startswith("rules: NVMe commands") for s in seen) and any("roll-up" in s for s in seen)


class Idle:
    def run_step(self, ctx):
        return None


@pytest.fixture
def engine(tmp_path):
    store = core.Store(str(tmp_path / "a.sqlite"))
    pid = store.exec("INSERT INTO project (admin, name, created, updated) VALUES ('a', 'p', 0, 0)")
    rid = store.exec("INSERT INTO run (project, kind, target, params, state, created, updated) VALUES (?, 'x', 't', '{}', 'running', 0, 0)", (pid,))
    return core.Engine(store, {"x": Idle()}, runner=None), rid


def _step(eng, rid, key="coder", note=None):
    sid = eng.store.exec("INSERT INTO step (run, idx, key, title, state, note, started) VALUES (?, 0, ?, 'The Coder writes the code', 'running', ?, ?)", (rid, key, note, time.time()))
    return eng.store.one("SELECT * FROM step WHERE id=?", (sid,))


def _tick(eng, st, seconds=0.5, t0=None):
    stop = threading.Event()
    th = threading.Thread(target=eng._tick_step, args=(st, t0 or time.time(), stop, 0.05))
    th.start()
    time.sleep(seconds)
    stop.set()
    th.join()
    return eng.store.one("SELECT note FROM step WHERE id=?", (st["id"],))["note"]


def test_a_step_with_no_progress_of_its_own_shows_an_estimated_percentage(engine):
    eng, rid = engine
    note = _tick(eng, _step(eng, rid))
    assert re.match(r"about \d+% · The Coder writes the code · .* so far$", note), note


def test_a_step_with_its_own_percentage_is_left_alone(engine):
    eng, rid = engine
    assert _tick(eng, _step(eng, rid, note="37% · reading the file")) == "37% · reading the file"


def test_the_estimate_comes_from_earlier_steps_and_never_passes_95(engine):
    eng, rid = engine
    t = time.time()
    eng.store.exec("INSERT INTO step (run, idx, key, title, state, started, finished) VALUES (?, 1, 'coder', 'x', 'done', ?, ?)", (rid, t - 20, t))
    st = _step(eng, rid)
    assert eng._typical_seconds(st) == 20
    note = _tick(eng, st, t0=time.time() - 500)
    assert note.startswith("about 95% ·")
    assert re.findall(r"about", note) == ["about"] and note.count(" so far") == 1      # the words do not pile up on each tick
