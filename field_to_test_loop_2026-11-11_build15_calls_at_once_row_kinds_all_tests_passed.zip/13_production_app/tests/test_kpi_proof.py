#!/usr/bin/env python3
"""Measured evidence for the KPIs of the goals page (owner, 2026-11-09: "I need proof everything is working, every KPI").

    python3 tests/test_kpi_proof.py [seeds]       (default 10; about 3 minutes; writes runs/kpi_proof/kpi_proof.json)

The real pipeline (loader, tree, rules, isolation API, four signals, procedural graph, test generator) in this process, on a
throw-away root: nothing of the admin's is read or written, no server and no model are used.

Method (see the status report for the sources):
  ground truth   known faults are written into copies of clean five-file recordings, in the CSV files, before anything reads
                 them: a command never completed, over the host's limit, slower than usual, aborted by the host, Read failed;
                 3 of each per recording, picked by a seed the rules never saw
  KPI 2          exact command found, right kind, false alarms on the clean recordings, against a trivial baseline (a filter
                 on the status column) on the same files
  KPI 2 leakage  a failure stored from one recording must, in another recording, get its procedure and its regression test;
                 each generated test must fail on a drive that still has the defect and pass on a fixed one (simulated drive)
  KPI 3          every script is written with no hand edit, compiles and runs unedited
  KPI 1          PROXY ONLY: rows left for an engineer to read. It is not a measure of engineer hours.
What this cannot show: anything about real recordings, real drives, or real engineer time.
"""
import bisect
import csv
import json
import os
import random
import shutil
import signal
import sqlite3
import statistics
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
sys.path.insert(0, os.path.join(APP, "app"))
csv.field_size_limit(10 ** 9)
from nvme_hier import builder as B, loader as L, rules as RL  # noqa: E402

BASES = ["S27_lcrc_nak_replay", "demo_225_commands"]
SAMPLES = os.path.join(APP, "samples", "clean_five_files")
NAMES = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv", "nvme_command": "nvme_command.csv"}
PER_KIND = 3
FIRST_SEED = 1000                        # seeds the rules were never tuned on
KINDS = {"never_completed": "never completed", "over_limit": "over the host's limit", "slower": "slower than usual", "aborted": "aborted by the host", "read_failed": None}
SIM = {"never_completed": ("hang", None), "over_limit": ("hang", None), "slower": ("slow", None), "aborted": ("status", "0x7"), "read_failed": ("status", "0x281")}
PS = 10 ** 12
RESULTS, PROBLEMS = {}, []


def to_ps(s):
    s = s.strip().rstrip("s")
    a, _, b = s.partition(".")
    return int(a) * PS + int((b + "0" * 12)[:12])


def from_ps(ps):
    return "%04d.%012ds" % (ps // PS, ps % PS)


def num(v):
    v = (v or "").strip().split(" ")[0]
    if not v:
        return None
    return int(v, 16) if v.lower().startswith("0x") else int(v)


def read_csv(path):
    with open(path, encoding="utf-8-sig", newline="") as fh:
        r = csv.reader(fh)
        head = next(r)
        return head, [x for x in r if any(c.strip() for c in x)]


def write_csv(path, head, rows):
    with open(path, "w", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(head)
        w.writerows(rows)


def inject(base, out, seed, per_kind=PER_KIND):
    """Copies a clean recording into `out` with known faults written into its CSV files. Returns {command number: kind}."""
    os.makedirs(out, exist_ok=True)
    d = os.path.join(SAMPLES, base)
    for key, name in NAMES.items():
        if key not in ("nvme_command", "nvme_transaction"):
            shutil.copy(os.path.join(d, name), os.path.join(out, name))
    r = random.Random(seed)
    ch, cmds = read_csv(os.path.join(d, NAMES["nvme_command"]))
    th, trs = read_csv(os.path.join(d, NAMES["nvme_transaction"]))
    c = {n: ch.index(n) for n in ("NVMe Cmd", "OPC", "SQID", "CID", "NLB", "ST", "ST.SCT", "ST.SC", "Time Stamp")}
    t = {n: th.index(n) for n in ("Type", "SQID", "CID", "SCT", "SC", "Time Stamp")}
    is_cqe = lambda row: "completion" in row[t["Type"]].lower() and "doorbell" not in row[t["Type"]].lower()      # noqa: E731
    open_cmds, entry_of = {}, {}
    order = sorted(range(len(cmds)), key=lambda i: to_ps(cmds[i][c["Time Stamp"]]))
    k, by_key = 0, {}
    for i in order:
        by_key.setdefault((cmds[i][c["SQID"]], cmds[i][c["CID"]]), []).append(i)
    for j, row in enumerate(trs):
        if is_cqe(row):
            at = to_ps(row[t["Time Stamp"]])
            cands = [i for i in by_key.get((row[t["SQID"]], row[t["CID"]]), []) if to_ps(cmds[i][c["Time Stamp"]]) <= at]
            if cands and cands[-1] not in entry_of:
                entry_of[cands[-1]] = j
    usable = [i for i, _j in entry_of.items() if cmds[i][c["SQID"]] != "0" and num(cmds[i][c["ST.SCT"]] or "0") == 0 and num(cmds[i][c["ST.SC"]] or "0") == 0]
    groups = {}
    for i in usable:
        groups.setdefault((cmds[i][c["OPC"]], cmds[i][c["NLB"]]), []).append(i)
    r.shuffle(usable)
    truth, used, drop, move = {}, set(), set(), {}

    def take(pred):
        out_ = []
        for i in usable:
            if len(out_) == per_kind:
                break
            if i not in used and pred(i):
                out_.append(i)
                used.add(i)
        return out_

    def status(i, sct, sc, text):
        cmds[i][c["ST"]], cmds[i][c["ST.SCT"]], cmds[i][c["ST.SC"]] = "0x%04X (%s)" % ((sct << 8) | sc, text), "%d" % sct, "0x%02X" % sc
        trs[entry_of[i]][t["SCT"]], trs[entry_of[i]][t["SC"]] = "%d" % sct, "0x%02X" % sc

    for i in take(lambda i: True):
        truth[i] = "never_completed"
        drop.add(entry_of[i])
        cmds[i][c["ST"]] = cmds[i][c["ST.SCT"]] = cmds[i][c["ST.SC"]] = ""
    def unique_cid(i):
        """A command number stays unique while the command is outstanding (NVMe Base 2.1): a delayed command gets one of its own."""
        new = str(50000 + len(truth))
        a, b = to_ps(cmds[i][c["Time Stamp"]]), to_ps(trs[entry_of[i]][t["Time Stamp"]])
        key = (cmds[i][c["SQID"]], cmds[i][c["CID"]])
        for row in trs:
            if (row[t["SQID"]], row[t["CID"]]) == key and a <= to_ps(row[t["Time Stamp"]]) <= b:
                row[t["CID"]] = new
        cmds[i][c["CID"]] = new

    for i in take(lambda i: True):
        truth[i] = "over_limit"
        unique_cid(i)
        move[entry_of[i]] = to_ps(cmds[i][c["Time Stamp"]]) + 31 * PS
    for i in take(lambda i: len(groups[(cmds[i][c["OPC"]], cmds[i][c["NLB"]])]) >= 25):
        truth[i] = "slower"
        unique_cid(i)
        move[entry_of[i]] = to_ps(trs[entry_of[i]][t["Time Stamp"]]) + 20 * 10 ** 9      # 20 ms on a command of tens of microseconds
    for i in take(lambda i: True):
        truth[i] = "aborted"
        status(i, 0, 7, "Command Abort Requested")
    for i in take(lambda i: "read" in cmds[i][c["OPC"]].lower()):
        truth[i] = "read_failed"
        status(i, 2, 0x81, "Unrecovered Read Error")
    # the recording goes on 40 s after its last command, so that the host's limit can pass: one healthy command at the end
    last = cmds[order[-1]]
    marker = list(next(cmds[i] for i in order if i in entry_of and i not in used and cmds[i][c["SQID"]] != "0"))
    end = to_ps(last[c["Time Stamp"]]) + 40 * PS
    marker[c["NVMe Cmd"]] = str(max(int(x[c["NVMe Cmd"]]) for x in cmds) + 1)
    marker[c["Time Stamp"]] = from_ps(end)
    marker[c["CID"]] = "60001"
    cmds.append(marker)
    tail = list(trs[next(iter(j for i, j in entry_of.items() if i not in used))])
    tail[t["SQID"]], tail[t["CID"]], tail[t["SCT"]], tail[t["SC"]] = marker[c["SQID"]], "60001", "0", "0"
    tail[t["Time Stamp"]] = from_ps(end + 50 * 10 ** 6)
    # rows moved in time go where the new time puts them; the file stays in time order
    moved = []
    kept = []
    for j, row in enumerate(trs):
        if j in drop:
            continue
        if j in move:
            row = list(row)
            row[t["Time Stamp"]] = from_ps(move[j])
            moved.append(row)
        else:
            kept.append(row)
    moved.append(tail)
    times = [to_ps(x[t["Time Stamp"]]) for x in kept]
    for row in sorted(moved, key=lambda x: to_ps(x[t["Time Stamp"]])):
        at = to_ps(row[t["Time Stamp"]])
        p = bisect.bisect_right(times, at)
        kept.insert(p, row)
        times.insert(p, at)
    write_csv(os.path.join(out, NAMES["nvme_command"]), ch, cmds)
    write_csv(os.path.join(out, NAMES["nvme_transaction"]), th, kept)
    return {int(cmds[i][c["NVMe Cmd"]]): kind for i, kind in truth.items()}


def renumber_and_shuffle(folder, seed):
    """Hard joins: every queue's command numbers restart from 0, so several queues use the same numbers at once (legal), and nearby completions
    change places (legal: commands finish in any order)."""
    r = random.Random(seed)
    cp, tp = os.path.join(folder, NAMES["nvme_command"]), os.path.join(folder, NAMES["nvme_transaction"])
    ch, cmds = read_csv(cp)
    th, trs = read_csv(tp)
    cq, cc, tq, tc, tt, ts = ch.index("SQID"), ch.index("CID"), th.index("SQID"), th.index("CID"), th.index("Type"), th.index("Time Stamp")
    maps = {}
    for row in cmds:
        m = maps.setdefault(row[cq], {})
        row[cc] = str(m.setdefault(row[cc], len(m)))
    for row in trs:
        if row[tc] and row[tq] in maps and row[tc] in maps[row[tq]]:
            row[tc] = str(maps[row[tq]][row[tc]])
    cqe = [i for i, row in enumerate(trs) if "completion" in row[tt].lower() and "doorbell" not in row[tt].lower()]
    for a, b in zip(cqe[::2], cqe[1::2]):
        if r.random() < 0.5 and trs[a][tq] == trs[b][tq] and to_ps(trs[b][ts]) - to_ps(trs[a][ts]) < 40 * 10 ** 6:
            trs[a][ts], trs[b][ts] = trs[b][ts], trs[a][ts]
            trs[a], trs[b] = trs[b], trs[a]
    write_csv(cp, ch, cmds)
    write_csv(tp, th, trs)


def parsed(base):
    d = os.path.join(SAMPLES, base)
    ch, cmds = read_csv(os.path.join(d, NAMES["nvme_command"]))
    th, trs = read_csv(os.path.join(d, NAMES["nvme_transaction"]))
    c = {n: ch.index(n) for n in ("NVMe Cmd", "OPC", "SQID", "CID", "NLB", "Time Stamp")}
    t = {n: th.index(n) for n in ("Type", "SQID", "CID", "Time Stamp")}
    by, entry = {}, {}
    for i in sorted(range(len(cmds)), key=lambda i: to_ps(cmds[i][c["Time Stamp"]])):
        by.setdefault((cmds[i][c["SQID"]], cmds[i][c["CID"]]), []).append(i)
    for j, row in enumerate(trs):
        if "completion" in row[t["Type"]].lower() and "doorbell" not in row[t["Type"]].lower():
            at = to_ps(row[t["Time Stamp"]])
            cs = [i for i in by.get((row[t["SQID"]], row[t["CID"]]), []) if to_ps(cmds[i][c["Time Stamp"]]) <= at]
            if cs and cs[-1] not in entry:
                entry[cs[-1]] = j
    return ch, cmds, th, trs, c, t, entry


def retime(cmds, trs, c, t, i, j, k, ps):
    """Command i's completion entry comes `ps` after the command; it gets a command number of its own while it is outstanding."""
    new, a, b, key = str(50000 + k), to_ps(cmds[i][c["Time Stamp"]]), to_ps(trs[j][t["Time Stamp"]]), (cmds[i][c["SQID"]], cmds[i][c["CID"]])
    for r in trs:
        if (r[t["SQID"]], r[t["CID"]]) == key and a <= to_ps(r[t["Time Stamp"]]) <= b:
            r[t["CID"]] = new
    cmds[i][c["CID"]] = new
    trs[j][t["Time Stamp"]] = from_ps(a + int(ps))


def two_level(root, name, ch, cmds, th, trs, t):
    """Only the two files the command rules need: fast enough for many attacks."""
    d = os.path.join(root, "two", name)
    os.makedirs(d, exist_ok=True)
    write_csv(os.path.join(d, "nvme_command.csv"), ch, cmds)
    write_csv(os.path.join(d, "NVME_Transactions.csv"), th, sorted(trs, key=lambda x: to_ps(x[t["Time Stamp"]])))
    db = os.path.join(d, "h.sqlite")
    L.load_upload(db, {"nvme_command": os.path.join(d, "nvme_command.csv"), "nvme_transaction": os.path.join(d, "NVME_Transactions.csv")})
    B.build(db)
    RL.apply(db)
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    got = {n for (n,) in con.execute("SELECT row_n FROM finding WHERE rule IN ('cmd.timeout', 'cmd.read_failure')")}
    n = con.execute("SELECT COUNT(*) FROM cmd").fetchone()[0]
    con.close()
    shutil.rmtree(d, ignore_errors=True)
    return got, n


def noise_alarms(root, sigma, seeds=5):
    alarms = total = 0
    for seed in range(seeds):
        for base in BASES:
            ch, cmds, th, trs, c, t, entry = parsed(base)
            r = random.Random(FIRST_SEED + seed)
            for k, (i, j) in enumerate(entry.items()):
                ps = (to_ps(trs[j][t["Time Stamp"]]) - to_ps(cmds[i][c["Time Stamp"]])) * r.lognormvariate(0, sigma)
                retime(cmds, trs, c, t, i, j, k, ps)
            got, n = two_level(root, "n%d%s" % (seed, base[:3]), ch, cmds, th, trs, t)
            alarms += len(got)
            total += n
    return alarms, total


def group_attack(root, pick_fn, seeds=4):
    found = inj = other = 0
    for seed in range(seeds):
        for base in BASES:
            ch, cmds, th, trs, c, t, entry = parsed(base)
            r = random.Random(FIRST_SEED + 7 + seed)
            groups = {}
            for i in entry:
                if cmds[i][c["SQID"]] != "0":
                    groups.setdefault((cmds[i][c["OPC"]], cmds[i][c["NLB"]]), []).append(i)
            med = {k: statistics.median(to_ps(trs[entry[i]][t["Time Stamp"]]) - to_ps(cmds[i][c["Time Stamp"]]) for i in v) for k, v in groups.items()}
            truth = set()
            for k, (i, mult) in enumerate(pick_fn(r, groups, cmds, c)):
                retime(cmds, trs, c, t, i, entry[i], k, med[(cmds[i][c["OPC"]], cmds[i][c["NLB"]])] * mult)
                truth.add(int(cmds[i][c["NVMe Cmd"]]))
            got, _n = two_level(root, "g%d%s" % (seed, base[:3]), ch, cmds, th, trs, t)
            found += len(truth & got)
            inj += len(truth)
            other += len(got - truth)
    return found, inj, other


def learning_curve(root, runs=120, rounds=60):
    """Does the graph learn? A simulated admin says Correct with the procedure's true quality. The policy against always using the first stored one."""
    from nvme_hier import store as ST
    q = [0.55, 0.7, 0.9]
    late_policy = late_static = 0.0
    best_share = 0.0
    for run in range(runs):
        st = ST.Store(os.path.join(root, "rl", "%d" % run, "db", "k.sqlite"))
        s = {"fine": "f", "coarse": "c", "display": "d", "fields": {"lvl": "nvme_command", "err": "cmd.timeout", "cmd": "io.Write", "cause": "self", "alg": "v1"}}
        st.touch_signature(s, "D", upload_id="u", finding_id=1)
        r = random.Random(run)
        ids = [st.add_procedure("f", [{"step": 1, "command": "c%d" % k, "position": "fault"}], "p", "x") for k in range(3)]
        for t_ in range(rounds):
            ch = st.graph_choice("f")
            pid = ch["procedure_id"] if ch else ids[0]
            good = r.random() < q[ids.index(pid)]
            st.signal("f", pid, "correct" if good else "wrong", "sim")
            if t_ >= rounds - 20:
                late_policy += q[ids.index(pid)]
                late_static += q[0]
                best_share += pid == ids[2]
        shutil.rmtree(os.path.join(root, "rl", "%d" % run), ignore_errors=True)
    n = runs * 20.0
    return late_policy / n, late_static / n, best_share / n


def load(root, uid, folder, firmware=None):
    d = os.path.join(root, "uploads", uid)
    os.makedirs(d, exist_ok=True)
    files = {k: os.path.join(folder, n) for k, n in NAMES.items()}
    db = os.path.join(d, "hier.sqlite")
    t0 = time.time()
    L.load_upload(db, files)
    B.build(db)
    RL.apply(db)
    json.dump({"upload_id": uid, "created": time.time(), "operator": "kpi", "device": "KPI DRIVE", "trace_name": uid, "recording_date": "", "notes": "", "files": files,
               "status": "loaded", "thresholds": {}, "file_stats": {}, "firmware": firmware}, open(os.path.join(d, "meta.json"), "w"))
    return db, time.time() - t0


def findings(db):
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    rows = [(i, rule, n, json.loads(detail or "{}").get("kind")) for i, rule, n, detail in con.execute(
        "SELECT id, rule, row_n, detail FROM finding WHERE rule IN ('cmd.timeout', 'cmd.read_failure')")]
    total = sum(con.execute("SELECT COUNT(*) FROM %s" % t).fetchone()[0] for t in ("pkt", "lnk", "spl", "ntx", "cmd"))
    n_cmd = con.execute("SELECT COUNT(*) FROM cmd").fetchone()[0]
    status = {n for n, a, b in con.execute("SELECT n, sct, sc FROM cmd") if (a or 0) != 0 or (b or 0) != 0}
    con.close()
    return rows, total, n_cmd, status


SIM_NVME = r'''#!/usr/bin/env python3
"""A simulated drive behind the nvme-cli command line: healthy, except the one command that has the defect on defective firmware."""
import os, sys, time
a = sys.argv[1:]
op = a[0] if a else ""
val = lambda f: a[a.index(f) + 1] if f in a else None
e = os.environ
state = e["SIM_STATE"] + "." + op                     # how many commands of this kind were sent so far in this run
n = int(open(state).read()) if os.path.exists(state) else 0
open(state, "w").write(str(n + 1))
import random
bad = e.get("SIM_FIRMWARE") == "defective" and op == e.get("SIM_FAULT_OP") and n % max(1, int(e.get("SIM_FAULT_EVERY", "1"))) == int(e.get("SIM_FAULT_INDEX", "0")) and random.random() < float(e.get("SIM_FAULT_P", "1"))
healthy = int(e.get("SIM_HEALTHY_US", "1"))
if random.random() < float(e.get("SIM_SPIKE", "0")):
    healthy *= 1000
kind = e.get("SIM_FAULT_KIND", "")
if bad and kind == "hang":
    time.sleep(3600)
if bad and kind == "status":
    sys.stderr.write("NVMe status: Injected failure(%s)\n" % e["SIM_FAULT_STATUS"])
    sys.exit(1)
if op == "read":
    sys.stdout.buffer.write(b"\0" * int(val("--data-size") or 512))
sys.stdout.buffer.write(("\n  latency: %s: %d us\n" % (op, 50000 if bad and kind == "slow" else healthy)).encode())
'''


def run_script(path, sim_dir, dev, firmware, expect, fault, **extra):
    op = fault["command"].lower()
    kind, status = fault["sim"]
    state = os.path.join(sim_dir, "count")
    for f in os.listdir(sim_dir):
        if f.startswith("count."):
            os.remove(os.path.join(sim_dir, f))
    env = dict(os.environ, PATH=sim_dir + os.pathsep + os.environ["PATH"], NVME_DEV=dev, NVME_TIMEOUT_S="1.0", EXPECT=expect, SIM_FIRMWARE=firmware, SIM_FAULT_OP=op,
               SIM_FAULT_INDEX=str(fault["index"]), SIM_FAULT_EVERY=str(fault["every"]), SIM_STATE=state, SIM_FAULT_KIND=kind, SIM_FAULT_STATUS=status or "", NVME_REPEAT=str(extra.get("repeat", 10)),
               SIM_FAULT_P=str(extra.get("p", 1.0)), SIM_HEALTHY_US=str(extra.get("healthy_us", 1)), SIM_SPIKE=str(extra.get("spike", 0)))
    p = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", path], capture_output=True, text=True, env=env, cwd=os.path.dirname(path), timeout=240)
    last = [x for x in p.stdout.strip().splitlines() if x.strip()]
    why = [x[:220] for x in last if x.startswith("E  ") and ("FAILED" in x or "Error" in x)][:2]
    return p.returncode, (last[-1] if last else p.stderr[-200:]), why


class Api:
    def __init__(self, root):
        from server import create_app
        cfg = json.load(open(os.path.join(APP, "config", "app_config.json")))
        self.app = create_app(cfg, root)
        self.c = self.app.test_client()

    def post(self, path, body):
        r = self.c.post(path, json=body)
        j = r.get_json(silent=True) or {}
        if r.status_code >= 400:
            raise RuntimeError("%s -> %s: %s" % (path, r.status_code, j.get("error")))
        return j

    def get(self, path):
        return self.c.get(path).get_json(silent=True) or {}


def isolate(api, uid, fid):
    return api.post("/api/isolate/%s/%d/isolate" % (uid, fid), {"n": 10, "m": 10, "levels": ["nvme_transaction"], "anyway": True, "standin": True, "name": "kpi"})


def store_and_write_test(api, uid, fid, iso):
    """The admin says Correct on the proposal; the expected outcomes are verified; the test file is written. Nothing is edited by hand."""
    seq = iso["sequence"]
    base = "/api/isolate/%s/%d/" % (uid, fid)
    res = api.post(base + "signal", {"signal": "correct", "proposal_steps": seq, "proposal_text": iso.get("reason") or "", "scenario_name": iso.get("scenario_name"), "reason": iso.get("reason") or "", "name": "kpi"})
    pid = res["result"].get("new_procedure_id") or res["result"].get("procedure_id")
    prop = api.post(base + "testcase", {"sequence": seq, "name": "kpi", "standin": True})
    made = api.post(base + "testcase", {"sequence": prop.get("sequence") or seq, "expected_outcomes": prop["expected_outcomes"], "verified": True, "procedure_id": pid, "scenario_name": iso.get("scenario_name"), "name": "kpi", "format": "nvme-cli"})   # this harness runs the first form against a stand-in nvme-cli
    return pid, made["path"], prop.get("sequence") or seq


def check(name, ok, detail=""):
    print("%s  %s  %s" % ("PASS" if ok else "FAIL", name, detail))
    if not ok:
        PROBLEMS.append(name)
    return ok


def main():
    seeds = int(sys.argv[1]) if len(sys.argv) > 1 else 10
    keep = os.path.join(APP, "runs", "kpi_proof")
    os.makedirs(keep, exist_ok=True)
    root = tempfile.mkdtemp(prefix="kpi_proof_")
    sim = os.path.join(root, "sim")
    os.makedirs(sim)
    with open(os.path.join(sim, "nvme"), "w") as fh:
        fh.write(SIM_NVME.replace("#!/usr/bin/env python3", "#!" + sys.executable, 1))
    os.chmod(os.path.join(sim, "nvme"), 0o755)
    dev = os.path.join(sim, "fake_drive")
    open(dev, "w").close()
    t_start = time.time()
    print("-- clean recordings: no fault written, the two rules must stay silent")
    clean = {}
    for base in BASES + ["S08_interrupt_before_completion"]:
        db, secs = load(root, "up-clean-" + base[:6], os.path.join(SAMPLES, base))
        rows, total, n_cmd, _st = findings(db)
        clean[base] = {"commands": n_cmd, "false_alarms": len(rows)}
    alarms = sum(v["false_alarms"] for v in clean.values())
    check("KPI 2 detection: no false alarm on clean recordings", alarms == 0, "%d alarms on %d commands" % (alarms, sum(v["commands"] for v in clean.values())))

    print("\n-- injected faults, full pipeline, %d seeds x %d recordings" % (seeds, len(BASES)))
    runs = []
    by_kind = {k: {"injected": 0, "found": 0, "kind_right": 0} for k in KINDS}
    for seed in range(FIRST_SEED, FIRST_SEED + seeds):
        for base in BASES:
            uid = "up-%s-%d" % (base[:4].lower(), seed)
            folder = os.path.join(root, "in", uid)
            truth = inject(base, folder, seed)
            db, secs = load(root, uid, folder)
            rows, total, n_cmd, status_col = findings(db)
            got = {n: (rule, kind) for _i, rule, n, kind in rows}
            tp = fp = kr = 0
            for n, kind in truth.items():
                by_kind[kind]["injected"] += 1
                if n in got:
                    tp += 1
                    by_kind[kind]["found"] += 1
                    rule, seen = got[n]
                    right = rule == "cmd.read_failure" if kind == "read_failed" else (rule == "cmd.timeout" and seen == KINDS[kind])
                    kr += right
                    by_kind[kind]["kind_right"] += right
            fp = len([n for n in got if n not in truth])
            base_found = len([n for n in truth if n in status_col])
            base_fp = len([n for n in status_col if n not in truth])
            runs.append({"seed": seed, "base": base, "uid": uid, "injected": len(truth), "found": tp, "kind_right": kr, "false_alarms": fp, "baseline_found": base_found, "baseline_false": base_fp,
                         "rows_to_read": len(got), "commands": n_cmd, "rows": total, "seconds": round(secs, 1), "findings": rows, "truth": truth})
    inj = sum(r["injected"] for r in runs)
    found = sum(r["found"] for r in runs)
    kind_ok = sum(r["kind_right"] for r in runs)
    fp = sum(r["false_alarms"] for r in runs)
    recall, precision, kind_acc = found / inj, found / max(1, found + fp), kind_ok / max(1, found)
    base_found = sum(r["baseline_found"] for r in runs)
    print("      by kind:", {k: "%(found)d of %(injected)d, right kind %(kind_right)d" % v for k, v in by_kind.items()})
    check("KPI 2 detection: at least 95%% of injected faults found at the exact command", recall >= 0.95, "%d of %d = %.1f%%" % (found, inj, 100 * recall))
    check("KPI 2 detection: at least 95%% of what it reports is a real fault", precision >= 0.95, "%.1f%% (%d false alarms)" % (100 * precision, fp))
    check("KPI 2 detection: at least 95%% get the right kind of fault", kind_acc >= 0.95, "%d of %d = %.1f%%" % (kind_ok, found, 100 * kind_acc))
    wins = sum(r["found"] > r["baseline_found"] for r in runs)
    check("KPI 2 improved accuracy: better than a filter on the status column in every run", wins == len(runs), "%d of %d runs; tool %.1f%%, filter %.1f%%" % (wins, len(runs), 100 * recall, 100 * base_found / inj))
    cut = [1 - r["rows_to_read"] / r["commands"] for r in runs]
    check("KPI 1 PROXY: at least 50%% fewer commands to read in every run", min(cut) >= 0.5, "lowest %.1f%%, median %.1f%%" % (100 * min(cut), 100 * statistics.median(cut)))

    print("\n-- known failures: stored from one recording, must be caught in another; generated tests on a simulated drive")
    api = Api(root)
    known, scripts, leaks, recur, new_sigs = {}, [], [], 0, 0
    pairs = [(runs[i], runs[i + 2]) for i in range(0, len(runs) - 2, 2)] + [(runs[i], runs[i + 2]) for i in range(1, len(runs) - 2, 2)]
    for first, later in pairs:
        for fid, _rule, n, _kind in first["findings"]:
            sig = api.get("/api/isolate/%s/%d/graph" % (first["uid"], fid))["graph"]["signature"]
            if sig in known or not first["truth"].get(n):
                continue
            iso = isolate(api, first["uid"], fid)
            pid, path, seq = store_and_write_test(api, first["uid"], fid, iso)
            f0 = next(s for s in seq if s.get("position") == "fault")
            fault = dict(f0, sim=SIM[first["truth"][n]], index=len([s for s in seq if s["step"] < f0["step"] and s["command"] == f0["command"]]),
                         every=max(1, len([s for s in seq if s["command"] == f0["command"]])))
            known[sig] = {"procedure": pid, "test": path}
            scripts.append({"path": path, "kind": first["truth"][n], "fault": fault})
        for fid, _rule, n, _kind in later["findings"]:
            sig = api.get("/api/isolate/%s/%d/graph" % (later["uid"], fid))["graph"]["signature"]
            if sig not in known:
                new_sigs += 1
                continue
            recur += 1
            ch = isolate(api, later["uid"], fid).get("choice")
            if not ch or not ch.get("test_path"):
                leaks.append((later["uid"], fid))
    check("KPI 2 leakage: every failure that came back got its stored procedure and regression test", recur > 0 and not leaks, "%d recurrences of %d known failures, %d leaked; %d other failures were new" % (recur, len(known), len(leaks), new_sigs))
    ran = {"defect caught": 0, "reproduced": 0, "fixed passes": 0, "fault absent": 0, "skipped": 0}
    bad = []
    for s in scripts:
        a = run_script(s["path"], sim, dev, "defective", "fixed", s["fault"])
        b = run_script(s["path"], sim, dev, "defective", "fault", s["fault"])
        c = run_script(s["path"], sim, dev, "fixed", "fixed", s["fault"])
        d = run_script(s["path"], sim, dev, "fixed", "fault", s["fault"])
        if any("skipped" in x[1] and "failed" not in x[1] and "passed" not in x[1] for x in (a, b, c, d)):
            ran["skipped"] += 1
            bad.append((s["kind"], "skipped", a[1]))
            continue
        ok = (a[0] == 1, b[0] == 0, c[0] == 0, d[0] == 1)
        for key, v in zip(("defect caught", "reproduced", "fixed passes", "fault absent"), ok):
            ran[key] += v
        if not all(ok):
            shutil.copy(s["path"], keep)
            bad.append((s["kind"], os.path.basename(s["path"]), [x[1] for x in (a, b, c, d)], [x[2] for x in (a, b, c, d)], s["fault"].get("command")))
    n = len(scripts)
    check("KPI 2 leakage: each generated test fails on a drive that still has the defect", n > 0 and ran["defect caught"] == n, "%d of %d" % (ran["defect caught"], n))
    check("KPI 2 leakage: each generated test passes on a fixed drive", n > 0 and ran["fixed passes"] == n, "%d of %d" % (ran["fixed passes"], n))
    check("KPI 3 productivity: every script written with no hand edit, and each ran unedited", n > 0 and ran["skipped"] == 0 and ran["reproduced"] == n, "%d scripts; %d skipped; hand-written lines 0" % (n, ran["skipped"]))
    for b_ in bad[:8]:
        print("      problem:", json.dumps(b_, default=str)[:400])

    print("\n-- harder: what the system must survive")
    for sigma, limit in ((0.5, 1.0), (0.8, 1.0)):
        alarms, total = noise_alarms(root, sigma)
        check("KPI 2 under natural latency noise (log-normal spread %.1f): at most %.0f false alarm in 1,000 commands" % (sigma, limit), 1000 * alarms / total <= limit, "%d alarms on %d commands" % (alarms, total))
    ten = lambda r, g, cmds, c: [(i, 10) for i in r.sample([x for v in g.values() if len(v) >= 25 for x in v], 6)]                 # noqa: E731
    five = lambda r, g, cmds, c: [(i, 5) for i in r.sample([x for v in g.values() if len(v) >= 25 for x in v], 6)]                 # noqa: E731
    f, i_, o = group_attack(root, ten)
    check("KPI 2 small faults: a command 10 x slower than usual is found", f / i_ >= 0.95 and o == 0, "%d of %d, %d other alarms" % (f, i_, o))
    f5, i5, _o = group_attack(root, five)
    print("      for the record: 5 x slower is found %d of %d" % (f5, i5))
    for share in (0.2, 0.4, 0.6):
        def mask(r, g, cmds, c, share=share):
            v = max(g.values(), key=len)
            return [(i, 50) for i in r.sample(v, max(1, int(len(v) * share)))]
        f, i_, o = group_attack(root, mask)
        check("KPI 2 masking: %d%% of a group slow at once, every one still found" % (100 * share), f / i_ >= 0.95, "%d of %d" % (f, i_))
    hard, total = 0, 0
    fa = 0
    for seed in range(FIRST_SEED, FIRST_SEED + 3):
        for base in BASES:
            uid = "up-hard-%s-%d" % (base[:4].lower(), seed)
            folder = os.path.join(root, "in", uid)
            truth = inject(base, folder, seed + 50)
            renumber_and_shuffle(folder, seed)
            db, _s = load(root, uid, folder)
            rows, _t, _n, _st = findings(db)
            got = {n for _i, _r, n, _k in rows}
            hard += len(set(truth) & got)
            total += len(truth)
            fa += len(got - set(truth))
    check("KPI 2 hard joins: queues sharing command numbers and completions out of order change nothing", hard / total >= 0.95 and fa == 0, "%d of %d, %d false alarms" % (hard, total, fa))
    # a known failure coming back on another firmware: the case a regression suite exists for
    r0 = runs[0]
    fw_uid, fw_folder = "up-fw2", os.path.join(root, "in", runs[0]["uid"])
    db, _s = load(root, fw_uid, fw_folder, firmware="NEWFW-2")
    fw_rows, _t, _n, _st = findings(db)
    fw_hit = fw_miss = 0
    for fid, _rule, n, _kind in fw_rows:
        g = api.get("/api/isolate/%s/%d/graph" % (fw_uid, fid))["graph"]["signature"]
        if g in known:
            continue                 # the same signature: the firmware is not in this recording's key
        ch = isolate(api, fw_uid, fid).get("choice")
        fw_hit += bool(ch and ch.get("from_family") and ch.get("test_path"))
        fw_miss += not (ch and ch.get("from_family") and ch.get("test_path"))
    check("KPI 2 leakage: a known failure on NEW firmware still finds its procedure and regression test", fw_hit > 0 and fw_miss == 0, "%d routed, %d leaked" % (fw_hit, fw_miss))
    # the regression test file is lost
    victim = scripts[0]["path"]
    os.remove(victim)
    sig0 = next(k for k, v in known.items() if v["test"] == victim)
    st_ = api.app.config["services"].hier_store
    states = [p["test_state"] for p in st_.graph_paths(sig0)]
    check("KPI 2 leakage: a deleted regression test is written again from its stored copy", "written again from the stored copy" in states and os.path.exists(victim), states)
    # flaky defects and realistic healthy drives
    caught = 0
    for s in scripts[:10]:
        a = run_script(s["path"], sim, dev, "defective", "fixed", s["fault"], p=0.3, repeat=12)
        caught += a[0] == 1
    n10 = min(10, len(scripts))
    check("KPI 2 leakage: a defect that shows only 3 times in 10 is still caught", caught >= 0.9 * n10, "%d of %d" % (caught, n10))
    false_fail = 0
    for s in scripts:
        c_ = run_script(s["path"], sim, dev, "fixed", "fixed", s["fault"], healthy_us=20, spike=0.02)
        false_fail += c_[0] != 0
    check("KPI 2: a healthy drive with an occasional slow command is not called defective", false_fail <= max(1, len(scripts) // 10), "%d false failures in %d" % (false_fail, len(scripts)))
    late, static, best = learning_curve(root)
    check("Reinforcement: the graph learns: late choices beat always using the first stored procedure", late >= static + 0.2 and best >= 0.7, "admin accepts %.0f%% late (static %.0f%%); best procedure chosen %.0f%%" % (100 * late, 100 * static, 100 * best))

    print("\n-- attacks on the API: each must be refused with a reason, never a crash")
    u0, f0 = runs[0]["uid"], next(x[0] for x in runs[0]["findings"] if runs[0]["truth"].get(x[2]))
    sig0 = api.get("/api/isolate/%s/%d/graph" % (u0, f0))["graph"]["signature"]
    other = api.get("/api/isolate/%s/%d/graph" % (u0, f0))["graph"]["paths"]
    u2, f2 = next((r_["uid"], x[0]) for r_ in runs for x in r_["findings"] if api.get("/api/isolate/%s/%d/graph" % (r_["uid"], x[0]))["graph"]["signature"] != sig0)      # another failure
    def refused(path, body, code=400, reason=True):
        r = api.c.post(path, json=body)
        return r.status_code == code and (not reason or bool((r.get_json(silent=True) or {}).get("error"))), r.status_code
    seq = [{"step": 1, "command": "Write", "position": "above"}]
    tests = {
        "a signal on another failure's procedure": refused("/api/isolate/%s/%d/signal" % (u2, f2), {"signal": "wrong", "procedure_id": (other or [{"procedure_id": 1}])[0]["procedure_id"], "name": "kpi"}),
        "a signal outside the four": refused("/api/isolate/%s/%d/signal" % (u0, f0), {"signal": "maybe", "name": "kpi"}),
        "edits that remove the defect": refused("/api/isolate/%s/%d/signal" % (u2, f2), {"signal": "correct_with_edits", "proposal_steps": seq, "edited_steps": seq, "name": "kpi"}),
        "Correct on an empty proposal": refused("/api/isolate/%s/%d/signal" % (u2, f2), {"signal": "correct", "proposal_steps": [], "name": "kpi"}),
        "a test file from steps without the defect": refused("/api/isolate/%s/%d/testcase" % (u0, f0), {"sequence": seq, "expected_outcomes": [], "verified": True, "name": "kpi"}),
        "a test file not verified by the admin": refused("/api/isolate/%s/%d/testcase" % (u0, f0), {"sequence": seq, "expected_outcomes": [{"step": 1}], "name": "kpi"}),
        "an upload that does not exist": refused("/api/isolate/nope/1/isolate", {}, 404),
        "a path in place of an upload": refused("/api/isolate/..%%2F..%%2Fetc/1/signal", {"signal": "correct"}, 404, reason=False),
        "a defect that does not exist": refused("/api/isolate/%s/999999/isolate" % u0, {}, 404),
    }
    for name, (ok, code) in tests.items():
        check("attack refused: " + name, ok, "HTTP %s" % code)
    out = {"made": time.time(), "seconds": round(time.time() - t_start), "seeds": seeds, "per_kind": PER_KIND, "bases": BASES, "clean": clean, "by_kind": by_kind,
           "kpi2": {"injected": inj, "found": found, "recall": recall, "precision": precision, "kind_accuracy": kind_acc, "false_alarms": fp, "baseline_recall": base_found / inj},
           "kpi1_proxy": {"commands_to_read_cut_min": min(cut), "commands_to_read_cut_median": statistics.median(cut), "note": "rows to read, not engineer hours"},
           "leakage": {"known_failures": len(known), "recurrences": recur, "leaked": len(leaks), "other_new_failures": new_sigs},
           "scripts": {"n": len(scripts), **ran, "problems": bad}, "seconds_per_recording": statistics.median(r["seconds"] for r in runs), "problems": PROBLEMS,
           "limits": "synthetic recordings with injected faults; simulated drive; KPI 1 is a proxy, not engineer hours"}
    json.dump(out, open(os.path.join(keep, "kpi_proof.json"), "w"), indent=1, default=str)
    shutil.rmtree(root, ignore_errors=True)
    print("\n%d checks failed; %d s; evidence in runs/kpi_proof/kpi_proof.json" % (len(PROBLEMS), time.time() - t_start))
    return 1 if PROBLEMS else 0


def _run_clean():
    """Whatever happens to the run (a crash, Ctrl-C, a stop), its temporary folder goes away: a stopped run must not fill the machine."""
    import atexit
    before = set(os.listdir(tempfile.gettempdir()))

    def tidy(*_a):
        for name in set(os.listdir(tempfile.gettempdir())) - before:
            if name.startswith(("fuzz_app_", "fuzz_kpi_", "kpi_proof_")):
                shutil.rmtree(os.path.join(tempfile.gettempdir(), name), ignore_errors=True)
    atexit.register(tidy)
    signal.signal(signal.SIGTERM, lambda *_a: sys.exit(143))
    return main()


if __name__ == "__main__":
    sys.exit(_run_clean())
