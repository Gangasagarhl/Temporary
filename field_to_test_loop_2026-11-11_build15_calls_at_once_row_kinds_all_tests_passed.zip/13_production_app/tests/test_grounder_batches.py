"""The Data Grounder on a real-size export (owner, 2026-11-11: "Data Grounder has stuck ... meanings of columns 1 to 120 of 361 ... 0%").

A file of 361 columns, each with keywords, against a stand-in model server that takes a second per call: the Grounder cuts the
columns into parts of at most 60 meanings (a column and each of its keywords count one), asks as many parts at the same time as the
runner allows (Settings, or worked out from the processor cores), finishes every column, and its progress line moves while the model
works. No real model is called; the stand-in server answers the columns it is given, in the short form the Grounder asks for (a
column by its number, a keyword as a short list) or in the long one (by name, with a "source" object): both are read."""
import json
import os
import shutil
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

N_COLUMNS = 361


class _Model:
    """Answers each Grounder call with a meaning for every column it was given, after a pause; records how many calls ran at once."""

    def __init__(self, pause=1.0, mode="all", shape="short"):
        self.calls, self.now, self.most, self.retries, self.retry_tools, self.contents_seen, self.cols_seen = 0, 0, 0, 0, 0, 0, 0
        self.cut, self.sizes, self.prompts = 0, [], []
        lock = threading.Lock()
        me = self

        class H(BaseHTTPRequestHandler):
            def do_POST(self):
                n = int(self.headers.get("content-length") or 0)
                body = json.loads(self.rfile.read(n) or b"{}")
                with lock:
                    me.calls += 1
                    me.now += 1
                    me.most = max(me.most, me.now)
                try:
                    time.sleep(pause)
                    prompt = body["messages"][0]["content"]
                    retry = "THE WEB COULD NOT BE USED" in prompt
                    with lock:
                        me.retries += retry
                        me.retry_tools += bool(retry and body.get("tools"))
                        me.contents_seen += '"most_common"' in prompt
                    if mode in ("fail", "402"):             # the address refuses every call (400, or 402: no credit on the account)
                        data = b'{"type": "error", "error": {"type": "invalid_request_error", "message": "refused"}}'
                        self.send_response(402 if mode == "402" else 400)
                        self.send_header("content-type", "application/json")
                        self.send_header("content-length", str(len(data)))
                        self.end_headers()
                        self.wfile.write(data)
                        return
                    cols = json.loads(prompt.split("CONTEXT:\n", 1)[1])["columns"]
                    with lock:
                        me.cols_seen += len(cols)
                        me.sizes.append(len(cols))
                        me.prompts.append(prompt)
                    stop = "end_turn"
                    if mode == "cut" and len(cols) > 2:      # an answer for more than 2 columns is longer than one call may write
                        stop = "max_tokens"
                        with lock:
                            me.cut += 1
                    if mode == "half" and not retry:        # the first try answers only every second column
                        cols = cols[::2]
                    if shape == "long":                     # by name, each meaning with a "source" object
                        ans = {"columns": [{"column": c["column"], "meaning": "what %s holds" % c["column"],
                                            "source": {"kind": "model", "ref": "model knowledge", "quote": ""},
                                            "keywords": [{"keyword": k, "meaning": "the value %s" % k, "source": {"kind": "model", "ref": "model knowledge", "quote": ""}}
                                                         for k in c.get("keywords") or []]} for c in cols]}
                    else:                                   # the form asked for: a column by its number, a keyword as a short list
                        ans = {"columns": [{"n": c["n"], "meaning": "what %s holds" % c["column"], "kind": "model",
                                            "keywords": [[k, "the value %s" % k, "model"] for k in c.get("keywords") or []]} for c in cols]}
                    data = json.dumps({"id": "m", "type": "message", "role": "assistant", "model": body.get("model"),
                                       "content": [{"type": "text", "text": json.dumps(ans)[:40] if stop == "max_tokens" else json.dumps(ans)}], "stop_reason": stop,
                                       "usage": {"input_tokens": 1, "output_tokens": 1}}).encode()
                    self.send_response(200)
                    self.send_header("content-type", "application/json")
                    self.send_header("content-length", str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                finally:
                    with lock:
                        me.now -= 1

            def log_message(self, *a):
                pass

        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = "http://127.0.0.1:%d" % self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()


class _Ctx:
    def __init__(self, runner, mem_file):
        self.engine = type("E", (), {"runner": runner})()
        self.project = {"refs": "[]"}
        self.run = {"id": 1}
        self.notes, self._mem = [], mem_file

    def output_of(self, key):
        return {"memory_file": self._mem}

    def progress(self, text):
        self.notes.append((time.time(), text))

    def evidence(self, claims):
        pass


def test_the_grounder_finishes_a_361_column_export_in_small_parts_at_once_and_its_progress_moves():
    from agentic import core, family1
    root = tempfile.mkdtemp(prefix="grounder_%d_" % os.getpid())
    was = {k: os.environ.get(k) for k in ("ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", "ANTHROPIC_AUTH_TOKEN")}
    model = _Model(pause=1.0)
    try:
        os.environ.update(ANTHROPIC_API_KEY="sk-test-grounder-0000", ANTHROPIC_BASE_URL=model.url)
        os.environ.pop("ANTHROPIC_AUTH_TOKEN", None)
        cols = [{"column": "Field %03d" % i, "header_cell": "Field %03d" % i, "type": "text", "rows_with_value": 50,
                 "keywords": [{"value": "K%d_%d" % (i, j), "count": 5} for j in range(25)]} for i in range(N_COLUMNS)]
        mem = os.path.join(root, "explorer.json")
        json.dump({"columns": cols}, open(mem, "w"))
        runner = core.AgentRunner(os.path.join(root, "runs"), runtime="http", http_model="company-model-1", web=False)
        ctx = _Ctx(runner, mem)
        t0 = time.time()
        res = family1._ground(ctx, {"name": "packets.csv", "level_label": "packets"})
        took = time.time() - t0
        out = json.load(open(res.output["memory_file"]))
        at_once = runner.slots.ceiling                                               # automatic: from this computer's processor cores
        per_part = family1.GROUND_MEANINGS // (1 + family1.GROUND_KEYWORDS)           # a column with 15 keywords is 16 meanings: 3 fit in 60
        parts = -(-N_COLUMNS // per_part)
        assert model.calls == parts and max(model.sizes) == per_part                  # 121 parts of 3 columns, none asked twice
        assert 1 < model.most <= at_once                                              # several at once, never more than the limit
        assert at_once >= 4 and res.output["timing"]["calls_at_once_allowed"] == at_once and 1 < res.output["timing"]["calls_at_once_most"] <= at_once
        assert len(out["columns"]) == N_COLUMNS and all(m["meaning"] for m in out["columns"].values())
        assert all(len(m["keywords"]) == family1.GROUND_KEYWORDS for m in out["columns"].values())   # at most 15 keywords asked per column
        assert took < parts * 1.0 / 2                                                 # at least twice as fast as one part after the other
        assert "model calls in %d parts" % parts in res.output["how_long"] and "at the same time" in res.output["how_long"]
        texts = [t for _w, t in ctx.notes]
        assert texts[0].startswith("0% · Data Grounder") and texts[-1].startswith("100% · Data Grounder")
        assert len({t.split(" · ")[0] for t in texts}) >= 3                           # the percentage moved on the way
        assert "%d of %d columns done" % (N_COLUMNS, N_COLUMNS) in texts[-1]
    finally:
        model.srv.shutdown()
        for k, v in was.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        shutil.rmtree(root, ignore_errors=True)


def _cols(n):
    return [{"column": "Field %03d" % i, "header_cell": "Field %03d" % i, "type": "text", "rows_with_value": 50, "observed": "holds a code",
             "top_values": [{"value": "V%d_%d" % (i, j), "count": 10 - j} for j in range(6)], "min": "V%d_0" % i, "max": "V%d_5" % i,
             "keywords": [{"value": "K%d_%d" % (i, j), "count": 5} for j in range(5)]} for i in range(n)]


def _run(mode, n=45, pause=0.2, dictionary=None, expect_error=False, shape="short", cols=None, mem_more=None):
    from agentic import core, family1
    root = tempfile.mkdtemp(prefix="grounder_%s_%d_" % (mode, os.getpid()))
    was = {k: os.environ.get(k) for k in ("ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", "ANTHROPIC_AUTH_TOKEN")}
    was_kd = family1.knowledge_dir
    family1.knowledge_dir = lambda: os.path.join(root, "knowledge")          # its own knowledge folder: approved dictionaries of this test only
    if dictionary:
        d = os.path.join(root, "knowledge", "dictionaries", "fmt1")
        os.makedirs(d)
        json.dump(dictionary, open(os.path.join(d, "packets.current.json"), "w"))
    model = _Model(pause=pause, mode=mode, shape=shape)
    try:
        os.environ.update(ANTHROPIC_API_KEY="sk-test-grounder-0000", ANTHROPIC_BASE_URL=model.url)
        os.environ.pop("ANTHROPIC_AUTH_TOKEN", None)
        mem = os.path.join(root, "explorer.json")
        json.dump(dict({"columns": cols or _cols(n)}, **(mem_more or {})), open(mem, "w"))
        runner = core.AgentRunner(os.path.join(root, "runs"), runtime="http", http_model="company-model-1", web=True)
        ctx = _Ctx(runner, mem)
        if expect_error:
            t0 = time.time()
            try:
                family1._ground(ctx, {"name": "packets.csv", "level": "packets", "level_label": "packets"})
            except RuntimeError as e:
                return model, str(e), time.time() - t0, ctx
            raise AssertionError("the step did not stop")
        res = family1._ground(ctx, {"name": "packets.csv", "level": "packets", "level_label": "packets"})
        return model, res, json.load(open(res.output["memory_file"])), ctx
    finally:
        family1.knowledge_dir = was_kd
        model.srv.shutdown()
        for k, v in was.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        shutil.rmtree(root, ignore_errors=True)


def test_columns_left_without_a_meaning_are_asked_again_without_the_web_from_their_name_and_contents():
    """Owner, 2026-11-11: "add a retry if the Data Grounder fails, and if the web cannot give it, use the column names and contents"."""
    model, res, out, ctx = _run("half")
    assert model.contents_seen >= 1                                       # the contents went with the columns
    assert model.retries >= 1 and model.retry_tools == 0                  # retried, and the retry did not use the web
    assert len(out["columns"]) == 45 and all(m["meaning"] and not m["meaning"].startswith("Described from") for m in out["columns"].values())
    assert "retry without the web" in res.producer
    assert any("retried without the web" in t for _w, t in ctx.notes)


def test_when_the_model_gives_nothing_no_meaning_is_written_by_code():
    """Owner, 2026-11-11: "it should not be written": after the three tries, a column without a source keeps no meaning (the admin
    fills it in the review); nothing is made up by code."""
    from agentic import family1
    model, res, out, ctx = _run("fail", n=12)
    assert model.retries >= 2                                             # retried without the web, then in halves
    assert len(out["columns"]) == 0                                       # no meaning was written for any column
    assert family1._status(None) == "no meaning found"
    assert "12 columns without a meaning after 3 tries" in res.producer
    assert res.output["meanings"] == {}


def test_a_meaning_from_the_web_keeps_its_page_and_words():
    """Owner, 2026-11-11: "if it is taken from the web, mention that it is from the web and store the meaning ... save from which
    place it came": the stored meaning keeps kind web, the page and the quoted words, and says so in words."""
    from agentic import family1
    m = {"meaning": "the transaction's sequence number", "checked": True,
         "source": {"kind": "web", "ref": "https://example.org/pcie/dllp", "quote": "a 12-bit sequence number"}}
    assert family1._status(m) == "from a web page (checked)"
    m["checked"] = False
    assert family1._status(m) == "web quote not found on the page: not trusted"


def test_columns_already_in_an_approved_dictionary_are_taken_from_it_and_only_the_others_are_asked():
    """Owner, 2026-11-11: "if it already has the column names, just use the description of the column, else go for finding"."""
    from agentic import family1
    known = {"level": "packets", "file": "packets.csv", "approved_by": "Sagar", "approved_at": 1794390000,
             "columns": [{"column": "Field %03d" % i, "meaning": "approved meaning %d" % i, "source": {"kind": "document", "ref": "manual.pdf:12", "quote": "q"},
                          "keywords": [{"value": "K%d_0" % i, "meaning": "approved keyword", "source": {"kind": "model", "ref": "model knowledge", "quote": ""}}]}
                         for i in range(5)] + [{"column": "Field 011", "meaning": "", "source": {}}]}       # an empty meaning is not reused
    model, res, out, ctx = _run("all", n=12, dictionary=known)
    assert model.cols_seen == 7                                            # only the 7 columns without an approved meaning were asked
    assert len(out["columns"]) == 12
    first = out["columns"]["Field 000"]
    assert first["meaning"] == "approved meaning 0" and first["source"]["ref"] == "manual.pdf:12" and first["keywords"]["K0_0"]["meaning"] == "approved keyword"
    assert family1._status(first).startswith("from the approved dictionary of packets.csv (approved by Sagar, ")
    assert "5 meanings reused from the approved dictionary" in res.producer
    assert any("5 taken from the approved dictionary" in t for _w, t in ctx.notes)


def test_a_refused_connection_stops_the_step_at_once_with_the_reason():
    """No credit (HTTP 402): the Grounder stops asking at once (no retries for every part) and the step fails with the reason in words."""
    model, err, took, ctx = _run("402", n=45, expect_error=True)
    assert "no credit" in err and "Settings -> Model connection" in err
    assert model.retries == 0 and model.calls <= 9                         # the first try of each of the 9 parts at most: no retries after a refusal
    assert took < 20
    assert any("last problem: part" in t and "no credit" in t for _w, t in ctx.notes)


def test_the_status_says_which_part_waits_how_long_and_why():
    from agentic import family1
    was = family1.GROUND_SLOW_AFTER
    family1.GROUND_SLOW_AFTER = 0.5
    try:
        model, res, out, ctx = _run("all", n=20, pause=12.5)               # four parts asked together, and the model takes 12.5 s
    finally:
        family1.GROUND_SLOW_AFTER = was
    texts = [t for _w, t in ctx.notes]
    slow = [t for t in texts if "has waited" in t]
    assert slow and "part 1 has waited" in slow[0] and "first try" in slow[0] and "a call gives up after" in slow[0], texts
    assert all(" · Data Grounder · packets.csv: " in t for t in texts)


def test_an_answer_in_the_long_form_by_column_name_is_read_too():
    """A model (or a gateway's model) that answers by name with "source" objects, as before the short form, is understood as well."""
    model, res, out, ctx = _run("all", n=12, shape="long")
    assert len(out["columns"]) == 12 and all(m["meaning"] and len(m["keywords"]) == 5 for m in out["columns"].values())
    assert out["columns"]["Field 003"]["keywords"]["K3_2"]["meaning"] == "the value K3_2"


def test_the_short_form_is_read_and_what_the_code_knows_is_filled_in_by_the_code():
    from agentic import family1
    batch = [{"column": "Mem.Address", "keywords": ["MWr(64)", "MRd(32)"]}, {"column": "OPC", "keywords": ["Read", "Write"]}, {"column": "PSN", "keywords": []}]
    ans = {"columns": [
        {"n": 2, "meaning": "the command's opcode", "kind": "data", "quote": "Read",
         "keywords": [["read", "a Read command", "data"], ["Write", "a Write command", "web", "https://nvmexpress.org/x", "Write command"],
                      ["Flush", "not one of this column's keywords", "model"], ["Write", "a second answer for the same keyword", "model"]]},
        {"n": 1, "meaning": "the address of the memory request", "kind": "document", "ref": "spec.md:12", "quote": "Address"},
        {"n": 2, "meaning": "a second answer for the same column", "kind": "model"},
        {"n": 3, "meaning": "", "kind": "model"},                                   # an empty meaning is no meaning
        {"n": 9, "meaning": "a column that was not asked", "kind": "model"},
        {"column": " psn ", "meaning": "the packet's sequence number", "kind": "something else"},      # by name, without regard to capitals and spaces
        "not an object"]}
    got = family1._read_answers(ans, batch)
    assert set(got) == {"Mem.Address", "OPC", "PSN"}
    assert got["OPC"]["meaning"] == "the command's opcode" and got["OPC"]["source"] == {"kind": "data", "ref": "OPC", "quote": "Read"}
    kws = {k["keyword"]: k for k in got["OPC"]["keywords"]}
    assert set(kws) == {"Read", "Write"}                                            # the keyword as the file writes it; unknown ones dropped
    assert kws["Read"]["source"] == {"kind": "data", "ref": "OPC", "quote": "Read"}  # data: the column itself, the keyword is its own value
    assert kws["Write"]["meaning"] == "a Write command" and kws["Write"]["source"] == {"kind": "web", "ref": "https://nvmexpress.org/x", "quote": "Write command"}
    assert got["Mem.Address"]["source"] == {"kind": "document", "ref": "spec.md:12", "quote": "Address"}
    assert got["PSN"]["source"] == {"kind": "model", "ref": "model knowledge", "quote": ""}     # an unknown kind is model knowledge
    assert family1._read_answers({"columns": "no list"}, batch) == {} and family1._read_answers("no object", batch) == {}


def test_the_parts_follow_the_calls_at_once_and_never_hold_more_than_60_meanings():
    from agentic import family1
    def items(n, k, group=""):
        return [{"column": "c%d" % i, "keywords": ["k"] * k, "group": group} for i in range(n)]
    # a small file: one round of calls finishes it (as many parts as calls at once), but a part is not made smaller than 30 meanings
    parts, per = family1.ground_parts(items(40, 5), 4)             # 240 meanings, 4 calls at once -> 60 each
    assert per == 60 and [len(p) for p in parts] == [10, 10, 10, 10]
    parts, per = family1.ground_parts(items(40, 5), 16)            # 16 calls at once -> 15 each would be too small: 30
    assert per == 30 and [len(p) for p in parts] == [5] * 8
    # a big file: never more than 60 meanings in one answer, never more than 20 columns in one call
    parts, per = family1.ground_parts(items(361, 15), 16)
    assert per == 60 and max(len(p) for p in parts) == 3 and sum(len(p) for p in parts) == 361
    parts, per = family1.ground_parts(items(100, 0), 1)
    assert max(len(p) for p in parts) == family1.GROUND_BATCH and sum(len(p) for p in parts) == 100
    # one column with more keywords than a part holds is still asked, alone
    parts, per = family1.ground_parts(items(1, 15) + items(2, 15), 16)
    assert [len(p) for p in parts] == [1, 1, 1] or [len(p) for p in parts] == [1, 2]
    # columns that the same kinds of row fill stay together: a new part where the kind changes, once the part is half full
    mixed = items(6, 4, "Read, Write") + items(6, 4, "Identify")
    parts, per = family1.ground_parts(mixed, 2)                    # 60 meanings, 2 calls at once -> 30 each
    assert [[it["group"] for it in p] for p in parts] == [["Read, Write"] * 6, ["Identify"] * 6]
    assert family1.ground_parts([], 8) == ([], 30)


def test_an_answer_that_was_cut_off_is_asked_again_in_two_halves_and_not_the_same_way():
    """Before: an answer longer than one call may write came back as "not JSON" and the same question was asked again."""
    model, res, out, ctx = _run("cut", n=8)                                # 8 columns of 6 meanings -> parts of 5 and 3; both are cut off
    assert model.cut >= 2                                                  # both first answers were too long
    assert len(out["columns"]) == 8 and all(m["meaning"] for m in out["columns"].values())
    assert "asked in two halves: the first answer was cut off" in res.producer
    assert any("last problem: part" in t and "longer than one call may write" in t for _w, t in ctx.notes)


def test_which_rows_fill_a_column_goes_to_the_model_and_the_columns_of_one_kind_are_asked_together():
    """Owner, 2026-11-11: "a Read command fills only the columns it needs ... that special status is also needed when extracting"."""
    cols = _cols(12)
    for i, c in enumerate(cols):
        if i % 2:           # every second column is a field of Read and Write commands only
            c["filled_for"] = {"text": "filled only on rows where OPC is Read (360 of 360 rows), Write (179 of 179 rows); never on the other 69 rows", "rows": "OPC: Read, Write"}
        elif i % 4 == 0:
            c["filled_for"] = {"text": "filled only on rows where OPC is Identify (15 of 15 rows); never on the other 593 rows", "rows": "OPC: Identify"}
    model, res, out, ctx = _run("all", cols=cols, mem_more={"kind_of_row": {"text": "The kind of each row is named by OPC: Read (360 rows), Write (179 rows)."}})
    assert len(out["columns"]) == 12
    asked = [json.loads(p.split("CONTEXT:\n", 1)[1]) for p in model.prompts]
    assert all(a["kind_of_row"].startswith("The kind of each row is named by OPC") for a in asked)
    seen = {c["column"]: c for a in asked for c in a["columns"]}
    assert seen["Field 001"]["filled_on"].startswith("filled only on rows where OPC is Read (360 of 360 rows)")
    assert "filled_on" not in seen["Field 002"] and "group" not in seen["Field 001"]      # nothing empty is sent, and no key of the program's own
    assert all(c["n"] == i + 1 for a in asked for i, c in enumerate(a["columns"]))        # numbered from 1 inside each call
    kinds = [[("Read" if "Read" in c.get("filled_on", "") else "Identify" if "Identify" in c.get("filled_on", "") else "") for c in a["columns"]] for a in asked]
    assert any(k == ["Read"] * 5 for k in kinds), kinds                    # a whole part of columns that Read and Write fill
