"""The whole pipeline as ONE flow, end to end, against the running server: Family 1 -> Family 2 -> Family 3 (rules,
stage 1 isolation, the four signals, stage 2 expected outcomes, the test file, the summary) -> the report.

    python3 tests/test_flow.py [--base http://127.0.0.1:8077] [--real] [--folder <five CSVs>] [--keep]

The test plays the admin: it starts the flow on a copy of a five-file recording and decides every review the way an
admin would, including the "change" paths (a strategy questioned, a rule changed after its result, a stage 1 proposal
judged wrong and retried with a hint, edited expected outcomes). Then a SECOND flow on the same project checks the
"next time" path: the approved dictionaries and strategy are offered and reused, the tree is not built again, the
approved rules proceed without a new conversation and give the same results.

Without --real every agent answers through the stand-in (deterministic). With --real the agents run on Claude Code
headless (the key and model of ~/.claude/settings.json) and stage 1 / stage 2 on the application's model connection.

Nothing the admin owns is changed: the approved knowledge (dictionaries, strategies, rules, generated code, exports)
is set aside during the test and put back; the isolation memory (db/hier_knowledge.sqlite) is copied first and put
back; the projects, runs, uploads and test files the test made are removed (unless --keep).
"""
import json
import os
import shutil
import sqlite3
import sys
import time
import urllib.error
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
ARGS = sys.argv[1:]
BASE = ARGS[ARGS.index("--base") + 1] if "--base" in ARGS else "http://127.0.0.1:8077"
REAL = "--real" in ARGS
KEEP = "--keep" in ARGS
SRC = ARGS[ARGS.index("--folder") + 1] if "--folder" in ARGS else os.path.join(ROOT, "samples", "five_level", "S17")
FIVE = ["packets.csv", "link.csv", "split.csv", "NVME_Transactions.csv", "nvme_command.csv"]
FOLDER = os.path.join(ROOT, "uploads", "_flow_test_five_files")
KNOW = os.path.join(ROOT, "knowledge")
KEPT = os.path.join(ROOT, "runs", "_flow_test_kept_knowledge")
HK = os.path.join(ROOT, "db", "hier_knowledge.sqlite")
SUITE = os.path.join(ROOT, "suite", "hier")
ADMIN = "flow-test"
R = {"pass": 0, "fail": 0}
MADE = {"projects": [], "uploads": set(), "runs": []}
T0 = time.time()


def check(name, ok, detail=""):
    R["pass" if ok else "fail"] += 1
    print("%s  %s%s" % ("PASS" if ok else "FAIL", name, ("  | " + str(detail)[:300]) if detail != "" else ""), flush=True)
    return ok


class ApiError(Exception):
    def __init__(self, code, body):
        super().__init__("HTTP %s: %s" % (code, body))
        self.code, self.body = code, body


def api(method, path, body=None, timeout=300):
    req = urllib.request.Request(BASE + path, data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Content-Type": "application/json"}, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            return json.loads(raw) if raw[:1] in (b"{", b"[") else raw
    except urllib.error.HTTPError as e:
        raw = e.read().decode(errors="replace")
        try:
            raw = json.loads(raw)
        except ValueError:
            pass
        raise ApiError(e.code, raw)


def view(rid):
    return api("GET", "/api/agents/runs/%d" % rid)


def step(v, key):
    return next((s for s in v["steps"] if s["key"] == key), None)


def steps_like(v, part):
    return [s for s in v["steps"] if part in s["key"]]


def progress_line(v, label):
    done = sum(1 for s in v["steps"] if s["state"] in ("done", "approved", "skipped"))
    cur = next((s for s in v["steps"] if s["state"] not in ("done", "approved", "skipped")), None)
    print("      [%4.0f s] %s: %d of %d steps finished%s" % (time.time() - T0, label, done, len(v["steps"]),
                                                          (" · now: %s (%s)" % (cur["title"][:90], cur["state"])) if cur else ""), flush=True)


def drive(rid, policy, label, timeout=7200):
    """Plays the admin until the run ends: every open review is decided by policy(v, step, review, n) where n counts the
    reviews already seen at that step. Returns the final view and the list of decisions made."""
    seen, decisions, last_print = {}, [], 0
    t0 = time.time()
    while time.time() - t0 < timeout:
        v = view(rid)
        if time.time() - last_print > 30:
            progress_line(v, label)
            last_print = time.time()
        failed = [s for s in v["steps"] if s["state"] == "failed"]
        if failed:
            print("      step failed: %s\n%s" % (failed[0]["title"], (failed[0]["error"] or "")[:1500]))
            return v, decisions
        if v["run"]["state"] != "running":
            return v, decisions
        rv = next((r for r in v["reviews"] if r["state"] == "open"), None)
        if rv is None:
            time.sleep(1.5)
            continue
        st = next(s for s in v["steps"] if s["id"] == rv["step"])
        n = seen.get(st["key"], 0)
        seen[st["key"]] = n + 1
        dec, comment, edits = policy(v, st, rv, n)
        edits = _ticked(rv, dec, edits)
        decisions.append((st["key"], dec, comment, edits))
        print("      [%4.0f s] review '%s' -> %s%s" % (time.time() - T0, rv["title"][:70], dec, (" (%s)" % (edits.get("signal") if isinstance(edits, dict) and edits.get("signal") else comment[:60])) if (comment or edits) else ""), flush=True)
        try:
            api("POST", "/api/agents/reviews/%d/decide" % rv["id"], {"decision": dec, "admin": ADMIN, "comment": comment, "edits": edits})
        except ApiError as e:
            # an approval the application refuses (for example a rule whose plan cannot become code): the admin asks
            # for a change with the reason, as on the page
            if dec != "approve" or e.code != 400:
                raise
            why = e.body.get("error") if isinstance(e.body, dict) else str(e.body)
            print("      [%4.0f s]   the approval was refused (%s): asking for a change instead" % (time.time() - T0, why[:120]), flush=True)
            decisions.append((st["key"], "change", why, None))
            api("POST", "/api/agents/reviews/%d/decide" % rv["id"], {"decision": "change", "admin": ADMIN,
                                                                      "comment": "This cannot be approved: %s. Correct it." % why, "edits": None})
    print("      (timed out)")
    return view(rid), decisions


# ---------------------------------------------------------------------------------------------- the admin's decisions
NEW_ITEM = {"section": "analytics", "level": "nvme_transaction", "name": "NVMe transaction types (flow test)",
            "description": "the percentage by type of all NVMe transactions"}


def _ticked(rv, decision, edits):
    """The admin in the test ticks every rule the page asks about (a strategy is refused otherwise)."""
    d = rv.get("data") or {}
    if decision == "approve" and d.get("joins") and edits is None:
        return {"verified": list((d.get("needs_check") or {}).keys())}
    return edits


def policy_first(v, st, rv, n):
    key, d = st["key"], rv.get("data") or {}
    if key.startswith("manager:") and key.endswith("nvme_command.csv"):
        return "approve", "", {"SQID": "the submission queue the command was placed on (given by the admin in the flow test)"}
    if key == "coder" and n == 0:
        return "change", "Say which columns keep a resent TLP under the same link transaction after a Nak.", None
    if key == "f3_plan":
        chosen = [i["key"] for i in d["items"] if i["key"] in ("analytics/nvme_command/command_type_share", "analytics/nvme_command/read_pattern",
                                                              "errors/nvme_command/cmd_timeout")]
        return "approve", "", {"selected": chosen, "new": [NEW_ITEM]}
    if key.endswith(":result") and "nvme_transaction_types" in key and n == 0 and "#" not in key:
        return "change", "percentage by dir instead (which way the transactions go)", None
    if key == "errors_done" and n == 0:
        work_error(v, 1)            # one error on its own page before the report (owner, 2026-11-11)
    return "approve", "", None


ERR = {}            # what each flow did on an error's own page
DEFECT = "Command never completed within the host limit (flow test)"


def work_error(v, round_):
    """One error on its own page (/isolate), through the page's routes, as the admin works there: stage 1 (isolate, name the defect),
    stage 2 (the cause; the first solution, or the stored one judged), the test (proposed, checked, written, approved)."""
    es = next(s for s in v["steps"] if s["key"] == "f3:errors/nvme_command/cmd_timeout:errors")
    o = es["output"]
    e = o["errors"][1 if round_ == 1 and len(o["errors"]) > 1 else 0]
    up, fid = o["upload_id"], e["finding"]
    base = "/api/isolate/%s/%d/" % (up, fid)
    iso = api("POST", base + "isolate", {"n": 15, "m": 15, "levels": ["nvme_transaction", "split", "link", "packets"], "history": True, "anyway": True,
                                         "isolation": True, "name": ADMIN})
    i = iso["isolation"]
    known = api("GET", "/api/dg/defects?rule=" + i["rule"])["defects"]
    rec = {"upload": up, "finding": fid, "isolation": i, "known": [k["name"] for k in known]}
    if round_ == 1:
        did = api("POST", "/api/dg/defects", {"name": DEFECT, "rule": i["rule"], "level": i["level"], "what": i["what"], "admin": ADMIN})["id"]
        api("POST", "/api/dg/occurrences", {"defect_id": did, "cause_id": None, "upload_id": up, "finding_id": fid, "device": i.get("device"), "admin": ADMIN})
        cz = api("POST", "/api/dg/causes", {"defect_id": did, "side": "host", "header": "host timer shorter than the drive's answer (flow test)", "admin": ADMIN})["id"]
        api("POST", "/api/dg/occurrences", {"defect_id": did, "cause_id": cz, "upload_id": up, "finding_id": fid, "device": i.get("device"), "admin": ADMIN})
        prop = api("POST", "/api/dg/optimized", {"upload_id": up, "finding_id": fid, "isolation": {"what": i["what"]}, "cause": {"side": "host", "header": "x"},
                                                 "error_seq": iso["sequence"]})
        sol = api("POST", "/api/dg/solutions", {"cause_id": cz, "error_seq": iso["sequence"], "optimized": prop["lines"] or ["raise the host's I/O timeout"],
                                                "admin": ADMIN, "upload_id": up, "finding_id": fid})
        ex = api("POST", base + "testcase", {"sequence": iso["sequence"], "expected_after": 3, "name": ADMIN})
        outs = [dict(x, verified=True) for x in ex["expected_outcomes"]]
        outs[0]["check"] = outs[0]["check"] + " (checked by the flow test)"
        f = api("POST", base + "testcase", {"sequence": ex["sequence"], "expected_outcomes": outs, "verified": True, "name": ADMIN})
        api("POST", base + "testcase/approve", {"path": f["path"], "name": ADMIN, "revision_id": sol["revision_id"]})
        rec.update(test=f["path"], two_sided=(f.get("two_sided") or {}).get("ok"))
    else:
        did = next(k["id"] for k in known if k["name"] == DEFECT)
        cause = api("GET", "/api/dg/defects/%d" % did)["causes"][0]
        occ = api("POST", "/api/dg/occurrences", {"defect_id": did, "cause_id": cause["id"], "upload_id": up, "finding_id": fid, "device": i.get("device"), "admin": ADMIN})["id"]
        sid = cause["solutions"][0]["id"]
        r1 = api("POST", "/api/dg/solutions/%d/verdict" % sid, {"signal": "wrong", "admin": ADMIN, "occurrence_id": occ})
        r2 = api("POST", "/api/dg/solutions/%d/verdict" % sid, {"signal": "correct_with_edits", "admin": ADMIN, "occurrence_id": occ,
                                                               "optimized": ["raise the host's I/O timeout above the drive's slowest answer (edited by the flow test)"]})
        rec.update(did1=r1["did"], version=r2["solution"]["version"], judged=r2["solution"]["judged_words"],
                   chosen=api("GET", "/api/dg/defects/%d" % did)["causes"][0]["chosen_words"])
    rec["status"] = api("GET", "/api/dg/status?upload=%s&findings=%d" % (up, fid))["status"][str(fid)]
    ERR[round_] = rec


def policy_second(v, st, rv, n):
    if st["key"] == "errors_done" and n == 0:
        work_error(v, 2)            # the same defect on another error: its stored cause and solution are shown and judged
    return "approve", "", None


# ---------------------------------------------------------------------------------------------- the checks
def order_checks(v, label):
    fam_idx = {}
    for s in v["steps"]:
        fam_idx.setdefault(s["family"], []).append(s["idx"])
    ok = max(fam_idx["1"]) < min(fam_idx["2"]) and max(fam_idx["2"]) < min(fam_idx["3"]) and max(fam_idx["3"]) < min(fam_idx["R"])
    check("%s: one flow, in order: every Family 1 step, then every Family 2 step, then Family 3, then the report" % label, ok,
          {k: (min(x), max(x)) for k, x in fam_idx.items()})
    bad = [s["title"] for s in v["steps"] if s["state"] not in ("done", "approved", "skipped")]
    check("%s: the run finished and every step is done, approved or skipped" % label, v["run"]["state"] == "finished" and not bad, bad[:3] or v["run"]["summary"])


def first_flow(p):
    print("\n-- 1. the first flow on a new recording (nothing approved before)")
    try:
        api("POST", "/api/agents/projects/%d/flow" % p["id"], {})
        check("a flow is not started without the name of the one who starts it", False)
    except ApiError as e:
        check("a flow is not started without the name of the one who starts it", e.code == 400 and "who is starting" in str(e.body), e.body)
    r = api("POST", "/api/agents/projects/%d/flow" % p["id"], {"admin": ADMIN})
    rid = r["run"]
    MADE["runs"].append(rid)
    check("the run records who started it", (r["view"]["run"]["params"] or {}).get("started_by") == ADMIN, r["view"]["run"]["params"])
    try:
        api("POST", "/api/agents/projects/%d/flow" % p["id"], {"admin": ADMIN})
        check("a second flow cannot start while this project's flow runs", False)
    except ApiError as e:
        check("a second flow cannot start while this project's flow runs", e.code == 409, e.body)
    keys = [s["key"] for s in r["view"]["steps"]]
    check("the flow is planned as one run: Director, dictionaries, Family 2's nine steps, Family 3's plan, the report",
          keys[0] == "director" and keys[1] == "f1_last" and "manager:nvme_command.csv" in keys and "independent" in keys and keys[-2:] == ["f3_plan", "report"], keys)
    v, dec = drive(rid, policy_first, "first flow")
    order_checks(v, "first flow")
    if v["run"]["state"] == "running":       # it stopped on a failed step: stop it, so the next flow can start
        api("POST", "/api/agents/runs/%d/stop" % rid, {"admin": ADMIN})
    p = api("GET", "/api/agents/projects/%d" % p["id"])
    up = p.get("upload_id")
    if up:
        MADE["uploads"].add(up)

    # Family 1
    print("\n-- 2. Family 1 · data experts")
    check("the Director found the five files", len((step(v, "director")["output"] or {}).get("files") or []) == 5)
    check("no dictionary was approved before: 'used last time?' was skipped", step(v, "f1_last")["state"] == "skipped", step(v, "f1_last")["note"])
    mans = steps_like(v, "manager:")
    check("one Manager per file, each dictionary approved by the admin", len(mans) == 5 and all(s["state"] == "approved" for s in mans), [s["state"] for s in mans])
    dicts = {}
    for base, _d, files in os.walk(os.path.join(KNOW, "dictionaries")):
        for fn in files:
            if fn.endswith(".current.json"):
                dicts[fn] = json.load(open(os.path.join(base, fn)))
    check("five data dictionaries are stored, approved by the admin", len(dicts) == 5 and all(d.get("approved_by") == ADMIN for d in dicts.values()), sorted(dicts))
    cmd = dicts.get("nvme_command.current.json") or {}
    sq = next((c for c in cmd.get("columns") or [] if c["column"] == "SQID"), {})
    check("the admin's edit of a meaning is kept in the dictionary", sq.get("status") == "given by the admin" and "flow test" in sq.get("meaning", ""), sq)
    ex = steps_like(v, "explore:")
    check("every Data Explorer read every row of its file by code and wrote a summary", all(s["state"] == "done" and (s["output"] or {}).get("rows", 0) > 0 and (s["output"] or {}).get("summary") for s in ex),
          [(s["key"], (s["output"] or {}).get("rows")) for s in ex])

    # Family 2
    print("\n-- 3. Family 2 · hierarchy")
    check("no strategy was approved before: 'used last time?' was skipped", step(v, "last_strategy")["state"] == "skipped")
    rea = step(v, "rea")
    check("the REA findings were asked for on page 2 (not on the start page); the admin continued without them",
          rea["state"] == "approved" and not step(v, "rea_search") and any(k == "rea" for k, _d, _c, _e in dec), rea["state"])
    coder = step(v, "coder")
    check("the admin questioned the strategy once; the Coder answered and the admin approved", coder["state"] == "approved" and coder["attempts"] == 2 and (coder["output"] or {}).get("joins"),
          coder["attempts"])
    fmt = (coder["output"] or {}).get("format")
    sp = os.path.join(KNOW, "strategies", fmt or "-", "v1.json")
    check("the approved strategy is stored as version 1 of this file format", os.path.exists(sp) and json.load(open(sp)).get("approved_by") == ADMIN, sp)
    b = step(v, "build")["output"] or {}
    check("the Builder built the tree on disk", bool(b.get("upload_id")) and not b.get("reused") and os.path.exists(os.path.join(ROOT, "uploads", b.get("upload_id") or "-", "hier.sqlite")), b.get("upload_id"))
    sl, br = step(v, "slice_test")["output"] or {}, step(v, "breaker")["output"] or {}
    check("the Code tester: every random window rebuilt alone matches the full tree and the analyzer's counts", sl.get("of", 0) >= 5 and sl.get("passed") == sl.get("of"), "%s of %s" % (sl.get("passed"), sl.get("of")))
    check("the Breaker: every hard window passes", br.get("of", 0) >= 1 and br.get("passed") == br.get("of"), "%s of %s" % (br.get("passed"), br.get("of")))
    inv = (step(v, "independent")["output"] or {}).get("invariants") or []
    check("the Independent tester: no violation of the column meanings", inv and all(i.get("violations") == 0 for i in inv), [(i["check"][:30], i.get("rows_checked"), i.get("violations")) for i in inv])

    # Family 3
    print("\n-- 4. Family 3 · rules, stage 1 and stage 2")
    plan = step(v, "f3_plan")
    chosen = (plan["output"] or {}).get("chosen") or []
    check("the admin picked three items and added a new one in the plan", len(chosen) == 4 and any("nvme_transaction_types" in c for c in chosen), chosen)
    writes = steps_like(v, ":write")
    check("the item without a procedure went to the Rule writer, and its procedure was approved before its code was made", writes and all(s["state"] == "approved" for s in writes), [(s["key"], s["state"]) for s in writes])
    codes = [s for s in steps_like(v, ":code") if "#" not in s["key"]]
    check("every analytics item's code was written by the Coder and approved by the admin (the detector's item needs none)",
          all(s["state"] == "approved" for s in codes if "/analytics/" in s["key"] or s["key"].startswith("f3:analytics/"))
          and all(s["state"] == "done" for s in codes if s["key"].startswith("f3:errors/")), [(s["key"], s["state"]) for s in codes])
    ct = "f3:analytics/nvme_command/command_type_share:"
    res = step(v, ct + "run")["output"] or {}
    test = step(v, ct + "test")["output"] or {}
    check("command type percentages: run on the tree, every tester check passed", res.get("rows", 0) > 0 and test.get("passed"), [(c["check"][:40], c["ok"]) for c in test.get("checks") or []])
    pct = sum(float(x[2]) for x in res.get("head") or [])
    check("command type percentages add up to 100", abs(pct - 100) < 0.05, pct)
    exp = step(v, ct + "export")["output"] or {}
    check("the result is exported as CSV and HTML", all(os.path.exists(x) for x in (exp.get("files") or {}).values()) and len(exp.get("files") or {}) == 2, exp)
    nt = [s for s in v["steps"] if "nvme_transaction_types" in s["key"]]
    r1 = next((s for s in nt if s["key"].endswith(":result") and "#" not in s["key"]), {})
    r2 = next((s for s in nt if s["key"].endswith(":result") and "#2" in s["key"]), {})
    check("the new item: the admin changed its rule after the first result; a second round ran and was approved",
          r1.get("state") == "skipped" and r2.get("state") == "approved", (r1.get("state"), r2.get("state")))
    rid_new = next((c.split("/")[2] for c in chosen if "nvme_transaction_types" in c), "")
    rule = json.load(open(os.path.join(KNOW, "rules", "analytics", "nvme_transaction", rid_new + ".json"))) if rid_new else {}
    check("the changed procedure is version 2, and version 1 is kept in its history", (rule.get("procedure") or {}).get("version") == 2
          and any((h.get("procedure") or {}).get("version") == 1 for h in rule.get("history") or []), ((rule.get("procedure") or {}).get("version"), len(rule.get("history") or [])))
    if not REAL:
        check("version 2 counts by the column the admin named (dir: the file column Link Dir)",
              ((rule.get("procedure") or {}).get("source_data") or [{}])[0].get("columns") == ["Link Dir"], (rule.get("procedure") or {}).get("source_data"))
    er = "f3:errors/nvme_command/cmd_timeout:"
    eres = step(v, er + "run")["output"] or {}
    con = sqlite3.connect("file:%s?mode=ro" % os.path.join(ROOT, "uploads", up, "hier.sqlite"), uri=True)
    n_inc = con.execute("SELECT COUNT(*) FROM finding WHERE rule='cmd.timeout'").fetchone()[0]
    con.close()
    check("the demo error: every timed-out command is listed", eres.get("rows") == n_inc and n_inc > 0, "%s listed, %s in the tree" % (eres.get("rows"), n_inc))
    es = step(v, er + "errors")
    check("the pattern's errors are listed for the errors page (each goes through stage 1 and stage 2 on its own page)",
          es and es["state"] == "done" and len((es["output"] or {}).get("errors") or []) == min(n_inc, 200), es and len((es["output"] or {}).get("errors") or []))
    check("page 3 asks for no choice of one error and runs no stage inside the flow", not step(v, er + "isolate"))
    e1 = ERR.get(1) or {}
    i = e1.get("isolation") or {}
    check("stage 1 on the error's page: the isolation answers what, why, when, where, who, which and how, and proposes a name",
          all(i.get(k) for k in ("what", "why", "when", "where", "who", "which", "how", "standard_name")), sorted(i))
    check("stage 2 and the test on the error's page: the defect, its cause and its first solution are stored and its test approved",
          (e1.get("status") or {}).get("state") == "tested", e1.get("status"))
    if e1.get("test"):
        MADE.setdefault("tests", []).append(e1["test"])
    check("the test file is written, tried both ways on the simulated drive, approved with the admin's name, and carries the admin's checked line",
          e1.get("test") and e1.get("two_sided") and os.path.exists(e1["test"] + ".approved.json") and "checked by the flow test" in open(e1["test"]).read(), e1.get("test"))

    # report
    print("\n-- 5. the report")
    rep = step(v, "report")["output"] or {}
    fl = rep.get("files") or {}
    ok = fl.get("html") and os.path.exists(fl["html"])
    check("the report of the whole flow is written (HTML and JSON)", ok and os.path.exists(fl.get("json", "")), fl)
    if ok:
        h = open(fl["html"]).read()
        check("the report covers Family 1, Family 2, Family 3, the errors' stage 1 and stage 2, and every step",
              all(x in h for x in ("Family 1", "Family 2", "Family 3", "The errors: stage 1, stage 2 and their tests", "Every step")))
        j = json.load(open(fl["json"]))
        check("the report says where the worked error stands", any(x["state"] == "tested" for x in j.get("errors") or []), [x["state"] for x in j.get("errors") or []][:8])
        check("the report lists every Family 3 item and round", len(j["family3"]) == 5 and all(x.get("rule_version") for x in j["family3"] if x["states"].get("code") != "waiting"), [(x["item"], x["rule_version"]) for x in j["family3"]])
        try:
            raw = api("GET", "/api/agents/file?path=" + urllib.request.quote(fl["html"]))
            check("the report opens from the page", b"Family 3" in raw if isinstance(raw, bytes) else False)
        except ApiError as e:
            check("the report opens from the page", False, e)
    try:
        page = urllib.request.urlopen(BASE + "/hier?upload=" + up).read()
        check("the tree opens from the flow (/hier?upload=...)", b"<html" in page.lower())
    except Exception as e:      # noqa: BLE001
        check("the tree opens from the flow (/hier?upload=...)", False, e)
    return v, up


def _has_col(con, table, col):
    return any(r[1] == col for r in con.execute("PRAGMA table_info(%s)" % table))


def second_flow(p, v1, up1):
    print("\n-- 6. the second flow on the same files (next time: reuse what was approved)")
    again = api("POST", "/api/agents/projects", {"admin": ADMIN, "name": "flow test", "folder": FOLDER})
    check("starting the same analysis again (same folder, same name) opens it instead of making a second one", again["id"] == p["id"] and again.get("reused") is True, (again["id"], again.get("reused")))
    rid = api("POST", "/api/agents/projects/%d/flow" % p["id"], {"admin": "second starter"})["run"]
    MADE["runs"].append(rid)
    v, dec = drive(rid, policy_second, "second flow")
    bodies = [r["body"] for r in v["reviews"]]
    check("the second flow, started by someone else, addresses every review to that person", bodies and all("Admin second starter, need review" in b for b in bodies if "need review" in b),
          [b[:40] for b in bodies[:3]])
    order_checks(v, "second flow")
    f1 = step(v, "f1_last")
    check("Family 1 offered the dictionaries approved last time; the admin proceeded", f1["state"] == "approved")
    check("so no file was read again: every Explorer, Grounder and Manager was skipped",
          all(s["state"] == "skipped" for s in steps_like(v, "explore:") + steps_like(v, "ground:") + steps_like(v, "manager:")))
    check("Family 2 offered the strategy approved last time; the research and the Coder were skipped",
          step(v, "last_strategy")["state"] == "approved" and all(step(v, k)["state"] == "skipped" for k in ("rea", "collect", "coder")))
    b = step(v, "build")["output"] or {}
    check("the tree was not built again: the same upload was reused", b.get("reused") and b.get("upload_id") == up1, b)
    check("the plan's approved rules proceeded without a new conversation (no Rule writer step)", not steps_like(v, ":write"))
    ct = "f3:analytics/nvme_command/command_type_share:"
    a, bb = (step(v1, ct + "run")["output"] or {}).get("head"), (step(v, ct + "run")["output"] or {}).get("head")
    check("'proceed' on an unchanged rule gives the same result as last time", a and a == bb, (a or [])[:3])
    e2 = ERR.get(2) or {}
    check("the next time: the defect is found by its name, with its stored cause and solution", DEFECT in (e2.get("known") or []), e2.get("known"))
    # (2026-11-11) one judgement per error counts, the latest: the Wrong and then the Correct with edits on the same error leave 1 of 1
    check("the admin's Wrong counted against it; Correct with edits on the same error replaced it and made version 2 (the ranking comes from these judgements)",
          (e2.get("did1") or [""])[0].endswith("judged correct 0 of 1 time") and e2.get("version") == 2 and e2.get("judged") == "judged correct 1 of 1 time (1 with edits)",
          (e2.get("did1"), e2.get("version"), e2.get("judged")))
    check("the cause was chosen for both errors", e2.get("chosen") == "chosen as the cause in 2 of 2 occurrences", e2.get("chosen"))
    n1, n2 = len(v1["steps"]), len(v["steps"])
    print("      steps: first flow %d, second flow %d; decisions asked of the admin: %d" % (n1, n2, len(dec)))


def other_name_same_files(up1):
    print("\n-- 6b. a new analysis of the same files under another name")
    p3 = api("POST", "/api/agents/projects", {"admin": ADMIN, "name": "flow test, another name", "folder": FOLDER})
    MADE["projects"].append(p3["id"])
    check("another name makes another analysis", not p3.get("reused"))
    rid = api("POST", "/api/agents/projects/%d/family2" % p3["id"])["run"]
    MADE["runs"].append(rid)
    rv, t0 = None, time.time()
    while time.time() - t0 < 300:
        v = view(rid)
        rv = next((r for r in v["reviews"] if r["state"] == "open"), None)
        if rv and rv["title"].startswith(("Use the tree", "Shall I build")):
            break
        if rv:
            api("POST", "/api/agents/reviews/%d/decide" % rv["id"], {"decision": "approve", "admin": ADMIN, "edits": _ticked(rv, "approve", None)})
        time.sleep(1.5)
    check("the tree built before from these same files is found by itself (the same files on disk), not built again",
          rv and rv["title"].startswith("Use the tree built before") and (rv["data"].get("reuse") or {}).get("upload_id") == up1, (rv or {}).get("title"))
    if rv:
        api("POST", "/api/agents/reviews/%d/decide" % rv["id"], {"decision": "approve", "admin": ADMIN, "edits": _ticked(rv, "approve", None)})
        t0 = time.time()
        while time.time() - t0 < 120 and (step(view(rid), "build") or {}).get("state") != "done":
            time.sleep(1.5)
        b = step(view(rid), "build")["output"] or {}
        check("the build step uses it: same upload, nothing rebuilt", b.get("reused") is True and b.get("upload_id") == up1, b.get("upload_id"))
    api("POST", "/api/agents/runs/%d/stop" % rid, {"admin": ADMIN})


def stop_flow(p):
    print("\n-- 7. a flow can be stopped")
    rid = api("POST", "/api/agents/projects/%d/flow" % p["id"], {"admin": ADMIN})["run"]
    MADE["runs"].append(rid)
    t0 = time.time()
    while time.time() - t0 < 120:
        v = view(rid)
        if any(r["state"] == "open" for r in v["reviews"]):
            break
        time.sleep(1)
    api("POST", "/api/agents/runs/%d/stop" % rid, {"admin": ADMIN})
    v = view(rid)
    check("the stopped flow says who stopped it", v["run"]["state"] == "stopped" and ADMIN in (v["run"]["summary"] or ""), v["run"]["summary"])
    r = api("POST", "/api/agents/projects/%d/flow" % p["id"], {"admin": ADMIN})
    MADE["runs"].append(r["run"])
    check("after a stop, a new flow can start", r.get("run"))
    api("POST", "/api/agents/runs/%d/stop" % r["run"], {"admin": ADMIN})


# ---------------------------------------------------------------------------------------------- set aside and put back
def set_aside():
    shutil.rmtree(KEPT, ignore_errors=True)
    os.makedirs(KEPT)
    for d in ("dictionaries", "strategies", "rules", "rules_code", "exports"):
        if os.path.isdir(os.path.join(KNOW, d)):
            shutil.move(os.path.join(KNOW, d), os.path.join(KEPT, d))
    if os.path.exists(HK):
        src, dst = sqlite3.connect(HK), sqlite3.connect(os.path.join(KEPT, "hier_knowledge.sqlite"))
        src.backup(dst)
        src.close()
        dst.close()
    MADE["suite_before"] = set(os.listdir(SUITE)) if os.path.isdir(SUITE) else set()
    shutil.rmtree(FOLDER, ignore_errors=True)
    os.makedirs(FOLDER)
    src = SRC
    if not all(os.path.exists(os.path.join(src, f)) for f in FIVE):
        # a fresh unzip has no samples: the application's own generator makes scenario S17 (I/O timeout, abort, reset)
        import subprocess
        gen_out = os.path.join(KEPT, "_generated")
        print("      no sample at %s: generating scenario S17 with data/generator/make_five_level_sets.py" % src, flush=True)
        subprocess.run([sys.executable, os.path.join(ROOT, "data", "generator", "make_five_level_sets.py"), "--out", gen_out, "--only", "S17"],
                       check=True, capture_output=True, timeout=1800)
        src = os.path.join(gen_out, "S17")
    for f in FIVE:
        shutil.copy(os.path.join(src, f), FOLDER)


def put_back():
    print("\n-- clean-up")
    s = MADE.get("settings")
    if s:
        api("PUT", "/api/agents/settings", s)
    if KEEP:
        print("      --keep: the projects, runs, uploads, knowledge and test files of this test stay (the admin's own knowledge is in %s)" % KEPT)
        return
    for up in MADE["uploads"]:
        try:
            api("DELETE", "/api/hier/uploads/%s" % up)
        except ApiError:
            pass
    db = os.path.join(ROOT, "db", "agentic.sqlite")
    con = sqlite3.connect(db, timeout=30)
    for pid in MADE["projects"]:
        for (rid,) in con.execute("SELECT id FROM run WHERE project=?", (pid,)).fetchall():
            for t in ("step", "review", "evidence"):
                con.execute("DELETE FROM %s WHERE run=?" % t, (rid,))
            shutil.rmtree(os.path.join(ROOT, "runs", "agentic", "run_%d" % rid), ignore_errors=True)
        con.execute("DELETE FROM chat WHERE review NOT IN (SELECT id FROM review)")
        con.execute("DELETE FROM run WHERE project=?", (pid,))
        con.execute("DELETE FROM project WHERE id=?", (pid,))
    con.commit()
    con.close()
    for d in ("dictionaries", "strategies", "rules", "rules_code", "exports"):
        shutil.rmtree(os.path.join(KNOW, d), ignore_errors=True)
        if os.path.isdir(os.path.join(KEPT, d)):
            shutil.move(os.path.join(KEPT, d), os.path.join(KNOW, d))
    kept_hk = os.path.join(KEPT, "hier_knowledge.sqlite")
    if os.path.exists(kept_hk):
        src, dst = sqlite3.connect(kept_hk), sqlite3.connect(HK, timeout=30)
        src.backup(dst)
        src.close()
        dst.close()
    if os.path.isdir(SUITE):
        for fn in set(os.listdir(SUITE)) - MADE.get("suite_before", set()):
            os.remove(os.path.join(SUITE, fn))
    shutil.rmtree(FOLDER, ignore_errors=True)
    shutil.rmtree(KEPT, ignore_errors=True)
    print("      removed %d project(s) and their runs, %d upload(s), the test files; the admin's knowledge and isolation memory are back" % (
        len(MADE["projects"]), len(MADE["uploads"])))


def main():
    print("the whole flow, end to end: %s, agents on %s" % (BASE, "Claude Code + the model connection" if REAL else "the stand-in"))
    s0 = api("GET", "/api/agents/settings")
    MADE["settings"] = {k: s0.get(k) for k in ("runtime", "model", "slices")}
    set_aside()
    try:
        api("PUT", "/api/agents/settings", {"runtime": "claude-code" if REAL else "standin", "slices": 6})
        if REAL:
            check("Claude Code is found for the agents", bool(api("GET", "/api/agents/settings").get("claude_found")))
        page = urllib.request.urlopen(BASE + "/").read()
        check("the front page is the flow", b"Field-to-Test flow" in page)
        try:
            api("POST", "/api/agents/projects", {"admin": ADMIN, "name": "  ", "folder": FOLDER})
            check("an analysis without a name is refused (the name is how it is recognised later)", False)
        except ApiError as e:
            check("an analysis without a name is refused (the name is how it is recognised later)", e.code == 400 and "name" in str(e.body), e.body)
        p = api("POST", "/api/agents/projects", {"admin": ADMIN, "name": "flow test", "folder": FOLDER})
        MADE["projects"].append(p["id"])
        other = os.path.join(KEPT, "_other_folder")
        os.makedirs(other, exist_ok=True)
        shutil.copy(os.path.join(FOLDER, "nvme_command.csv"), other)
        try:
            api("POST", "/api/agents/projects", {"admin": ADMIN, "name": "Flow  Test", "folder": other})
            check("a name already used for another folder is refused (one name, one folder; case and spaces ignored)", False)
        except ApiError as e:
            check("a name already used for another folder is refused (one name, one folder; case and spaces ignored)", e.code == 409 and FOLDER in str(e.body), e.body)
        v1, up = first_flow(p)
        if up:
            second_flow(p, v1, up)
            other_name_same_files(up)
        stop_flow(p)
    except Exception as e:      # noqa: BLE001 - reported as a failed check
        import traceback
        traceback.print_exc()
        check("the test ran to the end", False, e)
    finally:
        put_back()
    print("\n%d checks, %d failed, %.0f s" % (R["pass"] + R["fail"], R["fail"], time.time() - T0))
    sys.exit(1 if R["fail"] else 0)


if __name__ == "__main__":
    main()
