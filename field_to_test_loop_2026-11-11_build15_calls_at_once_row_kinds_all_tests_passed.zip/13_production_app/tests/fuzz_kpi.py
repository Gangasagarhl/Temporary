#!/usr/bin/env python3
"""Random attacks with a known answer (owner, 2026-11-09: "keep on iterating; find everything so that it will fail; maximum 200").

    python3 tests/fuzz_kpi.py [iterations] [first seed]       default 100 from seed 5000; a seed always rebuilds the same attack

Each iteration builds one hostile recording from a clean one: natural latency noise, known faults of every kind, a missing tail, command
numbers shared between queues, completions out of order, duplicate and orphan completion entries, and files written in unusual ways
(hex numbers, other line ends, a byte order mark, bad bytes, reordered and extra columns, blank lines, a cut last line). The real loader, tree
and rules read it, and the findings are compared with what was written. Each iteration also throws a random history of signals at the
procedural graph and checks what must always hold. A failure prints its seed; it is an application defect until shown otherwise.
"""
import json
import os
import random
import shutil
import signal
import sqlite3
import statistics
import sys
import tempfile
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
sys.path.insert(0, HERE)
from nvme_hier import builder as B, loader as L, rules as RL, store as ST  # noqa: E402
from test_kpi_proof import NAMES, PS, SAMPLES, from_ps, num, read_csv, to_ps, write_csv  # noqa: E402

BASES = ["S27_lcrc_nak_replay", "demo_225_commands", "S08_interrupt_before_completion"]
KIND = {"never_completed": "never completed", "over_limit": "over the host's limit", "slower": "slower than usual", "aborted": "aborted by the host"}


def build(seed):
    """One hostile recording. Returns (ch, cmds, th, trs, column indexes, truth {command number: kind}, must_stay_silent {number}, description)."""
    r = random.Random(seed)
    base = r.choice(BASES)
    d = os.path.join(SAMPLES, base)
    ch, cmds = read_csv(os.path.join(d, NAMES["nvme_command"]))
    th, trs = read_csv(os.path.join(d, NAMES["nvme_transaction"]))
    c = {n: ch.index(n) for n in ("NVMe Cmd", "OPC", "SQID", "CID", "NLB", "ST", "ST.SCT", "ST.SC", "Time Stamp")}
    t = {n: th.index(n) for n in ("Type", "SQID", "CID", "SCT", "SC", "Time Stamp")}
    is_cqe = lambda row: "completion" in row[t["Type"]].lower() and "doorbell" not in row[t["Type"]].lower()   # noqa: E731
    at = lambda i: to_ps(cmds[i][c["Time Stamp"]])                                                               # noqa: E731
    by, entry = {}, {}
    for i in sorted(range(len(cmds)), key=at):
        by.setdefault((cmds[i][c["SQID"]], cmds[i][c["CID"]]), []).append(i)
    for j, row in enumerate(trs):
        if is_cqe(row):
            when = to_ps(row[t["Time Stamp"]])
            cs = [i for i in by.get((row[t["SQID"]], row[t["CID"]]), []) if at(i) <= when]
            if cs and cs[-1] not in entry:
                entry[cs[-1]] = j
    next_cid = [40000]

    def own_cid(i, j):
        """A command that stays outstanding longer keeps a number of its own (a number is unique while its command is outstanding)."""
        new, a, b, key = str(next_cid[0]), at(i), to_ps(trs[j][t["Time Stamp"]]), (cmds[i][c["SQID"]], cmds[i][c["CID"]])
        next_cid[0] += 1
        for row in trs:
            if (row[t["SQID"]], row[t["CID"]]) == key and a <= to_ps(row[t["Time Stamp"]]) <= b:
                row[t["CID"]] = new
        cmds[i][c["CID"]] = new

    sigma = r.choice([0, 0.2, 0.5, 0.8])
    if sigma:
        for i, j in entry.items():
            own_cid(i, j)
            trs[j][t["Time Stamp"]] = from_ps(at(i) + int((to_ps(trs[j][t["Time Stamp"]]) - at(i)) * r.lognormvariate(0, sigma)))
    io = [i for i in entry if cmds[i][c["SQID"]] != "0" and (num(cmds[i][c["ST.SCT"]]) or 0) == 0 and (num(cmds[i][c["ST.SC"]]) or 0) == 0]
    groups = {}
    for i in io:
        groups.setdefault((cmds[i][c["OPC"]], cmds[i][c["NLB"]]), []).append(i)
    r.shuffle(io)
    free = iter(io)
    truth, silent, drop = {}, set(), set()
    has_tail = r.random() < 0.8

    def status(i, sct, sc):
        cmds[i][c["ST"]], cmds[i][c["ST.SCT"]], cmds[i][c["ST.SC"]] = "0x%04X (x)" % ((sct << 8) | sc), str(sct), "0x%02X" % sc
        trs[entry[i]][t["SCT"]], trs[entry[i]][t["SC"]] = str(sct), "0x%02X" % sc

    def number(i):
        return int(cmds[i][c["NVMe Cmd"]])

    for _ in range(r.randint(0, 4)):
        i = next(free, None)
        if i is None:
            break
        drop.add(entry[i])
        cmds[i][c["ST"]] = cmds[i][c["ST.SCT"]] = cmds[i][c["ST.SC"]] = ""
        if has_tail:
            truth[number(i)] = "never_completed"
        else:
            silent.add(number(i))          # still open when the recording ended: not judged
    for _ in range(r.randint(0, 3)):
        i = next(free, None)
        if i is None:
            break
        own_cid(i, entry[i])
        trs[entry[i]][t["Time Stamp"]] = from_ps(at(i) + 31 * PS + r.randint(0, 10 ** 9))
        truth[number(i)] = "over_limit"
    big = [k for k, v in groups.items() if len(v) >= 25]
    for _ in range(r.randint(0, 4) if big else 0):
        k = r.choice(big)
        cands = [x for x in groups[k] if number(x) not in truth and number(x) not in silent and entry[x] not in drop]
        if not cands:
            continue
        i = r.choice(cands)
        healthy = sorted(to_ps(trs[entry[x]][t["Time Stamp"]]) - at(x) for x in groups[k] if entry[x] not in drop)
        mult = {0: 15, 0.2: 20, 0.5: 40, 0.8: 150}[sigma]
        own_cid(i, entry[i])
        trs[entry[i]][t["Time Stamp"]] = from_ps(at(i) + healthy[len(healthy) // 2] * mult)
        truth[number(i)] = "slower"
    for _ in range(r.randint(0, 3)):
        i = next(free, None)
        if i is None or number(i) in truth or number(i) in silent:
            continue
        status(i, 0, r.choice([7, 8]))
        truth[number(i)] = "aborted"
    for _ in range(r.randint(0, 3)):
        i = next(free, None)
        if i is None or number(i) in truth or number(i) in silent:
            continue
        if "read" in cmds[i][c["OPC"]].lower():
            status(i, 2, r.choice([0x81, 0x80, 0x82]))
            truth[number(i)] = "read_failed"
        else:
            status(i, 2, 0x80)               # a failed Write is not a read failure; neither of the two rules is about it
            silent.add(number(i))
    extra = []
    # a duplicate completion entry: the first one counts, nothing else changes
    for _ in range(r.randint(0, 2)):
        i = next(free, None)
        if i is None or number(i) in truth or number(i) in silent:
            continue
        dup = list(trs[entry[i]])
        dup[t["Time Stamp"]] = from_ps(to_ps(dup[t["Time Stamp"]]) + r.randint(10 ** 6, 10 ** 12))
        extra.append(dup)
        silent.add(number(i))
    # a completion entry for a command that was never recorded
    if entry and r.random() < 0.4:
        ghost = list(trs[next(iter(entry.values()))])
        ghost[t["CID"]], ghost[t["SQID"]] = "61000", "3"
        extra.append(ghost)
    last = max(at(i) for i in range(len(cmds)))
    if has_tail:
        tmpl = next((i for i in entry if number(i) not in truth and number(i) not in silent and entry[i] not in drop and cmds[i][c["SQID"]] != "0"), None)
        if tmpl is not None:
            marker = list(cmds[tmpl])
            marker[c["NVMe Cmd"]], marker[c["CID"]], marker[c["Time Stamp"]] = str(max(int(x[c["NVMe Cmd"]]) for x in cmds) + 1), "60001", from_ps(last + 40 * PS)
            cmds.append(marker)
            tail = list(trs[entry[tmpl]])
            tail[t["CID"]], tail[t["SQID"]], tail[t["SCT"]], tail[t["SC"]], tail[t["Time Stamp"]] = "60001", marker[c["SQID"]], "0", "0", from_ps(last + 40 * PS + 50 * 10 ** 6)
            extra.append(tail)
    trs = [row for j, row in enumerate(trs) if j not in drop] + extra
    if r.random() < 0.4:                     # queues share command numbers
        maps = {}
        for row in cmds:
            m = maps.setdefault(row[c["SQID"]], {})
            row[c["CID"]] = str(m.setdefault(row[c["CID"]], len(m)))
        for row in trs:
            if row[t["CID"]] and row[t["SQID"]] in maps and row[t["CID"]] in maps[row[t["SQID"]]]:
                row[t["CID"]] = str(maps[row[t["SQID"]]][row[t["CID"]]])
    trs.sort(key=lambda x: to_ps(x[t["Time Stamp"]]))
    desc = {"seed": seed, "base": base, "noise": sigma, "tail": has_tail, "faults": len(truth), "cmds": len(cmds)}
    return ch, cmds, th, trs, c, t, truth, silent, desc, r


def write_hostile(folder, ch, cmds, th, trs, c, t, r, tail=True):
    """The two files, written in randomly unusual ways that a real export or a copy on another system can produce."""
    os.makedirs(folder, exist_ok=True)
    how = []
    if r.random() < 0.3:
        how.append("hex numbers")
        for head, rows, names in ((ch, cmds, ("SQID", "CID", "NLB")), (th, trs, ("SQID", "CID"))):
            idx = [head.index(n) for n in names]
            for row in rows:
                for i in idx:
                    if row[i].strip().isdigit():
                        row[i] = "0x%X" % int(row[i])
    if r.random() < 0.3:
        how.append("short time stamps")
        for rows, i in ((cmds, c["Time Stamp"]), (trs, t["Time Stamp"])):
            for row in rows:
                row[i] = row[i].rstrip("s").rstrip("0") + "s"
    for name, head, rows in ((NAMES["nvme_command"], ch, cmds), (NAMES["nvme_transaction"], th, trs)):
        p = os.path.join(folder, name)
        h, rs = list(head), [list(x) for x in rows]
        if r.random() < 0.2:
            how.append("extra column in " + name)
            h.append("Added By Another Tool")
            rs = [x + ["note"] for x in rs]
        if r.random() < 0.2:
            how.append("columns reordered in " + name)
            order = list(range(len(h)))
            r.shuffle(order)
            h = [h[i] for i in order]
            rs = [[x[i] if i < len(x) else "" for i in order] for x in rs]
        write_csv(p, h, rs)
        raw = open(p, "rb").read()
        if r.random() < 0.3:
            how.append("windows line ends in " + name)
            raw = raw.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
        if r.random() < 0.15:
            how.append("blank lines in " + name)
            raw = raw.replace(b"\r\n", b"\n").replace(b"\n", b"\n\n")
        if r.random() < 0.3:
            how.append("byte order mark in " + name)
            raw = b"\xef\xbb\xbf" + raw
        if r.random() < 0.15 and name == NAMES["nvme_transaction"] and tail:      # with the tail its completion is the last line; the command file's last line makes the recording run on
            how.append("cut last line of " + name)
            raw = raw.rstrip(b"\r\n")
            raw = raw[:raw.rfind(b"\n") + 1] + raw[raw.rfind(b"\n") + 1:][:12]
        if r.random() < 0.15:
            how.append("bad bytes in " + name)
            lines = raw.split(b"\n")
            k = r.randrange(1, max(2, len(lines) - 1))
            lines[k] = lines[k][:6] + b"\xff\xfe" + lines[k][6:]
            raw = b"\n".join(lines)
        open(p, "wb").write(raw)
    return how


def attack_recording(root, seed):
    ch, cmds, th, trs, c, t, truth, silent, desc, r = build(seed)
    folder = os.path.join(root, "f%d" % seed)
    desc["how"] = write_hostile(folder, ch, cmds, th, trs, c, t, r, desc["tail"])
    db = os.path.join(folder, "h.sqlite")
    L.load_upload(db, {"nvme_command": os.path.join(folder, NAMES["nvme_command"]), "nvme_transaction": os.path.join(folder, NAMES["nvme_transaction"])})
    B.build(db)
    RL.apply(db)
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    got = {}
    for rule, n, detail in con.execute("SELECT rule, row_n, detail FROM finding WHERE rule IN ('cmd.timeout', 'cmd.read_failure')"):
        got[n] = "read_failed" if rule == "cmd.read_failure" else json.loads(detail or "{}").get("kind")
    n_cmd = con.execute("SELECT COUNT(*) FROM cmd").fetchone()[0]
    con.close()
    shutil.rmtree(folder, ignore_errors=True)
    bad = []
    for n, kind in truth.items():
        if n not in got:
            bad.append("missed %s at command %d" % (kind, n))
        elif got[n] != KIND.get(kind, kind):
            bad.append("command %d is %s, not %s" % (n, got[n], kind))
    false = [n for n in got if n not in truth and n not in silent]
    for n in silent:
        if n in got and got[n] != "never completed" or (n in got and desc["tail"] is False):
            false.append(n)
    return desc, bad, len(set(false)), n_cmd


def attack_graph(root, seed):
    """A random history of signals on a few failures; what must always hold afterwards."""
    r = random.Random(seed + 7)
    path = os.path.join(root, "g%d" % seed, "db", "k.sqlite")
    st = ST.Store(path)
    bad = []
    step = lambda k, name, pos="above": {"step": k, "command": name, "position": pos}                                 # noqa: E731
    seqs = lambda: [step(1, r.choice(["Write", "Read", "Flush"])), step(2, r.choice(["Write", "Read"]), "fault")]     # noqa: E731
    sigs = [{"fine": "f%d" % k, "coarse": "c%d" % (k % 2), "display": "d", "fields": {"lvl": "cmd", "err": "e%d" % (k % 2), "cmd": "io.Write", "cause": "self", "alg": "v1"}} for k in range(3)]
    for k, s in enumerate(sigs):
        st.touch_signature(s, "D", upload_id="u", finding_id=k)
    live = {s["fine"]: [] for s in sigs}
    for _ in range(r.randint(10, 60)):
        s = r.choice(sigs)
        kind = r.choice(ST.SIGNALS)
        pid = r.choice(live[s["fine"]]) if live[s["fine"]] and r.random() < 0.7 else None
        try:
            res = st.signal(s["fine"], pid, kind, "x", proposal_steps=seqs(), proposal_text="t", edited_steps=seqs() if "edits" in kind else None, edited_text="e",
                            advice=r.choice([None, "look at the queue depth", ""]))
        except ValueError as e:
            bad.append("a legal signal was refused: %s" % e)
            continue
        new = res.get("new_procedure_id")
        if new:
            if "edits" in kind and pid:
                live[s["fine"]].remove(pid)
            live[s["fine"]].append(new)
    for s in sigs:
        v = st.graph_view(s["fine"])
        for x in v["nodes"] + v["edges"]:
            if not 0 < x["weight"] < 1 or x["a"] + x["b"] > ST.CAP + 1e-6:
                bad.append("a weight left its bounds: %s" % x["id"])
        actives = {p for p in live[s["fine"]]}
        seen = {p["procedure_id"] for p in v["paths"]}
        if seen != actives:
            bad.append("the paths %s are not the active procedures %s" % (sorted(seen), sorted(actives)))
        ch = st.graph_choice(s["fine"])
        if ch is not None and (ch["procedure_id"] not in actives or ch["node_weight"] < 0.5):
            bad.append("the policy chose a procedure it may not choose")
    want = {s["fine"]: st.graph_view(s["fine"]) for s in sigs}
    con = sqlite3.connect(path)
    con.execute("DELETE FROM pnode")
    con.execute("DELETE FROM pedge")
    con.commit()
    con.close()
    again = ST.Store(path)
    for s in sigs:
        got = again.graph_view(s["fine"])
        if sorted(json.dumps(n, sort_keys=True) for n in got["nodes"]) != sorted(json.dumps(n, sort_keys=True) for n in want[s["fine"]]["nodes"]) or \
           sorted(json.dumps(e, sort_keys=True) for e in got["edges"]) != sorted(json.dumps(e, sort_keys=True) for e in want[s["fine"]]["edges"]):
            bad.append("the graph rebuilt from its rows is not the same graph")
    shutil.rmtree(os.path.join(root, "g%d" % seed), ignore_errors=True)
    return bad


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 100
    first = int(sys.argv[2]) if len(sys.argv) > 2 else 5000
    root = tempfile.mkdtemp(prefix="fuzz_kpi_")
    t0 = time.time()
    failures, crashes, faults, cmds, false, by_noise = [], [], 0, 0, 0, {}
    for seed in range(first, first + n):
        try:
            d, bad, fa, nc = attack_recording(root, seed)
            faults += d["faults"]
            cmds += nc
            false += fa
            x = by_noise.setdefault(d["noise"], [0, 0])
            x[0] += fa
            x[1] += nc
            if bad:
                failures.append({"seed": seed, "problems": bad, "desc": d})
                print("FAIL seed %d: %s | %s" % (seed, "; ".join(bad[:3]), json.dumps(d)[:220]))
            if fa and d["noise"] == 0:
                failures.append({"seed": seed, "problems": ["%d false alarms with no noise" % fa], "desc": d})
                print("FAIL seed %d: %d false alarms with no noise | %s" % (seed, fa, json.dumps(d)[:220]))
            g = attack_graph(root, seed)
            if g:
                failures.append({"seed": seed, "problems": g, "desc": "graph"})
                print("FAIL seed %d graph: %s" % (seed, "; ".join(sorted(set(g))[:3])))
        except Exception:      # noqa: BLE001
            tb = traceback.format_exc()
            crashes.append({"seed": seed, "error": tb[-900:]})
            print("CRASH seed %d: %s" % (seed, tb.strip().splitlines()[-1][:200]))
    rate = 1000.0 * false / max(1, cmds)
    summary = {"iterations": n, "first_seed": first, "faults_written": faults, "commands": cmds, "failed": len(failures), "crashed": len(crashes), "false_alarms": false, "false_alarms_per_1000": round(rate, 2),
               "false_alarms_by_noise": {str(k): v for k, v in sorted(by_noise.items())}, "seconds": round(time.time() - t0), "failures": failures[:40], "crashes": crashes[:10]}
    keep = os.path.join(APP, "runs", "kpi_proof")
    os.makedirs(keep, exist_ok=True)
    json.dump(summary, open(os.path.join(keep, "fuzz_%d.json" % first), "w"), indent=1, default=str)
    shutil.rmtree(root, ignore_errors=True)
    print("\n%d iterations: %d failed, %d crashed; %d faults written; %d false alarms on %d commands (%.2f in 1,000); by noise %s; %d s" % (
        n, len(failures), len(crashes), faults, false, cmds, rate, summary["false_alarms_by_noise"], summary["seconds"]))
    return 1 if failures or crashes or rate > 1.0 else 0


def _run_clean():
    """Whatever happens to the run (a crash, Ctrl-C, a stop), its temporary folder goes away: a stopped run must not fill the machine."""
    import atexit
    before = set(os.listdir(tempfile.gettempdir()))

    def tidy(*_a):
        for name in set(os.listdir(tempfile.gettempdir())) - before:
            if name.startswith(("fuzz_app_", "fuzz_kpi_", "kpi_proof_")):
                shutil.rmtree(os.path.join(tempfile.gettempdir(), name), ignore_errors=True)
    atexit.register(tidy)
    signal.signal(signal.SIGTERM, lambda *_a: sys.exit(143))
    return main()


if __name__ == "__main__":
    sys.exit(_run_clean())
