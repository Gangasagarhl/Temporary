"""Reference documents are optional (owner, 2026-11-11, from a production machine: "these reference folders do not exist:
D:\\...\\09_defect_isolation_research\\research_notes" stopped "Start the flow" although the box was empty).

The project's own research notes are a default only when they are next to the application (the code-only zip does not carry them);
a missing default or a missing configured folder never stops a flow; a folder the admin types that does not exist is refused by name."""
import os
import shutil
import sys
import tempfile

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)


def test_an_empty_reference_box_starts_even_when_the_default_folder_is_missing():
    import fuzz_app as F
    from api import agentic_api as A
    if not os.path.isdir(F.BASE):
        pytest.skip("the S08 sample recording is not on this machine (the code-only zip carries no samples)")
    root = tempfile.mkdtemp(prefix="refs_%d_" % os.getpid())
    was = list(A.DEFAULTS["references"])
    try:
        app, c, _k, _r = F.setup(root)
        A.DEFAULTS["references"] = [os.path.join(root, "not_here", "09_defect_isolation_research", "research_notes")]
        with app.app_context():
            assert A.settings(A.svc())["references"] == []                     # a missing default is left out
        r = c.post("/api/agents/projects", json={"admin": "t", "name": "no references", "folder": F.BASE})
        assert r.status_code == 200, r.get_json()
        missing = os.path.join(root, "typed_but_missing")
        r = c.post("/api/agents/projects", json={"admin": "t", "name": "typed reference", "folder": F.BASE, "refs": [missing]})
        assert r.status_code == 400 and missing in r.get_json()["error"]        # what the admin typed is still checked
        r = c.post("/api/agents/projects", json={"admin": "t", "name": "typed and present", "folder": F.BASE, "refs": [root]})
        assert r.status_code == 200, r.get_json()
    finally:
        A.DEFAULTS["references"] = was
        shutil.rmtree(root, ignore_errors=True)
