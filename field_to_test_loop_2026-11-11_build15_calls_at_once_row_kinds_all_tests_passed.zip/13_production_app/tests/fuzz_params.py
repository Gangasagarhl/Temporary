"""Every route of the application, every parameter its own code reads, one hostile value at a time (owner, 2026-11-10: "100 different iterations to make it fail").

tests/fuzz_app.py picks parameter names at random, so a route is rarely sent the one parameter it actually reads. This reads each route's source for the names it
uses and sends each of them each hostile value: first on its own, then with every other parameter of the route set to something sensible, so the request gets past the
first refusal and reaches the code behind it. Runs on a throw-away root (the same one as fuzz_app); no model is called.

    python3 tests/fuzz_params.py [seconds, default 300] [seed, default 1] [part, default 0] [parts, default 1]      several parts at once share the work and cover it all

A route may refuse any of this in words (a 4xx). What it may not do is answer 500 or stay silent for 25 seconds.
One answer above 499 is a refusal in words too and is counted on its own, not as a problem: 503 "the database is busy: try again in a
moment" (app/server.py), given while a background job the attack itself started (a load taken up again, for example) is still writing
the recording's database. Seen once in 37,903 cases with six parts running at once (2026-11-11); tests/attack_round6.py accepts it too.
"""
import collections
import inspect
import json
import os
import random
import re
import shutil
import signal
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fuzz_app as F  # noqa: E402

TOP = ["n", "m", "level", "offset", "limit", "after", "before", "count", "filters", "sort", "parent", "parent_level", "top"]    # read by helpers all list routes share
LEVELS = ["packets", "link", "split", "nvme_transaction", "nvme_command"]
READERS = r"(?:body|args|request\.args|request\.values|request\.form|data|q|b|o|params|payload|edits|d|v)"
HOSTILE = ["abc", "", -1, 2 ** 70, float("inf"), float("nan"), True, None, [], {}, [1, "a", None], {"a": {"b": []}}, "x" * 70000, "\x00", "../../../../etc/passwd", "1e400", "[", {"value": "x", "unit": "ms"}]
ALONE = ["abc", 2 ** 70, [], {}, "\x00"]              # on its own the first refusal usually answers: a few of each kind are enough
NESTED = [{"value": v, "unit": "ms"} for v in ("abc", float("inf"), float("nan"), -1, 0, [], {})] + [{"value": 1, "unit": u} for u in ([], {}, 7, "parsecs")] + [
    {"value": 1, "unit": "ms", "source": s} for s in (7, [], {})] + ["default", 7, [], "x"]
SENSIBLE_NUMBER = {"n", "m", "limit", "offset", "after", "before", "per", "step", "slices", "count", "above_n", "n_before", "n_after", "fid", "rid", "version"}
SENSIBLE_YES = {"verified", "accept", "rerun", "same_queue", "anyway", "stale_ok", "confirm"}
SENSIBLE_WORD = {"level": "nvme_command", "parent_level": "nvme_command", "kind": "cmd", "unit": "ms", "signal": "correct", "action": "approve", "verdict": "accept"}


def sensible(name):
    if name in SENSIBLE_NUMBER:
        return 5
    if name in SENSIBLE_YES:
        return True
    return SENSIBLE_WORD.get(name, "fuzz")


def sources_of(fn, module_functions, depth=1):
    """The route's own code and that of the helpers of its module it calls, one level down: `_page(...)` reads parameters of the route too."""
    try:
        text = inspect.getsource(fn)
    except (OSError, TypeError):
        return ""
    if depth:
        for name in set(re.findall(r"\b(_[a-z_0-9]+)\(", text)):
            helper = module_functions.get(name)
            if helper is not None:
                text += "\n" + sources_of(helper, module_functions, depth - 1)
    return text


def params_of(app, rule):
    fn = app.view_functions[rule.endpoint]
    module = sys.modules.get(fn.__module__)
    funcs = {k: v for k, v in vars(module).items() if inspect.isfunction(v)} if module else {}
    text = sources_of(fn, funcs)
    names = set(re.findall(READERS + r"""\.get\(["']([A-Za-z_][A-Za-z_0-9]*)["']""", text))
    names |= set(re.findall(READERS + r"""\[["']([A-Za-z_][A-Za-z_0-9]*)["']\]""", text))
    if "_page(" in text or rule.methods & {"GET"}:
        names |= set(TOP)
    return sorted(names), ".items()" in text


class Always:
    """Stands in for random in fuzz_app.fill: every id in the address is one that exists, so the attack reaches the code behind it."""
    def random(self):
        return 0.0

    def choice(self, seq):
        return seq[0]


def plan(app):
    cases = []
    for rule in app.url_map.iter_rules():
        if rule.endpoint == "static" or any(x in rule.rule for x in ("/shutdown", "/events", "/stream", "/samples/generate")):
            continue
        names, walks_body = params_of(app, rule)
        for m in sorted(rule.methods - {"HEAD", "OPTIONS"}):
            for name in names:
                for v in HOSTILE:
                    cases.append((rule.rule, m, name, v, True, names))
                for v in ALONE:
                    cases.append((rule.rule, m, name, v, False, names))
            if walks_body and m in ("POST", "PUT", "PATCH"):
                for lvl in LEVELS:
                    for v in NESTED:
                        cases.append((rule.rule, m, lvl, v, False, names))
    return cases


def send(c, rule, m, name, value, together, names):
    url = F.fill(rule, Always())
    fields = {n: sensible(n) for n in names if n != name} if together else {}
    fields[name] = value
    if m in ("POST", "PUT", "PATCH", "DELETE"):
        return c.open(url, method=m, json=fields)
    return c.open(url, method=m, query_string={k: str(v) for k, v in fields.items()})


def main():
    seconds = int(sys.argv[1]) if len(sys.argv) > 1 else 300
    seed = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    part, parts = int(sys.argv[3]) if len(sys.argv) > 3 else 0, int(sys.argv[4]) if len(sys.argv) > 4 else 1
    signal.signal(signal.SIGALRM, F._alarm)
    root = tempfile.mkdtemp(prefix="fuzz_params_%d_" % os.getpid())
    t0 = time.time()
    app, c, _keys, _routes = F.setup(root)
    for mod in list(sys.modules.values()):                 # the model connection is dead on purpose: one try is enough, the pages' fallback is what is tested
        if getattr(mod, "HTTP_TRIES", None) is not None:
            mod.HTTP_TRIES = 1
    upload = os.path.join(root, "uploads", F.SEEDED_IDS["uid"])
    pristine = os.path.join(root, "pristine_upload")
    shutil.copytree(upload, pristine)
    cases = plan(app)
    random.Random(seed).shuffle(cases)
    cases.sort(key=lambda x: x[1] == "DELETE")             # deleting comes last: what is deleted cannot be attacked any more
    cases = cases[part::parts]
    print("%d cases over %d routes" % (len(cases), len({x[0] for x in cases})), flush=True)
    seen, codes, spent, done, busy = collections.Counter(), collections.Counter(), collections.Counter(), 0, 0
    last = time.time()
    for case in cases:
        if time.time() - t0 > seconds:
            break
        rule, m, name, value, together, names = case
        now = time.time()
        if done:
            spent["%s %s" % (cases[done - 1][1], cases[done - 1][0])] += now - last
        last = now
        signal.alarm(25)
        F.LAST_ERROR[0] = None
        try:
            resp = send(c, rule, m, name, value, together, names)
            code = resp.status_code
            detail = F.LAST_ERROR[0] or ""
            if code == 503 and not detail and b"the database is busy" in resp.get_data():
                busy += 1
                code = 409            # counted with the refusals in words; reported on its own in the last line
        except F.Hang:
            code, detail = 599, "no answer in 25 s"
        except Exception as e:      # noqa: BLE001 - the attack is on exactly this
            code, detail = 598, "%s: %s" % (type(e).__name__, str(e)[:160])
        finally:
            signal.alarm(0)
        done += 1
        codes[code // 100] += 1
        if code >= 500:
            key = re.sub(r"0x[0-9a-f]+|\d{4,}", "#", "%s %s %s" % (m, rule, detail))[:200]
            if key not in seen:
                print("[%d] %s %s %s=%s -> %s" % (code, m, rule, name, repr(value)[:60], detail[:260]), flush=True)
            seen[key] += 1
        if m == "DELETE" and not os.path.isdir(upload):
            shutil.copytree(pristine, upload)
    shutil.rmtree(root, ignore_errors=True)
    summary = {"seconds_budget": seconds, "seed": seed, "cases": len(cases), "sent": done, "answers": {"%dxx" % k: v for k, v in sorted(codes.items())}, "distinct_problems": len(seen), "problems": seen.most_common(60),
               "busy_try_again": busy}
    keep = os.path.join(F.APP, "runs", "kpi_proof")
    os.makedirs(keep, exist_ok=True)
    with open(os.path.join(keep, "fuzz_params_%d.json" % part), "w") as fh:
        json.dump(summary, fh, indent=1)
    print("where the time went: " + "; ".join("%s %d s" % (k, v) for k, v in spent.most_common(6)), flush=True)
    print("\n%d of %d cases sent, answers %s%s: %d distinct problems; %d s" % (
        done, len(cases), summary["answers"], " (%d of the 4xx were 'the database is busy: try again', HTTP 503)" % busy if busy else "", len(seen), time.time() - t0), flush=True)
    return 1 if seen else 0


if __name__ == "__main__":
    sys.exit(main())
