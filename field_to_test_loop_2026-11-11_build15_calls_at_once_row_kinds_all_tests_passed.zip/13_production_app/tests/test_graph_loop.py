"""The reinforcement loop on the procedural graph (owner, 2026-11-09: no model is trained; the admin's four signals change the
weights on the graph's nodes and edges, and the weights decide what comes out next).

    python3 -m pytest -q tests/test_graph_loop.py

Plain store, a throw-away database, no model and no server:
  - a stage 3 failure becomes signature -> cause -> procedure -> test in the graph;
  - each of the four signals changes the weights by the stated amounts;
  - the weights change the output: after a "wrong" the graph's first choice moves to the other procedure;
  - a procedure judged wrong more often than right is not offered, and a rejected one is skipped;
  - the same failure in another recording finds the procedure and its regression test;
  - another failure finds nothing;
  - failures stored before the graph existed get their graph.
"""
import os
import sqlite3
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from nvme_hier import store as ST  # noqa: E402


def sig(name="cmd.timeout", cmd="io.Write"):
    return {"fine": "fine-" + name + "-" + cmd, "coarse": "coarse-" + name, "display": "%s on %s" % (name, cmd),
            "fields": {"lvl": "nvme_command", "err": name, "cmd": cmd, "part": "none", "cause": "self", "alg": "v1"}}


SEQ_A = [{"step": 1, "command": "Write", "position": "above"}, {"step": 2, "command": "Write", "position": "fault"}]
SEQ_B = [{"step": 1, "command": "Flush", "position": "above"}, {"step": 2, "command": "Write", "position": "fault"}]
SEQ_C = [{"step": 1, "command": "Write", "position": "fault"}]


@pytest.fixture
def st(tmp_path):
    return ST.Store(str(tmp_path / "db" / "k.sqlite"))


def first(st, s, steps=SEQ_A):
    """A failure seen, the fresh proposal judged correct: procedure 1 of this failure."""
    st.touch_signature(s, "DRIVE", upload_id="up-1", finding_id=1)
    return st.signal(s["fine"], None, "correct", "Sagar", proposal_steps=steps, proposal_text="why", upload_id="up-1", finding_id=1)["new_procedure_id"]


def node(view, nid):
    return next(n for n in view["nodes"] if n["id"] == nid)


def edge(view, kind, to=None):
    return next(e for e in view["edges"] if e["kind"] == kind and (to is None or e["to"] == to))


def test_a_failure_becomes_a_graph_with_weights_on_nodes_and_edges(st):
    s = sig()
    p = first(st, s)
    v = st.graph_view(s["fine"])
    assert sorted(n["kind"] for n in v["nodes"]) == ["cause", "scenario", "signature"]
    assert sorted(e["kind"] for e in v["edges"]) == ["CAUSED_BY", "REPRODUCED_BY"]
    # the first "correct": one positive signal on the edges; the procedure starts at 2 / (2 + 1)
    assert (edge(v, "CAUSED_BY")["a"], edge(v, "CAUSED_BY")["b"]) == (2.0, 1.0)
    assert (edge(v, "REPRODUCED_BY")["a"], edge(v, "REPRODUCED_BY")["b"]) == (2.0, 1.0)
    assert (node(v, "proc::%d" % p)["a"], node(v, "proc::%d" % p)["b"]) == (2.0, 1.0)
    assert v["paths"][0]["weight_text"] == "judged correct 1 of 1 time" and st.graph_choice(s["fine"])["procedure_id"] == p


def test_correct_raises_every_weight_on_the_path(st):
    s = sig()
    p = first(st, s)
    st.signal(s["fine"], p, "correct", "Sagar")
    v = st.graph_view(s["fine"])
    assert edge(v, "CAUSED_BY")["a"] == 3.0 and edge(v, "REPRODUCED_BY")["a"] == 3.0
    n = node(v, "proc::%d" % p)
    assert n["a"] == pytest.approx(1 + (2 - 1) * 0.98 + 1) and n["b"] == pytest.approx(1.0)
    assert v["paths"][0]["weight"] > 2 / 3


def test_wrong_lowers_every_weight_on_the_path(st):
    s = sig()
    p = first(st, s)
    before = st.graph_view(s["fine"])
    st.signal(s["fine"], p, "wrong", "Sagar")
    v = st.graph_view(s["fine"])
    assert edge(v, "CAUSED_BY")["b"] == 2.0 and edge(v, "REPRODUCED_BY")["b"] == 2.0
    assert node(v, "proc::%d" % p)["b"] == pytest.approx(2.0)
    assert v["paths"][0]["weight"] < before["paths"][0]["weight"]
    assert ST.Store.graph_change(before, v)            # the sentences for the admin


def test_correct_with_edits_makes_a_new_version_that_takes_over(st):
    s = sig()
    p = first(st, s)
    new = st.signal(s["fine"], p, "correct_with_edits", "Sagar", edited_steps=SEQ_C, edited_text="shorter")["new_procedure_id"]
    v = st.graph_view(s["fine"])
    assert node(v, "proc::%d" % p)["status"] == "superseded" and node(v, "proc::%d" % new)["status"] == "active"
    assert edge(v, "SUPERSEDES")["to"] == "procedure version 1"
    c = st.graph_choice(s["fine"])
    assert c["procedure_id"] == new and c["steps"] == SEQ_C


def test_wrong_with_edits_replaces_it_and_leaves_the_cause_alone(st):
    s = sig()
    p = first(st, s)
    cause_before = edge(st.graph_view(s["fine"]), "CAUSED_BY")
    new = st.signal(s["fine"], p, "wrong_with_edits", "Sagar", edited_steps=SEQ_B, edited_text="other")["new_procedure_id"]
    v = st.graph_view(s["fine"])
    assert edge(v, "REPRODUCED_BY", "procedure version 1")["b"] == 2.0 and node(v, "proc::%d" % p)["status"] == "superseded"
    assert (edge(v, "CAUSED_BY")["a"], edge(v, "CAUSED_BY")["b"]) == (cause_before["a"], cause_before["b"])
    assert st.graph_choice(s["fine"])["steps"] == SEQ_B and st.graph_choice(s["fine"])["procedure_id"] == new


def test_a_wrong_on_a_fresh_proposal_lowers_the_cause_and_leaves_a_lesson(st):
    s = sig()
    st.touch_signature(s, "DRIVE", upload_id="up-1", finding_id=1)
    st.signal(s["fine"], None, "wrong", "Sagar", proposal_text="bad idea")
    v = st.graph_view(s["fine"])
    assert edge(v, "CAUSED_BY")["b"] == 2.0 and [e["kind"] for e in v["edges"] if e["kind"] == "LESSON_ABOUT"] == ["LESSON_ABOUT"]
    assert st.graph_choice(s["fine"]) is None


def test_the_weights_decide_the_next_output_a_wrong_moves_the_first_choice(st):
    s = sig()
    a = first(st, s, SEQ_A)
    b = st.add_procedure(s["fine"], SEQ_B, "second", "admin:Sagar")
    st.signal(s["fine"], a, "correct", "Sagar")
    assert st.graph_choice(s["fine"])["procedure_id"] == a
    before = st.graph_view(s["fine"])
    st.signal(s["fine"], a, "wrong", "Sagar")
    st.signal(s["fine"], a, "wrong", "Sagar")
    after = st.graph_view(s["fine"])
    c = st.graph_choice(s["fine"])
    assert c["procedure_id"] == b and c["steps"] == SEQ_B
    assert any("first choice next time" in x for x in ST.Store.graph_change(before, after))
    # and positive signals bring it back, once the other one has been tried and judged
    st.signal(s["fine"], b, "wrong", "Sagar")
    for _ in range(4):
        st.signal(s["fine"], a, "correct", "Sagar")
    assert st.graph_choice(s["fine"])["procedure_id"] == a


def test_a_rejected_procedure_is_skipped_and_one_judged_wrong_is_not_offered(st):
    s = sig()
    a = first(st, s, SEQ_A)
    b = st.add_procedure(s["fine"], SEQ_B, "second", "admin:Sagar")
    assert st.graph_choice(s["fine"], exclude=[a])["procedure_id"] == b
    assert st.graph_choice(s["fine"], exclude=[a, b]) is None      # then a new proposal from the recording is used
    for pid in (a, b):
        for _ in range(4):
            st.signal(s["fine"], pid, "wrong", "Sagar")
    assert st.graph_paths(s["fine"]) and st.graph_choice(s["fine"]) is None


def test_the_admins_explicit_order_comes_first(st):
    s = sig()
    a = first(st, s, SEQ_A)
    b = st.add_procedure(s["fine"], SEQ_B, "second", "admin:Sagar")
    st.signal(s["fine"], a, "correct", "Sagar")
    st.reorder(s["fine"], [b, a], "Sagar")
    p = st.graph_paths(s["fine"])
    assert [x["procedure_id"] for x in p] == [b, a] and p[0]["ordered_by"] == "the admin's order"


def test_the_same_failure_in_another_recording_finds_its_procedure_and_regression_test(st):
    s, other = sig(), sig("cmd.read_failure", "io.Read")
    p = first(st, s)
    st.set_test_path(p, "/suite/hier/up-1_f1_v1.py")
    st.touch_signature(s, "DRIVE", upload_id="up-2", finding_id=9)      # a later recording, the same failure
    v = st.graph_view(s["fine"])
    c = st.graph_choice(s["fine"])
    assert c["procedure_id"] == p and c["test_path"] == "/suite/hier/up-1_f1_v1.py"
    assert edge(v, "TESTED_BY")["to"] == "test file up-1_f1_v1.py" and node(v, s["fine"])["seen"] == 2
    st.touch_signature(other, "DRIVE", upload_id="up-2", finding_id=10)
    assert st.graph_choice(other["fine"]) is None and st.graph_view(other["fine"])["paths"] == []


def test_failures_stored_before_the_graph_get_their_graph(tmp_path):
    path = str(tmp_path / "db" / "k.sqlite")
    st = ST.Store(path)
    s = sig()
    p = first(st, s)
    st.signal(s["fine"], p, "correct", "Sagar")
    want = st.graph_view(s["fine"])
    con = sqlite3.connect(path)
    con.execute("DELETE FROM pnode")
    con.execute("DELETE FROM pedge")
    con.commit()
    con.close()
    again = ST.Store(path).graph_view(s["fine"])
    assert [(n["id"], n["a"], n["b"], n["n"]) for n in again["nodes"]] == [(n["id"], n["a"], n["b"], n["n"]) for n in want["nodes"]]
    assert sorted((e["id"], e["a"], e["b"]) for e in again["edges"]) == sorted((e["id"], e["a"], e["b"]) for e in want["edges"])


def test_a_database_put_back_without_the_graph_gets_its_graph_while_running(tmp_path):
    path = str(tmp_path / "db" / "k.sqlite")
    st = ST.Store(path)                     # the running server's store
    s = sig()
    p = first(st, s)
    con = sqlite3.connect(path)
    con.execute("DROP TABLE pnode")
    con.execute("DROP TABLE pedge")
    con.commit()
    con.close()
    st.signal(s["fine"], p, "correct", "Sagar")           # no error, and no lock left behind
    assert st.graph_paths(s["fine"])[0]["procedure_id"] == p
    con = sqlite3.connect(path, timeout=1)
    con.execute("INSERT INTO lesson (fine, text, producer, at) VALUES ('x', 'y', 'z', 0)")      # the database is free for everyone else
    con.rollback()
    con.close()
