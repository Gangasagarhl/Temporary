"""Edit rule/procedure and Code it work together (owner, 2026-11-09: "Edit rule/procedure and code should work simultaneously").

    python3 -m pytest -q tests/test_edit_and_code.py

Through the real API (Flask test client, a throw-away engine database, no step is executed):
  - "Save and code it" saves the text and starts the Coder on it in the same request;
  - saving a change while code is being made stops that coding and starts it again for the new text;
  - pressing it again with nothing changed gives back the coding already going: no second Coder;
  - a save names the text the editor started from: when the procedure changed meanwhile (for example the Coder's change was
    approved), nothing is saved and the answer says so; saving again then replaces it, knowingly.
"""
import copy
import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(HERE)
sys.path.insert(0, APP_DIR)
sys.path.insert(0, os.path.join(APP_DIR, "app"))
from agentic import core, family1, family3, procedures as PR, rule_evidence as E   # noqa: E402

U = "up-20261108-123729-0a98"
pytestmark = pytest.mark.skipif(not os.path.exists(os.path.join(E.APP, "uploads", U, "hier.sqlite")), reason="the S17 sample upload is not on this machine")
ITEM = ("analytics", "nvme_command", "read_pattern")


class QuietEngine(core.Engine):
    def kick(self, rid):            # the runs are recorded, their steps are not executed
        pass


@pytest.fixture
def api(tmp_path, monkeypatch):
    from flask import Flask
    from api import agentic_api as A
    monkeypatch.setattr(family1, "knowledge_dir", lambda: str(tmp_path / "knowledge"))
    family3._SECTIONS_SEEN[0] = None
    family3.tree()
    store = core.Store(str(tmp_path / "agentic.sqlite"))
    eng = QuietEngine(store, {"rule_code": family3, "rule_exec": family3}, runner=None)
    pid = store.exec("INSERT INTO project (admin, name, upload_id, created, updated) VALUES ('Sagar', 'S17', ?, 0, 0)", (U,))
    monkeypatch.setattr(A, "engine", lambda: eng)
    app = Flask(__name__)
    app.register_blueprint(A.bp)
    yield app.test_client(), eng, pid
    family3._SECTIONS_SEEN[0] = None


def url(tail):
    return "/api/agents/rules/%s/%s/%s/%s" % (ITEM + (tail,))


def card(c):
    return c.get(url("explain") + "?upload=" + U).get_json()


def coding_runs(eng):
    return [(x["id"], x["state"]) for x in eng.store.all("SELECT id, state FROM run WHERE kind='rule_code' ORDER BY id")]


def test_save_and_code_it_saves_the_text_and_starts_the_coder_in_one_request(api):
    c, eng, pid = api
    x = card(c)
    proc = copy.deepcopy(x["procedure_json"])
    proc["steps"][-1] += " (edited)"
    r = c.put(url("procedure"), json={"procedure": proc, "admin": "Sagar", "upload_id": U, "base_sha": x["procedure_info"]["sha"],
                                     "code": True, "project": pid})
    y = r.get_json()
    assert r.status_code == 200 and y["changed"] and y["run"]
    assert y["procedure_info"]["version"] == x["procedure_info"]["version"] + 1
    assert coding_runs(eng) == [(y["run"], "running")]
    # the same again, nothing changed: the coding already going is given back, no second Coder
    r2 = c.put(url("procedure"), json={"procedure": proc, "admin": "Sagar", "upload_id": U, "base_sha": y["procedure_info"]["sha"],
                                      "code": True, "project": pid}).get_json()
    assert not r2["changed"] and r2["run"] == y["run"] and "already" in r2["coding_note"]
    assert c.post(url("code"), json={"project": pid, "admin": "Sagar"}).get_json()["run"] == y["run"]
    assert len(coding_runs(eng)) == 1


def test_editing_while_the_code_is_made_replaces_that_coding_with_coding_of_the_new_text(api):
    c, eng, pid = api
    first = c.post(url("code"), json={"project": pid, "admin": "Sagar"}).get_json()["run"]
    x = card(c)
    assert x["activity"]["coding"]["run"] == first
    proc = copy.deepcopy(x["procedure_json"])
    proc["output"]["columns"] = ["read kind", "count", "percent"]
    y = c.put(url("procedure"), json={"procedure": proc, "admin": "Sagar", "upload_id": U, "base_sha": x["procedure_info"]["sha"],
                                     "code": True, "project": pid}).get_json()
    assert y["stopped_coding"] == [first] and y["run"] and y["run"] != first
    assert coding_runs(eng) == [(first, "stopped"), (y["run"], "running")]
    assert y["activity"]["coding"]["run"] == y["run"]
    # Save only, while that coding goes on: it stops, and nothing new starts until Code it
    proc["steps"][0] += " Nothing else."
    z = c.put(url("procedure"), json={"procedure": proc, "admin": "Sagar", "upload_id": U, "base_sha": y["procedure_info"]["sha"]}).get_json()
    assert z["changed"] and z["stopped_coding"] == [y["run"]] and z["run"] is None
    assert [s for _, s in coding_runs(eng)] == ["stopped", "stopped"]


def test_a_save_does_not_overwrite_a_change_made_meanwhile_unless_saved_again(api):
    c, eng, pid = api
    x = card(c)
    opened = x["procedure_info"]["sha"]
    # meanwhile the procedure changes (the Coder's change approved, another admin...)
    r = family3.load_rule(*ITEM)
    other = copy.deepcopy(PR.procedure_of(r))
    other["steps"][0] += " Changed meanwhile."
    r, _ = PR.store(r, {k: other[k] for k in ("source_data", "steps", "output", "open_questions")}, "Coder", note="meanwhile")
    family3.save_rule(r)
    mine = copy.deepcopy(x["procedure_json"])
    mine["steps"][-1] += " Mine."
    res = c.put(url("procedure"), json={"procedure": mine, "admin": "Sagar", "upload_id": U, "base_sha": opened, "code": True, "project": pid})
    j = res.get_json()
    assert res.status_code == 409 and j["conflict"] and "changed while you were editing" in j["error"]
    assert "Changed meanwhile." in PR.procedure_of(family3.load_rule(*ITEM))["steps"][0]      # nothing was saved
    assert coding_runs(eng) == []                                                             # and no Coder started
    # saving again from the text as it is now replaces it, knowingly
    res = c.put(url("procedure"), json={"procedure": mine, "admin": "Sagar", "upload_id": U, "base_sha": j["current_sha"]})
    assert res.status_code == 200 and res.get_json()["changed"]
    assert PR.procedure_of(family3.load_rule(*ITEM))["steps"][-1].endswith(" Mine.")


def test_save_and_code_it_needs_an_analysis(api):
    c, eng, pid = api
    x = card(c)
    r = c.put(url("procedure"), json={"procedure": x["procedure_json"], "admin": "Sagar", "code": True})
    assert r.status_code == 400 and "analysis" in r.get_json()["error"]
