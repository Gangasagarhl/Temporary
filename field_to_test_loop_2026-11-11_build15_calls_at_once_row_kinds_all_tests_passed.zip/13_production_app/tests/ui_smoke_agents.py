"""Browser check of the flow pages (the front page /, also at /agents) in headless Chrome (port 9333). Read-only.

    python3 tests/ui_smoke_agents.py

Home shows only what starts an analysis (your name, the folder, Start) and the four stages by name; there is no
permanent sidebar and no rules list at the start. The top bar opens History, the guide and Settings (a dialog). The
rules library (Family 3) lists Section 1 and Section 2 with a switch, five level filters and a search, and shows one
rule at a time; "Add an item" opens a dialog. No script error and no failed request.
(tests/ui_smoke_flow.py clicks through a whole flow.)
"""
import os
import socket
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from ui_smoke_hier import Chrome   # noqa: E402


def port_busy(port):
    with socket.socket() as sk:
        return sk.connect_ex(("127.0.0.1", port)) == 0


BASE = "http://127.0.0.1:8077"
R = {"pass": 0, "fail": 0}


def check(name, ok, detail=""):
    R["pass" if ok else "fail"] += 1
    print("%s  %s%s" % ("PASS" if ok else "FAIL", name, ("  | " + str(detail)[:200]) if detail != "" else ""), flush=True)


def main():
    if port_busy(9333):
        sys.exit("port 9333 is busy (another headless Chrome)")
    c = Chrome()
    txt = lambda: c.js("document.getElementById('main').innerText") or ""     # noqa: E731
    try:
        c.goto(BASE + "/#/")
        time.sleep(2.5)
        check("the front page is the flow", (c.js("document.title") or "").endswith("Field-to-Test flow"))
        t = txt()
        check("home names the four stages in order", all(x in t for x in ("1 · Understand the data", "2 · One tree", "3 · Rules, defects, test cases", "4 · Report")), t[:200])
        check("home asks only for what starts an analysis: the folder, a name, Start", all(c.js("!!document.getElementById('%s')" % i) for i in ("np-folder", "np-check", "np-name", "np-make")))
        check("the other options are folded under 'More options'", c.js("!document.querySelector('details.more[data-id=np-more]').open") is True)
        n_fields = c.js("document.querySelectorAll('#main label.f').length") or 0
        n_why = c.js("[...document.querySelectorAll('#main label.f')].filter(l => (l.nextElementSibling || {}).className === 'why' && l.nextElementSibling.textContent.length > 40).length") or 0
        check("every field says why it exists (a 'why' line under each label)", n_fields >= 3 and n_why == n_fields, (n_why, n_fields))
        check("the name of the analysis is marked required and unique", "required · unique" in (c.js("document.querySelector('label[for=np-name]').innerText") or ""))
        c.js("document.getElementById('adm').value = 'ui-check'; document.getElementById('np-folder').value = '/tmp'; document.getElementById('np-make').click()")
        time.sleep(0.8)
        check("Start without a name is stopped with the reason, nothing is created", "give the analysis a name" in (c.js("document.getElementById('np-msg').innerText") or ""))
        c.js("document.getElementById('np-name').value = 'a brand new name'; document.getElementById('np-name').dispatchEvent(new Event('input', {bubbles: true}))")
        time.sleep(0.4)
        check("while typing, the page says whether the name opens an existing analysis or makes a new one", "new analysis" in (c.js("document.getElementById('np-name-hint').innerText") or "").lower())
        c.js("localStorage.setItem('agents.admin', 'someone before')")
        c.goto(BASE + "/?reload=1#/")          # a real reload: the page reads the saved name again
        time.sleep(2.5)
        check("the starter's name is asked every time, even after a name was saved here (filled in, can be changed)",
              c.js("document.getElementById('adm') && document.getElementById('adm').value") == "someone before" and "change it if someone else is starting" in (c.js("document.querySelector('label[for=adm]').nextElementSibling.textContent") or ""))
        c.js("localStorage.removeItem('agents.admin')")
        check("no permanent sidebar and no rules list at the start", (c.js("document.querySelectorAll('nav#nav, .rb').length") or 0) == 0)
        top = c.js("document.querySelector('.top').innerText") or ""
        check("the top bar offers History, Guide and Settings", all(x in top for x in ("History", "Guide", "Settings")), top)
        c.js("document.getElementById('open-settings').click()")
        time.sleep(1)
        check("Settings open as a dialog: your name and where the agents run", c.js("document.getElementById('modal').classList.contains('on')") and (c.js("document.querySelectorAll('#set-rt button').length") or 0) == 3)
        c.js("document.querySelector('#modal [data-act=close]').click()")
        time.sleep(0.3)
        check("the dialog closes", not c.js("document.getElementById('modal').classList.contains('on')"))
        c.js("location.hash = '#/history'")
        time.sleep(1.5)
        check("History opens", "Every run" in txt())
        c.js("location.hash = '#/library'")
        for _ in range(30):        # the library draws when its list has arrived
            time.sleep(0.3)
            if (c.js("document.querySelectorAll('.rb-lib .rb-lvl').length") or 0) >= 10:
                break
        check("the rules library has the sidebar of sections and levels, and a search",
              (c.js("document.querySelectorAll('.rb-lib .rb-sec').length") or 0) >= 2 and (c.js("document.querySelectorAll('.rb-lib .rb-lvl').length") or 0) >= 10 and c.js("!!document.getElementById('lib-q')"))
        n1 = c.js("document.querySelectorAll('.rb-lib .rb-item').length") or 0
        c.js("document.querySelector('.rb-lib .rb-lvl[data-sec=errors][data-lvl=nvme_command]').click()")
        time.sleep(0.6)
        n2 = c.js("document.querySelectorAll('.rb-lib .rb-item').length") or 0
        check("a level of Section 1 lists the analytics items, the same level of Section 2 the detector's errors", n1 >= 2 and n2 >= 2, (n1, n2))
        c.js("[...document.querySelectorAll('.rb-lib .rb-open')].find(x => x.innerText.toLowerCase().includes('timeout')).click()")
        for _ in range(30):
            time.sleep(0.3)
            if c.js("!!document.querySelector('.rb-lib .rb-detail .rb-d')"):
                break
        t = txt().lower()
        check("one error shows its source data, its procedure, the detector's verified code and Edit rule/procedure",
              "timeout" in t and "source data" in t and "rules or procedure" in t and "verified code" in t and "edit rule/procedure" in t)
        c.js("document.getElementById('lib-q').value = 'read'; document.getElementById('lib-q').dispatchEvent(new Event('input', {bubbles: true}))")
        time.sleep(1.2)
        names = c.js("[...document.querySelectorAll('.rb-lib .rb-item .rb-nm')].map(x => x.innerText)") or []
        check("the search narrows the list across sections", names and all("read" in x.lower() for x in names), names[:3])
        c.js("document.getElementById('lib-q').value = ''; document.getElementById('lib-q').dispatchEvent(new Event('input', {bubbles: true}))")
        time.sleep(0.8)
        check("'Add a section' and 'Add an item' sit in the browser, with a name and the words", all(c.js("!!document.getElementById('%s')" % i) for i in ("asnlib", "asalib", "ainlib", "aidlib")))
        print("screenshot:", c.shot("agents_page"))
        check("no script error and no failed request", not c.errors, c.errors[:3])
    finally:
        c.close()
    print("%d checks, %d failed" % (R["pass"] + R["fail"], R["fail"]))
    sys.exit(1 if R["fail"] else 0)


if __name__ == "__main__":
    main()
