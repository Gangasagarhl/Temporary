"""Stage 1's window (owner, 2026-11-10): the admin sets n above and m below, looks again, and the numbers are remembered per kind of
defect; the commands from earlier in the recording that the failing command depends on are found by shared blocks, features and
queues (nvme_hier/slice.py), never by time stamp alone.

    python3 -m pytest -q tests/test_isolation_window.py
"""
import json
import os
import shutil
import sqlite3
import sys
import tempfile
import time

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
sys.path.insert(0, os.path.join(APP, "app"))
sys.path.insert(0, HERE)

from nvme_hier import slice as SL   # noqa: E402

COLS = ("rowid_file", "n", "sqid", "cqid", "opc", "nsid", "slba", "nlb", "ad", "nr", "fid", "qid", "t_ps", "dur_ps", "raw")


def _db(rows):
    con = sqlite3.connect(":memory:")
    con.row_factory = sqlite3.Row
    con.execute("CREATE TABLE cmd (%s)" % ", ".join(COLS))
    for i, r in enumerate(rows, 1):
        r = dict({"rowid_file": i, "n": i, "t_ps": i * 1000, "dur_ps": 100, "raw": "{}"}, **r)
        con.execute("INSERT INTO cmd (%s) VALUES (%s)" % (", ".join(COLS), ", ".join("?" * len(COLS))), [r.get(c) for c in COLS])
    return con


def test_history_finds_what_the_failing_command_depends_on_and_nothing_else():
    W, R, DSM, WZ = 0x01, 0x02, 0x09, 0x08
    rows = [
        {"sqid": 1, "opc": W, "nsid": 1, "slba": 100, "nlb": 7},                       # 1  written before the format: cannot matter
        {"sqid": 0, "opc": 0x80, "nsid": 1},                                            # 2  Format NVM: the cut-off
        {"sqid": 0, "opc": 0x05, "qid": 1},                                             # 3  Create I/O CQ 1
        {"sqid": 0, "opc": 0x01, "qid": 1},                                             # 4  Create I/O SQ 1
        {"sqid": 0, "opc": 0x09, "fid": 0x05},                                          # 5  Set Features Error Recovery (superseded by 9)
        {"sqid": 1, "opc": W, "nsid": 1, "slba": 96, "nlb": 7},                         # 6  writes blocks 96..103: covers 100..103
        {"sqid": 1, "opc": W, "nsid": 1, "slba": 104, "nlb": 3},                        # 7  writes blocks 104..107: covers the rest
        {"sqid": 1, "opc": W, "nsid": 2, "slba": 100, "nlb": 7},                        # 8  another namespace: independent
        {"sqid": 0, "opc": 0x09, "fid": 0x05},                                          # 9  the LAST Set Features Error Recovery
        {"sqid": 1, "opc": DSM, "nsid": 1, "ad": 1, "nr": 0, "raw": json.dumps({"RNG 0.SLBA": "100", "RNG 0.Length LB": "8"})},   # 10 deallocate of 100..107
        {"sqid": 1, "opc": DSM, "nsid": 1, "ad": 0, "nr": 0, "raw": json.dumps({"RNG 0.SLBA": "100", "RNG 0.Length LB": "8"})},   # 11 no deallocate attribute
        {"sqid": 1, "opc": R, "nsid": 1, "slba": 500, "nlb": 0},                        # 12 another range: independent
        {"sqid": 2, "opc": R, "nsid": 1, "slba": 900, "nlb": 0, "t_ps": 12500, "dur_ps": 5000},   # 13 still open when F is submitted
        {"sqid": 1, "opc": R, "nsid": 1, "slba": 1, "nlb": 0},                          # 14 the admin's window starts here
        {"sqid": 1, "cqid": 1, "opc": R, "nsid": 1, "slba": 100, "nlb": 7, "t_ps": 15000},  # 15 F: read of 100..107
    ]
    con = _db(rows)
    fault = dict(con.execute("SELECT * FROM cmd WHERE rowid_file=15").fetchone())
    fault["raw"] = {}
    hist, rep = SL.history(con, fault, 14)
    got = {r["rowid_file"]: r["history_why"] for r in hist}
    assert sorted(got) == [2, 3, 4, 6, 7, 9, 10, 13], got
    assert got[2][0].startswith("H4 the latest Format NVM") and rep["cutoff"]["rowid"] == 2
    assert any(w.startswith("H1 the last Write of blocks 100 to 103") for w in got[6]) and any(w.startswith("H1 the last Write of blocks 104 to 107") for w in got[7])
    assert got[9][0].startswith("H3 the last Set Features of Error Recovery") and 5 not in got
    assert got[10][0].startswith("H2 a deallocate") and 11 not in got and 1 not in got and 8 not in got and 12 not in got
    assert got[3][0].startswith("H5 the Create I/O Completion Queue of queue 1") and got[4][0].startswith("H5 the Create I/O Submission Queue of queue 1")
    assert got[13][0].startswith("H6 still open on queue 2")
    assert rep["uncovered"] == []


def test_history_says_which_blocks_were_never_written_and_stops_at_the_window():
    con = _db([{"sqid": 1, "opc": 0x01, "nsid": 1, "slba": 0, "nlb": 3}, {"sqid": 1, "opc": 0x02, "nsid": 1, "slba": 0, "nlb": 7}])
    fault = dict(con.execute("SELECT * FROM cmd WHERE rowid_file=2").fetchone())
    fault["raw"] = {}
    hist, rep = SL.history(con, fault, 2)
    assert [r["rowid_file"] for r in hist] == [1] and rep["uncovered"] == [{"nsid": 1, "first": 4, "last": 7}]
    assert SL.history(con, fault, 1) == ([], {"note": "the window starts at the first command of the recording: nothing lies before it"})


def _first_finding(app):
    from api import hier_api as H
    s = app.config["services"]
    d = H.upload_dir(s, "up-fuzz")
    con = sqlite3.connect(H.db_of(d))
    try:
        row = con.execute("SELECT id FROM finding WHERE level='nvme_command' ORDER BY id LIMIT 1").fetchone() or \
            con.execute("SELECT id FROM finding WHERE cmd_rowid IS NOT NULL ORDER BY id LIMIT 1").fetchone()
    finally:
        con.close()
    return row[0]


def test_the_admins_numbers_are_used_and_remembered_for_the_kind_of_defect():
    import fuzz_app as F
    if not os.path.isdir(F.BASE):
        pytest.skip("the S08 sample recording is not on this machine (the code-only zip carries no samples)")
    root = tempfile.mkdtemp(prefix="iso_window_%d_" % os.getpid())
    try:
        app, c, _k, _r = F.setup(root)
        fid = _first_finding(app)
        url = "/api/isolate/up-fuzz/%d/isolate" % fid
        r = c.post(url, json={"anyway": True, "standin": True, "name": "t"}).get_json()
        assert (r["window"]["n"], r["window"]["m"]) == (15, 15) and r["window"]["source"].startswith("the default")
        assert r["window"]["counts"]["commands"] >= 1 and "history" in r["window"]
        r = c.post(url, json={"n": 3, "m": 1, "remember": True, "anyway": True, "standin": True, "name": "Tester", "levels": ["nvme_transaction"]}).get_json()
        assert (r["window"]["n"], r["window"]["m"]) == (3, 1) and r["window"]["source"] == "set by the admin for this look"
        assert r["window"]["counts"].get("nvme_transaction", 0) >= 0
        r = c.post(url, json={"anyway": True, "standin": True, "name": "t"}).get_json()
        assert (r["window"]["n"], r["window"]["m"]) == (3, 1) and "Tester chose for this kind of defect" in r["window"]["source"]
        bad = c.post(url, json={"n": "many", "anyway": True, "standin": True})
        assert bad.status_code == 400
        # every step of the proposed sequence is a command of the window (history rows included), and the fault is in it
        cmds = {x["rowid"] for x in r["window"]["history"].get("rows") or []}
        assert any(s["position"] == "fault" for s in r["sequence"])
        assert all(s.get("source_row") is None or s["position"] != "above" or s["source_row"] for s in r["sequence"])
        assert isinstance(cmds, set)
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_the_error_page_opens_the_commands_level_by_level():
    """The error page (owner, 2026-11-11): the commands around the error as a tree; expand opens the rows directly under a row."""
    import test_regression_tests as R
    root = tempfile.mkdtemp(prefix="iso_tree_%d_" % os.getpid())
    try:
        app, c = R._app_with_s17(root)
        fid = 10                                   # the S17 Read the field host aborted after 421.788 us
        w = c.get("/api/isolate/up-s17/%d/window?n=15&m=15&levels=" % fid).get_json()
        fault = next(x for x in w["commands"] if x["position"] == "fault")
        assert sum(1 for x in w["commands"] if x["position"] == "above") <= 15 and not fault.get("under")
        r = c.get("/api/isolate/up-s17/%d/children?level=nvme_command&rowid=%d" % (fid, fault["rowid"])).get_json()
        assert [p_["level"] for p_ in r["parts"]] == ["nvme_transaction"] and r["parts"][0]["count"] >= len(r["parts"][0]["rows"]) > 0
        t = r["parts"][0]["rows"][0]
        assert t["summary"] and t["has_children"] is True and "findings" in t
        r2 = c.get("/api/isolate/up-s17/%d/children?level=nvme_transaction&rowid=%d" % (fid, t["rowid"])).get_json()
        assert {p_["level"] for p_ in r2["parts"]} <= {"split", "link"}
        link = next((x for p_ in r2["parts"] if p_["level"] == "link" for x in p_["rows"]), None)
        if link:
            r3 = c.get("/api/isolate/up-s17/%d/children?level=link&rowid=%d" % (fid, link["rowid"])).get_json()
            assert all(p_["level"] == "packets" for p_ in r3["parts"]) and all(x["has_children"] is False for p_ in r3["parts"] for x in p_["rows"])
        assert c.get("/api/isolate/up-s17/%d/children?level=moon&rowid=1" % fid).status_code == 400
        assert c.get("/api/isolate/up-s17/%d/children?level=link&rowid=x" % fid).status_code == 400
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_the_test_file_is_approved_with_who_and_its_fingerprint_and_tied_to_the_solution():
    import test_regression_tests as R
    from nvme_hier import defect_graph as DG
    root = tempfile.mkdtemp(prefix="iso_tf_%d_" % os.getpid())
    try:
        app, c = R._app_with_s17(root)
        fid = 10                                   # the S17 Read the field host aborted after 421.788 us
        iso = c.post("/api/isolate/up-s17/%d/isolate" % fid, json={"anyway": True, "standin": True, "name": "t", "isolation": True,
                                                                  "levels": ["nvme_transaction", "split", "link", "packets"]}).get_json()
        g = DG.DefectGraph(os.path.join(root, "db", "hier_knowledge.sqlite"))
        d, _ = g.add_defect("Read aborted by host", "cmd.timeout", "nvme_command", "", "t")
        cz, _ = g.add_cause(d, "host", "host timer too short", "t")
        sid, rev = g.add_solution(cz, iso["sequence"], ["raise the host's read timeout"], "", "admin:t", "t", "up-s17", fid)
        ex = c.post("/api/isolate/up-s17/%d/testcase" % fid, json={"sequence": iso["sequence"], "expected_after": 3, "name": "t", "standin": True}).get_json()
        outs = [dict(o, verified=True) for o in ex["expected_outcomes"]]
        f = c.post("/api/isolate/up-s17/%d/testcase" % fid, json={"sequence": ex["sequence"], "expected_outcomes": outs, "verified": True, "name": "t", "standin": True}).get_json()
        assert f["path"].endswith(".py") and "PLAN = {" in f["text"] and (f.get("two_sided") or {}).get("ok")
        assert c.post("/api/isolate/up-s17/%d/testcase/approve" % fid, json={"path": f["path"]}).status_code == 400          # who approves is required
        assert c.post("/api/isolate/up-s17/%d/testcase/approve" % fid, json={"path": "/etc/passwd", "name": "Tester"}).status_code == 400
        r = c.post("/api/isolate/up-s17/%d/testcase/approve" % fid, json={"path": f["path"], "name": "Tester", "revision_id": rev, "two_sided": True}).get_json()
        with open(f["path"] + ".approved.json") as fh:
            ap = json.load(fh)
        assert r["ok"] and ap["approved_by"] == "Tester" and ap["status"] == "approved" and len(ap["sha256"]) == 64
        assert g.solution(sid)["versions"][0]["test_path"] == os.path.realpath(f["path"])
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_long_step_runs_as_a_job_with_its_progress_and_its_answer():
    """(owner, 2026-11-11) the page shows how far the isolation is and what it does, then its answer."""
    import test_regression_tests as R
    root = tempfile.mkdtemp(prefix="iso_job_%d_" % os.getpid())
    try:
        app, c = R._app_with_s17(root)
        r = c.post("/api/isolate/up-s17/10/isolate?job=1", json={"anyway": True, "standin": True, "name": "t", "isolation": True,
                                                              "levels": ["nvme_transaction", "split", "link", "packets"]}).get_json()
        jid = r["job"]
        seen, t0 = [], time.time()
        while time.time() - t0 < 120:
            j = c.get("/api/isolate/jobs/%s" % jid).get_json()
            seen.append(j["pct"])
            if j["state"] != "running":
                break
            time.sleep(0.2)
        assert j["state"] == "done" and j["pct"] == 100 and j["result"]["isolation"]["what"], j.get("error")
        assert seen == sorted(seen) and any("round 1" in x["text"] for x in j["log"]) and any("decided by the fixed rules" in x["text"] for x in j["log"])
        assert c.get("/api/isolate/jobs/nope").status_code == 404
    finally:
        shutil.rmtree(root, ignore_errors=True)
