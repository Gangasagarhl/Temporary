#!/usr/bin/env python3
"""Trying to break the whole application (owner, 2026-11-09). Random hostile inputs, 200 iterations at most.

    python3 tests/fuzz_app.py [iterations] [first seed]        default 200 from seed 7000; a seed always rebuilds the same attack

Runs on a throw-away root with the configuration, the knowledge folder and the model connection replaced, so nothing of the admin's is read or written and no
model is called. Each iteration is one of:
  api      random calls on EVERY route with hostile ids, bodies and queries: the server must answer, never crash (no 500, no hang)
  cells    hostile values in the key columns of all five CSV files: load, tree and rules must finish, and keep every row
  rows     rows of all five files shuffled, repeated and dropped: load, tree and rules must finish
  script   hostile words reaching a generated test file: it must compile, and no words may run as code
  code     code an agent could write to escape: the code check must refuse it
  page     hostile words through the page's text renderer: no markup, no script
A failure is an application defect until shown otherwise.
"""
import collections
import copy
import csv
import importlib
import json
import os
import random
import re
import shutil
import signal
import sqlite3
import subprocess
import sys
import tempfile
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
sys.path.insert(0, os.path.join(APP, "app"))
csv.field_size_limit(10 ** 9)
from nvme_hier import builder as B, loader as L, rules as RL, testcase as TC  # noqa: E402

BASE = os.path.join(APP, "samples", "clean_five_files", "S08_interrupt_before_completion")
NAMES = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv", "nvme_command": "nvme_command.csv"}
EVIL_TEXT = ["", " ", "x" * 70000, "../../../../etc/passwd", "'; DROP TABLE run; --", "<script>alert(1)</script>", "<img src=x onerror=alert(1)>", "\x00", "%s%d{0}{x}", "\u6d4b\u8bd5\U0001F4A5", "a\nb\r\nc", '"""', "\\", "{", "}", "null", "-1", "NaN"]
EVIL_ANY = EVIL_TEXT + [None, 0, -1, 1, 2 ** 70, -2 ** 70, 1e308, 1.5, True, False, [], [1, "a", None], {}, {"a": {"b": []}}, [[[]]]]
EVIL_CELL = ["", " ", "abc", "-1", "0xZZ", "99999999999999999999999999", "1e400", "NaN", "\u0663", "0000.1s", "s", "-0.5s", "9" * 40 + "s", "\x00", "a,b", '"', "0x", "1 2 3", "0xFFFFFFFFFFFFFFFFFFFFFFFF"]
SEEDED_IDS = {}
LAST_ERROR = [None]
ONLY = os.environ.get("FUZZ_ONLY")


def _where(app_sender, exception, **_k):
    tb = traceback.extract_tb(exception.__traceback__)
    f = next((x for x in reversed(tb) if APP in x.filename and "tests/" not in x.filename), tb[-1])
    LAST_ERROR[0] = "%s: %s at %s:%d" % (type(exception).__name__, str(exception)[:90], os.path.basename(f.filename), f.lineno)


class Hang(Exception):
    pass


def _alarm(*_a):
    raise Hang()


REAL_KICK = None


def setup(root):
    """The application on a throw-away root: its own configuration file, knowledge folder and engine; the model connection points nowhere."""
    from agentic import core, family1
    from api import config_api
    cfg = copy.deepcopy(json.load(open(os.path.join(APP, "config", "app_config.json"))))
    cfg["_path"] = os.path.join(root, "app_config.json")
    cfg["llm"].update(base_url="http://127.0.0.1:9", api_key_env="FUZZ_NO_SUCH_KEY", backend="http")
    cfg["agentic"].update(runtime="standin", web=False)
    config_api.save_config = lambda c: None
    from api import hier_api
    hier_api.ENV_FILE = os.path.join(root, "env")      # the model page saves a key to this private file; a test must never reach the real one (found 2026-11-10: junk lines were added to it)
    family1.knowledge_dir = lambda: os.path.join(root, "knowledge")
    global REAL_KICK
    if REAL_KICK is None:
        REAL_KICK = core.Engine.kick                     # the engine's own start, kept the first time: a later test that runs flows puts it back with F.REAL_KICK
    core.Engine.kick = lambda self, rid: None
    os.makedirs(os.path.join(root, "knowledge"), exist_ok=True)
    os.makedirs(os.path.join(root, "config"), exist_ok=True)
    shutil.copy(os.path.join(APP, "config", "app_config.json"), os.path.join(root, "config", "app_config.json"))
    from server import create_app
    app = create_app(cfg, root)
    app.config["PROPAGATE_EXCEPTIONS"] = False
    app.logger.disabled = True
    from flask import got_request_exception
    got_request_exception.connect(_where, app, weak=False)
    uid = "up-fuzz"
    d = os.path.join(root, "uploads", uid)
    os.makedirs(d)
    files = {k: os.path.join(BASE, n) for k, n in NAMES.items()}
    db = os.path.join(d, "hier.sqlite")
    L.load_upload(db, files)
    B.build(db)
    RL.apply(db)
    json.dump({"upload_id": uid, "created": time.time(), "operator": "fuzz", "device": "D", "trace_name": uid, "recording_date": "", "notes": "", "files": files, "status": "loaded", "thresholds": {}, "file_stats": {}},
              open(os.path.join(d, "meta.json"), "w"))
    c = app.test_client()
    p = c.post("/api/agents/projects", json={"admin": "fuzz", "name": "fuzz project", "folder": BASE}).get_json() or {}
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    fid = con.execute("SELECT id FROM finding LIMIT 1").fetchone()[0]
    con.close()
    SEEDED_IDS.update(uid=uid, fid=fid, project=p.get("id", 1))
    keys = set()
    for f in os.listdir(os.path.join(APP, "app", "api")):
        if f.endswith(".py"):
            keys |= set(re.findall(r"""(?:body|args|request\.args|data)\.get\(["']([A-Za-z_]+)["']""", open(os.path.join(APP, "app", "api", f)).read()))
    routes = []
    for rule in app.url_map.iter_rules():
        if rule.endpoint == "static":
            continue
        if any(x in rule.rule for x in ("/shutdown", "/events", "/stream", "/samples/generate")):      # the generator runs for minutes by design; its arguments are tested apart
            continue
        routes.append((rule.rule, sorted(m for m in rule.methods if m not in ("HEAD", "OPTIONS"))))
    return app, c, sorted(keys), routes


def fill(rule, r):
    def arg(m):
        name = m.group(2)
        kind = m.group(1) or ""
        good = {"uid": SEEDED_IDS["uid"], "fid": SEEDED_IDS["fid"], "pid": SEEDED_IDS["project"], "rid": "read_pattern", "sec": "analytics", "section": "analytics", "lvl": "nvme_command", "level": "nvme_command"}
        if r.random() < 0.6 and name in good:
            return str(good[name])
        if "int" in kind:
            return r.choice(["0", "1", "999999", str(2 ** 40)])
        return r.choice(["nope", "..", "%2e%2e", "up-fuzz", "analytics", "errors", "a b", "x" * 300, "'"])
    return re.sub(r"<(?:([a-z]+):)?([a-zA-Z_]+)>", arg, rule)


def attack_api(c, keys, routes, r, n=30):
    bad = []
    for _ in range(n):
        rule, methods = r.choice(routes)
        if not methods:
            continue
        m = r.choice(methods)
        url = fill(rule, r)
        q = {r.choice(keys): str(r.choice(EVIL_ANY)) for _ in range(r.randint(0, 3))}
        kw = {}
        if m in ("POST", "PUT", "PATCH", "DELETE"):
            shape = r.random()
            if shape < 0.12:
                kw = {"data": b"{ this is not json", "content_type": "application/json"}
            elif shape < 0.24:
                kw = {"json": r.choice(EVIL_ANY)}
            else:
                kw = {"json": {r.choice(keys): r.choice(EVIL_ANY) for _ in range(r.randint(0, 8))}}
        signal.alarm(25)
        LAST_ERROR[0] = None
        try:
            resp = c.open(url, method=m, query_string=q, **kw)
            code = resp.status_code
            detail = LAST_ERROR[0] or resp.get_data()[:160].decode("utf-8", "replace")
        except Hang:
            code, detail = 599, "no answer in 25 s"
        except Exception as e:              # noqa: BLE001 - the attack is on exactly this
            code, detail = 598, "%s: %s" % (type(e).__name__, str(e)[:120])
        finally:
            signal.alarm(0)
        if code >= 500:
            bad.append("%s %s -> %d %s" % (m, rule, code, detail.replace("\n", " ")))
    return bad


def corrupted_set(root, seed, r, how):
    d = os.path.join(root, "c%d" % seed)
    os.makedirs(d)
    expected = {}
    for key, name in NAMES.items():
        with open(os.path.join(BASE, name), encoding="utf-8-sig", newline="") as fh:
            rd = csv.reader(fh)
            head = next(rd)
            rows = [x for x in rd if any(c.strip() for c in x)]
        if how == "cells":
            cols = [head.index(n) for n, _s, _f in L.KEYS.get(key, []) if n in head] or [0]
            for _ in range(r.randint(5, 60)):
                row = r.choice(rows)
                i = r.choice(cols)
                if i < len(row):
                    row[i] = r.choice(EVIL_CELL).replace("\x00", "")
        else:
            kind = r.choice(["shuffle", "repeat", "drop", "reverse"])
            if kind == "shuffle":
                r.shuffle(rows)
            elif kind == "repeat":
                rows = rows + [list(r.choice(rows)) for _ in range(r.randint(1, 40))]
            elif kind == "drop":
                rows = [x for x in rows if r.random() > 0.1]
            else:
                rows = rows[::-1]
        with open(os.path.join(d, name), "w", encoding="utf-8", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(head)
            w.writerows(rows)
        expected[key] = sum(1 for x in rows if any(c.strip() for c in x))
    return d, expected


def attack_files(root, seed, r, how):
    d, expected = corrupted_set(root, seed, r, how)
    db = os.path.join(d, "h.sqlite")
    files = {k: os.path.join(d, n) for k, n in NAMES.items()}
    bad = []
    L.load_upload(db, files)
    B.build(db)
    RL.apply(db)
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    for key, t in (("packets", "pkt"), ("link", "lnk"), ("split", "spl"), ("nvme_transaction", "ntx"), ("nvme_command", "cmd")):
        n = con.execute("SELECT COUNT(*) FROM %s" % t).fetchone()[0]
        if n != expected[key]:
            bad.append("%s holds %d rows, the file has %d" % (t, n, expected[key]))
    for rule, n in con.execute("SELECT rule, COUNT(*) FROM finding GROUP BY rule"):
        if n < 0:
            bad.append("impossible count for %s" % rule)
    con.close()
    shutil.rmtree(d, ignore_errors=True)
    return bad


def attack_script(root, seed, r):
    d = os.path.join(root, "s%d" % seed)
    os.makedirs(d)
    mark = os.path.join(d, "RAN")
    payload = 'x"""\nopen(%r, "w").write("x")\n"""' % mark
    words = [payload, payload.replace('"""', "'''"), "\\", "\n", '"""', "{}", "{0}", "{x}", "%s", "\r\n# comment", "\u6d4b"]
    w = lambda: r.choice(words) + r.choice(words)           # noqa: E731
    steps = [{"step": 1, "command": "Write", "admin": False, "parameters": {"slba": 0, "nlb": 7}, "gap_us": 1, "position": "above", "expected": w(), "why": [w()]},
             {"step": 2, "command": "Read", "admin": False, "parameters": {"slba": 8, "nlb": 7}, "gap_us": 1, "position": "fault", "expected": w()}]
    rule = r.choice(["cmd.timeout", "cmd.read_failure", "cmd.status_error", "cmd.incomplete", w()])
    finding = {"rule": rule, "level": "nvme_command", "id": 1, "name": w(), "detail": {"SCT": 2, "SC": 129}, "limit_ps": 10 ** 12}
    outcome = {"observed": w(), "verified_by": w(), "expected": {"status": w(), "description": w(), "check": w()}}
    after = [{"step": 2, "command": "Read", "status": w(), "check": w(), "timing_us": 100, "success": True}]
    text = TC.generate(finding, steps, {"display": w()}, w(), "up", version=1, device=w(), firmware=w(), nsid=1, name="t.py", outcome=outcome, limit_us=100, expected_after=after)
    p = os.path.join(d, "test_x.py")
    open(p, "w").write(text)
    bad = []
    try:
        compile(text, p, "exec")
    except SyntaxError as e:
        bad.append("the file does not compile: %s (line %s)" % (e.msg, e.lineno))
    else:
        out = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", p], capture_output=True, text=True, cwd=d, timeout=60, env=dict(os.environ, NVME_DEV="/dev/nvme-absent"))
        if os.path.exists(mark):
            bad.append("words from a recording ran as code")
        if "skipped" not in out.stdout:
            bad.append("the file does not skip cleanly without a drive: %s" % out.stdout.strip()[-160:])
    shutil.rmtree(d, ignore_errors=True)
    return bad


EVIL_CODE = ["import os\ndef run(sources, out_csv):\n    os.remove('/x')\n",
             "def run(sources, out_csv):\n    __import__('os').system('id')\n",
             "def run(sources, out_csv):\n    eval('1')\n",
             "def run(sources, out_csv):\n    open('/tmp/evil', 'w').write('x')\n",
             "def run(sources, out_csv):\n    with open('/etc/passwd', 'a') as f:\n        pass\n",
             "def run(sources, out_csv):\n    ().__class__.__base__.__subclasses__()\n",
             "def run(sources, out_csv):\n    globals()['__builtins__']\n",
             "def run(sources, out_csv):\n    getattr(__builtins__, 'ev' + 'al')('1')\n",
             "from importlib import import_module\ndef run(sources, out_csv):\n    import_module('os')\n",
             "def run(sources, out_csv):\n    f = open\n    f('/tmp/evil', 'w')\n",
             "def run(sources, out_csv):\n    breakpoint()\n",
             "import csv\ndef run(sources, out_csv):\n    csv.__dict__['sys']\n",
             "import sys\ndef run(sources, out_csv):\n    sys.modules['os']\n"]
GOOD_CODE = "import csv\ndef run(sources, out_csv):\n    with open(sources['nvme_command.csv'], newline='') as f, open(out_csv, 'w', newline='') as o:\n        w = csv.writer(o)\n        for row in csv.reader(f):\n            w.writerow(row[:1])\n"


def attack_code(r):
    from agentic import procedures as PR
    bad = []
    for code in EVIL_CODE:
        if not PR.check_code(code):
            bad.append("the code check let this through: %r" % code[:90])
    probs = PR.check_code(GOOD_CODE)
    if probs:
        bad.append("the code check refused honest code: %s" % probs)
    return bad


def attack_page(r):
    js = open(os.path.join(APP, "app", "static", "js", "agents.js"), encoding="utf-8").read()
    esc_line = next(x for x in js.splitlines() if x.startswith("const esc ="))
    start = js.index("function md(text) {")
    depth, i, seen = 0, start, False
    while True:
        if js[i] == "{":
            depth, seen = depth + 1, True
        elif js[i] == "}":
            depth -= 1
        i += 1
        if seen and depth == 0:
            break
    bits = ["<script>alert(1)</script>", "<img src=x onerror=alert(1)>", "[a](javascript:alert(1))", "**<b>x</b>**", "`<svg onload=alert(1)>`", "| <i>a</i> | b |\n|---|---|\n| <script>x</script> | c |", "# <u>t</u>", "- <a href=\"x\">y</a>", "[a](\"onmouseover=alert(1))", "\"><script>x</script>"]
    text = "\n".join(r.choice(bits) for _ in range(r.randint(1, 8)))
    node = "%s\n%s\nconsole.log(md(%s));" % (esc_line, js[start:i], json.dumps(text))
    out = subprocess.run(["node", "-e", node], capture_output=True, text=True, timeout=30)
    if out.returncode:
        return ["the page's renderer failed: %s" % out.stderr.strip()[-200:]]
    html = out.stdout
    bad = []
    for pat, what in ((r"<script", "a script tag"), (r"<img", "an image tag"), (r"<svg", "an svg tag"), (r"<[a-z]+[^>]*\son[a-z]+=", "an event handler"), (r"""href=["']?\s*javascript:""", "a script link"), (r"<b>x</b>", "raw markup")):
        if re.search(pat, html, re.I):
            bad.append("hostile words became %s: %s" % (what, html[:200]))
    return bad


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 200
    first = int(sys.argv[2]) if len(sys.argv) > 2 else 7000
    signal.signal(signal.SIGALRM, _alarm)
    root = tempfile.mkdtemp(prefix="fuzz_app_%d_" % os.getpid())
    t0 = time.time()
    app, c, keys, routes = setup(root)
    print("%d routes, %d parameter names" % (len(routes), len(keys)), flush=True)
    classes = ["api"] * 8 + ["cells"] * 5 + ["rows"] * 3 + ["script"] * 2 + ["code"] + ["page"]
    seen, counts, crashes = collections.Counter(), collections.Counter(), []
    for seed in range(first, first + n):
        r = random.Random(seed)
        kind = ONLY or classes[(seed - first) % len(classes)]
        counts[kind] += 1
        try:
            bad = {"api": lambda: attack_api(c, keys, routes, r), "cells": lambda: attack_files(root, seed, r, "cells"), "rows": lambda: attack_files(root, seed, r, "rows"),
                   "script": lambda: attack_script(root, seed, r), "code": lambda: attack_code(r), "page": lambda: attack_page(r)}[kind]()
        except Exception as e:           # noqa: BLE001
            tb = traceback.format_exc().strip().splitlines()
            where = next((x.strip() for x in reversed(tb) if APP in x and "tests/" not in x), tb[-3] if len(tb) > 2 else "")
            bad = ["%s %s %s" % (type(e).__name__, str(e)[:130], where[-90:])]
            crashes.append(seed)
        for b in bad:
            key = re.sub(r"0x[0-9a-f]+|\d{4,}", "#", b)[:170]
            if key not in seen:
                print("[%s seed %d] %s" % (kind, seed, b[:420]), flush=True)
            seen[key] += 1
    summary = {"iterations": n, "first_seed": first, "by_class": dict(counts), "distinct_problems": len(seen), "problems": seen.most_common(60), "crashes": crashes[:30], "seconds": round(time.time() - t0)}
    keep = os.path.join(APP, "runs", "kpi_proof")
    os.makedirs(keep, exist_ok=True)
    json.dump(summary, open(os.path.join(keep, "fuzz_app_%d.json" % first), "w"), indent=1)
    shutil.rmtree(root, ignore_errors=True)
    print("\n%d iterations %s: %d distinct problems, %d crashes; %d s" % (n, dict(counts), len(seen), len(crashes), summary["seconds"]), flush=True)
    return 1 if seen else 0


def _run_clean():
    """Whatever happens to the run (a crash, Ctrl-C, a stop), its temporary folder goes away: a stopped run must not fill the machine."""
    import atexit
    before = set(os.listdir(tempfile.gettempdir()))

    def tidy(*_a):
        for name in set(os.listdir(tempfile.gettempdir())) - before:
            if name.startswith("fuzz_app_%d_" % os.getpid()):       # only its own: two runs at once share the temporary folder (found 2026-11-10)
                shutil.rmtree(os.path.join(tempfile.gettempdir(), name), ignore_errors=True)
    atexit.register(tidy)
    signal.signal(signal.SIGTERM, lambda *_a: sys.exit(143))
    return main()


if __name__ == "__main__":
    sys.exit(_run_clean())
