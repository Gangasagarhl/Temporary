"""Round 5 of the attacks (owner, 2026-11-09: "try to break the application ... if there is any inefficiency, fix it"): a torn record, a crash in the
middle of a write, a Coder's code that prints, eats memory or fills the disk, and a recording id that tries to leave the uploads folder.

    python3 -m pytest -q tests/test_limits.py
"""
import json
import os
import stat
import sys
import threading
import time

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
sys.path.insert(0, os.path.join(APP, "app"))
from agentic import procedures as PR  # noqa: E402
from api import hier_api as H  # noqa: E402
from nvme_hier import loader as L  # noqa: E402


# ---- a record is whole or it is the old one
def test_a_reader_never_sees_half_a_record(tmp_path):
    d = str(tmp_path)
    big = {"upload_id": "u", "status": "loaded", "files": {"f%d" % i: "x" * 200 for i in range(3000)}}
    H.write_meta(d, big)
    stop, torn = threading.Event(), []

    def reader():
        while not stop.is_set():
            m = H.read_meta(d)
            if m is None or m.get("status") != "loaded" or len(m.get("files", {})) != 3000:
                torn.append(m)
    t = threading.Thread(target=reader)
    t.start()
    try:
        for i in range(150):
            H.write_meta(d, dict(big, n=i))
    finally:
        stop.set()
        t.join()
    assert not torn, "a reader saw half a record %d times" % len(torn)


def test_a_crash_during_a_write_leaves_the_old_file(tmp_path, monkeypatch):
    p = str(tmp_path / "config.json")
    L.write_json_atomic(p, {"v": 1})

    def boom(_fd):
        raise OSError("the disk went away")
    monkeypatch.setattr(os, "fsync", boom)
    with pytest.raises(OSError):
        L.write_json_atomic(p, {"v": 2})
    monkeypatch.undo()
    assert json.load(open(p)) == {"v": 1}
    assert os.listdir(str(tmp_path)) == ["config.json"], "the half-written file was left behind"


def test_a_private_file_stays_private(tmp_path):
    p = str(tmp_path / "secret.json")
    L.write_json_atomic(p, {"v": 1})
    os.chmod(p, 0o600)
    L.write_json_atomic(p, {"v": 2})
    assert stat.S_IMODE(os.stat(p).st_mode) == 0o600


def test_a_leftover_is_not_counted_as_a_version(tmp_path):
    """A version number is 1 + the files that start with "<name>.v": a crash's leftover must not look like one."""
    folder = tmp_path
    L.write_json_atomic(str(folder / "packets.v1.json"), {"v": 1})
    (folder / (".packets.v2.json.1.2.tmp")).write_text("half")
    assert len([x for x in os.listdir(str(folder)) if x.startswith("packets.v")]) == 1


# ---- a Coder's code cannot hurt the machine
def _run(tmp_path, body, sources=None, timeout=60):
    src = tmp_path / "in.csv"
    src.write_text("a,b\n1,2\n")
    code = tmp_path / "code.py"
    code.write_text("def run(sources, out_csv):\n" + "".join("    %s\n" % x for x in body.splitlines()) + "    return {}\n")
    return PR.run_code(str(code), sources or {"in.csv": str(src)}, str(tmp_path / "out.csv"), str(tmp_path / "box"), timeout=timeout)


def test_code_that_prints_for_ever_is_stopped(tmp_path):
    t0 = time.time()
    r = _run(tmp_path, "while True:\n    print('x' * 8000)", timeout=45)
    assert r["ok"] is False and "printed more than" in r["error"], r
    assert time.time() - t0 < 30
    assert os.path.getsize(str(tmp_path / "box" / "stdout.txt")) < 3 * 1024 ** 3


def test_code_that_loads_everything_in_memory_gets_a_plain_message(tmp_path):
    r = _run(tmp_path, "x = bytearray(40 * 1024 ** 3)", timeout=45)
    assert r["ok"] is False and "memory" in r["error"] and "line by line" in r["error"], r


def test_code_that_fills_the_disk_is_stopped(tmp_path, monkeypatch):
    monkeypatch.setattr(PR, "RUN_MIN_FILE_BYTES", 2 * 1024 ** 2)
    r = _run(tmp_path, "f = open(out_csv, 'w')\nwhile True:\n    f.write('y' * 65536)\n    f.flush()", timeout=45)
    assert r["ok"] is False and "wrote more than" in r["error"], r
    assert os.path.getsize(str(tmp_path / "out.csv")) <= 2 * 1024 ** 2


def test_good_code_still_runs_and_its_result_is_read(tmp_path):
    r = _run(tmp_path, "open(out_csv, 'w').write('a\\n1\\n')\nprint('noise')")
    assert r["ok"] is True and r["summary"] == {}, r


def test_the_tail_of_a_huge_file_costs_only_the_tail(tmp_path):
    p = tmp_path / "big.txt"
    with open(str(p), "wb") as fh:
        fh.write(b"a" * (50 * 1024 ** 2))
        fh.write(b"\nlast line")
    t = PR._tail(str(p), 4096)
    assert len(t) == 4096 and t.endswith("last line")


# ---- an id from a request stays inside the uploads folder
@pytest.mark.parametrize("bad", ["", None, 7, [], "..", "../..", "../../etc", "/etc", "a/b", "a\\b", "a\0b", ".hidden", "..a"])
def test_a_bad_recording_id_leaves_nothing_to_open(bad):
    assert PR.upload_folder(bad) is None
    assert PR.source_paths(bad) == {}


def test_the_recording_is_found_in_the_applications_own_folder(tmp_path):
    keep = PR._UPLOADS[0]
    try:
        PR.use_uploads_folder(str(tmp_path))
        d = tmp_path / "up-1"
        d.mkdir()
        H.write_meta(str(d), {"files": {"packets": "/x/packets.csv"}})
        assert PR.source_paths("up-1") == {"packets.csv": "/x/packets.csv"}
    finally:
        PR.use_uploads_folder(keep)


# ---- files of 5, 6, 7, 8 GB (owner, 2026-11-09): what goes wrong with a big file is a file that is one long line, a stray quote, or a machine short of memory or disk
def _load_in_a_small_box(tmp_path, body, memory_mb=400):
    """A load in its own process with its memory capped: going over the cap would end it with MemoryError, not with the plain message."""
    script = tmp_path / "box.py"
    script.write_text("import resource, sys\nsys.path.insert(0, %r)\nresource.setrlimit(resource.RLIMIT_AS, (%d, %d))\nfrom nvme_hier import loader as L\n" % (APP, memory_mb * 1024 ** 2, memory_mb * 1024 ** 2) + body)
    import subprocess
    return subprocess.run([sys.executable, str(script)], capture_output=True, text=True, timeout=120)


def _huge(path, mb, chunk):
    with open(str(path), "wb") as fh:
        for _ in range(mb):
            fh.write(chunk * (1024 ** 2 // len(chunk)))


def test_a_file_with_no_line_ends_is_refused_without_filling_the_memory(tmp_path):
    p = tmp_path / "packets.csv"
    _huge(p, 200, b"x" * 1024)                 # one line of 200 MB, read under a memory cap
    r = _load_in_a_small_box(tmp_path, "try:\n    L.sniff(%r)\nexcept L.BadFile as e:\n    print('REFUSED', e)\n" % str(p), memory_mb=512)
    assert "REFUSED" in r.stdout and "longer than" in r.stdout, r.stdout + r.stderr[-800:]


def test_planning_the_chunks_of_a_file_with_no_line_ends(tmp_path):
    p = tmp_path / "packets.csv"
    _huge(p, 200, b"x" * 1024)
    with pytest.raises(L.BadFile, match="longer than"):
        L.plan_chunks(str(p), 0)


def test_a_stray_quote_costs_one_chunk_and_no_quadratic_reading(tmp_path, monkeypatch):
    """Before: the chunk was read again for every line while the quote count stayed odd, and the whole rest of the file became one chunk."""
    p = tmp_path / "packets.csv"
    line = b"1,2,3," + b"a" * 100 + b"\n"
    with open(str(p), "wb") as fh:
        fh.write(b'h1,h2\n"stray quote,2\n')
        for _ in range(60):
            fh.write(line * (1024 ** 2 // len(line)))
    monkeypatch.setattr(L, "MAX_CHUNK_BYTES", 8 * 1024 ** 2)
    t0 = time.time()
    chunks = L.plan_chunks(str(p), 6, chunk_bytes=2 * 1024 ** 2)
    assert time.time() - t0 < 10
    assert max(b - a for a, b in chunks) <= 8 * 1024 ** 2 + 4096
    assert chunks[-1][1] == os.path.getsize(str(p)) and all(chunks[i][1] == chunks[i + 1][0] for i in range(len(chunks) - 1))


def test_chunks_of_a_normal_file_are_the_same_as_before(tmp_path):
    """Quoted cells with line ends inside must still stay in one chunk."""
    p = tmp_path / "x.csv"
    with open(str(p), "wb") as fh:
        for i in range(40000):
            fh.write(b'%d,"cell with\nline end",%d\n' % (i, i))
    chunks = L.plan_chunks(str(p), 0, chunk_bytes=64 * 1024)
    import csv
    import io
    total = 0
    for a, b in chunks:
        with open(str(p), "rb") as fh:
            fh.seek(a)
            rows = list(csv.reader(io.StringIO(fh.read(b - a).decode(), newline="")))
        assert all(len(r) == 3 for r in rows)
        total += len(rows)
    assert total == 40000


def test_a_load_refuses_to_start_without_disk_space(tmp_path, monkeypatch):
    class U:
        free = 10 * 1024 ** 3
    monkeypatch.setattr(L.shutil, "disk_usage", lambda p: U)
    text = L.room_problem(8 * 1024 ** 3, str(tmp_path))
    assert text and "free disk" in text and "32.0 GB" in text
    assert L.room_problem(1024 ** 3, str(tmp_path)) is None


def test_a_load_refuses_to_start_without_memory(tmp_path, monkeypatch):
    monkeypatch.setattr(L, "memory_available", lambda: 200 * 1024 ** 2)
    assert "memory" in L.room_problem(1024, str(tmp_path))


def test_fewer_workers_when_memory_is_short(monkeypatch):
    monkeypatch.setattr(L, "WORKERS", None)
    monkeypatch.delenv("F2T_WORKERS", raising=False)
    monkeypatch.setattr(L, "memory_available", lambda: 1024 ** 3 + 300 * 1024 ** 2)
    assert L.worker_count() == 1
    monkeypatch.setattr(L, "memory_available", lambda: 1024 ** 2)
    assert L.worker_count() == 1


def test_the_guard_stops_on_a_real_shortage_and_not_on_one_dip(tmp_path, monkeypatch):
    g = L.RoomGuard(str(tmp_path), memory_floor=1000)
    values = iter([500, 5000, 500, 500])
    monkeypatch.setattr(L, "memory_available", lambda: next(values))
    g.look()
    g.look()
    g.look()
    assert g.why is None, "one low look stopped the load"
    g.look()
    assert "memory" in g.why
    with pytest.raises(L.NoRoom):
        g.check()


def test_the_guard_stops_when_the_disk_fills(tmp_path, monkeypatch):
    class U:
        free = 100
    g = L.RoomGuard(str(tmp_path))
    monkeypatch.setattr(L, "memory_available", lambda: 10 ** 12)
    monkeypatch.setattr(L.shutil, "disk_usage", lambda p: U)
    g.look()
    assert "disk" in g.why


def test_a_running_statement_is_stopped_when_the_machine_runs_out(tmp_path):
    import sqlite3
    con = sqlite3.connect(str(tmp_path / "x.db"))
    g = L.RoomGuard(str(tmp_path))
    L._GUARDS.add(g)
    end = L.heartbeat(con, lambda s: None, every=0.2)
    try:
        g.why = "no room"
        with pytest.raises(sqlite3.OperationalError, match="interrupted"):
            con.execute("WITH RECURSIVE c(x) AS (SELECT 1 UNION ALL SELECT x + 1 FROM c) SELECT COUNT(*) FROM c").fetchall()
    finally:
        end()
        L._GUARDS.discard(g)
        con.close()


# ---- one name, one meaning (the 200-attack run: `NM`, the refusal's words, was overwritten by a module of the same name, so a bad number crashed the page instead of being refused)
def test_no_module_level_name_means_two_different_things():
    import ast
    import glob
    clashes = []
    for d in ("app", "nvme_hier", "agentic"):
        for f in glob.glob(os.path.join(APP, d, "**", "*.py"), recursive=True):
            with open(f, encoding="utf-8") as fh:
                tree = ast.parse(fh.read())
            bound = {}
            for n in tree.body:
                if not isinstance(n, ast.ImportFrom):
                    continue
                for a in n.names:
                    name, source = a.asname or a.name, "%s.%s" % (n.module or "", a.name)
                    if bound.get(name, source) != source:
                        clashes.append("%s: %s is both %s and %s" % (os.path.relpath(f, APP), name, bound[name], source))
                    bound[name] = source
    assert not clashes, clashes


def test_a_bad_number_is_refused_in_words_on_every_window_route():
    import flask
    app = flask.Flask(__name__)
    from api import whole
    for bad in ("x" * 900, [1], {"a": 1}, 1.5e400):
        with app.test_request_context("/"):
            with pytest.raises(Exception) as e:
                whole(bad, message=H.NM)
        assert e.value.code == 400 and e.value.description == "n and m must be whole numbers"


# ---- one folder, one recording (found 2026-11-10: a second packets file silently replaced the first, joining two recordings)
def _folder_with(tmp_path, names):
    src = os.path.join(APP, "samples", "clean_five_files", "demo_225_commands")
    if not os.path.isdir(src):
        pytest.skip("the sample recordings are not in this copy of the application")
    d = tmp_path / "rec"
    d.mkdir()
    for target, source in names.items():
        if source is None:
            (d / target).write_text("a,b\n1,2\n")
        else:
            (d / target).write_bytes(open(os.path.join(src, source), "rb").read())
    return str(d)


FIVE = {n: n for n in ("packets.csv", "link.csv", "split.csv", "NVME_Transactions.csv", "nvme_command.csv")}


def test_a_folder_with_one_recording_is_accepted(tmp_path):
    from agentic import family1
    assert family1.folder_problem(family1.inventory(_folder_with(tmp_path, FIVE))) is None


def test_a_csv_of_another_kind_beside_the_recording_is_accepted(tmp_path):
    from agentic import family1
    assert family1.folder_problem(family1.inventory(_folder_with(tmp_path, dict(FIVE, **{"notes.csv": None})))) is None


def test_two_files_of_one_kind_are_refused_by_name(tmp_path):
    from agentic import family1
    why = family1.folder_problem(family1.inventory(_folder_with(tmp_path, dict(FIVE, **{"run2_packets.csv": "packets.csv"}))))
    assert why and "packets.csv" in why and "run2_packets.csv" in why and "one recording" in why


def test_a_folder_with_none_of_the_five_kinds_is_refused(tmp_path):
    from agentic import family1
    why = family1.folder_problem(family1.inventory(_folder_with(tmp_path, {"notes.csv": None})))
    assert why and "five kinds" in why
