#!/usr/bin/env python3
"""Twenty ways to break the application that the random attacks do not reach (owner, 2026-11-09).

    python3 tests/attack_round3.py

Files outside the application, saved data that is corrupted, runaway code from an agent, two people pressing at the same moment, a full disk, a binary file passed off as a
CSV. A throw-away root, as tests/fuzz_app.py: nothing of the admin's is read or written and no model is called. Each attack says what a correct system must do.
"""
import json
import os
import random
import shutil
import sqlite3
import sys
import tempfile
import threading
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import fuzz_app as F  # noqa: E402  (sets up the import paths)
from nvme_hier import builder as B, loader as L, rules as RL, store as ST  # noqa: E402

RESULTS = []


def attack(n, title):
    def wrap(fn):
        def run(ctx):
            t0 = time.time()
            try:
                problems = fn(ctx) or []
            except Exception as e:          # noqa: BLE001
                tb = traceback.extract_tb(e.__traceback__)
                f = next((x for x in reversed(tb) if APP in x.filename and "tests/" not in x.filename), tb[-1])
                problems = ["crashed: %s: %s at %s:%d" % (type(e).__name__, str(e)[:120], os.path.basename(f.filename), f.lineno)]
            RESULTS.append((n, title, problems))
            print("%s %2d  %s  (%.1f s)%s" % ("FAIL" if problems else "PASS", n, title, time.time() - t0, "".join("\n        - " + p[:300] for p in problems)), flush=True)
        ATTACKS.append(run)
        return run
    return wrap


ATTACKS = []


def code(r):
    return r.status_code


@attack(1, "a JSON body nested 200,000 deep is refused, not a crash")
def a1(x):
    r = x.c.post("/api/agents/projects", data=b"[" * 200000 + b"]" * 200000, content_type="application/json")
    return [] if code(r) == 400 else ["answered %d" % code(r)]


@attack(2, "a 60 MB request body does not take the server down")
def a2(x):
    r = x.c.post("/api/agents/projects", data=b'{"name":"' + b"x" * 60000000 + b'"}', content_type="application/json")
    return [] if code(r) in (400, 413) else ["answered %d" % code(r)]


SECRET = "root:x:0:0"


@attack(3, "no route hands out a file outside its own folder (absolute paths, .. and encoded ..)")
def a3(x):
    bad = []
    uid = F.SEEDED_IDS["uid"]
    for url in ("/api/agents/file?path=/etc/passwd", "/api/agents/file?path=../../../../../../etc/passwd", "/api/suite/x/..%2f..%2f..%2f..%2f..%2fetc%2fpasswd", "/api/suite/..%2f..%2f..%2f..%2fetc/passwd",
                "/api/runs/nope/file?path=../../../../etc/passwd", "/api/runs/%s/file?path=/etc/passwd" % uid, "/static/..%2f..%2f..%2f..%2fetc%2fpasswd", "/api/hier/uploads/..%2f..%2f..%2fetc/findings"):
        r = x.c.get(url)
        if SECRET in r.get_data()[:5000].decode("latin1"):
            bad.append("%s gave /etc/passwd" % url)
        if code(r) >= 500:
            bad.append("%s answered %d" % (url, code(r)))
    return bad


@attack(4, "a link planted inside an allowed folder cannot reach outside it")
def a4(x):
    bad = []
    from agentic import family1
    ex = os.path.join(family1.knowledge_dir(), "exports")
    os.makedirs(ex, exist_ok=True)
    os.symlink("/etc/passwd", os.path.join(ex, "link.csv"))
    r = x.c.get("/api/agents/file", query_string={"path": os.path.join(ex, "link.csv")})
    if SECRET in r.get_data()[:5000].decode("latin1"):
        bad.append("the file route followed a link to /etc/passwd")
    sd = os.path.join(x.root, "suite", "t1")
    os.makedirs(sd, exist_ok=True)
    os.symlink("/etc/passwd", os.path.join(sd, "link.txt"))
    r = x.c.get("/api/suite/t1/link.txt")
    if SECRET in r.get_data()[:5000].decode("latin1"):
        bad.append("the suite route followed a link to /etc/passwd")
    return bad


def _rule_file(section="analytics", level="nvme_command", name="broken"):
    from agentic import family3
    d = os.path.join(family3.rules_root(), section, level)
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, name + ".json")


@attack(5, "one corrupted rule file does not take the rules page down")
def a5(x):
    x.c.get("/api/agents/rules")
    p = _rule_file()
    open(p, "w").write('{"id": "broken", "name": ')
    r = x.c.get("/api/agents/rules")
    bad = [] if code(r) == 200 else ["the rules page answered %d" % code(r)]
    r = x.c.get("/api/agents/rules/analytics/nvme_command/broken/explain")
    if code(r) >= 500:
        bad.append("opening the broken rule answered %d" % code(r))
    os.remove(p)
    return bad


@attack(6, "a corrupted list of deleted items does not take the rules page down")
def a6(x):
    from agentic import family3
    p = family3.deleted_file()
    keep = open(p).read() if os.path.exists(p) else None
    open(p, "w").write("[{]")
    r = x.c.get("/api/agents/rules")
    r2 = x.c.get("/api/agents/rules/deleted")
    if keep is not None:
        open(p, "w").write(keep)
    else:
        os.remove(p)
    return ["answered %d and %d" % (code(r), code(r2))] if code(r) >= 500 or code(r2) >= 500 else []


def _broken_upload(root, uid, meta=None, db=None):
    d = os.path.join(root, "uploads", uid)
    os.makedirs(d, exist_ok=True)
    if meta is not None:
        open(os.path.join(d, "meta.json"), "w").write(meta)
    if db is not None:
        open(os.path.join(d, "hier.sqlite"), "wb").write(db)
    return d


BROWSE = ("/findings", "/summary", "/tree", "/thresholds", "/timing_limits", "/defect_table", "/findings/1", "/export_tree.zip")


@attack(7, "an upload with a corrupted meta file does not break the list of uploads or its own pages")
def a7(x):
    _broken_upload(x.root, "up-badmeta", meta='{"upload_id": ', db=b"")
    bad = []
    r = x.c.get("/api/hier/uploads")
    if code(r) >= 500:
        bad.append("the list answered %d" % code(r))
    for p in BROWSE:
        r = x.c.get("/api/hier/uploads/up-badmeta" + p)
        if code(r) >= 500:
            bad.append("%s answered %d %s" % (p, code(r), F.LAST_ERROR[0]))
    return bad


@attack(8, "a database file full of garbage is reported, not a crash")
def a8(x):
    _broken_upload(x.root, "up-garbage", meta=json.dumps({"upload_id": "up-garbage", "status": "loaded", "files": {}, "thresholds": {}}), db=os.urandom(70000))
    bad = []
    for p in BROWSE:
        F.LAST_ERROR[0] = None
        r = x.c.get("/api/hier/uploads/up-garbage" + p)
        if code(r) >= 500:
            bad.append("%s answered %d %s" % (p, code(r), F.LAST_ERROR[0]))
    return bad


@attack(9, "an empty database (no tables) is reported, not a crash")
def a9(x):
    d = _broken_upload(x.root, "up-empty", meta=json.dumps({"upload_id": "up-empty", "status": "loaded", "files": {}, "thresholds": {}}))
    sqlite3.connect(os.path.join(d, "hier.sqlite")).close()
    bad = []
    for p in BROWSE:
        F.LAST_ERROR[0] = None
        r = x.c.get("/api/hier/uploads/up-empty" + p)
        if code(r) >= 500:
            bad.append("%s answered %d %s" % (p, code(r), F.LAST_ERROR[0]))
    return bad


def _sig(k):
    return {"fine": "fine%d" % k, "coarse": "c", "display": "d", "fields": {"lvl": "cmd", "err": "e", "cmd": "io.Write", "cause": "self", "alg": "v1"}}


@attack(10, "a stored procedure whose steps are corrupted does not break its failure")
def a10(x):
    st = ST.Store(os.path.join(x.root, "t10", "db", "k.sqlite"))
    s = _sig(1)
    st.touch_signature(s, "D", upload_id="u", finding_id=1)
    good = [{"step": 1, "command": "Write", "position": "fault"}]
    p = st.signal(s["fine"], None, "correct", "x", proposal_steps=good, proposal_text="t")["new_procedure_id"]
    q = st.add_procedure(s["fine"], good + [{"step": 2, "command": "Flush", "position": "below"}], "t", "x")
    con = sqlite3.connect(st.path)
    con.execute("UPDATE procedure SET steps='{not json' WHERE id=?", (q,))
    con.commit()
    con.close()
    st.graph_sync = None
    c = st.graph_choice(s["fine"])
    return [] if c and c["procedure_id"] == p else ["the policy answered %s" % c]


@attack(11, "a signature with corrupted fields does not stop the search for known failures")
def a11(x):
    st = ST.Store(os.path.join(x.root, "t11", "db", "k.sqlite"))
    good = _sig(1)
    st.touch_signature(good, "D", upload_id="u", finding_id=1)
    st.touch_signature(_sig(2), "D", upload_id="u", finding_id=2)
    con = sqlite3.connect(st.path)
    con.execute("UPDATE signature SET fields='{broken' WHERE fine='fine2'")
    con.commit()
    con.close()
    st.graph_view("fine2")
    st.graph_choice(good)
    st.retrieve(good, "D")
    st.touch_signature(_sig(2), "D", upload_id="u", finding_id=3)
    return []


@attack(12, "a cell that a spreadsheet would run as a formula is neutralised in the exports")
def a12(x):
    import io
    buf = io.StringIO()
    w = L.CsvOut(buf)
    w.writerow(['=HYPERLINK("http://evil","x")', "@SUM(A1)", "+1+1", "-1", "-0.5", "1e5", "plain"])
    out = buf.getvalue()
    bad = [] if out.startswith('"\'=HYPERLINK') and ",'@SUM" in out and ",'+1+1" in out and ",-1,-0.5,1e5,plain" in out else ["got: %s" % out.strip()]
    for f in ("app/api/hier_api.py", "agentic/family3.py", "app/api/agentic_api.py"):
        if "csv.writer(" in open(os.path.join(APP, f)).read().replace("_csv.writer(", "csv.writer("):
            bad.append("%s still writes exports without it" % f)
    return bad


def _agent_code(root, text, timeout):
    from agentic import procedures as PR
    d = os.path.join(root, "code%d" % random.randrange(10 ** 8))
    os.makedirs(d)
    p = os.path.join(d, "c.py")
    open(p, "w").write(text)
    src = os.path.join(d, "a.csv")
    open(src, "w").write("a\n1\n")
    return PR.run_code(p, {"nvme_command.csv": src}, os.path.join(d, "o.csv"), d, timeout=timeout)


@attack(13, "agent code that never ends is stopped by the time limit")
def a13(x):
    t0 = time.time()
    try:
        _agent_code(x.root, "def run(sources, out_csv):\n    while True:\n        pass\n", 3)
    except Exception:           # noqa: BLE001
        pass
    took = time.time() - t0
    return [] if took < 15 else ["it ran %d s against a limit of 3 s" % took]


@attack(14, "agent code that eats memory does not take the machine down")
def a14(x):
    t0 = time.time()
    try:
        _agent_code(x.root, "def run(sources, out_csv):\n    x = []\n    while True:\n        x.append(bytearray(50000000))\n", 20)
    except Exception:           # noqa: BLE001
        pass
    return [] if time.time() - t0 < 40 else ["it ran too long"]


def _review(x):
    eng = x.eng
    pid = SEEDED_PROJECT(x)
    rid = eng.store.exec("INSERT INTO run (project, kind, target, params, state, created, updated) VALUES (?, 'flow', 't', '{}', 'running', 0, 0)", (pid,))
    sid = eng.store.exec("INSERT INTO step (run, idx, key, title, state) VALUES (?, 0, 'note', 'x', 'needs_review')", (rid,))
    return eng.store.exec("INSERT INTO review (run, step, title, body, data, state, created) VALUES (?, ?, 't', 'b', '{}', 'open', 0)", (rid, sid))


def SEEDED_PROJECT(x):
    return F.SEEDED_IDS["project"]


@attack(15, "two people pressing Approve at the same moment count once")
def a15(x):
    rv = _review(x)
    results = []

    def press():
        r = x.app.test_client().post("/api/agents/reviews/%d/decide" % rv, json={"decision": "approve", "admin": "a"})
        results.append(code(r))
    ts = [threading.Thread(target=press) for _ in range(8)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    ok = [c for c in results if c == 200]
    bad = [] if len(ok) == 1 else ["%d presses counted: %s" % (len(ok), results)]
    return bad + ["a press crashed: %s" % results] if any(c >= 500 for c in results) else bad


@attack(16, "two flows started at the same moment on one project start once")
def a16(x):
    d = tempfile.mkdtemp(dir=x.root)
    for n in F.NAMES.values():
        shutil.copy(os.path.join(F.BASE, n), d)
    p = x.c.post("/api/agents/projects", json={"admin": "a", "name": "race", "folder": d}).get_json()
    results = []

    def go():
        r = x.app.test_client().post("/api/agents/projects/%d/flow" % p["id"], json={"admin": "a"})
        results.append(code(r))
    ts = [threading.Thread(target=go) for _ in range(6)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    n = x.eng.store.one("SELECT COUNT(*) AS n FROM run WHERE project=? AND kind='flow'", (p["id"],))["n"]
    bad = [] if n == 1 else ["%d flows started: %s" % (n, results)]
    return bad + ["a start crashed: %s" % results] if any(c >= 500 for c in results) else bad


@attack(17, "a hostile input folder is listed without a crash")
def a17(x):
    from agentic import family1
    d = os.path.join(x.root, "hostile")
    os.makedirs(os.path.join(d, "folder.csv"))
    open(os.path.join(d, "empty.csv"), "w").close()
    open(os.path.join(d, "binary.csv"), "wb").write(os.urandom(300000))
    open(os.path.join(d, "nul.csv"), "wb").write(b"a,b\n\x00\x00,1\n")
    open(os.path.join(d, "name with\nnewline.csv"), "w").write("a,b\n1,2\n")
    os.symlink(os.path.join(d, "missing"), os.path.join(d, "dangling.csv"))
    os.symlink(d, os.path.join(d, "loop.csv"))
    family1.inventory(d)
    r = x.c.post("/api/agents/projects", json={"admin": "a", "name": "hostile", "folder": d})
    return ["creating it answered %d %s" % (code(r), F.LAST_ERROR[0])] if code(r) >= 500 else []


@attack(18, "a binary capture passed off as a CSV gives a reason, not a crash")
def a18(x):
    d = os.path.join(x.root, "pex")
    os.makedirs(d)
    p = os.path.join(d, "packets.csv")
    open(p, "wb").write(b"CATC\x00\x01" + os.urandom(200000))
    db = os.path.join(d, "h.sqlite")
    rep = L.load_upload(db, {"packets": p})
    return [] if isinstance(rep, dict) else ["no report"]


@attack(19, "a 20 MB cell does not stop the load")
def a19(x):
    d = os.path.join(x.root, "wide")
    os.makedirs(d)
    src = os.path.join(F.BASE, F.NAMES["nvme_command"])
    with open(src, encoding="utf-8-sig", newline="") as fh:
        lines = fh.readlines()
    head, row = lines[0], lines[1].rstrip("\r\n")
    p = os.path.join(d, F.NAMES["nvme_command"])
    open(p, "w", encoding="utf-8", newline="").write(head + row[:-1] + "x" * 20000000 + "\n" + "".join(lines[2:6]))
    db = os.path.join(d, "h.sqlite")
    L.load_upload(db, {"nvme_command": p})
    con = sqlite3.connect(db)
    n = con.execute("SELECT COUNT(*) FROM cmd").fetchone()[0]
    con.close()
    return [] if n == 5 else ["%d rows of 5" % n]


@attack(20, "a full disk during the tree build fails with a reason and can be resumed")
def a20(x):
    d = os.path.join(x.root, "full")
    os.makedirs(d)
    from nvme_hier import builder
    real = builder.build
    def full(*a, **k):
        raise sqlite3.OperationalError("database or disk is full")
    builder.build = full
    try:
        r = x.c.post("/api/hier/uploads", json={"files": {k: os.path.join(F.BASE, n) for k, n in F.NAMES.items()}, "operator": "a", "device": "D", "trace_name": "full", "recording_date": ""})
        j = r.get_json() or {}
        if code(r) >= 500:
            return ["starting it answered %d" % code(r)]
        uid, jid = j.get("upload_id") or j.get("id"), j.get("job")
        s = x.app.config["services"]
        for _ in range(240):
            job = s.jobs.get(jid) if jid else None
            if job and job.get("status") in ("done", "failed", "cancelled"):
                break
            time.sleep(0.5)
        else:
            return ["the job never ended: %s" % job]
        out = []
        if job["status"] != "failed" or "disk" not in str(job.get("error")):
            out.append("job ended %s: %s" % (job["status"], str(job.get("error"))[:120]))
        m = x.c.get("/api/hier/uploads").get_json()
        rows = m if isinstance(m, list) else (m or {}).get("uploads") or []
        me = next((u for u in rows if u.get("upload_id") == uid or u.get("id") == uid), None)
        if me is None:
            out.append("the upload is not in the list")
        elif "fail" not in str(me.get("status")) and "interrupt" not in str(me.get("status")):
            out.append("its status is %s" % me.get("status"))
        return out
    finally:
        builder.build = real


class X:
    pass


def main():
    import signal
    signal.signal(signal.SIGALRM, F._alarm)
    x = X()
    x.root = tempfile.mkdtemp(prefix="fuzz_app_r3_")
    try:
        x.app, x.c, _k, _r = F.setup(x.root)
        from api import agentic_api as A
        with x.app.app_context():
            x.eng = A.engine()
        for a in ATTACKS:
            a(x)
    finally:
        shutil.rmtree(x.root, ignore_errors=True)
    bad = [r for r in RESULTS if r[2]]
    print("\n%d attacks, %d broke something" % (len(RESULTS), len(bad)))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
