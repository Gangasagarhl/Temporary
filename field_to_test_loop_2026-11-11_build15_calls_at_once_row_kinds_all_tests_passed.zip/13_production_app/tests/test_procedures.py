"""Procedures and their verified code (owner, 2026-11-09).

    python3 -m pytest -q tests/test_procedures.py

An item is: its source data, its procedure (numbered steps, a JSON the admin edits), its code. Code it: the Coder writes
Python from the procedure, the program checks it and tries it on the recording, the admin reviews it; approved, it is the
verified code of that procedure version, and Run takes only verified code. These tests drive the Family 3 steps on the
sample recording of scenario S17 with the stand-in Coder (no model), in a temporary knowledge folder:
  - the seeded procedures say how each cell is read; a procedure the admin writes is checked, versioned, and needs new code
  - Code it: the code is checked (compiles, allowed imports only, run() defined), tried on the recording, and the counts,
    the percentages and an independent count from the tree database (a different program) agree; the admin's review waits
  - approved, the code is verified; Code it again reuses it without a review; a changed procedure needs code again
  - Run takes only verified code; the Tester and the CSV export follow
  - unsafe code is refused before it runs; the detector's items run the detector's own code
"""
import csv
import json
import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from agentic import core, family1, family3, procedures as PR, rule_evidence as E   # noqa: E402


@pytest.fixture(autouse=True)
def _own_uploads_folder():
    """These tests read the application's own uploads folder. A throw-away app made by an earlier test in the same process points
    procedures at its temporary folder (create_app -> use_uploads_folder), which is deleted afterwards; start each test from the
    application's folder and put back whatever was set (found 2026-11-11 when this file ran after test_defect_graph.py)."""
    was = PR._UPLOADS[0]
    PR.use_uploads_folder(os.path.join(os.path.dirname(HERE), "uploads"))
    yield
    PR.use_uploads_folder(was)

U = "up-20261108-123729-0a98"
pytestmark = pytest.mark.skipif(not os.path.exists(os.path.join(E.APP, "uploads", U, "hier.sqlite")), reason="the S17 sample upload is not on this machine")


class Services:
    root = E.APP


class Engine:
    def __init__(self, tmp):
        self.runner = core.AgentRunner(os.path.join(tmp, "sandbox"), runtime="standin")
        self.services = Services()


class Ctx:
    def __init__(self, engine, kind, sec, lvl, rid, outputs=None, comments=None, step_output=None, run_id=1):
        self.engine = engine
        self.run = {"id": run_id, "params": json.dumps({"_kind": kind, "section": sec, "level": lvl, "id": rid})}
        self.params = {"_kind": kind, "section": sec, "level": lvl, "id": rid, "upload_id": U}
        self.input = {"comments": comments or []}
        self.step = {"key": "code", "output": json.dumps(step_output) if step_output else None}
        self.project = {"admin": "Sagar", "upload_id": U}
        self._out = outputs or {}

    def progress(self, text):
        pass

    def output_of(self, key):
        return self._out.get(key) or {}


@pytest.fixture
def knowledge(tmp_path, monkeypatch):
    monkeypatch.setattr(family1, "knowledge_dir", lambda: str(tmp_path / "knowledge"))
    family3._SECTIONS_SEEN[0] = None
    family3.tree()
    yield tmp_path
    family3._SECTIONS_SEEN[0] = None


def approve(kind, sec, lvl, rid, out, key):
    run = {"params": json.dumps({"_kind": kind, "section": sec, "level": lvl, "id": rid})}
    family3.on_approve(None, run, {"key": key, "output": json.dumps(out)}, {}, "Sagar")


def test_the_seeded_procedures_say_how_each_cell_is_read(knowledge):
    for rid in PR.SEEDS:
        r = family3.load_rule("analytics", "nvme_command", rid)
        p = r["procedure"]
        assert p["version"] == 1 and p["source_data"][0]["file"] == "nvme_command.csv"
        assert any("hash map" in s for s in p["steps"]) and any("hex number before the space" in s for s in p["steps"])
        assert all(len(s) <= 260 for s in p["steps"])                                 # short steps, one idea each
        assert PR.code_state(r) == {"kind": "python", "verified": False, "procedure_version": 1}
    card = E.explain("analytics", "nvme_command", "command_type_share", U)
    assert card["sources"][0]["path"].endswith("S17_io_timeout_abort_reset/nvme_command.csv") and card["sources"][0]["columns"] == ["OPC", "SQID"]


def test_code_it_checks_and_tries_the_code_then_the_admin_makes_it_verified_and_run_uses_it(knowledge):
    eng = Engine(str(knowledge))
    res = family3._code(Ctx(eng, "rule_code", "analytics", "nvme_command", "command_type_share"))
    out = res.output
    assert res.review and "need review" in res.review["body"] and "```python" in res.review["body"]
    assert "checked, not run" in res.review["body"] and "rows" not in out           # Code it does not run the code on the recording
    assert out["verified"] is False and not out["problems"] and all(c["ok"] for c in out["checks"]), out["checks"]
    tried_box = os.path.join(str(knowledge), "try")                                   # Try on a sample: the first records only
    src = PR.sample_sources(PR.source_paths(U), os.path.join(tried_box, "src"), records=100)
    tried = PR.run_code(out["code_file"], {"nvme_command.csv": src["nvme_command.csv"]}, os.path.join(tried_box, "out.csv"), os.path.join(tried_box, "run"))
    assert tried["ok"] and tried["summary"]["rows_read"] == 100
    approve("rule_code", "analytics", "nvme_command", "command_type_share", out, "code")
    r = family3.load_rule("analytics", "nvme_command", "command_type_share")
    st = PR.code_state(r)
    assert st["verified"] and st["verified_by"] == "Sagar" and st["procedure_version"] == 1
    again = family3._code(Ctx(eng, "rule_code", "analytics", "nvme_command", "command_type_share"))
    assert again.review is None and again.output["verified"] is True                # verified code is reused, no new review
    ran = family3._run(Ctx(eng, "rule_exec", "analytics", "nvme_command", "command_type_share", outputs={"code": again.output}, run_id=2))
    assert ran.output["rows"] == 10 and ran.output["summary"]["total"] == 608
    tested = family3._test(Ctx(eng, "rule_exec", "analytics", "nvme_command", "command_type_share", outputs={"code": again.output, "run": ran.output}))
    assert tested.output["passed"], tested.output["checks"]
    assert any("independent count" in c["check"] and c["ok"] for c in tested.output["checks"])   # two programs, one answer, on the whole recording
    exp = family3._export(Ctx(eng, "rule_exec", "analytics", "nvme_command", "command_type_share",
                              outputs={"code": again.output, "run": ran.output, "test": tested.output}, run_id=2))
    rows = list(csv.reader(open(exp.output["files"]["csv"])))
    assert rows[0] == ["command type", "count", "percent"] and rows[1][:2] == ["Read", "360"] and len(rows) == 11


def test_a_changed_procedure_needs_new_code_and_run_refuses_until_then(knowledge):
    eng = Engine(str(knowledge))
    out = family3._code(Ctx(eng, "rule_code", "analytics", "nvme_command", "read_pattern")).output
    assert not out["problems"] and all(c["ok"] for c in out["checks"]), out["checks"]
    approve("rule_code", "analytics", "nvme_command", "read_pattern", out, "code")
    r = family3.load_rule("analytics", "nvme_command", "read_pattern")
    assert PR.code_state(r)["verified"]
    p = dict(E.explain("analytics", "nvme_command", "read_pattern", U)["procedure_json"])
    p["steps"] = p["steps"] + ["Also count reads of exactly 8 blocks apart."]
    r, changed = PR.store(r, p, "Sagar")
    family3.save_rule(r)
    assert changed and r["procedure"]["version"] == 2 and r["kind"] == "python"
    st = PR.code_state(family3.load_rule("analytics", "nvme_command", "read_pattern"))
    assert not st["verified"] and st["procedure_version"] == 2 and st["for_this_version"] is False
    with pytest.raises(RuntimeError, match="no verified code"):
        family3._code(Ctx(eng, "rule_exec", "analytics", "nvme_command", "read_pattern"))
    with pytest.raises(ValueError):
        PR.store(r, {"source_data": [{"file": "x.csv", "columns": ["A"]}], "steps": ["a"], "output": {"columns": ["a"]}}, "Sagar")


def test_unsafe_code_is_refused_before_it_runs():
    assert PR.check_code("import os\ndef run(s, o):\n    os.system('rm -rf /')\n")
    assert PR.check_code("import subprocess\ndef run(s, o):\n    pass\n")
    assert PR.check_code("def run(s, o):\n    eval('1')\n")
    assert PR.check_code("def go(s, o):\n    pass\n") == ["it has no function run(sources, out_csv)"]
    assert PR.check_code(PR.STANDIN_CODE["read_pattern"]) == []


def test_the_detectors_items_run_the_detectors_own_code(knowledge):
    eng = Engine(str(knowledge))
    r = family3.load_rule("errors", "nvme_command", "cmd_timeout")
    st = PR.code_state(r)
    assert st["kind"] == "detector" and st["verified"] and st["path"] == "nvme_hier/rules.py"
    p = PR.procedure_of(r)
    assert p["from_detector"] and [x["file"] for x in p["source_data"]][:2] == ["nvme_command.csv", "NVME_Transactions.csv"]
    assert any("compared in lower case" in s for s in p["steps"]) and any("NVMe Base" in s for s in p["steps"])
    code = family3._code(Ctx(eng, "rule_run", "errors", "nvme_command", "cmd_timeout")).output
    ran = family3._run(Ctx(eng, "rule_run", "errors", "nvme_command", "cmd_timeout", outputs={"code": code}))
    assert code["kind"] == "detector" and ran.output["rows"] == 7
    same, changed = PR.store(dict(r), {k: p[k] for k in ("source_data", "steps", "output", "open_questions")}, "Sagar")
    assert not changed                                                            # saved unchanged: still the detector's


def test_samples_are_the_files_own_records_from_a_line_on():
    path = PR.source_paths(U)["nvme_command.csv"]
    x = PR.sample_rows(path, ["OPC", "SQID"], 2, 3)
    assert x["header"] == ["line", "OPC", "SQID"] and [r[0] for r in x["rows"]] == [2, 3, 4] and x["next_line"] == 5
    with open(path, newline="", encoding="utf-8-sig") as fh:                       # the same cells as the file itself, by line
        rows = list(csv.reader(fh))
    head = rows[0]
    assert x["rows"][0][1:] == [rows[1][head.index("OPC")], rows[1][head.index("SQID")]]
    end = PR.sample_rows(path, ["OPC"], len(rows) - 1, 50)
    assert [r[0] for r in end["rows"]] == [len(rows) - 1, len(rows)] and end["next_line"] is None   # the last two records, then the end
    full = PR.sample_rows(path, None, 100, 1)
    assert full["header"][1:] == head and full["rows"][0][1:] == rows[99]               # line 100 = the 99th record, every column
    with pytest.raises(ValueError, match="no column"):
        PR.sample_rows(path, ["NOT A COLUMN"], 2, 1)


def test_a_seed_is_not_reworded_once_the_coder_used_it(knowledge):
    """A seeded procedure takes newer wording only while nobody edited or coded it: code waiting for review, or verified,
    belongs to the exact text it was written from (2026-11-09: a rewording made a pending review unapprovable)."""
    r = family3.load_rule("analytics", "nvme_command", "command_type_share")
    old = dict(r["procedure"], steps=r["procedure"]["steps"] + ["an older wording"])
    r["procedure"], r["coded_from_sha"] = old, PR.sha(old)
    family3.save_rule(r)
    family3.tree()                                                                  # the seeding runs again
    assert family3.load_rule("analytics", "nvme_command", "command_type_share")["procedure"]["steps"] == old["steps"]
    r2 = family3.load_rule("analytics", "nvme_command", "read_pattern")
    r2["procedure"] = dict(r2["procedure"], steps=["an older wording"])
    family3.save_rule(r2)
    family3.tree()
    assert family3.load_rule("analytics", "nvme_command", "read_pattern")["procedure"]["steps"] == PR.SEEDS["read_pattern"]["steps"]   # not coded: reworded


def test_the_progress_of_a_run_is_read_from_the_open_file(tmp_path):
    """How far a process has read into a file, from /proc/<pid>/fdinfo: the percentage Run shows, with no change to the code."""
    big = tmp_path / "big.csv"
    big.write_text("a,b\n" + "1,2\n" * 200000)
    with open(big, "rb") as fh:
        fh.read(500000)
        pos = PR.read_positions(os.getpid(), [str(big)])
    assert list(pos) == [str(big)] and 500000 <= pos[str(big)] <= 500000 + 65536     # what the process pulled from the disk (Python reads ahead in blocks)
    code = tmp_path / "slow.py"
    code.write_text("import csv, time\n\ndef run(sources, out_csv):\n    n = 0\n    with open(sources['x.csv'], newline='') as fh:\n"
                    "        for row in csv.reader(fh):\n            n += 1\n            if n % 20000 == 0:\n                time.sleep(0.4)\n"
                    "    open(out_csv, 'w').write('n\\n%d\\n' % n)\n    return {'rows_read': n}\n")
    seen = []
    res = PR.run_code(str(code), {"x.csv": str(big)}, str(tmp_path / "out.csv"), str(tmp_path / "box"), progress=seen.append)
    assert res["ok"] and res["summary"]["rows_read"] == 200001
    assert seen and all(0 < i["percent"] < 100 for i in seen) and [i["percent"] for i in seen] == sorted(i["percent"] for i in seen)
    assert "% · " in seen[-1]["text"] and "read" in seen[-1]["text"] and "so far" in seen[-1]["text"]


def test_a_large_result_is_streamed_not_held_in_memory(knowledge):
    """A result of 300,000 lines: Run keeps its first 200 lines only, the Tester reads the whole file line by line, and
    Export copies the whole file (recordings are several GB; the result can be large too)."""
    eng = Engine(str(knowledge))
    it = family3.add_item("analytics", "nvme_command", "every command, many times", "", "Sagar")
    proc = {"source_data": [{"file": "nvme_command.csv", "columns": ["OPC"]}], "steps": ["write 300,000 lines"],
            "output": {"columns": ["n", "count", "percent"], "order": ""}, "open_questions": []}
    r, _ = PR.store(family3.load_rule("analytics", "nvme_command", it["id"]), proc, "Sagar")
    code = os.path.join(str(knowledge), "big_code.py")
    with open(code, "w") as fh:
        fh.write("import csv\n\ndef run(sources, out_csv):\n    with open(out_csv, 'w', newline='') as fh:\n        w = csv.writer(fh)\n"
                 "        w.writerow(['n', 'count', 'percent'])\n        for i in range(300000):\n            w.writerow([i, 1, 100.0 / 300000])\n"
                 "    return {'rows_read': 0, 'rows_written': 300000, 'total': 300000}\n")
    r["code"] = {"path": code, "procedure_sha": PR.sha(r["procedure"]), "procedure_version": 1, "verified_by": "Sagar", "verified_at": 1}
    family3.save_rule(r)
    code_out = family3._code(Ctx(eng, "rule_exec", "analytics", "nvme_command", it["id"])).output
    ran = family3._run(Ctx(eng, "rule_exec", "analytics", "nvme_command", it["id"], outputs={"code": code_out}, run_id=5)).output
    assert ran["rows"] == 300000 and len(ran["head"]) == 200 and "result_file" not in ran
    tested = family3._test(Ctx(eng, "rule_exec", "analytics", "nvme_command", it["id"], outputs={"code": code_out, "run": ran})).output
    assert tested["passed"], tested["checks"]
    exp = family3._export(Ctx(eng, "rule_exec", "analytics", "nvme_command", it["id"], outputs={"code": code_out, "run": ran, "test": tested}, run_id=5)).output
    with open(exp["files"]["csv"]) as fh:
        assert sum(1 for _ in fh) == 300001
    assert "more lines in the CSV" in open(exp["files"]["html"]).read()


def test_a_comment_that_asks_for_other_names_changes_the_procedure_and_the_code(knowledge, monkeypatch):
    """2026-11-09: the admin sent the code back twice asking for 'sqread' and 'RndRead'; the Coder kept the procedure's names,
    so nothing changed. Now a comment that asks for something the procedure says differently changes the procedure too:
    the review shows the change, and approving stores the new procedure version with its verified code."""
    eng = Engine(str(knowledge))
    r = family3.load_rule("analytics", "nvme_command", "read_pattern")
    base = PR.procedure_of(r)
    new_steps = [x.replace('"sequential read"', '"sqread"').replace('"random read (RndRead)"', '"RndRead"') for x in base["steps"]]
    code = PR.STANDIN_CODE["read_pattern"].replace('"sequential read"', '"sqread"').replace('"random read (RndRead)"', '"RndRead"')

    def answer(*a, **k):
        return ({"code": code, "how": [], "questions": [], "answers": ["The first read of a namespace has no read before it, so it is neither."],
                 "procedure": dict(base, steps=new_steps), "changes": ["step 6: the kinds are named sqread and RndRead"]}, "test model", str(knowledge))
    monkeypatch.setattr(eng.runner, "ask", answer)
    res = family3._code(Ctx(eng, "rule_code", "analytics", "nvme_command", "read_pattern", comments=["sequential read should be sqread, random read RndRead"]))
    out = res.output
    assert out["new_procedure"] and out["procedure_version"] == 2 and not out["problems"]
    assert "The procedure changes as you asked" in res.review["body"] and "← changed" in res.review["body"] and "neither" in res.review["body"]
    approve("rule_code", "analytics", "nvme_command", "read_pattern", out, "code")
    r = family3.load_rule("analytics", "nvme_command", "read_pattern")
    assert r["procedure"]["version"] == 2 and any('"sqread"' in x for x in r["procedure"]["steps"])
    st = PR.code_state(r)
    assert st["verified"] and st["procedure_version"] == 2
    ran = family3._run(Ctx(eng, "rule_exec", "analytics", "nvme_command", "read_pattern", outputs={"code": family3._code(
        Ctx(eng, "rule_exec", "analytics", "nvme_command", "read_pattern")).output}, run_id=7)).output
    assert {row[0] for row in ran["head"]} == {"sqread", "RndRead", "first read of its namespace"}   # the output changed as asked
