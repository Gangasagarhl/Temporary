"""Stands in for the other applications on the machine while a large recording loads (owner, 2026-11-10: "other application that is running behind ... should not crash").

Holds some memory and keeps using it, writes a little to disk and does a little work, as a browser or an editor would, and measures how long each of those takes.
    python3 tests/neighbour.py [GB to hold, default 3] [seconds, default 120] [file for the result]
Run it on its own first, to learn what a quiet machine gives, and then beside the load.
"""
import json
import mmap
import os
import random
import sys
import tempfile
import time

PAGE = 4096
STOP = os.environ.get("NEIGHBOUR_STOP")      # a file: when it appears the measuring ends, for a run whose length is not known in advance


def summary(values):
    v = sorted(values)
    return {"n": len(v), "median_ms": round(1000 * v[len(v) // 2], 2), "p99_ms": round(1000 * v[int(len(v) * 0.99)], 2), "max_ms": round(1000 * v[-1], 2)}


def main():
    gb = float(sys.argv[1]) if len(sys.argv) > 1 else 3.0
    seconds = float(sys.argv[2]) if len(sys.argv) > 2 else 120.0
    result = sys.argv[3] if len(sys.argv) > 3 else None
    size = int(gb * 2 ** 30)
    block = mmap.mmap(-1, size)
    t0 = time.time()
    for at in range(0, size, PAGE):
        block[at] = 1
    filled = time.time() - t0
    touch, write, work = [], [], []
    r = random.Random(1)
    folder = tempfile.mkdtemp(prefix="neighbour_", dir=os.path.dirname(os.path.abspath(__file__)))
    path = os.path.join(folder, "note")
    pages = size // PAGE
    end = time.time() + seconds
    try:
        while time.time() < end and not (STOP and os.path.exists(STOP)):
            t = time.perf_counter()
            for _ in range(20000):            # about 80 MB of its memory, anywhere in what it holds
                at = r.randrange(pages) * PAGE
                block[at] = (block[at] + 1) & 255
            touch.append(time.perf_counter() - t)
            t = time.perf_counter()
            with open(path, "wb") as fh:      # a small save, flushed to the disk
                fh.write(b"x" * 4096)
                fh.flush()
                os.fsync(fh.fileno())
            write.append(time.perf_counter() - t)
            t = time.perf_counter()
            total = 0
            for i in range(200000):           # a little thinking
                total += i * i
            work.append(time.perf_counter() - t)
            time.sleep(0.05)
    finally:
        os.remove(path) if os.path.exists(path) else None
        os.rmdir(folder)
    out = {"held_gb": gb, "fill_seconds": round(filled, 1), "use_memory": summary(touch), "small_save": summary(write), "work": summary(work)}
    text = json.dumps(out)
    print(text, flush=True)
    if result:
        with open(result, "w") as fh:
            fh.write(text)


if __name__ == "__main__":
    main()
