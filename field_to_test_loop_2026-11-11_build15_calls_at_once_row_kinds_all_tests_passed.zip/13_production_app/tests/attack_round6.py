#!/usr/bin/env python3
"""A hundred different ways to make the application fail (owner, 2026-11-09: "100 different iterations to make it fail ... for production").

    python3 tests/attack_round6.py [first attack number] [last attack number]

Damaged recordings, files that are not files, machines that run out of memory or disk, processes killed half way, saved data that is corrupted, approvals that try to slip
past the admin's checks, odd but valid commands, and many requests at the same moment. A throw-away root, as tests/fuzz_app.py: nothing of the admin's is read or written and
no model is called. Each attack states what a correct system must do. A refusal counts as correct only when it is in plain words.
"""
import contextlib
import csv
import json
import math
import os
import random
import shutil
import signal
import sqlite3
import stat
import subprocess
import sys
import tempfile
import threading
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import fuzz_app as F  # noqa: E402  (sets up the import paths)
import make_large_recording as MAKE  # noqa: E402
from nvme_hier import loader as L, store as ST  # noqa: E402

csv.field_size_limit(10 ** 8)
S08 = os.path.join(APP, "samples", "clean_five_files", "S08_interrupt_before_completion")
NAMES = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv", "nvme_command": "nvme_command.csv"}
UGLY = ("Traceback", "NoneType", "KeyError", "IndexError", "has no attribute", "not subscriptable", "unsupported operand", "invalid literal", "list index", "referenced before",
        "no such column", "no such table", "UNIQUE constraint", "not iterable", "Expecting value")
RESULTS, ATTACKS = [], []


class X:
    pass


def attack(title):
    def wrap(fn):
        n = len(ATTACKS) + 1

        def run(ctx):
            t0 = time.time()
            ctx.case = tempfile.mkdtemp(dir=ctx.work, prefix="a%d_" % n)
            signal.alarm(200)
            try:
                problems = fn(ctx) or []
            except F.Hang:
                problems = ["it hung for 200 s"]
            except Exception as e:      # noqa: BLE001
                tb = traceback.extract_tb(e.__traceback__)
                f = next((t for t in reversed(tb) if APP in t.filename and "tests/" not in t.filename), tb[-1])
                problems = ["crashed: %s: %s at %s:%d" % (type(e).__name__, str(e)[:200], os.path.basename(f.filename), f.lineno)]
            finally:
                signal.alarm(0)
                shutil.rmtree(ctx.case, ignore_errors=True)
            RESULTS.append((n, title, problems))
            print("%s %3d  %s  (%.1f s)%s" % ("FAIL" if problems else "PASS", n, title, time.time() - t0, "".join("\n        - " + str(p)[:420] for p in problems)), flush=True)
        ATTACKS.append(run)
        return run
    return wrap


class Mgr:
    """Stands for the job manager: what the load job calls."""

    def __init__(self, on_progress=None):
        self.on_progress = on_progress
        self.stop = False
        self.last = None

    def cancelled(self, _j):
        return self.stop

    def event(self, _j, _t):
        pass

    def span(self, _j, _n, _m=None):
        return contextlib.nullcontext()

    def get(self, _j):
        return {"progress": {}}

    def progress(self, _j, step, detail, pct=None, stats=None):
        self.last = (step, detail, pct)
        if self.on_progress:
            self.on_progress(self, step, detail, pct)


def copy_rec(x, name="rec"):
    d = os.path.join(x.case, name)
    os.makedirs(d)
    for n in NAMES.values():
        shutil.copy(os.path.join(S08, n), os.path.join(d, n))
    return d


def rows(p):
    with open(p, newline="", encoding="utf-8-sig", errors="replace") as f:
        return list(csv.reader(f))


def write(p, data):
    with open(p, "w", newline="", encoding="utf-8") as f:
        csv.writer(f, lineterminator="\n").writerows(data)


def files_of(d, only=None):
    return {k: os.path.join(d, v) for k, v in NAMES.items() if not only or k in only}


def job(x, files, mgr=None):
    """The real load job on an upload of the application's own uploads folder: (folder, result, the reason it stopped)."""
    from api import hier_api as H
    uid = "up-a%d" % random.randrange(10 ** 9)
    d = os.path.join(x.root, "uploads", uid)
    os.makedirs(d)
    H.write_meta(d, {"upload_id": uid, "created": time.time(), "operator": "t", "device": "D", "trace_name": uid, "recording_date": "", "notes": "", "files": files, "status": "loading", "thresholds": {}})
    return d, *run_job(d, files, mgr)


def run_job(d, files, mgr=None):
    from api import hier_api as H
    try:
        return H.run_hier_load("j", {"upload_dir": d, "files": files, "thresholds": {}, "workers": 2}, mgr or Mgr()), None
    except RuntimeError as e:
        return None, str(e)


def ugly(text):
    return [w for w in UGLY if w in str(text)]


def pages(x, d):
    """The pages of a finished recording must open: never a server error."""
    uid, bad = os.path.basename(d), []
    urls = ["/api/hier/uploads/%s" % uid, "/api/hier/uploads/%s/summary" % uid, "/api/hier/uploads/%s/defect_table" % uid] + ["/api/hier/uploads/%s/rows?level=%s&limit=5" % (uid, k) for k in NAMES]
    for u in urls:
        r = x.c.get(u)
        if r.status_code >= 500:
            bad.append("%s answered %d %s" % (u, r.status_code, r.get_data()[:160]))
    return bad


def judged(x, mutate, expect="any", only=None):
    """expect: clean = must load and follow the rules; flagged = refused in plain words, or loaded with a rule reported as not followed; any = either, never a crash."""
    from agentic import join_rules as JR
    from api import hier_api as H
    d0 = copy_rec(x)
    extra = mutate(d0) if mutate else None
    files = extra if isinstance(extra, dict) else files_of(d0, only)
    d, res, why = job(x, files)
    if why is not None:
        if ugly(why):
            return ["an unreadable reason: %s" % why]
        if expect == "clean":
            return ["a good recording was refused: %s" % why]
        if (H.read_meta(d) or {}).get("status") not in ("interrupted", "failed", "cancelled", "loading"):
            return ["the record says %s after a stop" % (H.read_meta(d) or {}).get("status")]
        return []
    bad = pages(x, d)
    verdict = JR.evaluate(H.db_of(d))
    if expect == "flagged" and not verdict["must_explain"]:
        bad.append("not reported as breaking a rule: %s" % [(r["id"], r["verdict"]) for r in verdict["rules"]])
    if expect == "clean" and verdict["must_explain"]:
        bad.append("a good recording was reported as breaking a rule: %s" % verdict["summary"])
    shutil.rmtree(d, ignore_errors=True)
    return bad


def edit(name, fn):
    """A change made to the rows of one file."""
    def go(d):
        p = os.path.join(d, name)
        data = rows(p)
        write(p, fn(data))
    return go


def set_col(column, value):
    def fn(data):
        i = data[0].index(column)
        rng = random.Random(4)
        for r in data[1:]:
            if i < len(r):
                r[i] = value(rng, r[i]) if callable(value) else value
        return data
    return fn


# --------------------------------------------------------------------------------------------------- recordings with damaged files
for level, fname in NAMES.items():
    attack("%s with its header only: finished or refused, never a crash" % fname)(lambda x, fname=fname: judged(x, edit(fname, lambda d: d[:1])))
for level, fname in NAMES.items():
    def _empty(d, fname=fname):
        open(os.path.join(d, fname), "w").close()
    attack("%s of 0 bytes" % fname)(lambda x, fn=_empty: judged(x, fn))
attack("packets.csv that holds only blank lines")(lambda x: judged(x, lambda d: open(os.path.join(d, "packets.csv"), "w").write("\n" * 200000)))
attack("packets.csv is random binary data")(lambda x: judged(x, lambda d: open(os.path.join(d, "packets.csv"), "wb").write(random.Random(1).randbytes(2 * 1024 ** 2))))


def _nuls(d):
    p = os.path.join(d, "packets.csv")
    b = open(p, "rb").read()
    open(p, "wb").write(b.replace(b",Upstream,", b",Up\x00stream,", 300))


attack("NUL bytes inside the rows of packets.csv")(lambda x: judged(x, _nuls))


def _utf16(d):
    p = os.path.join(d, "packets.csv")
    t = open(p, encoding="utf-8", errors="replace").read()
    open(p, "w", encoding="utf-16").write(t)


attack("packets.csv saved as UTF-16")(lambda x: judged(x, _utf16, "flagged"))


def _bom_crlf(d):
    for n in NAMES.values():
        p = os.path.join(d, n)
        b = open(p, "rb").read().replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
        open(p, "wb").write(b"\xef\xbb\xbf" + b)


attack("every file with a byte order mark and Windows line ends: still clean")(lambda x: judged(x, _bom_crlf, "clean"))


def _cut_last(name):
    def go(d):
        p = os.path.join(d, name)
        b = open(p, "rb").read()
        open(p, "wb").write(b[:-40])
    return go


attack("the last line of link.csv cut in the middle")(lambda x: judged(x, _cut_last("link.csv")))
attack("the last line of nvme_command.csv cut in the middle")(lambda x: judged(x, _cut_last("nvme_command.csv")))
attack("the same file given as packets and as link")(lambda x: judged(x, lambda d: dict(files_of(d), link=os.path.join(d, "packets.csv")), "flagged"))
attack("packets.csv given as the commands file")(lambda x: judged(x, lambda d: dict(files_of(d), nvme_command=os.path.join(d, "packets.csv")), "flagged"))
attack("the header line repeated in the middle of packets.csv")(lambda x: judged(x, edit("packets.csv", lambda d: d[:5000] + d[:1] + d[5000:])))
attack("two exports glued together, numbers starting again")(lambda x: judged(x, edit("link.csv", lambda d: d + d[1:]), "flagged"))
attack("rows of packets.csv with extra cells")(lambda x: judged(x, edit("packets.csv", lambda d: d[:1] + [r + ["extra", "cells"] for r in d[1:]])))
attack("rows of link.csv with too few cells")(lambda x: judged(x, edit("link.csv", lambda d: d[:1] + [r[:len(r) // 2] for r in d[1:]]), "flagged"))


def _reorder(data):
    order = list(range(len(data[0])))
    random.Random(5).shuffle(order)
    return [[r[i] if i < len(r) else "" for i in order] for r in data]


attack("the columns of link.csv in another order: still clean (columns are found by name)")(lambda x: judged(x, edit("link.csv", _reorder), "clean"))
attack("the PSN column of packets.csv renamed")(lambda x: judged(x, edit("packets.csv", lambda d: [[("Sequence" if c == "PSN" else c) for c in d[0]]] + d[1:]), "flagged"))
attack("every Time Stamp of packets.csv is nonsense")(lambda x: judged(x, edit("packets.csv", set_col("Time Stamp", "soon"))))
attack("every Time Stamp of packets.csv is blank")(lambda x: judged(x, edit("packets.csv", set_col("Time Stamp", ""))))
attack("nvme_command.csv in reverse order: still clean (commands are found by identity, not by place)")(lambda x: judged(x, edit("nvme_command.csv", lambda d: d[:1] + d[:0:-1]), "clean"))
attack("time stamps of six digits of seconds: still clean")(lambda x: judged(x, lambda d: [edit(n, set_col("Time Stamp", lambda _r, v: ("999" + v) if v else v))(d) for n in NAMES.values()] and None, "clean"))
attack("negative numbers in the Length column")(lambda x: judged(x, edit("packets.csv", set_col("Length", "-64"))))
attack("numbers of 200 digits in the PSN column")(lambda x: judged(x, edit("packets.csv", set_col("PSN", "9" * 200)), "flagged"))
attack("hex text in the decimal PSN column")(lambda x: judged(x, edit("packets.csv", set_col("PSN", lambda _r, v: hex(int(v)) if v.isdigit() else v))))
attack("one cell of 1 MB")(lambda x: judged(x, edit("packets.csv", lambda d: d[:100] + [d[100][:3] + ["y" * 1024 ** 2] + d[100][4:]] + d[101:])))


def _stray(d):
    p = os.path.join(d, "link.csv")
    b = open(p, "rb").read().split(b"\n")
    b[500] = b'"' + b[500]
    open(p, "wb").write(b"\n".join(b))


attack("one stray opening quote in link.csv")(lambda x: judged(x, _stray))


def _newline_cell(d):
    p = os.path.join(d, "packets.csv")
    data = rows(p)
    data[50][-1] = "two\nlines"
    write(p, data)


attack("a quoted cell with a line end inside: still clean")(lambda x: judged(x, _newline_cell, "clean"))
attack("rows of nothing but commas in the middle of packets.csv")(lambda x: judged(x, edit("packets.csv", lambda d: d[:800] + [[""] * len(d[0])] * 5000 + d[800:])))
attack("every packet row twice")(lambda x: judged(x, edit("packets.csv", lambda d: d[:1] + [r for r in d[1:] for _ in (0, 1)]), "flagged"))
attack("every second packet missing")(lambda x: judged(x, edit("packets.csv", lambda d: d[:1] + d[1::2]), "flagged"))
attack("nvme_command.csv sorted by CID: still clean (commands are found by identity, not by place)")(lambda x: judged(x, edit("nvme_command.csv", lambda d: d[:1] + sorted(d[1:], key=lambda r: r[d[0].index("CID")])), "clean"))
attack("only packets.csv given")(lambda x: judged(x, None, "any", only=["packets"]))
attack("only nvme_command.csv given")(lambda x: judged(x, None, "any", only=["nvme_command"]))
attack("everything but packets.csv")(lambda x: judged(x, None, "any", only=["link", "split", "nvme_transaction", "nvme_command"]))
attack("everything but nvme_command.csv")(lambda x: judged(x, None, "any", only=["packets", "link", "split", "nvme_transaction"]))
attack("everything but link.csv")(lambda x: judged(x, None, "any", only=["packets", "split", "nvme_transaction", "nvme_command"]))
attack("Metrics.# NVME Trans blank in every command")(lambda x: judged(x, edit("nvme_command.csv", set_col("Metrics.# NVME Trans", ""))))
attack("the same Link Dir in every packet")(lambda x: judged(x, edit("packets.csv", set_col("Link Dir", "Upstream")), "flagged"))
attack("nonsense in Link Dir")(lambda x: judged(x, edit("packets.csv", set_col("Link Dir", "Sideways")), "flagged"))
attack("nonsense in TLP Type")(lambda x: judged(x, edit("link.csv", set_col("Mem.TLP Type", "Banana"))))
attack("a SQID too large for 64 bits")(lambda x: judged(x, edit("nvme_command.csv", set_col("SQID", str(2 ** 70))), "flagged"))
attack("two columns with the same name")(lambda x: judged(x, edit("link.csv", lambda d: [d[0][:2] + [d[0][1]] + d[0][3:]] + d[1:])))
def _latin1(d):
    p = os.path.join(d, "split.csv")
    data = rows(p)
    data[10][-1] += "\xe9"
    with open(p, "w", newline="", encoding="latin-1") as f:
        csv.writer(f, lineterminator="\n").writerows(data)


attack("a Latin-1 byte inside a cell: still clean")(lambda x: judged(x, _latin1, "clean"))
attack("a comment line before the header")(lambda x: judged(x, edit("nvme_command.csv", lambda d: [["exported by the analyzer"]] + d), "flagged"))
attack("semicolons in place of commas")(lambda x: judged(x, lambda d: open(os.path.join(d, "link.csv"), "w").write(open(os.path.join(d, "link.csv")).read().replace(",", ";")), "flagged"))


# --------------------------------------------------------------------------------------------------- things that are not files, through the real start of a load
def through_api(x, path, level="packets"):
    """POST the load as the page does; it must answer at once or the job must end by itself in 25 s."""
    r = x.c.post("/api/hier/uploads", json={"device": "D", "operator": "t", "files": {level: path}})
    if r.status_code >= 500:
        return ["answered %d" % r.status_code]
    if r.status_code != 200:
        msg = (r.get_json() or {}).get("error", "")
        return ["an unreadable refusal: %s" % msg] if ugly(msg) or not msg else []
    jid = r.get_json()["job"]
    t0 = time.time()
    while time.time() - t0 < 25:
        j = x.c.get("/api/jobs/%s" % jid).get_json() or {}
        if j.get("status") in ("done", "failed", "cancelled"):
            first = (j.get("error") or "").split("\n")[0]
            return ["an unreadable reason: %s" % first] if ugly(first) else []
        time.sleep(0.2)
    return ["the load did not end by itself in 25 s"]


attack("/dev/zero given as a file")(lambda x: through_api(x, "/dev/zero"))
attack("/dev/urandom given as a file")(lambda x: through_api(x, "/dev/urandom"))
attack("a folder given as a file")(lambda x: through_api(x, x.case))


@attack("a named pipe that nobody writes to")
def _fifo(x):
    p = os.path.join(x.case, "packets.csv")
    os.mkfifo(p)
    try:
        return through_api(x, p)
    finally:
        with contextlib.suppress(OSError):
            os.close(os.open(p, os.O_WRONLY | os.O_NONBLOCK))


@attack("a link that points to itself")
def _loop(x):
    p = os.path.join(x.case, "packets.csv")
    os.symlink(p, p)
    return through_api(x, p)


@attack("a file nobody may read")
def _noread(x):
    if os.geteuid() == 0:
        return []
    p = os.path.join(x.case, "packets.csv")
    shutil.copy(os.path.join(S08, "packets.csv"), p)
    os.chmod(p, 0)
    try:
        return through_api(x, p)
    finally:
        os.chmod(p, stat.S_IRUSR | stat.S_IWUSR)


attack("a file that does not exist")(lambda x: through_api(x, os.path.join(x.case, "nothing.csv")))
attack("a path with a NUL byte")(lambda x: through_api(x, "/tmp/a\x00b.csv"))


# --------------------------------------------------------------------------------------------------- a machine that runs out, and processes that die
CHILD = """
import os, sys
sys.path.insert(0, %r); sys.path.insert(0, %r)
from nvme_hier import loader as L
from api import hier_api as H
class M:
    def cancelled(s, j): return False
    def event(s, j, t): pass
    def span(s, j, n, m=None):
        import contextlib
        return contextlib.nullcontext()
    def get(s, j): return {"progress": {}}
    def progress(s, j, step, detail, pct=None, stats=None): pass
if __name__ == "__main__":
    d = sys.argv[1]
    m = H.read_meta(d)
    try:
        H.run_hier_load("j", {"upload_dir": d, "files": m["files"], "thresholds": {}, "workers": 2}, M())
        print("FINISHED")
    except RuntimeError as e:
        print("STOPPED", e)
""" % (APP, os.path.join(APP, "app"))


def child_job(x, copies=3):
    from api import hier_api as H
    big = os.path.join(x.case, "big")
    MAKE.make(S08, big, copies)
    d = os.path.join(x.root, "uploads", "up-c%d" % random.randrange(10 ** 9))
    os.makedirs(d)
    H.write_meta(d, {"upload_id": os.path.basename(d), "files": files_of(big), "status": "loading", "thresholds": {}})
    script = os.path.join(x.case, "child.py")
    open(script, "w").write(CHILD)
    return d, subprocess.Popen([sys.executable, script, d], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, start_new_session=True)


def children(pid):
    out = []
    try:
        for t in os.listdir("/proc/%d/task" % pid):
            out += [int(c) for c in open("/proc/%d/task/%s/children" % (pid, t)).read().split()]
    except OSError:
        pass
    return out


def workers_of(pid):
    return [c for c in children(pid) if b"spawn_main" in open("/proc/%d/cmdline" % c, "rb").read()]


def wait_until(test, seconds):
    t0 = time.time()
    while time.time() - t0 < seconds:
        if test():
            return True
        time.sleep(0.05)
    return False


def kill_all(p):
    with contextlib.suppress(OSError):
        os.killpg(p.pid, signal.SIGKILL)
    p.wait()


@attack("a parser worker killed by the operating system during a load: the load ends with a reason, it does not hang")
def _worker_killed(x):
    d, p = child_job(x)
    try:
        if not wait_until(lambda: workers_of(p.pid), 60):
            return ["no worker appeared"]
        time.sleep(1.0)
        os.kill(workers_of(p.pid)[0], signal.SIGKILL)
        try:
            out, err = p.communicate(timeout=60)
        except subprocess.TimeoutExpired:
            return ["the load hung after its worker was killed"]
        if "STOPPED" not in out or "worker" not in out or ugly(out):
            return ["it ended without the plain reason: %s %s" % (out[-300:], err[-300:])]
        return []
    finally:
        kill_all(p)


@attack("the whole process killed during the tree build: Load again finishes it")
def _killed_build(x):
    from agentic import join_rules as JR
    from api import hier_api as H
    d, p = child_job(x)
    try:
        if not wait_until(lambda: os.path.exists(L.work_path(H.db_of(d))), 150):
            return ["the build never started"]
        time.sleep(1.5)
    finally:
        kill_all(p)
    res, why = run_job(d, (H.read_meta(d) or {})["files"])
    if why:
        return ["Load again failed: %s" % why]
    return ["Load again left a broken tree: %s" % JR.evaluate(H.db_of(d))["summary"]] if JR.evaluate(H.db_of(d))["must_explain"] else []


@attack("the whole process killed during the rules: Load again finishes it")
def _killed_rules(x):
    from api import hier_api as H
    d, p = child_job(x)
    try:
        if not wait_until(lambda: ((H.read_meta(d) or {}).get("stage_done") or {}).get("build"), 170):
            return ["the build never finished"]
    finally:
        kill_all(p)
    res, why = run_job(d, (H.read_meta(d) or {})["files"])
    return ["Load again failed: %s" % why] if why else []


def limited(pages_allowed):
    original = L.open_db

    def go(path):
        con = original(path)
        con.execute("PRAGMA max_page_count=%d" % pages_allowed)
        return con
    return original, go


@attack("the disk fills during the load: stopped with a reason, and Load again finishes")
def _disk_load(x):
    from api import hier_api as H
    d0 = copy_rec(x)
    original, go = limited(2000)
    L.open_db = go
    try:
        d, res, why = job(x, files_of(d0))
    finally:
        L.open_db = original
    if not why or "disk" not in why.lower() or ugly(why):
        return ["no plain reason: %s" % why]
    if (H.read_meta(d) or {}).get("status") != "interrupted":
        return ["the record says %s" % (H.read_meta(d) or {}).get("status")]
    res, why = run_job(d, files_of(d0))
    return ["Load again failed: %s" % why] if why else []


@attack("the disk fills during the tree build: stopped with a reason, and Load again finishes")
def _disk_build(x):
    from api import hier_api as H
    from nvme_hier import builder as B
    d0 = copy_rec(x)
    original_build, original_open = B.build, L.open_db

    def full_build(db, progress=None, settings=None):     # the app passes the join settings too (since 2026-11-08)
        con = sqlite3.connect(db)
        n = con.execute("PRAGMA page_count").fetchone()[0]
        con.close()

        def go(path):
            c = original_open(path)
            c.execute("PRAGMA max_page_count=%d" % (n + 3))
            return c
        L.open_db = go
        try:
            return original_build(db, progress)
        finally:
            L.open_db = original_open
    B.build = full_build
    try:
        d, res, why = job(x, files_of(d0))
    finally:
        B.build = original_build
    if not why or "disk" not in why.lower() or ugly(why):
        return ["no plain reason: %s" % why]
    res, why = run_job(d, files_of(d0))
    return ["Load again failed: %s" % why] if why else []


def memory_runs_out(after_step=None):
    """The machine's memory falls to almost nothing once the load has reached the named step."""
    state = {"low": False}
    original = L.memory_available
    L.memory_available = lambda: 10 ** 6 if state["low"] else 8 * 1024 ** 3

    def mark(_m, step, _detail, _pct):
        if after_step in (step or ""):
            state["low"] = True
    return original, mark


def _memory_case(x, word):
    from api import hier_api as H
    d0 = copy_rec(x)
    original, mark = memory_runs_out(word)
    guard_every = L.RoomGuard.__init__.__defaults__
    L.RoomGuard.__init__.__defaults__ = (0.05, None, None)
    try:
        d, res, why = job(x, files_of(d0), Mgr(mark))
    finally:
        L.memory_available = original
        L.RoomGuard.__init__.__defaults__ = guard_every
    if not why or "memory" not in why or ugly(why):
        return ["no plain reason: %s" % why]
    if (H.read_meta(d) or {}).get("status") != "interrupted":
        return ["the record says %s" % (H.read_meta(d) or {}).get("status")]
    res, why = run_job(d, files_of(d0))
    return ["Load again failed: %s" % why] if why else []


attack("memory runs out during the load")(lambda x: _memory_case(x, "loading"))
attack("memory runs out during the tree build")(lambda x: _memory_case(x, "tree:"))
attack("memory runs out during the rules")(lambda x: _memory_case(x, "rules"))


@attack("the admin cancels during the load, then presses Load again")
def _cancel(x):
    from api import hier_api as H
    d0 = copy_rec(x)

    def stop(m, step, detail, _pct):
        if "Link" in (detail or "") or "link" in (detail or ""):
            m.stop = True
    d, res, why = job(x, files_of(d0), Mgr(stop))
    if why is None:
        return []          # finished before the press
    res, why = run_job(d, files_of(d0))
    return ["Load again failed: %s" % why] if why else []


@attack("a scratch file left over from a crash, full of garbage")
def _stale_work(x):
    from api import hier_api as H
    d0 = copy_rec(x)
    uid = "up-w"
    d = os.path.join(x.root, "uploads", uid)
    os.makedirs(d)
    H.write_meta(d, {"upload_id": uid, "files": files_of(d0), "status": "loading", "thresholds": {}})
    open(L.work_path(H.db_of(d)), "wb").write(b"garbage" * 1000)
    res, why = run_job(d, files_of(d0))
    return ["it failed: %s" % why] if why else []


@attack("the database of a recording is garbage when Load again is pressed")
def _garbage_db(x):
    from api import hier_api as H
    d0 = copy_rec(x)
    uid = "up-g"
    d = os.path.join(x.root, "uploads", uid)
    os.makedirs(d)
    H.write_meta(d, {"upload_id": uid, "files": files_of(d0), "status": "interrupted", "thresholds": {}})
    open(H.db_of(d), "wb").write(b"not a database" * 1000)
    res, why = run_job(d, files_of(d0))
    if why is None:
        return []
    return ["an unreadable reason: %s" % why] if ugly(why) else []


@attack("the record of the load deleted while the load runs")
def _meta_gone(x):
    from api import hier_api as H
    d0 = copy_rec(x)
    holder = {}

    def gone(_m, _s, detail, _p):
        p = os.path.join(holder.get("d", ""), "meta.json")
        if "d" in holder and os.path.exists(p):
            os.remove(p)
    original = H.write_meta

    def spy(d, meta):
        holder["d"] = d
        original(d, meta)
    H.write_meta = spy
    try:
        _d, res, why = job(x, files_of(d0), Mgr(gone))
    finally:
        H.write_meta = original
    return ["an unreadable reason: %s" % why] if why and ugly(why) else []


@attack("an input file deleted while the load runs")
def _input_gone(x):
    d0 = copy_rec(x)
    target = os.path.join(d0, "link.csv")

    def gone(_m, _s, detail, _p):
        if "split" in (detail or "").lower() and os.path.exists(target):
            os.remove(target)
    _d, res, why = job(x, files_of(d0), Mgr(gone))
    return ["an unreadable reason: %s" % why] if why and ugly(why) else []


@attack("an input file cut short while the load runs")
def _input_cut(x):
    d0 = copy_rec(x)
    target = os.path.join(d0, "link.csv")
    done = []

    def cut(_m, _s, detail, _p):
        if not done and "split" in (detail or "").lower():
            done.append(1)
            with open(target, "r+b") as fh:
                fh.truncate(os.path.getsize(target) // 2)
    _d, res, why = job(x, files_of(d0), Mgr(cut))
    return ["an unreadable reason: %s" % why] if why and ugly(why) else []


@attack("an input file that changes between the stop and Load again is read again")
def _changed(x):
    from api import hier_api as H
    d0 = copy_rec(x)
    d, res, why = job(x, files_of(d0))
    if why:
        return ["the first load failed: %s" % why]
    p = os.path.join(d0, "nvme_command.csv")
    data = rows(p)
    write(p, data[:51])
    time.sleep(1.1)
    res, why = run_job(d, files_of(d0))
    if why:
        return ["Load again failed: %s" % why]
    con = sqlite3.connect(H.db_of(d))
    n = con.execute("SELECT COUNT(*) FROM cmd").fetchone()[0]
    return [] if n == 50 else ["the old rows were kept: %d commands" % n]


@attack("Load again pressed twice at the same moment starts one load")
def _double_resume(x):
    from api import hier_api as H
    d0 = copy_rec(x)
    uid = "up-d"
    d = os.path.join(x.root, "uploads", uid)
    os.makedirs(d)
    H.write_meta(d, {"upload_id": uid, "files": files_of(d0), "status": "interrupted", "thresholds": {}, "device": "D"})
    codes = []

    def press():
        codes.append(x.app.test_client().post("/api/hier/uploads/%s/resume" % uid).status_code)
    ts = [threading.Thread(target=press) for _ in range(12)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    jobs = (H.read_meta(d) or {}).get("job")
    wait_until(lambda: (x.c.get("/api/jobs/%s" % jobs).get_json() or {}).get("status") in ("done", "failed"), 60)
    return [] if codes.count(200) == 1 else ["%d presses started a load: %s" % (codes.count(200), sorted(codes))]


@attack("several large loads at once cannot promise the same free disk twice")
def _reserve(x):
    class U:
        free = 50 * 1024 ** 3
    original = L.shutil.disk_usage
    L.shutil.disk_usage = lambda p: U
    try:
        with L.reserve_room(8 * 1024 ** 3):              # one load of 8 GB is running: it will use about 40 GB of the 50
            text = L.room_problem(8 * 1024 ** 3, x.case)
        after = L.room_problem(8 * 1024 ** 3, x.case)
    finally:
        L.shutil.disk_usage = original
    bad = []
    if not text or "free disk" not in text:
        bad.append("a second load was promised the same disk: %s" % text)
    if after:
        bad.append("the room was not given back after the load: %s" % after)
    return bad


# --------------------------------------------------------------------------------------------------- saved data that is corrupted
def strategy_with(x, fmt, payload):
    from agentic import family1, family2
    d = os.path.join(family1.knowledge_dir(), "strategies", fmt)
    os.makedirs(d, exist_ok=True)
    open(os.path.join(d, "v1.json"), "w").write(payload)
    return family2


attack("a strategy file of garbage counts as no strategy")(lambda x: [] if strategy_with(x, "g1", "{not json").last_strategy("g1") is None else ["it was used"])


@attack("a strategy whose checks are a list, not a table")
def _verified_list(x):
    from agentic import join_rules as JR
    return [] if len(JR.needs_check([1, 2, 3])) == len(JR.RULES) else ["it counted as checked"]


@attack("a strategy whose checks hold nonsense entries")
def _verified_junk(x):
    from agentic import join_rules as JR
    junk = {r["id"]: v for r, v in zip(JR.RULES, ("yes", 7, [], None, {"sha": None}))}
    return [] if len(JR.needs_check(junk)) == len(JR.RULES) else ["a nonsense entry counted as a check"]


@attack("a strategy whose joins are not a list still shows the program's rules")
def _joins_junk(x):
    from agentic import family2, join_rules as JR
    bad = []
    for junk in ({"joins": "x"}, {"joins": 7}, {"joins": [1, "a", None]}, {"joins": None}):
        shown = family2._with_notes(junk)
        if len(shown) != len(JR.RULES):
            bad.append(str(junk))
    return bad


@attack("the strategies folder is a file")
def _strategies_file(x):
    from agentic import family1, family2
    p = os.path.join(family1.knowledge_dir(), "strategies")
    keep = None
    if os.path.isdir(p):
        keep = p + ".kept"
        os.rename(p, keep)
    open(p, "w").write("x")
    try:
        try:
            family2.last_strategy("f")
        except OSError as e:
            return ["it crashed reading: %s" % e]
        return []
    finally:
        os.remove(p)
        if keep:
            os.rename(keep, p)


def fake_build_db(x, value):
    p = os.path.join(x.case, "b.sqlite")
    c = sqlite3.connect(p)
    c.execute("CREATE TABLE meta (k TEXT PRIMARY KEY, v TEXT)")
    if value is not None:
        c.execute("INSERT INTO meta VALUES ('build', ?)", (value,))
    c.commit()
    c.close()
    return p


def evaluates(x, value):
    from agentic import join_rules as JR
    r = JR.evaluate(fake_build_db(x, value))
    return [] if isinstance(r.get("rules"), list) else ["no rules in the answer"]


attack("the build report is not JSON")(lambda x: evaluates(x, "{broken"))
attack("there is no build report")(lambda x: evaluates(x, None))
attack("the build report is a list")(lambda x: evaluates(x, "[1,2]"))
attack("the build report's counts are words")(lambda x: evaluates(x, json.dumps({"steps": {"packets_to_links": {"tlp_without_link_row": "many", "tlp_packets": "lots", "link_rows": []}}, "checks": {"link_rows_whose_packet_count_differs": {}}})))
attack("a count larger than its total, and a total of zero")(lambda x: evaluates(x, json.dumps({"steps": {"packets_to_links": {"tlp_without_link_row": 90, "tlp_packets": 3, "ack_nak_without_open_link": 5, "ack_nak_packets": 0, "link_rows": 0}}, "checks": {}})))


@attack("the database given to the rule report is garbage")
def _eval_garbage(x):
    from agentic import join_rules as JR
    p = os.path.join(x.case, "g.sqlite")
    open(p, "wb").write(b"garbage" * 2000)
    r = JR.evaluate(p)
    return [] if isinstance(r.get("rules"), list) else ["no answer"]


def store(x):
    st = ST.Store(os.path.join(x.case, "db", "k.sqlite"))
    s = {"fine": "f", "coarse": "c", "display": "d", "fields": {"lvl": "nvme_command", "err": "cmd.timeout", "cmd": "io.Write", "cause": "self"}}
    st.touch_signature(s, "D", upload_id="u", finding_id=1)
    pid = st.add_procedure("f", [{"step": 1, "command": "c", "position": "fault"}], "p", "x")
    return st, pid


def weights_set(x, a, b):
    st, pid = store(x)
    con = st._con()
    con.execute("UPDATE procedure SET a=?, b=? WHERE id=?", (a, b, pid))
    con.commit()
    con.close()
    st.graph_view("f")
    st.graph_choice("f")
    st.signal("f", pid, "correct", "t")
    st.graph_choice("f")
    return []


attack("a weight of not-a-number in the graph")(lambda x: weights_set(x, float("nan"), 1.0))
attack("an infinite weight in the graph")(lambda x: weights_set(x, float("inf"), 1.0))
attack("both counts zero in the graph")(lambda x: weights_set(x, 0.0, 0.0))
attack("negative counts in the graph")(lambda x: weights_set(x, -5.0, -9.0))
attack("words in place of counts in the graph")(lambda x: weights_set(x, "a lot", "few"))


def view_with_garbage(x, table, column, value):
    from api import agentic_api as A
    with x.app.app_context():
        eng = A.engine()
    p = x.c.post("/api/agents/projects", json={"admin": "t", "name": "g%d" % random.randrange(10 ** 8), "folder": S08}).get_json()
    run = x.c.post("/api/agents/projects/%d/flow" % p["id"], json={"admin": "t"}).get_json()["run"]
    eng.store.exec("UPDATE step SET %s=? WHERE run=?" % column if table == "step" else "UPDATE review SET %s=? WHERE run=?" % column, (value, run))
    if table == "review":
        s = eng.store.one("SELECT id FROM step WHERE run=? LIMIT 1", (run,))
        eng.store.exec("INSERT INTO review (run, step, title, body, data, state, created) VALUES (?,?,?,?,?,?,?)", (run, s["id"], "t", "b", value, "open", time.time()))
    r = x.c.get("/api/agents/runs/%d" % run)
    x.c.post("/api/agents/runs/%d/stop" % run, json={"admin": "t"})
    return [] if r.status_code < 500 else ["the run page answered %d" % r.status_code]


attack("a step's output is garbage in the database")(lambda x: view_with_garbage(x, "step", "output", "{nope"))
attack("a step's input is a bare number in the database")(lambda x: view_with_garbage(x, "step", "input", "7"))
attack("a review's data is garbage in the database")(lambda x: view_with_garbage(x, "review", "data", "[[["))


@attack("the break limit in the settings is not a number")
def _limit(x):
    from agentic import family2
    bad = []
    for v in ("abc", None, -1, float("nan"), float("inf"), [], {}, True, 1000):
        out = family2.break_limit({"agentic": {"join_break_limit_percent": v}})
        if not (isinstance(out, float) and 0 <= out <= 100 and not math.isnan(out)):
            bad.append("%r gave %r" % (v, out))
    return bad


# --------------------------------------------------------------------------------------------------- approvals that try to slip past the checks
def _step(key, output):
    return {"key": key, "output": json.dumps(output), "idx": 0}


def refused(fn, words):
    try:
        fn()
    except ValueError as e:
        return [] if words in str(e) else ["refused for another reason: %s" % e]
    return ["it was accepted"]


def approve_coder(x, edits, fmt="f9"):
    from agentic import family2 as F2, join_rules as JR
    out = {"joins": JR.as_strategy(), "problems": [], "format": fmt}
    F2.on_approve(None, {"id": 1}, _step("coder", out), {"edits": edits}, "A")


for name, junk in (("a number", 7), ("text", "all"), ("nested lists", [["packets_to_links"]]), ("nothing", None), ("numbers", [1, 2, 3, 4, 5])):
    attack("the rule ticks given as %s" % name)(lambda x, junk=junk: refused(lambda: approve_coder(x, {"verified": junk}), "check every rule"))
attack("edits that are not a table at all")(lambda x: refused(lambda: approve_coder(x, ["verified"]), "check every rule"))


@attack("half a million ticks answer at once")
def _many(x):
    from agentic import join_rules as JR
    t0 = time.time()
    refused(lambda: approve_coder(x, {"verified": ["x"] * 500000}), "check every rule")
    return [] if time.time() - t0 < 3 else ["it took %.1f s" % (time.time() - t0)]


@attack("rules ticked on one version of the code, approved on another")
def _code_moved(x):
    from agentic import family2 as F2, join_rules as JR
    joins = JR.as_strategy()
    joins[3]["code"]["sha"] = "older"
    out = {"joins": joins, "problems": [], "format": "f8"}
    return refused(lambda: F2.on_approve(None, {"id": 1}, _step("coder", out), {"edits": {"verified": [j["id"] for j in joins]}}, "A"), "changed")


BROKEN = {"join_checks": {"must_explain": True, "broken": ["x"]}}
for name, reason in (("a table", {"a": 1}), ("a list", ["x"]), ("spaces", "    "), ("non-breaking spaces", "\xa0\xa0\xa0"), ("zero-width characters", "​​​"), ("punctuation only", "...")):
    def _reason(x, reason=reason):
        from agentic import family2 as F2
        return refused(lambda: F2.on_approve(None, {"id": 1}, _step("independent", BROKEN), {"edits": {"accept_reason": reason}}, "A"), "Write why")
    attack("the written reason given as %s" % name)(_reason)


@attack("a written reason of 5 MB is kept short")
def _long_reason(x):
    from agentic import family2 as F2
    data = {"edits": {"accept_reason": "z" * 5 * 1024 ** 2}}
    F2.on_approve(None, {"id": 1}, _step("independent", BROKEN), data, "A")
    return [] if len(data["edits"]["accept_reason"]) <= 4000 else ["%d characters were stored" % len(data["edits"]["accept_reason"])]


@attack("twenty presses of Approve at the same moment count once")
def _twenty(x):
    from api import agentic_api as A
    with x.app.app_context():
        eng = A.engine()
    p = x.c.post("/api/agents/projects", json={"admin": "t", "name": "c%d" % random.randrange(10 ** 8), "folder": S08}).get_json()
    run = x.c.post("/api/agents/projects/%d/flow" % p["id"], json={"admin": "t"}).get_json()["run"]
    s = eng.store.one("SELECT id FROM step WHERE run=? LIMIT 1", (run,))
    eng.store.exec("UPDATE step SET state='needs_review', output='{}' WHERE id=?", (s["id"],))
    eng.store.exec("INSERT INTO review (run, step, title, body, data, state, created) VALUES (?,?,?,?,?,?,?)", (run, s["id"], "t", "b", "{}", "open", time.time()))
    rid = eng.store.one("SELECT MAX(id) AS i FROM review")["i"]
    codes = []

    def press():
        codes.append(x.app.test_client().post("/api/agents/reviews/%d/decide" % rid, json={"decision": "approve", "admin": "t"}).status_code)
    ts = [threading.Thread(target=press) for _ in range(20)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    x.c.post("/api/agents/runs/%d/stop" % run, json={"admin": "t"})
    return [] if codes.count(200) == 1 and max(codes) < 500 else ["answers: %s" % sorted(codes)]


attack("the rules page of a project that does not exist")(lambda x: [] if x.c.get("/api/agents/projects/999999/join_rules").status_code == 404 else ["not 404"])
attack("the rules page with an impossible project number")(lambda x: [] if x.c.get("/api/agents/projects/%d/join_rules" % 2 ** 70).status_code < 500 else ["a server error"])


@attack("the rules page of a project whose folder is gone")
def _no_folder(x):
    d = copy_rec(x)
    p = x.c.post("/api/agents/projects", json={"admin": "t", "name": "n%d" % random.randrange(10 ** 8), "folder": d}).get_json()
    shutil.rmtree(d)
    r = x.c.get("/api/agents/projects/%d/join_rules" % p["id"])
    return [] if r.status_code == 200 and len(r.get_json()["joins"]) == 5 else ["answered %d" % r.status_code]


@attack("a model's answer of the wrong shape changes no rule")
def _model_shape(x):
    from agentic import family2 as F2, join_rules as JR
    bad = []
    for ans in ({"joins": "x"}, {"joins": [1, None, "a"]}, {"joins": [{"join": JR.RULES[0]["join"], "evidence": "text", "note": {"a": 1}, "rule": "REWRITTEN"}]}, {}):
        merged = F2.merge_answer(JR.as_strategy(), ans)
        if len(merged) != 5 or any("REWRITTEN" in j["rule"] for j in merged):
            bad.append(str(ans)[:80])
    return bad


@attack("script tags in a CSV cell stay text on the page")
def _xss(x):
    js = open(os.path.join(APP, "app", "static", "js", "agents.js"), encoding="utf-8").read()
    a, b = js.index("function joinsView("), js.index("// Page 2, always:")
    prog = "const IC={check:'<svg></svg>',chev:''};const esc=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\"/g,'&quot;');const nf=String;" + js[a:b] + """
const evil='<img src=x onerror=alert(1)>';
const out=joinChecksView({summary:evil,limit_percent:5,rules:[{id:evil,title:evil,verdict:'broken',when_broken:[evil],checks:[{words:evil,broke:1,of:2,percent:50,file:evil,examples:[{[evil]:evil}]}]}]})
+joinsView([{id:'a',join:evil,title:evil,from:[evil],to:evil,column_map:{[evil]:[evil]},steps:[evil],when_broken:[evil],check:evil,agent_note:evil,code:{file:evil,function:evil,first:1,last:2},evidence:[{kind:evil,quote:evil,ref:evil}]}],{id:1,need:{a:evil},verified:{a:{by:evil,at:1}}});
console.log(out.includes('<img')?'RAW':'SAFE');"""
    p = os.path.join(x.case, "x.js")
    open(p, "w").write(prog)
    r = subprocess.run(["node", p], capture_output=True, text=True, timeout=30)
    return [] if r.stdout.strip() == "SAFE" else ["the page would run it: %s %s" % (r.stdout[:100], r.stderr[-300:])]


# --------------------------------------------------------------------------------------------------- odd but valid drives
attack("no command ever completes")(lambda x: judged(x, lambda d: [edit("nvme_command.csv", set_col(c, ""))(d) for c in ("ST", "ST.SCT", "ST.SC")] and None))
attack("every command has the same CID")(lambda x: judged(x, edit("nvme_command.csv", set_col("CID", "1"))))
attack("every command on queue 0")(lambda x: judged(x, edit("nvme_command.csv", set_col("SQID", "0"))))
attack("every command at the same moment")(lambda x: judged(x, edit("nvme_command.csv", set_col("Time Stamp", "0000.100000000000s"))))
attack("no time between any two rows")(lambda x: judged(x, edit("nvme_command.csv", set_col("Time Delta", "0 ns"))))
attack("opcodes nobody knows")(lambda x: judged(x, edit("nvme_command.csv", set_col("OPC", "0xFE (Vendor)"))))
attack("a status that cannot be read")(lambda x: judged(x, edit("nvme_command.csv", set_col("ST", "0xZZZZ"))))
attack("a read of four billion blocks")(lambda x: judged(x, edit("nvme_command.csv", set_col("NLB", "4294967295"))))
attack("every command failed")(lambda x: judged(x, lambda d: [edit("nvme_command.csv", set_col(c, v))(d) for c, v in (("ST", "0x0281 (Unrecovered Read Error)"), ("ST.SCT", "2"), ("ST.SC", "129"))] and None))


# --------------------------------------------------------------------------------------------------- many at once, on a loaded recording
def many(x, urls, n=60):
    bad = []

    def one(u):
        r = x.app.test_client().get(u)
        if r.status_code >= 500:
            bad.append("%s answered %d" % (u, r.status_code))
    ts = [threading.Thread(target=one, args=(urls[i % len(urls)],)) for i in range(n)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    return bad[:5]


def up(x):
    return F.SEEDED_IDS["uid"]


attack("sixty requests for rows at the same moment")(lambda x: many(x, ["/api/hier/uploads/%s/rows?level=%s&limit=50" % (up(x), k) for k in NAMES]))
attack("sixty sorted requests at the same moment")(lambda x: many(x, ["/api/hier/uploads/%s/rows?level=packets&sort=delta_ps&limit=50&offset=%d" % (up(x), i * 100) for i in range(10)]))


@attack("every column of every level can be sorted on")
def _sort_all(x):
    bad = []
    for level, keys in L.KEYS.items():
        for _c, sql, _f in keys:
            r = x.c.get("/api/hier/uploads/%s/rows?level=%s&sort=%s&limit=3&count=0" % (up(x), level, sql))
            if r.status_code >= 500:
                bad.append("%s %s: %d" % (level, sql, r.status_code))
    return bad[:5]


@attack("every filter on a column of every level")
def _filter_all(x):
    bad = []
    for level, keys in L.KEYS.items():
        for _c, sql, _f in keys[:12]:
            for op, v in (("eq", "1"), ("ne", "x"), ("in", ["a", 1]), ("contains", "%"), ("gt", "z"), ("lt", 1), ("ge", None), ("le", []), ("between", [1]), ("blank", None), ("notblank", None)):
                r = x.c.get("/api/hier/uploads/%s/rows" % up(x), query_string={"level": level, "limit": 3, "filters": json.dumps([{"col": sql, "column": sql, "op": op, "value": v}])})
                if r.status_code >= 500:
                    bad.append("%s %s %s: %d" % (level, sql, op, r.status_code))
    return bad[:5]


@attack("reading a recording while the rules run on it again")
def _read_while_rules(x):
    from nvme_hier import rules as RL
    from api import hier_api as H
    d = os.path.join(x.root, "uploads", up(x))
    done = threading.Event()
    bad = []

    def rules():
        try:
            RL.apply(H.db_of(d))
        finally:
            done.set()
    threading.Thread(target=rules, daemon=True).start()
    while not done.wait(0.02):
        r = x.app.test_client().get("/api/hier/uploads/%s/summary" % up(x))
        if r.status_code >= 500 and r.status_code != 503:
            bad.append("answered %d %s" % (r.status_code, r.get_data()[:200]))
            break
    done.wait(120)
    return bad


@attack("a formula in a CSV cell is neutralised in every export")
def _formula(x):
    out = os.path.join(x.case, "o.csv")
    with open(out, "w", newline="") as fh:
        L.CsvOut(fh).writerow(["=cmd|' /C calc'!A0", "+1+1", "-2", "@SUM(A1)", "ok"])
    row = next(csv.reader(open(out, newline="")))
    return [] if all(not c.startswith(("=", "+", "@")) for c in row) else ["left as a formula: %s" % row]


def main():
    signal.signal(signal.SIGALRM, F._alarm)
    x = X()
    x.root = tempfile.mkdtemp(prefix="fuzz_app_r6_")
    x.work = os.path.join(x.root, "work")
    os.makedirs(x.work)
    first, last = (int(sys.argv[1]), int(sys.argv[2])) if len(sys.argv) > 2 else (1, len(ATTACKS))
    try:
        x.app, x.c, _k, _r = F.setup(x.root)
        for a in ATTACKS[first - 1:last]:
            a(x)
    finally:
        shutil.rmtree(x.root, ignore_errors=True)
    bad = [r for r in RESULTS if r[2]]
    print("\n%d attacks, %d broke something: %s" % (len(RESULTS), len(bad), [r[0] for r in bad]))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
