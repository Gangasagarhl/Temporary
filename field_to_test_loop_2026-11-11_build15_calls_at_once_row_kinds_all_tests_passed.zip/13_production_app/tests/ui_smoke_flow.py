"""The whole flow clicked through in headless Chrome (port 9333), the way the admin uses the pages, with the stand-in.

    python3 tests/ui_smoke_flow.py

Home: your name, the folder ("Check" lists the five files), "Start the flow". Then the project's four pages
(1 Understand the data, 2 One tree, 3 Rules, defects, test cases, 4 Report): every decision is made with the page's
own buttons - the dictionaries, the strategy, the build, the tests, Family 3's rule picker (one item unticked, the
Errors switch and a level filter used), the rules, the result, stage 1 (the "Correct" signal card), stage 2
("Verified: write the test file") - until the flow finishes on the Report page. Checks that each page shows only its
own stage (no rules list before page 3), the links (tree, isolation tab, exports, report), the rules library, and that
no script error or failed request happened. Screenshots (light and dark) go to runs/ui_smoke_hier/flow_*.png.
The admin's own knowledge and isolation memory are set aside and put back (as in tests/test_flow.py).
"""
import json
import re
import os
import sys
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import test_flow as TF   # noqa: E402  (set aside / put back, the API helper)
from ui_smoke_hier import Chrome   # noqa: E402
from ui_smoke_agents import port_busy   # noqa: E402

BASE = TF.BASE
ADMIN = "flow-ui-test"
R = {"pass": 0, "fail": 0}
SHOTS = []


def check(name, ok, detail=""):
    R["pass" if ok else "fail"] += 1
    print("%s  %s%s" % ("PASS" if ok else "FAIL", name, ("  | " + str(detail)[:240]) if detail != "" else ""), flush=True)
    return ok


def shot(c, name):
    c.shot("flow_" + name)
    SHOTS.append(name)


def text(c, sel="#main"):
    return c.js("(document.querySelector(%s) || {innerText: ''}).innerText" % json.dumps(sel)) or ""


def main():
    if port_busy(9333):
        sys.exit("port 9333 is busy (another headless Chrome)")
    s0 = TF.api("GET", "/api/agents/settings")
    TF.MADE["settings"] = {k: s0.get(k) for k in ("runtime", "model", "slices")}
    TF.set_aside()
    TF.api("PUT", "/api/agents/settings", {"runtime": "standin", "slices": 5})
    c = Chrome()
    t0 = time.time()
    try:
        c.goto(BASE + "/#/")
        time.sleep(2)
        check("home: the flow's four stages are named, and nothing else is shown yet", "Understand the data" in text(c) and "Report" in text(c) and
              (c.js("document.querySelectorAll('.rb, nav#nav').length") or 0) == 0)
        check("home asks for no REA findings and no earlier tree (both come where they are used)", c.js("!document.getElementById('np-rea') && !document.getElementById('np-up')"))
        c.js("document.getElementById('adm').value = %s" % json.dumps(ADMIN))
        c.js("document.getElementById('np-folder').value = %s; document.getElementById('np-check').click()" % json.dumps(TF.FOLDER))
        time.sleep(1.5)
        n = c.js("document.querySelectorAll('#np-inv .file').length") or 0
        check("'Check' shows the five files with their levels", n == 5 and "All five levels are there" in text(c, "#np-inv"), n)
        c.js("document.getElementById('np-name').value = 'flow ui test'")
        shot(c, "1_home")
        c.js("document.getElementById('np-make').click()")
        time.sleep(3)
        proj = next((p for p in TF.api("GET", "/api/agents/state")["projects"] if p["name"] == "flow ui test"), None)
        check("'Start the flow' creates the analysis and opens its page", proj is not None and "#/p/" in (c.js("location.hash") or ""))
        if not proj:
            return
        TF.MADE["projects"].append(proj["id"])
        check("your name is kept and shown as initials", (c.js("document.getElementById('avatar').innerText") or "") == "F")
        check("the page shows the four stages as a stepper", (c.js("document.querySelectorAll('.stepper .stg').length") or 0) == 4)
        rid = next((r["id"] for r in TF.api("GET", "/api/agents/runs?project=%d" % proj["id"]) if r["kind"] == "flow"), None)
        clicks, seen, last, broken = [], set(), 0, []
        while time.time() - t0 < 1800:
            v = TF.view(rid)
            if time.time() - last > 30:
                TF.progress_line(v, "flow in the browser")
                last = time.time()
            if v["run"]["state"] != "running" or any(s["state"] == "failed" for s in v["steps"]):
                break
            if not any(r["state"] == "open" for r in v["reviews"]):
                time.sleep(2)
                continue
            time.sleep(1)
            c.js("location.hash = '#/p/%d'" % proj["id"])
            time.sleep(1.8)
            if "Something went wrong" in text(c):
                broken.append(text(c)[:200])
            title = c.js("(document.querySelector('.decide h3') || {}).innerText") or ""
            if not title:
                time.sleep(2)
                continue
            cur = c.js("(document.querySelector('.stg.cur .t') || {}).innerText") or ""
            if title.startswith("Data dictionary") and "dict" not in seen:
                seen.add("dict")
                check("a new decision rings the chime and the tab title shows how many wait", (c.js("window.__chimes") or 0) >= 1 and (c.js("document.title") or "").startswith("("),
                      (c.js("window.__chimes"), c.js("document.title")))
                check("page 1 opens by itself on the first decision, with nothing of the later stages", cur.startswith("1") and (c.js("document.querySelectorAll('.rb-item').length") or 0) == 0, cur)
                shot(c, "2_page1_decision")
            if title.startswith("The joining strategy") and "strat" not in seen:
                seen.add("strat")
                check("the page moves to 2 · One tree for the strategy, and page 1 shows done", cur.startswith("2") and "done" in (c.js("document.querySelector('.stg').innerText") or ""), cur)
                shot(c, "3_page2_strategy")
            if title.startswith("The rules to use") or title.startswith("What to look for"):
                check("page 3 opens for the rule picker", cur.startswith("3"), cur)
                # the rules browser (2026-11-09): sections and levels on the left, one level at a time, evidence under an item
                wait_for = lambda e: any(c.js(e) or time.sleep(0.3) for _ in range(40))      # noqa: E731
                wait_for("document.querySelectorAll('.rb .rb-lvl').length >= 10")
                check("the sidebar lists the sections, each with the five levels", (c.js("document.querySelectorAll('.rb .rb-sec').length") or 0) >= 2
                      and (c.js("document.querySelectorAll('.rb .rb-lvl').length") or 0) >= 10)
                c.js("document.querySelector('.rb-lvl[data-sec=errors][data-lvl=nvme_command]').click()")
                time.sleep(0.4)
                where = c.js("[...document.querySelectorAll('.rb .rb-item')].map(p => p.dataset.sec + '/' + p.dataset.lvl)") or []
                check("one click on a level shows only that section's level", where and set(where) == {"errors/nvme_command"}, set(where))
                c.js("document.querySelector('.rb-lvl[data-sec=errors][data-lvl=nvme_command]').click()")
                time.sleep(0.4)
                c.js("[...document.querySelectorAll('.rb .rb-open')].find(b => b.innerText.toLowerCase().includes('timeout')).click()")
                wait_for("document.querySelector('.rb-detail .rb-d')")
                d = (text(c, ".rb-detail") or "").lower()
                check("an opened item shows its source data (full paths), its procedure step by step, its code and the four buttons",
                      all(w in d for w in ("source data", "rules or procedure", "verified code", "nvme_transactions.csv", "edit rule/procedure", "run", "export csv")), d[:200])
                c.js("document.querySelector('.rb-lvl[data-sec=analytics][data-lvl=nvme_command]').click()")
                time.sleep(0.4)
                was = text(c, "[id^=sum]")
                c.js("document.querySelector('.rb-item[data-key$=\"/read_pattern\"] .rb-tick').click()")
                time.sleep(0.4)
                summ = text(c, "[id^=sum]")
                check("unticking an item updates the count", int(summ.split()[0]) == int(was.split()[0]) - 1, (was, summ))
                shot(c, "4_page3_picker")
            if title.startswith("Result:") and "timeout" in title.lower() and "res" not in seen:
                seen.add("res")
                check("an errors pattern's result asks for no choice of one error (2026-11-11)", not c.js("!!document.querySelector('.decide select[id^=df]')"))
            if title.startswith("The errors: stage 1 and stage 2") and "errs" not in seen:
                # (owner, 2026-11-11) the errors go to the errors page; each error to its own page; page 3 shows only where they stand
                seen.add("errs")
                check("page 3 shows the pattern's errors and where they stand, with the errors page", re.search(r"\d[\d,]* errors?\b.{0,12}stage 1 done", text(c) or "") is not None
                      and c.js("!!document.querySelector('a[href*=\"/errors\"]')"))
                c.js("location.hash = '#/p/%d/errors'" % proj["id"])
                time.sleep(3)
                check("the errors page lists the errors, each with 'Isolate this error'", (c.js("document.querySelectorAll('section.card table tr').length") or 0) >= 2
                      and "Isolate this error" in (text(c) or ""))
                shot(c, "5_errors_page")
                href = c.js("(document.querySelector('section.card table a.btn') || {}).href") or ""
                c.goto(href)
                time.sleep(4)
                h2 = c.js("[...document.querySelectorAll('h2')].map(x => x.innerText)") or []
                check("the error page has its six parts in the owner's order", [x.split(" · ")[0] for x in h2[:6]] == ["1", "2", "3", "4", "5", "6"] and "Isolation of the defect" in h2[2], h2)
                check("the commands around the error are a tree with expand", (c.js("document.querySelectorAll('#win button.exp').length") or 0) >= 1)
                c.js("document.getElementById('btn-isolate').click()")
                ok = any(c.js("!!document.getElementById('btn-name')") or time.sleep(1) for _ in range(180))
                check("'Isolate the defect' shows its progress and gives the dictionary's name of the defect", ok and "as the dictionary names it" in (text(c, "#iso-out") or "").lower(),
                      (ok, (text(c, "#iso-out") or "")[:160]))
                shot(c, "6_error_page_isolation")
                c.goto(BASE + "/#/p/%d/rules" % proj["id"])
                time.sleep(3)
            if title.startswith("REA findings"):
                check("page 2 asks for the REA findings, with 'Continue without'", cur.startswith("2") and c.js("!!document.querySelector('.decide button[data-norea]')"), cur)
            btn = (".decide .choice[data-sig=correct]" if c.js("!!document.querySelector('.decide .choice[data-sig=correct]')") else
                   ".decide button[data-norea]" if c.js("!!document.querySelector('.decide button[data-norea]')") else
                   ".decide .actions .btn.primary[data-dec=approve]")     # the card's own Approve (the join rules' hidden "Save as version" buttons are primary too)
            label = (c.js("(document.querySelector(%s + ' b') || document.querySelector(%s)).innerText" % (json.dumps(btn), json.dumps(btn))) or "").strip().split("\n")[0]
            c.js("document.querySelectorAll('.decide input[data-jr]').forEach(x => { if (!x.checked) x.click(); })")     # the admin ticks each rule for combining the files
            c.js("document.querySelector(%s).click()" % json.dumps(btn))
            clicks.append((title[:50], label))
            print("      [%4.0f s] clicked '%s' on '%s'" % (time.time() - t0, label, title[:60]), flush=True)
            time.sleep(2.5)
        v = TF.view(rid)
        check("the flow finished, decided entirely through the page's buttons", v["run"]["state"] == "finished" and not any(s["state"] == "failed" for s in v["steps"]),
              (v["run"]["state"], [s["title"] for s in v["steps"] if s["state"] == "failed"][:1]))
        labels = {lab for _t, lab in clicks}
        check("the plan and the end of the errors were decided with their own buttons", {"Run the chosen rules", "Done: write the report"} <= labels, sorted(labels))
        check("the item unticked in the page did not run", not any("read_pattern" in s["key"] for s in v["steps"]))
        up = TF.api("GET", "/api/agents/projects/%d" % proj["id"]).get("upload_id")
        if up:
            TF.MADE["uploads"].add(up)
        tc = next((s for s in v["steps"] if s["key"].endswith(":testcase")), {})
        if (tc.get("output") or {}).get("path"):
            TF.MADE.setdefault("tests", []).append(tc["output"]["path"])
        c.js("location.hash = '#/p/%d'" % proj["id"])
        time.sleep(2.5)
        cur = c.js("(document.querySelector('.stg.cur .t') || {}).innerText") or ""
        steps_done = c.js("[...document.querySelectorAll('.stg')].every(s => s.classList.contains('done'))")
        check("when the flow is finished the page opens on 4 · Report, and every stage shows done", cur.startswith("4") and steps_done, cur)
        tiles = text(c, ".tiles")
        check("the report page sums it up: dictionaries, windows, rules, errors found, isolated, stage 2, test files",
              all(x in tiles for x in ("data dictionaries", "rules run", "errors found", "isolated (stage 1 done)", "stage 2 done", "test files")), tiles[:160])
        href = c.js("([...document.querySelectorAll('a')].find(a => a.innerText.includes('Open the flow report')) || {}).href") or ""
        try:
            page = urllib.request.urlopen(href).read() if href else b""
            check("the flow report opens, with where each error stands", b"Family 3" in page and b"The errors: stage 1, stage 2" in page)
        except Exception as e:      # noqa: BLE001
            check("the flow report opens", False, e)
        shot(c, "7_page4_report")
        check("the analysis page says who started the flow", "started by " + ADMIN in (c.js("document.querySelector('.phead .meta').innerText") or ""))
        c.js("[...document.querySelectorAll('[data-act=start-flow]')].find(b => b.innerText.includes('Run the flow again')).click()")
        time.sleep(1)
        check("'Run the flow again' first asks who is starting it (filled in with the last name used)",
              (c.js("document.querySelector('#modal h2').innerText") or "") == "Who is starting this flow?" and c.js("document.getElementById('st-name').value") == ADMIN)
        c.js("document.querySelector('#modal [data-act=close]').click()")
        time.sleep(0.5)
        c.js("document.querySelector('.stg[data-stage=rules]').click()")
        time.sleep(2)
        c.js("document.querySelectorAll('details.group').forEach(d => d.open = true)")
        time.sleep(0.5)
        links = c.js("[...document.querySelectorAll('#main a')].map(a => a.innerText)") or []
        check("page 3 links the errors page and the exports, and shows the test files", any("errors page" in x for x in links) and any("export" in x.lower() for x in links) and "test file" in text(c), links[:8])
        shot(c, "8_page3_done")
        c.js("document.querySelector('.stg[data-stage=tree]').click()")
        time.sleep(2)
        check("page 2 shows the tree's tests as figures and opens the tree", "random windows" in text(c, ".tiles") and any("Open the tree" in x for x in (c.js("[...document.querySelectorAll('#main a')].map(a => a.innerText)") or [])))
        c.js("location.hash = '#/library'")
        time.sleep(2)
        check("the rules library opens from page 3 (and only lists, then shows one rule at a time)", (c.js("document.querySelectorAll('.rb-lib .rb-item').length") or 0) >= 2)
        c.js("document.querySelector('.rb-lib .rb-open').click()")
        time.sleep(2)
        check("one item shows its source data, its procedure and its code", all(w in text(c).lower() for w in ("source data", "rules or procedure", "code")))
        shot(c, "9_library")
        c.js("location.hash = '#/history'")
        time.sleep(1.5)
        check("History lists the flow", "The flow" in text(c))
        c.js("document.getElementById('open-settings').click()")
        time.sleep(1)
        check("Settings open as a dialog with the three places the agents can run", (c.js("document.querySelectorAll('#set-rt button').length") or 0) == 3)
        c.js("document.querySelector('#modal [data-act=close]').click()")
        c.send("Emulation.setEmulatedMedia", features=[{"name": "prefers-color-scheme", "value": "dark"}])
        c.js("location.hash = '#/p/%d/rules'" % proj["id"])
        time.sleep(2)
        shot(c, "10_page3_dark")
        c.js("location.hash = '#/'")
        time.sleep(2)
        shot(c, "11_home_dark")
        print("screenshots: runs/ui_smoke_hier/flow_*.png (%d)" % len(SHOTS))
        check("no script error and no failed request in the whole walk", not c.errors, c.errors[:3])
        check("the page never showed 'Something went wrong' (an error the page caught itself)", not broken, broken[:2])
    finally:
        c.close()
        TF.put_back()
    print("%d checks, %d failed, %.0f s" % (R["pass"] + R["fail"], R["fail"], time.time() - t0))
    sys.exit(1 if R["fail"] else 0)


if __name__ == "__main__":
    main()
