"""Family 3 on Family 2's tree (owner, 2026-11-10: "it needs to talk to family two and family one ... otherwise it cannot come to the rules"):
a procedure on "the tree", code with run(tree, out_csv) that reads only through nvme_hier.tree_api, run in the confined process with read-only
access to the tree's database and nothing else.

    python3 -m pytest -q tests/test_tree_contract.py
"""
import csv
import json
import os
import shutil
import sqlite3
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
sys.path.insert(0, os.path.join(APP, "app"))

from agentic import procedures as PR   # noqa: E402
from nvme_hier import tree_api as T    # noqa: E402

S17 = os.path.join(APP, "uploads", "up-20261108-123729-0a98", "hier.sqlite")

GOOD = '''import csv


def run(tree, out_csv):
    # step 1: every Write command, with how many packets are under it in the tree
    counts, rows_read = {}, 0
    for p in tree.rows("packets", with_ancestor="nvme_command"):
        rows_read += 1
        if p.ancestor is not None:
            counts[p.ancestor] = counts.get(p.ancestor, 0) + 1
    out = []
    for c in tree.rows("nvme_command"):
        if c.get("OPC", "").split(" ")[0] == "0x01":
            out.append([c.row, c.get("ST.SC", ""), counts.get(c.row, 0)])
    with open(out_csv, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["command row", "status code", "packets under it"])
        w.writerows(out)
    return {"rows_read": rows_read, "rows_written": len(out), "total": None}
'''


@pytest.fixture(scope="module")
def tree_db(tmp_path_factory):
    if not os.path.exists(S17):
        pytest.skip("the S17 sample tree is not on this machine")
    d = tmp_path_factory.mktemp("tree")
    p = str(d / "hier.sqlite")
    src = sqlite3.connect("file:%s?mode=ro" % S17, uri=True)
    dst = sqlite3.connect(p)
    src.backup(dst)
    src.close()
    dst.execute("PRAGMA journal_mode=WAL")       # as the loader leaves it: the confined reader needs its side files too
    dst.close()
    return p


def test_a_procedure_on_the_tree_names_columns_with_their_level():
    ok = PR.validate({"source_data": [{"file": "the tree", "columns": ["nvme_command: OPC", "packets: TLP Type"]}], "steps": ["count"],
                      "output": {"columns": ["n"], "order": ""}})
    assert ok["source_data"][0]["file"] == "the tree"
    with pytest.raises(ValueError, match="named with its level"):
        PR.validate({"source_data": [{"file": "the tree", "columns": ["OPC"]}], "steps": ["count"], "output": {"columns": ["n"], "order": ""}})
    assert PR.uses_tree(ok) and not PR.uses_tree({"source_data": [{"file": "link.csv", "columns": []}]})


def test_the_code_check_holds_the_tree_contract():
    assert PR.check_code(GOOD, tree=True) == []
    bad = PR.check_code(GOOD.replace('tree.rows("nvme_command")', 'csv.reader(open("/data/nvme_command.csv"))'), tree=True)
    assert any("never the CSV files" in p for p in bad)
    assert any("takes two values" in p or "two values" in p for p in PR.check_code("def run(tree):\n    return {}\n", tree=True))
    assert PR.check_code("import sqlite3\ndef run(tree, out_csv):\n    return {}\n", tree=True)        # no database of its own


def test_the_code_runs_on_the_tree_in_the_confined_process(tree_db, tmp_path):
    code = tmp_path / "rule.py"
    code.write_text(GOOD)
    out = tmp_path / "out" / "result.csv"
    out.parent.mkdir()
    res = PR.run_code(str(code), {PR.TREE: tree_db}, str(out), str(tmp_path / "box"), timeout=120)
    assert res.get("ok"), res
    rows = list(csv.reader(open(out)))
    assert rows[0] == ["command row", "status code", "packets under it"]
    by_row = {int(r[0]): r for r in rows[1:]}
    t = T.Tree(tree_db)            # held open while the next tests run: as the server holds the tree open while a rule runs
    pytest.held_tree = t
    assert 155 in by_row and by_row[155][1] == "" and int(by_row[155][2]) == len(t.descendants("nvme_command", 155, "packets"))
    calls = json.loads((tmp_path / "box" / "stdout.txt").read_text().strip().splitlines()[-1]).get("tree_calls")
    assert calls == {"rows": 2}


def test_code_on_the_tree_cannot_reach_the_raw_files(tree_db, tmp_path):
    csv_file = os.path.join(APP, "samples", "clean_five_files", "S17_io_timeout_abort_reset", "nvme_command.csv")
    sneaky = ("import json\n\ndef run(tree, out_csv):\n    f = json.codecs.open(%r)\n    f.read(10)\n    return {}\n") % csv_file
    code = tmp_path / "rule.py"
    code.write_text(sneaky)
    res = PR.run_code(str(code), {PR.TREE: tree_db}, str(tmp_path / "o.csv"), str(tmp_path / "box2"), timeout=60)
    assert not res.get("ok") and ("Permission" in (res.get("error") or "") or "denied" in (res.get("error") or "").lower()), res


def test_the_coder_is_given_the_tree_and_family_one_not_raw_paths(tree_db, monkeypatch):
    monkeypatch.setattr(PR, "source_paths", lambda up: {PR.TREE: tree_db, "nvme_command.csv": "/somewhere/nvme_command.csv"})
    proc = {"source_data": [{"file": "the tree", "columns": ["nvme_command: OPC", "nvme_transaction: Type"]}], "steps": ["s"], "output": {"columns": ["x"], "order": ""}}
    ctx = PR.coder_context_tree({"name": "t"}, proc, "up")
    tt = ctx["THE_TREE"]
    assert "Never join two levels again" in tt["guide"] and tt["rows_per_level"]["nvme_command"] == 608
    assert tt["rows_without_a_parent"]["nvme_transaction"] >= 0 and "packets" in tt["context_rows"]
    assert {c["name"] for c in tt["COLUMNS"]} == {"OPC", "Type"} and any(v.startswith("0x") for v in tt["COLUMNS"][0]["real_values_seen"])
    assert "/somewhere" not in json.dumps(ctx)


def test_the_detector_columns_are_the_same_in_both_places():
    from agentic import family3 as F3
    assert tuple(F3.PR_DETECTOR_OUTPUT) == tuple(PR.DETECTOR_OUTPUT)


def test_a_decision_cards_question_sees_families_one_and_two_and_can_query_the_tree():
    import tempfile, time
    sys.path.insert(0, HERE)
    import fuzz_app as F
    import fuzz_deep as FD
    import test_agent_layer as TA
    from agentic import core
    from api import agentic_api as A
    root = tempfile.mkdtemp(prefix="cardask_%d_" % os.getpid())
    kick = core.Engine.kick
    try:
        app, c, _k, _r = F.setup(root)
        core.Engine.kick = F.REAL_KICK or kick
        s17 = os.path.join(APP, "samples", "clean_five_files", "S17_io_timeout_abort_reset")
        pid = c.post("/api/agents/projects", json={"admin": "t", "name": "card ask", "folder": s17}).get_json()["id"]
        rid = c.post("/api/agents/projects/%d/flow" % pid, json={"admin": "t"}).get_json()["run"]
        t0, rv = time.time(), None
        while time.time() - t0 < 400:
            v = c.get("/api/agents/runs/%d" % rid).get_json()
            rv = next((q for q in v["reviews"] if q["state"] == "open"), None)
            if rv is None:
                time.sleep(0.3)
                continue
            st = next(s for s in v["steps"] if s["id"] == rv["step"])
            if st["key"] in ("independent", "slice_test", "breaker") or st["key"].endswith(":result"):
                break
            edits = {"selected": ["errors/nvme_command/cmd_timeout"]} if st["key"] == "f3_plan" else FD.edits_for(st["key"], rv.get("data") or {}, TA.Yes())
            c.post("/api/agents/reviews/%d/decide" % rv["id"], json={"decision": "approve", "admin": "t", "edits": edits})
        assert rv is not None, "no decision card reached"
        with app.app_context():
            eng = A.engine()
        seen = []

        def fake(run_id, agent, instruction, ctx, shape, must, standin, **kw):
            seen.append((instruction, json.loads(ctx)))
            if len(seen) == 1:
                return {"answer": "", "queries": ["SELECT COUNT(*) AS n FROM cmd WHERE opc = 1 AND sqid != 0 AND sct IS NULL"]}, "test model", None
            n = seen[-1][1]["query_results"][0]["rows"][0][0]
            return {"answer": "%d writes never completed." % n, "queries": []}, "test model", None
        real = eng.runner.ask
        eng.runner.ask = fake
        try:
            r = c.post("/api/agents/reviews/%d/ask" % rv["id"], json={"message": "how many writes never completed?", "admin": "t"}).get_json()
        finally:
            eng.runner.ask = real
        assert "writes never completed" in r["answer"] and "Looked at the recording with 1 query" in r["answer"], r
        first = seen[0][1]
        assert "the_tree" in first and first["the_tree"]["rows_per_table"]["cmd"] == 608 and "joins" in first["the_tree"]
        assert first["joining_rules_family_2"] and "column_meanings_family_1" in first and "read-only SQL" in seen[0][0]
    finally:
        core.Engine.kick = kick
        import shutil
        shutil.rmtree(root, ignore_errors=True)
