"""The two NVMe command rules the owner keeps (2026-11-09): cmd.timeout (NVMe command timeout) and cmd.read_failure (the
most common NVMe failure: a Read that does not return its data).

    python3 -m pytest -q tests/test_command_rules.py

On a COPY of the S17 tree (the user's upload is never touched). The expected findings are worked out here independently, in
plain Python over the command rows: never completed (no status, the recording went on for the host's limit), aborted by the
host (0/07h, 3/71h), over the host's limit, slower than usual per command type and size (robust usual time, at least 20 of them);
long-by-nature commands and the Asynchronous Event Request are never judged; the read failures come from the command rows
alone; a full load and the re-run agree; the retired Write rule's findings go away; the per-group quantiles are right.
"""
import json
import os
import random
import shutil
import sqlite3
import sys
from collections import defaultdict

import math
import statistics

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from nvme_hier import rules as RL   # noqa: E402

SRC = os.path.join(os.path.dirname(HERE), "uploads", "up-20261108-123729-0a98", "hier.sqlite")
pytestmark = pytest.mark.skipif(not os.path.exists(SRC), reason="the S17 sample upload is not on this machine")
S, IO, ADM = 10 ** 12, 30 * 10 ** 12, 60 * 10 ** 12
NOT_TIMED = {0x80, 0x84, 0x14, 0x10, 0x11, 0x0C}


@pytest.fixture
def db(tmp_path):
    p = str(tmp_path / "hier.sqlite")
    con, out = sqlite3.connect(SRC), sqlite3.connect(p)
    con.backup(out)
    out.close()
    con.close()
    return p


def lin(v, q):
    v = sorted(v)
    k = (len(v) - 1) * q
    f = int(k)
    return v[f] + (v[min(f + 1, len(v) - 1)] - v[f]) * (k - f)


def usual_limit(v):
    """The limit of slower than usual, written here again from its definition, without the detector's code."""
    x, cut = sorted(t for t in v if t > 0), None
    n = len(x)
    for i in range(max(1, math.ceil(n * 0.1)), n):
        if x[i] >= 3 * x[i - 1] and (n - i <= max(3, n * 0.1) or (x[i] >= 10 * x[i - 1] and (n - i) / n <= 0.65)):
            if n - i <= 2 and x[i] / x[i - 1] < min(5, math.exp(1.8 * math.log(x[int((i - 1) * 0.9)] / x[(i - 1) // 2]) / 1.2816)):
                continue
            cut = i
            break
    return round((x[:cut] if cut else x)[-1] * 3)


def expected(p):
    """{rowid: kind} worked out from the command rows, independently of the detector."""
    con = sqlite3.connect(p)
    first = {p: t for p, t in con.execute("SELECT parent, MIN(t_ps) FROM ntx WHERE parent_level = 'nvme_command' AND lower(type) LIKE "
                                           "'%completion queue entry%' GROUP BY parent")}
    rows = [(rid, opc, sqid, sct, sc, (first[rid] - t) if rid in first and t is not None else None, t, -1 if sqid == 0 or nlb is None else nlb)
            for rid, opc, sqid, sct, sc, t, nlb in con.execute("SELECT rowid_file, opc, sqid, sct, sc, t_ps, nlb FROM cmd")]
    con.close()
    end = max(r[6] for r in rows if r[6] is not None)
    durs = defaultdict(list)
    for rid, opc, sqid, sct, sc, dur, t, blk in rows:
        if dur is not None and not (sqid == 0 and opc in NOT_TIMED):
            durs[(sqid == 0, opc, blk)].append(dur)
    bars = {g: usual_limit([x for x in v if x < (ADM if g[0] else IO)]) for g, v in durs.items() if len([x for x in v if x < (ADM if g[0] else IO)]) >= 20}
    out = {}
    for rid, opc, sqid, sct, sc, dur, t, blk in rows:
        if sqid == 0 and opc in NOT_TIMED:
            continue
        lim = ADM if sqid == 0 else IO
        if sct is None and sc is None:
            if end - t >= lim:
                out[rid] = "never completed"
        elif (sct or 0, sc or 0) in ((0, 7), (0, 8), (3, 0x71)):
            out[rid] = "aborted by the host"
        elif dur is not None and dur >= lim:
            out[rid] = "over the host's limit"
        elif dur is not None and (sqid == 0, opc, blk) in bars and dur > round(bars[(sqid == 0, opc, blk)]):
            out[rid] = "slower than usual"
    reads = {rid for rid, opc, sqid, sct, sc, dur, t, blk in rows if opc == 2 and sqid != 0 and ((sct or 0), (sc or 0)) not in ((0, 0), (0, 7), (0, 8), (3, 0x71))}
    return out, reads


def found(p, rule):
    con = sqlite3.connect(p)
    got = {r: json.loads(d).get("kind") for r, d in con.execute("SELECT rowid, detail FROM finding WHERE rule=?", (rule,))}
    con.close()
    return got


def test_the_timeout_rule_files_exactly_the_commands_worked_out_from_the_rows(db):
    r = RL.rerun_command_rules(db, {})
    want, reads = expected(db)
    got = found(db, "cmd.timeout")
    assert got == want
    kinds = sorted(got.values())
    # S17: the 7 Writes once called slow (one group for all sizes) were 64- and 256-block Writes, normal for their size
    assert kinds.count("never completed") == 6 and kinds.count("aborted by the host") == 1 and kinds.count("slower than usual") == 0
    assert r["after"] == {"cmd.timeout": 7, "cmd.read_failure": len(reads)} and r["timing"]["open_at_end"] == 0
    usual = {(u["admin"], u["command"], u["blocks"]): u for u in r["timing"]["usual"]}
    assert usual[(False, "Write", 8)]["n"] == 66 and usual[(False, "Write", 256)]["bar_ps"] is None   # 5 Writes of 256 blocks < 20
    assert usual[(True, "Abort (admin)", None)]["bar_ps"] is None and sum(u["n"] for k, u in usual.items() if k[1] == "Write") == 175
    assert sum(u["n"] for k, u in usual.items() if k[1] == "Read") == 360


def test_long_by_nature_and_the_event_request_are_never_judged_for_time(db):
    con = sqlite3.connect(db)
    # an Asynchronous Event Request that never completes, and a Format that took 10 minutes: both normal
    t = con.execute("SELECT MIN(t_ps) FROM cmd").fetchone()[0]
    base = con.execute("SELECT MAX(rowid_file) FROM cmd").fetchone()[0]
    con.execute("INSERT INTO cmd (rowid_file, n, opc, sqid, cid, t_ps) VALUES (?, ?, 12, 0, 900, ?)", (base + 1, base + 1, t))
    con.execute("INSERT INTO cmd (rowid_file, n, opc, sqid, cid, sct, sc, dur_ps, t_ps) VALUES (?, ?, 128, 0, 901, 0, 0, ?, ?)", (base + 2, base + 2, 600 * S, t))
    con.commit()
    con.close()
    RL.rerun_command_rules(db, {})
    got = found(db, "cmd.timeout")
    assert base + 1 not in got and base + 2 not in got and got == expected(db)[0]


def test_a_command_still_open_at_the_end_is_not_judged_and_the_hosts_limit_counts(db):
    con = sqlite3.connect(db)
    end = con.execute("SELECT MAX(t_ps) FROM cmd").fetchone()[0]
    base = con.execute("SELECT MAX(rowid_file) FROM cmd").fetchone()[0]
    con.execute("INSERT INTO cmd (rowid_file, n, opc, sqid, cid, t_ps) VALUES (?, ?, 1, 3, 950, ?)", (base + 1, base + 1, end - 5 * S))   # 5 s before the end
    r = con.execute("SELECT MIN(rowid_file) FROM cmd WHERE opc = 2 AND sqid != 0 AND sc = 0").fetchone()[0]
    con.execute("UPDATE ntx SET t_ps = (SELECT t_ps FROM cmd WHERE rowid_file = ?) + ? WHERE parent = ? AND parent_level = 'nvme_command' "
                "AND lower(type) LIKE '%completion queue entry%'", (r, 31 * S, r))
    con.commit()
    con.close()
    r = RL.rerun_command_rules(db, {})
    got = found(db, "cmd.timeout")
    assert base + 1 not in got and r["timing"]["open_at_end"] == 1
    assert "over the host's limit" in got.values() and got == expected(db)[0]
    # the admin's own limit (page 3) is used instead of 30 s
    r = RL.rerun_command_rules(db, {"nvme_command": {"ps": 100 * S, "source": "admin"}})
    assert "over the host's limit" not in found(db, "cmd.timeout").values()


def test_read_failures_come_from_the_command_rows_alone(db):
    con = sqlite3.connect(db)
    a, b, c = [r for (r,) in con.execute("SELECT rowid_file FROM cmd WHERE opc = 2 AND sqid != 0 AND sc = 0 AND sct = 0 ORDER BY rowid_file LIMIT 3")]
    con.execute("UPDATE cmd SET sct = 2, sc = 129 WHERE rowid_file = ?", (a,))      # Unrecovered Read Error
    con.execute("UPDATE cmd SET sct = 0, sc = 4 WHERE rowid_file = ?", (b,))        # Data Transfer Error
    con.execute("UPDATE cmd SET sct = 3, sc = 113 WHERE rowid_file = ?", (c,))      # aborted by the host: a timeout, not a read failure
    con.commit()
    con.close()
    RL.rerun_command_rules(db, {})
    assert set(found(db, "cmd.read_failure")) == {a, b} == expected(db)[1]
    con = sqlite3.connect(db)
    name = con.execute("SELECT name FROM finding WHERE rule = 'cmd.read_failure' AND rowid = ?", (a,)).fetchone()[0]
    con.close()
    assert "Unrecovered Read Error" in name and "2h, code 81h" in name and found(db, "cmd.timeout")[c] == "aborted by the host"


def test_usual_is_per_command_type_and_size(db):
    con = sqlite3.connect(db)
    # the same Writes, but half of them moved 256 blocks and took 3 times as long: by size, none of those is unusual
    ws = [r for (r,) in con.execute("SELECT rowid_file FROM cmd WHERE opc = 1 AND sqid != 0 AND dur_ps IS NOT NULL ORDER BY rowid_file")]
    for r in ws[::2]:
        con.execute("UPDATE cmd SET nlb = 255 WHERE rowid_file = ?", (r,))
        con.execute("UPDATE ntx SET t_ps = (SELECT t_ps FROM cmd WHERE rowid_file = ?) + 3 * (t_ps - (SELECT t_ps FROM cmd WHERE rowid_file = ?)) "
                    "WHERE parent = ? AND parent_level = 'nvme_command' AND lower(type) LIKE '%completion queue entry%'", (r, r, r))
    slow = next(r for r in ws[1::2] if con.execute("SELECT nlb FROM cmd WHERE rowid_file = ?", (r,)).fetchone()[0] == 15)      # one really slow Write in a group of 20 or more, so that the words about its size can be checked
    con.execute("UPDATE ntx SET t_ps = (SELECT t_ps FROM cmd WHERE rowid_file = ?) + 200 * (t_ps - (SELECT t_ps FROM cmd WHERE rowid_file = ?)) "
                "WHERE parent = ? AND parent_level = 'nvme_command' AND lower(type) LIKE '%completion queue entry%'", (slow, slow, slow))
    con.commit()
    con.close()
    RL.rerun_command_rules(db, {})
    assert found(db, "cmd.timeout") == expected(db)[0]
    con = sqlite3.connect(db)
    names = [n for (n,) in con.execute("SELECT name FROM finding WHERE rule = 'cmd.timeout' AND name LIKE '%longer than usual%'")]
    con.close()
    assert names and all(" blocks took " in n for n in names)


def test_a_full_load_and_the_rerun_agree_and_the_retired_write_rule_goes_away(db, tmp_path):
    con = sqlite3.connect(db)
    con.execute("INSERT INTO finding (level, rule, name, severity, table_name, rowid) VALUES ('nvme_command', 'cmd.write_slow', 'old', 'error', 'cmd', 1)")
    con.commit()
    con.close()
    other = str(tmp_path / "rerun.sqlite")
    shutil.copy(db, other)
    RL.apply(db, {})
    r = RL.rerun_command_rules(other, {})
    assert r["before"].get("cmd.write_slow", 0) >= 1 and not found(other, "cmd.write_slow") and not found(db, "cmd.write_slow")
    assert found(db, "cmd.timeout") == found(other, "cmd.timeout") and len(found(db, "cmd.timeout")) == 7
    con = sqlite3.connect(db)
    rep = json.loads(con.execute("SELECT v FROM meta WHERE k='rules'").fetchone()[0])
    assert rep["by_rule"]["cmd.timeout"] == 7 and rep["timing"]["host_io_ps"] == IO


def test_quantiles_per_group_are_the_usual_linear_ones():
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE t (g INTEGER, h INTEGER, v REAL)")
    rnd, vals = random.Random(3), defaultdict(list)
    for _ in range(4000):
        g, h, v = rnd.randint(0, 2), rnd.randint(0, 1), rnd.expovariate(1 / 50.0)
        vals[(g, h)].append(v)
        con.execute("INSERT INTO t VALUES (?, ?, ?)", (g, h, v))
    got = RL.group_quantiles(con, "SELECT g, h, v FROM t", ("g", "h"), "v")
    assert set(got) == set(vals)
    for k, v in vals.items():
        n, q = got[k]
        assert n == len(v) and all(abs(q[x] - lin(v, x)) < 1e-9 for x in (0.25, 0.5, 0.75))
    n, q = RL.quantiles(con, "SELECT v FROM t")
    assert n == 4000 and abs(q[0.5] - lin([x for v in vals.values() for x in v], 0.5)) < 1e-9


def recount_from_csv(folder):
    """The card's lines, followed on the two raw CSV files with the csv module only: {NVMe Cmd number: kind}."""
    import csv
    csv.field_size_limit(10 ** 9)

    def ps(ts):
        ts = (ts or "").strip().rstrip("s")
        if not ts:
            return None
        a, _, b = ts.partition(".")
        return int(a) * S + int((b + "0" * 12)[:12])

    def num(v):
        v = (v or "").strip().split(" ")[0]
        return None if not v else int(v, 16) if v.lower().startswith("0x") else int(v)

    def rows(path, names):
        with open(path, newline="", encoding="utf-8-sig") as fh:
            r = csv.reader(fh)
            head = next(r)
            idx = {n: head.index(n) for n in names}
            for row in r:
                yield {n: (row[i] if i < len(row) else "") for n, i in idx.items()}
    cmds = [{"n": int(r["NVMe Cmd"]), "opc": num(r["OPC"]), "sqid": num(r["SQID"]), "cid": num(r["CID"]), "nlb": num(r["NLB"]), "sct": num(r["ST.SCT"]),
             "sc": num(r["ST.SC"]), "t": ps(r["Time Stamp"]), "end": None}
            for r in rows(os.path.join(folder, "nvme_command.csv"), ["NVMe Cmd", "OPC", "SQID", "CID", "NLB", "ST.SCT", "ST.SC", "Time Stamp"])]
    last = max(c["t"] for c in cmds if c["t"] is not None)
    by_id = defaultdict(list)
    for c in sorted(cmds, key=lambda c: (c["t"] or 0, c["n"])):
        by_id[(c["sqid"], c["cid"])].append(c)
    for r in rows(os.path.join(folder, "NVME_Transactions.csv"), ["Type", "SQID", "CID", "Time Stamp"]):
        ty = r["Type"].lower()
        if "completion" not in ty or "doorbell" in ty or "submission" in ty:      # the entry, not the head doorbell
            continue
        t = ps(r["Time Stamp"])
        sent = [c for c in by_id.get((num(r["SQID"]), num(r["CID"])), []) if c["t"] is not None and t is not None and c["t"] <= t]
        if sent and sent[-1]["end"] is None:          # the newest command with that SQID and CID; its first completion entry only
            sent[-1]["end"] = t
    out, groups = {}, defaultdict(list)
    key = lambda c: (c["sqid"] == 0, c["opc"], -1 if c["sqid"] == 0 or c["nlb"] is None else c["nlb"])
    for c in cmds:
        c["dur"] = c["end"] - c["t"] if c["end"] is not None else None
        if c["dur"] is not None and not (c["sqid"] == 0 and c["opc"] in NOT_TIMED):
            groups[key(c)].append(c["dur"])
    bar = {g: usual_limit([x for x in v if x < (ADM if g[0] else IO)]) for g, v in groups.items() if len([x for x in v if x < (ADM if g[0] else IO)]) >= 20}
    for c in cmds:
        if c["sqid"] == 0 and c["opc"] in NOT_TIMED:
            continue
        lim = ADM if c["sqid"] == 0 else IO
        if c["sct"] is None and c["sc"] is None:
            if last - c["t"] >= lim:
                out[c["n"]] = "never completed"
        elif ((c["sct"] or 0), (c["sc"] or 0)) in ((0, 7), (0, 8), (3, 0x71)):
            out[c["n"]] = "aborted by the host"
        elif c["dur"] is not None and c["dur"] >= lim:
            out[c["n"]] = "over the host's limit"
        elif c["dur"] is not None and key(c) in bar and c["dur"] > round(bar[key(c)]):
            out[c["n"]] = "slower than usual"
    return out


def test_the_card_followed_on_the_raw_csv_files_gives_the_same_findings(db):
    folder = os.path.join(os.path.dirname(HERE), "samples", "clean_five_files", "S17_io_timeout_abort_reset")
    RL.rerun_command_rules(db, {})
    con = sqlite3.connect(db)
    app = {n: json.loads(d)["kind"] for n, d in con.execute("SELECT c.n, f.detail FROM finding f JOIN cmd c ON c.rowid_file = f.rowid WHERE f.rule = 'cmd.timeout'")}
    con.close()
    assert recount_from_csv(folder) == app and len(app) == 7


def test_each_command_cycle_is_tracked_step_by_step_with_the_links_answer(db):
    con = sqlite3.connect(db)
    t = lambda r: con.execute("SELECT t_ps FROM cmd WHERE rowid_file = ?", (r,)).fetchone()[0]
    ok, stuck, aborted = RL.command_cycle(con, 154, t(154)), RL.command_cycle(con, 155, t(155)), RL.command_cycle(con, 144, t(144))
    assert ok["reached"] == ["submitted", "fetched", "prp", "data", "completed", "interrupt", "consumed"] and ok["answer"] == "positive"
    assert ok["tlps"] == 776 and ok["nak"] == ok["unacked"] == 0 and "all 776 packets ACKed" in ok["words"]
    assert stuck["reached"] == ["submitted", "fetched", "data"] and not stuck["completed"] and stuck["stopped_after"] == "data"
    assert aborted["completed"] and aborted["answer"] == "negative: status 0h/07h"
    # a NAK on one packet of the cycle is counted and said
    l = con.execute("SELECT l.rowid_file FROM ntx n JOIN spl s ON s.parent_level = 'nvme_transaction' AND s.parent = n.rowid_file "
                    "JOIN lnk l ON l.parent_level = 'split' AND l.parent = s.rowid_file WHERE n.parent = 154 LIMIT 1").fetchone()[0]
    con.execute("UPDATE lnk SET errors = 'Nak received, replayed 1 time' WHERE rowid_file = ?", (l,))
    con.commit()
    c = RL.command_cycle(con, 154, t(154))
    con.close()
    assert c["nak"] == 1 and "1 NAKed and replayed" in c["words"]
    # the findings carry the cycle
    RL.rerun_command_rules(db, {})
    con = sqlite3.connect(db)
    name, detail = con.execute("SELECT name, detail FROM finding WHERE rule = 'cmd.timeout' AND rowid = 155").fetchone()
    con.close()
    assert "its cycle stopped after the data" in name and json.loads(detail)["cycle"]["reached"] == ["submitted", "fetched", "data"]


def test_explicit_ack_no_means_a_later_ack_covered_the_packet(db):
    """PCIe ACKs are cumulative: on S17 every TLP is covered by an ACK from the other side carrying its sequence number or a
    later one (12-bit sequence numbers), whether the analyzer says Explicit ACK Yes or No."""
    import bisect
    con = sqlite3.connect(db)
    acks = defaultdict(list)
    for d, t, seq in con.execute("SELECT dir, t_ps, acknak FROM pkt WHERE dllp_type = 'ACK' AND acknak IS NOT NULL ORDER BY t_ps"):
        acks[d].append((t, int(seq)))
    other = {"Downstream": "Upstream", "Upstream": "Downstream"}
    seen = defaultdict(int)
    for psn, d, t, ex in con.execute("SELECT psn, dir, t_ps, explicit_ack FROM lnk WHERE psn IS NOT NULL AND tlp_type IS NOT NULL"):
        lst = acks[other[d]]
        i = bisect.bisect_left(lst, (t, -1))
        covered = any(((s - int(psn)) % 4096) < 2048 for _t, s in lst[i:i + 50])
        seen[(ex, covered)] += 1
    con.close()
    assert seen[("Yes", False)] == seen[("No", False)] == 0 and seen[("No", True)] > 10000 and seen[("Yes", True)] > 30000
