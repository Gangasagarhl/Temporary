"""The rules that combine the five files (owner, 2026-11-09): each one is shown, the admin checks each one, the check is tied to the code, and a recording that does
not follow a rule cannot be accepted without a written reason. The attacks are recordings broken in the ways a real export or a human can break them.

    python3 -m pytest -q tests/test_join_rules.py
"""
import csv
import json
import os
import random
import shutil
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
sys.path.insert(0, os.path.join(APP, "app"))
from agentic import family2 as F2, join_rules as JR  # noqa: E402
from nvme_hier import builder as B, loader as L  # noqa: E402

csv.field_size_limit(10 ** 9)
S08 = os.path.join(APP, "samples", "clean_five_files", "S08_interrupt_before_completion")
S17 = os.path.join(APP, "samples", "clean_five_files", "S17_io_timeout_abort_reset")
NAMES = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv", "nvme_command": "nvme_command.csv"}


def rows(p):
    with open(p, newline="", encoding="utf-8-sig", errors="replace") as f:
        return list(csv.reader(f))


def write(p, data):
    with open(p, "w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerows(data)


def blank(d, name, column, share=1.0):
    p = os.path.join(d, name)
    data = rows(p)
    i, rng = data[0].index(column), random.Random(1)
    for x in data[1:]:
        if i < len(x) and rng.random() < share:
            x[i] = ""
    write(p, data)


def drop(d, name, share):
    p = os.path.join(d, name)
    data, rng = rows(p), random.Random(2)
    write(p, data[:1] + [x for x in data[1:] if rng.random() >= share])


def shuffled(d, name):
    p = os.path.join(d, name)
    data = rows(p)
    body = data[1:]
    random.Random(3).shuffle(body)
    write(p, data[:1] + body)


def cut(d, name, keep):
    p = os.path.join(d, name)
    data = rows(p)
    write(p, data[:1 + int(len(data) * keep)])


def set_all(d, name, column, value):
    p = os.path.join(d, name)
    data = rows(p)
    i = data[0].index(column)
    for x in data[1:]:
        if i < len(x):
            x[i] = value
    write(p, data)


def other_recording(d):
    for n in ("link.csv", "split.csv", "NVME_Transactions.csv", "nvme_command.csv"):
        shutil.copy(os.path.join(S17, n), os.path.join(d, n))


def build(tmp_path, attack=None):
    if not os.path.isdir(S08):
        pytest.skip("the sample set is not on this machine")
    d = str(tmp_path / "rec")
    os.makedirs(d)
    for n in NAMES.values():
        shutil.copy(os.path.join(S08, n), os.path.join(d, n))
    if attack:
        attack(d)
    db = os.path.join(d, "h.sqlite")
    L.load_upload(db, {k: os.path.join(d, v) for k, v in NAMES.items()})
    B.build(db)
    return db


ATTACKS = [
    ("files of two recordings", other_recording, "packets_to_links"),
    ("no PSN in the packets", lambda d: blank(d, "packets.csv", "PSN"), "packets_to_links"),
    ("no PSN in 30% of the link rows", lambda d: blank(d, "link.csv", "PSN", .3), "packets_to_links"),
    ("half of the link rows missing", lambda d: drop(d, "link.csv", .5), "packets_to_links"),
    ("the packets in random order", lambda d: shuffled(d, "packets.csv"), "packets_to_links"),
    ("no CID in the NVMe transactions", lambda d: blank(d, "NVME_Transactions.csv", "CID"), "ntx_to_cmds"),
    ("no SQID in the commands", lambda d: blank(d, "nvme_command.csv", "SQID"), "ntx_to_cmds"),
    ("the last 40% of the commands cut", lambda d: cut(d, "nvme_command.csv", .6), "ntx_to_cmds"),
    ("Metrics.# Packets wrong everywhere", lambda d: set_all(d, "link.csv", "Metrics.# Packets", "9"), "packets_to_links"),
    ("no Address in the NVMe transactions", lambda d: blank(d, "NVME_Transactions.csv", "Address"), "units_to_ntx"),
    ("no Tag in the split rows", lambda d: blank(d, "split.csv", "Tag"), "links_to_splits"),
]


def test_a_clean_recording_follows_every_rule(tmp_path):
    r = JR.evaluate(build(tmp_path))
    assert not r["must_explain"], r["summary"]
    assert {x["verdict"] for x in r["rules"]} <= {"followed", "few"}


@pytest.mark.parametrize("name,attack,rule", ATTACKS, ids=[a[0] for a in ATTACKS])
def test_a_recording_that_breaks_a_rule_is_caught_on_that_rule(tmp_path, name, attack, rule):
    r = JR.evaluate(build(tmp_path, attack))
    hit = next(x for x in r["rules"] if x["id"] == rule)
    assert hit["verdict"] == "broken", "%s: %s" % (name, json.dumps(r["rules"], default=str)[:1500])
    assert r["must_explain"]
    bad = [c for c in hit["checks"] if c["verdict"] == "broken"]
    assert any(c["examples"] for c in bad), "no example rows are shown for: %s" % name


def test_rows_are_kept_not_dropped(tmp_path):
    db = build(tmp_path, lambda d: drop(d, "link.csv", .5))
    import sqlite3
    con = sqlite3.connect(db)
    n = con.execute("SELECT COUNT(*) FROM pkt").fetchone()[0]
    assert n == len(rows(os.path.join(S08, "packets.csv"))) - 1


def _step(key, output):
    return {"key": key, "output": json.dumps(output), "idx": 0}


def test_approval_is_refused_until_every_rule_is_ticked(tmp_path, monkeypatch):
    monkeypatch.setattr(F2.family1, "knowledge_dir", lambda: str(tmp_path))
    out = {"joins": JR.as_strategy(), "problems": [], "format": "f1"}
    some = [j["id"] for j in out["joins"]][:2]
    with pytest.raises(ValueError, match="check every rule"):
        F2.on_approve(None, {"id": 1}, _step("coder", out), {"edits": {"verified": some}}, "A")
    with pytest.raises(ValueError, match="check every rule"):
        F2.on_approve(None, {"id": 1}, _step("coder", out), {}, "A")
    assert F2.last_strategy("f1") is None, "a refused approval stored a strategy"
    F2.on_approve(None, {"id": 1}, _step("coder", out), {"edits": {"verified": [j["id"] for j in out["joins"]]}}, "A")
    st = F2.last_strategy("f1")
    assert set(st["verified"]) == {j["id"] for j in out["joins"]} and all(v["by"] == "A" for v in st["verified"].values())


def test_a_check_is_lost_when_the_code_changes(monkeypatch):
    joins = JR.as_strategy()
    ok = JR.record_check(None, [j["id"] for j in joins], "A")
    assert JR.needs_check(ok) == {}
    changed = json.loads(json.dumps(ok))
    changed["ntx_to_cmds"]["sha"] = "something else"
    need = JR.needs_check(changed)
    assert list(need) == ["ntx_to_cmds"] and "changed" in need["ntx_to_cmds"]
    with pytest.raises(ValueError):
        JR.record_check(changed, [], "A")
    again = JR.record_check(changed, ["ntx_to_cmds"], "B")
    assert again["ntx_to_cmds"]["by"] == "B" and again["packets_to_links"]["by"] == "A", "a rule that did not change kept its first check"


def test_a_broken_recording_needs_a_written_reason():
    out = {"join_checks": {"must_explain": True, "broken": ["Packets into link transactions"]}}
    with pytest.raises(ValueError, match="Write why"):
        F2.on_approve(None, {"id": 1}, _step("independent", out), {"edits": {"accept_reason": "   "}}, "A")
    F2.on_approve(None, {"id": 1}, _step("independent", out), {"edits": {"accept_reason": "known partial export"}}, "A")


def test_a_missing_column_needs_a_reason_before_the_build(tmp_path, monkeypatch):
    monkeypatch.setattr(F2.family1, "knowledge_dir", lambda: str(tmp_path))
    out = {"joins": JR.as_strategy(), "problems": ["uses columns that are not in the files: PSN"], "format": "f2"}
    with pytest.raises(ValueError, match="lack columns"):
        F2.on_approve(None, {"id": 1}, _step("coder", out), {"edits": {"verified": [j["id"] for j in out["joins"]]}}, "A")


def test_every_rule_names_columns_that_exist_and_code_that_exists():
    if not os.path.isdir(S17):
        pytest.skip("the sample set is not on this machine")
    for r in JR.RULES:
        for f, cols in r["column_map"].items():
            head = rows(os.path.join(S17, f))[0]
            assert not [c for c in cols if c not in head], (r["id"], f)
        first, last, sha = JR.code_of(r["code"])
        assert last > first and len(sha) == 12


@pytest.mark.parametrize("old", [{}, {"joins": []}, {"joins": [{"join": "packets -> link transaction", "rule": "a model's rewording", "columns": ["PSN"], "check": "x"}]}])
def test_an_older_strategy_shows_the_rules_the_code_applies(old):
    shown = F2._with_notes(old)
    assert [j["id"] for j in shown] == [r["id"] for r in JR.RULES]
    assert all("a model's rewording" not in j["rule"] for j in shown)
