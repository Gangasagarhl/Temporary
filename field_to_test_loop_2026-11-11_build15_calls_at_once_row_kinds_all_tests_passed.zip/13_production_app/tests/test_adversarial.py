"""Trying to break it (owner, 2026-11-09: "create the test cases to prove it is not working").

    python3 -m pytest -q tests/test_adversarial.py

Hostile inputs against the procedural graph, the signals and the CSV loader. Throw-away files, no server, no model.
Every test states what a correct system must do; a failure here is a defect of the application.
"""
import json
import os
import random
import shutil
import sqlite3
import sys
import threading

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
from nvme_hier import builder as B, loader as L, rules as RL, store as ST  # noqa: E402

S27 = os.path.join(APP, "samples", "clean_five_files", "S27_lcrc_nak_replay")
NAMES = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv", "nvme_command": "nvme_command.csv"}
A = [{"step": 1, "command": "Write", "position": "above"}, {"step": 2, "command": "Write", "position": "fault"}]
C = [{"step": 1, "command": "Flush", "position": "above"}, {"step": 2, "command": "Write", "position": "fault"}]


def sig(name="cmd.timeout", cmd="io.Write"):
    return {"fine": "fine-%s-%s" % (name, cmd), "coarse": "c-" + name, "display": name, "fields": {"lvl": "nvme_command", "err": name, "cmd": cmd, "part": "none", "cause": "self", "alg": "v1"}}


@pytest.fixture
def st(tmp_path):
    return ST.Store(str(tmp_path / "db" / "k.sqlite"))


def stored(st, s, steps=A):
    st.touch_signature(s, "D", upload_id="u", finding_id=abs(hash(s["fine"])) % 1000)
    return st.signal(s["fine"], None, "correct", "x", proposal_steps=steps, proposal_text="t")["new_procedure_id"]


# ------------------------------------------------------------------------------------------- signals that must be refused
def test_a_signal_cannot_touch_a_procedure_of_another_failure(st):
    a, b = sig("cmd.timeout"), sig("cmd.read_failure", "io.Read")
    pa = stored(st, a)
    stored(st, b, C)
    with pytest.raises(ValueError):
        st.signal(b["fine"], pa, "wrong", "x")


def test_a_signal_on_a_replaced_version_is_refused(st):
    s = sig()
    p = stored(st, s)
    st.signal(s["fine"], p, "correct_with_edits", "x", edited_steps=C, edited_text="e")
    with pytest.raises(ValueError):
        st.signal(s["fine"], p, "correct", "x")


@pytest.mark.parametrize("steps", [[], None])
def test_an_empty_procedure_is_never_stored(st, steps):
    s = sig()
    st.touch_signature(s, "D", upload_id="u", finding_id=1)
    with pytest.raises(ValueError):
        st.signal(s["fine"], None, "correct", "x", proposal_steps=steps, proposal_text="t")
    assert st.graph_paths(s["fine"]) == []


def test_edits_cannot_remove_the_defect_itself(st):
    s = sig()
    p = stored(st, s)
    with pytest.raises(ValueError):
        st.signal(s["fine"], p, "correct_with_edits", "x", edited_steps=[{"step": 1, "command": "Flush", "position": "above"}], edited_text="e")
    with pytest.raises(ValueError):
        st.signal(s["fine"], p, "wrong_with_edits", "x", edited_steps=[], edited_text="e")


def test_the_policy_never_offers_a_procedure_without_its_defect_step(st):
    s = sig()
    st.touch_signature(s, "D", upload_id="u", finding_id=1)
    st.add_procedure(s["fine"], [{"step": 1, "command": "Flush", "position": "above"}], "old row from before the check", "llm")
    assert st.graph_choice(s["fine"]) is None


def test_bad_exclude_values_do_not_crash_the_policy(st):
    s = sig()
    p = stored(st, s)
    assert st.graph_choice(s["fine"], exclude=["x", None, str(p)]) is None
    assert st.graph_choice(s["fine"], exclude=[None])["procedure_id"] == p


# ------------------------------------------------------------------------------------------- weights stay true
def test_every_weight_stays_between_0_and_1_and_inside_the_cap(st):
    s = sig()
    p = stored(st, s)
    for i in range(400):
        st.signal(s["fine"], p, "correct" if i % 3 else "wrong", "x")
    v = st.graph_view(s["fine"])
    for x in v["nodes"] + v["edges"]:
        assert 0 < x["weight"] < 1 and x["a"] + x["b"] <= ST.CAP + 1e-6, x


def test_the_graph_is_the_same_rebuilt_from_scratch_after_a_random_history(tmp_path):
    path = str(tmp_path / "db" / "k.sqlite")
    st = ST.Store(path)
    r = random.Random(7)
    sigs = [sig("cmd.timeout", c) for c in ("io.Write", "io.Read", "admin.Abort")]
    live = {}
    for s in sigs:
        live[s["fine"]] = [stored(st, s)]
    for i in range(300):
        s = r.choice(sigs)
        pid = r.choice(live[s["fine"]])
        kind = r.choice(ST.SIGNALS)
        edits = [{"step": 1, "command": "c%d" % i, "position": "above"}, {"step": 2, "command": "Write", "position": "fault"}]
        res = st.signal(s["fine"], pid, kind, "x", edited_steps=edits if "edits" in kind else None, edited_text="e")
        if res.get("new_procedure_id"):
            live[s["fine"]] = [x for x in live[s["fine"]] if x != pid] + [res["new_procedure_id"]]
    want = {s["fine"]: st.graph_view(s["fine"]) for s in sigs}
    con = sqlite3.connect(path)
    con.execute("DELETE FROM pnode")
    con.execute("DELETE FROM pedge")
    con.commit()
    con.close()
    again = ST.Store(path)
    for s in sigs:
        got = again.graph_view(s["fine"])
        assert sorted(json.dumps(n, sort_keys=True) for n in got["nodes"]) == sorted(json.dumps(n, sort_keys=True) for n in want[s["fine"]]["nodes"])
        assert sorted(json.dumps(e, sort_keys=True) for e in got["edges"]) == sorted(json.dumps(e, sort_keys=True) for e in want[s["fine"]]["edges"])


def test_signals_at_the_same_moment_are_all_counted(st):
    s = sig()
    p = stored(st, s)
    errors = []

    def go():
        try:
            st.signal(s["fine"], p, "correct", "x")
        except Exception as e:      # noqa: BLE001
            errors.append(repr(e))
    ts = [threading.Thread(target=go) for _ in range(24)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    assert errors == []
    # the Correct that stored the procedure counts too (2026-11-11: a fresh solution is judged by real signals only), so 1 + 24
    assert st.graph_paths(s["fine"])[0]["counts"]["correct"] == 25
    assert next(e for e in st.graph_view(s["fine"])["edges"] if e["kind"] == "REPRODUCED_BY")["n"] == 25


def test_strange_words_are_stored_as_words(st):
    s = sig()
    st.touch_signature(s, "D", upload_id="u", finding_id=1)
    bad = "'; DROP TABLE pnode; -- 测试 <script>alert(1)</script>\x00" + "x" * 5000
    st.signal(s["fine"], None, "wrong", "x", proposal_text=bad)
    st.add_lesson(s["fine"], bad, "x")
    v = st.graph_view(s["fine"])
    assert sum(n["kind"] == "lesson" for n in v["nodes"]) == 2


def test_the_admins_order_naming_unknown_procedures_does_no_harm(st):
    s = sig()
    p = stored(st, s)
    st.reorder(s["fine"], [99999, p], "x")
    assert [x["procedure_id"] for x in st.graph_paths(s["fine"])] == [p]


def test_one_failure_never_borrows_from_another(st):
    a, b = sig("cmd.timeout", "io.Write"), sig("cmd.timeout", "io.Read")
    pa = stored(st, a)
    st.touch_signature(b, "D", upload_id="u", finding_id=2)
    assert st.graph_choice(b["fine"]) is None
    st.signal(a["fine"], pa, "wrong", "x")
    assert st.graph_view(b["fine"])["paths"] == []


# ------------------------------------------------------------------------------------------- hostile CSV files
def copy_set(tmp_path, n=400):
    """The first rows of a real sample set, cut to n data lines so that each test is fast."""
    d = tmp_path / "in"
    d.mkdir()
    out = {}
    for key, name in NAMES.items():
        with open(os.path.join(S27, name), encoding="utf-8-sig", newline="") as fh:
            lines = [next(fh) for _ in range(n + 1)] if key != "nvme_command" else fh.readlines()
        p = d / name
        p.write_text("".join(lines), encoding="utf-8")
        out[key] = str(p)
    return out


def run_all(tmp_path, files):
    db = str(tmp_path / "h.sqlite")
    L.load_upload(db, files)
    B.build(db)
    RL.apply(db)
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    return con


@pytest.mark.skipif(not os.path.isdir(S27), reason="the sample set is not on this machine")
class TestHostileFiles:
    def test_a_line_cut_off_at_the_end_of_the_file_is_survived(self, tmp_path):
        f = copy_set(tmp_path)
        p = f["nvme_transaction"]
        s = open(p, encoding="utf-8").read()
        open(p, "w", encoding="utf-8").write(s[:-40])
        con = run_all(tmp_path, f)
        assert con.execute("SELECT COUNT(*) FROM cmd").fetchone()[0] > 0

    def test_a_file_with_only_its_header_is_survived(self, tmp_path):
        f = copy_set(tmp_path)
        p = f["split"]
        head = open(p, encoding="utf-8-sig").readline()
        open(p, "w", encoding="utf-8").write(head)
        con = run_all(tmp_path, f)
        assert con.execute("SELECT COUNT(*) FROM spl").fetchone()[0] == 0

    def test_blank_lines_and_windows_line_ends_are_survived(self, tmp_path):
        f = copy_set(tmp_path)
        p = f["nvme_command"]
        s = open(p, encoding="utf-8", newline="").read().replace("\r\n", "\n")
        n = s.count("\n") - 1
        open(p, "w", encoding="utf-8", newline="").write(s.replace("\n", "\r\n\r\n"))
        con = run_all(tmp_path, f)
        assert con.execute("SELECT COUNT(*) FROM cmd").fetchone()[0] == n

    def test_bytes_that_are_not_text_do_not_stop_the_load(self, tmp_path):
        f = copy_set(tmp_path)
        p = f["link"]
        raw = open(p, "rb").read().split(b"\n")
        raw[3] = raw[3][:20] + b"\xff\xfe\x80" + raw[3][20:]
        open(p, "wb").write(b"\n".join(raw))
        con = run_all(tmp_path, f)
        assert con.execute("SELECT COUNT(*) FROM lnk").fetchone()[0] > 0

    def test_a_missing_file_gives_a_partial_tree_not_a_crash(self, tmp_path):
        f = copy_set(tmp_path)
        del f["split"]
        con = run_all(tmp_path, f)
        assert con.execute("SELECT COUNT(*) FROM cmd").fetchone()[0] > 0

    def test_an_empty_file_is_refused_or_survived_but_never_a_crash_without_a_reason(self, tmp_path):
        f = copy_set(tmp_path)
        open(f["split"], "w").close()
        try:
            con = run_all(tmp_path, f)
        except ValueError as e:
            assert str(e)
        else:
            assert con.execute("SELECT COUNT(*) FROM cmd").fetchone()[0] > 0


# ------------------------------------------------------------------------------------------- broken clocks and exact limits
SRC = os.path.join(APP, "uploads", "up-20261108-123729-0a98", "hier.sqlite")
S_ = 10 ** 12


@pytest.fixture
def rule_db(tmp_path):
    if not os.path.exists(SRC):
        pytest.skip("the S17 sample upload is not on this machine")
    p = str(tmp_path / "hier.sqlite")
    con, out = sqlite3.connect("file:%s?mode=ro" % SRC, uri=True), sqlite3.connect(p)
    con.backup(out)
    out.close()
    con.close()
    return p


def kinds(db):
    con = sqlite3.connect(db)
    out = {r: json.loads(d or "{}").get("kind") for r, d in con.execute("SELECT rowid, detail FROM finding WHERE rule = 'cmd.timeout'")}
    con.close()
    return out


def a_good_read(con):
    return con.execute("SELECT rowid_file, t_ps FROM cmd WHERE opc = 2 AND sqid != 0 AND sc = 0 AND rowid_file IN (SELECT parent FROM ntx WHERE parent_level = 'nvme_command') ORDER BY rowid_file LIMIT 1 OFFSET 20").fetchone()


CQE = "parent = ? AND parent_level = 'nvme_command' AND lower(type) LIKE '%completion queue entry%'"


def test_a_completion_stamped_before_its_command_is_not_called_slow(rule_db):
    con = sqlite3.connect(rule_db)
    rid, t = a_good_read(con)
    con.execute("UPDATE ntx SET t_ps = ? WHERE " + CQE, (t - S_, rid))
    con.commit()
    con.close()
    RL.rerun_command_rules(rule_db, {})
    assert rid not in kinds(rule_db)


def test_a_command_without_a_time_stamp_is_not_judged_and_stops_nothing(rule_db):
    con = sqlite3.connect(rule_db)
    rid, _t = a_good_read(con)
    con.execute("UPDATE cmd SET t_ps = NULL WHERE rowid_file = ?", (rid,))
    other = con.execute("SELECT rowid_file FROM cmd WHERE opc = 2 AND sqid != 0 AND sc = 0 AND rowid_file != ? LIMIT 1 OFFSET 30", (rid,)).fetchone()[0]
    con.execute("UPDATE cmd SET t_ps = NULL, sct = NULL, sc = NULL WHERE rowid_file = ?", (other,))
    con.commit()
    con.close()
    RL.rerun_command_rules(rule_db, {})
    got = kinds(rule_db)
    assert rid not in got and other not in got and len(got) >= 7


@pytest.mark.parametrize("delta,over", [(0, True), (-1, False), (1, True)])
def test_the_hosts_limit_is_exact_to_the_picosecond(rule_db, delta, over):
    con = sqlite3.connect(rule_db)
    rid, t = a_good_read(con)
    con.execute("UPDATE ntx SET t_ps = ? WHERE " + CQE, (t + 30 * S_ + delta, rid))
    con.commit()
    con.close()
    RL.rerun_command_rules(rule_db, {})
    assert (kinds(rule_db).get(rid) == "over the host's limit") is over


def test_a_status_of_the_host_abort_is_not_a_read_failure(rule_db):
    con = sqlite3.connect(rule_db)
    rid, _t = a_good_read(con)
    con.execute("UPDATE cmd SET sct = 0, sc = 7 WHERE rowid_file = ?", (rid,))
    con.commit()
    con.close()
    RL.rerun_command_rules(rule_db, {})
    assert kinds(rule_db).get(rid) == "aborted by the host"
    con = sqlite3.connect(rule_db)
    assert con.execute("SELECT COUNT(*) FROM finding WHERE rule = 'cmd.read_failure' AND rowid = ?", (rid,)).fetchone()[0] == 0


# ------------------------------------------------------------------------------------------- cells written another way
@pytest.mark.skipif(not os.path.isdir(S27), reason="the sample set is not on this machine")
def test_numbers_written_in_hex_or_with_fewer_digits_give_the_same_findings(tmp_path):
    from test_kpi_proof import inject, read_csv, write_csv, NAMES
    a, b = str(tmp_path / "a"), str(tmp_path / "b")
    truth = inject("S27_lcrc_nak_replay", a, 77)
    shutil.copytree(a, b)
    ch, cmds = read_csv(os.path.join(b, NAMES["nvme_command"]))
    th, trs = read_csv(os.path.join(b, NAMES["nvme_transaction"]))
    for head, rows, cols in ((ch, cmds, ("SQID", "CID", "NLB")), (th, trs, ("SQID", "CID"))):
        idx = [head.index(c) for c in cols]
        for row in rows:
            for i in idx:
                if row[i].strip().isdigit():
                    row[i] = "0x%X" % int(row[i])
    i_t = ch.index("Time Stamp")
    for row in cmds:                                    # trailing zeros dropped from the time stamp
        row[i_t] = row[i_t].rstrip("s").rstrip("0") + "s"
    write_csv(os.path.join(b, NAMES["nvme_command"]), ch, cmds)
    write_csv(os.path.join(b, NAMES["nvme_transaction"]), th, trs)

    def found(d, name):
        db = str(tmp_path / (name + ".sqlite"))
        L.load_upload(db, {"nvme_command": os.path.join(d, NAMES["nvme_command"]), "nvme_transaction": os.path.join(d, NAMES["nvme_transaction"])})
        B.build(db)
        RL.apply(db)
        con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
        return {n for (n,) in con.execute("SELECT row_n FROM finding WHERE rule IN ('cmd.timeout', 'cmd.read_failure')")}
    assert found(a, "a") == set(truth) == found(b, "b")


# ------------------------------------------------------------------------------------------- scale and the honest limits of a replay
def test_a_huge_group_keeps_its_slowest_commands_within_the_memory_bound():
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE t (g INTEGER, v REAL)")
    r = random.Random(5)
    n = 300000
    con.executemany("INSERT INTO t VALUES (1, ?)", ((50 + r.random() * 30,) for _ in range(n)))
    con.executemany("INSERT INTO t VALUES (1, ?)", ((5000.0,), (6000.0,), (7000.0,)))
    total, v = RL.group_values(con, "SELECT g, v FROM t", ("g",), "v")[(1,)]
    assert total == n + 3 and len(v) <= RL.USUAL_SAMPLE + 5000 and v[-3:] == [5000.0, 6000.0, 7000.0]
    u = RL.usual_bar(v)
    assert u["top_ps"] < 90 and all(x > u["bar_ps"] for x in v[-3:])


def _replay_script(tmp_path, command, admin):
    from nvme_hier import testcase as TC
    steps = [{"step": 1, "command": command, "admin": admin, "parameters": {"slba": 0, "nlb": 7}, "gap_us": 1, "position": "fault"}]
    text = TC.generate({"rule": "cmd.timeout", "level": "nvme_command", "id": 1, "name": "x", "limit_ps": 30 * 10 ** 12}, steps, {"display": "d"}, "s", "u", name="t.py")
    p = tmp_path / "test_gen.py"
    p.write_text(text)
    sim = tmp_path / "sim"
    sim.mkdir()
    (sim / "nvme").write_text("#!/bin/sh\necho \"$1\" >> \"%s/called\"\nexit 0\n" % sim)
    os.chmod(sim / "nvme", 0o755)
    (sim / "dev").write_text("")
    import subprocess
    out = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", str(p)], capture_output=True, text=True, cwd=str(tmp_path),
                         env=dict(os.environ, PATH=str(sim) + os.pathsep + os.environ["PATH"], NVME_DEV=str(sim / "dev"), EXPECT="fixed", NVME_REPEAT="1", NVME_TIMEOUT_S="2"))
    called = (sim / "called").read_text().split() if (sim / "called").exists() else []
    return out.stdout, called


def test_a_command_that_cannot_be_replayed_says_so_and_nothing_else_is_sent_in_its_place(tmp_path):
    out, called = _replay_script(tmp_path, "Abort (admin)", True)
    assert "1 skipped" in out and called == []


def test_a_replayable_admin_command_is_sent_as_itself(tmp_path):
    out, called = _replay_script(tmp_path, "Identify (admin)", True)
    assert "1 passed" in out and called == ["id-ctrl"]


@pytest.mark.skipif(not os.path.isdir(S27), reason="the sample set is not on this machine")
def test_a_recording_loaded_by_an_earlier_version_can_have_all_rules_applied(tmp_path):
    f = copy_set(tmp_path)
    db = str(tmp_path / "h.sqlite")
    L.load_upload(db, f)
    B.build(db)
    con = sqlite3.connect(db)
    con.execute("ALTER TABLE spl DROP COLUMN errors")
    con.commit()
    con.close()
    RL.apply(db)
    con = sqlite3.connect(db)
    assert con.execute("SELECT COUNT(*) FROM finding").fetchone()[0] >= 0 and "errors" in {r[1] for r in con.execute("PRAGMA table_info(spl)")}
