"""The owner's order (2026-11-11): the error (the admin's pattern) -> the isolation of the defect (the model, from 15 commands above and 15
below with every level; no signal here) -> the procedural graph: is this defect stored, with which causes and solutions? (store it at the
right place, or show what is stored, ranked by the admin's judgements) -> the test case from the error sequence.

    python3 -m pytest -q tests/test_defect_graph.py
"""
import os
import shutil
import sys
import tempfile
import time

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
sys.path.insert(0, os.path.join(APP, "app"))
sys.path.insert(0, HERE)

from nvme_hier import defect_graph as DG   # noqa: E402

SEQ = [{"step": 1, "command": "Write", "position": "above", "gap_us": 5}, {"step": 2, "command": "Read", "position": "fault", "gap_us": 10},
       {"step": 3, "command": "Abort (admin)", "position": "below", "gap_us": 60}]


@pytest.fixture
def g(tmp_path):
    return DG.DefectGraph(str(tmp_path / "k.sqlite"))


def test_a_defect_is_found_by_its_name_whatever_the_case_or_punctuation(g):
    a, new = g.add_defect("Read aborted by host after late completion", "cmd.timeout", "nvme_command", "a read", "Sagar")
    b, again = g.add_defect("read aborted by HOST, after late completion!", "cmd.timeout", "nvme_command", "a read", "Sagar")
    assert new and not again and a == b and g.find_defect("READ aborted by host after late completion")["id"] == a
    with pytest.raises(ValueError, match="standard name"):
        g.add_defect("  ", None, None, "", "Sagar")


def test_causes_rank_by_how_often_the_admin_chose_them_and_solutions_by_judgements(g):
    d, _ = g.add_defect("Read aborted by host", "cmd.timeout", "nvme_command", "", "Sagar")
    host, _ = g.add_cause(d, "host", "host timer shorter than the drive's read time", "Sagar")
    dev, _ = g.add_cause(d, "device", "firmware stalled the read", "Sagar")
    with pytest.raises(ValueError, match="side"):
        g.add_cause(d, "the moon", "x", "Sagar")
    for i, c in enumerate([dev, host, host]):
        g.record_occurrence(d, c, "up-%d" % i, 7, "Samsung PM9A3", "1.0", {"what": "x"}, "Sagar")
    g.record_occurrence(d, host, "up-2", 7, "Samsung PM9A3", "1.0", {"what": "x"}, "Sagar")          # the same error again: still one occurrence
    v = g.view(d)
    assert [c["header"] for c in v["causes"]] == ["host timer shorter than the drive's read time", "firmware stalled the read"]
    assert v["causes"][0]["chosen_words"] == "chosen as the cause in 2 of 3 occurrences" and v["seen"] == 3
    s1, _ = g.add_solution(host, SEQ, ["raise the host's read timeout"], "", "admin:Sagar", "Sagar")
    s2, _ = g.add_solution(host, SEQ, ["split the read in two"], "", "admin:Sagar", "Sagar")
    for _ in range(3):
        g.verdict(s2, "correct", "Sagar", device="Samsung PM9A3")
    r = g.verdict(s1, "wrong", "Sagar", device="Samsung PM9A3")
    assert r["did"][0] == "this solution under this cause: not yet judged → judged correct 0 of 1 time" and r["did"][-1] == "nothing else changed"
    sols = g.solutions(host)
    assert [x["id"] for x in sols] == [s2, s1] and sols[0]["judged_words"] == "judged correct 3 of 3 times"
    assert sols[0]["devices"] == [{"device": "Samsung PM9A3", "words": "judged correct 3 of 3"}]
    # a solution judged wrong never outranks one not judged yet (both have the lower bound 0; 2026-11-11 fix of the tie-break)
    s3, _ = g.add_solution(host, SEQ, ["not judged yet"], "", "admin:Sagar", "Sagar")
    for _ in range(2):
        g.verdict(s1, "wrong", "Sagar")
    assert [x["id"] for x in g.solutions(host)] == [s2, s3, s1]
    with pytest.raises(ValueError, match="error sequence"):
        g.add_solution(host, [], ["x"], "", "admin:Sagar", "Sagar")



def test_the_store_keeps_the_cause_counts_one_judgement_per_error_and_refuses_a_foreign_error(g):
    """The audit of 2026-11-11: naming the defect again set the error's cause back to none; three clicks on Correct for one error counted
    three judgements; a judgement on an error that does not exist was accepted; "Wrong, keep my edits" recorded the old solution's error."""
    d, _ = g.add_defect("Write never completed", "cmd.timeout", "nvme_command", "", "Sagar", term_key="w")
    other, _ = g.add_defect("Read aborted", "cmd.timeout", "nvme_command", "", "Sagar", term_key="r")
    c, _ = g.add_cause(d, "device", "the drive dropped it", "Sagar", keyword="firmware_stall")
    o13 = g.record_occurrence(d, c, "up", 13, "drive", "fw1", {}, "Sagar")
    assert g.record_occurrence(d, None, "up", 13, "drive", "fw1", {}, "Sagar") == o13 and g.occurrence(o13)["cause_id"] == c    # kept
    con = g._con()
    try:
        assert [r[0] for r in con.execute("SELECT cause_id FROM dg_occurrence_log WHERE occurrence_id=? ORDER BY id", (o13,))] == [c]
    finally:
        con.close()
    s1, _ = g.add_solution(c, SEQ, ["first"], "", "admin:Sagar", "Sagar", origin_upload="up", origin_finding=13)
    o261 = g.record_occurrence(d, c, "up", 261, "drive", "fw1", {}, "Sagar")
    for _ in range(3):
        g.verdict(s1, "correct", "Sagar", occurrence_id=o261)
    assert g.solution(s1)["judged_words"] == "judged correct 1 of 1 time"            # one error, one judgement
    g.verdict(s1, "wrong", "Sagar", occurrence_id=o261)
    assert g.solution(s1)["judged_words"] == "judged correct 0 of 1 time"            # the later judgement of the same error replaces it
    assert [v["counted"] for v in g.solution(s1)["verdicts"]] == [False, False, False, True]
    with pytest.raises(ValueError, match="no such error"):
        g.verdict(s1, "correct", "Sagar", occurrence_id=999999)
    o_other = g.record_occurrence(other, None, "up", 10, "drive", "fw1", {}, "Sagar")
    with pytest.raises(ValueError, match="not an occurrence"):
        g.verdict(s1, "correct", "Sagar", occurrence_id=o_other)
    o525 = g.record_occurrence(d, c, "up", 525, "drive", "fw1", {}, "Sagar")
    r = g.verdict(s1, "wrong_with_edits", "Sagar", occurrence_id=o525, optimized=["second"])
    new = g.solution(r["new_solution_id"])
    assert (new["origin_upload"], new["origin_finding"]) == ("up", 525)               # made on error 525, not on error 13
    st = g.status("up", [13, 261, 525])
    assert all("cause: " not in x["words"] or "cause: not named" not in x["words"] for x in st.values()) and st[13]["cause"] == "the drive dropped it"


def test_edits_make_a_new_version_or_a_new_solution(g):
    d, _ = g.add_defect("Read aborted by host", "cmd.timeout", "nvme_command", "", "Sagar")
    c, _ = g.add_cause(d, "host", "host timer too short", "Sagar")
    s, _ = g.add_solution(c, SEQ, ["raise the timeout"], "", "admin:Sagar", "Sagar")
    r = g.verdict(s, "correct_with_edits", "Sagar", error_seq=SEQ[1:], optimized=["raise the timeout to 1 s"])
    x = g.solution(s)
    assert x["version"] == 2 and x["optimized"] == ["raise the timeout to 1 s"] and len(x["error_seq"]) == 2 and x["judged_words"] == "judged correct 1 of 1 time (1 with edits)"
    assert "your edits are its version 2; earlier versions are kept" in r["did"]
    r = g.verdict(s, "wrong_with_edits", "Sagar", optimized=["disable the power-saving state first"])
    new = g.solution(r["new_solution_id"])
    assert new["judged_words"] == "not yet judged" and new["parent"] == s and new["optimized"] == ["disable the power-saving state first"]
    assert g.solution(s)["judged_words"] == "judged correct 1 of 2 times (2 with edits)"


def _drive(c, rid, stop, limit=600):
    """Answer the flow's cards the plain way until stop(step) is true; returns (review, step). The errors page is answered by the test itself."""
    import fuzz_deep as FD
    import test_agent_layer as T
    t0 = time.time()
    while time.time() - t0 < limit:
        v = c.get("/api/agents/runs/%d" % rid).get_json()
        failed = [(s["key"], s.get("error")) for s in v["steps"] if s["state"] == "failed"]
        assert not failed, failed
        rv = next((q for q in v["reviews"] if q["state"] == "open"), None)
        if rv is None:
            time.sleep(0.3)
            continue
        st = next(s for s in v["steps"] if s["id"] == rv["step"])
        if stop(st):
            return rv, st
        if st["key"] == "f3_plan":
            edits = {"selected": ["errors/nvme_command/cmd_timeout"]}
        elif st["key"].endswith(":result"):
            edits = None                       # a pattern with an errors page: nothing to pick on the result card
        else:
            edits = FD.edits_for(st["key"], rv.get("data") or {}, T.Yes())
        r = c.post("/api/agents/reviews/%d/decide" % rv["id"], json={"decision": "approve", "admin": "t", "edits": edits})
        assert r.status_code == 200, (st["key"], r.get_json())
    raise AssertionError("not reached")


def _wait_card(c, rid, key_end, not_id=None, limit=300):
    t0 = time.time()
    while time.time() - t0 < limit:
        v = c.get("/api/agents/runs/%d" % rid).get_json()
        assert not [s for s in v["steps"] if s["state"] == "failed"], [(s["key"], s.get("error")) for s in v["steps"] if s["state"] == "failed"]
        rv = next((q for q in v["reviews"] if q["state"] == "open"), None)
        if rv and rv["id"] != not_id:
            st = next(s for s in v["steps"] if s["id"] == rv["step"])
            if st["key"].endswith(key_end):
                return rv, st
        time.sleep(0.3)
    raise AssertionError("the card %s did not come" % key_end)


def test_the_errors_go_to_their_own_pages_and_page_3_and_the_report_show_where_each_stands():
    import fuzz_app as F
    from agentic import core
    if not os.path.isdir(F.BASE):
        pytest.skip("the S08 sample recording is not on this machine (the code-only zip carries no samples)")
    if not os.path.isdir(os.path.join(APP, "samples", "clean_five_files", "S17_io_timeout_abort_reset")):
        pytest.skip("the S17 sample recording is not on this machine (the code-only zip carries no samples)")
    root = tempfile.mkdtemp(prefix="dg_flow_%d_" % os.getpid())
    kick = core.Engine.kick
    try:
        app, c, _k, _r = F.setup(root)
        core.Engine.kick = F.REAL_KICK or kick
        s17 = os.path.join(APP, "samples", "clean_five_files", "S17_io_timeout_abort_reset")
        if not os.path.isdir(s17):
            pytest.skip("the S17 sample recording is not on this machine (the code-only zip carries no samples)")
        pid = c.post("/api/agents/projects", json={"admin": "t", "name": "graph", "folder": s17}).get_json()["id"]
        rid = c.post("/api/agents/projects/%d/flow" % pid, json={"admin": "t"}).get_json()["run"]

        # the flow runs the patterns, lists their errors (errors, not defects) and waits at one gate before the report
        rv, st = _drive(c, rid, lambda s_: s_["key"] == "errors_done")
        assert rv["data"]["errors_overview"] and "errors page" in rv["body"]
        v = c.get("/api/agents/runs/%d" % rid).get_json()
        es = next(s_ for s_ in v["steps"] if s_["key"].endswith(":errors"))
        o = es["output"]
        assert es["state"] == "done" and o["pattern"] and len(o["errors"]) >= 2 and all(e["where"].startswith("row ") for e in o["errors"])
        result_rv = next(q for q in v["reviews"] if q["title"].startswith("Result:"))
        assert "errors" in result_rv["body"] and "defects in this recording" not in result_rv["body"] and result_rv["data"]["errors_page"]
        up, e1, e2 = o["upload_id"], o["errors"][0]["finding"], o["errors"][1]["finding"]
        status = lambda: c.get("/api/dg/status?upload=%s&findings=%d,%d" % (up, e1, e2)).get_json()["status"]     # noqa: E731
        assert status()[str(e1)]["state"] == "new"

        # error 1 on its own page: isolate, name the defect, name the cause, store the first solution, write and approve its test
        base = "/api/isolate/%s/%d/" % (up, e1)
        iso = c.post(base + "isolate", json={"n": 15, "m": 15, "levels": ["nvme_transaction", "split", "link", "packets"], "history": True, "anyway": True,
                                             "isolation": True, "name": "Sagar", "standin": True}).get_json()
        i = iso["isolation"]
        assert set("what why when where who which how".split()) <= set(i) and i["standard_name"] and iso["window"]["n"] == 15
        d = c.post("/api/dg/defects", json={"name": "Read aborted by host after late completion", "rule": i["rule"], "level": i["level"], "what": i["what"], "admin": "Sagar"}).get_json()
        occ = c.post("/api/dg/occurrences", json={"defect_id": d["id"], "cause_id": None, "upload_id": up, "finding_id": e1, "device": i["device"], "admin": "Sagar"}).get_json()["id"]
        assert status()[str(e1)]["state"] == "isolated"
        cz = c.post("/api/dg/causes", json={"defect_id": d["id"], "side": "host", "header": "host timer shorter than the drive's read time", "admin": "Sagar"}).get_json()["id"]
        assert c.post("/api/dg/occurrences", json={"defect_id": d["id"], "cause_id": cz, "upload_id": up, "finding_id": e1, "admin": "Sagar"}).get_json()["id"] == occ
        assert status()[str(e1)]["state"] == "cause"
        prop = c.post("/api/dg/optimized", json={"upload_id": up, "finding_id": e1, "isolation": {"what": i["what"]}, "cause": {"side": "host", "header": "x"},
                                                 "error_seq": iso["sequence"], "standin": True}).get_json()
        assert prop["standin"] and prop["lines"] == []
        sol = c.post("/api/dg/solutions", json={"cause_id": cz, "error_seq": iso["sequence"], "optimized": ["raise the host's read timeout"], "admin": "Sagar",
                                                "upload_id": up, "finding_id": e1}).get_json()
        assert sol["solution"]["judged_words"] == "not yet judged" and status()[str(e1)]["state"] == "solved"
        ex = c.post(base + "testcase", json={"sequence": iso["sequence"], "expected_after": 3, "name": "Sagar", "standin": True}).get_json()
        f = c.post(base + "testcase", json={"sequence": ex["sequence"], "expected_outcomes": [dict(x, verified=True) for x in ex["expected_outcomes"]], "verified": True,
                                            "name": "Sagar", "standin": True}).get_json()
        assert c.post(base + "testcase/approve", json={"path": f["path"], "name": "Sagar", "revision_id": sol["revision_id"]}).get_json()["ok"]
        st1 = status()[str(e1)]
        assert st1["state"] == "tested" and st1["words"].startswith("done: the defect") and st1["test_path"]

        # error 2: the defect is known; its cause and solution are found; Wrong, then Correct with edits re-rank and version it
        known = c.get("/api/dg/defects?rule=%s" % i["rule"]).get_json()["defects"]
        assert [k["name"] for k in known] == ["Read aborted by host after late completion"] and known[0]["causes"] == 1
        occ2 = c.post("/api/dg/occurrences", json={"defect_id": d["id"], "cause_id": cz, "upload_id": up, "finding_id": e2, "admin": "Sagar"}).get_json()["id"]
        view = c.get("/api/dg/defects/%d" % d["id"]).get_json()
        assert view["causes"][0]["chosen_words"] == "chosen as the cause in 2 of 2 occurrences" and [x["id"] for x in view["causes"][0]["solutions"]] == [sol["id"]]
        r = c.post("/api/dg/solutions/%d/verdict" % sol["id"], json={"signal": "wrong", "admin": "Sagar", "occurrence_id": occ2}).get_json()
        assert r["did"][0].endswith("judged correct 0 of 1 time")
        assert status()[str(e2)]["state"] == "cause"                       # a Wrong chooses nothing for the test
        r = c.post("/api/dg/solutions/%d/verdict" % sol["id"], json={"signal": "correct_with_edits", "admin": "Sagar", "occurrence_id": occ2,
                                                                     "optimized": ["raise the host's read timeout to 1 s"]}).get_json()
        # the same error judged twice: the later judgement replaces the earlier one in the counts (one judgement per error; both rows kept)
        assert r["solution"]["version"] == 2 and r["solution"]["judged_words"] == "judged correct 1 of 1 time (1 with edits)" and status()[str(e2)]["state"] == "solved"
        assert [v["counted"] for v in r["solution"]["verdicts"]] == [False, True]

        # Done: the report says where each error stands
        assert c.post("/api/agents/reviews/%d/decide" % rv["id"], json={"decision": "approve", "admin": "Sagar"}).status_code == 200
        t0 = time.time()
        while time.time() - t0 < 120:
            v = c.get("/api/agents/runs/%d" % rid).get_json()
            rep = next((s_ for s_ in v["steps"] if s_["key"] == "report" and s_["state"] == "done"), None)
            if rep:
                break
            time.sleep(0.3)
        assert rep, [(s_["key"], s_["state"]) for s_ in v["steps"]][-5:]
        import json as _j
        rj = _j.load(open(rep["output"]["files"]["json"]))
        states = {x["where"]: x["state"] for x in rj["errors"]}
        assert states[o["errors"][0]["where"]] == "tested" and states[o["errors"][1]["where"]] == "solved"
        html = open(rep["output"]["files"]["html"]).read()
        assert "The errors: stage 1, stage 2 and their tests" in html and "with an approved test" in html
    finally:
        core.Engine.kick = kick
        shutil.rmtree(root, ignore_errors=True)


def test_the_dictionary_names_a_defect_the_same_way_every_time_and_keeps_causes_to_its_keywords():
    """(owner, 2026-11-11) the system keeps the names: the defect term is made by code from the recording, the cause is one fixed keyword."""
    import test_regression_tests as R
    from nvme_hier import terms as TM
    root = tempfile.mkdtemp(prefix="dg_terms_%d_" % os.getpid())
    try:
        app, c = R._app_with_s17(root)
        from api import isolate_api as IA
        with app.test_request_context():
            s = app.config["services"]
            terms = {fid: TM.defect_term(IA._load(s, "up-s17", fid)["f"]) for fid in (10, 13, 138, 261, 390, 525, 644)}
        assert len({t["key"] for t in terms.values()}) == 3                     # seven errors, three kinds of defect
        assert terms[13]["key"] == terms[261]["key"] == terms[525]["key"] == terms[644]["key"] and terms[138]["key"] == terms[390]["key"]
        assert terms[10]["name"] == "Read aborted by the host, status Command Abort Requested"
        assert terms[13]["name"].startswith("Write never completed, stopped after the data")
        iso = c.post("/api/isolate/up-s17/13/isolate", json={"anyway": True, "standin": True, "name": "t", "isolation": True}).get_json()["isolation"]
        assert iso["term"]["key"] == terms[13]["key"] and iso["stored"] is None and iso["cause_key"] in TM.CAUSES
        d = c.post("/api/dg/defects", json={"name": iso["term"]["name"], "term_key": iso["term"]["key"], "admin": "A"}).get_json()
        d2 = c.post("/api/dg/defects", json={"name": "something else typed", "term_key": terms[261]["key"], "admin": "B"}).get_json()
        assert d["created"] and d2["id"] == d["id"] and not d2["created"]       # another admin, another time: the same defect
        assert c.post("/api/dg/causes", json={"defect_id": d["id"], "keyword": "made_up_cause", "admin": "A"}).status_code == 400
        k1 = c.post("/api/dg/causes", json={"defect_id": d["id"], "keyword": "firmware_stall", "admin": "A"}).get_json()
        k2 = c.post("/api/dg/causes", json={"defect_id": d["id"], "keyword": "firmware_stall", "admin": "B"}).get_json()
        assert k1["id"] == k2["id"] and not k2["created"]
        iso2 = c.post("/api/isolate/up-s17/261/isolate", json={"anyway": True, "standin": True, "name": "t", "isolation": True}).get_json()["isolation"]
        assert iso2["stored"] and iso2["stored"]["id"] == d["id"] and [x["key"] for x in iso2["stored"]["causes"]] == ["kw:firmware_stall"]
        assert c.get("/api/dg/defects?term=%s" % terms[13]["key"]).get_json()["defect"]["id"] == d["id"]
        assert any(x["key"] == "unknown_cause" for x in c.get("/api/dg/terms").get_json()["causes"])
        assert c.post("/api/dg/term_requests", json={"term_key": terms[13]["key"], "note": "this one stopped later", "admin": "A"}).get_json()["ok"]
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_the_isolation_of_an_error_does_not_change_with_the_window_or_when_asked_again():
    """(owner, 2026-11-11) "even if I draw 1,000 lines from above or below, the causation should always be one": the evidence card is the
    error's own, the cause is decided from it by fixed rules, and the isolation is kept per error."""
    import test_regression_tests as R
    root = tempfile.mkdtemp(prefix="dg_stable_%d_" % os.getpid())
    try:
        app, c = R._app_with_s17(root)
        lv = ["nvme_transaction", "split", "link", "packets"]
        runs = [c.post("/api/isolate/up-s17/10/isolate", json={"anyway": True, "standin": True, "name": "t", "isolation": True, "levels": lv, "n": n, "m": m}).get_json()["isolation"]
                for n, m in ((2, 1), (15, 15), (40, 40), (15, 15))]
        fixed = ("cause_key", "cause_header", "what", "when", "where", "which", "who", "card_hash", "why", "how")
        assert all(all(r[k] == runs[0][k] for k in fixed) for r in runs), [(r["cause_key"], r["card_hash"]) for r in runs]
        assert runs[0]["cause_key"] == "host_abort_by_tool_or_test" and "60.000 µs after the doorbell" in runs[0]["cause_header"]
        assert runs[0]["kept_at"] is None and all(r["kept_at"] for r in runs[1:])          # the first isolation is kept; the others reuse it
        assert "row 1952" in runs[0]["which"] and runs[0]["card"]["abort"]["row"] == 145
        again = c.post("/api/isolate/up-s17/10/isolate", json={"anyway": True, "standin": True, "name": "t", "isolation": True, "levels": lv, "n": 5, "m": 5,
                                                               "rewrite": True}).get_json()["isolation"]
        assert again["cause_key"] == runs[0]["cause_key"] and again["which"] == runs[0]["which"] and again["kept_at"] is None    # new words only
        w = c.post("/api/isolate/up-s17/13/isolate", json={"anyway": True, "standin": True, "name": "t", "isolation": True, "levels": lv, "n": 3, "m": 3}).get_json()["isolation"]
        w2 = c.post("/api/isolate/up-s17/13/isolate", json={"anyway": True, "standin": True, "name": "t", "isolation": True, "levels": lv, "n": 30, "m": 0}).get_json()["isolation"]
        assert w["cause_key"] == w2["cause_key"] == "firmware_stall" and w["which"] == w2["which"] and "Transferred Data" in w["which"]
    finally:
        shutil.rmtree(root, ignore_errors=True)
