"""Stop means stop (owner, 2026-11-11: "Stop the flow and Delete are not working ... stop means stop, that's all").

A step waiting on a long Claude Code call is stopped: the step reads "stopped" at once, the Claude Code process is ended, the run tries
nothing more, and a result that would still come back is not written. Deleting an analysis whose flow is running stops it first
and deletes it (before, Delete was refused while a step was still working, so after a Stop it did nothing)."""
import os
import shutil
import stat
import sys
import tempfile
import time
import types

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)


def _slow_kind(core):
    """A kind of run with one step that asks Claude Code once (a stand-in program that would take 60 s), then a second step."""
    def steps(params, project):
        return [{"key": "slow", "title": "slow agent", "agent": "Slow"}, {"key": "after", "title": "after it", "agent": "After"}]

    def run_step(ctx):
        if ctx.step["key"] == "slow":
            ans, producer, _ = ctx.engine.runner.ask(ctx.run["id"], "slow", "say ok", {}, '{"ok": "yes"}', "ok", lambda: {"ok": "stand-in"})
            return core.Result({"ans": ans}, producer=producer)
        return core.Result({"after": True})
    return types.SimpleNamespace(steps=steps, run_step=run_step)


def test_stop_ends_a_step_that_waits_on_claude_code_at_once():
    from agentic import core
    root = tempfile.mkdtemp(prefix="stop_%d_" % os.getpid())
    was = os.environ.pop("ANTHROPIC_BASE_URL", None)
    try:
        fake = os.path.join(root, "claude")
        with open(fake, "w") as fh:                                   # a Claude Code that would answer after 60 s
            fh.write("#!/bin/sh\necho $$ > %s/pid\nsleep 60\necho '{\"result\": \"{\\\\\"ok\\\\\": \\\\\"late\\\\\"}\"}'\n" % root)
        os.chmod(fake, os.stat(fake).st_mode | stat.S_IEXEC)
        store = core.Store(os.path.join(root, "agentic.sqlite"))
        runner = core.AgentRunner(os.path.join(root, "runs"), runtime="claude-code", claude_path=fake, web=False)
        eng = core.Engine(store, {"slow": _slow_kind(core)}, runner)
        pid = store.exec("INSERT INTO project (name, folder, created) VALUES (?,?,?)", ("p", root, time.time()))
        rid = eng.start(pid, "slow")
        t0 = time.time()
        while not os.path.exists(os.path.join(root, "pid")) and time.time() - t0 < 20:
            time.sleep(0.2)
        assert os.path.exists(os.path.join(root, "pid")), "the stand-in Claude Code did not start"
        proc = int(open(os.path.join(root, "pid")).read().strip())
        t1 = time.time()
        eng.stop(rid, "t")
        assert store.one("SELECT state FROM run WHERE id=?", (rid,))["state"] == "stopped"
        assert store.one("SELECT state FROM step WHERE run=? AND key='slow'", (rid,))["state"] == "stopped"
        while time.time() - t1 < 5:
            try:
                os.kill(proc, 0)
            except OSError:
                break
            time.sleep(0.1)
        else:
            raise AssertionError("the Claude Code process was not ended")
        time.sleep(2)                                                     # the step's thread comes back: it must write nothing
        steps = {r["key"]: r["state"] for r in store.all("SELECT key, state FROM step WHERE run=?", (rid,))}
        assert steps == {"slow": "stopped", "after": "waiting"}, steps
        assert store.one("SELECT COUNT(*) AS n FROM review WHERE run=?", (rid,))["n"] == 0
        assert time.time() - t1 < 10
        # run again: the stopped step waits again and the run may call the model again
        eng.retry(rid)
        assert rid not in runner.cancelled
        eng.stop(rid, "t")
    finally:
        if was is not None:
            os.environ["ANTHROPIC_BASE_URL"] = was
        shutil.rmtree(root, ignore_errors=True)


def test_delete_stops_a_running_analysis_and_deletes_it():
    import fuzz_app as F
    from api import agentic_api as A
    import pytest
    if not os.path.isdir(F.BASE):
        pytest.skip("the S08 sample recording is not on this machine (the code-only zip carries no samples)")
    root = tempfile.mkdtemp(prefix="delete_%d_" % os.getpid())
    try:
        app, c, _k, _r = F.setup(root)
        pid = c.post("/api/agents/projects", json={"admin": "t", "name": "to delete", "folder": F.BASE}).get_json()["id"]
        with app.app_context():
            eng = A.engine()
        rid = eng.store.exec("INSERT INTO run (project, kind, target, params, state, created, updated, heartbeat) VALUES (?,?,?,?,?,?,?,?)",
                             (pid, "flow", "", "{}", "running", time.time(), time.time(), time.time()))
        eng.store.exec("INSERT INTO step (run, idx, key, title, family, agent, state, needs_review, input) VALUES (?,?,?,?,?,?,?,?,?)",
                       (rid, 0, "ground:x.csv", "Data Grounder", "1", "Data Grounder", "running", 0, "{}"))      # a step still working
        r = c.delete("/api/agents/projects/%d" % pid, json={"admin": "t"})
        assert r.status_code == 200, r.get_json()
        assert eng.store.one("SELECT id FROM project WHERE id=?", (pid,)) is None and eng.store.one("SELECT id FROM run WHERE id=?", (rid,)) is None
        assert rid in eng.runner.cancelled                                   # its model calls were ended too
    finally:
        shutil.rmtree(root, ignore_errors=True)
