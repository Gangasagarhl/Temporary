"""Stage 2 inside the app: one knowledge database for the laptop, one Stage2V3 instance, serialized through a lock.

present(run, inc)   retrieval + "seen before" + the admin card: the STORED procedure (what the admin saved, with its
                    metadata and feedback) and the LLM-GENERATED proposal side by side when a stored one exists,
                    only the generated one otherwise; synchronous (seconds; the LLM digest dominates)
act(run, inc, a)    the admin's action -> events -> weights / CRUD; accept / add_cause continue into a background
                    job: regression guard or search under the trial + 10-minute budgets, closed-loop verification,
                    ledger, test files. Everything is timed and written to runs/<run>/stage2/<inc>.json
"""
import json
import os
import sys
import threading
import time

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STAGE2 = os.path.join(APP, "stage2")
sys.path.insert(0, STAGE2)
os.environ.setdefault("PCIE_ENGINE_DIR", os.path.join(APP, "stage1"))
os.environ.setdefault("PCIE_GENERATOR", os.path.join(APP, "data", "generator", "generate_synthetic_pcie_trace.py"))
os.environ.setdefault("PCIE_ATLAS_CARDS", os.path.join(APP, "data", "atlas_cards_raw.json"))
os.environ.setdefault("PCIE_BENCH_WORKDIR", os.path.join(APP, "runs", "_bench"))

from admin_actions import ALL as ACTIONS, available            # noqa: E402
from kgdb import KGDB                                         # noqa: E402
from llm_adapter import AnthropicLLM, OllamaLLM, OpenAICompat, StandInLLM   # noqa: E402
from presenter import render_markdown                         # noqa: E402
from stage1_adapter import load_run                           # noqa: E402
from stage2_v3 import SEARCH_ACTIONS, Stage2V3                # noqa: E402


def make_llm(cfg, cache_path):
    b = cfg.get("backend", "auto")
    model = cfg.get("model", "claude-haiku-5-5")
    if b == "standin":
        return StandInLLM(cache_path)
    if b in ("cli", "sdk", "http", "auto"):
        if b in ("sdk", "http") and cfg.get("base_url"):
            os.environ["ANTHROPIC_BASE_URL"] = cfg["base_url"]
        if cfg.get("api_key_env") and os.environ.get(cfg["api_key_env"]) and not os.environ.get("ANTHROPIC_API_KEY"):
            os.environ["ANTHROPIC_API_KEY"] = os.environ[cfg["api_key_env"]]
        llm = AnthropicLLM(model, effort=cfg.get("effort", "low"), cache_path=cache_path, backend=b, tools=tuple(cfg.get("tools") or ()))
        if llm.available():
            return llm
        return StandInLLM(cache_path)
    if b == "openai-compat":
        return OpenAICompat(model, cfg.get("base_url", ""), os.environ.get(cfg.get("api_key_env", ""), ""), cache_path)
    if b == "ollama":
        o = OllamaLLM(model, cache_path=cache_path)
        return o if o.available() else StandInLLM(cache_path)
    return StandInLLM(cache_path)


def rule_defs_from(spec_path):
    out = {}
    if os.path.exists(spec_path):
        with open(spec_path) as f:
            lines = f.readlines()
        for line in lines:
            r = json.loads(line)
            out[r["card_id"]] = "%s\nDETECT: %s\nCONFIRMATION TESTS: %s" % (
                r["title"], r["detect"][:700], "; ".join(t.get("test", "") for t in r.get("confirmation_tests", [])[:3]))
    return out


class Stage2Service:
    def __init__(self, cfg, root, jobs):
        self.cfg, self.root, self.jobs = cfg, root, jobs
        self.lock = threading.Lock()
        self.state_lock = threading.Lock()      # read-modify-write of a defect's state file (present / _record / _ctx)
        os.makedirs(os.path.join(root, "db"), exist_ok=True)
        self.db = KGDB(os.path.join(root, "db", "knowledge.sqlite"))
        self.llm = make_llm(cfg["llm"], os.path.join(root, "db", "llm_cache.jsonl"))
        s2 = cfg["stage2"]
        self.s2 = Stage2V3(self.db, llm=self.llm, suite_dir=os.path.join(root, "suite"), opt_budget=s2.get("opt_budget", 300),
                           rule_defs=rule_defs_from(os.path.join(root, "data", "DEFECT_DETECTION_SPEC_485.jsonl")),
                           search_on=s2.get("search_on", "model"), log_path=os.path.join(root, "db", "stage2_log.jsonl"),
                           use_llm=not isinstance(self.llm, StandInLLM), n_bad=s2.get("n_bad", 6), n_fixed=s2.get("n_fixed", 3),
                           max_rows=s2.get("max_rows", 25), time_budget_s=s2.get("time_budget_s", 600),
                           optimal_consecutive=s2.get("optimal_consecutive", 3), optimizer=s2.get("optimizer", "bandit"),
                           stress_trials=s2.get("stress_trials", 30),
                           bench_factory=self._bench_factory() if s2.get("bench") == "hook" else None)
        self.ctx = {}            # (run_id, inc_id) -> presentation context (in memory; the card is also on disk)
        self.incidents = {}      # run_id -> {inc_id: Incident}

    def reload_llm(self):
        """Hot-swap the LLM backend after a config change (no restart)."""
        with self.lock:
            self.llm = make_llm(self.cfg["llm"], os.path.join(self.root, "db", "llm_cache.jsonl"))
            self.s2.llm = self.llm
            self.s2.use_llm = not isinstance(self.llm, StandInLLM)
            s2 = self.cfg["stage2"]
            self.s2.opt_budget = s2.get("opt_budget", self.s2.opt_budget)
            self.s2.optimizer_kind = s2.get("optimizer", self.s2.optimizer_kind)
            self.s2.time_budget_s = s2.get("time_budget_s", self.s2.time_budget_s)
            self.s2.stress_trials = s2.get("stress_trials", self.s2.stress_trials)
            self.s2.optimal_consecutive = s2.get("optimal_consecutive", self.s2.optimal_consecutive)
            self.s2.n_bad, self.s2.n_fixed = s2.get("n_bad", self.s2.n_bad), s2.get("n_fixed", self.s2.n_fixed)
            self.s2.search_on = s2.get("search_on", self.s2.search_on)

    def _bench_factory(self):
        sys.path.insert(0, os.path.join(APP, "app"))
        from bench_hook import HardwareBench   # noqa: E402
        return lambda sig, family, expected, fixed, decoy, seed: HardwareBench(sig, family, expected, fixed, decoy, seed)

    # ------------------------------------------------------------------ incidents of a run
    def load(self, run_id, run_dir, firmware):
        if run_id not in self.incidents:
            self.incidents[run_id] = {i.id: i for i in load_run(run_dir, firmware) if i.card}
        return self.incidents[run_id]

    def _state_path(self, run_dir, inc_id):
        d = os.path.join(run_dir, "stage2")
        os.makedirs(d, exist_ok=True)
        return os.path.join(d, inc_id + ".json")

    def state(self, run_dir, inc_id):
        p = self._state_path(run_dir, inc_id)
        if not os.path.exists(p):
            return {"incident": inc_id, "presented": False, "results": []}
        with open(p) as f:
            return json.load(f)

    def _save(self, run_dir, inc_id, st):
        path = self._state_path(run_dir, inc_id)                  # never half a file: the incident's state is read back on every page
        tmp = "%s.%d.%d.tmp" % (path, os.getpid(), threading.get_ident())
        with open(tmp, "w") as f:
            json.dump(st, f, indent=1, default=str)
        os.replace(tmp, path)

    # ------------------------------------------------------------------ present
    # ------------------------------------------------------------------ metadata stamped on every event
    @staticmethod
    def _event_meta(meta, inc_id, operator=None):
        """What the knowledge base remembers with every event: which run and trace, which defect, which device and
        firmware, which person. `operator` (the requester of a decision) overrides the person who started the run."""
        m = meta or {}
        dev = m.get("device") or {}
        return {"run": m.get("run"), "trace": m.get("trace"), "defect": inc_id, "operator": operator or m.get("operator"),
                "device": dev.get("name"), "device_source": dev.get("source"), "serial_number": dev.get("serial_number"),
                "firmware_revision": dev.get("firmware_revision"), "firmware": m.get("firmware"),
                "at": time.strftime("%Y-%m-%dT%H:%M:%S%z")}

    def solution_summary(self, vhash):
        """When and by whom a procedure was proposed, validated, approved and judged, and on which devices: the
        metadata line of a candidate card. Built from the event log (kgdb.solution_history)."""
        ev = self.db.solution_history(vhash)
        meta = lambda e: e.get("meta") or {}
        who = lambda e: meta(e).get("operator") or e["actor"]
        dev = lambda e: meta(e).get("device")
        prop = next((e for e in ev if e["kind"] == "solution_propose"), None)
        vals = [e for e in ev if e["kind"] == "solution_validate" and (e.get("repro_lower95") or 0) > 0]
        appr = next((e for e in reversed(ev) if e["kind"] == "solution_approve"), None)
        acts = [e for e in ev if e["kind"] == "admin_action" and not e["undone"]]
        gates = [e for e in ev if e["kind"] == "script_gate" and e.get("admitted")]
        return {"proposed_at": prop["ts"] if prop else None, "proposed_by": (prop.get("producer") or prop["actor"]) if prop else None,
                "proposed_on_device": dev(prop) if prop else None, "proposed_in_run": meta(prop).get("run") if prop else None,
                "proposed_for_defect": meta(prop).get("defect") if prop else None, "proposed_operator": meta(prop).get("operator") if prop else None,
                "validated_at": vals[-1]["ts"] if vals else None, "validated_on_device": dev(vals[-1]) if vals else None,
                "validated_firmware": meta(vals[-1]).get("firmware") if vals else None, "validations": len(vals),
                "approved_at": appr["ts"] if appr else None, "approved_by": appr.get("approved_by") if appr else None,
                "decisions": [{"at": e["ts"], "by": who(e), "action": e.get("action"), "note": e.get("note"), "device": dev(e),
                               "run": meta(e).get("run"), "defect": meta(e).get("defect")} for e in acts][-6:],
                "tests_filed": len(gates), "last_test_at": gates[-1]["ts"] if gates else None,
                "devices": sorted({d for d in (dev(e) for e in ev) if d})}

    # ------------------------------------------------------------------ present
    def present(self, run_id, run_dir, inc_id, firmware, meta=None):
        inc = self.load(run_id, run_dir, firmware)[inc_id]
        with self.lock:
            self.db.event_meta = self._event_meta(meta, inc_id)
            try:
                ctx = self.s2.present(inc, firmware, device=(meta or {}).get("device"))
                self.db.commit()                 # the lookup's events (incident_seen, impression) are on disk at once
            finally:
                self.db.event_meta = None
        self.ctx[(run_id, inc_id)] = ctx
        card = ctx["card"]
        view = {"incident": inc_id, "card": card, "card_md": render_markdown(card), "run_meta": meta,
                "stored": card["recommended"],                       # what the admin saved earlier (+ feedback metadata)
                "generated": (card.get("llm") or {}).get("recommended_sequence"),   # the LLM's proposal for this evidence
                "llm": card.get("llm"), "llm_problems": card["llm_problems"],
                "seen": ctx["seen"], "seen_label": card["seen_before"].get("label"), "seen_score": ctx["score"],
                "actions": card["actions"], "timings": {"present_s": ctx["present_s"], "llm_s": ctx["llm_s"]},
                "presented_at": time.time()}
        with self.state_lock:
            st = self.state(run_dir, inc_id)
            st.update(presented=True, view=view, ctx=dict(ctx, allowed=sorted(ctx["allowed"])))   # ctx persisted: a restart needs no re-presentation
            self._save(run_dir, inc_id, st)
        return view

    def _ctx(self, run_id, run_dir, inc_id, firmware, meta=None):
        key = (run_id, inc_id)
        if key not in self.ctx:
            st = self.state(run_dir, inc_id)
            if st.get("ctx"):
                ctx = st["ctx"]
                ctx["allowed"] = set(ctx.get("allowed") or [])
                self.ctx[key] = ctx
            else:
                self.present(run_id, run_dir, inc_id, firmware, meta)
        return self.ctx[key]

    # ------------------------------------------------------------------ act
    def act(self, run_id, run_dir, inc_id, action, firmware, meta=None):
        if action.get("action") not in ACTIONS:
            return {"error": "unknown action %s" % action.get("action")}, None
        key = (run_id, inc_id)
        self._ctx(run_id, run_dir, inc_id, firmware, meta)
        action.setdefault("sig", self.ctx[key]["sig"])
        action.setdefault("requester", (meta or {}).get("operator") or "admin")
        emeta = self._event_meta(meta, inc_id, operator=action.get("requester"))
        action["incident"], action["run"] = inc_id, run_id            # recorded in the admin_action event
        st_ = self.state(run_dir, inc_id)                                  # Negative Ack restart: the n-th attempt uses another random stream
        action.setdefault("attempt", sum(1 for r in st_.get("results", []) if r.get("status") in ("budget_exhausted", "triage_timeout", "admin_procedure_failed", "not_reproduced")))
        inc = self.load(run_id, run_dir, firmware)[inc_id]
        if action["action"] in SEARCH_ACTIONS:
            jid = self.jobs.submit("stage2", {"run_id": run_id, "run_dir": run_dir, "incident": inc_id, "action": action, "meta": emeta},
                                   lambda jid, params, mgr: self._execute_job(jid, params, mgr, inc, firmware))
            return {"job": jid, "queued": True}, jid
        with self.lock:
            self.db.event_meta = emeta
            try:
                out = self.s2.execute(inc, self.ctx[key], action)
                self.db.commit()                 # every decision is durable when the answer reaches the screen
            finally:
                self.db.event_meta = None
        self._record(run_dir, inc_id, out)
        return out, None

    def _execute_job(self, jid, params, mgr, inc, firmware):
        key = (params["run_id"], params["incident"])
        with self.lock:
            self.db.event_meta = params.get("meta")
            try:
                with mgr.span(jid, "stage2.execute", {"incident": inc.id, "action": params["action"]["action"]}):
                    mgr.progress(jid, "stage2", "re-running the saved procedure, searching, and verifying for %s" % inc.id, 10)
                    out = self.s2.execute(inc, self.ctx[key], params["action"])
                    self.db.commit()
            finally:
                self.db.event_meta = None
        self._record(params["run_dir"], inc.id, out)
        return out

    def _record(self, run_dir, inc_id, out):
        with self.state_lock:
            st = self.state(run_dir, inc_id)
            # what was known about this defect WHEN the admin decided (new, ambiguous, or a match of a stored procedure):
            # a later re-presentation sees the procedure this decision stored and would call it "seen before", which made
            # the KPI count a first-time defect as a recurrence that slipped past its test (found 2026-11-08)
            if isinstance(out, dict):
                out.setdefault("seen_at_decision", (st.get("view") or {}).get("seen"))
            st.setdefault("results", []).append(out)
            st["last"] = out
            self._save(run_dir, inc_id, st)

    def forget_run(self, run_id):
        self.incidents.pop(run_id, None)
        for k in [k for k in self.ctx if k[0] == run_id]:
            self.ctx.pop(k, None)

    # ------------------------------------------------------------------ database views (read-only)
    def db_summary(self):
        return {"knowledge": self.db.stats(), "graph": self.s2.graph.stats(), "llm": getattr(self.llm, "name", "stand-in"),
                "llm_usage": getattr(self.llm, "usage", None), "counters": self.s2.counters}

    def db_table(self, name, limit=200, offset=0, sig=None):
        allowed = {"event": "SELECT id,ts,kind,actor,payload,undone FROM event",
                   "signature": "SELECT sig,pattern,seen,first_seen FROM signature",
                   "node": "SELECT id,kind,sig,status,prior_rank FROM node",
                   "edge": "SELECT src,dst,kind,a,b,n,pl,ta,tb,status FROM edge",
                   "solution": "SELECT vhash,sig,cause,status,repro_lower95,producer,approved_by,context_hash,supersedes FROM solution",
                   "lesson": "SELECT sig,cause,text,producer,event_id FROM lesson",
                   "pnode": "SELECT id,kind,sig,status,a,b,n,pl,ver FROM pnode",
                   "pedge": "SELECT id,kind,src,dst,status,a,b,n FROM pedge",
                   "artifact": "SELECT id,kind,sig,cause,event_id FROM artifact"}
        if name not in allowed:
            return None
        q, args = allowed[name], []
        if sig and name in ("signature", "node", "solution", "lesson", "pnode", "artifact"):
            q += " WHERE sig=?"
            args.append(sig)
        elif sig and name == "edge":
            q += " WHERE src=?"
            args.append(sig)
        elif sig and name == "pedge":
            q += " WHERE src LIKE ? OR dst LIKE ?"
            args += [sig + "%", sig + "%"]
        if name == "event":
            q += " ORDER BY id DESC"
        q += " LIMIT ? OFFSET ?"
        cur = self.db.con.execute(q, args + [limit, offset])
        cols = [d[0] for d in cur.description]
        rows = [dict(zip(cols, r)) for r in cur.fetchall()]
        for r in rows:
            for k in ("payload",):
                if k in r and isinstance(r[k], str):
                    try:
                        r[k] = json.loads(r[k])
                    except ValueError:
                        pass
        return {"table": name, "columns": cols, "rows": rows}

    def procedures(self, sig):
        return {"sig": sig, "causes": [{"id": c, "content": self.db.content(sig, c), "edge": self.db.edge(sig, c)} for c in self.db.causes(sig)],
                "procedures": self.s2.graph.procedures_for(sig, statuses=None), "solutions": self.db.solutions(sig),
                "lessons": self.db.lessons(sig, 20)}

    def feedback_history(self, sig, limit=50):
        """The admin's earlier decisions on this card: who, when, what, note, and what came of it (from the event log).
        An admin_action event is followed, for the same card, by the execution's script_gate event when a search ran."""
        rows = self.db.con.execute("SELECT id,ts,kind,actor,payload FROM event WHERE undone=0 AND kind IN ('admin_action','script_gate') "
                                   "AND payload LIKE ? ORDER BY id", ('%"sig": "' + sig + '"%',)).fetchall()
        out, pending = [], None
        for eid, ts, kind, actor, payload in rows:
            pl = json.loads(payload)
            if pl.get("sig") != sig:
                continue
            if kind == "admin_action":
                pending = {"event_id": eid, "when": ts, "actor": actor, "action": pl.get("action"), "targets": pl.get("targets"),
                           "note": pl.get("note"), "approver": pl.get("approver"), "incident": pl.get("incident"), "run": pl.get("run"),
                           "polarity": "positive" if pl.get("action") in ("accept", "accept_with_note", "promote", "add_procedure", "add_cause") else
                                       "negative" if pl.get("action") in ("reject", "not_reproducible", "wrong_signature", "deprecate", "delete_request", "delete_approve")
                                       or (pl.get("action") == "lesson" and str(pl.get("note") or "").upper().startswith("NOT CORRECT")) else "neutral",
                           "outcome": None}
                out.append(pending)
            elif kind == "script_gate" and pending is not None and pending["outcome"] is None:
                g = pl.get("gate") or {}
                pending["outcome"] = {"admitted": bool(pl.get("admitted")), "vhash": pl.get("vhash"),
                                      "known_bad": "%s/%s" % (g.get("known_bad_hits"), g.get("known_bad_n")) if g else None,
                                      "fixed": "%s/%s" % (g.get("fixed_hits"), g.get("fixed_n")) if g else None}
        return list(reversed(out))[:limit]

    def undo(self, event_id, actor):
        with self.lock:
            self.db.undo(int(event_id), actor)
            self.s2.index.sync(force=True)
        return {"undone": event_id}

    def available_actions(self, run_id, inc_id):
        ctx = self.ctx.get((run_id, inc_id))
        return available(ctx["seen"] if ctx else "new", bool(ctx and ctx["shown"]))
