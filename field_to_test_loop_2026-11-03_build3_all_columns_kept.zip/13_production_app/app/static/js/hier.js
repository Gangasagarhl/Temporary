/* Five-level NVMe hierarchy page: upload, tree with filters, summary, time limits. */
import { api, $, esc, num, toast, poll } from "./api.js";

const LEVELS = ["nvme_command", "nvme_transaction", "split", "link", "packets"];
const LABEL = { packets: "packet", link: "link transaction", split: "split transaction", nvme_transaction: "NVMe transaction", nvme_command: "NVMe command" };
const FILES = { packets: "packets.csv (113 columns)", link: "link.csv (34 columns)", split: "split.csv (17 columns)", nvme_transaction: "NVME_Transactions.csv (402 columns)", nvme_command: "nvme_command.csv (1598 columns)" };
const MEASURE = { packets: "nothing: a packet has no length in time", link: "from the packet to the receipt (Ack) or refusal (Nak) that answered it", split: "from the request to its answer (the completion)", nvme_transaction: "from the first packet to the last packet of the step", nvme_command: "from the doorbell ring to the drive's answer (the command's latency)" };
const IO_OPC = { 0: "Flush", 1: "Write", 2: "Read", 4: "Write Uncorrectable", 5: "Compare", 8: "Write Zeroes", 9: "Dataset Management", 12: "Verify", 13: "Reservation Register", 14: "Reservation Report", 17: "Reservation Acquire", 21: "Reservation Release", 25: "Copy" };
const ADMIN_OPC = { 0: "Delete I/O SQ", 1: "Create I/O SQ", 2: "Get Log Page", 4: "Delete I/O CQ", 5: "Create I/O CQ", 6: "Identify", 8: "Abort", 9: "Set Features", 10: "Get Features", 12: "Async Event Request", 13: "Namespace Management", 16: "Firmware Commit", 17: "Firmware Image Download", 20: "Device Self-test", 21: "Namespace Attachment", 24: "Keep Alive", 25: "Directive Send", 26: "Directive Receive", 28: "Virtualization Management", 29: "NVMe-MI Send", 30: "NVMe-MI Receive", 124: "Doorbell Buffer Config", 128: "Format NVM", 129: "Security Send", 130: "Security Receive", 132: "Sanitize", 134: "Get LBA Status" };
export const opcName = (opc, sqid) => opc === null || opc === undefined ? "-" : ((sqid === 0 ? ADMIN_OPC : IO_OPC)[opc] || ("opcode " + opc)) + (sqid === 0 ? " (admin)" : "");
const statusText = r => r.sct === null || r.sct === undefined ? "-" : (r.sct === 0 && r.sc === 0 ? "success" : ((r.raw && (r.raw["ST"] || r.raw["Cpl Status"]) || "").replace(/^0x[0-9A-Fa-f]+\s*\(?/, "").replace(/\)$/, "").trim() || `type ${r.sct} code ${r.sc}`));
const tsText = r => { const t = r.raw && r.raw["Time Stamp"]; if (!t) return "-"; const m = /^0*(\d+)\.(\d+)s$/.exec(t); return m ? `${m[1]}.${m[2].replace(/0+$/, "") || "0"} s` : t; };
const SHOW = {
  nvme_command: [["NVMe Cmd", r => r.n], ["command", r => opcName(r.opc, r.sqid)], ["queue / id", r => `${r.sqid ?? "-"} / ${r.cid ?? "-"}`], ["namespace", r => r.nsid ?? "-"], ["start LBA", r => r.slba ?? "-"], ["blocks", r => r.nlb === null || r.nlb === undefined ? "-" : r.nlb + 1], ["bytes", r => r.nbytes ?? "-"], ["status", statusText], ["NVMe transactions", r => r.n_ntx ?? "-"], ["duration", r => r.dur_ps_text || "-"], ["Time Delta", r => r.delta_ps_text || "-"], ["Time Stamp", tsText], ["errors", r => r.errors || ""], ["warnings", r => r.warnings || ""]],
  nvme_transaction: [["NVMe", r => r.n], ["type", r => r.type || "-"], ["queue / id", r => `${r.sqid ?? r.qid ?? "-"} / ${r.cid ?? "-"}`], ["address", r => r.raw["Address"] || "-"], ["bytes", r => r.nbytes ?? "-"], ["status", statusText], ["link+split", r => r.n_links_splits ?? "-"], ["duration", r => r.dur_ps_text || "-"], ["Time Delta", r => r.delta_ps_text || "-"], ["Time Stamp", tsText], ["errors", r => r.errors || ""], ["warnings", r => r.warnings || ""]],
  split: [["Split Tra", r => r.n], ["request", r => r.tlp_type || "-"], ["direction", r => r.dir || "-"], ["requester / tag", r => `${r.rid || "-"} / ${r.tag ?? "-"}`], ["address", r => r.raw["Address"] || "-"], ["completion status", r => r.cpl_status || "-"], ["bytes", r => r.nbytes ?? "-"], ["link transactions", r => r.n_links ?? "-"], ["duration", r => r.dur_ps_text || "-"], ["Time Delta", r => r.delta_ps_text || "-"], ["Time Stamp", tsText]],
  link: [["Link Tra", r => r.n], ["TLP", r => r.tlp_type || "-"], ["direction", r => r.dir || "-"], ["PSN", r => r.psn ?? "-"], ["requester / tag", r => `${r.rid || "-"} / ${r.tag ?? "-"}`], ["address", r => r.raw["Address"] || "-"], ["completion status", r => r.cpl_status || ""], ["packets", r => r.n_packets ?? "-"], ["ack", r => r.explicit_ack || ""], ["duration", r => r.dur_ps_text || "-"], ["Time Delta", r => r.delta_ps_text || "-"], ["Time Stamp", tsText], ["errors", r => r.errors || ""]],
  packets: [["Packet", r => r.n ?? "(no number)"], ["direction", r => r.dir || "-"], ["what", r => r.tlp_type || r.dllp_type || r.os_type || r.link_event || "-"], ["PSN", r => r.psn ?? ""], ["Ack/Nak seq", r => r.acknak ?? ""], ["requester / tag", r => r.rid ? `${r.rid} / ${r.tag ?? "-"}` : ""], ["address", r => r.raw["Address"] || ""], ["length", r => r.length ?? ""], ["completion status", r => r.cpl_status || ""], ["LCRC", r => r.lcrc || ""], ["Time Delta", r => r.delta_ps_text || "-"], ["Time Stamp", tsText], ["errors", r => r.errors || ""]],
};
const NEXT = { nvme_command: "nvme_transaction", nvme_transaction: "split", split: "link", link: "packets" };
// plain-English meaning of every column heading; shown when you point at the heading
const GLOSS = {
  "NVMe Cmd": "the command's row number in the NVMe command file", "NVMe": "the row number in the NVMe transaction file", "Split Tra": "the row number in the split transaction file", "Link Tra": "the row number in the link transaction file", "Packet": "the packet's number in the packet file",
  "command": "what the order was: Read, Write, Identify… (admin) marks housekeeping orders on queue 0", "queue / id": "the queue the order went through, and the order's number inside that queue",
  "namespace": "which storage area of the drive the order touches (most drives have one, numbered 1)", "start LBA": "the number of the first block the order reads or writes (LBA = logical block address)",
  "blocks": "how many blocks the order reads or writes", "bytes": "how many bytes of data moved", "status": "the drive's verdict: success, or the error name it returned",
  "NVMe transactions": "how many pieces (doorbell, fetch, data, answer, interrupt) the command has", "duration": "from the first packet of this row to its last", "Time Delta": "the analyzer's gap from this row to the next row in the same file (a wait, not a length)",
  "Time Stamp": "when the row started, in seconds from the start of the recording", "errors": "the analyzer's error cell for this row", "warnings": "the analyzer's warning cell for this row",
  "type": "what kind of step this is: doorbell ring, order fetch, data, answer, interrupt, register", "address": "the memory address the packet reads from or writes to", "link+split": "how many link and split transactions this step is made of",
  "request": "the kind of request that opened this split transaction (a memory read, a configuration access)", "direction": "Downstream = from the computer to the drive; Upstream = from the drive to the computer",
  "requester / tag": "who sent the request and the small number it attached, used to match the answer to the request", "completion status": "the answer's status: SC = success, UR = unsupported request, CA = aborted, CRS = retry",
  "link transactions": "how many link transactions (request plus answers) this split transaction has", "TLP": "the kind of transaction packet: MRd = memory read, MWr = memory write, CplD = answer with data, Cpl = answer without data, Msg = message",
  "PSN": "packet sequence number: the running number the sender stamps on the packet; the receipt (Ack) names it", "packets": "how many packets this link transaction has (the packet, its replays, its Ack or Nak)",
  "ack": "Yes = this packet got its own receipt (Ack); No = a later receipt covered it, or none came", "what": "what the packet is: a transaction packet, a receipt (Ack), a refusal (Nak), a credit note, a training signal or a link event",
  "Ack/Nak seq": "the packet number this receipt or refusal refers to", "length": "the packet's data length in 4-byte words", "LCRC": "the packet's checksum; (Bad) means the wire corrupted it",
  "file row": "the row number in the file this row came from",
};
const NUMERIC = new Set(["NVMe Cmd", "NVMe", "Split Tra", "Link Tra", "Packet", "namespace", "start LBA", "blocks", "bytes", "NVMe transactions", "link+split", "link transactions", "packets", "PSN", "Ack/Nak seq", "length", "duration", "Time Delta", "Time Stamp"]);
const cls = c => NUMERIC.has(c[0]) ? ' class="num"' : "";

let uid = null, levelsPresent = [], filters = [], topLevel = "nvme_command", mode = "top", curDevice = "";
// the owner's rule of 2026-11-03: no admin name is asked for at the start; where a name is recorded (signals, chat, reorder, test case)
// the drive under test is the actor when the optional name field is empty, and the API falls back to "admin"
const actor = () => ($("dd-admin") && $("dd-admin").value.trim()) || curDevice || "admin";

// ------------------------------------------------------------------ scrolling lists (rows stay on disk; a page at a time comes into the browser)
// Every long list on this page (the top of the tree, each expanded child list, the summary, the defects) is a
// ScrollList: the first PAGE rows are fetched, a sentinel row at the end asks the API for the next page when it
// scrolls into view (keyset: "the rows after this file row"), and once more than MAX_DOM rows are in the browser
// the rows far above the viewport are released again (a spacer row keeps the scroll position) and are fetched
// from disk once more when the user scrolls back up. Filters are always applied in SQL by the API.
const PAGE = 200, MAX_DOM = 2000, TRIM = 600;
const SENTINEL = new WeakMap();                      // sentinel row -> its list
const io = new IntersectionObserver(entries => { for (const e of entries) if (e.isIntersecting) { const l = SENTINEL.get(e.target); if (l) l.onSentinel(e.target); } }, { rootMargin: "600px 0px" });
class ScrollList {
  // fetch({after, before, offset, limit, count}) -> {rows, total, has_more}; render(rows) -> html of the <tr>s;
  // key(row) -> file row id for keyset paging (null = offset paging); line = element for "loaded N of M rows";
  // prefix(total) -> words before that line; onPage(response, isFirst) -> extra work with the first page.
  constructor(o) {
    Object.assign(this, { key: r => r.rowid_file, prefix: () => "", onPage: null, rowsPerUnit: 1, avgH: 26 }, o);
    this.first = 0; this.last = 0; this.firstKey = null; this.lastKey = null; this.total = null; this.end = false; this.loading = false; this.dead = false;
    this.tbody.innerHTML = `<tr class="gap" hidden><td colspan="${this.colspan}"></td></tr><tr class="more"><td colspan="${this.colspan}" class="muted small">loading…</td></tr>`;
    this.gap = this.tbody.firstElementChild; this.more = this.tbody.lastElementChild;
    SENTINEL.set(this.gap, this); SENTINEL.set(this.more, this);
  }
  async start() { const r = await this.load("down"); io.observe(this.more); io.observe(this.gap); return r; }
  destroy() { this.dead = true; io.unobserve(this.gap); io.unobserve(this.more); }
  dataRows() { return [...this.tbody.children].filter(tr => tr !== this.gap && tr !== this.more && !tr.classList.contains("kids")); }
  onSentinel(el) { if (this.dead || this.loading) return; if (el === this.more && !this.end) this.load("down"); else if (el === this.gap && this.first > 0) this.load("up"); }
  async load(dir) {
    this.loading = true; this.more.firstElementChild.textContent = "reading rows from disk…";
    let r;
    try {
      const q = dir === "down" ? { after: this.lastKey, offset: this.last, limit: PAGE, count: this.total === null ? 1 : 0 }
        : { before: this.firstKey, offset: Math.max(0, this.first - PAGE), limit: Math.min(PAGE, this.first), count: 0 };
      r = await this.fetch(q);
    } catch (e) { this.more.firstElementChild.innerHTML = `<span class="bad">${esc(e.message)}</span>`; this.loading = false; return null; }
    if (this.dead) return r;
    const isFirst = this.total === null;
    if (r.total !== null && r.total !== undefined) this.total = r.total;
    const rows = r.rows || r.findings || [];
    if (dir === "down") {
      this.more.insertAdjacentHTML("beforebegin", this.render(rows));
      this.last += rows.length; if (rows.length) this.lastKey = this.key ? this.key(rows[rows.length - 1]) : null;
      if (this.firstKey === null && rows.length) this.firstKey = this.key ? this.key(rows[0]) : null;
      this.end = !r.has_more || rows.length < PAGE || (this.total !== null && this.last >= this.total);
      this.trim("top");
    } else {
      const before = document.scrollingElement.scrollTop, hBefore = this.tbody.offsetHeight;
      this.gap.insertAdjacentHTML("afterend", this.render(rows));
      this.first -= rows.length; if (rows.length) this.firstKey = this.key ? this.key(rows[0]) : null;
      this.setGap();
      document.scrollingElement.scrollTop = before + (this.tbody.offsetHeight - hBefore);   // the viewport stays on the same row
      this.end = false; this.trim("bottom");
    }
    if (this.onPage) this.onPage(r, isFirst);
    this.line && (this.line.textContent = this.lineText());
    this.more.firstElementChild.textContent = this.end ? (this.total ? "all rows of this list are loaded" : "no rows") : "more rows are read from disk as you scroll";
    this.loading = false;
    io.unobserve(this.more); io.observe(this.more); io.unobserve(this.gap); io.observe(this.gap);   // still in view? then the next page
    return r;
  }
  trim(side) {
    // release rows far from the viewport so a list of millions never holds more than MAX_DOM rows in the browser
    const rows = this.dataRows(); if (rows.length <= MAX_DOM) return;
    const n = Math.min(TRIM, rows.length - PAGE), victims = side === "top" ? rows.slice(0, n) : rows.slice(rows.length - n);
    let h = 0;
    for (const tr of victims) { const kids = tr.nextElementSibling; h += tr.offsetHeight; tr.remove(); if (kids && kids.classList.contains("kids")) { destroyListsIn(kids); h += kids.offsetHeight; kids.remove(); } }
    if (side === "top") { this.avgH = h / n; this.first += n; this.firstKey = this.key ? +this.dataRows()[0].dataset.key : null; this.setGap(); }
    else { this.last -= n; const left = this.dataRows(); this.lastKey = this.key ? +left[left.length - 1].dataset.key : null; this.end = false; }
  }
  setGap() { this.gap.hidden = this.first === 0; this.gap.firstElementChild.style.height = (this.first * this.avgH) + "px"; }
  lineText() {
    const held = this.last - this.first, tot = this.total ?? held;
    const base = `${this.prefix(tot)}loaded ${num(held)} of ${num(tot)} rows`;
    if (this.first > 0) return `${base} (rows ${num(this.first + 1)}–${num(this.last)} are in the browser; the rows above and below are read from disk again as you scroll)`;
    return this.end ? `${base}${held < tot ? " (the rest are read from disk as you scroll)" : ""}` : `${base} · the rest are read from disk as you scroll`;
  }
}
function destroyListsIn(root) { root.querySelectorAll("tr.more, tr.gap").forEach(tr => { const l = SENTINEL.get(tr); if (l) l.destroy(); }); }
const paging = q => `${q.after !== null && q.after !== undefined ? `after=${q.after}&` : q.before !== null && q.before !== undefined ? `before=${q.before}&` : `offset=${q.offset}&`}limit=${q.limit}&count=${q.count}`;

// ------------------------------------------------------------------ navigation
document.querySelectorAll("aside button.nav").forEach(b => b.onclick = () => showPage(b.dataset.page));
function showPage(p) {
  document.querySelectorAll("aside button.nav").forEach(b => b.classList.toggle("active", b.dataset.page === p));
  document.querySelectorAll("main .page").forEach(s => s.classList.toggle("active", s.id === "page-" + p));
  $("page-title").textContent = { upload: "Upload the five files", tree: "Hierarchy, summary, filters", defects: "Defects found", settings: "Time limits per level", help: "What the words mean" }[p];
  if (p === "tree" && uid) loadTree();
  if (p === "defects" && uid) loadDefectTable();
  if (p === "settings") { renderThresholds(); renderModel(); }
}

// ------------------------------------------------------------------ 1 upload
function fileRows() {
  $("file-rows").innerHTML = LEVELS.map(k => `<div class="row file-row"><label style="flex:0 0 100%">${esc(LABEL[k])} file <span class="muted">(${esc(FILES[k])})</span></label><button class="primary small" data-browse="${k}" title="pick the file on this machine">Choose file…</button><input id="path-${k}" placeholder="no file chosen yet (the path appears here; you may also type or paste any path and press Enter)"><button class="small" data-check="${k}">Check this file</button><span id="chk-${k}" class="muted small" style="flex:0 0 100%"></span></div>`).join("");
  // a path typed or pasted by hand: Enter checks it, the same as the "Check this file" button; no folder is refused
  LEVELS.forEach(k => $("path-" + k).addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); checkFile(k); } }));
  document.querySelectorAll("button[data-check]").forEach(b => b.onclick = () => checkFile(b.dataset.check));
  document.querySelectorAll("button[data-browse]").forEach(b => b.onclick = () => openBrowser(b.dataset.browse));
}

// ---- the progress bar of a running load (percent = bytes read of the five files, then build, rules, indexes)
let loadStart = null;
function showLoadProgress(j) {
  const p = j.progress || {}; const pct = Math.max(0, Math.min(100, Number(p.pct) || 0));
  $("load-bar").hidden = false; $("load-progress").value = pct; $("load-pct").textContent = pct.toFixed(pct < 10 ? 1 : 0) + " %";
  $("load-status").textContent = `${p.step || ""}: ${p.detail || ""}`;
  if (!loadStart) loadStart = Date.now() - (j.elapsed_s || 0) * 1000;
  const el = (Date.now() - loadStart) / 1000;
  $("load-eta").textContent = pct > 2 && pct < 100 ? `${Math.round(el / 60)} min so far, about ${Math.max(1, Math.round(el * (100 - pct) / pct / 60))} min left` : (pct >= 100 ? `done in ${Math.round(el / 60)} min` : "");
  $("nav-upload").innerHTML = `<progress max="100" value="${pct}"></progress><div>${pct.toFixed(0)} % · ${esc(p.step || "")}</div>`;
}
function watchLoad(job) {
  loadStart = null; $("load-bar").hidden = false; $("load-progress").value = 0; $("load-pct").textContent = "0 %"; $("load-eta").textContent = "";
  poll(job, showLoadProgress, async j => {
    showLoadProgress(j);
    $("load-status").textContent = j.status === "done" ? "done" : "failed: " + (j.error || "").split("\n")[0];
    if (j.status !== "done") { $("load-pct").textContent = "stopped"; $("nav-upload").textContent = "load stopped: " + (j.error || "").split("\n")[0]; }
    await openUpload(uid); listUploads();
  });
}

// ---- model connection (settings page): URL, model name, key variable, the key (write-only), a test call
async function renderModel() {
  try {
    const m = await api("GET", "/api/hier/model");
    $("mdl-url").value = m.base_url || ""; $("mdl-model").value = m.model || ""; $("mdl-keyenv").value = m.api_key_env || "ANTHROPIC_API_KEY"; $("mdl-key").value = "";
    $("mdl-state").textContent = `in use now: ${m.active === "stand-in" || m.active === "standin" ? "the stand-in (no model)" : m.active} · key ${m.key_present ? "present" : "missing"} in the environment · private key file: ${m.env_file}` + (m.locked ? " · the address and the key are locked by the production setting; change them in the files and restart" : "");
    if (m.locked) { $("mdl-url").disabled = true; $("mdl-keyenv").disabled = true; $("mdl-key").disabled = true; }
  } catch (e) { $("mdl-state").textContent = "could not read the model settings: " + e.message; }
}
$("mdl-save").onclick = async () => {
  $("mdl-status").textContent = "saving…";
  const body = { base_url: $("mdl-url").value.trim(), model: $("mdl-model").value.trim(), api_key_env: $("mdl-keyenv").value.trim() || "ANTHROPIC_API_KEY" };
  if ($("mdl-key").value.trim()) body.key = $("mdl-key").value.trim();
  try { const r = await api("PUT", "/api/hier/model", body); $("mdl-status").textContent = `saved · in use now: ${r.active}` + (r.key_written_to_env_file ? " · the key was written to the private file" : ""); $("mdl-key").value = ""; renderModel(); }
  catch (e) { $("mdl-status").innerHTML = `<span class="bad">${esc(e.message)}</span>`; }
};
$("mdl-test").onclick = async () => {
  $("mdl-status").textContent = "testing… (up to four tries with pauses, so this can take a little while)";
  try {
    const r = await api("POST", "/api/hier/model/test", {});
    $("mdl-status").innerHTML = r.ok ? `<span class="ok">the model answered</span> · ${esc(r.producer)} · ${r.tries} ${r.tries === 1 ? "try" : "tries"} · ${r.seconds} s` : `<span class="bad">no answer: ${esc(r.error || "")}</span>${r.tries ? ` · after ${r.tries} tries` : ""} · the stand-in will answer until this works`;
  } catch (e) { $("mdl-status").innerHTML = `<span class="bad">${esc(e.message)}</span>`; }
};

// ---- file picker: a folder browser on the server (the files stay where they are; nothing is copied)
let brFor = null;
function openBrowser(k) {
  brFor = k;
  $("br-title").textContent = `Choose the ${LABEL[k]} file`;
  const start = $("path-" + k).value.trim() || LEVELS.map(x => $("path-" + x).value.trim()).find(v => v) || (localStorage.getItem("hier.lastFolder") || "");
  $("browser").hidden = false;
  browseTo(start ? start.replace(/[^/]*$/, "") : "");
}
async function browseTo(path) {
  const box = $("br-lists");
  box.innerHTML = `<p class="muted small">reading the folder…</p>`;
  let r;
  try { r = await api("GET", "/api/hier/browse?path=" + encodeURIComponent(path)); }
  catch (e) { box.innerHTML = `<p class="bad">${esc(e.message)}</p><p class="small muted">Starting points (shortcuts only: any folder on this machine can be opened, type its path above and press Enter):</p>` + ""; try { const r0 = await api("GET", "/api/hier/browse?path="); box.innerHTML += rootsList(r0.roots); } catch (_) {} return; }
  $("br-path").value = r.path;
  $("br-up").disabled = !r.parent;
  $("br-up").onclick = () => r.parent && browseTo(r.parent);
  try { if (r.path) localStorage.setItem("hier.lastFolder", r.path); } catch (_) {}
  let h = "";
  if (!r.path) h += `<p class="small muted">Starting points (shortcuts only: any folder on this machine can be opened, type its path above and press Enter):</p>` + rootsList(r.roots);
  if (r.dirs.length && r.path) h += `<table><tbody>` + r.dirs.map(d => `<tr class="pick" data-dir="${esc(d.path)}"><td>&#128193;</td><td>${esc(d.name)}</td><td class="muted small">folder</td></tr>`).join("") + `</tbody></table>`;
  if (r.files.length) h += `<table><thead><tr><th></th><th>file</th><th>looks like</th><th>size</th><th>changed</th></tr></thead><tbody>` + r.files.map(f => `<tr class="pick" data-file="${esc(f.path)}" data-level="${esc(f.level || "")}"><td>&#128196;</td><td>${esc(f.name)}</td><td>${f.level ? (f.level === brFor ? `<span class="ok">the ${esc(f.level_label)} file</span>` : esc(f.level_label + " file")) : `<span class="muted">not one of the five exports</span>`}</td><td>${num(f.bytes)} bytes</td><td class="muted small">${esc(f.modified)}</td></tr>`).join("") + `</tbody></table>`;
  if (r.path && !r.dirs.length && !r.files.length) h += `<p class="muted">this folder has no sub-folders and no CSV files</p>`;
  box.innerHTML = h;
  box.querySelectorAll("tr[data-dir]").forEach(tr => tr.onclick = () => browseTo(tr.dataset.dir));
  box.querySelectorAll("tr[data-file]").forEach(tr => tr.onclick = () => pickFile(tr.dataset.file, r.files));
}
function rootsList(roots) { return `<table><tbody>` + (roots || []).map(p => `<tr class="pick" data-dir="${esc(p)}"><td>&#128193;</td><td>${esc(p)}</td></tr>`).join("") + `</tbody></table>`; }
function pickFile(path, files) {
  $("path-" + brFor).value = path;
  checkFile(brFor);
  // the other four: fill the empty inputs with the files of this folder whose header looks like that level
  let filled = 0;
  LEVELS.filter(k => k !== brFor && !$("path-" + k).value.trim()).forEach(k => {
    const cands = files.filter(f => f.level === k && f.path !== path);
    if (cands.length === 1) { $("path-" + k).value = cands[0].path; checkFile(k); filled++; }
    else if (cands.length > 1) { $("chk-" + k).innerHTML = `<span class="warn">${cands.length} files in that folder look like the ${esc(LABEL[k])} file; choose one with Browse…</span>`; }
  });
  $("browser").hidden = true;
  if (filled) $("load-status").textContent = `${filled} other file${filled > 1 ? "s" : ""} filled in from the same folder; check the five lines, then load`;
}
$("br-close").onclick = () => { $("browser").hidden = true; };
$("browser").addEventListener("click", e => { if (e.target === $("browser")) $("browser").hidden = true; });
$("br-go").onclick = () => browseTo($("br-path").value.trim());
$("br-path").addEventListener("keydown", e => { if (e.key === "Enter") browseTo($("br-path").value.trim()); });
document.addEventListener("keydown", e => { if (e.key === "Escape" && !$("browser").hidden) $("browser").hidden = true; });
async function checkFile(k) {
  const p = $("path-" + k).value.trim(); const out = $("chk-" + k);
  if (!p) { out.textContent = "give a path first"; return; }
  out.textContent = "checking…";
  try {
    const r = await api("POST", "/api/hier/sniff", { path: p });
    const hc = r.header_check;
    const lvl = r.level ? (r.level === k ? `<span class="ok">looks like the ${esc(LABEL[k])} file</span>` : `<span class="warn">looks like the ${esc(r.level_label)} file, not the ${esc(LABEL[k])} file</span>`) : `<span class="warn">level not recognised from the header</span>`;
    out.innerHTML = `${lvl} · ${num(r.bytes)} bytes · ${r.columns_in_file} columns in the file` + (hc && hc.header_format && hc.header_format.startsWith("the customer") ? ` · <span class="ok">read from ${esc(hc.header_format)}</span>` : "") + (hc ? ` · found ${hc.found_named_columns} of the ${hc.expected_named_columns} expected column names in the first line, ${hc.separator_columns_dropped} unnamed spacer columns (kept, nothing is removed)` + (hc.missing_columns.length ? `, <span class="warn">missing: ${esc(hc.missing_columns.slice(0, 4).join(", "))}</span>` : "") + (hc.unknown_columns.length ? `, <span class="warn">unknown: ${esc(hc.unknown_columns.slice(0, 4).map(u => u.header).join(", "))}</span>` : "") + ((hc.extra_columns_kept || []).length ? `, ${hc.extra_columns_kept.length} extra column${hc.extra_columns_kept.length > 1 ? "s" : ""} kept (${esc(hc.extra_columns_kept.slice(0, 6).join(", "))}${hc.extra_columns_kept.length > 6 ? ", …" : ""})` : "") : "");
  } catch (e) { out.innerHTML = `<span class="bad">${esc(e.message)}</span>`; }
}
$("btn-load").onclick = async () => {
  const files = {}; LEVELS.forEach(k => { const v = $("path-" + k).value.trim(); if (v) files[k] = v; });
  if (!$("device").value.trim()) { toast("the drive under test is required"); $("device").focus(); return; }
  const body = { files, operator: $("operator").value, device: $("device").value, trace_name: $("trace_name").value, recording_date: $("recording_date").value, notes: $("notes").value };
  $("load-status").textContent = "starting…";
  try {
    const r = await api("POST", "/api/hier/uploads", body);
    uid = r.upload_id; $("upload-badge").textContent = uid;
    $("load-status").textContent = "loading…";
    watchLoad(r.job);
  } catch (e) { $("load-status").innerHTML = `<span class="bad">${esc(e.message)}</span>`; }
};
async function listUploads() {
  const ups = await api("GET", "/api/hier/uploads");
  const sel = $("upload-select"); sel.innerHTML = `<option value="">- none -</option>` + ups.map(u => `<option value="${esc(u.upload_id)}">${esc(u.upload_id)} · ${esc(u.trace_name || "no trace name")} · ${esc(u.operator)}</option>`).join("");
  if (uid) sel.value = uid;
  $("uploads-list").innerHTML = ups.length ? `<table><thead><tr><th>upload</th><th>trace</th><th>device</th><th>by</th><th>files</th><th>status</th><th></th></tr></thead><tbody>` + ups.map(u => `<tr><td>${esc(u.upload_id)}</td><td>${esc(u.trace_name || "-")}</td><td>${esc(u.device || "-")}</td><td>${esc(u.operator)}</td><td>${u.files.map(f => esc(LABEL[f])).join(", ")}</td><td>${esc(u.status)}${u.status === "loading" && u.progress ? ` <progress max="100" value="${Number(u.progress.pct) || 0}" style="width:90px;height:10px"></progress> ${(Number(u.progress.pct) || 0).toFixed(0)} % <button class="small" data-watch="${esc(u.job)}" data-uid="${esc(u.upload_id)}">follow</button>` : ""}${u.status === "interrupted" ? ` <span class="warn small">(${esc(u.error || "the server stopped while loading")})</span>` : ""}</td><td><button class="small" data-open="${esc(u.upload_id)}">open</button> ${u.status === "interrupted" || u.status === "failed" ? `<button class="small primary" data-again="${esc(u.upload_id)}" title="same five files, same names: a fresh load">load again</button> ` : ""}<button class="small danger" data-del="${esc(u.upload_id)}">remove</button></td></tr>`).join("") + "</tbody></table>" : "none yet";
  document.querySelectorAll("button[data-watch]").forEach(b => b.onclick = () => { uid = b.dataset.uid; $("upload-badge").textContent = uid; watchLoad(b.dataset.watch); window.scrollTo(0, 0); });
  document.querySelectorAll("button[data-again]").forEach(b => b.onclick = async () => {
    const u = ups.find(x => x.upload_id === b.dataset.again); if (!u) return;
    b.disabled = true; b.textContent = "starting…";
    try {
      const r = await api("POST", "/api/hier/uploads", { files: u.file_paths, operator: u.operator, device: u.device, trace_name: u.trace_name, recording_date: u.recording_date, notes: u.notes });
      await api("DELETE", "/api/hier/uploads/" + u.upload_id);
      uid = r.upload_id; $("upload-badge").textContent = uid; $("load-status").textContent = "loading…";
      watchLoad(r.job);
      listUploads();
    } catch (e) { b.textContent = "failed: " + e.message; }
  });
  document.querySelectorAll("button[data-open]").forEach(b => b.onclick = () => openUpload(b.dataset.open));
  document.querySelectorAll("button[data-del]").forEach(b => b.onclick = async () => { if (!b.dataset.sure) { b.dataset.sure = "1"; b.textContent = "remove for sure?"; return; } await api("DELETE", "/api/hier/uploads/" + b.dataset.del); if (uid === b.dataset.del) uid = null; listUploads(); });
}
$("upload-select").onchange = e => { if (e.target.value) openUpload(e.target.value); };
async function openUpload(id) {
  const m = await api("GET", "/api/hier/uploads/" + id);
  uid = id; levelsPresent = m.levels_present || []; curDevice = m.device || ""; $("upload-badge").textContent = id;
  $("upload-select").value = id;
  $("report-card").hidden = false;
  const reps = m.load_reports || {};
  let h = `<p>${esc(m.trace_name || "no trace name")} · device ${esc(m.device || "from the trace")} · uploaded by ${esc(m.operator)} · status ${esc(m.job_status || m.status)}` + (m.job_error ? ` · <span class="bad">${esc(m.job_error.split("\n")[0])}</span>` : "") + `</p>`;
  h += `<table class="report"><thead><tr><th>level</th><th>rows read</th><th>column names found (of the expected)</th><th>unnamed spacer columns (kept)</th><th>unnamed columns given a name</th><th>names missing / unexpected</th><th>unreadable cells</th></tr></thead><tbody>`;
  for (const k of LEVELS) {
    const r = reps[k];
    if (!r) { h += `<tr><td>${esc(LABEL[k])}</td><td colspan="6" class="muted">not given</td></tr>`; continue; }
    const unread = Object.entries(r.unreadable_cells || {}).map(([c, u]) => `${esc(c)}: ${num(u.count)} (e.g. "${esc(u.example)}")`).join("; ") || "none";
    h += `<tr><td>${esc(LABEL[k])}</td><td class="num">${num(r.rows)}</td><td>${r.found_named_columns} of ${r.expected_named_columns}</td><td class="num">${r.separator_columns_dropped}</td><td>${esc(Object.keys(r.label_less_columns_named || {}).join(", ") || "-")}</td><td>${(r.missing_columns || []).length ? `<span class="warn">missing ${esc(r.missing_columns.slice(0, 5).join(", "))}</span>` : ""}${(r.unknown_columns || []).length ? ` <span class="warn">unknown ${esc(r.unknown_columns.slice(0, 5).map(u => u.header).join(", "))}</span>` : ""}${!(r.missing_columns || []).length && !(r.unknown_columns || []).length ? `<span class="ok">header matches</span>` : ""}${(r.extra_columns_kept || []).length ? ` <span class="muted">+${r.extra_columns_kept.length} extra kept: ${esc(r.extra_columns_kept.slice(0, 5).join(", "))}</span>` : ""}</td><td>${unread}</td></tr>`;
  }
  h += "</tbody></table>";
  if (m.build) h += `<h3>Tree build</h3><pre class="small">${esc(JSON.stringify(m.build, null, 1))}</pre>`;
  if (m.job_spans) h += `<p class="muted small">time taken: ${m.job_spans.map(s => `${esc(s.name)} ${s.seconds} s`).join(" · ")}</p>`;
  $("report").innerHTML = h;
  $("nav-upload").textContent = levelsPresent.map(k => LABEL[k]).join(", ");
  topLevel = levelsPresent[0] || "nvme_command";
  fillFilterLevels();
  listUploads();
}

// ------------------------------------------------------------------ 2 tree + filters
function fillFilterLevels() {
  $("f-level").innerHTML = levelsPresent.map(k => `<option value="${k}">${esc(LABEL[k])}</option>`).join("");
  fillFilterCols();
}
async function fillFilterCols() {
  const lvl = $("f-level").value; if (!lvl || !uid) return;
  const c = await api("GET", `/api/hier/uploads/${uid}/columns?level=${lvl}`);
  const typed = c.typed.map(t => `<option value="${esc(t.sql)}">${esc(t.names.join(" / "))}${t.kind === "time" ? " (time)" : ""}</option>`).join("");
  const rest = c.all_columns.filter(n => !c.typed.some(t => t.names.includes(n))).map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join("");
  $("f-col").innerHTML = typed + (rest ? `<option disabled>— every other column —</option>` + rest : "");
}
$("f-level").onchange = fillFilterCols;
const TIME_RE = /^\s*(-?\d+(?:\.\d+)?)\s*(ps|ns|us|µs|ms|s)\s*$/i;
const UNIT = { ps: 1, ns: 1e3, us: 1e6, "µs": 1e6, ms: 1e9, s: 1e12 };
function parseVal(col, op, v) {
  if (op === "between") return v.split(",").map(x => parseVal(col, "eq", x.trim()));
  if (op === "in") return v.split(",").map(x => x.trim()).filter(Boolean);
  const m = TIME_RE.exec(v); if (m && /_ps$/.test(col)) return Math.round(parseFloat(m[1]) * UNIT[m[2].toLowerCase()]);
  if (/^-?\d+(\.\d+)?$/.test(v)) return Number(v);
  if (/^0x[0-9a-f]+$/i.test(v)) return parseInt(v, 16);
  return v;
}
$("f-add").onclick = () => {
  const level = $("f-level").value, column = $("f-col").value, op = $("f-op").value, raw = $("f-val").value;
  if (!column) return;
  filters.push({ level, column, op, value: parseVal(column, op, raw), text: raw });
  renderChips(); loadTree();
};
$("f-clear").onclick = () => { filters = []; renderChips(); loadTree(); };
function renderChips() {
  $("chips").innerHTML = filters.map((f, i) => `<span class="chip">${esc(LABEL[f.level])} · ${esc(f.column)} ${esc($("f-op").querySelector(`option[value=${f.op}]`).textContent)} ${esc(f.text)} <button data-i="${i}" title="remove">✕</button></span>`).join("");
  document.querySelectorAll(".chip button").forEach(b => b.onclick = () => { filters.splice(+b.dataset.i, 1); renderChips(); loadTree(); });
}
const filtersFor = lvl => JSON.stringify(filters.filter(f => f.level === lvl).map(({ column, op, value }) => ({ column, op, value })));
let findingAt = [];
function rowsUrl(lvl, extra) { return `/api/hier/uploads/${uid}/rows?level=${lvl}&filters=${encodeURIComponent(filtersFor(lvl))}${findingAt.length && lvl === topLevel ? "&finding_at=" + findingAt.join(",") : ""}&${extra}`; }

let topList = null;
async function loadTree() {
  if (!uid || !levelsPresent.length) { $("tree").innerHTML = `<span class="muted">open an upload first</span>`; return; }
  const lvl = topLevel;
  destroyListsIn($("tree")); if (topList) topList.destroy();
  const scope = mode === "outside" ? "top=1&relation=orphan" : "top=1";
  $("crumb").textContent = mode === "outside" ? "rows outside any command" : `top level: ${LABEL[lvl]}s`;
  $("tree").innerHTML = tableShell(lvl);
  $("tree-page").textContent = "reading rows from disk…";
  topList = new ScrollList({
    tbody: $("tree").querySelector("tbody"), colspan: colspanOf(lvl), line: $("tree-page"),
    fetch: q => api("GET", rowsUrl(lvl, `${scope}&${paging(q)}`)), render: rows => rowsHtml(lvl, rows),
    onPage: (r, isFirst) => { if (isFirst) $("nav-tree").textContent = `${num(r.total)} ${LABEL[lvl]}s`; },
  });
  await topList.start();
  if ($("summary-card").hidden === false) loadSummary();
}
function hiddenCols(lvl) { try { return new Set(JSON.parse(localStorage.getItem("hier.hide." + lvl) || "[]")); } catch (e) { return new Set(); } }
function visibleCols(lvl) { const h = hiddenCols(lvl); return SHOW[lvl].filter(c => !h.has(c[0])); }
const colspanOf = lvl => visibleCols(lvl).length + 2;
function tableShell(lvl) {
  const cols = visibleCols(lvl);
  const canExpand = NEXT[lvl] && levelsPresent.includes(NEXT[lvl]);
  const th = c => `<th${cls(c)} title="${esc(GLOSS[c[0]] || "")}">${esc(c[0])}</th>`;
  return `<table><thead><tr>${canExpand ? `<th title="opens the level below this row"></th>` : ""}${cols.map(th).join("")}<th title="${esc(GLOSS["file row"])}">file row</th></tr></thead><tbody></tbody></table>`;
}
const cellClass = (c, v) => c[0] === "status" ? (v === "success" ? ' class="ok"' : (v && v !== "-" ? ' class="bad"' : "")) : cls(c);
function rowsHtml(lvl, rows) {
  const cols = visibleCols(lvl);
  const canExpand = NEXT[lvl] && levelsPresent.includes(NEXT[lvl]);
  return rows.map(r => `<tr class="${(r.errors || r.n_findings || r.n_sub_findings) ? "has-err" : ""} ${r.relation === "context" ? "ctx" : ""}" data-rid="${r.rowid_file}" data-key="${r.rowid_file}">${canExpand ? `<td><button class="exp" data-lvl="${lvl}" data-rid="${r.rowid_file}">expand</button></td>` : ""}${cols.map(c => { const v = c[1](r); return `<td${cellClass(c, v)}>${esc(v)}</td>`; }).join("")}<td class="src" title="row ${r.rowid_file} of the ${esc(LABEL[lvl])} file">${r.rowid_file}</td></tr><tr class="kids" data-for="${r.rowid_file}" hidden><td colspan="${cols.length + 2}"></td></tr>`).join("");
}
// children of one row: a lazily fetched, scrolling list per level below it (collapse frees the DOM)
$("tree").addEventListener("click", async ev => {
  const b = ev.target.closest("button.exp"); if (!b || !$("tree").contains(b)) return;
  const lvl = b.dataset.lvl, rid = b.dataset.rid, next = NEXT[lvl];
  const holder = b.closest("tr").nextElementSibling, cell = holder.firstElementChild;
  if (!holder.hidden) { destroyListsIn(cell); cell.innerHTML = ""; holder.hidden = true; b.textContent = "expand"; return; }
  b.textContent = "…";
  // children at the next level; for an NVMe transaction also the link transactions attached directly (posted writes);
  // for every level the context packets of its time window
  const parts = [[next, `parent_level=${lvl}&parent=${rid}`, t => `${num(t)} ${LABEL[next]}${t === 1 ? "" : "s"} of this ${LABEL[lvl]} · `, true]];
  if (lvl === "nvme_transaction" && levelsPresent.includes("link")) parts.push(["link", `parent_level=nvme_transaction&parent=${rid}`, t => `${num(t)} link transaction${t === 1 ? "" : "s"} directly under this NVMe transaction (posted writes have no split transaction) · `, false]);
  if (lvl !== "packets" && levelsPresent.includes("packets")) parts.push(["packets", `parent_level=${lvl}&parent=${rid}&relation=context`, t => `${num(t)} context packet${t === 1 ? "" : "s"} in this ${LABEL[lvl]}'s time window (flow control, ordered sets, link events) · `, false]);
  cell.innerHTML = parts.map(([l], i) => `<div class="lvl l-${l}" data-part="${i}"><div class="crumb"></div>${tableShell(l)}</div>`).join("");
  holder.hidden = false;
  let any = false;
  for (const [i, [l, scope, prefix, always]] of parts.entries()) {
    const box = cell.querySelector(`[data-part="${i}"]`);
    const list = new ScrollList({ tbody: box.querySelector("tbody"), colspan: colspanOf(l), line: box.querySelector(".crumb"), prefix,
      fetch: q => api("GET", rowsUrl(l, `${scope}&${paging(q)}`)), render: rows => rowsHtml(l, rows) });
    const r = await list.start();
    if (!r || (!r.total && !always)) { list.destroy(); box.remove(); } else any = true;
  }
  if (!any) cell.innerHTML = `<span class="muted">nothing below (tree links are filled when the build runs)</span>`;
  b.textContent = "collapse";
});
$("btn-outside").onclick = () => { mode = mode === "outside" ? "top" : "outside"; loadTree(); };
$("btn-cols").onclick = () => {
  const pop = $("cols-pop"); if (!pop.hidden) { pop.hidden = true; return; }
  const lvl = topLevel; const h = hiddenCols(lvl);
  pop.innerHTML = `<div class="muted small" style="margin-bottom:4px">columns of the ${esc(LABEL[lvl])} list (the choice is remembered in this browser)</div>` + SHOW[lvl].map(c => `<label><input type="checkbox" data-col="${esc(c[0])}" ${h.has(c[0]) ? "" : "checked"}> ${esc(c[0])}</label>`).join("") + `<div style="margin-top:6px"><button class="small" id="cols-all">show all</button> <button class="small" id="cols-close">close</button></div>`;
  pop.hidden = false;
  const save = () => { const hide = [...pop.querySelectorAll("input[data-col]")].filter(i => !i.checked).map(i => i.dataset.col); try { localStorage.setItem("hier.hide." + lvl, JSON.stringify(hide)); } catch (e) {} loadTree(); };
  pop.querySelectorAll("input[data-col]").forEach(i => i.onchange = save);
  pop.querySelector("#cols-all").onclick = () => { pop.querySelectorAll("input[data-col]").forEach(i => i.checked = true); save(); };
  pop.querySelector("#cols-close").onclick = () => { pop.hidden = true; };
};
document.addEventListener("click", e => { const pop = $("cols-pop"); if (!pop.hidden && !pop.contains(e.target) && e.target !== $("btn-cols")) pop.hidden = true; });
document.querySelectorAll("#errfilters input[type=checkbox]").forEach(cb => cb.onchange = () => {
  // "error at level X" = the command's subtree holds a rule finding (severity error) at that level
  findingAt = [...document.querySelectorAll("#errfilters input:checked")].map(c => c.dataset.lvl);
  loadTree();
});

// ------------------------------------------------------------------ summary (one SQL aggregate row per command, paged like the tree)
let summaryList = null;
function summaryRow(c) {
  const params = [c.nsid !== null && c.nsid !== undefined ? `namespace ${c.nsid}` : "", c.slba !== null && c.slba !== undefined ? `start LBA ${c.slba}` : "", c.nlb !== null && c.nlb !== undefined ? `${c.nlb + 1} blocks` : "", c.nbytes ? `${num(c.nbytes)} bytes` : "", c.fua ? "FUA" : "", c.cns ? `CNS ${c.cns}` : "", c.fid ? `feature ${c.fid}` : "", c.lid ? `log ${c.lid}` : "", c.ad ? "deallocate" : "", c.nr ? `${(+c.nr) + 1} ranges` : ""].filter(Boolean).join(" · ") || "-";
  const below = Object.entries(c.findings_by_level || {}).filter(([l]) => l !== "nvme_command").map(([l, k]) => `${k} at the ${LABEL[l]} level`).join(", ");
  const errs = [c.errors ? `analyzer: ${c.errors}` : "", c.warnings ? `warning: ${c.warnings}` : "", (c.sct || c.sc) ? `status type ${c.sct} code ${c.sc}` : "", c.n_findings ? `${c.n_findings} rule hit${c.n_findings === 1 ? "" : "s"} at this level` : "", c.n_sub_findings ? `${c.n_sub_findings} below (${below || (c.cause_level ? LABEL[c.cause_level] + " level" : "lower level")})` : "", c.role || ""].filter(Boolean).join(" · ") || "none";
  return `<tr class="${(c.errors || c.sc || c.n_findings || c.n_sub_findings) ? "has-err" : ""}" data-key="${c.rowid_file}"><td>${esc(opcName(c.opc, c.sqid))}<br><span class="muted small">command ${c.n}, queue ${c.sqid}, id ${c.cid}</span></td><td>${esc(params)}</td><td>Time Delta ${esc(c.delta_ps_text || "-")}<br><span class="muted small">duration ${esc(c.dur_ps_text || "not built yet")}</span></td><td>${esc(errs)}</td><td class="muted small">${c.n_ntx ?? "-"} NVMe transactions</td></tr>`;
}
async function loadSummary() {
  if (!uid || !levelsPresent.includes("nvme_command")) { toast("the summary needs the NVMe command file"); return; }
  if (summaryList) summaryList.destroy();
  const scope = `filters=${encodeURIComponent(filtersFor("nvme_command"))}${findingAt.length ? "&finding_at=" + findingAt.join(",") : ""}${mode === "outside" ? "&relation=orphan" : ""}`;
  $("summary-card").hidden = false;
  summaryList = new ScrollList({
    tbody: $("summary-table").querySelector("tbody"), colspan: 5, line: $("summary-page"),
    fetch: q => api("GET", `/api/hier/uploads/${uid}/summary?${scope}&${paging(q)}`), render: rows => rows.map(summaryRow).join(""),
    onPage: (r, isFirst) => {
      if (!isFirst || !r.totals) return;
      const t = r.totals;
      $("summary-totals").textContent = `${num(t.commands)} commands in this selection · ${num(t.commands_with_errors)} with an error or a rule hit · ${num(t.nvme_transactions)} NVMe transactions · longest command ${t.longest_text || "-"}, mean ${t.mean_text || "-"} (computed by the database, not in the browser)`;
    },
  });
  await summaryList.start();
}
$("btn-summary").onclick = async () => { if (!$("summary-card").hidden && summaryList) { $("summary-card").hidden = true; summaryList.destroy(); summaryList = null; return; } await loadSummary(); $("summary-card").scrollIntoView({ behavior: "smooth", block: "start" }); };

// ------------------------------------------------------------------ settings
let thrCache = {};
async function renderThresholds() {
  const th = uid ? await api("GET", `/api/hier/uploads/${uid}/thresholds`) : {};
  thrCache = th;
  const DFLT = { link: "50 us (PCIe replay timer, the default)", nvme_transaction: "50 ms (PCIe completion timeout, the default)" };
  const p3Text = k => k in th ? (th[k] === null ? "no limit: timing at this level is not considered" : `${th[k].value} ${th[k].unit} (${th[k].source || "set by the admin"})`) : DFLT[k];
  $("thr-table").querySelector("tbody").innerHTML = LEVELS.map(k => k in DFLT
    ? `<tr><td>${esc(LABEL[k])}</td><td class="muted">${esc(MEASURE[k])}</td><td colspan="3" class="muted" id="thr-${k === "link" ? "link" : "ntx"}-note">${esc(p3Text(k))} · this limit is set at the top of page 3, not here</td></tr>`
    : `<tr><td>${esc(LABEL[k])}</td><td class="muted">${esc(MEASURE[k])}</td><td><input id="thr-v-${k}" size="8" value="${th[k] ? th[k].value : ""}"></td><td><select id="thr-u-${k}">${["ns", "us", "ms", "s"].map(u => `<option ${th[k] && th[k].unit === u ? "selected" : (!th[k] && u === "ms" ? "selected" : "")}>${u}</option>`).join("")}</select></td><td><input id="thr-s-${k}" value="${esc(th[k] ? th[k].source : "")}" placeholder="where this limit comes from"></td></tr>`).join("");
}
$("btn-thr").onclick = async () => {
  if (!uid) { toast("open an upload first"); return; }
  const body = {}; LEVELS.filter(k => k !== "link" && k !== "nvme_transaction").forEach(k => { const v = $("thr-v-" + k).value.trim(); if (v) body[k] = { value: v, unit: $("thr-u-" + k).value, source: $("thr-s-" + k).value }; });
  for (const k of ["link", "nvme_transaction"]) if (k in thrCache) body[k] = thrCache[k];        // page 3's two limits are kept as they are (null = not considered)
  await api("PUT", `/api/hier/uploads/${uid}/thresholds`, body);
  $("thr-status").textContent = "saved; the rules use these limits on the next run";
};

// ------------------------------------------------------------------ start
fileRows();
listUploads();

// ------------------------------------------------------------------ 3 defects: the defect table (one row per NVMe command, error or not)
let curFinding = null, curDetail = null, curWindow = null, curProposal = null, dtList = null, timingLimits = null;
const SEV = { error: ["bad", "✕"], check: ["warn", "?"], warning: ["info", "!"] };
const sevPill = s => { const [c, i] = SEV[s] || ["", ""]; return `<span class="pill ${c}">${i} ${esc(s)}</span>`; };
const CHIP = { error: "chip-err", check: "chip-chk", warning: "chip-wrn" };
const isolateUrl = fid => `/isolate?upload=${encodeURIComponent(uid)}&finding=${fid}`;
const paramsText = c => [c.nsid !== null && c.nsid !== undefined ? `namespace ${c.nsid}` : "", c.slba !== null && c.slba !== undefined ? `start LBA ${c.slba}` : "", c.nlb !== null && c.nlb !== undefined ? `${c.nlb + 1} blocks` : "", c.nbytes ? `${num(c.nbytes)} bytes` : "", c.fua ? "FUA" : "", c.cns ? `CNS ${c.cns}` : "", c.fid ? `feature ${c.fid}` : "", c.lid ? `log ${c.lid}` : "", c.qid !== null && c.qid !== undefined && c.sqid === 0 && [1, 5, 0, 4].includes(c.opc) ? `queue ${c.qid}${c.qsize ? ` of ${c.qsize} entries` : ""}` : "", c.ad ? "deallocate" : "", c.nr ? `${(+c.nr) + 1} ranges` : ""].filter(Boolean).join(" · ") || "no parameters";
// a short label for the chip: the rule's short name in words
const CHIP_LABEL = { "cmd.status_error": "error status", "cmd.analyzer_error": "analyzer error", "cmd.analyzer_warning": "analyzer warning", "cmd.incomplete": "never completed", "cmd.not_fetched": "entry not fetched", "cmd.doorbell_missing": "doorbell missing", "cmd.no_interrupt": "no interrupt", "cmd.latency_over_limit": "command over its limit", "cmd.bytes_short": "bytes short", "cmd.write_zeroes_readback": "write-zeroes read-back", "cmd.deallocate_readback": "deallocate read-back", "ntx.analyzer_error": "analyzer error", "ntx.analyzer_warning": "analyzer warning", "ntx.status_error": "error status", "ntx.over_limit": "NVMe transaction over the limit", "ntx.phase_wrong": "wrong phase bit", "ntx.interrupt_before_completion": "interrupt before completion", "ntx.completion_unknown_command": "completion for unknown id", "lnk.response_over_limit": "link transaction over the limit" };
const chipLabel = f => f.level === "link" ? `link transaction ${f.row_n ?? f.rowid} over the limit` : `${CHIP_LABEL[f.rule] || f.rule}${f.level === "nvme_transaction" ? ` · NVMe transaction ${f.row_n ?? f.rowid}` : ""}`;
// one finding = one chip linked to its own isolation tab (a new browser tab); the statement above carries the evidence
const chipLink = f => `<a class="fnd" href="${isolateUrl(f.id)}" target="_blank" rel="noopener" title="${esc((f.evidence || {}).text || f.under || f.name)} — opens the isolation tab for this defect in a new browser tab"><span class="${CHIP[f.severity] || "chip-wrn"}">${esc(chipLabel(f))}</span></a>`;
// the statement: the program's sentences; the error sentences in red, "No error." in green, "not considered" in grey, the basis in small print
function statementHtml(t) {
  const sentences = String(t || "").split(/(?<=\.)\s+(?=[A-Z])/);
  return `<div class="stmt">` + sentences.map(x => {
    if (/^No error\.$/.test(x)) return `<span class="ok">${esc(x)}</span>`;
    if (/^Timing at the .* not considered\.$/.test(x)) return `<span class="nc">${esc(x)}</span>`;
    if (/^Basis: /.test(x)) return `<span class="bs">${esc(x)}</span>`;
    if (/^(Specification|Source): /.test(x)) return `<span class="spec">${esc(x)}</span>`;
    if (/^(To check by hand|Context): /.test(x)) return `<span>${esc(x)}</span>`;
    return x === sentences[0] ? `<span>${esc(x)}</span>` : `<span class="err">${esc(x)}</span>`;
  }).join(" ") + `</div>`;
}
function defectRow(c) {
  const txBad = new Set(c.findings.filter(f => f.level === "nvme_transaction" && f.severity === "error").map(f => f.rowid).concat(c.link_findings.map(f => f.ntx_rowid)));
  const tx = c.transactions || [];
  const col2 = tx.map(t => `<div class="tx ${txBad.has(t.rowid) ? "bad" : ""}" title="${esc(t.type || "")} · NVMe transaction file row ${t.rowid}">${esc(t.type || "-")}<span class="sub">number ${t.n ?? t.rowid}</span></div>`).join("") || `<span class="muted">no NVMe transactions under this command</span>`;
  const col3 = tx.map(t => `<div class="tx" title="time to complete = from the transaction's first packet to its last; the gap = the analyzer's Time Delta to the next row of the transaction file (a wait, not a length)">took ${esc(t.dur_ps_text || "-")}<span class="sub">gap to the next row ${esc(t.delta_ps_text || "-")}</span></div>`).join("");
  const chips = c.findings.concat(c.link_findings).map(chipLink).join("");
  const fid = c.first_finding;
  return `<tr class="${c.has_error ? "has-err" : ""}" data-key="${c.rowid_file}" data-cmd="${c.rowid_file}" data-n="${c.n}" ${fid ? `data-fid="${fid}"` : ""} title="${fid ? "click to open the isolation tab for this command's first error in a new browser tab" : "no defect in this command"}">` +
    `<td><b>${esc(opcName(c.opc, c.sqid))}</b><br><span class="muted small">command ${c.n}, queue ${c.sqid ?? "-"}, id ${c.cid ?? "-"}</span><br><span class="small">${esc(paramsText(c))}</span><br><span class="small">status: <span class="${c.status_ok ? "ok" : "bad"}">${esc(c.status_text || "-")}</span></span><br><span class="small">took <b>${esc(c.dur_ps_text || "not built")}</b> <span class="muted">(doorbell to completion-queue doorbell)</span></span>${c.role ? `<br><span class="muted small">${esc(c.role)}</span>` : ""}</td>` +
    `<td>${col2}</td><td>${col3}</td><td>${statementHtml(c.statement)}${chips ? `<div class="chips">${chips}</div>` : ""}</td></tr>`;
}
const TL = { link: "tl-link", nvme_transaction: "tl-ntx" };
function showTimingLimits(lim) {
  if (!lim) return;
  timingLimits = lim;
  const warn = [];
  for (const [level, id] of Object.entries(TL)) {
    const l = lim[level]; if (!l) continue;
    $(id + "-value").value = l.considered ? l.value : ""; $(id + "-unit").value = l.unit;
    $(id + "-source").textContent = l.considered ? `in force: ${l.text} · source: ${l.set_by_admin ? l.source : l.source}` : "in force: not considered (the field is empty: timing errors at this level are not counted)";
    if (!l.findings_match) warn.push(`the ${l.label} findings were computed with ${l.in_force ? l.in_force.text : "another limit"}; press apply to use ${l.text}`);
  }
  if (warn.length) $("tl-status").innerHTML = `<span class="warn">${esc(warn.join(" · "))}</span>`;
}
async function loadDefectTable() {
  if (!uid) { $("dt-table").querySelector("tbody").innerHTML = `<tr><td colspan="4" class="muted">open an upload first</td></tr>`; return; }
  if (!levelsPresent.includes("nvme_command")) { $("dt-table").querySelector("tbody").innerHTML = `<tr><td colspan="4" class="muted">the defect table needs the NVMe command file</td></tr>`; return; }
  if (dtList) dtList.destroy();
  const flt = $("dt-filter").value || "all";
  $("dt-page").textContent = "reading commands from disk…";
  dtList = new ScrollList({
    tbody: $("dt-table").querySelector("tbody"), colspan: 4, line: $("dt-page"), avgH: 120,
    fetch: q => api("GET", `/api/hier/uploads/${uid}/defect_table?filter=${flt}&filters=${encodeURIComponent(filtersFor("nvme_command"))}&${paging(q)}`),
    render: rows => rows.map(defectRow).join("") || `<tr><td colspan="4" class="muted">${{ all: "no commands", error: "no command has an error (none at the NVMe transaction level, none at the NVMe command level, no link transaction over the link limit)", no_error: "every command has an error" }[flt]}</td></tr>`,
    onPage: (r, isFirst) => {
      if (!isFirst) return;
      showTimingLimits(r.timing_limits);
      const what = { all: "commands (every command of the recording)", error: `command${r.total === 1 ? "" : "s"} with an error`, no_error: `command${r.total === 1 ? "" : "s"} without an error` }[flt];
      $("dt-count").textContent = `${num(r.total)} ${what}`;
      $("nav-defects").textContent = `${num(r.total)} ${what}`;
    },
  });
  await dtList.start();
}
// a click on a row opens the isolation tab for its first error finding; a click on a chip opens that finding's own tab (the links do it themselves)
$("dt-table").addEventListener("click", ev => {
  if (ev.target.closest("a")) return;
  const tr = ev.target.closest("tr[data-cmd]"); if (!tr) return;
  if (!tr.dataset.fid) { toast(`command ${tr.dataset.n} has no defect`); return; }
  window.open(isolateUrl(tr.dataset.fid), "_blank", "noopener");
});
$("dt-filter").onchange = () => loadDefectTable();
$("dt-refresh").onclick = () => loadDefectTable();
$("tl-defaults").onclick = () => {
  for (const [level, id] of Object.entries(TL)) { const d = timingLimits && timingLimits[level] && timingLimits[level].default; if (d) { $(id + "-value").value = d.value; $(id + "-unit").value = d.unit; } }
  $("tl-status").textContent = "the specification defaults are in the fields; press apply to use them";
};
$("tl-apply").onclick = async () => {
  if (!uid) { toast("open an upload first"); return; }
  const body = {};
  for (const [level, id] of Object.entries(TL)) {
    const v = $(id + "-value").value.trim();
    if (v && !(Number(v) > 0)) { toast("a limit must be a number above zero, or empty"); return; }
    const d = timingLimits && timingLimits[level] && timingLimits[level].default;
    body[level] = !v ? null : (d && Number(v) === Number(d.value) && $(id + "-unit").value === d.unit ? "default" : { value: v, unit: $(id + "-unit").value });
  }
  $("tl-apply").disabled = true; $("tl-status").textContent = "running the timing rules again…";
  try {
    const r = await api("PUT", `/api/hier/uploads/${uid}/timing_limits`, body);
    showTimingLimits(r.timing_limits);
    await loadDefectTable();
    const done = Object.entries(r.counts || {}).map(([level, c]) => `${LABEL[level]}s: ${num(c.after)} at or over ${r.timing_limits[level].considered ? r.timing_limits[level].text : "no limit (not considered)"} (${num(c.before)} before, ${c.seconds} s)`);
    $("tl-status").textContent = done.length ? `applied: ${done.join(" · ")} · ${num(r.commands_with_errors)} command${r.commands_with_errors === 1 ? "" : "s"} with an error` : "nothing changed: the limits are the ones in force";
  } catch (e) { $("tl-status").innerHTML = `<span class="bad">${esc(e.message)}</span>`; }
  $("tl-apply").disabled = false;
};

// ---- the earlier "one defect in full" panel (hidden; the isolation tab replaces it on page 3; kept so it can be reached from there later)
function catHtml(c) {
  if (!c) return `<span class="muted">no catalogue entry for this rule</span>`;
  return `<p><b>${esc(c.error || "")}</b> — ${esc(c.meaning || "")}</p>` + (c.spec ? `<p class="muted">specification: ${esc(c.spec)}</p>` : "") +
    (c.defects && c.defects.length ? `<p>Defects that produce it, by domain:</p><ul>${c.defects.map(d => `<li><b>${esc(d.domain)}</b>: ${esc(d.cause)}</li>`).join("")}</ul>` : "") +
    (c.extra_evidence && c.extra_evidence.length ? `<p>Evidence to add when the trace cannot show it: ${c.extra_evidence.map(esc).join("; ")}</p>` : "");
}
function procsHtml(k) {
  if (!k) return "";
  let h = `<p class="small">seen ${k.seen} time${k.seen === 1 ? "" : "s"}${k.scenario_name ? ` · scenario name: <b>${esc(k.scenario_name)}</b>` : ""}</p>`;
  if (!k.exact.length) h += `<p class="muted">nothing stored yet for this exact signature${k.similar.length ? `; ${k.similar.length} similar signature${k.similar.length === 1 ? "" : "s"} on other devices: ${k.similar.map(s => esc(s.scenario_name || s.display.slice(0, 50))).join("; ")}` : ""}.</p>`;
  else h += `<ol id="proc-list">` + k.exact.map(p => `<li data-pid="${p.id}"><b>v${p.version}</b> score ${esc(p.score_text)} (correct ${p.c_ok}, correct with edits ${p.c_ok_edit}, wrong ${p.c_wrong}, wrong with edits ${p.c_wrong_edit}; ordered by ${esc(p.ordered_by)}) · by ${esc(p.producer)}${p.test_path ? ` · test ${esc(p.test_path.split("/").pop())}` : ""}<br><span class="small">${esc(p.text || "")}</span>${p.outcome && p.outcome.expected ? `<br><span class="small">expected outcome: <b>${esc(p.outcome.expected.status || "")}</b>${p.outcome.expected.description ? " · " + esc(p.outcome.expected.description) : ""}${p.outcome.verified_by ? ` · verified by ${esc(p.outcome.verified_by)}` : " · <span class='warn'>not verified</span>"}</span>` : ""}<br><span class="mono small">${esc(JSON.stringify(p.steps).slice(0, 300))}</span><br><button class="small" data-use="${p.id}">use as proposal</button> <button class="small" data-up="${p.id}">move up</button></li>`).join("") + `</ol>`;
  if (k.lessons && k.lessons.length) h += `<p class="small">lessons: ${k.lessons.map(l => esc(l.text)).join(" · ")}</p>`;
  return h;
}
function wireProcs() {
  document.querySelectorAll("button[data-use]").forEach(b => b.onclick = () => { const p = curDetail.knowledge.exact.find(x => x.id === +b.dataset.use); curProposal = { scenario_name: curDetail.knowledge.scenario_name, summary: p.text, proposed_sequence: p.steps, procedure_id: p.id, producer: "stored procedure v" + p.version, expected_outcome: (p.outcome || {}).expected ? Object.assign({}, p.outcome.expected, { verified_by: p.outcome.verified_by }) : null, observed_outcome: (p.outcome || {}).observed }; renderProposal(); });
  document.querySelectorAll("button[data-up]").forEach(b => b.onclick = async () => {
    const ids = [...document.querySelectorAll("#proc-list li")].map(li => +li.dataset.pid); const i = ids.indexOf(+b.dataset.up); if (i > 0) { [ids[i - 1], ids[i]] = [ids[i], ids[i - 1]]; }
    const r = await api("POST", `/api/hier/uploads/${uid}/findings/${curFinding}/reorder`, { order: ids, admin: actor() });
    curDetail.knowledge = r.knowledge; $("dd-procs").innerHTML = procsHtml(r.knowledge); wireProcs();
  });
}
async function openFinding(fid) {
  curFinding = fid; curProposal = null; curWindow = null;
  const f = await api("GET", `/api/hier/uploads/${uid}/findings/${fid}`); curDetail = f;
  $("df-detail").hidden = false;
  $("dd-title").textContent = `Defect ${fid}: ${f.name}`;
  $("dd-what").innerHTML = `<p>${sevPill(f.severity)} rule <code>${esc(f.rule)}</code> at the ${esc(f.level_label)} level.</p>` +
    `<p class="spec"><b>${esc((f.basis || {}).words || "Source: none recorded.")}</b> <span class="muted small">${esc((f.basis || {}).text || "")}${(f.basis || {}).firm === false ? " (a suspect)" : ""}</span></p>` +
    `<p>${esc(f.name)}${f.value_ps_text ? ` — measured <b>${esc(f.value_ps_text)}</b>, limit <b>${esc(f.limit_ps_text)}</b> (${esc(f.limit_source || "")})` : ""}.</p>` +
    `<p>Affected command: <b>${esc(f.command ? f.command.summary : "outside any command")}</b>${f.command && f.command.row && f.command.row.role ? ` · ${esc(f.command.row.role)}` : ""}.</p>` +
    (f.cause ? `<p>Lowest-level cause inside this command: <b>${esc(f.cause.level)}</b> level, ${esc(f.cause.name)} (<a href="#" data-open-f="${f.cause.id}">defect ${f.cause.id}</a>).</p>` : "") +
    (f.other_findings_in_command.length ? `<p class="small">Other findings in the same command: ${f.other_findings_in_command.map(o => `<a href="#" data-open-f="${o.id}">${esc(o.level)} · ${esc(o.name)}</a>`).join("; ")}</p>` : "") +
    `<p class="muted small">source: ${esc(f.level_label)} file row ${f.rowid}${f.row_n !== null && f.row_n !== undefined ? ` (${esc(f.level_label)} number ${f.row_n})` : ""}</p>`;
  document.querySelectorAll("#dd-what a[data-open-f]").forEach(a => a.onclick = e => { e.preventDefault(); openFinding(+a.dataset.openF); });
  $("dd-chain").innerHTML = `<table><thead><tr><th>level</th><th>number</th><th>what</th><th>time</th><th>duration</th><th>errors</th></tr></thead><tbody>` + f.chain.map(c => `<tr><td>${esc(c.label)}</td><td>${c.n ?? "-"}</td><td>${esc(c.summary)}</td><td>${esc(c.t || "-")}</td><td>${esc(c.dur || "-")}</td><td>${esc(c.errors || "")}</td></tr>`).join("") + "</tbody></table>" +
    ((f.below || []).length ? `<h3 style="margin-top:10px">What lies below (from the row that fired down to its packets; the first rows of each level)</h3>` + f.below.map(b => `<p class="small muted" style="margin:4px 0 2px">under the ${esc(b.under_label)}: ${Object.entries(b.counts).map(([k, v]) => `${num(v)} ${LABEL[k]}${v === 1 ? "" : "s"}`).join(", ")}</p><table><thead><tr><th>level</th><th>number</th><th>what</th><th>time</th><th>duration</th><th>relation</th><th>errors</th></tr></thead><tbody>` + b.rows.map(c => `<tr class="${c.relation === "context" ? "ctx" : ""}"><td>${esc(c.label)}</td><td>${c.n ?? "-"}</td><td>${esc(c.summary)}</td><td>${esc(c.t || "-")}</td><td>${esc(c.dur || "-")}</td><td>${esc(c.relation || "")}</td><td>${esc(c.errors || "")}</td></tr>`).join("") + "</tbody></table>").join("") : "");
  $("dd-cat").innerHTML = catHtml(f.catalogue);
  $("dd-sig").innerHTML = `${esc(f.signature.display)}<br><span class="muted">exact key ${esc(f.signature.fine.slice(0, 16))}… · family key ${esc(f.signature.coarse.slice(0, 16))}… · device ${esc(f.signature.device || "unknown")}, firmware ${esc(f.signature.firmware || "unknown")}</span>`;
  $("dd-procs").innerHTML = procsHtml(f.knowledge); wireProcs(); gateModel(f.knowledge);
  $("dd-observed").textContent = f.observed_outcome || "";
  const eo0 = f.expected_outcome_default || {};
  $("dd-exp-status").value = eo0.status || ""; $("dd-exp-desc").value = eo0.description || ""; $("dd-exp-check").value = eo0.check || ""; $("dd-verified").checked = false;
  $("dw-level").innerHTML = (f.levels_present || LEVELS).map(l => `<option value="${l}" ${l === "nvme_command" ? "selected" : ""}>${esc(LABEL[l])}</option>`).join("");
  $("dd-window").innerHTML = ""; $("dd-proposal").innerHTML = `<span class="muted">nothing proposed yet</span>`; $("dd-testcase").textContent = "";
  $("dd-chat").innerHTML = (f.chat || []).map(m => `<p><b>${esc(m.role)}</b>: ${esc(m.text)}</p>`).join("") || `<span class="muted">no messages yet</span>`;
  showPage("defects"); $("df-detail").scrollIntoView({ behavior: "smooth" });
}
function windowHtml(w) {
  const low = w.level !== "nvme_command";
  const below = r => r.below_count ? Object.entries(r.below_count).map(([k, v]) => `${v} ${LABEL[k]}${v === 1 ? "" : "s"}`).join(", ") : "";
  return `<p class="small muted">${esc(w.label)} level · ${w.n} above, ${w.m} below · ${w.same_queue ? "same queue" : "all queues"}${w.note ? ` · <span class="warn">${esc(w.note)}</span>` : ""}</p><table><thead><tr><th></th><th>row</th><th>what</th>${low ? "<th>belongs to command</th><th>below it</th>" : ""}<th>gap before</th><th>duration</th><th>findings</th><th>kept?</th></tr></thead><tbody>` +
    w.rows.map(r => `<tr class="${r.position === "fault" ? "sel" : ""} ${r.keep === false ? "ctx" : ""}"><td>${esc(r.position)}</td><td>${r.n ?? r.rowid_file}</td><td>${esc(r.summary)}</td>${low ? `<td class="small">${esc(r.command || "")}</td><td class="small">${esc(below(r))}</td>` : ""}<td>${esc(r.gap_text || "")}</td><td>${esc(r.dur_ps_text || "")}</td><td>${(r.findings || []).map(x => esc(x.name)).join("; ")}</td><td class="small">${r.keep === undefined ? "" : (r.keep ? "kept: " + esc((r.why || []).join("; ")) : "dropped")}</td></tr>`).join("") + "</tbody></table>" +
    (low ? `<p class="small muted">"Keep only what matters" works on the command level: it maps this row to its command first.</p>` : "");
}
$("dw-get").onclick = async () => {
  const q = new URLSearchParams({ level: $("dw-level").value, n: $("dw-n").value, m: $("dw-m").value, queue: $("dw-same").checked ? "same" : "all" });
  $("dd-window").innerHTML = `<span class="muted small">reading the window from disk…</span>`;
  try { curWindow = await api("GET", `/api/hier/uploads/${uid}/findings/${curFinding}/window?${q}`); $("dd-window").innerHTML = windowHtml(curWindow); }
  catch (e) { $("dd-window").innerHTML = `<p class="bad">${esc(e.message)}</p>`; }
};
$("dw-opt").onclick = async () => {
  let r;
  try { r = await api("POST", `/api/hier/uploads/${uid}/findings/${curFinding}/optimise`, { level: "nvme_command", n: $("dw-n").value, m: $("dw-m").value, same_queue: $("dw-same").checked }); }
  catch (e) { $("dd-window").innerHTML = `<p class="bad">${esc(e.message)}</p>`; return; }
  curWindow = Object.assign({}, r.window, { rows: r.rows });
  $("dd-window").innerHTML = windowHtml(curWindow) + `<p class="small">kept ${r.kept_above} of ${r.kept_above + r.dropped_above} above, ${r.kept_below} of ${r.kept_below + r.dropped_below} below → ${r.steps.length} steps.</p>`;
  curProposal = { scenario_name: curDetail.knowledge.scenario_name, summary: "dependency-kept sequence (computed by code)", proposed_sequence: r.steps, producer: "optimiser" };
  renderProposal();
};
function renderProposal() {
  const p = curProposal; if (!p) return;
  $("dd-proposal").innerHTML = `<p><b>${esc(p.scenario_name || "(no name yet)")}</b> <span class="muted small">by ${esc(p.producer || "model")}</span></p><p class="small">${esc(p.summary || "")}</p>` +
    (p.checks && !p.checks.ok ? `<p class="bad small">checks: ${p.checks.problems.map(esc).join("; ")}</p>` : "") +
    `<ol class="small">${(p.proposed_sequence || []).map(s => `<li>${esc(s.command)} ${esc(JSON.stringify(s.parameters || {}))} · gap ${s.gap_us ?? 10} µs${s.expected ? ` · <span class="muted">${esc(s.expected)}</span>` : ""}</li>`).join("")}</ol>` +
    (p.assumptions && p.assumptions.length ? `<p class="muted small">assumptions: ${p.assumptions.map(esc).join("; ")}</p>` : "");
  $("dd-edits").value = JSON.stringify(p.proposed_sequence || [], null, 1);
  const eo = p.expected_outcome || (curDetail && curDetail.expected_outcome_default) || {};
  $("dd-exp-status").value = eo.status || ""; $("dd-exp-desc").value = eo.description || ""; $("dd-exp-check").value = eo.check || "";
  $("dd-verified").checked = !!eo.verified_by;
  if (p.observed_outcome) $("dd-observed").textContent = p.observed_outcome;
}
function outcomeFromForm() {
  const admin = actor();
  return { observed: $("dd-observed").textContent, expected: { status: $("dd-exp-status").value.trim(), description: $("dd-exp-desc").value.trim(), check: $("dd-exp-check").value.trim() },
           verified_by: $("dd-verified").checked ? admin : null };
}
function requireVerified() {
  if (!$("dd-exp-status").value.trim()) { toast("fill in the expected outcome first (the status a correct drive should return)"); return false; }
  if (!$("dd-verified").checked) { toast("tick \"I have verified the expected outcome\" first"); return false; }
  return true;
}
function gateModel(k) {
  // the model is asked only when nothing is stored, or when the admin asks for a new proposal anyway
  const stored = k && k.exact && k.exact.length;
  $("dd-anyway-label").hidden = !stored; $("dd-anyway").checked = false;
  $("dd-send").disabled = !!stored;
  $("dd-stored-note").hidden = !stored;
  if (stored) $("dd-stored-note").innerHTML = `<b>${k.exact.length} stored procedure${k.exact.length === 1 ? "" : "s"} exist${k.exact.length === 1 ? "s" : ""} for this signature.</b> Use one with "use as proposal" above, then judge it with the four buttons. The model is not asked again unless you tick "a new proposal anyway".`;
}
$("dd-anyway").onchange = () => { $("dd-send").disabled = !$("dd-anyway").checked && !!(curDetail && curDetail.knowledge && curDetail.knowledge.exact.length); };
$("dd-send").onclick = async () => {
  const admin = actor();
  $("dd-chat-status").textContent = "asking…";
  try {
    const r = await api("POST", `/api/hier/uploads/${uid}/findings/${curFinding}/chat`, { message: $("dd-msg").value, admin, level: $("dw-level").value || "nvme_command", n: $("dw-n").value, m: $("dw-m").value, same_queue: $("dw-same").checked, anyway: $("dd-anyway").checked });
    $("dd-chat").innerHTML = r.history.map(m => `<p><b>${esc(m.role)}</b>: ${esc(m.text)}</p>`).join("");
    curProposal = r.answer; renderProposal(); $("dd-chat-status").textContent = `answered by ${r.answer.producer}`;
  } catch (e) { $("dd-chat-status").innerHTML = `<span class="bad">${esc(e.message)}</span>`; }
};
document.querySelectorAll("button[data-sig]").forEach(b => b.onclick = async () => {
  const admin = actor();
  if (!curProposal) { toast("nothing to judge: ask the model or pick a stored procedure first"); return; }
  let edited = null;
  if (b.dataset.sig.endsWith("with_edits")) { try { edited = JSON.parse($("dd-edits").value); } catch (e) { toast("the edits must be a JSON list of steps"); return; } }
  if (b.dataset.sig.startsWith("correct") && !requireVerified()) return;
  const body = { signal: b.dataset.sig, admin, procedure_id: curProposal.procedure_id || null, edited_steps: edited, edited_text: curProposal.summary,
    proposal_steps: curProposal.proposed_sequence, proposal_text: curProposal.summary, scenario_name: curProposal.scenario_name, outcome: outcomeFromForm() };
  const r = await api("POST", `/api/hier/uploads/${uid}/findings/${curFinding}/signal`, body);
  curDetail.knowledge = r.knowledge; $("dd-procs").innerHTML = procsHtml(r.knowledge); wireProcs(); gateModel(r.knowledge);
  $("dd-sig-status").textContent = `recorded: ${b.dataset.sig.replace(/_/g, " ")}` + (r.result.new_procedure_id ? ` → stored as procedure ${r.result.new_procedure_id} with its expected outcome` : "");
  if (r.result.new_procedure_id) curProposal.procedure_id = r.result.new_procedure_id;
});
$("dd-test").onclick = async () => {
  if (!requireVerified()) return;
  const steps = curProposal ? curProposal.proposed_sequence : null;
  const r = await api("POST", `/api/hier/uploads/${uid}/findings/${curFinding}/testcase`, { steps, scenario_name: curProposal ? curProposal.scenario_name : null, admin: actor(), procedure_id: curProposal ? curProposal.procedure_id : null, n: $("dw-n").value, m: $("dw-m").value, same_queue: $("dw-same").checked, outcome: outcomeFromForm() });
  $("dd-testcase").textContent = `# written to ${r.path}\n` + r.text;
};
// the hidden panel can be opened by another tab or by the console: window.hierOpenDefect(findingId)
window.hierOpenDefect = openFinding;

// the build this server runs, shown in the left column so that an old copy is never mistaken for the new one
api("GET", "/api/hier/version").then(v => { const el = $("build-line"); if (el) el.textContent = `${v.build}${(v.stored_headers || []).length ? " · stored real headers for " + v.stored_headers.length + " files" : ""}`; }).catch(() => {});
